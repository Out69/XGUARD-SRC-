package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.StatCollector;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockRedstoneRepeater
  extends BlockRedstoneDiode
{
  private static boolean lllIIllllIIlII(int ???)
  {
    String llllllllllllllIIlllIlIIlllIlIlll;
    return ??? == 0;
  }
  
  protected int getDelay(IBlockState llllllllllllllIIlllIlIlIIlllIllI)
  {
    ;
    return ((Integer)llllllllllllllIIlllIlIlIIlllIllI.getValue(DELAY)).intValue() * lIIlIlllIIIII[3];
  }
  
  private static void lllIIllllIIIlI()
  {
    lIIlIllIlllll = new String[lIIlIlllIIIII[4]];
    lIIlIllIlllll[lIIlIlllIIIII[0]] = lllIIllllIIIII("DTkNAg0F", "aVnih");
    lIIlIllIlllll[lIIlIlllIIIII[1]] = lllIIllllIIIIl("zWuIzQmmpiU=", "dfYtn");
    lIIlIllIlllll[lIIlIlllIIIII[3]] = lllIIllllIIIII("JxInGlcqDy0THGAIIxoc", "NfBwy");
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIIlllIlIlIIIIIlIlI)
  {
    ;
    ;
    int llllllllllllllIIlllIlIlIIIIIlIIl = lIIlIlllIIIII[0];
    llllllllllllllIIlllIlIlIIIIIlIIl |= ((EnumFacing)llllllllllllllIIlllIlIlIIIIIlIII.getValue(FACING)).getHorizontalIndex();
    llllllllllllllIIlllIlIlIIIIIlIIl |= ((Integer)llllllllllllllIIlllIlIlIIIIIlIII.getValue(DELAY)).intValue() - lIIlIlllIIIII[1] << lIIlIlllIIIII[3];
    return llllllllllllllIIlllIlIlIIIIIlIIl;
  }
  
  protected IBlockState getPoweredState(IBlockState llllllllllllllIIlllIlIlIIllIlIll)
  {
    ;
    ;
    ;
    ;
    Integer llllllllllllllIIlllIlIlIIllIlllI = (Integer)llllllllllllllIIlllIlIlIIllIlIll.getValue(DELAY);
    Boolean llllllllllllllIIlllIlIlIIllIllIl = (Boolean)llllllllllllllIIlllIlIlIIllIllll.getValue(LOCKED);
    EnumFacing llllllllllllllIIlllIlIlIIllIllII = (EnumFacing)llllllllllllllIIlllIlIlIIllIllll.getValue(FACING);
    return Blocks.powered_repeater.getDefaultState().withProperty(FACING, llllllllllllllIIlllIlIlIIllIllII).withProperty(DELAY, llllllllllllllIIlllIlIlIIllIlllI).withProperty(LOCKED, llllllllllllllIIlllIlIlIIllIllIl);
  }
  
  private static String lllIIllllIIIII(String llllllllllllllIIlllIlIIllllIllII, String llllllllllllllIIlllIlIIllllIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIlllIlIIllllIllII = new String(Base64.getDecoder().decode(llllllllllllllIIlllIlIIllllIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIlllIlIIllllIlIlI = new StringBuilder();
    char[] llllllllllllllIIlllIlIIllllIlIIl = llllllllllllllIIlllIlIIllllIIllI.toCharArray();
    int llllllllllllllIIlllIlIIllllIlIII = lIIlIlllIIIII[0];
    boolean llllllllllllllIIlllIlIIllllIIIlI = llllllllllllllIIlllIlIIllllIllII.toCharArray();
    short llllllllllllllIIlllIlIIllllIIIIl = llllllllllllllIIlllIlIIllllIIIlI.length;
    int llllllllllllllIIlllIlIIllllIIIII = lIIlIlllIIIII[0];
    while (lllIIllllIIlll(llllllllllllllIIlllIlIIllllIIIII, llllllllllllllIIlllIlIIllllIIIIl))
    {
      char llllllllllllllIIlllIlIIllllIllIl = llllllllllllllIIlllIlIIllllIIIlI[llllllllllllllIIlllIlIIllllIIIII];
      "".length();
      "".length();
      if ("   ".length() != "   ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIlllIlIIllllIlIlI);
  }
  
  public void breakBlock(World llllllllllllllIIlllIlIlIIIIllIlI, BlockPos llllllllllllllIIlllIlIlIIIIllIIl, IBlockState llllllllllllllIIlllIlIlIIIIlIlII)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIIlllIlIlIIIIllIll.breakBlock(llllllllllllllIIlllIlIlIIIIllIlI, llllllllllllllIIlllIlIlIIIIllIIl, llllllllllllllIIlllIlIlIIIIlIlII);
    llllllllllllllIIlllIlIlIIIIllIll.notifyNeighbors(llllllllllllllIIlllIlIlIIIIllIlI, llllllllllllllIIlllIlIlIIIIllIIl, llllllllllllllIIlllIlIlIIIIlIlII);
  }
  
  public String getLocalizedName()
  {
    return StatCollector.translateToLocal(lIIlIllIlllll[lIIlIlllIIIII[3]]);
  }
  
  public boolean onBlockActivated(World llllllllllllllIIlllIlIlIIlllllII, BlockPos llllllllllllllIIlllIlIlIlIIIIIll, IBlockState llllllllllllllIIlllIlIlIlIIIIIlI, EntityPlayer llllllllllllllIIlllIlIlIlIIIIIIl, EnumFacing llllllllllllllIIlllIlIlIlIIIIIII, float llllllllllllllIIlllIlIlIIlllllll, float llllllllllllllIIlllIlIlIIllllllI, float llllllllllllllIIlllIlIlIIlllllIl)
  {
    ;
    ;
    ;
    ;
    if (lllIIllllIIlII(capabilities.allowEdit)) {
      return lIIlIlllIIIII[0];
    }
    "".length();
    return lIIlIlllIIIII[1];
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIIlllIlIlIIlIllIIl, Random llllllllllllllIIlllIlIlIIlIllIII, int llllllllllllllIIlllIlIlIIlIlIlll)
  {
    return Items.repeater;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIIlllIlIlIIIIIIlII, new IProperty[] { FACING, DELAY, LOCKED });
  }
  
  private static boolean lllIIllllIIllI(int ???)
  {
    String llllllllllllllIIlllIlIIlllIllIIl;
    return ??? != 0;
  }
  
  static
  {
    lllIIllllIIIll();
    lllIIllllIIIlI();
    LOCKED = PropertyBool.create(lIIlIllIlllll[lIIlIlllIIIII[0]]);
  }
  
  public boolean isLocked(IBlockAccess llllllllllllllIIlllIlIlIIlIIlIlI, BlockPos llllllllllllllIIlllIlIlIIlIIlIIl, IBlockState llllllllllllllIIlllIlIlIIlIIllII)
  {
    ;
    ;
    ;
    ;
    if (lllIIllllIIlIl(llllllllllllllIIlllIlIlIIlIIllll.getPowerOnSides(llllllllllllllIIlllIlIlIIlIIlIlI, llllllllllllllIIlllIlIlIIlIIlIIl, llllllllllllllIIlllIlIlIIlIIllII))) {
      return lIIlIlllIIIII[1];
    }
    return lIIlIlllIIIII[0];
  }
  
  protected boolean canPowerSide(Block llllllllllllllIIlllIlIlIIlIIIlII)
  {
    ;
    return isRedstoneRepeaterBlockID(llllllllllllllIIlllIlIlIIlIIIlII);
  }
  
  protected BlockRedstoneRepeater(boolean llllllllllllllIIlllIlIlIlIIlIlll)
  {
    llllllllllllllIIlllIlIlIlIIllIlI.<init>(llllllllllllllIIlllIlIlIlIIlIlll);
    llllllllllllllIIlllIlIlIlIIllIlI.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(DELAY, Integer.valueOf(lIIlIlllIIIII[1])).withProperty(LOCKED, Boolean.valueOf(lIIlIlllIIIII[0])));
  }
  
  public void randomDisplayTick(World llllllllllllllIIlllIlIlIIIlIlIlI, BlockPos llllllllllllllIIlllIlIlIIIlIlIIl, IBlockState llllllllllllllIIlllIlIlIIIlIlIII, Random llllllllllllllIIlllIlIlIIIlIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIllllIIllI(isRepeaterPowered))
    {
      EnumFacing llllllllllllllIIlllIlIlIIIllIIlI = (EnumFacing)llllllllllllllIIlllIlIlIIIlIlIII.getValue(FACING);
      double llllllllllllllIIlllIlIlIIIllIIIl = llllllllllllllIIlllIlIlIIIllIlIl.getX() + 0.5F + (llllllllllllllIIlllIlIlIIIlIIlll.nextFloat() - 0.5F) * 0.2D;
      double llllllllllllllIIlllIlIlIIIllIIII = llllllllllllllIIlllIlIlIIIllIlIl.getY() + 0.4F + (llllllllllllllIIlllIlIlIIIlIIlll.nextFloat() - 0.5F) * 0.2D;
      double llllllllllllllIIlllIlIlIIIlIllll = llllllllllllllIIlllIlIlIIIllIlIl.getZ() + 0.5F + (llllllllllllllIIlllIlIlIIIlIIlll.nextFloat() - 0.5F) * 0.2D;
      float llllllllllllllIIlllIlIlIIIlIlllI = -5.0F;
      if (lllIIllllIIllI(llllllllllllllIIlllIlIlIIIlIIlll.nextBoolean())) {
        llllllllllllllIIlllIlIlIIIlIlllI = ((Integer)llllllllllllllIIlllIlIlIIIlIlIII.getValue(DELAY)).intValue() * lIIlIlllIIIII[3] - lIIlIlllIIIII[1];
      }
      llllllllllllllIIlllIlIlIIIlIlllI /= 16.0F;
      double llllllllllllllIIlllIlIlIIIlIllIl = llllllllllllllIIlllIlIlIIIlIlllI * llllllllllllllIIlllIlIlIIIllIIlI.getFrontOffsetX();
      double llllllllllllllIIlllIlIlIIIlIllII = llllllllllllllIIlllIlIlIIIlIlllI * llllllllllllllIIlllIlIlIIIllIIlI.getFrontOffsetZ();
      llllllllllllllIIlllIlIlIIIlIlIlI.spawnParticle(EnumParticleTypes.REDSTONE, llllllllllllllIIlllIlIlIIIllIIIl + llllllllllllllIIlllIlIlIIIlIllIl, llllllllllllllIIlllIlIlIIIllIIII, llllllllllllllIIlllIlIlIIIlIllll + llllllllllllllIIlllIlIlIIIlIllII, 0.0D, 0.0D, 0.0D, new int[lIIlIlllIIIII[0]]);
    }
  }
  
  private static boolean lllIIllllIIlll(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIIlllIlIIlllIllIll;
    return ??? < i;
  }
  
  public IBlockState getActualState(IBlockState llllllllllllllIIlllIlIlIlIIlIIII, IBlockAccess llllllllllllllIIlllIlIlIlIIIlIll, BlockPos llllllllllllllIIlllIlIlIlIIIlIlI)
  {
    ;
    ;
    ;
    ;
    return llllllllllllllIIlllIlIlIlIIlIIII.withProperty(LOCKED, Boolean.valueOf(llllllllllllllIIlllIlIlIlIIlIIIl.isLocked(llllllllllllllIIlllIlIlIlIIIlIll, llllllllllllllIIlllIlIlIlIIIlIlI, llllllllllllllIIlllIlIlIlIIlIIII)));
  }
  
  public Item getItem(World llllllllllllllIIlllIlIlIIlIlIlIl, BlockPos llllllllllllllIIlllIlIlIIlIlIlII)
  {
    return Items.repeater;
  }
  
  protected IBlockState getUnpoweredState(IBlockState llllllllllllllIIlllIlIlIIlIllllI)
  {
    ;
    ;
    ;
    ;
    Integer llllllllllllllIIlllIlIlIIllIIIIl = (Integer)llllllllllllllIIlllIlIlIIlIllllI.getValue(DELAY);
    Boolean llllllllllllllIIlllIlIlIIllIIIII = (Boolean)llllllllllllllIIlllIlIlIIllIIIlI.getValue(LOCKED);
    EnumFacing llllllllllllllIIlllIlIlIIlIlllll = (EnumFacing)llllllllllllllIIlllIlIlIIllIIIlI.getValue(FACING);
    return Blocks.unpowered_repeater.getDefaultState().withProperty(FACING, llllllllllllllIIlllIlIlIIlIlllll).withProperty(DELAY, llllllllllllllIIlllIlIlIIllIIIIl).withProperty(LOCKED, llllllllllllllIIlllIlIlIIllIIIII);
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIIlllIlIlIIIIIlllI)
  {
    ;
    ;
    return llllllllllllllIIlllIlIlIIIIIllll.getDefaultState().withProperty(FACING, EnumFacing.getHorizontal(llllllllllllllIIlllIlIlIIIIIlllI)).withProperty(LOCKED, Boolean.valueOf(lIIlIlllIIIII[0])).withProperty(DELAY, Integer.valueOf(lIIlIlllIIIII[1] + (llllllllllllllIIlllIlIlIIIIIlllI >> lIIlIlllIIIII[3])));
  }
  
  private static String lllIIllllIIIIl(String llllllllllllllIIlllIlIIlllllllII, String llllllllllllllIIlllIlIIllllllIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIlllIlIIlllllllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIIlllIlIIllllllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIIlllIlIIllllllllI = Cipher.getInstance("Blowfish");
      llllllllllllllIIlllIlIIllllllllI.init(lIIlIlllIIIII[3], llllllllllllllIIlllIlIIlllllllll);
      return new String(llllllllllllllIIlllIlIIllllllllI.doFinal(Base64.getDecoder().decode(llllllllllllllIIlllIlIIlllllllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIlllIlIIlllllllIl)
    {
      llllllllllllllIIlllIlIIlllllllIl.printStackTrace();
    }
    return null;
  }
  
  private static void lllIIllllIIIll()
  {
    lIIlIlllIIIII = new int[5];
    lIIlIlllIIIII[0] = ((0xA4 ^ 0xAF) & (0x3E ^ 0x35 ^ 0xFFFFFFFF) & ((0xAB ^ 0xAD) & (0x9B ^ 0x9D ^ 0xFFFFFFFF) ^ 0xFFFFFFFF));
    lIIlIlllIIIII[1] = " ".length();
    lIIlIlllIIIII[2] = (107 + '' - 78 + 11 ^ 109 + 82 - 99 + 94);
    lIIlIlllIIIII[3] = "  ".length();
    lIIlIlllIIIII[4] = "   ".length();
  }
  
  private static boolean lllIIllllIIlIl(int ???)
  {
    String llllllllllllllIIlllIlIIlllIlIlIl;
    return ??? > 0;
  }
}

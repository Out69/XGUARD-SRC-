package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockRedstoneLight
  extends Block
{
  public BlockRedstoneLight(boolean lIIIllIlllIIllI)
  {
    lIIIllIlllIlIIl.<init>(Material.redstoneLight);
    isOn = lIIIllIlllIIllI;
    if (lllIlIIIIl(lIIIllIlllIIllI)) {
      "".length();
    }
  }
  
  private static boolean lllIlIIIlI(int ???)
  {
    boolean lIIIllIlIlllIIl;
    return ??? == 0;
  }
  
  public void updateTick(World lIIIllIllIIllII, BlockPos lIIIllIllIIIllI, IBlockState lIIIllIllIIlIlI, Random lIIIllIllIIlIIl)
  {
    ;
    ;
    ;
    if ((lllIlIIIlI(isRemote)) && (lllIlIIIIl(isOn)) && (lllIlIIIlI(lIIIllIllIIllII.isBlockPowered(lIIIllIllIIlIll)))) {
      "".length();
    }
  }
  
  public Item getItemDropped(IBlockState lIIIllIllIIIlII, Random lIIIllIllIIIIll, int lIIIllIllIIIIlI)
  {
    return Item.getItemFromBlock(Blocks.redstone_lamp);
  }
  
  static {}
  
  public Item getItem(World lIIIllIllIIIIII, BlockPos lIIIllIlIllllll)
  {
    return Item.getItemFromBlock(Blocks.redstone_lamp);
  }
  
  private static void lllIlIIIII()
  {
    lIIIIlllI = new int[2];
    lIIIIlllI[0] = "  ".length();
    lIIIIlllI[1] = (0xA7 ^ 0xA3);
  }
  
  private static boolean lllIlIIIIl(int ???)
  {
    short lIIIllIlIlllIll;
    return ??? != 0;
  }
  
  public void onNeighborBlockChange(World lIIIllIllIlIlll, BlockPos lIIIllIllIlIllI, IBlockState lIIIllIllIlIlIl, Block lIIIllIllIlIlII)
  {
    ;
    ;
    ;
    if (lllIlIIIlI(isRemote)) {
      if ((lllIlIIIIl(isOn)) && (lllIlIIIlI(lIIIllIllIlIlll.isBlockPowered(lIIIllIllIlIIIl))))
      {
        lIIIllIllIlIlll.scheduleUpdate(lIIIllIllIlIIIl, lIIIllIllIlIIll, lIIIIlllI[1]);
        "".length();
        if (((0xA1 ^ 0xBC) & (0x2F ^ 0x32 ^ 0xFFFFFFFF)) <= (0x8D ^ 0x89)) {}
      }
      else if ((lllIlIIIlI(isOn)) && (lllIlIIIIl(lIIIllIllIlIlll.isBlockPowered(lIIIllIllIlIIIl))))
      {
        "".length();
      }
    }
  }
  
  public void onBlockAdded(World lIIIllIlllIIIIl, BlockPos lIIIllIllIlllII, IBlockState lIIIllIllIlllll)
  {
    ;
    ;
    ;
    if (lllIlIIIlI(isRemote)) {
      if ((lllIlIIIIl(isOn)) && (lllIlIIIlI(lIIIllIlllIIIIl.isBlockPowered(lIIIllIllIlllII))))
      {
        "".length();
        "".length();
        if ("  ".length() < (0x7A ^ 0x7E)) {}
      }
      else if ((lllIlIIIlI(isOn)) && (lllIlIIIIl(lIIIllIlllIIIIl.isBlockPowered(lIIIllIllIlllII))))
      {
        "".length();
      }
    }
  }
  
  protected ItemStack createStackedBlock(IBlockState lIIIllIlIllllIl)
  {
    return new ItemStack(Blocks.redstone_lamp);
  }
}

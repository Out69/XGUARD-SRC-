package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.World;

public class BlockBush
  extends Block
{
  public boolean isFullCube()
  {
    return lIIlIIIIIIIl[1];
  }
  
  private static void llIlllllIIIIl()
  {
    lIIlIIIIIIIl = new int[3];
    lIIlIIIIIIIl[0] = " ".length();
    lIIlIIIIIIIl[1] = ((0x6E ^ 0x30) & (0x6 ^ 0x58 ^ 0xFFFFFFFF));
    lIIlIIIIIIIl[2] = "   ".length();
  }
  
  public void onNeighborBlockChange(World lllllllllllllllIllIlIlllIllIllII, BlockPos lllllllllllllllIllIlIlllIllIlIll, IBlockState lllllllllllllllIllIlIlllIllIlIlI, Block lllllllllllllllIllIlIlllIllIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllIlIlllIllIlIII.onNeighborBlockChange(lllllllllllllllIllIlIlllIllIllII, lllllllllllllllIllIlIlllIllIIllI, lllllllllllllllIllIlIlllIllIlIlI, lllllllllllllllIllIlIlllIllIIlII);
    lllllllllllllllIllIlIlllIllIlIII.checkAndDropBlock(lllllllllllllllIllIlIlllIllIllII, lllllllllllllllIllIlIlllIllIIllI, lllllllllllllllIllIlIlllIllIlIlI);
  }
  
  protected BlockBush()
  {
    lllllllllllllllIllIlIllllIIlIIlI.<init>(Material.plants);
  }
  
  private static boolean llIlllllIIIll(Object ???, Object arg1)
  {
    Object localObject;
    String lllllllllllllllIllIlIlllIIllIllI;
    return ??? != localObject;
  }
  
  public boolean canBlockStay(World lllllllllllllllIllIlIlllIlIIIIlI, BlockPos lllllllllllllllIllIlIlllIlIIIlIl, IBlockState lllllllllllllllIllIlIlllIlIIIlII)
  {
    ;
    ;
    ;
    return lllllllllllllllIllIlIlllIlIIIlll.canPlaceBlockOn(lllllllllllllllIllIlIlllIlIIIIlI.getBlockState(lllllllllllllllIllIlIlllIlIIIlIl.down()).getBlock());
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World lllllllllllllllIllIlIlllIIllllll, BlockPos lllllllllllllllIllIlIlllIIlllllI, IBlockState lllllllllllllllIllIlIlllIIllllIl)
  {
    return null;
  }
  
  public boolean isOpaqueCube()
  {
    return lIIlIIIIIIIl[1];
  }
  
  protected void checkAndDropBlock(World lllllllllllllllIllIlIlllIlIlIIIl, BlockPos lllllllllllllllIllIlIlllIlIIllII, IBlockState lllllllllllllllIllIlIlllIlIIllll)
  {
    ;
    ;
    ;
    ;
    if (llIlllllIIlII(lllllllllllllllIllIlIlllIlIlIIlI.canBlockStay(lllllllllllllllIllIlIlllIlIlIIIl, lllllllllllllllIllIlIlllIlIIllII, lllllllllllllllIllIlIlllIlIIllll)))
    {
      lllllllllllllllIllIlIlllIlIlIIlI.dropBlockAsItem(lllllllllllllllIllIlIlllIlIlIIIl, lllllllllllllllIllIlIlllIlIIllII, lllllllllllllllIllIlIlllIlIIllll, lIIlIIIIIIIl[1]);
      "".length();
    }
  }
  
  protected boolean canPlaceBlockOn(Block lllllllllllllllIllIlIlllIlllIIll)
  {
    ;
    if ((llIlllllIIIll(lllllllllllllllIllIlIlllIlllIIll, Blocks.grass)) && (llIlllllIIIll(lllllllllllllllIllIlIlllIlllIlII, Blocks.dirt)) && (llIlllllIIIll(lllllllllllllllIllIlIlllIlllIlII, Blocks.farmland))) {
      return lIIlIIIIIIIl[1];
    }
    return lIIlIIIIIIIl[0];
  }
  
  protected BlockBush(Material lllllllllllllllIllIlIllllIIIIllI, MapColor lllllllllllllllIllIlIllllIIIIlIl)
  {
    lllllllllllllllIllIlIllllIIIIlll.<init>(lllllllllllllllIllIlIllllIIIIIlI, lllllllllllllllIllIlIllllIIIIlIl);
    "".length();
    float lllllllllllllllIllIlIllllIIIIlII = 0.2F;
    lllllllllllllllIllIlIllllIIIIlll.setBlockBounds(0.5F - lllllllllllllllIllIlIllllIIIIlII, 0.0F, 0.5F - lllllllllllllllIllIlIllllIIIIlII, 0.5F + lllllllllllllllIllIlIllllIIIIlII, lllllllllllllllIllIlIllllIIIIlII * 3.0F, 0.5F + lllllllllllllllIllIlIllllIIIIlII);
    "".length();
  }
  
  public void updateTick(World lllllllllllllllIllIlIlllIlIllIIl, BlockPos lllllllllllllllIllIlIlllIlIlllIl, IBlockState lllllllllllllllIllIlIlllIlIlllII, Random lllllllllllllllIllIlIlllIlIllIll)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIllIlIlllIlIlllll.checkAndDropBlock(lllllllllllllllIllIlIlllIlIllIIl, lllllllllllllllIllIlIlllIlIllIII, lllllllllllllllIllIlIlllIlIlllII);
  }
  
  private static boolean llIlllllIIIlI(int ???)
  {
    String lllllllllllllllIllIlIlllIIllIlII;
    return ??? != 0;
  }
  
  private static boolean llIlllllIIlII(int ???)
  {
    String lllllllllllllllIllIlIlllIIllIIlI;
    return ??? == 0;
  }
  
  protected BlockBush(Material lllllllllllllllIllIlIllllIIIllII)
  {
    lllllllllllllllIllIlIllllIIIllll.<init>(lllllllllllllllIllIlIllllIIIllII, lllllllllllllllIllIlIllllIIIllII.getMaterialMapColor());
  }
  
  static {}
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public boolean canPlaceBlockAt(World lllllllllllllllIllIlIlllIllllIII, BlockPos lllllllllllllllIllIlIlllIlllIlll)
  {
    ;
    ;
    ;
    if ((llIlllllIIIlI(lllllllllllllllIllIlIlllIllllIIl.canPlaceBlockAt(lllllllllllllllIllIlIlllIllllIll, lllllllllllllllIllIlIlllIlllIlll))) && (llIlllllIIIlI(lllllllllllllllIllIlIlllIllllIIl.canPlaceBlockOn(lllllllllllllllIllIlIlllIllllIll.getBlockState(lllllllllllllllIllIlIlllIlllIlll.down()).getBlock())))) {
      return lIIlIIIIIIIl[0];
    }
    return lIIlIIIIIIIl[1];
  }
}

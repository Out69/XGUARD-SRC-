package net.minecraft.block;

public class BlockButtonWood
  extends BlockButton
{
  protected BlockButtonWood()
  {
    lllllllllllllllIlllIllllIllllIII.<init>(lIIIlIIIIIII[0]);
  }
  
  static {}
  
  private static void llIlIIlIlIllI()
  {
    lIIIlIIIIIII = new int[1];
    lIIIlIIIIIII[0] = " ".length();
  }
}

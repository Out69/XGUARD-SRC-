package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.World;

public class BlockCactus
  extends Block
{
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public AxisAlignedBB getSelectedBoundingBox(World llllllllllllllIllIIlIIIIIIlllIlI, BlockPos llllllllllllllIllIIlIIIIIIlllIIl)
  {
    ;
    ;
    float llllllllllllllIllIIlIIIIIIlllIII = 0.0625F;
    return new AxisAlignedBB(llllllllllllllIllIIlIIIIIIllIlll.getX() + llllllllllllllIllIIlIIIIIIlllIII, llllllllllllllIllIIlIIIIIIllIlll.getY(), llllllllllllllIllIIlIIIIIIllIlll.getZ() + llllllllllllllIllIIlIIIIIIlllIII, llllllllllllllIllIIlIIIIIIllIlll.getX() + llllllIIIIIl[2] - llllllllllllllIllIIlIIIIIIlllIII, llllllllllllllIllIIlIIIIIIllIlll.getY() + llllllIIIIIl[2], llllllllllllllIllIIlIIIIIIllIlll.getZ() + llllllIIIIIl[2] - llllllllllllllIllIIlIIIIIIlllIII);
  }
  
  public void onEntityCollidedWithBlock(World llllllllllllllIllIIlIIIIIIIIllIl, BlockPos llllllllllllllIllIIlIIIIIIIIllII, IBlockState llllllllllllllIllIIlIIIIIIIIlIll, Entity llllllllllllllIllIIlIIIIIIIIlIIl)
  {
    ;
    "".length();
  }
  
  public boolean canBlockStay(World llllllllllllllIllIIlIIIIIIIllIIl, BlockPos llllllllllllllIllIIlIIIIIIIlIIll)
  {
    ;
    ;
    ;
    ;
    byte llllllllllllllIllIIlIIIIIIIlIIIl = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if (((99 + 'Ï' - 121 + 36 ^ 95 + 30 - 65 + 85) & (0x3C ^ 0x32 ^ 0x33 ^ 0x71 ^ -" ".length())) != 0) {
      return (0x1C ^ 0xB ^ 0x98 ^ 0x9F) & (0x56 ^ 0x42 ^ 0x35 ^ 0x31 ^ -" ".length());
    }
    while (!llIIIIIIIlIllI(llllllllllllllIllIIlIIIIIIIlIIIl.hasNext()))
    {
      Object llllllllllllllIllIIlIIIIIIIlIlll = llllllllllllllIllIIlIIIIIIIlIIIl.next();
      EnumFacing llllllllllllllIllIIlIIIIIIIlIllI = (EnumFacing)llllllllllllllIllIIlIIIIIIIlIlll;
      if (llIIIIIIIlIIlI(llllllllllllllIllIIlIIIIIIIllIIl.getBlockState(llllllllllllllIllIIlIIIIIIIlIIll.offset(llllllllllllllIllIIlIIIIIIIlIllI)).getBlock().getMaterial().isSolid())) {
        return llllllIIIIIl[0];
      }
    }
    Block llllllllllllllIllIIlIIIIIIIlIlIl = llllllllllllllIllIIlIIIIIIIllIIl.getBlockState(llllllllllllllIllIIlIIIIIIIlIIll.down()).getBlock();
    if ((llIIIIIIIlIIll(llllllllllllllIllIIlIIIIIIIlIlIl, Blocks.cactus)) && (llIIIIIIIlIIll(llllllllllllllIllIIlIIIIIIIlIlIl, Blocks.sand))) {
      return llllllIIIIIl[0];
    }
    return llllllIIIIIl[2];
  }
  
  static
  {
    llIIIIIIIlIIIl();
    llIIIIIIIlIIII();
  }
  
  private static void llIIIIIIIlIIII()
  {
    llllllIIIIII = new String[llllllIIIIIl[2]];
    llllllIIIIII[llllllIIIIIl[0]] = llIIIIIIIIllll("2P1i1bQNb6g=", "ydJxl");
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIllIIlIIIIIIIIIIlI)
  {
    ;
    ;
    return llllllllllllllIllIIlIIIIIIIIIIll.getDefaultState().withProperty(AGE, Integer.valueOf(llllllllllllllIllIIlIIIIIIIIIIlI));
  }
  
  private static boolean llIIIIIIIlIlIl(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIllIIIlllllllIlIlI;
    return ??? == i;
  }
  
  public boolean isFullCube()
  {
    return llllllIIIIIl[0];
  }
  
  private static boolean llIIIIIIIlIIll(Object ???, Object arg1)
  {
    Object localObject;
    String llllllllllllllIllIIIlllllllIIIlI;
    return ??? != localObject;
  }
  
  public boolean isOpaqueCube()
  {
    return llllllIIIIIl[0];
  }
  
  private static boolean llIIIIIIIlIllI(int ???)
  {
    long llllllllllllllIllIIIllllllIllllI;
    return ??? == 0;
  }
  
  public void onNeighborBlockChange(World llllllllllllllIllIIlIIIIIIlIIllI, BlockPos llllllllllllllIllIIlIIIIIIlIIlIl, IBlockState llllllllllllllIllIIlIIIIIIlIIlII, Block llllllllllllllIllIIlIIIIIIlIIIll)
  {
    ;
    ;
    ;
    if (llIIIIIIIlIllI(llllllllllllllIllIIlIIIIIIlIIlll.canBlockStay(llllllllllllllIllIIlIIIIIIlIIllI, llllllllllllllIllIIlIIIIIIlIIIII))) {
      "".length();
    }
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIllIIIlllllllllIll, new IProperty[] { AGE });
  }
  
  private static String llIIIIIIIIllll(String llllllllllllllIllIIIllllllllIIll, String llllllllllllllIllIIIllllllllIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIIllllllllIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIIllllllllIIII.getBytes(StandardCharsets.UTF_8)), llllllIIIIIl[5]), "DES");
      Cipher llllllllllllllIllIIIllllllllIlIl = Cipher.getInstance("DES");
      llllllllllllllIllIIIllllllllIlIl.init(llllllIIIIIl[6], llllllllllllllIllIIIllllllllIllI);
      return new String(llllllllllllllIllIIIllllllllIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIIllllllllIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIIllllllllIlII)
    {
      llllllllllllllIllIIIllllllllIlII.printStackTrace();
    }
    return null;
  }
  
  private static void llIIIIIIIlIIIl()
  {
    llllllIIIIIl = new int[7];
    llllllIIIIIl[0] = ((0x13 ^ 0x2 ^ 0xB ^ 0x35) & (0x0 ^ 0x37 ^ 0x52 ^ 0x4A ^ -" ".length()));
    llllllIIIIIl[1] = (0xA5 ^ 0xAA);
    llllllIIIIIl[2] = " ".length();
    llllllIIIIIl[3] = "   ".length();
    llllllIIIIIl[4] = (0x32 ^ 0xE ^ 0x6C ^ 0x54);
    llllllIIIIIl[5] = (0xEA ^ 0xBE ^ 0x44 ^ 0x18);
    llllllIIIIIl[6] = "  ".length();
  }
  
  public boolean canPlaceBlockAt(World llllllllllllllIllIIlIIIIIIlIllII, BlockPos llllllllllllllIllIIlIIIIIIlIlllI)
  {
    ;
    ;
    ;
    if (llIIIIIIIlIIlI(llllllllllllllIllIIlIIIIIIllIIII.canPlaceBlockAt(llllllllllllllIllIIlIIIIIIlIllll, llllllllllllllIllIIlIIIIIIlIlllI)))
    {
      "".length();
      if (-(0x5 ^ 0x14 ^ 0xAF ^ 0xBB) < 0) {
        break label77;
      }
      return (0x19 ^ 0x0 ^ 0x2E ^ 0x1E) & (0x3B ^ 0x36 ^ 0xE2 ^ 0xC6 ^ -" ".length());
    }
    label77:
    return llllllIIIIIl[0];
  }
  
  private static boolean llIIIIIIIlIIlI(int ???)
  {
    float llllllllllllllIllIIIlllllllIIIII;
    return ??? != 0;
  }
  
  protected BlockCactus()
  {
    llllllllllllllIllIIlIIIIIllIIIIl.<init>(Material.cactus);
    llllllllllllllIllIIlIIIIIllIIIII.setDefaultState(blockState.getBaseState().withProperty(AGE, Integer.valueOf(llllllIIIIIl[0])));
    "".length();
    "".length();
  }
  
  public void updateTick(World llllllllllllllIllIIlIIIIIlIlIllI, BlockPos llllllllllllllIllIIlIIIIIlIlIlIl, IBlockState llllllllllllllIllIIlIIIIIlIIlIll, Random llllllllllllllIllIIlIIIIIlIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    BlockPos llllllllllllllIllIIlIIIIIlIlIIlI = llllllllllllllIllIIlIIIIIlIlIlIl.up();
    if (llIIIIIIIlIIlI(llllllllllllllIllIIlIIIIIlIlIllI.isAirBlock(llllllllllllllIllIIlIIIIIlIlIIlI)))
    {
      int llllllllllllllIllIIlIIIIIlIlIIIl = llllllIIIIIl[2];
      "".length();
      if ("   ".length() < ((0xE4 ^ 0x84) & (0xC0 ^ 0xA0 ^ 0xFFFFFFFF))) {
        return;
      }
      while (!llIIIIIIIlIIll(llllllllllllllIllIIlIIIIIlIlIllI.getBlockState(llllllllllllllIllIIlIIIIIlIIllII.down(llllllllllllllIllIIlIIIIIlIlIIIl)).getBlock(), llllllllllllllIllIIlIIIIIlIlIlll)) {
        llllllllllllllIllIIlIIIIIlIlIIIl++;
      }
      if (llIIIIIIIlIlII(llllllllllllllIllIIlIIIIIlIlIIIl, llllllIIIIIl[3]))
      {
        int llllllllllllllIllIIlIIIIIlIlIIII = ((Integer)llllllllllllllIllIIlIIIIIlIIlIll.getValue(AGE)).intValue();
        if (llIIIIIIIlIlIl(llllllllllllllIllIIlIIIIIlIlIIII, llllllIIIIIl[1]))
        {
          "".length();
          IBlockState llllllllllllllIllIIlIIIIIlIIllll = llllllllllllllIllIIlIIIIIlIIlIll.withProperty(AGE, Integer.valueOf(llllllIIIIIl[0]));
          "".length();
          llllllllllllllIllIIlIIIIIlIlIlll.onNeighborBlockChange(llllllllllllllIllIIlIIIIIlIlIllI, llllllllllllllIllIIlIIIIIlIlIIlI, llllllllllllllIllIIlIIIIIlIIllll, llllllllllllllIllIIlIIIIIlIlIlll);
          "".length();
          if (((0xCE ^ 0x9C) & (0x1E ^ 0x4C ^ 0xFFFFFFFF)) >= -" ".length()) {}
        }
        else
        {
          "".length();
        }
      }
    }
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIllIIlIIIIIlIIIIll, BlockPos llllllllllllllIllIIlIIIIIIllllll, IBlockState llllllllllllllIllIIlIIIIIlIIIIIl)
  {
    ;
    ;
    float llllllllllllllIllIIlIIIIIlIIIIII = 0.0625F;
    return new AxisAlignedBB(llllllllllllllIllIIlIIIIIIllllll.getX() + llllllllllllllIllIIlIIIIIlIIIIII, llllllllllllllIllIIlIIIIIIllllll.getY(), llllllllllllllIllIIlIIIIIIllllll.getZ() + llllllllllllllIllIIlIIIIIlIIIIII, llllllllllllllIllIIlIIIIIIllllll.getX() + llllllIIIIIl[2] - llllllllllllllIllIIlIIIIIlIIIIII, llllllllllllllIllIIlIIIIIIllllll.getY() + llllllIIIIIl[2] - llllllllllllllIllIIlIIIIIlIIIIII, llllllllllllllIllIIlIIIIIIllllll.getZ() + llllllIIIIIl[2] - llllllllllllllIllIIlIIIIIlIIIIII);
  }
  
  private static boolean llIIIIIIIlIlII(int ???, int arg1)
  {
    int i;
    short llllllllllllllIllIIIlllllllIIllI;
    return ??? < i;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIllIIIlllllllllllI)
  {
    ;
    return ((Integer)llllllllllllllIllIIIlllllllllllI.getValue(AGE)).intValue();
  }
}

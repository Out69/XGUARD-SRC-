package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class BlockRedstoneOre
  extends Block
{
  private void activate(World llllllllllllllIlIIIllllIlIIIllIl, BlockPos llllllllllllllIlIIIllllIlIIIllII)
  {
    ;
    ;
    ;
    llllllllllllllIlIIIllllIlIIlIIIl.spawnParticles(llllllllllllllIlIIIllllIlIIlIIII, llllllllllllllIlIIIllllIlIIIllII);
    if (llIllIlIlIlIlI(llllllllllllllIlIIIllllIlIIlIIIl, Blocks.redstone_ore)) {
      "".length();
    }
  }
  
  public void dropBlockAsItemWithChance(World llllllllllllllIlIIIllllIIllIIIII, BlockPos llllllllllllllIlIIIllllIIlIlllll, IBlockState llllllllllllllIlIIIllllIIlIllllI, float llllllllllllllIlIIIllllIIllIIlII, int llllllllllllllIlIIIllllIIlIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIIllllIIllIIIIl.dropBlockAsItemWithChance(llllllllllllllIlIIIllllIIllIIIII, llllllllllllllIlIIIllllIIlIlllll, llllllllllllllIlIIIllllIIlIllllI, llllllllllllllIlIIIllllIIllIIlII, llllllllllllllIlIIIllllIIlIlllII);
    if (llIllIlIlIlIll(llllllllllllllIlIIIllllIIllIIIIl.getItemDropped(llllllllllllllIlIIIllllIIlIllllI, rand, llllllllllllllIlIIIllllIIlIlllII), Item.getItemFromBlock(llllllllllllllIlIIIllllIIllIIIIl)))
    {
      int llllllllllllllIlIIIllllIIllIIIlI = lIIlIIIIIIIII[0] + rand.nextInt(lIIlIIIIIIIII[4]);
      llllllllllllllIlIIIllllIIllIIIIl.dropXpOnBlockBreak(llllllllllllllIlIIIllllIIllIIIII, llllllllllllllIlIIIllllIIlIlllll, llllllllllllllIlIIIllllIIllIIIlI);
    }
  }
  
  private static boolean llIllIlIllIIlI(int ???)
  {
    double llllllllllllllIlIIIllllIIIIllIll;
    return ??? > 0;
  }
  
  private static boolean llIllIlIllIIII(int ???)
  {
    Exception llllllllllllllIlIIIllllIIIIlllll;
    return ??? >= 0;
  }
  
  private static int llIllIlIlIllIl(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean llIllIlIlIlIlI(Object ???, Object arg1)
  {
    Object localObject;
    double llllllllllllllIlIIIllllIIIlIIlIl;
    return ??? == localObject;
  }
  
  public BlockRedstoneOre(boolean llllllllllllllIlIIIllllIllIIlIlI)
  {
    llllllllllllllIlIIIllllIllIIllIl.<init>(Material.rock);
    if (llIllIlIlIlIIl(llllllllllllllIlIIIllllIllIIlIlI)) {
      "".length();
    }
    isOn = llllllllllllllIlIIIllllIllIIlIlI;
  }
  
  public void onBlockClicked(World llllllllllllllIlIIIllllIlIlllllI, BlockPos llllllllllllllIlIIIllllIllIIIIIl, EntityPlayer llllllllllllllIlIIIllllIllIIIIII)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIlIIIllllIlIllllll.activate(llllllllllllllIlIIIllllIlIlllllI, llllllllllllllIlIIIllllIllIIIIIl);
    llllllllllllllIlIIIllllIlIllllll.onBlockClicked(llllllllllllllIlIIIllllIlIlllllI, llllllllllllllIlIIIllllIllIIIIIl, llllllllllllllIlIIIllllIllIIIIII);
  }
  
  public void onEntityCollidedWithBlock(World llllllllllllllIlIIIllllIlIllIllI, BlockPos llllllllllllllIlIIIllllIlIllIIIl, Entity llllllllllllllIlIIIllllIlIllIlII)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIlIIIllllIlIllIlll.activate(llllllllllllllIlIIIllllIlIllIllI, llllllllllllllIlIIIllllIlIllIIIl);
    llllllllllllllIlIIIllllIlIllIlll.onEntityCollidedWithBlock(llllllllllllllIlIIIllllIlIllIllI, llllllllllllllIlIIIllllIlIllIIIl, llllllllllllllIlIIIllllIlIllIlII);
  }
  
  public int quantityDroppedWithBonus(int llllllllllllllIlIIIllllIIlllIlIl, Random llllllllllllllIlIIIllllIIlllIlll)
  {
    ;
    ;
    ;
    return llllllllllllllIlIIIllllIIlllIllI.quantityDropped(llllllllllllllIlIIIllllIIlllIlll) + llllllllllllllIlIIIllllIIlllIlll.nextInt(llllllllllllllIlIIIllllIIllllIII + lIIlIIIIIIIII[0]);
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIlIIIllllIIlllllll, Random llllllllllllllIlIIIllllIIllllllI, int llllllllllllllIlIIIllllIIlllllIl)
  {
    return Items.redstone;
  }
  
  public int quantityDropped(Random llllllllllllllIlIIIllllIIlllIIII)
  {
    ;
    return lIIlIIIIIIIII[2] + llllllllllllllIlIIIllllIIlllIIIl.nextInt(lIIlIIIIIIIII[3]);
  }
  
  static {}
  
  private static int llIllIlIlIllII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean llIllIlIlIlIll(Object ???, Object arg1)
  {
    Object localObject;
    double llllllllllllllIlIIIllllIIIlIlIIl;
    return ??? != localObject;
  }
  
  private static void llIllIlIlIlIII()
  {
    lIIlIIIIIIIII = new int[8];
    lIIlIIIIIIIII[0] = " ".length();
    lIIlIIIIIIIII[1] = (0x16 ^ 0x8);
    lIIlIIIIIIIII[2] = (0x62 ^ 0x66);
    lIIlIIIIIIIII[3] = "  ".length();
    lIIlIIIIIIIII[4] = (0xB ^ 0xE);
    lIIlIIIIIIIII[5] = ((0x4 ^ 0x1B) & (0xA8 ^ 0xB7 ^ 0xFFFFFFFF));
    lIIlIIIIIIIII[6] = "   ".length();
    lIIlIIIIIIIII[7] = (0x3B ^ 0x3D);
  }
  
  protected ItemStack createStackedBlock(IBlockState llllllllllllllIlIIIllllIIIllIlIl)
  {
    return new ItemStack(Blocks.redstone_ore);
  }
  
  public int tickRate(World llllllllllllllIlIIIllllIllIIlIII)
  {
    return lIIlIIIIIIIII[1];
  }
  
  private static boolean llIllIlIlIlIIl(int ???)
  {
    long llllllllllllllIlIIIllllIIIlIIIll;
    return ??? != 0;
  }
  
  private void spawnParticles(World llllllllllllllIlIIIllllIIIlllllI, BlockPos llllllllllllllIlIIIllllIIlIIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Random llllllllllllllIlIIIllllIIlIIIlII = rand;
    double llllllllllllllIlIIIllllIIlIIIIll = 0.0625D;
    int llllllllllllllIlIIIllllIIlIIIIlI = lIIlIIIIIIIII[5];
    "".length();
    if ((0x36 ^ 0x32) != (0x29 ^ 0x2D)) {
      return;
    }
    while (!llIllIlIllIIll(llllllllllllllIlIIIllllIIlIIIIlI, lIIlIIIIIIIII[7]))
    {
      double llllllllllllllIlIIIllllIIlIIIIIl = llllllllllllllIlIIIllllIIlIIIlIl.getX() + llllllllllllllIlIIIllllIIlIIIlII.nextFloat();
      double llllllllllllllIlIIIllllIIlIIIIII = llllllllllllllIlIIIllllIIlIIIlIl.getY() + llllllllllllllIlIIIllllIIlIIIlII.nextFloat();
      double llllllllllllllIlIIIllllIIIllllll = llllllllllllllIlIIIllllIIlIIIlIl.getZ() + llllllllllllllIlIIIllllIIlIIIlII.nextFloat();
      if ((llIllIlIlIlllI(llllllllllllllIlIIIllllIIlIIIIlI)) && (llIllIlIlIlllI(llllllllllllllIlIIIllllIIIlllllI.getBlockState(llllllllllllllIlIIIllllIIlIIIlIl.up()).getBlock().isOpaqueCube()))) {
        llllllllllllllIlIIIllllIIlIIIIII = llllllllllllllIlIIIllllIIlIIIlIl.getY() + llllllllllllllIlIIIllllIIlIIIIll + 1.0D;
      }
      if ((llIllIlIlIllll(llllllllllllllIlIIIllllIIlIIIIlI, lIIlIIIIIIIII[0])) && (llIllIlIlIlllI(llllllllllllllIlIIIllllIIIlllllI.getBlockState(llllllllllllllIlIIIllllIIlIIIlIl.down()).getBlock().isOpaqueCube()))) {
        llllllllllllllIlIIIllllIIlIIIIII = llllllllllllllIlIIIllllIIlIIIlIl.getY() - llllllllllllllIlIIIllllIIlIIIIll;
      }
      if ((llIllIlIlIllll(llllllllllllllIlIIIllllIIlIIIIlI, lIIlIIIIIIIII[3])) && (llIllIlIlIlllI(llllllllllllllIlIIIllllIIIlllllI.getBlockState(llllllllllllllIlIIIllllIIlIIIlIl.south()).getBlock().isOpaqueCube()))) {
        llllllllllllllIlIIIllllIIIllllll = llllllllllllllIlIIIllllIIlIIIlIl.getZ() + llllllllllllllIlIIIllllIIlIIIIll + 1.0D;
      }
      if ((llIllIlIlIllll(llllllllllllllIlIIIllllIIlIIIIlI, lIIlIIIIIIIII[6])) && (llIllIlIlIlllI(llllllllllllllIlIIIllllIIIlllllI.getBlockState(llllllllllllllIlIIIllllIIlIIIlIl.north()).getBlock().isOpaqueCube()))) {
        llllllllllllllIlIIIllllIIIllllll = llllllllllllllIlIIIllllIIlIIIlIl.getZ() - llllllllllllllIlIIIllllIIlIIIIll;
      }
      if ((llIllIlIlIllll(llllllllllllllIlIIIllllIIlIIIIlI, lIIlIIIIIIIII[2])) && (llIllIlIlIlllI(llllllllllllllIlIIIllllIIIlllllI.getBlockState(llllllllllllllIlIIIllllIIlIIIlIl.east()).getBlock().isOpaqueCube()))) {
        llllllllllllllIlIIIllllIIlIIIIIl = llllllllllllllIlIIIllllIIlIIIlIl.getX() + llllllllllllllIlIIIllllIIlIIIIll + 1.0D;
      }
      if ((llIllIlIlIllll(llllllllllllllIlIIIllllIIlIIIIlI, lIIlIIIIIIIII[4])) && (llIllIlIlIlllI(llllllllllllllIlIIIllllIIIlllllI.getBlockState(llllllllllllllIlIIIllllIIlIIIlIl.west()).getBlock().isOpaqueCube()))) {
        llllllllllllllIlIIIllllIIlIIIIIl = llllllllllllllIlIIIllllIIlIIIlIl.getX() - llllllllllllllIlIIIllllIIlIIIIll;
      }
      if ((!llIllIlIllIIII(llIllIlIlIllII(llllllllllllllIlIIIllllIIlIIIIIl, llllllllllllllIlIIIllllIIlIIIlIl.getX()))) || (!llIllIlIllIIIl(llIllIlIlIllIl(llllllllllllllIlIIIllllIIlIIIIIl, llllllllllllllIlIIIllllIIlIIIlIl.getX() + lIIlIIIIIIIII[0]))) || (!llIllIlIllIIII(llIllIlIlIllII(llllllllllllllIlIIIllllIIlIIIIII, 0.0D))) || (!llIllIlIllIIIl(llIllIlIlIllIl(llllllllllllllIlIIIllllIIlIIIIII, llllllllllllllIlIIIllllIIlIIIlIl.getY() + lIIlIIIIIIIII[0]))) || (!llIllIlIllIIII(llIllIlIlIllII(llllllllllllllIlIIIllllIIIllllll, llllllllllllllIlIIIllllIIlIIIlIl.getZ()))) || (llIllIlIllIIlI(llIllIlIlIllIl(llllllllllllllIlIIIllllIIIllllll, llllllllllllllIlIIIllllIIlIIIlIl.getZ() + lIIlIIIIIIIII[0])))) {
        llllllllllllllIlIIIllllIIIlllllI.spawnParticle(EnumParticleTypes.REDSTONE, llllllllllllllIlIIIllllIIlIIIIIl, llllllllllllllIlIIIllllIIlIIIIII, llllllllllllllIlIIIllllIIIllllll, 0.0D, 0.0D, 0.0D, new int[lIIlIIIIIIIII[5]]);
      }
      llllllllllllllIlIIIllllIIlIIIIlI++;
    }
  }
  
  private static boolean llIllIlIlIllll(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIlIIIllllIIIllIIIl;
    return ??? == i;
  }
  
  public boolean onBlockActivated(World llllllllllllllIlIIIllllIlIIlllII, BlockPos llllllllllllllIlIIIllllIlIIllIll, IBlockState llllllllllllllIlIIIllllIlIlIIIll, EntityPlayer llllllllllllllIlIIIllllIlIIllIIl, EnumFacing llllllllllllllIlIIIllllIlIlIIIIl, float llllllllllllllIlIIIllllIlIIlIlll, float llllllllllllllIlIIIllllIlIIlllll, float llllllllllllllIlIIIllllIlIIlIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIIllllIlIIlllIl.activate(llllllllllllllIlIIIllllIlIIlllII, llllllllllllllIlIIIllllIlIIllIll);
    return llllllllllllllIlIIIllllIlIIlllIl.onBlockActivated(llllllllllllllIlIIIllllIlIIlllII, llllllllllllllIlIIIllllIlIIllIll, llllllllllllllIlIIIllllIlIlIIIll, llllllllllllllIlIIIllllIlIlIIIlI, llllllllllllllIlIIIllllIlIlIIIIl, llllllllllllllIlIIIllllIlIIlIlll, llllllllllllllIlIIIllllIlIIlllll, llllllllllllllIlIIIllllIlIIlIlIl);
  }
  
  private static boolean llIllIlIllIIll(int ???, int arg1)
  {
    int i;
    char llllllllllllllIlIIIllllIIIlIllIl;
    return ??? >= i;
  }
  
  public void updateTick(World llllllllllllllIlIIIllllIlIIIIIlI, BlockPos llllllllllllllIlIIIllllIlIIIIllI, IBlockState llllllllllllllIlIIIllllIlIIIIlIl, Random llllllllllllllIlIIIllllIlIIIIlII)
  {
    ;
    ;
    ;
    if (llIllIlIlIlIlI(llllllllllllllIlIIIllllIlIIIIIll, Blocks.lit_redstone_ore)) {
      "".length();
    }
  }
  
  private static boolean llIllIlIllIIIl(int ???)
  {
    Exception llllllllllllllIlIIIllllIIIIlllIl;
    return ??? <= 0;
  }
  
  private static boolean llIllIlIlIlllI(int ???)
  {
    String llllllllllllllIlIIIllllIIIlIIIIl;
    return ??? == 0;
  }
  
  public void randomDisplayTick(World llllllllllllllIlIIIllllIIlIlIllI, BlockPos llllllllllllllIlIIIllllIIlIlIIII, IBlockState llllllllllllllIlIIIllllIIlIlIlII, Random llllllllllllllIlIIIllllIIlIlIIll)
  {
    ;
    ;
    ;
    if (llIllIlIlIlIIl(isOn)) {
      llllllllllllllIlIIIllllIIlIlIlll.spawnParticles(llllllllllllllIlIIIllllIIlIlIllI, llllllllllllllIlIIIllllIIlIlIlIl);
    }
  }
}

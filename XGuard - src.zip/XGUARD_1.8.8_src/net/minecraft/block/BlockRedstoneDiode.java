package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockRedstoneDiode
  extends BlockDirectional
{
  public boolean isAssociatedBlock(Block llllllllllllllIllIIlIIlIIIlIIlII)
  {
    ;
    ;
    return llllllllllllllIllIIlIIlIIIlIIlIl.isAssociated(llllllllllllllIllIIlIIlIIIlIIlII);
  }
  
  public boolean canBlockStay(World llllllllllllllIllIIlIIllIlIlIIlI, BlockPos llllllllllllllIllIIlIIllIlIlIIll)
  {
    ;
    ;
    return World.doesBlockHaveSolidTopSurface(llllllllllllllIllIIlIIllIlIlIIlI, llllllllllllllIllIIlIIllIlIlIIll.down());
  }
  
  private static boolean lIlllllllIlllI(Object ???, Object arg1)
  {
    Object localObject;
    char llllllllllllllIllIIlIIlIIIIlIlIl;
    return ??? == localObject;
  }
  
  protected boolean isPowered(IBlockState llllllllllllllIllIIlIIllIIllIIll)
  {
    ;
    return isRepeaterPowered;
  }
  
  protected abstract IBlockState getPoweredState(IBlockState paramIBlockState);
  
  public boolean isLocked(IBlockAccess llllllllllllllIllIIlIIlIlllIlIlI, BlockPos llllllllllllllIllIIlIIlIlllIlIIl, IBlockState llllllllllllllIllIIlIIlIlllIlIII)
  {
    return lllllIllIlII[0];
  }
  
  protected int getPowerOnSides(IBlockAccess llllllllllllllIllIIlIIlIlIllllIl, BlockPos llllllllllllllIllIIlIIlIlIllIlIl, IBlockState llllllllllllllIllIIlIIlIlIllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllIllIIlIIlIlIlllIlI = (EnumFacing)llllllllllllllIllIIlIIlIlIllIlII.getValue(FACING);
    EnumFacing llllllllllllllIllIIlIIlIlIlllIIl = llllllllllllllIllIIlIIlIlIlllIlI.rotateY();
    EnumFacing llllllllllllllIllIIlIIlIlIlllIII = llllllllllllllIllIIlIIlIlIlllIlI.rotateYCCW();
    return Math.max(llllllllllllllIllIIlIIlIlIlllllI.getPowerOnSide(llllllllllllllIllIIlIIlIlIllllIl, llllllllllllllIllIIlIIlIlIllIlIl.offset(llllllllllllllIllIIlIIlIlIlllIIl), llllllllllllllIllIIlIIlIlIlllIIl), llllllllllllllIllIIlIIlIlIlllllI.getPowerOnSide(llllllllllllllIllIIlIIlIlIllllIl, llllllllllllllIllIIlIIlIlIllIlIl.offset(llllllllllllllIllIIlIIlIlIlllIII), llllllllllllllIllIIlIIlIlIlllIII));
  }
  
  public boolean isOpaqueCube()
  {
    return lllllIllIlII[0];
  }
  
  public boolean shouldSideBeRendered(IBlockAccess llllllllllllllIllIIlIIllIIlllIIl, BlockPos llllllllllllllIllIIlIIllIIlllIII, EnumFacing llllllllllllllIllIIlIIllIIllIllI)
  {
    ;
    if (lIlllllllIllIl(llllllllllllllIllIIlIIllIIllIllI.getAxis(), EnumFacing.Axis.Y)) {
      return lllllIllIlII[3];
    }
    return lllllIllIlII[0];
  }
  
  protected boolean canPowerSide(Block llllllllllllllIllIIlIIlIIlIIlIll)
  {
    ;
    return llllllllllllllIllIIlIIlIIlIIlIll.canProvidePower();
  }
  
  public void updateTick(World llllllllllllllIllIIlIIllIlIIIlIl, BlockPos llllllllllllllIllIIlIIllIlIIIlII, IBlockState llllllllllllllIllIIlIIllIlIIIIll, Random llllllllllllllIllIIlIIllIlIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIlllllllIllII(llllllllllllllIllIIlIIllIlIIIIII.isLocked(llllllllllllllIllIIlIIllIlIIIlIl, llllllllllllllIllIIlIIllIIlllllI, llllllllllllllIllIIlIIllIlIIIIll)))
    {
      boolean llllllllllllllIllIIlIIllIlIIIIIl = llllllllllllllIllIIlIIllIlIIIIII.shouldBePowered(llllllllllllllIllIIlIIllIlIIIlIl, llllllllllllllIllIIlIIllIIlllllI, llllllllllllllIllIIlIIllIlIIIIll);
      if ((lIlllllllIlIll(isRepeaterPowered)) && (lIlllllllIllII(llllllllllllllIllIIlIIllIlIIIIIl)))
      {
        "".length();
        "".length();
        if (((0xCF ^ 0xB9 ^ 0x75 ^ 0x5D) & ('' + 14 - 11 + 12 ^ 12 + 74 - 37 + 145 ^ -" ".length())) <= "   ".length()) {}
      }
      else if (lIlllllllIllII(isRepeaterPowered))
      {
        "".length();
        if (lIlllllllIllII(llllllllllllllIllIIlIIllIlIIIIIl)) {
          llllllllllllllIllIIlIIllIlIIIlIl.updateBlockTick(llllllllllllllIllIIlIIllIIlllllI, llllllllllllllIllIIlIIllIlIIIIII.getPoweredState(llllllllllllllIllIIlIIllIlIIIIll).getBlock(), llllllllllllllIllIIlIIllIlIIIIII.getTickDelay(llllllllllllllIllIIlIIllIlIIIIll), lllllIllIlII[2]);
        }
      }
    }
  }
  
  public boolean canPlaceBlockAt(World llllllllllllllIllIIlIIllIlIllIIl, BlockPos llllllllllllllIllIIlIIllIlIllIII)
  {
    ;
    ;
    ;
    if (lIlllllllIlIll(World.doesBlockHaveSolidTopSurface(llllllllllllllIllIIlIIllIlIllIIl, llllllllllllllIllIIlIIllIlIllIII.down())))
    {
      "".length();
      if ((120 + '²' - 188 + 74 ^ 99 + '' - 232 + 172) > " ".length()) {
        break label98;
      }
      return (0x77 ^ 0x7B ^ 0x42 ^ 0x5A) & (0x45 ^ 0x2B ^ 0x1D ^ 0x67 ^ -" ".length());
    }
    label98:
    return lllllIllIlII[0];
  }
  
  private static boolean lIlllllllIllIl(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllIllIIlIIlIIIIllIIl;
    return ??? != localObject;
  }
  
  public void onNeighborBlockChange(World llllllllllllllIllIIlIIllIIIIIlII, BlockPos llllllllllllllIllIIlIIllIIIIIIll, IBlockState llllllllllllllIllIIlIIllIIIIlIII, Block llllllllllllllIllIIlIIllIIIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlllllllIlIll(llllllllllllllIllIIlIIllIIIIlIll.canBlockStay(llllllllllllllIllIIlIIllIIIIIlII, llllllllllllllIllIIlIIllIIIIlIIl)))
    {
      llllllllllllllIllIIlIIllIIIIlIll.updateState(llllllllllllllIllIIlIIllIIIIIlII, llllllllllllllIllIIlIIllIIIIlIIl, llllllllllllllIllIIlIIllIIIIlIII);
      "".length();
      if (" ".length() < "  ".length()) {}
    }
    else
    {
      llllllllllllllIllIIlIIllIIIIlIll.dropBlockAsItem(llllllllllllllIllIIlIIllIIIIIlII, llllllllllllllIllIIlIIllIIIIlIIl, llllllllllllllIllIIlIIllIIIIlIII, lllllIllIlII[0]);
      "".length();
      llllllllllllllIllIIlIIlIllllllll = (llllllllllllllIllIIlIIlIlllllllI = EnumFacing.values()).length;
      llllllllllllllIllIIlIIllIIIIIIII = lllllIllIlII[0];
      "".length();
      if ("  ".length() != "  ".length()) {
        return;
      }
      while (!lIlllllllIllll(llllllllllllllIllIIlIIllIIIIIIII, llllllllllllllIllIIlIIlIllllllll))
      {
        EnumFacing llllllllllllllIllIIlIIllIIIIIllI = llllllllllllllIllIIlIIlIlllllllI[llllllllllllllIllIIlIIllIIIIIIII];
        llllllllllllllIllIIlIIllIIIIIlII.notifyNeighborsOfStateChange(llllllllllllllIllIIlIIllIIIIlIIl.offset(llllllllllllllIllIIlIIllIIIIIllI), llllllllllllllIllIIlIIllIIIIlIll);
      }
    }
  }
  
  private static void lIlllllllIlIlI()
  {
    lllllIllIlII = new int[7];
    lllllIllIlII[0] = ((0x3C ^ 0x0 ^ 0x27 ^ 0x50) & (0x7A ^ 0x49 ^ 0x4 ^ 0x7C ^ -" ".length()));
    lllllIllIlII[1] = "  ".length();
    lllllIllIlII[2] = (-" ".length());
    lllllIllIlII[3] = " ".length();
    lllllIllIlII[4] = (-"   ".length());
    lllllIllIlII[5] = (-"  ".length());
    lllllIllIlII[6] = (0x99 ^ 0x90 ^ 0x9B ^ 0x9D);
  }
  
  public void onBlockAdded(World llllllllllllllIllIIlIIlIIlllllIl, BlockPos llllllllllllllIllIIlIIlIIllllIII, IBlockState llllllllllllllIllIIlIIlIIlllIlll)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIllIIlIIlIIllllIlI.notifyNeighbors(llllllllllllllIllIIlIIlIIlllllIl, llllllllllllllIllIIlIIlIIllllIII, llllllllllllllIllIIlIIlIIlllIlll);
  }
  
  protected abstract int getDelay(IBlockState paramIBlockState);
  
  protected void updateState(World llllllllllllllIllIIlIIlIllllIIII, BlockPos llllllllllllllIllIIlIIlIllllIlIl, IBlockState llllllllllllllIllIIlIIlIlllIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlllllllIllII(llllllllllllllIllIIlIIlIllllIIIl.isLocked(llllllllllllllIllIIlIIlIllllIIII, llllllllllllllIllIIlIIlIllllIlIl, llllllllllllllIllIIlIIlIlllIlllI)))
    {
      boolean llllllllllllllIllIIlIIlIllllIIll = llllllllllllllIllIIlIIlIllllIIIl.shouldBePowered(llllllllllllllIllIIlIIlIllllIIII, llllllllllllllIllIIlIIlIllllIlIl, llllllllllllllIllIIlIIlIlllIlllI);
      if (((lIlllllllIlIll(isRepeaterPowered)) && (!lIlllllllIlIll(llllllllllllllIllIIlIIlIllllIIll))) || ((lIlllllllIllII(isRepeaterPowered)) && (lIlllllllIlIll(llllllllllllllIllIIlIIlIllllIIll)) && (lIlllllllIllII(llllllllllllllIllIIlIIlIllllIIII.isBlockTickPending(llllllllllllllIllIIlIIlIllllIlIl, llllllllllllllIllIIlIIlIllllIIIl)))))
      {
        int llllllllllllllIllIIlIIlIllllIIlI = lllllIllIlII[2];
        if (lIlllllllIlIll(llllllllllllllIllIIlIIlIllllIIIl.isFacingTowardsRepeater(llllllllllllllIllIIlIIlIllllIIII, llllllllllllllIllIIlIIlIllllIlIl, llllllllllllllIllIIlIIlIlllIlllI)))
        {
          llllllllllllllIllIIlIIlIllllIIlI = lllllIllIlII[4];
          "".length();
          if ((51 + 8 - -89 + 16 ^ 11 + 21 - 6 + 134) > 0) {}
        }
        else if (lIlllllllIlIll(isRepeaterPowered))
        {
          llllllllllllllIllIIlIIlIllllIIlI = lllllIllIlII[5];
        }
        llllllllllllllIllIIlIIlIllllIIII.updateBlockTick(llllllllllllllIllIIlIIlIllllIlIl, llllllllllllllIllIIlIIlIllllIIIl, llllllllllllllIllIIlIIlIllllIIIl.getDelay(llllllllllllllIllIIlIIlIlllIlllI), llllllllllllllIllIIlIIlIllllIIlI);
      }
    }
  }
  
  protected BlockRedstoneDiode(boolean llllllllllllllIllIIlIIllIllIIlII)
  {
    llllllllllllllIllIIlIIllIllIIIll.<init>(Material.circuits);
    isRepeaterPowered = llllllllllllllIllIIlIIllIllIIlII;
    llllllllllllllIllIIlIIllIllIIIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
  }
  
  protected boolean shouldBePowered(World llllllllllllllIllIIlIIlIlllIIIlI, BlockPos llllllllllllllIllIIlIIlIlllIIIIl, IBlockState llllllllllllllIllIIlIIlIlllIIIII)
  {
    ;
    ;
    ;
    ;
    if (lIllllllllIIII(llllllllllllllIllIIlIIlIlllIIIll.calculateInputStrength(llllllllllllllIllIIlIIlIlllIIIlI, llllllllllllllIllIIlIIlIlllIIIIl, llllllllllllllIllIIlIIlIlllIIIII))) {
      return lllllIllIlII[3];
    }
    return lllllIllIlII[0];
  }
  
  public void onBlockDestroyedByPlayer(World llllllllllllllIllIIlIIlIIlIllIll, BlockPos llllllllllllllIllIIlIIlIIlIlIlIl, IBlockState llllllllllllllIllIIlIIlIIlIlIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlllllllIlIll(isRepeaterPowered))
    {
      llllllllllllllIllIIlIIlIIlIlIIIl = (llllllllllllllIllIIlIIlIIlIlIIII = EnumFacing.values()).length;
      llllllllllllllIllIIlIIlIIlIlIIlI = lllllIllIlII[0];
      "".length();
      if (null != null) {
        return;
      }
      while (!lIlllllllIllll(llllllllllllllIllIIlIIlIIlIlIIlI, llllllllllllllIllIIlIIlIIlIlIIIl))
      {
        EnumFacing llllllllllllllIllIIlIIlIIlIllIII = llllllllllllllIllIIlIIlIIlIlIIII[llllllllllllllIllIIlIIlIIlIlIIlI];
        llllllllllllllIllIIlIIlIIlIllIll.notifyNeighborsOfStateChange(llllllllllllllIllIIlIIlIIlIlIlIl.offset(llllllllllllllIllIIlIIlIIlIllIII), llllllllllllllIllIIlIIlIIlIlIlll);
        llllllllllllllIllIIlIIlIIlIlIIlI++;
      }
    }
    llllllllllllllIllIIlIIlIIlIlIlll.onBlockDestroyedByPlayer(llllllllllllllIllIIlIIlIIlIllIll, llllllllllllllIllIIlIIlIIlIlIlIl, llllllllllllllIllIIlIIlIIlIlIlII);
  }
  
  public int getWeakPower(IBlockAccess llllllllllllllIllIIlIIllIIIlllII, BlockPos llllllllllllllIllIIlIIllIIIlIllI, IBlockState llllllllllllllIllIIlIIllIIIllIlI, EnumFacing llllllllllllllIllIIlIIllIIIlIlII)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIlllllllIllII(llllllllllllllIllIIlIIllIIIlllIl.isPowered(llllllllllllllIllIIlIIllIIIllIlI)))
    {
      "".length();
      if ("  ".length() == (' ' + 87 - 80 + 15 ^ 59 + 99 - 69 + 89)) {
        return (0x1C ^ 0x4D ^ 0x10 ^ 0x1F) & (58 + '' - 12 + 71 ^ 10 + 100 - 73 + 126 ^ -" ".length());
      }
    }
    else if (lIlllllllIlllI(llllllllllllllIllIIlIIllIIIllIlI.getValue(FACING), llllllllllllllIllIIlIIllIIIlIlII))
    {
      "".length();
      if ((0x39 ^ 0x40 ^ 0x40 ^ 0x3D) > " ".length()) {
        break label194;
      }
      return (75 + 127 - 111 + 87 ^ 114 + 34 - 20 + 5) & (0x3A ^ 0x1F ^ 0x29 ^ 0x3B ^ -" ".length());
    }
    label194:
    return lllllIllIlII[0];
  }
  
  protected int getActiveSignal(IBlockAccess llllllllllllllIllIIlIIlIIlIIlIIl, BlockPos llllllllllllllIllIIlIIlIIlIIlIII, IBlockState llllllllllllllIllIIlIIlIIlIIIlll)
  {
    return lllllIllIlII[6];
  }
  
  private static boolean lIlllllllIlIll(int ???)
  {
    byte llllllllllllllIllIIlIIlIIIIlIIll;
    return ??? != 0;
  }
  
  protected int getTickDelay(IBlockState llllllllllllllIllIIlIIlIIIlIlIII)
  {
    ;
    ;
    return llllllllllllllIllIIlIIlIIIlIlIIl.getDelay(llllllllllllllIllIIlIIlIIIlIlIII);
  }
  
  protected abstract IBlockState getUnpoweredState(IBlockState paramIBlockState);
  
  protected void notifyNeighbors(World llllllllllllllIllIIlIIlIIllIlIIl, BlockPos llllllllllllllIllIIlIIlIIllIlIII, IBlockState llllllllllllllIllIIlIIlIIllIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllIllIIlIIlIIllIllII = (EnumFacing)llllllllllllllIllIIlIIlIIllIllIl.getValue(FACING);
    BlockPos llllllllllllllIllIIlIIlIIllIlIll = llllllllllllllIllIIlIIlIIllIlIII.offset(llllllllllllllIllIIlIIlIIllIllII.getOpposite());
    llllllllllllllIllIIlIIlIIllIlIIl.notifyBlockOfStateChange(llllllllllllllIllIIlIIlIIllIlIll, llllllllllllllIllIIlIIlIIlllIIII);
    llllllllllllllIllIIlIIlIIllIlIIl.notifyNeighborsOfStateExcept(llllllllllllllIllIIlIIlIIllIlIll, llllllllllllllIllIIlIIlIIlllIIII, llllllllllllllIllIIlIIlIIllIllII);
  }
  
  protected int calculateInputStrength(World llllllllllllllIllIIlIIlIllIIllII, BlockPos llllllllllllllIllIIlIIlIllIlIIlI, IBlockState llllllllllllllIllIIlIIlIllIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllIllIIlIIlIllIlIIII = (EnumFacing)llllllllllllllIllIIlIIlIllIIlIlI.getValue(FACING);
    BlockPos llllllllllllllIllIIlIIlIllIIllll = llllllllllllllIllIIlIIlIllIIlIll.offset(llllllllllllllIllIIlIIlIllIlIIII);
    int llllllllllllllIllIIlIIlIllIIlllI = llllllllllllllIllIIlIIlIllIIllII.getRedstonePower(llllllllllllllIllIIlIIlIllIIllll, llllllllllllllIllIIlIIlIllIlIIII);
    if (lIlllllllIllll(llllllllllllllIllIIlIIlIllIIlllI, lllllIllIlII[6])) {
      return llllllllllllllIllIIlIIlIllIIlllI;
    }
    IBlockState llllllllllllllIllIIlIIlIllIIllIl = llllllllllllllIllIIlIIlIllIIllII.getBlockState(llllllllllllllIllIIlIIlIllIIllll);
    if (lIlllllllIlllI(llllllllllllllIllIIlIIlIllIIllIl.getBlock(), Blocks.redstone_wire))
    {
      "".length();
      if (((0x8 ^ 0x24) & (0xEC ^ 0xC0 ^ 0xFFFFFFFF)) == ((0x8A ^ 0xB6) & (0x8C ^ 0xB0 ^ 0xFFFFFFFF))) {
        break label151;
      }
      return (0x53 ^ 0x61) & (0x21 ^ 0x13 ^ 0xFFFFFFFF);
    }
    label151:
    return Math.max(((Integer)llllllllllllllIllIIlIIlIllIIllIl.getValue(BlockRedstoneWire.POWER)).intValue(), lllllIllIlII[0]);
  }
  
  public static boolean isRedstoneRepeaterBlockID(Block llllllllllllllIllIIlIIlIIlIIIlIl)
  {
    ;
    if ((lIlllllllIllII(Blocks.unpowered_repeater.isAssociated(llllllllllllllIllIIlIIlIIlIIIlII))) && (lIlllllllIllII(Blocks.unpowered_comparator.isAssociated(llllllllllllllIllIIlIIlIIlIIIlII)))) {
      return lllllIllIlII[0];
    }
    return lllllIllIlII[3];
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public boolean canProvidePower()
  {
    return lllllIllIlII[3];
  }
  
  protected int getPowerOnSide(IBlockAccess llllllllllllllIllIIlIIlIlIlIIIll, BlockPos llllllllllllllIllIIlIIlIlIlIlIII, EnumFacing llllllllllllllIllIIlIIlIlIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllIllIIlIIlIlIlIIllI = llllllllllllllIllIIlIIlIlIlIIIll.getBlockState(llllllllllllllIllIIlIIlIlIlIlIII);
    Block llllllllllllllIllIIlIIlIlIlIIlIl = llllllllllllllIllIIlIIlIlIlIIllI.getBlock();
    if (lIlllllllIlIll(llllllllllllllIllIIlIIlIlIlIIlII.canPowerSide(llllllllllllllIllIIlIIlIlIlIIlIl)))
    {
      if (lIlllllllIlllI(llllllllllllllIllIIlIIlIlIlIIlIl, Blocks.redstone_wire))
      {
        "".length();
        if (-"  ".length() < 0) {
          break label184;
        }
        return (0xB ^ 0x4A) & (0x17 ^ 0x56 ^ 0xFFFFFFFF);
      }
      "".length();
      if (-" ".length() <= ((92 + 51 - 22 + 6 ^ 0xC2 ^ 0x90) & (86 + 24 - 75 + 97 ^ '' + 38 - 91 + 89 ^ -" ".length()))) {
        break label184;
      }
      return "   ".length() & ("   ".length() ^ -" ".length());
    }
    label184:
    return lllllIllIlII[0];
  }
  
  public boolean isFullCube()
  {
    return lllllIllIlII[0];
  }
  
  public void randomTick(World llllllllllllllIllIIlIIllIlIIllll, BlockPos llllllllllllllIllIIlIIllIlIIlllI, IBlockState llllllllllllllIllIIlIIllIlIIllIl, Random llllllllllllllIllIIlIIllIlIIllII) {}
  
  public int getStrongPower(IBlockAccess llllllllllllllIllIIlIIllIIlIlIll, BlockPos llllllllllllllIllIIlIIllIIlIlIlI, IBlockState llllllllllllllIllIIlIIllIIlIIlII, EnumFacing llllllllllllllIllIIlIIllIIlIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    return llllllllllllllIllIIlIIllIIlIllII.getWeakPower(llllllllllllllIllIIlIIllIIlIlIll, llllllllllllllIllIIlIIllIIlIIlIl, llllllllllllllIllIIlIIllIIlIIlII, llllllllllllllIllIIlIIllIIlIIIll);
  }
  
  public IBlockState onBlockPlaced(World llllllllllllllIllIIlIIlIlIIllIlI, BlockPos llllllllllllllIllIIlIIlIlIIllIIl, EnumFacing llllllllllllllIllIIlIIlIlIIllIII, float llllllllllllllIllIIlIIlIlIIlIlll, float llllllllllllllIllIIlIIlIlIIlIllI, float llllllllllllllIllIIlIIlIlIIlIlIl, int llllllllllllllIllIIlIIlIlIIlIlII, EntityLivingBase llllllllllllllIllIIlIIlIlIIlIIIl)
  {
    ;
    ;
    return llllllllllllllIllIIlIIlIlIIllIll.getDefaultState().withProperty(FACING, llllllllllllllIllIIlIIlIlIIlIIIl.getHorizontalFacing().getOpposite());
  }
  
  public boolean isAssociated(Block llllllllllllllIllIIlIIlIIIlllllI)
  {
    ;
    ;
    if ((lIlllllllIllIl(llllllllllllllIllIIlIIlIIIlllllI, llllllllllllllIllIIlIIlIIIllllll.getPoweredState(llllllllllllllIllIIlIIlIIIllllll.getDefaultState()).getBlock())) && (lIlllllllIllIl(llllllllllllllIllIIlIIlIIIlllllI, llllllllllllllIllIIlIIlIIIllllll.getUnpoweredState(llllllllllllllIllIIlIIlIIIllllll.getDefaultState()).getBlock()))) {
      return lllllIllIlII[0];
    }
    return lllllIllIlII[3];
  }
  
  private static boolean lIlllllllIllII(int ???)
  {
    double llllllllllllllIllIIlIIlIIIIlIIIl;
    return ??? == 0;
  }
  
  public void onBlockPlacedBy(World llllllllllllllIllIIlIIlIlIIIlIll, BlockPos llllllllllllllIllIIlIIlIlIIIlIlI, IBlockState llllllllllllllIllIIlIIlIlIIIlIIl, EntityLivingBase llllllllllllllIllIIlIIlIlIIIlIII, ItemStack llllllllllllllIllIIlIIlIlIIIIlll)
  {
    ;
    ;
    ;
    ;
    if (lIlllllllIlIll(llllllllllllllIllIIlIIlIlIIIIllI.shouldBePowered(llllllllllllllIllIIlIIlIlIIIlIll, llllllllllllllIllIIlIIlIlIIIlIlI, llllllllllllllIllIIlIIlIlIIIlIIl))) {
      llllllllllllllIllIIlIIlIlIIIlIll.scheduleUpdate(llllllllllllllIllIIlIIlIlIIIlIlI, llllllllllllllIllIIlIIlIlIIIIllI, lllllIllIlII[3]);
    }
  }
  
  static {}
  
  public boolean isFacingTowardsRepeater(World llllllllllllllIllIIlIIlIIIllIIlI, BlockPos llllllllllllllIllIIlIIlIIIllIllI, IBlockState llllllllllllllIllIIlIIlIIIllIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllIllIIlIIlIIIllIlII = ((EnumFacing)llllllllllllllIllIIlIIlIIIllIlIl.getValue(FACING)).getOpposite();
    BlockPos llllllllllllllIllIIlIIlIIIllIIll = llllllllllllllIllIIlIIlIIIllIIIl.offset(llllllllllllllIllIIlIIlIIIllIlII);
    if (lIlllllllIlIll(isRedstoneRepeaterBlockID(llllllllllllllIllIIlIIlIIIllIIlI.getBlockState(llllllllllllllIllIIlIIlIIIllIIll).getBlock())))
    {
      if (lIlllllllIllIl(llllllllllllllIllIIlIIlIIIllIIlI.getBlockState(llllllllllllllIllIIlIIlIIIllIIll).getValue(FACING), llllllllllllllIllIIlIIlIIIllIlII))
      {
        "".length();
        if (-"   ".length() < 0) {
          break label206;
        }
        return (0x55 ^ 0x65 ^ 0x44 ^ 0x3E) & (75 + 61 - 18 + 24 ^ 41 + 119 - 75 + 111 ^ -" ".length());
      }
      "".length();
      if (-" ".length() <= "  ".length()) {
        break label206;
      }
      return (0xE8 ^ 0xC0 ^ 0x2D ^ 0x31) & (99 + '' - 85 + 20 ^ 86 + 105 - 84 + 48 ^ -" ".length());
    }
    label206:
    return lllllIllIlII[0];
  }
  
  private static boolean lIllllllllIIII(int ???)
  {
    char llllllllllllllIllIIlIIlIIIIIllll;
    return ??? > 0;
  }
  
  private static boolean lIlllllllIllll(int ???, int arg1)
  {
    int i;
    short llllllllllllllIllIIlIIlIIIIlllIl;
    return ??? >= i;
  }
}

package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.util.EnumWorldBlockLayer;

public class BlockGlass
  extends BlockBreakable
{
  static {}
  
  private static void lIlllllIIlII()
  {
    llllIIIlII = new int[2];
    llllIIIlII[0] = ((0x3A ^ 0x5D ^ 0x73 ^ 0x76) & (125 + '¨' - 271 + 224 ^ '' + 57 - 100 + 63 ^ -" ".length()));
    llllIIIlII[1] = " ".length();
  }
  
  public BlockGlass(Material llllllllllllllllllIIllIlIllIIIII, boolean llllllllllllllllllIIllIlIlIlllll)
  {
    llllllllllllllllllIIllIlIllIIIIl.<init>(llllllllllllllllllIIllIlIlIlllIl, llllllllllllllllllIIllIlIlIlllll);
    "".length();
  }
  
  protected boolean canSilkHarvest()
  {
    return llllIIIlII[1];
  }
  
  public int quantityDropped(Random llllllllllllllllllIIllIlIlIllIlI)
  {
    return llllIIIlII[0];
  }
  
  public boolean isFullCube()
  {
    return llllIIIlII[0];
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.IStringSerializable;
import net.minecraft.world.ColorizerGrass;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;

public class BlockTallGrass
  extends BlockBush
  implements IGrowable
{
  public int getMetaFromState(IBlockState llllllllllllllllllIIIllIlIIIIIll)
  {
    ;
    return ((EnumType)llllllllllllllllllIIIllIlIIIIIll.getValue(TYPE)).getMeta();
  }
  
  private static boolean llIIIlIlllII(int ???, int arg1)
  {
    int i;
    char llllllllllllllllllIIIllIIlIlllll;
    return ??? < i;
  }
  
  private static boolean llIIIlIlIlll(Object ???, Object arg1)
  {
    Object localObject;
    float llllllllllllllllllIIIllIIlIlIlll;
    return ??? == localObject;
  }
  
  public void harvestBlock(World llllllllllllllllllIIIllIllIIIIII, EntityPlayer llllllllllllllllllIIIllIllIIIlIl, BlockPos llllllllllllllllllIIIllIllIIIlII, IBlockState llllllllllllllllllIIIllIlIllllIl, TileEntity llllllllllllllllllIIIllIllIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((llIIIlIllIII(isRemote)) && (llIIIlIllIIl(llllllllllllllllllIIIllIllIIIlIl.getCurrentEquippedItem())) && (llIIIlIlIlll(llllllllllllllllllIIIllIllIIIlIl.getCurrentEquippedItem().getItem(), Items.shears)))
    {
      llllllllllllllllllIIIllIllIIIlIl.triggerAchievement(net.minecraft.stats.StatList.mineBlockStatArray[Block.getIdFromBlock(llllllllllllllllllIIIllIllIIIIIl)]);
      spawnAsEntity(llllllllllllllllllIIIllIllIIIIII, llllllllllllllllllIIIllIllIIIlII, new ItemStack(Blocks.tallgrass, lllllIIIII[1], ((EnumType)llllllllllllllllllIIIllIlIllllIl.getValue(TYPE)).getMeta()));
      "".length();
      if ((0x74 ^ 0x21 ^ 0xFE ^ 0xAF) != 0) {}
    }
    else
    {
      llllllllllllllllllIIIllIllIIIIIl.harvestBlock(llllllllllllllllllIIIllIllIIIIII, llllllllllllllllllIIIllIllIIIlIl, llllllllllllllllllIIIllIllIIIlII, llllllllllllllllllIIIllIlIllllIl, llllllllllllllllllIIIllIllIIIIlI);
    }
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllllllIIIllIlIIIIlll)
  {
    ;
    ;
    return llllllllllllllllllIIIllIlIIIlIII.getDefaultState().withProperty(TYPE, EnumType.byMetadata(llllllllllllllllllIIIllIlIIIIlll));
  }
  
  protected BlockTallGrass()
  {
    llllllllllllllllllIIIllIlllllIll.<init>(Material.vine);
    llllllllllllllllllIIIllIllllllIl.setDefaultState(blockState.getBaseState().withProperty(TYPE, EnumType.DEAD_BUSH));
    float llllllllllllllllllIIIllIllllllII = 0.4F;
    llllllllllllllllllIIIllIllllllIl.setBlockBounds(0.5F - llllllllllllllllllIIIllIllllllII, 0.0F, 0.5F - llllllllllllllllllIIIllIllllllII, 0.5F + llllllllllllllllllIIIllIllllllII, 0.8F, 0.5F + llllllllllllllllllIIIllIllllllII);
  }
  
  public Item getItemDropped(IBlockState llllllllllllllllllIIIllIllIllIII, Random llllllllllllllllllIIIllIllIlIlll, int llllllllllllllllllIIIllIllIlIllI)
  {
    ;
    if (llIIIlIllIII(llllllllllllllllllIIIllIllIlIlll.nextInt(lllllIIIII[3])))
    {
      "".length();
      if (null == null) {
        break label31;
      }
      return null;
    }
    label31:
    return null;
  }
  
  public boolean isReplaceable(World llllllllllllllllllIIIllIlllIllIl, BlockPos llllllllllllllllllIIIllIlllIllII)
  {
    return lllllIIIII[1];
  }
  
  public int colorMultiplier(IBlockAccess llllllllllllllllllIIIllIllIlllll, BlockPos llllllllllllllllllIIIllIllIllllI, int llllllllllllllllllIIIllIllIlllIl)
  {
    ;
    ;
    return llllllllllllllllllIIIllIllIlllll.getBiomeGenForCoords(llllllllllllllllllIIIllIllIllIll).getGrassColorAtPos(llllllllllllllllllIIIllIllIllIll);
  }
  
  public Block.EnumOffsetType getOffsetType()
  {
    return Block.EnumOffsetType.XYZ;
  }
  
  private static boolean llIIIlIllIlI(int ???, int arg1)
  {
    int i;
    long llllllllllllllllllIIIllIIllIIIll;
    return ??? >= i;
  }
  
  public int getBlockColor()
  {
    return ColorizerGrass.getGrassColor(0.5D, 1.0D);
  }
  
  private static void llIIIlIlIlIl()
  {
    lllllIIIII = new int[6];
    lllllIIIII[0] = ((0xF9 ^ 0x98) & (0x6E ^ 0xF ^ 0xFFFFFFFF));
    lllllIIIII[1] = " ".length();
    lllllIIIII[2] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lllllIIIII[3] = (0x63 ^ 0x6B);
    lllllIIIII[4] = "  ".length();
    lllllIIIII[5] = "   ".length();
  }
  
  public boolean canBlockStay(World llllllllllllllllllIIIllIllllIIII, BlockPos llllllllllllllllllIIIllIllllIIll, IBlockState llllllllllllllllllIIIllIllllIIlI)
  {
    ;
    ;
    ;
    return llllllllllllllllllIIIllIllllIlIl.canPlaceBlockOn(llllllllllllllllllIIIllIllllIIII.getBlockState(llllllllllllllllllIIIllIllllIIll.down()).getBlock());
  }
  
  static
  {
    llIIIlIlIlIl();
    llIIIlIlIlII();
  }
  
  private static boolean llIIIlIllIII(int ???)
  {
    char llllllllllllllllllIIIllIIlIlIIIl;
    return ??? == 0;
  }
  
  public boolean canGrow(World llllllllllllllllllIIIllIlIlIIlII, BlockPos llllllllllllllllllIIIllIlIlIIIll, IBlockState llllllllllllllllllIIIllIlIlIIIlI, boolean llllllllllllllllllIIIllIlIlIIIIl)
  {
    ;
    if (llIIIlIlIllI(llllllllllllllllllIIIllIlIlIIIlI.getValue(TYPE), EnumType.DEAD_BUSH)) {
      return lllllIIIII[1];
    }
    return lllllIIIII[0];
  }
  
  private static boolean llIIIlIllIll(int ???)
  {
    String llllllllllllllllllIIIllIIlIlIIll;
    return ??? != 0;
  }
  
  public int getRenderColor(IBlockState llllllllllllllllllIIIllIlllIIlll)
  {
    ;
    ;
    ;
    if (llIIIlIlIllI(llllllllllllllllllIIIllIlllIIlll.getBlock(), llllllllllllllllllIIIllIlllIIlIl)) {
      return llllllllllllllllllIIIllIlllIIlIl.getRenderColor(llllllllllllllllllIIIllIlllIIlll);
    }
    EnumType llllllllllllllllllIIIllIlllIIllI = (EnumType)llllllllllllllllllIIIllIlllIIlll.getValue(TYPE);
    if (llIIIlIlIlll(llllllllllllllllllIIIllIlllIIllI, EnumType.DEAD_BUSH))
    {
      "".length();
      if ("   ".length() == "   ".length()) {
        break label121;
      }
      return (38 + 69 - -50 + 17 ^ 90 + 9 - 33 + 80) & (0x1E ^ 0x17 ^ 0x89 ^ 0xBC ^ -" ".length());
    }
    label121:
    return ColorizerGrass.getGrassColor(0.5D, 1.0D);
  }
  
  public int quantityDroppedWithBonus(int llllllllllllllllllIIIllIllIlIIIl, Random llllllllllllllllllIIIllIllIIlllI)
  {
    ;
    ;
    return lllllIIIII[1] + llllllllllllllllllIIIllIllIIlllI.nextInt(llllllllllllllllllIIIllIllIlIIIl * lllllIIIII[4] + lllllIIIII[1]);
  }
  
  public void getSubBlocks(Item llllllllllllllllllIIIllIlIlIlIIl, CreativeTabs llllllllllllllllllIIIllIlIlIllII, List<ItemStack> llllllllllllllllllIIIllIlIlIlIll)
  {
    ;
    ;
    ;
    int llllllllllllllllllIIIllIlIlIlIlI = lllllIIIII[1];
    "".length();
    if ((0x41 ^ 0x45) < 0) {
      return;
    }
    while (!llIIIlIllIlI(llllllllllllllllllIIIllIlIlIlIlI, lllllIIIII[5]))
    {
      new ItemStack(llllllllllllllllllIIIllIlIlIlIIl, lllllIIIII[1], llllllllllllllllllIIIllIlIlIlIlI);
      "".length();
    }
  }
  
  public int getDamageValue(World llllllllllllllllllIIIllIlIllIlll, BlockPos llllllllllllllllllIIIllIlIllIllI)
  {
    ;
    ;
    ;
    IBlockState llllllllllllllllllIIIllIlIllIlIl = llllllllllllllllllIIIllIlIllIlll.getBlockState(llllllllllllllllllIIIllIlIllIllI);
    return llllllllllllllllllIIIllIlIllIlIl.getBlock().getMetaFromState(llllllllllllllllllIIIllIlIllIlIl);
  }
  
  public void grow(World llllllllllllllllllIIIllIlIIlIlIl, Random llllllllllllllllllIIIllIlIIlIlII, BlockPos llllllllllllllllllIIIllIlIIlIIll, IBlockState llllllllllllllllllIIIllIlIIIlllI)
  {
    ;
    ;
    ;
    ;
    BlockDoublePlant.EnumPlantType llllllllllllllllllIIIllIlIIlIIIl = BlockDoublePlant.EnumPlantType.GRASS;
    if (llIIIlIlIlll(llllllllllllllllllIIIllIlIIIlllI.getValue(TYPE), EnumType.FERN)) {
      llllllllllllllllllIIIllIlIIlIIIl = BlockDoublePlant.EnumPlantType.FERN;
    }
    if (llIIIlIllIll(Blocks.double_plant.canPlaceBlockAt(llllllllllllllllllIIIllIlIIlIlIl, llllllllllllllllllIIIllIlIIIllll))) {
      Blocks.double_plant.placeAt(llllllllllllllllllIIIllIlIIlIlIl, llllllllllllllllllIIIllIlIIIllll, llllllllllllllllllIIIllIlIIlIIIl, lllllIIIII[4]);
    }
  }
  
  private static boolean llIIIlIllIIl(Object ???)
  {
    char llllllllllllllllllIIIllIIlIlIlIl;
    return ??? != null;
  }
  
  private static void llIIIlIlIlII()
  {
    llllIlllll = new String[lllllIIIII[1]];
    llllIlllll[lllllIIIII[0]] = llIIIlIlIIll("BxwUJA==", "sedAA");
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllllllIIIllIlIIIIIIl, new IProperty[] { TYPE });
  }
  
  private static String llIIIlIlIIll(String llllllllllllllllllIIIllIIlllIlII, String llllllllllllllllllIIIllIIllIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllllIIIllIIlllIlII = new String(Base64.getDecoder().decode(llllllllllllllllllIIIllIIlllIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllIIIllIIlllIIlI = new StringBuilder();
    char[] llllllllllllllllllIIIllIIlllIIIl = llllllllllllllllllIIIllIIllIlllI.toCharArray();
    int llllllllllllllllllIIIllIIlllIIII = lllllIIIII[0];
    String llllllllllllllllllIIIllIIllIlIlI = llllllllllllllllllIIIllIIlllIlII.toCharArray();
    String llllllllllllllllllIIIllIIllIlIIl = llllllllllllllllllIIIllIIllIlIlI.length;
    boolean llllllllllllllllllIIIllIIllIlIII = lllllIIIII[0];
    while (llIIIlIlllII(llllllllllllllllllIIIllIIllIlIII, llllllllllllllllllIIIllIIllIlIIl))
    {
      char llllllllllllllllllIIIllIIlllIlIl = llllllllllllllllllIIIllIIllIlIlI[llllllllllllllllllIIIllIIllIlIII];
      "".length();
      "".length();
      if ((0x2F ^ 0x2B) == ((0x63 ^ 0x5A) & (0x1D ^ 0x24 ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllllIIIllIIlllIIlI);
  }
  
  public boolean canUseBonemeal(World llllllllllllllllllIIIllIlIIllllI, Random llllllllllllllllllIIIllIlIIlllIl, BlockPos llllllllllllllllllIIIllIlIIlllII, IBlockState llllllllllllllllllIIIllIlIIllIll)
  {
    return lllllIIIII[1];
  }
  
  private static boolean llIIIlIlIllI(Object ???, Object arg1)
  {
    Object localObject;
    char llllllllllllllllllIIIllIIlIllIll;
    return ??? != localObject;
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    private static void llIllIIIIll()
    {
      lIIIIlIllI = new int[8];
      lIIIIlIllI[0] = ((0x40 ^ 0x32 ^ 0xD9 ^ 0x98) & (0xA9 ^ 0xAE ^ 0x22 ^ 0x16 ^ -" ".length()) & (" ".length() & (" ".length() ^ -" ".length()) ^ -" ".length()));
      lIIIIlIllI[1] = " ".length();
      lIIIIlIllI[2] = "  ".length();
      lIIIIlIllI[3] = "   ".length();
      lIIIIlIllI[4] = (0x4D ^ 0x6C ^ 0x2F ^ 0xA);
      lIIIIlIllI[5] = (0xB0 ^ 0xC4 ^ 0xC7 ^ 0xB6);
      lIIIIlIllI[6] = (0x72 ^ 0x5C ^ 0x93 ^ 0xBB);
      lIIIIlIllI[7] = (0x66 ^ 0x6E);
    }
    
    public static EnumType byMetadata(int llIllIIlIlIII)
    {
      ;
      if ((!llIllIIIlIl(llIllIIlIlIII)) || (llIllIIIlII(llIllIIlIIlll, META_LOOKUP.length))) {
        llIllIIlIIlll = lIIIIlIllI[0];
      }
      return META_LOOKUP[llIllIIlIIlll];
    }
    
    private static String llIllIIIIIl(String llIllIIIlIIlI, String llIllIIIlIIll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llIllIIIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llIllIIIlIIll.getBytes(StandardCharsets.UTF_8)), lIIIIlIllI[7]), "DES");
        Cipher llIllIIIlIllI = Cipher.getInstance("DES");
        llIllIIIlIllI.init(lIIIIlIllI[2], llIllIIIlIlll);
        return new String(llIllIIIlIllI.doFinal(Base64.getDecoder().decode(llIllIIIlIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llIllIIIlIlIl)
      {
        llIllIIIlIlIl.printStackTrace();
      }
      return null;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    private static String llIlIllllll(String llIlIllllIIlI, String llIlIllllIIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llIlIllllIIlI = new String(Base64.getDecoder().decode(llIlIllllIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llIlIllllIlIl = new StringBuilder();
      char[] llIlIllllIlII = llIlIllllIIIl.toCharArray();
      int llIlIllllIIll = lIIIIlIllI[0];
      boolean llIlIlllIllIl = llIlIllllIIlI.toCharArray();
      Exception llIlIlllIllII = llIlIlllIllIl.length;
      long llIlIlllIlIll = lIIIIlIllI[0];
      while (llIllIIIllI(llIlIlllIlIll, llIlIlllIllII))
      {
        char llIlIlllllIII = llIlIlllIllIl[llIlIlllIlIll];
        "".length();
        "".length();
        if ((0xB0 ^ 0xB4) <= " ".length()) {
          return null;
        }
      }
      return String.valueOf(llIlIllllIlIl);
    }
    
    private static String llIllIIIIII(String llIllIIIIIlll, String llIllIIIIIlII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llIllIIIIlIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llIllIIIIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llIllIIIIlIIl = Cipher.getInstance("Blowfish");
        llIllIIIIlIIl.init(lIIIIlIllI[2], llIllIIIIlIlI);
        return new String(llIllIIIIlIIl.doFinal(Base64.getDecoder().decode(llIllIIIIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llIllIIIIlIII)
      {
        llIllIIIIlIII.printStackTrace();
      }
      return null;
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private static boolean llIllIIIlII(int ???, int arg1)
    {
      int i;
      Exception llIlIlllIIllI;
      return ??? >= i;
    }
    
    private EnumType(int llIllIIllIllI, String llIllIIllIlIl)
    {
      meta = llIllIIllIIIl;
      name = llIllIIllIlIl;
    }
    
    private static boolean llIllIIIlIl(int ???)
    {
      double llIlIlllIIIII;
      return ??? >= 0;
    }
    
    public int getMeta()
    {
      ;
      return meta;
    }
    
    private static boolean llIllIIIllI(int ???, int arg1)
    {
      int i;
      boolean llIlIlllIIIlI;
      return ??? < i;
    }
    
    static
    {
      llIllIIIIll();
      llIllIIIIlI();
      long llIllIIllllIl;
      Exception llIllIlIIIIII;
      DEAD_BUSH = new EnumType(lIIIIlIlIl[lIIIIlIllI[0]], lIIIIlIllI[0], lIIIIlIllI[0], lIIIIlIlIl[lIIIIlIllI[1]]);
      GRASS = new EnumType(lIIIIlIlIl[lIIIIlIllI[2]], lIIIIlIllI[1], lIIIIlIllI[1], lIIIIlIlIl[lIIIIlIllI[3]]);
      FERN = new EnumType(lIIIIlIlIl[lIIIIlIllI[4]], lIIIIlIllI[2], lIIIIlIllI[2], lIIIIlIlIl[lIIIIlIllI[5]]);
      ENUM$VALUES = new EnumType[] { DEAD_BUSH, GRASS, FERN };
      META_LOOKUP = new EnumType[values().length];
      float llIllIIlllllI = (llIllIIllllIl = values()).length;
      int llIllIIllllll = lIIIIlIllI[0];
      "".length();
      if (" ".length() < -" ".length()) {
        return;
      }
      while (!llIllIIIlII(llIllIIllllll, llIllIIlllllI))
      {
        EnumType llIllIlIIIIIl = llIllIIllllIl[llIllIIllllll];
        META_LOOKUP[llIllIlIIIIIl.getMeta()] = llIllIlIIIIIl;
        llIllIIllllll++;
      }
    }
    
    private static void llIllIIIIlI()
    {
      lIIIIlIlIl = new String[lIIIIlIllI[6]];
      lIIIIlIlIl[lIIIIlIllI[0]] = llIlIllllll("By04DRwBPSoB", "ChyIC");
      lIIIIlIlIl[lIIIIlIllI[1]] = llIlIllllll("FjYvBjAQJj0K", "rSNbo");
      lIIIIlIlIl[lIIIIlIllI[2]] = llIlIllllll("AwMkOgk=", "DQeiZ");
      lIIIIlIlIl[lIIIIlIllI[3]] = llIllIIIIII("+L1z+D7d3ZUuQl3VqdQoCQ==", "IJciv");
      lIIIIlIlIl[lIIIIlIllI[4]] = llIllIIIIIl("giylog54k4U=", "iPyUY");
      lIIIIlIlIl[lIIIIlIllI[5]] = llIlIllllll("EAQZGw==", "vakuT");
    }
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.BlockPos.MutableBlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockFarmland
  extends Block
{
  private static boolean lllIllllllllII(Object ???, Object arg1)
  {
    Object localObject;
    double llllllllllllllIIllIIIlIllIIIllII;
    return ??? != localObject;
  }
  
  private boolean hasCrops(World llllllllllllllIIllIIIlIlllllllll, BlockPos llllllllllllllIIllIIIllIIIIIIIIl)
  {
    ;
    ;
    ;
    Block llllllllllllllIIllIIIllIIIIIIIII = llllllllllllllIIllIIIlIlllllllll.getBlockState(llllllllllllllIIllIIIllIIIIIIIIl.up()).getBlock();
    if ((lllIllllllIlIl(llllllllllllllIIllIIIllIIIIIIIII instanceof BlockCrops)) && (lllIllllllIlIl(llllllllllllllIIllIIIllIIIIIIIII instanceof BlockStem))) {
      return lIIllllIIIIlI[0];
    }
    return lIIllllIIIIlI[2];
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIIllIIIlIlllIIllll, Random llllllllllllllIIllIIIlIlllIIlllI, int llllllllllllllIIllIIIlIlllIIllIl)
  {
    ;
    ;
    return Blocks.dirt.getItemDropped(Blocks.dirt.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.DIRT), llllllllllllllIIllIIIlIlllIIlllI, llllllllllllllIIllIIIlIlllIIllIl);
  }
  
  protected BlockFarmland()
  {
    llllllllllllllIIllIIIllIIIlIllll.<init>(Material.ground);
    llllllllllllllIIllIIIllIIIlIlllI.setDefaultState(blockState.getBaseState().withProperty(MOISTURE, Integer.valueOf(lIIllllIIIIlI[0])));
    "".length();
    llllllllllllllIIllIIIllIIIlIlllI.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.9375F, 1.0F);
    "".length();
  }
  
  public void onFallenUpon(World llllllllllllllIIllIIIllIIIIIllll, BlockPos llllllllllllllIIllIIIllIIIIIlllI, Entity llllllllllllllIIllIIIllIIIIIllIl, float llllllllllllllIIllIIIllIIIIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIlllllllIIl(llllllllllllllIIllIIIllIIIIIllIl instanceof EntityLivingBase))
    {
      if ((lllIllllllIlIl(isRemote)) && (lllIlllllllIlI(lllIlllllllIII(rand.nextFloat(), llllllllllllllIIllIIIllIIIIIIlll - 0.5F))))
      {
        if ((lllIllllllIlIl(llllllllllllllIIllIIIllIIIIIllIl instanceof EntityPlayer)) && (lllIllllllIlIl(llllllllllllllIIllIIIllIIIIIllll.getGameRules().getBoolean(lIIlllIllllll[lIIllllIIIIlI[2]])))) {
          return;
        }
        "".length();
      }
      llllllllllllllIIllIIIllIIIIlIIII.onFallenUpon(llllllllllllllIIllIIIllIIIIIllll, llllllllllllllIIllIIIllIIIIIlIIl, llllllllllllllIIllIIIllIIIIIllIl, llllllllllllllIIllIIIllIIIIIIlll);
    }
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIIllIIIlIllIlllIll, new IProperty[] { MOISTURE });
  }
  
  private static int lllIlllllllIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lllIllllllIlIl(int ???)
  {
    double llllllllllllllIIllIIIlIllIIIIIlI;
    return ??? == 0;
  }
  
  public Item getItem(World llllllllllllllIIllIIIlIlllIIlIIl, BlockPos llllllllllllllIIllIIIlIlllIIlIII)
  {
    return Item.getItemFromBlock(Blocks.dirt);
  }
  
  private static String lllIlllllIIlIl(String llllllllllllllIIllIIIlIllIlIlllI, String llllllllllllllIIllIIIlIllIlIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIIIlIllIlIlllI = new String(Base64.getDecoder().decode(llllllllllllllIIllIIIlIllIlIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIllIIIlIllIlIllII = new StringBuilder();
    char[] llllllllllllllIIllIIIlIllIlIlIll = llllllllllllllIIllIIIlIllIlIlIII.toCharArray();
    int llllllllllllllIIllIIIlIllIlIlIlI = lIIllllIIIIlI[0];
    double llllllllllllllIIllIIIlIllIlIIlII = llllllllllllllIIllIIIlIllIlIlllI.toCharArray();
    byte llllllllllllllIIllIIIlIllIlIIIll = llllllllllllllIIllIIIlIllIlIIlII.length;
    boolean llllllllllllllIIllIIIlIllIlIIIlI = lIIllllIIIIlI[0];
    while (lllIllllllIlll(llllllllllllllIIllIIIlIllIlIIIlI, llllllllllllllIIllIIIlIllIlIIIll))
    {
      char llllllllllllllIIllIIIlIllIlIllll = llllllllllllllIIllIIIlIllIlIIlII[llllllllllllllIIllIIIlIllIlIIIlI];
      "".length();
      "".length();
      if (-" ".length() > 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIllIIIlIllIlIllII);
  }
  
  static
  {
    lllIllllllIlII();
    lllIllllllIIIl();
  }
  
  private static boolean lllIlllllllIlI(int ???)
  {
    double llllllllllllllIIllIIIlIllIIIIIII;
    return ??? < 0;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIIllIIIlIllIlllllI)
  {
    ;
    return ((Integer)llllllllllllllIIllIIIlIllIlllllI.getValue(MOISTURE)).intValue();
  }
  
  private static void lllIllllllIlII()
  {
    lIIllllIIIIlI = new int[10];
    lIIllllIIIIlI[0] = ((0x6A ^ 0x41) & (0xB0 ^ 0x9B ^ 0xFFFFFFFF));
    lIIllllIIIIlI[1] = (86 + 97 - 165 + 158 ^ '' + 82 - 65 + 29);
    lIIllllIIIIlI[2] = " ".length();
    lIIllllIIIIlI[3] = ('' + '«' - 286 + 165 + (37 + 54 - 54 + 198) - (16 + 89 - -79 + 5) + (0xA5 ^ 0xBC));
    lIIllllIIIIlI[4] = "  ".length();
    lIIllllIIIIlI[5] = (-(0x8C ^ 0x94 ^ 0x1F ^ 0x3));
    lIIllllIIIIlI[6] = (19 + 15 - -117 + 7 ^ 16 + 113 - 116 + 141);
    lIIllllIIIIlI[7] = (0x1 ^ 0x6F ^ 0x61 ^ 0x9);
    lIIllllIIIIlI[8] = "   ".length();
    lIIllllIIIIlI[9] = (0xEB ^ 0x90 ^ 0x30 ^ 0x4E);
  }
  
  public boolean isFullCube()
  {
    return lIIllllIIIIlI[0];
  }
  
  private static boolean lllIllllllIllI(int ???)
  {
    Exception llllllllllllllIIllIIIlIlIllllllI;
    return ??? > 0;
  }
  
  public boolean shouldSideBeRendered(IBlockAccess llllllllllllllIIllIIIlIlllIlIllI, BlockPos llllllllllllllIIllIIIlIlllIllIlI, EnumFacing llllllllllllllIIllIIIlIlllIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[llllllllllllllIIllIIIlIlllIllIIl.ordinal()])
    {
    case 2: 
      return lIIllllIIIIlI[2];
    case 3: 
    case 4: 
    case 5: 
    case 6: 
      Block llllllllllllllIIllIIIlIlllIllIII = llllllllllllllIIllIIIlIlllIlIllI.getBlockState(llllllllllllllIIllIIIlIlllIllIlI).getBlock();
      if ((lllIllllllIlIl(llllllllllllllIIllIIIlIlllIllIII.isOpaqueCube())) && (lllIllllllllII(llllllllllllllIIllIIIlIlllIllIII, Blocks.farmland))) {
        return lIIllllIIIIlI[2];
      }
      return lIIllllIIIIlI[0];
    }
    return llllllllllllllIIllIIIlIlllIlIlll.shouldSideBeRendered(llllllllllllllIIllIIIlIlllIlIllI, llllllllllllllIIllIIIlIlllIllIlI, llllllllllllllIIllIIIlIlllIllIIl);
  }
  
  private static boolean lllIllllllllIl(Object ???)
  {
    int llllllllllllllIIllIIIlIllIIIIllI;
    return ??? != null;
  }
  
  public boolean isOpaqueCube()
  {
    return lIIllllIIIIlI[0];
  }
  
  private static String lllIlllllIIllI(String llllllllllllllIIllIIIlIllIIlIlll, String llllllllllllllIIllIIIlIllIIlIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllIIIlIllIIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllIIIlIllIIlIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIIllIIIlIllIIllIll = Cipher.getInstance("Blowfish");
      llllllllllllllIIllIIIlIllIIllIll.init(lIIllllIIIIlI[4], llllllllllllllIIllIIIlIllIIlllII);
      return new String(llllllllllllllIIllIIIlIllIIllIll.doFinal(Base64.getDecoder().decode(llllllllllllllIIllIIIlIllIIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllIIIlIllIIllIlI)
    {
      llllllllllllllIIllIIIlIllIIllIlI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIllllllIlll(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIIllIIIlIllIIlIIII;
    return ??? < i;
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIIllIIIlIlllIIIlII)
  {
    ;
    ;
    return llllllllllllllIIllIIIlIlllIIIlIl.getDefaultState().withProperty(MOISTURE, Integer.valueOf(llllllllllllllIIllIIIlIlllIIIlII & lIIllllIIIIlI[1]));
  }
  
  public void onNeighborBlockChange(World llllllllllllllIIllIIIlIllllIIlIl, BlockPos llllllllllllllIIllIIIlIllllIIlII, IBlockState llllllllllllllIIllIIIlIllllIIIll, Block llllllllllllllIIllIIIlIllllIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIIIlIllllIlIll.onNeighborBlockChange(llllllllllllllIIllIIIlIllllIIlIl, llllllllllllllIIllIIIlIllllIlIIl, llllllllllllllIIllIIIlIllllIIIll, llllllllllllllIIllIIIlIllllIIIlI);
    if (lllIlllllllIIl(llllllllllllllIIllIIIlIllllIIlIl.getBlockState(llllllllllllllIIllIIIlIllllIlIIl.up()).getBlock().getMaterial().isSolid())) {
      "".length();
    }
  }
  
  private static void lllIllllllIIIl()
  {
    lIIlllIllllll = new String[lIIllllIIIIlI[4]];
    lIIlllIllllll[lIIllllIIIIlI[0]] = lllIlllllIIlIl("ARciPiEZCi4=", "lxKMU");
    lIIlllIllllll[lIIllllIIIIlI[2]] = lllIlllllIIllI("2TBAwMvcJUQt8p+Lo6r1ag==", "GAIwK");
  }
  
  public void updateTick(World llllllllllllllIIllIIIllIIIIllIIl, BlockPos llllllllllllllIIllIIIllIIIIllllI, IBlockState llllllllllllllIIllIIIllIIIIlIlll, Random llllllllllllllIIllIIIllIIIIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIIllIIIllIIIIllIll = ((Integer)llllllllllllllIIllIIIllIIIIlIlll.getValue(MOISTURE)).intValue();
    if ((lllIllllllIlIl(llllllllllllllIIllIIIllIIIIllIlI.hasWater(llllllllllllllIIllIIIllIIIIllIIl, llllllllllllllIIllIIIllIIIIllIII))) && (lllIllllllIlIl(llllllllllllllIIllIIIllIIIIllIIl.canLightningStrike(llllllllllllllIIllIIIllIIIIllIII.up()))))
    {
      if (lllIllllllIllI(llllllllllllllIIllIIIllIIIIllIll))
      {
        "".length();
        "".length();
        if (" ".length() != 0) {}
      }
      else if (lllIllllllIlIl(llllllllllllllIIllIIIllIIIIllIlI.hasCrops(llllllllllllllIIllIIIllIIIIllIIl, llllllllllllllIIllIIIllIIIIllIII)))
      {
        "".length();
        "".length();
        if ("   ".length() > ((0x4B ^ 0x1F) & (0x94 ^ 0xC0 ^ 0xFFFFFFFF))) {}
      }
    }
    else if (lllIllllllIlll(llllllllllllllIIllIIIllIIIIllIll, lIIllllIIIIlI[1])) {
      "".length();
    }
  }
  
  private boolean hasWater(World llllllllllllllIIllIIIlIlllllIlII, BlockPos llllllllllllllIIllIIIlIlllllIllI)
  {
    ;
    ;
    ;
    Exception llllllllllllllIIllIIIlIlllllIIIl = BlockPos.getAllInBoxMutable(llllllllllllllIIllIIIlIlllllIllI.add(lIIllllIIIIlI[5], lIIllllIIIIlI[0], lIIllllIIIIlI[5]), llllllllllllllIIllIIIlIlllllIllI.add(lIIllllIIIIlI[6], lIIllllIIIIlI[2], lIIllllIIIIlI[6])).iterator();
    "".length();
    if (-"   ".length() >= 0) {
      return (0x23 ^ 0x55 ^ 0x85 ^ 0xAA) & (0x62 ^ 0x26 ^ 0x73 ^ 0x6E ^ -" ".length());
    }
    while (!lllIllllllIlIl(llllllllllllllIIllIIIlIlllllIIIl.hasNext()))
    {
      BlockPos.MutableBlockPos llllllllllllllIIllIIIlIlllllIlIl = (BlockPos.MutableBlockPos)llllllllllllllIIllIIIlIlllllIIIl.next();
      if (lllIlllllllIll(llllllllllllllIIllIIIlIlllllIlII.getBlockState(llllllllllllllIIllIIIlIlllllIlIl).getBlock().getMaterial(), Material.water)) {
        return lIIllllIIIIlI[2];
      }
    }
    return lIIllllIIIIlI[0];
  }
  
  private static boolean lllIlllllllIIl(int ???)
  {
    boolean llllllllllllllIIllIIIlIllIIIIlII;
    return ??? != 0;
  }
  
  private static boolean lllIlllllllIll(Object ???, Object arg1)
  {
    Object localObject;
    byte llllllllllllllIIllIIIlIllIIIlIII;
    return ??? == localObject;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIIllIIIllIIIlIlIll, BlockPos llllllllllllllIIllIIIllIIIlIlIlI, IBlockState llllllllllllllIIllIIIllIIIlIlIIl)
  {
    ;
    return new AxisAlignedBB(llllllllllllllIIllIIIllIIIlIlIlI.getX(), llllllllllllllIIllIIIllIIIlIlIlI.getY(), llllllllllllllIIllIIIllIIIlIlIlI.getZ(), llllllllllllllIIllIIIllIIIlIlIlI.getX() + lIIllllIIIIlI[2], llllllllllllllIIllIIIllIIIlIlIlI.getY() + lIIllllIIIIlI[2], llllllllllllllIIllIIIllIIIlIlIlI.getZ() + lIIllllIIIIlI[2]);
  }
}

package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockDeadBush
  extends BlockBush
{
  protected boolean canPlaceBlockOn(Block llllllllllllllIlIIlllIIlIlIIllIl)
  {
    ;
    if ((llIlIlIIIIIlll(llllllllllllllIlIIlllIIlIlIIllIl, Blocks.sand)) && (llIlIlIIIIIlll(llllllllllllllIlIIlllIIlIlIIllII, Blocks.hardened_clay)) && (llIlIlIIIIIlll(llllllllllllllIlIIlllIIlIlIIllII, Blocks.stained_hardened_clay)) && (llIlIlIIIIIlll(llllllllllllllIlIIlllIIlIlIIllII, Blocks.dirt))) {
      return lIIIlIllIIIll[0];
    }
    return lIIIlIllIIIll[1];
  }
  
  private static boolean llIlIlIIIIlIIl(Object ???)
  {
    char llllllllllllllIlIIlllIIlIIlIllIl;
    return ??? != null;
  }
  
  private static boolean llIlIlIIIIIlll(Object ???, Object arg1)
  {
    Object localObject;
    boolean llllllllllllllIlIIlllIIlIIlIllll;
    return ??? != localObject;
  }
  
  public boolean isReplaceable(World llllllllllllllIlIIlllIIlIlIIlIlI, BlockPos llllllllllllllIlIIlllIIlIlIIlIIl)
  {
    return lIIIlIllIIIll[1];
  }
  
  static {}
  
  private static boolean llIlIlIIIIlIII(int ???)
  {
    float llllllllllllllIlIIlllIIlIIlIIlll;
    return ??? == 0;
  }
  
  private static boolean llIlIlIIIIlIlI(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllIlIIlllIIlIIlIlIIl;
    return ??? == localObject;
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIlIIlllIIlIlIIIlll, Random llllllllllllllIlIIlllIIlIlIIIllI, int llllllllllllllIlIIlllIIlIlIIIlIl)
  {
    return null;
  }
  
  public void harvestBlock(World llllllllllllllIlIIlllIIlIIllllIl, EntityPlayer llllllllllllllIlIIlllIIlIIllllII, BlockPos llllllllllllllIlIIlllIIlIIllIlIl, IBlockState llllllllllllllIlIIlllIIlIIllIlII, TileEntity llllllllllllllIlIIlllIIlIIlllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((llIlIlIIIIlIII(isRemote)) && (llIlIlIIIIlIIl(llllllllllllllIlIIlllIIlIIllllII.getCurrentEquippedItem())) && (llIlIlIIIIlIlI(llllllllllllllIlIIlllIIlIIllllII.getCurrentEquippedItem().getItem(), Items.shears)))
    {
      llllllllllllllIlIIlllIIlIIllllII.triggerAchievement(net.minecraft.stats.StatList.mineBlockStatArray[Block.getIdFromBlock(llllllllllllllIlIIlllIIlIIlllllI)]);
      spawnAsEntity(llllllllllllllIlIIlllIIlIIllllIl, llllllllllllllIlIIlllIIlIIllIlIl, new ItemStack(Blocks.deadbush, lIIIlIllIIIll[1], lIIIlIllIIIll[0]));
      "".length();
      if (-"   ".length() < 0) {}
    }
    else
    {
      llllllllllllllIlIIlllIIlIIlllllI.harvestBlock(llllllllllllllIlIIlllIIlIIllllIl, llllllllllllllIlIIlllIIlIIllllII, llllllllllllllIlIIlllIIlIIllIlIl, llllllllllllllIlIIlllIIlIIllIlII, llllllllllllllIlIIlllIIlIIlllIIl);
    }
  }
  
  private static void llIlIlIIIIIllI()
  {
    lIIIlIllIIIll = new int[2];
    lIIIlIllIIIll[0] = ((86 + 8 - 89 + 186 ^ 5 + 42 - -74 + 53) & (0xFE ^ 0x8C ^ 0x6 ^ 0x65 ^ -" ".length()));
    lIIIlIllIIIll[1] = " ".length();
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllIlIIlllIIlIlIlIIII)
  {
    return MapColor.woodColor;
  }
  
  protected BlockDeadBush()
  {
    llllllllllllllIlIIlllIIlIlIlIIll.<init>(Material.vine);
    float llllllllllllllIlIIlllIIlIlIlIlII = 0.4F;
    llllllllllllllIlIIlllIIlIlIlIlIl.setBlockBounds(0.5F - llllllllllllllIlIIlllIIlIlIlIlII, 0.0F, 0.5F - llllllllllllllIlIIlllIIlIlIlIlII, 0.5F + llllllllllllllIlIIlllIIlIlIlIlII, 0.8F, 0.5F + llllllllllllllIlIIlllIIlIlIlIlII);
  }
}

package net.minecraft.block;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;

public class BlockLeavesBase
  extends Block
{
  private static void llIIlIlIIIIIl()
  {
    lIIIIIlIIlIl = new int[1];
    lIIIIIlIIlIl[0] = ((0xCB ^ 0x9F) & (0xD ^ 0x59 ^ 0xFFFFFFFF));
  }
  
  public boolean shouldSideBeRendered(IBlockAccess lllllllllllllllIlllllllllIIlIIIl, BlockPos lllllllllllllllIlllllllllIIlIlII, EnumFacing lllllllllllllllIlllllllllIIlIIll)
  {
    ;
    ;
    ;
    ;
    if ((llIIlIlIIIIlI(fancyGraphics)) && (llIIlIlIIIIll(lllllllllllllllIlllllllllIIlIIIl.getBlockState(lllllllllllllllIlllllllllIIlIlII).getBlock(), lllllllllllllllIlllllllllIIlIIlI)))
    {
      "".length();
      if (((0xC8 ^ 0x98) & (0xF ^ 0x5F ^ 0xFFFFFFFF)) == 0) {
        break label81;
      }
      return (0x75 ^ 0x3E) & (0xDF ^ 0x94 ^ 0xFFFFFFFF);
    }
    label81:
    return lllllllllllllllIlllllllllIIlIIlI.shouldSideBeRendered(lllllllllllllllIlllllllllIIlIIIl, lllllllllllllllIlllllllllIIlIlII, lllllllllllllllIlllllllllIIlIIll);
  }
  
  private static boolean llIIlIlIIIIll(Object ???, Object arg1)
  {
    Object localObject;
    char lllllllllllllllIlllllllllIIIlIll;
    return ??? == localObject;
  }
  
  static {}
  
  public boolean isOpaqueCube()
  {
    return lIIIIIlIIlIl[0];
  }
  
  protected BlockLeavesBase(Material lllllllllllllllIlllllllllIIlllIl, boolean lllllllllllllllIlllllllllIIlllll)
  {
    lllllllllllllllIlllllllllIlIIIIl.<init>(lllllllllllllllIlllllllllIlIIIII);
    fancyGraphics = lllllllllllllllIlllllllllIIlllll;
  }
  
  private static boolean llIIlIlIIIIlI(int ???)
  {
    char lllllllllllllllIlllllllllIIIlIIl;
    return ??? == 0;
  }
}

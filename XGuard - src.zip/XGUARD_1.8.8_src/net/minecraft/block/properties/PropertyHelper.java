package net.minecraft.block.properties;

import com.google.common.base.Objects;
import com.google.common.base.Objects.ToStringHelper;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public abstract class PropertyHelper<T extends Comparable<T>>
  implements IProperty<T>
{
  private static void lIIIlIIllllIll()
  {
    lIllIIlIllII = new int[6];
    lIllIIlIllII[0] = ((0xE2 ^ 0xAE ^ 0x62 ^ 0xA) & (109 + '' - 106 + 7 ^ 47 + 7 - -18 + 98 ^ -" ".length()));
    lIllIIlIllII[1] = " ".length();
    lIllIIlIllII[2] = "  ".length();
    lIllIIlIllII[3] = (0xB7 ^ 0xA8);
    lIllIIlIllII[4] = "   ".length();
    lIllIIlIllII[5] = (6 + 16 - -90 + 32 ^ 45 + '' - 85 + 47);
  }
  
  public boolean equals(Object lllllllllllllllIIllIllIIlIlIIIII)
  {
    ;
    ;
    ;
    if (lIIIlIIlllllII(lllllllllllllllIIllIllIIlIlIIIIl, lllllllllllllllIIllIllIIlIlIIIII)) {
      return lIllIIlIllII[1];
    }
    if ((lIIIlIIlllllIl(lllllllllllllllIIllIllIIlIlIIIII)) && (lIIIlIIlllllII(lllllllllllllllIIllIllIIlIlIIIIl.getClass(), lllllllllllllllIIllIllIIlIlIIIII.getClass())))
    {
      PropertyHelper lllllllllllllllIIllIllIIlIIlllll = (PropertyHelper)lllllllllllllllIIllIllIIlIlIIIII;
      if ((lIIIlIIllllllI(valueClass.equals(valueClass))) && (lIIIlIIllllllI(name.equals(name)))) {
        return lIllIIlIllII[1];
      }
      return lIllIIlIllII[0];
    }
    return lIllIIlIllII[0];
  }
  
  static
  {
    lIIIlIIllllIll();
    lIIIlIIllllIIl();
  }
  
  private static String lIIIlIIlllIlll(String lllllllllllllllIIllIllIIlIIIllll, String lllllllllllllllIIllIllIIlIIlIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIllIllIIlIIlIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIllIIlIIlIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIllIllIIlIIlIIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIIllIllIIlIIlIIll.init(lIllIIlIllII[2], lllllllllllllllIIllIllIIlIIlIlII);
      return new String(lllllllllllllllIIllIllIIlIIlIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIllIIlIIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIllIllIIlIIlIIlI)
    {
      lllllllllllllllIIllIllIIlIIlIIlI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIlIIlllllIl(Object ???)
  {
    String lllllllllllllllIIllIllIIIllllIIl;
    return ??? != null;
  }
  
  public String getName()
  {
    ;
    return name;
  }
  
  private static boolean lIIIlIIllllllI(int ???)
  {
    Exception lllllllllllllllIIllIllIIIlllIlll;
    return ??? != 0;
  }
  
  private static String lIIIlIIlllIllI(String lllllllllllllllIIllIllIIlIIIIlII, String lllllllllllllllIIllIllIIlIIIIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIllIllIIlIIIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIllIIlIIIIIll.getBytes(StandardCharsets.UTF_8)), lIllIIlIllII[5]), "DES");
      Cipher lllllllllllllllIIllIllIIlIIIIllI = Cipher.getInstance("DES");
      lllllllllllllllIIllIllIIlIIIIllI.init(lIllIIlIllII[2], lllllllllllllllIIllIllIIlIIIIlll);
      return new String(lllllllllllllllIIllIllIIlIIIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIllIIlIIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIllIllIIlIIIIlIl)
    {
      lllllllllllllllIIllIllIIlIIIIlIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIlIIlllllII(Object ???, Object arg1)
  {
    Object localObject;
    float lllllllllllllllIIllIllIIIllllIll;
    return ??? == localObject;
  }
  
  protected PropertyHelper(String lllllllllllllllIIllIllIIlIllIIlI, Class<T> lllllllllllllllIIllIllIIlIllIIIl)
  {
    valueClass = lllllllllllllllIIllIllIIlIllIIIl;
    name = lllllllllllllllIIllIllIIlIlIllll;
  }
  
  public Class<T> getValueClass()
  {
    ;
    return valueClass;
  }
  
  private static void lIIIlIIllllIIl()
  {
    lIllIIlIlIll = new String[lIllIIlIllII[4]];
    lIllIIlIlIll[lIllIIlIllII[0]] = lIIIlIIlllIllI("Ts5KbzFRQ3w=", "BfJdw");
    lIllIIlIlIll[lIllIIlIllII[1]] = lIIIlIIlllIlll("rCn0rj4CCPw=", "KTQNb");
    lIllIIlIlIll[lIllIIlIllII[2]] = lIIIlIIlllIllI("Zxgxh+9J9Ro=", "jHgmr");
  }
  
  public int hashCode()
  {
    ;
    return lIllIIlIllII[3] * valueClass.hashCode() + name.hashCode();
  }
  
  public String toString()
  {
    ;
    return Objects.toStringHelper(lllllllllllllllIIllIllIIlIlIIlIl).add(lIllIIlIlIll[lIllIIlIllII[0]], name).add(lIllIIlIlIll[lIllIIlIllII[1]], valueClass).add(lIllIIlIlIll[lIllIIlIllII[2]], lllllllllllllllIIllIllIIlIlIIllI.getAllowedValues()).toString();
  }
}

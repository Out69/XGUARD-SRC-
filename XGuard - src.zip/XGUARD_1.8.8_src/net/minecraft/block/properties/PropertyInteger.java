package net.minecraft.block.properties;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class PropertyInteger
  extends PropertyHelper<Integer>
{
  public boolean equals(Object llllllllllllllIllIlIIlIIIlIlllIl)
  {
    ;
    ;
    ;
    if (lIlllIlllIIIIl(llllllllllllllIllIlIIlIIIllIIIIl, llllllllllllllIllIlIIlIIIlIlllIl)) {
      return llllIllIlIIl[1];
    }
    if ((lIlllIlllIIIlI(llllllllllllllIllIlIIlIIIlIlllIl)) && (lIlllIlllIIIIl(llllllllllllllIllIlIIlIIIllIIIIl.getClass(), llllllllllllllIllIlIIlIIIlIlllIl.getClass())))
    {
      if (lIlllIlllIIIll(llllllllllllllIllIlIIlIIIllIIIIl.equals(llllllllllllllIllIlIIlIIIlIlllIl))) {
        return llllIllIlIIl[0];
      }
      PropertyInteger llllllllllllllIllIlIIlIIIlIlllll = (PropertyInteger)llllllllllllllIllIlIIlIIIlIlllIl;
      return allowedValues.equals(allowedValues);
    }
    return llllIllIlIIl[0];
  }
  
  private static boolean lIlllIllIllllI(int ???)
  {
    Exception llllllllllllllIllIlIIlIIIIIllIIl;
    return ??? < 0;
  }
  
  private static String lIlllIllIlIlll(String llllllllllllllIllIlIIlIIIIllIIII, String llllllllllllllIllIlIIlIIIIlIllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIlIIlIIIIllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIIlIIIIlIllll.getBytes(StandardCharsets.UTF_8)), llllIllIlIIl[7]), "DES");
      Cipher llllllllllllllIllIlIIlIIIIllIIlI = Cipher.getInstance("DES");
      llllllllllllllIllIlIIlIIIIllIIlI.init(llllIllIlIIl[2], llllllllllllllIllIlIIlIIIIllIIll);
      return new String(llllllllllllllIllIlIIlIIIIllIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIIlIIIIllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIlIIlIIIIllIIIl)
    {
      llllllllllllllIllIlIIlIIIIllIIIl.printStackTrace();
    }
    return null;
  }
  
  public int hashCode()
  {
    ;
    ;
    int llllllllllllllIllIlIIlIIIlIllIII = llllllllllllllIllIlIIlIIIlIlIlll.hashCode();
    llllllllllllllIllIlIIlIIIlIllIII = llllIllIlIIl[5] * llllllllllllllIllIlIIlIIIlIllIII + allowedValues.hashCode();
    return llllllllllllllIllIlIIlIIIlIllIII;
  }
  
  private static boolean lIlllIllIlllll(int ???, int arg1)
  {
    int i;
    String llllllllllllllIllIlIIlIIIIlIIlll;
    return ??? <= i;
  }
  
  public static PropertyInteger create(String llllllllllllllIllIlIIlIIIlIIllll, int llllllllllllllIllIlIIlIIIlIIlllI, int llllllllllllllIllIlIIlIIIlIIllIl)
  {
    ;
    ;
    ;
    return new PropertyInteger(llllllllllllllIllIlIIlIIIlIIllll, llllllllllllllIllIlIIlIIIlIlIIIl, llllllllllllllIllIlIIlIIIlIIllIl);
  }
  
  private static boolean lIlllIlllIIIlI(Object ???)
  {
    char llllllllllllllIllIlIIlIIIIIlllIl;
    return ??? != null;
  }
  
  protected PropertyInteger(String llllllllllllllIllIlIIlIIIllIllII, int llllllllllllllIllIlIIlIIIllIlIll, int llllllllllllllIllIlIIlIIIllIlIlI)
  {
    llllllllllllllIllIlIIlIIIlllIIll.<init>(llllllllllllllIllIlIIlIIIllIllII, Integer.class);
    if (lIlllIllIllllI(llllllllllllllIllIlIIlIIIllIlIll)) {
      throw new IllegalArgumentException(String.valueOf(new StringBuilder(llllIllIIlll[llllIllIlIIl[0]]).append(llllllllllllllIllIlIIlIIIllIllII).append(llllIllIIlll[llllIllIlIIl[1]])));
    }
    if (lIlllIllIlllll(llllllllllllllIllIlIIlIIIllIlIlI, llllllllllllllIllIlIIlIIIllIlIll)) {
      throw new IllegalArgumentException(String.valueOf(new StringBuilder(llllIllIIlll[llllIllIlIIl[2]]).append(llllllllllllllIllIlIIlIIIllIllII).append(llllIllIIlll[llllIllIlIIl[3]]).append(llllllllllllllIllIlIIlIIIllIlIll).append(llllIllIIlll[llllIllIlIIl[4]])));
    }
    Set<Integer> llllllllllllllIllIlIIlIIIllIllll = Sets.newHashSet();
    int llllllllllllllIllIlIIlIIIllIlllI = llllllllllllllIllIlIIlIIIllIlIll;
    "".length();
    if (" ".length() != " ".length()) {
      throw null;
    }
    while (!lIlllIlllIIIII(llllllllllllllIllIlIIlIIIllIlllI, llllllllllllllIllIlIIlIIIllIlIlI)) {
      "".length();
    }
    allowedValues = ImmutableSet.copyOf(llllllllllllllIllIlIIlIIIllIllll);
  }
  
  private static void lIlllIllIllIIl()
  {
    llllIllIIlll = new String[llllIllIlIIl[6]];
    llllIllIIlll[llllIllIlIIl[0]] = lIlllIllIlIlll("vZi9h0zK6M0qgpGhrOjUEA==", "gWqmd");
    llllIllIIlll[llllIllIlIIl[1]] = lIlllIllIllIII("Q/tHOTbmKB8C0+khDJn4/fVHpKn/cRUR", "rnitr");
    llllIllIIlll[llllIllIlIIl[2]] = lIlllIllIlIlll("Nfs72jLezTEsiXOvAmrHPw==", "ryZhQ");
    llllIllIIlll[llllIllIlIIl[3]] = lIlllIllIlIlll("GaOO7EiKXpUbMtYrwPcDctGY7aVOs1JEtwByRBEZUk8=", "RFhLY");
    llllIllIIlll[llllIllIlIIl[4]] = lIlllIllIlIlll("7NgGSCl//dY=", "quIvy");
  }
  
  private static void lIlllIllIlllIl()
  {
    llllIllIlIIl = new int[8];
    llllIllIlIIl[0] = ((0xE0 ^ 0xBD) & (0x9A ^ 0xC7 ^ 0xFFFFFFFF));
    llllIllIlIIl[1] = " ".length();
    llllIllIlIIl[2] = "  ".length();
    llllIllIlIIl[3] = "   ".length();
    llllIllIlIIl[4] = (0x32 ^ 0x36);
    llllIllIlIIl[5] = (28 + 38 - -6 + 103 ^ 84 + 82 - 93 + 103);
    llllIllIlIIl[6] = (0x11 ^ 0x14);
    llllIllIlIIl[7] = (0x5E ^ 0x69 ^ 0xA ^ 0x35);
  }
  
  static
  {
    lIlllIllIlllIl();
    lIlllIllIllIIl();
  }
  
  public String getName(Integer llllllllllllllIllIlIIlIIIlIIlIIl)
  {
    ;
    return llllllllllllllIllIlIIlIIIlIIlIIl.toString();
  }
  
  private static boolean lIlllIlllIIIll(int ???)
  {
    short llllllllllllllIllIlIIlIIIIIllIll;
    return ??? == 0;
  }
  
  private static boolean lIlllIlllIIIII(int ???, int arg1)
  {
    int i;
    int llllllllllllllIllIlIIlIIIIlIIIll;
    return ??? > i;
  }
  
  private static boolean lIlllIlllIIIIl(Object ???, Object arg1)
  {
    Object localObject;
    byte llllllllllllllIllIlIIlIIIIIlllll;
    return ??? == localObject;
  }
  
  private static String lIlllIllIllIII(String llllllllllllllIllIlIIlIIIIllllIl, String llllllllllllllIllIlIIlIIIIllllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIlIIlIIIlIIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIIlIIIIllllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIlIIlIIIIllllll = Cipher.getInstance("Blowfish");
      llllllllllllllIllIlIIlIIIIllllll.init(llllIllIlIIl[2], llllllllllllllIllIlIIlIIIlIIIIII);
      return new String(llllllllllllllIllIlIIlIIIIllllll.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIIlIIIIllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIlIIlIIIIlllllI)
    {
      llllllllllllllIllIlIIlIIIIlllllI.printStackTrace();
    }
    return null;
  }
  
  public Collection<Integer> getAllowedValues()
  {
    ;
    return allowedValues;
  }
}

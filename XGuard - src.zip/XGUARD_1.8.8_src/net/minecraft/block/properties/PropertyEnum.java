package net.minecraft.block.properties;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Collections2;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.util.IStringSerializable;

public class PropertyEnum<T extends Enum<T>,  extends IStringSerializable>
  extends PropertyHelper<T>
{
  public static <T extends Enum<T>,  extends IStringSerializable> PropertyEnum<T> create(String lllllllllllllllIIlIlIIllIlllIIIl, Class<T> lllllllllllllllIIlIlIIllIlllIIII, T... lllllllllllllllIIlIlIIllIllIllll)
  {
    ;
    ;
    ;
    return create(lllllllllllllllIIlIlIIllIlllIIIl, lllllllllllllllIIlIlIIllIllIllIl, Lists.newArrayList(lllllllllllllllIIlIlIIllIllIllll));
  }
  
  private static void lIIlIIIIlIlIll()
  {
    lIllllIIllII = new int[3];
    lIllllIIllII[0] = ((0xCC ^ 0xC0) & (0x94 ^ 0x98 ^ 0xFFFFFFFF));
    lIllllIIllII[1] = " ".length();
    lIllllIIllII[2] = "  ".length();
  }
  
  public String getName(T lllllllllllllllIIlIlIIlllIIIIlII)
  {
    ;
    return ((IStringSerializable)lllllllllllllllIIlIlIIlllIIIIlII).getName();
  }
  
  public static <T extends Enum<T>,  extends IStringSerializable> PropertyEnum<T> create(String lllllllllllllllIIlIlIIllIlllllll, Class<T> lllllllllllllllIIlIlIIllIllllllI)
  {
    ;
    ;
    return create(lllllllllllllllIIlIlIIllIlllllll, lllllllllllllllIIlIlIIllIllllllI, Predicates.alwaysTrue());
  }
  
  public Collection<T> getAllowedValues()
  {
    ;
    return allowedValues;
  }
  
  private static boolean lIIlIIIIlIllll(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIIlIlIIllIlIIIIll;
    return ??? < i;
  }
  
  static
  {
    lIIlIIIIlIlIll();
    lIIlIIIIlIlIIl();
  }
  
  public static <T extends Enum<T>,  extends IStringSerializable> PropertyEnum<T> create(String lllllllllllllllIIlIlIIllIllllIlI, Class<T> lllllllllllllllIIlIlIIllIllllIIl, Predicate<T> lllllllllllllllIIlIlIIllIllllIII)
  {
    ;
    ;
    ;
    return create(lllllllllllllllIIlIlIIllIllllIlI, lllllllllllllllIIlIlIIllIlllIllI, Collections2.filter(Lists.newArrayList((Enum[])lllllllllllllllIIlIlIIllIlllIllI.getEnumConstants()), lllllllllllllllIIlIlIIllIllllIII));
  }
  
  private static boolean lIIlIIIIlIllIl(int ???)
  {
    byte lllllllllllllllIIlIlIIllIlIIIIIl;
    return ??? != 0;
  }
  
  private static String lIIlIIIIlIlIII(String lllllllllllllllIIlIlIIllIlIIllll, String lllllllllllllllIIlIlIIllIlIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIlIIllIlIIllll = new String(Base64.getDecoder().decode(lllllllllllllllIIlIlIIllIlIIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlIlIIllIlIlIIlI = new StringBuilder();
    char[] lllllllllllllllIIlIlIIllIlIlIIIl = lllllllllllllllIIlIlIIllIlIlIIll.toCharArray();
    int lllllllllllllllIIlIlIIllIlIlIIII = lIllllIIllII[0];
    char lllllllllllllllIIlIlIIllIlIIlIlI = lllllllllllllllIIlIlIIllIlIIllll.toCharArray();
    Exception lllllllllllllllIIlIlIIllIlIIlIIl = lllllllllllllllIIlIlIIllIlIIlIlI.length;
    float lllllllllllllllIIlIlIIllIlIIlIII = lIllllIIllII[0];
    while (lIIlIIIIlIllll(lllllllllllllllIIlIlIIllIlIIlIII, lllllllllllllllIIlIlIIllIlIIlIIl))
    {
      char lllllllllllllllIIlIlIIllIlIlIlIl = lllllllllllllllIIlIlIIllIlIIlIlI[lllllllllllllllIIlIlIIllIlIIlIII];
      "".length();
      "".length();
      if (" ".length() <= ((18 + 70 - 77 + 165 ^ 91 + 68 - 66 + 78) & (18 + '' - 33 + 42 ^ 87 + 103 - 71 + 61 ^ -" ".length()))) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlIlIIllIlIlIIlI);
  }
  
  private static void lIIlIIIIlIlIIl()
  {
    lIllllIIIlll = new String[lIllllIIllII[2]];
    lIllllIIIlll[lIllllIIllII[0]] = lIIlIIIIlIlIII("Jx4DJSQaBwpxOwsHGjQ+SgMOJyhKHwc0bRkKAjRtBAoCNG1N", "jkoQM");
    lIllllIIIlll[lIllllIIllII[1]] = lIIlIIIIlIlIII("TQ==", "jznRG");
  }
  
  private static boolean lIIlIIIIlIlllI(int ???)
  {
    float lllllllllllllllIIlIlIIllIIllllll;
    return ??? == 0;
  }
  
  protected PropertyEnum(String lllllllllllllllIIlIlIIlllIIlIIII, Class<T> lllllllllllllllIIlIlIIlllIIlIlIl, Collection<T> lllllllllllllllIIlIlIIlllIIIlllI)
  {
    lllllllllllllllIIlIlIIlllIIlIlll.<init>(lllllllllllllllIIlIlIIlllIIlIIII, lllllllllllllllIIlIlIIlllIIlIlIl);
    allowedValues = ImmutableSet.copyOf(lllllllllllllllIIlIlIIlllIIIlllI);
    short lllllllllllllllIIlIlIIlllIIIllII = lllllllllllllllIIlIlIIlllIIIlllI.iterator();
    "".length();
    if (((0x4A ^ 0x28) & (0x3D ^ 0x5F ^ 0xFFFFFFFF)) != 0) {
      throw null;
    }
    while (!lIIlIIIIlIlllI(lllllllllllllllIIlIlIIlllIIIllII.hasNext()))
    {
      T lllllllllllllllIIlIlIIlllIIlIIll = (Enum)lllllllllllllllIIlIlIIlllIIIllII.next();
      String lllllllllllllllIIlIlIIlllIIlIIlI = ((IStringSerializable)lllllllllllllllIIlIlIIlllIIlIIll).getName();
      if (lIIlIIIIlIllIl(nameToValue.containsKey(lllllllllllllllIIlIlIIlllIIlIIlI))) {
        throw new IllegalArgumentException(String.valueOf(new StringBuilder(lIllllIIIlll[lIllllIIllII[0]]).append(lllllllllllllllIIlIlIIlllIIlIIlI).append(lIllllIIIlll[lIllllIIllII[1]])));
      }
      "".length();
    }
  }
  
  public static <T extends Enum<T>,  extends IStringSerializable> PropertyEnum<T> create(String lllllllllllllllIIlIlIIllIllIIlIl, Class<T> lllllllllllllllIIlIlIIllIllIIlll, Collection<T> lllllllllllllllIIlIlIIllIllIIllI)
  {
    ;
    ;
    ;
    return new PropertyEnum(lllllllllllllllIIlIlIIllIllIIlIl, lllllllllllllllIIlIlIIllIllIIlII, lllllllllllllllIIlIlIIllIllIIllI);
  }
}

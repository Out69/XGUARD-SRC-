package net.minecraft.block.properties;

import java.util.Collection;

public class PropertyBool
  extends PropertyHelper<Boolean>
{
  public static PropertyBool create(String llllllllllllllIllIlIlllIlllIIlII)
  {
    ;
    return new PropertyBool(llllllllllllllIllIlIlllIlllIIIll);
  }
  
  protected PropertyBool(String llllllllllllllIllIlIlllIlllIlIIl)
  {
    llllllllllllllIllIlIlllIlllIllII.<init>(llllllllllllllIllIlIlllIlllIlIIl, Boolean.class);
  }
  
  static {}
  
  public String getName(Boolean llllllllllllllIllIlIlllIlllIIIII)
  {
    ;
    return llllllllllllllIllIlIlllIlllIIIII.toString();
  }
  
  private static void lIlllIIIIllllI()
  {
    llllIIlIIlII = new int[2];
    llllIIlIIlII[0] = " ".length();
    llllIIlIIlII[1] = ((0x9F ^ 0x8A ^ 0x2D ^ 0x24) & (0x61 ^ 0x44 ^ 0xFA ^ 0xC3 ^ -" ".length()));
  }
  
  public Collection<Boolean> getAllowedValues()
  {
    ;
    return allowedValues;
  }
}

package net.minecraft.block.properties;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import java.util.Collection;
import net.minecraft.util.EnumFacing;

public class PropertyDirection
  extends PropertyEnum<EnumFacing>
{
  public static PropertyDirection create(String lllllllllllllllIlllIIlIlIIIlIIll, Predicate<EnumFacing> lllllllllllllllIlllIIlIlIIIlIIII)
  {
    ;
    ;
    return create(lllllllllllllllIlllIIlIlIIIlIIll, Collections2.filter(Lists.newArrayList(EnumFacing.values()), lllllllllllllllIlllIIlIlIIIlIIII));
  }
  
  public static PropertyDirection create(String lllllllllllllllIlllIIlIlIIIlIlll)
  {
    ;
    return create(lllllllllllllllIlllIIlIlIIIlIlll, Predicates.alwaysTrue());
  }
  
  protected PropertyDirection(String lllllllllllllllIlllIIlIlIIIlllIl, Collection<EnumFacing> lllllllllllllllIlllIIlIlIIIlllII)
  {
    lllllllllllllllIlllIIlIlIIIllllI.<init>(lllllllllllllllIlllIIlIlIIIllIlI, EnumFacing.class, lllllllllllllllIlllIIlIlIIIlllII);
  }
  
  public static PropertyDirection create(String lllllllllllllllIlllIIlIlIIIIllIl, Collection<EnumFacing> lllllllllllllllIlllIIlIlIIIIllII)
  {
    ;
    ;
    return new PropertyDirection(lllllllllllllllIlllIIlIlIIIIllIl, lllllllllllllllIlllIIlIlIIIIllII);
  }
}

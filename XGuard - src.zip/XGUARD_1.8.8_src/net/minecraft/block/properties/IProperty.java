package net.minecraft.block.properties;

import java.util.Collection;

public abstract interface IProperty<T extends Comparable<T>>
{
  public abstract Class<T> getValueClass();
  
  public abstract String getName(T paramT);
  
  public abstract Collection<T> getAllowedValues();
  
  public abstract String getName();
}

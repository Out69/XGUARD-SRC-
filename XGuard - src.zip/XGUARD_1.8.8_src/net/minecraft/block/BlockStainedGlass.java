package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.World;

public class BlockStainedGlass
  extends BlockBreakable
{
  public int damageDropped(IBlockState llllllllllllllllIIlIIIIlIllIllll)
  {
    ;
    return ((EnumDyeColor)llllllllllllllllIIlIIIIlIllIllll.getValue(COLOR)).getMetadata();
  }
  
  public boolean isFullCube()
  {
    return llllIIIIIII[0];
  }
  
  public int quantityDropped(Random llllllllllllllllIIlIIIIlIlIlIlll)
  {
    return llllIIIIIII[0];
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllllIIlIIIIlIIlllIII, new IProperty[] { COLOR });
  }
  
  private static boolean lIlllIIlllIll(int ???)
  {
    byte llllllllllllllllIIlIIIIlIIlIIlIl;
    return ??? == 0;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.TRANSLUCENT;
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllllIIlIIIIlIlIIllll)
  {
    ;
    ;
    return llllllllllllllllIIlIIIIlIlIlIIII.getDefaultState().withProperty(COLOR, EnumDyeColor.byMetadata(llllllllllllllllIIlIIIIlIlIIllll));
  }
  
  private static String lIllIllIlIIII(String llllllllllllllllIIlIIIIlIIlIlllI, String llllllllllllllllIIlIIIIlIIlIllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIlIIIIlIIllIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIlIIIIlIIlIllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIIlIIIIlIIllIIlI = Cipher.getInstance("Blowfish");
      llllllllllllllllIIlIIIIlIIllIIlI.init(llllIIIIIII[2], llllllllllllllllIIlIIIIlIIllIIll);
      return new String(llllllllllllllllIIlIIIIlIIllIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllIIlIIIIlIIlIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIlIIIIlIIllIIIl)
    {
      llllllllllllllllIIlIIIIlIIllIIIl.printStackTrace();
    }
    return null;
  }
  
  private static void lIlllIIlllIIl()
  {
    llllIIIIIII = new int[3];
    llllIIIIIII[0] = ((46 + 78 - 88 + 94 ^ '' + 23 - 0 + 5) & (0xB5 ^ 0x91 ^ 0x4D ^ 0x77 ^ -" ".length()));
    llllIIIIIII[1] = " ".length();
    llllIIIIIII[2] = "  ".length();
  }
  
  private static boolean lIlllIIlllIlI(int ???, int arg1)
  {
    int i;
    long llllllllllllllllIIlIIIIlIIlIIlll;
    return ??? >= i;
  }
  
  static
  {
    lIlllIIlllIIl();
    lIllIllIlIIIl();
  }
  
  public void breakBlock(World llllllllllllllllIIlIIIIlIlIIIIII, BlockPos llllllllllllllllIIlIIIIlIIllllll, IBlockState llllllllllllllllIIlIIIIlIlIIIIIl)
  {
    ;
    ;
    if (lIlllIIlllIll(isRemote)) {
      BlockBeacon.updateColorAsync(llllllllllllllllIIlIIIIlIlIIIIII, llllllllllllllllIIlIIIIlIlIIIIlI);
    }
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllllIIlIIIIlIlIllIlI)
  {
    ;
    return ((EnumDyeColor)llllllllllllllllIIlIIIIlIlIllIlI.getValue(COLOR)).getMapColor();
  }
  
  public BlockStainedGlass(Material llllllllllllllllIIlIIIIlIlllIlIl)
  {
    llllllllllllllllIIlIIIIlIlllIllI.<init>(llllllllllllllllIIlIIIIlIlllIlIl, llllIIIIIII[0]);
    llllllllllllllllIIlIIIIlIlllIllI.setDefaultState(blockState.getBaseState().withProperty(COLOR, EnumDyeColor.WHITE));
    "".length();
  }
  
  public void getSubBlocks(Item llllllllllllllllIIlIIIIlIllIIlll, CreativeTabs llllllllllllllllIIlIIIIlIllIIllI, List<ItemStack> llllllllllllllllIIlIIIIlIllIIIlI)
  {
    ;
    ;
    ;
    ;
    short llllllllllllllllIIlIIIIlIlIlllll = (llllllllllllllllIIlIIIIlIlIllllI = EnumDyeColor.values()).length;
    byte llllllllllllllllIIlIIIIlIllIIIII = llllIIIIIII[0];
    "".length();
    if (-" ".length() > ((0x97 ^ 0x92) & (0x11 ^ 0x14 ^ 0xFFFFFFFF))) {
      return;
    }
    while (!lIlllIIlllIlI(llllllllllllllllIIlIIIIlIllIIIII, llllllllllllllllIIlIIIIlIlIlllll))
    {
      EnumDyeColor llllllllllllllllIIlIIIIlIllIIlII = llllllllllllllllIIlIIIIlIlIllllI[llllllllllllllllIIlIIIIlIllIIIII];
      new ItemStack(llllllllllllllllIIlIIIIlIllIIlll, llllIIIIIII[1], llllllllllllllllIIlIIIIlIllIIlII.getMetadata());
      "".length();
    }
  }
  
  private static void lIllIllIlIIIl()
  {
    lllIlIlllll = new String[llllIIIIIII[1]];
    lllIlIlllll[llllIIIIIII[0]] = lIllIllIlIIII("0y3VL/Ivcd8=", "sfbEc");
  }
  
  protected boolean canSilkHarvest()
  {
    return llllIIIIIII[1];
  }
  
  public int getMetaFromState(IBlockState llllllllllllllllIIlIIIIlIIlllIll)
  {
    ;
    return ((EnumDyeColor)llllllllllllllllIIlIIIIlIIlllIll.getValue(COLOR)).getMetadata();
  }
  
  public void onBlockAdded(World llllllllllllllllIIlIIIIlIlIIlIll, BlockPos llllllllllllllllIIlIIIIlIlIIIlll, IBlockState llllllllllllllllIIlIIIIlIlIIlIIl)
  {
    ;
    ;
    if (lIlllIIlllIll(isRemote)) {
      BlockBeacon.updateColorAsync(llllllllllllllllIIlIIIIlIlIIlIll, llllllllllllllllIIlIIIIlIlIIlIlI);
    }
  }
}

package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.dispenser.IBlockSource;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockSourceImpl
  implements IBlockSource
{
  public BlockPos getBlockPos()
  {
    ;
    return pos;
  }
  
  public World getWorld()
  {
    ;
    return worldObj;
  }
  
  public double getY()
  {
    ;
    return pos.getY() + 0.5D;
  }
  
  public double getX()
  {
    ;
    return pos.getX() + 0.5D;
  }
  
  public int getBlockMetadata()
  {
    ;
    ;
    IBlockState lllllllllllllllIlIlllIllIlIlIlll = worldObj.getBlockState(pos);
    return lllllllllllllllIlIlllIllIlIlIlll.getBlock().getMetaFromState(lllllllllllllllIlIlllIllIlIlIlll);
  }
  
  public <T extends TileEntity> T getBlockTileEntity()
  {
    ;
    return worldObj.getTileEntity(pos);
  }
  
  public BlockSourceImpl(World lllllllllllllllIlIlllIllIllIlIll, BlockPos lllllllllllllllIlIlllIllIllIlIlI)
  {
    worldObj = lllllllllllllllIlIlllIllIllIlllI;
    pos = lllllllllllllllIlIlllIllIllIlIlI;
  }
  
  public double getZ()
  {
    ;
    return pos.getZ() + 0.5D;
  }
}

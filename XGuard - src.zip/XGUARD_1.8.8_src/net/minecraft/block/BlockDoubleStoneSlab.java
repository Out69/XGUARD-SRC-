package net.minecraft.block;

public class BlockDoubleStoneSlab
  extends BlockStoneSlab
{
  private static void llIlIIIlIIIIll()
  {
    lIIIlIIIllllI = new int[1];
    lIIIlIIIllllI[0] = " ".length();
  }
  
  static {}
  
  public BlockDoubleStoneSlab() {}
  
  public boolean isDouble()
  {
    return lIIIlIIIllllI[0];
  }
}

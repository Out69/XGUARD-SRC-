package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class BlockColored
  extends Block
{
  public MapColor getMapColor(IBlockState llllllllllllllIllIIlllIlIIIllIII)
  {
    ;
    return ((EnumDyeColor)llllllllllllllIllIIlllIlIIIllIII.getValue(COLOR)).getMapColor();
  }
  
  private static boolean lIllllIlIlllIl(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIllIIlllIIlllllIlI;
    return ??? >= i;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIllIIlllIlIIIIlIll, new IProperty[] { COLOR });
  }
  
  static
  {
    lIllllIlIlllII();
    lIllllIlIllIIl();
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIllIIlllIlIIIlIlII)
  {
    ;
    ;
    return llllllllllllllIllIIlllIlIIIlIlIl.getDefaultState().withProperty(COLOR, EnumDyeColor.byMetadata(llllllllllllllIllIIlllIlIIIlIlII));
  }
  
  private static String lIllllIlIllIII(String llllllllllllllIllIIlllIlIIIIIIIl, String llllllllllllllIllIIlllIlIIIIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIlllIlIIIIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIlllIlIIIIIIII.getBytes(StandardCharsets.UTF_8)), lllllIIIIllI[2]), "DES");
      Cipher llllllllllllllIllIIlllIlIIIIIlIl = Cipher.getInstance("DES");
      llllllllllllllIllIIlllIlIIIIIlIl.init(lllllIIIIllI[3], llllllllllllllIllIIlllIlIIIIIllI);
      return new String(llllllllllllllIllIIlllIlIIIIIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIlllIlIIIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIlllIlIIIIIlII)
    {
      llllllllllllllIllIIlllIlIIIIIlII.printStackTrace();
    }
    return null;
  }
  
  public void getSubBlocks(Item llllllllllllllIllIIlllIlIIlIIIIl, CreativeTabs llllllllllllllIllIIlllIlIIlIIlII, List<ItemStack> llllllllllllllIllIIlllIlIIlIIIll)
  {
    ;
    ;
    ;
    ;
    String llllllllllllllIllIIlllIlIIIlllIl = (llllllllllllllIllIIlllIlIIIlllII = EnumDyeColor.values()).length;
    float llllllllllllllIllIIlllIlIIIllllI = lllllIIIIllI[0];
    "".length();
    if (((0x71 ^ 0x47) & (0x6A ^ 0x5C ^ 0xFFFFFFFF)) <= -" ".length()) {
      return;
    }
    while (!lIllllIlIlllIl(llllllllllllllIllIIlllIlIIIllllI, llllllllllllllIllIIlllIlIIIlllIl))
    {
      EnumDyeColor llllllllllllllIllIIlllIlIIlIIIlI = llllllllllllllIllIIlllIlIIIlllII[llllllllllllllIllIIlllIlIIIllllI];
      new ItemStack(llllllllllllllIllIIlllIlIIlIIIIl, lllllIIIIllI[1], llllllllllllllIllIIlllIlIIlIIIlI.getMetadata());
      "".length();
    }
  }
  
  private static void lIllllIlIllIIl()
  {
    lllllIIIIlIl = new String[lllllIIIIllI[1]];
    lllllIIIIlIl[lllllIIIIllI[0]] = lIllllIlIllIII("WZKNJvF5W5o=", "zblbu");
  }
  
  private static void lIllllIlIlllII()
  {
    lllllIIIIllI = new int[4];
    lllllIIIIllI[0] = ((0x8C ^ 0xA2) & (0x49 ^ 0x67 ^ 0xFFFFFFFF));
    lllllIIIIllI[1] = " ".length();
    lllllIIIIllI[2] = (54 + 47 - 53 + 94 ^ 105 + 74 - 48 + 3);
    lllllIIIIllI[3] = "  ".length();
  }
  
  public int damageDropped(IBlockState llllllllllllllIllIIlllIlIIlIllIl)
  {
    ;
    return ((EnumDyeColor)llllllllllllllIllIIlllIlIIlIllIl.getValue(COLOR)).getMetadata();
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIllIIlllIlIIIIllll)
  {
    ;
    return ((EnumDyeColor)llllllllllllllIllIIlllIlIIIIllll.getValue(COLOR)).getMetadata();
  }
  
  public BlockColored(Material llllllllllllllIllIIlllIlIIllIIIl)
  {
    llllllllllllllIllIIlllIlIIllIIlI.<init>(llllllllllllllIllIIlllIlIIllIIIl);
    llllllllllllllIllIIlllIlIIllIIlI.setDefaultState(blockState.getBaseState().withProperty(COLOR, EnumDyeColor.WHITE));
    "".length();
  }
}

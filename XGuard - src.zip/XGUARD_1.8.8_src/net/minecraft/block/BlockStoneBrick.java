package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;

public class BlockStoneBrick
  extends Block
{
  private static String llIIIllIIl(String lIlIIIlIIIllIll, String lIlIIIlIIIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIlIIIlIIIllIll = new String(Base64.getDecoder().decode(lIlIIIlIIIllIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIlIIIlIIIllllI = new StringBuilder();
    char[] lIlIIIlIIIlllIl = lIlIIIlIIIllIlI.toCharArray();
    int lIlIIIlIIIlllII = llllIllI[0];
    double lIlIIIlIIIlIllI = lIlIIIlIIIllIll.toCharArray();
    boolean lIlIIIlIIIlIlIl = lIlIIIlIIIlIllI.length;
    boolean lIlIIIlIIIlIlII = llllIllI[0];
    while (llIIIlllIl(lIlIIIlIIIlIlII, lIlIIIlIIIlIlIl))
    {
      char lIlIIIlIIlIIIIl = lIlIIIlIIIlIllI[lIlIIIlIIIlIlII];
      "".length();
      "".length();
      if ((0x3F ^ 0x41 ^ 0x39 ^ 0x43) == "   ".length()) {
        return null;
      }
    }
    return String.valueOf(lIlIIIlIIIllllI);
  }
  
  private static boolean llIIIlllII(int ???, int arg1)
  {
    int i;
    boolean lIlIIIlIIIIllll;
    return ??? >= i;
  }
  
  public IBlockState getStateFromMeta(int lIlIIIlIIllIlII)
  {
    ;
    ;
    return lIlIIIlIIllIlIl.getDefaultState().withProperty(VARIANT, EnumType.byMetadata(lIlIIIlIIllIlII));
  }
  
  static
  {
    llIIIllIll();
    llIIIllIlI();
    VARIANT = PropertyEnum.create(llllIlIl[llllIllI[0]], EnumType.class);
    DEFAULT_META = EnumType.DEFAULT.getMetadata();
    MOSSY_META = EnumType.MOSSY.getMetadata();
    CRACKED_META = EnumType.CRACKED.getMetadata();
  }
  
  private static void llIIIllIll()
  {
    llllIllI = new int[2];
    llllIllI[0] = ((0x31 ^ 0x77) & (0x6E ^ 0x28 ^ 0xFFFFFFFF));
    llllIllI[1] = " ".length();
  }
  
  public void getSubBlocks(Item lIlIIIlIlIIIIIl, CreativeTabs lIlIIIlIlIIIIII, List<ItemStack> lIlIIIlIIllllll)
  {
    ;
    ;
    ;
    ;
    char lIlIIIlIIlllIIl = (lIlIIIlIIlllIII = EnumType.values()).length;
    String lIlIIIlIIlllIlI = llllIllI[0];
    "".length();
    if ("   ".length() < -" ".length()) {
      return;
    }
    while (!llIIIlllII(lIlIIIlIIlllIlI, lIlIIIlIIlllIIl))
    {
      EnumType lIlIIIlIIlllllI = lIlIIIlIIlllIII[lIlIIIlIIlllIlI];
      new ItemStack(lIlIIIlIlIIIIIl, llllIllI[1], lIlIIIlIIlllllI.getMetadata());
      "".length();
    }
  }
  
  private static void llIIIllIlI()
  {
    llllIlIl = new String[llllIllI[1]];
    llllIlIl[llllIllI[0]] = llIIIllIIl("FzYFJhIPIw==", "aWwOs");
  }
  
  public int getMetaFromState(IBlockState lIlIIIlIIlIllll)
  {
    ;
    return ((EnumType)lIlIIIlIIlIllll.getValue(VARIANT)).getMetadata();
  }
  
  public int damageDropped(IBlockState lIlIIIlIlIIlIlI)
  {
    ;
    return ((EnumType)lIlIIIlIlIIlIlI.getValue(VARIANT)).getMetadata();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lIlIIIlIIlIllII, new IProperty[] { VARIANT });
  }
  
  public BlockStoneBrick()
  {
    lIlIIIlIlIIllIl.<init>(Material.rock);
    lIlIIIlIlIIlllI.setDefaultState(blockState.getBaseState().withProperty(VARIANT, EnumType.DEFAULT));
    "".length();
  }
  
  private static boolean llIIIlllIl(int ???, int arg1)
  {
    int i;
    Exception lIlIIIlIIIIlIll;
    return ??? < i;
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    private static boolean llIlIlIIIIllll(int ???)
    {
      byte llllllllllllllIlIIlllIIIllIIIlII;
      return ??? >= 0;
    }
    
    private EnumType(int llllllllllllllIlIIlllIIlIIIIIIll, String llllllllllllllIlIIlllIIIllllllII, String llllllllllllllIlIIlllIIIlllllIll)
    {
      meta = llllllllllllllIlIIlllIIlIIIIIIll;
      name = llllllllllllllIlIIlllIIIllllllII;
      unlocalizedName = llllllllllllllIlIIlllIIIlllllIll;
    }
    
    static
    {
      llIlIlIIIIllII();
      llIlIlIIIIIlIl();
      long llllllllllllllIlIIlllIIlIIIIlIll;
      String llllllllllllllIlIIlllIIlIIIIlllI;
      DEFAULT = new EnumType(lIIIlIlIlllll[lIIIlIllIIllI[0]], lIIIlIllIIllI[0], lIIIlIllIIllI[0], lIIIlIlIlllll[lIIIlIllIIllI[1]], lIIIlIlIlllll[lIIIlIllIIllI[2]]);
      MOSSY = new EnumType(lIIIlIlIlllll[lIIIlIllIIllI[3]], lIIIlIllIIllI[1], lIIIlIllIIllI[1], lIIIlIlIlllll[lIIIlIllIIllI[4]], lIIIlIlIlllll[lIIIlIllIIllI[5]]);
      CRACKED = new EnumType(lIIIlIlIlllll[lIIIlIllIIllI[6]], lIIIlIllIIllI[2], lIIIlIllIIllI[2], lIIIlIlIlllll[lIIIlIllIIllI[7]], lIIIlIlIlllll[lIIIlIllIIllI[8]]);
      CHISELED = new EnumType(lIIIlIlIlllll[lIIIlIllIIllI[9]], lIIIlIllIIllI[3], lIIIlIllIIllI[3], lIIIlIlIlllll[lIIIlIllIIllI[10]], lIIIlIlIlllll[lIIIlIllIIllI[11]]);
      ENUM$VALUES = new EnumType[] { DEFAULT, MOSSY, CRACKED, CHISELED };
      META_LOOKUP = new EnumType[values().length];
      byte llllllllllllllIlIIlllIIlIIIIllII = (llllllllllllllIlIIlllIIlIIIIlIll = values()).length;
      int llllllllllllllIlIIlllIIlIIIIllIl = lIIIlIllIIllI[0];
      "".length();
      if (((72 + '' - 75 + 25 ^ '' + 39 - 66 + 54) & (0x7E ^ 0x69 ^ 0x1E ^ 0xD ^ -" ".length())) != 0) {
        return;
      }
      while (!llIlIlIIIIllIl(llllllllllllllIlIIlllIIlIIIIllIl, llllllllllllllIlIIlllIIlIIIIllII))
      {
        EnumType llllllllllllllIlIIlllIIlIIIIllll = llllllllllllllIlIIlllIIlIIIIlIll[llllllllllllllIlIIlllIIlIIIIllIl];
        META_LOOKUP[llllllllllllllIlIIlllIIlIIIIllll.getMetadata()] = llllllllllllllIlIIlllIIlIIIIllll;
        llllllllllllllIlIIlllIIlIIIIllIl++;
      }
    }
    
    private static boolean llIlIlIIIIllIl(int ???, int arg1)
    {
      int i;
      long llllllllllllllIlIIlllIIIllIIIllI;
      return ??? >= i;
    }
    
    private static String llIlIlIIIIIIll(String llllllllllllllIlIIlllIIIllIIllll, String llllllllllllllIlIIlllIIIllIIllII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIIlllIIIllIlIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIlllIIIllIIllII.getBytes(StandardCharsets.UTF_8)), lIIIlIllIIllI[8]), "DES");
        Cipher llllllllllllllIlIIlllIIIllIlIIIl = Cipher.getInstance("DES");
        llllllllllllllIlIIlllIIIllIlIIIl.init(lIIIlIllIIllI[2], llllllllllllllIlIIlllIIIllIlIIlI);
        return new String(llllllllllllllIlIIlllIIIllIlIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIlllIIIllIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIIlllIIIllIlIIII)
      {
        llllllllllllllIlIIlllIIIllIlIIII.printStackTrace();
      }
      return null;
    }
    
    public static EnumType byMetadata(int llllllllllllllIlIIlllIIIllllIIll)
    {
      ;
      if ((!llIlIlIIIIllll(llllllllllllllIlIIlllIIIllllIIll)) || (llIlIlIIIIllIl(llllllllllllllIlIIlllIIIllllIIlI, META_LOOKUP.length))) {
        llllllllllllllIlIIlllIIIllllIIlI = lIIIlIllIIllI[0];
      }
      return META_LOOKUP[llllllllllllllIlIIlllIIIllllIIlI];
    }
    
    private static void llIlIlIIIIllII()
    {
      lIIIlIllIIllI = new int[13];
      lIIIlIllIIllI[0] = (('' + 92 - 1 + 28 ^ 48 + 81 - 119 + 149) & (0x8E ^ 0xA6 ^ 0x3 ^ 0x49 ^ -" ".length()));
      lIIIlIllIIllI[1] = " ".length();
      lIIIlIllIIllI[2] = "  ".length();
      lIIIlIllIIllI[3] = "   ".length();
      lIIIlIllIIllI[4] = (0x7A ^ 0x7E);
      lIIIlIllIIllI[5] = (0xB7 ^ 0xB2);
      lIIIlIllIIllI[6] = (0x42 ^ 0x23 ^ 0x72 ^ 0x15);
      lIIIlIllIIllI[7] = (0xA0 ^ 0x81 ^ 0xBB ^ 0x9D);
      lIIIlIllIIllI[8] = (0x90 ^ 0x98);
      lIIIlIllIIllI[9] = (0x90 ^ 0xAA ^ 0x10 ^ 0x23);
      lIIIlIllIIllI[10] = (0x53 ^ 0x59);
      lIIIlIllIIllI[11] = (24 + '·' - 91 + 84 ^ 74 + 111 - 57 + 67);
      lIIIlIllIIllI[12] = ('' + '' - 242 + 126 ^ 102 + '' - 73 + 7);
    }
    
    private static void llIlIlIIIIIlIl()
    {
      lIIIlIlIlllll = new String[lIIIlIllIIllI[12]];
      lIIIlIlIlllll[lIIIlIllIIllI[0]] = llIlIlIIIIIIIl("MintfM6Pbac=", "xqNYm");
      lIIIlIlIlllll[lIIIlIllIIllI[1]] = llIlIlIIIIIIll("qPPgZRELqNry9OlIj8yGnw==", "bkAbT");
      lIIIlIlIlllll[lIIIlIllIIllI[2]] = llIlIlIIIIIIIl("XvmhVmFzGhE=", "sowNi");
      lIIIlIlIlllll[lIIIlIllIIllI[3]] = llIlIlIIIIIIll("e65WpwZNY9g=", "ZPXDN");
      lIIIlIlIlllll[lIIIlIllIIllI[4]] = llIlIlIIIIIIll("avGA2bUEJiDPgXBaSN9F+FHdgLnPYJTa", "yRKbL");
      lIIIlIlIlllll[lIIIlIllIIllI[5]] = llIlIlIIIIIIll("skJyo1hC53o=", "RPwac");
      lIIIlIlIlllll[lIIIlIllIIllI[6]] = llIlIlIIIIIIll("WVEaAue5r/g=", "RxZvE");
      lIIIlIlIlllll[lIIIlIllIIllI[7]] = llIlIlIIIIIIIl("+NgOT2s4uJVueP5upWaPNywtGJQVIkDw", "RxrOH");
      lIIIlIlIlllll[lIIIlIllIIllI[8]] = llIlIlIIIIIIll("Y65k+1H56Hw=", "JjtlU");
      lIIIlIlIlllll[lIIIlIllIIllI[9]] = llIlIlIIIIIIll("H96WdmbdIvv7XfEhoq880A==", "zjBzH");
      lIIIlIlIlllll[lIIIlIllIIllI[10]] = llIlIlIIIIIIll("NIoPkBWpGlBLDDGwadKvP3zllT+Dr/Wz", "ANROE");
      lIIIlIlIlllll[lIIIlIllIIllI[11]] = llIlIlIIIIIIIl("P6c71Yv6fjLK9qeryKtKVw==", "iAVpp");
    }
    
    public String getUnlocalizedName()
    {
      ;
      return unlocalizedName;
    }
    
    private static String llIlIlIIIIIIIl(String llllllllllllllIlIIlllIIIllIlllII, String llllllllllllllIlIIlllIIIllIllIll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIIlllIIIllIlllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIlllIIIllIllIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIlIIlllIIIllIllllI = Cipher.getInstance("Blowfish");
        llllllllllllllIlIIlllIIIllIllllI.init(lIIIlIllIIllI[2], llllllllllllllIlIIlllIIIllIlllll);
        return new String(llllllllllllllIlIIlllIIIllIllllI.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIlllIIIllIlllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIIlllIIIllIlllIl)
      {
        llllllllllllllIlIIlllIIIllIlllIl.printStackTrace();
      }
      return null;
    }
    
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    public String toString()
    {
      ;
      return name;
    }
  }
}

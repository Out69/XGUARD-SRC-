package net.minecraft.block;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockBarrier
  extends Block
{
  public boolean isOpaqueCube()
  {
    return lllIIlIIIlIl[2];
  }
  
  static {}
  
  protected BlockBarrier()
  {
    llllllllllllllIlllIlIlIllIllIlII.<init>(Material.barrier);
    "".length();
    "".length();
    "".length();
    translucent = lllIIlIIIlIl[0];
  }
  
  public void dropBlockAsItemWithChance(World llllllllllllllIlllIlIlIllIlIlllI, BlockPos llllllllllllllIlllIlIlIllIlIllIl, IBlockState llllllllllllllIlllIlIlIllIlIllII, float llllllllllllllIlllIlIlIllIlIlIll, int llllllllllllllIlllIlIlIllIlIlIlI) {}
  
  public int getRenderType()
  {
    return lllIIlIIIlIl[1];
  }
  
  public float getAmbientOcclusionLightValue()
  {
    return 1.0F;
  }
  
  private static void lIlIlllIlIIllI()
  {
    lllIIlIIIlIl = new int[3];
    lllIIlIIIlIl[0] = " ".length();
    lllIIlIIIlIl[1] = (-" ".length());
    lllIIlIIIlIl[2] = ((0x45 ^ 0x65) & (0x33 ^ 0x13 ^ 0xFFFFFFFF));
  }
}

package net.minecraft.block;

public class BlockDoubleWoodSlab
  extends BlockWoodSlab
{
  static {}
  
  public boolean isDouble()
  {
    return lllIIIlIIIII[0];
  }
  
  public BlockDoubleWoodSlab() {}
  
  private static void lIlIllIIlIlIlI()
  {
    lllIIIlIIIII = new int[1];
    lllIIIlIIIII[0] = " ".length();
  }
}

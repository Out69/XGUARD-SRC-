package net.minecraft.block;

public class BlockDoubleStoneSlabNew
  extends BlockStoneSlabNew
{
  public BlockDoubleStoneSlabNew() {}
  
  public boolean isDouble()
  {
    return lIIlIlIlIllII[0];
  }
  
  static {}
  
  private static void lllIIIllllIIll()
  {
    lIIlIlIlIllII = new int[1];
    lIIlIlIlIllII[0] = " ".length();
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockSnow
  extends Block
{
  public boolean shouldSideBeRendered(IBlockAccess llllllllllllllIllIlIlllllllllIll, BlockPos llllllllllllllIllIlIllllllllIllI, EnumFacing llllllllllllllIllIlIllllllllIlIl)
  {
    ;
    ;
    ;
    ;
    if (lIlllIIIIIlllI(llllllllllllllIllIlIllllllllIlIl, EnumFacing.UP))
    {
      "".length();
      if (null == null) {
        break label65;
      }
      return (0x7A ^ 0x32 ^ "   ".length()) & (0x95 ^ 0x83 ^ 0x72 ^ 0x2F ^ -" ".length());
    }
    label65:
    return llllllllllllllIllIlIllllllllllII.shouldSideBeRendered(llllllllllllllIllIlIlllllllllIll, llllllllllllllIllIlIllllllllIllI, llllllllllllllIllIlIllllllllIlIl);
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIllIllIIIIIIIlIIII, Random llllllllllllllIllIllIIIIIIIIllll, int llllllllllllllIllIllIIIIIIIIlllI)
  {
    return Items.snowball;
  }
  
  protected void getBoundsForLayers(int llllllllllllllIllIllIIIIIlIIlIlI)
  {
    ;
    ;
    llllllllllllllIllIllIIIIIlIIllIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, llllllllllllllIllIllIIIIIlIIlIlI / 8.0F, 1.0F);
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIllIlIllllllllIIIl)
  {
    ;
    ;
    return llllllllllllllIllIlIllllllllIIII.getDefaultState().withProperty(LAYERS, Integer.valueOf((llllllllllllllIllIlIllllllllIIIl & llllIIIlllll[4]) + llllIIIlllll[1]));
  }
  
  static
  {
    lIlllIIIIIlIll();
    lIlllIIIIIlIlI();
  }
  
  public void harvestBlock(World llllllllllllllIllIllIIIIIIIllIll, EntityPlayer llllllllllllllIllIllIIIIIIIlIlII, BlockPos llllllllllllllIllIllIIIIIIIllIIl, IBlockState llllllllllllllIllIllIIIIIIIlIIlI, TileEntity llllllllllllllIllIllIIIIIIIlIlll)
  {
    ;
    ;
    ;
    ;
    ;
    spawnAsEntity(llllllllllllllIllIllIIIIIIIllIll, llllllllllllllIllIllIIIIIIIllIIl, new ItemStack(Items.snowball, ((Integer)llllllllllllllIllIllIIIIIIIlIIlI.getValue(LAYERS)).intValue() + llllIIIlllll[1], llllIIIlllll[0]));
    "".length();
    llllllllllllllIllIllIIIIIIIlIlII.triggerAchievement(net.minecraft.stats.StatList.mineBlockStatArray[Block.getIdFromBlock(llllllllllllllIllIllIIIIIIIlIllI)]);
  }
  
  public int quantityDropped(Random llllllllllllllIllIllIIIIIIIIllII)
  {
    return llllIIIlllll[0];
  }
  
  public void updateTick(World llllllllllllllIllIllIIIIIIIIIIlI, BlockPos llllllllllllllIllIllIIIIIIIIIIIl, IBlockState llllllllllllllIllIllIIIIIIIIIlIl, Random llllllllllllllIllIllIIIIIIIIIlII)
  {
    ;
    ;
    ;
    if (lIlllIIIIlIIlI(llllllllllllllIllIllIIIIIIIIIIlI.getLightFor(EnumSkyBlock.BLOCK, llllllllllllllIllIllIIIIIIIIIllI), llllIIIlllll[5]))
    {
      llllllllllllllIllIllIIIIIIIIIIll.dropBlockAsItem(llllllllllllllIllIllIIIIIIIIIIlI, llllllllllllllIllIllIIIIIIIIIllI, llllllllllllllIllIllIIIIIIIIIIlI.getBlockState(llllllllllllllIllIllIIIIIIIIIllI), llllIIIlllll[0]);
      "".length();
    }
  }
  
  public boolean isFullCube()
  {
    return llllIIIlllll[0];
  }
  
  public boolean isPassable(IBlockAccess llllllllllllllIllIllIIIIIlllIIlI, BlockPos llllllllllllllIllIllIIIIIlllIIIl)
  {
    ;
    ;
    if (lIlllIIIIIllII(((Integer)llllllllllllllIllIllIIIIIlllIIlI.getBlockState(llllllllllllllIllIllIIIIIlllIIIl).getValue(LAYERS)).intValue(), llllIIIlllll[3])) {
      return llllIIIlllll[1];
    }
    return llllIIIlllll[0];
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    llllllllllllllIllIllIIIIIlIlllII.getBoundsForLayers(llllIIIlllll[0]);
  }
  
  private static boolean lIlllIIIIlIIll(int ???, int arg1)
  {
    int i;
    char llllllllllllllIllIlIllllllIlIIII;
    return ??? == i;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIllIlIlllllllIIIlI, new IProperty[] { LAYERS });
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIllIllIIIIIlIlIIlI, BlockPos llllllllllllllIllIllIIIIIlIlIlIl)
  {
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllIllIllIIIIIlIlIlII = llllllllllllllIllIllIIIIIlIlIIlI.getBlockState(llllllllllllllIllIllIIIIIlIlIlIl);
    llllllllllllllIllIllIIIIIlIlIlll.getBoundsForLayers(((Integer)llllllllllllllIllIllIIIIIlIlIlII.getValue(LAYERS)).intValue());
  }
  
  private static void lIlllIIIIIlIll()
  {
    llllIIIlllll = new int[7];
    llllIIIlllll[0] = ((0xB3 ^ 0x82 ^ (0x68 ^ 0x6C) & (0x22 ^ 0x26 ^ 0xFFFFFFFF)) & (90 + 52 - 84 + 84 ^ 22 + 10 - -24 + 135 ^ -" ".length()));
    llllIIIlllll[1] = " ".length();
    llllIIIlllll[2] = (0xDB ^ 0xBD ^ 0xAD ^ 0xC3);
    llllIIIlllll[3] = (0xA3 ^ 0xA6);
    llllIIIlllll[4] = (0x19 ^ 0x1E);
    llllIIIlllll[5] = (75 + '' - 164 + 113 ^ 95 + 33 - 7 + 29);
    llllIIIlllll[6] = "  ".length();
  }
  
  public boolean isOpaqueCube()
  {
    return llllIIIlllll[0];
  }
  
  private static boolean lIlllIIIIlIIlI(int ???, int arg1)
  {
    int i;
    long llllllllllllllIllIlIllllllIIIlII;
    return ??? > i;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIllIllIIIIIllIlIlI, BlockPos llllllllllllllIllIllIIIIIllIIlII, IBlockState llllllllllllllIllIllIIIIIllIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIllIllIIIIIllIIlll = ((Integer)llllllllllllllIllIllIIIIIllIlIII.getValue(LAYERS)).intValue() - llllIIIlllll[1];
    float llllllllllllllIllIllIIIIIllIIllI = 0.125F;
    return new AxisAlignedBB(llllllllllllllIllIllIIIIIllIlIIl.getX() + minX, llllllllllllllIllIllIIIIIllIlIIl.getY() + minY, llllllllllllllIllIllIIIIIllIlIIl.getZ() + minZ, llllllllllllllIllIllIIIIIllIlIIl.getX() + maxX, llllllllllllllIllIllIIIIIllIlIIl.getY() + llllllllllllllIllIllIIIIIllIIlll * llllllllllllllIllIllIIIIIllIIllI, llllllllllllllIllIllIIIIIllIlIIl.getZ() + maxZ);
  }
  
  public boolean isReplaceable(World llllllllllllllIllIlIlllllllIlIIl, BlockPos llllllllllllllIllIlIlllllllIlIII)
  {
    ;
    ;
    if (lIlllIIIIlIIll(((Integer)llllllllllllllIllIlIlllllllIlIIl.getBlockState(llllllllllllllIllIlIlllllllIlIII).getValue(LAYERS)).intValue(), llllIIIlllll[1])) {
      return llllIIIlllll[1];
    }
    return llllIIIlllll[0];
  }
  
  private boolean checkAndDropBlock(World llllllllllllllIllIllIIIIIIlIlIII, BlockPos llllllllllllllIllIllIIIIIIlIIIll, IBlockState llllllllllllllIllIllIIIIIIlIIIlI)
  {
    ;
    ;
    ;
    ;
    if (lIlllIIIIlIIIl(llllllllllllllIllIllIIIIIIlIlIIl.canPlaceBlockAt(llllllllllllllIllIllIIIIIIlIlIII, llllllllllllllIllIllIIIIIIlIIIll)))
    {
      llllllllllllllIllIllIIIIIIlIlIIl.dropBlockAsItem(llllllllllllllIllIllIIIIIIlIlIII, llllllllllllllIllIllIIIIIIlIIIll, llllllllllllllIllIllIIIIIIlIIIlI, llllIIIlllll[0]);
      "".length();
      return llllIIIlllll[0];
    }
    return llllIIIlllll[1];
  }
  
  private static String lIlllIIIIIlIIl(String llllllllllllllIllIlIllllllIllIIl, String llllllllllllllIllIlIllllllIlIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIlIllllllIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIllllllIlIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIlIllllllIllIll = Cipher.getInstance("Blowfish");
      llllllllllllllIllIlIllllllIllIll.init(llllIIIlllll[6], llllllllllllllIllIlIllllllIlllII);
      return new String(llllllllllllllIllIlIllllllIllIll.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIllllllIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIlIllllllIllIlI)
    {
      llllllllllllllIllIlIllllllIllIlI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlllIIIIIllII(int ???, int arg1)
  {
    int i;
    char llllllllllllllIllIlIllllllIIlIII;
    return ??? < i;
  }
  
  private static boolean lIlllIIIIlIIII(int ???)
  {
    Exception llllllllllllllIllIlIlllllIlllIlI;
    return ??? != 0;
  }
  
  private static void lIlllIIIIIlIlI()
  {
    llllIIIlllIl = new String[llllIIIlllll[1]];
    llllIIIlllIl[llllIIIlllll[0]] = lIlllIIIIIlIIl("cikpWtK/Vro=", "UmAFo");
  }
  
  private static boolean lIlllIIIIIllll(int ???, int arg1)
  {
    int i;
    String llllllllllllllIllIlIllllllIIllII;
    return ??? >= i;
  }
  
  private static boolean lIlllIIIIIlllI(Object ???, Object arg1)
  {
    Object localObject;
    float llllllllllllllIllIlIlllllIllllII;
    return ??? == localObject;
  }
  
  public void onNeighborBlockChange(World llllllllllllllIllIllIIIIIIllIIII, BlockPos llllllllllllllIllIllIIIIIIllIlII, IBlockState llllllllllllllIllIllIIIIIIllIIll, Block llllllllllllllIllIllIIIIIIllIIlI)
  {
    ;
    ;
    ;
    ;
    "".length();
  }
  
  private static boolean lIlllIIIIIllIl(Object ???, Object arg1)
  {
    Object localObject;
    float llllllllllllllIllIlIllllllIIIIII;
    return ??? != localObject;
  }
  
  private static boolean lIlllIIIIlIIIl(int ???)
  {
    char llllllllllllllIllIlIlllllIlllIII;
    return ??? == 0;
  }
  
  public boolean canPlaceBlockAt(World llllllllllllllIllIllIIIIIIlllllI, BlockPos llllllllllllllIllIllIIIIIIllllIl)
  {
    ;
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllIllIllIIIIIlIIIIIl = llllllllllllllIllIllIIIIIIlllllI.getBlockState(llllllllllllllIllIllIIIIIIllllIl.down());
    Block llllllllllllllIllIllIIIIIlIIIIII = llllllllllllllIllIllIIIIIlIIIIIl.getBlock();
    if ((lIlllIIIIIllIl(llllllllllllllIllIllIIIIIlIIIIII, Blocks.ice)) && (lIlllIIIIIllIl(llllllllllllllIllIllIIIIIlIIIIII, Blocks.packed_ice)))
    {
      if (lIlllIIIIIlllI(llllllllllllllIllIllIIIIIlIIIIII.getMaterial(), Material.leaves))
      {
        "".length();
        if ("  ".length() <= "  ".length()) {
          break label369;
        }
        return (110 + '' - 249 + 212 ^ '¤' + 25 - 138 + 121) & ('ì' + 'ä' - 419 + 199 ^ 96 + 81 - 78 + 89 ^ -" ".length());
      }
      if ((lIlllIIIIIlllI(llllllllllllllIllIllIIIIIlIIIIII, llllllllllllllIllIllIIIIIlIIIlII)) && (lIlllIIIIIllll(((Integer)llllllllllllllIllIllIIIIIlIIIIIl.getValue(LAYERS)).intValue(), llllIIIlllll[4])))
      {
        "".length();
        if (-" ".length() < 0) {
          break label369;
        }
        return (0xC1 ^ 0x8C ^ 0x5C ^ 0x4E) & (0xDB ^ 0x80 ^ 0x73 ^ 0x77 ^ -" ".length());
      }
      if ((lIlllIIIIlIIII(llllllllllllllIllIllIIIIIlIIIIII.isOpaqueCube())) && (lIlllIIIIlIIII(blockMaterial.blocksMovement())))
      {
        "".length();
        if ((0x89 ^ 0x91 ^ 0x57 ^ 0x4B) >= 0) {
          break label369;
        }
        return (0x61 ^ 0x67 ^ 0x41 ^ 0x67) & (67 + 2 - -4 + 80 ^ '·' + 3 - 71 + 70 ^ -" ".length());
      }
      "".length();
      if ((0xC3 ^ 0xC7) > 0) {
        break label369;
      }
      return (0x46 ^ 0x71) & (0xA7 ^ 0x90 ^ 0xFFFFFFFF);
    }
    label369:
    return llllIIIlllll[0];
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIllIlIlllllllIIlIl)
  {
    ;
    return ((Integer)llllllllllllllIllIlIlllllllIIlIl.getValue(LAYERS)).intValue() - llllIIIlllll[1];
  }
  
  protected BlockSnow()
  {
    llllllllllllllIllIllIIIIIllllIIl.<init>(Material.snow);
    llllllllllllllIllIllIIIIIllllIII.setDefaultState(blockState.getBaseState().withProperty(LAYERS, Integer.valueOf(llllIIIlllll[1])));
    llllllllllllllIllIllIIIIIllllIII.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
    "".length();
    "".length();
    llllllllllllllIllIllIIIIIllllIII.setBlockBoundsForItemRender();
  }
}

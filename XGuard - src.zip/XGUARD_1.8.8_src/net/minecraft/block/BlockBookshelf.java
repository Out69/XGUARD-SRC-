package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;

public class BlockBookshelf
  extends Block
{
  public int quantityDropped(Random llllllllllllllllIIIIIIIIlllllIII)
  {
    return lIIIIIlIIIII[0];
  }
  
  static {}
  
  public Item getItemDropped(IBlockState llllllllllllllllIIIIIIIIllllIllI, Random llllllllllllllllIIIIIIIIllllIlIl, int llllllllllllllllIIIIIIIIllllIlII)
  {
    return Items.book;
  }
  
  public BlockBookshelf()
  {
    llllllllllllllllIIIIIIIIlllllIlI.<init>(Material.wood);
    "".length();
  }
  
  private static void llIIlIIlIllIl()
  {
    lIIIIIlIIIII = new int[1];
    lIIIIIlIIIII[0] = "   ".length();
  }
}

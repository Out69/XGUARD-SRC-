package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.command.server.CommandBlockLogic;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityCommandBlock;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;

public class BlockCommandBlock
  extends BlockContainer
{
  public TileEntity createNewTileEntity(World lIIlIIlIIllllI, int lIIlIIlIIlllIl)
  {
    return new TileEntityCommandBlock();
  }
  
  private static boolean llIIIlIIIll(int ???)
  {
    int lIIIlllllllllI;
    return ??? > 0;
  }
  
  private static boolean llIIIlIIIIl(int ???)
  {
    float lIIlIIIIIIIIlI;
    return ??? != 0;
  }
  
  public IBlockState onBlockPlaced(World lIIlIIIIllIlIl, BlockPos lIIlIIIIllIlII, EnumFacing lIIlIIIIllIIll, float lIIlIIIIllIIlI, float lIIlIIIIllIIIl, float lIIlIIIIllIIII, int lIIlIIIIlIllll, EntityLivingBase lIIlIIIIlIlllI)
  {
    ;
    return lIIlIIIIllIllI.getDefaultState().withProperty(TRIGGERED, Boolean.valueOf(llllIIlII[0]));
  }
  
  public void onBlockPlacedBy(World lIIlIIIlIIllll, BlockPos lIIlIIIlIlIlIl, IBlockState lIIlIIIlIlIlII, EntityLivingBase lIIlIIIlIlIIll, ItemStack lIIlIIIlIlIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    TileEntity lIIlIIIlIlIIIl = lIIlIIIlIIllll.getTileEntity(lIIlIIIlIlIlIl);
    if (llIIIlIIIIl(lIIlIIIlIlIIIl instanceof TileEntityCommandBlock))
    {
      CommandBlockLogic lIIlIIIlIlIIII = ((TileEntityCommandBlock)lIIlIIIlIlIIIl).getCommandBlockLogic();
      if (llIIIlIIIIl(lIIlIIIlIlIIlI.hasDisplayName())) {
        lIIlIIIlIlIIII.setName(lIIlIIIlIlIIlI.getDisplayName());
      }
      if (llIIIlIIIII(isRemote)) {
        lIIlIIIlIlIIII.setTrackOutput(lIIlIIIlIIllll.getGameRules().getBoolean(llllIIIll[llllIIlII[1]]));
      }
    }
  }
  
  private static void llIIIIlllll()
  {
    llllIIlII = new int[6];
    llllIIlII[0] = ((122 + 2 - 100 + 231 ^ 39 + '' - 38 + 3) & (0xB4 ^ 0xB3 ^ 0x24 ^ 0x7E ^ -" ".length()));
    llllIIlII[1] = " ".length();
    llllIIlII[2] = (0x19 ^ 0x32 ^ 0x31 ^ 0x1E);
    llllIIlII[3] = "   ".length();
    llllIIlII[4] = "  ".length();
    llllIIlII[5] = (0xB7 ^ 0xBF);
  }
  
  public void updateTick(World lIIlIIlIIIIlII, BlockPos lIIlIIlIIIIIll, IBlockState lIIlIIlIIIIIlI, Random lIIlIIlIIIIIIl)
  {
    ;
    ;
    ;
    ;
    TileEntity lIIlIIlIIIIIII = lIIlIIlIIIIlII.getTileEntity(lIIlIIIlllllIl);
    if (llIIIlIIIIl(lIIlIIlIIIIIII instanceof TileEntityCommandBlock))
    {
      ((TileEntityCommandBlock)lIIlIIlIIIIIII).getCommandBlockLogic().trigger(lIIlIIlIIIIlII);
      lIIlIIlIIIIlII.updateComparatorOutputLevel(lIIlIIIlllllIl, lIIlIIlIIIIlIl);
    }
  }
  
  public IBlockState getStateFromMeta(int lIIlIIIlIIIIlI)
  {
    ;
    ;
    if (llIIIlIIIll(lIIlIIIlIIIIlI & llllIIlII[1]))
    {
      "".length();
      if (" ".length() > ((0x8 ^ 0x38) & (0x7B ^ 0x4B ^ 0xFFFFFFFF))) {
        break label59;
      }
      return null;
    }
    label59:
    return TRIGGERED.withProperty(llllIIlII[1], Boolean.valueOf(llllIIlII[0]));
  }
  
  public BlockCommandBlock()
  {
    lIIlIIlIlIIIIl.<init>(Material.iron, MapColor.adobeColor);
    lIIlIIlIlIIIII.setDefaultState(blockState.getBaseState().withProperty(TRIGGERED, Boolean.valueOf(llllIIlII[0])));
  }
  
  private static String llIIIIlIlII(String lIIlIIIIlIIlIl, String lIIlIIIIlIIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIlIIIIlIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIIlIIIIlIIlII.getBytes(StandardCharsets.UTF_8)), llllIIlII[5]), "DES");
      Cipher lIIlIIIIlIIlll = Cipher.getInstance("DES");
      lIIlIIIIlIIlll.init(llllIIlII[4], lIIlIIIIlIlIII);
      return new String(lIIlIIIIlIIlll.doFinal(Base64.getDecoder().decode(lIIlIIIIlIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIlIIIIlIIllI)
    {
      lIIlIIIIlIIllI.printStackTrace();
    }
    return null;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lIIlIIIIlllIII, new IProperty[] { TRIGGERED });
  }
  
  public int tickRate(World lIIlIIIllllIlI)
  {
    return llllIIlII[1];
  }
  
  private static String llIIIIlIlIl(String lIIlIIIIIlIIII, String lIIlIIIIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIIlIIIIIlIIII = new String(Base64.getDecoder().decode(lIIlIIIIIlIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIIlIIIIIlIIll = new StringBuilder();
    char[] lIIlIIIIIlIIlI = lIIlIIIIIIllll.toCharArray();
    int lIIlIIIIIlIIIl = llllIIlII[0];
    int lIIlIIIIIIlIll = lIIlIIIIIlIIII.toCharArray();
    long lIIlIIIIIIlIlI = lIIlIIIIIIlIll.length;
    int lIIlIIIIIIlIIl = llllIIlII[0];
    while (llIIIlIIlIl(lIIlIIIIIIlIIl, lIIlIIIIIIlIlI))
    {
      char lIIlIIIIIlIllI = lIIlIIIIIIlIll[lIIlIIIIIIlIIl];
      "".length();
      "".length();
      if (((0x43 ^ 0x64 ^ 0x7E ^ 0x6A) & (0xBA ^ 0xBF ^ 0x56 ^ 0x60 ^ -" ".length())) < 0) {
        return null;
      }
    }
    return String.valueOf(lIIlIIIIIlIIll);
  }
  
  static
  {
    llIIIIlllll();
    llIIIIlIllI();
  }
  
  private static void llIIIIlIllI()
  {
    llllIIIll = new String[llllIIlII[4]];
    llllIIIll[llllIIlII[0]] = llIIIIlIlII("Qn8ZiP5iLwndTSnJkhTVhw==", "kgVfs");
    llllIIIll[llllIIlII[1]] = llIIIIlIlIl("MQ02KRstBTUsNiYuPSg8IAk7Jg==", "BhXMX");
  }
  
  public void onNeighborBlockChange(World lIIlIIlIIIlllI, BlockPos lIIlIIlIIlIlII, IBlockState lIIlIIlIIIllII, Block lIIlIIlIIlIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIIlIIIII(isRemote))
    {
      boolean lIIlIIlIIlIIIl = lIIlIIlIIIlllI.isBlockPowered(lIIlIIlIIIllIl);
      boolean lIIlIIlIIlIIII = ((Boolean)lIIlIIlIIIllII.getValue(TRIGGERED)).booleanValue();
      if ((llIIIlIIIIl(lIIlIIlIIlIIIl)) && (llIIIlIIIII(lIIlIIlIIlIIII)))
      {
        "".length();
        lIIlIIlIIIlllI.scheduleUpdate(lIIlIIlIIIllIl, lIIlIIlIIlIllI, lIIlIIlIIlIllI.tickRate(lIIlIIlIIIlllI));
        "".length();
        if (-" ".length() <= 0) {}
      }
      else if ((llIIIlIIIII(lIIlIIlIIlIIIl)) && (llIIIlIIIIl(lIIlIIlIIlIIII)))
      {
        "".length();
      }
    }
  }
  
  public boolean onBlockActivated(World lIIlIIIlllIlII, BlockPos lIIlIIIlllIIll, IBlockState lIIlIIIlllIIlI, EntityPlayer lIIlIIIlllIIIl, EnumFacing lIIlIIIlllIIII, float lIIlIIIllIllll, float lIIlIIIllIlllI, float lIIlIIIllIllIl)
  {
    ;
    ;
    ;
    ;
    TileEntity lIIlIIIllIllII = lIIlIIIlllIlII.getTileEntity(lIIlIIIlllIIll);
    if (llIIIlIIIIl(lIIlIIIllIllII instanceof TileEntityCommandBlock))
    {
      "".length();
      if (('ª' + 14 - 9 + 15 ^ 22 + '' - 75 + 92) != 0) {
        break label119;
      }
      return (0xD7 ^ 0x9D ^ 0x58 ^ 0x45) & ('¸' + '' - 267 + 176 ^ 65 + 69 - 35 + 65 ^ -" ".length());
    }
    label119:
    return llllIIlII[0];
  }
  
  private static boolean llIIIlIIlIl(int ???, int arg1)
  {
    int i;
    long lIIlIIIIIIIlII;
    return ??? < i;
  }
  
  private static boolean llIIIlIIIII(int ???)
  {
    int lIIlIIIIIIIIII;
    return ??? == 0;
  }
  
  public boolean hasComparatorInputOverride()
  {
    return llllIIlII[1];
  }
  
  public int quantityDropped(Random lIIlIIIlIIlIIl)
  {
    return llllIIlII[0];
  }
  
  public int getComparatorInputOverride(World lIIlIIIlIlllll, BlockPos lIIlIIIlIllllI)
  {
    ;
    ;
    ;
    TileEntity lIIlIIIllIIIII = lIIlIIIlIlllll.getTileEntity(lIIlIIIlIllllI);
    if (llIIIlIIIIl(lIIlIIIllIIIII instanceof TileEntityCommandBlock))
    {
      "".length();
      if (-" ".length() < 0) {
        break label94;
      }
      return ('Ö' + 86 - 197 + 138 ^ 78 + 81 - 136 + 149) & (0x55 ^ 0x21 ^ 0x1B ^ 0x32 ^ -" ".length());
    }
    label94:
    return llllIIlII[0];
  }
  
  public int getMetaFromState(IBlockState lIIlIIIIlllllI)
  {
    ;
    ;
    int lIIlIIIIllllIl = llllIIlII[0];
    if (llIIIlIIIIl(((Boolean)lIIlIIIIllllII.getValue(TRIGGERED)).booleanValue())) {
      lIIlIIIIllllIl |= llllIIlII[1];
    }
    return lIIlIIIIllllIl;
  }
  
  public int getRenderType()
  {
    return llllIIlII[3];
  }
}

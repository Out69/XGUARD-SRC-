package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockDragonEgg
  extends Block
{
  public boolean isOpaqueCube()
  {
    return lIllllllIIII[3];
  }
  
  private static boolean lIIlIIIllllIII(int ???)
  {
    String lllllllllllllllIIlIIlIIlIIlIIllI;
    return ??? > 0;
  }
  
  public void onBlockAdded(World lllllllllllllllIIlIIlIIllIllIIII, BlockPos lllllllllllllllIIlIIlIIllIlIlIll, IBlockState lllllllllllllllIIlIIlIIllIlIlllI)
  {
    ;
    ;
    ;
    lllllllllllllllIIlIIlIIllIllIIII.scheduleUpdate(lllllllllllllllIIlIIlIIllIlIlIll, lllllllllllllllIIlIIlIIllIlIllIl, lllllllllllllllIIlIIlIIllIlIllIl.tickRate(lllllllllllllllIIlIIlIIllIllIIII));
  }
  
  public boolean onBlockActivated(World lllllllllllllllIIlIIlIIllIIIIIIl, BlockPos lllllllllllllllIIlIIlIIlIlllIlll, IBlockState lllllllllllllllIIlIIlIIlIlllllll, EntityPlayer lllllllllllllllIIlIIlIIlIllllllI, EnumFacing lllllllllllllllIIlIIlIIlIlllllIl, float lllllllllllllllIIlIIlIIlIlllllII, float lllllllllllllllIIlIIlIIlIllllIll, float lllllllllllllllIIlIIlIIlIllllIlI)
  {
    ;
    ;
    ;
    lllllllllllllllIIlIIlIIllIIIIIlI.teleport(lllllllllllllllIIlIIlIIllIIIIIIl, lllllllllllllllIIlIIlIIlIlllIlll);
    return lIllllllIIII[2];
  }
  
  public void onBlockClicked(World lllllllllllllllIIlIIlIIlIllIlllI, BlockPos lllllllllllllllIIlIIlIIlIllIllIl, EntityPlayer lllllllllllllllIIlIIlIIlIlllIIII)
  {
    ;
    ;
    ;
    lllllllllllllllIIlIIlIIlIllIllll.teleport(lllllllllllllllIIlIIlIIlIllIlllI, lllllllllllllllIIlIIlIIlIllIllIl);
  }
  
  public BlockDragonEgg()
  {
    lllllllllllllllIIlIIlIIllIllIlIl.<init>(Material.dragonEgg, MapColor.blackColor);
    lllllllllllllllIIlIIlIIllIllIllI.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 1.0F, 0.9375F);
  }
  
  public void onNeighborBlockChange(World lllllllllllllllIIlIIlIIllIlIIllI, BlockPos lllllllllllllllIIlIIlIIllIlIIIII, IBlockState lllllllllllllllIIlIIlIIllIlIIlII, Block lllllllllllllllIIlIIlIIllIlIIIll)
  {
    ;
    ;
    ;
    lllllllllllllllIIlIIlIIllIlIIllI.scheduleUpdate(lllllllllllllllIIlIIlIIllIlIIlIl, lllllllllllllllIIlIIlIIllIlIIIlI, lllllllllllllllIIlIIlIIllIlIIIlI.tickRate(lllllllllllllllIIlIIlIIllIlIIllI));
  }
  
  private static boolean lIIlIIIlllIlIl(int ???)
  {
    short lllllllllllllllIIlIIlIIlIIlIlIlI;
    return ??? >= 0;
  }
  
  public boolean isFullCube()
  {
    return lIllllllIIII[3];
  }
  
  public void updateTick(World lllllllllllllllIIlIIlIIllIIllIll, BlockPos lllllllllllllllIIlIIlIIllIIllIlI, IBlockState lllllllllllllllIIlIIlIIllIIllIIl, Random lllllllllllllllIIlIIlIIllIIllIII)
  {
    ;
    ;
    ;
    lllllllllllllllIIlIIlIIllIIlllII.checkFall(lllllllllllllllIIlIIlIIllIIllIll, lllllllllllllllIIlIIlIIllIIlIlIl);
  }
  
  private void teleport(World lllllllllllllllIIlIIlIIlIlIIllll, BlockPos lllllllllllllllIIlIIlIIlIlIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState lllllllllllllllIIlIIlIIlIlIllIll = lllllllllllllllIIlIIlIIlIlIIllll.getBlockState(lllllllllllllllIIlIIlIIlIlIlllII);
    if (lIIlIIIllllIIl(lllllllllllllllIIlIIlIIlIlIllIll.getBlock(), lllllllllllllllIIlIIlIIlIlIlIIII))
    {
      int lllllllllllllllIIlIIlIIlIlIllIlI = lIllllllIIII[3];
      "".length();
      if (((0x22 ^ 0x3C) & (0x17 ^ 0x9 ^ 0xFFFFFFFF)) > (0x4B ^ 0x4F)) {
        return;
      }
      while (!lIIlIIIllllIlI(lllllllllllllllIIlIIlIIlIlIllIlI, lIllllllIIII[7]))
      {
        BlockPos lllllllllllllllIIlIIlIIlIlIllIIl = lllllllllllllllIIlIIlIIlIlIlllII.add(rand.nextInt(lIllllllIIII[4]) - rand.nextInt(lIllllllIIII[4]), rand.nextInt(lIllllllIIII[5]) - rand.nextInt(lIllllllIIII[5]), rand.nextInt(lIllllllIIII[4]) - rand.nextInt(lIllllllIIII[4]));
        if (lIIlIIIllllIIl(getBlockStategetBlockblockMaterial, Material.air))
        {
          if (lIIlIIIlllIlII(isRemote))
          {
            int lllllllllllllllIIlIIlIIlIlIllIII = lIllllllIIII[3];
            "".length();
            if ((0xE0 ^ 0xAF ^ 0x44 ^ 0xF) != (0x7 ^ 0x2F ^ 0x26 ^ 0xA)) {
              return;
            }
            while (!lIIlIIIllllIlI(lllllllllllllllIIlIIlIIlIlIllIII, lIllllllIIII[6]))
            {
              double lllllllllllllllIIlIIlIIlIlIlIlll = rand.nextDouble();
              float lllllllllllllllIIlIIlIIlIlIlIllI = (rand.nextFloat() - 0.5F) * 0.2F;
              float lllllllllllllllIIlIIlIIlIlIlIlIl = (rand.nextFloat() - 0.5F) * 0.2F;
              float lllllllllllllllIIlIIlIIlIlIlIlII = (rand.nextFloat() - 0.5F) * 0.2F;
              double lllllllllllllllIIlIIlIIlIlIlIIll = lllllllllllllllIIlIIlIIlIlIllIIl.getX() + (lllllllllllllllIIlIIlIIlIlIlllII.getX() - lllllllllllllllIIlIIlIIlIlIllIIl.getX()) * lllllllllllllllIIlIIlIIlIlIlIlll + (rand.nextDouble() - 0.5D) * 1.0D + 0.5D;
              double lllllllllllllllIIlIIlIIlIlIlIIlI = lllllllllllllllIIlIIlIIlIlIllIIl.getY() + (lllllllllllllllIIlIIlIIlIlIlllII.getY() - lllllllllllllllIIlIIlIIlIlIllIIl.getY()) * lllllllllllllllIIlIIlIIlIlIlIlll + rand.nextDouble() * 1.0D - 0.5D;
              double lllllllllllllllIIlIIlIIlIlIlIIIl = lllllllllllllllIIlIIlIIlIlIllIIl.getZ() + (lllllllllllllllIIlIIlIIlIlIlllII.getZ() - lllllllllllllllIIlIIlIIlIlIllIIl.getZ()) * lllllllllllllllIIlIIlIIlIlIlIlll + (rand.nextDouble() - 0.5D) * 1.0D + 0.5D;
              lllllllllllllllIIlIIlIIlIlIlllIl.spawnParticle(EnumParticleTypes.PORTAL, lllllllllllllllIIlIIlIIlIlIlIIll, lllllllllllllllIIlIIlIIlIlIlIIlI, lllllllllllllllIIlIIlIIlIlIlIIIl, lllllllllllllllIIlIIlIIlIlIlIllI, lllllllllllllllIIlIIlIIlIlIlIlIl, lllllllllllllllIIlIIlIIlIlIlIlII, new int[lIllllllIIII[3]]);
              lllllllllllllllIIlIIlIIlIlIllIII++;
            }
            "".length();
            if (((0x55 ^ 0x4A ^ 0x31 ^ 0x79) & (69 + '¤' - 124 + 95 ^ 20 + 8 - -78 + 49 ^ -" ".length())) == 0) {}
          }
          else
          {
            "".length();
            "".length();
          }
          return;
        }
        lllllllllllllllIIlIIlIIlIlIllIlI++;
      }
    }
  }
  
  private static boolean lIIlIIIlllIlII(int ???)
  {
    String lllllllllllllllIIlIIlIIlIIlIlllI;
    return ??? != 0;
  }
  
  private static boolean lIIlIIIlllIllI(int ???)
  {
    long lllllllllllllllIIlIIlIIlIIlIllII;
    return ??? == 0;
  }
  
  static {}
  
  public int tickRate(World lllllllllllllllIIlIIlIIlIlIIIIIl)
  {
    return lIllllllIIII[8];
  }
  
  private static boolean lIIlIIIllllIIl(Object ???, Object arg1)
  {
    Object localObject;
    double lllllllllllllllIIlIIlIIlIIllIIII;
    return ??? == localObject;
  }
  
  private void checkFall(World lllllllllllllllIIlIIlIIllIIIlIIl, BlockPos lllllllllllllllIIlIIlIIllIIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    if ((lIIlIIIlllIlII(BlockFalling.canFallInto(lllllllllllllllIIlIIlIIllIIIlIIl, lllllllllllllllIIlIIlIIllIIIllIl.down()))) && (lIIlIIIlllIlIl(lllllllllllllllIIlIIlIIllIIIllIl.getY())))
    {
      int lllllllllllllllIIlIIlIIllIIIllII = lIllllllIIII[0];
      if ((lIIlIIIlllIllI(BlockFalling.fallInstantly)) && (lIIlIIIlllIlII(lllllllllllllllIIlIIlIIllIIIlllI.isAreaLoaded(lllllllllllllllIIlIIlIIllIIIllIl.add(-lllllllllllllllIIlIIlIIllIIIllII, -lllllllllllllllIIlIIlIIllIIIllII, -lllllllllllllllIIlIIlIIllIIIllII), lllllllllllllllIIlIIlIIllIIIllIl.add(lllllllllllllllIIlIIlIIllIIIllII, lllllllllllllllIIlIIlIIllIIIllII, lllllllllllllllIIlIIlIIllIIIllII)))))
      {
        new EntityFallingBlock(lllllllllllllllIIlIIlIIllIIIlllI, lllllllllllllllIIlIIlIIllIIIllIl.getX() + 0.5F, lllllllllllllllIIlIIlIIllIIIllIl.getY(), lllllllllllllllIIlIIlIIllIIIllIl.getZ() + 0.5F, lllllllllllllllIIlIIlIIllIIIllll.getDefaultState());
        "".length();
        "".length();
        if (-" ".length() < ((0x9E ^ 0xC2) & (0x5E ^ 0x2 ^ 0xFFFFFFFF))) {}
      }
      else
      {
        "".length();
        BlockPos lllllllllllllllIIlIIlIIllIIIlIll = lllllllllllllllIIlIIlIIllIIIllIl;
        "".length();
        if (((59 + 80 - 123 + 157 ^ 66 + 123 - 150 + 150) & (0x53 ^ 0x7B ^ 0xB1 ^ 0x89 ^ -" ".length())) >= (0x2C ^ 0xF ^ 0x68 ^ 0x4F)) {
          return;
        }
        while ((lIIlIIIlllIlII(BlockFalling.canFallInto(lllllllllllllllIIlIIlIIllIIIlllI, lllllllllllllllIIlIIlIIllIIIlIll))) && (!lIIlIIIlllIlll(lllllllllllllllIIlIIlIIllIIIlIll.getY()))) {
          lllllllllllllllIIlIIlIIllIIIlIll = lllllllllllllllIIlIIlIIllIIIlIll.down();
        }
        if (lIIlIIIllllIII(lllllllllllllllIIlIIlIIllIIIlIll.getY())) {
          "".length();
        }
      }
    }
  }
  
  private static boolean lIIlIIIlllIlll(int ???)
  {
    byte lllllllllllllllIIlIIlIIlIIlIlIII;
    return ??? <= 0;
  }
  
  private static boolean lIIlIIIllllIlI(int ???, int arg1)
  {
    int i;
    int lllllllllllllllIIlIIlIIlIIllIlII;
    return ??? >= i;
  }
  
  private static void lIIlIIIlllIIll()
  {
    lIllllllIIII = new int[9];
    lIllllllIIII[0] = (0x1E ^ 0x3E);
    lIllllllIIII[1] = "  ".length();
    lIllllllIIII[2] = " ".length();
    lIllllllIIII[3] = ((0xA0 ^ 0xBD ^ 0x92 ^ 0xAD) & (0xA6 ^ 0x8E ^ 0x4E ^ 0x44 ^ -" ".length()));
    lIllllllIIII[4] = (0x83 ^ 0x93);
    lIllllllIIII[5] = (0x7D ^ 0x75);
    lIllllllIIII[6] = (95 + 60 - 86 + 59);
    lIllllllIIII[7] = (-(0xFCC7 & 0x2F3B) & 0xBFEF & 0x6FFA);
    lIllllllIIII[8] = (0x94 ^ 0x98 ^ 0xAE ^ 0xA7);
  }
  
  public Item getItem(World lllllllllllllllIIlIIlIIlIIlllIIl, BlockPos lllllllllllllllIIlIIlIIlIIlllIII)
  {
    return null;
  }
  
  public boolean shouldSideBeRendered(IBlockAccess lllllllllllllllIIlIIlIIlIIllllIl, BlockPos lllllllllllllllIIlIIlIIlIIllllII, EnumFacing lllllllllllllllIIlIIlIIlIIlllIll)
  {
    return lIllllllIIII[2];
  }
}

package net.minecraft.block;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class BlockOldLog
  extends BlockLog
{
  public BlockOldLog()
  {
    llllllllllllllllIIlIIIIIIIIIllII.setDefaultState(blockState.getBaseState().withProperty(VARIANT, BlockPlanks.EnumType.OAK).withProperty(LOG_AXIS, BlockLog.EnumAxis.Y));
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllllIIIllllllllllIII)
  {
    ;
    ;
    ;
    IBlockState llllllllllllllllIIIlllllllllIlll = llllllllllllllllIIIllllllllllIIl.getDefaultState().withProperty(VARIANT, BlockPlanks.EnumType.byMetadata((llllllllllllllllIIIllllllllllIII & llllIIIlIll[2]) % llllIIIlIll[3]));
    switch (llllllllllllllllIIIllllllllllIII & llllIIIlIll[4])
    {
    case 0: 
      llllllllllllllllIIIlllllllllIlll = llllllllllllllllIIIlllllllllIlll.withProperty(LOG_AXIS, BlockLog.EnumAxis.Y);
      "".length();
      if (null != null) {
        return null;
      }
      break;
    case 4: 
      llllllllllllllllIIIlllllllllIlll = llllllllllllllllIIIlllllllllIlll.withProperty(LOG_AXIS, BlockLog.EnumAxis.X);
      "".length();
      if (-"   ".length() > 0) {
        return null;
      }
      break;
    case 8: 
      llllllllllllllllIIIlllllllllIlll = llllllllllllllllIIIlllllllllIlll.withProperty(LOG_AXIS, BlockLog.EnumAxis.Z);
      "".length();
      if ((0x9 ^ 0xC) == 0) {
        return null;
      }
      break;
    default: 
      llllllllllllllllIIIlllllllllIlll = llllllllllllllllIIIlllllllllIlll.withProperty(LOG_AXIS, BlockLog.EnumAxis.NONE);
    }
    return llllllllllllllllIIIlllllllllIlll;
  }
  
  private static String lIlllIlIIlllI(String llllllllllllllllIIIlllllllIIllII, String llllllllllllllllIIIlllllllIIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIIlllllllIIllII = new String(Base64.getDecoder().decode(llllllllllllllllIIIlllllllIIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIIIlllllllIIllll = new StringBuilder();
    char[] llllllllllllllllIIIlllllllIIlllI = llllllllllllllllIIIlllllllIIlIll.toCharArray();
    int llllllllllllllllIIIlllllllIIllIl = llllIIIlIll[0];
    double llllllllllllllllIIIlllllllIIIlll = llllllllllllllllIIIlllllllIIllII.toCharArray();
    Exception llllllllllllllllIIIlllllllIIIllI = llllllllllllllllIIIlllllllIIIlll.length;
    String llllllllllllllllIIIlllllllIIIlIl = llllIIIlIll[0];
    while (lIlllIlIlIIlI(llllllllllllllllIIIlllllllIIIlIl, llllllllllllllllIIIlllllllIIIllI))
    {
      char llllllllllllllllIIIlllllllIlIIlI = llllllllllllllllIIIlllllllIIIlll[llllllllllllllllIIIlllllllIIIlIl];
      "".length();
      "".length();
      if ((0x1C ^ 0x18) < ((0xC1 ^ 0x85) & (0x28 ^ 0x6C ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIIIlllllllIIllll);
  }
  
  public void getSubBlocks(Item llllllllllllllllIIlIIIIIIIIIIIIl, CreativeTabs llllllllllllllllIIlIIIIIIIIIIIII, List<ItemStack> llllllllllllllllIIIlllllllllllIl)
  {
    ;
    ;
    new ItemStack(llllllllllllllllIIlIIIIIIIIIIIIl, llllIIIlIll[1], BlockPlanks.EnumType.OAK.getMetadata());
    "".length();
    new ItemStack(llllllllllllllllIIlIIIIIIIIIIIIl, llllIIIlIll[1], BlockPlanks.EnumType.SPRUCE.getMetadata());
    "".length();
    new ItemStack(llllllllllllllllIIlIIIIIIIIIIIIl, llllIIIlIll[1], BlockPlanks.EnumType.BIRCH.getMetadata());
    "".length();
    new ItemStack(llllllllllllllllIIlIIIIIIIIIIIIl, llllIIIlIll[1], BlockPlanks.EnumType.JUNGLE.getMetadata());
    "".length();
  }
  
  private static void lIlllIlIlIIII()
  {
    llllIIIlIll = new int[9];
    llllIIIlIll[0] = ((0x5B ^ 0x4A ^ 0x9A ^ 0xC1) & ('º' + 28 - 174 + 166 ^ 55 + 70 - 78 + 85 ^ -" ".length()));
    llllIIIlIll[1] = " ".length();
    llllIIIlIll[2] = "   ".length();
    llllIIIlIll[3] = (16 + 0 - 65396 + 32 ^ 41 + 110 - 122 + 155);
    llllIIIlIll[4] = (0x44 ^ 0x63 ^ 0x63 ^ 0x48);
    llllIIIlIll[5] = (0x57 ^ 0x5F);
    llllIIIlIll[6] = "  ".length();
    llllIIIlIll[7] = (0x13 ^ 0x57 ^ 0x56 ^ 0x17);
    llllIIIlIll[8] = (0x90 ^ 0x96);
  }
  
  public int damageDropped(IBlockState llllllllllllllllIIIllllllllIIIII)
  {
    ;
    return ((BlockPlanks.EnumType)llllllllllllllllIIIllllllllIIIII.getValue(VARIANT)).getMetadata();
  }
  
  private static void lIlllIlIIllll()
  {
    llllIIIlIlI = new String[llllIIIlIll[1]];
    llllIIIlIlI[llllIIIlIll[0]] = lIlllIlIIlllI("MAoeOwMoHw==", "FklRb");
  }
  
  private static boolean lIlllIlIlIIlI(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllIIIlllllllIIIIII;
    return ??? < i;
  }
  
  static
  {
    lIlllIlIlIIII();
    lIlllIlIIllll();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllllIIIllllllllIlIll, new IProperty[] { VARIANT, LOG_AXIS });
  }
  
  protected ItemStack createStackedBlock(IBlockState llllllllllllllllIIIllllllllIIlII)
  {
    ;
    ;
    return new ItemStack(Item.getItemFromBlock(llllllllllllllllIIIllllllllIIlIl), llllIIIlIll[1], ((BlockPlanks.EnumType)llllllllllllllllIIIllllllllIIlII.getValue(VARIANT)).getMetadata());
  }
  
  public int getMetaFromState(IBlockState llllllllllllllllIIIllllllllIlllI)
  {
    ;
    ;
    int llllllllllllllllIIIllllllllIllll = llllIIIlIll[0];
    llllllllllllllllIIIllllllllIllll |= ((BlockPlanks.EnumType)llllllllllllllllIIIlllllllllIIII.getValue(VARIANT)).getMetadata();
    switch ($SWITCH_TABLE$net$minecraft$block$BlockLog$EnumAxis()[((BlockLog.EnumAxis)llllllllllllllllIIIlllllllllIIII.getValue(LOG_AXIS)).ordinal()])
    {
    case 1: 
      llllllllllllllllIIIllllllllIllll |= llllIIIlIll[3];
      "".length();
      if (" ".length() < -" ".length()) {
        return (0xD0 ^ 0x9B ^ 0x27 ^ 0x53) & (14 + 91 - 89 + 233 ^ '' + 92 - 142 + 89 ^ -" ".length());
      }
      break;
    case 3: 
      llllllllllllllllIIIllllllllIllll |= llllIIIlIll[5];
      "".length();
      if ((0x2F ^ 0x2B) != (0x27 ^ 0x23)) {
        return (0x73 ^ 0x77) & (0xA7 ^ 0xA3 ^ 0xFFFFFFFF);
      }
      break;
    case 4: 
      llllllllllllllllIIIllllllllIllll |= llllIIIlIll[4];
    }
    return llllllllllllllllIIIllllllllIllll;
  }
  
  private static boolean lIlllIlIlIIIl(Object ???)
  {
    String llllllllllllllllIIIllllllIlllllI;
    return ??? != null;
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllllIIlIIIIIIIIIIllI)
  {
    ;
    ;
    BlockPlanks.EnumType llllllllllllllllIIlIIIIIIIIIIlll = (BlockPlanks.EnumType)llllllllllllllllIIlIIIIIIIIIIllI.getValue(VARIANT);
    switch ($SWITCH_TABLE$net$minecraft$block$BlockLog$EnumAxis()[((BlockLog.EnumAxis)llllllllllllllllIIlIIIIIIIIIlIII.getValue(LOG_AXIS)).ordinal()])
    {
    case 1: 
    case 3: 
    case 4: 
    default: 
      switch ($SWITCH_TABLE$net$minecraft$block$BlockPlanks$EnumType()[llllllllllllllllIIlIIIIIIIIIIlll.ordinal()])
      {
      case 1: 
      default: 
        return BlockPlanks.EnumType.SPRUCE.func_181070_c();
      case 2: 
        return BlockPlanks.EnumType.DARK_OAK.func_181070_c();
      case 3: 
        return MapColor.quartzColor;
      }
      return BlockPlanks.EnumType.SPRUCE.func_181070_c();
    }
    return llllllllllllllllIIlIIIIIIIIIIlll.func_181070_c();
  }
}

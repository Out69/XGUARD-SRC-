package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockPistonExtension
  extends Block
{
  public int quantityDropped(Random lllllllllllllllIlIlIIIllIIllllll)
  {
    return lIlIIIIlIlII[0];
  }
  
  public void applyHeadBounds(IBlockState lllllllllllllllIlIlIIIlIllllllII)
  {
    ;
    ;
    ;
    ;
    float lllllllllllllllIlIlIIIlIllllllll = 0.25F;
    EnumFacing lllllllllllllllIlIlIIIlIlllllllI = (EnumFacing)lllllllllllllllIlIlIIIlIllllllII.getValue(FACING);
    if (lllllIIlIIIlI(lllllllllllllllIlIlIIIlIlllllllI)) {
      switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[lllllllllllllllIlIlIIIlIlllllllI.ordinal()])
      {
      case 1: 
        lllllllllllllllIlIlIIIllIIIIIIIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.25F, 1.0F);
        "".length();
        if (" ".length() == 0) {}
        break;
      case 2: 
        lllllllllllllllIlIlIIIllIIIIIIIl.setBlockBounds(0.0F, 0.75F, 0.0F, 1.0F, 1.0F, 1.0F);
        "".length();
        if (-(0xA7 ^ 0xC7 ^ 0x53 ^ 0x37) >= 0) {}
        break;
      case 3: 
        lllllllllllllllIlIlIIIllIIIIIIIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.25F);
        "".length();
        if (" ".length() >= "  ".length()) {}
        break;
      case 4: 
        lllllllllllllllIlIlIIIllIIIIIIIl.setBlockBounds(0.0F, 0.0F, 0.75F, 1.0F, 1.0F, 1.0F);
        "".length();
        if (((22 + 37 - -106 + 46 ^ 54 + 88 - 13 + 23) & ('ï' + 52 - 52 + 3 ^ 9 + '£' - 98 + 111 ^ -" ".length())) > 0) {}
        break;
      case 5: 
        lllllllllllllllIlIlIIIllIIIIIIIl.setBlockBounds(0.0F, 0.0F, 0.0F, 0.25F, 1.0F, 1.0F);
        "".length();
        if (((0x1C ^ 0x5A) & (0xE8 ^ 0xAE ^ 0xFFFFFFFF)) > ((0x5E ^ 0x3C) & (0x76 ^ 0x14 ^ 0xFFFFFFFF))) {}
        break;
      case 6: 
        lllllllllllllllIlIlIIIllIIIIIIIl.setBlockBounds(0.75F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
      }
    }
  }
  
  private static boolean lllllIIlIIlll(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIlIlIIIlIlIIlIlII;
    return ??? > i;
  }
  
  private void applyCoreBounds(IBlockState lllllllllllllllIlIlIIIllIIIllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIlIlIIIllIIIllIlI = 0.25F;
    float lllllllllllllllIlIlIIIllIIIllIIl = 0.375F;
    float lllllllllllllllIlIlIIIllIIIllIII = 0.625F;
    float lllllllllllllllIlIlIIIllIIIlIlll = 0.25F;
    float lllllllllllllllIlIlIIIllIIIlIllI = 0.75F;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[((EnumFacing)lllllllllllllllIlIlIIIllIIIllIll.getValue(FACING)).ordinal()])
    {
    case 1: 
      lllllllllllllllIlIlIIIllIIIlllII.setBlockBounds(0.375F, 0.25F, 0.375F, 0.625F, 1.0F, 0.625F);
      "".length();
      if (((0x16 ^ 0x61 ^ 0xEB ^ 0x99) & (0x3A ^ 0x24 ^ 0x4C ^ 0x57 ^ -" ".length())) >= " ".length()) {}
      break;
    case 2: 
      lllllllllllllllIlIlIIIllIIIlllII.setBlockBounds(0.375F, 0.0F, 0.375F, 0.625F, 0.75F, 0.625F);
      "".length();
      if ((" ".length() ^ 0x97 ^ 0x92) <= " ".length()) {}
      break;
    case 3: 
      lllllllllllllllIlIlIIIllIIIlllII.setBlockBounds(0.25F, 0.375F, 0.25F, 0.75F, 0.625F, 1.0F);
      "".length();
      if (" ".length() == ((0x49 ^ 0x72) & (0x5E ^ 0x65 ^ 0xFFFFFFFF))) {}
      break;
    case 4: 
      lllllllllllllllIlIlIIIllIIIlllII.setBlockBounds(0.25F, 0.375F, 0.0F, 0.75F, 0.625F, 0.75F);
      "".length();
      if ("   ".length() <= -" ".length()) {}
      break;
    case 5: 
      lllllllllllllllIlIlIIIllIIIlllII.setBlockBounds(0.375F, 0.25F, 0.25F, 0.625F, 0.75F, 1.0F);
      "".length();
      if (null != null) {}
      break;
    case 6: 
      lllllllllllllllIlIlIIIllIIIlllII.setBlockBounds(0.0F, 0.375F, 0.25F, 0.75F, 0.625F, 0.75F);
    }
  }
  
  public BlockPistonExtension()
  {
    lllllllllllllllIlIlIIIlllIlIIlIl.<init>(Material.piston);
    lllllllllllllllIlIlIIIlllIlIIlII.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(TYPE, EnumPistonType.DEFAULT).withProperty(SHORT, Boolean.valueOf(lIlIIIIlIlII[0])));
    "".length();
    "".length();
  }
  
  public boolean isFullCube()
  {
    return lIlIIIIlIlII[0];
  }
  
  private static boolean lllllIIlIIIll(Object ???, Object arg1)
  {
    Object localObject;
    Exception lllllllllllllllIlIlIIIlIlIIlIIII;
    return ??? != localObject;
  }
  
  public void onBlockHarvested(World lllllllllllllllIlIlIIIlllIIIIIIl, BlockPos lllllllllllllllIlIlIIIllIlllllll, IBlockState lllllllllllllllIlIlIIIlllIIIllIl, EntityPlayer lllllllllllllllIlIlIIIllIlllllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllllIIlIIIIl(capabilities.isCreativeMode))
    {
      EnumFacing lllllllllllllllIlIlIIIlllIIIlIll = (EnumFacing)lllllllllllllllIlIlIIIlllIIIllIl.getValue(FACING);
      if (lllllIIlIIIlI(lllllllllllllllIlIlIIIlllIIIlIll))
      {
        BlockPos lllllllllllllllIlIlIIIlllIIIlIlI = lllllllllllllllIlIlIIIlllIIIlllI.offset(lllllllllllllllIlIlIIIlllIIIlIll.getOpposite());
        Block lllllllllllllllIlIlIIIlllIIIlIIl = lllllllllllllllIlIlIIIlllIIIIIIl.getBlockState(lllllllllllllllIlIlIIIlllIIIlIlI).getBlock();
        if ((!lllllIIlIIIll(lllllllllllllllIlIlIIIlllIIIlIIl, Blocks.piston)) || (lllllIIlIIlII(lllllllllllllllIlIlIIIlllIIIlIIl, Blocks.sticky_piston))) {
          "".length();
        }
      }
    }
    lllllllllllllllIlIlIIIlllIIIIIll.onBlockHarvested(lllllllllllllllIlIlIIIlllIIIIIIl, lllllllllllllllIlIlIIIlllIIIlllI, lllllllllllllllIlIlIIIlllIIIllIl, lllllllllllllllIlIlIIIllIlllllII);
  }
  
  public boolean canPlaceBlockAt(World lllllllllllllllIlIlIIIllIlIIlIII, BlockPos lllllllllllllllIlIlIIIllIlIIIlll)
  {
    return lIlIIIIlIlII[0];
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess lllllllllllllllIlIlIIIllIIIIIlll, BlockPos lllllllllllllllIlIlIIIllIIIIlIIl)
  {
    ;
    ;
    ;
    lllllllllllllllIlIlIIIllIIIIlIII.applyHeadBounds(lllllllllllllllIlIlIIIllIIIIlIlI.getBlockState(lllllllllllllllIlIlIIIllIIIIlIIl));
  }
  
  public void breakBlock(World lllllllllllllllIlIlIIIllIlIlIlII, BlockPos lllllllllllllllIlIlIIIllIlIllllI, IBlockState lllllllllllllllIlIlIIIllIlIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIIIllIllIIIIl.breakBlock(lllllllllllllllIlIlIIIllIlIlIlII, lllllllllllllllIlIlIIIllIlIllllI, lllllllllllllllIlIlIIIllIlIlllII);
    EnumFacing lllllllllllllllIlIlIIIllIlIllIlI = ((EnumFacing)lllllllllllllllIlIlIIIllIlIlllII.getValue(FACING)).getOpposite();
    BlockPos lllllllllllllllIlIlIIIllIlIllllI = lllllllllllllllIlIlIIIllIlIllllI.offset(lllllllllllllllIlIlIIIllIlIllIlI);
    IBlockState lllllllllllllllIlIlIIIllIlIllIII = lllllllllllllllIlIlIIIllIlIlIlII.getBlockState(lllllllllllllllIlIlIIIllIlIllllI);
    if (((!lllllIIlIIIll(lllllllllllllllIlIlIIIllIlIllIII.getBlock(), Blocks.piston)) || (lllllIIlIIlII(lllllllllllllllIlIlIIIllIlIllIII.getBlock(), Blocks.sticky_piston))) && (lllllIIlIIIIl(((Boolean)lllllllllllllllIlIlIIIllIlIllIII.getValue(BlockPistonBase.EXTENDED)).booleanValue())))
    {
      lllllllllllllllIlIlIIIllIlIllIII.getBlock().dropBlockAsItem(lllllllllllllllIlIlIIIllIlIlIlII, lllllllllllllllIlIlIIIllIlIllllI, lllllllllllllllIlIlIIIllIlIllIII, lIlIIIIlIlII[0]);
      "".length();
    }
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIlIlIIIlIllIIIIll, new IProperty[] { FACING, TYPE, SHORT });
  }
  
  private static boolean lllllIIlIlIII(int ???)
  {
    int lllllllllllllllIlIlIIIlIlIIIIllI;
    return ??? > 0;
  }
  
  private static boolean lllllIIlIllII(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIlIlIIIlIlIIllIII;
    return ??? < i;
  }
  
  private static void lllllIIlIIIII()
  {
    lIlIIIIlIlII = new int[9];
    lIlIIIIlIlII[0] = ((115 + 53 - 107 + 90 ^ 113 + 38 - -24 + 5) & (0x76 ^ 0x2D ^ 0xCD ^ 0xB5 ^ -" ".length()));
    lIlIIIIlIlII[1] = " ".length();
    lIlIIIIlIlII[2] = "  ".length();
    lIlIIIIlIlII[3] = (19 + 105 - 85 + 114 ^ 127 + '' - 123 + 6);
    lIlIIIIlIlII[4] = (0x5A ^ 0x4B ^ 0x42 ^ 0x56);
    lIlIIIIlIlII[5] = (0x57 ^ 0x5F);
    lIlIIIIlIlII[6] = "   ".length();
    lIlIIIIlIlII[7] = (62 + 8 - -99 + 18 ^ 38 + 54 - -48 + 49);
    lIlIIIIlIlII[8] = (0x53 ^ 0x6A ^ 0x28 ^ 0x15);
  }
  
  public void onNeighborBlockChange(World lllllllllllllllIlIlIIIlIlllIlIlI, BlockPos lllllllllllllllIlIlIIIlIlllIlIIl, IBlockState lllllllllllllllIlIlIIIlIlllIllll, Block lllllllllllllllIlIlIIIlIlllIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing lllllllllllllllIlIlIIIlIlllIllIl = (EnumFacing)lllllllllllllllIlIlIIIlIlllIllll.getValue(FACING);
    BlockPos lllllllllllllllIlIlIIIlIlllIllII = lllllllllllllllIlIlIIIlIlllIlIIl.offset(lllllllllllllllIlIlIIIlIlllIllIl.getOpposite());
    IBlockState lllllllllllllllIlIlIIIlIlllIlIll = lllllllllllllllIlIlIIIlIlllIlIlI.getBlockState(lllllllllllllllIlIlIIIlIlllIllII);
    if ((lllllIIlIIIll(lllllllllllllllIlIlIIIlIlllIlIll.getBlock(), Blocks.piston)) && (lllllIIlIIIll(lllllllllllllllIlIlIIIlIlllIlIll.getBlock(), Blocks.sticky_piston)))
    {
      "".length();
      "".length();
      if ("   ".length() > ((0x49 ^ 0x3E ^ 0xD4 ^ 0x81) & (0xF3 ^ 0xA5 ^ 0xA ^ 0x7E ^ -" ".length()))) {}
    }
    else
    {
      lllllllllllllllIlIlIIIlIlllIlIll.getBlock().onNeighborBlockChange(lllllllllllllllIlIlIIIlIlllIlIlI, lllllllllllllllIlIlIIIlIlllIllII, lllllllllllllllIlIlIIIlIlllIlIll, lllllllllllllllIlIlIIIlIlllIlllI);
    }
  }
  
  private static void lllllIIIIlllI()
  {
    lIlIIIIIlllI = new String[lIlIIIIlIlII[6]];
    lIlIIIIIlllI[lIlIIIIlIlII[0]] = lllllIIIIllII("MSAGLjcw", "WAeGY");
    lIlIIIIIlllI[lIlIIIIlIlII[1]] = lllllIIIIllIl("Us15CeQAO2g=", "IpMWu");
    lIlIIIIIlllI[lIlIIIIlIlII[2]] = lllllIIIIllIl("ROp1KC2jxnk=", "VhWeM");
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIlIlIIIlIllIIlIIl)
  {
    ;
    ;
    int lllllllllllllllIlIlIIIlIllIIlIII = lIlIIIIlIlII[0];
    lllllllllllllllIlIlIIIlIllIIlIII |= ((EnumFacing)lllllllllllllllIlIlIIIlIllIIIlll.getValue(FACING)).getIndex();
    if (lllllIIlIIlII(lllllllllllllllIlIlIIIlIllIIIlll.getValue(TYPE), EnumPistonType.STICKY)) {
      lllllllllllllllIlIlIIIlIllIIlIII |= lIlIIIIlIlII[5];
    }
    return lllllllllllllllIlIlIIIlIllIIlIII;
  }
  
  private static boolean lllllIIlIIIIl(int ???)
  {
    short lllllllllllllllIlIlIIIlIlIIIlIII;
    return ??? != 0;
  }
  
  public boolean shouldSideBeRendered(IBlockAccess lllllllllllllllIlIlIIIlIlllIIIlI, BlockPos lllllllllllllllIlIlIIIlIlllIIIIl, EnumFacing lllllllllllllllIlIlIIIlIlllIIIII)
  {
    return lIlIIIIlIlII[1];
  }
  
  private static String lllllIIIIllIl(String lllllllllllllllIlIlIIIlIlIllIlll, String lllllllllllllllIlIlIIIlIlIllIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIIIlIlIllllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIIIlIlIllIllI.getBytes(StandardCharsets.UTF_8)), lIlIIIIlIlII[5]), "DES");
      Cipher lllllllllllllllIlIlIIIlIlIlllIll = Cipher.getInstance("DES");
      lllllllllllllllIlIlIIIlIlIlllIll.init(lIlIIIIlIlII[2], lllllllllllllllIlIlIIIlIlIllllII);
      return new String(lllllllllllllllIlIlIIIlIlIlllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIIIlIlIllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIIIlIlIlllIlI)
    {
      lllllllllllllllIlIlIIIlIlIlllIlI.printStackTrace();
    }
    return null;
  }
  
  public boolean isOpaqueCube()
  {
    return lIlIIIIlIlII[0];
  }
  
  public static EnumFacing getFacing(int lllllllllllllllIlIlIIIlIllIlllIl)
  {
    ;
    ;
    int lllllllllllllllIlIlIIIlIllIlllII = lllllllllllllllIlIlIIIlIllIlllIl & lIlIIIIlIlII[3];
    if (lllllIIlIIlll(lllllllllllllllIlIlIIIlIllIlllII, lIlIIIIlIlII[4]))
    {
      "".length();
      if (null == null) {
        break label37;
      }
      return null;
    }
    label37:
    return EnumFacing.getFront(lllllllllllllllIlIlIIIlIllIlllII);
  }
  
  public boolean canPlaceBlockOnSide(World lllllllllllllllIlIlIIIllIlIIIlIl, BlockPos lllllllllllllllIlIlIIIllIlIIIlII, EnumFacing lllllllllllllllIlIlIIIllIlIIIIll)
  {
    return lIlIIIIlIlII[0];
  }
  
  public void addCollisionBoxesToList(World lllllllllllllllIlIlIIIllIIlIlIIl, BlockPos lllllllllllllllIlIlIIIllIIlIlIII, IBlockState lllllllllllllllIlIlIIIllIIlIlllI, AxisAlignedBB lllllllllllllllIlIlIIIllIIlIIllI, List<AxisAlignedBB> lllllllllllllllIlIlIIIllIIlIllII, Entity lllllllllllllllIlIlIIIllIIlIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIIIllIIllIIIl.applyHeadBounds(lllllllllllllllIlIlIIIllIIlIIlll);
    lllllllllllllllIlIlIIIllIIllIIIl.addCollisionBoxesToList(lllllllllllllllIlIlIIIllIIlIlIIl, lllllllllllllllIlIlIIIllIIlIlIII, lllllllllllllllIlIlIIIllIIlIIlll, lllllllllllllllIlIlIIIllIIlIIllI, lllllllllllllllIlIlIIIllIIlIllII, lllllllllllllllIlIlIIIllIIlIIlII);
    lllllllllllllllIlIlIIIllIIllIIIl.applyCoreBounds(lllllllllllllllIlIlIIIllIIlIIlll);
    lllllllllllllllIlIlIIIllIIllIIIl.addCollisionBoxesToList(lllllllllllllllIlIlIIIllIIlIlIIl, lllllllllllllllIlIlIIIllIIlIlIII, lllllllllllllllIlIlIIIllIIlIIlll, lllllllllllllllIlIlIIIllIIlIIllI, lllllllllllllllIlIlIIIllIIlIllII, lllllllllllllllIlIlIIIllIIlIIlII);
    lllllllllllllllIlIlIIIllIIllIIIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  
  static
  {
    lllllIIlIIIII();
    lllllIIIIlllI();
  }
  
  private static boolean lllllIIlIIIlI(Object ???)
  {
    char lllllllllllllllIlIlIIIlIlIIIlllI;
    return ??? != null;
  }
  
  private static boolean lllllIIlIIlII(Object ???, Object arg1)
  {
    Object localObject;
    Exception lllllllllllllllIlIlIIIlIlIIIlIlI;
    return ??? == localObject;
  }
  
  public Item getItem(World lllllllllllllllIlIlIIIlIllIlIlII, BlockPos lllllllllllllllIlIlIIIlIllIlIlIl)
  {
    ;
    ;
    if (lllllIIlIIlII(lllllllllllllllIlIlIIIlIllIlIlII.getBlockState(lllllllllllllllIlIlIIIlIllIlIlIl).getValue(TYPE), EnumPistonType.STICKY))
    {
      "".length();
      if (null == null) {
        break label46;
      }
      return null;
    }
    label46:
    return Item.getItemFromBlock(Blocks.piston);
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIlIlIIIlIllIIllll)
  {
    ;
    ;
    if (lllllIIlIlIII(lllllllllllllllIlIlIIIlIllIIllll & lIlIIIIlIlII[5]))
    {
      "".length();
      if (((0xA9 ^ 0xA5) & (0x1E ^ 0x12 ^ 0xFFFFFFFF)) < " ".length()) {
        break label69;
      }
      return null;
    }
    label69:
    return TYPE.withProperty(EnumPistonType.STICKY, EnumPistonType.DEFAULT);
  }
  
  private static String lllllIIIIllII(String lllllllllllllllIlIlIIIlIlIlIIlII, String lllllllllllllllIlIlIIIlIlIlIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIIIlIlIlIIlII = new String(Base64.getDecoder().decode(lllllllllllllllIlIlIIIlIlIlIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlIlIIIlIlIlIIlll = new StringBuilder();
    char[] lllllllllllllllIlIlIIIlIlIlIIllI = lllllllllllllllIlIlIIIlIlIlIIIll.toCharArray();
    int lllllllllllllllIlIlIIIlIlIlIIlIl = lIlIIIIlIlII[0];
    float lllllllllllllllIlIlIIIlIlIIlllll = lllllllllllllllIlIlIIIlIlIlIIlII.toCharArray();
    float lllllllllllllllIlIlIIIlIlIIllllI = lllllllllllllllIlIlIIIlIlIIlllll.length;
    short lllllllllllllllIlIlIIIlIlIIlllIl = lIlIIIIlIlII[0];
    while (lllllIIlIllII(lllllllllllllllIlIlIIIlIlIIlllIl, lllllllllllllllIlIlIIIlIlIIllllI))
    {
      char lllllllllllllllIlIlIIIlIlIlIlIlI = lllllllllllllllIlIlIIIlIlIIlllll[lllllllllllllllIlIlIIIlIlIIlllIl];
      "".length();
      "".length();
      if (-" ".length() > -" ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIlIlIIIlIlIlIIlll);
  }
  
  public static enum EnumPistonType
    implements IStringSerializable
  {
    DEFAULT(lIIIllIlIlIl[lIIIllIlIllI[1]]),  STICKY(lIIIllIlIlIl[lIIIllIlIllI[3]]);
    
    private EnumPistonType(String lllllllllllllllIlllIIIIIlllIIlII)
    {
      VARIANT = lllllllllllllllIlllIIIIIlllIIlII;
    }
    
    public String getName()
    {
      ;
      return VARIANT;
    }
    
    private static boolean llIllIlIlIIll(int ???, int arg1)
    {
      int i;
      long lllllllllllllllIlllIIIIIlIlIlIIl;
      return ??? < i;
    }
    
    private static String llIllIlIlIIII(String lllllllllllllllIlllIIIIIllIIIIlI, String lllllllllllllllIlllIIIIIllIIIIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIlllIIIIIllIIIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIIIllIIIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIlllIIIIIllIIIlIl = new StringBuilder();
      char[] lllllllllllllllIlllIIIIIllIIIlII = lllllllllllllllIlllIIIIIllIIIIIl.toCharArray();
      int lllllllllllllllIlllIIIIIllIIIIll = lIIIllIlIllI[0];
      boolean lllllllllllllllIlllIIIIIlIllllIl = lllllllllllllllIlllIIIIIllIIIIlI.toCharArray();
      float lllllllllllllllIlllIIIIIlIllllII = lllllllllllllllIlllIIIIIlIllllIl.length;
      String lllllllllllllllIlllIIIIIlIlllIll = lIIIllIlIllI[0];
      while (llIllIlIlIIll(lllllllllllllllIlllIIIIIlIlllIll, lllllllllllllllIlllIIIIIlIllllII))
      {
        char lllllllllllllllIlllIIIIIllIIlIII = lllllllllllllllIlllIIIIIlIllllIl[lllllllllllllllIlllIIIIIlIlllIll];
        "".length();
        "".length();
        if ("   ".length() <= "  ".length()) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIlllIIIIIllIIIlIl);
    }
    
    private static void llIllIlIlIIlI()
    {
      lIIIllIlIllI = new int[6];
      lIIIllIlIllI[0] = ((0xC ^ 0x1D ^ 0xCC ^ 0x9E) & (0xFF ^ 0xBE ^ "  ".length() ^ -" ".length()));
      lIIIllIlIllI[1] = " ".length();
      lIIIllIlIllI[2] = "  ".length();
      lIIIllIlIllI[3] = "   ".length();
      lIIIllIlIllI[4] = ('' + 47 - 103 + 77 ^ 95 + 86 - 45 + 23);
      lIIIllIlIllI[5] = ('' + 114 - 163 + 78 ^ '' + 92 - 228 + 158);
    }
    
    public String toString()
    {
      ;
      return VARIANT;
    }
    
    private static void llIllIlIlIIIl()
    {
      lIIIllIlIlIl = new String[lIIIllIlIllI[4]];
      lIIIllIlIlIl[lIIIllIlIllI[0]] = llIllIlIIllll("YEh9tU4CW1U=", "AcYvB");
      lIIIllIlIlIl[lIIIllIlIllI[1]] = llIllIlIlIIII("GQAYHQkb", "wojph");
      lIIIllIlIlIl[lIIIllIlIllI[2]] = llIllIlIlIIII("NgAPDxo8", "eTFLQ");
      lIIIllIlIlIl[lIIIllIlIllI[3]] = llIllIlIlIIII("BgUoBQMM", "uqAfh");
    }
    
    private static String llIllIlIIllll(String lllllllllllllllIlllIIIIIlIllIIlI, String lllllllllllllllIlllIIIIIlIlIllll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIlllIIIIIlIllIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIIIlIlIllll.getBytes(StandardCharsets.UTF_8)), lIIIllIlIllI[5]), "DES");
        Cipher lllllllllllllllIlllIIIIIlIllIlII = Cipher.getInstance("DES");
        lllllllllllllllIlllIIIIIlIllIlII.init(lIIIllIlIllI[2], lllllllllllllllIlllIIIIIlIllIlIl);
        return new String(lllllllllllllllIlllIIIIIlIllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIIIlIllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIlllIIIIIlIllIIll)
      {
        lllllllllllllllIlllIIIIIlIllIIll.printStackTrace();
      }
      return null;
    }
    
    static
    {
      llIllIlIlIIlI();
      llIllIlIlIIIl();
    }
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;

public class BlockReed
  extends Block
{
  private static boolean llIlIIllIIIlI(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIlllIlllIllIIIIll;
    return ??? == i;
  }
  
  public boolean isOpaqueCube()
  {
    return lIIIlIIIIlIl[0];
  }
  
  protected BlockReed()
  {
    lllllllllllllllIlllIllllIlIlllII.<init>(Material.plants);
    lllllllllllllllIlllIllllIlIllIlI.setDefaultState(blockState.getBaseState().withProperty(AGE, Integer.valueOf(lIIIlIIIIlIl[0])));
    float lllllllllllllllIlllIllllIlIllIll = 0.375F;
    lllllllllllllllIlllIllllIlIllIlI.setBlockBounds(0.5F - lllllllllllllllIlllIllllIlIllIll, 0.0F, 0.5F - lllllllllllllllIlllIllllIlIllIll, 0.5F + lllllllllllllllIlllIllllIlIllIll, 1.0F, 0.5F + lllllllllllllllIlllIllllIlIllIll);
    "".length();
  }
  
  private static void llIlIIlIllllI()
  {
    lIIIlIIIIlIl = new int[6];
    lIIIlIIIIlIl[0] = ((0x6D ^ 0x28) & (0x5D ^ 0x18 ^ 0xFFFFFFFF));
    lIIIlIIIIlIl[1] = (0x8 ^ 0x7);
    lIIIlIIIIlIl[2] = " ".length();
    lIIIlIIIIlIl[3] = "   ".length();
    lIIIlIIIIlIl[4] = (0x82 ^ 0x86);
    lIIIlIIIIlIl[5] = "  ".length();
  }
  
  private static void llIlIIlIllIll()
  {
    lIIIlIIIIIll = new String[lIIIlIIIIlIl[2]];
    lIIIlIIIIIll[lIIIlIIIIlIl[0]] = llIlIIlIllIIl("y4OwgAV3Hgs=", "ZlKUx");
  }
  
  public int colorMultiplier(IBlockAccess lllllllllllllllIlllIlllIlllIIllI, BlockPos lllllllllllllllIlllIlllIlllIIIlI, int lllllllllllllllIlllIlllIlllIIlII)
  {
    ;
    ;
    return lllllllllllllllIlllIlllIlllIIllI.getBiomeGenForCoords(lllllllllllllllIlllIlllIlllIIlIl).getGrassColorAtPos(lllllllllllllllIlllIlllIlllIIlIl);
  }
  
  public boolean isFullCube()
  {
    return lIIIlIIIIlIl[0];
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllIlllIlllIllllIIIl, Random lllllllllllllllIlllIlllIllllIIII, int lllllllllllllllIlllIlllIlllIllll)
  {
    return Items.reeds;
  }
  
  private static boolean llIlIIllIIIll(Object ???, Object arg1)
  {
    Object localObject;
    String lllllllllllllllIlllIlllIlIllIlll;
    return ??? == localObject;
  }
  
  private static boolean llIlIIllIIIII(int ???)
  {
    Exception lllllllllllllllIlllIlllIlIllIlIl;
    return ??? != 0;
  }
  
  public Item getItem(World lllllllllllllllIlllIlllIlllIlIll, BlockPos lllllllllllllllIlllIlllIlllIlIlI)
  {
    return Items.reeds;
  }
  
  private static boolean llIlIIllIIIIl(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIlllIlllIlIllllll;
    return ??? < i;
  }
  
  private static boolean llIlIIllIIlII(int ???)
  {
    long lllllllllllllllIlllIlllIlIllIIll;
    return ??? == 0;
  }
  
  protected final boolean checkForDrop(World lllllllllllllllIlllIllllIIIIIllI, BlockPos lllllllllllllllIlllIllllIIIIIlIl, IBlockState lllllllllllllllIlllIllllIIIIIIII)
  {
    ;
    ;
    ;
    ;
    if (llIlIIllIIIII(lllllllllllllllIlllIllllIIIIIlll.canBlockStay(lllllllllllllllIlllIllllIIIIIllI, lllllllllllllllIlllIllllIIIIIlIl))) {
      return lIIIlIIIIlIl[2];
    }
    lllllllllllllllIlllIllllIIIIIlll.dropBlockAsItem(lllllllllllllllIlllIllllIIIIIllI, lllllllllllllllIlllIllllIIIIIlIl, lllllllllllllllIlllIllllIIIIIIII, lIIIlIIIIlIl[0]);
    "".length();
    return lIIIlIIIIlIl[0];
  }
  
  public void onNeighborBlockChange(World lllllllllllllllIlllIllllIIIIlllI, BlockPos lllllllllllllllIlllIllllIIIIllIl, IBlockState lllllllllllllllIlllIllllIIIlIIIl, Block lllllllllllllllIlllIllllIIIlIIII)
  {
    ;
    ;
    ;
    ;
    "".length();
  }
  
  public boolean canBlockStay(World lllllllllllllllIlllIlllIlllllIII, BlockPos lllllllllllllllIlllIlllIlllllIlI)
  {
    ;
    ;
    ;
    return lllllllllllllllIlllIlllIlllllIIl.canPlaceBlockAt(lllllllllllllllIlllIlllIlllllIll, lllllllllllllllIlllIlllIlllllIlI);
  }
  
  private static boolean llIlIIlIlllll(Object ???, Object arg1)
  {
    Object localObject;
    char lllllllllllllllIlllIlllIlIlllIll;
    return ??? != localObject;
  }
  
  public boolean canPlaceBlockAt(World lllllllllllllllIlllIllllIIlIIlII, BlockPos lllllllllllllllIlllIllllIIlIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    Block lllllllllllllllIlllIllllIIlIIIlI = lllllllllllllllIlllIllllIIlIIlII.getBlockState(lllllllllllllllIlllIllllIIlIIIll.down()).getBlock();
    if (llIlIIllIIIll(lllllllllllllllIlllIllllIIlIIIlI, lllllllllllllllIlllIllllIIIlllll)) {
      return lIIIlIIIIlIl[2];
    }
    if ((llIlIIlIlllll(lllllllllllllllIlllIllllIIlIIIlI, Blocks.grass)) && (llIlIIlIlllll(lllllllllllllllIlllIllllIIlIIIlI, Blocks.dirt)) && (llIlIIlIlllll(lllllllllllllllIlllIllllIIlIIIlI, Blocks.sand))) {
      return lIIIlIIIIlIl[0];
    }
    int lllllllllllllllIlllIllllIIIllIlI = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if (-"   ".length() > 0) {
      return (0x53 ^ 0x45) & (0x16 ^ 0x0 ^ 0xFFFFFFFF);
    }
    while (!llIlIIllIIlII(lllllllllllllllIlllIllllIIIllIlI.hasNext()))
    {
      Object lllllllllllllllIlllIllllIIlIIIIl = lllllllllllllllIlllIllllIIIllIlI.next();
      EnumFacing lllllllllllllllIlllIllllIIlIIIII = (EnumFacing)lllllllllllllllIlllIllllIIlIIIIl;
      if (llIlIIllIIIll(lllllllllllllllIlllIllllIIIllllI.getBlockState(lllllllllllllllIlllIllllIIlIIIll.offset(lllllllllllllllIlllIllllIIlIIIII).down()).getBlock().getMaterial(), Material.water)) {
        return lIIIlIIIIlIl[2];
      }
    }
    return lIIIlIIIIlIl[0];
  }
  
  static
  {
    llIlIIlIllllI();
    llIlIIlIllIll();
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIlllIlllIllIlllIl)
  {
    ;
    ;
    return lllllllllllllllIlllIlllIllIllllI.getDefaultState().withProperty(AGE, Integer.valueOf(lllllllllllllllIlllIlllIllIlllIl));
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIlllIlllIllIlIlll)
  {
    ;
    return ((Integer)lllllllllllllllIlllIlllIllIlIlll.getValue(AGE)).intValue();
  }
  
  public void updateTick(World lllllllllllllllIlllIllllIlIIIIII, BlockPos lllllllllllllllIlllIllllIIlllllI, IBlockState lllllllllllllllIlllIllllIIllllII, Random lllllllllllllllIlllIllllIIlllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (((!llIlIIlIlllll(lllllllllllllllIlllIllllIlIIIIII.getBlockState(lllllllllllllllIlllIllllIIllIIII.down()).getBlock(), Blocks.reeds)) || (llIlIIllIIIII(lllllllllllllllIlllIllllIlIIIIlI.checkForDrop(lllllllllllllllIlllIllllIlIIIIII, lllllllllllllllIlllIllllIIllIIII, lllllllllllllllIlllIllllIIllllII)))) && (llIlIIllIIIII(lllllllllllllllIlllIllllIlIIIIII.isAirBlock(lllllllllllllllIlllIllllIIllIIII.up()))))
    {
      int lllllllllllllllIlllIllllIIlllIII = lIIIlIIIIlIl[2];
      "".length();
      if (-(0x1D ^ 0x18) >= 0) {
        return;
      }
      while (!llIlIIlIlllll(lllllllllllllllIlllIllllIlIIIIII.getBlockState(lllllllllllllllIlllIllllIIllIIII.down(lllllllllllllllIlllIllllIIlllIII)).getBlock(), lllllllllllllllIlllIllllIlIIIIlI)) {
        lllllllllllllllIlllIllllIIlllIII++;
      }
      if (llIlIIllIIIIl(lllllllllllllllIlllIllllIIlllIII, lIIIlIIIIlIl[3]))
      {
        int lllllllllllllllIlllIllllIIllIllI = ((Integer)lllllllllllllllIlllIllllIIllllII.getValue(AGE)).intValue();
        if (llIlIIllIIIlI(lllllllllllllllIlllIllllIIllIllI, lIIIlIIIIlIl[1]))
        {
          "".length();
          "".length();
          "".length();
          if (-(0x75 ^ 0x70) < 0) {}
        }
        else
        {
          "".length();
        }
      }
    }
  }
  
  private static String llIlIIlIllIIl(String lllllllllllllllIlllIlllIllIIllII, String lllllllllllllllIlllIlllIllIIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlllIlllIllIIllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIlllIllIIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIlllIllIIlllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIlllIllIIlllI.init(lIIIlIIIIlIl[5], lllllllllllllllIlllIlllIllIIllll);
      return new String(lllllllllllllllIlllIlllIllIIlllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIlllIllIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlllIlllIllIIllIl)
    {
      lllllllllllllllIlllIlllIllIIllIl.printStackTrace();
    }
    return null;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIlllIlllIllIlIlII, new IProperty[] { AGE });
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World lllllllllllllllIlllIlllIllllIlIl, BlockPos lllllllllllllllIlllIlllIllllIlII, IBlockState lllllllllllllllIlllIlllIllllIIll)
  {
    return null;
  }
}

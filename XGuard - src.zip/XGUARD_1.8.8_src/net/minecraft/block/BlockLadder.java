package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockLadder
  extends Block
{
  private static boolean lIlIllIllIlI(int ???)
  {
    byte llllllllllllllllllIllIllIIllIlll;
    return ??? != 0;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllllllIllIllIllIIlIl)
  {
    ;
    ;
    ;
    EnumFacing llllllllllllllllllIllIllIllIIlll = EnumFacing.getFront(llllllllllllllllllIllIllIllIIlIl);
    if (lIlIllIllIIl(llllllllllllllllllIllIllIllIIlll.getAxis(), EnumFacing.Axis.Y)) {
      llllllllllllllllllIllIllIllIIlll = EnumFacing.NORTH;
    }
    return llllllllllllllllllIllIllIllIIllI.getDefaultState().withProperty(FACING, llllllllllllllllllIllIllIllIIlll);
  }
  
  private static boolean lIlIllIlllIl(int ???, int arg1)
  {
    int i;
    long llllllllllllllllllIllIllIIllllll;
    return ??? < i;
  }
  
  public void onNeighborBlockChange(World llllllllllllllllllIllIllIlllllII, BlockPos llllllllllllllllllIllIllIllllIll, IBlockState llllllllllllllllllIllIllIllllIlI, Block llllllllllllllllllIllIllIllllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllllllIllIllIllllllI = (EnumFacing)llllllllllllllllllIllIllIllllIlI.getValue(FACING);
    if (lIlIllIllIll(llllllllllllllllllIllIllIlllllIl.canBlockStay(llllllllllllllllllIllIllIlllllII, llllllllllllllllllIllIlllIIIIIIl, llllllllllllllllllIllIllIllllllI)))
    {
      llllllllllllllllllIllIllIlllllIl.dropBlockAsItem(llllllllllllllllllIllIllIlllllII, llllllllllllllllllIllIlllIIIIIIl, llllllllllllllllllIllIllIllllIlI, llIllIIIll[0]);
      "".length();
    }
    llllllllllllllllllIllIllIlllllIl.onNeighborBlockChange(llllllllllllllllllIllIllIlllllII, llllllllllllllllllIllIlllIIIIIIl, llllllllllllllllllIllIllIllllIlI, llllllllllllllllllIllIllIllllIIl);
  }
  
  private static String lIlIllIlIllI(String llllllllllllllllllIllIllIlIlIIII, String llllllllllllllllllIllIllIlIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllllIllIllIlIlIIII = new String(Base64.getDecoder().decode(llllllllllllllllllIllIllIlIlIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllIllIllIlIIlllI = new StringBuilder();
    char[] llllllllllllllllllIllIllIlIIllIl = llllllllllllllllllIllIllIlIIlIlI.toCharArray();
    int llllllllllllllllllIllIllIlIIllII = llIllIIIll[0];
    int llllllllllllllllllIllIllIlIIIllI = llllllllllllllllllIllIllIlIlIIII.toCharArray();
    String llllllllllllllllllIllIllIlIIIlIl = llllllllllllllllllIllIllIlIIIllI.length;
    String llllllllllllllllllIllIllIlIIIlII = llIllIIIll[0];
    while (lIlIllIlllIl(llllllllllllllllllIllIllIlIIIlII, llllllllllllllllllIllIllIlIIIlIl))
    {
      char llllllllllllllllllIllIllIlIlIIIl = llllllllllllllllllIllIllIlIIIllI[llllllllllllllllllIllIllIlIIIlII];
      "".length();
      "".length();
      if ((0x5D ^ 0x25 ^ 0xE1 ^ 0x9C) <= 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllllIllIllIlIIlllI);
  }
  
  private static void lIlIllIlIlll()
  {
    llIllIIIlI = new String[llIllIIIll[1]];
    llIllIIIlI[llIllIIIll[0]] = lIlIllIlIllI("KSQzHzso", "OEPvU");
  }
  
  public boolean isFullCube()
  {
    return llIllIIIll[0];
  }
  
  public AxisAlignedBB getSelectedBoundingBox(World llllllllllllllllllIllIlllIllllll, BlockPos llllllllllllllllllIllIlllIlllllI)
  {
    ;
    ;
    ;
    llllllllllllllllllIllIlllIllllIl.setBlockBoundsBasedOnState(llllllllllllllllllIllIlllIllllII, llllllllllllllllllIllIlllIlllllI);
    return llllllllllllllllllIllIlllIllllIl.getSelectedBoundingBox(llllllllllllllllllIllIlllIllllII, llllllllllllllllllIllIlllIlllllI);
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllllllIllIllllIIlIlI, BlockPos llllllllllllllllllIllIllllIIlIIl, IBlockState llllllllllllllllllIllIllllIIlIII)
  {
    ;
    ;
    ;
    ;
    llllllllllllllllllIllIllllIIlIll.setBlockBoundsBasedOnState(llllllllllllllllllIllIllllIIlIlI, llllllllllllllllllIllIllllIIlIIl);
    return llllllllllllllllllIllIllllIIlIll.getCollisionBoundingBox(llllllllllllllllllIllIllllIIlIlI, llllllllllllllllllIllIllllIIlIIl, llllllllllllllllllIllIllllIIlIII);
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllllllIllIllIlIllllI, new IProperty[] { FACING });
  }
  
  public IBlockState onBlockPlaced(World llllllllllllllllllIllIlllIIIllll, BlockPos llllllllllllllllllIllIlllIIIlllI, EnumFacing llllllllllllllllllIllIlllIIllIII, float llllllllllllllllllIllIlllIIlIlll, float llllllllllllllllllIllIlllIIlIllI, float llllllllllllllllllIllIlllIIlIlIl, int llllllllllllllllllIllIlllIIlIlII, EntityLivingBase llllllllllllllllllIllIlllIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIlIllIllIlI(llllllllllllllllllIllIlllIIllIII.getAxis().isHorizontal())) && (lIlIllIllIlI(llllllllllllllllllIllIlllIIlIIII.canBlockStay(llllllllllllllllllIllIlllIIIllll, llllllllllllllllllIllIlllIIIlllI, llllllllllllllllllIllIlllIIllIII)))) {
      return llllllllllllllllllIllIlllIIlIIII.getDefaultState().withProperty(FACING, llllllllllllllllllIllIlllIIllIII);
    }
    Exception llllllllllllllllllIllIlllIIIlIll = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if (((0x56 ^ 0x1E) & (0xCE ^ 0x86 ^ 0xFFFFFFFF)) == " ".length()) {
      return null;
    }
    while (!lIlIllIllIll(llllllllllllllllllIllIlllIIIlIll.hasNext()))
    {
      Object llllllllllllllllllIllIlllIIlIIlI = llllllllllllllllllIllIlllIIIlIll.next();
      EnumFacing llllllllllllllllllIllIlllIIlIIIl = (EnumFacing)llllllllllllllllllIllIlllIIlIIlI;
      if (lIlIllIllIlI(llllllllllllllllllIllIlllIIlIIII.canBlockStay(llllllllllllllllllIllIlllIIIllll, llllllllllllllllllIllIlllIIIlllI, llllllllllllllllllIllIlllIIlIIIl))) {
        return llllllllllllllllllIllIlllIIlIIII.getDefaultState().withProperty(FACING, llllllllllllllllllIllIlllIIlIIIl);
      }
    }
    return llllllllllllllllllIllIlllIIlIIII.getDefaultState();
  }
  
  protected boolean canBlockStay(World llllllllllllllllllIllIllIlllIIII, BlockPos llllllllllllllllllIllIllIllIllll, EnumFacing llllllllllllllllllIllIllIllIlllI)
  {
    ;
    ;
    ;
    return llllllllllllllllllIllIllIlllIIII.getBlockState(llllllllllllllllllIllIllIlllIIlI.offset(llllllllllllllllllIllIllIllIlllI.getOpposite())).getBlock().isNormalCube();
  }
  
  public boolean isOpaqueCube()
  {
    return llIllIIIll[0];
  }
  
  public boolean canPlaceBlockAt(World llllllllllllllllllIllIlllIlIIlII, BlockPos llllllllllllllllllIllIlllIlIIlIl)
  {
    ;
    ;
    if (lIlIllIllIlI(llllllllllllllllllIllIlllIlIIlII.getBlockState(llllllllllllllllllIllIlllIlIIlIl.west()).getBlock().isNormalCube()))
    {
      "".length();
      if (((0x26 ^ 0x79 ^ (0x44 ^ 0x76) & (0x92 ^ 0xA0 ^ 0xFFFFFFFF)) & (65 + 0 - -110 + 67 ^ '' + '' - 211 + 96 ^ -" ".length())) >= " ".length()) {
        return (0x51 ^ 0x31 ^ 0x39 ^ 0xB) & (112 + 18 - 119 + 199 ^ 65 + 8 - 21 + 76 ^ -" ".length());
      }
    }
    else if (lIlIllIllIlI(llllllllllllllllllIllIlllIlIIlII.getBlockState(llllllllllllllllllIllIlllIlIIlIl.east()).getBlock().isNormalCube()))
    {
      "".length();
      if (((0x7E ^ 0xC ^ 0xE8 ^ 0x94) & (0x61 ^ 0x6D ^ "  ".length() ^ -" ".length())) != 0) {
        return (0xA1 ^ 0x95 ^ 0x3D ^ 0x4A) & (0x77 ^ 0x1E ^ 0xB8 ^ 0x92 ^ -" ".length());
      }
    }
    else if (lIlIllIllIlI(llllllllllllllllllIllIlllIlIIlII.getBlockState(llllllllllllllllllIllIlllIlIIlIl.north()).getBlock().isNormalCube()))
    {
      "".length();
      if (" ".length() < "   ".length()) {
        break label326;
      }
      return (0x4E ^ 0x65) & (0x17 ^ 0x3C ^ 0xFFFFFFFF);
    }
    label326:
    return llllllllllllllllllIllIlllIlIIlII.getBlockState(llllllllllllllllllIllIlllIlIIlIl.south()).getBlock().isNormalCube();
  }
  
  private static boolean lIlIllIllIll(int ???)
  {
    int llllllllllllllllllIllIllIIllIlIl;
    return ??? == 0;
  }
  
  protected BlockLadder()
  {
    llllllllllllllllllIllIllllIlIIIl.<init>(Material.circuits);
    llllllllllllllllllIllIllllIlIIII.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
    "".length();
  }
  
  private static void lIlIllIllIII()
  {
    llIllIIIll = new int[7];
    llIllIIIll[0] = ((0x9C ^ 0x8D) & (0x13 ^ 0x2 ^ 0xFFFFFFFF));
    llIllIIIll[1] = " ".length();
    llIllIIIll[2] = (38 + 74 - 108 + 147 ^ 80 + 104 - 112 + 73);
    llIllIIIll[3] = "   ".length();
    llIllIIIll[4] = (0x12 ^ 0x16);
    llIllIIIll[5] = "  ".length();
    llIllIIIll[6] = (51 + 28 - 9 + 107 ^ 90 + 22 - 48 + 116);
  }
  
  private static boolean lIlIllIlllII(Object ???)
  {
    short llllllllllllllllllIllIllIIlllIIl;
    return ??? != null;
  }
  
  static
  {
    lIlIllIllIII();
    lIlIllIlIlll();
  }
  
  public int getMetaFromState(IBlockState llllllllllllllllllIllIllIllIIIII)
  {
    ;
    return ((EnumFacing)llllllllllllllllllIllIllIllIIIII.getValue(FACING)).getIndex();
  }
  
  private static boolean lIlIllIllIIl(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllllllIllIllIIlllIll;
    return ??? == localObject;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllllllIllIlllIllIlII, BlockPos llllllllllllllllllIllIlllIllIIll)
  {
    ;
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllllllIllIlllIllIIlI = llllllllllllllllllIllIlllIllIlII.getBlockState(llllllllllllllllllIllIlllIllIIll);
    if (lIlIllIllIIl(llllllllllllllllllIllIlllIllIIlI.getBlock(), llllllllllllllllllIllIlllIllIlIl))
    {
      float llllllllllllllllllIllIlllIllIIIl = 0.125F;
      switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[((EnumFacing)llllllllllllllllllIllIlllIllIIlI.getValue(FACING)).ordinal()])
      {
      case 3: 
        llllllllllllllllllIllIlllIllIlIl.setBlockBounds(0.0F, 0.0F, 1.0F - llllllllllllllllllIllIlllIllIIIl, 1.0F, 1.0F, 1.0F);
        "".length();
        if (null != null) {}
        break;
      case 4: 
        llllllllllllllllllIllIlllIllIlIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, llllllllllllllllllIllIlllIllIIIl);
        "".length();
        if ("  ".length() >= (16 + 47 - 62 + 128 ^ 78 + 34 - 49 + 70)) {}
        break;
      case 5: 
        llllllllllllllllllIllIlllIllIlIl.setBlockBounds(1.0F - llllllllllllllllllIllIlllIllIIIl, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        "".length();
        if (null != null) {}
        break;
      case 6: 
      default: 
        llllllllllllllllllIllIlllIllIlIl.setBlockBounds(0.0F, 0.0F, 0.0F, llllllllllllllllllIllIlllIllIIIl, 1.0F, 1.0F);
      }
    }
  }
}

package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;

public class BlockMelon
  extends Block
{
  public int quantityDropped(Random llllllllllllllllllIlIllIlIIlIlIl)
  {
    ;
    return llIlllIlll[0] + llllllllllllllllllIlIllIlIIlIlII.nextInt(llIlllIlll[1]);
  }
  
  protected BlockMelon()
  {
    llllllllllllllllllIlIllIlIIlllIl.<init>(Material.gourd, MapColor.limeColor);
    "".length();
  }
  
  static {}
  
  public Item getItemDropped(IBlockState llllllllllllllllllIlIllIlIIllIlI, Random llllllllllllllllllIlIllIlIIllIIl, int llllllllllllllllllIlIllIlIIllIII)
  {
    return Items.melon;
  }
  
  private static void lIllIIlIlIll()
  {
    llIlllIlll = new int[4];
    llIlllIlll[0] = "   ".length();
    llIlllIlll[1] = (0x72 ^ 0x77);
    llIlllIlll[2] = (0x3E ^ 0x37);
    llIlllIlll[3] = " ".length();
  }
  
  public int quantityDroppedWithBonus(int llllllllllllllllllIlIllIlIIIllII, Random llllllllllllllllllIlIllIlIIIlllI)
  {
    ;
    ;
    ;
    return Math.min(llIlllIlll[2], llllllllllllllllllIlIllIlIIIllIl.quantityDropped(llllllllllllllllllIlIllIlIIIlllI) + llllllllllllllllllIlIllIlIIIlllI.nextInt(llIlllIlll[3] + llllllllllllllllllIlIllIlIIIllll));
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;

public abstract class BlockRotatedPillar
  extends Block
{
  private static void lIllllIlllIIl()
  {
    llllIllIlII = new int[2];
    llllIllIlII[0] = ("  ".length() & ("  ".length() ^ -" ".length()));
    llllIllIlII[1] = " ".length();
  }
  
  private static String lIllllIllIlll(String llllllllllllllllIIIllIlIllIlllIl, String llllllllllllllllIIIllIlIllIlIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIIllIlIllIlllIl = new String(Base64.getDecoder().decode(llllllllllllllllIIIllIlIllIlllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIIIllIlIllIllIll = new StringBuilder();
    char[] llllllllllllllllIIIllIlIllIllIlI = llllllllllllllllIIIllIlIllIlIlll.toCharArray();
    int llllllllllllllllIIIllIlIllIllIIl = llllIllIlII[0];
    long llllllllllllllllIIIllIlIllIlIIll = llllllllllllllllIIIllIlIllIlllIl.toCharArray();
    boolean llllllllllllllllIIIllIlIllIlIIlI = llllllllllllllllIIIllIlIllIlIIll.length;
    short llllllllllllllllIIIllIlIllIlIIIl = llllIllIlII[0];
    while (lIllllIlllIlI(llllllllllllllllIIIllIlIllIlIIIl, llllllllllllllllIIIllIlIllIlIIlI))
    {
      char llllllllllllllllIIIllIlIllIllllI = llllllllllllllllIIIllIlIllIlIIll[llllllllllllllllIIIllIlIllIlIIIl];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIIIllIlIllIllIll);
  }
  
  protected BlockRotatedPillar(Material llllllllllllllllIIIllIlIlllIlIIl, MapColor llllllllllllllllIIIllIlIlllIlIll)
  {
    llllllllllllllllIIIllIlIlllIllIl.<init>(llllllllllllllllIIIllIlIlllIllII, llllllllllllllllIIIllIlIlllIlIll);
  }
  
  static
  {
    lIllllIlllIIl();
    lIllllIlllIII();
  }
  
  private static void lIllllIlllIII()
  {
    llllIllIIll = new String[llllIllIlII[1]];
    llllIllIIll[llllIllIlII[0]] = lIllllIllIlll("CC4FOQ==", "iVlJQ");
  }
  
  private static boolean lIllllIlllIlI(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllIIIllIlIllIIllII;
    return ??? < i;
  }
  
  protected BlockRotatedPillar(Material llllllllllllllllIIIllIlIllllIIll)
  {
    llllllllllllllllIIIllIlIllllIlII.<init>(llllllllllllllllIIIllIlIllllIIll, llllllllllllllllIIIllIlIllllIIll.getMaterialMapColor());
  }
}

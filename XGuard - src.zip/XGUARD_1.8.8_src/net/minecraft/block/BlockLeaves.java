package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.BlockPos.MutableBlockPos;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.ColorizerFoliage;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeColorHelper;

public abstract class BlockLeaves
  extends BlockLeavesBase
{
  private static boolean lIIlllIIIIIIII(Object ???, Object arg1)
  {
    Object localObject;
    short lllllllllllllllIIIlIIlIlIIlllllI;
    return ??? != localObject;
  }
  
  public void dropBlockAsItemWithChance(World lllllllllllllllIIIlIIlIllIIIllII, BlockPos lllllllllllllllIIIlIIlIllIIIlIll, IBlockState lllllllllllllllIIIlIIlIllIIIlIlI, float lllllllllllllllIIIlIIlIllIIlIIIl, int lllllllllllllllIIIlIIlIllIIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIllIllllllIl(isRemote))
    {
      int lllllllllllllllIIIlIIlIllIIIllll = lllllllllllllllIIIlIIlIllIIlIlIl.getSaplingDropChance(lllllllllllllllIIIlIIlIllIIIlIlI);
      if (lIIlllIIIIIIll(lllllllllllllllIIIlIIlIllIIlIIII))
      {
        lllllllllllllllIIIlIIlIllIIIllll -= (llIIllIIIIll[4] << lllllllllllllllIIIlIIlIllIIlIIII);
        if (lIIlllIIIIIlII(lllllllllllllllIIIlIIlIllIIIllll, llIIllIIIIll[9])) {
          lllllllllllllllIIIlIIlIllIIIllll = llIIllIIIIll[9];
        }
      }
      if (lIIllIllllllIl(rand.nextInt(lllllllllllllllIIIlIIlIllIIIllll)))
      {
        Item lllllllllllllllIIIlIIlIllIIIlllI = lllllllllllllllIIIlIIlIllIIlIlIl.getItemDropped(lllllllllllllllIIIlIIlIllIIIlIlI, rand, lllllllllllllllIIIlIIlIllIIlIIII);
        spawnAsEntity(lllllllllllllllIIIlIIlIllIIIllII, lllllllllllllllIIIlIIlIllIIIlIll, new ItemStack(lllllllllllllllIIIlIIlIllIIIlllI, llIIllIIIIll[1], lllllllllllllllIIIlIIlIllIIlIlIl.damageDropped(lllllllllllllllIIIlIIlIllIIIlIlI)));
      }
      lllllllllllllllIIIlIIlIllIIIllll = llIIllIIIIll[10];
      if (lIIlllIIIIIIll(lllllllllllllllIIIlIIlIllIIlIIII))
      {
        lllllllllllllllIIIlIIlIllIIIllll -= (llIIllIIIIll[9] << lllllllllllllllIIIlIIlIllIIlIIII);
        if (lIIlllIIIIIlII(lllllllllllllllIIIlIIlIllIIIllll, llIIllIIIIll[11])) {
          lllllllllllllllIIIlIIlIllIIIllll = llIIllIIIIll[11];
        }
      }
      lllllllllllllllIIIlIIlIllIIlIlIl.dropApple(lllllllllllllllIIIlIIlIllIIIllII, lllllllllllllllIIIlIIlIllIIIlIll, lllllllllllllllIIIlIIlIllIIIlIlI, lllllllllllllllIIIlIIlIllIIIllll);
    }
  }
  
  private static boolean lIIlllIIIIIIIl(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIIIlIIlIlIlIIlIlI;
    return ??? == i;
  }
  
  public int quantityDropped(Random lllllllllllllllIIIlIIlIllIlIIIlI)
  {
    ;
    if (lIIllIllllllIl(lllllllllllllllIIIlIIlIllIlIIIlI.nextInt(llIIllIIIIll[8])))
    {
      "".length();
      if (null == null) {
        break label81;
      }
      return (0x58 ^ 0x2F ^ 0x2 ^ 0x49) & (113 + 39 - 84 + 76 ^ '¤' + '' - 214 + 92 ^ -" ".length());
    }
    label81:
    return llIIllIIIIll[0];
  }
  
  private static boolean lIIlllIIIIIlII(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIIIlIIlIlIlIIIllI;
    return ??? < i;
  }
  
  private static boolean lIIllIlllllIll(int ???)
  {
    float lllllllllllllllIIIlIIlIlIIllIllI;
    return ??? != 0;
  }
  
  public BlockLeaves()
  {
    lllllllllllllllIIIlIIllIIIlIllIl.<init>(Material.leaves, llIIllIIIIll[0]);
    "".length();
    "".length();
    "".length();
    "".length();
    "".length();
  }
  
  private static boolean lIIllIllllllll(Object ???)
  {
    short lllllllllllllllIIIlIIlIlIIlllIII;
    return ??? == null;
  }
  
  public boolean isOpaqueCube()
  {
    ;
    if (lIIllIlllllIll(fancyGraphics))
    {
      "".length();
      if (((0x16 ^ 0x52) & (0x52 ^ 0x16 ^ 0xFFFFFFFF)) == ((0xF0 ^ 0xC7) & (0x29 ^ 0x1E ^ 0xFFFFFFFF))) {
        break label71;
      }
      return (0x66 ^ 0x58) & (0x37 ^ 0x9 ^ 0xFFFFFFFF);
    }
    label71:
    return llIIllIIIIll[1];
  }
  
  private static void lIIllIlllllIlI()
  {
    llIIllIIIIll = new int[13];
    llIIllIIIIll[0] = ((0x41 ^ 0x45 ^ 0xBA ^ 0xA7) & (0x37 ^ 0x16 ^ 0x51 ^ 0x69 ^ -" ".length()));
    llIIllIIIIll[1] = " ".length();
    llIIllIIIIll[2] = (0x18 ^ 0x1C);
    llIIllIIIIll[3] = (0xFB ^ 0xBD ^ 0xC9 ^ 0xAF);
    llIIllIIIIll[4] = "  ".length();
    llIIllIIIIll[5] = (-"  ".length());
    llIIllIIIIll[6] = (-" ".length());
    llIIllIIIIll[7] = (0x39 ^ 0x36);
    llIIllIIIIll[8] = (0x59 ^ 0x4D);
    llIIllIIIIll[9] = (0x86 ^ 0x8C);
    llIIllIIIIll[10] = (51 + 34 - 68 + 183);
    llIIllIIIIll[11] = (0x61 ^ 0x21 ^ 0x26 ^ 0x4E);
    llIIllIIIIll[12] = ("   ".length() ^ 0x33 ^ 0x38);
  }
  
  private static boolean lIIllIlllllllI(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIIIlIIlIlIlIIIIlI;
    return ??? > i;
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllIIIlIIlIllIIlllll, Random lllllllllllllllIIIlIIlIllIIllllI, int lllllllllllllllIIIlIIlIllIIlllIl)
  {
    return Item.getItemFromBlock(Blocks.sapling);
  }
  
  private static boolean lIIlllIIIIIIlI(int ???)
  {
    int lllllllllllllllIIIlIIlIlIIllIIlI;
    return ??? >= 0;
  }
  
  public void randomDisplayTick(World lllllllllllllllIIIlIIlIllIlllIlI, BlockPos lllllllllllllllIIIlIIlIllIlllIIl, IBlockState lllllllllllllllIIIlIIlIllIlllIII, Random lllllllllllllllIIIlIIlIllIllIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIIllIlllllIll(lllllllllllllllIIIlIIlIllIlllIlI.canLightningStrike(lllllllllllllllIIIlIIlIllIlllIIl.up()))) && (lIIllIllllllIl(World.doesBlockHaveSolidTopSurface(lllllllllllllllIIIlIIlIllIlllIlI, lllllllllllllllIIIlIIlIllIlllIIl.down()))) && (lIIlllIIIIIIIl(lllllllllllllllIIIlIIlIllIllIlll.nextInt(llIIllIIIIll[7]), llIIllIIIIll[1])))
    {
      double lllllllllllllllIIIlIIlIllIllIllI = lllllllllllllllIIIlIIlIllIlllIIl.getX() + lllllllllllllllIIIlIIlIllIllIlll.nextFloat();
      double lllllllllllllllIIIlIIlIllIllIlIl = lllllllllllllllIIIlIIlIllIlllIIl.getY() - 0.05D;
      double lllllllllllllllIIIlIIlIllIllIlII = lllllllllllllllIIIlIIlIllIlllIIl.getZ() + lllllllllllllllIIIlIIlIllIllIlll.nextFloat();
      lllllllllllllllIIIlIIlIllIlllIlI.spawnParticle(EnumParticleTypes.DRIP_WATER, lllllllllllllllIIIlIIlIllIllIllI, lllllllllllllllIIIlIIlIllIllIlIl, lllllllllllllllIIIlIIlIllIllIlII, 0.0D, 0.0D, 0.0D, new int[llIIllIIIIll[0]]);
    }
  }
  
  private static boolean lIIllIllllllIl(int ???)
  {
    double lllllllllllllllIIIlIIlIlIIllIlII;
    return ??? == 0;
  }
  
  public int getRenderColor(IBlockState lllllllllllllllIIIlIIllIIIlIlIIl)
  {
    return ColorizerFoliage.getFoliageColorBasic();
  }
  
  private void destroy(World lllllllllllllllIIIlIIlIllIlIlIIl, BlockPos lllllllllllllllIIIlIIlIllIlIlIII)
  {
    ;
    ;
    ;
    lllllllllllllllIIIlIIlIllIlIIlll.dropBlockAsItem(lllllllllllllllIIIlIIlIllIlIIllI, lllllllllllllllIIIlIIlIllIlIlIII, lllllllllllllllIIIlIIlIllIlIIllI.getBlockState(lllllllllllllllIIIlIIlIllIlIlIII), llIIllIIIIll[0]);
    "".length();
  }
  
  public void breakBlock(World lllllllllllllllIIIlIIllIIIIIIllI, BlockPos lllllllllllllllIIIlIIllIIIIlIIlI, IBlockState lllllllllllllllIIIlIIllIIIIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIIIlIIllIIIIlIIII = llIIllIIIIll[1];
    int lllllllllllllllIIIlIIllIIIIIllll = lllllllllllllllIIIlIIllIIIIlIIII + llIIllIIIIll[1];
    int lllllllllllllllIIIlIIllIIIIIlllI = lllllllllllllllIIIlIIllIIIIIIlIl.getX();
    int lllllllllllllllIIIlIIllIIIIIllIl = lllllllllllllllIIIlIIllIIIIIIlIl.getY();
    int lllllllllllllllIIIlIIllIIIIIllII = lllllllllllllllIIIlIIllIIIIIIlIl.getZ();
    if (lIIllIlllllIll(lllllllllllllllIIIlIIllIIIIIIllI.isAreaLoaded(new BlockPos(lllllllllllllllIIIlIIllIIIIIlllI - lllllllllllllllIIIlIIllIIIIIllll, lllllllllllllllIIIlIIllIIIIIllIl - lllllllllllllllIIIlIIllIIIIIllll, lllllllllllllllIIIlIIllIIIIIllII - lllllllllllllllIIIlIIllIIIIIllll), new BlockPos(lllllllllllllllIIIlIIllIIIIIlllI + lllllllllllllllIIIlIIllIIIIIllll, lllllllllllllllIIIlIIllIIIIIllIl + lllllllllllllllIIIlIIllIIIIIllll, lllllllllllllllIIIlIIllIIIIIllII + lllllllllllllllIIIlIIllIIIIIllll))))
    {
      int lllllllllllllllIIIlIIllIIIIIlIll = -lllllllllllllllIIIlIIllIIIIlIIII;
      "".length();
      if ((0xAD ^ 0xA9) < " ".length()) {
        return;
      }
      while (!lIIllIlllllllI(lllllllllllllllIIIlIIllIIIIIlIll, lllllllllllllllIIIlIIllIIIIlIIII))
      {
        int lllllllllllllllIIIlIIllIIIIIlIlI = -lllllllllllllllIIIlIIllIIIIlIIII;
        "".length();
        if ("  ".length() == 0) {
          return;
        }
        while (!lIIllIlllllllI(lllllllllllllllIIIlIIllIIIIIlIlI, lllllllllllllllIIIlIIllIIIIlIIII))
        {
          int lllllllllllllllIIIlIIllIIIIIlIIl = -lllllllllllllllIIIlIIllIIIIlIIII;
          "".length();
          if (" ".length() < ((0xA7 ^ 0xC4) & (0x0 ^ 0x63 ^ 0xFFFFFFFF))) {
            return;
          }
          while (!lIIllIlllllllI(lllllllllllllllIIIlIIllIIIIIlIIl, lllllllllllllllIIIlIIllIIIIlIIII))
          {
            BlockPos lllllllllllllllIIIlIIllIIIIIlIII = lllllllllllllllIIIlIIllIIIIIIlIl.add(lllllllllllllllIIIlIIllIIIIIlIll, lllllllllllllllIIIlIIllIIIIIlIlI, lllllllllllllllIIIlIIllIIIIIlIIl);
            IBlockState lllllllllllllllIIIlIIllIIIIIIlll = lllllllllllllllIIIlIIllIIIIIIllI.getBlockState(lllllllllllllllIIIlIIllIIIIIlIII);
            if ((lIIllIllllllII(lllllllllllllllIIIlIIllIIIIIIlll.getBlock().getMaterial(), Material.leaves)) && (lIIllIllllllIl(((Boolean)lllllllllllllllIIIlIIllIIIIIIlll.getValue(CHECK_DECAY)).booleanValue()))) {
              "".length();
            }
            lllllllllllllllIIIlIIllIIIIIlIIl++;
          }
        }
      }
    }
  }
  
  public abstract BlockPlanks.EnumType getWoodType(int paramInt);
  
  public int colorMultiplier(IBlockAccess lllllllllllllllIIIlIIllIIIlIIlIl, BlockPos lllllllllllllllIIIlIIllIIIlIIlII, int lllllllllllllllIIIlIIllIIIlIIIll)
  {
    ;
    ;
    return BiomeColorHelper.getFoliageColorAtPos(lllllllllllllllIIIlIIllIIIlIIlIl, lllllllllllllllIIIlIIllIIIlIIIIl);
  }
  
  public void updateTick(World lllllllllllllllIIIlIIlIllllIlIII, BlockPos lllllllllllllllIIIlIIlIlllIlIIII, IBlockState lllllllllllllllIIIlIIlIlllIIllll, Random lllllllllllllllIIIlIIlIllllIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIIllIllllllIl(isRemote)) && (lIIllIlllllIll(((Boolean)lllllllllllllllIIIlIIlIlllIIllll.getValue(CHECK_DECAY)).booleanValue())) && (lIIllIlllllIll(((Boolean)lllllllllllllllIIIlIIlIlllIIllll.getValue(DECAYABLE)).booleanValue())))
    {
      int lllllllllllllllIIIlIIlIllllIIlII = llIIllIIIIll[2];
      int lllllllllllllllIIIlIIlIllllIIIll = lllllllllllllllIIIlIIlIllllIIlII + llIIllIIIIll[1];
      int lllllllllllllllIIIlIIlIllllIIIlI = lllllllllllllllIIIlIIlIllllIIlll.getX();
      int lllllllllllllllIIIlIIlIllllIIIIl = lllllllllllllllIIIlIIlIllllIIlll.getY();
      int lllllllllllllllIIIlIIlIllllIIIII = lllllllllllllllIIIlIIlIllllIIlll.getZ();
      int lllllllllllllllIIIlIIlIlllIlllll = llIIllIIIIll[3];
      int lllllllllllllllIIIlIIlIlllIllllI = lllllllllllllllIIIlIIlIlllIlllll * lllllllllllllllIIIlIIlIlllIlllll;
      int lllllllllllllllIIIlIIlIlllIlllIl = lllllllllllllllIIIlIIlIlllIlllll / llIIllIIIIll[4];
      if (lIIllIllllllll(surroundings)) {
        surroundings = new int[lllllllllllllllIIIlIIlIlllIlllll * lllllllllllllllIIIlIIlIlllIlllll * lllllllllllllllIIIlIIlIlllIlllll];
      }
      if (lIIllIlllllIll(lllllllllllllllIIIlIIlIllllIlIII.isAreaLoaded(new BlockPos(lllllllllllllllIIIlIIlIllllIIIlI - lllllllllllllllIIIlIIlIllllIIIll, lllllllllllllllIIIlIIlIllllIIIIl - lllllllllllllllIIIlIIlIllllIIIll, lllllllllllllllIIIlIIlIllllIIIII - lllllllllllllllIIIlIIlIllllIIIll), new BlockPos(lllllllllllllllIIIlIIlIllllIIIlI + lllllllllllllllIIIlIIlIllllIIIll, lllllllllllllllIIIlIIlIllllIIIIl + lllllllllllllllIIIlIIlIllllIIIll, lllllllllllllllIIIlIIlIllllIIIII + lllllllllllllllIIIlIIlIllllIIIll))))
      {
        BlockPos.MutableBlockPos lllllllllllllllIIIlIIlIlllIlllII = new BlockPos.MutableBlockPos();
        int lllllllllllllllIIIlIIlIlllIllIll = -lllllllllllllllIIIlIIlIllllIIlII;
        "".length();
        if ("   ".length() != "   ".length()) {
          return;
        }
        while (!lIIllIlllllllI(lllllllllllllllIIIlIIlIlllIllIll, lllllllllllllllIIIlIIlIllllIIlII))
        {
          int lllllllllllllllIIIlIIlIlllIllIlI = -lllllllllllllllIIIlIIlIllllIIlII;
          "".length();
          if (-" ".length() > (('' + 86 - 120 + 86 ^ 73 + '' - 80 + 69) & (0xEE ^ 0x82 ^ 0x79 ^ 0x12 ^ -" ".length()))) {
            return;
          }
          while (!lIIllIlllllllI(lllllllllllllllIIIlIIlIlllIllIlI, lllllllllllllllIIIlIIlIllllIIlII))
          {
            int lllllllllllllllIIIlIIlIlllIllIIl = -lllllllllllllllIIIlIIlIllllIIlII;
            "".length();
            if ((('¶' + 91 - 236 + 148 ^ 126 + 60 - 94 + 53) & (0xE4 ^ 0xB2 ^ 0xBA ^ 0xC4 ^ -" ".length())) != ((121 + '' - 262 + 203 ^ 34 + 103 - 44 + 44) & (0x2E ^ 0x52 ^ 0x55 ^ 0x6C ^ -" ".length()))) {
              return;
            }
            while (!lIIllIlllllllI(lllllllllllllllIIIlIIlIlllIllIIl, lllllllllllllllIIIlIIlIllllIIlII))
            {
              Block lllllllllllllllIIIlIIlIlllIllIII = lllllllllllllllIIIlIIlIllllIlIII.getBlockState(lllllllllllllllIIIlIIlIlllIlllII.func_181079_c(lllllllllllllllIIIlIIlIllllIIIlI + lllllllllllllllIIIlIIlIlllIllIll, lllllllllllllllIIIlIIlIllllIIIIl + lllllllllllllllIIIlIIlIlllIllIlI, lllllllllllllllIIIlIIlIllllIIIII + lllllllllllllllIIIlIIlIlllIllIIl)).getBlock();
              if ((lIIlllIIIIIIII(lllllllllllllllIIIlIIlIlllIllIII, Blocks.log)) && (lIIlllIIIIIIII(lllllllllllllllIIIlIIlIlllIllIII, Blocks.log2)))
              {
                if (lIIllIllllllII(lllllllllllllllIIIlIIlIlllIllIII.getMaterial(), Material.leaves))
                {
                  surroundings[((lllllllllllllllIIIlIIlIlllIllIll + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIllIlI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIllIIl + lllllllllllllllIIIlIIlIlllIlllIl)] = llIIllIIIIll[5];
                  "".length();
                  if (" ".length() != 0) {}
                }
                else
                {
                  surroundings[((lllllllllllllllIIIlIIlIlllIllIll + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIllIlI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIllIIl + lllllllllllllllIIIlIIlIlllIlllIl)] = llIIllIIIIll[6];
                  "".length();
                  if (" ".length() > 0) {}
                }
              }
              else {
                surroundings[((lllllllllllllllIIIlIIlIlllIllIll + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIllIlI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIllIIl + lllllllllllllllIIIlIIlIlllIlllIl)] = llIIllIIIIll[0];
              }
              lllllllllllllllIIIlIIlIlllIllIIl++;
            }
            lllllllllllllllIIIlIIlIlllIllIlI++;
          }
          lllllllllllllllIIIlIIlIlllIllIll++;
        }
        int lllllllllllllllIIIlIIlIlllIlIlll = llIIllIIIIll[1];
        "".length();
        if (-(0xC6 ^ 0xC2) >= 0) {
          return;
        }
        while (!lIIllIlllllllI(lllllllllllllllIIIlIIlIlllIlIlll, llIIllIIIIll[2]))
        {
          int lllllllllllllllIIIlIIlIlllIlIllI = -lllllllllllllllIIIlIIlIllllIIlII;
          "".length();
          if ("   ".length() != "   ".length()) {
            return;
          }
          while (!lIIllIlllllllI(lllllllllllllllIIIlIIlIlllIlIllI, lllllllllllllllIIIlIIlIllllIIlII))
          {
            int lllllllllllllllIIIlIIlIlllIlIlIl = -lllllllllllllllIIIlIIlIllllIIlII;
            "".length();
            if ("   ".length() <= -" ".length()) {
              return;
            }
            while (!lIIllIlllllllI(lllllllllllllllIIIlIIlIlllIlIlIl, lllllllllllllllIIIlIIlIllllIIlII))
            {
              int lllllllllllllllIIIlIIlIlllIlIlII = -lllllllllllllllIIIlIIlIllllIIlII;
              "".length();
              if ("  ".length() == -" ".length()) {
                return;
              }
              while (!lIIllIlllllllI(lllllllllllllllIIIlIIlIlllIlIlII, lllllllllllllllIIIlIIlIllllIIlII))
              {
                if (lIIlllIIIIIIIl(surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl)], lllllllllllllllIIIlIIlIlllIlIlll - llIIllIIIIll[1]))
                {
                  if (lIIlllIIIIIIIl(surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl - llIIllIIIIll[1]) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl)], llIIllIIIIll[5])) {
                    surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl - llIIllIIIIll[1]) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl)] = lllllllllllllllIIIlIIlIlllIlIlll;
                  }
                  if (lIIlllIIIIIIIl(surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl + llIIllIIIIll[1]) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl)], llIIllIIIIll[5])) {
                    surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl + llIIllIIIIll[1]) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl)] = lllllllllllllllIIIlIIlIlllIlIlll;
                  }
                  if (lIIlllIIIIIIIl(surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl - llIIllIIIIll[1]) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl)], llIIllIIIIll[5])) {
                    surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl - llIIllIIIIll[1]) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl)] = lllllllllllllllIIIlIIlIlllIlIlll;
                  }
                  if (lIIlllIIIIIIIl(surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl + llIIllIIIIll[1]) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl)], llIIllIIIIll[5])) {
                    surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl + llIIllIIIIll[1]) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl)] = lllllllllllllllIIIlIIlIlllIlIlll;
                  }
                  if (lIIlllIIIIIIIl(surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + (lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl - llIIllIIIIll[1]))], llIIllIIIIll[5])) {
                    surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + (lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl - llIIllIIIIll[1]))] = lllllllllllllllIIIlIIlIlllIlIlll;
                  }
                  if (lIIlllIIIIIIIl(surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl + llIIllIIIIll[1])], llIIllIIIIll[5])) {
                    surroundings[((lllllllllllllllIIIlIIlIlllIlIllI + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIllllI + (lllllllllllllllIIIlIIlIlllIlIlIl + lllllllllllllllIIIlIIlIlllIlllIl) * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlIlII + lllllllllllllllIIIlIIlIlllIlllIl + llIIllIIIIll[1])] = lllllllllllllllIIIlIIlIlllIlIlll;
                  }
                }
                lllllllllllllllIIIlIIlIlllIlIlII++;
              }
              lllllllllllllllIIIlIIlIlllIlIlIl++;
            }
            lllllllllllllllIIIlIIlIlllIlIllI++;
          }
          lllllllllllllllIIIlIIlIlllIlIlll++;
        }
      }
      int lllllllllllllllIIIlIIlIlllIlIIll = surroundings[(lllllllllllllllIIIlIIlIlllIlllIl * lllllllllllllllIIIlIIlIlllIllllI + lllllllllllllllIIIlIIlIlllIlllIl * lllllllllllllllIIIlIIlIlllIlllll + lllllllllllllllIIIlIIlIlllIlllIl)];
      if (lIIlllIIIIIIlI(lllllllllllllllIIIlIIlIlllIlIIll))
      {
        "".length();
        "".length();
        if ((0x65 ^ 0x2 ^ 0x66 ^ 0x5) > ((0x51 ^ 0x15 ^ 0x28 ^ 0xC) & (74 + 115 - 182 + 201 ^ 51 + '' - 148 + 121 ^ -" ".length()))) {}
      }
      else
      {
        lllllllllllllllIIIlIIlIlllIlIIlI.destroy(lllllllllllllllIIIlIIlIllllIlIII, lllllllllllllllIIIlIIlIllllIIlll);
      }
    }
  }
  
  private static String lIIllIllllIlII(String lllllllllllllllIIIlIIlIlIllIlIIl, String lllllllllllllllIIIlIIlIlIllIlIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIIlIIlIlIllIlllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIlIIlIlIllIlIlI.getBytes(StandardCharsets.UTF_8)), llIIllIIIIll[12]), "DES");
      Cipher lllllllllllllllIIIlIIlIlIllIllIl = Cipher.getInstance("DES");
      lllllllllllllllIIIlIIlIlIllIllIl.init(llIIllIIIIll[4], lllllllllllllllIIIlIIlIlIllIlllI);
      return new String(lllllllllllllllIIIlIIlIlIllIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIlIIlIlIllIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIIlIIlIlIllIllII)
    {
      lllllllllllllllIIIlIIlIlIllIllII.printStackTrace();
    }
    return null;
  }
  
  protected int getSaplingDropChance(IBlockState lllllllllllllllIIIlIIlIllIIIIIII)
  {
    return llIIllIIIIll[8];
  }
  
  public boolean isVisuallyOpaque()
  {
    return llIIllIIIIll[0];
  }
  
  private static String lIIllIllllIIll(String lllllllllllllllIIIlIIlIlIlIllIll, String lllllllllllllllIIIlIIlIlIlIlIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIlIIlIlIlIllIll = new String(Base64.getDecoder().decode(lllllllllllllllIIIlIIlIlIlIllIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIIlIIlIlIlIllIIl = new StringBuilder();
    char[] lllllllllllllllIIIlIIlIlIlIllIII = lllllllllllllllIIIlIIlIlIlIlIlIl.toCharArray();
    int lllllllllllllllIIIlIIlIlIlIlIlll = llIIllIIIIll[0];
    char lllllllllllllllIIIlIIlIlIlIlIIIl = lllllllllllllllIIIlIIlIlIlIllIll.toCharArray();
    boolean lllllllllllllllIIIlIIlIlIlIlIIII = lllllllllllllllIIIlIIlIlIlIlIIIl.length;
    byte lllllllllllllllIIIlIIlIlIlIIllll = llIIllIIIIll[0];
    while (lIIlllIIIIIlII(lllllllllllllllIIIlIIlIlIlIIllll, lllllllllllllllIIIlIIlIlIlIlIIII))
    {
      char lllllllllllllllIIIlIIlIlIlIlllII = lllllllllllllllIIIlIIlIlIlIlIIIl[lllllllllllllllIIIlIIlIlIlIIllll];
      "".length();
      "".length();
      if (" ".length() != " ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIIlIIlIlIlIllIIl);
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    ;
    if (lIIllIlllllIll(isTransparent))
    {
      "".length();
      if (-" ".length() <= " ".length()) {
        break label38;
      }
      return null;
    }
    label38:
    return EnumWorldBlockLayer.SOLID;
  }
  
  protected void dropApple(World lllllllllllllllIIIlIIlIllIIIIlIl, BlockPos lllllllllllllllIIIlIIlIllIIIIlII, IBlockState lllllllllllllllIIIlIIlIllIIIIIll, int lllllllllllllllIIIlIIlIllIIIIIlI) {}
  
  static
  {
    lIIllIlllllIlI();
    lIIllIllllIlIl();
  }
  
  private static boolean lIIlllIIIIIIll(int ???)
  {
    float lllllllllllllllIIIlIIlIlIIllIIII;
    return ??? > 0;
  }
  
  private static void lIIllIllllIlIl()
  {
    llIIllIIIIIl = new String[llIIllIIIIll[4]];
    llIIllIIIIIl[llIIllIIIIll[0]] = lIIllIllllIIll("Nx0ZFzQyGhYT", "SxzvM");
    llIIllIIIIIl[llIIllIIIIll[1]] = lIIllIllllIlII("SoFrppo6lQ4wfkLUr7pY0Q==", "EeDbA");
  }
  
  private static boolean lIIllIllllllII(Object ???, Object arg1)
  {
    Object localObject;
    float lllllllllllllllIIIlIIlIlIIlllIlI;
    return ??? == localObject;
  }
  
  public int getBlockColor()
  {
    return ColorizerFoliage.getFoliageColor(0.5D, 1.0D);
  }
  
  public void setGraphicsLevel(boolean lllllllllllllllIIIlIIlIlIllllIIl)
  {
    ;
    ;
    isTransparent = lllllllllllllllIIIlIIlIlIllllIIl;
    fancyGraphics = lllllllllllllllIIIlIIlIlIllllIIl;
    if (lIIllIlllllIll(lllllllllllllllIIIlIIlIlIllllIIl))
    {
      "".length();
      if ((0x4A ^ 0x12 ^ 0x3E ^ 0x63) != 0) {
        break label49;
      }
    }
    label49:
    llIIllIIIIll0iconIndex = llIIllIIIIll[1];
  }
}

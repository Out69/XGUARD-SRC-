package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.InventoryEnderChest;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class BlockEnderChest
  extends BlockContainer
{
  private static void llIlIIlIllll()
  {
    lIIIIlIIIIl = new int[5];
    lIIIIlIIIIl[0] = ((0x57 ^ 0x6B ^ 0x59 ^ 0x36) & (28 + 126 - -32 + 21 ^ 88 + 5 - 5 + 68 ^ -" ".length()));
    lIIIIlIIIIl[1] = "  ".length();
    lIIIIlIIIIl[2] = (0x4D ^ 0x45);
    lIIIIlIIIIl[3] = " ".length();
    lIIIIlIIIIl[4] = "   ".length();
  }
  
  public boolean isFullCube()
  {
    return lIIIIlIIIIl[0];
  }
  
  static
  {
    llIlIIlIllll();
    llIlIIlIlllI();
  }
  
  private static boolean llIlIIllIIlI(int ???, int arg1)
  {
    int i;
    long lllllllllllllllllIlllIIlIlllIlll;
    return ??? >= i;
  }
  
  public TileEntity createNewTileEntity(World lllllllllllllllllIlllIIlllIIlIlI, int lllllllllllllllllIlllIIlllIIlIIl)
  {
    return new TileEntityEnderChest();
  }
  
  protected BlockEnderChest()
  {
    lllllllllllllllllIlllIlIIIIIIlll.<init>(Material.rock);
    lllllllllllllllllIlllIlIIIIIIllI.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
    "".length();
    lllllllllllllllllIlllIlIIIIIIllI.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
  }
  
  private static void llIlIIlIlllI()
  {
    lIIIIlIIIII = new String[lIIIIlIIIIl[3]];
    lIIIIlIIIII[lIIIIlIIIIl[0]] = llIlIIlIllIl("Mjc2JQAz", "TVULn");
  }
  
  public IBlockState onBlockPlaced(World lllllllllllllllllIlllIIllllllIII, BlockPos lllllllllllllllllIlllIIlllllIlll, EnumFacing lllllllllllllllllIlllIIlllllIllI, float lllllllllllllllllIlllIIlllllIlIl, float lllllllllllllllllIlllIIlllllIlII, float lllllllllllllllllIlllIIlllllIIll, int lllllllllllllllllIlllIIlllllIIlI, EntityLivingBase lllllllllllllllllIlllIIlllllIIIl)
  {
    ;
    ;
    return lllllllllllllllllIlllIIlllllIIII.getDefaultState().withProperty(FACING, lllllllllllllllllIlllIIlllllIIIl.getHorizontalFacing().getOpposite());
  }
  
  private static boolean llIlIIllIIII(Object ???)
  {
    double lllllllllllllllllIlllIIlIlllIIIl;
    return ??? != null;
  }
  
  public void onBlockPlacedBy(World lllllllllllllllllIlllIIllllIlIIl, BlockPos lllllllllllllllllIlllIIllllIIIll, IBlockState lllllllllllllllllIlllIIllllIIlll, EntityLivingBase lllllllllllllllllIlllIIllllIIllI, ItemStack lllllllllllllllllIlllIIllllIIlIl)
  {
    ;
    ;
    ;
    ;
    "".length();
  }
  
  public int getRenderType()
  {
    return lIIIIlIIIIl[1];
  }
  
  public boolean onBlockActivated(World lllllllllllllllllIlllIIlllIlIIII, BlockPos lllllllllllllllllIlllIIlllIIllll, IBlockState lllllllllllllllllIlllIIlllIllIII, EntityPlayer lllllllllllllllllIlllIIlllIlIlll, EnumFacing lllllllllllllllllIlllIIlllIlIllI, float lllllllllllllllllIlllIIlllIlIlIl, float lllllllllllllllllIlllIIlllIlIlII, float lllllllllllllllllIlllIIlllIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    InventoryEnderChest lllllllllllllllllIlllIIlllIlIIlI = lllllllllllllllllIlllIIlllIlIlll.getInventoryEnderChest();
    TileEntity lllllllllllllllllIlllIIlllIlIIIl = lllllllllllllllllIlllIIlllIlIIII.getTileEntity(lllllllllllllllllIlllIIlllIIllll);
    if ((llIlIIllIIII(lllllllllllllllllIlllIIlllIlIIlI)) && (llIlIIllIIIl(lllllllllllllllllIlllIIlllIlIIIl instanceof TileEntityEnderChest)))
    {
      if (llIlIIllIIIl(lllllllllllllllllIlllIIlllIlIIII.getBlockState(lllllllllllllllllIlllIIlllIIllll.up()).getBlock().isNormalCube())) {
        return lIIIIlIIIIl[3];
      }
      if (llIlIIllIIIl(isRemote)) {
        return lIIIIlIIIIl[3];
      }
      lllllllllllllllllIlllIIlllIlIIlI.setChestTileEntity((TileEntityEnderChest)lllllllllllllllllIlllIIlllIlIIIl);
      lllllllllllllllllIlllIIlllIlIlll.displayGUIChest(lllllllllllllllllIlllIIlllIlIIlI);
      lllllllllllllllllIlllIIlllIlIlll.triggerAchievement(StatList.field_181738_V);
      return lIIIIlIIIIl[3];
    }
    return lIIIIlIIIIl[3];
  }
  
  private static boolean llIlIIllIlII(int ???, int arg1)
  {
    int i;
    float lllllllllllllllllIlllIIlIlllIIll;
    return ??? < i;
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllllIlllIlIIIIIIIIl, Random lllllllllllllllllIlllIlIIIIIIIII, int lllllllllllllllllIlllIIlllllllll)
  {
    return Item.getItemFromBlock(Blocks.obsidian);
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllllIlllIIllIIlIllI)
  {
    ;
    return ((EnumFacing)lllllllllllllllllIlllIIllIIlIllI.getValue(FACING)).getIndex();
  }
  
  protected boolean canSilkHarvest()
  {
    return lIIIIlIIIIl[3];
  }
  
  public void randomDisplayTick(World lllllllllllllllllIlllIIllIlIllIl, BlockPos lllllllllllllllllIlllIIllIlIllII, IBlockState lllllllllllllllllIlllIIllIlllIIl, Random lllllllllllllllllIlllIIllIlIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllllIlllIIllIllIlll = lIIIIlIIIIl[0];
    "".length();
    if (((0x5F ^ 0x55 ^ 0x70 ^ 0x20) & ('á' + 4 - 100 + 109 ^ '­' + 29 - 139 + 117 ^ -" ".length())) != 0) {
      return;
    }
    while (!llIlIIllIIlI(lllllllllllllllllIlllIIllIllIlll, lIIIIlIIIIl[4]))
    {
      int lllllllllllllllllIlllIIllIllIllI = lllllllllllllllllIlllIIllIlIlIlI.nextInt(lIIIIlIIIIl[1]) * lIIIIlIIIIl[1] - lIIIIlIIIIl[3];
      int lllllllllllllllllIlllIIllIllIlIl = lllllllllllllllllIlllIIllIlIlIlI.nextInt(lIIIIlIIIIl[1]) * lIIIIlIIIIl[1] - lIIIIlIIIIl[3];
      double lllllllllllllllllIlllIIllIllIlII = lllllllllllllllllIlllIIllIlIllII.getX() + 0.5D + 0.25D * lllllllllllllllllIlllIIllIllIllI;
      double lllllllllllllllllIlllIIllIllIIll = lllllllllllllllllIlllIIllIlIllII.getY() + lllllllllllllllllIlllIIllIlIlIlI.nextFloat();
      double lllllllllllllllllIlllIIllIllIIlI = lllllllllllllllllIlllIIllIlIllII.getZ() + 0.5D + 0.25D * lllllllllllllllllIlllIIllIllIlIl;
      double lllllllllllllllllIlllIIllIllIIIl = lllllllllllllllllIlllIIllIlIlIlI.nextFloat() * lllllllllllllllllIlllIIllIllIllI;
      double lllllllllllllllllIlllIIllIllIIII = (lllllllllllllllllIlllIIllIlIlIlI.nextFloat() - 0.5D) * 0.125D;
      double lllllllllllllllllIlllIIllIlIllll = lllllllllllllllllIlllIIllIlIlIlI.nextFloat() * lllllllllllllllllIlllIIllIllIlIl;
      lllllllllllllllllIlllIIllIlIllIl.spawnParticle(EnumParticleTypes.PORTAL, lllllllllllllllllIlllIIllIllIlII, lllllllllllllllllIlllIIllIllIIll, lllllllllllllllllIlllIIllIllIIlI, lllllllllllllllllIlllIIllIllIIIl, lllllllllllllllllIlllIIllIllIIII, lllllllllllllllllIlllIIllIlIllll, new int[lIIIIlIIIIl[0]]);
      lllllllllllllllllIlllIIllIllIlll++;
    }
  }
  
  public boolean isOpaqueCube()
  {
    return lIIIIlIIIIl[0];
  }
  
  private static boolean llIlIIllIIIl(int ???)
  {
    char lllllllllllllllllIlllIIlIllIlIll;
    return ??? != 0;
  }
  
  private static boolean llIlIIllIIll(Object ???, Object arg1)
  {
    Object localObject;
    long lllllllllllllllllIlllIIlIllIllIl;
    return ??? == localObject;
  }
  
  public int quantityDropped(Random lllllllllllllllllIlllIIlllllllIl)
  {
    return lIIIIlIIIIl[2];
  }
  
  private static String llIlIIlIllIl(String lllllllllllllllllIlllIIllIIIlIII, String lllllllllllllllllIlllIIllIIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIlllIIllIIIlIII = new String(Base64.getDecoder().decode(lllllllllllllllllIlllIIllIIIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIlllIIllIIIIllI = new StringBuilder();
    char[] lllllllllllllllllIlllIIllIIIIlIl = lllllllllllllllllIlllIIllIIIIlll.toCharArray();
    int lllllllllllllllllIlllIIllIIIIlII = lIIIIlIIIIl[0];
    boolean lllllllllllllllllIlllIIlIllllllI = lllllllllllllllllIlllIIllIIIlIII.toCharArray();
    long lllllllllllllllllIlllIIlIlllllIl = lllllllllllllllllIlllIIlIllllllI.length;
    byte lllllllllllllllllIlllIIlIlllllII = lIIIIlIIIIl[0];
    while (llIlIIllIlII(lllllllllllllllllIlllIIlIlllllII, lllllllllllllllllIlllIIlIlllllIl))
    {
      char lllllllllllllllllIlllIIllIIIlIIl = lllllllllllllllllIlllIIlIllllllI[lllllllllllllllllIlllIIlIlllllII];
      "".length();
      "".length();
      if (((0x52 ^ 0x70) & (0xA4 ^ 0x86 ^ 0xFFFFFFFF)) > 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIlllIIllIIIIllI);
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllllIlllIIllIIlIIll, new IProperty[] { FACING });
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllllIlllIIllIIllllI)
  {
    ;
    ;
    ;
    EnumFacing lllllllllllllllllIlllIIllIIlllIl = EnumFacing.getFront(lllllllllllllllllIlllIIllIIllllI);
    if (llIlIIllIIll(lllllllllllllllllIlllIIllIIlllIl.getAxis(), EnumFacing.Axis.Y)) {
      lllllllllllllllllIlllIIllIIlllIl = EnumFacing.NORTH;
    }
    return lllllllllllllllllIlllIIllIIlllII.getDefaultState().withProperty(FACING, lllllllllllllllllIlllIIllIIlllIl);
  }
}

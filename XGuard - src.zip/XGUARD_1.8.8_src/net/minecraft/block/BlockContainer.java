package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public abstract class BlockContainer
  extends Block
  implements ITileEntityProvider
{
  private static void llIIlIlIlIllI()
  {
    lIIIIIllIIIl = new int[3];
    lIIIIIllIIIl[0] = " ".length();
    lIIIIIllIIIl[1] = ((93 + 75 - 96 + 58 ^ 114 + 4 - 11 + 72) & (69 + '' - 156 + 198 ^ 13 + 'ª' - -7 + 5 ^ -" ".length()));
    lIIIIIllIIIl[2] = (-" ".length());
  }
  
  protected boolean func_181086_a(World lllllllllllllllIlllllllIlIllIlII, BlockPos lllllllllllllllIlllllllIlIllIIll, EnumFacing lllllllllllllllIlllllllIlIllIIlI)
  {
    ;
    ;
    ;
    if (llIIlIlIlIlll(lllllllllllllllIlllllllIlIllIlII.getBlockState(lllllllllllllllIlllllllIlIllIllI.offset(lllllllllllllllIlllllllIlIllIIlI)).getBlock().getMaterial(), Material.cactus)) {
      return lIIIIIllIIIl[0];
    }
    return lIIIIIllIIIl[1];
  }
  
  protected BlockContainer(Material lllllllllllllllIlllllllIllIIIlll)
  {
    lllllllllllllllIlllllllIllIIlIII.<init>(lllllllllllllllIlllllllIllIIIlll, lllllllllllllllIlllllllIllIIIlll.getMaterialMapColor());
  }
  
  static {}
  
  public boolean onBlockEventReceived(World lllllllllllllllIlllllllIlIIIllII, BlockPos lllllllllllllllIlllllllIlIIlIIlI, IBlockState lllllllllllllllIlllllllIlIIlIIIl, int lllllllllllllllIlllllllIlIIIlIIl, int lllllllllllllllIlllllllIlIIIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    "".length();
    TileEntity lllllllllllllllIlllllllIlIIIlllI = lllllllllllllllIlllllllIlIIIllII.getTileEntity(lllllllllllllllIlllllllIlIIlIIlI);
    if (llIIlIlIllIIl(lllllllllllllllIlllllllIlIIIlllI))
    {
      "".length();
      if (-" ".length() < " ".length()) {
        break label80;
      }
      return (0x4D ^ 0xE) & (0x70 ^ 0x33 ^ 0xFFFFFFFF);
    }
    label80:
    return lllllllllllllllIlllllllIlIIIlllI.receiveClientEvent(lllllllllllllllIlllllllIlIIIlIIl, lllllllllllllllIlllllllIlIIIlIII);
  }
  
  protected BlockContainer(Material lllllllllllllllIlllllllIlIllllIl, MapColor lllllllllllllllIlllllllIlIllllII)
  {
    lllllllllllllllIlllllllIlIlllllI.<init>(lllllllllllllllIlllllllIllIIIIII, lllllllllllllllIlllllllIlIllllII);
    isBlockContainer = lIIIIIllIIIl[0];
  }
  
  private static boolean llIIlIlIllIIl(Object ???)
  {
    boolean lllllllllllllllIlllllllIlIIIIIIl;
    return ??? == null;
  }
  
  public int getRenderType()
  {
    return lIIIIIllIIIl[2];
  }
  
  private static boolean llIIlIlIllIII(int ???)
  {
    short lllllllllllllllIlllllllIIlllllll;
    return ??? == 0;
  }
  
  public void breakBlock(World lllllllllllllllIlllllllIlIIllllI, BlockPos lllllllllllllllIlllllllIlIlIIIIl, IBlockState lllllllllllllllIlllllllIlIIlllII)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIlllllllIlIIlllll.breakBlock(lllllllllllllllIlllllllIlIIllllI, lllllllllllllllIlllllllIlIlIIIIl, lllllllllllllllIlllllllIlIIlllII);
    lllllllllllllllIlllllllIlIIllllI.removeTileEntity(lllllllllllllllIlllllllIlIlIIIIl);
  }
  
  protected boolean func_181087_e(World lllllllllllllllIlllllllIlIlIllIl, BlockPos lllllllllllllllIlllllllIlIlIllII)
  {
    ;
    ;
    ;
    if ((llIIlIlIllIII(lllllllllllllllIlllllllIlIlIlIll.func_181086_a(lllllllllllllllIlllllllIlIlIlIlI, lllllllllllllllIlllllllIlIlIllII, EnumFacing.NORTH))) && (llIIlIlIllIII(lllllllllllllllIlllllllIlIlIlIll.func_181086_a(lllllllllllllllIlllllllIlIlIlIlI, lllllllllllllllIlllllllIlIlIllII, EnumFacing.SOUTH))) && (llIIlIlIllIII(lllllllllllllllIlllllllIlIlIlIll.func_181086_a(lllllllllllllllIlllllllIlIlIlIlI, lllllllllllllllIlllllllIlIlIllII, EnumFacing.WEST))) && (llIIlIlIllIII(lllllllllllllllIlllllllIlIlIlIll.func_181086_a(lllllllllllllllIlllllllIlIlIlIlI, lllllllllllllllIlllllllIlIlIllII, EnumFacing.EAST)))) {
      return lIIIIIllIIIl[1];
    }
    return lIIIIIllIIIl[0];
  }
  
  private static boolean llIIlIlIlIlll(Object ???, Object arg1)
  {
    Object localObject;
    short lllllllllllllllIlllllllIlIIIIIll;
    return ??? == localObject;
  }
}

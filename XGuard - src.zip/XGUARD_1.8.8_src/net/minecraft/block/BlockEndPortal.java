package net.minecraft.block;

import java.util.List;
import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityEndPortal;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockEndPortal
  extends BlockContainer
{
  public boolean isOpaqueCube()
  {
    return llIIllIlIlI[0];
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllllIlIllIIlIlIIIllI)
  {
    return MapColor.blackColor;
  }
  
  private static boolean lIIlllIIIIlIl(int ???)
  {
    float llllllllllllllllIlIllIIlIIlllllI;
    return ??? == 0;
  }
  
  public Item getItem(World llllllllllllllllIlIllIIlIlIIlIIl, BlockPos llllllllllllllllIlIllIIlIlIIlIII)
  {
    return null;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllllIlIllIIllIIIllII, BlockPos llllllllllllllllIlIllIIllIIIlIll)
  {
    ;
    ;
    float llllllllllllllllIlIllIIllIIIlIlI = 0.0625F;
    llllllllllllllllIlIllIIllIIIllIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, llllllllllllllllIlIllIIllIIIlIlI, 1.0F);
  }
  
  public boolean shouldSideBeRendered(IBlockAccess llllllllllllllllIlIllIIlIllllllI, BlockPos llllllllllllllllIlIllIIllIIIIIIl, EnumFacing llllllllllllllllIlIllIIllIIIIIII)
  {
    ;
    ;
    ;
    ;
    if (lIIlllIIIIIll(llllllllllllllllIlIllIIllIIIIIII, EnumFacing.DOWN))
    {
      "".length();
      if ("   ".length() <= (0x49 ^ 0x32 ^ 69 + 61 - 105 + 102)) {
        break label99;
      }
      return (0x52 ^ 0x7 ^ 0xFE ^ 0xBC) & (38 + 30 - 41 + 108 ^ 40 + 88 - 115 + 131 ^ -" ".length());
    }
    label99:
    return llIIllIlIlI[0];
  }
  
  public TileEntity createNewTileEntity(World llllllllllllllllIlIllIIllIIlIIIl, int llllllllllllllllIlIllIIllIIlIIII)
  {
    return new TileEntityEndPortal();
  }
  
  private static void lIIlllIIIIIlI()
  {
    llIIllIlIlI = new int[2];
    llIIllIlIlI[0] = ((0x19 ^ 0x6E ^ 0xFA ^ 0x82) & (47 + 122 - 86 + 97 ^ 89 + '°' - 210 + 132 ^ -" ".length()));
    llIIllIlIlI[1] = " ".length();
  }
  
  public boolean isFullCube()
  {
    return llIIllIlIlI[0];
  }
  
  public void randomDisplayTick(World llllllllllllllllIlIllIIlIlIlIIll, BlockPos llllllllllllllllIlIllIIlIlIlllII, IBlockState llllllllllllllllIlIllIIlIlIllIll, Random llllllllllllllllIlIllIIlIlIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    double llllllllllllllllIlIllIIlIlIllIIl = llllllllllllllllIlIllIIlIlIlllII.getX() + llllllllllllllllIlIllIIlIlIlIIIl.nextFloat();
    double llllllllllllllllIlIllIIlIlIllIII = llllllllllllllllIlIllIIlIlIlllII.getY() + 0.8F;
    double llllllllllllllllIlIllIIlIlIlIlll = llllllllllllllllIlIllIIlIlIlllII.getZ() + llllllllllllllllIlIllIIlIlIlIIIl.nextFloat();
    double llllllllllllllllIlIllIIlIlIlIllI = 0.0D;
    double llllllllllllllllIlIllIIlIlIlIlIl = 0.0D;
    double llllllllllllllllIlIllIIlIlIlIlII = 0.0D;
    llllllllllllllllIlIllIIlIlIlIIll.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, llllllllllllllllIlIllIIlIlIllIIl, llllllllllllllllIlIllIIlIlIllIII, llllllllllllllllIlIllIIlIlIlIlll, llllllllllllllllIlIllIIlIlIlIllI, llllllllllllllllIlIllIIlIlIlIlIl, llllllllllllllllIlIllIIlIlIlIlII, new int[llIIllIlIlI[0]]);
  }
  
  public int quantityDropped(Random llllllllllllllllIlIllIIlIlllIIIl)
  {
    return llIIllIlIlI[0];
  }
  
  static {}
  
  protected BlockEndPortal(Material llllllllllllllllIlIllIIllIIlIIll)
  {
    llllllllllllllllIlIllIIllIIlIlII.<init>(llllllllllllllllIlIllIIllIIlIIll);
    "".length();
  }
  
  private static boolean lIIlllIIIIIll(Object ???, Object arg1)
  {
    Object localObject;
    double llllllllllllllllIlIllIIlIlIIIIlI;
    return ??? == localObject;
  }
  
  public void addCollisionBoxesToList(World llllllllllllllllIlIllIIlIllllIlI, BlockPos llllllllllllllllIlIllIIlIllllIIl, IBlockState llllllllllllllllIlIllIIlIllllIII, AxisAlignedBB llllllllllllllllIlIllIIlIlllIlll, List<AxisAlignedBB> llllllllllllllllIlIllIIlIlllIllI, Entity llllllllllllllllIlIllIIlIlllIlIl) {}
  
  public void onEntityCollidedWithBlock(World llllllllllllllllIlIllIIlIllIllIl, BlockPos llllllllllllllllIlIllIIlIllIllII, IBlockState llllllllllllllllIlIllIIlIllIlIll, Entity llllllllllllllllIlIllIIlIllIlIlI)
  {
    ;
    ;
    if ((lIIlllIIIIlII(ridingEntity)) && (lIIlllIIIIlII(riddenByEntity)) && (lIIlllIIIIlIl(isRemote))) {
      llllllllllllllllIlIllIIlIllIlIlI.travelToDimension(llIIllIlIlI[1]);
    }
  }
  
  private static boolean lIIlllIIIIlII(Object ???)
  {
    boolean llllllllllllllllIlIllIIlIlIIIIII;
    return ??? == null;
  }
}

package net.minecraft.block;

public class BlockHalfStoneSlabNew
  extends BlockStoneSlabNew
{
  static {}
  
  public BlockHalfStoneSlabNew() {}
  
  private static void lIlIIlIllIII()
  {
    llIIllllll = new int[1];
    llIIllllll[0] = (('Ï' + 107 - 69 + 5 ^ '¡' + 87 - 105 + 19) & (0xF8 ^ 0xB2 ^ 0xA3 ^ 0xB1 ^ -" ".length()));
  }
  
  public boolean isDouble()
  {
    return llIIllllll[0];
  }
}

package net.minecraft.block;

public class BlockHalfStoneSlab
  extends BlockStoneSlab
{
  static {}
  
  public BlockHalfStoneSlab() {}
  
  public boolean isDouble()
  {
    return llIIlllIIlll[0];
  }
  
  private static void lIIlllIlIlIIlI()
  {
    llIIlllIIlll = new int[1];
    llIIlllIIlll[0] = ((0xCC ^ 0xBB ^ 0xAE ^ 0xC7) & (0x7 ^ 0x6F ^ 0xE7 ^ 0x91 ^ -" ".length()));
  }
}

package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;

public class BlockCompressedPowered
  extends Block
{
  public BlockCompressedPowered(Material llllllllllllllIlIIIIIIIIllllIIIl, MapColor llllllllllllllIlIIIIIIIIllllIIII)
  {
    llllllllllllllIlIIIIIIIIlllIllll.<init>(llllllllllllllIlIIIIIIIIlllIlllI, llllllllllllllIlIIIIIIIIllllIIII);
  }
  
  public boolean canProvidePower()
  {
    return lIIlIlIIIllIl[0];
  }
  
  public int getWeakPower(IBlockAccess llllllllllllllIlIIIIIIIIlllIlIlI, BlockPos llllllllllllllIlIIIIIIIIlllIlIIl, IBlockState llllllllllllllIlIIIIIIIIlllIlIII, EnumFacing llllllllllllllIlIIIIIIIIlllIIlll)
  {
    return lIIlIlIIIllIl[1];
  }
  
  private static void lllIIIlIIIllIl()
  {
    lIIlIlIIIllIl = new int[2];
    lIIlIlIIIllIl[0] = " ".length();
    lIIlIlIIIllIl[1] = (0x88 ^ 0x87);
  }
  
  static {}
}

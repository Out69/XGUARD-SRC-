package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;

public class BlockHardenedClay
  extends Block
{
  public BlockHardenedClay()
  {
    lllllllllllllllIIIllIIllIlIIlIll.<init>(Material.rock);
    "".length();
  }
  
  public MapColor getMapColor(IBlockState lllllllllllllllIIIllIIllIlIIlIIl)
  {
    return MapColor.adobeColor;
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockCocoa
  extends BlockDirectional
  implements IGrowable
{
  private static String lllIIIllIIllIl(String llllllllllllllIIlllllIIIIllIlIII, String llllllllllllllIIlllllIIIIllIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIlllllIIIIllIlIII = new String(Base64.getDecoder().decode(llllllllllllllIIlllllIIIIllIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIlllllIIIIllIIllI = new StringBuilder();
    char[] llllllllllllllIIlllllIIIIllIIlIl = llllllllllllllIIlllllIIIIllIIlll.toCharArray();
    int llllllllllllllIIlllllIIIIllIIlII = lIIlIlIlIIlll[0];
    int llllllllllllllIIlllllIIIIlIllllI = llllllllllllllIIlllllIIIIllIlIII.toCharArray();
    String llllllllllllllIIlllllIIIIlIlllIl = llllllllllllllIIlllllIIIIlIllllI.length;
    boolean llllllllllllllIIlllllIIIIlIlllII = lIIlIlIlIIlll[0];
    while (lllIIIlllIlIll(llllllllllllllIIlllllIIIIlIlllII, llllllllllllllIIlllllIIIIlIlllIl))
    {
      char llllllllllllllIIlllllIIIIllIlIIl = llllllllllllllIIlllllIIIIlIllllI[llllllllllllllIIlllllIIIIlIlllII];
      "".length();
      "".length();
      if (-"   ".length() >= 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIlllllIIIIllIIllI);
  }
  
  public boolean canBlockStay(World llllllllllllllIIlllllIIlIIlIIlII, BlockPos llllllllllllllIIlllllIIlIIlIIlll, IBlockState llllllllllllllIIlllllIIlIIlIIllI)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIIlllllIIlIIlIIIll = llllllllllllllIIlllllIIlIIlIIlll.offset((EnumFacing)llllllllllllllIIlllllIIlIIlIIllI.getValue(FACING));
    IBlockState llllllllllllllIIlllllIIlIIlIIlIl = llllllllllllllIIlllllIIlIIlIIlII.getBlockState(llllllllllllllIIlllllIIlIIlIIIll);
    if ((lllIIIlllIllII(llllllllllllllIIlllllIIlIIlIIlIl.getBlock(), Blocks.log)) && (lllIIIlllIllII(llllllllllllllIIlllllIIlIIlIIlIl.getValue(BlockPlanks.VARIANT), BlockPlanks.EnumType.JUNGLE))) {
      return lIIlIlIlIIlll[2];
    }
    return lIIlIlIlIIlll[0];
  }
  
  public BlockCocoa()
  {
    llllllllllllllIIlllllIIlIIlllllI.<init>(Material.plants);
    llllllllllllllIIlllllIIlIIllllll.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(AGE, Integer.valueOf(lIIlIlIlIIlll[0])));
    "".length();
  }
  
  public void updateTick(World llllllllllllllIIlllllIIlIIllIlll, BlockPos llllllllllllllIIlllllIIlIIllIllI, IBlockState llllllllllllllIIlllllIIlIIlIllll, Random llllllllllllllIIlllllIIlIIllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIIIlllIlIlI(llllllllllllllIIlllllIIlIIlllIII.canBlockStay(llllllllllllllIIlllllIIlIIllIlll, llllllllllllllIIlllllIIlIIllIIII, llllllllllllllIIlllllIIlIIlIllll)))
    {
      llllllllllllllIIlllllIIlIIlllIII.dropBlock(llllllllllllllIIlllllIIlIIllIlll, llllllllllllllIIlllllIIlIIllIIII, llllllllllllllIIlllllIIlIIlIllll);
      "".length();
      if (((58 + 43 - -43 + 87 ^ 10 + 118 - 105 + 110) & (0x8E ^ 0xC1 ^ 0xA8 ^ 0x85 ^ -" ".length())) <= (('´' + '«' - 344 + 183 ^ 114 + 121 - 132 + 49) & (101 + 80 - 74 + 121 ^ 47 + '¡' - 105 + 91 ^ -" ".length()))) {}
    }
    else if (lllIIIlllIlIlI(rand.nextInt(lIIlIlIlIIlll[3])))
    {
      int llllllllllllllIIlllllIIlIIllIIll = ((Integer)llllllllllllllIIlllllIIlIIlIllll.getValue(AGE)).intValue();
      if (lllIIIlllIlIll(llllllllllllllIIlllllIIlIIllIIll, lIIlIlIlIIlll[1])) {
        "".length();
      }
    }
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIIlllllIIIIlllllll)
  {
    ;
    ;
    return llllllllllllllIIlllllIIIlIIIIIII.getDefaultState().withProperty(FACING, EnumFacing.getHorizontal(llllllllllllllIIlllllIIIIlllllll)).withProperty(AGE, Integer.valueOf((llllllllllllllIIlllllIIIIlllllll & lIIlIlIlIIlll[6]) >> lIIlIlIlIIlll[1]));
  }
  
  public boolean isOpaqueCube()
  {
    return lIIlIlIlIIlll[0];
  }
  
  private static void lllIIIllIIlllI()
  {
    lIIlIlIlIIIIl = new String[lIIlIlIlIIlll[2]];
    lIIlIlIlIIIIl[lIIlIlIlIIlll[0]] = lllIIIllIIllIl("BjU9", "gRXHq");
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public void grow(World llllllllllllllIIlllllIIIlIIIlIII, Random llllllllllllllIIlllllIIIlIIIlIll, BlockPos llllllllllllllIIlllllIIIlIIIIlll, IBlockState llllllllllllllIIlllllIIIlIIIlIIl)
  {
    ;
    ;
    ;
    "".length();
  }
  
  private void dropBlock(World llllllllllllllIIlllllIIIlIlllllI, BlockPos llllllllllllllIIlllllIIIlIlllIIl, IBlockState llllllllllllllIIlllllIIIlIllllII)
  {
    ;
    ;
    ;
    ;
    "".length();
    llllllllllllllIIlllllIIIlIlllIll.dropBlockAsItem(llllllllllllllIIlllllIIIlIlllllI, llllllllllllllIIlllllIIIlIlllIIl, llllllllllllllIIlllllIIIlIllllII, lIIlIlIlIIlll[0]);
  }
  
  public boolean canGrow(World llllllllllllllIIlllllIIIlIIllIlI, BlockPos llllllllllllllIIlllllIIIlIIllIIl, IBlockState llllllllllllllIIlllllIIIlIIlIllI, boolean llllllllllllllIIlllllIIIlIIlIlll)
  {
    ;
    if (lllIIIlllIlIll(((Integer)llllllllllllllIIlllllIIIlIIlIllI.getValue(AGE)).intValue(), lIIlIlIlIIlll[1])) {
      return lIIlIlIlIIlll[2];
    }
    return lIIlIlIlIIlll[0];
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIIlllllIIIIlllIlIl, new IProperty[] { FACING, AGE });
  }
  
  private static boolean lllIIIlllIlIll(int ???, int arg1)
  {
    int i;
    long llllllllllllllIIlllllIIIIlIlIIll;
    return ??? < i;
  }
  
  public boolean canUseBonemeal(World llllllllllllllIIlllllIIIlIIlIlII, Random llllllllllllllIIlllllIIIlIIlIIll, BlockPos llllllllllllllIIlllllIIIlIIlIIlI, IBlockState llllllllllllllIIlllllIIIlIIlIIIl)
  {
    return lIIlIlIlIIlll[2];
  }
  
  public IBlockState onBlockPlaced(World llllllllllllllIIlllllIIIllIllIlI, BlockPos llllllllllllllIIlllllIIIllIllIIl, EnumFacing llllllllllllllIIlllllIIIllIllIII, float llllllllllllllIIlllllIIIllIlIlll, float llllllllllllllIIlllllIIIllIlIllI, float llllllllllllllIIlllllIIIllIlIlIl, int llllllllllllllIIlllllIIIllIlIlII, EntityLivingBase llllllllllllllIIlllllIIIllIlIIll)
  {
    ;
    ;
    if (lllIIIlllIlIlI(llllllllllllllIIlllllIIIllIllIII.getAxis().isHorizontal())) {
      llllllllllllllIIlllllIIIllIllIII = EnumFacing.NORTH;
    }
    return llllllllllllllIIlllllIIIllIlIIlI.getDefaultState().withProperty(FACING, llllllllllllllIIlllllIIIllIllIII.getOpposite()).withProperty(AGE, Integer.valueOf(lIIlIlIlIIlll[0]));
  }
  
  public Item getItem(World llllllllllllllIIlllllIIIlIlIIIIl, BlockPos llllllllllllllIIlllllIIIlIlIIIII)
  {
    return Items.dye;
  }
  
  public void dropBlockAsItemWithChance(World llllllllllllllIIlllllIIIlIllIIII, BlockPos llllllllllllllIIlllllIIIlIlIIlll, IBlockState llllllllllllllIIlllllIIIlIlIIllI, float llllllllllllllIIlllllIIIlIlIllIl, int llllllllllllllIIlllllIIIlIlIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIIlllllIIIlIlIlIll = ((Integer)llllllllllllllIIlllllIIIlIlIIllI.getValue(AGE)).intValue();
    int llllllllllllllIIlllllIIIlIlIlIlI = lIIlIlIlIIlll[2];
    if (lllIIIlllIlllI(llllllllllllllIIlllllIIIlIlIlIll, lIIlIlIlIIlll[1])) {
      llllllllllllllIIlllllIIIlIlIlIlI = lIIlIlIlIIlll[5];
    }
    int llllllllllllllIIlllllIIIlIlIlIIl = lIIlIlIlIIlll[0];
    "".length();
    if (null != null) {
      return;
    }
    while (!lllIIIlllIlllI(llllllllllllllIIlllllIIIlIlIlIIl, llllllllllllllIIlllllIIIlIlIlIlI))
    {
      spawnAsEntity(llllllllllllllIIlllllIIIlIllIIII, llllllllllllllIIlllllIIIlIlIIlll, new ItemStack(Items.dye, lIIlIlIlIIlll[2], EnumDyeColor.BROWN.getDyeDamage()));
      llllllllllllllIIlllllIIIlIlIlIIl++;
    }
  }
  
  private static boolean lllIIIlllIllII(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllIIlllllIIIIlIIllll;
    return ??? == localObject;
  }
  
  private static void lllIIIlllIlIII()
  {
    lIIlIlIlIIlll = new int[8];
    lIIlIlIlIIlll[0] = ((0x32 ^ 0x6E) & (0x78 ^ 0x24 ^ 0xFFFFFFFF));
    lIIlIlIlIIlll[1] = "  ".length();
    lIIlIlIlIIlll[2] = " ".length();
    lIIlIlIlIIlll[3] = (0xB1 ^ 0xB4);
    lIIlIlIlIIlll[4] = (0x39 ^ 0x3D);
    lIIlIlIlIIlll[5] = "   ".length();
    lIIlIlIlIIlll[6] = (0x61 ^ 0x6E);
    lIIlIlIlIIlll[7] = (104 + 3 - 51 + 139 ^ 118 + 10 - 81 + 150);
  }
  
  private static boolean lllIIIlllIllll(Object ???)
  {
    byte llllllllllllllIIlllllIIIIlIIllIl;
    return ??? != null;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIIlllllIIIllllllll, BlockPos llllllllllllllIIlllllIIIllllIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllIIlllllIIIllllllIl = llllllllllllllIIlllllIIIllllllll.getBlockState(llllllllllllllIIlllllIIIllllIlIl);
    EnumFacing llllllllllllllIIlllllIIIllllllII = (EnumFacing)llllllllllllllIIlllllIIIllllllIl.getValue(FACING);
    int llllllllllllllIIlllllIIIlllllIll = ((Integer)llllllllllllllIIlllllIIIllllllIl.getValue(AGE)).intValue();
    int llllllllllllllIIlllllIIIlllllIlI = lIIlIlIlIIlll[4] + llllllllllllllIIlllllIIIlllllIll * lIIlIlIlIIlll[1];
    int llllllllllllllIIlllllIIIlllllIIl = lIIlIlIlIIlll[3] + llllllllllllllIIlllllIIIlllllIll * lIIlIlIlIIlll[1];
    float llllllllllllllIIlllllIIIlllllIII = llllllllllllllIIlllllIIIlllllIlI / 2.0F;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[llllllllllllllIIlllllIIIllllllII.ordinal()])
    {
    case 4: 
      llllllllllllllIIlllllIIlIIIIIIII.setBlockBounds((8.0F - llllllllllllllIIlllllIIIlllllIII) / 16.0F, (12.0F - llllllllllllllIIlllllIIIlllllIIl) / 16.0F, (15.0F - llllllllllllllIIlllllIIIlllllIlI) / 16.0F, (8.0F + llllllllllllllIIlllllIIIlllllIII) / 16.0F, 0.75F, 0.9375F);
      "".length();
      if (((0x5 ^ 0x39) & (0xBC ^ 0x80 ^ 0xFFFFFFFF)) != 0) {}
      break;
    case 3: 
      llllllllllllllIIlllllIIlIIIIIIII.setBlockBounds((8.0F - llllllllllllllIIlllllIIIlllllIII) / 16.0F, (12.0F - llllllllllllllIIlllllIIIlllllIIl) / 16.0F, 0.0625F, (8.0F + llllllllllllllIIlllllIIIlllllIII) / 16.0F, 0.75F, (1.0F + llllllllllllllIIlllllIIIlllllIlI) / 16.0F);
      "".length();
      if ("  ".length() <= 0) {}
      break;
    case 5: 
      llllllllllllllIIlllllIIlIIIIIIII.setBlockBounds(0.0625F, (12.0F - llllllllllllllIIlllllIIIlllllIIl) / 16.0F, (8.0F - llllllllllllllIIlllllIIIlllllIII) / 16.0F, (1.0F + llllllllllllllIIlllllIIIlllllIlI) / 16.0F, 0.75F, (8.0F + llllllllllllllIIlllllIIIlllllIII) / 16.0F);
      "".length();
      if (-(0xF3 ^ 0xA7 ^ 0xCC ^ 0x9D) >= 0) {}
      break;
    case 6: 
      llllllllllllllIIlllllIIlIIIIIIII.setBlockBounds((15.0F - llllllllllllllIIlllllIIIlllllIlI) / 16.0F, (12.0F - llllllllllllllIIlllllIIIlllllIIl) / 16.0F, (8.0F - llllllllllllllIIlllllIIIlllllIII) / 16.0F, 0.9375F, 0.75F, (8.0F + llllllllllllllIIlllllIIIlllllIII) / 16.0F);
    }
  }
  
  public boolean isFullCube()
  {
    return lIIlIlIlIIlll[0];
  }
  
  public AxisAlignedBB getSelectedBoundingBox(World llllllllllllllIIlllllIIlIIIIlIll, BlockPos llllllllllllllIIlllllIIlIIIIlIlI)
  {
    ;
    ;
    ;
    llllllllllllllIIlllllIIlIIIIllII.setBlockBoundsBasedOnState(llllllllllllllIIlllllIIlIIIIlllI, llllllllllllllIIlllllIIlIIIIlIlI);
    return llllllllllllllIIlllllIIlIIIIllII.getSelectedBoundingBox(llllllllllllllIIlllllIIlIIIIlllI, llllllllllllllIIlllllIIlIIIIlIlI);
  }
  
  private static boolean lllIIIlllIlllI(int ???, int arg1)
  {
    int i;
    double llllllllllllllIIlllllIIIIlIlIlll;
    return ??? >= i;
  }
  
  static
  {
    lllIIIlllIlIII();
    lllIIIllIIlllI();
  }
  
  public void onBlockPlacedBy(World llllllllllllllIIlllllIIIlllIIIlI, BlockPos llllllllllllllIIlllllIIIlllIIIIl, IBlockState llllllllllllllIIlllllIIIlllIIIII, EntityLivingBase llllllllllllllIIlllllIIIllIlllll, ItemStack llllllllllllllIIlllllIIIlllIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllIIlllllIIIlllIIIll = EnumFacing.fromAngle(rotationYaw);
    "".length();
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIIlllllIIIIllllIll)
  {
    ;
    ;
    int llllllllllllllIIlllllIIIIllllIlI = lIIlIlIlIIlll[0];
    llllllllllllllIIlllllIIIIllllIlI |= ((EnumFacing)llllllllllllllIIlllllIIIIllllIIl.getValue(FACING)).getHorizontalIndex();
    llllllllllllllIIlllllIIIIllllIlI |= ((Integer)llllllllllllllIIlllllIIIIllllIIl.getValue(AGE)).intValue() << lIIlIlIlIIlll[1];
    return llllllllllllllIIlllllIIIIllllIlI;
  }
  
  private static boolean lllIIIlllIlIlI(int ???)
  {
    int llllllllllllllIIlllllIIIIlIIlIll;
    return ??? == 0;
  }
  
  public int getDamageValue(World llllllllllllllIIlllllIIIlIIllllI, BlockPos llllllllllllllIIlllllIIIlIIlllIl)
  {
    return EnumDyeColor.BROWN.getDyeDamage();
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIIlllllIIlIIIllIIl, BlockPos llllllllllllllIIlllllIIlIIIllIII, IBlockState llllllllllllllIIlllllIIlIIIlIlll)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIIlllllIIlIIIllIlI.setBlockBoundsBasedOnState(llllllllllllllIIlllllIIlIIIllIIl, llllllllllllllIIlllllIIlIIIllIII);
    return llllllllllllllIIlllllIIlIIIllIlI.getCollisionBoundingBox(llllllllllllllIIlllllIIlIIIllIIl, llllllllllllllIIlllllIIlIIIllIII, llllllllllllllIIlllllIIlIIIlIlll);
  }
  
  public void onNeighborBlockChange(World llllllllllllllIIlllllIIIllIIIllI, BlockPos llllllllllllllIIlllllIIIllIIlIlI, IBlockState llllllllllllllIIlllllIIIllIIlIIl, Block llllllllllllllIIlllllIIIllIIlIII)
  {
    ;
    ;
    ;
    ;
    if (lllIIIlllIlIlI(llllllllllllllIIlllllIIIllIIllII.canBlockStay(llllllllllllllIIlllllIIIllIIIllI, llllllllllllllIIlllllIIIllIIIlIl, llllllllllllllIIlllllIIIllIIlIIl))) {
      llllllllllllllIIlllllIIIllIIllII.dropBlock(llllllllllllllIIlllllIIIllIIIllI, llllllllllllllIIlllllIIIllIIIlIl, llllllllllllllIIlllllIIIllIIlIIl);
    }
  }
}

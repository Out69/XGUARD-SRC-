package net.minecraft.block;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockPattern;
import net.minecraft.block.state.pattern.BlockPattern.PatternHelper;
import net.minecraft.block.state.pattern.BlockStateHelper;
import net.minecraft.block.state.pattern.FactoryBlockPattern;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.stats.AchievementList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntitySkull;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.StatCollector;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockSkull
  extends BlockContainer
{
  public int getDamageValue(World llllllllllllllIllIlIIIllIllllllI, BlockPos llllllllllllllIllIlIIIllIlllllIl)
  {
    ;
    ;
    ;
    ;
    TileEntity llllllllllllllIllIlIIIllIlllllII = llllllllllllllIllIlIIIllIllllllI.getTileEntity(llllllllllllllIllIlIIIllIlllllIl);
    if (lIlllIlllIllll(llllllllllllllIllIlIIIllIlllllII instanceof TileEntitySkull))
    {
      "".length();
      if (-" ".length() <= -" ".length()) {
        break label98;
      }
      return (0xD9 ^ 0xA0 ^ 0x15 ^ 0x37) & (21 + 12 - -22 + 100 ^ '' + 64 - 181 + 151 ^ -" ".length());
    }
    label98:
    return llllllllllllllIllIlIIIllIllllIll.getDamageValue(llllllllllllllIllIlIIIllIllllIlI, llllllllllllllIllIlIIIllIlllllIl);
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIllIlIIIlllIIllIIl, BlockPos llllllllllllllIllIlIIIlllIIlllII, IBlockState llllllllllllllIllIlIIIlllIIlIlll)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIllIlIIIlllIIllIlI.setBlockBoundsBasedOnState(llllllllllllllIllIlIIIlllIIllIIl, llllllllllllllIllIlIIIlllIIlllII);
    return llllllllllllllIllIlIIIlllIIllIlI.getCollisionBoundingBox(llllllllllllllIllIlIIIlllIIllIIl, llllllllllllllIllIlIIIlllIIlllII, llllllllllllllIllIlIIIlllIIlIlll);
  }
  
  private static String lIlllIlllIIlll(String llllllllllllllIllIlIIIlIllIllIII, String llllllllllllllIllIlIIIlIllIlIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIlIIIlIllIllIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIIIlIllIlIlIl.getBytes(StandardCharsets.UTF_8)), llllIllIllIl[7]), "DES");
      Cipher llllllllllllllIllIlIIIlIllIllIlI = Cipher.getInstance("DES");
      llllllllllllllIllIlIIIlIllIllIlI.init(llllIllIllIl[2], llllllllllllllIllIlIIIlIllIllIll);
      return new String(llllllllllllllIllIlIIIlIllIllIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIIIlIllIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIlIIIlIllIllIIl)
    {
      llllllllllllllIllIlIIIlIllIllIIl.printStackTrace();
    }
    return null;
  }
  
  public String getLocalizedName()
  {
    return StatCollector.translateToLocal(llllIllIlIlI[llllIllIllIl[2]]);
  }
  
  private static boolean lIlllIllllIllI(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllIllIlIIIlIlIllIIII;
    return ??? == localObject;
  }
  
  private static boolean lIlllIllllIlIl(Object ???, Object arg1)
  {
    Object localObject;
    char llllllllllllllIllIlIIIlIlIllIllI;
    return ??? != localObject;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIllIlIIIlllIlIIlll, BlockPos llllllllllllllIllIlIIIlllIlIIIll)
  {
    ;
    ;
    ;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[((EnumFacing)llllllllllllllIllIlIIIlllIlIIlII.getBlockState(llllllllllllllIllIlIIIlllIlIIIll).getValue(FACING)).ordinal()])
    {
    case 2: 
    default: 
      llllllllllllllIllIlIIIlllIlIIlIl.setBlockBounds(0.25F, 0.0F, 0.25F, 0.75F, 0.5F, 0.75F);
      "".length();
      if ((("   ".length() ^ 0x3 ^ 0x7) & (0xD5 ^ 0x85 ^ 0x4D ^ 0x1A ^ -" ".length())) >= "  ".length()) {}
      break;
    case 3: 
      llllllllllllllIllIlIIIlllIlIIlIl.setBlockBounds(0.25F, 0.25F, 0.5F, 0.75F, 0.75F, 1.0F);
      "".length();
      if (" ".length() <= -" ".length()) {}
      break;
    case 4: 
      llllllllllllllIllIlIIIlllIlIIlIl.setBlockBounds(0.25F, 0.25F, 0.0F, 0.75F, 0.75F, 0.5F);
      "".length();
      if ("  ".length() == -" ".length()) {}
      break;
    case 5: 
      llllllllllllllIllIlIIIlllIlIIlIl.setBlockBounds(0.5F, 0.25F, 0.25F, 1.0F, 0.75F, 0.75F);
      "".length();
      if (null != null) {}
      break;
    case 6: 
      llllllllllllllIllIlIIIlllIlIIlIl.setBlockBounds(0.0F, 0.25F, 0.25F, 0.5F, 0.75F, 0.75F);
    }
  }
  
  public Item getItem(World llllllllllllllIllIlIIIlllIIIIlIl, BlockPos llllllllllllllIllIlIIIlllIIIIlII)
  {
    return Items.skull;
  }
  
  private static void lIlllIlllIlIlI()
  {
    llllIllIlIlI = new String[llllIllIllIl[14]];
    llllIllIlIlI[llllIllIllIl[0]] = lIlllIlllIIlIl("CVaxnyppzLw=", "LOpYy");
    llllIllIlIlI[llllIllIllIl[1]] = lIlllIlllIIllI("ICUzPzw+", "NJWMS");
    llllIllIlIlI[llllIllIllIl[2]] = lIlllIlllIIlll("lcNMWhXQjEpPRInG6BwXVtuzW1EAhWxcy8uR0zewm0o=", "DVORN");
    llllIllIlIlI[llllIllIllIl[4]] = lIlllIlllIIlIl("cP/jBPVizhv7TM4LU88u3g==", "PbNpu");
    llllIllIlIlI[llllIllIllIl[3]] = lIlllIlllIIllI("dWN5", "UCYyq");
    llllIllIlIlI[llllIllIllIl[8]] = lIlllIlllIIlIl("33RZqy2NcoA=", "GsToE");
    llllIllIlIlI[llllIllIllIl[9]] = lIlllIlllIIlll("YZLUTSaASCk=", "IKfKV");
    llllIllIlIlI[llllIllIllIl[6]] = lIlllIlllIIlll("87rkB0uJ8zI=", "EzloE");
    llllIllIlIlI[llllIllIllIl[7]] = lIlllIlllIIlll("su58IHK+wIY=", "Vvumk");
    llllIllIlIlI[llllIllIllIl[12]] = lIlllIlllIIlIl("F4/Srv2hoHA=", "zfWRc");
  }
  
  private static boolean lIlllIllllIIIl(int ???)
  {
    Exception llllllllllllllIllIlIIIlIlIlIlIlI;
    return ??? == 0;
  }
  
  private static boolean lIlllIlllllIII(Object ???)
  {
    int llllllllllllllIllIlIIIlIlIlIlllI;
    return ??? == null;
  }
  
  private static String lIlllIlllIIllI(String llllllllllllllIllIlIIIlIlllIllIl, String llllllllllllllIllIlIIIlIlllIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIlIIIlIlllIllIl = new String(Base64.getDecoder().decode(llllllllllllllIllIlIIIlIlllIllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIlIIIlIlllIlIll = new StringBuilder();
    char[] llllllllllllllIllIlIIIlIlllIlIlI = llllllllllllllIllIlIIIlIlllIIlll.toCharArray();
    int llllllllllllllIllIlIIIlIlllIlIIl = llllIllIllIl[0];
    double llllllllllllllIllIlIIIlIlllIIIll = llllllllllllllIllIlIIIlIlllIllIl.toCharArray();
    int llllllllllllllIllIlIIIlIlllIIIlI = llllllllllllllIllIlIIIlIlllIIIll.length;
    boolean llllllllllllllIllIlIIIlIlllIIIIl = llllIllIllIl[0];
    while (lIlllIlllllIIl(llllllllllllllIllIlIIIlIlllIIIIl, llllllllllllllIllIlIIIlIlllIIIlI))
    {
      char llllllllllllllIllIlIIIlIlllIlllI = llllllllllllllIllIlIIIlIlllIIIll[llllllllllllllIllIlIIIlIlllIIIIl];
      "".length();
      "".length();
      if ((0x35 ^ 0x31) == 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIlIIIlIlllIlIll);
  }
  
  public void breakBlock(World llllllllllllllIllIlIIIllIlIllIIl, BlockPos llllllllllllllIllIlIIIllIlIlIIII, IBlockState llllllllllllllIllIlIIIllIlIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlllIllllIIIl(isRemote))
    {
      if (lIlllIllllIIIl(((Boolean)llllllllllllllIllIlIIIllIlIIllll.getValue(NODROP)).booleanValue()))
      {
        TileEntity llllllllllllllIllIlIIIllIlIlIllI = llllllllllllllIllIlIIIllIlIllIIl.getTileEntity(llllllllllllllIllIlIIIllIlIlIIII);
        if (lIlllIlllIllll(llllllllllllllIllIlIIIllIlIlIllI instanceof TileEntitySkull))
        {
          TileEntitySkull llllllllllllllIllIlIIIllIlIlIlIl = (TileEntitySkull)llllllllllllllIllIlIIIllIlIlIllI;
          ItemStack llllllllllllllIllIlIIIllIlIlIlII = new ItemStack(Items.skull, llllIllIllIl[1], llllllllllllllIllIlIIIllIlIllIlI.getDamageValue(llllllllllllllIllIlIIIllIlIllIIl, llllllllllllllIllIlIIIllIlIlIIII));
          if ((lIlllIllllIIlI(llllllllllllllIllIlIIIllIlIlIlIl.getSkullType(), llllIllIllIl[4])) && (lIlllIllllIIll(llllllllllllllIllIlIIIllIlIlIlIl.getPlayerProfile())))
          {
            llllllllllllllIllIlIIIllIlIlIlII.setTagCompound(new NBTTagCompound());
            NBTTagCompound llllllllllllllIllIlIIIllIlIlIIll = new NBTTagCompound();
            "".length();
            llllllllllllllIllIlIIIllIlIlIlII.getTagCompound().setTag(llllIllIlIlI[llllIllIllIl[4]], llllllllllllllIllIlIIIllIlIlIIll);
          }
          spawnAsEntity(llllllllllllllIllIlIIIllIlIllIIl, llllllllllllllIllIlIIIllIlIlIIII, llllllllllllllIllIlIIIllIlIlIlII);
        }
      }
      llllllllllllllIllIlIIIllIlIllIlI.breakBlock(llllllllllllllIllIlIIIllIlIllIIl, llllllllllllllIllIlIIIllIlIlIIII, llllllllllllllIllIlIIIllIlIIllll);
    }
  }
  
  public void onBlockHarvested(World llllllllllllllIllIlIIIllIllIIllI, BlockPos llllllllllllllIllIlIIIllIllIlIlI, IBlockState llllllllllllllIllIlIIIllIllIIlII, EntityPlayer llllllllllllllIllIlIIIllIllIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIlllIlllIllll(capabilities.isCreativeMode))
    {
      llllllllllllllIllIlIIIllIllIIlII = llllllllllllllIllIlIIIllIllIIlII.withProperty(NODROP, Boolean.valueOf(llllIllIllIl[1]));
      "".length();
    }
    llllllllllllllIllIlIIIllIllIIlll.onBlockHarvested(llllllllllllllIllIlIIIllIllIIllI, llllllllllllllIllIlIIIllIllIIlIl, llllllllllllllIllIlIIIllIllIIlII, llllllllllllllIllIlIIIllIllIIIll);
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIllIlIIIllIlIIlIIl, Random llllllllllllllIllIlIIIllIlIIlIII, int llllllllllllllIllIlIIIllIlIIIlll)
  {
    return Items.skull;
  }
  
  private static boolean lIlllIllllIlll(int ???)
  {
    double llllllllllllllIllIlIIIlIlIlIlIII;
    return ??? > 0;
  }
  
  private static void lIlllIlllIllIl()
  {
    llllIllIllIl = new int[15];
    llllIllIllIl[0] = ((0x26 ^ 0x6C) & (0xE3 ^ 0xA9 ^ 0xFFFFFFFF));
    llllIllIllIl[1] = " ".length();
    llllIllIllIl[2] = "  ".length();
    llllIllIllIl[3] = (0x9D ^ 0x99);
    llllIllIllIl[4] = "   ".length();
    llllIllIllIl[5] = (0x42 ^ 0x3A);
    llllIllIllIl[6] = ('' + 70 - 176 + 134 ^ '' + 67 - 158 + 107);
    llllIllIllIl[7] = ('' + '' - 118 + 1 ^ 110 + 19 - 103 + 140);
    llllIllIllIl[8] = (0x40 ^ 0x45);
    llllIllIllIl[9] = (0x72 ^ 0x74);
    llllIllIllIl[10] = (0x29 ^ 0xA);
    llllIllIllIl[11] = (0x36 ^ 0x48);
    llllIllIllIl[12] = (70 + 124 - 145 + 151 ^ 5 + '' - 97 + 138);
    llllIllIllIl[13] = (0x48 ^ 0x11 ^ 0xB2 ^ 0xB5);
    llllIllIllIl[14] = (0xBE ^ 0xB4);
  }
  
  static
  {
    lIlllIlllIllIl();
    lIlllIlllIlIlI();
  }
  
  public boolean canDispenserPlace(World llllllllllllllIllIlIIIllIlIIIIIl, BlockPos llllllllllllllIllIlIIIllIlIIIIII, ItemStack llllllllllllllIllIlIIIllIIllllll)
  {
    ;
    ;
    ;
    ;
    if ((lIlllIllllIIlI(llllllllllllllIllIlIIIllIIllllll.getMetadata(), llllIllIllIl[1])) && (lIlllIllllIlII(llllllllllllllIllIlIIIllIlIIIIII.getY(), llllIllIllIl[2])) && (lIlllIllllIlIl(llllllllllllllIllIlIIIllIlIIIIIl.getDifficulty(), EnumDifficulty.PEACEFUL)) && (lIlllIllllIIIl(isRemote)))
    {
      if (lIlllIllllIIll(llllllllllllllIllIlIIIllIIlllllI.getWitherBasePattern().match(llllllllllllllIllIlIIIllIlIIIIIl, llllllllllllllIllIlIIIllIlIIIIII)))
      {
        "".length();
        if (" ".length() == " ".length()) {
          break label143;
        }
        return (0x2 ^ 0x2E) & (0xA1 ^ 0x8D ^ 0xFFFFFFFF);
      }
      "".length();
      if ("   ".length() >= 0) {
        break label143;
      }
      return (0x12 ^ 0x0) & (0x5 ^ 0x17 ^ 0xFFFFFFFF);
    }
    label143:
    return llllIllIllIl[0];
  }
  
  private static boolean lIlllIllllIlII(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIllIlIIIlIlIlllllI;
    return ??? >= i;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIllIlIIIllIIIIIllI)
  {
    ;
    ;
    int llllllllllllllIllIlIIIllIIIIIlIl = llllIllIllIl[0];
    llllllllllllllIllIlIIIllIIIIIlIl |= ((EnumFacing)llllllllllllllIllIlIIIllIIIIIlII.getValue(FACING)).getIndex();
    if (lIlllIlllIllll(((Boolean)llllllllllllllIllIlIIIllIIIIIlII.getValue(NODROP)).booleanValue())) {
      llllllllllllllIllIlIIIllIIIIIlIl |= llllIllIllIl[7];
    }
    return llllllllllllllIllIlIIIllIIIIIlIl;
  }
  
  private static String lIlllIlllIIlIl(String llllllllllllllIllIlIIIlIllIIlIll, String llllllllllllllIllIlIIIlIllIIlIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIlIIIlIllIIlllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIIIlIllIIlIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIlIIIlIllIIllIl = Cipher.getInstance("Blowfish");
      llllllllllllllIllIlIIIlIllIIllIl.init(llllIllIllIl[2], llllllllllllllIllIlIIIlIllIIlllI);
      return new String(llllllllllllllIllIlIIIlIllIIllIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIIIlIllIIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIlIIIlIllIIllII)
    {
      llllllllllllllIllIlIIIlIllIIllII.printStackTrace();
    }
    return null;
  }
  
  public void checkWitherSpawn(World llllllllllllllIllIlIIIllIIlIllIl, BlockPos llllllllllllllIllIlIIIllIIlIllII, TileEntitySkull llllllllllllllIllIlIIIllIIIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIlllIllllIIlI(llllllllllllllIllIlIIIllIIIllIII.getSkullType(), llllIllIllIl[1])) && (lIlllIllllIlII(llllllllllllllIllIlIIIllIIlIllII.getY(), llllIllIllIl[2])) && (lIlllIllllIlIl(llllllllllllllIllIlIIIllIIlIllIl.getDifficulty(), EnumDifficulty.PEACEFUL)) && (lIlllIllllIIIl(isRemote)))
    {
      BlockPattern llllllllllllllIllIlIIIllIIlIlIlI = llllllllllllllIllIlIIIllIIIllIll.getWitherPattern();
      BlockPattern.PatternHelper llllllllllllllIllIlIIIllIIlIlIIl = llllllllllllllIllIlIIIllIIlIlIlI.match(llllllllllllllIllIlIIIllIIlIllIl, llllllllllllllIllIlIIIllIIlIllII);
      if (lIlllIllllIIll(llllllllllllllIllIlIIIllIIlIlIIl))
      {
        int llllllllllllllIllIlIIIllIIlIlIII = llllIllIllIl[0];
        "".length();
        if ((0xA ^ 0x13 ^ 0x88 ^ 0x95) != ('' + 93 - 223 + 133 ^ 2 + 103 - 13 + 65)) {
          return;
        }
        while (!lIlllIllllIlII(llllllllllllllIllIlIIIllIIlIlIII, llllIllIllIl[4]))
        {
          BlockWorldState llllllllllllllIllIlIIIllIIlIIlll = llllllllllllllIllIlIIIllIIlIlIIl.translateOffset(llllllllllllllIllIlIIIllIIlIlIII, llllIllIllIl[0], llllIllIllIl[0]);
          "".length();
        }
        int llllllllllllllIllIlIIIllIIlIIllI = llllIllIllIl[0];
        "".length();
        if ((0x16 ^ 0x12) < "   ".length()) {
          return;
        }
        while (!lIlllIllllIlII(llllllllllllllIllIlIIIllIIlIIllI, llllllllllllllIllIlIIIllIIlIlIlI.getPalmLength()))
        {
          int llllllllllllllIllIlIIIllIIlIIlIl = llllIllIllIl[0];
          "".length();
          if ("   ".length() <= 0) {
            return;
          }
          while (!lIlllIllllIlII(llllllllllllllIllIlIIIllIIlIIlIl, llllllllllllllIllIlIIIllIIlIlIlI.getThumbLength()))
          {
            BlockWorldState llllllllllllllIllIlIIIllIIlIIlII = llllllllllllllIllIlIIIllIIlIlIIl.translateOffset(llllllllllllllIllIlIIIllIIlIIllI, llllllllllllllIllIlIIIllIIlIIlIl, llllIllIllIl[0]);
            "".length();
          }
        }
        BlockPos llllllllllllllIllIlIIIllIIlIIIll = llllllllllllllIllIlIIIllIIlIlIIl.translateOffset(llllIllIllIl[1], llllIllIllIl[0], llllIllIllIl[0]).getPos();
        EntityWither llllllllllllllIllIlIIIllIIlIIIlI = new EntityWither(llllllllllllllIllIlIIIllIIlIllIl);
        BlockPos llllllllllllllIllIlIIIllIIlIIIIl = llllllllllllllIllIlIIIllIIlIlIIl.translateOffset(llllIllIllIl[1], llllIllIllIl[2], llllIllIllIl[0]).getPos();
        if (lIlllIllllIllI(llllllllllllllIllIlIIIllIIlIlIIl.getFinger().getAxis(), EnumFacing.Axis.X))
        {
          "".length();
          if (" ".length() != 0) {
            break label458;
          }
        }
        label458:
        (llllllllllllllIllIlIIIllIIlIIIIl.getX() + 0.5D).setLocationAndAngles(llllllllllllllIllIlIIIllIIlIIIIl.getY() + 0.55D, llllllllllllllIllIlIIIllIIlIIIIl.getZ() + 0.5D, 0.0F, 90.0F, 0.0F);
        if (lIlllIllllIllI(llllllllllllllIllIlIIIllIIlIlIIl.getFinger().getAxis(), EnumFacing.Axis.X))
        {
          "".length();
          if ("   ".length() >= "  ".length()) {
            break label505;
          }
        }
        label505:
        0.0FrenderYawOffset = 90.0F;
        llllllllllllllIllIlIIIllIIlIIIlI.func_82206_m();
        llllllllllllllIllIlIIIllIIIlIIIl = llllllllllllllIllIlIIIllIIlIllIl.getEntitiesWithinAABB(EntityPlayer.class, llllllllllllllIllIlIIIllIIlIIIlI.getEntityBoundingBox().expand(50.0D, 50.0D, 50.0D)).iterator();
        "".length();
        if (null != null) {
          return;
        }
        while (!lIlllIllllIIIl(llllllllllllllIllIlIIIllIIIlIIIl.hasNext()))
        {
          EntityPlayer llllllllllllllIllIlIIIllIIlIIIII = (EntityPlayer)llllllllllllllIllIlIIIllIIIlIIIl.next();
          llllllllllllllIllIlIIIllIIlIIIII.triggerAchievement(AchievementList.spawnWither);
        }
        "".length();
        int llllllllllllllIllIlIIIllIIIlllll = llllIllIllIl[0];
        "".length();
        if ("   ".length() == (0x1B ^ 0x7 ^ 0x60 ^ 0x78)) {
          return;
        }
        while (!lIlllIllllIlII(llllllllllllllIllIlIIIllIIIlllll, llllIllIllIl[5])) {
          llllllllllllllIllIlIIIllIIlIllIl.spawnParticle(EnumParticleTypes.SNOWBALL, llllllllllllllIllIlIIIllIIlIIIll.getX() + rand.nextDouble(), llllllllllllllIllIlIIIllIIlIIIll.getY() - llllIllIllIl[2] + rand.nextDouble() * 3.9D, llllllllllllllIllIlIIIllIIlIIIll.getZ() + rand.nextDouble(), 0.0D, 0.0D, 0.0D, new int[llllIllIllIl[0]]);
        }
        int llllllllllllllIllIlIIIllIIIllllI = llllIllIllIl[0];
        "".length();
        if (null != null) {
          return;
        }
        while (!lIlllIllllIlII(llllllllllllllIllIlIIIllIIIllllI, llllllllllllllIllIlIIIllIIlIlIlI.getPalmLength()))
        {
          int llllllllllllllIllIlIIIllIIIlllIl = llllIllIllIl[0];
          "".length();
          if ("  ".length() == 0) {
            return;
          }
          while (!lIlllIllllIlII(llllllllllllllIllIlIIIllIIIlllIl, llllllllllllllIllIlIIIllIIlIlIlI.getThumbLength()))
          {
            BlockWorldState llllllllllllllIllIlIIIllIIIlllII = llllllllllllllIllIlIIIllIIlIlIIl.translateOffset(llllllllllllllIllIlIIIllIIIllllI, llllllllllllllIllIlIIIllIIIlllIl, llllIllIllIl[0]);
            llllllllllllllIllIlIIIllIIlIllIl.notifyNeighborsRespectDebug(llllllllllllllIllIlIIIllIIIlllII.getPos(), Blocks.air);
          }
        }
      }
    }
  }
  
  private static boolean lIlllIlllllIIl(int ???, int arg1)
  {
    int i;
    String llllllllllllllIllIlIIIlIlIlllIlI;
    return ??? < i;
  }
  
  private static boolean lIlllIllllIIlI(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIllIlIIIlIllIIIIlI;
    return ??? == i;
  }
  
  public boolean isFullCube()
  {
    return llllIllIllIl[0];
  }
  
  private static boolean lIlllIllllIIll(Object ???)
  {
    long llllllllllllllIllIlIIIlIlIllIlII;
    return ??? != null;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIllIlIIIllIIIIIIII, new IProperty[] { FACING, NODROP });
  }
  
  protected BlockPattern getWitherPattern()
  {
    ;
    if (lIlllIlllllIII(witherPattern)) {
      witherPattern = FactoryBlockPattern.start().aisle(new String[] { llllIllIlIlI[llllIllIllIl[6]], llllIllIlIlI[llllIllIllIl[7]], llllIllIlIlI[llllIllIllIl[12]] }).where(llllIllIllIl[10], BlockWorldState.hasState(BlockStateHelper.forBlock(Blocks.soul_sand))).where(llllIllIllIl[13], IS_WITHER_SKELETON).where(llllIllIllIl[11], BlockWorldState.hasState(BlockStateHelper.forBlock(Blocks.air))).build();
    }
    return witherPattern;
  }
  
  protected BlockPattern getWitherBasePattern()
  {
    ;
    if (lIlllIlllllIII(witherBasePattern)) {
      witherBasePattern = FactoryBlockPattern.start().aisle(new String[] { llllIllIlIlI[llllIllIllIl[3]], llllIllIlIlI[llllIllIllIl[8]], llllIllIlIlI[llllIllIllIl[9]] }).where(llllIllIllIl[10], BlockWorldState.hasState(BlockStateHelper.forBlock(Blocks.soul_sand))).where(llllIllIllIl[11], BlockWorldState.hasState(BlockStateHelper.forBlock(Blocks.air))).build();
    }
    return witherBasePattern;
  }
  
  public TileEntity createNewTileEntity(World llllllllllllllIllIlIIIlllIIIlIII, int llllllllllllllIllIlIIIlllIIIIlll)
  {
    return new TileEntitySkull();
  }
  
  public boolean isOpaqueCube()
  {
    return llllIllIllIl[0];
  }
  
  public void dropBlockAsItemWithChance(World llllllllllllllIllIlIIIllIlllIllI, BlockPos llllllllllllllIllIlIIIllIlllIlIl, IBlockState llllllllllllllIllIlIIIllIlllIlII, float llllllllllllllIllIlIIIllIlllIIll, int llllllllllllllIllIlIIIllIlllIIlI) {}
  
  protected BlockSkull()
  {
    llllllllllllllIllIlIIIlllIlIllll.<init>(Material.circuits);
    llllllllllllllIllIlIIIlllIllIIII.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(NODROP, Boolean.valueOf(llllIllIllIl[0])));
    llllllllllllllIllIlIIIlllIllIIII.setBlockBounds(0.25F, 0.0F, 0.25F, 0.75F, 0.5F, 0.75F);
  }
  
  public IBlockState onBlockPlaced(World llllllllllllllIllIlIIIlllIIlIIll, BlockPos llllllllllllllIllIlIIIlllIIlIIlI, EnumFacing llllllllllllllIllIlIIIlllIIlIIIl, float llllllllllllllIllIlIIIlllIIlIIII, float llllllllllllllIllIlIIIlllIIIllll, float llllllllllllllIllIlIIIlllIIIlllI, int llllllllllllllIllIlIIIlllIIIllIl, EntityLivingBase llllllllllllllIllIlIIIlllIIIllII)
  {
    ;
    ;
    return llllllllllllllIllIlIIIlllIIIlIll.getDefaultState().withProperty(FACING, llllllllllllllIllIlIIIlllIIIllII.getHorizontalFacing()).withProperty(NODROP, Boolean.valueOf(llllIllIllIl[0]));
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIllIlIIIllIIIIllII)
  {
    ;
    ;
    if (lIlllIllllIlll(llllllllllllllIllIlIIIllIIIIllII & llllIllIllIl[7]))
    {
      "".length();
      if (((0x40 ^ 0xB) & (0x19 ^ 0x52 ^ 0xFFFFFFFF)) > -" ".length()) {
        break label80;
      }
      return null;
    }
    label80:
    return NODROP.withProperty(llllIllIllIl[1], Boolean.valueOf(llllIllIllIl[0]));
  }
  
  private static boolean lIlllIlllIllll(int ???)
  {
    double llllllllllllllIllIlIIIlIlIlIllII;
    return ??? != 0;
  }
}

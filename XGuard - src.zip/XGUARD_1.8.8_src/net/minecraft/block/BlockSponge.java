package net.minecraft.block;

import com.google.common.collect.Lists;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.StatCollector;
import net.minecraft.util.Tuple;
import net.minecraft.world.World;

public class BlockSponge
  extends Block
{
  public int getMetaFromState(IBlockState llIIIlIlIlIIll)
  {
    ;
    if (lIlIIIllIlI(((Boolean)llIIIlIlIlIIll.getValue(WET)).booleanValue()))
    {
      "".length();
      if (null == null) {
        break label55;
      }
      return (0x45 ^ 0x6) & (0x52 ^ 0x11 ^ 0xFFFFFFFF);
    }
    label55:
    return llIIIlIII[0];
  }
  
  public int damageDropped(IBlockState llIIIllIllIIll)
  {
    ;
    if (lIlIIIllIlI(((Boolean)llIIIllIllIIll.getValue(WET)).booleanValue()))
    {
      "".length();
      if (-" ".length() < "  ".length()) {
        break label67;
      }
      return (0x23 ^ 0x64) & (0xEF ^ 0xA8 ^ 0xFFFFFFFF);
    }
    label67:
    return llIIIlIII[0];
  }
  
  public String getLocalizedName()
  {
    ;
    return StatCollector.translateToLocal(String.valueOf(new StringBuilder(String.valueOf(llIIIllIllIlll.getUnlocalizedName())).append(llIIIIlll[llIIIlIII[1]])));
  }
  
  private static boolean lIlIIIllIlI(int ???)
  {
    byte llIIIlIIIlIIII;
    return ??? != 0;
  }
  
  private static boolean lIlIIlIIIlI(Object ???, Object arg1)
  {
    Object localObject;
    byte llIIIlIIIlIllI;
    return ??? != localObject;
  }
  
  protected void tryAbsorb(World llIIIllIIIllIl, BlockPos llIIIllIIlIIII, IBlockState llIIIllIIIlIll)
  {
    ;
    ;
    ;
    ;
    if ((lIlIIIllIll(((Boolean)llIIIllIIIlIll.getValue(WET)).booleanValue())) && (lIlIIIllIlI(llIIIllIIIlllI.absorb(llIIIllIIIllIl, llIIIllIIlIIII))))
    {
      "".length();
      llIIIllIIIllIl.playAuxSFX(llIIIlIII[3], llIIIllIIlIIII, Block.getIdFromBlock(Blocks.water));
    }
  }
  
  private static void lIlIIIllIIl()
  {
    llIIIlIII = new int[7];
    llIIIlIII[0] = ((0x19 ^ 0x35) & (0x45 ^ 0x69 ^ 0xFFFFFFFF));
    llIIIlIII[1] = " ".length();
    llIIIlIII[2] = "  ".length();
    llIIIlIII[3] = (-(0xDFAB & 0x6057) & 0xE7DF & 0x5FF3);
    llIIIlIII[4] = (111 + '' - 179 + 78 ^ 75 + 8 - 3 + 75);
    llIIIlIII[5] = (0x40 ^ 0x7F ^ 11 + 98 - 1 + 19);
    llIIIlIII[6] = (124 + 103 - 77 + 31 ^ '' + '' - 128 + 17);
  }
  
  public void onNeighborBlockChange(World llIIIllIIlllll, BlockPos llIIIllIIllllI, IBlockState llIIIllIIlllIl, Block llIIIllIIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    llIIIllIIllIll.tryAbsorb(llIIIllIIlllll, llIIIllIIllIIl, llIIIllIIlllIl);
    llIIIllIIllIll.onNeighborBlockChange(llIIIllIIlllll, llIIIllIIllIIl, llIIIllIIlllIl, llIIIllIIlllII);
  }
  
  private static boolean lIlIIIlllII(Object ???, Object arg1)
  {
    Object localObject;
    double llIIIlIIIlIIlI;
    return ??? == localObject;
  }
  
  protected BlockSponge()
  {
    llIIIllIlllIIl.<init>(Material.sponge);
    llIIIllIlllIlI.setDefaultState(blockState.getBaseState().withProperty(WET, Boolean.valueOf(llIIIlIII[0])));
    "".length();
  }
  
  private static boolean lIlIIIllIll(int ???)
  {
    char llIIIlIIIIlllI;
    return ??? == 0;
  }
  
  private boolean absorb(World llIIIlIlllIIIl, BlockPos llIIIlIlllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Queue<Tuple<BlockPos, Integer>> llIIIlIllllIlI = Lists.newLinkedList();
    ArrayList<BlockPos> llIIIlIllllIIl = Lists.newArrayList();
    new Tuple(llIIIlIlllIIII, Integer.valueOf(llIIIlIII[0]));
    "".length();
    int llIIIlIllllIII = llIIIlIII[0];
    "".length();
    if (((0x13 ^ 0x33) & (0xB ^ 0x2B ^ 0xFFFFFFFF)) >= (0x1A ^ 0x1E)) {
      return (0xE2 ^ 0x83) & (0x2E ^ 0x4F ^ 0xFFFFFFFF);
    }
    while (!lIlIIIllIlI(llIIIlIllllIlI.isEmpty()))
    {
      Tuple<BlockPos, Integer> llIIIlIlllIlll = (Tuple)llIIIlIllllIlI.poll();
      llIIIlIlllIllI = (BlockPos)llIIIlIlllIlll.getFirst();
      int llIIIlIlllIlIl = ((Integer)llIIIlIlllIlll.getSecond()).intValue();
      llIIIlIllIIlll = (llIIIlIllIIllI = EnumFacing.values()).length;
      llIIIlIllIlIII = llIIIlIII[0];
      "".length();
      if (-" ".length() >= ((0xBE ^ 0x9F ^ 0x73 ^ 0x68) & (11 + 93 - 51 + 81 ^ 101 + 111 - 153 + 129 ^ -" ".length()))) {
        return (0x7D ^ 0x4A ^ 0x2C ^ 0x7B) & (0x66 ^ 0x4B ^ 0x43 ^ 0xE ^ -" ".length());
      }
      while (!lIlIIIllllI(llIIIlIllIlIII, llIIIlIllIIlll))
      {
        EnumFacing llIIIlIlllIlII = llIIIlIllIIllI[llIIIlIllIlIII];
        BlockPos llIIIlIlllIIll = llIIIlIlllIllI.offset(llIIIlIlllIlII);
        if (lIlIIIlllII(llIIIlIlllIIIl.getBlockState(llIIIlIlllIIll).getBlock().getMaterial(), Material.water))
        {
          "".length();
          "".length();
          llIIIlIllllIII++;
          if (lIlIIIlllIl(llIIIlIlllIlIl, llIIIlIII[4]))
          {
            new Tuple(llIIIlIlllIIll, Integer.valueOf(llIIIlIlllIlIl + llIIIlIII[1]));
            "".length();
          }
        }
        llIIIlIllIlIII++;
      }
      if (lIlIIIlllll(llIIIlIllllIII, llIIIlIII[5]))
      {
        "".length();
        if (-" ".length() < " ".length()) {
          break;
        }
        return (0x87 ^ 0x96 ^ 0x58 ^ 0x52) & (0x7B ^ 0x58 ^ 0x3F ^ 0x7 ^ -" ".length());
      }
    }
    BlockPos llIIIlIlllIllI = llIIIlIllllIIl.iterator();
    "".length();
    if ((0x9D ^ 0x99) == "   ".length()) {
      return (0xA7 ^ 0xAC) & (0xA2 ^ 0xA9 ^ 0xFFFFFFFF);
    }
    while (!lIlIIIllIll(llIIIlIlllIllI.hasNext()))
    {
      BlockPos llIIIlIlllIIlI = (BlockPos)llIIIlIlllIllI.next();
      llIIIlIlllIIIl.notifyNeighborsOfStateChange(llIIIlIlllIIlI, Blocks.air);
    }
    if (lIlIIlIIIII(llIIIlIllllIII)) {
      return llIIIlIII[1];
    }
    return llIIIlIII[0];
  }
  
  private static boolean lIlIIlIIIIl(int ???, int arg1)
  {
    int i;
    double llIIIlIIlIIllI;
    return ??? == i;
  }
  
  public void randomDisplayTick(World llIIIlIIlllllI, BlockPos llIIIlIlIIIlIl, IBlockState llIIIlIIllllII, Random llIIIlIIlllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIIIllIlI(((Boolean)llIIIlIIllllII.getValue(WET)).booleanValue()))
    {
      EnumFacing llIIIlIlIIIIlI = EnumFacing.random(llIIIlIIlllIll);
      if ((lIlIIlIIIlI(llIIIlIlIIIIlI, EnumFacing.UP)) && (lIlIIIllIll(World.doesBlockHaveSolidTopSurface(llIIIlIIlllllI, llIIIlIlIIIlIl.offset(llIIIlIlIIIIlI)))))
      {
        double llIIIlIlIIIIIl = llIIIlIlIIIlIl.getX();
        double llIIIlIlIIIIII = llIIIlIlIIIlIl.getY();
        double llIIIlIIllllll = llIIIlIlIIIlIl.getZ();
        if (lIlIIIlllII(llIIIlIlIIIIlI, EnumFacing.DOWN))
        {
          llIIIlIlIIIIII -= 0.05D;
          llIIIlIlIIIIIl += llIIIlIIlllIll.nextDouble();
          llIIIlIIllllll += llIIIlIIlllIll.nextDouble();
          "".length();
          if (-"  ".length() < 0) {}
        }
        else
        {
          llIIIlIlIIIIII += llIIIlIIlllIll.nextDouble() * 0.8D;
          if (lIlIIIlllII(llIIIlIlIIIIlI.getAxis(), EnumFacing.Axis.X))
          {
            llIIIlIIllllll += llIIIlIIlllIll.nextDouble();
            if (lIlIIIlllII(llIIIlIlIIIIlI, EnumFacing.EAST))
            {
              llIIIlIlIIIIIl += 1.0D;
              "".length();
              if (" ".length() >= 0) {}
            }
            else
            {
              llIIIlIlIIIIIl += 0.05D;
              "".length();
              if ("   ".length() <= (0xAD ^ 0x91 ^ 0x3F ^ 0x7)) {}
            }
          }
          else
          {
            llIIIlIlIIIIIl += llIIIlIIlllIll.nextDouble();
            if (lIlIIIlllII(llIIIlIlIIIIlI, EnumFacing.SOUTH))
            {
              llIIIlIIllllll += 1.0D;
              "".length();
              if (null == null) {}
            }
            else
            {
              llIIIlIIllllll += 0.05D;
            }
          }
        }
        llIIIlIIlllllI.spawnParticle(EnumParticleTypes.DRIP_WATER, llIIIlIlIIIIIl, llIIIlIlIIIIII, llIIIlIIllllll, 0.0D, 0.0D, 0.0D, new int[llIIIlIII[0]]);
      }
    }
  }
  
  private static String lIlIIIlIlII(String llIIIlIIlIllll, String llIIIlIIlIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIIIlIIllIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llIIIlIIlIllII.getBytes(StandardCharsets.UTF_8)), llIIIlIII[6]), "DES");
      Cipher llIIIlIIllIIIl = Cipher.getInstance("DES");
      llIIIlIIllIIIl.init(llIIIlIII[2], llIIIlIIllIIlI);
      return new String(llIIIlIIllIIIl.doFinal(Base64.getDecoder().decode(llIIIlIIlIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIIIlIIllIIII)
    {
      llIIIlIIllIIII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlIIIllllI(int ???, int arg1)
  {
    int i;
    float llIIIlIIlIIIlI;
    return ??? >= i;
  }
  
  public void getSubBlocks(Item llIIIlIllIIIIl, CreativeTabs llIIIlIllIIIII, List<ItemStack> llIIIlIlIlllIl)
  {
    ;
    ;
    new ItemStack(llIIIlIllIIIIl, llIIIlIII[1], llIIIlIII[0]);
    "".length();
    new ItemStack(llIIIlIllIIIIl, llIIIlIII[1], llIIIlIII[1]);
    "".length();
  }
  
  public IBlockState getStateFromMeta(int llIIIlIlIlIlll)
  {
    ;
    ;
    if (lIlIIlIIIIl(llIIIlIlIlIlll & llIIIlIII[1], llIIIlIII[1]))
    {
      "".length();
      if (-(86 + 62 - 69 + 49 ^ 15 + 73 - 25 + 69) < 0) {
        break label70;
      }
      return null;
    }
    label70:
    return WET.withProperty(llIIIlIII[1], Boolean.valueOf(llIIIlIII[0]));
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llIIIlIlIlIIII, new IProperty[] { WET });
  }
  
  private static boolean lIlIIIlllIl(int ???, int arg1)
  {
    int i;
    String llIIIlIIIllllI;
    return ??? < i;
  }
  
  public void onBlockAdded(World llIIIllIlIlIII, BlockPos llIIIllIlIlIll, IBlockState llIIIllIlIlIlI)
  {
    ;
    ;
    ;
    ;
    llIIIllIlIlIIl.tryAbsorb(llIIIllIlIlIII, llIIIllIlIlIll, llIIIllIlIlIlI);
  }
  
  private static boolean lIlIIIlllll(int ???, int arg1)
  {
    int i;
    float llIIIlIIIllIlI;
    return ??? > i;
  }
  
  private static void lIlIIIlIlIl()
  {
    llIIIIlll = new String[llIIIlIII[2]];
    llIIIIlll[llIIIlIII[0]] = lIlIIIlIlII("1kkvEWHfkZc=", "rnvEs");
    llIIIIlll[llIIIlIII[1]] = lIlIIIlIlII("0oZW54AcQ0t2dJJgFoFTGg==", "AZgnm");
  }
  
  private static boolean lIlIIlIIIII(int ???)
  {
    char llIIIlIIIIllII;
    return ??? > 0;
  }
  
  static
  {
    lIlIIIllIIl();
    lIlIIIlIlIl();
  }
}

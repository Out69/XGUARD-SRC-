package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockButton
  extends Block
{
  static
  {
    lIIIIIllIl();
    lIIIIIIllI();
  }
  
  public boolean canPlaceBlockAt(World llIIIIlIlIIIIII, BlockPos llIIIIlIIllllII)
  {
    ;
    ;
    ;
    ;
    boolean llIIIIlIIlllIIl = (llIIIIlIIlllIII = EnumFacing.values()).length;
    Exception llIIIIlIIlllIlI = lIlIIIll[0];
    "".length();
    if (((0xDF ^ 0xC2) & (0xB1 ^ 0xAC ^ 0xFFFFFFFF)) >= "   ".length()) {
      return (0x8E ^ 0x9A) & (0x39 ^ 0x2D ^ 0xFFFFFFFF);
    }
    while (!lIIIIIllll(llIIIIlIIlllIlI, llIIIIlIIlllIIl))
    {
      EnumFacing llIIIIlIIlllllI = llIIIIlIIlllIII[llIIIIlIIlllIlI];
      if (lIIIIIlllI(func_181088_a(llIIIIlIlIIIIII, llIIIIlIIllllII, llIIIIlIIlllllI))) {
        return lIlIIIll[1];
      }
      llIIIIlIIlllIlI++;
    }
    return lIlIIIll[0];
  }
  
  public boolean canProvidePower()
  {
    return lIlIIIll[1];
  }
  
  public void randomTick(World llIIIIIlIlIlllI, BlockPos llIIIIIlIlIllIl, IBlockState llIIIIIlIlIllII, Random llIIIIIlIlIlIll) {}
  
  private static boolean lIIIIlIIII(Object ???, Object arg1)
  {
    Object localObject;
    byte llIIIIIIIIIIlll;
    return ??? == localObject;
  }
  
  public boolean isOpaqueCube()
  {
    return lIlIIIll[0];
  }
  
  private static String lllllllII(String llIIIIIIIIlIllI, String llIIIIIIIIlIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIIIIIIIIllIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llIIIIIIIIlIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llIIIIIIIIllIlI = Cipher.getInstance("Blowfish");
      llIIIIIIIIllIlI.init(lIlIIIll[4], llIIIIIIIIllIll);
      return new String(llIIIIIIIIllIlI.doFinal(Base64.getDecoder().decode(llIIIIIIIIlIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIIIIIIIIllIIl)
    {
      llIIIIIIIIllIIl.printStackTrace();
    }
    return null;
  }
  
  public boolean isFullCube()
  {
    return lIlIIIll[0];
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    ;
    ;
    ;
    float llIIIIIlIIllIII = 0.1875F;
    float llIIIIIlIIlIlll = 0.125F;
    float llIIIIIlIIlIllI = 0.125F;
    llIIIIIlIIlIlIl.setBlockBounds(0.5F - llIIIIIlIIllIII, 0.5F - llIIIIIlIIlIlll, 0.5F - llIIIIIlIIlIllI, 0.5F + llIIIIIlIIllIII, 0.5F + llIIIIIlIIlIlll, 0.5F + llIIIIIlIIlIllI);
  }
  
  public int tickRate(World llIIIIlIlIlIlIl)
  {
    ;
    if (lIIIIIlllI(wooden))
    {
      "".length();
      if (-" ".length() == -" ".length()) {
        break label57;
      }
      return (0x28 ^ 0x39) & (0xA0 ^ 0xB1 ^ 0xFFFFFFFF);
    }
    label57:
    return lIlIIIll[3];
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llIIIIIIlIIIlll, new IProperty[] { FACING, POWERED });
  }
  
  private static boolean lIIIIlIIlI(int ???)
  {
    int lIlllllllllllll;
    return ??? > 0;
  }
  
  public void breakBlock(World llIIIIIllIIIlll, BlockPos llIIIIIllIIIllI, IBlockState llIIIIIllIIIlIl)
  {
    ;
    ;
    ;
    ;
    if (lIIIIIlllI(((Boolean)llIIIIIllIIIlIl.getValue(POWERED)).booleanValue())) {
      llIIIIIllIIIlII.notifyNeighbors(llIIIIIllIIIlll, llIIIIIllIIIllI, (EnumFacing)llIIIIIllIIIlIl.getValue(FACING));
    }
    llIIIIIllIIIlII.breakBlock(llIIIIIllIIIlll, llIIIIIllIIIllI, llIIIIIllIIIlIl);
  }
  
  private static void lIIIIIllIl()
  {
    lIlIIIll = new int[12];
    lIlIIIll[0] = ((0xF3 ^ 0xA2 ^ 0x25 ^ 0x7F) & (0xBC ^ 0x86 ^ 0xBD ^ 0x8C ^ -" ".length()));
    lIlIIIll[1] = " ".length();
    lIlIIIll[2] = (0x23 ^ 0x19 ^ 0x58 ^ 0x7C);
    lIlIIIll[3] = (0x41 ^ 0x54 ^ " ".length());
    lIlIIIll[4] = "  ".length();
    lIlIIIll[5] = "   ".length();
    lIlIIIll[6] = (0x92 ^ 0xBE ^ 0x9D ^ 0xBE);
    lIlIIIll[7] = (0x6E ^ 0x6A);
    lIlIIIll[8] = (0x6F ^ 0x7E ^ 0xB0 ^ 0xA4);
    lIlIIIll[9] = ('' + 73 - 97 + 59 ^ 116 + 125 - 234 + 170);
    lIlIIIll[10] = (0x44 ^ 0x4C);
    lIlIIIll[11] = (0x73 ^ 0x5B ^ 0x0 ^ 0x2E);
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llIIIIIllllllIl, BlockPos llIIIIIllllllII)
  {
    ;
    ;
    ;
    llIIIIIlllllIll.updateBlockBounds(llIIIIIlllllIlI.getBlockState(llIIIIIllllllII));
  }
  
  public void updateTick(World llIIIIIlIlIIIII, BlockPos llIIIIIlIIlllll, IBlockState llIIIIIlIIllllI, Random llIIIIIlIlIIIlI)
  {
    ;
    ;
    ;
    ;
    if ((lIIIIlIIIl(isRemote)) && (lIIIIIlllI(((Boolean)llIIIIIlIIllllI.getValue(POWERED)).booleanValue()))) {
      if (lIIIIIlllI(wooden))
      {
        llIIIIIlIlIIIIl.checkForArrows(llIIIIIlIlIIIII, llIIIIIlIlIIlII, llIIIIIlIIllllI);
        "".length();
        if (" ".length() != 0) {}
      }
      else
      {
        "".length();
        llIIIIIlIlIIIIl.notifyNeighbors(llIIIIIlIlIIIII, llIIIIIlIlIIlII, (EnumFacing)llIIIIIlIIllllI.getValue(FACING));
        llIIIIIlIlIIIII.playSoundEffect(llIIIIIlIlIIlII.getX() + 0.5D, llIIIIIlIlIIlII.getY() + 0.5D, llIIIIIlIlIIlII.getZ() + 0.5D, lIlIIIIl[lIlIIIll[5]], 0.3F, 0.5F);
        llIIIIIlIlIIIII.markBlockRangeForRenderUpdate(llIIIIIlIlIIlII, llIIIIIlIlIIlII);
      }
    }
  }
  
  public IBlockState onBlockPlaced(World llIIIIlIIlIIllI, BlockPos llIIIIlIIlIIlIl, EnumFacing llIIIIlIIlIIlII, float llIIIIlIIlIIIll, float llIIIIlIIlIIIlI, float llIIIIlIIlIIIIl, int llIIIIlIIlIIIII, EntityLivingBase llIIIIlIIIlllll)
  {
    ;
    ;
    ;
    ;
    if (lIIIIIlllI(func_181088_a(llIIIIlIIlIIllI, llIIIIlIIlIIlIl, llIIIIlIIlIIlII.getOpposite())))
    {
      "".length();
      if (((28 + 19 - 16 + 103 ^ 64 + '' - 96 + 64) & ('' + 93 - 155 + 95 ^ 51 + '' - 149 + 113 ^ -" ".length())) == 0) {
        break label145;
      }
      return null;
    }
    label145:
    return llIIIIlIIIllllI.getDefaultState().withProperty(FACING, EnumFacing.DOWN).withProperty(POWERED, Boolean.valueOf(lIlIIIll[0]));
  }
  
  protected BlockButton(boolean llIIIIlIlIlllII)
  {
    llIIIIlIlIlllIl.<init>(Material.circuits);
    llIIIIlIlIlllIl.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(POWERED, Boolean.valueOf(lIlIIIll[0])));
    "".length();
    "".length();
    wooden = llIIIIlIlIlllII;
  }
  
  private static boolean lIIIIIllll(int ???, int arg1)
  {
    int i;
    short llIIIIIIIIIllll;
    return ??? >= i;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llIIIIlIlIllIlI, BlockPos llIIIIlIlIllIIl, IBlockState llIIIIlIlIllIII)
  {
    return null;
  }
  
  public void onEntityCollidedWithBlock(World llIIIIIlIIIllII, BlockPos llIIIIIlIIIIllI, IBlockState llIIIIIlIIIIlIl, Entity llIIIIIlIIIlIIl)
  {
    ;
    ;
    ;
    ;
    if ((lIIIIlIIIl(isRemote)) && (lIIIIIlllI(wooden)) && (lIIIIlIIIl(((Boolean)llIIIIIlIIIIlIl.getValue(POWERED)).booleanValue()))) {
      llIIIIIlIIIlIII.checkForArrows(llIIIIIlIIIllII, llIIIIIlIIIlIll, llIIIIIlIIIIlIl);
    }
  }
  
  private static boolean lIIIIlIIIl(int ???)
  {
    float llIIIIIIIIIIIIl;
    return ??? == 0;
  }
  
  public IBlockState getStateFromMeta(int llIIIIIIlIlIlll)
  {
    ;
    ;
    ;
    EnumFacing llIIIIIIlIllIIl;
    switch (llIIIIIIlIlIlll & lIlIIIll[9])
    {
    case 0: 
      EnumFacing llIIIIIIlIllllI = EnumFacing.DOWN;
      "".length();
      if (-(0x2F ^ 0x60 ^ 0x4F ^ 0x4) >= 0) {
        return null;
      }
      break;
    case 1: 
      EnumFacing llIIIIIIlIlllIl = EnumFacing.EAST;
      "".length();
      if (" ".length() <= -" ".length()) {
        return null;
      }
      break;
    case 2: 
      EnumFacing llIIIIIIlIlllII = EnumFacing.WEST;
      "".length();
      if ((0x89 ^ 0x8D) <= 0) {
        return null;
      }
      break;
    case 3: 
      EnumFacing llIIIIIIlIllIll = EnumFacing.SOUTH;
      "".length();
      if ("  ".length() <= -" ".length()) {
        return null;
      }
      break;
    case 4: 
      EnumFacing llIIIIIIlIllIlI = EnumFacing.NORTH;
      "".length();
      if ("  ".length() >= (0x39 ^ 0x6F ^ 0x3F ^ 0x6D)) {
        return null;
      }
      break;
    case 5: 
    default: 
      llIIIIIIlIllIIl = EnumFacing.UP;
    }
    if (lIIIIlIIlI(llIIIIIIlIlIlll & lIlIIIll[10]))
    {
      "".length();
      if (-" ".length() != "  ".length()) {
        break label248;
      }
      return null;
    }
    label248:
    return POWERED.withProperty(lIlIIIll[1], Boolean.valueOf(lIlIIIll[0]));
  }
  
  private static void lIIIIIIllI()
  {
    lIlIIIIl = new String[lIlIIIll[11]];
    lIlIIIIl[lIlIIIll[0]] = llllllIll("DAwuAz4N", "jmMjP");
    lIlIIIIl[lIlIIIll[1]] = lllllllII("94ZLZv+PNRE=", "vcmVE");
    lIlIIIIl[lIlIIIll[4]] = llllllIll("Iw8bMw48QBY7CDIF", "QnuWa");
    lIlIIIIl[lIlIIIll[5]] = lllllllII("wDoYW7jQgzpgLHG6VmFwNw==", "GiDPO");
    lIlIIIIl[lIlIIIll[7]] = lIIIIIIlIl("Jo7QeY6qgIc0aTMNpdpcKA==", "JYbdB");
    lIlIIIIl[lIlIIIll[8]] = llllllIll("PC8MFQEjYAEdBy0l", "NNbqn");
  }
  
  public boolean onBlockActivated(World llIIIIIllIllIII, BlockPos llIIIIIllIlIlll, IBlockState llIIIIIllIIllIl, EntityPlayer llIIIIIllIlIlIl, EnumFacing llIIIIIllIlIlII, float llIIIIIllIlIIll, float llIIIIIllIlIIlI, float llIIIIIllIlIIIl)
  {
    ;
    ;
    ;
    ;
    if (lIIIIIlllI(((Boolean)llIIIIIllIIllIl.getValue(POWERED)).booleanValue())) {
      return lIlIIIll[1];
    }
    "".length();
    llIIIIIllIllIII.markBlockRangeForRenderUpdate(llIIIIIllIlIlll, llIIIIIllIlIlll);
    llIIIIIllIllIII.playSoundEffect(llIIIIIllIlIlll.getX() + 0.5D, llIIIIIllIlIlll.getY() + 0.5D, llIIIIIllIlIlll.getZ() + 0.5D, lIlIIIIl[lIlIIIll[4]], 0.3F, 0.6F);
    llIIIIIllIllIIl.notifyNeighbors(llIIIIIllIllIII, llIIIIIllIlIlll, (EnumFacing)llIIIIIllIIllIl.getValue(FACING));
    llIIIIIllIllIII.scheduleUpdate(llIIIIIllIlIlll, llIIIIIllIllIIl, llIIIIIllIllIIl.tickRate(llIIIIIllIllIII));
    return lIlIIIll[1];
  }
  
  public boolean canPlaceBlockOnSide(World llIIIIlIlIIllIl, BlockPos llIIIIlIlIIllII, EnumFacing llIIIIlIlIIlIll)
  {
    ;
    ;
    ;
    return func_181088_a(llIIIIlIlIIllIl, llIIIIlIlIIlIIl, llIIIIlIlIIlIll.getOpposite());
  }
  
  private static boolean lIIIIlIlII(int ???, int arg1)
  {
    int i;
    short llIIIIIIIIIlIll;
    return ??? < i;
  }
  
  public int getMetaFromState(IBlockState llIIIIIIlIlIIlI)
  {
    ;
    ;
    int llIIIIIIlIIllII;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[((EnumFacing)llIIIIIIlIIlIll.getValue(FACING)).ordinal()])
    {
    case 6: 
      int llIIIIIIlIlIIIl = lIlIIIll[1];
      "".length();
      if (null != null) {
        return (0x7C ^ 0x2D ^ 0x2B ^ 0x2D) & ((0xE1 ^ 0x83) & (0x46 ^ 0x24 ^ 0xFFFFFFFF) ^ 0x26 ^ 0x71 ^ -" ".length());
      }
      break;
    case 5: 
      int llIIIIIIlIlIIII = lIlIIIll[4];
      "".length();
      if (-"  ".length() >= 0) {
        return (0x1C ^ 0x10 ^ 0x61 ^ 0x25) & (0xDB ^ 0x88 ^ 0xDE ^ 0xC5 ^ -" ".length());
      }
      break;
    case 4: 
      int llIIIIIIlIIllll = lIlIIIll[5];
      "".length();
      if (((0x7A ^ 0x2F) & (0x61 ^ 0x34 ^ 0xFFFFFFFF)) > ((0x7B ^ 0x21) & (0x45 ^ 0x1F ^ 0xFFFFFFFF))) {
        return (0xB4 ^ 0x9E) & (0x56 ^ 0x7C ^ 0xFFFFFFFF);
      }
      break;
    case 3: 
      int llIIIIIIlIIlllI = lIlIIIll[7];
      "".length();
      if ((85 + 81 - 125 + 151 ^ 98 + '°' - 128 + 50) <= 0) {
        return (0x46 ^ 0x57 ^ 0x6 ^ 0x47) & ('¨' + 42 - 129 + 136 ^ 6 + 76 - -6 + 49 ^ -" ".length());
      }
      break;
    case 2: 
    default: 
      int llIIIIIIlIIllIl = lIlIIIll[8];
      "".length();
      if (-" ".length() >= 0) {
        return (0xE0 ^ 0xB9) & (0x2D ^ 0x74 ^ 0xFFFFFFFF);
      }
      break;
    case 1: 
      llIIIIIIlIIllII = lIlIIIll[0];
    }
    if (lIIIIIlllI(((Boolean)llIIIIIIlIIlIll.getValue(POWERED)).booleanValue())) {
      llIIIIIIlIIllII |= lIlIIIll[10];
    }
    return llIIIIIIlIIllII;
  }
  
  public int getStrongPower(IBlockAccess llIIIIIlIllIllI, BlockPos llIIIIIlIllIlIl, IBlockState llIIIIIlIllIIlI, EnumFacing llIIIIIlIllIIll)
  {
    ;
    ;
    if (lIIIIlIIIl(((Boolean)llIIIIIlIllIIlI.getValue(POWERED)).booleanValue()))
    {
      "".length();
      if (" ".length() < 0) {
        return (0x61 ^ 0x29) & (0x2A ^ 0x62 ^ 0xFFFFFFFF);
      }
    }
    else if (lIIIIlIIII(llIIIIIlIllIIlI.getValue(FACING), llIIIIIlIllIIll))
    {
      "".length();
      if ("   ".length() != 0) {
        break label139;
      }
      return (0xAA ^ 0xB4 ^ 0x5A ^ 0x79) & ((0x6 ^ 0x23) & (0xB0 ^ 0x95 ^ 0xFFFFFFFF) ^ 0x30 ^ 0xD ^ -" ".length());
    }
    label139:
    return lIlIIIll[0];
  }
  
  private void notifyNeighbors(World llIIIIIIllIIllI, BlockPos llIIIIIIllIlIIl, EnumFacing llIIIIIIllIIlII)
  {
    ;
    ;
    ;
    ;
    llIIIIIIllIIllI.notifyNeighborsOfStateChange(llIIIIIIllIlIIl, llIIIIIIllIIlll);
    llIIIIIIllIIllI.notifyNeighborsOfStateChange(llIIIIIIllIlIIl.offset(llIIIIIIllIIlII.getOpposite()), llIIIIIIllIIlll);
  }
  
  private static String lIIIIIIlIl(String llIIIIIIIlIIIll, String llIIIIIIIlIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIIIIIIIlIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llIIIIIIIlIIIlI.getBytes(StandardCharsets.UTF_8)), lIlIIIll[10]), "DES");
      Cipher llIIIIIIIlIIlll = Cipher.getInstance("DES");
      llIIIIIIIlIIlll.init(lIlIIIll[4], llIIIIIIIlIlIII);
      return new String(llIIIIIIIlIIlll.doFinal(Base64.getDecoder().decode(llIIIIIIIlIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIIIIIIIlIIllI)
    {
      llIIIIIIIlIIllI.printStackTrace();
    }
    return null;
  }
  
  private static String llllllIll(String llIIIIIIIllIlIl, String llIIIIIIIllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llIIIIIIIllIlIl = new String(Base64.getDecoder().decode(llIIIIIIIllIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llIIIIIIIlllIII = new StringBuilder();
    char[] llIIIIIIIllIlll = llIIIIIIIllIlII.toCharArray();
    int llIIIIIIIllIllI = lIlIIIll[0];
    short llIIIIIIIllIIII = llIIIIIIIllIlIl.toCharArray();
    int llIIIIIIIlIllll = llIIIIIIIllIIII.length;
    double llIIIIIIIlIlllI = lIlIIIll[0];
    while (lIIIIlIlII(llIIIIIIIlIlllI, llIIIIIIIlIllll))
    {
      char llIIIIIIIlllIll = llIIIIIIIllIIII[llIIIIIIIlIlllI];
      "".length();
      "".length();
      if (-"   ".length() >= 0) {
        return null;
      }
    }
    return String.valueOf(llIIIIIIIlllIII);
  }
  
  public int getWeakPower(IBlockAccess llIIIIIlIlllllI, BlockPos llIIIIIlIllllIl, IBlockState llIIIIIlIllllII, EnumFacing llIIIIIlIlllIll)
  {
    ;
    if (lIIIIIlllI(((Boolean)llIIIIIlIllllII.getValue(POWERED)).booleanValue()))
    {
      "".length();
      if ("   ".length() <= (40 + 61 - -6 + 85 ^ 111 + 49 - -5 + 31)) {
        break label117;
      }
      return (0x59 ^ 0x76 ^ 0x8E ^ 0x85) & ('§' + 85 - 205 + 131 ^ 26 + 67 - 31 + 88 ^ -" ".length());
    }
    label117:
    return lIlIIIll[0];
  }
  
  protected static boolean func_181088_a(World llIIIIlIIllIIll, BlockPos llIIIIlIIllIIlI, EnumFacing llIIIIlIIllIIIl)
  {
    ;
    ;
    ;
    ;
    BlockPos llIIIIlIIllIIII = llIIIIlIIllIIlI.offset(llIIIIlIIllIIIl);
    if (lIIIIlIIII(llIIIIlIIllIIIl, EnumFacing.DOWN))
    {
      "".length();
      if ("  ".length() != 0) {
        break label96;
      }
      return ('' + 6 - 89 + 187 ^ 107 + 103 - 179 + 159) & (0x46 ^ 0x54 ^ 0xE ^ 0x58 ^ -" ".length());
    }
    label96:
    return llIIIIlIIllIIll.getBlockState(llIIIIlIIllIIII).getBlock().isNormalCube();
  }
  
  private static boolean lIIIIlIIll(Object ???)
  {
    long llIIIIIIIIIIlIl;
    return ??? != null;
  }
  
  private static boolean lIIIIIlllI(int ???)
  {
    double llIIIIIIIIIIIll;
    return ??? != 0;
  }
  
  private void checkForArrows(World llIIIIIIlllllII, BlockPos llIIIIIIlllIlII, IBlockState llIIIIIIllllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llIIIIIIlllIllI.updateBlockBounds(llIIIIIIllllIlI);
    List<? extends Entity> llIIIIIIllllIIl = llIIIIIIlllllII.getEntitiesWithinAABB(EntityArrow.class, new AxisAlignedBB(llIIIIIIlllIlII.getX() + minX, llIIIIIIlllIlII.getY() + minY, llIIIIIIlllIlII.getZ() + minZ, llIIIIIIlllIlII.getX() + maxX, llIIIIIIlllIlII.getY() + maxY, llIIIIIIlllIlII.getZ() + maxZ));
    if (lIIIIIlllI(llIIIIIIllllIIl.isEmpty()))
    {
      "".length();
      if ("  ".length() != "   ".length()) {
        break label125;
      }
    }
    label125:
    boolean llIIIIIIllllIII = lIlIIIll[1];
    boolean llIIIIIIlllIlll = ((Boolean)llIIIIIIllllIlI.getValue(POWERED)).booleanValue();
    if ((lIIIIIlllI(llIIIIIIllllIII)) && (lIIIIlIIIl(llIIIIIIlllIlll)))
    {
      "".length();
      llIIIIIIlllIllI.notifyNeighbors(llIIIIIIlllllII, llIIIIIIlllIlII, (EnumFacing)llIIIIIIllllIlI.getValue(FACING));
      llIIIIIIlllllII.markBlockRangeForRenderUpdate(llIIIIIIlllIlII, llIIIIIIlllIlII);
      llIIIIIIlllllII.playSoundEffect(llIIIIIIlllIlII.getX() + 0.5D, llIIIIIIlllIlII.getY() + 0.5D, llIIIIIIlllIlII.getZ() + 0.5D, lIlIIIIl[lIlIIIll[7]], 0.3F, 0.6F);
    }
    if ((lIIIIlIIIl(llIIIIIIllllIII)) && (lIIIIIlllI(llIIIIIIlllIlll)))
    {
      "".length();
      llIIIIIIlllIllI.notifyNeighbors(llIIIIIIlllllII, llIIIIIIlllIlII, (EnumFacing)llIIIIIIllllIlI.getValue(FACING));
      llIIIIIIlllllII.markBlockRangeForRenderUpdate(llIIIIIIlllIlII, llIIIIIIlllIlII);
      llIIIIIIlllllII.playSoundEffect(llIIIIIIlllIlII.getX() + 0.5D, llIIIIIIlllIlII.getY() + 0.5D, llIIIIIIlllIlII.getZ() + 0.5D, lIlIIIIl[lIlIIIll[8]], 0.3F, 0.5F);
    }
    if (lIIIIIlllI(llIIIIIIllllIII)) {
      llIIIIIIlllllII.scheduleUpdate(llIIIIIIlllIlII, llIIIIIIlllIllI, llIIIIIIlllIllI.tickRate(llIIIIIIlllllII));
    }
  }
  
  public void onNeighborBlockChange(World llIIIIlIIIlIlIl, BlockPos llIIIIlIIIIllll, IBlockState llIIIIlIIIlIIll, Block llIIIIlIIIlIIlI)
  {
    ;
    ;
    ;
    ;
    if ((lIIIIIlllI(llIIIIlIIIlIllI.checkForDrop(llIIIIlIIIlIlIl, llIIIIlIIIlIlII, llIIIIlIIIlIIll))) && (lIIIIlIIIl(func_181088_a(llIIIIlIIIlIlIl, llIIIIlIIIlIlII, ((EnumFacing)llIIIIlIIIlIIll.getValue(FACING)).getOpposite()))))
    {
      llIIIIlIIIlIllI.dropBlockAsItem(llIIIIlIIIlIlIl, llIIIIlIIIlIlII, llIIIIlIIIlIIll, lIlIIIll[0]);
      "".length();
    }
  }
  
  private boolean checkForDrop(World llIIIIlIIIIlIII, BlockPos llIIIIlIIIIIIll, IBlockState llIIIIlIIIIIIlI)
  {
    ;
    ;
    ;
    ;
    if (lIIIIIlllI(llIIIIlIIIIlIIl.canPlaceBlockAt(llIIIIlIIIIlIII, llIIIIlIIIIIIll))) {
      return lIlIIIll[1];
    }
    llIIIIlIIIIlIIl.dropBlockAsItem(llIIIIlIIIIlIII, llIIIIlIIIIIIll, llIIIIlIIIIIIlI, lIlIIIll[0]);
    "".length();
    return lIlIIIll[0];
  }
  
  private void updateBlockBounds(IBlockState llIIIIIlllIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing llIIIIIlllIllIl = (EnumFacing)llIIIIIlllIlllI.getValue(FACING);
    boolean llIIIIIlllIllII = ((Boolean)llIIIIIlllIlllI.getValue(POWERED)).booleanValue();
    float llIIIIIlllIlIll = 0.25F;
    float llIIIIIlllIlIlI = 0.375F;
    if (lIIIIIlllI(llIIIIIlllIllII))
    {
      "".length();
      if ("   ".length() >= 0) {
        break label71;
      }
    }
    label71:
    float llIIIIIlllIlIIl = lIlIIIll[4] / 16.0F;
    float llIIIIIlllIlIII = 0.125F;
    float llIIIIIlllIIlll = 0.1875F;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[llIIIIIlllIllIl.ordinal()])
    {
    case 6: 
      llIIIIIlllIIllI.setBlockBounds(0.0F, 0.375F, 0.3125F, llIIIIIlllIlIIl, 0.625F, 0.6875F);
      "".length();
      if (((54 + 53 - -13 + 39 ^ 99 + 117 - 114 + 59) & (0x6 ^ 0x7D ^ 0x55 ^ 0x10 ^ -" ".length())) != 0) {}
      break;
    case 5: 
      llIIIIIlllIIllI.setBlockBounds(1.0F - llIIIIIlllIlIIl, 0.375F, 0.3125F, 1.0F, 0.625F, 0.6875F);
      "".length();
      if (((111 + 13 - 47 + 54 ^ '' + '' - 175 + 53) & (0xD ^ 0x23 ^ 0x9F ^ 0xA0 ^ -" ".length())) != 0) {}
      break;
    case 4: 
      llIIIIIlllIIllI.setBlockBounds(0.3125F, 0.375F, 0.0F, 0.6875F, 0.625F, llIIIIIlllIlIIl);
      "".length();
      if (((0xB2 ^ 0x97 ^ 0x4F ^ 0x57) & (0xD3 ^ 0xB4 ^ 0x2 ^ 0x58 ^ -" ".length())) != 0) {}
      break;
    case 3: 
      llIIIIIlllIIllI.setBlockBounds(0.3125F, 0.375F, 1.0F - llIIIIIlllIlIIl, 0.6875F, 0.625F, 1.0F);
      "".length();
      if (null != null) {}
      break;
    case 2: 
      llIIIIIlllIIllI.setBlockBounds(0.3125F, 0.0F, 0.375F, 0.6875F, 0.0F + llIIIIIlllIlIIl, 0.625F);
      "".length();
      if (((0x18 ^ 0xA) & (0xBD ^ 0xAF ^ 0xFFFFFFFF)) >= "   ".length()) {}
      break;
    case 1: 
      llIIIIIlllIIllI.setBlockBounds(0.3125F, 1.0F - llIIIIIlllIlIIl, 0.375F, 0.6875F, 1.0F, 0.625F);
    }
  }
}

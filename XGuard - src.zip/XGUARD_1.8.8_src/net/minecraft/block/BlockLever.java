package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.IStringSerializable;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockLever
  extends Block
{
  private static boolean llIIIIIIIlllll(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllIllIIIlllIlllIllll;
    return ??? == localObject;
  }
  
  public void onNeighborBlockChange(World llllllllllllllIllIIIlllllIIIIllI, BlockPos llllllllllllllIllIIIlllllIIIIlIl, IBlockState llllllllllllllIllIIIlllllIIIIlII, Block llllllllllllllIllIIIlllllIIIlIII)
  {
    ;
    ;
    ;
    ;
    if ((llIIIIIIIllIll(llllllllllllllIllIIIlllllIIIllII.func_181091_e(llllllllllllllIllIIIlllllIIIIllI, llllllllllllllIllIIIlllllIIIlIlI, llllllllllllllIllIIIlllllIIIIlII))) && (llIIIIIIIllllI(func_181090_a(llllllllllllllIllIIIlllllIIIIllI, llllllllllllllIllIIIlllllIIIlIlI, ((EnumOrientation)llllllllllllllIllIIIlllllIIIIlII.getValue(FACING)).getFacing().getOpposite()))))
    {
      llllllllllllllIllIIIlllllIIIllII.dropBlockAsItem(llllllllllllllIllIIIlllllIIIIllI, llllllllllllllIllIIIlllllIIIlIlI, llllllllllllllIllIIIlllllIIIIlII, llllllIIIIll[0]);
      "".length();
    }
  }
  
  private static boolean llIIIIIIIllllI(int ???)
  {
    float llllllllllllllIllIIIlllIlllIlIIl;
    return ??? == 0;
  }
  
  private boolean func_181091_e(World llllllllllllllIllIIIllllIllllllI, BlockPos llllllllllllllIllIIIllllIlllllIl, IBlockState llllllllllllllIllIIIllllIlllllII)
  {
    ;
    ;
    ;
    ;
    if (llIIIIIIIllIll(llllllllllllllIllIIIllllIllllIll.canPlaceBlockAt(llllllllllllllIllIIIllllIllllllI, llllllllllllllIllIIIllllIlllllIl))) {
      return llllllIIIIll[1];
    }
    llllllllllllllIllIIIllllIllllIll.dropBlockAsItem(llllllllllllllIllIIIllllIllllllI, llllllllllllllIllIIIllllIlllllIl, llllllllllllllIllIIIllllIlllllII, llllllIIIIll[0]);
    "".length();
    return llllllIIIIll[0];
  }
  
  public boolean canPlaceBlockAt(World llllllllllllllIllIIIllllllIIIIll, BlockPos llllllllllllllIllIIIllllllIIIIlI)
  {
    ;
    ;
    ;
    ;
    long llllllllllllllIllIIIlllllIllllII = (llllllllllllllIllIIIlllllIlllIll = EnumFacing.values()).length;
    byte llllllllllllllIllIIIlllllIllllIl = llllllIIIIll[0];
    "".length();
    if (" ".length() == 0) {
      return (0x67 ^ 0x43) & (0x51 ^ 0x75 ^ 0xFFFFFFFF);
    }
    while (!llIIIIIIIlllII(llllllllllllllIllIIIlllllIllllIl, llllllllllllllIllIIIlllllIllllII))
    {
      EnumFacing llllllllllllllIllIIIllllllIIIIIl = llllllllllllllIllIIIlllllIlllIll[llllllllllllllIllIIIlllllIllllIl];
      if (llIIIIIIIllIll(func_181090_a(llllllllllllllIllIIIllllllIIIIll, llllllllllllllIllIIIllllllIIIIlI, llllllllllllllIllIIIllllllIIIIIl))) {
        return llllllIIIIll[1];
      }
      llllllllllllllIllIIIlllllIllllIl++;
    }
    return llllllIIIIll[0];
  }
  
  public int getStrongPower(IBlockAccess llllllllllllllIllIIIllllIIlllllI, BlockPos llllllllllllllIllIIIllllIIllllIl, IBlockState llllllllllllllIllIIIllllIIllllII, EnumFacing llllllllllllllIllIIIllllIIlllIIl)
  {
    ;
    ;
    if (llIIIIIIIllllI(((Boolean)llllllllllllllIllIIIllllIIllllII.getValue(POWERED)).booleanValue()))
    {
      "".length();
      if (-"   ".length() >= 0) {
        return (0x39 ^ 0x77) & (0xEF ^ 0xA1 ^ 0xFFFFFFFF);
      }
    }
    else if (llIIIIIIIlllll(((EnumOrientation)llllllllllllllIllIIIllllIIllllII.getValue(FACING)).getFacing(), llllllllllllllIllIIIllllIIlllIIl))
    {
      "".length();
      if (((0xD5 ^ 0x99) & (0x3D ^ 0x71 ^ 0xFFFFFFFF)) < "   ".length()) {
        break label152;
      }
      return (0xB6 ^ 0xAF) & (0x7B ^ 0x62 ^ 0xFFFFFFFF) & ((0x1F ^ 0x5B) & (0x1B ^ 0x5F ^ 0xFFFFFFFF) ^ 0xFFFFFFFF);
    }
    label152:
    return llllllIIIIll[0];
  }
  
  private static void llIIIIIIIllIlI()
  {
    llllllIIIIll = new int[11];
    llllllIIIIll[0] = ((0xDD ^ 0xC6 ^ 0x2C ^ 0x3) & (0x1E ^ 0x6B ^ 0xEC ^ 0xAD ^ -" ".length()));
    llllllIIIIll[1] = " ".length();
    llllllIIIIll[2] = ('¢' + '' - 163 + 32 ^ 85 + 51 - 48 + 89);
    llllllIIIIll[3] = (0x3D ^ 0x39);
    llllllIIIIll[4] = "   ".length();
    llllllIIIIll[5] = "  ".length();
    llllllIIIIll[6] = (-" ".length());
    llllllIIIIll[7] = (0x38 ^ 0x14 ^ 0xE5 ^ 0xC6);
    llllllIIIIll[8] = (0x83 ^ 0x97 ^ 0x23 ^ 0x30);
    llllllIIIIll[9] = (0x4B ^ 0x43);
    llllllIIIIll[10] = (0x9E ^ 0xB1 ^ 0x10 ^ 0x39);
  }
  
  protected static boolean func_181090_a(World llllllllllllllIllIIIlllllIllIlII, BlockPos llllllllllllllIllIIIlllllIllIllI, EnumFacing llllllllllllllIllIIIlllllIllIlIl)
  {
    ;
    ;
    ;
    return BlockButton.func_181088_a(llllllllllllllIllIIIlllllIllIlII, llllllllllllllIllIIIlllllIllIIll, llllllllllllllIllIIIlllllIllIlIl);
  }
  
  public IBlockState onBlockPlaced(World llllllllllllllIllIIIlllllIIllIll, BlockPos llllllllllllllIllIIIlllllIIllIlI, EnumFacing llllllllllllllIllIIIlllllIIllIIl, float llllllllllllllIllIIIlllllIlIIlII, float llllllllllllllIllIIIlllllIlIIIll, float llllllllllllllIllIIIlllllIlIIIlI, int llllllllllllllIllIIIlllllIlIIIIl, EntityLivingBase llllllllllllllIllIIIlllllIlIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllIllIIIlllllIIlllll = llllllllllllllIllIIIlllllIlIlIII.getDefaultState().withProperty(POWERED, Boolean.valueOf(llllllIIIIll[0]));
    if (llIIIIIIIllIll(func_181090_a(llllllllllllllIllIIIlllllIIllIll, llllllllllllllIllIIIlllllIIllIlI, llllllllllllllIllIIIlllllIIllIIl.getOpposite()))) {
      return llllllllllllllIllIIIlllllIIlllll.withProperty(FACING, EnumOrientation.forFacings(llllllllllllllIllIIIlllllIIllIIl, llllllllllllllIllIIIlllllIlIIIII.getHorizontalFacing()));
    }
    double llllllllllllllIllIIIlllllIIlIlIl = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if ("  ".length() != "  ".length()) {
      return null;
    }
    while (!llIIIIIIIllllI(llllllllllllllIllIIIlllllIIlIlIl.hasNext()))
    {
      Object llllllllllllllIllIIIlllllIIllllI = llllllllllllllIllIIIlllllIIlIlIl.next();
      EnumFacing llllllllllllllIllIIIlllllIIlllIl = (EnumFacing)llllllllllllllIllIIIlllllIIllllI;
      if ((llIIIIIIIlllIl(llllllllllllllIllIIIlllllIIlllIl, llllllllllllllIllIIIlllllIIllIIl)) && (llIIIIIIIllIll(func_181090_a(llllllllllllllIllIIIlllllIIllIll, llllllllllllllIllIIIlllllIIllIlI, llllllllllllllIllIIIlllllIIlllIl.getOpposite())))) {
        return llllllllllllllIllIIIlllllIIlllll.withProperty(FACING, EnumOrientation.forFacings(llllllllllllllIllIIIlllllIIlllIl, llllllllllllllIllIIIlllllIlIIIII.getHorizontalFacing()));
      }
    }
    if (llIIIIIIIllIll(World.doesBlockHaveSolidTopSurface(llllllllllllllIllIIIlllllIIllIll, llllllllllllllIllIIIlllllIIllIlI.down()))) {
      return llllllllllllllIllIIIlllllIIlllll.withProperty(FACING, EnumOrientation.forFacings(EnumFacing.UP, llllllllllllllIllIIIlllllIlIIIII.getHorizontalFacing()));
    }
    return llllllllllllllIllIIIlllllIIlllll;
  }
  
  static
  {
    llIIIIIIIllIlI();
    llIIIIIIIllIIl();
  }
  
  private static boolean llIIIIIIlIIIIl(Object ???)
  {
    boolean llllllllllllllIllIIIlllIlllIllIl;
    return ??? != null;
  }
  
  private static void llIIIIIIIllIIl()
  {
    llllllIIIIlI = new String[llllllIIIIll[4]];
    llllllIIIIlI[llllllIIIIll[0]] = llIIIIIIIlIlll("FCYgAAsV", "rGCie");
    llllllIIIIlI[llllllIIIIll[1]] = llIIIIIIIllIII("lg98KeOYX8E=", "kphDm");
    llllllIIIIlI[llllllIIIIll[5]] = llIIIIIIIlIlll("HDA3Ej0DfzoaOw06", "nQYvR");
  }
  
  private static boolean llIIIIIIlIIIII(int ???)
  {
    long llllllllllllllIllIIIlllIlllIIlll;
    return ??? > 0;
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIllIIIllllIIllIIlI)
  {
    ;
    ;
    if (llIIIIIIlIIIII(llllllllllllllIllIIIllllIIllIIlI & llllllIIIIll[9]))
    {
      "".length();
      if (null == null) {
        break label62;
      }
      return null;
    }
    label62:
    return POWERED.withProperty(llllllIIIIll[1], Boolean.valueOf(llllllIIIIll[0]));
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIllIIIllllllIllIIl, BlockPos llllllllllllllIllIIIllllllIllIII, IBlockState llllllllllllllIllIIIllllllIlIlll)
  {
    return null;
  }
  
  protected BlockLever()
  {
    llllllllllllllIllIIIllllllIllIll.<init>(Material.circuits);
    llllllllllllllIllIIIllllllIlllII.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumOrientation.NORTH).withProperty(POWERED, Boolean.valueOf(llllllIIIIll[0])));
    "".length();
  }
  
  private static String llIIIIIIIllIII(String llllllllllllllIllIIIllllIIIIIIlI, String llllllllllllllIllIIIllllIIIIIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIIllllIIIIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIIllllIIIIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIIIllllIIIIIllI = Cipher.getInstance("Blowfish");
      llllllllllllllIllIIIllllIIIIIllI.init(llllllIIIIll[5], llllllllllllllIllIIIllllIIIIIlll);
      return new String(llllllllllllllIllIIIllllIIIIIllI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIIllllIIIIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIIllllIIIIIlIl)
    {
      llllllllllllllIllIIIllllIIIIIlIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIIIIIIIllIll(int ???)
  {
    long llllllllllllllIllIIIlllIlllIlIll;
    return ??? != 0;
  }
  
  private static boolean llIIIIIIlIIIlI(int ???, int arg1)
  {
    int i;
    char llllllllllllllIllIIIlllIllllIlll;
    return ??? < i;
  }
  
  public boolean isOpaqueCube()
  {
    return llllllIIIIll[0];
  }
  
  public void breakBlock(World llllllllllllllIllIIIllllIlIlIIIl, BlockPos llllllllllllllIllIIIllllIlIIlIll, IBlockState llllllllllllllIllIIIllllIlIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIIIIIIIllIll(((Boolean)llllllllllllllIllIIIllllIlIIlIlI.getValue(POWERED)).booleanValue()))
    {
      llllllllllllllIllIIIllllIlIlIIIl.notifyNeighborsOfStateChange(llllllllllllllIllIIIllllIlIIlIll, llllllllllllllIllIIIllllIlIlIIlI);
      EnumFacing llllllllllllllIllIIIllllIlIIlllI = ((EnumOrientation)llllllllllllllIllIIIllllIlIIlIlI.getValue(FACING)).getFacing();
      llllllllllllllIllIIIllllIlIlIIIl.notifyNeighborsOfStateChange(llllllllllllllIllIIIllllIlIIlIll.offset(llllllllllllllIllIIIllllIlIIlllI.getOpposite()), llllllllllllllIllIIIllllIlIlIIlI);
    }
    llllllllllllllIllIIIllllIlIlIIlI.breakBlock(llllllllllllllIllIIIllllIlIlIIIl, llllllllllllllIllIIIllllIlIIlIll, llllllllllllllIllIIIllllIlIIlIlI);
  }
  
  public boolean canProvidePower()
  {
    return llllllIIIIll[1];
  }
  
  public boolean canPlaceBlockOnSide(World llllllllllllllIllIIIllllllIIllIl, BlockPos llllllllllllllIllIIIllllllIIllll, EnumFacing llllllllllllllIllIIIllllllIIlllI)
  {
    ;
    ;
    ;
    return func_181090_a(llllllllllllllIllIIIllllllIIllIl, llllllllllllllIllIIIllllllIIllII, llllllllllllllIllIIIllllllIIlllI.getOpposite());
  }
  
  private static boolean llIIIIIIIlllIl(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllIllIIIlllIllllIIll;
    return ??? != localObject;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIllIIIllllIllIlllI, BlockPos llllllllllllllIllIIIllllIllIllIl)
  {
    ;
    ;
    ;
    ;
    float llllllllllllllIllIIIllllIlllIIII = 0.1875F;
    switch ($SWITCH_TABLE$net$minecraft$block$BlockLever$EnumOrientation()[((EnumOrientation)llllllllllllllIllIIIllllIlllIIlI.getBlockState(llllllllllllllIllIIIllllIllIllIl).getValue(FACING)).ordinal()])
    {
    case 2: 
      llllllllllllllIllIIIllllIllIllll.setBlockBounds(0.0F, 0.2F, 0.5F - llllllllllllllIllIIIllllIlllIIII, llllllllllllllIllIIIllllIlllIIII * 2.0F, 0.8F, 0.5F + llllllllllllllIllIIIllllIlllIIII);
      "".length();
      if (("   ".length() ^ 0xB4 ^ 0xB3) < -" ".length()) {}
      break;
    case 3: 
      llllllllllllllIllIIIllllIllIllll.setBlockBounds(1.0F - llllllllllllllIllIIIllllIlllIIII * 2.0F, 0.2F, 0.5F - llllllllllllllIllIIIllllIlllIIII, 1.0F, 0.8F, 0.5F + llllllllllllllIllIIIllllIlllIIII);
      "".length();
      if (-"   ".length() > 0) {}
      break;
    case 4: 
      llllllllllllllIllIIIllllIllIllll.setBlockBounds(0.5F - llllllllllllllIllIIIllllIlllIIII, 0.2F, 0.0F, 0.5F + llllllllllllllIllIIIllllIlllIIII, 0.8F, llllllllllllllIllIIIllllIlllIIII * 2.0F);
      "".length();
      if (null != null) {}
      break;
    case 5: 
      llllllllllllllIllIIIllllIllIllll.setBlockBounds(0.5F - llllllllllllllIllIIIllllIlllIIII, 0.2F, 1.0F - llllllllllllllIllIIIllllIlllIIII * 2.0F, 0.5F + llllllllllllllIllIIIllllIlllIIII, 0.8F, 1.0F);
      "".length();
      if (" ".length() == "  ".length()) {}
      break;
    case 6: 
    case 7: 
      llllllllllllllIllIIIllllIlllIIII = 0.25F;
      llllllllllllllIllIIIllllIllIllll.setBlockBounds(0.5F - llllllllllllllIllIIIllllIlllIIII, 0.0F, 0.5F - llllllllllllllIllIIIllllIlllIIII, 0.5F + llllllllllllllIllIIIllllIlllIIII, 0.6F, 0.5F + llllllllllllllIllIIIllllIlllIIII);
      "".length();
      if ((0x2 ^ 0x6) < -" ".length()) {}
      break;
    case 1: 
    case 8: 
      llllllllllllllIllIIIllllIlllIIII = 0.25F;
      llllllllllllllIllIIIllllIllIllll.setBlockBounds(0.5F - llllllllllllllIllIIIllllIlllIIII, 0.4F, 0.5F - llllllllllllllIllIIIllllIlllIIII, 0.5F + llllllllllllllIllIIIllllIlllIIII, 1.0F, 0.5F + llllllllllllllIllIIIllllIlllIIII);
    }
  }
  
  public int getWeakPower(IBlockAccess llllllllllllllIllIIIllllIlIIIllI, BlockPos llllllllllllllIllIIIllllIlIIIlIl, IBlockState llllllllllllllIllIIIllllIlIIIlII, EnumFacing llllllllllllllIllIIIllllIlIIIIll)
  {
    ;
    if (llIIIIIIIllIll(((Boolean)llllllllllllllIllIIIllllIlIIIlII.getValue(POWERED)).booleanValue()))
    {
      "".length();
      if (" ".length() > 0) {
        break label105;
      }
      return ('' + 126 - 134 + 28 ^ 68 + 32 - 39 + 102) & (99 + 32 - 10 + 15 ^ 66 + '¦' - 150 + 107 ^ -" ".length());
    }
    label105:
    return llllllIIIIll[0];
  }
  
  public boolean onBlockActivated(World llllllllllllllIllIIIllllIlIllIll, BlockPos llllllllllllllIllIIIllllIlIllIlI, IBlockState llllllllllllllIllIIIllllIllIIIll, EntityPlayer llllllllllllllIllIIIllllIllIIIlI, EnumFacing llllllllllllllIllIIIllllIllIIIIl, float llllllllllllllIllIIIllllIllIIIII, float llllllllllllllIllIIIllllIlIlllll, float llllllllllllllIllIIIllllIlIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIIIIIIIllIll(isRemote)) {
      return llllllIIIIll[1];
    }
    llllllllllllllIllIIIllllIllIIIll = llllllllllllllIllIIIllllIllIIIll.cycleProperty(POWERED);
    "".length();
    if (llIIIIIIIllIll(((Boolean)llllllllllllllIllIIIllllIllIIIll.getValue(POWERED)).booleanValue()))
    {
      "".length();
      if (((0xD9 ^ 0x8E) & (0x7F ^ 0x28 ^ 0xFFFFFFFF)) < " ".length()) {
        break label154;
      }
      return (0x1D ^ 0x4) & (0xDB ^ 0xC2 ^ 0xFFFFFFFF);
    }
    label154:
    (llllllllllllllIllIIIllllIlIllIlI.getX() + 0.5D).playSoundEffect(llllllllllllllIllIIIllllIlIllIlI.getY() + 0.5D, llllllllllllllIllIIIllllIlIllIlI.getZ() + 0.5D, llllllIIIIlI[llllllIIIIll[5]], 0.3F, 0.6F, 0.5F);
    llllllllllllllIllIIIllllIlIllIll.notifyNeighborsOfStateChange(llllllllllllllIllIIIllllIlIllIlI, llllllllllllllIllIIIllllIllIIllI);
    EnumFacing llllllllllllllIllIIIllllIlIlllIl = ((EnumOrientation)llllllllllllllIllIIIllllIllIIIll.getValue(FACING)).getFacing();
    llllllllllllllIllIIIllllIlIllIll.notifyNeighborsOfStateChange(llllllllllllllIllIIIllllIlIllIlI.offset(llllllllllllllIllIIIllllIlIlllIl.getOpposite()), llllllllllllllIllIIIllllIllIIllI);
    return llllllIIIIll[1];
  }
  
  public static int getMetadataForFacing(EnumFacing llllllllllllllIllIIIlllllIIlIIlI)
  {
    ;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[llllllllllllllIllIIIlllllIIlIIIl.ordinal()])
    {
    case 1: 
      return llllllIIIIll[0];
    case 2: 
      return llllllIIIIll[2];
    case 3: 
      return llllllIIIIll[3];
    case 4: 
      return llllllIIIIll[4];
    case 5: 
      return llllllIIIIll[5];
    case 6: 
      return llllllIIIIll[1];
    }
    return llllllIIIIll[6];
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIllIIIllllIIlIllII)
  {
    ;
    ;
    int llllllllllllllIllIIIllllIIlIllIl = llllllIIIIll[0];
    llllllllllllllIllIIIllllIIlIllIl |= ((EnumOrientation)llllllllllllllIllIIIllllIIlIlllI.getValue(FACING)).getMetadata();
    if (llIIIIIIIllIll(((Boolean)llllllllllllllIllIIIllllIIlIlllI.getValue(POWERED)).booleanValue())) {
      llllllllllllllIllIIIllllIIlIllIl |= llllllIIIIll[9];
    }
    return llllllllllllllIllIIIllllIIlIllIl;
  }
  
  private static String llIIIIIIIlIlll(String llllllllllllllIllIIIllllIIIllIIl, String llllllllllllllIllIIIllllIIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIIllllIIIllIIl = new String(Base64.getDecoder().decode(llllllllllllllIllIIIllllIIIllIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIIIllllIIIlIlll = new StringBuilder();
    char[] llllllllllllllIllIIIllllIIIlIllI = llllllllllllllIllIIIllllIIIlIIll.toCharArray();
    int llllllllllllllIllIIIllllIIIlIlIl = llllllIIIIll[0];
    char llllllllllllllIllIIIllllIIIIllll = llllllllllllllIllIIIllllIIIllIIl.toCharArray();
    Exception llllllllllllllIllIIIllllIIIIlllI = llllllllllllllIllIIIllllIIIIllll.length;
    double llllllllllllllIllIIIllllIIIIllIl = llllllIIIIll[0];
    while (llIIIIIIlIIIlI(llllllllllllllIllIIIllllIIIIllIl, llllllllllllllIllIIIllllIIIIlllI))
    {
      char llllllllllllllIllIIIllllIIIllIlI = llllllllllllllIllIIIllllIIIIllll[llllllllllllllIllIIIllllIIIIllIl];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIIIllllIIIlIlll);
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIllIIIllllIIlIlIII, new IProperty[] { FACING, POWERED });
  }
  
  private static boolean llIIIIIIIlllII(int ???, int arg1)
  {
    int i;
    short llllllllllllllIllIIIlllIlllllIll;
    return ??? >= i;
  }
  
  public boolean isFullCube()
  {
    return llllllIIIIll[0];
  }
  
  public static enum EnumOrientation
    implements IStringSerializable
  {
    private static String lIIIIlllIlIIl(String llllllllllllllllIllllllIllIIlIII, String llllllllllllllllIllllllIllIIIlll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllllIllllllIllIIlIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllllllIllIIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllllIllllllIllIIlIlI = Cipher.getInstance("Blowfish");
        llllllllllllllllIllllllIllIIlIlI.init(lIllIIIIllI[2], llllllllllllllllIllllllIllIIlIll);
        return new String(llllllllllllllllIllllllIllIIlIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllIllllllIllIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllllIllllllIllIIlIIl)
      {
        llllllllllllllllIllllllIllIIlIIl.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIIIlIIIIIlII(Object ???)
    {
      byte llllllllllllllllIllllllIlIlllIIl;
      return ??? != null;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    static
    {
      lIIIIllllllll();
      lIIIIllllIllI();
      double llllllllllllllllIlllllllIIlIIllI;
      boolean llllllllllllllllIlllllllIIlIlIIl;
      DOWN_X = new EnumOrientation(lIlIlllIlIl[lIllIIIIllI[0]], lIllIIIIllI[0], lIllIIIIllI[0], lIlIlllIlIl[lIllIIIIllI[1]], EnumFacing.DOWN);
      EAST = new EnumOrientation(lIlIlllIlIl[lIllIIIIllI[2]], lIllIIIIllI[1], lIllIIIIllI[1], lIlIlllIlIl[lIllIIIIllI[3]], EnumFacing.EAST);
      WEST = new EnumOrientation(lIlIlllIlIl[lIllIIIIllI[4]], lIllIIIIllI[2], lIllIIIIllI[2], lIlIlllIlIl[lIllIIIIllI[5]], EnumFacing.WEST);
      SOUTH = new EnumOrientation(lIlIlllIlIl[lIllIIIIllI[6]], lIllIIIIllI[3], lIllIIIIllI[3], lIlIlllIlIl[lIllIIIIllI[7]], EnumFacing.SOUTH);
      NORTH = new EnumOrientation(lIlIlllIlIl[lIllIIIIllI[8]], lIllIIIIllI[4], lIllIIIIllI[4], lIlIlllIlIl[lIllIIIIllI[9]], EnumFacing.NORTH);
      UP_Z = new EnumOrientation(lIlIlllIlIl[lIllIIIIllI[10]], lIllIIIIllI[5], lIllIIIIllI[5], lIlIlllIlIl[lIllIIIIllI[11]], EnumFacing.UP);
      UP_X = new EnumOrientation(lIlIlllIlIl[lIllIIIIllI[12]], lIllIIIIllI[6], lIllIIIIllI[6], lIlIlllIlIl[lIllIIIIllI[13]], EnumFacing.UP);
      DOWN_Z = new EnumOrientation(lIlIlllIlIl[lIllIIIIllI[14]], lIllIIIIllI[7], lIllIIIIllI[7], lIlIlllIlIl[lIllIIIIllI[15]], EnumFacing.DOWN);
      ENUM$VALUES = new EnumOrientation[] { DOWN_X, EAST, WEST, SOUTH, NORTH, UP_Z, UP_X, DOWN_Z };
      META_LOOKUP = new EnumOrientation[values().length];
      long llllllllllllllllIlllllllIIlIIlll = (llllllllllllllllIlllllllIIlIIllI = values()).length;
      Exception llllllllllllllllIlllllllIIlIlIII = lIllIIIIllI[0];
      "".length();
      if (-" ".length() >= 0) {
        return;
      }
      while (!lIIIlIIIIIIII(llllllllllllllllIlllllllIIlIlIII, llllllllllllllllIlllllllIIlIIlll))
      {
        EnumOrientation llllllllllllllllIlllllllIIlIlIlI = llllllllllllllllIlllllllIIlIIllI[llllllllllllllllIlllllllIIlIlIII];
        META_LOOKUP[llllllllllllllllIlllllllIIlIlIlI.getMetadata()] = llllllllllllllllIlllllllIIlIlIlI;
        llllllllllllllllIlllllllIIlIlIII++;
      }
    }
    
    private static String lIIIIlllIlIll(String llllllllllllllllIllllllIllIllIII, String llllllllllllllllIllllllIllIlllII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllllIllllllIllIllIII = new String(Base64.getDecoder().decode(llllllllllllllllIllllllIllIllIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllllIllllllIllIllIll = new StringBuilder();
      char[] llllllllllllllllIllllllIllIllIlI = llllllllllllllllIllllllIllIlllII.toCharArray();
      int llllllllllllllllIllllllIllIllIIl = lIllIIIIllI[0];
      double llllllllllllllllIllllllIllIlIIll = llllllllllllllllIllllllIllIllIII.toCharArray();
      String llllllllllllllllIllllllIllIlIIlI = llllllllllllllllIllllllIllIlIIll.length;
      char llllllllllllllllIllllllIllIlIIIl = lIllIIIIllI[0];
      while (lIIIlIIIIIlIl(llllllllllllllllIllllllIllIlIIIl, llllllllllllllllIllllllIllIlIIlI))
      {
        char llllllllllllllllIllllllIllIllllI = llllllllllllllllIllllllIllIlIIll[llllllllllllllllIllllllIllIlIIIl];
        "".length();
        "".length();
        if (" ".length() >= "  ".length()) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllllIllllllIllIllIll);
    }
    
    public static EnumOrientation byMetadata(int llllllllllllllllIlllllllIIIIlIlI)
    {
      ;
      if ((!lIIIlIIIIIIIl(llllllllllllllllIlllllllIIIIlIlI)) || (lIIIlIIIIIIII(llllllllllllllllIlllllllIIIIlIll, META_LOOKUP.length))) {
        llllllllllllllllIlllllllIIIIlIll = lIllIIIIllI[0];
      }
      return META_LOOKUP[llllllllllllllllIlllllllIIIIlIll];
    }
    
    public static EnumOrientation forFacings(EnumFacing llllllllllllllllIlllllllIIIIIlll, EnumFacing llllllllllllllllIlllllllIIIIIllI)
    {
      ;
      ;
      switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[llllllllllllllllIlllllllIIIIIlll.ordinal()])
      {
      case 1: 
        switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing$Axis()[llllllllllllllllIlllllllIIIIIllI.getAxis().ordinal()])
        {
        case 1: 
          return DOWN_X;
        case 3: 
          return DOWN_Z;
        }
        throw new IllegalArgumentException(String.valueOf(new StringBuilder(lIlIlllIlIl[lIllIIIIllI[16]]).append(llllllllllllllllIlllllllIIIIIllI).append(lIlIlllIlIl[lIllIIIIllI[17]]).append(llllllllllllllllIlllllllIIIIIlll)));
      case 2: 
        switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing$Axis()[llllllllllllllllIlllllllIIIIIllI.getAxis().ordinal()])
        {
        case 1: 
          return UP_X;
        case 3: 
          return UP_Z;
        }
        throw new IllegalArgumentException(String.valueOf(new StringBuilder(lIlIlllIlIl[lIllIIIIllI[18]]).append(llllllllllllllllIlllllllIIIIIllI).append(lIlIlllIlIl[lIllIIIIllI[19]]).append(llllllllllllllllIlllllllIIIIIlll)));
      case 3: 
        return NORTH;
      case 4: 
        return SOUTH;
      case 5: 
        return WEST;
      case 6: 
        return EAST;
      }
      throw new IllegalArgumentException(String.valueOf(new StringBuilder(lIlIlllIlIl[lIllIIIIllI[20]]).append(llllllllllllllllIlllllllIIIIIlll)));
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private EnumOrientation(int llllllllllllllllIlllllllIIIllIII, String llllllllllllllllIlllllllIIIlIlll, EnumFacing llllllllllllllllIlllllllIIIlllII)
    {
      meta = llllllllllllllllIlllllllIIIllIII;
      name = llllllllllllllllIlllllllIIIlIlll;
      facing = llllllllllllllllIlllllllIIIlllII;
    }
    
    private static boolean lIIIlIIIIIIII(int ???, int arg1)
    {
      int i;
      byte llllllllllllllllIllllllIlIllllll;
      return ??? >= i;
    }
    
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    private static boolean lIIIlIIIIIlIl(int ???, int arg1)
    {
      int i;
      short llllllllllllllllIllllllIlIlllIll;
      return ??? < i;
    }
    
    private static void lIIIIllllllll()
    {
      lIllIIIIllI = new int[22];
      lIllIIIIllI[0] = ((0x3A ^ 0x7D) & (0x63 ^ 0x24 ^ 0xFFFFFFFF));
      lIllIIIIllI[1] = " ".length();
      lIllIIIIllI[2] = "  ".length();
      lIllIIIIllI[3] = "   ".length();
      lIllIIIIllI[4] = (0x4F ^ 0x10 ^ 0x41 ^ 0x1A);
      lIllIIIIllI[5] = (0x98 ^ 0xC5 ^ 0x47 ^ 0x1F);
      lIllIIIIllI[6] = (0x91 ^ 0xBC ^ 0x6A ^ 0x41);
      lIllIIIIllI[7] = (0x5D ^ 0x5A);
      lIllIIIIllI[8] = (0xCD ^ 0xA6 ^ 0x67 ^ 0x4);
      lIllIIIIllI[9] = (0xE ^ 0x25 ^ 0x82 ^ 0xA0);
      lIllIIIIllI[10] = (0x5E ^ 0x54);
      lIllIIIIllI[11] = (0x83 ^ 0x88);
      lIllIIIIllI[12] = (0x2B ^ 0x3A ^ 0x1 ^ 0x1C);
      lIllIIIIllI[13] = (0x9 ^ 0x4);
      lIllIIIIllI[14] = (0xCD ^ 0xC3);
      lIllIIIIllI[15] = (0x6B ^ 0x64);
      lIllIIIIllI[16] = (0x2D ^ 0x70 ^ 0x4B ^ 0x6);
      lIllIIIIllI[17] = ('' + 14 - 23 + 59 ^ ' ' + '£' - 291 + 132);
      lIllIIIIllI[18] = (0xD3 ^ 0xC1);
      lIllIIIIllI[19] = (0xD5 ^ 0x8D ^ 0xEC ^ 0xA7);
      lIllIIIIllI[20] = (0x5E ^ 0x4A);
      lIllIIIIllI[21] = (0x1B ^ 0xE);
    }
    
    public EnumFacing getFacing()
    {
      ;
      return facing;
    }
    
    private static void lIIIIllllIllI()
    {
      lIlIlllIlIl = new String[lIllIIIIllI[21]];
      lIlIlllIlIl[lIllIIIIllI[0]] = lIIIIlllIlIIl("sQ5ft0wbgDI=", "EypFm");
      lIlIlllIlIl[lIllIIIIllI[1]] = lIIIIlllIlIll("DCcwJx0Q", "hHGIB");
      lIlIlllIlIl[lIllIIIIllI[2]] = lIIIIlllIllII("3bXk9beWhII=", "TAgeS");
      lIlIlllIlIl[lIllIIIIllI[3]] = lIIIIlllIlIll("JhInNQ==", "CsTAz");
      lIlIlllIlIl[lIllIIIIllI[4]] = lIIIIlllIlIll("ASMxAQ==", "VfbUW");
      lIlIlllIlIl[lIllIIIIllI[5]] = lIIIIlllIlIll("GSAJNg==", "nEzBX");
      lIlIlllIlIl[lIllIIIIllI[6]] = lIIIIlllIllII("cTUEnfhFbRE=", "UeWJQ");
      lIlIlllIlIl[lIllIIIIllI[7]] = lIIIIlllIllII("h06+APGO578=", "qGjUk");
      lIlIlllIlIl[lIllIIIIllI[8]] = lIIIIlllIlIIl("zf4lzdnB2u4=", "rgRob");
      lIlIlllIlIl[lIllIIIIllI[9]] = lIIIIlllIlIIl("SK5f1e1D4tI=", "SYSMq");
      lIlIlllIlIl[lIllIIIIllI[10]] = lIIIIlllIlIIl("coj+JKVx7cg=", "dbNbM");
      lIlIlllIlIl[lIllIIIIllI[11]] = lIIIIlllIlIIl("j4vqdxO9yMs=", "sEqQX");
      lIlIlllIlIl[lIllIIIIllI[12]] = lIIIIlllIlIIl("e1XneNMXJLA=", "kvajy");
      lIlIlllIlIl[lIllIIIIllI[13]] = lIIIIlllIlIll("DBwmDg==", "ylyvF");
      lIlIlllIlIl[lIllIIIIllI[14]] = lIIIIlllIlIll("Myo8Pw8t", "wekqP");
      lIlIlllIlIl[lIllIIIIllI[15]] = lIIIIlllIllII("uMpE96wv8kg=", "ACZQJ");
      lIlIlllIlIl[lIllIIIIllI[16]] = lIIIIlllIlIll("BBc1KB8kHWMsHTkQNzA1LBoqJxRt", "MyCIs");
      lIlIlllIlIl[lIllIIIIllI[17]] = lIIIIlllIlIIl("HZPavg7gEi7FSGwPx3GpBg==", "ZRZwz");
      lIlIlllIlIl[lIllIIIIllI[18]] = lIIIIlllIlIll("ITcAAB8BPVYEHRwwAhg1CTofDxRI", "hYvas");
      lIlIlllIlIl[lIllIIIIllI[19]] = lIIIIlllIllII("xX3Xd7rvJ/SW+oVTe+4tdQ==", "GPCcJ");
      lIlIlllIlIl[lIllIIIIllI[20]] = lIIIIlllIlIIl("Q6wEzQ2ELd4CLJh12a2ekRHgntDvpz3t", "gfpHP");
    }
    
    private static String lIIIIlllIllII(String llllllllllllllllIllllllIlllIlIll, String llllllllllllllllIllllllIlllIlIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllllIllllllIllllIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllllllIlllIlIlI.getBytes(StandardCharsets.UTF_8)), lIllIIIIllI[8]), "DES");
        Cipher llllllllllllllllIllllllIlllIllll = Cipher.getInstance("DES");
        llllllllllllllllIllllllIlllIllll.init(lIllIIIIllI[2], llllllllllllllllIllllllIllllIIII);
        return new String(llllllllllllllllIllllllIlllIllll.doFinal(Base64.getDecoder().decode(llllllllllllllllIllllllIlllIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllllIllllllIlllIlllI)
      {
        llllllllllllllllIllllllIlllIlllI.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIIIlIIIIIIIl(int ???)
    {
      long llllllllllllllllIllllllIlIllIlll;
      return ??? >= 0;
    }
  }
}

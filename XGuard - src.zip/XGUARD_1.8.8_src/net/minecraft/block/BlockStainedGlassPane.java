package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.World;

public class BlockStainedGlassPane
  extends BlockPane
{
  private static boolean lIIllIIlllI(int ???, int arg1)
  {
    int i;
    long llIlllIlIIIIll;
    return ??? >= i;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.TRANSLUCENT;
  }
  
  public MapColor getMapColor(IBlockState llIlllIllllllI)
  {
    ;
    return ((EnumDyeColor)llIlllIllllllI.getValue(COLOR)).getMapColor();
  }
  
  private static boolean lIIllIlIIII(int ???, int arg1)
  {
    int i;
    long llIlllIIllllll;
    return ??? < i;
  }
  
  private static String lIIllIIlIll(String llIlllIlIlIlII, String llIlllIlIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llIlllIlIlIlII = new String(Base64.getDecoder().decode(llIlllIlIlIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llIlllIlIlIIlI = new StringBuilder();
    char[] llIlllIlIlIIIl = llIlllIlIIlllI.toCharArray();
    int llIlllIlIlIIII = lIlllIlll[0];
    char llIlllIlIIlIlI = llIlllIlIlIlII.toCharArray();
    String llIlllIlIIlIIl = llIlllIlIIlIlI.length;
    byte llIlllIlIIlIII = lIlllIlll[0];
    while (lIIllIlIIII(llIlllIlIIlIII, llIlllIlIIlIIl))
    {
      char llIlllIlIlIlIl = llIlllIlIIlIlI[llIlllIlIIlIII];
      "".length();
      "".length();
      if (-" ".length() >= "   ".length()) {
        return null;
      }
    }
    return String.valueOf(llIlllIlIlIIlI);
  }
  
  public int getMetaFromState(IBlockState llIlllIlllIIll)
  {
    ;
    return ((EnumDyeColor)llIlllIlllIIll.getValue(COLOR)).getMetadata();
  }
  
  private static void lIIllIIllIl()
  {
    lIlllIlll = new int[6];
    lIlllIlll[0] = ((0x12 ^ 0x33 ^ 0x7A ^ 0x3B) & ((0xB0 ^ 0xB9) & (0x85 ^ 0x8C ^ 0xFFFFFFFF) ^ 0x11 ^ 0x71 ^ -" ".length()));
    lIlllIlll[1] = " ".length();
    lIlllIlll[2] = (83 + 85 - 128 + 116 ^ 104 + 79 - 171 + 141);
    lIlllIlll[3] = "  ".length();
    lIlllIlll[4] = "   ".length();
    lIlllIlll[5] = (0x6F ^ 0x6B);
  }
  
  private static boolean lIIllIIllll(int ???)
  {
    boolean llIlllIIllllIl;
    return ??? == 0;
  }
  
  private static void lIIllIIllII()
  {
    lIlllIllI = new String[lIlllIlll[1]];
    lIlllIllI[lIlllIlll[0]] = lIIllIIlIll("Jh4eJzE=", "EqrHC");
  }
  
  public void breakBlock(World llIlllIllIIIll, BlockPos llIlllIlIlllll, IBlockState llIlllIllIIIIl)
  {
    ;
    ;
    if (lIIllIIllll(isRemote)) {
      BlockBeacon.updateColorAsync(llIlllIllIIIll, llIlllIllIIIlI);
    }
  }
  
  public IBlockState getStateFromMeta(int llIlllIllllIII)
  {
    ;
    ;
    return llIlllIllllIIl.getDefaultState().withProperty(COLOR, EnumDyeColor.byMetadata(llIlllIllllIII));
  }
  
  public void getSubBlocks(Item llIllllIIIIlll, CreativeTabs llIllllIIIIllI, List<ItemStack> llIllllIIIIIlI)
  {
    ;
    ;
    ;
    int llIllllIIIIlII = lIlllIlll[0];
    "".length();
    if ("   ".length() <= 0) {
      return;
    }
    while (!lIIllIIlllI(llIllllIIIIlII, EnumDyeColor.values().length))
    {
      new ItemStack(llIllllIIIIlll, lIlllIlll[1], llIllllIIIIlII);
      "".length();
    }
  }
  
  public void onBlockAdded(World llIlllIllIlIII, BlockPos llIlllIllIIlll, IBlockState llIlllIllIlIIl)
  {
    ;
    ;
    if (lIIllIIllll(isRemote)) {
      BlockBeacon.updateColorAsync(llIlllIllIlIII, llIlllIllIlIlI);
    }
  }
  
  public int damageDropped(IBlockState llIllllIIIllII)
  {
    ;
    return ((EnumDyeColor)llIllllIIIllII.getValue(COLOR)).getMetadata();
  }
  
  public BlockStainedGlassPane()
  {
    llIllllIIlIIIl.<init>(Material.glass, lIlllIlll[0]);
    llIllllIIlIIII.setDefaultState(blockState.getBaseState().withProperty(NORTH, Boolean.valueOf(lIlllIlll[0])).withProperty(EAST, Boolean.valueOf(lIlllIlll[0])).withProperty(SOUTH, Boolean.valueOf(lIlllIlll[0])).withProperty(WEST, Boolean.valueOf(lIlllIlll[0])).withProperty(COLOR, EnumDyeColor.WHITE));
    "".length();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llIlllIllIllll, new IProperty[] { NORTH, EAST, WEST, SOUTH, COLOR });
  }
  
  static
  {
    lIIllIIllIl();
    lIIllIIllII();
  }
}

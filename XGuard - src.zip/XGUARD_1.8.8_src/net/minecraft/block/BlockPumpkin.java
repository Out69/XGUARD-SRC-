package net.minecraft.block;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockPattern;
import net.minecraft.block.state.pattern.BlockPattern.PatternHelper;
import net.minecraft.block.state.pattern.BlockStateHelper;
import net.minecraft.block.state.pattern.FactoryBlockPattern;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class BlockPumpkin
  extends BlockDirectional
{
  protected BlockPumpkin()
  {
    lllllllllllllllIlIlIlIlIllIIIIII.<init>(Material.gourd, MapColor.adobeColor);
    lllllllllllllllIlIlIlIlIlIllllll.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
    "".length();
    "".length();
  }
  
  public IBlockState onBlockPlaced(World lllllllllllllllIlIlIlIlIIllllIlI, BlockPos lllllllllllllllIlIlIlIlIIllllIIl, EnumFacing lllllllllllllllIlIlIlIlIIllllIII, float lllllllllllllllIlIlIlIlIIlllIlll, float lllllllllllllllIlIlIlIlIIlllIllI, float lllllllllllllllIlIlIlIlIIlllIlIl, int lllllllllllllllIlIlIlIlIIlllIlII, EntityLivingBase lllllllllllllllIlIlIlIlIIlllIIIl)
  {
    ;
    ;
    return lllllllllllllllIlIlIlIlIIllllIll.getDefaultState().withProperty(FACING, lllllllllllllllIlIlIlIlIIlllIIIl.getHorizontalFacing().getOpposite());
  }
  
  public boolean canPlaceBlockAt(World lllllllllllllllIlIlIlIlIIlllllll, BlockPos lllllllllllllllIlIlIlIlIlIIIIIII)
  {
    ;
    ;
    if ((llllIllIIIlIl(getBlockStategetBlockblockMaterial.isReplaceable())) && (llllIllIIIlIl(World.doesBlockHaveSolidTopSurface(lllllllllllllllIlIlIlIlIIlllllll, lllllllllllllllIlIlIlIlIlIIIIIII.down())))) {
      return lIIllllllIII[0];
    }
    return lIIllllllIII[1];
  }
  
  private static boolean llllIllIIIIlI(Object ???)
  {
    byte lllllllllllllllIlIlIlIlIIIIllIlI;
    return ??? == null;
  }
  
  private static boolean llllIllIIIlII(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllIlIlIlIlIIIlIIIlI;
    return ??? >= i;
  }
  
  protected BlockPattern getGolemBasePattern()
  {
    ;
    if (llllIllIIIIlI(golemBasePattern)) {
      golemBasePattern = FactoryBlockPattern.start().aisle(new String[] { lIIlllllIIlI[lIIllllllIII[9]], lIIlllllIIlI[lIIllllllIII[10]], lIIlllllIIlI[lIIllllllIII[11]] }).where(lIIllllllIII[5], BlockWorldState.hasState(BlockStateHelper.forBlock(Blocks.iron_block))).where(lIIllllllIII[12], BlockWorldState.hasState(BlockStateHelper.forBlock(Blocks.air))).build();
    }
    return golemBasePattern;
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIlIlIlIlIIllIIlll)
  {
    ;
    return ((EnumFacing)lllllllllllllllIlIlIlIlIIllIIlll.getValue(FACING)).getHorizontalIndex();
  }
  
  private static String llllIlIlIIllI(String lllllllllllllllIlIlIlIlIIIlIlIIl, String lllllllllllllllIlIlIlIlIIIlIlIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIlIlIIIlIlllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIlIlIIIlIlIlI.getBytes(StandardCharsets.UTF_8)), lIIllllllIII[11]), "DES");
      Cipher lllllllllllllllIlIlIlIlIIIlIllIl = Cipher.getInstance("DES");
      lllllllllllllllIlIlIlIlIIIlIllIl.init(lIIllllllIII[2], lllllllllllllllIlIlIlIlIIIlIlllI);
      return new String(lllllllllllllllIlIlIlIlIIIlIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIlIlIIIlIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIlIlIIIlIllII)
    {
      lllllllllllllllIlIlIlIlIIIlIllII.printStackTrace();
    }
    return null;
  }
  
  private static void llllIllIIIIIl()
  {
    lIIllllllIII = new int[17];
    lIIllllllIII[0] = " ".length();
    lIIllllllIII[1] = ((75 + 12 - -118 + 7 ^ 33 + 112 - 56 + 54) & ('' + 39 - 46 + 76 ^ '' + 58 - 89 + 71 ^ -" ".length()));
    lIIllllllIII[2] = "  ".length();
    lIIllllllIII[3] = (0x56 ^ 0x79 ^ 0xD6 ^ 0x81);
    lIIllllllIII[4] = "   ".length();
    lIIllllllIII[5] = (0xB4 ^ 0x97);
    lIIllllllIII[6] = (0xAC ^ 0xB6 ^ 0x4E ^ 0x50);
    lIIllllllIII[7] = (0x45 ^ 0x40);
    lIIllllllIII[8] = (0x2D ^ 0x53 ^ 0x9A ^ 0xBA);
    lIIllllllIII[9] = (0xB ^ 0x7F ^ 0xD2 ^ 0xA0);
    lIIllllllIII[10] = (0x6D ^ 0x7A ^ 0xB0 ^ 0xA0);
    lIIllllllIII[11] = (0x8C ^ 0x84);
    lIIllllllIII[12] = (0x8 ^ 0x76);
    lIIllllllIII[13] = (0x10 ^ 0x19);
    lIIllllllIII[14] = (0x5D ^ 0x57);
    lIIllllllIII[15] = (0xC8 ^ 0xC3);
    lIIllllllIII[16] = (0x1A ^ 0x16);
  }
  
  private static boolean llllIllIIIllI(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIlIlIlIlIIIIllllI;
    return ??? < i;
  }
  
  private static boolean llllIllIIIIll(Object ???)
  {
    byte lllllllllllllllIlIlIlIlIIIIlllII;
    return ??? != null;
  }
  
  public boolean canDispenserPlace(World lllllllllllllllIlIlIlIlIlIlIlllI, BlockPos lllllllllllllllIlIlIlIlIlIlIllIl)
  {
    ;
    ;
    ;
    if ((llllIllIIIIlI(lllllllllllllllIlIlIlIlIlIlIllll.getSnowmanBasePattern().match(lllllllllllllllIlIlIlIlIlIlIlIll, lllllllllllllllIlIlIlIlIlIlIllIl))) && (llllIllIIIIlI(lllllllllllllllIlIlIlIlIlIlIllll.getGolemBasePattern().match(lllllllllllllllIlIlIlIlIlIlIlIll, lllllllllllllllIlIlIlIlIlIlIllIl)))) {
      return lIIllllllIII[1];
    }
    return lIIllllllIII[0];
  }
  
  private void trySpawnGolem(World lllllllllllllllIlIlIlIlIlIIlllll, BlockPos lllllllllllllllIlIlIlIlIlIIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    BlockPattern.PatternHelper lllllllllllllllIlIlIlIlIlIIlllIl;
    if (llllIllIIIIll(lllllllllllllllIlIlIlIlIlIIlllIl = lllllllllllllllIlIlIlIlIlIlIIIII.getSnowmanPattern().match(lllllllllllllllIlIlIlIlIlIIIllII, lllllllllllllllIlIlIlIlIlIIllllI)))
    {
      int lllllllllllllllIlIlIlIlIlIIlllII = lIIllllllIII[1];
      "".length();
      if (-"  ".length() > 0) {
        return;
      }
      while (!llllIllIIIlII(lllllllllllllllIlIlIlIlIlIIlllII, lllllllllllllllIlIlIlIlIlIlIIIII.getSnowmanPattern().getThumbLength()))
      {
        BlockWorldState lllllllllllllllIlIlIlIlIlIIllIll = lllllllllllllllIlIlIlIlIlIIlllIl.translateOffset(lIIllllllIII[1], lllllllllllllllIlIlIlIlIlIIlllII, lIIllllllIII[1]);
        "".length();
      }
      EntitySnowman lllllllllllllllIlIlIlIlIlIIllIlI = new EntitySnowman(lllllllllllllllIlIlIlIlIlIIIllII);
      BlockPos lllllllllllllllIlIlIlIlIlIIllIIl = lllllllllllllllIlIlIlIlIlIIlllIl.translateOffset(lIIllllllIII[1], lIIllllllIII[2], lIIllllllIII[1]).getPos();
      lllllllllllllllIlIlIlIlIlIIllIlI.setLocationAndAngles(lllllllllllllllIlIlIlIlIlIIllIIl.getX() + 0.5D, lllllllllllllllIlIlIlIlIlIIllIIl.getY() + 0.05D, lllllllllllllllIlIlIlIlIlIIllIIl.getZ() + 0.5D, 0.0F, 0.0F);
      "".length();
      int lllllllllllllllIlIlIlIlIlIIllIII = lIIllllllIII[1];
      "".length();
      if (-" ".length() >= " ".length()) {
        return;
      }
      while (!llllIllIIIlII(lllllllllllllllIlIlIlIlIlIIllIII, lIIllllllIII[3])) {
        lllllllllllllllIlIlIlIlIlIIIllII.spawnParticle(EnumParticleTypes.SNOW_SHOVEL, lllllllllllllllIlIlIlIlIlIIllIIl.getX() + rand.nextDouble(), lllllllllllllllIlIlIlIlIlIIllIIl.getY() + rand.nextDouble() * 2.5D, lllllllllllllllIlIlIlIlIlIIllIIl.getZ() + rand.nextDouble(), 0.0D, 0.0D, 0.0D, new int[lIIllllllIII[1]]);
      }
      int lllllllllllllllIlIlIlIlIlIIlIlll = lIIllllllIII[1];
      "".length();
      if (null != null) {
        return;
      }
      while (!llllIllIIIlII(lllllllllllllllIlIlIlIlIlIIlIlll, lllllllllllllllIlIlIlIlIlIlIIIII.getSnowmanPattern().getThumbLength()))
      {
        BlockWorldState lllllllllllllllIlIlIlIlIlIIlIllI = lllllllllllllllIlIlIlIlIlIIlllIl.translateOffset(lIIllllllIII[1], lllllllllllllllIlIlIlIlIlIIlIlll, lIIllllllIII[1]);
        lllllllllllllllIlIlIlIlIlIIIllII.notifyNeighborsRespectDebug(lllllllllllllllIlIlIlIlIlIIlIllI.getPos(), Blocks.air);
      }
      "".length();
      if ("  ".length() > -" ".length()) {}
    }
    else if (llllIllIIIIll(lllllllllllllllIlIlIlIlIlIIlllIl = lllllllllllllllIlIlIlIlIlIlIIIII.getGolemPattern().match(lllllllllllllllIlIlIlIlIlIIIllII, lllllllllllllllIlIlIlIlIlIIllllI)))
    {
      int lllllllllllllllIlIlIlIlIlIIlIlIl = lIIllllllIII[1];
      "".length();
      if (" ".length() == 0) {
        return;
      }
      while (!llllIllIIIlII(lllllllllllllllIlIlIlIlIlIIlIlIl, lllllllllllllllIlIlIlIlIlIlIIIII.getGolemPattern().getPalmLength()))
      {
        int lllllllllllllllIlIlIlIlIlIIlIlII = lIIllllllIII[1];
        "".length();
        if (" ".length() == ((0x55 ^ 0x4F ^ 0x6E ^ 0x66) & (0x4E ^ 0x9 ^ 0xF2 ^ 0xA7 ^ -" ".length()))) {
          return;
        }
        while (!llllIllIIIlII(lllllllllllllllIlIlIlIlIlIIlIlII, lllllllllllllllIlIlIlIlIlIlIIIII.getGolemPattern().getThumbLength())) {
          "".length();
        }
      }
      BlockPos lllllllllllllllIlIlIlIlIlIIlIIll = lllllllllllllllIlIlIlIlIlIIlllIl.translateOffset(lIIllllllIII[0], lIIllllllIII[2], lIIllllllIII[1]).getPos();
      EntityIronGolem lllllllllllllllIlIlIlIlIlIIlIIlI = new EntityIronGolem(lllllllllllllllIlIlIlIlIlIIIllII);
      lllllllllllllllIlIlIlIlIlIIlIIlI.setPlayerCreated(lIIllllllIII[0]);
      lllllllllllllllIlIlIlIlIlIIlIIlI.setLocationAndAngles(lllllllllllllllIlIlIlIlIlIIlIIll.getX() + 0.5D, lllllllllllllllIlIlIlIlIlIIlIIll.getY() + 0.05D, lllllllllllllllIlIlIlIlIlIIlIIll.getZ() + 0.5D, 0.0F, 0.0F);
      "".length();
      int lllllllllllllllIlIlIlIlIlIIlIIIl = lIIllllllIII[1];
      "".length();
      if ("   ".length() <= " ".length()) {
        return;
      }
      while (!llllIllIIIlII(lllllllllllllllIlIlIlIlIlIIlIIIl, lIIllllllIII[3])) {
        lllllllllllllllIlIlIlIlIlIIIllII.spawnParticle(EnumParticleTypes.SNOWBALL, lllllllllllllllIlIlIlIlIlIIlIIll.getX() + rand.nextDouble(), lllllllllllllllIlIlIlIlIlIIlIIll.getY() + rand.nextDouble() * 3.9D, lllllllllllllllIlIlIlIlIlIIlIIll.getZ() + rand.nextDouble(), 0.0D, 0.0D, 0.0D, new int[lIIllllllIII[1]]);
      }
      int lllllllllllllllIlIlIlIlIlIIlIIII = lIIllllllIII[1];
      "".length();
      if ((0x72 ^ 0x76) <= "  ".length()) {
        return;
      }
      while (!llllIllIIIlII(lllllllllllllllIlIlIlIlIlIIlIIII, lllllllllllllllIlIlIlIlIlIlIIIII.getGolemPattern().getPalmLength()))
      {
        int lllllllllllllllIlIlIlIlIlIIIllll = lIIllllllIII[1];
        "".length();
        if ("   ".length() == 0) {
          return;
        }
        while (!llllIllIIIlII(lllllllllllllllIlIlIlIlIlIIIllll, lllllllllllllllIlIlIlIlIlIlIIIII.getGolemPattern().getThumbLength()))
        {
          BlockWorldState lllllllllllllllIlIlIlIlIlIIIlllI = lllllllllllllllIlIlIlIlIlIIlllIl.translateOffset(lllllllllllllllIlIlIlIlIlIIlIIII, lllllllllllllllIlIlIlIlIlIIIllll, lIIllllllIII[1]);
          lllllllllllllllIlIlIlIlIlIIIllII.notifyNeighborsRespectDebug(lllllllllllllllIlIlIlIlIlIIIlllI.getPos(), Blocks.air);
        }
      }
    }
  }
  
  private static boolean llllIllIIIlIl(int ???)
  {
    byte lllllllllllllllIlIlIlIlIIIIllIII;
    return ??? != 0;
  }
  
  private static String llllIlIlIlIll(String lllllllllllllllIlIlIlIlIIlIIlIII, String lllllllllllllllIlIlIlIlIIlIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIlIlIIlIIlIII = new String(Base64.getDecoder().decode(lllllllllllllllIlIlIlIlIIlIIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlIlIlIlIIlIIlIll = new StringBuilder();
    char[] lllllllllllllllIlIlIlIlIIlIIlIlI = lllllllllllllllIlIlIlIlIIlIIIlll.toCharArray();
    int lllllllllllllllIlIlIlIlIIlIIlIIl = lIIllllllIII[1];
    short lllllllllllllllIlIlIlIlIIlIIIIll = lllllllllllllllIlIlIlIlIIlIIlIII.toCharArray();
    short lllllllllllllllIlIlIlIlIIlIIIIlI = lllllllllllllllIlIlIlIlIIlIIIIll.length;
    byte lllllllllllllllIlIlIlIlIIlIIIIIl = lIIllllllIII[1];
    while (llllIllIIIllI(lllllllllllllllIlIlIlIlIIlIIIIIl, lllllllllllllllIlIlIlIlIIlIIIIlI))
    {
      char lllllllllllllllIlIlIlIlIIlIIlllI = lllllllllllllllIlIlIlIlIIlIIIIll[lllllllllllllllIlIlIlIlIIlIIIIIl];
      "".length();
      "".length();
      if (" ".length() <= 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIlIlIlIlIIlIIlIll);
  }
  
  public void onBlockAdded(World lllllllllllllllIlIlIlIlIlIllIlIl, BlockPos lllllllllllllllIlIlIlIlIlIlllIII, IBlockState lllllllllllllllIlIlIlIlIlIllIIll)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIlIlIlIlllIlI.onBlockAdded(lllllllllllllllIlIlIlIlIlIllIlIl, lllllllllllllllIlIlIlIlIlIlllIII, lllllllllllllllIlIlIlIlIlIllIIll);
    lllllllllllllllIlIlIlIlIlIlllIlI.trySpawnGolem(lllllllllllllllIlIlIlIlIlIllIlIl, lllllllllllllllIlIlIlIlIlIlllIII);
  }
  
  static
  {
    llllIllIIIIIl();
    llllIlIllIllI();
  }
  
  protected BlockPattern getSnowmanPattern()
  {
    ;
    if (llllIllIIIIlI(snowmanPattern)) {
      snowmanPattern = FactoryBlockPattern.start().aisle(new String[] { lIIlllllIIlI[lIIllllllIII[4]], lIIlllllIIlI[lIIllllllIII[6]], lIIlllllIIlI[lIIllllllIII[7]] }).where(lIIllllllIII[8], BlockWorldState.hasState(field_181085_Q)).where(lIIllllllIII[5], BlockWorldState.hasState(BlockStateHelper.forBlock(Blocks.snow))).build();
    }
    return snowmanPattern;
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIlIlIlIlIIllIlIll)
  {
    ;
    ;
    return lllllllllllllllIlIlIlIlIIllIlllI.getDefaultState().withProperty(FACING, EnumFacing.getHorizontal(lllllllllllllllIlIlIlIlIIllIlIll));
  }
  
  private static String llllIlIlIllIl(String lllllllllllllllIlIlIlIlIIIllIllI, String lllllllllllllllIlIlIlIlIIIllIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIlIlIIIlllIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIlIlIIIllIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlIlIlIlIIIlllIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlIlIlIlIIIlllIlI.init(lIIllllllIII[2], lllllllllllllllIlIlIlIlIIIlllIll);
      return new String(lllllllllllllllIlIlIlIlIIIlllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIlIlIIIllIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIlIlIIIlllIIl)
    {
      lllllllllllllllIlIlIlIlIIIlllIIl.printStackTrace();
    }
    return null;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIlIlIlIlIIllIIlIl, new IProperty[] { FACING });
  }
  
  protected BlockPattern getSnowmanBasePattern()
  {
    ;
    if (llllIllIIIIlI(snowmanBasePattern)) {
      snowmanBasePattern = FactoryBlockPattern.start().aisle(new String[] { lIIlllllIIlI[lIIllllllIII[1]], lIIlllllIIlI[lIIllllllIII[0]], lIIlllllIIlI[lIIllllllIII[2]] }).where(lIIllllllIII[5], BlockWorldState.hasState(BlockStateHelper.forBlock(Blocks.snow))).build();
    }
    return snowmanBasePattern;
  }
  
  private static void llllIlIllIllI()
  {
    lIIlllllIIlI = new String[lIIllllllIII[16]];
    lIIlllllIIlI[lIIllllllIII[1]] = llllIlIlIIllI("kCIcPQlgH+Q=", "qdrCR");
    lIIlllllIIlI[lIIllllllIII[0]] = llllIlIlIlIll("SQ==", "jwvDV");
    lIIlllllIIlI[lIIllllllIII[2]] = llllIlIlIIllI("RGEGcgsKArE=", "TVHcQ");
    lIIlllllIIlI[lIIllllllIII[4]] = llllIlIlIllIl("woifpir6JUA=", "jNCJY");
    lIIlllllIIlI[lIIllllllIII[6]] = llllIlIlIllIl("hTZ80Yvm3hg=", "NaYIJ");
    lIIlllllIIlI[lIIllllllIII[7]] = llllIlIlIIllI("66VzxH0DVwc=", "OBPpJ");
    lIIlllllIIlI[lIIllllllIII[9]] = llllIlIlIIllI("b7b8TKCwOGQ=", "rRthm");
    lIIlllllIIlI[lIIllllllIII[10]] = llllIlIlIllIl("UxMmYsfjes4=", "jehPN");
    lIIlllllIIlI[lIIllllllIII[11]] = llllIlIlIlIll("CnUs", "tVRNJ");
    lIIlllllIIlI[lIIllllllIII[13]] = llllIlIlIlIll("FDY9", "jhCMe");
    lIIlllllIIlI[lIIllllllIII[14]] = llllIlIlIIllI("sNifoJtJ018=", "pfGWl");
    lIIlllllIIlI[lIIllllllIII[15]] = llllIlIlIIllI("mawDQfUs7SI=", "gaGCz");
  }
  
  protected BlockPattern getGolemPattern()
  {
    ;
    if (llllIllIIIIlI(golemPattern)) {
      golemPattern = FactoryBlockPattern.start().aisle(new String[] { lIIlllllIIlI[lIIllllllIII[13]], lIIlllllIIlI[lIIllllllIII[14]], lIIlllllIIlI[lIIllllllIII[15]] }).where(lIIllllllIII[8], BlockWorldState.hasState(field_181085_Q)).where(lIIllllllIII[5], BlockWorldState.hasState(BlockStateHelper.forBlock(Blocks.iron_block))).where(lIIllllllIII[12], BlockWorldState.hasState(BlockStateHelper.forBlock(Blocks.air))).build();
    }
    return golemPattern;
  }
}

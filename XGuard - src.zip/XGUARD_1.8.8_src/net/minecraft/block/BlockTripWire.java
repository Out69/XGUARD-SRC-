package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockTripWire
  extends Block
{
  static
  {
    lIllIIIlIIII();
    lIllIIIIllll();
    POWERED = PropertyBool.create(llIlllIIIl[llIlllIIlI[0]]);
    SUSPENDED = PropertyBool.create(llIlllIIIl[llIlllIIlI[1]]);
    ATTACHED = PropertyBool.create(llIlllIIIl[llIlllIIlI[2]]);
    DISARMED = PropertyBool.create(llIlllIIIl[llIlllIIlI[3]]);
    NORTH = PropertyBool.create(llIlllIIIl[llIlllIIlI[4]]);
    EAST = PropertyBool.create(llIlllIIIl[llIlllIIlI[5]]);
    SOUTH = PropertyBool.create(llIlllIIIl[llIlllIIlI[6]]);
  }
  
  private static boolean lIllIIIlIllI(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllllllIlIllllIlIIIll;
    return ??? != localObject;
  }
  
  private static boolean lIllIIIlIIlI(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllllIlIllllIIlIIll;
    return ??? != i;
  }
  
  public boolean isFullCube()
  {
    return llIlllIIlI[0];
  }
  
  public Item getItemDropped(IBlockState llllllllllllllllllIllIIIlIIlIlll, Random llllllllllllllllllIllIIIlIIlIllI, int llllllllllllllllllIllIIIlIIlIlIl)
  {
    return Items.string;
  }
  
  private static String lIllIIIIllIl(String llllllllllllllllllIlIlllllIIIIIl, String llllllllllllllllllIlIllllIlllllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIlIlllllIIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlIllllIlllllI.getBytes(StandardCharsets.UTF_8)), llIlllIIlI[9]), "DES");
      Cipher llllllllllllllllllIlIlllllIIIIll = Cipher.getInstance("DES");
      llllllllllllllllllIlIlllllIIIIll.init(llIlllIIlI[2], llllllllllllllllllIlIlllllIIIlII);
      return new String(llllllllllllllllllIlIlllllIIIIll.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlIlllllIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIlIlllllIIIIlI)
    {
      llllllllllllllllllIlIlllllIIIIlI.printStackTrace();
    }
    return null;
  }
  
  private void updateState(World llllllllllllllllllIllIIIIIIIIlII, BlockPos llllllllllllllllllIllIIIIIIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllllllIllIIIIIIIIIlI = llllllllllllllllllIllIIIIIIIIlII.getBlockState(llllllllllllllllllIllIIIIIIIIIll);
    boolean llllllllllllllllllIllIIIIIIIIIIl = ((Boolean)llllllllllllllllllIllIIIIIIIIIlI.getValue(POWERED)).booleanValue();
    boolean llllllllllllllllllIllIIIIIIIIIII = llIlllIIlI[0];
    List<? extends Entity> llllllllllllllllllIlIlllllllllll = llllllllllllllllllIlIlllllllllII.getEntitiesWithinAABBExcludingEntity(null, new AxisAlignedBB(llllllllllllllllllIllIIIIIIIIIll.getX() + minX, llllllllllllllllllIllIIIIIIIIIll.getY() + minY, llllllllllllllllllIllIIIIIIIIIll.getZ() + minZ, llllllllllllllllllIllIIIIIIIIIll.getX() + maxX, llllllllllllllllllIllIIIIIIIIIll.getY() + maxY, llllllllllllllllllIllIIIIIIIIIll.getZ() + maxZ));
    if (lIllIIIlIIll(llllllllllllllllllIlIlllllllllll.isEmpty()))
    {
      llllllllllllllllllIlIlllllllIlIl = llllllllllllllllllIlIlllllllllll.iterator();
      "".length();
      if (-"  ".length() > 0) {
        return;
      }
      while (!lIllIIIlIIll(llllllllllllllllllIlIlllllllIlIl.hasNext()))
      {
        Entity llllllllllllllllllIlIllllllllllI = (Entity)llllllllllllllllllIlIlllllllIlIl.next();
        if (lIllIIIlIIll(llllllllllllllllllIlIllllllllllI.doesEntityNotTriggerPressurePlate()))
        {
          llllllllllllllllllIllIIIIIIIIIII = llIlllIIlI[1];
          "".length();
          if ("   ".length() > 0) {
            break;
          }
          return;
        }
      }
    }
    if (lIllIIIlIIlI(llllllllllllllllllIllIIIIIIIIIII, llllllllllllllllllIllIIIIIIIIIIl))
    {
      llllllllllllllllllIllIIIIIIIIIlI = llllllllllllllllllIllIIIIIIIIIlI.withProperty(POWERED, Boolean.valueOf(llllllllllllllllllIllIIIIIIIIIII));
      "".length();
      llllllllllllllllllIlIlllllllllIl.notifyHook(llllllllllllllllllIlIlllllllllII, llllllllllllllllllIllIIIIIIIIIll, llllllllllllllllllIllIIIIIIIIIlI);
    }
    if (lIllIIIlIIIl(llllllllllllllllllIllIIIIIIIIIII)) {
      llllllllllllllllllIlIlllllllllII.scheduleUpdate(llllllllllllllllllIllIIIIIIIIIll, llllllllllllllllllIlIlllllllllIl, llllllllllllllllllIlIlllllllllIl.tickRate(llllllllllllllllllIlIlllllllllII));
    }
  }
  
  public IBlockState getActualState(IBlockState llllllllllllllllllIllIIIlIlIIIlI, IBlockAccess llllllllllllllllllIllIIIlIlIIlII, BlockPos llllllllllllllllllIllIIIlIlIIIll)
  {
    ;
    ;
    ;
    return llllllllllllllllllIllIIIlIlIIIlI.withProperty(NORTH, Boolean.valueOf(isConnectedTo(llllllllllllllllllIllIIIlIlIIIIl, llllllllllllllllllIllIIIlIlIIIll, llllllllllllllllllIllIIIlIlIIIlI, EnumFacing.NORTH))).withProperty(EAST, Boolean.valueOf(isConnectedTo(llllllllllllllllllIllIIIlIlIIIIl, llllllllllllllllllIllIIIlIlIIIll, llllllllllllllllllIllIIIlIlIIIlI, EnumFacing.EAST))).withProperty(SOUTH, Boolean.valueOf(isConnectedTo(llllllllllllllllllIllIIIlIlIIIIl, llllllllllllllllllIllIIIlIlIIIll, llllllllllllllllllIllIIIlIlIIIlI, EnumFacing.SOUTH))).withProperty(WEST, Boolean.valueOf(isConnectedTo(llllllllllllllllllIllIIIlIlIIIIl, llllllllllllllllllIllIIIlIlIIIll, llllllllllllllllllIllIIIlIlIIIlI, EnumFacing.WEST)));
  }
  
  public void updateTick(World llllllllllllllllllIllIIIIIIlIlIl, BlockPos llllllllllllllllllIllIIIIIIIllll, IBlockState llllllllllllllllllIllIIIIIIlIIll, Random llllllllllllllllllIllIIIIIIlIIlI)
  {
    ;
    ;
    ;
    if ((lIllIIIlIIll(isRemote)) && (lIllIIIlIIIl(((Boolean)llllllllllllllllllIllIIIIIIlIlIl.getBlockState(llllllllllllllllllIllIIIIIIlIlII).getValue(POWERED)).booleanValue()))) {
      llllllllllllllllllIllIIIIIIlIIIl.updateState(llllllllllllllllllIllIIIIIIlIlIl, llllllllllllllllllIllIIIIIIlIlII);
    }
  }
  
  public static boolean isConnectedTo(IBlockAccess llllllllllllllllllIlIllllllIlIll, BlockPos llllllllllllllllllIlIllllllIIIII, IBlockState llllllllllllllllllIlIlllllIlllll, EnumFacing llllllllllllllllllIlIllllllIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    BlockPos llllllllllllllllllIlIllllllIIlll = llllllllllllllllllIlIllllllIIIII.offset(llllllllllllllllllIlIllllllIlIII);
    IBlockState llllllllllllllllllIlIllllllIIllI = llllllllllllllllllIlIllllllIlIll.getBlockState(llllllllllllllllllIlIllllllIIlll);
    Block llllllllllllllllllIlIllllllIIlIl = llllllllllllllllllIlIllllllIIllI.getBlock();
    if (lIllIIIlIlIl(llllllllllllllllllIlIllllllIIlIl, Blocks.tripwire_hook))
    {
      EnumFacing llllllllllllllllllIlIllllllIIlII = llllllllllllllllllIlIllllllIlIII.getOpposite();
      if (lIllIIIlIlIl(llllllllllllllllllIlIllllllIIllI.getValue(BlockTripWireHook.FACING), llllllllllllllllllIlIllllllIIlII)) {
        return llIlllIIlI[1];
      }
      return llIlllIIlI[0];
    }
    if (lIllIIIlIlIl(llllllllllllllllllIlIllllllIIlIl, Blocks.tripwire))
    {
      boolean llllllllllllllllllIlIllllllIIIll = ((Boolean)llllllllllllllllllIlIlllllIlllll.getValue(SUSPENDED)).booleanValue();
      boolean llllllllllllllllllIlIllllllIIIlI = ((Boolean)llllllllllllllllllIlIllllllIIllI.getValue(SUSPENDED)).booleanValue();
      if (lIllIIIllIII(llllllllllllllllllIlIllllllIIIll, llllllllllllllllllIlIllllllIIIlI)) {
        return llIlllIIlI[1];
      }
      return llIlllIIlI[0];
    }
    return llIlllIIlI[0];
  }
  
  public int getMetaFromState(IBlockState llllllllllllllllllIlIlllllIIllIl)
  {
    ;
    ;
    int llllllllllllllllllIlIlllllIIlllI = llIlllIIlI[0];
    if (lIllIIIlIIIl(((Boolean)llllllllllllllllllIlIlllllIIllll.getValue(POWERED)).booleanValue())) {
      llllllllllllllllllIlIlllllIIlllI |= llIlllIIlI[1];
    }
    if (lIllIIIlIIIl(((Boolean)llllllllllllllllllIlIlllllIIllll.getValue(SUSPENDED)).booleanValue())) {
      llllllllllllllllllIlIlllllIIlllI |= llIlllIIlI[2];
    }
    if (lIllIIIlIIIl(((Boolean)llllllllllllllllllIlIlllllIIllll.getValue(ATTACHED)).booleanValue())) {
      llllllllllllllllllIlIlllllIIlllI |= llIlllIIlI[4];
    }
    if (lIllIIIlIIIl(((Boolean)llllllllllllllllllIlIlllllIIllll.getValue(DISARMED)).booleanValue())) {
      llllllllllllllllllIlIlllllIIlllI |= llIlllIIlI[9];
    }
    return llllllllllllllllllIlIlllllIIlllI;
  }
  
  public void onBlockAdded(World llllllllllllllllllIllIIIIllIIlll, BlockPos llllllllllllllllllIllIIIIllIIllI, IBlockState llllllllllllllllllIllIIIIllIIlIl)
  {
    ;
    ;
    ;
    if (lIllIIIlIIIl(World.doesBlockHaveSolidTopSurface(llllllllllllllllllIllIIIIllIIlll, llllllllllllllllllIllIIIIllIIllI.down())))
    {
      "".length();
      if (null == null) {
        break label39;
      }
    }
    label39:
    IBlockState llllllllllllllllllIllIIIIllIIlIl = SUSPENDED.withProperty(llIlllIIlI[0], Boolean.valueOf(llIlllIIlI[1]));
    "".length();
    llllllllllllllllllIllIIIIllIIlII.notifyHook(llllllllllllllllllIllIIIIllIIlll, llllllllllllllllllIllIIIIllIIllI, llllllllllllllllllIllIIIIllIIlIl);
  }
  
  public boolean isOpaqueCube()
  {
    return llIlllIIlI[0];
  }
  
  private static boolean lIllIIIlIIIl(int ???)
  {
    char llllllllllllllllllIlIllllIIllIll;
    return ??? != 0;
  }
  
  public Item getItem(World llllllllllllllllllIllIIIlIIlIIll, BlockPos llllllllllllllllllIllIIIlIIlIIlI)
  {
    return Items.string;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllllllIlIlllllIIlIlI, new IProperty[] { POWERED, SUSPENDED, ATTACHED, DISARMED, NORTH, EAST, WEST, SOUTH });
  }
  
  private static void lIllIIIlIIII()
  {
    llIlllIIlI = new int[10];
    llIlllIIlI[0] = ((0xAC ^ 0x85) & (0x89 ^ 0xA0 ^ 0xFFFFFFFF));
    llIlllIIlI[1] = " ".length();
    llIlllIIlI[2] = "  ".length();
    llIlllIIlI[3] = "   ".length();
    llIlllIIlI[4] = (0xD7 ^ 0x8E ^ 0xCF ^ 0x92);
    llIlllIIlI[5] = (0x4B ^ 0x4E);
    llIlllIIlI[6] = (0xE ^ 0x8);
    llIlllIIlI[7] = ('' + 0 - 81 + 118 ^ 51 + 19 - -72 + 40);
    llIlllIIlI[8] = (0x5A ^ 0x70);
    llIlllIIlI[9] = (0x7B ^ 0x73);
  }
  
  public void breakBlock(World llllllllllllllllllIllIIIIlIlIlll, BlockPos llllllllllllllllllIllIIIIlIllIlI, IBlockState llllllllllllllllllIllIIIIlIllIIl)
  {
    ;
    ;
    ;
    ;
    llllllllllllllllllIllIIIIlIllIII.notifyHook(llllllllllllllllllIllIIIIlIlIlll, llllllllllllllllllIllIIIIlIllIlI, llllllllllllllllllIllIIIIlIllIIl.withProperty(POWERED, Boolean.valueOf(llIlllIIlI[1])));
  }
  
  public void onBlockHarvested(World llllllllllllllllllIllIIIIlIIllll, BlockPos llllllllllllllllllIllIIIIlIIlIlI, IBlockState llllllllllllllllllIllIIIIlIIlIIl, EntityPlayer llllllllllllllllllIllIIIIlIIlIII)
  {
    ;
    ;
    ;
    ;
    if ((lIllIIIlIIll(isRemote)) && (lIllIIIlIlII(llllllllllllllllllIllIIIIlIIlIII.getCurrentEquippedItem())) && (lIllIIIlIlIl(llllllllllllllllllIllIIIIlIIlIII.getCurrentEquippedItem().getItem(), Items.shears))) {
      "".length();
    }
  }
  
  public BlockTripWire()
  {
    llllllllllllllllllIllIIIlIlIlIll.<init>(Material.circuits);
    llllllllllllllllllIllIIIlIlIlIlI.setDefaultState(blockState.getBaseState().withProperty(POWERED, Boolean.valueOf(llIlllIIlI[0])).withProperty(SUSPENDED, Boolean.valueOf(llIlllIIlI[0])).withProperty(ATTACHED, Boolean.valueOf(llIlllIIlI[0])).withProperty(DISARMED, Boolean.valueOf(llIlllIIlI[0])).withProperty(NORTH, Boolean.valueOf(llIlllIIlI[0])).withProperty(EAST, Boolean.valueOf(llIlllIIlI[0])).withProperty(SOUTH, Boolean.valueOf(llIlllIIlI[0])).withProperty(WEST, Boolean.valueOf(llIlllIIlI[0])));
    llllllllllllllllllIllIIIlIlIlIlI.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.15625F, 1.0F);
    "".length();
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllllllIlIlllllIlIIll)
  {
    ;
    ;
    if (lIllIIIllIIl(llllllllllllllllllIlIlllllIlIIll & llIlllIIlI[1]))
    {
      "".length();
      if ("   ".length() == "   ".length()) {
        break label53;
      }
      return null;
    }
    label53:
    if (lIllIIIllIIl(llllllllllllllllllIlIlllllIlIIll & llIlllIIlI[2]))
    {
      "".length();
      if (((79 + 86 - 162 + 134 ^ 32 + 73 - -6 + 73) & (0xEF ^ 0xA7 ^ 0x4D ^ 0x34 ^ -" ".length())) == 0) {
        break label145;
      }
      return null;
    }
    label145:
    if (lIllIIIllIIl(llllllllllllllllllIlIlllllIlIIll & llIlllIIlI[4]))
    {
      "".length();
      if (-" ".length() < "  ".length()) {
        break label202;
      }
      return null;
    }
    label202:
    if (lIllIIIllIIl(llllllllllllllllllIlIlllllIlIIll & llIlllIIlI[9]))
    {
      "".length();
      if ((0xC ^ 0x5A ^ 0x2F ^ 0x7D) >= 0) {
        break label259;
      }
      return null;
    }
    label259:
    return DISARMED.withProperty(llIlllIIlI[1], Boolean.valueOf(llIlllIIlI[0]));
  }
  
  private static boolean lIllIIIlIIll(int ???)
  {
    long llllllllllllllllllIlIllllIIllIIl;
    return ??? == 0;
  }
  
  private static boolean lIllIIIlIlIl(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllllllIlIllllIIlllIl;
    return ??? == localObject;
  }
  
  private static boolean lIllIIIlIlll(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllllllIlIllllIlIIlll;
    return ??? >= i;
  }
  
  public void randomTick(World llllllllllllllllllIllIIIIIIlllIl, BlockPos llllllllllllllllllIllIIIIIIlllII, IBlockState llllllllllllllllllIllIIIIIIllIll, Random llllllllllllllllllIllIIIIIIllIlI) {}
  
  private static String lIllIIIIlllI(String llllllllllllllllllIlIllllIllIlII, String llllllllllllllllllIlIllllIllIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIlIllllIllIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlIllllIllIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIlIllllIllIllI = Cipher.getInstance("Blowfish");
      llllllllllllllllllIlIllllIllIllI.init(llIlllIIlI[2], llllllllllllllllllIlIllllIllIlll);
      return new String(llllllllllllllllllIlIllllIllIllI.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlIllllIllIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIlIllllIllIlIl)
    {
      llllllllllllllllllIlIllllIllIlIl.printStackTrace();
    }
    return null;
  }
  
  public void onEntityCollidedWithBlock(World llllllllllllllllllIllIIIIIlIIllI, BlockPos llllllllllllllllllIllIIIIIlIIIII, IBlockState llllllllllllllllllIllIIIIIlIIlII, Entity llllllllllllllllllIllIIIIIlIIIll)
  {
    ;
    ;
    ;
    ;
    if ((lIllIIIlIIll(isRemote)) && (lIllIIIlIIll(((Boolean)llllllllllllllllllIllIIIIIlIIlII.getValue(POWERED)).booleanValue()))) {
      llllllllllllllllllIllIIIIIlIIlll.updateState(llllllllllllllllllIllIIIIIlIIllI, llllllllllllllllllIllIIIIIlIIlIl);
    }
  }
  
  private static boolean lIllIIIlIlII(Object ???)
  {
    String llllllllllllllllllIlIllllIlIIIIl;
    return ??? != null;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllllllIllIIIIlllIlll, BlockPos llllllllllllllllllIllIIIIlllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllllllIllIIIIlllIlIl = llllllllllllllllllIllIIIIlllIlll.getBlockState(llllllllllllllllllIllIIIIlllIIII);
    boolean llllllllllllllllllIllIIIIlllIlII = ((Boolean)llllllllllllllllllIllIIIIlllIlIl.getValue(ATTACHED)).booleanValue();
    boolean llllllllllllllllllIllIIIIlllIIll = ((Boolean)llllllllllllllllllIllIIIIlllIlIl.getValue(SUSPENDED)).booleanValue();
    if (lIllIIIlIIll(llllllllllllllllllIllIIIIlllIIll))
    {
      llllllllllllllllllIllIIIIllllIII.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.09375F, 1.0F);
      "".length();
      if (-" ".length() <= 0) {}
    }
    else if (lIllIIIlIIll(llllllllllllllllllIllIIIIlllIlII))
    {
      llllllllllllllllllIllIIIIllllIII.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
      "".length();
      if (((60 + 116 - 71 + 112 ^ 86 + '' - 139 + 91) & (0x7F ^ 0x36 ^ 0x64 ^ 0x31 ^ -" ".length())) != "  ".length()) {}
    }
    else
    {
      llllllllllllllllllIllIIIIllllIII.setBlockBounds(0.0F, 0.0625F, 0.0F, 1.0F, 0.15625F, 1.0F);
    }
  }
  
  private static void lIllIIIIllll()
  {
    llIlllIIIl = new String[llIlllIIlI[9]];
    llIlllIIIl[llIlllIIlI[0]] = lIllIIIIllIl("KiIiSNdbeSU=", "arBWB");
    llIlllIIIl[llIlllIIlI[1]] = lIllIIIIlllI("jWYRH4/l6zA9yp+Eh5SMhA==", "sBKEl");
    llIlllIIIl[llIlllIIlI[2]] = lIllIIIIllIl("DVVuvgnhF0zIZooONKDYZQ==", "jfTDB");
    llIlllIIIl[llIlllIIlI[3]] = lIllIIIIlllI("MOEITRAOIlcXgxnY6QuBmA==", "diwTA");
    llIlllIIIl[llIlllIIlI[4]] = lIllIIIIlllI("CPOMFezS+LI=", "aYqdw");
    llIlllIIIl[llIlllIIlI[5]] = lIllIIIIllIl("/Dn8oqsrHNQ=", "IFSJM");
    llIlllIIIl[llIlllIIlI[6]] = lIllIIIIllIl("+Hj63f+Esxg=", "WMmSq");
    llIlllIIIl[llIlllIIlI[7]] = lIllIIIIlllI("ZKwyHWhEv9c=", "Lnovx");
  }
  
  private static boolean lIllIIIllIIl(int ???)
  {
    int llllllllllllllllllIlIllllIIlIlll;
    return ??? > 0;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.TRANSLUCENT;
  }
  
  private static boolean lIllIIIllIII(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllllllIlIllllIlIlIll;
    return ??? == i;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllllllIllIIIlIIllllI, BlockPos llllllllllllllllllIllIIIlIIlllIl, IBlockState llllllllllllllllllIllIIIlIIlllII)
  {
    return null;
  }
  
  public void onNeighborBlockChange(World llllllllllllllllllIllIIIlIIIIIll, BlockPos llllllllllllllllllIllIIIlIIIIIlI, IBlockState llllllllllllllllllIllIIIlIIIlIII, Block llllllllllllllllllIllIIIlIIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    boolean llllllllllllllllllIllIIIlIIIIllI = ((Boolean)llllllllllllllllllIllIIIlIIIlIII.getValue(SUSPENDED)).booleanValue();
    if (lIllIIIlIIIl(World.doesBlockHaveSolidTopSurface(llllllllllllllllllIllIIIlIIIIIll, llllllllllllllllllIllIIIlIIIlIIl.down())))
    {
      "".length();
      if (" ".length() >= 0) {
        break label57;
      }
    }
    label57:
    boolean llllllllllllllllllIllIIIlIIIIlIl = llIlllIIlI[1];
    if (lIllIIIlIIlI(llllllllllllllllllIllIIIlIIIIllI, llllllllllllllllllIllIIIlIIIIlIl))
    {
      llllllllllllllllllIllIIIlIIIIlII.dropBlockAsItem(llllllllllllllllllIllIIIlIIIIIll, llllllllllllllllllIllIIIlIIIlIIl, llllllllllllllllllIllIIIlIIIlIII, llIlllIIlI[0]);
      "".length();
    }
  }
  
  private void notifyHook(World llllllllllllllllllIllIIIIIllIlIl, BlockPos llllllllllllllllllIllIIIIIlllIll, IBlockState llllllllllllllllllIllIIIIIlllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    short llllllllllllllllllIllIIIIIllIIII = (llllllllllllllllllIllIIIIIlIllll = new EnumFacing[] { EnumFacing.SOUTH, EnumFacing.WEST }).length;
    String llllllllllllllllllIllIIIIIllIIIl = llIlllIIlI[0];
    "".length();
    if (" ".length() >= ('´' + '' - 159 + 24 ^ 20 + '' - 121 + 145)) {
      return;
    }
    while (!lIllIIIlIlll(llllllllllllllllllIllIIIIIllIIIl, llllllllllllllllllIllIIIIIllIIII))
    {
      EnumFacing llllllllllllllllllIllIIIIIlllIIl = llllllllllllllllllIllIIIIIlIllll[llllllllllllllllllIllIIIIIllIIIl];
      int llllllllllllllllllIllIIIIIlllIII = llIlllIIlI[1];
      "".length();
      if (-"  ".length() > 0) {
        return;
      }
      while (!lIllIIIlIlll(llllllllllllllllllIllIIIIIlllIII, llIlllIIlI[8]))
      {
        BlockPos llllllllllllllllllIllIIIIIllIlll = llllllllllllllllllIllIIIIIllIlII.offset(llllllllllllllllllIllIIIIIlllIIl, llllllllllllllllllIllIIIIIlllIII);
        IBlockState llllllllllllllllllIllIIIIIllIllI = llllllllllllllllllIllIIIIIllIlIl.getBlockState(llllllllllllllllllIllIIIIIllIlll);
        if (lIllIIIlIlIl(llllllllllllllllllIllIIIIIllIllI.getBlock(), Blocks.tripwire_hook))
        {
          if (!lIllIIIlIlIl(llllllllllllllllllIllIIIIIllIllI.getValue(BlockTripWireHook.FACING), llllllllllllllllllIllIIIIIlllIIl.getOpposite())) {
            break;
          }
          Blocks.tripwire_hook.func_176260_a(llllllllllllllllllIllIIIIIllIlIl, llllllllllllllllllIllIIIIIllIlll, llllllllllllllllllIllIIIIIllIllI, llIlllIIlI[0], llIlllIIlI[1], llllllllllllllllllIllIIIIIlllIII, llllllllllllllllllIllIIIIIlllIlI);
          "".length();
          if ("   ".length() >= 0) {
            break;
          }
          return;
        }
        if (lIllIIIlIllI(llllllllllllllllllIllIIIIIllIllI.getBlock(), Blocks.tripwire))
        {
          "".length();
          if ((0xB4 ^ 0xB0) >= ((0xA0 ^ 0x9C) & (0x89 ^ 0xB5 ^ 0xFFFFFFFF))) {
            break;
          }
          return;
        }
        llllllllllllllllllIllIIIIIlllIII++;
      }
      llllllllllllllllllIllIIIIIllIIIl++;
    }
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.InventoryLargeChest;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.ILockableContainer;
import net.minecraft.world.World;

public class BlockChest
  extends BlockContainer
{
  private static boolean lIIllIIIIIIIll(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIIIllIIlllIlIIlIl;
    return ??? <= i;
  }
  
  public boolean isFullCube()
  {
    return llIIIlllIlII[0];
  }
  
  public IBlockState onBlockPlaced(World lllllllllllllllIIIllIlIlIlIIllII, BlockPos lllllllllllllllIIIllIlIlIlIIlIlI, EnumFacing lllllllllllllllIIIllIlIlIlIIlIIl, float lllllllllllllllIIIllIlIlIlIIlIII, float lllllllllllllllIIIllIlIlIlIIIIll, float lllllllllllllllIIIllIlIlIlIIIIIl, int lllllllllllllllIIIllIlIlIIllllll, EntityLivingBase lllllllllllllllIIIllIlIlIIlllIll)
  {
    ;
    ;
    return lllllllllllllllIIIllIlIlIlIIllIl.getDefaultState().withProperty(FACING, lllllllllllllllIIIllIlIlIIlllIll.getHorizontalFacing());
  }
  
  private boolean isBlocked(World lllllllllllllllIIIllIIlllllIlllI, BlockPos lllllllllllllllIIIllIIlllllIllIl)
  {
    ;
    ;
    ;
    if ((lIIlIlllllllll(lllllllllllllllIIIllIIlllllIllll.isBelowSolidBlock(lllllllllllllllIIIllIIlllllIlIll, lllllllllllllllIIIllIIlllllIllIl))) && (lIIlIlllllllll(lllllllllllllllIIIllIIlllllIllll.isOcelotSittingOnChest(lllllllllllllllIIIllIIlllllIlIll, lllllllllllllllIIIllIIlllllIllIl)))) {
      return llIIIlllIlII[0];
    }
    return llIIIlllIlII[3];
  }
  
  public boolean canPlaceBlockAt(World lllllllllllllllIIIllIlIIlIIIllIl, BlockPos lllllllllllllllIIIllIlIIlIIIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIIIllIlIIlIIIlIll = llIIIlllIlII[0];
    BlockPos lllllllllllllllIIIllIlIIlIIIlIlI = lllllllllllllllIIIllIlIIlIIIIlII.west();
    BlockPos lllllllllllllllIIIllIlIIlIIIlIIl = lllllllllllllllIIIllIlIIlIIIIlII.east();
    BlockPos lllllllllllllllIIIllIlIIlIIIlIII = lllllllllllllllIIIllIlIIlIIIIlII.north();
    BlockPos lllllllllllllllIIIllIlIIlIIIIlll = lllllllllllllllIIIllIlIIlIIIIlII.south();
    if (lIIlIllllllllI(lllllllllllllllIIIllIlIIlIIIIlIl.getBlockState(lllllllllllllllIIIllIlIIlIIIlIlI).getBlock(), lllllllllllllllIIIllIlIIlIIIIllI))
    {
      if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIlIIIIllI.isDoubleChest(lllllllllllllllIIIllIlIIlIIIIlIl, lllllllllllllllIIIllIlIIlIIIlIlI))) {
        return llIIIlllIlII[0];
      }
      lllllllllllllllIIIllIlIIlIIIlIll++;
    }
    if (lIIlIllllllllI(lllllllllllllllIIIllIlIIlIIIIlIl.getBlockState(lllllllllllllllIIIllIlIIlIIIlIIl).getBlock(), lllllllllllllllIIIllIlIIlIIIIllI))
    {
      if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIlIIIIllI.isDoubleChest(lllllllllllllllIIIllIlIIlIIIIlIl, lllllllllllllllIIIllIlIIlIIIlIIl))) {
        return llIIIlllIlII[0];
      }
      lllllllllllllllIIIllIlIIlIIIlIll++;
    }
    if (lIIlIllllllllI(lllllllllllllllIIIllIlIIlIIIIlIl.getBlockState(lllllllllllllllIIIllIlIIlIIIlIII).getBlock(), lllllllllllllllIIIllIlIIlIIIIllI))
    {
      if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIlIIIIllI.isDoubleChest(lllllllllllllllIIIllIlIIlIIIIlIl, lllllllllllllllIIIllIlIIlIIIlIII))) {
        return llIIIlllIlII[0];
      }
      lllllllllllllllIIIllIlIIlIIIlIll++;
    }
    if (lIIlIllllllllI(lllllllllllllllIIIllIlIIlIIIIlIl.getBlockState(lllllllllllllllIIIllIlIIlIIIIlll).getBlock(), lllllllllllllllIIIllIlIIlIIIIllI))
    {
      if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIlIIIIllI.isDoubleChest(lllllllllllllllIIIllIlIIlIIIIlIl, lllllllllllllllIIIllIlIIlIIIIlll))) {
        return llIIIlllIlII[0];
      }
      lllllllllllllllIIIllIlIIlIIIlIll++;
    }
    if (lIIllIIIIIIIll(lllllllllllllllIIIllIlIIlIIIlIll, llIIIlllIlII[3])) {
      return llIIIlllIlII[3];
    }
    return llIIIlllIlII[0];
  }
  
  public void onNeighborBlockChange(World lllllllllllllllIIIllIlIIIllIIllI, BlockPos lllllllllllllllIIIllIlIIIlIlllll, IBlockState lllllllllllllllIIIllIlIIIllIIlII, Block lllllllllllllllIIIllIlIIIlIlllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIllIlIIIllIIlll.onNeighborBlockChange(lllllllllllllllIIIllIlIIIllIIllI, lllllllllllllllIIIllIlIIIllIIlIl, lllllllllllllllIIIllIlIIIllIIlII, lllllllllllllllIIIllIlIIIlIlllIl);
    TileEntity lllllllllllllllIIIllIlIIIllIIIlI = lllllllllllllllIIIllIlIIIllIIllI.getTileEntity(lllllllllllllllIIIllIlIIIllIIlIl);
    if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIIllIIIlI instanceof TileEntityChest)) {
      lllllllllllllllIIIllIlIIIllIIIlI.updateContainingBlockInfo();
    }
  }
  
  private boolean isOcelotSittingOnChest(World lllllllllllllllIIIllIIllllIlllII, BlockPos lllllllllllllllIIIllIIllllIlIlll)
  {
    ;
    ;
    ;
    ;
    float lllllllllllllllIIIllIIllllIlIlIl = lllllllllllllllIIIllIIllllIlllII.getEntitiesWithinAABB(EntityOcelot.class, new AxisAlignedBB(lllllllllllllllIIIllIIllllIlIlll.getX(), lllllllllllllllIIIllIIllllIlIlll.getY() + llIIIlllIlII[3], lllllllllllllllIIIllIIllllIlIlll.getZ(), lllllllllllllllIIIllIIllllIlIlll.getX() + llIIIlllIlII[3], lllllllllllllllIIIllIIllllIlIlll.getY() + llIIIlllIlII[1], lllllllllllllllIIIllIIllllIlIlll.getZ() + llIIIlllIlII[3])).iterator();
    "".length();
    if (((0x1D ^ 0x4C ^ 0x18 ^ 0x6) & (113 + 83 - 141 + 145 ^ 16 + 46 - -53 + 20 ^ -" ".length())) != 0) {
      return (0x51 ^ 0x36 ^ 0xF5 ^ 0x88) & (0x62 ^ 0x66 ^ 0xB8 ^ 0xA6 ^ -" ".length());
    }
    while (!lIIlIlllllllll(lllllllllllllllIIIllIIllllIlIlIl.hasNext()))
    {
      Entity lllllllllllllllIIIllIIllllIllIlI = (Entity)lllllllllllllllIIIllIIllllIlIlIl.next();
      EntityOcelot lllllllllllllllIIIllIIllllIllIIl = (EntityOcelot)lllllllllllllllIIIllIIllllIllIlI;
      if (lIIllIIIIIIIII(lllllllllllllllIIIllIIllllIllIIl.isSitting())) {
        return llIIIlllIlII[3];
      }
    }
    return llIIIlllIlII[0];
  }
  
  private static boolean lIIllIIIIIIIIl(Object ???, Object arg1)
  {
    Object localObject;
    short lllllllllllllllIIIllIIlllIlIIIIl;
    return ??? != localObject;
  }
  
  private static boolean lIIlIlllllllll(int ???)
  {
    Exception lllllllllllllllIIIllIIlllIIlIlll;
    return ??? == 0;
  }
  
  private static boolean lIIlIllllllllI(Object ???, Object arg1)
  {
    Object localObject;
    String lllllllllllllllIIIllIIlllIIlllIl;
    return ??? == localObject;
  }
  
  private static void lIIlIlllllllIl()
  {
    llIIIlllIlII = new int[5];
    llIIIlllIlII[0] = ((0x36 ^ 0x20) & (0xD7 ^ 0xC1 ^ 0xFFFFFFFF));
    llIIIlllIlII[1] = "  ".length();
    llIIIlllIlII[2] = "   ".length();
    llIIIlllIlII[3] = " ".length();
    llIIIlllIlII[4] = (0x1B ^ 0x28 ^ 0x44 ^ 0x78);
  }
  
  public IBlockState correctFacing(World lllllllllllllllIIIllIlIIlIlIIlll, BlockPos lllllllllllllllIIIllIlIIlIlIIllI, IBlockState lllllllllllllllIIIllIlIIlIIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing lllllllllllllllIIIllIlIIlIlIIlII = null;
    Exception lllllllllllllllIIIllIlIIlIIllIIl = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if (-"  ".length() > 0) {
      return null;
    }
    while (!lIIlIlllllllll(lllllllllllllllIIIllIlIIlIIllIIl.hasNext()))
    {
      Object lllllllllllllllIIIllIlIIlIlIIIll = lllllllllllllllIIIllIlIIlIIllIIl.next();
      EnumFacing lllllllllllllllIIIllIlIIlIlIIIlI = (EnumFacing)lllllllllllllllIIIllIlIIlIlIIIll;
      IBlockState lllllllllllllllIIIllIlIIlIlIIIIl = lllllllllllllllIIIllIlIIlIlIIlll.getBlockState(lllllllllllllllIIIllIlIIlIlIIllI.offset(lllllllllllllllIIIllIlIIlIlIIIlI));
      if (lIIlIllllllllI(lllllllllllllllIIIllIlIIlIlIIIIl.getBlock(), lllllllllllllllIIIllIlIIlIIlllll)) {
        return lllllllllllllllIIIllIlIIlIIlllII;
      }
      if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIlIlIIIIl.getBlock().isFullBlock()))
      {
        if (lIIllIIIIIIIlI(lllllllllllllllIIIllIlIIlIlIIlII))
        {
          lllllllllllllllIIIllIlIIlIlIIlII = null;
          "".length();
          if ("   ".length() == "   ".length()) {
            break;
          }
          return null;
        }
        lllllllllllllllIIIllIlIIlIlIIlII = lllllllllllllllIIIllIlIIlIlIIIlI;
      }
    }
    if (lIIllIIIIIIIlI(lllllllllllllllIIIllIlIIlIlIIlII)) {
      return lllllllllllllllIIIllIlIIlIIlllII.withProperty(FACING, lllllllllllllllIIIllIlIIlIlIIlII.getOpposite());
    }
    EnumFacing lllllllllllllllIIIllIlIIlIlIIIII = (EnumFacing)lllllllllllllllIIIllIlIIlIIlllII.getValue(FACING);
    if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIlIlIIlll.getBlockState(lllllllllllllllIIIllIlIIlIlIIllI.offset(lllllllllllllllIIIllIlIIlIlIIIII)).getBlock().isFullBlock())) {
      lllllllllllllllIIIllIlIIlIlIIIII = lllllllllllllllIIIllIlIIlIlIIIII.getOpposite();
    }
    if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIlIlIIlll.getBlockState(lllllllllllllllIIIllIlIIlIlIIllI.offset(lllllllllllllllIIIllIlIIlIlIIIII)).getBlock().isFullBlock())) {
      lllllllllllllllIIIllIlIIlIlIIIII = lllllllllllllllIIIllIlIIlIlIIIII.rotateY();
    }
    if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIlIlIIlll.getBlockState(lllllllllllllllIIIllIlIIlIlIIllI.offset(lllllllllllllllIIIllIlIIlIlIIIII)).getBlock().isFullBlock())) {
      lllllllllllllllIIIllIlIIlIlIIIII = lllllllllllllllIIIllIlIIlIlIIIII.getOpposite();
    }
    return lllllllllllllllIIIllIlIIlIIlllII.withProperty(FACING, lllllllllllllllIIIllIlIIlIlIIIII);
  }
  
  private static String lIIlIllllllIll(String lllllllllllllllIIIllIIlllIllIIII, String lllllllllllllllIIIllIIlllIlIllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIIllIIlllIllIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIllIIlllIlIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIIllIIlllIllIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllIIIllIIlllIllIlII.init(llIIIlllIlII[1], lllllllllllllllIIIllIIlllIllIlIl);
      return new String(lllllllllllllllIIIllIIlllIllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIllIIlllIllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIIllIIlllIllIIll)
    {
      lllllllllllllllIIIllIIlllIllIIll.printStackTrace();
    }
    return null;
  }
  
  public void onBlockAdded(World lllllllllllllllIIIllIlIlIllIlIII, BlockPos lllllllllllllllIIIllIlIlIllIIlll, IBlockState lllllllllllllllIIIllIlIlIlIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    "".length();
    long lllllllllllllllIIIllIlIlIlIlIllI = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if ((0x54 ^ 0x50) <= -" ".length()) {
      return;
    }
    while (!lIIlIlllllllll(lllllllllllllllIIIllIlIlIlIlIllI.hasNext()))
    {
      Object lllllllllllllllIIIllIlIlIllIIlIl = lllllllllllllllIIIllIlIlIlIlIllI.next();
      EnumFacing lllllllllllllllIIIllIlIlIllIIlII = (EnumFacing)lllllllllllllllIIIllIlIlIllIIlIl;
      BlockPos lllllllllllllllIIIllIlIlIllIIIll = lllllllllllllllIIIllIlIlIllIIlll.offset(lllllllllllllllIIIllIlIlIllIIlII);
      IBlockState lllllllllllllllIIIllIlIlIlIlllll = lllllllllllllllIIIllIlIlIllIlIII.getBlockState(lllllllllllllllIIIllIlIlIllIIIll);
      if (lIIlIllllllllI(lllllllllllllllIIIllIlIlIlIlllll.getBlock(), lllllllllllllllIIIllIlIlIllIlIIl)) {
        "".length();
      }
    }
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess lllllllllllllllIIIllIlIllIIIIlIl, BlockPos lllllllllllllllIIIllIlIllIIIIlII)
  {
    ;
    ;
    ;
    if (lIIlIllllllllI(lllllllllllllllIIIllIlIllIIIIlIl.getBlockState(lllllllllllllllIIIllIlIllIIIIlII.north()).getBlock(), lllllllllllllllIIIllIlIllIIIIllI))
    {
      lllllllllllllllIIIllIlIllIIIIllI.setBlockBounds(0.0625F, 0.0F, 0.0F, 0.9375F, 0.875F, 0.9375F);
      "".length();
      if (null == null) {}
    }
    else if (lIIlIllllllllI(lllllllllllllllIIIllIlIllIIIIIlI.getBlockState(lllllllllllllllIIIllIlIllIIIIlII.south()).getBlock(), lllllllllllllllIIIllIlIllIIIIllI))
    {
      lllllllllllllllIIIllIlIllIIIIllI.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 1.0F);
      "".length();
      if (-" ".length() < 0) {}
    }
    else if (lIIlIllllllllI(lllllllllllllllIIIllIlIllIIIIIlI.getBlockState(lllllllllllllllIIIllIlIllIIIIlII.west()).getBlock(), lllllllllllllllIIIllIlIllIIIIllI))
    {
      lllllllllllllllIIIllIlIllIIIIllI.setBlockBounds(0.0F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
      "".length();
      if (" ".length() == " ".length()) {}
    }
    else if (lIIlIllllllllI(lllllllllllllllIIIllIlIllIIIIIlI.getBlockState(lllllllllllllllIIIllIlIllIIIIlII.east()).getBlock(), lllllllllllllllIIIllIlIllIIIIllI))
    {
      lllllllllllllllIIIllIlIllIIIIllI.setBlockBounds(0.0625F, 0.0F, 0.0625F, 1.0F, 0.875F, 0.9375F);
      "".length();
      if (-(0xC1 ^ 0xC5) < 0) {}
    }
    else
    {
      lllllllllllllllIIIllIlIllIIIIllI.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
    }
  }
  
  protected BlockChest(int lllllllllllllllIIIllIlIllIIIllIl)
  {
    lllllllllllllllIIIllIlIllIIIlllI.<init>(Material.wood);
    lllllllllllllllIIIllIlIllIIIlllI.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
    chestType = lllllllllllllllIIIllIlIllIIIllIl;
    "".length();
    lllllllllllllllIIIllIlIllIIIlllI.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
  }
  
  public int getComparatorInputOverride(World lllllllllllllllIIIllIIllllIIlllI, BlockPos lllllllllllllllIIIllIIllllIIllIl)
  {
    ;
    ;
    ;
    return Container.calcRedstoneFromInventory(lllllllllllllllIIIllIIllllIIllII.getLockableContainer(lllllllllllllllIIIllIIllllIIlIll, lllllllllllllllIIIllIIllllIIllIl));
  }
  
  static
  {
    lIIlIlllllllIl();
    lIIlIlllllllII();
  }
  
  public int getRenderType()
  {
    return llIIIlllIlII[1];
  }
  
  private static boolean lIIllIIIIIIlII(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllIIIllIIlllIlIlIIl;
    return ??? == i;
  }
  
  public int getStrongPower(IBlockAccess lllllllllllllllIIIllIIlllllllIll, BlockPos lllllllllllllllIIIllIIllllllIlIl, IBlockState lllllllllllllllIIIllIIlllllllIIl, EnumFacing lllllllllllllllIIIllIIlllllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIlIllllllllI(lllllllllllllllIIIllIIlllllllIII, EnumFacing.UP))
    {
      "".length();
      if ((0x82 ^ 0x86) > " ".length()) {
        break label60;
      }
      return (0x6F ^ 0x25) & (0x6C ^ 0x26 ^ 0xFFFFFFFF);
    }
    label60:
    return llIIIlllIlII[0];
  }
  
  public boolean isOpaqueCube()
  {
    return llIIIlllIlII[0];
  }
  
  public ILockableContainer getLockableContainer(World lllllllllllllllIIIllIlIIIIlIllII, BlockPos lllllllllllllllIIIllIlIIIIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    TileEntity lllllllllllllllIIIllIlIIIIlIlIlI = lllllllllllllllIIIllIlIIIIlIllII.getTileEntity(lllllllllllllllIIIllIlIIIIlIIIIl);
    if (lIIlIlllllllll(lllllllllllllllIIIllIlIIIIlIlIlI instanceof TileEntityChest)) {
      return null;
    }
    ILockableContainer lllllllllllllllIIIllIlIIIIlIlIIl = (TileEntityChest)lllllllllllllllIIIllIlIIIIlIlIlI;
    if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIIIlIIIll.isBlocked(lllllllllllllllIIIllIlIIIIlIIIlI, lllllllllllllllIIIllIlIIIIlIIIIl))) {
      return null;
    }
    char lllllllllllllllIIIllIlIIIIIlllIl = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if (((0x10 ^ 0x59) & (0x1C ^ 0x55 ^ 0xFFFFFFFF)) < 0) {
      return null;
    }
    while (!lIIlIlllllllll(lllllllllllllllIIIllIlIIIIIlllIl.hasNext()))
    {
      Object lllllllllllllllIIIllIlIIIIlIlIII = lllllllllllllllIIIllIlIIIIIlllIl.next();
      EnumFacing lllllllllllllllIIIllIlIIIIlIIlll = (EnumFacing)lllllllllllllllIIIllIlIIIIlIlIII;
      BlockPos lllllllllllllllIIIllIlIIIIlIIllI = lllllllllllllllIIIllIlIIIIlIIIIl.offset(lllllllllllllllIIIllIlIIIIlIIlll);
      Block lllllllllllllllIIIllIlIIIIlIIlIl = lllllllllllllllIIIllIlIIIIlIIIlI.getBlockState(lllllllllllllllIIIllIlIIIIlIIllI).getBlock();
      if (lIIlIllllllllI(lllllllllllllllIIIllIlIIIIlIIlIl, lllllllllllllllIIIllIlIIIIlIIIll))
      {
        if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIIIlIIIll.isBlocked(lllllllllllllllIIIllIlIIIIlIIIlI, lllllllllllllllIIIllIlIIIIlIIllI))) {
          return null;
        }
        TileEntity lllllllllllllllIIIllIlIIIIlIIlII = lllllllllllllllIIIllIlIIIIlIIIlI.getTileEntity(lllllllllllllllIIIllIlIIIIlIIllI);
        if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIIIlIIlII instanceof TileEntityChest)) {
          if ((lIIllIIIIIIIIl(lllllllllllllllIIIllIlIIIIlIIlll, EnumFacing.WEST)) && (lIIllIIIIIIIIl(lllllllllllllllIIIllIlIIIIlIIlll, EnumFacing.NORTH)))
          {
            lllllllllllllllIIIllIlIIIIlIlIIl = new InventoryLargeChest(llIIIlllIIll[llIIIlllIlII[3]], lllllllllllllllIIIllIlIIIIlIlIIl, (TileEntityChest)lllllllllllllllIIIllIlIIIIlIIlII);
            "".length();
            if (((0x3F ^ 0x78) & (0xC7 ^ 0x80 ^ 0xFFFFFFFF)) != 0) {
              return null;
            }
          }
          else
          {
            lllllllllllllllIIIllIlIIIIlIlIIl = new InventoryLargeChest(llIIIlllIIll[llIIIlllIlII[1]], (TileEntityChest)lllllllllllllllIIIllIlIIIIlIIlII, lllllllllllllllIIIllIlIIIIlIlIIl);
          }
        }
      }
    }
    return lllllllllllllllIIIllIlIIIIlIlIIl;
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIIIllIIllllIIIlIl)
  {
    ;
    ;
    ;
    EnumFacing lllllllllllllllIIIllIIllllIIIlII = EnumFacing.getFront(lllllllllllllllIIIllIIllllIIIlIl);
    if (lIIlIllllllllI(lllllllllllllllIIIllIIllllIIIlII.getAxis(), EnumFacing.Axis.Y)) {
      lllllllllllllllIIIllIIllllIIIlII = EnumFacing.NORTH;
    }
    return lllllllllllllllIIIllIIllllIIIIll.getDefaultState().withProperty(FACING, lllllllllllllllIIIllIIllllIIIlII);
  }
  
  private static void lIIlIlllllllII()
  {
    llIIIlllIIll = new String[llIIIlllIlII[2]];
    llIIIlllIIll[llIIIlllIlII[0]] = lIIlIllllllIll("TGKCoE7xVF0=", "KOOGw");
    llIIIlllIIll[llIIIlllIlII[3]] = lIIlIllllllIll("b+7pT+gbE8ackFHiqC1H53WMVEt7xK4Q", "Tdzft");
    llIIIlllIIll[llIIIlllIlII[1]] = lIIlIllllllIll("/uJZE0G9QhJKVM95kbsK9DMXwwk+OQwp", "xSEQN");
  }
  
  public TileEntity createNewTileEntity(World lllllllllllllllIIIllIlIIIIIlIlll, int lllllllllllllllIIIllIlIIIIIlIllI)
  {
    return new TileEntityChest();
  }
  
  private boolean isDoubleChest(World lllllllllllllllIIIllIlIIIlllIlll, BlockPos lllllllllllllllIIIllIlIIIlllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIllIIIIIIIIl(lllllllllllllllIIIllIlIIIlllIlll.getBlockState(lllllllllllllllIIIllIlIIIlllIIIl).getBlock(), lllllllllllllllIIIllIlIIIllllIII)) {
      return llIIIlllIlII[0];
    }
    long lllllllllllllllIIIllIlIIIllIllll = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if ((0x7B ^ 0x7E) == 0) {
      return (0xFA ^ 0x9A) & (0x72 ^ 0x12 ^ 0xFFFFFFFF);
    }
    while (!lIIlIlllllllll(lllllllllllllllIIIllIlIIIllIllll.hasNext()))
    {
      Object lllllllllllllllIIIllIlIIIlllIlIl = lllllllllllllllIIIllIlIIIllIllll.next();
      EnumFacing lllllllllllllllIIIllIlIIIlllIlII = (EnumFacing)lllllllllllllllIIIllIlIIIlllIlIl;
      if (lIIlIllllllllI(lllllllllllllllIIIllIlIIIlllIIlI.getBlockState(lllllllllllllllIIIllIlIIIlllIIIl.offset(lllllllllllllllIIIllIlIIIlllIlII)).getBlock(), lllllllllllllllIIIllIlIIIllllIII)) {
        return llIIIlllIlII[3];
      }
    }
    return llIIIlllIlII[0];
  }
  
  public void breakBlock(World lllllllllllllllIIIllIlIIIlIlIIII, BlockPos lllllllllllllllIIIllIlIIIlIlIlII, IBlockState lllllllllllllllIIIllIlIIIlIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    TileEntity lllllllllllllllIIIllIlIIIlIlIIlI = lllllllllllllllIIIllIlIIIlIlIIII.getTileEntity(lllllllllllllllIIIllIlIIIlIlIlII);
    if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIIlIlIIlI instanceof IInventory))
    {
      InventoryHelper.dropInventoryItems(lllllllllllllllIIIllIlIIIlIlIIII, lllllllllllllllIIIllIlIIIlIlIlII, (IInventory)lllllllllllllllIIIllIlIIIlIlIIlI);
      lllllllllllllllIIIllIlIIIlIlIIII.updateComparatorOutputLevel(lllllllllllllllIIIllIlIIIlIlIlII, lllllllllllllllIIIllIlIIIlIlIllI);
    }
    lllllllllllllllIIIllIlIIIlIlIllI.breakBlock(lllllllllllllllIIIllIlIIIlIlIIII, lllllllllllllllIIIllIlIIIlIlIlII, lllllllllllllllIIIllIlIIIlIlIIll);
  }
  
  public void onBlockPlacedBy(World lllllllllllllllIIIllIlIlIIIlIlll, BlockPos lllllllllllllllIIIllIlIlIIIIIllI, IBlockState lllllllllllllllIIIllIlIlIIIIIlIl, EntityLivingBase lllllllllllllllIIIllIlIlIIIIIlII, ItemStack lllllllllllllllIIIllIlIlIIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing lllllllllllllllIIIllIlIlIIIlIIlI = EnumFacing.getHorizontal(MathHelper.floor_double(rotationYaw * 4.0F / 360.0F + 0.5D) & llIIIlllIlII[2]).getOpposite();
    int lllllllllllllllIIIllIlIlIIIIIlIl = lllllllllllllllIIIllIlIlIIIIIlIl.withProperty(FACING, lllllllllllllllIIIllIlIlIIIlIIlI);
    BlockPos lllllllllllllllIIIllIlIlIIIlIIIl = lllllllllllllllIIIllIlIlIIIIIllI.north();
    BlockPos lllllllllllllllIIIllIlIlIIIlIIII = lllllllllllllllIIIllIlIlIIIIIllI.south();
    BlockPos lllllllllllllllIIIllIlIlIIIIllll = lllllllllllllllIIIllIlIlIIIIIllI.west();
    BlockPos lllllllllllllllIIIllIlIlIIIIlllI = lllllllllllllllIIIllIlIlIIIIIllI.east();
    if (lIIlIllllllllI(lllllllllllllllIIIllIlIlIIIIlIII, lllllllllllllllIIIllIlIlIIIlIlll.getBlockState(lllllllllllllllIIIllIlIlIIIlIIIl).getBlock()))
    {
      "".length();
      if ((0x3B ^ 0x3F) > "   ".length()) {
        break label119;
      }
    }
    label119:
    boolean lllllllllllllllIIIllIlIlIIIIllIl = llIIIlllIlII[0];
    if (lIIlIllllllllI(lllllllllllllllIIIllIlIlIIIIlIII, lllllllllllllllIIIllIlIlIIIlIlll.getBlockState(lllllllllllllllIIIllIlIlIIIlIIII).getBlock()))
    {
      "".length();
      if (" ".length() < (0x47 ^ 0x30 ^ 0x6C ^ 0x1F)) {
        break label175;
      }
    }
    label175:
    boolean lllllllllllllllIIIllIlIlIIIIllII = llIIIlllIlII[0];
    if (lIIlIllllllllI(lllllllllllllllIIIllIlIlIIIIlIII, lllllllllllllllIIIllIlIlIIIlIlll.getBlockState(lllllllllllllllIIIllIlIlIIIIllll).getBlock()))
    {
      "".length();
      if (-(0x20 ^ 0xD ^ 0x5C ^ 0x75) < 0) {
        break label227;
      }
    }
    label227:
    boolean lllllllllllllllIIIllIlIlIIIIlIll = llIIIlllIlII[0];
    if (lIIlIllllllllI(lllllllllllllllIIIllIlIlIIIIlIII, lllllllllllllllIIIllIlIlIIIlIlll.getBlockState(lllllllllllllllIIIllIlIlIIIIlllI).getBlock()))
    {
      "".length();
      if ("  ".length() == "  ".length()) {
        break label277;
      }
    }
    label277:
    boolean lllllllllllllllIIIllIlIlIIIIlIlI = llIIIlllIlII[0];
    if ((lIIlIlllllllll(lllllllllllllllIIIllIlIlIIIIllIl)) && (lIIlIlllllllll(lllllllllllllllIIIllIlIlIIIIllII)) && (lIIlIlllllllll(lllllllllllllllIIIllIlIlIIIIlIll)) && (lIIlIlllllllll(lllllllllllllllIIIllIlIlIIIIlIlI)))
    {
      "".length();
      "".length();
      if (null == null) {}
    }
    else if ((!lIIlIllllllllI(lllllllllllllllIIIllIlIlIIIlIIlI.getAxis(), EnumFacing.Axis.X)) || ((lIIlIlllllllll(lllllllllllllllIIIllIlIlIIIIllIl)) && (lIIlIlllllllll(lllllllllllllllIIIllIlIlIIIIllII))))
    {
      if ((lIIlIllllllllI(lllllllllllllllIIIllIlIlIIIlIIlI.getAxis(), EnumFacing.Axis.Z)) && ((!lIIlIlllllllll(lllllllllllllllIIIllIlIlIIIIlIll)) || (lIIllIIIIIIIII(lllllllllllllllIIIllIlIlIIIIlIlI))))
      {
        if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIlIIIIlIll))
        {
          "".length();
          "".length();
          if (null == null) {}
        }
        else
        {
          "".length();
        }
        "".length();
        "".length();
        if (null == null) {}
      }
    }
    else
    {
      if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIlIIIIllIl))
      {
        "".length();
        "".length();
        if ("   ".length() != 0) {}
      }
      else
      {
        "".length();
      }
      "".length();
    }
    if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIlIIIlIIll.hasDisplayName()))
    {
      TileEntity lllllllllllllllIIIllIlIlIIIIlIIl = lllllllllllllllIIIllIlIlIIIlIlll.getTileEntity(lllllllllllllllIIIllIlIlIIIIIllI);
      if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIlIIIIlIIl instanceof TileEntityChest)) {
        ((TileEntityChest)lllllllllllllllIIIllIlIlIIIIlIIl).setCustomName(lllllllllllllllIIIllIlIlIIIlIIll.getDisplayName());
      }
    }
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIIIllIIlllIlllllI)
  {
    ;
    return ((EnumFacing)lllllllllllllllIIIllIIlllIlllllI.getValue(FACING)).getIndex();
  }
  
  public boolean onBlockActivated(World lllllllllllllllIIIllIlIIIlIIIllI, BlockPos lllllllllllllllIIIllIlIIIIlllIll, IBlockState lllllllllllllllIIIllIlIIIlIIIlII, EntityPlayer lllllllllllllllIIIllIlIIIIlllIlI, EnumFacing lllllllllllllllIIIllIlIIIlIIIIlI, float lllllllllllllllIIIllIlIIIlIIIIIl, float lllllllllllllllIIIllIlIIIlIIIIII, float lllllllllllllllIIIllIlIIIIllllll)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIllIIIIIIIII(isRemote)) {
      return llIIIlllIlII[3];
    }
    ILockableContainer lllllllllllllllIIIllIlIIIIlllllI = lllllllllllllllIIIllIlIIIlIIIlll.getLockableContainer(lllllllllllllllIIIllIlIIIlIIIllI, lllllllllllllllIIIllIlIIIIlllIll);
    if (lIIllIIIIIIIlI(lllllllllllllllIIIllIlIIIIlllllI))
    {
      lllllllllllllllIIIllIlIIIIlllIlI.displayGUIChest(lllllllllllllllIIIllIlIIIIlllllI);
      if (lIIlIlllllllll(chestType))
      {
        lllllllllllllllIIIllIlIIIIlllIlI.triggerAchievement(StatList.field_181723_aa);
        "".length();
        if (-" ".length() >= "  ".length()) {
          return (0xA7 ^ 0xB4 ^ 0x7A ^ 0x7E) & (0x53 ^ 0x56 ^ 0x95 ^ 0x87 ^ -" ".length());
        }
      }
      else if (lIIllIIIIIIlII(chestType, llIIIlllIlII[3]))
      {
        lllllllllllllllIIIllIlIIIIlllIlI.triggerAchievement(StatList.field_181737_U);
      }
    }
    return llIIIlllIlII[3];
  }
  
  public boolean canProvidePower()
  {
    ;
    if (lIIllIIIIIIlII(chestType, llIIIlllIlII[3])) {
      return llIIIlllIlII[3];
    }
    return llIIIlllIlII[0];
  }
  
  private boolean isBelowSolidBlock(World lllllllllllllllIIIllIIlllllIIllI, BlockPos lllllllllllllllIIIllIIlllllIIlIl)
  {
    ;
    ;
    return lllllllllllllllIIIllIIlllllIIllI.getBlockState(lllllllllllllllIIIllIIlllllIIlIl.up()).getBlock().isNormalCube();
  }
  
  private static boolean lIIllIIIIIIIII(int ???)
  {
    double lllllllllllllllIIIllIIlllIIllIIl;
    return ??? != 0;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIIIllIIlllIlllIll, new IProperty[] { FACING });
  }
  
  public IBlockState checkForSurroundingChests(World lllllllllllllllIIIllIlIIllIIIlIl, BlockPos lllllllllllllllIIIllIlIIllIIIlII, IBlockState lllllllllllllllIIIllIlIIllIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIllIIIIIIIII(isRemote)) {
      return lllllllllllllllIIIllIlIIllIIIIll;
    }
    IBlockState lllllllllllllllIIIllIlIIllIlllll = lllllllllllllllIIIllIlIIllIIIlIl.getBlockState(lllllllllllllllIIIllIlIIllIIIlII.north());
    IBlockState lllllllllllllllIIIllIlIIllIllllI = lllllllllllllllIIIllIlIIllIIIlIl.getBlockState(lllllllllllllllIIIllIlIIllIIIlII.south());
    IBlockState lllllllllllllllIIIllIlIIllIlllIl = lllllllllllllllIIIllIlIIllIIIlIl.getBlockState(lllllllllllllllIIIllIlIIllIIIlII.west());
    IBlockState lllllllllllllllIIIllIlIIllIlllII = lllllllllllllllIIIllIlIIllIIIlIl.getBlockState(lllllllllllllllIIIllIlIIllIIIlII.east());
    EnumFacing lllllllllllllllIIIllIlIIllIllIll = (EnumFacing)lllllllllllllllIIIllIlIIllIIIIll.getValue(FACING);
    Block lllllllllllllllIIIllIlIIllIllIlI = lllllllllllllllIIIllIlIIllIlllll.getBlock();
    Block lllllllllllllllIIIllIlIIllIllIIl = lllllllllllllllIIIllIlIIllIllllI.getBlock();
    Block lllllllllllllllIIIllIlIIllIllIII = lllllllllllllllIIIllIlIIllIlllIl.getBlock();
    Block lllllllllllllllIIIllIlIIllIlIlll = lllllllllllllllIIIllIlIIllIlllII.getBlock();
    if ((lIIllIIIIIIIIl(lllllllllllllllIIIllIlIIllIllIlI, lllllllllllllllIIIllIlIIllIIIllI)) && (lIIllIIIIIIIIl(lllllllllllllllIIIllIlIIllIllIIl, lllllllllllllllIIIllIlIIllIIIllI)))
    {
      boolean lllllllllllllllIIIllIlIIllIlIllI = lllllllllllllllIIIllIlIIllIllIlI.isFullBlock();
      boolean lllllllllllllllIIIllIlIIllIlIlIl = lllllllllllllllIIIllIlIIllIllIIl.isFullBlock();
      if ((!lIIllIIIIIIIIl(lllllllllllllllIIIllIlIIllIllIII, lllllllllllllllIIIllIlIIllIIIllI)) || (lIIlIllllllllI(lllllllllllllllIIIllIlIIllIlIlll, lllllllllllllllIIIllIlIIllIIIllI)))
      {
        if (lIIlIllllllllI(lllllllllllllllIIIllIlIIllIllIII, lllllllllllllllIIIllIlIIllIIIllI))
        {
          "".length();
          if (((0xD8 ^ 0x89 ^ 0x7E ^ 0x28) & (0x43 ^ 0x30 ^ 0x7D ^ 0x9 ^ -" ".length())) >= ((0x49 ^ 0x4D ^ 0x1B ^ 0x10) & (126 + '' - 272 + 178 ^ 119 + '' - 174 + 100 ^ -" ".length()))) {
            break label259;
          }
          return null;
        }
        label259:
        BlockPos lllllllllllllllIIIllIlIIllIlIlII = lllllllllllllllIIIllIlIIllIIIlII.east();
        IBlockState lllllllllllllllIIIllIlIIllIlIIll = lllllllllllllllIIIllIlIIllIIIlIl.getBlockState(lllllllllllllllIIIllIlIIllIlIlII.north());
        IBlockState lllllllllllllllIIIllIlIIllIlIIlI = lllllllllllllllIIIllIlIIllIIIlIl.getBlockState(lllllllllllllllIIIllIlIIllIlIlII.south());
        lllllllllllllllIIIllIlIIllIllIll = EnumFacing.SOUTH;
        EnumFacing lllllllllllllllIIIllIlIIllIlIIII;
        if (lIIlIllllllllI(lllllllllllllllIIIllIlIIllIllIII, lllllllllllllllIIIllIlIIllIIIllI))
        {
          EnumFacing lllllllllllllllIIIllIlIIllIlIIIl = (EnumFacing)lllllllllllllllIIIllIlIIllIlllIl.getValue(FACING);
          "".length();
          if ("   ".length() != "   ".length()) {
            return null;
          }
        }
        else
        {
          lllllllllllllllIIIllIlIIllIlIIII = (EnumFacing)lllllllllllllllIIIllIlIIllIlllII.getValue(FACING);
        }
        if (lIIlIllllllllI(lllllllllllllllIIIllIlIIllIlIIII, EnumFacing.NORTH)) {
          lllllllllllllllIIIllIlIIllIllIll = EnumFacing.NORTH;
        }
        Block lllllllllllllllIIIllIlIIllIIllll = lllllllllllllllIIIllIlIIllIlIIll.getBlock();
        Block lllllllllllllllIIIllIlIIllIIlllI = lllllllllllllllIIIllIlIIllIlIIlI.getBlock();
        if (((!lIIlIlllllllll(lllllllllllllllIIIllIlIIllIlIllI)) || (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIllIIllll.isFullBlock()))) && (lIIlIlllllllll(lllllllllllllllIIIllIlIIllIlIlIl)) && (lIIlIlllllllll(lllllllllllllllIIIllIlIIllIIlllI.isFullBlock()))) {
          lllllllllllllllIIIllIlIIllIllIll = EnumFacing.SOUTH;
        }
        if (((!lIIlIlllllllll(lllllllllllllllIIIllIlIIllIlIlIl)) || (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIllIIlllI.isFullBlock()))) && (lIIlIlllllllll(lllllllllllllllIIIllIlIIllIlIllI)) && (lIIlIlllllllll(lllllllllllllllIIIllIlIIllIIllll.isFullBlock())))
        {
          lllllllllllllllIIIllIlIIllIllIll = EnumFacing.NORTH;
          "".length();
          if (-" ".length() > ((0x9B ^ 0x86 ^ 0x39 ^ 0x61) & (0xD5 ^ 0xBA ^ 0xB6 ^ 0x9C ^ -" ".length()))) {
            return null;
          }
        }
      }
    }
    else
    {
      if (lIIlIllllllllI(lllllllllllllllIIIllIlIIllIllIlI, lllllllllllllllIIIllIlIIllIIIllI))
      {
        "".length();
        if (null == null) {
          break label550;
        }
        return null;
      }
      label550:
      BlockPos lllllllllllllllIIIllIlIIllIIllIl = lllllllllllllllIIIllIlIIllIIIlII.south();
      IBlockState lllllllllllllllIIIllIlIIllIIllII = lllllllllllllllIIIllIlIIllIIIlIl.getBlockState(lllllllllllllllIIIllIlIIllIIllIl.west());
      IBlockState lllllllllllllllIIIllIlIIllIIlIll = lllllllllllllllIIIllIlIIllIIIlIl.getBlockState(lllllllllllllllIIIllIlIIllIIllIl.east());
      lllllllllllllllIIIllIlIIllIllIll = EnumFacing.EAST;
      EnumFacing lllllllllllllllIIIllIlIIllIIlIIl;
      if (lIIlIllllllllI(lllllllllllllllIIIllIlIIllIllIlI, lllllllllllllllIIIllIlIIllIIIllI))
      {
        EnumFacing lllllllllllllllIIIllIlIIllIIlIlI = (EnumFacing)lllllllllllllllIIIllIlIIllIlllll.getValue(FACING);
        "".length();
        if (((0x4C ^ 0x2D) & (0xC4 ^ 0xA5 ^ 0xFFFFFFFF)) < ((0x6B ^ 0x7F) & (0x2C ^ 0x38 ^ 0xFFFFFFFF))) {
          return null;
        }
      }
      else
      {
        lllllllllllllllIIIllIlIIllIIlIIl = (EnumFacing)lllllllllllllllIIIllIlIIllIllllI.getValue(FACING);
      }
      if (lIIlIllllllllI(lllllllllllllllIIIllIlIIllIIlIIl, EnumFacing.WEST)) {
        lllllllllllllllIIIllIlIIllIllIll = EnumFacing.WEST;
      }
      Block lllllllllllllllIIIllIlIIllIIlIII = lllllllllllllllIIIllIlIIllIIllII.getBlock();
      Block lllllllllllllllIIIllIlIIllIIIlll = lllllllllllllllIIIllIlIIllIIlIll.getBlock();
      if (((!lIIlIlllllllll(lllllllllllllllIIIllIlIIllIllIII.isFullBlock())) || (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIllIIlIII.isFullBlock()))) && (lIIlIlllllllll(lllllllllllllllIIIllIlIIllIlIlll.isFullBlock())) && (lIIlIlllllllll(lllllllllllllllIIIllIlIIllIIIlll.isFullBlock()))) {
        lllllllllllllllIIIllIlIIllIllIll = EnumFacing.EAST;
      }
      if (((!lIIlIlllllllll(lllllllllllllllIIIllIlIIllIlIlll.isFullBlock())) || (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIllIIIlll.isFullBlock()))) && (lIIlIlllllllll(lllllllllllllllIIIllIlIIllIllIII.isFullBlock())) && (lIIlIlllllllll(lllllllllllllllIIIllIlIIllIIlIII.isFullBlock()))) {
        lllllllllllllllIIIllIlIIllIllIll = EnumFacing.WEST;
      }
    }
    byte lllllllllllllllIIIllIlIIllIIIIll = lllllllllllllllIIIllIlIIllIIIIll.withProperty(FACING, lllllllllllllllIIIllIlIIllIllIll);
    "".length();
    return lllllllllllllllIIIllIlIIllIIIIll;
  }
  
  public boolean hasComparatorInputOverride()
  {
    return llIIIlllIlII[3];
  }
  
  private static boolean lIIllIIIIIIIlI(Object ???)
  {
    short lllllllllllllllIIIllIIlllIIllIll;
    return ??? != null;
  }
  
  public int getWeakPower(IBlockAccess lllllllllllllllIIIllIlIIIIIIllII, BlockPos lllllllllllllllIIIllIlIIIIIIlIll, IBlockState lllllllllllllllIIIllIlIIIIIIlIlI, EnumFacing lllllllllllllllIIIllIlIIIIIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIlIlllllllll(lllllllllllllllIIIllIlIIIIIIIllI.canProvidePower())) {
      return llIIIlllIlII[0];
    }
    int lllllllllllllllIIIllIlIIIIIIlIII = llIIIlllIlII[0];
    TileEntity lllllllllllllllIIIllIlIIIIIIIlll = lllllllllllllllIIIllIlIIIIIIllII.getTileEntity(lllllllllllllllIIIllIlIIIIIIIlII);
    if (lIIllIIIIIIIII(lllllllllllllllIIIllIlIIIIIIIlll instanceof TileEntityChest)) {
      lllllllllllllllIIIllIlIIIIIIlIII = numPlayersUsing;
    }
    return MathHelper.clamp_int(lllllllllllllllIIIllIlIIIIIIlIII, llIIIlllIlII[0], llIIIlllIlII[4]);
  }
}

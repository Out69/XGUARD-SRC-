package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.world.World;

public class BlockHugeMushroom
  extends Block
{
  public int getMetaFromState(IBlockState llllllllllllllIlllllIllllllIllll)
  {
    ;
    return ((EnumType)llllllllllllllIlllllIllllllIllll.getValue(VARIANT)).getMetadata();
  }
  
  public IBlockState onBlockPlaced(World llllllllllllllIllllllIIIIIIIIIIl, BlockPos llllllllllllllIllllllIIIIIIIIIII, EnumFacing llllllllllllllIlllllIlllllllllll, float llllllllllllllIlllllIllllllllllI, float llllllllllllllIlllllIlllllllllIl, float llllllllllllllIlllllIlllllllllII, int llllllllllllllIlllllIllllllllIll, EntityLivingBase llllllllllllllIlllllIllllllllIlI)
  {
    ;
    return llllllllllllllIlllllIllllllllIIl.getDefaultState();
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIlllllIlllllllIlIl)
  {
    ;
    ;
    return llllllllllllllIlllllIlllllllIllI.getDefaultState().withProperty(VARIANT, EnumType.byMetadata(llllllllllllllIlllllIlllllllIlIl));
  }
  
  public BlockHugeMushroom(Material llllllllllllllIllllllIIIIIIllIll, MapColor llllllllllllllIllllllIIIIIIllIlI, Block llllllllllllllIllllllIIIIIIlllIl)
  {
    llllllllllllllIllllllIIIIIIlllII.<init>(llllllllllllllIllllllIIIIIIllIll, llllllllllllllIllllllIIIIIIllIlI);
    llllllllllllllIllllllIIIIIIlllII.setDefaultState(blockState.getBaseState().withProperty(VARIANT, EnumType.ALL_OUTSIDE));
    smallBlock = llllllllllllllIllllllIIIIIIlllIl;
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIllllllIIIIIIIllII, Random llllllllllllllIllllllIIIIIIIlIll, int llllllllllllllIllllllIIIIIIIlIlI)
  {
    ;
    return Item.getItemFromBlock(smallBlock);
  }
  
  static
  {
    lIlIIllIlIlIIl();
    lIlIIllIlIIlII();
  }
  
  private static boolean lIlIIllIlIlIlI(Object ???)
  {
    short llllllllllllllIlllllIlllllIllIll;
    return ??? != null;
  }
  
  private static String lIlIIllIlIIIll(String llllllllllllllIlllllIllllllIIIlI, String llllllllllllllIlllllIlllllIlllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlllllIllllllIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllllIlllllIlllll.getBytes(StandardCharsets.UTF_8)), llIllIIlllIl[11]), "DES");
      Cipher llllllllllllllIlllllIllllllIIlII = Cipher.getInstance("DES");
      llllllllllllllIlllllIllllllIIlII.init(llIllIIlllIl[9], llllllllllllllIlllllIllllllIIlIl);
      return new String(llllllllllllllIlllllIllllllIIlII.doFinal(Base64.getDecoder().decode(llllllllllllllIlllllIllllllIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlllllIllllllIIIll)
    {
      llllllllllllllIlllllIllllllIIIll.printStackTrace();
    }
    return null;
  }
  
  public int quantityDropped(Random llllllllllllllIllllllIIIIIIlIllI)
  {
    ;
    return Math.max(llIllIIlllIl[0], llllllllllllllIllllllIIIIIIlIlIl.nextInt(llIllIIlllIl[1]) - llIllIIlllIl[2]);
  }
  
  public Item getItem(World llllllllllllllIllllllIIIIIIIIllI, BlockPos llllllllllllllIllllllIIIIIIIIlIl)
  {
    ;
    return Item.getItemFromBlock(smallBlock);
  }
  
  private static void lIlIIllIlIlIIl()
  {
    llIllIIlllIl = new int[14];
    llIllIIlllIl[0] = ((0x8F ^ 0x87) & (0x71 ^ 0x79 ^ 0xFFFFFFFF));
    llIllIIlllIl[1] = (0xBA ^ 0x81 ^ 0x6D ^ 0x5C);
    llIllIIlllIl[2] = (41 + 31 - -105 + 21 ^ 6 + 10 - -59 + 118);
    llIllIIlllIl[3] = " ".length();
    llIllIIlllIl[4] = (0xCE ^ 0xC5);
    llIllIIlllIl[5] = (0x8B ^ 0x87);
    llIllIIlllIl[6] = (0xE8 ^ 0xBC ^ 0x6B ^ 0x32);
    llIllIIlllIl[7] = (0x67 ^ 0x62);
    llIllIIlllIl[8] = (119 + 60 - 93 + 62 ^ '' + 76 - 94 + 35);
    llIllIIlllIl[9] = "  ".length();
    llIllIIlllIl[10] = "   ".length();
    llIllIIlllIl[11] = (0xF8 ^ 0xA6 ^ 0xD0 ^ 0x86);
    llIllIIlllIl[12] = (0xBA ^ 0xAE ^ 0x63 ^ 0x7E);
    llIllIIlllIl[13] = (0x6 ^ 0x3D ^ 0x96 ^ 0xA9);
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllIllllllIIIIIIlIIIl)
  {
    ;
    ;
    switch ($SWITCH_TABLE$net$minecraft$block$BlockHugeMushroom$EnumType()[((EnumType)llllllllllllllIllllllIIIIIIlIIIl.getValue(VARIANT)).ordinal()])
    {
    case 13: 
      return MapColor.clothColor;
    case 11: 
      return MapColor.sandColor;
    case 10: 
      return MapColor.sandColor;
    }
    return llllllllllllllIllllllIIIIIIlIIII.getMapColor(llllllllllllllIllllllIIIIIIlIIIl);
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIlllllIllllllIllIl, new IProperty[] { VARIANT });
  }
  
  private static void lIlIIllIlIIlII()
  {
    llIllIIllIll = new String[llIllIIlllIl[3]];
    llIllIIllIll[llIllIIlllIl[0]] = lIlIIllIlIIIll("T5+dU953az0=", "Ovoqk");
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    static
    {
      lIllIlIllIIlIl();
      lIllIlIllIIIll();
      int llllllllllllllIllIlllIIIllIlIlll;
      char llllllllllllllIllIlllIIIllIllIlI;
      NORTH_WEST = new EnumType(lllIllIllIII[lllIllIllIIl[0]], lllIllIllIIl[0], lllIllIllIIl[1], lllIllIllIII[lllIllIllIIl[1]]);
      NORTH = new EnumType(lllIllIllIII[lllIllIllIIl[2]], lllIllIllIIl[1], lllIllIllIIl[2], lllIllIllIII[lllIllIllIIl[3]]);
      NORTH_EAST = new EnumType(lllIllIllIII[lllIllIllIIl[4]], lllIllIllIIl[2], lllIllIllIIl[3], lllIllIllIII[lllIllIllIIl[5]]);
      WEST = new EnumType(lllIllIllIII[lllIllIllIIl[6]], lllIllIllIIl[3], lllIllIllIIl[4], lllIllIllIII[lllIllIllIIl[7]]);
      CENTER = new EnumType(lllIllIllIII[lllIllIllIIl[8]], lllIllIllIIl[4], lllIllIllIIl[5], lllIllIllIII[lllIllIllIIl[9]]);
      EAST = new EnumType(lllIllIllIII[lllIllIllIIl[10]], lllIllIllIIl[5], lllIllIllIIl[6], lllIllIllIII[lllIllIllIIl[11]]);
      SOUTH_WEST = new EnumType(lllIllIllIII[lllIllIllIIl[12]], lllIllIllIIl[6], lllIllIllIIl[7], lllIllIllIII[lllIllIllIIl[13]]);
      SOUTH = new EnumType(lllIllIllIII[lllIllIllIIl[14]], lllIllIllIIl[7], lllIllIllIIl[8], lllIllIllIII[lllIllIllIIl[15]]);
      SOUTH_EAST = new EnumType(lllIllIllIII[lllIllIllIIl[16]], lllIllIllIIl[8], lllIllIllIIl[9], lllIllIllIII[lllIllIllIIl[17]]);
      STEM = new EnumType(lllIllIllIII[lllIllIllIIl[18]], lllIllIllIIl[9], lllIllIllIIl[10], lllIllIllIII[lllIllIllIIl[19]]);
      ALL_INSIDE = new EnumType(lllIllIllIII[lllIllIllIIl[20]], lllIllIllIIl[10], lllIllIllIIl[0], lllIllIllIII[lllIllIllIIl[21]]);
      ALL_OUTSIDE = new EnumType(lllIllIllIII[lllIllIllIIl[22]], lllIllIllIIl[11], lllIllIllIIl[14], lllIllIllIII[lllIllIllIIl[23]]);
      ALL_STEM = new EnumType(lllIllIllIII[lllIllIllIIl[24]], lllIllIllIIl[12], lllIllIllIIl[15], lllIllIllIII[lllIllIllIIl[25]]);
      ENUM$VALUES = new EnumType[] { NORTH_WEST, NORTH, NORTH_EAST, WEST, CENTER, EAST, SOUTH_WEST, SOUTH, SOUTH_EAST, STEM, ALL_INSIDE, ALL_OUTSIDE, ALL_STEM };
      META_LOOKUP = new EnumType[lllIllIllIIl[16]];
      long llllllllllllllIllIlllIIIllIllIII = (llllllllllllllIllIlllIIIllIlIlll = values()).length;
      boolean llllllllllllllIllIlllIIIllIllIIl = lllIllIllIIl[0];
      "".length();
      if (-" ".length() > "   ".length()) {
        return;
      }
      while (!lIllIlIllIIllI(llllllllllllllIllIlllIIIllIllIIl, llllllllllllllIllIlllIIIllIllIII))
      {
        EnumType llllllllllllllIllIlllIIIllIllIll = llllllllllllllIllIlllIIIllIlIlll[llllllllllllllIllIlllIIIllIllIIl];
        META_LOOKUP[llllllllllllllIllIlllIIIllIllIll.getMetadata()] = llllllllllllllIllIlllIIIllIllIll;
        llllllllllllllIllIlllIIIllIllIIl++;
      }
    }
    
    private static boolean lIllIlIllIlIIl(int ???, int arg1)
    {
      int i;
      int llllllllllllllIllIlllIIIIllllIIl;
      return ??? < i;
    }
    
    public static EnumType byMetadata(int llllllllllllllIllIlllIIIllIIIIIl)
    {
      ;
      ;
      if ((!lIllIlIllIIlll(llllllllllllllIllIlllIIIllIIIIIl)) || (lIllIlIllIIllI(llllllllllllllIllIlllIIIlIllllll, META_LOOKUP.length))) {
        llllllllllllllIllIlllIIIlIllllll = lllIllIllIIl[0];
      }
      EnumType llllllllllllllIllIlllIIIllIIIIII = META_LOOKUP[llllllllllllllIllIlllIIIlIllllll];
      if (lIllIlIllIlIII(llllllllllllllIllIlllIIIllIIIIII))
      {
        "".length();
        if ("   ".length() == "   ".length()) {
          break label68;
        }
        return null;
      }
      label68:
      return llllllllllllllIllIlllIIIllIIIIII;
    }
    
    private static void lIllIlIllIIlIl()
    {
      lllIllIllIIl = new int[27];
      lllIllIllIIl[0] = ((18 + '' - 6 + 9 ^ 20 + 111 - -29 + 7) & (13 + 100 - -37 + 3 ^ 110 + 4 - 55 + 99 ^ -" ".length()));
      lllIllIllIIl[1] = " ".length();
      lllIllIllIIl[2] = "  ".length();
      lllIllIllIIl[3] = "   ".length();
      lllIllIllIIl[4] = (0x98 ^ 0x9C);
      lllIllIllIIl[5] = (0x86 ^ 0x83);
      lllIllIllIIl[6] = (0x9B ^ 0xA5 ^ 0x88 ^ 0xB0);
      lllIllIllIIl[7] = (0xCD ^ 0xC0 ^ 0xB ^ 0x1);
      lllIllIllIIl[8] = (0x84 ^ 0x8C);
      lllIllIllIIl[9] = (0xA1 ^ 0xA8);
      lllIllIllIIl[10] = (0x94 ^ 0xAA ^ 0x66 ^ 0x52);
      lllIllIllIIl[11] = (0x2B ^ 0x20);
      lllIllIllIIl[12] = (0x6D ^ 0x61);
      lllIllIllIIl[13] = (0x71 ^ 0x51 ^ 0x3D ^ 0x10);
      lllIllIllIIl[14] = (0x86 ^ 0xBC ^ 0x52 ^ 0x66);
      lllIllIllIIl[15] = (0x15 ^ 0x30 ^ 0x20 ^ 0xA);
      lllIllIllIIl[16] = (0x78 ^ 0x4A ^ 0x35 ^ 0x17);
      lllIllIllIIl[17] = (0x88 ^ 0x99);
      lllIllIllIIl[18] = (0x7E ^ 0x6C);
      lllIllIllIIl[19] = (0x5E ^ 0x4D);
      lllIllIllIIl[20] = (0x7F ^ 0x6B);
      lllIllIllIIl[21] = (0xC1 ^ 0xB7 ^ 0x38 ^ 0x5B);
      lllIllIllIIl[22] = (0x1A ^ 0xC);
      lllIllIllIIl[23] = (0xF3 ^ 0x89 ^ 0x6E ^ 0x3);
      lllIllIllIIl[24] = (0xB0 ^ 0xA8);
      lllIllIllIIl[25] = (0x46 ^ 0x62 ^ 0x2C ^ 0x11);
      lllIllIllIIl[26] = (96 + 110 - 83 + 4 ^ 0x51 ^ 0x34);
    }
    
    private static String lIllIlIlIllIII(String llllllllllllllIllIlllIIIlIlIIIll, String llllllllllllllIllIlllIIIlIlIIlll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIllIlllIIIlIlIIIll = new String(Base64.getDecoder().decode(llllllllllllllIllIlllIIIlIlIIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIllIlllIIIlIlIIllI = new StringBuilder();
      char[] llllllllllllllIllIlllIIIlIlIIlIl = llllllllllllllIllIlllIIIlIlIIlll.toCharArray();
      int llllllllllllllIllIlllIIIlIlIIlII = lllIllIllIIl[0];
      int llllllllllllllIllIlllIIIlIIllllI = llllllllllllllIllIlllIIIlIlIIIll.toCharArray();
      int llllllllllllllIllIlllIIIlIIlllIl = llllllllllllllIllIlllIIIlIIllllI.length;
      boolean llllllllllllllIllIlllIIIlIIlllII = lllIllIllIIl[0];
      while (lIllIlIllIlIIl(llllllllllllllIllIlllIIIlIIlllII, llllllllllllllIllIlllIIIlIIlllIl))
      {
        char llllllllllllllIllIlllIIIlIlIlIIl = llllllllllllllIllIlllIIIlIIllllI[llllllllllllllIllIlllIIIlIIlllII];
        "".length();
        "".length();
        if ("  ".length() <= ((55 + 79 - 58 + 65 ^ '' + '' - 199 + 81) & (34 + 24 - 55 + 150 ^ 83 + 15 - 6 + 45 ^ -" ".length()))) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIllIlllIIIlIlIIllI);
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    private static void lIllIlIllIIIll()
    {
      lllIllIllIII = new String[lllIllIllIIl[26]];
      lllIllIllIII[lllIllIllIIl[0]] = lIllIlIlIllIII("PyYhMC0uPjY3MQ==", "qisde");
      lllIllIllIII[lllIllIllIIl[1]] = lIllIlIlIllIIl("+8kX2uhJ/gE7e8VJTTqVAg==", "KrcaH");
      lllIllIllIII[lllIllIllIIl[2]] = lIllIlIlIllIlI("j3070ErDKnU=", "ggOjO");
      lllIllIllIII[lllIllIllIIl[3]] = lIllIlIlIllIlI("JyoxgRfGcs0=", "uwJzq");
      lllIllIllIII[lllIllIllIIl[4]] = lIllIlIlIllIlI("67bpDSjuY4L0gKRcZ5qw0Q==", "cvHPP");
      lllIllIllIII[lllIllIllIIl[5]] = lIllIlIlIllIII("NiYGPhsHLBU5Bw==", "XItJs");
      lllIllIllIII[lllIllIllIIl[6]] = lIllIlIlIllIIl("UlHjv4a64ko=", "ANBea");
      lllIllIllIII[lllIllIllIIl[7]] = lIllIlIlIllIIl("zUpSKiml6e8=", "lXZwa");
      lllIllIllIII[lllIllIllIIl[8]] = lIllIlIlIllIIl("hsNmZxJhVHM=", "pgaOZ");
      lllIllIllIII[lllIllIllIIl[9]] = lIllIlIlIllIlI("gvNCCS0FuBs=", "OxmQT");
      lllIllIllIII[lllIllIllIIl[10]] = lIllIlIlIllIII("CQ8GPA==", "LNUhb");
      lllIllIllIII[lllIllIllIIl[11]] = lIllIlIlIllIIl("33PhP7NeIFs=", "czdBa");
      lllIllIllIII[lllIllIllIIl[12]] = lIllIlIlIllIlI("TO1YqKnWAUQ74Nl+ObvWlg==", "bQbDK");
      lllIllIllIII[lllIllIllIIl[13]] = lIllIlIlIllIIl("Q+1H7dOm+/6zVZzyAemVkg==", "aPhnc");
      lllIllIllIII[lllIllIllIIl[14]] = lIllIlIlIllIIl("NQyKT7mlb+4=", "tLwLp");
      lllIllIllIII[lllIllIllIIl[15]] = lIllIlIlIllIII("HScBNiQ=", "nHtBL");
      lllIllIllIII[lllIllIllIIl[16]] = lIllIlIlIllIII("Hh8eGAoSFQofFg==", "MPKLB");
      lllIllIllIII[lllIllIllIIl[17]] = lIllIlIlIllIIl("OHjrZ5Dex7nmcFsAx7HJlg==", "QplZm");
      lllIllIllIII[lllIllIllIIl[18]] = lIllIlIlIllIII("BDYoPw==", "WbmrV");
      lllIllIllIII[lllIllIllIIl[19]] = lIllIlIlIllIIl("UInj79/CE9Q=", "wivEu");
      lllIllIllIII[lllIllIllIIl[20]] = lIllIlIlIllIII("Ch4KDxoFAQ8UFg==", "KRFPS");
      lllIllIllIII[lllIllIllIIl[21]] = lIllIlIlIllIII("KBs2Kx0nBDMQEQ==", "IwZtt");
      lllIllIllIII[lllIllIllIIl[22]] = lIllIlIlIllIII("ES8gMhgFNz8kExU=", "PclmW");
      lllIllIllIII[lllIllIllIIl[23]] = lIllIlIlIllIII("NDsACRsgIx8/EDA=", "UWlVt");
      lllIllIllIII[lllIllIllIIl[24]] = lIllIlIlIllIlI("+hvsjDUdOQE9H3M5ONb6Dw==", "wTJgU");
      lllIllIllIII[lllIllIllIIl[25]] = lIllIlIlIllIlI("PIWadJ6CTEbmTrcqLP8Ong==", "MmzwR");
    }
    
    private static String lIllIlIlIllIIl(String llllllllllllllIllIlllIIIlIIIIlII, String llllllllllllllIllIlllIIIlIIIIlIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIllIlllIIIlIIIlIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlllIIIlIIIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIllIlllIIIlIIIlIII = Cipher.getInstance("Blowfish");
        llllllllllllllIllIlllIIIlIIIlIII.init(lllIllIllIIl[2], llllllllllllllIllIlllIIIlIIIlIIl);
        return new String(llllllllllllllIllIlllIIIlIIIlIII.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlllIIIlIIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIllIlllIIIlIIIIlll)
      {
        llllllllllllllIllIlllIIIlIIIIlll.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIllIlIllIlIII(Object ???)
    {
      float llllllllllllllIllIlllIIIIlllIlll;
      return ??? == null;
    }
    
    private EnumType(int llllllllllllllIllIlllIIIllIlIIII, String llllllllllllllIllIlllIIIllIIllll)
    {
      meta = llllllllllllllIllIlllIIIllIIlIll;
      name = llllllllllllllIllIlllIIIllIIllll;
    }
    
    private static String lIllIlIlIllIlI(String llllllllllllllIllIlllIIIlIIlIIll, String llllllllllllllIllIlllIIIlIIlIIII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIllIlllIIIlIIlIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlllIIIlIIlIIII.getBytes(StandardCharsets.UTF_8)), lllIllIllIIl[8]), "DES");
        Cipher llllllllllllllIllIlllIIIlIIlIlIl = Cipher.getInstance("DES");
        llllllllllllllIllIlllIIIlIIlIlIl.init(lllIllIllIIl[2], llllllllllllllIllIlllIIIlIIlIllI);
        return new String(llllllllllllllIllIlllIIIlIIlIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlllIIIlIIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIllIlllIIIlIIlIlII)
      {
        llllllllllllllIllIlllIIIlIIlIlII.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIllIlIllIIllI(int ???, int arg1)
    {
      int i;
      boolean llllllllllllllIllIlllIIIIlllllIl;
      return ??? >= i;
    }
    
    private static boolean lIllIlIllIIlll(int ???)
    {
      long llllllllllllllIllIlllIIIIlllIlIl;
      return ??? >= 0;
    }
  }
}

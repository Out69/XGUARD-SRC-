package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

public class BlockTNT
  extends Block
{
  public boolean canDropFromExplosion(Explosion llllllllllllllIllllIlIlIlllIllll)
  {
    return llIlllIIlIlI[0];
  }
  
  public void onNeighborBlockChange(World llllllllllllllIllllIlIllIlIIllll, BlockPos llllllllllllllIllllIlIllIlIIlllI, IBlockState llllllllllllllIllllIlIllIlIIlIII, Block llllllllllllllIllllIlIllIlIIllII)
  {
    ;
    ;
    ;
    ;
    if (lIlIlIIlIIIIlI(llllllllllllllIllllIlIllIlIIllll.isBlockPowered(llllllllllllllIllllIlIllIlIIlIIl)))
    {
      llllllllllllllIllllIlIllIlIIlIll.onBlockDestroyedByPlayer(llllllllllllllIllllIlIllIlIIllll, llllllllllllllIllllIlIllIlIIlIIl, llllllllllllllIllllIlIllIlIIlIII.withProperty(EXPLODE, Boolean.valueOf(llIlllIIlIlI[1])));
      "".length();
    }
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIllllIlIlIlllIIIlI, new IProperty[] { EXPLODE });
  }
  
  private static boolean lIlIlIIlIIIlll(int ???)
  {
    float llllllllllllllIllllIlIlIlIlllIII;
    return ??? > 0;
  }
  
  private static void lIlIlIIlIIIIII()
  {
    llIlllIIlIIl = new String[llIlllIIlIlI[4]];
    llIlllIIlIIl[llIlllIIlIlI[0]] = lIlIlIIIlllllI("bif2aLaxw5Y=", "TurPD");
    llIlllIIlIIl[llIlllIIlIlI[1]] = lIlIlIIIllllll("l59vpGmeHsxF1klG6uPJ6Q==", "sklgw");
  }
  
  private static boolean lIlIlIIlIIIlII(Object ???)
  {
    double llllllllllllllIllllIlIlIllIIIIlI;
    return ??? != null;
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIllllIlIlIlllIlIIl)
  {
    ;
    ;
    if (lIlIlIIlIIIlll(llllllllllllllIllllIlIlIlllIlIIl & llIlllIIlIlI[1]))
    {
      "".length();
      if (((91 + 48 - 81 + 92 ^ 29 + 77 - 77 + 107) & (0xC8 ^ 0x83 ^ 0x16 ^ 0x43 ^ -" ".length())) == 0) {
        break label85;
      }
      return null;
    }
    label85:
    return EXPLODE.withProperty(llIlllIIlIlI[1], Boolean.valueOf(llIlllIIlIlI[0]));
  }
  
  public void onBlockDestroyedByPlayer(World llllllllllllllIllllIlIllIIllIlIl, BlockPos llllllllllllllIllllIlIllIIllIIII, IBlockState llllllllllllllIllllIlIllIIlIllll)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIllllIlIllIIllIIlI.explode(llllllllllllllIllllIlIllIIllIlIl, llllllllllllllIllllIlIllIIllIIII, llllllllllllllIllllIlIllIIlIllll, null);
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIllllIlIlIlllIIllI)
  {
    ;
    if (lIlIlIIlIIIIlI(((Boolean)llllllllllllllIllllIlIlIlllIIllI.getValue(EXPLODE)).booleanValue()))
    {
      "".length();
      if ((0x18 ^ 0x1C) != " ".length()) {
        break label64;
      }
      return "  ".length() & ("  ".length() ^ 0xFFFFFFFF);
    }
    label64:
    return llIlllIIlIlI[0];
  }
  
  private static boolean lIlIlIIlIIIlIl(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllIllllIlIlIllIIIlII;
    return ??? != localObject;
  }
  
  public BlockTNT()
  {
    llllllllllllllIllllIlIllIllIIIlI.<init>(Material.tnt);
    llllllllllllllIllllIlIllIllIIIIl.setDefaultState(blockState.getBaseState().withProperty(EXPLODE, Boolean.valueOf(llIlllIIlIlI[0])));
    "".length();
  }
  
  private static boolean lIlIlIIlIIIllI(Object ???, Object arg1)
  {
    Object localObject;
    double llllllllllllllIllllIlIlIlIlllllI;
    return ??? == localObject;
  }
  
  private static boolean lIlIlIIlIIIIll(int ???)
  {
    short llllllllllllllIllllIlIlIlIlllIlI;
    return ??? == 0;
  }
  
  public void onBlockAdded(World llllllllllllllIllllIlIllIlIllIll, BlockPos llllllllllllllIllllIlIllIlIllIlI, IBlockState llllllllllllllIllllIlIllIlIlIlIl)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIllllIlIllIlIllIII.onBlockAdded(llllllllllllllIllllIlIllIlIllIll, llllllllllllllIllllIlIllIlIllIlI, llllllllllllllIllllIlIllIlIlIlIl);
    if (lIlIlIIlIIIIlI(llllllllllllllIllllIlIllIlIllIll.isBlockPowered(llllllllllllllIllllIlIllIlIllIlI)))
    {
      llllllllllllllIllllIlIllIlIllIII.onBlockDestroyedByPlayer(llllllllllllllIllllIlIllIlIllIll, llllllllllllllIllllIlIllIlIllIlI, llllllllllllllIllllIlIllIlIlIlIl.withProperty(EXPLODE, Boolean.valueOf(llIlllIIlIlI[1])));
      "".length();
    }
  }
  
  private static boolean lIlIlIIlIIIIlI(int ???)
  {
    float llllllllllllllIllllIlIlIlIllllII;
    return ??? != 0;
  }
  
  public void explode(World llllllllllllllIllllIlIllIIlIIIll, BlockPos llllllllllllllIllllIlIllIIlIIlll, IBlockState llllllllllllllIllllIlIllIIlIIIIl, EntityLivingBase llllllllllllllIllllIlIllIIlIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    if ((lIlIlIIlIIIIll(isRemote)) && (lIlIlIIlIIIIlI(((Boolean)llllllllllllllIllllIlIllIIlIIIIl.getValue(EXPLODE)).booleanValue())))
    {
      EntityTNTPrimed llllllllllllllIllllIlIllIIlIIlII = new EntityTNTPrimed(llllllllllllllIllllIlIllIIlIIIll, llllllllllllllIllllIlIllIIlIIlll.getX() + 0.5F, llllllllllllllIllllIlIllIIlIIlll.getY(), llllllllllllllIllllIlIllIIlIIlll.getZ() + 0.5F, llllllllllllllIllllIlIllIIlIIlIl);
      "".length();
      llllllllllllllIllllIlIllIIlIIIll.playSoundAtEntity(llllllllllllllIllllIlIllIIlIIlII, llIlllIIlIIl[llIlllIIlIlI[1]], 1.0F, 1.0F);
    }
  }
  
  public boolean onBlockActivated(World llllllllllllllIllllIlIllIIIlIIll, BlockPos llllllllllllllIllllIlIllIIIIlIII, IBlockState llllllllllllllIllllIlIllIIIIIlll, EntityPlayer llllllllllllllIllllIlIllIIIIIllI, EnumFacing llllllllllllllIllllIlIllIIIIllll, float llllllllllllllIllllIlIllIIIIlllI, float llllllllllllllIllllIlIllIIIIllIl, float llllllllllllllIllllIlIllIIIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIlIIlIIIlII(llllllllllllllIllllIlIllIIIIIllI.getCurrentEquippedItem()))
    {
      Item llllllllllllllIllllIlIllIIIIlIll = llllllllllllllIllllIlIllIIIlIIII.getCurrentEquippedItem().getItem();
      if ((!lIlIlIIlIIIlIl(llllllllllllllIllllIlIllIIIIlIll, Items.flint_and_steel)) || (lIlIlIIlIIIllI(llllllllllllllIllllIlIllIIIIlIll, Items.fire_charge)))
      {
        llllllllllllllIllllIlIllIIIIlIlI.explode(llllllllllllllIllllIlIllIIIlIIll, llllllllllllllIllllIlIllIIIIlIII, llllllllllllllIllllIlIllIIIIIlll.withProperty(EXPLODE, Boolean.valueOf(llIlllIIlIlI[1])), llllllllllllllIllllIlIllIIIlIIII);
        "".length();
        if (lIlIlIIlIIIllI(llllllllllllllIllllIlIllIIIIlIll, Items.flint_and_steel))
        {
          llllllllllllllIllllIlIllIIIlIIII.getCurrentEquippedItem().damageItem(llIlllIIlIlI[1], llllllllllllllIllllIlIllIIIlIIII);
          "".length();
          if (((0x8A ^ 0xAA) & (0x29 ^ 0x9 ^ 0xFFFFFFFF)) != 0) {
            return (0x93 ^ 0x94) & (0xC6 ^ 0xC1 ^ 0xFFFFFFFF);
          }
        }
        else if (lIlIlIIlIIIIll(capabilities.isCreativeMode))
        {
          getCurrentEquippedItemstackSize -= llIlllIIlIlI[1];
        }
        return llIlllIIlIlI[1];
      }
    }
    return llllllllllllllIllllIlIllIIIIlIlI.onBlockActivated(llllllllllllllIllllIlIllIIIlIIll, llllllllllllllIllllIlIllIIIIlIII, llllllllllllllIllllIlIllIIIIIlll, llllllllllllllIllllIlIllIIIlIIII, llllllllllllllIllllIlIllIIIIllll, llllllllllllllIllllIlIllIIIIlllI, llllllllllllllIllllIlIllIIIIllIl, llllllllllllllIllllIlIllIIIIIIlI);
  }
  
  public void onBlockDestroyedByExplosion(World llllllllllllllIllllIlIllIIlllllI, BlockPos llllllllllllllIllllIlIllIIllllIl, Explosion llllllllllllllIllllIlIllIIllllII)
  {
    ;
    ;
    ;
    ;
    if (lIlIlIIlIIIIll(isRemote))
    {
      EntityTNTPrimed llllllllllllllIllllIlIllIIllllll = new EntityTNTPrimed(llllllllllllllIllllIlIllIIlllllI, llllllllllllllIllllIlIllIlIIIIIl.getX() + 0.5F, llllllllllllllIllllIlIllIlIIIIIl.getY(), llllllllllllllIllllIlIllIlIIIIIl.getZ() + 0.5F, llllllllllllllIllllIlIllIIllllII.getExplosivePlacedBy());
      fuse = (rand.nextInt(fuse / llIlllIIlIlI[2]) + fuse / llIlllIIlIlI[3]);
      "".length();
    }
  }
  
  public void onEntityCollidedWithBlock(World llllllllllllllIllllIlIlIlllllIlI, BlockPos llllllllllllllIllllIlIlIllllIIll, IBlockState llllllllllllllIllllIlIlIlllllIII, Entity llllllllllllllIllllIlIlIllllIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    if ((lIlIlIIlIIIIll(isRemote)) && (lIlIlIIlIIIIlI(llllllllllllllIllllIlIlIllllIIlI instanceof EntityArrow)))
    {
      EntityArrow llllllllllllllIllllIlIlIllllIllI = (EntityArrow)llllllllllllllIllllIlIlIllllIIlI;
      if (lIlIlIIlIIIIlI(llllllllllllllIllllIlIlIllllIllI.isBurning()))
      {
        if (lIlIlIIlIIIIlI(shootingEntity instanceof EntityLivingBase))
        {
          "".length();
          if (" ".length() > -" ".length()) {
            break label107;
          }
        }
        label107:
        llllllllllllllIllllIlIlIlllllIlI.explode(llllllllllllllIllllIlIlIlllllIIl, llllllllllllllIllllIlIlIlllllIlI.getBlockState(llllllllllllllIllllIlIlIlllllIIl).withProperty(EXPLODE, Boolean.valueOf(llIlllIIlIlI[1])), (EntityLivingBase)shootingEntity, null);
        "".length();
      }
    }
  }
  
  private static String lIlIlIIIlllllI(String llllllllllllllIllllIlIlIllIllIII, String llllllllllllllIllllIlIlIllIllIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllllIlIlIllIlllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllllIlIlIllIllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllllIlIlIllIlllII = Cipher.getInstance("Blowfish");
      llllllllllllllIllllIlIlIllIlllII.init(llIlllIIlIlI[4], llllllllllllllIllllIlIlIllIlllIl);
      return new String(llllllllllllllIllllIlIlIllIlllII.doFinal(Base64.getDecoder().decode(llllllllllllllIllllIlIlIllIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllllIlIlIllIllIll)
    {
      llllllllllllllIllllIlIlIllIllIll.printStackTrace();
    }
    return null;
  }
  
  private static void lIlIlIIlIIIIIl()
  {
    llIlllIIlIlI = new int[5];
    llIlllIIlIlI[0] = ((0x98 ^ 0xAA) & (0x41 ^ 0x73 ^ 0xFFFFFFFF));
    llIlllIIlIlI[1] = " ".length();
    llIlllIIlIlI[2] = (0xBB ^ 0xBF);
    llIlllIIlIlI[3] = ('' + 87 - 109 + 71 ^ 110 + 41 - 43 + 89);
    llIlllIIlIlI[4] = "  ".length();
  }
  
  static
  {
    lIlIlIIlIIIIIl();
    lIlIlIIlIIIIII();
  }
  
  private static String lIlIlIIIllllll(String llllllllllllllIllllIlIlIllIIlIll, String llllllllllllllIllllIlIlIllIIlIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllllIlIlIllIlIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllllIlIlIllIIlIlI.getBytes(StandardCharsets.UTF_8)), llIlllIIlIlI[3]), "DES");
      Cipher llllllllllllllIllllIlIlIllIIllll = Cipher.getInstance("DES");
      llllllllllllllIllllIlIlIllIIllll.init(llIlllIIlIlI[4], llllllllllllllIllllIlIlIllIlIIII);
      return new String(llllllllllllllIllllIlIlIllIIllll.doFinal(Base64.getDecoder().decode(llllllllllllllIllllIlIlIllIIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllllIlIlIllIIlllI)
    {
      llllllllllllllIllllIlIlIllIIlllI.printStackTrace();
    }
    return null;
  }
}

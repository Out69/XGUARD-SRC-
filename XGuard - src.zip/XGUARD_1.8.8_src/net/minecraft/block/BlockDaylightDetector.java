package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityDaylightDetector;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;

public class BlockDaylightDetector
  extends BlockContainer
{
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIlIIIIIIIlIllIllIl, BlockPos llllllllllllllIlIIIIIIIlIllIllII)
  {
    ;
    llllllllllllllIlIIIIIIIlIllIlIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.375F, 1.0F);
  }
  
  public void updatePower(World llllllllllllllIlIIIIIIIlIlIllIll, BlockPos llllllllllllllIlIIIIIIIlIlIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIIlIIIIIlI(provider.getHasNoSky()))
    {
      IBlockState llllllllllllllIlIIIIIIIlIlIllIIl = llllllllllllllIlIIIIIIIlIlIlIlII.getBlockState(llllllllllllllIlIIIIIIIlIlIlIIll);
      int llllllllllllllIlIIIIIIIlIlIllIII = llllllllllllllIlIIIIIIIlIlIlIlII.getLightFor(EnumSkyBlock.SKY, llllllllllllllIlIIIIIIIlIlIlIIll) - llllllllllllllIlIIIIIIIlIlIlIlII.getSkylightSubtracted();
      float llllllllllllllIlIIIIIIIlIlIlIlll = llllllllllllllIlIIIIIIIlIlIlIlII.getCelestialAngleRadians(1.0F);
      if (lllIIIlIIIIIll(lllIIIlIIIIIIl(llllllllllllllIlIIIIIIIlIlIlIlll, 3.1415927F)))
      {
        "".length();
        if (((0xA4 ^ 0xC4 ^ 0x5A ^ 0x75) & (57 + 20 - 65 + 222 ^ '' + 65 - 38 + 9 ^ -" ".length())) == 0) {
          break label113;
        }
      }
      label113:
      float llllllllllllllIlIIIIIIIlIlIlIllI = 6.2831855F;
      llllllllllllllIlIIIIIIIlIlIlIlll += (llllllllllllllIlIIIIIIIlIlIlIllI - llllllllllllllIlIIIIIIIlIlIlIlll) * 0.2F;
      llllllllllllllIlIIIIIIIlIlIllIII = Math.round(llllllllllllllIlIIIIIIIlIlIllIII * MathHelper.cos(llllllllllllllIlIIIIIIIlIlIlIlll));
      llllllllllllllIlIIIIIIIlIlIllIII = MathHelper.clamp_int(llllllllllllllIlIIIIIIIlIlIllIII, lIIlIlIIIlIll[0], lIIlIlIIIlIll[1]);
      if (lllIIIlIIIIlII(inverted)) {
        llllllllllllllIlIIIIIIIlIlIllIII = lIIlIlIIIlIll[1] - llllllllllllllIlIIIIIIIlIlIllIII;
      }
      if (lllIIIlIIIIlIl(((Integer)llllllllllllllIlIIIIIIIlIlIllIIl.getValue(POWER)).intValue(), llllllllllllllIlIIIIIIIlIlIllIII)) {
        "".length();
      }
    }
  }
  
  public boolean isFullCube()
  {
    return lIIlIlIIIlIll[0];
  }
  
  private static boolean lllIIIlIIIIIll(int ???)
  {
    float llllllllllllllIlIIIIIIIIlllllIlI;
    return ??? < 0;
  }
  
  public boolean isOpaqueCube()
  {
    return lIIlIlIIIlIll[0];
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIlIIIIIIIlIIIllIlI, new IProperty[] { POWER });
  }
  
  private static boolean lllIIIlIIIIlII(int ???)
  {
    float llllllllllllllIlIIIIIIIIlllllllI;
    return ??? != 0;
  }
  
  public boolean onBlockActivated(World llllllllllllllIlIIIIIIIlIlIIIlII, BlockPos llllllllllllllIlIIIIIIIlIlIIIIll, IBlockState llllllllllllllIlIIIIIIIlIIlllIIl, EntityPlayer llllllllllllllIlIIIIIIIlIIlllIII, EnumFacing llllllllllllllIlIIIIIIIlIlIIIIII, float llllllllllllllIlIIIIIIIlIIllIllI, float llllllllllllllIlIIIIIIIlIIlllllI, float llllllllllllllIlIIIIIIIlIIllllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIIlIIIIlII(llllllllllllllIlIIIIIIIlIIlllIII.isAllowEdit()))
    {
      if (lllIIIlIIIIlII(isRemote)) {
        return lIIlIlIIIlIll[2];
      }
      if (lllIIIlIIIIlII(inverted))
      {
        "".length();
        Blocks.daylight_detector.updatePower(llllllllllllllIlIIIIIIIlIlIIIlII, llllllllllllllIlIIIIIIIlIlIIIIll);
        "".length();
        if (((0xEC ^ 0xA8 ^ 0x7B ^ 0x9) & (51 + 78 - 1 + 9 ^ 30 + 10 - -111 + 40 ^ -" ".length())) < 0) {
          return (0x4B ^ 0x47 ^ 0x46 ^ 0xA) & ('Î' + 27 - 206 + 211 ^ 8 + 78 - -26 + 62 ^ -" ".length());
        }
      }
      else
      {
        "".length();
        Blocks.daylight_detector_inverted.updatePower(llllllllllllllIlIIIIIIIlIlIIIlII, llllllllllllllIlIIIIIIIlIlIIIIll);
      }
      return lIIlIlIIIlIll[2];
    }
    return llllllllllllllIlIIIIIIIlIIllllII.onBlockActivated(llllllllllllllIlIIIIIIIlIlIIIlII, llllllllllllllIlIIIIIIIlIlIIIIll, llllllllllllllIlIIIIIIIlIIlllIIl, llllllllllllllIlIIIIIIIlIlIIIIIl, llllllllllllllIlIIIIIIIlIlIIIIII, llllllllllllllIlIIIIIIIlIIllIllI, llllllllllllllIlIIIIIIIlIIlllllI, llllllllllllllIlIIIIIIIlIIllllIl);
  }
  
  private static boolean lllIIIlIIIIlIl(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlIIIIIIIIllllIllI;
    return ??? != i;
  }
  
  static
  {
    lllIIIlIIIIIII();
    lllIIIIlllllll();
  }
  
  public Item getItem(World llllllllllllllIlIIIIIIIlIIlIlllI, BlockPos llllllllllllllIlIIIIIIIlIIlIllIl)
  {
    return Item.getItemFromBlock(Blocks.daylight_detector);
  }
  
  private static String lllIIIIllllllI(String llllllllllllllIlIIIIIIIlIIIIIlIl, String llllllllllllllIlIIIIIIIlIIIIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIIIIIIlIIIIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIIIIIIlIIIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIIIIIIIlIIIIIlll = Cipher.getInstance("Blowfish");
      llllllllllllllIlIIIIIIIlIIIIIlll.init(lIIlIlIIIlIll[5], llllllllllllllIlIIIIIIIlIIIIlIII);
      return new String(llllllllllllllIlIIIIIIIlIIIIIlll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIIIIIIlIIIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIIIIIIlIIIIIllI)
    {
      llllllllllllllIlIIIIIIIlIIIIIllI.printStackTrace();
    }
    return null;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIlIIIIIIIlIIIlllII)
  {
    ;
    return ((Integer)llllllllllllllIlIIIIIIIlIIIlllII.getValue(POWER)).intValue();
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIlIIIIIIIlIIllIIlI, Random llllllllllllllIlIIIIIIIlIIllIIIl, int llllllllllllllIlIIIIIIIlIIllIIII)
  {
    return Item.getItemFromBlock(Blocks.daylight_detector);
  }
  
  public boolean canProvidePower()
  {
    return lIIlIlIIIlIll[2];
  }
  
  private static int lllIIIlIIIIIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public BlockDaylightDetector(boolean llllllllllllllIlIIIIIIIlIlllIIII)
  {
    llllllllllllllIlIIIIIIIlIlllIIll.<init>(Material.wood);
    inverted = llllllllllllllIlIIIIIIIlIlllIIII;
    llllllllllllllIlIIIIIIIlIlllIIll.setDefaultState(blockState.getBaseState().withProperty(POWER, Integer.valueOf(lIIlIlIIIlIll[0])));
    llllllllllllllIlIIIIIIIlIlllIIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.375F, 1.0F);
    "".length();
    "".length();
    "".length();
    "".length();
  }
  
  public int getRenderType()
  {
    return lIIlIlIIIlIll[3];
  }
  
  private static boolean lllIIIlIIIIIlI(int ???)
  {
    short llllllllllllllIlIIIIIIIIllllllII;
    return ??? == 0;
  }
  
  public void getSubBlocks(Item llllllllllllllIlIIIIIIIlIIIIllll, CreativeTabs llllllllllllllIlIIIIIIIlIIIlIIlI, List<ItemStack> llllllllllllllIlIIIIIIIlIIIIllIl)
  {
    ;
    ;
    ;
    ;
    if (lllIIIlIIIIIlI(inverted)) {
      llllllllllllllIlIIIIIIIlIIIlIIII.getSubBlocks(llllllllllllllIlIIIIIIIlIIIIllll, llllllllllllllIlIIIIIIIlIIIlIIlI, llllllllllllllIlIIIIIIIlIIIIllIl);
    }
  }
  
  public TileEntity createNewTileEntity(World llllllllllllllIlIIIIIIIlIIlIIlll, int llllllllllllllIlIIIIIIIlIIlIIllI)
  {
    return new TileEntityDaylightDetector();
  }
  
  private static void lllIIIIlllllll()
  {
    lIIlIlIIIlIIl = new String[lIIlIlIIIlIll[5]];
    lIIlIlIIIlIIl[lIIlIlIIIlIll[0]] = lllIIIIllllllI("uGbML0KAC3Q=", "HxVAd");
    lIIlIlIIIlIIl[lIIlIlIIIlIll[2]] = lllIIIIllllllI("hUSYflBQ1SHwN4K7vm/vdr2lxKSE86F3", "xDLDQ");
  }
  
  public int getWeakPower(IBlockAccess llllllllllllllIlIIIIIIIlIllIlIII, BlockPos llllllllllllllIlIIIIIIIlIllIIlll, IBlockState llllllllllllllIlIIIIIIIlIllIIlII, EnumFacing llllllllllllllIlIIIIIIIlIllIIlIl)
  {
    ;
    return ((Integer)llllllllllllllIlIIIIIIIlIllIIlII.getValue(POWER)).intValue();
  }
  
  private static void lllIIIlIIIIIII()
  {
    lIIlIlIIIlIll = new int[6];
    lIIlIlIIIlIll[0] = ((' ' + 33 - 122 + 149 ^ 124 + 'º' - 166 + 47) & (0xB5 ^ 0x87 ^ 0x16 ^ 0x47 ^ -" ".length()));
    lIIlIlIIIlIll[1] = (0x22 ^ 0x2D);
    lIIlIlIIIlIll[2] = " ".length();
    lIIlIlIIIlIll[3] = "   ".length();
    lIIlIlIIIlIll[4] = (0xB3 ^ 0xB7);
    lIIlIlIIIlIll[5] = "  ".length();
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIlIIIIIIIlIIlIIIlI)
  {
    ;
    ;
    return llllllllllllllIlIIIIIIIlIIlIIIll.getDefaultState().withProperty(POWER, Integer.valueOf(llllllllllllllIlIIIIIIIlIIlIIIlI));
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;

public class BlockStaticLiquid
  extends BlockLiquid
{
  private static void lIIIlIlIlIIlIl()
  {
    lIllIIlllIII = new int[5];
    lIllIIlllIII[0] = ((0xCB ^ 0x82 ^ 0xA5 ^ 0xB7) & (0x2E ^ 0xE ^ 0x6C ^ 0x17 ^ -" ".length()));
    lIllIIlllIII[1] = " ".length();
    lIllIIlllIII[2] = "  ".length();
    lIllIIlllIII[3] = "   ".length();
    lIllIIlllIII[4] = (0x10 ^ 0x18);
  }
  
  private static void lIIIlIlIlIIlII()
  {
    lIllIIllIlll = new String[lIllIIlllIII[1]];
    lIllIIllIlll[lIllIIlllIII[0]] = lIIIlIlIlIIIll("iugzgzIEUhRDor8fx6TYxw==", "wPdYE");
  }
  
  private static boolean lIIIlIlIlIlIII(int ???)
  {
    long lllllllllllllllIIllIlIIlllIIIIII;
    return ??? != 0;
  }
  
  private static boolean lIIIlIlIlIIlll(int ???)
  {
    short lllllllllllllllIIllIlIIllIlllllI;
    return ??? == 0;
  }
  
  protected boolean isSurroundingBlockFlammable(World lllllllllllllllIIllIlIIllllIIlll, BlockPos lllllllllllllllIIllIlIIllllIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    char lllllllllllllllIIllIlIIlllIlllll = (lllllllllllllllIIllIlIIlllIllllI = EnumFacing.values()).length;
    byte lllllllllllllllIIllIlIIllllIIIII = lIllIIlllIII[0];
    "".length();
    if (null != null) {
      return (0x16 ^ 0x76) & (0xFE ^ 0x9E ^ 0xFFFFFFFF);
    }
    while (!lIIIlIlIlIlIlI(lllllllllllllllIIllIlIIllllIIIII, lllllllllllllllIIllIlIIlllIlllll))
    {
      EnumFacing lllllllllllllllIIllIlIIllllIIlIl = lllllllllllllllIIllIlIIlllIllllI[lllllllllllllllIIllIlIIllllIIIII];
      if (lIIIlIlIlIlIII(lllllllllllllllIIllIlIIllllIlIII.getCanBlockBurn(lllllllllllllllIIllIlIIllllIIIll, lllllllllllllllIIllIlIIllllIIllI.offset(lllllllllllllllIIllIlIIllllIIlIl)))) {
        return lIllIIlllIII[1];
      }
      lllllllllllllllIIllIlIIllllIIIII++;
    }
    return lIllIIlllIII[0];
  }
  
  static
  {
    lIIIlIlIlIIlIl();
    lIIIlIlIlIIlII();
  }
  
  private static boolean lIIIlIlIlIIllI(Object ???, Object arg1)
  {
    Object localObject;
    double lllllllllllllllIIllIlIIlllIIIIlI;
    return ??? == localObject;
  }
  
  private void updateLiquid(World lllllllllllllllIIllIlIlIIIIlIIll, BlockPos lllllllllllllllIIllIlIlIIIIIllIl, IBlockState lllllllllllllllIIllIlIlIIIIIllII)
  {
    ;
    ;
    ;
    ;
    ;
    BlockDynamicLiquid lllllllllllllllIIllIlIlIIIIlIIII = getFlowingBlock(blockMaterial);
    "".length();
    lllllllllllllllIIllIlIlIIIIlIIll.scheduleUpdate(lllllllllllllllIIllIlIlIIIIIllIl, lllllllllllllllIIllIlIlIIIIlIIII, lllllllllllllllIIllIlIlIIIIIllll.tickRate(lllllllllllllllIIllIlIlIIIIlIIll));
  }
  
  protected BlockStaticLiquid(Material lllllllllllllllIIllIlIlIIIlIIlll)
  {
    lllllllllllllllIIllIlIlIIIlIlIII.<init>(lllllllllllllllIIllIlIlIIIlIIlll);
    "".length();
    if (lIIIlIlIlIIllI(lllllllllllllllIIllIlIlIIIlIIlll, Material.lava)) {
      "".length();
    }
  }
  
  public void onNeighborBlockChange(World lllllllllllllllIIllIlIlIIIIlllII, BlockPos lllllllllllllllIIllIlIlIIIIllIll, IBlockState lllllllllllllllIIllIlIlIIIIlllll, Block lllllllllllllllIIllIlIlIIIIllllI)
  {
    ;
    ;
    ;
    ;
    if (lIIIlIlIlIIlll(lllllllllllllllIIllIlIlIIIIlllIl.checkForMixing(lllllllllllllllIIllIlIlIIIIlllII, lllllllllllllllIIllIlIlIIIlIIIII, lllllllllllllllIIllIlIlIIIIlllll))) {
      lllllllllllllllIIllIlIlIIIIlllIl.updateLiquid(lllllllllllllllIIllIlIlIIIIlllII, lllllllllllllllIIllIlIlIIIlIIIII, lllllllllllllllIIllIlIlIIIIlllll);
    }
  }
  
  private boolean getCanBlockBurn(World lllllllllllllllIIllIlIIlllIllIII, BlockPos lllllllllllllllIIllIlIIlllIllIIl)
  {
    ;
    ;
    return lllllllllllllllIIllIlIIlllIllIII.getBlockState(lllllllllllllllIIllIlIIlllIllIIl).getBlock().getMaterial().getCanBurn();
  }
  
  public void updateTick(World lllllllllllllllIIllIlIIlllllIllI, BlockPos lllllllllllllllIIllIlIlIIIIIIIII, IBlockState lllllllllllllllIIllIlIIlllllllll, Random lllllllllllllllIIllIlIIllllllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIIIlIlIlIIllI(blockMaterial, Material.lava)) && (lIIIlIlIlIlIII(lllllllllllllllIIllIlIIlllllIllI.getGameRules().getBoolean(lIllIIllIlll[lIllIIlllIII[0]]))))
    {
      int lllllllllllllllIIllIlIIlllllllIl = lllllllllllllllIIllIlIIllllllllI.nextInt(lIllIIlllIII[3]);
      if (lIIIlIlIlIlIIl(lllllllllllllllIIllIlIIlllllllIl))
      {
        BlockPos lllllllllllllllIIllIlIIlllllllII = lllllllllllllllIIllIlIIlllllIlIl;
        int lllllllllllllllIIllIlIIllllllIll = lIllIIlllIII[0];
        "".length();
        if (-" ".length() != -" ".length()) {
          return;
        }
        while (!lIIIlIlIlIlIlI(lllllllllllllllIIllIlIIllllllIll, lllllllllllllllIIllIlIIlllllllIl))
        {
          lllllllllllllllIIllIlIIlllllllII = lllllllllllllllIIllIlIIlllllllII.add(lllllllllllllllIIllIlIIllllllllI.nextInt(lIllIIlllIII[3]) - lIllIIlllIII[1], lIllIIlllIII[1], lllllllllllllllIIllIlIIllllllllI.nextInt(lIllIIlllIII[3]) - lIllIIlllIII[1]);
          Block lllllllllllllllIIllIlIIllllllIlI = lllllllllllllllIIllIlIIlllllIllI.getBlockState(lllllllllllllllIIllIlIIlllllllII).getBlock();
          if (lIIIlIlIlIIllI(blockMaterial, Material.air))
          {
            if (lIIIlIlIlIlIII(lllllllllllllllIIllIlIIlllllIlll.isSurroundingBlockFlammable(lllllllllllllllIIllIlIIlllllIllI, lllllllllllllllIIllIlIIlllllllII))) {
              "".length();
            }
          }
          else if (lIIIlIlIlIlIII(blockMaterial.blocksMovement())) {
            return;
          }
          lllllllllllllllIIllIlIIllllllIll++;
        }
        "".length();
        if ((0x47 ^ 0x43) >= -" ".length()) {}
      }
      else
      {
        int lllllllllllllllIIllIlIIllllllIIl = lIllIIlllIII[0];
        "".length();
        if (-" ".length() >= "   ".length()) {
          return;
        }
        while (!lIIIlIlIlIlIlI(lllllllllllllllIIllIlIIllllllIIl, lIllIIlllIII[3]))
        {
          BlockPos lllllllllllllllIIllIlIIllllllIII = lllllllllllllllIIllIlIIlllllIlIl.add(lllllllllllllllIIllIlIIllllllllI.nextInt(lIllIIlllIII[3]) - lIllIIlllIII[1], lIllIIlllIII[0], lllllllllllllllIIllIlIIllllllllI.nextInt(lIllIIlllIII[3]) - lIllIIlllIII[1]);
          if ((lIIIlIlIlIlIII(lllllllllllllllIIllIlIIlllllIllI.isAirBlock(lllllllllllllllIIllIlIIllllllIII.up()))) && (lIIIlIlIlIlIII(lllllllllllllllIIllIlIIlllllIlll.getCanBlockBurn(lllllllllllllllIIllIlIIlllllIllI, lllllllllllllllIIllIlIIllllllIII)))) {
            "".length();
          }
          lllllllllllllllIIllIlIIllllllIIl++;
        }
      }
    }
  }
  
  private static String lIIIlIlIlIIIll(String lllllllllllllllIIllIlIIlllIIllll, String lllllllllllllllIIllIlIIlllIIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIllIlIIlllIlIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIlIIlllIIllII.getBytes(StandardCharsets.UTF_8)), lIllIIlllIII[4]), "DES");
      Cipher lllllllllllllllIIllIlIIlllIlIIIl = Cipher.getInstance("DES");
      lllllllllllllllIIllIlIIlllIlIIIl.init(lIllIIlllIII[2], lllllllllllllllIIllIlIIlllIlIIlI);
      return new String(lllllllllllllllIIllIlIIlllIlIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIlIIlllIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIllIlIIlllIlIIII)
    {
      lllllllllllllllIIllIlIIlllIlIIII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIlIlIlIlIlI(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIIllIlIIlllIIIllI;
    return ??? >= i;
  }
  
  private static boolean lIIIlIlIlIlIIl(int ???)
  {
    short lllllllllllllllIIllIlIIllIllllII;
    return ??? > 0;
  }
}

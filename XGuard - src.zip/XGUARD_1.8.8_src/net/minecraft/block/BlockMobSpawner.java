package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityMobSpawner;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.World;

public class BlockMobSpawner
  extends BlockContainer
{
  public int quantityDropped(Random lllllllllllllllIIlIIIlIIlIlllIIl)
  {
    return llIIIIlIIIll[0];
  }
  
  public int getRenderType()
  {
    return llIIIIlIIIll[2];
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllIIlIIIlIIlIllllIl, Random lllllllllllllllIIlIIIlIIlIllllII, int lllllllllllllllIIlIIIlIIlIlllIll)
  {
    return null;
  }
  
  public TileEntity createNewTileEntity(World lllllllllllllllIIlIIIlIIllIIIIII, int lllllllllllllllIIlIIIlIIlIllllll)
  {
    return new TileEntityMobSpawner();
  }
  
  public boolean isOpaqueCube()
  {
    return llIIIIlIIIll[0];
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  static {}
  
  private static void lIIlIlIIIIllIl()
  {
    llIIIIlIIIll = new int[3];
    llIIIIlIIIll[0] = ((0x36 ^ 0x7E ^ 0x1 ^ 0x6F) & ('¯' + 107 - 263 + 205 ^ 41 + 62 - 42 + 137 ^ -" ".length()));
    llIIIIlIIIll[1] = (0x2A ^ 0x25);
    llIIIIlIIIll[2] = "   ".length();
  }
  
  public void dropBlockAsItemWithChance(World lllllllllllllllIIlIIIlIIlIlIlIIl, BlockPos lllllllllllllllIIlIIIlIIlIlIllll, IBlockState lllllllllllllllIIlIIIlIIlIlIIlll, float lllllllllllllllIIlIIIlIIlIlIllIl, int lllllllllllllllIIlIIIlIIlIlIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIIlIIlIlIlIlI.dropBlockAsItemWithChance(lllllllllllllllIIlIIIlIIlIlIlIIl, lllllllllllllllIIlIIIlIIlIlIllll, lllllllllllllllIIlIIIlIIlIlIIlll, lllllllllllllllIIlIIIlIIlIlIllIl, lllllllllllllllIIlIIIlIIlIlIllII);
    int lllllllllllllllIIlIIIlIIlIlIlIll = llIIIIlIIIll[1] + rand.nextInt(llIIIIlIIIll[1]) + rand.nextInt(llIIIIlIIIll[1]);
    lllllllllllllllIIlIIIlIIlIlIlIlI.dropXpOnBlockBreak(lllllllllllllllIIlIIIlIIlIlIlIIl, lllllllllllllllIIlIIIlIIlIlIllll, lllllllllllllllIIlIIIlIIlIlIlIll);
  }
  
  public Item getItem(World lllllllllllllllIIlIIIlIIlIIlllll, BlockPos lllllllllllllllIIlIIIlIIlIIllllI)
  {
    return null;
  }
  
  protected BlockMobSpawner()
  {
    lllllllllllllllIIlIIIlIIllIIIIll.<init>(Material.rock);
  }
}

package net.minecraft.block;

import java.util.Iterator;
import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenBigMushroom;
import net.minecraft.world.gen.feature.WorldGenerator;

public class BlockMushroom
  extends BlockBush
  implements IGrowable
{
  public boolean canPlaceBlockAt(World llllllllllllllIIllIIllIIllIllIll, BlockPos llllllllllllllIIllIIllIIllIllIlI)
  {
    ;
    ;
    ;
    if ((lllIlllIIlIIll(llllllllllllllIIllIIllIIllIlllII.canPlaceBlockAt(llllllllllllllIIllIIllIIllIllllI, llllllllllllllIIllIIllIIllIllIlI))) && (lllIlllIIlIIll(llllllllllllllIIllIIllIIllIlllII.canBlockStay(llllllllllllllIIllIIllIIllIllllI, llllllllllllllIIllIIllIIllIllIlI, llllllllllllllIIllIIllIIllIlllII.getDefaultState())))) {
      return lIIlllIIlIlll[0];
    }
    return lIIlllIIlIlll[8];
  }
  
  private static boolean lllIlllIIlIlII(int ???, int arg1)
  {
    int i;
    long llllllllllllllIIllIIllIIlIIllIII;
    return ??? >= i;
  }
  
  private static boolean lllIlllIIlIIlI(int ???)
  {
    double llllllllllllllIIllIIllIIlIIIIlII;
    return ??? <= 0;
  }
  
  private static boolean lllIlllIIlIlll(Object ???)
  {
    byte llllllllllllllIIllIIllIIlIIIlllI;
    return ??? != null;
  }
  
  public boolean generateBigMushroom(World llllllllllllllIIllIIllIIllIIIIIl, BlockPos llllllllllllllIIllIIllIIlIlllIlI, IBlockState llllllllllllllIIllIIllIIlIllllll, Random llllllllllllllIIllIIllIIlIlllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    "".length();
    WorldGenerator llllllllllllllIIllIIllIIlIllllIl = null;
    if (lllIlllIIlIIIl(llllllllllllllIIllIIllIIlIllllII, Blocks.brown_mushroom))
    {
      llllllllllllllIIllIIllIIlIllllIl = new WorldGenBigMushroom(Blocks.brown_mushroom_block);
      "".length();
      if (null != null) {
        return (0x85 ^ 0xA3) & (0xE ^ 0x28 ^ 0xFFFFFFFF);
      }
    }
    else if (lllIlllIIlIIIl(llllllllllllllIIllIIllIIlIllllII, Blocks.red_mushroom))
    {
      llllllllllllllIIllIIllIIlIllllIl = new WorldGenBigMushroom(Blocks.red_mushroom_block);
    }
    if ((lllIlllIIlIlll(llllllllllllllIIllIIllIIlIllllIl)) && (lllIlllIIlIIll(llllllllllllllIIllIIllIIlIllllIl.generate(llllllllllllllIIllIIllIIllIIIIIl, llllllllllllllIIllIIllIIlIlllIII, llllllllllllllIIllIIllIIllIIIIII)))) {
      return lIIlllIIlIlll[0];
    }
    "".length();
    return lIIlllIIlIlll[8];
  }
  
  private static boolean lllIlllIIlIIIl(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllIIllIIllIIlIIlIIII;
    return ??? == localObject;
  }
  
  private static boolean lllIlllIIlIIll(int ???)
  {
    byte llllllllllllllIIllIIllIIlIIIllII;
    return ??? != 0;
  }
  
  static {}
  
  protected BlockMushroom()
  {
    float llllllllllllllIIllIIllIIllllllll = 0.2F;
    llllllllllllllIIllIIllIlIIIIIIII.setBlockBounds(0.5F - llllllllllllllIIllIIllIIllllllll, 0.0F, 0.5F - llllllllllllllIIllIIllIIllllllll, 0.5F + llllllllllllllIIllIIllIIllllllll, llllllllllllllIIllIIllIIllllllll * 2.0F, 0.5F + llllllllllllllIIllIIllIIllllllll);
    "".length();
  }
  
  public boolean canUseBonemeal(World llllllllllllllIIllIIllIIlIlIllll, Random llllllllllllllIIllIIllIIlIlIlIll, BlockPos llllllllllllllIIllIIllIIlIlIllIl, IBlockState llllllllllllllIIllIIllIIlIlIllII)
  {
    ;
    if (lllIlllIIllIIl(lllIlllIIllIII(llllllllllllllIIllIIllIIlIlIlIll.nextFloat(), 0.4D))) {
      return lIIlllIIlIlll[0];
    }
    return lIIlllIIlIlll[8];
  }
  
  private static boolean lllIlllIIlIIII(int ???)
  {
    float llllllllllllllIIllIIllIIlIIIlIlI;
    return ??? == 0;
  }
  
  private static void lllIlllIIIllll()
  {
    lIIlllIIlIlll = new int[11];
    lIIlllIIlIlll[0] = " ".length();
    lIIlllIIlIlll[1] = (0x51 ^ 0x48);
    lIIlllIIlIlll[2] = (0x77 ^ 0x72);
    lIIlllIIlIlll[3] = (0x91 ^ 0x95);
    lIIlllIIlIlll[4] = (-(0x4C ^ 0x48));
    lIIlllIIlIlll[5] = (-" ".length());
    lIIlllIIlIlll[6] = "   ".length();
    lIIlllIIlIlll[7] = "  ".length();
    lIIlllIIlIlll[8] = ((122 + 48 - 168 + 132 ^ '' + 27 - 86 + 96) & (54 + 32 - 46 + 90 ^ 117 + 'Æ' - 163 + 47 ^ -" ".length()));
    lIIlllIIlIlll[9] = (-(0xFFFFFFF3 & 0x5E6F) & 0xDF63 & 0x7FFE);
    lIIlllIIlIlll[10] = (125 + 119 - 123 + 57 ^ 88 + '³' - 255 + 179);
  }
  
  private static boolean lllIlllIIlIllI(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIIllIIllIIlIIlIlII;
    return ??? < i;
  }
  
  public void updateTick(World llllllllllllllIIllIIllIIlllIlIIl, BlockPos llllllllllllllIIllIIllIIllllIIlI, IBlockState llllllllllllllIIllIIllIIllllIIIl, Random llllllllllllllIIllIIllIIllllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIlllIIlIIII(llllllllllllllIIllIIllIIllllIIII.nextInt(lIIlllIIlIlll[1])))
    {
      int llllllllllllllIIllIIllIIlllIllll = lIIlllIIlIlll[2];
      int llllllllllllllIIllIIllIIlllIlllI = lIIlllIIlIlll[3];
      llllllllllllllIIllIIllIIlllIIIll = BlockPos.getAllInBoxMutable(llllllllllllllIIllIIllIIlllIlIII.add(lIIlllIIlIlll[4], lIIlllIIlIlll[5], lIIlllIIlIlll[4]), llllllllllllllIIllIIllIIlllIlIII.add(lIIlllIIlIlll[3], lIIlllIIlIlll[0], lIIlllIIlIlll[3])).iterator();
      "".length();
      if ("  ".length() == " ".length()) {
        return;
      }
      while (!lllIlllIIlIIII(llllllllllllllIIllIIllIIlllIIIll.hasNext()))
      {
        BlockPos llllllllllllllIIllIIllIIlllIllIl = (BlockPos)llllllllllllllIIllIIllIIlllIIIll.next();
        if (lllIlllIIlIIIl(llllllllllllllIIllIIllIIlllIlIIl.getBlockState(llllllllllllllIIllIIllIIlllIllIl).getBlock(), llllllllllllllIIllIIllIIllllIlII))
        {
          llllllllllllllIIllIIllIIlllIllll--;
          if (lllIlllIIlIIlI(llllllllllllllIIllIIllIIlllIllll)) {
            return;
          }
        }
      }
      BlockPos llllllllllllllIIllIIllIIlllIllII = llllllllllllllIIllIIllIIlllIlIII.add(llllllllllllllIIllIIllIIllllIIII.nextInt(lIIlllIIlIlll[6]) - lIIlllIIlIlll[0], llllllllllllllIIllIIllIIllllIIII.nextInt(lIIlllIIlIlll[7]) - llllllllllllllIIllIIllIIllllIIII.nextInt(lIIlllIIlIlll[7]), llllllllllllllIIllIIllIIllllIIII.nextInt(lIIlllIIlIlll[6]) - lIIlllIIlIlll[0]);
      int llllllllllllllIIllIIllIIlllIlIll = lIIlllIIlIlll[8];
      "".length();
      if (-" ".length() != -" ".length()) {
        return;
      }
      while (!lllIlllIIlIlII(llllllllllllllIIllIIllIIlllIlIll, lIIlllIIlIlll[3]))
      {
        if ((lllIlllIIlIIll(llllllllllllllIIllIIllIIlllIlIIl.isAirBlock(llllllllllllllIIllIIllIIlllIllII))) && (lllIlllIIlIIll(llllllllllllllIIllIIllIIllllIlII.canBlockStay(llllllllllllllIIllIIllIIlllIlIIl, llllllllllllllIIllIIllIIlllIllII, llllllllllllllIIllIIllIIllllIlII.getDefaultState())))) {
          llllllllllllllIIllIIllIIlllIlIII = llllllllllllllIIllIIllIIlllIllII;
        }
        llllllllllllllIIllIIllIIlllIllII = llllllllllllllIIllIIllIIlllIlIII.add(llllllllllllllIIllIIllIIllllIIII.nextInt(lIIlllIIlIlll[6]) - lIIlllIIlIlll[0], llllllllllllllIIllIIllIIllllIIII.nextInt(lIIlllIIlIlll[7]) - llllllllllllllIIllIIllIIllllIIII.nextInt(lIIlllIIlIlll[7]), llllllllllllllIIllIIllIIllllIIII.nextInt(lIIlllIIlIlll[6]) - lIIlllIIlIlll[0]);
        llllllllllllllIIllIIllIIlllIlIll++;
      }
      if ((lllIlllIIlIIll(llllllllllllllIIllIIllIIlllIlIIl.isAirBlock(llllllllllllllIIllIIllIIlllIllII))) && (lllIlllIIlIIll(llllllllllllllIIllIIllIIllllIlII.canBlockStay(llllllllllllllIIllIIllIIlllIlIIl, llllllllllllllIIllIIllIIlllIllII, llllllllllllllIIllIIllIIllllIlII.getDefaultState())))) {
        "".length();
      }
    }
  }
  
  private static boolean lllIlllIIlIlIl(int ???)
  {
    String llllllllllllllIIllIIllIIlIIIlIII;
    return ??? >= 0;
  }
  
  public boolean canGrow(World llllllllllllllIIllIIllIIlIllIlIl, BlockPos llllllllllllllIIllIIllIIlIllIlII, IBlockState llllllllllllllIIllIIllIIlIllIIll, boolean llllllllllllllIIllIIllIIlIllIIlI)
  {
    return lIIlllIIlIlll[0];
  }
  
  public void grow(World llllllllllllllIIllIIllIIlIIlllll, Random llllllllllllllIIllIIllIIlIlIIIll, BlockPos llllllllllllllIIllIIllIIlIIlllIl, IBlockState llllllllllllllIIllIIllIIlIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    "".length();
  }
  
  private static boolean lllIlllIIllIIl(int ???)
  {
    double llllllllllllllIIllIIllIIlIIIIllI;
    return ??? < 0;
  }
  
  protected boolean canPlaceBlockOn(Block llllllllllllllIIllIIllIIllIlIlll)
  {
    ;
    return llllllllllllllIIllIIllIIllIlIlll.isFullBlock();
  }
  
  private static int lllIlllIIllIII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public boolean canBlockStay(World llllllllllllllIIllIIllIIllIlIIII, BlockPos llllllllllllllIIllIIllIIllIIlIlI, IBlockState llllllllllllllIIllIIllIIllIIlllI)
  {
    ;
    ;
    ;
    ;
    if ((lllIlllIIlIlIl(llllllllllllllIIllIIllIIllIIlIlI.getY())) && (lllIlllIIlIllI(llllllllllllllIIllIIllIIllIIlIlI.getY(), lIIlllIIlIlll[9])))
    {
      IBlockState llllllllllllllIIllIIllIIllIIllIl = llllllllllllllIIllIIllIIllIlIIII.getBlockState(llllllllllllllIIllIIllIIllIIlIlI.down());
      if (lllIlllIIlIIIl(llllllllllllllIIllIIllIIllIIllIl.getBlock(), Blocks.mycelium))
      {
        "".length();
        if (" ".length() < 0) {
          return (0xD ^ 0x2F ^ 0xE1 ^ 0x9C) & (0x4 ^ 0xC ^ 0xEA ^ 0xBD ^ -" ".length());
        }
      }
      else if ((lllIlllIIlIIIl(llllllllllllllIIllIIllIIllIIllIl.getBlock(), Blocks.dirt)) && (lllIlllIIlIIIl(llllllllllllllIIllIIllIIllIIllIl.getValue(BlockDirt.VARIANT), BlockDirt.DirtType.PODZOL)))
      {
        "".length();
        if (" ".length() <= ((0x15 ^ 0x5E) & (0x4C ^ 0x7 ^ 0xFFFFFFFF))) {
          return (0xFA ^ 0xC1) & (0xA ^ 0x31 ^ 0xFFFFFFFF);
        }
      }
      else if ((lllIlllIIlIllI(llllllllllllllIIllIIllIIllIlIIII.getLight(llllllllllllllIIllIIllIIllIIlIlI), lIIlllIIlIlll[10])) && (lllIlllIIlIIll(llllllllllllllIIllIIllIIllIIllII.canPlaceBlockOn(llllllllllllllIIllIIllIIllIIllIl.getBlock()))))
      {
        "".length();
        if (-"  ".length() <= 0) {
          break label264;
        }
        return (0x8A ^ 0x95) & (0x22 ^ 0x3D ^ 0xFFFFFFFF);
      }
      label264:
      return lIIlllIIlIlll[8];
    }
    return lIIlllIIlIlll[8];
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class BlockCrops
  extends BlockBush
  implements IGrowable
{
  private static boolean lIIllIllI(int ???)
  {
    double llIlIllllllllIl;
    return ??? != 0;
  }
  
  public void grow(World llIllIIIlIIIlll, Random llIllIIIlIIIllI, BlockPos llIllIIIlIIIlIl, IBlockState llIllIIIlIIIIII)
  {
    ;
    ;
    ;
    ;
    llIllIIIlIIlIII.grow(llIllIIIlIIIlll, llIllIIIlIIIlIl, llIllIIIlIIIIII);
  }
  
  public boolean canBlockStay(World llIllIIlIIIIlII, BlockPos llIllIIlIIIIIll, IBlockState llIllIIlIIIIllI)
  {
    ;
    ;
    ;
    if (((!lIIllIIlI(llIllIIlIIIIlII.getLight(llIllIIlIIIIIll), llIIIIl[7])) || (lIIllIllI(llIllIIlIIIIlII.canSeeSky(llIllIIlIIIIIll)))) && (lIIllIllI(llIllIIlIIIlIIl.canPlaceBlockOn(llIllIIlIIIIlII.getBlockState(llIllIIlIIIIIll.down()).getBlock())))) {
      return llIIIIl[2];
    }
    return llIIIIl[0];
  }
  
  protected static float getGrowthChance(Block llIllIIlIlIlIII, World llIllIIlIlIIlll, BlockPos llIllIIlIIlIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llIllIIlIlIIlIl = 1.0F;
    BlockPos llIllIIlIlIIlII = llIllIIlIIlIllI.down();
    int llIllIIlIlIIIll = llIIIIl[6];
    "".length();
    if (((0x72 ^ 0x24 ^ "  ".length()) & (0xF3 ^ 0xB0 ^ 0xBB ^ 0xAC ^ -" ".length())) < -" ".length()) {
      return 0.0F;
    }
    while (!lIIllIlII(llIllIIlIlIIIll, llIIIIl[2]))
    {
      int llIllIIlIlIIIlI = llIIIIl[6];
      "".length();
      if ((0x3 ^ 0x7) != (0x67 ^ 0x63)) {
        return 0.0F;
      }
      while (!lIIllIlII(llIllIIlIlIIIlI, llIIIIl[2]))
      {
        float llIllIIlIlIIIIl = 0.0F;
        IBlockState llIllIIlIlIIIII = llIllIIlIIlIlll.getBlockState(llIllIIlIlIIlII.add(llIllIIlIlIIIll, llIIIIl[0], llIllIIlIlIIIlI));
        if (lIIllIIII(llIllIIlIlIIIII.getBlock(), Blocks.farmland))
        {
          llIllIIlIlIIIIl = 1.0F;
          if (lIIllIlIl(((Integer)llIllIIlIlIIIII.getValue(BlockFarmland.MOISTURE)).intValue())) {
            llIllIIlIlIIIIl = 3.0F;
          }
        }
        if ((!lIIllIIll(llIllIIlIlIIIll)) || (lIIllIllI(llIllIIlIlIIIlI))) {
          llIllIIlIlIIIIl /= 4.0F;
        }
        llIllIIlIlIIlIl += llIllIIlIlIIIIl;
        llIllIIlIlIIIlI++;
      }
      llIllIIlIlIIIll++;
    }
    BlockPos llIllIIlIIlllll = llIllIIlIIlIllI.north();
    BlockPos llIllIIlIIllllI = llIllIIlIIlIllI.south();
    BlockPos llIllIIlIIlllIl = llIllIIlIIlIllI.west();
    BlockPos llIllIIlIIlllII = llIllIIlIIlIllI.east();
    if ((lIIllIlll(llIllIIlIlIlIII, llIllIIlIIlIlll.getBlockState(llIllIIlIIlllIl).getBlock())) && (lIIllIlll(llIllIIlIlIlIII, llIllIIlIIlIlll.getBlockState(llIllIIlIIlllII).getBlock())))
    {
      "".length();
      if ("   ".length() < (0xBE ^ 0xBA)) {
        break label316;
      }
      return 0.0F;
    }
    label316:
    boolean llIllIIlIIllIll = llIIIIl[2];
    if ((lIIllIlll(llIllIIlIlIlIII, llIllIIlIIlIlll.getBlockState(llIllIIlIIlllll).getBlock())) && (lIIllIlll(llIllIIlIlIlIII, llIllIIlIIlIlll.getBlockState(llIllIIlIIllllI).getBlock())))
    {
      "".length();
      if ((0x7F ^ 0x36 ^ 0x72 ^ 0x3F) > 0) {
        break label386;
      }
      return 0.0F;
    }
    label386:
    boolean llIllIIlIIllIlI = llIIIIl[2];
    if ((lIIllIllI(llIllIIlIIllIll)) && (lIIllIllI(llIllIIlIIllIlI)))
    {
      llIllIIlIlIIlIl /= 2.0F;
      "".length();
      if ("   ".length() < "  ".length()) {
        return 0.0F;
      }
    }
    else
    {
      if ((lIIllIlll(llIllIIlIlIlIII, llIllIIlIIlIlll.getBlockState(llIllIIlIIlllIl.north()).getBlock())) && (lIIllIlll(llIllIIlIlIlIII, llIllIIlIIlIlll.getBlockState(llIllIIlIIlllII.north()).getBlock())) && (lIIllIlll(llIllIIlIlIlIII, llIllIIlIIlIlll.getBlockState(llIllIIlIIlllII.south()).getBlock())) && (lIIllIlll(llIllIIlIlIlIII, llIllIIlIIlIlll.getBlockState(llIllIIlIIlllIl.south()).getBlock())))
      {
        "".length();
        if (((0x2C ^ 0x7A) & (0x17 ^ 0x41 ^ 0xFFFFFFFF)) == 0) {
          break label547;
        }
        return 0.0F;
      }
      label547:
      boolean llIllIIlIIllIIl = llIIIIl[2];
      if (lIIllIllI(llIllIIlIIllIIl)) {
        llIllIIlIlIIlIl /= 2.0F;
      }
    }
    return llIllIIlIlIIlIl;
  }
  
  private static boolean lIIllIlll(Object ???, Object arg1)
  {
    Object localObject;
    byte llIllIIIIIIIIll;
    return ??? != localObject;
  }
  
  private static boolean lIIllIIll(int ???)
  {
    double llIlIlllllllIll;
    return ??? == 0;
  }
  
  public Item getItemDropped(IBlockState llIllIIIlIllllI, Random llIllIIIllIIIIl, int llIllIIIllIIIII)
  {
    ;
    ;
    if (lIIlllIIl(((Integer)llIllIIIlIllllI.getValue(AGE)).intValue(), llIIIIl[1]))
    {
      "".length();
      if (-" ".length() < "   ".length()) {
        break label56;
      }
      return null;
    }
    label56:
    return llIllIIIlIlllll.getSeed();
  }
  
  public Item getItem(World llIllIIIlIllIll, BlockPos llIllIIIlIllIlI)
  {
    ;
    return llIllIIIlIllIIl.getSeed();
  }
  
  protected Item getSeed()
  {
    return Items.wheat_seeds;
  }
  
  private static boolean lIIllIlIl(int ???)
  {
    char llIlIlllllllIIl;
    return ??? > 0;
  }
  
  public void dropBlockAsItemWithChance(World llIllIIIlllIllI, BlockPos llIllIIIlllIlIl, IBlockState llIllIIIlllIlII, float llIllIIIlllIIll, int llIllIIIllIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llIllIIIllIlllI.dropBlockAsItemWithChance(llIllIIIlllIllI, llIllIIIlllIlIl, llIllIIIlllIlII, llIllIIIlllIIll, llIIIIl[0]);
    if (lIIllIIll(isRemote))
    {
      int llIllIIIlllIIIl = ((Integer)llIllIIIlllIlII.getValue(AGE)).intValue();
      if (lIIllIIIl(llIllIIIlllIIIl, llIIIIl[1]))
      {
        int llIllIIIlllIIII = llIIIIl[8] + llIllIIIllIlIIl;
        int llIllIIIllIllll = llIIIIl[0];
        "".length();
        if (null != null) {
          return;
        }
        while (!lIIllIIIl(llIllIIIllIllll, llIllIIIlllIIII))
        {
          if (lIIlllIII(rand.nextInt(llIIIIl[9]), llIllIIIlllIIIl)) {
            spawnAsEntity(llIllIIIlllIllI, llIllIIIlllIlIl, new ItemStack(llIllIIIllIlllI.getSeed(), llIIIIl[2], llIIIIl[0]));
          }
          llIllIIIllIllll++;
        }
      }
    }
  }
  
  public void grow(World llIllIIlIllllII, BlockPos llIllIIlIlllIll, IBlockState llIllIIlIllIllI)
  {
    ;
    ;
    ;
    ;
    int llIllIIlIlllIIl = ((Integer)llIllIIlIllIllI.getValue(AGE)).intValue() + MathHelper.getRandomIntegerInRange(rand, llIIIIl[4], llIIIIl[5]);
    if (lIIllIlII(llIllIIlIlllIIl, llIIIIl[1])) {
      llIllIIlIlllIIl = llIIIIl[1];
    }
    "".length();
  }
  
  protected Item getCrop()
  {
    return Items.wheat;
  }
  
  private static boolean lIIllIIIl(int ???, int arg1)
  {
    int i;
    byte llIllIIIIIlIIll;
    return ??? >= i;
  }
  
  private static void lIIlIllIl()
  {
    llIIIII = new String[llIIIIl[2]];
    llIIIII[llIIIIl[0]] = lIIlIlIlI("BSE1", "dFPFb");
  }
  
  public IBlockState getStateFromMeta(int llIllIIIIllllII)
  {
    ;
    ;
    return llIllIIIIllllIl.getDefaultState().withProperty(AGE, Integer.valueOf(llIllIIIIllllII));
  }
  
  private static void lIIlIllll()
  {
    llIIIIl = new int[10];
    llIIIIl[0] = ((0x80 ^ 0x92) & (0x2C ^ 0x3E ^ 0xFFFFFFFF));
    llIIIIl[1] = (0x3D ^ 0x3A);
    llIIIIl[2] = " ".length();
    llIIIIl[3] = (0x93 ^ 0xAB ^ 0xF0 ^ 0xC1);
    llIIIIl[4] = "  ".length();
    llIIIIl[5] = (0x27 ^ 0x22);
    llIIIIl[6] = (-" ".length());
    llIIIIl[7] = (0x52 ^ 0x54 ^ 0x19 ^ 0x17);
    llIIIIl[8] = "   ".length();
    llIIIIl[9] = (0xC9 ^ 0xAF ^ 0xED ^ 0x84);
  }
  
  private static String lIIlIlIlI(String llIllIIIIlIIIll, String llIllIIIIlIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llIllIIIIlIIIll = new String(Base64.getDecoder().decode(llIllIIIIlIIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llIllIIIIlIIllI = new StringBuilder();
    char[] llIllIIIIlIIlIl = llIllIIIIlIIIlI.toCharArray();
    int llIllIIIIlIIlII = llIIIIl[0];
    float llIllIIIIIllllI = llIllIIIIlIIIll.toCharArray();
    int llIllIIIIIlllIl = llIllIIIIIllllI.length;
    char llIllIIIIIlllII = llIIIIl[0];
    while (lIIllIIlI(llIllIIIIIlllII, llIllIIIIIlllIl))
    {
      char llIllIIIIlIlIIl = llIllIIIIIllllI[llIllIIIIIlllII];
      "".length();
      "".length();
      if ((0xC1 ^ 0x82 ^ 0x35 ^ 0x73) <= 0) {
        return null;
      }
    }
    return String.valueOf(llIllIIIIlIIllI);
  }
  
  protected BlockCrops()
  {
    llIllIIllIlllII.setDefaultState(blockState.getBaseState().withProperty(AGE, Integer.valueOf(llIIIIl[0])));
    "".length();
    float llIllIIllIlllIl = 0.5F;
    llIllIIllIlllII.setBlockBounds(0.5F - llIllIIllIlllIl, 0.0F, 0.5F - llIllIIllIlllIl, 0.5F + llIllIIllIlllIl, 0.25F, 0.5F + llIllIIllIlllIl);
    "".length();
    "".length();
    "".length();
    "".length();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llIllIIIIllIlII, new IProperty[] { AGE });
  }
  
  public boolean canUseBonemeal(World llIllIIIlIlIIII, Random llIllIIIlIIllll, BlockPos llIllIIIlIIlllI, IBlockState llIllIIIlIIllIl)
  {
    return llIIIIl[2];
  }
  
  private static boolean lIIllIlII(int ???, int arg1)
  {
    int i;
    double llIllIIIIIIIlll;
    return ??? > i;
  }
  
  private static boolean lIIllIIlI(int ???, int arg1)
  {
    int i;
    double llIllIIIIIIllll;
    return ??? < i;
  }
  
  public int getMetaFromState(IBlockState llIllIIIIllIllI)
  {
    ;
    return ((Integer)llIllIIIIllIllI.getValue(AGE)).intValue();
  }
  
  static
  {
    lIIlIllll();
    lIIlIllIl();
  }
  
  public boolean canGrow(World llIllIIIlIlIllI, BlockPos llIllIIIlIlIlIl, IBlockState llIllIIIlIlIlII, boolean llIllIIIlIlIIll)
  {
    ;
    if (lIIllIIlI(((Integer)llIllIIIlIlIlII.getValue(AGE)).intValue(), llIIIIl[1])) {
      return llIIIIl[2];
    }
    return llIIIIl[0];
  }
  
  protected boolean canPlaceBlockOn(Block llIllIIllIllIII)
  {
    ;
    if (lIIllIIII(llIllIIllIllIII, Blocks.farmland)) {
      return llIIIIl[2];
    }
    return llIIIIl[0];
  }
  
  private static boolean lIIlllIII(int ???, int arg1)
  {
    int i;
    double llIllIIIIIIlIll;
    return ??? <= i;
  }
  
  private static boolean lIIllIIII(Object ???, Object arg1)
  {
    Object localObject;
    Exception llIlIllllllllll;
    return ??? == localObject;
  }
  
  private static boolean lIIlllIIl(int ???, int arg1)
  {
    int i;
    double llIllIIIIIlIlll;
    return ??? == i;
  }
  
  public void updateTick(World llIllIIllIIlllI, BlockPos llIllIIllIIIllI, IBlockState llIllIIllIIIlIl, Random llIllIIllIIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llIllIIllIIlIII.updateTick(llIllIIllIIlllI, llIllIIllIIllIl, llIllIIllIIIlIl, llIllIIllIIIlII);
    if (lIIllIIIl(llIllIIllIIlllI.getLightFromNeighbors(llIllIIllIIllIl.up()), llIIIIl[3]))
    {
      int llIllIIllIIlIlI = ((Integer)llIllIIllIIIlIl.getValue(AGE)).intValue();
      if (lIIllIIlI(llIllIIllIIlIlI, llIIIIl[1]))
      {
        float llIllIIllIIlIIl = getGrowthChance(llIllIIllIIlIII, llIllIIllIIlllI, llIllIIllIIllIl);
        if (lIIllIIll(llIllIIllIIIlII.nextInt((int)(25.0F / llIllIIllIIlIIl) + llIIIIl[2]))) {
          "".length();
        }
      }
    }
  }
}

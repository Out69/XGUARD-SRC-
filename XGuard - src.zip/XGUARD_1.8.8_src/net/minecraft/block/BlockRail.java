package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockRail
  extends BlockRailBase
{
  public IProperty<BlockRailBase.EnumRailDirection> getShapeProperty()
  {
    return SHAPE;
  }
  
  private static boolean lIIllIIllllIll(int ???)
  {
    char lllllllllllllllIIIlIllIIlllIllIl;
    return ??? != 0;
  }
  
  protected void onNeighborChangedInternal(World lllllllllllllllIIIlIllIlIIIlIllI, BlockPos lllllllllllllllIIIlIllIlIIIlIlIl, IBlockState lllllllllllllllIIIlIllIlIIIIllll, Block lllllllllllllllIIIlIllIlIIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    if ((lIIllIIllllIll(lllllllllllllllIIIlIllIlIIIlIIll.canProvidePower())) && (lIIllIIlllllII(new BlockRailBase.Rail(lllllllllllllllIIIlIllIlIIIlIIlI, lllllllllllllllIIIlIllIlIIIlIllI, lllllllllllllllIIIlIllIlIIIlIIII, lllllllllllllllIIIlIllIlIIIIllll).countAdjacentRails(), llIIlIIlIIlI[1]))) {
      "".length();
    }
  }
  
  private static String lIIlIllIlIIlll(String lllllllllllllllIIIlIllIIllllIllI, String lllllllllllllllIIIlIllIIllllIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIIlIllIIlllllIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIlIllIIllllIlll.getBytes(StandardCharsets.UTF_8)), llIIlIIlIIlI[3]), "DES");
      Cipher lllllllllllllllIIIlIllIIlllllIlI = Cipher.getInstance("DES");
      lllllllllllllllIIIlIllIIlllllIlI.init(llIIlIIlIIlI[4], lllllllllllllllIIIlIllIIlllllIll);
      return new String(lllllllllllllllIIIlIllIIlllllIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIlIllIIllllIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIIlIllIIlllllIIl)
    {
      lllllllllllllllIIIlIllIIlllllIIl.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIIllIIllllIIl();
    lIIlIllIlIlIII();
  }
  
  private static void lIIllIIllllIIl()
  {
    llIIlIIlIIlI = new int[5];
    llIIlIIlIIlI[0] = (('' + 'Ñ' - 254 + 117 ^ 101 + 66 - 84 + 57) & ('¾' + 'È' - 252 + 88 ^ 70 + '©' - 79 + 16 ^ -" ".length()) & ((0x63 ^ 0x28 ^ 0x5E ^ 0x31) & (0x15 ^ 0x66 ^ 0x6D ^ 0x3A ^ -" ".length()) & ((0x24 ^ 0x2C ^ 0x2F ^ 0x1E) & (0x50 ^ 0x30 ^ 0xED ^ 0xB4 ^ -" ".length()) ^ -" ".length()) ^ -" ".length()));
    llIIlIIlIIlI[1] = "   ".length();
    llIIlIIlIIlI[2] = " ".length();
    llIIlIIlIIlI[3] = (0x71 ^ 0x31 ^ 0xEB ^ 0xA3);
    llIIlIIlIIlI[4] = "  ".length();
  }
  
  private static void lIIlIllIlIlIII()
  {
    llIIIlIlllIl = new String[llIIlIIlIIlI[2]];
    llIIIlIlllIl[llIIlIIlIIlI[0]] = lIIlIllIlIIlll("3C10AGFyZls=", "RkIwQ");
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIIIlIllIlIIIIIIII, new IProperty[] { SHAPE });
  }
  
  protected BlockRail()
  {
    lllllllllllllllIIIlIllIlIIIllllI.<init>(llIIlIIlIIlI[0]);
    lllllllllllllllIIIlIllIlIIIlllIl.setDefaultState(blockState.getBaseState().withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH));
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIIIlIllIlIIIIIlll)
  {
    ;
    ;
    return lllllllllllllllIIIlIllIlIIIIlIlI.getDefaultState().withProperty(SHAPE, BlockRailBase.EnumRailDirection.byMetadata(lllllllllllllllIIIlIllIlIIIIIlll));
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIIIlIllIlIIIIIlII)
  {
    ;
    return ((BlockRailBase.EnumRailDirection)lllllllllllllllIIIlIllIlIIIIIlII.getValue(SHAPE)).getMetadata();
  }
  
  private static boolean lIIllIIlllllII(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIIIlIllIIlllIllll;
    return ??? == i;
  }
}

package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;

public class BlockNetherrack
  extends Block
{
  public MapColor getMapColor(IBlockState lllllllllllllllIIIlIlIIIIlIllIIl)
  {
    return MapColor.netherrackColor;
  }
  
  public BlockNetherrack()
  {
    lllllllllllllllIIIlIlIIIIlIlllII.<init>(Material.rock);
    "".length();
  }
}

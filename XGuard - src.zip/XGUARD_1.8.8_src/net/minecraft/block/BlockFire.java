package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.WorldProviderEnd;

public class BlockFire
  extends Block
{
  private static boolean llIllIllIlIIII(int ???, int arg1)
  {
    int i;
    long llllllllllllllIlIIIllIlllIlIlIlI;
    return ??? < i;
  }
  
  public void randomDisplayTick(World llllllllllllllIlIIIllIlllllllllI, BlockPos llllllllllllllIlIIIlllIIIIIllIIl, IBlockState llllllllllllllIlIIIlllIIIIIllIII, Random llllllllllllllIlIIIlllIIIIIlIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIllIllIIllII(llllllllllllllIlIIIlllIIIIIlIlll.nextInt(lIIlIIIIIIllI[20]))) {
      llllllllllllllIlIIIllIlllllllllI.playSound(llllllllllllllIlIIIlllIIIIIllIIl.getX() + 0.5F, llllllllllllllIlIIIlllIIIIIllIIl.getY() + 0.5F, llllllllllllllIlIIIlllIIIIIllIIl.getZ() + 0.5F, lIIlIIIIIIlII[lIIlIIIIIIllI[21]], 1.0F + llllllllllllllIlIIIlllIIIIIlIlll.nextFloat(), llllllllllllllIlIIIlllIIIIIlIlll.nextFloat() * 0.7F + 0.3F, lIIlIIIIIIllI[0]);
    }
    if ((llIllIllIIllII(World.doesBlockHaveSolidTopSurface(llllllllllllllIlIIIllIlllllllllI, llllllllllllllIlIIIlllIIIIIllIIl.down()))) && (llIllIllIIllII(Blocks.fire.canCatchFire(llllllllllllllIlIIIllIlllllllllI, llllllllllllllIlIIIlllIIIIIllIIl.down()))))
    {
      if (llIllIllIIlllI(Blocks.fire.canCatchFire(llllllllllllllIlIIIllIlllllllllI, llllllllllllllIlIIIlllIIIIIllIIl.west())))
      {
        int llllllllllllllIlIIIlllIIIIIlIllI = lIIlIIIIIIllI[0];
        "".length();
        if (((0x95 ^ 0xC2) & (0xEA ^ 0xBD ^ 0xFFFFFFFF)) >= "  ".length()) {
          return;
        }
        while (!llIllIllIlIllI(llllllllllllllIlIIIlllIIIIIlIllI, lIIlIIIIIIllI[3]))
        {
          double llllllllllllllIlIIIlllIIIIIlIlIl = llllllllllllllIlIIIlllIIIIIllIIl.getX() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble() * 0.10000000149011612D;
          double llllllllllllllIlIIIlllIIIIIlIlII = llllllllllllllIlIIIlllIIIIIllIIl.getY() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
          double llllllllllllllIlIIIlllIIIIIlIIll = llllllllllllllIlIIIlllIIIIIllIIl.getZ() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
          llllllllllllllIlIIIllIlllllllllI.spawnParticle(EnumParticleTypes.SMOKE_LARGE, llllllllllllllIlIIIlllIIIIIlIlIl, llllllllllllllIlIIIlllIIIIIlIlII, llllllllllllllIlIIIlllIIIIIlIIll, 0.0D, 0.0D, 0.0D, new int[lIIlIIIIIIllI[0]]);
          llllllllllllllIlIIIlllIIIIIlIllI++;
        }
      }
      if (llIllIllIIlllI(Blocks.fire.canCatchFire(llllllllllllllIlIIIllIlllllllllI, llllllllllllllIlIIIlllIIIIIllIIl.east())))
      {
        int llllllllllllllIlIIIlllIIIIIlIIlI = lIIlIIIIIIllI[0];
        "".length();
        if (((0x60 ^ 0x3C) & (0x42 ^ 0x1E ^ 0xFFFFFFFF)) > 0) {
          return;
        }
        while (!llIllIllIlIllI(llllllllllllllIlIIIlllIIIIIlIIlI, lIIlIIIIIIllI[3]))
        {
          double llllllllllllllIlIIIlllIIIIIlIIIl = llllllllllllllIlIIIlllIIIIIllIIl.getX() + lIIlIIIIIIllI[2] - llllllllllllllIlIIIlllIIIIIlIlll.nextDouble() * 0.10000000149011612D;
          double llllllllllllllIlIIIlllIIIIIlIIII = llllllllllllllIlIIIlllIIIIIllIIl.getY() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
          double llllllllllllllIlIIIlllIIIIIIllll = llllllllllllllIlIIIlllIIIIIllIIl.getZ() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
          llllllllllllllIlIIIllIlllllllllI.spawnParticle(EnumParticleTypes.SMOKE_LARGE, llllllllllllllIlIIIlllIIIIIlIIIl, llllllllllllllIlIIIlllIIIIIlIIII, llllllllllllllIlIIIlllIIIIIIllll, 0.0D, 0.0D, 0.0D, new int[lIIlIIIIIIllI[0]]);
          llllllllllllllIlIIIlllIIIIIlIIlI++;
        }
      }
      if (llIllIllIIlllI(Blocks.fire.canCatchFire(llllllllllllllIlIIIllIlllllllllI, llllllllllllllIlIIIlllIIIIIllIIl.north())))
      {
        int llllllllllllllIlIIIlllIIIIIIlllI = lIIlIIIIIIllI[0];
        "".length();
        if ("   ".length() <= -" ".length()) {
          return;
        }
        while (!llIllIllIlIllI(llllllllllllllIlIIIlllIIIIIIlllI, lIIlIIIIIIllI[3]))
        {
          double llllllllllllllIlIIIlllIIIIIIllIl = llllllllllllllIlIIIlllIIIIIllIIl.getX() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
          double llllllllllllllIlIIIlllIIIIIIllII = llllllllllllllIlIIIlllIIIIIllIIl.getY() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
          double llllllllllllllIlIIIlllIIIIIIlIll = llllllllllllllIlIIIlllIIIIIllIIl.getZ() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble() * 0.10000000149011612D;
          llllllllllllllIlIIIllIlllllllllI.spawnParticle(EnumParticleTypes.SMOKE_LARGE, llllllllllllllIlIIIlllIIIIIIllIl, llllllllllllllIlIIIlllIIIIIIllII, llllllllllllllIlIIIlllIIIIIIlIll, 0.0D, 0.0D, 0.0D, new int[lIIlIIIIIIllI[0]]);
          llllllllllllllIlIIIlllIIIIIIlllI++;
        }
      }
      if (llIllIllIIlllI(Blocks.fire.canCatchFire(llllllllllllllIlIIIllIlllllllllI, llllllllllllllIlIIIlllIIIIIllIIl.south())))
      {
        int llllllllllllllIlIIIlllIIIIIIlIlI = lIIlIIIIIIllI[0];
        "".length();
        if (((76 + 107 - 80 + 56 ^ 48 + 34 - 78 + 171) & (0xC2 ^ 0xC4 ^ 0x59 ^ 0x6F ^ -" ".length())) >= "   ".length()) {
          return;
        }
        while (!llIllIllIlIllI(llllllllllllllIlIIIlllIIIIIIlIlI, lIIlIIIIIIllI[3]))
        {
          double llllllllllllllIlIIIlllIIIIIIlIIl = llllllllllllllIlIIIlllIIIIIllIIl.getX() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
          double llllllllllllllIlIIIlllIIIIIIlIII = llllllllllllllIlIIIlllIIIIIllIIl.getY() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
          double llllllllllllllIlIIIlllIIIIIIIlll = llllllllllllllIlIIIlllIIIIIllIIl.getZ() + lIIlIIIIIIllI[2] - llllllllllllllIlIIIlllIIIIIlIlll.nextDouble() * 0.10000000149011612D;
          llllllllllllllIlIIIllIlllllllllI.spawnParticle(EnumParticleTypes.SMOKE_LARGE, llllllllllllllIlIIIlllIIIIIIlIIl, llllllllllllllIlIIIlllIIIIIIlIII, llllllllllllllIlIIIlllIIIIIIIlll, 0.0D, 0.0D, 0.0D, new int[lIIlIIIIIIllI[0]]);
          llllllllllllllIlIIIlllIIIIIIlIlI++;
        }
      }
      if (llIllIllIIlllI(Blocks.fire.canCatchFire(llllllllllllllIlIIIllIlllllllllI, llllllllllllllIlIIIlllIIIIIllIIl.up())))
      {
        int llllllllllllllIlIIIlllIIIIIIIllI = lIIlIIIIIIllI[0];
        "".length();
        if ("  ".length() < "  ".length()) {
          return;
        }
        while (!llIllIllIlIllI(llllllllllllllIlIIIlllIIIIIIIllI, lIIlIIIIIIllI[3]))
        {
          double llllllllllllllIlIIIlllIIIIIIIlIl = llllllllllllllIlIIIlllIIIIIllIIl.getX() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
          double llllllllllllllIlIIIlllIIIIIIIlII = llllllllllllllIlIIIlllIIIIIllIIl.getY() + lIIlIIIIIIllI[2] - llllllllllllllIlIIIlllIIIIIlIlll.nextDouble() * 0.10000000149011612D;
          double llllllllllllllIlIIIlllIIIIIIIIll = llllllllllllllIlIIIlllIIIIIllIIl.getZ() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
          llllllllllllllIlIIIllIlllllllllI.spawnParticle(EnumParticleTypes.SMOKE_LARGE, llllllllllllllIlIIIlllIIIIIIIlIl, llllllllllllllIlIIIlllIIIIIIIlII, llllllllllllllIlIIIlllIIIIIIIIll, 0.0D, 0.0D, 0.0D, new int[lIIlIIIIIIllI[0]]);
          llllllllllllllIlIIIlllIIIIIIIllI++;
        }
        "".length();
        if (-"  ".length() <= 0) {}
      }
    }
    else
    {
      int llllllllllllllIlIIIlllIIIIIIIIlI = lIIlIIIIIIllI[0];
      "".length();
      if (((43 + 30 - 40 + 145 ^ 80 + 119 - 67 + 14) & (0x65 ^ 0x5 ^ 0x64 ^ 0x24 ^ -" ".length())) == (0xF ^ 0x47 ^ 0x50 ^ 0x1C)) {
        return;
      }
      while (!llIllIllIlIllI(llllllllllllllIlIIIlllIIIIIIIIlI, lIIlIIIIIIllI[4]))
      {
        double llllllllllllllIlIIIlllIIIIIIIIIl = llllllllllllllIlIIIlllIIIIIllIIl.getX() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
        double llllllllllllllIlIIIlllIIIIIIIIII = llllllllllllllIlIIIlllIIIIIllIIl.getY() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble() * 0.5D + 0.5D;
        double llllllllllllllIlIIIllIllllllllll = llllllllllllllIlIIIlllIIIIIllIIl.getZ() + llllllllllllllIlIIIlllIIIIIlIlll.nextDouble();
        llllllllllllllIlIIIllIlllllllllI.spawnParticle(EnumParticleTypes.SMOKE_LARGE, llllllllllllllIlIIIlllIIIIIIIIIl, llllllllllllllIlIIIlllIIIIIIIIII, llllllllllllllIlIIIllIllllllllll, 0.0D, 0.0D, 0.0D, new int[lIIlIIIIIIllI[0]]);
        llllllllllllllIlIIIlllIIIIIIIIlI++;
      }
    }
  }
  
  public boolean isFullCube()
  {
    return lIIlIIIIIIllI[0];
  }
  
  protected BlockFire()
  {
    llllllllllllllIlIIIlllIIllllIlII.<init>(Material.fire);
    llllllllllllllIlIIIlllIIllllIIll.setDefaultState(blockState.getBaseState().withProperty(AGE, Integer.valueOf(lIIlIIIIIIllI[0])).withProperty(FLIP, Boolean.valueOf(lIIlIIIIIIllI[0])).withProperty(ALT, Boolean.valueOf(lIIlIIIIIIllI[0])).withProperty(NORTH, Boolean.valueOf(lIIlIIIIIIllI[0])).withProperty(EAST, Boolean.valueOf(lIIlIIIIIIllI[0])).withProperty(SOUTH, Boolean.valueOf(lIIlIIIIIIllI[0])).withProperty(WEST, Boolean.valueOf(lIIlIIIIIIllI[0])).withProperty(UPPER, Integer.valueOf(lIIlIIIIIIllI[0])));
    "".length();
  }
  
  private static String llIllIllIIIlII(String llllllllllllllIlIIIllIllllIIlIII, String llllllllllllllIlIIIllIllllIIIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIIllIllllIIlIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIIllIllllIIIlIl.getBytes(StandardCharsets.UTF_8)), lIIlIIIIIIllI[13]), "DES");
      Cipher llllllllllllllIlIIIllIllllIIlIlI = Cipher.getInstance("DES");
      llllllllllllllIlIIIllIllllIIlIlI.init(lIIlIIIIIIllI[3], llllllllllllllIlIIIllIllllIIlIll);
      return new String(llllllllllllllIlIIIllIllllIIlIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIIllIllllIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIIllIllllIIlIIl)
    {
      llllllllllllllIlIIIllIllllIIlIIl.printStackTrace();
    }
    return null;
  }
  
  public int tickRate(World llllllllllllllIlIIIlllIIllIlllIl)
  {
    return lIIlIIIIIIllI[10];
  }
  
  private static boolean llIllIllIlIlII(Object ???)
  {
    short llllllllllllllIlIIIllIlllIIlllII;
    return ??? == null;
  }
  
  public boolean canPlaceBlockAt(World llllllllllllllIlIIIlllIIIIllllII, BlockPos llllllllllllllIlIIIlllIIIIlllIII)
  {
    ;
    ;
    ;
    if ((llIllIllIIllII(World.doesBlockHaveSolidTopSurface(llllllllllllllIlIIIlllIIIIllllII, llllllllllllllIlIIIlllIIIIlllIII.down()))) && (llIllIllIIllII(llllllllllllllIlIIIlllIIIIlllIlI.canNeighborCatchFire(llllllllllllllIlIIIlllIIIIlllIIl, llllllllllllllIlIIIlllIIIIlllIII)))) {
      return lIIlIIIIIIllI[0];
    }
    return lIIlIIIIIIllI[2];
  }
  
  public void onBlockAdded(World llllllllllllllIlIIIlllIIIIlIlIII, BlockPos llllllllllllllIlIIIlllIIIIlIIlll, IBlockState llllllllllllllIlIIIlllIIIIlIIllI)
  {
    ;
    ;
    ;
    if ((!llIllIllIlIlll(provider.getDimensionId())) || (llIllIllIIllII(Blocks.portal.func_176548_d(llllllllllllllIlIIIlllIIIIlIlIII, llllllllllllllIlIIIlllIIIIlIIlll)))) {
      if ((llIllIllIIllII(World.doesBlockHaveSolidTopSurface(llllllllllllllIlIIIlllIIIIlIlIII, llllllllllllllIlIIIlllIIIIlIIlll.down()))) && (llIllIllIIllII(llllllllllllllIlIIIlllIIIIlIIlIl.canNeighborCatchFire(llllllllllllllIlIIIlllIIIIlIlIII, llllllllllllllIlIIIlllIIIIlIIlll))))
      {
        "".length();
        "".length();
        if ((0x90 ^ 0xA2 ^ 0xA5 ^ 0x93) >= 0) {}
      }
      else
      {
        llllllllllllllIlIIIlllIIIIlIlIII.scheduleUpdate(llllllllllllllIlIIIlllIIIIlIIlll, llllllllllllllIlIIIlllIIIIlIIlIl, llllllllllllllIlIIIlllIIIIlIIlIl.tickRate(llllllllllllllIlIIIlllIIIIlIlIII) + rand.nextInt(lIIlIIIIIIllI[14]));
      }
    }
  }
  
  private boolean canNeighborCatchFire(World llllllllllllllIlIIIlllIIIllIlIIl, BlockPos llllllllllllllIlIIIlllIIIllIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    String llllllllllllllIlIIIlllIIIllIIIIl = (llllllllllllllIlIIIlllIIIllIIIII = EnumFacing.values()).length;
    Exception llllllllllllllIlIIIlllIIIllIIIlI = lIIlIIIIIIllI[0];
    "".length();
    if ("   ".length() == 0) {
      return ('¯' + '' - 274 + 174 ^ '' + 126 - 153 + 32) & (0x25 ^ 0x3D ^ 0xDC ^ 0x83 ^ -" ".length());
    }
    while (!llIllIllIlIllI(llllllllllllllIlIIIlllIIIllIIIlI, llllllllllllllIlIIIlllIIIllIIIIl))
    {
      EnumFacing llllllllllllllIlIIIlllIIIllIIlll = llllllllllllllIlIIIlllIIIllIIIII[llllllllllllllIlIIIlllIIIllIIIlI];
      if (llIllIllIIlllI(llllllllllllllIlIIIlllIIIllIlIlI.canCatchFire(llllllllllllllIlIIIlllIIIllIIlIl, llllllllllllllIlIIIlllIIIllIlIII.offset(llllllllllllllIlIIIlllIIIllIIlll)))) {
        return lIIlIIIIIIllI[2];
      }
      llllllllllllllIlIIIlllIIIllIIIlI++;
    }
    return lIIlIIIIIIllI[0];
  }
  
  private int getNeighborEncouragement(World llllllllllllllIlIIIlllIIIlIlIIIl, BlockPos llllllllllllllIlIIIlllIIIlIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIllIllIIllII(llllllllllllllIlIIIlllIIIlIlIIIl.isAirBlock(llllllllllllllIlIIIlllIIIlIlIIII))) {
      return lIIlIIIIIIllI[0];
    }
    int llllllllllllllIlIIIlllIIIlIlIlII = lIIlIIIIIIllI[0];
    String llllllllllllllIlIIIlllIIIlIIllII = (llllllllllllllIlIIIlllIIIlIIlIll = EnumFacing.values()).length;
    byte llllllllllllllIlIIIlllIIIlIIllIl = lIIlIIIIIIllI[0];
    "".length();
    if (" ".length() >= (0x42 ^ 0x46)) {
      return (0x81 ^ 0x8B) & (0x86 ^ 0x8C ^ 0xFFFFFFFF);
    }
    while (!llIllIllIlIllI(llllllllllllllIlIIIlllIIIlIIllIl, llllllllllllllIlIIIlllIIIlIIllII))
    {
      EnumFacing llllllllllllllIlIIIlllIIIlIlIIll = llllllllllllllIlIIIlllIIIlIIlIll[llllllllllllllIlIIIlllIIIlIIllIl];
      llllllllllllllIlIIIlllIIIlIlIlII = Math.max(llllllllllllllIlIIIlllIIIlIlIlll.getEncouragement(llllllllllllllIlIIIlllIIIlIlIllI.getBlockState(llllllllllllllIlIIIlllIIIlIlIIII.offset(llllllllllllllIlIIIlllIIIlIlIIll)).getBlock()), llllllllllllllIlIIIlllIIIlIlIlII);
      llllllllllllllIlIIIlllIIIlIIllIl++;
    }
    return llllllllllllllIlIIIlllIIIlIlIlII;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIlIIIllIlllllIlIII, new IProperty[] { AGE, NORTH, EAST, SOUTH, WEST, UPPER, FLIP, ALT });
  }
  
  public void setFireInfo(Block llllllllllllllIlIIIlllIIlllIlIIl, int llllllllllllllIlIIIlllIIlllIllII, int llllllllllllllIlIIIlllIIlllIIlll)
  {
    ;
    ;
    ;
    ;
    "".length();
    "".length();
  }
  
  public boolean canCatchFire(IBlockAccess llllllllllllllIlIIIlllIIIlIIIlIl, BlockPos llllllllllllllIlIIIlllIIIlIIIlII)
  {
    ;
    ;
    ;
    if (llIllIllIlIIlI(llllllllllllllIlIIIlllIIIlIIIllI.getEncouragement(llllllllllllllIlIIIlllIIIlIIIIlI.getBlockState(llllllllllllllIlIIIlllIIIlIIIlII).getBlock()))) {
      return lIIlIIIIIIllI[2];
    }
    return lIIlIIIIIIllI[0];
  }
  
  private static boolean llIllIllIlIIll(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlIIIllIlllIlIIllI;
    return ??? <= i;
  }
  
  private static void llIllIllIIlIll()
  {
    lIIlIIIIIIllI = new int[22];
    lIIlIIIIIIllI[0] = ("   ".length() & ("   ".length() ^ 0xFFFFFFFF));
    lIIlIIIIIIllI[1] = (0x5A ^ 0x49 ^ 0x52 ^ 0x4E);
    lIIlIIIIIIllI[2] = " ".length();
    lIIlIIIIIIllI[3] = "  ".length();
    lIIlIIIIIIllI[4] = "   ".length();
    lIIlIIIIIIllI[5] = (47 + 78 - 27 + 83 ^ '' + 123 - 142 + 67);
    lIIlIIIIIIllI[6] = (0x71 ^ 0x74);
    lIIlIIIIIIllI[7] = (0xA ^ 0xC);
    lIIlIIIIIIllI[8] = (0x95 ^ 0x92);
    lIIlIIIIIIllI[9] = (67 + 121 - 176 + 119 ^ 112 + 69 - 75 + 45);
    lIIlIIIIIIllI[10] = (0xB9 ^ 0xA7);
    lIIlIIIIIIllI[11] = (107 + 91 - 144 + 112 ^ 65 + 80 - 119 + 128);
    lIIlIIIIIIllI[12] = (0xD9 ^ 0xBD);
    lIIlIIIIIIllI[13] = (0x3C ^ 0x52 ^ 0xF ^ 0x69);
    lIIlIIIIIIllI[14] = (0x56 ^ 0x5C);
    lIIlIIIIIIllI[15] = (-(0x21 ^ 0x13));
    lIIlIIIIIIllI[16] = (-(0xCBD7 & 0x7EFC) & 0xEFFF & 0x5BFF);
    lIIlIIIIIIllI[17] = ('¢' + 'Ó' - 366 + 243);
    lIIlIIIIIIllI[18] = (-" ".length());
    lIIlIIIIIIllI[19] = (0x96 ^ 0x9F ^ 0xBE ^ 0x9F);
    lIIlIIIIIIllI[20] = (125 + 60 - 97 + 84 ^ 112 + 69 - 78 + 77);
    lIIlIIIIIIllI[21] = (0xD4 ^ 0xA9 ^ 0xC8 ^ 0xBC);
  }
  
  public void onNeighborBlockChange(World llllllllllllllIlIIIlllIIIIllIIll, BlockPos llllllllllllllIlIIIlllIIIIllIIlI, IBlockState llllllllllllllIlIIIlllIIIIllIIIl, Block llllllllllllllIlIIIlllIIIIllIIII)
  {
    ;
    ;
    ;
    if ((llIllIllIIllII(World.doesBlockHaveSolidTopSurface(llllllllllllllIlIIIlllIIIIllIIll, llllllllllllllIlIIIlllIIIIlIllIl.down()))) && (llIllIllIIllII(llllllllllllllIlIIIlllIIIIlIllll.canNeighborCatchFire(llllllllllllllIlIIIlllIIIIllIIll, llllllllllllllIlIIIlllIIIIlIllIl)))) {
      "".length();
    }
  }
  
  private static boolean llIllIllIlIIIl(int ???, int arg1)
  {
    int i;
    char llllllllllllllIlIIIllIlllIlIIIlI;
    return ??? > i;
  }
  
  private static boolean llIllIllIlIlll(int ???)
  {
    byte llllllllllllllIlIIIllIlllIIlIllI;
    return ??? <= 0;
  }
  
  static
  {
    llIllIllIIlIll();
    llIllIllIIIlll();
    AGE = PropertyInteger.create(lIIlIIIIIIlII[lIIlIIIIIIllI[0]], lIIlIIIIIIllI[0], lIIlIIIIIIllI[1]);
    FLIP = PropertyBool.create(lIIlIIIIIIlII[lIIlIIIIIIllI[2]]);
    ALT = PropertyBool.create(lIIlIIIIIIlII[lIIlIIIIIIllI[3]]);
    NORTH = PropertyBool.create(lIIlIIIIIIlII[lIIlIIIIIIllI[4]]);
    EAST = PropertyBool.create(lIIlIIIIIIlII[lIIlIIIIIIllI[5]]);
    SOUTH = PropertyBool.create(lIIlIIIIIIlII[lIIlIIIIIIllI[6]]);
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIlIIIllIlllllIllll)
  {
    ;
    ;
    return llllllllllllllIlIIIllIllllllIIlI.getDefaultState().withProperty(AGE, Integer.valueOf(llllllllllllllIlIIIllIlllllIllll));
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIlIIIllIlllllIlIll)
  {
    ;
    return ((Integer)llllllllllllllIlIIIllIlllllIlIll.getValue(AGE)).intValue();
  }
  
  private static boolean llIllIllIlIIlI(int ???)
  {
    short llllllllllllllIlIIIllIlllIIlIlII;
    return ??? > 0;
  }
  
  private int getFlammability(Block llllllllllllllIlIIIlllIIlIIllIlI)
  {
    ;
    ;
    ;
    Integer llllllllllllllIlIIIlllIIlIIllIIl = (Integer)flammabilities.get(llllllllllllllIlIIIlllIIlIIllIlI);
    if (llIllIllIlIlII(llllllllllllllIlIIIlllIIlIIllIIl))
    {
      "".length();
      if ("  ".length() != " ".length()) {
        break label67;
      }
      return (0xA4 ^ 0xB5) & (0xAA ^ 0xBB ^ 0xFFFFFFFF);
    }
    label67:
    return llllllllllllllIlIIIlllIIlIIllIIl.intValue();
  }
  
  private static boolean llIllIllIIllIl(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIlIIIllIlllIllIIlI;
    return ??? == i;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIlIIIlllIIlllIIlIl, BlockPos llllllllllllllIlIIIlllIIlllIIlII, IBlockState llllllllllllllIlIIIlllIIlllIIIll)
  {
    return null;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public boolean requiresUpdates()
  {
    return lIIlIIIIIIllI[0];
  }
  
  private void catchOnFire(World llllllllllllllIlIIIlllIIlIIIIIlI, BlockPos llllllllllllllIlIIIlllIIIllllIII, int llllllllllllllIlIIIlllIIlIIIIIII, Random llllllllllllllIlIIIlllIIIlllIllI, int llllllllllllllIlIIIlllIIIlllIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIIIlllIIIlllllIl = llllllllllllllIlIIIlllIIlIIIIIll.getFlammability(llllllllllllllIlIIIlllIIlIIIIIlI.getBlockState(llllllllllllllIlIIIlllIIIllllIII).getBlock());
    if (llIllIllIlIIII(llllllllllllllIlIIIlllIIIlllIllI.nextInt(llllllllllllllIlIIIlllIIlIIIIIII), llllllllllllllIlIIIlllIIIlllllIl))
    {
      IBlockState llllllllllllllIlIIIlllIIIlllllII = llllllllllllllIlIIIlllIIlIIIIIlI.getBlockState(llllllllllllllIlIIIlllIIIllllIII);
      if ((llIllIllIlIIII(llllllllllllllIlIIIlllIIIlllIllI.nextInt(llllllllllllllIlIIIlllIIIlllIlIl + lIIlIIIIIIllI[14]), lIIlIIIIIIllI[6])) && (llIllIllIIllII(llllllllllllllIlIIIlllIIlIIIIIlI.canLightningStrike(llllllllllllllIlIIIlllIIIllllIII))))
      {
        int llllllllllllllIlIIIlllIIIllllIll = llllllllllllllIlIIIlllIIIlllIlIl + llllllllllllllIlIIIlllIIIlllIllI.nextInt(lIIlIIIIIIllI[6]) / lIIlIIIIIIllI[5];
        if (llIllIllIlIIIl(llllllllllllllIlIIIlllIIIllllIll, lIIlIIIIIIllI[1])) {
          llllllllllllllIlIIIlllIIIllllIll = lIIlIIIIIIllI[1];
        }
        "".length();
        "".length();
        if ((0xF4 ^ 0x99 ^ 0xF9 ^ 0x90) >= 0) {}
      }
      else
      {
        "".length();
      }
      if (llIllIllIIllll(llllllllllllllIlIIIlllIIIlllllII.getBlock(), Blocks.tnt)) {
        Blocks.tnt.onBlockDestroyedByPlayer(llllllllllllllIlIIIlllIIlIIIIIlI, llllllllllllllIlIIIlllIIIllllIII, llllllllllllllIlIIIlllIIIlllllII.withProperty(BlockTNT.EXPLODE, Boolean.valueOf(lIIlIIIIIIllI[2])));
      }
    }
  }
  
  public void updateTick(World llllllllllllllIlIIIlllIIlIllIlll, BlockPos llllllllllllllIlIIIlllIIlIllIllI, IBlockState llllllllllllllIlIIIlllIIlIllIlIl, Random llllllllllllllIlIIIlllIIllIIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIllIllIIlllI(llllllllllllllIlIIIlllIIlIllIlll.getGameRules().getBoolean(lIIlIIIIIIlII[lIIlIIIIIIllI[13]])))
    {
      if (llIllIllIIllII(llllllllllllllIlIIIlllIIlIlllIII.canPlaceBlockAt(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIllIIlIII))) {
        "".length();
      }
      Block llllllllllllllIlIIIlllIIllIIIlIl = llllllllllllllIlIIIlllIIlIllIlll.getBlockState(llllllllllllllIlIIIlllIIllIIlIII.down()).getBlock();
      if (llIllIllIIllll(llllllllllllllIlIIIlllIIllIIIlIl, Blocks.netherrack))
      {
        "".length();
        if (" ".length() >= 0) {
          break label97;
        }
      }
      label97:
      boolean llllllllllllllIlIIIlllIIllIIIlII = lIIlIIIIIIllI[0];
      if ((llIllIllIIlllI(provider instanceof WorldProviderEnd)) && (llIllIllIIllll(llllllllllllllIlIIIlllIIllIIIlIl, Blocks.bedrock))) {
        llllllllllllllIlIIIlllIIllIIIlII = lIIlIIIIIIllI[2];
      }
      if ((llIllIllIIllII(llllllllllllllIlIIIlllIIllIIIlII)) && (llIllIllIIlllI(llllllllllllllIlIIIlllIIlIllIlll.isRaining())) && (llIllIllIIlllI(llllllllllllllIlIIIlllIIlIlllIII.canDie(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIllIIlIII))))
      {
        "".length();
        "".length();
        if (-" ".length() != ((0x3A ^ 0x1B ^ 0x6A ^ 0x64) & (0x1F ^ 0x47 ^ 0xEC ^ 0x9B ^ -" ".length()))) {}
      }
      else
      {
        int llllllllllllllIlIIIlllIIllIIIIll = ((Integer)llllllllllllllIlIIIlllIIlIllIlIl.getValue(AGE)).intValue();
        if (llIllIllIlIIII(llllllllllllllIlIIIlllIIllIIIIll, lIIlIIIIIIllI[1]))
        {
          llllllllllllllIlIIIlllIIlIllIlIl = llllllllllllllIlIIIlllIIlIllIlIl.withProperty(AGE, Integer.valueOf(llllllllllllllIlIIIlllIIllIIIIll + llllllllllllllIlIIIlllIIllIIIllI.nextInt(lIIlIIIIIIllI[4]) / lIIlIIIIIIllI[3]));
          "".length();
        }
        llllllllllllllIlIIIlllIIlIllIlll.scheduleUpdate(llllllllllllllIlIIIlllIIllIIlIII, llllllllllllllIlIIIlllIIlIlllIII, llllllllllllllIlIIIlllIIlIlllIII.tickRate(llllllllllllllIlIIIlllIIlIllIlll) + llllllllllllllIlIIIlllIIllIIIllI.nextInt(lIIlIIIIIIllI[14]));
        if (llIllIllIIllII(llllllllllllllIlIIIlllIIllIIIlII))
        {
          if (llIllIllIIllII(llllllllllllllIlIIIlllIIlIlllIII.canNeighborCatchFire(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIllIIlIII)))
          {
            if ((!llIllIllIIlllI(World.doesBlockHaveSolidTopSurface(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIllIIlIII.down()))) || (llIllIllIlIIIl(llllllllllllllIlIIIlllIIllIIIIll, lIIlIIIIIIllI[4]))) {
              "".length();
            }
            return;
          }
          if ((llIllIllIIllII(llllllllllllllIlIIIlllIIlIlllIII.canCatchFire(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIllIIlIII.down()))) && (llIllIllIIllIl(llllllllllllllIlIIIlllIIllIIIIll, lIIlIIIIIIllI[1])) && (llIllIllIIllII(llllllllllllllIlIIIlllIIllIIIllI.nextInt(lIIlIIIIIIllI[5]))))
          {
            "".length();
            return;
          }
        }
        boolean llllllllllllllIlIIIlllIIllIIIIlI = llllllllllllllIlIIIlllIIlIllIlll.isBlockinHighHumidity(llllllllllllllIlIIIlllIIllIIlIII);
        int llllllllllllllIlIIIlllIIllIIIIIl = lIIlIIIIIIllI[0];
        if (llIllIllIIlllI(llllllllllllllIlIIIlllIIllIIIIlI)) {
          llllllllllllllIlIIIlllIIllIIIIIl = lIIlIIIIIIllI[15];
        }
        llllllllllllllIlIIIlllIIlIlllIII.catchOnFire(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIllIIlIII.east(), lIIlIIIIIIllI[16] + llllllllllllllIlIIIlllIIllIIIIIl, llllllllllllllIlIIIlllIIllIIIllI, llllllllllllllIlIIIlllIIllIIIIll);
        llllllllllllllIlIIIlllIIlIlllIII.catchOnFire(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIllIIlIII.west(), lIIlIIIIIIllI[16] + llllllllllllllIlIIIlllIIllIIIIIl, llllllllllllllIlIIIlllIIllIIIllI, llllllllllllllIlIIIlllIIllIIIIll);
        llllllllllllllIlIIIlllIIlIlllIII.catchOnFire(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIllIIlIII.down(), lIIlIIIIIIllI[17] + llllllllllllllIlIIIlllIIllIIIIIl, llllllllllllllIlIIIlllIIllIIIllI, llllllllllllllIlIIIlllIIllIIIIll);
        llllllllllllllIlIIIlllIIlIlllIII.catchOnFire(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIllIIlIII.up(), lIIlIIIIIIllI[17] + llllllllllllllIlIIIlllIIllIIIIIl, llllllllllllllIlIIIlllIIllIIIllI, llllllllllllllIlIIIlllIIllIIIIll);
        llllllllllllllIlIIIlllIIlIlllIII.catchOnFire(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIllIIlIII.north(), lIIlIIIIIIllI[16] + llllllllllllllIlIIIlllIIllIIIIIl, llllllllllllllIlIIIlllIIllIIIllI, llllllllllllllIlIIIlllIIllIIIIll);
        llllllllllllllIlIIIlllIIlIlllIII.catchOnFire(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIllIIlIII.south(), lIIlIIIIIIllI[16] + llllllllllllllIlIIIlllIIllIIIIIl, llllllllllllllIlIIIlllIIllIIIllI, llllllllllllllIlIIIlllIIllIIIIll);
        int llllllllllllllIlIIIlllIIllIIIIII = lIIlIIIIIIllI[18];
        "".length();
        if ((0x25 ^ 0x43 ^ 0x19 ^ 0x7B) <= 0) {
          return;
        }
        while (!llIllIllIlIIIl(llllllllllllllIlIIIlllIIllIIIIII, lIIlIIIIIIllI[2]))
        {
          int llllllllllllllIlIIIlllIIlIllllll = lIIlIIIIIIllI[18];
          "".length();
          if (null != null) {
            return;
          }
          while (!llIllIllIlIIIl(llllllllllllllIlIIIlllIIlIllllll, lIIlIIIIIIllI[2]))
          {
            int llllllllllllllIlIIIlllIIlIlllllI = lIIlIIIIIIllI[18];
            "".length();
            if (" ".length() <= 0) {
              return;
            }
            while (!llIllIllIlIIIl(llllllllllllllIlIIIlllIIlIlllllI, lIIlIIIIIIllI[5]))
            {
              if ((!llIllIllIIllII(llllllllllllllIlIIIlllIIllIIIIII)) || (!llIllIllIIllII(llllllllllllllIlIIIlllIIlIlllllI)) || (llIllIllIIlllI(llllllllllllllIlIIIlllIIlIllllll)))
              {
                int llllllllllllllIlIIIlllIIlIllllIl = lIIlIIIIIIllI[12];
                if (llIllIllIlIIIl(llllllllllllllIlIIIlllIIlIlllllI, lIIlIIIIIIllI[2])) {
                  llllllllllllllIlIIIlllIIlIllllIl += (llllllllllllllIlIIIlllIIlIlllllI - lIIlIIIIIIllI[2]) * lIIlIIIIIIllI[12];
                }
                BlockPos llllllllllllllIlIIIlllIIlIllllII = llllllllllllllIlIIIlllIIllIIlIII.add(llllllllllllllIlIIIlllIIllIIIIII, llllllllllllllIlIIIlllIIlIlllllI, llllllllllllllIlIIIlllIIlIllllll);
                int llllllllllllllIlIIIlllIIlIlllIll = llllllllllllllIlIIIlllIIlIlllIII.getNeighborEncouragement(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIlIllllII);
                if (llIllIllIlIIlI(llllllllllllllIlIIIlllIIlIlllIll))
                {
                  int llllllllllllllIlIIIlllIIlIlllIlI = (llllllllllllllIlIIIlllIIlIlllIll + lIIlIIIIIIllI[19] + llllllllllllllIlIIIlllIIlIllIlll.getDifficulty().getDifficultyId() * lIIlIIIIIIllI[8]) / (llllllllllllllIlIIIlllIIllIIIIll + lIIlIIIIIIllI[10]);
                  if (llIllIllIIlllI(llllllllllllllIlIIIlllIIllIIIIlI)) {
                    llllllllllllllIlIIIlllIIlIlllIlI /= lIIlIIIIIIllI[3];
                  }
                  if ((llIllIllIlIIlI(llllllllllllllIlIIIlllIIlIlllIlI)) && (llIllIllIlIIll(llllllllllllllIlIIIlllIIllIIIllI.nextInt(llllllllllllllIlIIIlllIIlIllllIl), llllllllllllllIlIIIlllIIlIlllIlI)) && ((!llIllIllIIlllI(llllllllllllllIlIIIlllIIlIllIlll.isRaining())) || (llIllIllIIllII(llllllllllllllIlIIIlllIIlIlllIII.canDie(llllllllllllllIlIIIlllIIlIllIlll, llllllllllllllIlIIIlllIIlIllllII)))))
                  {
                    int llllllllllllllIlIIIlllIIlIlllIIl = llllllllllllllIlIIIlllIIllIIIIll + llllllllllllllIlIIIlllIIllIIIllI.nextInt(lIIlIIIIIIllI[6]) / lIIlIIIIIIllI[5];
                    if (llIllIllIlIIIl(llllllllllllllIlIIIlllIIlIlllIIl, lIIlIIIIIIllI[1])) {
                      llllllllllllllIlIIIlllIIlIlllIIl = lIIlIIIIIIllI[1];
                    }
                    "".length();
                  }
                }
              }
              llllllllllllllIlIIIlllIIlIlllllI++;
            }
          }
        }
      }
    }
  }
  
  private int getEncouragement(Block llllllllllllllIlIIIlllIIlIIIlllI)
  {
    ;
    ;
    ;
    Integer llllllllllllllIlIIIlllIIlIIlIIII = (Integer)encouragements.get(llllllllllllllIlIIIlllIIlIIIlllI);
    if (llIllIllIlIlII(llllllllllllllIlIIIlllIIlIIlIIII))
    {
      "".length();
      if (((0x7C ^ 0x67 ^ 0xE ^ 0x29) & (101 + 40 - 10 + 8 ^ 105 + 8 - -27 + 43 ^ -" ".length())) >= -" ".length()) {
        break label150;
      }
      return (0x80 ^ 0xA0 ^ 0xF9 ^ 0x98) & (0xDE ^ 0xAD ^ 0x43 ^ 0x71 ^ -" ".length()) & (" ".length() & (" ".length() ^ -" ".length()) ^ -" ".length());
    }
    label150:
    return llllllllllllllIlIIIlllIIlIIlIIII.intValue();
  }
  
  private static void llIllIllIIIlll()
  {
    lIIlIIIIIIlII = new String[lIIlIIIIIIllI[14]];
    lIIlIIIIIIlII[lIIlIIIIIIllI[0]] = llIllIllIIIlII("rEK+xyZjeMw=", "Ssush");
    lIIlIIIIIIlII[lIIlIIIIIIllI[2]] = llIllIllIIIlIl("2FmlbOKVnl0=", "IArIS");
    lIIlIIIIIIlII[lIIlIIIIIIllI[3]] = llIllIllIIIlII("4mFer4cb4fQ=", "EeSSb");
    lIIlIIIIIIlII[lIIlIIIIIIllI[4]] = llIllIllIIIlIl("jBv+GMg/kM8=", "BvNVS");
    lIIlIIIIIIlII[lIIlIIIIIIllI[5]] = llIllIllIIIlII("/tOrx6IgdMY=", "YQgYW");
    lIIlIIIIIIlII[lIIlIIIIIIllI[6]] = llIllIllIIIlIl("mYPfCkaEEzw=", "Bqjob");
    lIIlIIIIIIlII[lIIlIIIIIIllI[7]] = llIllIllIIIlIl("t2SBuVA2SzU=", "bMePX");
    lIIlIIIIIIlII[lIIlIIIIIIllI[8]] = llIllIllIIIlIl("ZkblEIYF4IY=", "YmBWW");
    lIIlIIIIIIlII[lIIlIIIIIIllI[13]] = llIllIllIIIllI("ASIIBCMAGScOOg==", "eMNmQ");
    lIIlIIIIIIlII[lIIlIIIIIIllI[21]] = llIllIllIIIlII("M7tpoCwkvwLYKVQqNnOL/w==", "fHmmJ");
  }
  
  private static boolean llIllIllIlIllI(int ???, int arg1)
  {
    int i;
    long llllllllllllllIlIIIllIlllIlIlllI;
    return ??? >= i;
  }
  
  private static boolean llIllIllIIllll(Object ???, Object arg1)
  {
    Object localObject;
    boolean llllllllllllllIlIIIllIlllIIllllI;
    return ??? == localObject;
  }
  
  public boolean isCollidable()
  {
    return lIIlIIIIIIllI[0];
  }
  
  private static boolean llIllIllIIllII(int ???)
  {
    byte llllllllllllllIlIIIllIlllIIllIII;
    return ??? == 0;
  }
  
  public boolean isOpaqueCube()
  {
    return lIIlIIIIIIllI[0];
  }
  
  public static void init()
  {
    Blocks.fire.setFireInfo(Blocks.planks, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.double_wooden_slab, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.wooden_slab, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.oak_fence_gate, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.spruce_fence_gate, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.birch_fence_gate, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.jungle_fence_gate, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.dark_oak_fence_gate, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.acacia_fence_gate, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.oak_fence, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.spruce_fence, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.birch_fence, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.jungle_fence, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.dark_oak_fence, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.acacia_fence, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.oak_stairs, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.birch_stairs, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.spruce_stairs, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.jungle_stairs, lIIlIIIIIIllI[6], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.log, lIIlIIIIIIllI[6], lIIlIIIIIIllI[6]);
    Blocks.fire.setFireInfo(Blocks.log2, lIIlIIIIIIllI[6], lIIlIIIIIIllI[6]);
    Blocks.fire.setFireInfo(Blocks.leaves, lIIlIIIIIIllI[10], lIIlIIIIIIllI[11]);
    Blocks.fire.setFireInfo(Blocks.leaves2, lIIlIIIIIIllI[10], lIIlIIIIIIllI[11]);
    Blocks.fire.setFireInfo(Blocks.bookshelf, lIIlIIIIIIllI[10], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.tnt, lIIlIIIIIIllI[1], lIIlIIIIIIllI[12]);
    Blocks.fire.setFireInfo(Blocks.tallgrass, lIIlIIIIIIllI[11], lIIlIIIIIIllI[12]);
    Blocks.fire.setFireInfo(Blocks.double_plant, lIIlIIIIIIllI[11], lIIlIIIIIIllI[12]);
    Blocks.fire.setFireInfo(Blocks.yellow_flower, lIIlIIIIIIllI[11], lIIlIIIIIIllI[12]);
    Blocks.fire.setFireInfo(Blocks.red_flower, lIIlIIIIIIllI[11], lIIlIIIIIIllI[12]);
    Blocks.fire.setFireInfo(Blocks.deadbush, lIIlIIIIIIllI[11], lIIlIIIIIIllI[12]);
    Blocks.fire.setFireInfo(Blocks.wool, lIIlIIIIIIllI[10], lIIlIIIIIIllI[11]);
    Blocks.fire.setFireInfo(Blocks.vine, lIIlIIIIIIllI[1], lIIlIIIIIIllI[12]);
    Blocks.fire.setFireInfo(Blocks.coal_block, lIIlIIIIIIllI[6], lIIlIIIIIIllI[6]);
    Blocks.fire.setFireInfo(Blocks.hay_block, lIIlIIIIIIllI[11], lIIlIIIIIIllI[9]);
    Blocks.fire.setFireInfo(Blocks.carpet, lIIlIIIIIIllI[11], lIIlIIIIIIllI[9]);
  }
  
  protected boolean canDie(World llllllllllllllIlIIIlllIIlIlIIIIl, BlockPos llllllllllllllIlIIIlllIIlIlIIIII)
  {
    ;
    ;
    if ((llIllIllIIllII(llllllllllllllIlIIIlllIIlIlIIIIl.canLightningStrike(llllllllllllllIlIIIlllIIlIlIIIII))) && (llIllIllIIllII(llllllllllllllIlIIIlllIIlIlIIIIl.canLightningStrike(llllllllllllllIlIIIlllIIlIlIIIII.west()))) && (llIllIllIIllII(llllllllllllllIlIIIlllIIlIlIIIIl.canLightningStrike(llllllllllllllIlIIIlllIIlIlIIIII.east()))) && (llIllIllIIllII(llllllllllllllIlIIIlllIIlIlIIIIl.canLightningStrike(llllllllllllllIlIIIlllIIlIlIIIII.north()))) && (llIllIllIIllII(llllllllllllllIlIIIlllIIlIlIIIIl.canLightningStrike(llllllllllllllIlIIIlllIIlIlIIIII.south())))) {
      return lIIlIIIIIIllI[0];
    }
    return lIIlIIIIIIllI[2];
  }
  
  public int quantityDropped(Random llllllllllllllIlIIIlllIIllIlllll)
  {
    return lIIlIIIIIIllI[0];
  }
  
  private static boolean llIllIllIIlllI(int ???)
  {
    char llllllllllllllIlIIIllIlllIIllIlI;
    return ??? != 0;
  }
  
  private static String llIllIllIIIllI(String llllllllllllllIlIIIllIllllIllIII, String llllllllllllllIlIIIllIllllIlIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIIllIllllIllIII = new String(Base64.getDecoder().decode(llllllllllllllIlIIIllIllllIllIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIIIllIllllIllIll = new StringBuilder();
    char[] llllllllllllllIlIIIllIllllIllIlI = llllllllllllllIlIIIllIllllIlIlll.toCharArray();
    int llllllllllllllIlIIIllIllllIllIIl = lIIlIIIIIIllI[0];
    char llllllllllllllIlIIIllIllllIlIIll = llllllllllllllIlIIIllIllllIllIII.toCharArray();
    long llllllllllllllIlIIIllIllllIlIIlI = llllllllllllllIlIIIllIllllIlIIll.length;
    float llllllllllllllIlIIIllIllllIlIIIl = lIIlIIIIIIllI[0];
    while (llIllIllIlIIII(llllllllllllllIlIIIllIllllIlIIIl, llllllllllllllIlIIIllIllllIlIIlI))
    {
      char llllllllllllllIlIIIllIllllIllllI = llllllllllllllIlIIIllIllllIlIIll[llllllllllllllIlIIIllIllllIlIIIl];
      "".length();
      "".length();
      if (((108 + '¹' - 82 + 37 ^ 20 + '' - 22 + 30) & (0xDB ^ 0x92 ^ "   ".length() ^ -" ".length())) <= -" ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIIIllIllllIllIll);
  }
  
  private static String llIllIllIIIlIl(String llllllllllllllIlIIIllIlllIlllIll, String llllllllllllllIlIIIllIlllIlllIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIIllIlllIlllllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIIllIlllIlllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIIIllIlllIllllIl = Cipher.getInstance("Blowfish");
      llllllllllllllIlIIIllIlllIllllIl.init(lIIlIIIIIIllI[3], llllllllllllllIlIIIllIlllIlllllI);
      return new String(llllllllllllllIlIIIllIlllIllllIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIIllIlllIlllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIIllIlllIllllII)
    {
      llllllllllllllIlIIIllIlllIllllII.printStackTrace();
    }
    return null;
  }
  
  public IBlockState getActualState(IBlockState llllllllllllllIlIIIlllIIlllllllI, IBlockAccess llllllllllllllIlIIIlllIIllllllIl, BlockPos llllllllllllllIlIIIlllIIllllllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIIIlllIlIIIIIlIl = llllllllllllllIlIIIlllIIllllllII.getX();
    int llllllllllllllIlIIIlllIlIIIIIlII = llllllllllllllIlIIIlllIIllllllII.getY();
    int llllllllllllllIlIIIlllIlIIIIIIll = llllllllllllllIlIIIlllIIllllllII.getZ();
    if ((llIllIllIIllII(World.doesBlockHaveSolidTopSurface(llllllllllllllIlIIIlllIIllllllIl, llllllllllllllIlIIIlllIIllllllII.down()))) && (llIllIllIIllII(Blocks.fire.canCatchFire(llllllllllllllIlIIIlllIIllllllIl, llllllllllllllIlIIIlllIIllllllII.down()))))
    {
      if (llIllIllIIllIl(llllllllllllllIlIIIlllIlIIIIIlIl + llllllllllllllIlIIIlllIlIIIIIlII + llllllllllllllIlIIIlllIlIIIIIIll & lIIlIIIIIIllI[2], lIIlIIIIIIllI[2]))
      {
        "".length();
        if (-"   ".length() < 0) {
          break label101;
        }
        return null;
      }
      label101:
      boolean llllllllllllllIlIIIlllIlIIIIIIlI = lIIlIIIIIIllI[0];
      if (llIllIllIIllIl(llllllllllllllIlIIIlllIlIIIIIlIl / lIIlIIIIIIllI[3] + llllllllllllllIlIIIlllIlIIIIIlII / lIIlIIIIIIllI[3] + llllllllllllllIlIIIlllIlIIIIIIll / lIIlIIIIIIllI[3] & lIIlIIIIIIllI[2], lIIlIIIIIIllI[2]))
      {
        "".length();
        if (" ".length() != 0) {
          break label172;
        }
        return null;
      }
      label172:
      boolean llllllllllllllIlIIIlllIlIIIIIIIl = lIIlIIIIIIllI[0];
      int llllllllllllllIlIIIlllIlIIIIIIII = lIIlIIIIIIllI[0];
      if (llIllIllIIlllI(llllllllllllllIlIIIlllIIllllllll.canCatchFire(llllllllllllllIlIIIlllIIllllllIl, llllllllllllllIlIIIlllIIllllllII.up())))
      {
        if (llIllIllIIlllI(llllllllllllllIlIIIlllIlIIIIIIlI))
        {
          "".length();
          if ((0x25 ^ 0x21) != 0) {
            break label230;
          }
          return null;
        }
        label230:
        llllllllllllllIlIIIlllIlIIIIIIII = lIIlIIIIIIllI[3];
      }
      return llllllllllllllIlIIIlllIIlllllllI.withProperty(NORTH, Boolean.valueOf(llllllllllllllIlIIIlllIIllllllll.canCatchFire(llllllllllllllIlIIIlllIIllllllIl, llllllllllllllIlIIIlllIIllllllII.north()))).withProperty(EAST, Boolean.valueOf(llllllllllllllIlIIIlllIIllllllll.canCatchFire(llllllllllllllIlIIIlllIIllllllIl, llllllllllllllIlIIIlllIIllllllII.east()))).withProperty(SOUTH, Boolean.valueOf(llllllllllllllIlIIIlllIIllllllll.canCatchFire(llllllllllllllIlIIIlllIIllllllIl, llllllllllllllIlIIIlllIIllllllII.south()))).withProperty(WEST, Boolean.valueOf(llllllllllllllIlIIIlllIIllllllll.canCatchFire(llllllllllllllIlIIIlllIIllllllIl, llllllllllllllIlIIIlllIIllllllII.west()))).withProperty(UPPER, Integer.valueOf(llllllllllllllIlIIIlllIlIIIIIIII)).withProperty(FLIP, Boolean.valueOf(llllllllllllllIlIIIlllIlIIIIIIIl)).withProperty(ALT, Boolean.valueOf(llllllllllllllIlIIIlllIlIIIIIIlI));
    }
    return llllllllllllllIlIIIlllIIllllllll.getDefaultState();
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllIlIIIllIllllllIllI)
  {
    return MapColor.tntColor;
  }
}

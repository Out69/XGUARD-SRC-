package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.IStringSerializable;
import net.minecraft.world.World;

public abstract class BlockStoneSlab
  extends BlockSlab
{
  private static void lIllIIIllIllll()
  {
    lllIlIIIIIIl = new int[6];
    lllIlIIIIIIl[0] = ((0x70 ^ 0x77) & (0x17 ^ 0x10 ^ 0xFFFFFFFF));
    lllIlIIIIIIl[1] = " ".length();
    lllIlIIIIIIl[2] = "  ".length();
    lllIlIIIIIIl[3] = (0x8F ^ 0x88);
    lllIlIIIIIIl[4] = (0xBF ^ 0xB7);
    lllIlIIIIIIl[5] = "   ".length();
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIlllIIIlllIIllIIII)
  {
    ;
    ;
    ;
    IBlockState llllllllllllllIlllIIIlllIIllIIlI = llllllllllllllIlllIIIlllIIllIIIl.getDefaultState().withProperty(VARIANT, EnumType.byMetadata(llllllllllllllIlllIIIlllIIllIIII & lllIlIIIIIIl[3]));
    if (lIllIIIlllIIII(llllllllllllllIlllIIIlllIIllIIIl.isDouble()))
    {
      if (lIllIIIlllIIII(llllllllllllllIlllIIIlllIIllIIII & lllIlIIIIIIl[4]))
      {
        "".length();
        if ((0x2 ^ 0x6) != "   ".length()) {
          break label80;
        }
        return null;
      }
      label80:
      llllllllllllllIlllIIIlllIIllIIlI = SEAMLESS.withProperty(lllIlIIIIIIl[1], Boolean.valueOf(lllIlIIIIIIl[0]));
      "".length();
      if (((0x54 ^ 0x44) & (0x91 ^ 0x81 ^ 0xFFFFFFFF)) != ((0x22 ^ 0x61) & (0x2A ^ 0x69 ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    else
    {
      if (lIllIIIlllIIll(llllllllllllllIlllIIIlllIIllIIII & lllIlIIIIIIl[4]))
      {
        "".length();
        if ((0x5 ^ 0x1) <= (0x7 ^ 0x3)) {
          break label169;
        }
        return null;
      }
      label169:
      llllllllllllllIlllIIIlllIIllIIlI = HALF.withProperty(BlockSlab.EnumBlockHalf.BOTTOM, BlockSlab.EnumBlockHalf.TOP);
    }
    return llllllllllllllIlllIIIlllIIllIIlI;
  }
  
  public String getUnlocalizedName(int llllllllllllllIlllIIIlllIlIlIIII)
  {
    ;
    ;
    return String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlllIIIlllIlIIllll.getUnlocalizedName())).append(lllIIllllIII[lllIlIIIIIIl[2]]).append(EnumType.byMetadata(llllllllllllllIlllIIIlllIlIlIIII).getUnlocalizedName()));
  }
  
  public Object getVariant(ItemStack llllllllllllllIlllIIIlllIlIIlIlI)
  {
    ;
    return EnumType.byMetadata(llllllllllllllIlllIIIlllIlIIlIlI.getMetadata() & lllIlIIIIIIl[3]);
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIlllIIIlllIlIllIIl, Random llllllllllllllIlllIIIlllIlIllIII, int llllllllllllllIlllIIIlllIlIlIlll)
  {
    return Item.getItemFromBlock(Blocks.stone_slab);
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllIlllIIIlllIIIlllII)
  {
    ;
    return ((EnumType)llllllllllllllIlllIIIlllIIIlllII.getValue(VARIANT)).func_181074_c();
  }
  
  private static boolean lIllIIIlllIIll(int ???)
  {
    short llllllllllllllIlllIIIllIlllIllll;
    return ??? == 0;
  }
  
  private static boolean lIllIIIlllIIIl(Object ???, Object arg1)
  {
    Object localObject;
    float llllllllllllllIlllIIIllIllllIlll;
    return ??? != localObject;
  }
  
  public void getSubBlocks(Item llllllllllllllIlllIIIlllIlIIIIIl, CreativeTabs llllllllllllllIlllIIIlllIlIIIIII, List<ItemStack> llllllllllllllIlllIIIlllIIllllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllIIIlllIIIl(llllllllllllllIlllIIIlllIlIIIIIl, Item.getItemFromBlock(Blocks.double_stone_slab)))
    {
      llllllllllllllIlllIIIlllIIlllIIl = (llllllllllllllIlllIIIlllIIlllIII = EnumType.values()).length;
      llllllllllllllIlllIIIlllIIlllIlI = lllIlIIIIIIl[0];
      "".length();
      if (((0xBF ^ 0x91) & (0xAC ^ 0x82 ^ 0xFFFFFFFF)) != 0) {
        return;
      }
      while (!lIllIIIlllIIlI(llllllllllllllIlllIIIlllIIlllIlI, llllllllllllllIlllIIIlllIIlllIIl))
      {
        EnumType llllllllllllllIlllIIIlllIIlllllI = llllllllllllllIlllIIIlllIIlllIII[llllllllllllllIlllIIIlllIIlllIlI];
        if (lIllIIIlllIIIl(llllllllllllllIlllIIIlllIIlllllI, EnumType.WOOD))
        {
          new ItemStack(llllllllllllllIlllIIIlllIlIIIIIl, lllIlIIIIIIl[1], llllllllllllllIlllIIIlllIIlllllI.getMetadata());
          "".length();
        }
        llllllllllllllIlllIIIlllIIlllIlI++;
      }
    }
  }
  
  public IProperty<?> getVariantProperty()
  {
    return VARIANT;
  }
  
  public Item getItem(World llllllllllllllIlllIIIlllIlIlIlIl, BlockPos llllllllllllllIlllIIIlllIlIlIlII)
  {
    return Item.getItemFromBlock(Blocks.stone_slab);
  }
  
  private static String lIllIIIlIlIIIl(String llllllllllllllIlllIIIlllIIIlIIII, String llllllllllllllIlllIIIlllIIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlllIIIlllIIIlIIII = new String(Base64.getDecoder().decode(llllllllllllllIlllIIIlllIIIlIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlllIIIlllIIIIlllI = new StringBuilder();
    char[] llllllllllllllIlllIIIlllIIIIllIl = llllllllllllllIlllIIIlllIIIIllll.toCharArray();
    int llllllllllllllIlllIIIlllIIIIllII = lllIlIIIIIIl[0];
    float llllllllllllllIlllIIIlllIIIIIllI = llllllllllllllIlllIIIlllIIIlIIII.toCharArray();
    boolean llllllllllllllIlllIIIlllIIIIIlIl = llllllllllllllIlllIIIlllIIIIIllI.length;
    short llllllllllllllIlllIIIlllIIIIIlII = lllIlIIIIIIl[0];
    while (lIllIIIlllIlIl(llllllllllllllIlllIIIlllIIIIIlII, llllllllllllllIlllIIIlllIIIIIlIl))
    {
      char llllllllllllllIlllIIIlllIIIlIIIl = llllllllllllllIlllIIIlllIIIIIllI[llllllllllllllIlllIIIlllIIIIIlII];
      "".length();
      "".length();
      if ((0xE ^ 0x17 ^ 0x8B ^ 0x97) <= 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlllIIIlllIIIIlllI);
  }
  
  protected BlockState createBlockState()
  {
    ;
    if (lIllIIIlllIIII(llllllllllllllIlllIIIlllIIlIIIll.isDouble()))
    {
      new BlockState(llllllllllllllIlllIIIlllIIlIIlII, tmp33_23);
      "".length();
      if (-" ".length() < "  ".length()) {
        break label104;
      }
      return null;
    }
    label104:
    return new BlockState(llllllllllllllIlllIIIlllIIlIIlII, new IProperty[] { HALF, VARIANT });
  }
  
  static
  {
    lIllIIIllIllll();
    lIllIIIllIlllI();
    SEAMLESS = PropertyBool.create(lllIIllllIII[lllIlIIIIIIl[0]]);
  }
  
  private static void lIllIIIllIlllI()
  {
    lllIIllllIII = new String[lllIlIIIIIIl[5]];
    lllIIllllIII[lllIlIIIIIIl[0]] = lIllIIIlIlIIIl("Ki8EBAo8ORY=", "YJeif");
    lllIIllllIII[lllIlIIIIIIl[1]] = lIllIIIlIlIIIl("HiUbPA0GMA==", "hDiUl");
    lllIIllllIII[lllIlIIIIIIl[2]] = lIllIIIlIlIIIl("dA==", "ZFDrl");
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIlllIIIlllIIlIlIlI)
  {
    ;
    ;
    ;
    int llllllllllllllIlllIIIlllIIlIlIIl = lllIlIIIIIIl[0];
    llllllllllllllIlllIIIlllIIlIlIIl |= ((EnumType)llllllllllllllIlllIIIlllIIlIlIlI.getValue(VARIANT)).getMetadata();
    if (lIllIIIlllIIII(llllllllllllllIlllIIIlllIIlIlIII.isDouble()))
    {
      if (lIllIIIlllIIII(((Boolean)llllllllllllllIlllIIIlllIIlIlIlI.getValue(SEAMLESS)).booleanValue()))
      {
        llllllllllllllIlllIIIlllIIlIlIIl |= lllIlIIIIIIl[4];
        "".length();
        if (-"   ".length() > 0) {
          return (0x52 ^ 0x49) & (0x3A ^ 0x21 ^ 0xFFFFFFFF);
        }
      }
    }
    else if (lIllIIIlllIlII(llllllllllllllIlllIIIlllIIlIlIlI.getValue(HALF), BlockSlab.EnumBlockHalf.TOP)) {
      llllllllllllllIlllIIIlllIIlIlIIl |= lllIlIIIIIIl[4];
    }
    return llllllllllllllIlllIIIlllIIlIlIIl;
  }
  
  private static boolean lIllIIIlllIlII(Object ???, Object arg1)
  {
    Object localObject;
    boolean llllllllllllllIlllIIIllIllllIIll;
    return ??? == localObject;
  }
  
  private static boolean lIllIIIlllIlIl(int ???, int arg1)
  {
    int i;
    char llllllllllllllIlllIIIllIlllllIll;
    return ??? < i;
  }
  
  private static boolean lIllIIIlllIIII(int ???)
  {
    double llllllllllllllIlllIIIllIllllIIIl;
    return ??? != 0;
  }
  
  public int damageDropped(IBlockState llllllllllllllIlllIIIlllIIlIIIII)
  {
    ;
    return ((EnumType)llllllllllllllIlllIIIlllIIlIIIII.getValue(VARIANT)).getMetadata();
  }
  
  public BlockStoneSlab()
  {
    llllllllllllllIlllIIIlllIlIllllI.<init>(Material.rock);
    IBlockState llllllllllllllIlllIIIlllIlIlllIl = blockState.getBaseState();
    if (lIllIIIlllIIII(llllllllllllllIlllIIIlllIlIlllII.isDouble()))
    {
      llllllllllllllIlllIIIlllIlIlllIl = llllllllllllllIlllIIIlllIlIlllIl.withProperty(SEAMLESS, Boolean.valueOf(lllIlIIIIIIl[0]));
      "".length();
      if (" ".length() <= (('Ó' + 85 - 163 + 82 ^ 18 + 113 - 130 + 153) & ('Ä' + 92 - 121 + 76 ^ 95 + 110 - 18 + 3 ^ -" ".length()))) {
        throw null;
      }
    }
    else
    {
      llllllllllllllIlllIIIlllIlIlllIl = llllllllllllllIlllIIIlllIlIlllIl.withProperty(HALF, BlockSlab.EnumBlockHalf.BOTTOM);
    }
    llllllllllllllIlllIIIlllIlIlllII.setDefaultState(llllllllllllllIlllIIIlllIlIlllIl.withProperty(VARIANT, EnumType.STONE));
    "".length();
  }
  
  private static boolean lIllIIIlllIIlI(int ???, int arg1)
  {
    int i;
    double llllllllllllllIlllIIIllIllllllll;
    return ??? >= i;
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    private static boolean llIIllllIIIIll(int ???, int arg1)
    {
      int i;
      Exception llllllllllllllIlIlIIllIIIlIllIII;
      return ??? < i;
    }
    
    public static EnumType byMetadata(int llllllllllllllIlIlIIllIIlIlIIIII)
    {
      ;
      if ((!llIIllllIIIIlI(llllllllllllllIlIlIIllIIlIlIIIII)) || (llIIllllIIIIIl(llllllllllllllIlIlIIllIIlIlIIIIl, META_LOOKUP.length))) {
        llllllllllllllIlIlIIllIIlIlIIIIl = lIIIIlllIlIll[0];
      }
      return META_LOOKUP[llllllllllllllIlIlIIllIIlIlIIIIl];
    }
    
    private EnumType(int llllllllllllllIlIlIIllIIlIlIllll, MapColor llllllllllllllIlIlIIllIIlIlIlllI, String llllllllllllllIlIlIIllIIlIllIlII, String llllllllllllllIlIlIIllIIlIlIllII)
    {
      meta = llllllllllllllIlIlIIllIIlIlIllll;
      field_181075_k = llllllllllllllIlIlIIllIIlIllIlIl;
      name = llllllllllllllIlIlIIllIIlIllIlII;
      unlocalizedName = llllllllllllllIlIlIIllIIlIlIllII;
    }
    
    private EnumType(int llllllllllllllIlIlIIllIIllIIIlll, MapColor llllllllllllllIlIlIIllIIllIIIIII, String llllllllllllllIlIlIIllIIllIIIlIl)
    {
      llllllllllllllIlIlIIllIIllIIIlII.<init>(llllllllllllllIlIlIIllIIllIIIIll, llllllllllllllIlIlIIllIIllIIIIlI, llllllllllllllIlIlIIllIIllIIIlll, llllllllllllllIlIlIIllIIllIIIIII, llllllllllllllIlIlIIllIIllIIIlIl, llllllllllllllIlIlIIllIIllIIIlIl);
    }
    
    private static String llIIlllIllIIlI(String llllllllllllllIlIlIIllIIlIIIlIlI, String llllllllllllllIlIlIIllIIlIIIIlll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIlIIllIIlIIIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIIllIIlIIIIlll.getBytes(StandardCharsets.UTF_8)), lIIIIlllIlIll[8]), "DES");
        Cipher llllllllllllllIlIlIIllIIlIIIllII = Cipher.getInstance("DES");
        llllllllllllllIlIlIIllIIlIIIllII.init(lIIIIlllIlIll[2], llllllllllllllIlIlIIllIIlIIIllIl);
        return new String(llllllllllllllIlIlIIllIIlIIIllII.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIIllIIlIIIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIlIIllIIlIIIlIll)
      {
        llllllllllllllIlIlIIllIIlIIIlIll.printStackTrace();
      }
      return null;
    }
    
    private static void llIIllllIIIIII()
    {
      lIIIIlllIlIll = new int[22];
      lIIIIlllIlIll[0] = ((0xCB ^ 0x8D) & (0xF2 ^ 0xB4 ^ 0xFFFFFFFF));
      lIIIIlllIlIll[1] = " ".length();
      lIIIIlllIlIll[2] = "  ".length();
      lIIIIlllIlIll[3] = "   ".length();
      lIIIIlllIlIll[4] = (0x4 ^ 0x0);
      lIIIIlllIlIll[5] = (0x73 ^ 0x76);
      lIIIIlllIlIll[6] = (0x81 ^ 0xC0 ^ 0x26 ^ 0x61);
      lIIIIlllIlIll[7] = (0xCC ^ 0xB2 ^ 0xD5 ^ 0xAC);
      lIIIIlllIlIll[8] = (0xAF ^ 0xA7);
      lIIIIlllIlIll[9] = (0x4F ^ 0x46);
      lIIIIlllIlIll[10] = (83 + '' - 70 + 39 ^ '' + 36 - 42 + 72);
      lIIIIlllIlIll[11] = (1 + 50 - 31 + 183 ^ 'µ' + 104 - 256 + 163);
      lIIIIlllIlIll[12] = (0x2F ^ 0x23);
      lIIIIlllIlIll[13] = (0x84 ^ 0x89);
      lIIIIlllIlIll[14] = (0x84 ^ 0x8A);
      lIIIIlllIlIll[15] = (0x23 ^ 0x49 ^ 0x12 ^ 0x77);
      lIIIIlllIlIll[16] = (54 + 117 - 159 + 135 ^ 79 + 11 - 88 + 129);
      lIIIIlllIlIll[17] = (23 + '' - 48 + 73 ^ 25 + '¡' - 163 + 139);
      lIIIIlllIlIll[18] = (0x27 ^ 0x14 ^ 0x61 ^ 0x40);
      lIIIIlllIlIll[19] = (0xA ^ 0x18 ^ " ".length());
      lIIIIlllIlIll[20] = (0x4A ^ 0x5E);
      lIIIIlllIlIll[21] = ('Í' + 122 - 291 + 175 ^ 106 + 124 - 155 + 123);
    }
    
    private static void llIIlllIllllII()
    {
      lIIIIlllIIlII = new String[lIIIIlllIlIll[21]];
      lIIIIlllIIlII[lIIIIlllIlIll[0]] = llIIlllIllIIlI("qY0ZInJNW48=", "bRGqu");
      lIIIIlllIIlII[lIIIIlllIlIll[1]] = llIIlllIllIIll("EDAhLTM=", "cDNCV");
      lIIIIlllIIlII[lIIIIlllIlIll[2]] = llIIlllIllIlII("P20qaCNV9ng=", "dVYlN");
      lIIIIlllIIlII[lIIIIlllIlIll[3]] = llIIlllIllIlII("kijuqsz7spnOTAwpQoc4dw==", "qmGKw");
      lIIIIlllIIlII[lIIIIlllIlIll[4]] = llIIlllIllIIll("IDcCEQ==", "SVlus");
      lIIIIlllIIlII[lIIIIlllIlIll[5]] = llIIlllIllIlII("vE4iplY8Brk=", "AGykP");
      lIIIIlllIIlII[lIIIIlllIlIll[6]] = llIIlllIllIlII("t416qRJUL6Rt03cvIevo7Q==", "DBunA");
      lIIIIlllIIlII[lIIIIlllIlIll[7]] = llIIlllIllIIlI("6qrnkIawtlg=", "ZoUEX");
      lIIIIlllIIlII[lIIIIlllIlIll[8]] = llIIlllIllIlII("FlaImBD1eXXe3EKoeOKMMg==", "kZHpM");
      lIIIIlllIIlII[lIIIIlllIlIll[9]] = llIIlllIllIIlI("4ZYRBzAi0CIOkUN5GnFgug==", "RvVkW");
      lIIIIlllIIlII[lIIIIlllIlIll[10]] = llIIlllIllIIlI("yZn7IPGJSZQ=", "RQVXl");
      lIIIIlllIIlII[lIIIIlllIlIll[11]] = llIIlllIllIlII("3XqxztEBFRs=", "WxqAO");
      lIIIIlllIIlII[lIIIIlllIlIll[12]] = llIIlllIllIlII("rAT9Id8EN/E=", "dqPAL");
      lIIIIlllIIlII[lIIIIlllIlIll[13]] = llIIlllIllIlII("bT/RTx3Xx4AWStH5B+d5hA==", "PraKY");
      lIIIIlllIIlII[lIIIIlllIlIll[14]] = llIIlllIllIlII("s68CvMjMrwDAF47giKLPPQ==", "PnLfe");
      lIIIIlllIIlII[lIIIIlllIlIll[15]] = llIIlllIllIIlI("OaYu7dfTVTHdfIyk7dJRiUF7PJ4pKrz0", "hksun");
      lIIIIlllIIlII[lIIIIlllIlIll[16]] = llIIlllIllIlII("QCqAtI0RKaaJOBxk9PdhSg==", "kUmiZ");
      lIIIIlllIIlII[lIIIIlllIlIll[17]] = llIIlllIllIlII("4gQuadLkUCrTbOd6wnK2sg==", "wRJSF");
      lIIIIlllIIlII[lIIIIlllIlIll[18]] = llIIlllIllIIll("JgstGgA6LCsbBiM=", "HnYre");
      lIIIIlllIIlII[lIIIIlllIlIll[19]] = llIIlllIllIlII("AuGQrsvQvZE=", "pVPuq");
      lIIIIlllIIlII[lIIIIlllIlIll[20]] = llIIlllIllIIlI("hpFmhm/eV68=", "kktGU");
    }
    
    private static boolean llIIllllIIIIIl(int ???, int arg1)
    {
      int i;
      long llllllllllllllIlIlIIllIIIlIlllII;
      return ??? >= i;
    }
    
    private static String llIIlllIllIIll(String llllllllllllllIlIlIIllIIIllIlIII, String llllllllllllllIlIlIIllIIIllIIlll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIlIlIIllIIIllIlIII = new String(Base64.getDecoder().decode(llllllllllllllIlIlIIllIIIllIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIlIlIIllIIIllIlIll = new StringBuilder();
      char[] llllllllllllllIlIlIIllIIIllIlIlI = llllllllllllllIlIlIIllIIIllIIlll.toCharArray();
      int llllllllllllllIlIlIIllIIIllIlIIl = lIIIIlllIlIll[0];
      char llllllllllllllIlIlIIllIIIllIIIll = llllllllllllllIlIlIIllIIIllIlIII.toCharArray();
      short llllllllllllllIlIlIIllIIIllIIIlI = llllllllllllllIlIlIIllIIIllIIIll.length;
      Exception llllllllllllllIlIlIIllIIIllIIIIl = lIIIIlllIlIll[0];
      while (llIIllllIIIIll(llllllllllllllIlIlIIllIIIllIIIIl, llllllllllllllIlIlIIllIIIllIIIlI))
      {
        char llllllllllllllIlIlIIllIIIllIlllI = llllllllllllllIlIlIIllIIIllIIIll[llllllllllllllIlIlIIllIIIllIIIIl];
        "".length();
        "".length();
        if ("  ".length() == 0) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIlIlIIllIIIllIlIll);
    }
    
    private static String llIIlllIllIlII(String llllllllllllllIlIlIIllIIIlllllIl, String llllllllllllllIlIlIIllIIIllllIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIlIIllIIlIIIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIIllIIIllllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIlIlIIllIIIlllllll = Cipher.getInstance("Blowfish");
        llllllllllllllIlIlIIllIIIlllllll.init(lIIIIlllIlIll[2], llllllllllllllIlIlIIllIIlIIIIIII);
        return new String(llllllllllllllIlIlIIllIIIlllllll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIIllIIIlllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIlIIllIIIllllllI)
      {
        llllllllllllllIlIlIIllIIIllllllI.printStackTrace();
      }
      return null;
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private static boolean llIIllllIIIIlI(int ???)
    {
      boolean llllllllllllllIlIlIIllIIIlIlIllI;
      return ??? >= 0;
    }
    
    public String getUnlocalizedName()
    {
      ;
      return unlocalizedName;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    public MapColor func_181074_c()
    {
      ;
      return field_181075_k;
    }
    
    static
    {
      llIIllllIIIIII();
      llIIlllIllllII();
      boolean llllllllllllllIlIlIIllIIllIIllll;
      boolean llllllllllllllIlIlIIllIIllIlIIlI;
      STONE = new EnumType(lIIIIlllIIlII[lIIIIlllIlIll[0]], lIIIIlllIlIll[0], lIIIIlllIlIll[0], MapColor.stoneColor, lIIIIlllIIlII[lIIIIlllIlIll[1]]);
      SAND = new EnumType(lIIIIlllIIlII[lIIIIlllIlIll[2]], lIIIIlllIlIll[1], lIIIIlllIlIll[1], MapColor.sandColor, lIIIIlllIIlII[lIIIIlllIlIll[3]], lIIIIlllIIlII[lIIIIlllIlIll[4]]);
      WOOD = new EnumType(lIIIIlllIIlII[lIIIIlllIlIll[5]], lIIIIlllIlIll[2], lIIIIlllIlIll[2], MapColor.woodColor, lIIIIlllIIlII[lIIIIlllIlIll[6]], lIIIIlllIIlII[lIIIIlllIlIll[7]]);
      COBBLESTONE = new EnumType(lIIIIlllIIlII[lIIIIlllIlIll[8]], lIIIIlllIlIll[3], lIIIIlllIlIll[3], MapColor.stoneColor, lIIIIlllIIlII[lIIIIlllIlIll[9]], lIIIIlllIIlII[lIIIIlllIlIll[10]]);
      BRICK = new EnumType(lIIIIlllIIlII[lIIIIlllIlIll[11]], lIIIIlllIlIll[4], lIIIIlllIlIll[4], MapColor.redColor, lIIIIlllIIlII[lIIIIlllIlIll[12]]);
      SMOOTHBRICK = new EnumType(lIIIIlllIIlII[lIIIIlllIlIll[13]], lIIIIlllIlIll[5], lIIIIlllIlIll[5], MapColor.stoneColor, lIIIIlllIIlII[lIIIIlllIlIll[14]], lIIIIlllIIlII[lIIIIlllIlIll[15]]);
      NETHERBRICK = new EnumType(lIIIIlllIIlII[lIIIIlllIlIll[16]], lIIIIlllIlIll[6], lIIIIlllIlIll[6], MapColor.netherrackColor, lIIIIlllIIlII[lIIIIlllIlIll[17]], lIIIIlllIIlII[lIIIIlllIlIll[18]]);
      QUARTZ = new EnumType(lIIIIlllIIlII[lIIIIlllIlIll[19]], lIIIIlllIlIll[7], lIIIIlllIlIll[7], MapColor.quartzColor, lIIIIlllIIlII[lIIIIlllIlIll[20]]);
      ENUM$VALUES = new EnumType[] { STONE, SAND, WOOD, COBBLESTONE, BRICK, SMOOTHBRICK, NETHERBRICK, QUARTZ };
      META_LOOKUP = new EnumType[values().length];
      String llllllllllllllIlIlIIllIIllIlIIII = (llllllllllllllIlIlIIllIIllIIllll = values()).length;
      short llllllllllllllIlIlIIllIIllIlIIIl = lIIIIlllIlIll[0];
      "".length();
      if (-"   ".length() >= 0) {
        return;
      }
      while (!llIIllllIIIIIl(llllllllllllllIlIlIIllIIllIlIIIl, llllllllllllllIlIlIIllIIllIlIIII))
      {
        EnumType llllllllllllllIlIlIIllIIllIlIIll = llllllllllllllIlIlIIllIIllIIllll[llllllllllllllIlIlIIllIIllIlIIIl];
        META_LOOKUP[llllllllllllllIlIlIIllIIllIlIIll.getMetadata()] = llllllllllllllIlIlIIllIIllIlIIll;
        llllllllllllllIlIlIIllIIllIlIIIl++;
      }
    }
    
    public int getMetadata()
    {
      ;
      return meta;
    }
  }
}

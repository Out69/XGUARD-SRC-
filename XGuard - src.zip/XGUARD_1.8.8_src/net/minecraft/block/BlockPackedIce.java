package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;

public class BlockPackedIce
  extends Block
{
  public BlockPackedIce()
  {
    llllllllllllllIlIlIlIlIlIllIllII.<init>(Material.packedIce);
    slipperiness = 0.98F;
    "".length();
  }
  
  private static void llIIllIlIIlIlI()
  {
    lIIIIllIIIlIl = new int[1];
    lIIIIllIIIlIl[0] = ((0xDF ^ 0xC1) & (0x51 ^ 0x4F ^ 0xFFFFFFFF));
  }
  
  public int quantityDropped(Random llllllllllllllIlIlIlIlIlIllIlIIl)
  {
    return lIIIIllIIIlIl[0];
  }
  
  static {}
}

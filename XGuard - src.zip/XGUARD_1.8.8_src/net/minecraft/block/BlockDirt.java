package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.IStringSerializable;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockDirt
  extends Block
{
  public IBlockState getActualState(IBlockState lllllllllllllllIllIlIIIIIlllIIIl, IBlockAccess lllllllllllllllIllIlIIIIIllIllII, BlockPos lllllllllllllllIllIlIIIIIllIllll)
  {
    ;
    ;
    ;
    ;
    if (lllIIIlIIIllI(lllllllllllllllIllIlIIIIIlllIIIl.getValue(VARIANT), DirtType.PODZOL))
    {
      Block lllllllllllllllIllIlIIIIIllIlllI = lllllllllllllllIllIlIIIIIlllIIII.getBlockState(lllllllllllllllIllIlIIIIIllIllll.up()).getBlock();
      if ((lllIIIlIIIlll(lllllllllllllllIllIlIIIIIllIlllI, Blocks.snow)) && (lllIIIlIIIlll(lllllllllllllllIllIlIIIIIllIlllI, Blocks.snow_layer)))
      {
        "".length();
        if (-" ".length() < 0) {
          break label88;
        }
        return null;
      }
      label88:
      lllllllllllllllIllIlIIIIIlllIIIl = SNOWY.withProperty(lIIlIIlIIIIl[0], Boolean.valueOf(lIIlIIlIIIIl[1]));
    }
    return lllllllllllllllIllIlIIIIIlllIIIl;
  }
  
  public int getDamageValue(World lllllllllllllllIllIlIIIIIlIlllII, BlockPos lllllllllllllllIllIlIIIIIlIlIlll)
  {
    ;
    ;
    ;
    ;
    IBlockState lllllllllllllllIllIlIIIIIlIllIlI = lllllllllllllllIllIlIIIIIlIlllII.getBlockState(lllllllllllllllIllIlIIIIIlIlIlll);
    if (lllIIIlIIIlll(lllllllllllllllIllIlIIIIIlIllIlI.getBlock(), lllllllllllllllIllIlIIIIIlIlllIl))
    {
      "".length();
      if (((0xC ^ 0x50) & (0xC8 ^ 0x94 ^ 0xFFFFFFFF)) == ((0xC4 ^ 0xC2) & (0x61 ^ 0x67 ^ 0xFFFFFFFF))) {
        break label96;
      }
      return (0x8D ^ 0x92) & (0xA5 ^ 0xBA ^ 0xFFFFFFFF);
    }
    label96:
    return ((DirtType)lllllllllllllllIllIlIIIIIlIllIlI.getValue(VARIANT)).getMetadata();
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIllIlIIIIIlIlIIlI)
  {
    ;
    ;
    return lllllllllllllllIllIlIIIIIlIlIIll.getDefaultState().withProperty(VARIANT, DirtType.byMetadata(lllllllllllllllIllIlIIIIIlIlIIlI));
  }
  
  private static boolean lllIIIlIIIlll(Object ???, Object arg1)
  {
    Object localObject;
    double lllllllllllllllIllIlIIIIIIllIIIl;
    return ??? != localObject;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIllIlIIIIIlIIlIIl, new IProperty[] { VARIANT, SNOWY });
  }
  
  private static void lllIIIlIIIlIl()
  {
    lIIlIIlIIIIl = new int[4];
    lIIlIIlIIIIl[0] = ((0x5C ^ 0x7E ^ 0x96 ^ 0x88) & (0x58 ^ 0x6D ^ 0xCA ^ 0xC3 ^ -" ".length()));
    lIIlIIlIIIIl[1] = " ".length();
    lIIlIIlIIIIl[2] = "  ".length();
    lIIlIIlIIIIl[3] = (0xB ^ 0x42 ^ 0xF3 ^ 0xB2);
  }
  
  public MapColor getMapColor(IBlockState lllllllllllllllIllIlIIIIIllllIII)
  {
    ;
    return ((DirtType)lllllllllllllllIllIlIIIIIllllIII.getValue(VARIANT)).func_181066_d();
  }
  
  static
  {
    lllIIIlIIIlIl();
    lllIIIlIIIIlI();
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIllIlIIIIIlIIllIl)
  {
    ;
    return ((DirtType)lllllllllllllllIllIlIIIIIlIIllIl.getValue(VARIANT)).getMetadata();
  }
  
  private static boolean lllIIIlIIIllI(Object ???, Object arg1)
  {
    Object localObject;
    byte lllllllllllllllIllIlIIIIIIlIllIl;
    return ??? == localObject;
  }
  
  protected BlockDirt()
  {
    lllllllllllllllIllIlIIIIIlllllII.<init>(Material.ground);
    lllllllllllllllIllIlIIIIIllllIll.setDefaultState(blockState.getBaseState().withProperty(VARIANT, DirtType.DIRT).withProperty(SNOWY, Boolean.valueOf(lIIlIIlIIIIl[0])));
    "".length();
  }
  
  public int damageDropped(IBlockState lllllllllllllllIllIlIIIIIlIIIIll)
  {
    ;
    ;
    DirtType lllllllllllllllIllIlIIIIIlIIIlII = (DirtType)lllllllllllllllIllIlIIIIIlIIIIll.getValue(VARIANT);
    if (lllIIIlIIIllI(lllllllllllllllIllIlIIIIIlIIIlII, DirtType.PODZOL)) {
      lllllllllllllllIllIlIIIIIlIIIlII = DirtType.DIRT;
    }
    return lllllllllllllllIllIlIIIIIlIIIlII.getMetadata();
  }
  
  private static String lllIIIlIIIIIl(String lllllllllllllllIllIlIIIIIIlllIII, String lllllllllllllllIllIlIIIIIIlllIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIlIIIIIIllllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIIIIlllIIl.getBytes(StandardCharsets.UTF_8)), lIIlIIlIIIIl[3]), "DES");
      Cipher lllllllllllllllIllIlIIIIIIllllII = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIIIIIllllII.init(lIIlIIlIIIIl[2], lllllllllllllllIllIlIIIIIIllllIl);
      return new String(lllllllllllllllIllIlIIIIIIllllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIIIlllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIlIIIIIIlllIll)
    {
      lllllllllllllllIllIlIIIIIIlllIll.printStackTrace();
    }
    return null;
  }
  
  private static void lllIIIlIIIIlI()
  {
    lIIlIIIlllll = new String[lIIlIIlIIIIl[2]];
    lIIlIIIlllll[lIIlIIlIIIIl[0]] = lllIIIlIIIIIl("xro1ek0SDcc=", "wbqZe");
    lIIlIIIlllll[lIIlIIlIIIIl[1]] = lllIIIlIIIIIl("j/7OMWaUEiU=", "YGyKC");
  }
  
  public void getSubBlocks(Item lllllllllllllllIllIlIIIIIllIIllI, CreativeTabs lllllllllllllllIllIlIIIIIllIIlIl, List<ItemStack> lllllllllllllllIllIlIIIIIllIIIlI)
  {
    ;
    ;
    new ItemStack(lllllllllllllllIllIlIIIIIllIIIll, lIIlIIlIIIIl[1], DirtType.DIRT.getMetadata());
    "".length();
    new ItemStack(lllllllllllllllIllIlIIIIIllIIIll, lIIlIIlIIIIl[1], DirtType.COARSE_DIRT.getMetadata());
    "".length();
    new ItemStack(lllllllllllllllIllIlIIIIIllIIIll, lIIlIIlIIIIl[1], DirtType.PODZOL.getMetadata());
    "".length();
  }
  
  public static enum DirtType
    implements IStringSerializable
  {
    private DirtType(int lllllllllllllllIlIIIllIlIllIIlII, String lllllllllllllllIlIIIllIlIllIIIll, String lllllllllllllllIlIIIllIlIllIIIlI, MapColor lllllllllllllllIlIIIllIlIllIIIIl)
    {
      metadata = lllllllllllllllIlIIIllIlIllIIlII;
      name = lllllllllllllllIlIIIllIlIllIlIlI;
      unlocalizedName = lllllllllllllllIlIIIllIlIllIIIlI;
      field_181067_h = lllllllllllllllIlIIIllIlIllIIIIl;
    }
    
    public int getMetadata()
    {
      ;
      return metadata;
    }
    
    public String getUnlocalizedName()
    {
      ;
      return unlocalizedName;
    }
    
    private static String lIIIIIIIlIIIlI(String lllllllllllllllIlIIIllIlIIllllll, String lllllllllllllllIlIIIllIlIIllllII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIlIIIllIlIlIIIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIIIllIlIIllllII.getBytes(StandardCharsets.UTF_8)), lIlIIllIllll[8]), "DES");
        Cipher lllllllllllllllIlIIIllIlIlIIIIIl = Cipher.getInstance("DES");
        lllllllllllllllIlIIIllIlIlIIIIIl.init(lIlIIllIllll[2], lllllllllllllllIlIIIllIlIlIIIIlI);
        return new String(lllllllllllllllIlIIIllIlIlIIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIIIllIlIIllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIlIIIllIlIlIIIIII)
      {
        lllllllllllllllIlIIIllIlIlIIIIII.printStackTrace();
      }
      return null;
    }
    
    public MapColor func_181066_d()
    {
      ;
      return field_181067_h;
    }
    
    private static void lIIIIIIlIllIIl()
    {
      lIlIIllIllll = new int[9];
      lIlIIllIllll[0] = (" ".length() & (" ".length() ^ -" ".length()));
      lIlIIllIllll[1] = " ".length();
      lIlIIllIllll[2] = "  ".length();
      lIlIIllIllll[3] = "   ".length();
      lIlIIllIllll[4] = (0xF5 ^ 0x87 ^ 0xEF ^ 0x99);
      lIlIIllIllll[5] = (0x1E ^ 0x1B);
      lIlIIllIllll[6] = (0x11 ^ 0x17);
      lIlIIllIllll[7] = (0xAE ^ 0xA9);
      lIlIIllIllll[8] = (0x10 ^ 0x18);
    }
    
    private static boolean lIIIIIIlIllIlI(int ???, int arg1)
    {
      int i;
      long lllllllllllllllIlIIIllIlIIIlIIIl;
      return ??? >= i;
    }
    
    static
    {
      lIIIIIIlIllIIl();
      lIIIIIIIlIIlII();
      Exception lllllllllllllllIlIIIllIllIIIIlII;
      int lllllllllllllllIlIIIllIllIIIIlll;
      DIRT = new DirtType(lIlIIllIIlIl[lIlIIllIllll[0]], lIlIIllIllll[0], lIlIIllIllll[0], lIlIIllIIlIl[lIlIIllIllll[1]], lIlIIllIIlIl[lIlIIllIllll[2]], MapColor.dirtColor);
      COARSE_DIRT = new DirtType(lIlIIllIIlIl[lIlIIllIllll[3]], lIlIIllIllll[1], lIlIIllIllll[1], lIlIIllIIlIl[lIlIIllIllll[4]], lIlIIllIIlIl[lIlIIllIllll[5]], MapColor.dirtColor);
      PODZOL = new DirtType(lIlIIllIIlIl[lIlIIllIllll[6]], lIlIIllIllll[2], lIlIIllIllll[2], lIlIIllIIlIl[lIlIIllIllll[7]], MapColor.obsidianColor);
      ENUM$VALUES = new DirtType[] { DIRT, COARSE_DIRT, PODZOL };
      METADATA_LOOKUP = new DirtType[values().length];
      Exception lllllllllllllllIlIIIllIllIIIIlIl = (lllllllllllllllIlIIIllIllIIIIlII = values()).length;
      char lllllllllllllllIlIIIllIllIIIIllI = lIlIIllIllll[0];
      "".length();
      if ("   ".length() <= " ".length()) {
        return;
      }
      while (!lIIIIIIlIllIlI(lllllllllllllllIlIIIllIllIIIIllI, lllllllllllllllIlIIIllIllIIIIlIl))
      {
        DirtType lllllllllllllllIlIIIllIllIIIlIII = lllllllllllllllIlIIIllIllIIIIlII[lllllllllllllllIlIIIllIllIIIIllI];
        METADATA_LOOKUP[lllllllllllllllIlIIIllIllIIIlIII.getMetadata()] = lllllllllllllllIlIIIllIllIIIlIII;
        lllllllllllllllIlIIIllIllIIIIllI++;
      }
    }
    
    private static void lIIIIIIIlIIlII()
    {
      lIlIIllIIlIl = new String[lIlIIllIllll[8]];
      lIlIIllIIlIl[lIlIIllIllll[0]] = lIIIIIIIIlllll("BiE7Bw==", "BhiSs");
      lIlIIllIIlIl[lIlIIllIllll[1]] = lIIIIIIIlIIIII("uhs8I+hCASc=", "iYzPx");
      lIlIIllIIlIl[lIlIIllIllll[2]] = lIIIIIIIIlllll("CiAMIBkCMQ==", "nEjAl");
      lIlIIllIIlIl[lIlIIllIllll[3]] = lIIIIIIIlIIIII("GvpELEKgc2875uAi+TGLeA==", "jQDVQ");
      lIlIIllIIlIl[lIlIIllIllll[4]] = lIIIIIIIlIIIlI("HaQlQZFPwv5bteZRH9UsRg==", "hAewX");
      lIlIIllIIlIl[lIlIIllIllll[5]] = lIIIIIIIIlllll("IQYxGRQn", "BiPkg");
      lIlIIllIIlIl[lIlIIllIllll[6]] = lIIIIIIIlIIIII("am7ecYiE++M=", "pwLeo");
      lIlIIllIIlIl[lIlIIllIllll[7]] = lIIIIIIIlIIIlI("XWA8wqXjFJI=", "IzhUa");
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private static boolean lIIIIIIlIlllII(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllIlIIIllIlIIIIllIl;
      return ??? < i;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    private static boolean lIIIIIIlIllIll(int ???)
    {
      boolean lllllllllllllllIlIIIllIlIIIIlIll;
      return ??? >= 0;
    }
    
    public static DirtType byMetadata(int lllllllllllllllIlIIIllIlIlIlIIll)
    {
      ;
      if ((!lIIIIIIlIllIll(lllllllllllllllIlIIIllIlIlIlIIll)) || (lIIIIIIlIllIlI(lllllllllllllllIlIIIllIlIlIlIIlI, METADATA_LOOKUP.length))) {
        lllllllllllllllIlIIIllIlIlIlIIlI = lIlIIllIllll[0];
      }
      return METADATA_LOOKUP[lllllllllllllllIlIIIllIlIlIlIIlI];
    }
    
    private static String lIIIIIIIlIIIII(String lllllllllllllllIlIIIllIlIIIllIlI, String lllllllllllllllIlIIIllIlIIIlIlll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIlIIIllIlIIIlllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIIIllIlIIIlIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIlIIIllIlIIIlllII = Cipher.getInstance("Blowfish");
        lllllllllllllllIlIIIllIlIIIlllII.init(lIlIIllIllll[2], lllllllllllllllIlIIIllIlIIIlllIl);
        return new String(lllllllllllllllIlIIIllIlIIIlllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIIIllIlIIIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIlIIIllIlIIIllIll)
      {
        lllllllllllllllIlIIIllIlIIIllIll.printStackTrace();
      }
      return null;
    }
    
    private static String lIIIIIIIIlllll(String lllllllllllllllIlIIIllIlIIlIllll, String lllllllllllllllIlIIIllIlIIlIlIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIlIIIllIlIIlIllll = new String(Base64.getDecoder().decode(lllllllllllllllIlIIIllIlIIlIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIlIIIllIlIIlIllIl = new StringBuilder();
      char[] lllllllllllllllIlIIIllIlIIlIllII = lllllllllllllllIlIIIllIlIIlIlIIl.toCharArray();
      int lllllllllllllllIlIIIllIlIIlIlIll = lIlIIllIllll[0];
      char lllllllllllllllIlIIIllIlIIlIIlIl = lllllllllllllllIlIIIllIlIIlIllll.toCharArray();
      short lllllllllllllllIlIIIllIlIIlIIlII = lllllllllllllllIlIIIllIlIIlIIlIl.length;
      String lllllllllllllllIlIIIllIlIIlIIIll = lIlIIllIllll[0];
      while (lIIIIIIlIlllII(lllllllllllllllIlIIIllIlIIlIIIll, lllllllllllllllIlIIIllIlIIlIIlII))
      {
        char lllllllllllllllIlIIIllIlIIllIIII = lllllllllllllllIlIIIllIlIIlIIlIl[lllllllllllllllIlIIIllIlIIlIIIll];
        "".length();
        "".length();
        if ("  ".length() <= ((0x8E ^ 0xA4 ^ 0x7D ^ 0x4C) & (0x3B ^ 0x4 ^ 0x85 ^ 0xA1 ^ -" ".length()))) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIlIIIllIlIIlIllIl);
    }
    
    private DirtType(int lllllllllllllllIlIIIllIlIlllIllI, String lllllllllllllllIlIIIllIlIlllIlIl, MapColor lllllllllllllllIlIIIllIlIllllIlI)
    {
      lllllllllllllllIlIIIllIlIllllIIl.<init>(lllllllllllllllIlIIIllIlIllllIII, lllllllllllllllIlIIIllIlIlllIlll, lllllllllllllllIlIIIllIlIlllIllI, lllllllllllllllIlIIIllIlIlllIlIl, lllllllllllllllIlIIIllIlIlllIlIl, lllllllllllllllIlIIIllIlIllllIlI);
    }
  }
}

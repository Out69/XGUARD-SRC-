package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockNetherWart
  extends BlockBush
{
  public int quantityDropped(Random lIIIlIllIlIlllI)
  {
    return lIIIlIllI[0];
  }
  
  public boolean canBlockStay(World lIIIlIlllIlllll, BlockPos lIIIlIlllIllllI, IBlockState lIIIlIlllIlllIl)
  {
    ;
    ;
    ;
    return lIIIlIlllIlllII.canPlaceBlockOn(lIIIlIlllIlllll.getBlockState(lIIIlIlllIllllI.down()).getBlock());
  }
  
  private static String lllIllIIII(String lIIIlIllIIIlllI, String lIIIlIllIIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIIIlIllIIIlllI = new String(Base64.getDecoder().decode(lIIIlIllIIIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIIIlIllIIlIIIl = new StringBuilder();
    char[] lIIIlIllIIlIIII = lIIIlIllIIIllIl.toCharArray();
    int lIIIlIllIIIllll = lIIIlIllI[0];
    int lIIIlIllIIIlIIl = lIIIlIllIIIlllI.toCharArray();
    double lIIIlIllIIIlIII = lIIIlIllIIIlIIl.length;
    String lIIIlIllIIIIlll = lIIIlIllI[0];
    while (lllIllIlII(lIIIlIllIIIIlll, lIIIlIllIIIlIII))
    {
      char lIIIlIllIIlIlII = lIIIlIllIIIlIIl[lIIIlIllIIIIlll];
      "".length();
      "".length();
      if (-"  ".length() >= 0) {
        return null;
      }
    }
    return String.valueOf(lIIIlIllIIlIIIl);
  }
  
  static
  {
    lllIllIIlI();
    lllIllIIIl();
  }
  
  private static boolean lllIllIllI(int ???, int arg1)
  {
    int i;
    Exception lIIIlIllIIIIIlI;
    return ??? >= i;
  }
  
  protected BlockNetherWart()
  {
    lIIIlIllllIlIll.<init>(Material.plants, MapColor.redColor);
    lIIIlIllllIlIIl.setDefaultState(blockState.getBaseState().withProperty(AGE, Integer.valueOf(lIIIlIllI[0])));
    "".length();
    float lIIIlIllllIlIlI = 0.5F;
    lIIIlIllllIlIIl.setBlockBounds(0.5F - lIIIlIllllIlIlI, 0.0F, 0.5F - lIIIlIllllIlIlI, 0.5F + lIIIlIllllIlIlI, 0.25F, 0.5F + lIIIlIllllIlIlI);
    "".length();
  }
  
  public int getMetaFromState(IBlockState lIIIlIllIlIIIIl)
  {
    ;
    return ((Integer)lIIIlIllIlIIIIl.getValue(AGE)).intValue();
  }
  
  private static boolean lllIllIlll(int ???)
  {
    long lIIIlIlIlllIllI;
    return ??? > 0;
  }
  
  protected boolean canPlaceBlockOn(Block lIIIlIllllIIlII)
  {
    ;
    if (lllIllIIll(lIIIlIllllIIlII, Blocks.soul_sand)) {
      return lIIIlIllI[2];
    }
    return lIIIlIllI[0];
  }
  
  private static void lllIllIIIl()
  {
    lIIIlIlIl = new String[lIIIlIllI[2]];
    lIIIlIlIl[lIIIlIllI[0]] = lllIllIIII("GBUv", "yrJJz");
  }
  
  private static void lllIllIIlI()
  {
    lIIIlIllI = new int[5];
    lIIIlIllI[0] = ((0x32 ^ 0x26) & (0x88 ^ 0x9C ^ 0xFFFFFFFF) & ((0x0 ^ 0x56) & (0x3C ^ 0x6A ^ 0xFFFFFFFF) ^ 0xFFFFFFFF));
    lIIIlIllI[1] = "   ".length();
    lIIIlIllI[2] = " ".length();
    lIIIlIllI[3] = (0xB9 ^ 0xB3);
    lIIIlIllI[4] = "  ".length();
  }
  
  public IBlockState getStateFromMeta(int lIIIlIllIlIIlIl)
  {
    ;
    ;
    return lIIIlIllIlIIllI.getDefaultState().withProperty(AGE, Integer.valueOf(lIIIlIllIlIIlIl));
  }
  
  private static boolean lllIllIlII(int ???, int arg1)
  {
    int i;
    String lIIIlIlIllllllI;
    return ??? < i;
  }
  
  public void updateTick(World lIIIlIlllIIllII, BlockPos lIIIlIlllIIlIll, IBlockState lIIIlIlllIIlIlI, Random lIIIlIlllIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int lIIIlIlllIIlllI = ((Integer)lIIIlIlllIIlIlI.getValue(AGE)).intValue();
    if ((lllIllIlII(lIIIlIlllIIlllI, lIIIlIllI[1])) && (lllIllIlIl(lIIIlIlllIIllll.nextInt(lIIIlIllI[3]))))
    {
      lIIIlIlllIIlIlI = lIIIlIlllIIlIlI.withProperty(AGE, Integer.valueOf(lIIIlIlllIIlllI + lIIIlIllI[2]));
      "".length();
    }
    lIIIlIlllIlIIll.updateTick(lIIIlIlllIIllII, lIIIlIlllIlIIIl, lIIIlIlllIIlIlI, lIIIlIlllIIllll);
  }
  
  public Item getItemDropped(IBlockState lIIIlIllIllIIlI, Random lIIIlIllIllIIIl, int lIIIlIllIllIIII)
  {
    return null;
  }
  
  public Item getItem(World lIIIlIllIlIllII, BlockPos lIIIlIllIlIlIll)
  {
    return Items.nether_wart;
  }
  
  public void dropBlockAsItemWithChance(World lIIIlIllIlllIIl, BlockPos lIIIlIllIlllIII, IBlockState lIIIlIllIllIlll, float lIIIlIllIllllIl, int lIIIlIllIllllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIllIlIl(isRemote))
    {
      int lIIIlIllIlllIll = lIIIlIllI[2];
      if (lllIllIllI(((Integer)lIIIlIllIlllllI.getValue(AGE)).intValue(), lIIIlIllI[1]))
      {
        lIIIlIllIlllIll = lIIIlIllI[4] + rand.nextInt(lIIIlIllI[1]);
        if (lllIllIlll(lIIIlIllIllllII)) {
          lIIIlIllIlllIll += rand.nextInt(lIIIlIllIllllII + lIIIlIllI[2]);
        }
      }
      int lIIIlIllIlllIlI = lIIIlIllI[0];
      "".length();
      if (" ".length() <= 0) {
        return;
      }
      while (!lllIllIllI(lIIIlIllIlllIlI, lIIIlIllIlllIll))
      {
        spawnAsEntity(lIIIlIllIlllIIl, lIIIlIllIlllIII, new ItemStack(Items.nether_wart));
        lIIIlIllIlllIlI++;
      }
    }
  }
  
  private static boolean lllIllIIll(Object ???, Object arg1)
  {
    Object localObject;
    boolean lIIIlIlIllllIlI;
    return ??? == localObject;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lIIIlIllIIlllll, new IProperty[] { AGE });
  }
  
  private static boolean lllIllIlIl(int ???)
  {
    double lIIIlIlIllllIII;
    return ??? == 0;
  }
}

package net.minecraft.block;

public class BlockButtonStone
  extends BlockButton
{
  static {}
  
  protected BlockButtonStone()
  {
    lllllllllllllllIIlIlIIlIIIIIIIll.<init>(lIlllllIIIII[0]);
  }
  
  private static void lIIlIIIlIIlIII()
  {
    lIlllllIIIII = new int[1];
    lIlllllIIIII[0] = ((0x7C ^ 0x25 ^ 0x1B ^ 0x14) & (0x35 ^ 0x30 ^ 0x35 ^ 0x66 ^ -" ".length()));
  }
}

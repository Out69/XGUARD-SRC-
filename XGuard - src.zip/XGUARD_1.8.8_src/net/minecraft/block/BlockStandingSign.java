package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockStandingSign
  extends BlockSign
{
  private static void lllIlIlIllIIII()
  {
    lIIllIIlIlIIl = new int[3];
    lIIllIIlIlIIl[0] = ((0xD ^ 0x42 ^ "  ".length()) & (0x8 ^ 0x3C ^ 0x11 ^ 0x68 ^ -" ".length()));
    lIIllIIlIlIIl[1] = (0x23 ^ 0x2C);
    lIIllIIlIlIIl[2] = " ".length();
  }
  
  private static void lllIlIlIlIlllI()
  {
    lIIllIIlIlIII = new String[lIIllIIlIlIIl[2]];
    lIIllIIlIlIII[lIIllIIlIlIIl[0]] = lllIlIlIlIllII("AywVKRgYLA8=", "qCaHl");
  }
  
  public void onNeighborBlockChange(World llllllllllllllIIllIllIlIIlIlllll, BlockPos llllllllllllllIIllIllIlIIlIllllI, IBlockState llllllllllllllIIllIllIlIIlIlllIl, Block llllllllllllllIIllIllIlIIlIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIlIlIllIIIl(llllllllllllllIIllIllIlIIlIlllll.getBlockState(llllllllllllllIIllIllIlIIllIIIll.down()).getBlock().getMaterial().isSolid()))
    {
      llllllllllllllIIllIllIlIIllIIIII.dropBlockAsItem(llllllllllllllIIllIllIlIIlIlllll, llllllllllllllIIllIllIlIIllIIIll, llllllllllllllIIllIllIlIIlIlllIl, lIIllIIlIlIIl[0]);
      "".length();
    }
    llllllllllllllIIllIllIlIIllIIIII.onNeighborBlockChange(llllllllllllllIIllIllIlIIlIlllll, llllllllllllllIIllIllIlIIllIIIll, llllllllllllllIIllIllIlIIlIlllIl, llllllllllllllIIllIllIlIIlIlllII);
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIIllIllIlIIlIllIII)
  {
    ;
    ;
    return llllllllllllllIIllIllIlIIlIllIIl.getDefaultState().withProperty(ROTATION, Integer.valueOf(llllllllllllllIIllIllIlIIlIllIII));
  }
  
  static
  {
    lllIlIlIllIIII();
    lllIlIlIlIlllI();
  }
  
  public BlockStandingSign()
  {
    llllllllllllllIIllIllIlIIllIlIll.setDefaultState(blockState.getBaseState().withProperty(ROTATION, Integer.valueOf(lIIllIIlIlIIl[0])));
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIIllIllIlIIlIlIIII, new IProperty[] { ROTATION });
  }
  
  private static boolean lllIlIlIllIIIl(int ???)
  {
    String llllllllllllllIIllIllIlIIIllIIIl;
    return ??? == 0;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIIllIllIlIIlIlIIll)
  {
    ;
    return ((Integer)llllllllllllllIIllIllIlIIlIlIIll.getValue(ROTATION)).intValue();
  }
  
  private static boolean lllIlIlIllIIlI(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIIllIllIlIIIllIIll;
    return ??? < i;
  }
  
  private static String lllIlIlIlIllII(String llllllllllllllIIllIllIlIIlIIIlII, String llllllllllllllIIllIllIlIIIlllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIllIlIIlIIIlII = new String(Base64.getDecoder().decode(llllllllllllllIIllIllIlIIlIIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIllIllIlIIlIIIIlI = new StringBuilder();
    char[] llllllllllllllIIllIllIlIIlIIIIIl = llllllllllllllIIllIllIlIIIlllllI.toCharArray();
    int llllllllllllllIIllIllIlIIlIIIIII = lIIllIIlIlIIl[0];
    int llllllllllllllIIllIllIlIIIlllIlI = llllllllllllllIIllIllIlIIlIIIlII.toCharArray();
    byte llllllllllllllIIllIllIlIIIlllIIl = llllllllllllllIIllIllIlIIIlllIlI.length;
    boolean llllllllllllllIIllIllIlIIIlllIII = lIIllIIlIlIIl[0];
    while (lllIlIlIllIIlI(llllllllllllllIIllIllIlIIIlllIII, llllllllllllllIIllIllIlIIIlllIIl))
    {
      char llllllllllllllIIllIllIlIIlIIIlIl = llllllllllllllIIllIllIlIIIlllIlI[llllllllllllllIIllIllIlIIIlllIII];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIllIllIlIIlIIIIlI);
  }
}

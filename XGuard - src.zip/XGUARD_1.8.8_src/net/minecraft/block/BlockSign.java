package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockSign
  extends BlockContainer
{
  protected BlockSign()
  {
    lllllllllllllllllIIllIlIIlIlllII.<init>(Material.wood);
    float lllllllllllllllllIIllIlIIlIllIll = 0.25F;
    float lllllllllllllllllIIllIlIIlIllIlI = 1.0F;
    lllllllllllllllllIIllIlIIlIllIIl.setBlockBounds(0.5F - lllllllllllllllllIIllIlIIlIllIll, 0.0F, 0.5F - lllllllllllllllllIIllIlIIlIllIll, 0.5F + lllllllllllllllllIIllIlIIlIllIll, lllllllllllllllllIIllIlIIlIllIlI, 0.5F + lllllllllllllllllIIllIlIIlIllIll);
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllllIIllIlIIIllllll, Random lllllllllllllllllIIllIlIIIlllllI, int lllllllllllllllllIIllIlIIIllllIl)
  {
    return Items.sign;
  }
  
  private static boolean llllIIlIIllI(int ???)
  {
    int lllllllllllllllllIIllIlIIIIlllIl;
    return ??? != 0;
  }
  
  private static void llllIIlIIlIl()
  {
    lIIllIIllll = new int[2];
    lIIllIIllll[0] = ((0xB3 ^ 0x93 ^ 0xF5 ^ 0x97) & ('ç' + '' - 357 + 221 ^ '¦' + '­' - 222 + 67 ^ -" ".length()));
    lIIllIIllll[1] = " ".length();
  }
  
  public AxisAlignedBB getSelectedBoundingBox(World lllllllllllllllllIIllIlIIlIIlllI, BlockPos lllllllllllllllllIIllIlIIlIIllIl)
  {
    ;
    ;
    ;
    lllllllllllllllllIIllIlIIlIIllll.setBlockBoundsBasedOnState(lllllllllllllllllIIllIlIIlIIlIll, lllllllllllllllllIIllIlIIlIIllIl);
    return lllllllllllllllllIIllIlIIlIIllll.getSelectedBoundingBox(lllllllllllllllllIIllIlIIlIIlIll, lllllllllllllllllIIllIlIIlIIllIl);
  }
  
  private static boolean llllIIlIIlll(int ???)
  {
    double lllllllllllllllllIIllIlIIIIllIll;
    return ??? == 0;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World lllllllllllllllllIIllIlIIlIlIlIl, BlockPos lllllllllllllllllIIllIlIIlIlIlII, IBlockState lllllllllllllllllIIllIlIIlIlIIll)
  {
    return null;
  }
  
  public boolean func_181623_g()
  {
    return lIIllIIllll[1];
  }
  
  static {}
  
  public boolean canPlaceBlockAt(World lllllllllllllllllIIllIlIIIlIIIII, BlockPos lllllllllllllllllIIllIlIIIIlllll)
  {
    ;
    ;
    ;
    if ((llllIIlIIlll(lllllllllllllllllIIllIlIIIlIIIIl.func_181087_e(lllllllllllllllllIIllIlIIIlIIIll, lllllllllllllllllIIllIlIIIIlllll))) && (llllIIlIIllI(lllllllllllllllllIIllIlIIIlIIIIl.canPlaceBlockAt(lllllllllllllllllIIllIlIIIlIIIll, lllllllllllllllllIIllIlIIIIlllll)))) {
      return lIIllIIllll[1];
    }
    return lIIllIIllll[0];
  }
  
  public Item getItem(World lllllllllllllllllIIllIlIIIlllIll, BlockPos lllllllllllllllllIIllIlIIIlllIlI)
  {
    return Items.sign;
  }
  
  public boolean onBlockActivated(World lllllllllllllllllIIllIlIIIllIlII, BlockPos lllllllllllllllllIIllIlIIIllIIll, IBlockState lllllllllllllllllIIllIlIIIllIIlI, EntityPlayer lllllllllllllllllIIllIlIIIllIIIl, EnumFacing lllllllllllllllllIIllIlIIIllIIII, float lllllllllllllllllIIllIlIIIlIllll, float lllllllllllllllllIIllIlIIIlIlllI, float lllllllllllllllllIIllIlIIIlIllIl)
  {
    ;
    ;
    ;
    ;
    if (llllIIlIIllI(isRemote)) {
      return lIIllIIllll[1];
    }
    TileEntity lllllllllllllllllIIllIlIIIlIllII = lllllllllllllllllIIllIlIIIllIlII.getTileEntity(lllllllllllllllllIIllIlIIIllIIll);
    if (llllIIlIIllI(lllllllllllllllllIIllIlIIIlIllII instanceof TileEntitySign))
    {
      "".length();
      if ("   ".length() != " ".length()) {
        break label113;
      }
      return ('' + 50 - 140 + 169 ^ 1 + 26 - 13 + 126) & (0x23 ^ 0x67 ^ 0x22 ^ 0x30 ^ -" ".length());
    }
    label113:
    return lIIllIIllll[0];
  }
  
  public boolean isPassable(IBlockAccess lllllllllllllllllIIllIlIIlIIIlll, BlockPos lllllllllllllllllIIllIlIIlIIIllI)
  {
    return lIIllIIllll[1];
  }
  
  public boolean isFullCube()
  {
    return lIIllIIllll[0];
  }
  
  public boolean isOpaqueCube()
  {
    return lIIllIIllll[0];
  }
  
  public TileEntity createNewTileEntity(World lllllllllllllllllIIllIlIIlIIIIlI, int lllllllllllllllllIIllIlIIlIIIIIl)
  {
    return new TileEntitySign();
  }
}

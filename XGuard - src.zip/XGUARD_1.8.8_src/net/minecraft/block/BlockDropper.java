package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.dispenser.IBehaviorDispenseItem;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityDropper;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public class BlockDropper
  extends BlockDispenser
{
  private static boolean lIIlIlIIllIIlI(Object ???)
  {
    float lllllllllllllllIIlIIIIlIIllllIll;
    return ??? == null;
  }
  
  public TileEntity createNewTileEntity(World lllllllllllllllIIlIIIIlIlIlIIIlI, int lllllllllllllllIIlIIIIlIlIlIIIIl)
  {
    return new TileEntityDropper();
  }
  
  static {}
  
  public BlockDropper() {}
  
  private static boolean lIIlIlIIllIIll(int ???)
  {
    long lllllllllllllllIIlIIIIlIIlllIlll;
    return ??? <= 0;
  }
  
  private static void lIIlIlIIlIllll()
  {
    llIIIIlllIll = new int[3];
    llIIIIlllIll[0] = (-(0xDF7D & 0x7C97) & 0xDFFF & 0x7FFD);
    llIIIIlllIll[1] = ((120 + '' - 189 + 97 ^ 4 + 126 - 89 + 121) & (8 + 47 - 27 + 110 ^ '' + 35 - 137 + 111 ^ -" ".length()));
    llIIIIlllIll[2] = " ".length();
  }
  
  protected IBehaviorDispenseItem getBehavior(ItemStack lllllllllllllllIIlIIIIlIlIlIIlIl)
  {
    ;
    return dropBehavior;
  }
  
  protected void dispense(World lllllllllllllllIIlIIIIlIlIIIlIII, BlockPos lllllllllllllllIIlIIIIlIlIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    BlockSourceImpl lllllllllllllllIIlIIIIlIlIIlIIlI = new BlockSourceImpl(lllllllllllllllIIlIIIIlIlIIlIlII, lllllllllllllllIIlIIIIlIlIIlIIll);
    TileEntityDispenser lllllllllllllllIIlIIIIlIlIIlIIIl = (TileEntityDispenser)lllllllllllllllIIlIIIIlIlIIlIIlI.getBlockTileEntity();
    if (lIIlIlIIllIIII(lllllllllllllllIIlIIIIlIlIIlIIIl))
    {
      int lllllllllllllllIIlIIIIlIlIIlIIII = lllllllllllllllIIlIIIIlIlIIlIIIl.getDispenseSlot();
      if (lIIlIlIIllIIIl(lllllllllllllllIIlIIIIlIlIIlIIII))
      {
        lllllllllllllllIIlIIIIlIlIIlIlII.playAuxSFX(llIIIIlllIll[0], lllllllllllllllIIlIIIIlIlIIlIIll, llIIIIlllIll[1]);
        "".length();
        if (((0xCB ^ 0x8E ^ "   ".length()) & (0xA1 ^ 0xB0 ^ 0xD ^ 0x5A ^ -" ".length())) == 0) {}
      }
      else
      {
        ItemStack lllllllllllllllIIlIIIIlIlIIIllll = lllllllllllllllIIlIIIIlIlIIlIIIl.getStackInSlot(lllllllllllllllIIlIIIIlIlIIlIIII);
        if (lIIlIlIIllIIII(lllllllllllllllIIlIIIIlIlIIIllll))
        {
          EnumFacing lllllllllllllllIIlIIIIlIlIIIlllI = (EnumFacing)lllllllllllllllIIlIIIIlIlIIlIlII.getBlockState(lllllllllllllllIIlIIIIlIlIIlIIll).getValue(FACING);
          BlockPos lllllllllllllllIIlIIIIlIlIIIllIl = lllllllllllllllIIlIIIIlIlIIlIIll.offset(lllllllllllllllIIlIIIIlIlIIIlllI);
          IInventory lllllllllllllllIIlIIIIlIlIIIllII = TileEntityHopper.getInventoryAtPosition(lllllllllllllllIIlIIIIlIlIIlIlII, lllllllllllllllIIlIIIIlIlIIIllIl.getX(), lllllllllllllllIIlIIIIlIlIIIllIl.getY(), lllllllllllllllIIlIIIIlIlIIIllIl.getZ());
          ItemStack lllllllllllllllIIlIIIIlIlIIIlIlI;
          if (lIIlIlIIllIIlI(lllllllllllllllIIlIIIIlIlIIIllII))
          {
            ItemStack lllllllllllllllIIlIIIIlIlIIIlIll = dropBehavior.dispense(lllllllllllllllIIlIIIIlIlIIlIIlI, lllllllllllllllIIlIIIIlIlIIIllll);
            if ((lIIlIlIIllIIII(lllllllllllllllIIlIIIIlIlIIIlIll)) && (lIIlIlIIllIIll(stackSize)))
            {
              lllllllllllllllIIlIIIIlIlIIIlIll = null;
              "".length();
              if ("   ".length() > -" ".length()) {}
            }
          }
          else
          {
            lllllllllllllllIIlIIIIlIlIIIlIlI = TileEntityHopper.putStackInInventoryAllSlots(lllllllllllllllIIlIIIIlIlIIIllII, lllllllllllllllIIlIIIIlIlIIIllll.copy().splitStack(llIIIIlllIll[2]), lllllllllllllllIIlIIIIlIlIIIlllI.getOpposite());
            if (lIIlIlIIllIIlI(lllllllllllllllIIlIIIIlIlIIIlIlI))
            {
              lllllllllllllllIIlIIIIlIlIIIlIlI = lllllllllllllllIIlIIIIlIlIIIllll.copy();
              if (lIIlIlIIllIIll(lllllllllllllllIIlIIIIlIlIIIlIlI.stackSize -= llIIIIlllIll[2]))
              {
                lllllllllllllllIIlIIIIlIlIIIlIlI = null;
                "".length();
                if (null == null) {}
              }
            }
            else
            {
              lllllllllllllllIIlIIIIlIlIIIlIlI = lllllllllllllllIIlIIIIlIlIIIllll.copy();
            }
          }
          lllllllllllllllIIlIIIIlIlIIlIIIl.setInventorySlotContents(lllllllllllllllIIlIIIIlIlIIlIIII, lllllllllllllllIIlIIIIlIlIIIlIlI);
        }
      }
    }
  }
  
  private static boolean lIIlIlIIllIIIl(int ???)
  {
    double lllllllllllllllIIlIIIIlIIllllIIl;
    return ??? < 0;
  }
  
  private static boolean lIIlIlIIllIIII(Object ???)
  {
    float lllllllllllllllIIlIIIIlIIlllllIl;
    return ??? != null;
  }
}

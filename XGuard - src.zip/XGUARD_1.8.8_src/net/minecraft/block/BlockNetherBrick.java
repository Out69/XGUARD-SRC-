package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;

public class BlockNetherBrick
  extends Block
{
  public MapColor getMapColor(IBlockState lllllllllllllllIlIlllIllIlIIIIlI)
  {
    return MapColor.netherrackColor;
  }
  
  public BlockNetherBrick()
  {
    lllllllllllllllIlIlllIllIlIIIlIl.<init>(Material.rock);
    "".length();
  }
}

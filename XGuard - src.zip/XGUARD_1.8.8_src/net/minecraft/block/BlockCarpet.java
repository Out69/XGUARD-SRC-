package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockCarpet
  extends Block
{
  private static boolean lIIIIlIllllIIl(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIIllllIlllIlIlllI;
    return ??? >= i;
  }
  
  private static void lIIIIlIlllIIIl()
  {
    lIlIllIIlIll = new String[lIlIllIlIIII[1]];
    lIlIllIIlIll[lIlIllIlIIII[0]] = lIIIIlIllIllll("SCrtgqGRkVk=", "rOGma");
  }
  
  public boolean isFullCube()
  {
    return lIlIllIlIIII[0];
  }
  
  public void onNeighborBlockChange(World lllllllllllllllIIllllIllllllllII, BlockPos lllllllllllllllIIlllllIIIIIIIIII, IBlockState lllllllllllllllIIllllIllllllllll, Block lllllllllllllllIIllllIlllllllllI)
  {
    ;
    ;
    ;
    ;
    "".length();
  }
  
  public int damageDropped(IBlockState lllllllllllllllIIllllIllllIllIII)
  {
    ;
    return ((EnumDyeColor)lllllllllllllllIIllllIllllIllIII.getValue(COLOR)).getMetadata();
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    lllllllllllllllIIlllllIIIIIlllll.setBlockBoundsFromMeta(lIlIllIlIIII[0]);
  }
  
  private static boolean lIIIIlIllllIII(Object ???, Object arg1)
  {
    Object localObject;
    float lllllllllllllllIIllllIlllIlIlIlI;
    return ??? == localObject;
  }
  
  public void getSubBlocks(Item lllllllllllllllIIllllIllllIIlllI, CreativeTabs lllllllllllllllIIllllIllllIlIIIl, List<ItemStack> lllllllllllllllIIllllIllllIIllIl)
  {
    ;
    ;
    ;
    int lllllllllllllllIIllllIllllIIllll = lIlIllIlIIII[0];
    "".length();
    if (((109 + 53 - 112 + 157 ^ 26 + 63 - 34 + 81) & (0x34 ^ 0x59 ^ 0x5B ^ 0x71 ^ -" ".length())) < ((0x86 ^ 0xAA ^ 0x6D ^ 0x7A) & ('' + 42 - -25 + 50 ^ '¥' + '' - 253 + 142 ^ -" ".length()))) {
      return;
    }
    while (!lIIIIlIllllIIl(lllllllllllllllIIllllIllllIIllll, lIlIllIlIIII[2]))
    {
      new ItemStack(lllllllllllllllIIllllIllllIIlllI, lIlIllIlIIII[1], lllllllllllllllIIllllIllllIIllll);
      "".length();
    }
  }
  
  private static boolean lIIIIlIlllIlll(int ???)
  {
    Exception lllllllllllllllIIllllIlllIlIIllI;
    return ??? == 0;
  }
  
  protected void setBlockBoundsFromMeta(int lllllllllllllllIIlllllIIIIIlIlIl)
  {
    ;
    ;
    ;
    int lllllllllllllllIIlllllIIIIIlIlII = lIlIllIlIIII[0];
    float lllllllllllllllIIlllllIIIIIlIIll = lIlIllIlIIII[1] * (lIlIllIlIIII[1] + lllllllllllllllIIlllllIIIIIlIlII) / 16.0F;
    lllllllllllllllIIlllllIIIIIlIllI.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, lllllllllllllllIIlllllIIIIIlIIll, 1.0F);
  }
  
  public boolean canPlaceBlockAt(World lllllllllllllllIIlllllIIIIIIlIII, BlockPos lllllllllllllllIIlllllIIIIIIIlll)
  {
    ;
    ;
    ;
    if ((lIIIIlIlllIlIl(lllllllllllllllIIlllllIIIIIIlIIl.canPlaceBlockAt(lllllllllllllllIIlllllIIIIIIlIll, lllllllllllllllIIlllllIIIIIIIlll))) && (lIIIIlIlllIlIl(lllllllllllllllIIlllllIIIIIIlIIl.canBlockStay(lllllllllllllllIIlllllIIIIIIlIll, lllllllllllllllIIlllllIIIIIIIlll)))) {
      return lIlIllIlIIII[1];
    }
    return lIlIllIlIIII[0];
  }
  
  public boolean isOpaqueCube()
  {
    return lIlIllIlIIII[0];
  }
  
  protected BlockCarpet()
  {
    lllllllllllllllIIlllllIIIIlIlIII.<init>(Material.carpet);
    lllllllllllllllIIlllllIIIIlIlIIl.setDefaultState(blockState.getBaseState().withProperty(COLOR, EnumDyeColor.WHITE));
    lllllllllllllllIIlllllIIIIlIlIIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.0625F, 1.0F);
    "".length();
    "".length();
    lllllllllllllllIIlllllIIIIlIlIIl.setBlockBoundsFromMeta(lIlIllIlIIII[0]);
  }
  
  public MapColor getMapColor(IBlockState lllllllllllllllIIlllllIIIIlIIlIl)
  {
    ;
    return ((EnumDyeColor)lllllllllllllllIIlllllIIIIlIIlIl.getValue(COLOR)).getMapColor();
  }
  
  private boolean canBlockStay(World lllllllllllllllIIllllIlllllIlIlI, BlockPos lllllllllllllllIIllllIlllllIlIIl)
  {
    ;
    ;
    if (lIIIIlIlllIlIl(lllllllllllllllIIllllIlllllIlIlI.isAirBlock(lllllllllllllllIIllllIlllllIlIIl.down())))
    {
      "".length();
      if (" ".length() == " ".length()) {
        break label59;
      }
      return (0x8C ^ 0x8A) & (0xB ^ 0xD ^ 0xFFFFFFFF);
    }
    label59:
    return lIlIllIlIIII[1];
  }
  
  public boolean shouldSideBeRendered(IBlockAccess lllllllllllllllIIllllIllllIlllIl, BlockPos lllllllllllllllIIllllIlllllIIIII, EnumFacing lllllllllllllllIIllllIllllIllIll)
  {
    ;
    ;
    ;
    ;
    if (lIIIIlIllllIII(lllllllllllllllIIllllIllllIllIll, EnumFacing.UP))
    {
      "".length();
      if ("  ".length() > 0) {
        break label79;
      }
      return (0xF7 ^ 0xB4 ^ (0xCF ^ 0x8D) & (0x53 ^ 0x11 ^ 0xFFFFFFFF)) & (0x29 ^ 0x42 ^ 0x38 ^ 0x10 ^ -" ".length());
    }
    label79:
    return lllllllllllllllIIllllIlllllIIIlI.shouldSideBeRendered(lllllllllllllllIIllllIllllIlllIl, lllllllllllllllIIllllIlllllIIIII, lllllllllllllllIIllllIllllIllIll);
  }
  
  private boolean checkForDrop(World lllllllllllllllIIllllIllllllIIII, BlockPos lllllllllllllllIIllllIllllllIIll, IBlockState lllllllllllllllIIllllIlllllIlllI)
  {
    ;
    ;
    ;
    ;
    if (lIIIIlIlllIlll(lllllllllllllllIIllllIllllllIlIl.canBlockStay(lllllllllllllllIIllllIllllllIIII, lllllllllllllllIIllllIllllllIIll)))
    {
      lllllllllllllllIIllllIllllllIlIl.dropBlockAsItem(lllllllllllllllIIllllIllllllIIII, lllllllllllllllIIllllIllllllIIll, lllllllllllllllIIllllIlllllIlllI, lIlIllIlIIII[0]);
      "".length();
      return lIlIllIlIIII[0];
    }
    return lIlIllIlIIII[1];
  }
  
  private static String lIIIIlIllIllll(String lllllllllllllllIIllllIlllIllIlll, String lllllllllllllllIIllllIlllIllIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIllllIlllIlllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllllIlllIllIllI.getBytes(StandardCharsets.UTF_8)), lIlIllIlIIII[3]), "DES");
      Cipher lllllllllllllllIIllllIlllIlllIIl = Cipher.getInstance("DES");
      lllllllllllllllIIllllIlllIlllIIl.init(lIlIllIlIIII[4], lllllllllllllllIIllllIlllIlllIlI);
      return new String(lllllllllllllllIIllllIlllIlllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllllIlllIllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIllllIlllIlllIII)
    {
      lllllllllllllllIIllllIlllIlllIII.printStackTrace();
    }
    return null;
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIIllllIllllIIlIII)
  {
    ;
    ;
    return lllllllllllllllIIllllIllllIIlIIl.getDefaultState().withProperty(COLOR, EnumDyeColor.byMetadata(lllllllllllllllIIllllIllllIIlIII));
  }
  
  private static void lIIIIlIlllIIll()
  {
    lIlIllIlIIII = new int[5];
    lIlIllIlIIII[0] = ((0x5C ^ 0x18 ^ 0x29 ^ 0x59) & (0x2B ^ 0x5F ^ 0x2A ^ 0x6A ^ -" ".length()));
    lIlIllIlIIII[1] = " ".length();
    lIlIllIlIIII[2] = (0x97 ^ 0xA5 ^ 0xE1 ^ 0xC3);
    lIlIllIlIIII[3] = (0xAF ^ 0xA7);
    lIlIllIlIIII[4] = "  ".length();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIIllllIllllIIIIII, new IProperty[] { COLOR });
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess lllllllllllllllIIlllllIIIIIlllII, BlockPos lllllllllllllllIIlllllIIIIIllIll)
  {
    ;
    lllllllllllllllIIlllllIIIIIllIlI.setBlockBoundsFromMeta(lIlIllIlIIII[0]);
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIIllllIllllIIIIlI)
  {
    ;
    return ((EnumDyeColor)lllllllllllllllIIllllIllllIIIIlI.getValue(COLOR)).getMetadata();
  }
  
  static
  {
    lIIIIlIlllIIll();
    lIIIIlIlllIIIl();
  }
  
  private static boolean lIIIIlIlllIlIl(int ???)
  {
    byte lllllllllllllllIIllllIlllIlIlIII;
    return ??? != 0;
  }
}

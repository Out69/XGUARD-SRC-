package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBanner;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.StatCollector;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockBanner
  extends BlockContainer
{
  private static String lIlllllIlIlIIl(String llllllllllllllIllIIlIllIIIlllIII, String llllllllllllllIllIIlIllIIIllIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIlIllIIIlllIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIlIllIIIllIlll.getBytes(StandardCharsets.UTF_8)), lllllIlIIlIl[9]), "DES");
      Cipher llllllllllllllIllIIlIllIIIlllIlI = Cipher.getInstance("DES");
      llllllllllllllIllIIlIllIIIlllIlI.init(lllllIlIIlIl[3], llllllllllllllIllIIlIllIIIlllIll);
      return new String(llllllllllllllIllIIlIllIIIlllIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIlIllIIIlllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIlIllIIIlllIIl)
    {
      llllllllllllllIllIIlIllIIIlllIIl.printStackTrace();
    }
    return null;
  }
  
  public boolean isOpaqueCube()
  {
    return lllllIlIIlIl[0];
  }
  
  private static boolean lIlllllIlllIII(int ???)
  {
    char llllllllllllllIllIIlIllIIIlIlIll;
    return ??? == 0;
  }
  
  private static boolean lIlllllIllIlll(int ???)
  {
    short llllllllllllllIllIIlIllIIIlIllIl;
    return ??? != 0;
  }
  
  private static void lIlllllIlIllII()
  {
    lllllIlIIIII = new String[lllllIlIIlIl[10]];
    lllllIlIIIII[lllllIlIIlIl[0]] = lIlllllIlIlIII("TPQ7FNcMIn4=", "GgURA");
    lllllIlIIIII[lllllIlIIlIl[1]] = lIlllllIlIlIIl("HRVuvzAfJye4chnsV5M6MQ==", "HshwH");
    lllllIlIIIII[lllllIlIIlIl[3]] = lIlllllIlIlIIl("ACc1RRwqtdoP9idVc+3RhE+yhnqSk4SU", "ACVTd");
    lllllIlIIIII[lllllIlIIlIl[4]] = lIlllllIlIlIlI("DA==", "tmCot");
    lllllIlIIIII[lllllIlIIlIl[5]] = lIlllllIlIlIlI("Lg==", "WtKoY");
    lllllIlIIIII[lllllIlIIlIl[6]] = lIlllllIlIlIIl("kKLhg/EHpFY=", "Fytlc");
    lllllIlIIIII[lllllIlIIlIl[7]] = lIlllllIlIlIlI("Pxc=", "VsVSN");
    lllllIlIIIII[lllllIlIIlIl[8]] = lIlllllIlIlIII("dmy/RlFRJDDP6r+XgWQ+Ow==", "rlpCo");
    lllllIlIIIII[lllllIlIIlIl[9]] = lIlllllIlIlIII("vIVdMB0LAcGqI0HPlUtZOQ==", "TPKqF");
  }
  
  static
  {
    lIlllllIllIllI();
    lIlllllIlIllII();
  }
  
  public Item getItem(World llllllllllllllIllIIlIllIlIllIlII, BlockPos llllllllllllllIllIIlIllIlIllIIll)
  {
    return Items.banner;
  }
  
  private static String lIlllllIlIlIlI(String llllllllllllllIllIIlIllIIlIlIlIl, String llllllllllllllIllIIlIllIIlIlIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIlIllIIlIlIlIl = new String(Base64.getDecoder().decode(llllllllllllllIllIIlIllIIlIlIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIIlIllIIlIllIII = new StringBuilder();
    char[] llllllllllllllIllIIlIllIIlIlIlll = llllllllllllllIllIIlIllIIlIlIlII.toCharArray();
    int llllllllllllllIllIIlIllIIlIlIllI = lllllIlIIlIl[0];
    float llllllllllllllIllIIlIllIIlIlIIII = llllllllllllllIllIIlIllIIlIlIlIl.toCharArray();
    float llllllllllllllIllIIlIllIIlIIllll = llllllllllllllIllIIlIllIIlIlIIII.length;
    String llllllllllllllIllIIlIllIIlIIlllI = lllllIlIIlIl[0];
    while (lIlllllIlllIIl(llllllllllllllIllIIlIllIIlIIlllI, llllllllllllllIllIIlIllIIlIIllll))
    {
      char llllllllllllllIllIIlIllIIlIlllIl = llllllllllllllIllIIlIllIIlIlIIII[llllllllllllllIllIIlIllIIlIIlllI];
      "".length();
      "".length();
      if ((105 + 4 - 57 + 110 ^ 83 + '' - 124 + 63) < "  ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIIlIllIIlIllIII);
  }
  
  public String getLocalizedName()
  {
    return StatCollector.translateToLocal(lllllIlIIIII[lllllIlIIlIl[3]]);
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIllIIlIllIlIlllIII, Random llllllllllllllIllIIlIllIlIllIlll, int llllllllllllllIllIIlIllIlIllIllI)
  {
    return Items.banner;
  }
  
  private static boolean lIlllllIlllIIl(int ???, int arg1)
  {
    int i;
    char llllllllllllllIllIIlIllIIIlIllll;
    return ??? < i;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIllIIlIllIllIIlllI, BlockPos llllllllllllllIllIIlIllIllIIllIl, IBlockState llllllllllllllIllIIlIllIllIIllII)
  {
    return null;
  }
  
  public AxisAlignedBB getSelectedBoundingBox(World llllllllllllllIllIIlIllIllIIIlll, BlockPos llllllllllllllIllIIlIllIllIIIllI)
  {
    ;
    ;
    ;
    llllllllllllllIllIIlIllIllIIlIII.setBlockBoundsBasedOnState(llllllllllllllIllIIlIllIllIIIlII, llllllllllllllIllIIlIllIllIIIllI);
    return llllllllllllllIllIIlIllIllIIlIII.getSelectedBoundingBox(llllllllllllllIllIIlIllIllIIIlII, llllllllllllllIllIIlIllIllIIIllI);
  }
  
  public void dropBlockAsItemWithChance(World llllllllllllllIllIIlIllIlIlIlIII, BlockPos llllllllllllllIllIIlIllIlIlIIlll, IBlockState llllllllllllllIllIIlIllIlIlIIllI, float llllllllllllllIllIIlIllIlIIlllII, int llllllllllllllIllIIlIllIlIlIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    TileEntity llllllllllllllIllIIlIllIlIlIIIll = llllllllllllllIllIIlIllIlIlIlIII.getTileEntity(llllllllllllllIllIIlIllIlIlIIlll);
    if (lIlllllIllIlll(llllllllllllllIllIIlIllIlIlIIIll instanceof TileEntityBanner))
    {
      ItemStack llllllllllllllIllIIlIllIlIlIIIlI = new ItemStack(Items.banner, lllllIlIIlIl[1], ((TileEntityBanner)llllllllllllllIllIIlIllIlIlIIIll).getBaseColor());
      NBTTagCompound llllllllllllllIllIIlIllIlIlIIIIl = new NBTTagCompound();
      llllllllllllllIllIIlIllIlIlIIIll.writeToNBT(llllllllllllllIllIIlIllIlIlIIIIl);
      llllllllllllllIllIIlIllIlIlIIIIl.removeTag(lllllIlIIIII[lllllIlIIlIl[4]]);
      llllllllllllllIllIIlIllIlIlIIIIl.removeTag(lllllIlIIIII[lllllIlIIlIl[5]]);
      llllllllllllllIllIIlIllIlIlIIIIl.removeTag(lllllIlIIIII[lllllIlIIlIl[6]]);
      llllllllllllllIllIIlIllIlIlIIIIl.removeTag(lllllIlIIIII[lllllIlIIlIl[7]]);
      llllllllllllllIllIIlIllIlIlIIIlI.setTagInfo(lllllIlIIIII[lllllIlIIlIl[8]], llllllllllllllIllIIlIllIlIlIIIIl);
      spawnAsEntity(llllllllllllllIllIIlIllIlIlIlIII, llllllllllllllIllIIlIllIlIlIIlll, llllllllllllllIllIIlIllIlIlIIIlI);
      "".length();
      if (" ".length() <= " ".length()) {}
    }
    else
    {
      llllllllllllllIllIIlIllIlIlIIIII.dropBlockAsItemWithChance(llllllllllllllIllIIlIllIlIlIlIII, llllllllllllllIllIIlIllIlIlIIlll, llllllllllllllIllIIlIllIlIlIIllI, llllllllllllllIllIIlIllIlIIlllII, llllllllllllllIllIIlIllIlIlIIlII);
    }
  }
  
  public void harvestBlock(World llllllllllllllIllIIlIllIlIIIIlII, EntityPlayer llllllllllllllIllIIlIllIIllllIlI, BlockPos llllllllllllllIllIIlIllIIllllIIl, IBlockState llllllllllllllIllIIlIllIlIIIIIIl, TileEntity llllllllllllllIllIIlIllIlIIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlllllIllIlll(llllllllllllllIllIIlIllIlIIIIIII instanceof TileEntityBanner))
    {
      TileEntityBanner llllllllllllllIllIIlIllIIlllllll = (TileEntityBanner)llllllllllllllIllIIlIllIlIIIIIII;
      ItemStack llllllllllllllIllIIlIllIIllllllI = new ItemStack(Items.banner, lllllIlIIlIl[1], ((TileEntityBanner)llllllllllllllIllIIlIllIlIIIIIII).getBaseColor());
      NBTTagCompound llllllllllllllIllIIlIllIIlllllIl = new NBTTagCompound();
      TileEntityBanner.func_181020_a(llllllllllllllIllIIlIllIIlllllIl, llllllllllllllIllIIlIllIIlllllll.getBaseColor(), llllllllllllllIllIIlIllIIlllllll.func_181021_d());
      llllllllllllllIllIIlIllIIllllllI.setTagInfo(lllllIlIIIII[lllllIlIIlIl[9]], llllllllllllllIllIIlIllIIlllllIl);
      spawnAsEntity(llllllllllllllIllIIlIllIlIIIIlII, llllllllllllllIllIIlIllIIllllIIl, llllllllllllllIllIIlIllIIllllllI);
      "".length();
      if (-"   ".length() < 0) {}
    }
    else
    {
      llllllllllllllIllIIlIllIIlllllII.harvestBlock(llllllllllllllIllIIlIllIlIIIIlII, llllllllllllllIllIIlIllIIllllIlI, llllllllllllllIllIIlIllIIllllIIl, llllllllllllllIllIIlIllIlIIIIIIl, null);
    }
  }
  
  public boolean func_181623_g()
  {
    return lllllIlIIlIl[1];
  }
  
  public TileEntity createNewTileEntity(World llllllllllllllIllIIlIllIlIlllIll, int llllllllllllllIllIIlIllIlIlllIlI)
  {
    return new TileEntityBanner();
  }
  
  private static void lIlllllIllIllI()
  {
    lllllIlIIlIl = new int[11];
    lllllIlIIlIl[0] = ((0x30 ^ 0xE) & (0xB7 ^ 0x89 ^ 0xFFFFFFFF));
    lllllIlIIlIl[1] = " ".length();
    lllllIlIIlIl[2] = (0x91 ^ 0x9E);
    lllllIlIIlIl[3] = "  ".length();
    lllllIlIIlIl[4] = "   ".length();
    lllllIlIIlIl[5] = (0x3F ^ 0x7F ^ 0xFD ^ 0xB9);
    lllllIlIIlIl[6] = (50 + '¦' - 162 + 122 ^ 84 + 47 - 71 + 121);
    lllllIlIIlIl[7] = (0x10 ^ 0x16);
    lllllIlIIlIl[8] = (80 + 69 - 60 + 51 ^ 38 + 24 - -68 + 9);
    lllllIlIIlIl[9] = (0xA4 ^ 0xAC);
    lllllIlIIlIl[10] = (0x54 ^ 0x5D);
  }
  
  protected BlockBanner()
  {
    llllllllllllllIllIIlIllIllIlIllI.<init>(Material.wood);
    float llllllllllllllIllIIlIllIllIlIlIl = 0.25F;
    float llllllllllllllIllIIlIllIllIlIlII = 1.0F;
    llllllllllllllIllIIlIllIllIlIIll.setBlockBounds(0.5F - llllllllllllllIllIIlIllIllIlIlIl, 0.0F, 0.5F - llllllllllllllIllIIlIllIllIlIlIl, 0.5F + llllllllllllllIllIIlIllIllIlIlIl, llllllllllllllIllIIlIllIllIlIlII, 0.5F + llllllllllllllIllIIlIllIllIlIlIl);
  }
  
  public boolean isPassable(IBlockAccess llllllllllllllIllIIlIllIllIIIIII, BlockPos llllllllllllllIllIIlIllIlIllllll)
  {
    return lllllIlIIlIl[1];
  }
  
  public boolean isFullCube()
  {
    return lllllIlIIlIl[0];
  }
  
  public boolean canPlaceBlockAt(World llllllllllllllIllIIlIllIlIIlIIII, BlockPos llllllllllllllIllIIlIllIlIIlIIlI)
  {
    ;
    ;
    ;
    if ((lIlllllIlllIII(llllllllllllllIllIIlIllIlIIlIIIl.func_181087_e(llllllllllllllIllIIlIllIlIIlIIll, llllllllllllllIllIIlIllIlIIlIIlI))) && (lIlllllIllIlll(llllllllllllllIllIIlIllIlIIlIIIl.canPlaceBlockAt(llllllllllllllIllIIlIllIlIIlIIll, llllllllllllllIllIIlIllIlIIlIIlI)))) {
      return lllllIlIIlIl[1];
    }
    return lllllIlIIlIl[0];
  }
  
  private static String lIlllllIlIlIII(String llllllllllllllIllIIlIllIIlIIIlIl, String llllllllllllllIllIIlIllIIlIIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIlIllIIlIIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIlIllIIlIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIIlIllIIlIIIlll = Cipher.getInstance("Blowfish");
      llllllllllllllIllIIlIllIIlIIIlll.init(lllllIlIIlIl[3], llllllllllllllIllIIlIllIIlIIlIII);
      return new String(llllllllllllllIllIIlIllIIlIIIlll.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIlIllIIlIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIlIllIIlIIIllI)
    {
      llllllllllllllIllIIlIllIIlIIIllI.printStackTrace();
    }
    return null;
  }
  
  public static class BlockBannerStanding
    extends BlockBanner
  {
    public int getMetaFromState(IBlockState llllllllllllllllIlIIIlllIlllIlII)
    {
      ;
      return ((Integer)llllllllllllllllIlIIIlllIlllIlII.getValue(ROTATION)).intValue();
    }
    
    private static boolean lIlIIllIIllIl(int ???)
    {
      boolean llllllllllllllllIlIIIlllIllIlllI;
      return ??? == 0;
    }
    
    private static void lIlIIllIIllII()
    {
      llIllIIIlll = new int[2];
      llIllIIIlll[0] = ("  ".length() & ("  ".length() ^ 0xFFFFFFFF));
      llIllIIIlll[1] = " ".length();
    }
    
    public BlockBannerStanding()
    {
      llllllllllllllllIlIIIllllIIIllII.setDefaultState(blockState.getBaseState().withProperty(ROTATION, Integer.valueOf(llIllIIIlll[0])));
    }
    
    protected BlockState createBlockState()
    {
      ;
      return new BlockState(llllllllllllllllIlIIIlllIlllIIIl, new IProperty[] { ROTATION });
    }
    
    public void onNeighborBlockChange(World llllllllllllllllIlIIIllllIIIIlIl, BlockPos llllllllllllllllIlIIIllllIIIIlII, IBlockState llllllllllllllllIlIIIlllIllllllI, Block llllllllllllllllIlIIIllllIIIIIlI)
    {
      ;
      ;
      ;
      ;
      ;
      if (lIlIIllIIllIl(llllllllllllllllIlIIIllllIIIIlIl.getBlockState(llllllllllllllllIlIIIlllIlllllll.down()).getBlock().getMaterial().isSolid()))
      {
        llllllllllllllllIlIIIllllIIIIllI.dropBlockAsItem(llllllllllllllllIlIIIllllIIIIlIl, llllllllllllllllIlIIIlllIlllllll, llllllllllllllllIlIIIlllIllllllI, llIllIIIlll[0]);
        "".length();
      }
      llllllllllllllllIlIIIllllIIIIllI.onNeighborBlockChange(llllllllllllllllIlIIIllllIIIIlIl, llllllllllllllllIlIIIlllIlllllll, llllllllllllllllIlIIIlllIllllllI, llllllllllllllllIlIIIllllIIIIIlI);
    }
    
    static {}
    
    public IBlockState getStateFromMeta(int llllllllllllllllIlIIIlllIllllIIl)
    {
      ;
      ;
      return llllllllllllllllIlIIIlllIllllIII.getDefaultState().withProperty(ROTATION, Integer.valueOf(llllllllllllllllIlIIIlllIllllIIl));
    }
  }
  
  public static class BlockBannerHanging
    extends BlockBanner
  {
    public void onNeighborBlockChange(World lllllllllllllllIIIIIIlllIIIllIlI, BlockPos lllllllllllllllIIIIIIlllIIIllIIl, IBlockState lllllllllllllllIIIIIIlllIIIllllI, Block lllllllllllllllIIIIIIlllIIIlllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      EnumFacing lllllllllllllllIIIIIIlllIIIlllII = (EnumFacing)lllllllllllllllIIIIIIlllIIIllllI.getValue(FACING);
      if (lIlIIIlIllIIIl(lllllllllllllllIIIIIIlllIIIllIlI.getBlockState(lllllllllllllllIIIIIIlllIIIlllll.offset(lllllllllllllllIIIIIIlllIIIlllII.getOpposite())).getBlock().getMaterial().isSolid()))
      {
        lllllllllllllllIIIIIIlllIIIllIll.dropBlockAsItem(lllllllllllllllIIIIIIlllIIIllIlI, lllllllllllllllIIIIIIlllIIIlllll, lllllllllllllllIIIIIIlllIIIllllI, llIlIlIIIIlI[0]);
        "".length();
      }
      lllllllllllllllIIIIIIlllIIIllIll.onNeighborBlockChange(lllllllllllllllIIIIIIlllIIIllIlI, lllllllllllllllIIIIIIlllIIIlllll, lllllllllllllllIIIIIIlllIIIllllI, lllllllllllllllIIIIIIlllIIIlllIl);
    }
    
    public void setBlockBoundsBasedOnState(IBlockAccess lllllllllllllllIIIIIIlllIIlllIII, BlockPos lllllllllllllllIIIIIIlllIIllIlll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      EnumFacing lllllllllllllllIIIIIIlllIIllIllI = (EnumFacing)lllllllllllllllIIIIIIlllIIlllIII.getBlockState(lllllllllllllllIIIIIIlllIIllIlll).getValue(FACING);
      float lllllllllllllllIIIIIIlllIIllIlIl = 0.0F;
      float lllllllllllllllIIIIIIlllIIllIlII = 0.78125F;
      float lllllllllllllllIIIIIIlllIIllIIll = 0.0F;
      float lllllllllllllllIIIIIIlllIIllIIlI = 1.0F;
      float lllllllllllllllIIIIIIlllIIllIIIl = 0.125F;
      lllllllllllllllIIIIIIlllIIllIIII.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
      switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[lllllllllllllllIIIIIIlllIIllIllI.ordinal()])
      {
      case 3: 
      default: 
        lllllllllllllllIIIIIIlllIIllIIII.setBlockBounds(lllllllllllllllIIIIIIlllIIllIIll, lllllllllllllllIIIIIIlllIIllIlIl, 1.0F - lllllllllllllllIIIIIIlllIIllIIIl, lllllllllllllllIIIIIIlllIIllIIlI, lllllllllllllllIIIIIIlllIIllIlII, 1.0F);
        "".length();
        if ("  ".length() < 0) {}
        break;
      case 4: 
        lllllllllllllllIIIIIIlllIIllIIII.setBlockBounds(lllllllllllllllIIIIIIlllIIllIIll, lllllllllllllllIIIIIIlllIIllIlIl, 0.0F, lllllllllllllllIIIIIIlllIIllIIlI, lllllllllllllllIIIIIIlllIIllIlII, lllllllllllllllIIIIIIlllIIllIIIl);
        "".length();
        if (((0x5F ^ 0x3F) & (0xC4 ^ 0xA4 ^ 0xFFFFFFFF)) != 0) {}
        break;
      case 5: 
        lllllllllllllllIIIIIIlllIIllIIII.setBlockBounds(1.0F - lllllllllllllllIIIIIIlllIIllIIIl, lllllllllllllllIIIIIIlllIIllIlIl, lllllllllllllllIIIIIIlllIIllIIll, 1.0F, lllllllllllllllIIIIIIlllIIllIlII, lllllllllllllllIIIIIIlllIIllIIlI);
        "".length();
        if (-(0xC ^ 0x64 ^ 0xD0 ^ 0xBC) >= 0) {}
        break;
      case 6: 
        lllllllllllllllIIIIIIlllIIllIIII.setBlockBounds(0.0F, lllllllllllllllIIIIIIlllIIllIlIl, lllllllllllllllIIIIIIlllIIllIIll, lllllllllllllllIIIIIIlllIIllIIIl, lllllllllllllllIIIIIIlllIIllIlII, lllllllllllllllIIIIIIlllIIllIIlI);
      }
    }
    
    public BlockBannerHanging()
    {
      lllllllllllllllIIIIIIlllIlIIIIll.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
    }
    
    private static boolean lIlIIIlIllIIll(Object ???)
    {
      boolean lllllllllllllllIIIIIIllIlllllllI;
      return ??? != null;
    }
    
    private static boolean lIlIIIlIllIIIl(int ???)
    {
      long lllllllllllllllIIIIIIllIllllllII;
      return ??? == 0;
    }
    
    private static void lIlIIIlIllIIII()
    {
      llIlIlIIIIlI = new int[7];
      llIlIlIIIIlI[0] = ((0x3 ^ 0xA ^ 0xC9 ^ 0x9E) & (0xF5 ^ 0xC4 ^ 0xD3 ^ 0xBC ^ -" ".length()));
      llIlIlIIIIlI[1] = " ".length();
      llIlIlIIIIlI[2] = (0x53 ^ 0x55);
      llIlIlIIIIlI[3] = "   ".length();
      llIlIlIIIIlI[4] = (0x7D ^ 0x79);
      llIlIlIIIIlI[5] = "  ".length();
      llIlIlIIIIlI[6] = (0xDE ^ 0xAE ^ 0x59 ^ 0x2C);
    }
    
    public int getMetaFromState(IBlockState lllllllllllllllIIIIIIlllIIIIlIIl)
    {
      ;
      return ((EnumFacing)lllllllllllllllIIIIIIlllIIIIlIIl.getValue(FACING)).getIndex();
    }
    
    public IBlockState getStateFromMeta(int lllllllllllllllIIIIIIlllIIIIlllI)
    {
      ;
      ;
      ;
      EnumFacing lllllllllllllllIIIIIIlllIIIlIIII = EnumFacing.getFront(lllllllllllllllIIIIIIlllIIIIlllI);
      if (lIlIIIlIllIIlI(lllllllllllllllIIIIIIlllIIIlIIII.getAxis(), EnumFacing.Axis.Y)) {
        lllllllllllllllIIIIIIlllIIIlIIII = EnumFacing.NORTH;
      }
      return lllllllllllllllIIIIIIlllIIIIllll.getDefaultState().withProperty(FACING, lllllllllllllllIIIIIIlllIIIlIIII);
    }
    
    protected BlockState createBlockState()
    {
      ;
      return new BlockState(lllllllllllllllIIIIIIlllIIIIIlll, new IProperty[] { FACING });
    }
    
    private static boolean lIlIIIlIllIIlI(Object ???, Object arg1)
    {
      Object localObject;
      char lllllllllllllllIIIIIIlllIIIIIIII;
      return ??? == localObject;
    }
    
    static {}
  }
}

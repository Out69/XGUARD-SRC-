package net.minecraft.block;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockRailPowered
  extends BlockRailBase
{
  private static String lIIlIIlIlIllII(String lllllllllllllllIIlIIllIIIIlIllIl, String lllllllllllllllIIlIIllIIIIllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIllIIIIlIllIl = new String(Base64.getDecoder().decode(lllllllllllllllIIlIIllIIIIlIllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlIIllIIIIllIIII = new StringBuilder();
    char[] lllllllllllllllIIlIIllIIIIlIllll = lllllllllllllllIIlIIllIIIIllIIIl.toCharArray();
    int lllllllllllllllIIlIIllIIIIlIlllI = llIIIIIIlIIl[0];
    String lllllllllllllllIIlIIllIIIIlIlIII = lllllllllllllllIIlIIllIIIIlIllIl.toCharArray();
    int lllllllllllllllIIlIIllIIIIlIIlll = lllllllllllllllIIlIIllIIIIlIlIII.length;
    long lllllllllllllllIIlIIllIIIIlIIllI = llIIIIIIlIIl[0];
    while (lIIlIIlIlllIII(lllllllllllllllIIlIIllIIIIlIIllI, lllllllllllllllIIlIIllIIIIlIIlll))
    {
      char lllllllllllllllIIlIIllIIIIllIIll = lllllllllllllllIIlIIllIIIIlIlIII[lllllllllllllllIIlIIllIIIIlIIllI];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlIIllIIIIllIIII);
  }
  
  private static boolean lIIlIIlIllIllI(int ???)
  {
    byte lllllllllllllllIIlIIllIIIIIIllIl;
    return ??? > 0;
  }
  
  protected BlockRailPowered()
  {
    lllllllllllllllIIlIIllIIlIIlllII.<init>(llIIIIIIlIIl[1]);
    lllllllllllllllIIlIIllIIlIIlllIl.setDefaultState(blockState.getBaseState().withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH).withProperty(POWERED, Boolean.valueOf(llIIIIIIlIIl[0])));
  }
  
  private static boolean lIIlIIlIllIIII(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIIlIIllIIIIlIIIIl;
    return ??? >= i;
  }
  
  private static boolean lIIlIIlIllIlIl(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIIlIIllIIIIIIlIIl;
    return ??? != i;
  }
  
  protected boolean func_176566_a(World lllllllllllllllIIlIIllIIlIIIIlII, BlockPos lllllllllllllllIIlIIllIIlIIIlllI, IBlockState lllllllllllllllIIlIIllIIlIIIIIlI, boolean lllllllllllllllIIlIIllIIlIIIllII, int lllllllllllllllIIlIIllIIlIIIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIlIIlIllIIII(lllllllllllllllIIlIIllIIlIIIlIll, llIIIIIIlIIl[2])) {
      return llIIIIIIlIIl[0];
    }
    int lllllllllllllllIIlIIllIIlIIIlIlI = lllllllllllllllIIlIIllIIlIIIlllI.getX();
    int lllllllllllllllIIlIIllIIlIIIlIIl = lllllllllllllllIIlIIllIIlIIIlllI.getY();
    int lllllllllllllllIIlIIllIIlIIIlIII = lllllllllllllllIIlIIllIIlIIIlllI.getZ();
    boolean lllllllllllllllIIlIIllIIlIIIIlll = llIIIIIIlIIl[1];
    BlockRailBase.EnumRailDirection lllllllllllllllIIlIIllIIlIIIIllI = (BlockRailBase.EnumRailDirection)lllllllllllllllIIlIIllIIlIIIIIlI.getValue(SHAPE);
    switch ($SWITCH_TABLE$net$minecraft$block$BlockRailBase$EnumRailDirection()[lllllllllllllllIIlIIllIIlIIIIllI.ordinal()])
    {
    case 1: 
      if (lIIlIIlIllIIIl(lllllllllllllllIIlIIllIIlIIIllII))
      {
        lllllllllllllllIIlIIllIIlIIIlIII++;
        "".length();
        if (((77 + '' - 166 + 119 ^ 25 + 11 - 34 + 143) & (15 + 17 - 27 + 158 ^ 90 + 14 - 25 + 68 ^ -" ".length())) != 0) {
          return ('±' + 97 - 75 + 36 ^ '¾' + 'Á' - 360 + 176) & (102 + 56 - -63 + 17 ^ 102 + 60 - 16 + 48 ^ -" ".length());
        }
      }
      else
      {
        lllllllllllllllIIlIIllIIlIIIlIII--;
        "".length();
        if (" ".length() > "   ".length()) {
          return (0x4 ^ 0xD) & (0x66 ^ 0x6F ^ 0xFFFFFFFF);
        }
      }
      break;
    case 2: 
      if (lIIlIIlIllIIIl(lllllllllllllllIIlIIllIIlIIIllII))
      {
        lllllllllllllllIIlIIllIIlIIIlIlI--;
        "".length();
        if (-(0x88 ^ 0x8C) >= 0) {
          return (0x62 ^ 0x2E) & (0x62 ^ 0x2E ^ 0xFFFFFFFF);
        }
      }
      else
      {
        lllllllllllllllIIlIIllIIlIIIlIlI++;
        "".length();
        if (-"  ".length() >= 0) {
          return (0xA2 ^ 0x82) & (0x14 ^ 0x34 ^ 0xFFFFFFFF);
        }
      }
      break;
    case 3: 
      if (lIIlIIlIllIIIl(lllllllllllllllIIlIIllIIlIIIllII))
      {
        lllllllllllllllIIlIIllIIlIIIlIlI--;
        "".length();
        if ("   ".length() < 0) {
          return ('»' + '' - 207 + 81 ^ '' + 2 - 148 + 148) & (0xAD ^ 0xB1 ^ 0x5 ^ 0x54 ^ -" ".length());
        }
      }
      else
      {
        lllllllllllllllIIlIIllIIlIIIlIlI++;
        lllllllllllllllIIlIIllIIlIIIlIIl++;
        lllllllllllllllIIlIIllIIlIIIIlll = llIIIIIIlIIl[0];
      }
      lllllllllllllllIIlIIllIIlIIIIllI = BlockRailBase.EnumRailDirection.EAST_WEST;
      "".length();
      if ("  ".length() > "   ".length()) {
        return (0x5D ^ 0x4 ^ 0x39 ^ 0x40) & ('©' + '¤' - 267 + 109 ^ 102 + 58 - 138 + 121 ^ -" ".length());
      }
      break;
    case 4: 
      if (lIIlIIlIllIIIl(lllllllllllllllIIlIIllIIlIIIllII))
      {
        lllllllllllllllIIlIIllIIlIIIlIlI--;
        lllllllllllllllIIlIIllIIlIIIlIIl++;
        lllllllllllllllIIlIIllIIlIIIIlll = llIIIIIIlIIl[0];
        "".length();
        if (null != null) {
          return (0x5C ^ 0x58 ^ 0x2C ^ 0x65) & (0x27 ^ 0x78 ^ 0x75 ^ 0x67 ^ -" ".length());
        }
      }
      else
      {
        lllllllllllllllIIlIIllIIlIIIlIlI++;
      }
      lllllllllllllllIIlIIllIIlIIIIllI = BlockRailBase.EnumRailDirection.EAST_WEST;
      "".length();
      if (-" ".length() > ((6 + 22 - -20 + 81 ^ 4 + 2 - -17 + 151) & (97 + '' - 165 + 82 ^ 103 + 72 - 154 + 115 ^ -" ".length()))) {
        return (0x90 ^ 0xBD ^ 0xCA ^ 0xA9) & (0x20 ^ 0x27 ^ 0x1E ^ 0x57 ^ -" ".length());
      }
      break;
    case 5: 
      if (lIIlIIlIllIIIl(lllllllllllllllIIlIIllIIlIIIllII))
      {
        lllllllllllllllIIlIIllIIlIIIlIII++;
        "".length();
        if ("  ".length() == 0) {
          return (0xF2 ^ 0xBA ^ 0xE1 ^ 0x98) & (0x1B ^ 0x51 ^ 0xF2 ^ 0x89 ^ -" ".length());
        }
      }
      else
      {
        lllllllllllllllIIlIIllIIlIIIlIII--;
        lllllllllllllllIIlIIllIIlIIIlIIl++;
        lllllllllllllllIIlIIllIIlIIIIlll = llIIIIIIlIIl[0];
      }
      lllllllllllllllIIlIIllIIlIIIIllI = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
      "".length();
      if ("   ".length() <= -" ".length()) {
        return (0xE7 ^ 0x8F ^ 0x5E ^ 0x1C) & (0x3C ^ 0x41 ^ 0x5E ^ 0x9 ^ -" ".length());
      }
      break;
    case 6: 
      if (lIIlIIlIllIIIl(lllllllllllllllIIlIIllIIlIIIllII))
      {
        lllllllllllllllIIlIIllIIlIIIlIII++;
        lllllllllllllllIIlIIllIIlIIIlIIl++;
        lllllllllllllllIIlIIllIIlIIIIlll = llIIIIIIlIIl[0];
        "".length();
        if ((0xA8 ^ 0xAC) <= "   ".length()) {
          return (0x15 ^ 0x2E) & (0x51 ^ 0x6A ^ 0xFFFFFFFF);
        }
      }
      else
      {
        lllllllllllllllIIlIIllIIlIIIlIII--;
      }
      lllllllllllllllIIlIIllIIlIIIIllI = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
    }
    if (lIIlIIlIllIIIl(lllllllllllllllIIlIIllIIlIIlIIII.func_176567_a(lllllllllllllllIIlIIllIIlIIIIlII, new BlockPos(lllllllllllllllIIlIIllIIlIIIlIlI, lllllllllllllllIIlIIllIIlIIIlIIl, lllllllllllllllIIlIIllIIlIIIlIII), lllllllllllllllIIlIIllIIlIIIllII, lllllllllllllllIIlIIllIIlIIIlIll, lllllllllllllllIIlIIllIIlIIIIllI)))
    {
      "".length();
      if (null != null) {
        return (0x8C ^ 0x9E) & (0x18 ^ 0xA ^ 0xFFFFFFFF);
      }
    }
    else if ((lIIlIIlIllIIIl(lllllllllllllllIIlIIllIIlIIIIlll)) && (lIIlIIlIllIIIl(lllllllllllllllIIlIIllIIlIIlIIII.func_176567_a(lllllllllllllllIIlIIllIIlIIIIlII, new BlockPos(lllllllllllllllIIlIIllIIlIIIlIlI, lllllllllllllllIIlIIllIIlIIIlIIl - llIIIIIIlIIl[1], lllllllllllllllIIlIIllIIlIIIlIII), lllllllllllllllIIlIIllIIlIIIllII, lllllllllllllllIIlIIllIIlIIIlIll, lllllllllllllllIIlIIllIIlIIIIllI))))
    {
      "".length();
      if ("   ".length() == "   ".length()) {
        break label1065;
      }
      return (60 + '' - 180 + 126 ^ '¨' + 113 - 250 + 164) & (0x23 ^ 0x79 ^ 0x2D ^ 0x39 ^ -" ".length());
    }
    label1065:
    return llIIIIIIlIIl[0];
  }
  
  private static void lIIlIIlIlIllIl()
  {
    llIIIIIIlIII = new String[llIIIIIIlIIl[5]];
    llIIIIIIlIII[llIIIIIIlIIl[0]] = lIIlIIlIlIllII("HAAtHCQ=", "ohLlA");
    llIIIIIIlIII[llIIIIIIlIIl[1]] = lIIlIIlIlIllII("Ny0DCQsiJg==", "GBtly");
  }
  
  private static boolean lIIlIIlIllIIIl(int ???)
  {
    long lllllllllllllllIIlIIllIIIIIlIIIl;
    return ??? != 0;
  }
  
  private static boolean lIIlIIlIllIlII(int ???)
  {
    short lllllllllllllllIIlIIllIIIIIIllll;
    return ??? == 0;
  }
  
  private static boolean lIIlIIlIllIIlI(Object ???, Object arg1)
  {
    Object localObject;
    byte lllllllllllllllIIlIIllIIIIIllIIl;
    return ??? != localObject;
  }
  
  private static boolean lIIlIIlIllIlll(Object ???)
  {
    int lllllllllllllllIIlIIllIIIIIlIIll;
    return ??? != null;
  }
  
  private static boolean lIIlIIlIlllIII(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIIlIIllIIIIIlllIl;
    return ??? < i;
  }
  
  private static void lIIlIIlIlIllll()
  {
    llIIIIIIlIIl = new int[11];
    llIIIIIIlIIl[0] = ((0x47 ^ 0x5) & (0x4B ^ 0x9 ^ 0xFFFFFFFF));
    llIIIIIIlIIl[1] = " ".length();
    llIIIIIIlIIl[2] = (0x3C ^ 0x34);
    llIIIIIIlIIl[3] = "   ".length();
    llIIIIIIlIIl[4] = (0x9D ^ 0x9A);
    llIIIIIIlIIl[5] = "  ".length();
    llIIIIIIlIIl[6] = (0xB9 ^ 0x93 ^ 0x79 ^ 0x56);
    llIIIIIIlIIl[7] = (0x17 ^ 0x11);
    llIIIIIIlIIl[8] = (0xA ^ 0xE);
    llIIIIIIlIIl[9] = (0x96 ^ 0x9C);
    llIIIIIIlIIl[10] = ("  ".length() ^ 0x1 ^ 0xA);
  }
  
  protected boolean func_176567_a(World lllllllllllllllIIlIIllIIIlllIIIl, BlockPos lllllllllllllllIIlIIllIIIlllIIII, boolean lllllllllllllllIIlIIllIIIllIIlll, int lllllllllllllllIIlIIllIIIllIIllI, BlockRailBase.EnumRailDirection lllllllllllllllIIlIIllIIIllIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState lllllllllllllllIIlIIllIIIllIllII = lllllllllllllllIIlIIllIIIlllIIIl.getBlockState(lllllllllllllllIIlIIllIIIlllIIII);
    if (lIIlIIlIllIIlI(lllllllllllllllIIlIIllIIIllIllII.getBlock(), lllllllllllllllIIlIIllIIIllIlIlI)) {
      return llIIIIIIlIIl[0];
    }
    BlockRailBase.EnumRailDirection lllllllllllllllIIlIIllIIIllIlIll = (BlockRailBase.EnumRailDirection)lllllllllllllllIIlIIllIIIllIllII.getValue(SHAPE);
    if ((!lIIlIIlIllIIll(lllllllllllllllIIlIIllIIIllIllIl, BlockRailBase.EnumRailDirection.EAST_WEST)) || ((lIIlIIlIllIIlI(lllllllllllllllIIlIIllIIIllIlIll, BlockRailBase.EnumRailDirection.NORTH_SOUTH)) && (lIIlIIlIllIIlI(lllllllllllllllIIlIIllIIIllIlIll, BlockRailBase.EnumRailDirection.ASCENDING_NORTH)) && (lIIlIIlIllIIlI(lllllllllllllllIIlIIllIIIllIlIll, BlockRailBase.EnumRailDirection.ASCENDING_SOUTH))))
    {
      if ((!lIIlIIlIllIIll(lllllllllllllllIIlIIllIIIllIllIl, BlockRailBase.EnumRailDirection.NORTH_SOUTH)) || ((lIIlIIlIllIIlI(lllllllllllllllIIlIIllIIIllIlIll, BlockRailBase.EnumRailDirection.EAST_WEST)) && (lIIlIIlIllIIlI(lllllllllllllllIIlIIllIIIllIlIll, BlockRailBase.EnumRailDirection.ASCENDING_EAST)) && (lIIlIIlIllIIlI(lllllllllllllllIIlIIllIIIllIlIll, BlockRailBase.EnumRailDirection.ASCENDING_WEST))))
      {
        if (lIIlIIlIllIIIl(((Boolean)lllllllllllllllIIlIIllIIIllIllII.getValue(POWERED)).booleanValue()))
        {
          if (lIIlIIlIllIIIl(lllllllllllllllIIlIIllIIIlllIIIl.isBlockPowered(lllllllllllllllIIlIIllIIIlllIIII)))
          {
            "".length();
            if ("  ".length() > 0) {
              break label368;
            }
            return (0xE4 ^ 0xC6) & (0x37 ^ 0x15 ^ 0xFFFFFFFF);
          }
          "".length();
          if (" ".length() != (0x5A ^ 0x70 ^ 0x57 ^ 0x79)) {
            break label368;
          }
          return (0x47 ^ 0x9 ^ 0x70 ^ 0x29) & (0x36 ^ 0x42 ^ 0x1 ^ 0x62 ^ -" ".length());
        }
        "".length();
        if (null == null) {
          break label368;
        }
        return (0x24 ^ 0x68) & (0x36 ^ 0x7A ^ 0xFFFFFFFF);
      }
      "".length();
      if ("  ".length() != 0) {
        break label368;
      }
      return (0x16 ^ 0x76 ^ 0xE5 ^ 0xAF) & (120 + 'Ã' - 84 + 5 ^ '' + 43 - 0 + 23 ^ -" ".length());
    }
    label368:
    return llIIIIIIlIIl[0];
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIIlIIllIIIIllllll, new IProperty[] { SHAPE, POWERED });
  }
  
  protected void onNeighborChangedInternal(World lllllllllllllllIIlIIllIIIlIlIlII, BlockPos lllllllllllllllIIlIIllIIIlIllIlI, IBlockState lllllllllllllllIIlIIllIIIlIllIIl, Block lllllllllllllllIIlIIllIIIlIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    boolean lllllllllllllllIIlIIllIIIlIlIlll = ((Boolean)lllllllllllllllIIlIIllIIIlIllIIl.getValue(POWERED)).booleanValue();
    if ((lIIlIIlIllIlII(lllllllllllllllIIlIIllIIIlIlIlII.isBlockPowered(lllllllllllllllIIlIIllIIIlIlIIll))) && (lIIlIIlIllIlII(lllllllllllllllIIlIIllIIIlIlllII.func_176566_a(lllllllllllllllIIlIIllIIIlIlIlII, lllllllllllllllIIlIIllIIIlIlIIll, lllllllllllllllIIlIIllIIIlIllIIl, llIIIIIIlIIl[1], llIIIIIIlIIl[0]))) && (lIIlIIlIllIlII(lllllllllllllllIIlIIllIIIlIlllII.func_176566_a(lllllllllllllllIIlIIllIIIlIlIlII, lllllllllllllllIIlIIllIIIlIlIIll, lllllllllllllllIIlIIllIIIlIllIIl, llIIIIIIlIIl[0], llIIIIIIlIIl[0]))))
    {
      "".length();
      if (-" ".length() < "   ".length()) {
        break label105;
      }
    }
    label105:
    boolean lllllllllllllllIIlIIllIIIlIlIllI = llIIIIIIlIIl[1];
    if (lIIlIIlIllIlIl(lllllllllllllllIIlIIllIIIlIlIllI, lllllllllllllllIIlIIllIIIlIlIlll))
    {
      "".length();
      lllllllllllllllIIlIIllIIIlIlIlII.notifyNeighborsOfStateChange(lllllllllllllllIIlIIllIIIlIlIIll.down(), lllllllllllllllIIlIIllIIIlIlllII);
      if (lIIlIIlIllIIIl(((BlockRailBase.EnumRailDirection)lllllllllllllllIIlIIllIIIlIllIIl.getValue(SHAPE)).isAscending())) {
        lllllllllllllllIIlIIllIIIlIlIlII.notifyNeighborsOfStateChange(lllllllllllllllIIlIIllIIIlIlIIll.up(), lllllllllllllllIIlIIllIIIlIlllII);
      }
    }
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIIlIIllIIIlIIlIll)
  {
    ;
    ;
    if (lIIlIIlIllIllI(lllllllllllllllIIlIIllIIIlIIlIll & llIIIIIIlIIl[2]))
    {
      "".length();
      if ("  ".length() != "   ".length()) {
        break label69;
      }
      return null;
    }
    label69:
    return POWERED.withProperty(llIIIIIIlIIl[1], Boolean.valueOf(llIIIIIIlIIl[0]));
  }
  
  private static boolean lIIlIIlIllIIll(Object ???, Object arg1)
  {
    Object localObject;
    long lllllllllllllllIIlIIllIIIIIlIlIl;
    return ??? == localObject;
  }
  
  static
  {
    lIIlIIlIlIllll();
    lIIlIIlIlIllIl();
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIIlIIllIIIlIIIIll)
  {
    ;
    ;
    int lllllllllllllllIIlIIllIIIlIIIlII = llIIIIIIlIIl[0];
    lllllllllllllllIIlIIllIIIlIIIlII |= ((BlockRailBase.EnumRailDirection)lllllllllllllllIIlIIllIIIlIIIlIl.getValue(SHAPE)).getMetadata();
    if (lIIlIIlIllIIIl(((Boolean)lllllllllllllllIIlIIllIIIlIIIlIl.getValue(POWERED)).booleanValue())) {
      lllllllllllllllIIlIIllIIIlIIIlII |= llIIIIIIlIIl[2];
    }
    return lllllllllllllllIIlIIllIIIlIIIlII;
  }
  
  public IProperty<BlockRailBase.EnumRailDirection> getShapeProperty()
  {
    return SHAPE;
  }
}

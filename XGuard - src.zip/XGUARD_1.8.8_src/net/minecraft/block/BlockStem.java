package net.minecraft.block;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockStem
  extends BlockBush
  implements IGrowable
{
  private static String lIllllllIIIIII(String llllllllllllllIllIIlIlIIIllllIIl, String llllllllllllllIllIIlIlIIIllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIlIlIIIllllIIl = new String(Base64.getDecoder().decode(llllllllllllllIllIIlIlIIIllllIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIIlIlIIIlllIlll = new StringBuilder();
    char[] llllllllllllllIllIIlIlIIIlllIllI = llllllllllllllIllIIlIlIIIllllIII.toCharArray();
    int llllllllllllllIllIIlIlIIIlllIlIl = lllllIlIlllI[0];
    Exception llllllllllllllIllIIlIlIIIllIllll = llllllllllllllIllIIlIlIIIllllIIl.toCharArray();
    float llllllllllllllIllIIlIlIIIllIlllI = llllllllllllllIllIIlIlIIIllIllll.length;
    boolean llllllllllllllIllIIlIlIIIllIllIl = lllllIlIlllI[0];
    while (lIllllllIlIlIl(llllllllllllllIllIIlIlIIIllIllIl, llllllllllllllIllIIlIlIIIllIlllI))
    {
      char llllllllllllllIllIIlIlIIIllllIlI = llllllllllllllIllIIlIlIIIllIllll[llllllllllllllIllIIlIlIIIllIllIl];
      "".length();
      "".length();
      if ("  ".length() == ((0x31 ^ 0x11) & (0xAD ^ 0x8D ^ 0xFFFFFFFF) & ((0x89 ^ 0xA7) & (0x3D ^ 0x13 ^ 0xFFFFFFFF) ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIIlIlIIIlllIlll);
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIllIIlIlIIllIIIIIl, Random llllllllllllllIllIIlIlIIllIIIIII, int llllllllllllllIllIIlIlIIlIllllll)
  {
    return null;
  }
  
  public void updateTick(World llllllllllllllIllIIlIlIlIIlIIlII, BlockPos llllllllllllllIllIIlIlIlIIlIllIl, IBlockState llllllllllllllIllIIlIlIlIIlIllII, Random llllllllllllllIllIIlIlIlIIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIlIlIlIIlIllll.updateTick(llllllllllllllIllIIlIlIlIIlIIlII, llllllllllllllIllIIlIlIlIIlIIIll, llllllllllllllIllIIlIlIlIIlIllII, llllllllllllllIllIIlIlIlIIlIIIIl);
    if (lIllllllIlIlII(llllllllllllllIllIIlIlIlIIlIIlII.getLightFromNeighbors(llllllllllllllIllIIlIlIlIIlIIIll.up()), lllllIlIlllI[3]))
    {
      float llllllllllllllIllIIlIlIlIIlIlIlI = BlockCrops.getGrowthChance(llllllllllllllIllIIlIlIlIIlIllll, llllllllllllllIllIIlIlIlIIlIIlII, llllllllllllllIllIIlIlIlIIlIIIll);
      if (lIllllllIlIIll(llllllllllllllIllIIlIlIlIIlIIIIl.nextInt((int)(25.0F / llllllllllllllIllIIlIlIlIIlIlIlI) + lllllIlIlllI[2])))
      {
        int llllllllllllllIllIIlIlIlIIlIlIIl = ((Integer)llllllllllllllIllIIlIlIlIIlIllII.getValue(AGE)).intValue();
        if (lIllllllIlIlIl(llllllllllllllIllIIlIlIlIIlIlIIl, lllllIlIlllI[1]))
        {
          llllllllllllllIllIIlIlIlIIlIllII = llllllllllllllIllIIlIlIlIIlIllII.withProperty(AGE, Integer.valueOf(llllllllllllllIllIIlIlIlIIlIlIIl + lllllIlIlllI[2]));
          "".length();
          "".length();
          if ("  ".length() >= 0) {}
        }
        else
        {
          llllllllllllllIllIIlIlIlIIIlllIl = EnumFacing.Plane.HORIZONTAL.iterator();
          "".length();
          if (('' + 98 - 165 + 73 ^ 48 + 98 - 14 + 16) < 0) {
            return;
          }
          while (!lIllllllIlIIll(llllllllllllllIllIIlIlIlIIIlllIl.hasNext()))
          {
            Object llllllllllllllIllIIlIlIlIIlIlIII = llllllllllllllIllIIlIlIlIIIlllIl.next();
            EnumFacing llllllllllllllIllIIlIlIlIIlIIlll = (EnumFacing)llllllllllllllIllIIlIlIlIIlIlIII;
            if (lIllllllIlIIIl(llllllllllllllIllIIlIlIlIIlIIlII.getBlockState(llllllllllllllIllIIlIlIlIIlIIIll.offset(llllllllllllllIllIIlIlIlIIlIIlll)).getBlock(), crop)) {
              return;
            }
          }
          llllllllllllllIllIIlIlIlIIlIIIll = llllllllllllllIllIIlIlIlIIlIIIll.offset(EnumFacing.Plane.HORIZONTAL.random(llllllllllllllIllIIlIlIlIIlIIIIl));
          Block llllllllllllllIllIIlIlIlIIlIIllI = llllllllllllllIllIIlIlIlIIlIIlII.getBlockState(llllllllllllllIllIIlIlIlIIlIIIll.down()).getBlock();
          if ((lIllllllIlIIIl(getBlockStategetBlockblockMaterial, Material.air)) && ((!lIllllllIlIlll(llllllllllllllIllIIlIlIlIIlIIllI, Blocks.farmland)) || (!lIllllllIlIlll(llllllllllllllIllIIlIlIlIIlIIllI, Blocks.dirt)) || (lIllllllIlIIIl(llllllllllllllIllIIlIlIlIIlIIllI, Blocks.grass)))) {
            "".length();
          }
        }
      }
    }
  }
  
  public IBlockState getActualState(IBlockState llllllllllllllIllIIlIlIlIlIIIIll, IBlockAccess llllllllllllllIllIIlIlIlIlIIIIlI, BlockPos llllllllllllllIllIIlIlIlIlIIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIlIlIlIlIIIIll = llllllllllllllIllIIlIlIlIlIIIIll.withProperty(FACING, EnumFacing.UP);
    double llllllllllllllIllIIlIlIlIIllllll = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if (-"  ".length() > 0) {
      return null;
    }
    while (!lIllllllIlIIll(llllllllllllllIllIIlIlIlIIllllll.hasNext()))
    {
      Object llllllllllllllIllIIlIlIlIlIIIllI = llllllllllllllIllIIlIlIlIIllllll.next();
      EnumFacing llllllllllllllIllIIlIlIlIlIIIlIl = (EnumFacing)llllllllllllllIllIIlIlIlIlIIIllI;
      if (lIllllllIlIIIl(llllllllllllllIllIIlIlIlIlIIIIlI.getBlockState(llllllllllllllIllIIlIlIlIlIIIIIl.offset(llllllllllllllIllIIlIlIlIlIIIlIl)).getBlock(), crop))
      {
        llllllllllllllIllIIlIlIlIlIIIIll = llllllllllllllIllIIlIlIlIlIIIIll.withProperty(FACING, llllllllllllllIllIIlIlIlIlIIIlIl);
        "".length();
        if (-" ".length() <= 0) {
          break;
        }
        return null;
      }
    }
    return llllllllllllllIllIIlIlIlIlIIIIll;
  }
  
  private static String lIllllllIIIIIl(String llllllllllllllIllIIlIlIIlIIIIlll, String llllllllllllllIllIIlIlIIlIIIIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIlIlIIlIIIllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIlIlIIlIIIIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIIlIlIIlIIIlIll = Cipher.getInstance("Blowfish");
      llllllllllllllIllIIlIlIIlIIIlIll.init(lllllIlIlllI[4], llllllllllllllIllIIlIlIIlIIIllII);
      return new String(llllllllllllllIllIIlIlIIlIIIlIll.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIlIlIIlIIIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIlIlIIlIIIlIlI)
    {
      llllllllllllllIllIIlIlIIlIIIlIlI.printStackTrace();
    }
    return null;
  }
  
  protected BlockStem(Block llllllllllllllIllIIlIlIlIlIllIll)
  {
    llllllllllllllIllIIlIlIlIlIlllII.setDefaultState(blockState.getBaseState().withProperty(AGE, Integer.valueOf(lllllIlIlllI[0])).withProperty(FACING, EnumFacing.UP));
    crop = llllllllllllllIllIIlIlIlIlIllIll;
    "".length();
    float llllllllllllllIllIIlIlIlIlIlllIl = 0.125F;
    llllllllllllllIllIIlIlIlIlIlllII.setBlockBounds(0.5F - llllllllllllllIllIIlIlIlIlIlllIl, 0.0F, 0.5F - llllllllllllllIllIIlIlIlIlIlllIl, 0.5F + llllllllllllllIllIIlIlIlIlIlllIl, 0.25F, 0.5F + llllllllllllllIllIIlIlIlIlIlllIl);
    "".length();
  }
  
  private static boolean lIllllllIlIlll(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllIllIIlIlIIIlIlllII;
    return ??? != localObject;
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    ;
    float llllllllllllllIllIIlIlIIlllIllll = 0.125F;
    llllllllllllllIllIIlIlIIllllIIII.setBlockBounds(0.5F - llllllllllllllIllIIlIlIIlllIllll, 0.0F, 0.5F - llllllllllllllIllIIlIlIIlllIllll, 0.5F + llllllllllllllIllIIlIlIIlllIllll, 0.25F, 0.5F + llllllllllllllIllIIlIlIIlllIllll);
  }
  
  public boolean canUseBonemeal(World llllllllllllllIllIIlIlIIlIlIlllI, Random llllllllllllllIllIIlIlIIlIlIllIl, BlockPos llllllllllllllIllIIlIlIIlIlIllII, IBlockState llllllllllllllIllIIlIlIIlIlIlIll)
  {
    return lllllIlIlllI[2];
  }
  
  public void grow(World llllllllllllllIllIIlIlIIlIlIIIII, Random llllllllllllllIllIIlIlIIlIlIIlII, BlockPos llllllllllllllIllIIlIlIIlIIlllll, IBlockState llllllllllllllIllIIlIlIIlIlIIIlI)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIllIIlIlIIlIlIIIIl.growStem(llllllllllllllIllIIlIlIIlIlIIIII, llllllllllllllIllIIlIlIIlIIlllll, llllllllllllllIllIIlIlIIlIlIIIlI);
  }
  
  protected Item getSeedItem()
  {
    ;
    if (lIllllllIlIIIl(crop, Blocks.pumpkin))
    {
      "".length();
      if (" ".length() <= -" ".length()) {
        return null;
      }
    }
    else if (lIllllllIlIIIl(crop, Blocks.melon_block))
    {
      "".length();
      if (" ".length() <= (0xAD ^ 0x9D ^ 0x90 ^ 0xA4)) {
        break label89;
      }
      return null;
    }
    label89:
    return null;
  }
  
  public void dropBlockAsItemWithChance(World llllllllllllllIllIIlIlIIllIIllIl, BlockPos llllllllllllllIllIIlIlIIllIlIlIl, IBlockState llllllllllllllIllIIlIlIIllIlIlII, float llllllllllllllIllIIlIlIIllIIlIlI, int llllllllllllllIllIIlIlIIllIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIlIlIIllIlIlll.dropBlockAsItemWithChance(llllllllllllllIllIIlIlIIllIIllIl, llllllllllllllIllIIlIlIIllIlIlIl, llllllllllllllIllIIlIlIIllIlIlII, llllllllllllllIllIIlIlIIllIIlIlI, llllllllllllllIllIIlIlIIllIIlIIl);
    if (lIllllllIlIIll(isRemote))
    {
      Item llllllllllllllIllIIlIlIIllIlIIIl = llllllllllllllIllIIlIlIIllIlIlll.getSeedItem();
      if (lIllllllIllIII(llllllllllllllIllIIlIlIIllIlIIIl))
      {
        int llllllllllllllIllIIlIlIIllIlIIII = ((Integer)llllllllllllllIllIIlIlIIllIlIlII.getValue(AGE)).intValue();
        int llllllllllllllIllIIlIlIIllIIllll = lllllIlIlllI[0];
        "".length();
        if (-" ".length() >= 0) {
          return;
        }
        while (!lIllllllIlIlII(llllllllllllllIllIIlIlIIllIIllll, lllllIlIlllI[12]))
        {
          if (lIllllllIllIIl(rand.nextInt(lllllIlIlllI[11]), llllllllllllllIllIIlIlIIllIlIIII)) {
            spawnAsEntity(llllllllllllllIllIIlIlIIllIIllIl, llllllllllllllIllIIlIlIIllIlIlIl, new ItemStack(llllllllllllllIllIIlIlIIllIlIIIl));
          }
          llllllllllllllIllIIlIlIIllIIllll++;
        }
      }
    }
  }
  
  private static boolean lIllllllIllIII(Object ???)
  {
    boolean llllllllllllllIllIIlIlIIIlIlIllI;
    return ??? != null;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIllIIlIlIIlIIlIlIl)
  {
    ;
    return ((Integer)llllllllllllllIllIIlIlIIlIIlIlIl.getValue(AGE)).intValue();
  }
  
  private static boolean lIllllllIllIlI(int ???, int arg1)
  {
    int i;
    char llllllllllllllIllIIlIlIIIlIlIIII;
    return ??? != i;
  }
  
  private static boolean lIllllllIlIIIl(Object ???, Object arg1)
  {
    Object localObject;
    byte llllllllllllllIllIIlIlIIIlIllIII;
    return ??? == localObject;
  }
  
  public int colorMultiplier(IBlockAccess llllllllllllllIllIIlIlIIllllIlII, BlockPos llllllllllllllIllIIlIlIIllllIlll, int llllllllllllllIllIIlIlIIllllIllI)
  {
    ;
    ;
    ;
    return llllllllllllllIllIIlIlIIlllllIIl.getRenderColor(llllllllllllllIllIIlIlIIllllIlII.getBlockState(llllllllllllllIllIIlIlIIllllIlll));
  }
  
  private static boolean lIllllllIlIlIl(int ???, int arg1)
  {
    int i;
    char llllllllllllllIllIIlIlIIIllIIlII;
    return ??? < i;
  }
  
  public void growStem(World llllllllllllllIllIIlIlIlIIIlIIlI, BlockPos llllllllllllllIllIIlIlIlIIIlIIIl, IBlockState llllllllllllllIllIIlIlIlIIIlIlII)
  {
    ;
    ;
    ;
    ;
    int llllllllllllllIllIIlIlIlIIIlIIll = ((Integer)llllllllllllllIllIIlIlIlIIIlIlII.getValue(AGE)).intValue() + MathHelper.getRandomIntegerInRange(rand, lllllIlIlllI[4], lllllIlIlllI[5]);
    "".length();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIllIIlIlIIlIIlIIlI, new IProperty[] { AGE, FACING });
  }
  
  static
  {
    lIllllllIIllll();
    lIllllllIIIIll();
  }
  
  private static void lIllllllIIIIll()
  {
    lllllIlIlIIl = new String[lllllIlIlllI[4]];
    lllllIlIlIIl[lllllIlIlllI[0]] = lIllllllIIIIII("MjAy", "SWWHL");
    lllllIlIlIIl[lllllIlIlllI[2]] = lIllllllIIIIIl("3SX/uCB9yQE=", "eElwP");
  }
  
  private static boolean lIllllllIlIIll(int ???)
  {
    double llllllllllllllIllIIlIlIIIlIlIlII;
    return ??? == 0;
  }
  
  public Item getItem(World llllllllllllllIllIIlIlIIlIlllIll, BlockPos llllllllllllllIllIIlIlIIlIlllIlI)
  {
    ;
    ;
    Item llllllllllllllIllIIlIlIIlIlllIIl = llllllllllllllIllIIlIlIIlIllllII.getSeedItem();
    if (lIllllllIllIII(llllllllllllllIllIIlIlIIlIlllIIl))
    {
      "".length();
      if ("  ".length() >= 0) {
        break label30;
      }
      return null;
    }
    label30:
    return null;
  }
  
  private static boolean lIllllllIllIIl(int ???, int arg1)
  {
    int i;
    char llllllllllllllIllIIlIlIIIllIIIII;
    return ??? <= i;
  }
  
  private static void lIllllllIIllll()
  {
    lllllIlIlllI = new int[13];
    lllllIlIlllI[0] = ((0x4E ^ 0x61) & (0x24 ^ 0xB ^ 0xFFFFFFFF));
    lllllIlIlllI[1] = (0x66 ^ 0xB ^ 0x1B ^ 0x71);
    lllllIlIlllI[2] = " ".length();
    lllllIlIlllI[3] = (0xC4 ^ 0xB0 ^ 0x10 ^ 0x6D);
    lllllIlIlllI[4] = "  ".length();
    lllllIlIlllI[5] = (0x6 ^ 0x3);
    lllllIlIlllI[6] = (0x63 ^ 0x75 ^ 0xB5 ^ 0x83);
    lllllIlIlllI[7] = (6 + 72 - 39 + 216);
    lllllIlIlllI[8] = (0x3A ^ 0x32);
    lllllIlIlllI[9] = (0x72 ^ 0x76);
    lllllIlIlllI[10] = (0x73 ^ 0x37 ^ 0x54 ^ 0x0);
    lllllIlIlllI[11] = (0x74 ^ 0x7B);
    lllllIlIlllI[12] = "   ".length();
  }
  
  private static boolean lIllllllIlIlII(int ???, int arg1)
  {
    int i;
    long llllllllllllllIllIIlIlIIIllIlIII;
    return ??? >= i;
  }
  
  public int getRenderColor(IBlockState llllllllllllllIllIIlIlIlIIIIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllllllIlIlll(llllllllllllllIllIIlIlIlIIIIIIIl.getBlock(), llllllllllllllIllIIlIlIlIIIIlIII)) {
      return llllllllllllllIllIIlIlIlIIIIlIII.getRenderColor(llllllllllllllIllIIlIlIlIIIIIIIl);
    }
    int llllllllllllllIllIIlIlIlIIIIIllI = ((Integer)llllllllllllllIllIIlIlIlIIIIIIIl.getValue(AGE)).intValue();
    int llllllllllllllIllIIlIlIlIIIIIlIl = llllllllllllllIllIIlIlIlIIIIIllI * lllllIlIlllI[6];
    int llllllllllllllIllIIlIlIlIIIIIlII = lllllIlIlllI[7] - llllllllllllllIllIIlIlIlIIIIIllI * lllllIlIlllI[8];
    int llllllllllllllIllIIlIlIlIIIIIIll = llllllllllllllIllIIlIlIlIIIIIllI * lllllIlIlllI[9];
    return llllllllllllllIllIIlIlIlIIIIIlIl << lllllIlIlllI[10] | llllllllllllllIllIIlIlIlIIIIIlII << lllllIlIlllI[8] | llllllllllllllIllIIlIlIlIIIIIIll;
  }
  
  public boolean canGrow(World llllllllllllllIllIIlIlIIlIllIlII, BlockPos llllllllllllllIllIIlIlIIlIllIIll, IBlockState llllllllllllllIllIIlIlIIlIllIIII, boolean llllllllllllllIllIIlIlIIlIllIIIl)
  {
    ;
    if (lIllllllIllIlI(((Integer)llllllllllllllIllIIlIlIIlIllIIII.getValue(AGE)).intValue(), lllllIlIlllI[1])) {
      return lllllIlIlllI[2];
    }
    return lllllIlIlllI[0];
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIllIIlIlIIlllIIlll, BlockPos llllllllllllllIllIIlIlIIlllIIllI)
  {
    ;
    ;
    ;
    ;
    maxY = ((((Integer)llllllllllllllIllIIlIlIIlllIIIll.getBlockState(llllllllllllllIllIIlIlIIlllIIllI).getValue(AGE)).intValue() * lllllIlIlllI[4] + lllllIlIlllI[4]) / 16.0F);
    float llllllllllllllIllIIlIlIIlllIIlIl = 0.125F;
    llllllllllllllIllIIlIlIIlllIlIII.setBlockBounds(0.5F - llllllllllllllIllIIlIlIIlllIIlIl, 0.0F, 0.5F - llllllllllllllIllIIlIlIIlllIIlIl, 0.5F + llllllllllllllIllIIlIlIIlllIIlIl, (float)maxY, 0.5F + llllllllllllllIllIIlIlIIlllIIlIl);
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIllIIlIlIIlIIllIII)
  {
    ;
    ;
    return llllllllllllllIllIIlIlIIlIIllIll.getDefaultState().withProperty(AGE, Integer.valueOf(llllllllllllllIllIIlIlIIlIIllIII));
  }
  
  protected boolean canPlaceBlockOn(Block llllllllllllllIllIIlIlIlIIlllIll)
  {
    ;
    if (lIllllllIlIIIl(llllllllllllllIllIIlIlIlIIlllIll, Blocks.farmland)) {
      return lllllIlIlllI[2];
    }
    return lllllIlIlllI[0];
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockRedstoneTorch
  extends BlockTorch
{
  protected BlockRedstoneTorch(boolean llllllllllllllllllIlllIIllIIlIll)
  {
    isOn = llllllllllllllllllIlllIIllIIlIll;
    "".length();
    "".length();
  }
  
  private static boolean lIlIllIIllIl(int ???)
  {
    boolean llllllllllllllllllIllIlllllllIIl;
    return ??? == 0;
  }
  
  private static boolean lIlIllIlIIll(int ???)
  {
    boolean llllllllllllllllllIllIllllllIlll;
    return ??? <= 0;
  }
  
  private static boolean lIlIllIIllll(int ???, int arg1)
  {
    int i;
    byte llllllllllllllllllIlllIIIIIIIlll;
    return ??? >= i;
  }
  
  public void updateTick(World llllllllllllllllllIlllIIIllllIIl, BlockPos llllllllllllllllllIlllIIIllllIII, IBlockState llllllllllllllllllIlllIIIlllIlll, Random llllllllllllllllllIlllIIIllIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    boolean llllllllllllllllllIlllIIIlllIlIl = llllllllllllllllllIlllIIIllIllll.shouldBeOff(llllllllllllllllllIlllIIIllllIIl, llllllllllllllllllIlllIIIllIllIl, llllllllllllllllllIlllIIIlllIlll);
    List<Toggle> llllllllllllllllllIlllIIIlllIlII = (List)toggles.get(llllllllllllllllllIlllIIIllllIIl);
    "".length();
    if (((0xE4 ^ 0x86 ^ 0xF3 ^ 0x87) & (0x60 ^ 0x3B ^ 0x20 ^ 0x6D ^ -" ".length())) != 0) {
      return;
    }
    while ((lIlIllIlIIlI(llllllllllllllllllIlllIIIlllIlII)) && (lIlIllIIllIl(llllllllllllllllllIlllIIIlllIlII.isEmpty())) && (!lIlIllIlIIll(lIlIllIlIIIl(llllllllllllllllllIlllIIIllllIIl.getTotalWorldTime() - getllIlIlllIl0time, 60L)))) {
      "".length();
    }
    if (lIlIllIIlllI(isOn))
    {
      if (lIlIllIIlllI(llllllllllllllllllIlllIIIlllIlIl))
      {
        "".length();
        if (lIlIllIIlllI(llllllllllllllllllIlllIIIllIllll.isBurnedOut(llllllllllllllllllIlllIIIllllIIl, llllllllllllllllllIlllIIIllIllIl, llIlIlllIl[2])))
        {
          llllllllllllllllllIlllIIIllllIIl.playSoundEffect(llllllllllllllllllIlllIIIllIllIl.getX() + 0.5F, llllllllllllllllllIlllIIIllIllIl.getY() + 0.5F, llllllllllllllllllIlllIIIllIllIl.getZ() + 0.5F, llIlIlllII[llIlIlllIl[0]], 0.5F, 2.6F + (rand.nextFloat() - rand.nextFloat()) * 0.8F);
          int llllllllllllllllllIlllIIIlllIIll = llIlIlllIl[0];
          "".length();
          if ("  ".length() != "  ".length()) {
            return;
          }
          while (!lIlIllIIllll(llllllllllllllllllIlllIIIlllIIll, llIlIlllIl[6]))
          {
            double llllllllllllllllllIlllIIIlllIIlI = llllllllllllllllllIlllIIIllIllIl.getX() + llllllllllllllllllIlllIIIllIlIll.nextDouble() * 0.6D + 0.2D;
            double llllllllllllllllllIlllIIIlllIIIl = llllllllllllllllllIlllIIIllIllIl.getY() + llllllllllllllllllIlllIIIllIlIll.nextDouble() * 0.6D + 0.2D;
            double llllllllllllllllllIlllIIIlllIIII = llllllllllllllllllIlllIIIllIllIl.getZ() + llllllllllllllllllIlllIIIllIlIll.nextDouble() * 0.6D + 0.2D;
            llllllllllllllllllIlllIIIllllIIl.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, llllllllllllllllllIlllIIIlllIIlI, llllllllllllllllllIlllIIIlllIIIl, llllllllllllllllllIlllIIIlllIIII, 0.0D, 0.0D, 0.0D, new int[llIlIlllIl[0]]);
          }
          llllllllllllllllllIlllIIIllllIIl.scheduleUpdate(llllllllllllllllllIlllIIIllIllIl, llllllllllllllllllIlllIIIllllIIl.getBlockState(llllllllllllllllllIlllIIIllIllIl).getBlock(), llIlIlllIl[7]);
          "".length();
          if ((0x6F ^ 0x6B) >= "   ".length()) {}
        }
      }
    }
    else if ((lIlIllIIllIl(llllllllllllllllllIlllIIIlllIlIl)) && (lIlIllIIllIl(llllllllllllllllllIlllIIIllIllll.isBurnedOut(llllllllllllllllllIlllIIIllllIIl, llllllllllllllllllIlllIIIllIllIl, llIlIlllIl[0])))) {
      "".length();
    }
  }
  
  public int tickRate(World llllllllllllllllllIlllIIllIIlIIl)
  {
    return llIlIlllIl[3];
  }
  
  private static boolean lIlIllIlIIII(Object ???, Object arg1)
  {
    Object localObject;
    double llllllllllllllllllIlllIIIIIIIIll;
    return ??? != localObject;
  }
  
  public int getStrongPower(IBlockAccess llllllllllllllllllIlllIIIlIlIIIl, BlockPos llllllllllllllllllIlllIIIlIlIIII, IBlockState llllllllllllllllllIlllIIIlIIllll, EnumFacing llllllllllllllllllIlllIIIlIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIlIllIlIlIl(llllllllllllllllllIlllIIIlIIlllI, EnumFacing.DOWN))
    {
      "".length();
      if (null == null) {
        break label51;
      }
      return (0xFD ^ 0xA8) & (0x8 ^ 0x5D ^ 0xFFFFFFFF);
    }
    label51:
    return llIlIlllIl[0];
  }
  
  private static void lIlIllIIllII()
  {
    llIlIlllIl = new int[8];
    llIlIlllIl[0] = ((0xA7 ^ 0xBE) & (0x31 ^ 0x28 ^ 0xFFFFFFFF));
    llIlIlllIl[1] = (0x96 ^ 0xC5 ^ 0x54 ^ 0xF);
    llIlIlllIl[2] = " ".length();
    llIlIlllIl[3] = "  ".length();
    llIlIlllIl[4] = (80 + 52 - 97 + 111 ^ '' + 45 - 55 + 32);
    llIlIlllIl[5] = "   ".length();
    llIlIlllIl[6] = (0x35 ^ 0x30);
    llIlIlllIl[7] = ((0x3F ^ 0x13) + (0x82 ^ 0xB9) - (0x7D ^ 0x2D) + (7 + '' - 137 + 131));
  }
  
  private static void lIlIllIIlIll()
  {
    llIlIlllII = new String[llIlIlllIl[2]];
    llIlIlllII[llIlIlllIl[0]] = lIlIllIIlIlI("ooM3heKnFXjzTe0EqPox5Q==", "HCDOH");
  }
  
  private boolean shouldBeOff(World llllllllllllllllllIlllIIlIIlIIlI, BlockPos llllllllllllllllllIlllIIlIIlIIIl, IBlockState llllllllllllllllllIlllIIlIIlIIII)
  {
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllllllIlllIIlIIIllll = ((EnumFacing)llllllllllllllllllIlllIIlIIlIIII.getValue(FACING)).getOpposite();
    return llllllllllllllllllIlllIIlIIlIIlI.isSidePowered(llllllllllllllllllIlllIIlIIIllIl.offset(llllllllllllllllllIlllIIlIIIllll), llllllllllllllllllIlllIIlIIIllll);
  }
  
  public void randomTick(World llllllllllllllllllIlllIIlIIIlIIl, BlockPos llllllllllllllllllIlllIIlIIIlIII, IBlockState llllllllllllllllllIlllIIlIIIIlll, Random llllllllllllllllllIlllIIlIIIIllI) {}
  
  private static String lIlIllIIlIlI(String llllllllllllllllllIlllIIIIIlIIlI, String llllllllllllllllllIlllIIIIIlIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIlllIIIIIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlllIIIIIlIIll.getBytes(StandardCharsets.UTF_8)), llIlIlllIl[1]), "DES");
      Cipher llllllllllllllllllIlllIIIIIlIllI = Cipher.getInstance("DES");
      llllllllllllllllllIlllIIIIIlIllI.init(llIlIlllIl[3], llllllllllllllllllIlllIIIIIlIlll);
      return new String(llllllllllllllllllIlllIIIIIlIllI.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlllIIIIIlIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIlllIIIIIlIlIl)
    {
      llllllllllllllllllIlllIIIIIlIlIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlIllIIlllI(int ???)
  {
    short llllllllllllllllllIllIlllllllIll;
    return ??? != 0;
  }
  
  public void randomDisplayTick(World llllllllllllllllllIlllIIIIllIlll, BlockPos llllllllllllllllllIlllIIIIlIlIll, IBlockState llllllllllllllllllIlllIIIIllIlIl, Random llllllllllllllllllIlllIIIIlIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIllIIlllI(isOn))
    {
      double llllllllllllllllllIlllIIIIllIIll = llllllllllllllllllIlllIIIIllIllI.getX() + 0.5D + (llllllllllllllllllIlllIIIIlIlIIl.nextDouble() - 0.5D) * 0.2D;
      double llllllllllllllllllIlllIIIIllIIlI = llllllllllllllllllIlllIIIIllIllI.getY() + 0.7D + (llllllllllllllllllIlllIIIIlIlIIl.nextDouble() - 0.5D) * 0.2D;
      double llllllllllllllllllIlllIIIIllIIIl = llllllllllllllllllIlllIIIIllIllI.getZ() + 0.5D + (llllllllllllllllllIlllIIIIlIlIIl.nextDouble() - 0.5D) * 0.2D;
      EnumFacing llllllllllllllllllIlllIIIIllIIII = (EnumFacing)llllllllllllllllllIlllIIIIllIlIl.getValue(FACING);
      if (lIlIllIIlllI(llllllllllllllllllIlllIIIIllIIII.getAxis().isHorizontal()))
      {
        EnumFacing llllllllllllllllllIlllIIIIlIllll = llllllllllllllllllIlllIIIIllIIII.getOpposite();
        double llllllllllllllllllIlllIIIIlIlllI = 0.27D;
        llllllllllllllllllIlllIIIIllIIll += 0.27D * llllllllllllllllllIlllIIIIlIllll.getFrontOffsetX();
        llllllllllllllllllIlllIIIIllIIlI += 0.22D;
        llllllllllllllllllIlllIIIIllIIIl += 0.27D * llllllllllllllllllIlllIIIIlIllll.getFrontOffsetZ();
      }
      llllllllllllllllllIlllIIIIllIlll.spawnParticle(EnumParticleTypes.REDSTONE, llllllllllllllllllIlllIIIIllIIll, llllllllllllllllllIlllIIIIllIIlI, llllllllllllllllllIlllIIIIllIIIl, 0.0D, 0.0D, 0.0D, new int[llIlIlllIl[0]]);
    }
  }
  
  private static boolean lIlIllIlIIlI(Object ???)
  {
    boolean llllllllllllllllllIlllIIIIIIIIIl;
    return ??? != null;
  }
  
  private static boolean lIlIllIlIlIl(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllllllIllIllllllllIl;
    return ??? == localObject;
  }
  
  public void breakBlock(World llllllllllllllllllIlllIIlIlIlIII, BlockPos llllllllllllllllllIlllIIlIlIIlll, IBlockState llllllllllllllllllIlllIIlIlIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIllIIlllI(isOn))
    {
      llllllllllllllllllIlllIIlIlIIlII = (llllllllllllllllllIlllIIlIlIIIll = EnumFacing.values()).length;
      llllllllllllllllllIlllIIlIlIIlIl = llIlIlllIl[0];
      "".length();
      if ("  ".length() == 0) {
        return;
      }
      while (!lIlIllIIllll(llllllllllllllllllIlllIIlIlIIlIl, llllllllllllllllllIlllIIlIlIIlII))
      {
        EnumFacing llllllllllllllllllIlllIIlIlIlIlI = llllllllllllllllllIlllIIlIlIIIll[llllllllllllllllllIlllIIlIlIIlIl];
        llllllllllllllllllIlllIIlIlIlIII.notifyNeighborsOfStateChange(llllllllllllllllllIlllIIlIlIIlll.offset(llllllllllllllllllIlllIIlIlIlIlI), llllllllllllllllllIlllIIlIlIlIIl);
        llllllllllllllllllIlllIIlIlIIlIl++;
      }
    }
  }
  
  public boolean isAssociatedBlock(Block llllllllllllllllllIlllIIIIIlllIl)
  {
    ;
    if ((lIlIllIlIIII(llllllllllllllllllIlllIIIIIlllIl, Blocks.unlit_redstone_torch)) && (lIlIllIlIIII(llllllllllllllllllIlllIIIIIlllII, Blocks.redstone_torch))) {
      return llIlIlllIl[0];
    }
    return llIlIlllIl[2];
  }
  
  public int getWeakPower(IBlockAccess llllllllllllllllllIlllIIlIIllllI, BlockPos llllllllllllllllllIlllIIlIIlllIl, IBlockState llllllllllllllllllIlllIIlIIlllII, EnumFacing llllllllllllllllllIlllIIlIIllIll)
  {
    ;
    ;
    ;
    if ((lIlIllIIlllI(isOn)) && (lIlIllIlIIII(llllllllllllllllllIlllIIlIIllIIl.getValue(FACING), llllllllllllllllllIlllIIlIIllIll)))
    {
      "".length();
      if (" ".length() >= 0) {
        break label91;
      }
      return (0xEC ^ 0xBD ^ 0x23 ^ 0x2A) & ((0x7F ^ 0x47) & (0x58 ^ 0x60 ^ 0xFFFFFFFF) ^ 0x1 ^ 0x59 ^ -" ".length());
    }
    label91:
    return llIlIlllIl[0];
  }
  
  private boolean isBurnedOut(World llllllllllllllllllIlllIIllIllllI, BlockPos llllllllllllllllllIlllIIllIlllIl, boolean llllllllllllllllllIlllIIllIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIllIIllIl(toggles.containsKey(llllllllllllllllllIlllIIllIllllI))) {
      "".length();
    }
    List<Toggle> llllllllllllllllllIlllIIllIllIll = (List)toggles.get(llllllllllllllllllIlllIIllIllllI);
    if (lIlIllIIlllI(llllllllllllllllllIlllIIllIlllII))
    {
      new Toggle(llllllllllllllllllIlllIIllIlIllI, llllllllllllllllllIlllIIllIllllI.getTotalWorldTime());
      "".length();
    }
    int llllllllllllllllllIlllIIllIllIlI = llIlIlllIl[0];
    int llllllllllllllllllIlllIIllIllIIl = llIlIlllIl[0];
    "".length();
    if (((0x4D ^ 0x36 ^ 0x7F ^ 0x20) & (0x26 ^ 0x5F ^ 0x5 ^ 0x58 ^ -" ".length())) >= " ".length()) {
      return (0x32 ^ 0xC ^ 0x21 ^ 0x3C) & (69 + '' - 32 + 5 ^ 99 + 25 - 113 + 132 ^ -" ".length());
    }
    while (!lIlIllIIllll(llllllllllllllllllIlllIIllIllIIl, llllllllllllllllllIlllIIllIllIll.size()))
    {
      Toggle llllllllllllllllllIlllIIllIllIII = (Toggle)llllllllllllllllllIlllIIllIllIll.get(llllllllllllllllllIlllIIllIllIIl);
      if ((lIlIllIIlllI(pos.equals(llllllllllllllllllIlllIIllIlIllI))) && (lIlIllIIllll(++llllllllllllllllllIlllIIllIllIlI, llIlIlllIl[1]))) {
        return llIlIlllIl[2];
      }
      llllllllllllllllllIlllIIllIllIIl++;
    }
    return llIlIlllIl[0];
  }
  
  static
  {
    lIlIllIIllII();
    lIlIllIIlIll();
  }
  
  public Item getItemDropped(IBlockState llllllllllllllllllIlllIIIlIIIlll, Random llllllllllllllllllIlllIIIlIIIllI, int llllllllllllllllllIlllIIIlIIIlIl)
  {
    return Item.getItemFromBlock(Blocks.redstone_torch);
  }
  
  public void onBlockAdded(World llllllllllllllllllIlllIIllIIIIII, BlockPos llllllllllllllllllIlllIIlIlllIlI, IBlockState llllllllllllllllllIlllIIlIlllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIllIIlllI(isOn))
    {
      llllllllllllllllllIlllIIlIllIlll = (llllllllllllllllllIlllIIlIllIllI = EnumFacing.values()).length;
      llllllllllllllllllIlllIIlIlllIII = llIlIlllIl[0];
      "".length();
      if (-" ".length() >= "  ".length()) {
        return;
      }
      while (!lIlIllIIllll(llllllllllllllllllIlllIIlIlllIII, llllllllllllllllllIlllIIlIllIlll))
      {
        EnumFacing llllllllllllllllllIlllIIlIllllIl = llllllllllllllllllIlllIIlIllIllI[llllllllllllllllllIlllIIlIlllIII];
        llllllllllllllllllIlllIIllIIIIII.notifyNeighborsOfStateChange(llllllllllllllllllIlllIIlIlllIlI.offset(llllllllllllllllllIlllIIlIllllIl), llllllllllllllllllIlllIIllIIIIIl);
        llllllllllllllllllIlllIIlIlllIII++;
      }
    }
  }
  
  public boolean canProvidePower()
  {
    return llIlIlllIl[2];
  }
  
  private static boolean lIlIllIlIlII(int ???, int arg1)
  {
    int i;
    char llllllllllllllllllIlllIIIIIIlIll;
    return ??? == i;
  }
  
  private static int lIlIllIlIIIl(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  public Item getItem(World llllllllllllllllllIlllIIIIlIIIIl, BlockPos llllllllllllllllllIlllIIIIlIIIII)
  {
    return Item.getItemFromBlock(Blocks.redstone_torch);
  }
  
  public void onNeighborBlockChange(World llllllllllllllllllIlllIIIlIlllll, BlockPos llllllllllllllllllIlllIIIlIllllI, IBlockState llllllllllllllllllIlllIIIlIlllIl, Block llllllllllllllllllIlllIIIlIlllII)
  {
    ;
    ;
    ;
    ;
    if ((lIlIllIIllIl(llllllllllllllllllIlllIIIllIIIII.onNeighborChangeInternal(llllllllllllllllllIlllIIIlIlllll, llllllllllllllllllIlllIIIlIllIIl, llllllllllllllllllIlllIIIlIlllIl))) && (lIlIllIlIlII(isOn, llllllllllllllllllIlllIIIllIIIII.shouldBeOff(llllllllllllllllllIlllIIIlIlllll, llllllllllllllllllIlllIIIlIllIIl, llllllllllllllllllIlllIIIlIlllIl)))) {
      llllllllllllllllllIlllIIIlIlllll.scheduleUpdate(llllllllllllllllllIlllIIIlIllIIl, llllllllllllllllllIlllIIIllIIIII, llllllllllllllllllIlllIIIllIIIII.tickRate(llllllllllllllllllIlllIIIlIlllll));
    }
  }
  
  static class Toggle
  {
    public Toggle(BlockPos llllllllllllllIlllIlIIIlIIIllllI, long llllllllllllllIlllIlIIIlIIIllIlI)
    {
      pos = llllllllllllllIlllIlIIIlIIIllIll;
      time = llllllllllllllIlllIlIIIlIIIllIlI;
    }
  }
}

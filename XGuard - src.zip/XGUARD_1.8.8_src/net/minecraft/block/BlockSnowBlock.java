package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.BlockPos;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;

public class BlockSnowBlock
  extends Block
{
  public Item getItemDropped(IBlockState lllllllllllllllIIlIllIllllllIlII, Random lllllllllllllllIIlIllIllllllIIll, int lllllllllllllllIIlIllIllllllIIlI)
  {
    return Items.snowball;
  }
  
  protected BlockSnowBlock()
  {
    lllllllllllllllIIlIllIllllllIllI.<init>(Material.craftedSnow);
    "".length();
    "".length();
  }
  
  public int quantityDropped(Random lllllllllllllllIIlIllIlllllIlllI)
  {
    return lIlllIIlIIII[1];
  }
  
  private static void lIIIlllIIIllII()
  {
    lIlllIIlIIII = new int[4];
    lIlllIIlIIII[0] = " ".length();
    lIlllIIlIIII[1] = (" ".length() ^ 0x4C ^ 0x49);
    lIlllIIlIIII[2] = (0xB8 ^ 0xA2 ^ 0x25 ^ 0x34);
    lIlllIIlIIII[3] = ((0x4A ^ 0x9) & (0xC2 ^ 0x81 ^ 0xFFFFFFFF));
  }
  
  public void updateTick(World lllllllllllllllIIlIllIlllllIIIll, BlockPos lllllllllllllllIIlIllIlllllIIIlI, IBlockState lllllllllllllllIIlIllIlllllIIIIl, Random lllllllllllllllIIlIllIlllllIIIII)
  {
    ;
    ;
    ;
    if (lIIIlllIIIllIl(lllllllllllllllIIlIllIlllllIIIll.getLightFor(EnumSkyBlock.BLOCK, lllllllllllllllIIlIllIllllIlllIl), lIlllIIlIIII[2]))
    {
      lllllllllllllllIIlIllIlllllIIlII.dropBlockAsItem(lllllllllllllllIIlIllIlllllIIIll, lllllllllllllllIIlIllIllllIlllIl, lllllllllllllllIIlIllIlllllIIIll.getBlockState(lllllllllllllllIIlIllIllllIlllIl), lIlllIIlIIII[3]);
      "".length();
    }
  }
  
  static {}
  
  private static boolean lIIIlllIIIllIl(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllIIlIllIllllIllIIl;
    return ??? > i;
  }
}

package net.minecraft.block;

import com.google.common.base.Objects;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockTripWireHook
  extends Block
{
  public int getWeakPower(IBlockAccess lllllllllllllllllIIIIllIlllIIIIl, BlockPos lllllllllllllllllIIIIllIlllIIIII, IBlockState lllllllllllllllllIIIIllIllIlllll, EnumFacing lllllllllllllllllIIIIllIllIllllI)
  {
    ;
    if (lIIIIIlllIlII(((Boolean)lllllllllllllllllIIIIllIllIlllll.getValue(POWERED)).booleanValue()))
    {
      "".length();
      if (((0x6C ^ 0xF) & (0xA4 ^ 0xC7 ^ 0xFFFFFFFF)) >= 0) {
        break label70;
      }
      return (0x63 ^ 0x50) & (0x7B ^ 0x48 ^ 0xFFFFFFFF);
    }
    label70:
    return lIlIlIlIllI[0];
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World lllllllllllllllllIIIIlllllIlIlII, BlockPos lllllllllllllllllIIIIlllllIlIIll, IBlockState lllllllllllllllllIIIIlllllIlIIlI)
  {
    return null;
  }
  
  public int getStrongPower(IBlockAccess lllllllllllllllllIIIIllIllIllIIl, BlockPos lllllllllllllllllIIIIllIllIllIII, IBlockState lllllllllllllllllIIIIllIllIlIlll, EnumFacing lllllllllllllllllIIIIllIllIlIllI)
  {
    ;
    ;
    if (lIIIIIlllIlIl(((Boolean)lllllllllllllllllIIIIllIllIlIlll.getValue(POWERED)).booleanValue()))
    {
      "".length();
      if ("   ".length() >= (0xC3 ^ 0xB3 ^ 0x34 ^ 0x40)) {
        return "   ".length() & ("   ".length() ^ -" ".length());
      }
    }
    else if (lIIIIIlllIlll(lllllllllllllllllIIIIllIllIlIlll.getValue(FACING), lllllllllllllllllIIIIllIllIlIllI))
    {
      "".length();
      if (-" ".length() <= (0xBA ^ 0xBE)) {
        break label151;
      }
      return (0x43 ^ 0x4) & (0x34 ^ 0x73 ^ 0xFFFFFFFF) & ((0x16 ^ 0x5C) & (0x59 ^ 0x13 ^ 0xFFFFFFFF) ^ 0xFFFFFFFF);
    }
    label151:
    return lIlIlIlIllI[0];
  }
  
  public boolean isFullCube()
  {
    return lIlIlIlIllI[0];
  }
  
  private static boolean lIIIIIlllIlll(Object ???, Object arg1)
  {
    Object localObject;
    double lllllllllllllllllIIIIllIIlllIllI;
    return ??? == localObject;
  }
  
  private static boolean lIIIIIlllIllI(Object ???, Object arg1)
  {
    Object localObject;
    byte lllllllllllllllllIIIIllIIllllIlI;
    return ??? != localObject;
  }
  
  public void func_176260_a(World lllllllllllllllllIIIIlllIllIllll, BlockPos lllllllllllllllllIIIIlllIlIlIIlI, IBlockState lllllllllllllllllIIIIlllIllIllIl, boolean lllllllllllllllllIIIIlllIlIlIIII, boolean lllllllllllllllllIIIIlllIlIIllll, int lllllllllllllllllIIIIlllIllIlIlI, IBlockState lllllllllllllllllIIIIlllIllIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing lllllllllllllllllIIIIlllIllIlIII = (EnumFacing)lllllllllllllllllIIIIlllIllIllIl.getValue(FACING);
    boolean lllllllllllllllllIIIIlllIllIIlll = ((Boolean)lllllllllllllllllIIIIlllIllIllIl.getValue(ATTACHED)).booleanValue();
    boolean lllllllllllllllllIIIIlllIllIIllI = ((Boolean)lllllllllllllllllIIIIlllIllIllIl.getValue(POWERED)).booleanValue();
    if (lIIIIIlllIlII(World.doesBlockHaveSolidTopSurface(lllllllllllllllllIIIIlllIllIllll, lllllllllllllllllIIIIlllIlIlIIlI.down())))
    {
      "".length();
      if (" ".length() < "  ".length()) {
        break label92;
      }
    }
    label92:
    boolean lllllllllllllllllIIIIlllIllIIlIl = lIlIlIlIllI[1];
    if (lIIIIIlllIlII(lllllllllllllllllIIIIlllIlIlIIII))
    {
      "".length();
      if (((2 + 118 - 47 + 88 ^ 34 + 91 - 34 + 97) & (0x5F ^ 0xD ^ 0x33 ^ 0x7C ^ -" ".length())) <= 0) {
        break label163;
      }
    }
    label163:
    boolean lllllllllllllllllIIIIlllIllIIlII = lIlIlIlIllI[1];
    boolean lllllllllllllllllIIIIlllIllIIIll = lIlIlIlIllI[0];
    int lllllllllllllllllIIIIlllIllIIIlI = lIlIlIlIllI[0];
    IBlockState[] lllllllllllllllllIIIIlllIllIIIIl = new IBlockState[lIlIlIlIllI[5]];
    int lllllllllllllllllIIIIlllIllIIIII = lIlIlIlIllI[1];
    "".length();
    if (-"  ".length() > 0) {
      return;
    }
    label417:
    label497:
    label543:
    while (!lIIIIIllllIlI(lllllllllllllllllIIIIlllIllIIIII, lIlIlIlIllI[5]))
    {
      BlockPos lllllllllllllllllIIIIlllIlIlllll = lllllllllllllllllIIIIlllIlIlIIlI.offset(lllllllllllllllllIIIIlllIllIlIII, lllllllllllllllllIIIIlllIllIIIII);
      IBlockState lllllllllllllllllIIIIlllIlIllllI = lllllllllllllllllIIIIlllIllIllll.getBlockState(lllllllllllllllllIIIIlllIlIlllll);
      if (lIIIIIlllIlll(lllllllllllllllllIIIIlllIlIllllI.getBlock(), Blocks.tripwire_hook))
      {
        if (!lIIIIIlllIlll(lllllllllllllllllIIIIlllIlIllllI.getValue(FACING), lllllllllllllllllIIIIlllIllIlIII.getOpposite())) {
          break;
        }
        lllllllllllllllllIIIIlllIllIIIlI = lllllllllllllllllIIIIlllIllIIIII;
        "".length();
        if (-" ".length() == -" ".length()) {
          break;
        }
        return;
      }
      if ((lIIIIIlllIllI(lllllllllllllllllIIIIlllIlIllllI.getBlock(), Blocks.tripwire)) && (lIIIIIllllIII(lllllllllllllllllIIIIlllIllIIIII, lllllllllllllllllIIIIlllIllIlIlI)))
      {
        lllllllllllllllllIIIIlllIllIIIIl[lllllllllllllllllIIIIlllIllIIIII] = null;
        lllllllllllllllllIIIIlllIllIIlII = lIlIlIlIllI[0];
        "".length();
        if (-" ".length() < 0) {}
      }
      else
      {
        if (lIIIIIllllIIl(lllllllllllllllllIIIIlllIllIIIII, lllllllllllllllllIIIIlllIllIlIlI)) {
          lllllllllllllllllIIIIlllIlIllllI = (IBlockState)Objects.firstNonNull(lllllllllllllllllIIIIlllIllIlIIl, lllllllllllllllllIIIIlllIlIllllI);
        }
        if (lIIIIIlllIlII(((Boolean)lllllllllllllllllIIIIlllIlIllllI.getValue(BlockTripWire.DISARMED)).booleanValue()))
        {
          "".length();
          if ("   ".length() != 0) {
            break label417;
          }
        }
        boolean lllllllllllllllllIIIIlllIlIlllIl = lIlIlIlIllI[1];
        boolean lllllllllllllllllIIIIlllIlIlllII = ((Boolean)lllllllllllllllllIIIIlllIlIllllI.getValue(BlockTripWire.POWERED)).booleanValue();
        boolean lllllllllllllllllIIIIlllIlIllIll = ((Boolean)lllllllllllllllllIIIIlllIlIllllI.getValue(BlockTripWire.SUSPENDED)).booleanValue();
        if (lIIIIIllllIIl(lllllllllllllllllIIIIlllIlIllIll, lllllllllllllllllIIIIlllIllIIlIl))
        {
          "".length();
          if (" ".length() == " ".length()) {
            break label497;
          }
        }
        lllllllllllllllllIIIIlllIllIIlII = lIlIlIlIllI[1] & lIlIlIlIllI[0];
        if ((lIIIIIlllIlII(lllllllllllllllllIIIIlllIlIlllIl)) && (lIIIIIlllIlII(lllllllllllllllllIIIIlllIlIlllII)))
        {
          "".length();
          if (" ".length() != 0) {
            break label543;
          }
        }
        lllllllllllllllllIIIIlllIllIIIll = lIlIlIlIllI[1] | lIlIlIlIllI[0];
        lllllllllllllllllIIIIlllIllIIIIl[lllllllllllllllllIIIIlllIllIIIII] = lllllllllllllllllIIIIlllIlIllllI;
        if (lIIIIIllllIIl(lllllllllllllllllIIIIlllIllIIIII, lllllllllllllllllIIIIlllIllIlIlI))
        {
          lllllllllllllllllIIIIlllIllIllll.scheduleUpdate(lllllllllllllllllIIIIlllIlIlIIlI, lllllllllllllllllIIIIlllIlIlIlII, lllllllllllllllllIIIIlllIlIlIlII.tickRate(lllllllllllllllllIIIIlllIllIllll));
          lllllllllllllllllIIIIlllIllIIlII &= lllllllllllllllllIIIIlllIlIlllIl;
        }
      }
      lllllllllllllllllIIIIlllIllIIIII++;
    }
    if (lIIIIIllllIll(lllllllllllllllllIIIIlllIllIIIlI, lIlIlIlIllI[1]))
    {
      "".length();
      if ("  ".length() == "  ".length()) {
        break label642;
      }
    }
    label642:
    lllllllllllllllllIIIIlllIllIIlII = lIlIlIlIllI[1] & lIlIlIlIllI[0];
    lllllllllllllllllIIIIlllIllIIIll &= lllllllllllllllllIIIIlllIllIIlII;
    IBlockState lllllllllllllllllIIIIlllIlIllIlI = lllllllllllllllllIIIIlllIlIlIlII.getDefaultState().withProperty(ATTACHED, Boolean.valueOf(lllllllllllllllllIIIIlllIllIIlII)).withProperty(POWERED, Boolean.valueOf(lllllllllllllllllIIIIlllIllIIIll));
    if (lIIIIIlllllII(lllllllllllllllllIIIIlllIllIIIlI))
    {
      BlockPos lllllllllllllllllIIIIlllIlIllIIl = lllllllllllllllllIIIIlllIlIlIIlI.offset(lllllllllllllllllIIIIlllIllIlIII, lllllllllllllllllIIIIlllIllIIIlI);
      EnumFacing lllllllllllllllllIIIIlllIlIllIII = lllllllllllllllllIIIIlllIllIlIII.getOpposite();
      "".length();
      lllllllllllllllllIIIIlllIlIlIlII.func_176262_b(lllllllllllllllllIIIIlllIllIllll, lllllllllllllllllIIIIlllIlIllIIl, lllllllllllllllllIIIIlllIlIllIII);
      lllllllllllllllllIIIIlllIlIlIlII.func_180694_a(lllllllllllllllllIIIIlllIllIllll, lllllllllllllllllIIIIlllIlIllIIl, lllllllllllllllllIIIIlllIllIIlII, lllllllllllllllllIIIIlllIllIIIll, lllllllllllllllllIIIIlllIllIIlll, lllllllllllllllllIIIIlllIllIIllI);
    }
    lllllllllllllllllIIIIlllIlIlIlII.func_180694_a(lllllllllllllllllIIIIlllIllIllll, lllllllllllllllllIIIIlllIlIlIIlI, lllllllllllllllllIIIIlllIllIIlII, lllllllllllllllllIIIIlllIllIIIll, lllllllllllllllllIIIIlllIllIIlll, lllllllllllllllllIIIIlllIllIIllI);
    if (lIIIIIlllIlIl(lllllllllllllllllIIIIlllIlIlIIII))
    {
      "".length();
      if (lIIIIIlllIlII(lllllllllllllllllIIIIlllIlIIllll)) {
        lllllllllllllllllIIIIlllIlIlIlII.func_176262_b(lllllllllllllllllIIIIlllIllIllll, lllllllllllllllllIIIIlllIlIlIIlI, lllllllllllllllllIIIIlllIllIlIII);
      }
    }
    if (lIIIIIllllIII(lllllllllllllllllIIIIlllIllIIlll, lllllllllllllllllIIIIlllIllIIlII))
    {
      int lllllllllllllllllIIIIlllIlIlIlll = lIlIlIlIllI[1];
      "".length();
      if (-" ".length() > 0) {
        return;
      }
      while (!lIIIIIllllIlI(lllllllllllllllllIIIIlllIlIlIlll, lllllllllllllllllIIIIlllIllIIIlI))
      {
        BlockPos lllllllllllllllllIIIIlllIlIlIllI = lllllllllllllllllIIIIlllIlIlIIlI.offset(lllllllllllllllllIIIIlllIllIlIII, lllllllllllllllllIIIIlllIlIlIlll);
        IBlockState lllllllllllllllllIIIIlllIlIlIlIl = lllllllllllllllllIIIIlllIllIIIIl[lllllllllllllllllIIIIlllIlIlIlll];
        if ((lIIIIIlllllIl(lllllllllllllllllIIIIlllIlIlIlIl)) && (lIIIIIlllIllI(lllllllllllllllllIIIIlllIllIllll.getBlockState(lllllllllllllllllIIIIlllIlIlIllI).getBlock(), Blocks.air))) {
          "".length();
        }
        lllllllllllllllllIIIIlllIlIlIlll++;
      }
    }
  }
  
  private static void lIIIIIlllIIll()
  {
    lIlIlIlIllI = new int[12];
    lIlIlIlIllI[0] = ((0x4A ^ 0x5D) & (0x8E ^ 0x99 ^ 0xFFFFFFFF));
    lIlIlIlIllI[1] = " ".length();
    lIlIlIlIllI[2] = "  ".length();
    lIlIlIlIllI[3] = "   ".length();
    lIlIlIlIllI[4] = (-" ".length());
    lIlIlIlIllI[5] = (0x4 ^ 0x2E);
    lIlIlIlIllI[6] = (0xD2 ^ 0xB5 ^ 0x30 ^ 0x53);
    lIlIlIlIllI[7] = (0xC ^ 0x9);
    lIlIlIlIllI[8] = (0x9F ^ 0x9A ^ "   ".length());
    lIlIlIlIllI[9] = (0x12 ^ 0x15);
    lIlIlIlIllI[10] = (0x5D ^ 0x12 ^ 0x6E ^ 0x2E);
    lIlIlIlIllI[11] = (113 + 6 - -10 + 11 ^ 1 + 62 - 6 + 75);
  }
  
  public boolean canPlaceBlockAt(World lllllllllllllllllIIIIllllIllllll, BlockPos lllllllllllllllllIIIIllllIlllIlI)
  {
    ;
    ;
    ;
    ;
    boolean lllllllllllllllllIIIIllllIlllIII = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if ("  ".length() == 0) {
      return (0x77 ^ 0x31 ^ 0x64 ^ 0x3F) & (0xEB ^ 0x86 ^ 0x2A ^ 0x5A ^ -" ".length());
    }
    while (!lIIIIIlllIlIl(lllllllllllllllllIIIIllllIlllIII.hasNext()))
    {
      Object lllllllllllllllllIIIIllllIllllIl = lllllllllllllllllIIIIllllIlllIII.next();
      EnumFacing lllllllllllllllllIIIIllllIllllII = (EnumFacing)lllllllllllllllllIIIIllllIllllIl;
      if (lIIIIIlllIlII(lllllllllllllllllIIIIllllIllllll.getBlockState(lllllllllllllllllIIIIllllIlllIlI.offset(lllllllllllllllllIIIIllllIllllII)).getBlock().isNormalCube())) {
        return lIlIlIlIllI[1];
      }
    }
    return lIlIlIlIllI[0];
  }
  
  private static String lIIIIIllIlIIl(String lllllllllllllllllIIIIllIlIllIlIl, String lllllllllllllllllIIIIllIlIllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIIllIlIllIlIl = new String(Base64.getDecoder().decode(lllllllllllllllllIIIIllIlIllIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIIIllIlIllIIll = new StringBuilder();
    char[] lllllllllllllllllIIIIllIlIllIIlI = lllllllllllllllllIIIIllIlIllIlII.toCharArray();
    int lllllllllllllllllIIIIllIlIllIIIl = lIlIlIlIllI[0];
    String lllllllllllllllllIIIIllIlIlIlIll = lllllllllllllllllIIIIllIlIllIlIl.toCharArray();
    String lllllllllllllllllIIIIllIlIlIlIlI = lllllllllllllllllIIIIllIlIlIlIll.length;
    int lllllllllllllllllIIIIllIlIlIlIIl = lIlIlIlIllI[0];
    while (lIIIIIllllllI(lllllllllllllllllIIIIllIlIlIlIIl, lllllllllllllllllIIIIllIlIlIlIlI))
    {
      char lllllllllllllllllIIIIllIlIllIllI = lllllllllllllllllIIIIllIlIlIlIll[lllllllllllllllllIIIIllIlIlIlIIl];
      "".length();
      "".length();
      if ("   ".length() == 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIIIIllIlIllIIll);
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllllIIIIllIllIIIIll, new IProperty[] { FACING, POWERED, ATTACHED, SUSPENDED });
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT_MIPPED;
  }
  
  public IBlockState getActualState(IBlockState lllllllllllllllllIIIIlllllIllIII, IBlockAccess lllllllllllllllllIIIIlllllIlIlll, BlockPos lllllllllllllllllIIIIlllllIllIIl)
  {
    ;
    ;
    ;
    if (lIIIIIlllIlII(World.doesBlockHaveSolidTopSurface(lllllllllllllllllIIIIlllllIllIlI, lllllllllllllllllIIIIlllllIllIIl.down())))
    {
      "".length();
      if ("  ".length() >= 0) {
        break label44;
      }
      return null;
    }
    label44:
    return SUSPENDED.withProperty(lIlIlIlIllI[0], Boolean.valueOf(lIlIlIlIllI[1]));
  }
  
  public void randomTick(World lllllllllllllllllIIIIlllIIllllIl, BlockPos lllllllllllllllllIIIIlllIIllllII, IBlockState lllllllllllllllllIIIIlllIIlllIll, Random lllllllllllllllllIIIIlllIIlllIlI) {}
  
  public void breakBlock(World lllllllllllllllllIIIIllIlllIlllI, BlockPos lllllllllllllllllIIIIllIlllIIlll, IBlockState lllllllllllllllllIIIIllIlllIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    boolean lllllllllllllllllIIIIllIlllIlIll = ((Boolean)lllllllllllllllllIIIIllIlllIIllI.getValue(ATTACHED)).booleanValue();
    boolean lllllllllllllllllIIIIllIlllIlIlI = ((Boolean)lllllllllllllllllIIIIllIlllIIllI.getValue(POWERED)).booleanValue();
    if ((!lIIIIIlllIlIl(lllllllllllllllllIIIIllIlllIlIll)) || (lIIIIIlllIlII(lllllllllllllllllIIIIllIlllIlIlI))) {
      lllllllllllllllllIIIIllIlllIllll.func_176260_a(lllllllllllllllllIIIIllIlllIlllI, lllllllllllllllllIIIIllIlllIIlll, lllllllllllllllllIIIIllIlllIIllI, lIlIlIlIllI[1], lIlIlIlIllI[0], lIlIlIlIllI[4], null);
    }
    if (lIIIIIlllIlII(lllllllllllllllllIIIIllIlllIlIlI))
    {
      lllllllllllllllllIIIIllIlllIlllI.notifyNeighborsOfStateChange(lllllllllllllllllIIIIllIlllIIlll, lllllllllllllllllIIIIllIlllIllll);
      lllllllllllllllllIIIIllIlllIlllI.notifyNeighborsOfStateChange(lllllllllllllllllIIIIllIlllIIlll.offset(((EnumFacing)lllllllllllllllllIIIIllIlllIIllI.getValue(FACING)).getOpposite()), lllllllllllllllllIIIIllIlllIllll);
    }
    lllllllllllllllllIIIIllIlllIllll.breakBlock(lllllllllllllllllIIIIllIlllIlllI, lllllllllllllllllIIIIllIlllIIlll, lllllllllllllllllIIIIllIlllIIllI);
  }
  
  static
  {
    lIIIIIlllIIll();
    lIIIIIllIlllI();
    FACING = PropertyDirection.create(lIlIlIlIIll[lIlIlIlIllI[0]], EnumFacing.Plane.HORIZONTAL);
    POWERED = PropertyBool.create(lIlIlIlIIll[lIlIlIlIllI[1]]);
    ATTACHED = PropertyBool.create(lIlIlIlIIll[lIlIlIlIllI[2]]);
  }
  
  private boolean checkForDrop(World lllllllllllllllllIIIIlllIIIIIlII, BlockPos lllllllllllllllllIIIIlllIIIIIlll, IBlockState lllllllllllllllllIIIIlllIIIIIllI)
  {
    ;
    ;
    ;
    ;
    if (lIIIIIlllIlIl(lllllllllllllllllIIIIlllIIIIIlIl.canPlaceBlockAt(lllllllllllllllllIIIIlllIIIIIlII, lllllllllllllllllIIIIlllIIIIIlll)))
    {
      lllllllllllllllllIIIIlllIIIIIlIl.dropBlockAsItem(lllllllllllllllllIIIIlllIIIIIlII, lllllllllllllllllIIIIlllIIIIIlll, lllllllllllllllllIIIIlllIIIIIllI, lIlIlIlIllI[0]);
      "".length();
      return lIlIlIlIllI[0];
    }
    return lIlIlIlIllI[1];
  }
  
  private void func_180694_a(World lllllllllllllllllIIIIlllIIlIIlIl, BlockPos lllllllllllllllllIIIIlllIIlIIlII, boolean lllllllllllllllllIIIIlllIIIlllIl, boolean lllllllllllllllllIIIIlllIIlIIIlI, boolean lllllllllllllllllIIIIlllIIIllIll, boolean lllllllllllllllllIIIIlllIIlIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIIIIIlllIlII(lllllllllllllllllIIIIlllIIlIIIlI)) && (lIIIIIlllIlIl(lllllllllllllllllIIIIlllIIlIIIII)))
    {
      lllllllllllllllllIIIIlllIIlIIlIl.playSoundEffect(lllllllllllllllllIIIIlllIIlIIlII.getX() + 0.5D, lllllllllllllllllIIIIlllIIlIIlII.getY() + 0.1D, lllllllllllllllllIIIIlllIIlIIlII.getZ() + 0.5D, lIlIlIlIIll[lIlIlIlIllI[6]], 0.4F, 0.6F);
      "".length();
      if (null == null) {}
    }
    else if ((lIIIIIlllIlIl(lllllllllllllllllIIIIlllIIlIIIlI)) && (lIIIIIlllIlII(lllllllllllllllllIIIIlllIIlIIIII)))
    {
      lllllllllllllllllIIIIlllIIlIIlIl.playSoundEffect(lllllllllllllllllIIIIlllIIlIIlII.getX() + 0.5D, lllllllllllllllllIIIIlllIIlIIlII.getY() + 0.1D, lllllllllllllllllIIIIlllIIlIIlII.getZ() + 0.5D, lIlIlIlIIll[lIlIlIlIllI[7]], 0.4F, 0.5F);
      "".length();
      if ("  ".length() == "  ".length()) {}
    }
    else if ((lIIIIIlllIlII(lllllllllllllllllIIIIlllIIIlllIl)) && (lIIIIIlllIlIl(lllllllllllllllllIIIIlllIIIllIll)))
    {
      lllllllllllllllllIIIIlllIIlIIlIl.playSoundEffect(lllllllllllllllllIIIIlllIIlIIlII.getX() + 0.5D, lllllllllllllllllIIIIlllIIlIIlII.getY() + 0.1D, lllllllllllllllllIIIIlllIIlIIlII.getZ() + 0.5D, lIlIlIlIIll[lIlIlIlIllI[8]], 0.4F, 0.7F);
      "".length();
      if (-" ".length() <= 0) {}
    }
    else if ((lIIIIIlllIlIl(lllllllllllllllllIIIIlllIIIlllIl)) && (lIIIIIlllIlII(lllllllllllllllllIIIIlllIIIllIll)))
    {
      lllllllllllllllllIIIIlllIIlIIlIl.playSoundEffect(lllllllllllllllllIIIIlllIIlIIlII.getX() + 0.5D, lllllllllllllllllIIIIlllIIlIIlII.getY() + 0.1D, lllllllllllllllllIIIIlllIIlIIlII.getZ() + 0.5D, lIlIlIlIIll[lIlIlIlIllI[9]], 0.4F, 1.2F / (rand.nextFloat() * 0.2F + 0.9F));
    }
  }
  
  public boolean canPlaceBlockOnSide(World lllllllllllllllllIIIIlllllIIlIll, BlockPos lllllllllllllllllIIIIlllllIIIlll, EnumFacing lllllllllllllllllIIIIlllllIIlIIl)
  {
    ;
    ;
    ;
    if ((lIIIIIlllIlII(lllllllllllllllllIIIIlllllIIlIIl.getAxis().isHorizontal())) && (lIIIIIlllIlII(lllllllllllllllllIIIIlllllIIlIll.getBlockState(lllllllllllllllllIIIIlllllIIlIlI.offset(lllllllllllllllllIIIIlllllIIlIIl.getOpposite())).getBlock().isNormalCube()))) {
      return lIlIlIlIllI[1];
    }
    return lIlIlIlIllI[0];
  }
  
  private void func_176262_b(World lllllllllllllllllIIIIlllIIIlIIII, BlockPos lllllllllllllllllIIIIlllIIIIllll, EnumFacing lllllllllllllllllIIIIlllIIIlIIlI)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIIlllIIIlIIII.notifyNeighborsOfStateChange(lllllllllllllllllIIIIlllIIIIllll, lllllllllllllllllIIIIlllIIIlIIIl);
    lllllllllllllllllIIIIlllIIIlIIII.notifyNeighborsOfStateChange(lllllllllllllllllIIIIlllIIIIllll.offset(lllllllllllllllllIIIIlllIIIlIIlI.getOpposite()), lllllllllllllllllIIIIlllIIIlIIIl);
  }
  
  private static void lIIIIIllIlllI()
  {
    lIlIlIlIIll = new String[lIlIlIlIllI[11]];
    lIlIlIlIIll[lIlIlIlIllI[0]] = lIIIIIllIIllI("F5RHwjxzf1I=", "Dmkus");
    lIlIlIlIIll[lIlIlIlIllI[1]] = lIIIIIllIIllI("Hz8VZSKBPW0=", "oAUEU");
    lIlIlIlIIll[lIlIlIlIllI[2]] = lIIIIIllIlIIl("CjEbOTMDIAs=", "kEoXP");
    lIlIlIlIIll[lIlIlIlIllI[3]] = lIIIIIllIlIIl("BwcSADUaFgQU", "trapP");
    lIlIlIlIIll[lIlIlIlIllI[6]] = lIIIIIllIlIll("frJuWkH/w2LycUXQJP/mmg==", "OgYfz");
    lIlIlIlIIll[lIlIlIlIllI[7]] = lIIIIIllIIllI("M8I2J+OKXCxEhtwbI1+Guw==", "vQDuN");
    lIlIlIlIIll[lIlIlIlIllI[8]] = lIIIIIllIlIll("Grjp82kRRQjimLFlHwzMaA==", "kZJLB");
    lIlIlIlIIll[lIlIlIlIllI[9]] = lIIIIIllIlIll("Uz35A6AM6u7qUOIvx/Mi8A==", "EKYZh");
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllllIIIIllIllIIllII)
  {
    ;
    ;
    if (lIIIIIlllllII(lllllllllllllllllIIIIllIllIIllII & lIlIlIlIllI[11]))
    {
      "".length();
      if ((0x60 ^ 0x71 ^ 0x34 ^ 0x20) > 0) {
        break label71;
      }
      return null;
    }
    label71:
    if (lIIIIIlllllII(lllllllllllllllllIIIIllIllIIllII & lIlIlIlIllI[6]))
    {
      "".length();
      if ("  ".length() < "   ".length()) {
        break label127;
      }
      return null;
    }
    label127:
    return ATTACHED.withProperty(lIlIlIlIllI[1], Boolean.valueOf(lIlIlIlIllI[0]));
  }
  
  public void updateTick(World lllllllllllllllllIIIIlllIIllIlII, BlockPos lllllllllllllllllIIIIlllIIllIIll, IBlockState lllllllllllllllllIIIIlllIIllIIlI, Random lllllllllllllllllIIIIlllIIllIIIl)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIIlllIIllIlIl.func_176260_a(lllllllllllllllllIIIIlllIIllIlII, lllllllllllllllllIIIIlllIIlIlllI, lllllllllllllllllIIIIlllIIllIIlI, lIlIlIlIllI[0], lIlIlIlIllI[1], lIlIlIlIllI[4], null);
  }
  
  public BlockTripWireHook()
  {
    lllllllllllllllllIIIIllllllIIIIl.<init>(Material.circuits);
    lllllllllllllllllIIIIllllllIIIII.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(POWERED, Boolean.valueOf(lIlIlIlIllI[0])).withProperty(ATTACHED, Boolean.valueOf(lIlIlIlIllI[0])).withProperty(SUSPENDED, Boolean.valueOf(lIlIlIlIllI[0])));
    "".length();
    "".length();
  }
  
  private static boolean lIIIIIllllIll(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllllIIIIllIIllllllI;
    return ??? > i;
  }
  
  public void onNeighborBlockChange(World lllllllllllllllllIIIIllllIIlIIIl, BlockPos lllllllllllllllllIIIIllllIIIlIlI, IBlockState lllllllllllllllllIIIIllllIIIlIIl, Block lllllllllllllllllIIIIllllIIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIIIIIlllIllI(lllllllllllllllllIIIIllllIIIlllI, lllllllllllllllllIIIIllllIIlIIlI)) && (lIIIIIlllIlII(lllllllllllllllllIIIIllllIIlIIlI.checkForDrop(lllllllllllllllllIIIIllllIIlIIIl, lllllllllllllllllIIIIllllIIlIIII, lllllllllllllllllIIIIllllIIIlIIl))))
    {
      EnumFacing lllllllllllllllllIIIIllllIIIllIl = (EnumFacing)lllllllllllllllllIIIIllllIIIlIIl.getValue(FACING);
      if (lIIIIIlllIlIl(lllllllllllllllllIIIIllllIIlIIIl.getBlockState(lllllllllllllllllIIIIllllIIlIIII.offset(lllllllllllllllllIIIIllllIIIllIl.getOpposite())).getBlock().isNormalCube()))
      {
        lllllllllllllllllIIIIllllIIlIIlI.dropBlockAsItem(lllllllllllllllllIIIIllllIIlIIIl, lllllllllllllllllIIIIllllIIlIIII, lllllllllllllllllIIIIllllIIIlIIl, lIlIlIlIllI[0]);
        "".length();
      }
    }
  }
  
  public boolean canProvidePower()
  {
    return lIlIlIlIllI[1];
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllllIIIIllIllIIIllI)
  {
    ;
    ;
    int lllllllllllllllllIIIIllIllIIIlll = lIlIlIlIllI[0];
    lllllllllllllllllIIIIllIllIIIlll |= ((EnumFacing)lllllllllllllllllIIIIllIllIIlIII.getValue(FACING)).getHorizontalIndex();
    if (lIIIIIlllIlII(((Boolean)lllllllllllllllllIIIIllIllIIlIII.getValue(POWERED)).booleanValue())) {
      lllllllllllllllllIIIIllIllIIIlll |= lIlIlIlIllI[11];
    }
    if (lIIIIIlllIlII(((Boolean)lllllllllllllllllIIIIllIllIIlIII.getValue(ATTACHED)).booleanValue())) {
      lllllllllllllllllIIIIllIllIIIlll |= lIlIlIlIllI[6];
    }
    return lllllllllllllllllIIIIllIllIIIlll;
  }
  
  private static String lIIIIIllIIllI(String lllllllllllllllllIIIIllIlIlIIIII, String lllllllllllllllllIIIIllIlIIlllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIIIllIlIlIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIIllIlIIlllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIIIIllIlIlIIIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllllIIIIllIlIlIIIlI.init(lIlIlIlIllI[2], lllllllllllllllllIIIIllIlIlIIIll);
      return new String(lllllllllllllllllIIIIllIlIlIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIIllIlIlIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIIIllIlIlIIIIl)
    {
      lllllllllllllllllIIIIllIlIlIIIIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIIIlllIlII(int ???)
  {
    boolean lllllllllllllllllIIIIllIIlllIIlI;
    return ??? != 0;
  }
  
  private static boolean lIIIIIllllIII(int ???, int arg1)
  {
    int i;
    int lllllllllllllllllIIIIllIIllIlIlI;
    return ??? != i;
  }
  
  private static boolean lIIIIIlllllIl(Object ???)
  {
    short lllllllllllllllllIIIIllIIlllIlII;
    return ??? != null;
  }
  
  public void onBlockPlacedBy(World lllllllllllllllllIIIIllllIIllIll, BlockPos lllllllllllllllllIIIIllllIlIIIII, IBlockState lllllllllllllllllIIIIllllIIllIIl, EntityLivingBase lllllllllllllllllIIIIllllIIllllI, ItemStack lllllllllllllllllIIIIllllIIlllIl)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIIllllIIlllII.func_176260_a(lllllllllllllllllIIIIllllIIllIll, lllllllllllllllllIIIIllllIlIIIII, lllllllllllllllllIIIIllllIIllIIl, lIlIlIlIllI[0], lIlIlIlIllI[0], lIlIlIlIllI[4], null);
  }
  
  private static boolean lIIIIIlllIlIl(int ???)
  {
    short lllllllllllllllllIIIIllIIlllIIII;
    return ??? == 0;
  }
  
  private static boolean lIIIIIllllllI(int ???, int arg1)
  {
    int i;
    char lllllllllllllllllIIIIllIlIIIIIlI;
    return ??? < i;
  }
  
  private static boolean lIIIIIlllllII(int ???)
  {
    int lllllllllllllllllIIIIllIIllIlllI;
    return ??? > 0;
  }
  
  public IBlockState onBlockPlaced(World lllllllllllllllllIIIIllllIllIIlI, BlockPos lllllllllllllllllIIIIllllIllIIIl, EnumFacing lllllllllllllllllIIIIllllIlIlIII, float lllllllllllllllllIIIIllllIlIllll, float lllllllllllllllllIIIIllllIlIlllI, float lllllllllllllllllIIIIllllIlIllIl, int lllllllllllllllllIIIIllllIlIllII, EntityLivingBase lllllllllllllllllIIIIllllIlIlIll)
  {
    ;
    ;
    ;
    IBlockState lllllllllllllllllIIIIllllIlIlIlI = lllllllllllllllllIIIIllllIllIIll.getDefaultState().withProperty(POWERED, Boolean.valueOf(lIlIlIlIllI[0])).withProperty(ATTACHED, Boolean.valueOf(lIlIlIlIllI[0])).withProperty(SUSPENDED, Boolean.valueOf(lIlIlIlIllI[0]));
    if (lIIIIIlllIlII(lllllllllllllllllIIIIllllIlIlIII.getAxis().isHorizontal())) {
      lllllllllllllllllIIIIllllIlIlIlI = lllllllllllllllllIIIIllllIlIlIlI.withProperty(FACING, lllllllllllllllllIIIIllllIlIlIII);
    }
    return lllllllllllllllllIIIIllllIlIlIlI;
  }
  
  private static String lIIIIIllIlIll(String lllllllllllllllllIIIIllIlIIlIIIl, String lllllllllllllllllIIIIllIlIIlIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIIIllIlIIlIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIIllIlIIlIIII.getBytes(StandardCharsets.UTF_8)), lIlIlIlIllI[11]), "DES");
      Cipher lllllllllllllllllIIIIllIlIIlIlIl = Cipher.getInstance("DES");
      lllllllllllllllllIIIIllIlIIlIlIl.init(lIlIlIlIllI[2], lllllllllllllllllIIIIllIlIIlIllI);
      return new String(lllllllllllllllllIIIIllIlIIlIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIIllIlIIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIIIllIlIIlIlII)
    {
      lllllllllllllllllIIIIllIlIIlIlII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIIIllllIlI(int ???, int arg1)
  {
    int i;
    long lllllllllllllllllIIIIllIlIIIIllI;
    return ??? >= i;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess lllllllllllllllllIIIIllIllllllII, BlockPos lllllllllllllllllIIIIllIlllllIll)
  {
    ;
    ;
    ;
    ;
    float lllllllllllllllllIIIIllIlllllIlI = 0.1875F;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[((EnumFacing)lllllllllllllllllIIIIllIlllllIII.getBlockState(lllllllllllllllllIIIIllIlllllIll).getValue(FACING)).ordinal()])
    {
    case 6: 
      lllllllllllllllllIIIIllIllllllIl.setBlockBounds(0.0F, 0.2F, 0.5F - lllllllllllllllllIIIIllIlllllIlI, lllllllllllllllllIIIIllIlllllIlI * 2.0F, 0.8F, 0.5F + lllllllllllllllllIIIIllIlllllIlI);
      "".length();
      if ("  ".length() != "  ".length()) {}
      break;
    case 5: 
      lllllllllllllllllIIIIllIllllllIl.setBlockBounds(1.0F - lllllllllllllllllIIIIllIlllllIlI * 2.0F, 0.2F, 0.5F - lllllllllllllllllIIIIllIlllllIlI, 1.0F, 0.8F, 0.5F + lllllllllllllllllIIIIllIlllllIlI);
      "".length();
      if (-" ".length() != -" ".length()) {}
      break;
    case 4: 
      lllllllllllllllllIIIIllIllllllIl.setBlockBounds(0.5F - lllllllllllllllllIIIIllIlllllIlI, 0.2F, 0.0F, 0.5F + lllllllllllllllllIIIIllIlllllIlI, 0.8F, lllllllllllllllllIIIIllIlllllIlI * 2.0F);
      "".length();
      if ("   ".length() != "   ".length()) {}
      break;
    case 3: 
      lllllllllllllllllIIIIllIllllllIl.setBlockBounds(0.5F - lllllllllllllllllIIIIllIlllllIlI, 0.2F, 1.0F - lllllllllllllllllIIIIllIlllllIlI * 2.0F, 0.5F + lllllllllllllllllIIIIllIlllllIlI, 0.8F, 1.0F);
    }
  }
  
  private static boolean lIIIIIllllIIl(int ???, int arg1)
  {
    int i;
    String lllllllllllllllllIIIIllIlIIIlIlI;
    return ??? == i;
  }
  
  public boolean isOpaqueCube()
  {
    return lIlIlIlIllI[0];
  }
}

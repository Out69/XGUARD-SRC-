package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.BlockPos;

public class BlockEventData
{
  public int getEventID()
  {
    ;
    return eventID;
  }
  
  private static String lllIIlIIlIIll(String lllllllllllllllIllIIlIllIlIIIlII, String lllllllllllllllIllIIlIllIlIIIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIIlIllIlIIlIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIllIlIIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIlIllIlIIlIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIlIllIlIIlIII.init(lIIlIlIIIIIl[2], lllllllllllllllIllIIlIllIlIIlIIl);
      return new String(lllllllllllllllIllIIlIllIlIIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIllIlIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIIlIllIlIIIlll)
    {
      lllllllllllllllIllIIlIllIlIIIlll.printStackTrace();
    }
    return null;
  }
  
  private static void lllIIlIIlIllI()
  {
    lIIlIlIIIIII = new String[lIIlIlIIIIIl[4]];
    lIIlIlIIIIII[lIIlIlIIIIIl[0]] = lllIIlIIlIIll("iCvr0wtZcjM=", "aaNuV");
    lIIlIlIIIIII[lIIlIlIIIIIl[1]] = lllIIlIIlIIll("L7/ar/NArm4=", "AcqfC");
    lIIlIlIIIIII[lIIlIlIIIIIl[2]] = lllIIlIIlIlII("e7DlEblvxvc=", "PpipB");
    lIIlIlIIIIII[lIIlIlIIIIIl[3]] = lllIIlIIlIlIl("Xw==", "sOQlV");
  }
  
  public BlockPos getPosition()
  {
    ;
    return position;
  }
  
  public BlockEventData(BlockPos lllllllllllllllIllIIlIlllIIIlllI, Block lllllllllllllllIllIIlIlllIIlIIlI, int lllllllllllllllIllIIlIlllIIlIIIl, int lllllllllllllllIllIIlIlllIIIlIll)
  {
    position = lllllllllllllllIllIIlIlllIIIlllI;
    eventID = lllllllllllllllIllIIlIlllIIlIIIl;
    eventParameter = lllllllllllllllIllIIlIlllIIIlIll;
    blockType = lllllllllllllllIllIIlIlllIIIllIl;
  }
  
  private static void lllIIlIIlIlll()
  {
    lIIlIlIIIIIl = new int[6];
    lIIlIlIIIIIl[0] = ((0x82 ^ 0xA5) & (0xB1 ^ 0x96 ^ 0xFFFFFFFF));
    lIIlIlIIIIIl[1] = " ".length();
    lIIlIlIIIIIl[2] = "  ".length();
    lIIlIlIIIIIl[3] = "   ".length();
    lIIlIlIIIIIl[4] = (0x20 ^ 0x24);
    lIIlIlIIIIIl[5] = (0xCC ^ 0xC4);
  }
  
  private static String lllIIlIIlIlII(String lllllllllllllllIllIIlIllIlIlIIll, String lllllllllllllllIllIIlIllIlIlIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIIlIllIlIlIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIllIlIlIIII.getBytes(StandardCharsets.UTF_8)), lIIlIlIIIIIl[5]), "DES");
      Cipher lllllllllllllllIllIIlIllIlIlIlIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIlIllIlIlIlIl.init(lIIlIlIIIIIl[2], lllllllllllllllIllIIlIllIlIlIllI);
      return new String(lllllllllllllllIllIIlIllIlIlIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIllIlIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIIlIllIlIlIlII)
    {
      lllllllllllllllIllIIlIllIlIlIlII.printStackTrace();
    }
    return null;
  }
  
  private static String lllIIlIIlIlIl(String lllllllllllllllIllIIlIllIllIlIII, String lllllllllllllllIllIIlIllIllIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllIIlIllIllIlIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlIllIllIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlIllIllIIllI = new StringBuilder();
    char[] lllllllllllllllIllIIlIllIllIIlIl = lllllllllllllllIllIIlIllIllIIlll.toCharArray();
    int lllllllllllllllIllIIlIllIllIIlII = lIIlIlIIIIIl[0];
    Exception lllllllllllllllIllIIlIllIlIllllI = lllllllllllllllIllIIlIllIllIlIII.toCharArray();
    float lllllllllllllllIllIIlIllIlIlllIl = lllllllllllllllIllIIlIllIlIllllI.length;
    float lllllllllllllllIllIIlIllIlIlllII = lIIlIlIIIIIl[0];
    while (lllIIlIIlllII(lllllllllllllllIllIIlIllIlIlllII, lllllllllllllllIllIIlIllIlIlllIl))
    {
      char lllllllllllllllIllIIlIllIllIlIIl = lllllllllllllllIllIIlIllIlIllllI[lllllllllllllllIllIIlIllIlIlllII];
      "".length();
      "".length();
      if (-(0x72 ^ 0xC ^ 0x16 ^ 0x6C) >= 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIllIIlIllIllIIllI);
  }
  
  private static boolean lllIIlIIllIlI(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIllIIlIllIIllllIl;
    return ??? == i;
  }
  
  private static boolean lllIIlIIlllII(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIllIIlIllIIlllIIl;
    return ??? < i;
  }
  
  private static boolean lllIIlIIllIll(Object ???, Object arg1)
  {
    Object localObject;
    int lllllllllllllllIllIIlIllIIllIlIl;
    return ??? == localObject;
  }
  
  private static boolean lllIIlIIllIIl(int ???)
  {
    Exception lllllllllllllllIllIIlIllIIllIIll;
    return ??? != 0;
  }
  
  public int getEventParameter()
  {
    ;
    return eventParameter;
  }
  
  public boolean equals(Object lllllllllllllllIllIIlIllIlllIlll)
  {
    ;
    ;
    ;
    if (lllIIlIIllIII(lllllllllllllllIllIIlIllIlllIlll instanceof BlockEventData)) {
      return lIIlIlIIIIIl[0];
    }
    BlockEventData lllllllllllllllIllIIlIllIllllIIl = (BlockEventData)lllllllllllllllIllIIlIllIlllIlll;
    if ((lllIIlIIllIIl(position.equals(position))) && (lllIIlIIllIlI(eventID, eventID)) && (lllIIlIIllIlI(eventParameter, eventParameter)) && (lllIIlIIllIll(blockType, blockType))) {
      return lIIlIlIIIIIl[1];
    }
    return lIIlIlIIIIIl[0];
  }
  
  private static boolean lllIIlIIllIII(int ???)
  {
    float lllllllllllllllIllIIlIllIIllIIIl;
    return ??? == 0;
  }
  
  public String toString()
  {
    ;
    return String.valueOf(new StringBuilder(lIIlIlIIIIII[lIIlIlIIIIIl[0]]).append(position).append(lIIlIlIIIIII[lIIlIlIIIIIl[1]]).append(eventID).append(lIIlIlIIIIII[lIIlIlIIIIIl[2]]).append(eventParameter).append(lIIlIlIIIIII[lIIlIlIIIIIl[3]]).append(blockType));
  }
  
  static
  {
    lllIIlIIlIlll();
    lllIIlIIlIllI();
  }
  
  public Block getBlock()
  {
    ;
    return blockType;
  }
}

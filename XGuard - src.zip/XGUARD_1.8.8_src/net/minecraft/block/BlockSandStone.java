package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;

public class BlockSandStone
  extends Block
{
  private static void lIlIIlIIIllIIl()
  {
    llIlIlIlllll = new String[llIlIllIIIll[1]];
    llIlIlIlllll[llIlIllIIIll[0]] = lIlIIlIIIllIII("LBE7Jw==", "XhKBs");
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIIIIIIIIIIIIllIII)
  {
    ;
    return ((EnumType)lllllllllllllllIIIIIIIIIIIIllIII.getValue(TYPE)).getMetadata();
  }
  
  private static boolean lIlIIlIIIlllII(int ???, int arg1)
  {
    int i;
    long llllllllllllllIllllllllllllllIII;
    return ??? >= i;
  }
  
  static
  {
    lIlIIlIIIllIll();
    lIlIIlIIIllIIl();
  }
  
  private static void lIlIIlIIIllIll()
  {
    llIlIllIIIll = new int[2];
    llIlIllIIIll[0] = ((0x69 ^ 0x40) & (0x35 ^ 0x1C ^ 0xFFFFFFFF));
    llIlIllIIIll[1] = " ".length();
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIIIIIIIIIIIIllIll)
  {
    ;
    ;
    return lllllllllllllllIIIIIIIIIIIIlllII.getDefaultState().withProperty(TYPE, EnumType.byMetadata(lllllllllllllllIIIIIIIIIIIIllIll));
  }
  
  public BlockSandStone()
  {
    lllllllllllllllIIIIIIIIIIIlllIII.<init>(Material.rock);
    lllllllllllllllIIIIIIIIIIIlllIIl.setDefaultState(blockState.getBaseState().withProperty(TYPE, EnumType.DEFAULT));
    "".length();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIIIIIIIIIIIIlIlII, new IProperty[] { TYPE });
  }
  
  public void getSubBlocks(Item lllllllllllllllIIIIIIIIIIIlIllII, CreativeTabs lllllllllllllllIIIIIIIIIIIlIlIll, List<ItemStack> lllllllllllllllIIIIIIIIIIIlIIlll)
  {
    ;
    ;
    ;
    ;
    double lllllllllllllllIIIIIIIIIIIlIIlII = (lllllllllllllllIIIIIIIIIIIlIIIll = EnumType.values()).length;
    boolean lllllllllllllllIIIIIIIIIIIlIIlIl = llIlIllIIIll[0];
    "".length();
    if (-"   ".length() > 0) {
      return;
    }
    while (!lIlIIlIIIlllII(lllllllllllllllIIIIIIIIIIIlIIlIl, lllllllllllllllIIIIIIIIIIIlIIlII))
    {
      EnumType lllllllllllllllIIIIIIIIIIIlIlIIl = lllllllllllllllIIIIIIIIIIIlIIIll[lllllllllllllllIIIIIIIIIIIlIIlIl];
      new ItemStack(lllllllllllllllIIIIIIIIIIIlIllII, llIlIllIIIll[1], lllllllllllllllIIIIIIIIIIIlIlIIl.getMetadata());
      "".length();
    }
  }
  
  public int damageDropped(IBlockState lllllllllllllllIIIIIIIIIIIllIlII)
  {
    ;
    return ((EnumType)lllllllllllllllIIIIIIIIIIIllIlII.getValue(TYPE)).getMetadata();
  }
  
  private static String lIlIIlIIIllIII(String lllllllllllllllIIIIIIIIIIIIIIlII, String lllllllllllllllIIIIIIIIIIIIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIIIIIIIIIIIIlII = new String(Base64.getDecoder().decode(lllllllllllllllIIIIIIIIIIIIIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIIIIIIIIIIIIIlll = new StringBuilder();
    char[] lllllllllllllllIIIIIIIIIIIIIIllI = lllllllllllllllIIIIIIIIIIIIIIIll.toCharArray();
    int lllllllllllllllIIIIIIIIIIIIIIlIl = llIlIllIIIll[0];
    char llllllllllllllIlllllllllllllllll = lllllllllllllllIIIIIIIIIIIIIIlII.toCharArray();
    Exception llllllllllllllIllllllllllllllllI = llllllllllllllIlllllllllllllllll.length;
    String llllllllllllllIlllllllllllllllIl = llIlIllIIIll[0];
    while (lIlIIlIIIlllIl(llllllllllllllIlllllllllllllllIl, llllllllllllllIllllllllllllllllI))
    {
      char lllllllllllllllIIIIIIIIIIIIIlIlI = llllllllllllllIlllllllllllllllll[llllllllllllllIlllllllllllllllIl];
      "".length();
      "".length();
      if ((('¥' + 2 - 125 + 135 ^ '¢' + 121 - 158 + 55) & (0x51 ^ 0x3B ^ 0x1F ^ 0x70 ^ -" ".length())) > 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIIIIIIIIIIIIIlll);
  }
  
  private static boolean lIlIIlIIIlllIl(int ???, int arg1)
  {
    int i;
    char llllllllllllllIlllllllllllllIlII;
    return ??? < i;
  }
  
  public MapColor getMapColor(IBlockState lllllllllllllllIIIIIIIIIIIlIIIIl)
  {
    return MapColor.sandColor;
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    private static boolean lIllIIlIIllllI(int ???, int arg1)
    {
      int i;
      int llllllllllllllIlllIIIlIIlllIllII;
      return ??? < i;
    }
    
    public static EnumType byMetadata(int llllllllllllllIlllIIIlIlIIllIlII)
    {
      ;
      if ((!lIllIIlIIlllII(llllllllllllllIlllIIIlIlIIllIlII)) || (lIllIIlIIllIll(llllllllllllllIlllIIIlIlIIllIlIl, META_LOOKUP.length))) {
        llllllllllllllIlllIIIlIlIIllIlIl = lllIlIIlIlIl[0];
      }
      return META_LOOKUP[llllllllllllllIlllIIIlIlIIllIlIl];
    }
    
    private static boolean lIllIIlIIlllII(int ???)
    {
      int llllllllllllllIlllIIIlIIlllIlIlI;
      return ??? >= 0;
    }
    
    static
    {
      lIllIIlIIllIlI();
      lIllIIlIIllIII();
      double llllllllllllllIlllIIIlIlIlIIllIl;
      Exception llllllllllllllIlllIIIlIlIlIlIIII;
      DEFAULT = new EnumType(lllIlIIIllll[lllIlIIlIlIl[0]], lllIlIIlIlIl[0], lllIlIIlIlIl[0], lllIlIIIllll[lllIlIIlIlIl[1]], lllIlIIIllll[lllIlIIlIlIl[2]]);
      CHISELED = new EnumType(lllIlIIIllll[lllIlIIlIlIl[3]], lllIlIIlIlIl[1], lllIlIIlIlIl[1], lllIlIIIllll[lllIlIIlIlIl[4]], lllIlIIIllll[lllIlIIlIlIl[5]]);
      SMOOTH = new EnumType(lllIlIIIllll[lllIlIIlIlIl[6]], lllIlIIlIlIl[2], lllIlIIlIlIl[2], lllIlIIIllll[lllIlIIlIlIl[7]], lllIlIIIllll[lllIlIIlIlIl[8]]);
      ENUM$VALUES = new EnumType[] { DEFAULT, CHISELED, SMOOTH };
      META_LOOKUP = new EnumType[values().length];
      byte llllllllllllllIlllIIIlIlIlIIlllI = (llllllllllllllIlllIIIlIlIlIIllIl = values()).length;
      String llllllllllllllIlllIIIlIlIlIIllll = lllIlIIlIlIl[0];
      "".length();
      if (-"  ".length() >= 0) {
        return;
      }
      while (!lIllIIlIIllIll(llllllllllllllIlllIIIlIlIlIIllll, llllllllllllllIlllIIIlIlIlIIlllI))
      {
        EnumType llllllllllllllIlllIIIlIlIlIlIIIl = llllllllllllllIlllIIIlIlIlIIllIl[llllllllllllllIlllIIIlIlIlIIllll];
        META_LOOKUP[llllllllllllllIlllIIIlIlIlIlIIIl.getMetadata()] = llllllllllllllIlllIIIlIlIlIlIIIl;
        llllllllllllllIlllIIIlIlIlIIllll++;
      }
    }
    
    private static boolean lIllIIlIIllIll(int ???, int arg1)
    {
      int i;
      byte llllllllllllllIlllIIIlIIllllIIII;
      return ??? >= i;
    }
    
    private EnumType(int llllllllllllllIlllIIIlIlIIllllll, String llllllllllllllIlllIIIlIlIIlllllI, String llllllllllllllIlllIIIlIlIIllllIl)
    {
      metadata = llllllllllllllIlllIIIlIlIIllllll;
      name = llllllllllllllIlllIIIlIlIIlllllI;
      unlocalizedName = llllllllllllllIlllIIIlIlIIllllIl;
    }
    
    private static void lIllIIlIIllIlI()
    {
      lllIlIIlIlIl = new int[10];
      lllIlIIlIlIl[0] = ((0x6 ^ 0x2E) & (0x3D ^ 0x15 ^ 0xFFFFFFFF));
      lllIlIIlIlIl[1] = " ".length();
      lllIlIIlIlIl[2] = "  ".length();
      lllIlIIlIlIl[3] = "   ".length();
      lllIlIIlIlIl[4] = (0xB2 ^ 0xB6);
      lllIlIIlIlIl[5] = (0x5B ^ 0x74 ^ 0x38 ^ 0x12);
      lllIlIIlIlIl[6] = (0x98 ^ 0x9E);
      lllIlIIlIlIl[7] = (0x85 ^ 0x82);
      lllIlIIlIlIl[8] = (0x59 ^ 0x16 ^ 0x24 ^ 0x63);
      lllIlIIlIlIl[9] = (0x4C ^ 0x3E ^ 0xF0 ^ 0x8B);
    }
    
    public String getUnlocalizedName()
    {
      ;
      return unlocalizedName;
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private static void lIllIIlIIllIII()
    {
      lllIlIIIllll = new String[lllIlIIlIlIl[9]];
      lllIlIIIllll[lllIlIIlIlIl[0]] = lIllIIlIIlIlII("DQMRLzkFEg==", "IFWnl");
      lllIlIIIllll[lllIlIIlIlIl[1]] = lIllIIlIIlIlIl("h4NKN22sPW1xW+2uIHftqw==", "VtezR");
      lllIlIIIllll[lllIlIIlIlIl[2]] = lIllIIlIIlIlII("EBchEwQYBg==", "trGrq");
      lllIlIIIllll[lllIlIIlIlIl[3]] = lIllIIlIIlIlll("lykfsGdF8aYhaMDGOIFJ4w==", "judXS");
      lllIlIIIllll[lllIlIIlIlIl[4]] = lIllIIlIIlIlll("gAAHletbAi5suyDeMVKG70G+KJMOerl4", "wfcRj");
      lllIlIIIllll[lllIlIIlIlIl[5]] = lIllIIlIIlIlII("MxoPCQw8FwI=", "Prfzi");
      lllIlIIIllll[lllIlIIlIlIl[6]] = lIllIIlIIlIlIl("gypFpuTsHsY=", "oYmEJ");
      lllIlIIIllll[lllIlIIlIlIl[7]] = lIllIIlIIlIlII("HwckFhMENTgYCQgZPxYJCQ==", "ljKyg");
      lllIlIIIllll[lllIlIIlIlIl[8]] = lIllIIlIIlIlll("enjUmMA5z34=", "XQkTC");
    }
    
    private static String lIllIIlIIlIlIl(String llllllllllllllIlllIIIlIIllllIlll, String llllllllllllllIlllIIIlIIllllIllI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlllIIIlIIllllllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllIIIlIIllllIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIlllIIIlIIlllllIll = Cipher.getInstance("Blowfish");
        llllllllllllllIlllIIIlIIlllllIll.init(lllIlIIlIlIl[2], llllllllllllllIlllIIIlIIllllllII);
        return new String(llllllllllllllIlllIIIlIIlllllIll.doFinal(Base64.getDecoder().decode(llllllllllllllIlllIIIlIIllllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlllIIIlIIlllllIlI)
      {
        llllllllllllllIlllIIIlIIlllllIlI.printStackTrace();
      }
      return null;
    }
    
    private static String lIllIIlIIlIlII(String llllllllllllllIlllIIIlIlIIIIlllI, String llllllllllllllIlllIIIlIlIIIIllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIlllIIIlIlIIIIlllI = new String(Base64.getDecoder().decode(llllllllllllllIlllIIIlIlIIIIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIlllIIIlIlIIIIllII = new StringBuilder();
      char[] llllllllllllllIlllIIIlIlIIIIlIll = llllllllllllllIlllIIIlIlIIIIllIl.toCharArray();
      int llllllllllllllIlllIIIlIlIIIIlIlI = lllIlIIlIlIl[0];
      byte llllllllllllllIlllIIIlIlIIIIIlII = llllllllllllllIlllIIIlIlIIIIlllI.toCharArray();
      float llllllllllllllIlllIIIlIlIIIIIIll = llllllllllllllIlllIIIlIlIIIIIlII.length;
      float llllllllllllllIlllIIIlIlIIIIIIlI = lllIlIIlIlIl[0];
      while (lIllIIlIIllllI(llllllllllllllIlllIIIlIlIIIIIIlI, llllllllllllllIlllIIIlIlIIIIIIll))
      {
        char llllllllllllllIlllIIIlIlIIIIllll = llllllllllllllIlllIIIlIlIIIIIlII[llllllllllllllIlllIIIlIlIIIIIIlI];
        "".length();
        "".length();
        if (null != null) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIlllIIIlIlIIIIllII);
    }
    
    public int getMetadata()
    {
      ;
      return metadata;
    }
    
    private static String lIllIIlIIlIlll(String llllllllllllllIlllIIIlIlIIIllllI, String llllllllllllllIlllIIIlIlIIIlllIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlllIIIlIlIIlIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllIIIlIlIIIlllIl.getBytes(StandardCharsets.UTF_8)), lllIlIIlIlIl[8]), "DES");
        Cipher llllllllllllllIlllIIIlIlIIlIIIII = Cipher.getInstance("DES");
        llllllllllllllIlllIIIlIlIIlIIIII.init(lllIlIIlIlIl[2], llllllllllllllIlllIIIlIlIIlIIIIl);
        return new String(llllllllllllllIlllIIIlIlIIlIIIII.doFinal(Base64.getDecoder().decode(llllllllllllllIlllIIIlIlIIIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlllIIIlIlIIIlllll)
      {
        llllllllllllllIlllIIIlIlIIIlllll.printStackTrace();
      }
      return null;
    }
    
    public String getName()
    {
      ;
      return name;
    }
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.StatCollector;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockWall
  extends Block
{
  static
  {
    lIIIIllllllllI();
    lIIIIlllllllIl();
    UP = PropertyBool.create(lIlIlllllIlI[lIlIlllllIll[0]]);
    NORTH = PropertyBool.create(lIlIlllllIlI[lIlIlllllIll[1]]);
    EAST = PropertyBool.create(lIlIlllllIlI[lIlIlllllIll[2]]);
    SOUTH = PropertyBool.create(lIlIlllllIlI[lIlIlllllIll[3]]);
    WEST = PropertyBool.create(lIlIlllllIlI[lIlIlllllIll[4]]);
  }
  
  public int damageDropped(IBlockState lllllllllllllllIIlllIlIlIIllIlII)
  {
    ;
    return ((EnumType)lllllllllllllllIIlllIlIlIIllIlII.getValue(VARIANT)).getMetadata();
  }
  
  public boolean canConnectTo(IBlockAccess lllllllllllllllIIlllIlIlIlIIlllI, BlockPos lllllllllllllllIIlllIlIlIlIIlIIl)
  {
    ;
    ;
    ;
    ;
    Block lllllllllllllllIIlllIlIlIlIIllII = lllllllllllllllIIlllIlIlIlIIlllI.getBlockState(lllllllllllllllIIlllIlIlIlIIlIIl).getBlock();
    if (lIIIlIIIIIIIlI(lllllllllllllllIIlllIlIlIlIIllII, Blocks.barrier))
    {
      "".length();
      if ("   ".length() == 0) {
        return (0x88 ^ 0xBC) & (0x40 ^ 0x74 ^ 0xFFFFFFFF);
      }
    }
    else if ((lIIIlIIIIIIIll(lllllllllllllllIIlllIlIlIlIIllII, lllllllllllllllIIlllIlIlIlIIllll)) && (lIIIlIIIIIIIII(lllllllllllllllIIlllIlIlIlIIllII instanceof BlockFenceGate)))
    {
      if ((lIIIIlllllllll(blockMaterial.isOpaque())) && (lIIIIlllllllll(lllllllllllllllIIlllIlIlIlIIllII.isFullCube())))
      {
        if (lIIIlIIIIIIIll(blockMaterial, Material.gourd))
        {
          "".length();
          if ((0x6C ^ 0x68) == (0xA6 ^ 0xA2)) {
            break label265;
          }
          return (0x8 ^ 0x37) & (0xB4 ^ 0x8B ^ 0xFFFFFFFF);
        }
        "".length();
        if (null == null) {
          break label265;
        }
        return (0x91 ^ 0xAB ^ 0xB2 ^ 0x94) & (0xA6 ^ 0xB3 ^ 0x9 ^ 0x0 ^ -" ".length());
      }
      "".length();
      if ("   ".length() >= 0) {
        break label265;
      }
      return (0xA5 ^ 0x86 ^ 0x73 ^ 0x2) & (0xD4 ^ 0xC6 ^ 0xF3 ^ 0xB3 ^ -" ".length());
    }
    label265:
    return lIlIlllllIll[1];
  }
  
  private static boolean lIIIlIIIIIIIll(Object ???, Object arg1)
  {
    Object localObject;
    double lllllllllllllllIIlllIIllIIlIIlIl;
    return ??? != localObject;
  }
  
  private static String lIIIIllllllIlI(String lllllllllllllllIIlllIIllIlIIIIIl, String lllllllllllllllIIlllIIllIlIIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlllIIllIlIIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlllIIllIlIIIIII.getBytes(StandardCharsets.UTF_8)), lIlIlllllIll[8]), "DES");
      Cipher lllllllllllllllIIlllIIllIlIIIlIl = Cipher.getInstance("DES");
      lllllllllllllllIIlllIIllIlIIIlIl.init(lIlIlllllIll[2], lllllllllllllllIIlllIIllIlIIIllI);
      return new String(lllllllllllllllIIlllIIllIlIIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlllIIllIlIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlllIIllIlIIIlII)
    {
      lllllllllllllllIIlllIIllIlIIIlII.printStackTrace();
    }
    return null;
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIIlllIlIlIIIllllI)
  {
    ;
    return ((EnumType)lllllllllllllllIIlllIlIlIIIllllI.getValue(VARIANT)).getMetadata();
  }
  
  public IBlockState getActualState(IBlockState lllllllllllllllIIlllIlIlIIIlIIll, IBlockAccess lllllllllllllllIIlllIlIlIIIlIIlI, BlockPos lllllllllllllllIIlllIlIlIIIlIIIl)
  {
    ;
    ;
    ;
    ;
    if (lIIIIlllllllll(lllllllllllllllIIlllIlIlIIIlIIlI.isAirBlock(lllllllllllllllIIlllIlIlIIIlIIIl.up())))
    {
      "".length();
      if ("  ".length() >= 0) {
        break label46;
      }
      return null;
    }
    label46:
    return UP.withProperty(lIlIlllllIll[0], Boolean.valueOf(lIlIlllllIll[1])).withProperty(NORTH, Boolean.valueOf(lllllllllllllllIIlllIlIlIIIlIlII.canConnectTo(lllllllllllllllIIlllIlIlIIIlIIlI, lllllllllllllllIIlllIlIlIIIlIIIl.north()))).withProperty(EAST, Boolean.valueOf(lllllllllllllllIIlllIlIlIIIlIlII.canConnectTo(lllllllllllllllIIlllIlIlIIIlIIlI, lllllllllllllllIIlllIlIlIIIlIIIl.east()))).withProperty(SOUTH, Boolean.valueOf(lllllllllllllllIIlllIlIlIIIlIlII.canConnectTo(lllllllllllllllIIlllIlIlIIIlIIlI, lllllllllllllllIIlllIlIlIIIlIIIl.south()))).withProperty(WEST, Boolean.valueOf(lllllllllllllllIIlllIlIlIIIlIlII.canConnectTo(lllllllllllllllIIlllIlIlIIIlIIlI, lllllllllllllllIIlllIlIlIIIlIIIl.west())));
  }
  
  private static void lIIIIllllllllI()
  {
    lIlIlllllIll = new int[9];
    lIlIlllllIll[0] = ((0x98 ^ 0xBB) & (0x1F ^ 0x3C ^ 0xFFFFFFFF));
    lIlIlllllIll[1] = " ".length();
    lIlIlllllIll[2] = "  ".length();
    lIlIlllllIll[3] = "   ".length();
    lIlIlllllIll[4] = (0x54 ^ 0x39 ^ 0xF6 ^ 0x9F);
    lIlIlllllIll[5] = (0x61 ^ 0x64);
    lIlIlllllIll[6] = (56 + 66 - 65 + 97 ^ 70 + 72 - -6 + 8);
    lIlIlllllIll[7] = (0x6B ^ 0x6C);
    lIlIlllllIll[8] = ('' + '' - 226 + 135 ^ 18 + 56 - -98 + 8);
  }
  
  private static boolean lIIIlIIIIIIlII(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIIlllIIllIIlIllIl;
    return ??? >= i;
  }
  
  private static void lIIIIlllllllIl()
  {
    lIlIlllllIlI = new String[lIlIlllllIll[8]];
    lIlIlllllIlI[lIlIlllllIll[0]] = lIIIIllllllIlI("8Hr4sd8DBqA=", "oBAUe");
    lIlIlllllIlI[lIlIlllllIll[1]] = lIIIIllllllIll("2XULtqVhQlI=", "OxoEK");
    lIlIlllllIlI[lIlIlllllIll[2]] = lIIIIllllllIlI("at9WwiemWfs=", "bSjPG");
    lIlIlllllIlI[lIlIlllllIll[3]] = lIIIIllllllIlI("v8605fKzmzU=", "RopAD");
    lIlIlllllIlI[lIlIlllllIll[4]] = lIIIIlllllllII("PAE7OA==", "KdHLp");
    lIlIlllllIlI[lIlIlllllIll[5]] = lIIIIllllllIlI("NoIjZJ8e+9E=", "otxIB");
    lIlIlllllIlI[lIlIlllllIll[6]] = lIIIIllllllIlI("MMoxfKrQMps=", "rzEZO");
    lIlIlllllIlI[lIlIlllllIll[7]] = lIIIIllllllIlI("mlWlsAbxlZ4=", "mhJpS");
  }
  
  private static boolean lIIIlIIIIIIllI(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIIlllIIllIIlIlIIl;
    return ??? < i;
  }
  
  public boolean isFullCube()
  {
    return lIlIlllllIll[0];
  }
  
  public void getSubBlocks(Item lllllllllllllllIIlllIlIlIIllllII, CreativeTabs lllllllllllllllIIlllIlIlIIllllll, List<ItemStack> lllllllllllllllIIlllIlIlIIlllllI)
  {
    ;
    ;
    ;
    ;
    boolean lllllllllllllllIIlllIlIlIIlllIII = (lllllllllllllllIIlllIlIlIIllIlll = EnumType.values()).length;
    long lllllllllllllllIIlllIlIlIIlllIIl = lIlIlllllIll[0];
    "".length();
    if ((0x0 ^ 0x4) <= 0) {
      return;
    }
    while (!lIIIlIIIIIIlII(lllllllllllllllIIlllIlIlIIlllIIl, lllllllllllllllIIlllIlIlIIlllIII))
    {
      EnumType lllllllllllllllIIlllIlIlIIllllIl = lllllllllllllllIIlllIlIlIIllIlll[lllllllllllllllIIlllIlIlIIlllIIl];
      new ItemStack(lllllllllllllllIIlllIlIlIIllllII, lIlIlllllIll[1], lllllllllllllllIIlllIlIlIIllllIl.getMetadata());
      "".length();
    }
  }
  
  private static String lIIIIlllllllII(String lllllllllllllllIIlllIIllIlIlIIll, String lllllllllllllllIIlllIIllIlIlIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlllIIllIlIlIIll = new String(Base64.getDecoder().decode(lllllllllllllllIIlllIIllIlIlIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlllIIllIlIlIllI = new StringBuilder();
    char[] lllllllllllllllIIlllIIllIlIlIlIl = lllllllllllllllIIlllIIllIlIlIIlI.toCharArray();
    int lllllllllllllllIIlllIIllIlIlIlII = lIlIlllllIll[0];
    float lllllllllllllllIIlllIIllIlIIlllI = lllllllllllllllIIlllIIllIlIlIIll.toCharArray();
    String lllllllllllllllIIlllIIllIlIIllIl = lllllllllllllllIIlllIIllIlIIlllI.length;
    String lllllllllllllllIIlllIIllIlIIllII = lIlIlllllIll[0];
    while (lIIIlIIIIIIllI(lllllllllllllllIIlllIIllIlIIllII, lllllllllllllllIIlllIIllIlIIllIl))
    {
      char lllllllllllllllIIlllIIllIlIllIIl = lllllllllllllllIIlllIIllIlIIlllI[lllllllllllllllIIlllIIllIlIIllII];
      "".length();
      "".length();
      if (-" ".length() >= "   ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlllIIllIlIlIllI);
  }
  
  private static String lIIIIllllllIll(String lllllllllllllllIIlllIIllIIllIlII, String lllllllllllllllIIlllIIllIIllIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlllIIllIIlllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlllIIllIIllIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIlllIIllIIlllIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIIlllIIllIIlllIII.init(lIlIlllllIll[2], lllllllllllllllIIlllIIllIIlllIIl);
      return new String(lllllllllllllllIIlllIIllIIlllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlllIIllIIllIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlllIIllIIllIlll)
    {
      lllllllllllllllIIlllIIllIIllIlll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIlIIIIIIIlI(Object ???, Object arg1)
  {
    Object localObject;
    long lllllllllllllllIIlllIIllIIlIIIIl;
    return ??? == localObject;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World lllllllllllllllIIlllIlIlIlIlIllI, BlockPos lllllllllllllllIIlllIlIlIlIllIIl, IBlockState lllllllllllllllIIlllIlIlIlIllIII)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIIlllIlIlIlIllIll.setBlockBoundsBasedOnState(lllllllllllllllIIlllIlIlIlIlIllI, lllllllllllllllIIlllIlIlIlIllIIl);
    maxY = 1.5D;
    return lllllllllllllllIIlllIlIlIlIllIll.getCollisionBoundingBox(lllllllllllllllIIlllIlIlIlIlIllI, lllllllllllllllIIlllIlIlIlIllIIl, lllllllllllllllIIlllIlIlIlIllIII);
  }
  
  public BlockWall(Block lllllllllllllllIIlllIlIllIIIlllI)
  {
    lllllllllllllllIIlllIlIllIIIllll.<init>(blockMaterial);
    lllllllllllllllIIlllIlIllIIIllll.setDefaultState(blockState.getBaseState().withProperty(UP, Boolean.valueOf(lIlIlllllIll[0])).withProperty(NORTH, Boolean.valueOf(lIlIlllllIll[0])).withProperty(EAST, Boolean.valueOf(lIlIlllllIll[0])).withProperty(SOUTH, Boolean.valueOf(lIlIlllllIll[0])).withProperty(WEST, Boolean.valueOf(lIlIlllllIll[0])).withProperty(VARIANT, EnumType.NORMAL));
    "".length();
    "".length();
    "".length();
    "".length();
  }
  
  public boolean shouldSideBeRendered(IBlockAccess lllllllllllllllIIlllIlIlIIlIlIIl, BlockPos lllllllllllllllIIlllIlIlIIlIllII, EnumFacing lllllllllllllllIIlllIlIlIIlIIlll)
  {
    ;
    ;
    ;
    ;
    if (lIIIlIIIIIIIlI(lllllllllllllllIIlllIlIlIIlIIlll, EnumFacing.DOWN))
    {
      "".length();
      if ("   ".length() > -" ".length()) {
        break label77;
      }
      return (0xDC ^ 0xA7 ^ 0xE1 ^ 0xC7) & (0xA ^ 0x51 ^ 0x18 ^ 0x1E ^ -" ".length());
    }
    label77:
    return lIlIlllllIll[1];
  }
  
  private static boolean lIIIIlllllllll(int ???)
  {
    double lllllllllllllllIIlllIIllIIIlllll;
    return ??? != 0;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess lllllllllllllllIIlllIlIlIlllIllI, BlockPos lllllllllllllllIIlllIlIlIllIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    boolean lllllllllllllllIIlllIlIlIlllIlII = lllllllllllllllIIlllIlIlIlllIlll.canConnectTo(lllllllllllllllIIlllIlIlIllIlIlI, lllllllllllllllIIlllIlIlIllIlIIl.north());
    boolean lllllllllllllllIIlllIlIlIlllIIll = lllllllllllllllIIlllIlIlIlllIlll.canConnectTo(lllllllllllllllIIlllIlIlIllIlIlI, lllllllllllllllIIlllIlIlIllIlIIl.south());
    boolean lllllllllllllllIIlllIlIlIlllIIlI = lllllllllllllllIIlllIlIlIlllIlll.canConnectTo(lllllllllllllllIIlllIlIlIllIlIlI, lllllllllllllllIIlllIlIlIllIlIIl.west());
    boolean lllllllllllllllIIlllIlIlIlllIIIl = lllllllllllllllIIlllIlIlIlllIlll.canConnectTo(lllllllllllllllIIlllIlIlIllIlIlI, lllllllllllllllIIlllIlIlIllIlIIl.east());
    float lllllllllllllllIIlllIlIlIlllIIII = 0.25F;
    float lllllllllllllllIIlllIlIlIllIllll = 0.75F;
    float lllllllllllllllIIlllIlIlIllIlllI = 0.25F;
    float lllllllllllllllIIlllIlIlIllIllIl = 0.75F;
    float lllllllllllllllIIlllIlIlIllIllII = 1.0F;
    if (lIIIIlllllllll(lllllllllllllllIIlllIlIlIlllIlII)) {
      lllllllllllllllIIlllIlIlIllIlllI = 0.0F;
    }
    if (lIIIIlllllllll(lllllllllllllllIIlllIlIlIlllIIll)) {
      lllllllllllllllIIlllIlIlIllIllIl = 1.0F;
    }
    if (lIIIIlllllllll(lllllllllllllllIIlllIlIlIlllIIlI)) {
      lllllllllllllllIIlllIlIlIlllIIII = 0.0F;
    }
    if (lIIIIlllllllll(lllllllllllllllIIlllIlIlIlllIIIl)) {
      lllllllllllllllIIlllIlIlIllIllll = 1.0F;
    }
    if ((lIIIIlllllllll(lllllllllllllllIIlllIlIlIlllIlII)) && (lIIIIlllllllll(lllllllllllllllIIlllIlIlIlllIIll)) && (lIIIlIIIIIIIII(lllllllllllllllIIlllIlIlIlllIIlI)) && (lIIIlIIIIIIIII(lllllllllllllllIIlllIlIlIlllIIIl)))
    {
      lllllllllllllllIIlllIlIlIllIllII = 0.8125F;
      lllllllllllllllIIlllIlIlIlllIIII = 0.3125F;
      lllllllllllllllIIlllIlIlIllIllll = 0.6875F;
      "".length();
      if ((0x54 ^ 0x41 ^ 0xD0 ^ 0xC1) > -" ".length()) {}
    }
    else if ((lIIIlIIIIIIIII(lllllllllllllllIIlllIlIlIlllIlII)) && (lIIIlIIIIIIIII(lllllllllllllllIIlllIlIlIlllIIll)) && (lIIIIlllllllll(lllllllllllllllIIlllIlIlIlllIIlI)) && (lIIIIlllllllll(lllllllllllllllIIlllIlIlIlllIIIl)))
    {
      lllllllllllllllIIlllIlIlIllIllII = 0.8125F;
      lllllllllllllllIIlllIlIlIllIlllI = 0.3125F;
      lllllllllllllllIIlllIlIlIllIllIl = 0.6875F;
    }
    lllllllllllllllIIlllIlIlIlllIlll.setBlockBounds(lllllllllllllllIIlllIlIlIlllIIII, 0.0F, lllllllllllllllIIlllIlIlIllIlllI, lllllllllllllllIIlllIlIlIllIllll, lllllllllllllllIIlllIlIlIllIllII, lllllllllllllllIIlllIlIlIllIllIl);
  }
  
  private static boolean lIIIlIIIIIIIII(int ???)
  {
    char lllllllllllllllIIlllIIllIIIlllIl;
    return ??? == 0;
  }
  
  public String getLocalizedName()
  {
    ;
    return StatCollector.translateToLocal(String.valueOf(new StringBuilder(String.valueOf(lllllllllllllllIIlllIlIllIIIlIlI.getUnlocalizedName())).append(lIlIlllllIlI[lIlIlllllIll[6]]).append(EnumType.NORMAL.getUnlocalizedName()).append(lIlIlllllIlI[lIlIlllllIll[7]])));
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIIlllIlIlIIlIIIIl)
  {
    ;
    ;
    return lllllllllllllllIIlllIlIlIIlIIlII.getDefaultState().withProperty(VARIANT, EnumType.byMetadata(lllllllllllllllIIlllIlIlIIlIIIIl));
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIIlllIlIlIIIIllll, new IProperty[] { UP, NORTH, EAST, WEST, SOUTH, VARIANT });
  }
  
  public boolean isOpaqueCube()
  {
    return lIlIlllllIll[0];
  }
  
  public boolean isPassable(IBlockAccess lllllllllllllllIIlllIlIllIIIIllI, BlockPos lllllllllllllllIIlllIlIllIIIIlIl)
  {
    return lIlIlllllIll[0];
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    private static void lIlIIIIIlIl()
    {
      llIIIIlIl = new int[7];
      llIIIIlIl[0] = ((0xB4 ^ 0xAC) & (0x6A ^ 0x72 ^ 0xFFFFFFFF));
      llIIIIlIl[1] = " ".length();
      llIIIIlIl[2] = "  ".length();
      llIIIIlIl[3] = "   ".length();
      llIIIIlIl[4] = (0xA1 ^ 0x9C ^ 0x49 ^ 0x70);
      llIIIIlIl[5] = (0x8D ^ 0x88);
      llIIIIlIl[6] = (0x89 ^ 0x8F);
    }
    
    private static String lIIlllllllI(String llIIIlllIlIIll, String llIIIlllIIllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llIIIlllIlIIll = new String(Base64.getDecoder().decode(llIIIlllIlIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llIIIlllIlIIIl = new StringBuilder();
      char[] llIIIlllIlIIII = llIIIlllIIllIl.toCharArray();
      int llIIIlllIIllll = llIIIIlIl[0];
      char llIIIlllIIlIIl = llIIIlllIlIIll.toCharArray();
      String llIIIlllIIlIII = llIIIlllIIlIIl.length;
      double llIIIlllIIIlll = llIIIIlIl[0];
      while (lIlIIIllIII(llIIIlllIIIlll, llIIIlllIIlIII))
      {
        char llIIIlllIlIlII = llIIIlllIIlIIl[llIIIlllIIIlll];
        "".length();
        "".length();
        if ("  ".length() < 0) {
          return null;
        }
      }
      return String.valueOf(llIIIlllIlIIIl);
    }
    
    public String getUnlocalizedName()
    {
      ;
      return unlocalizedName;
    }
    
    private static String lIIllllllll(String llIIIllllIIIll, String llIIIllllIIIII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llIIIllllIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llIIIllllIIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llIIIllllIIlIl = Cipher.getInstance("Blowfish");
        llIIIllllIIlIl.init(llIIIIlIl[2], llIIIllllIIllI);
        return new String(llIIIllllIIlIl.doFinal(Base64.getDecoder().decode(llIIIllllIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llIIIllllIIlII)
      {
        llIIIllllIIlII.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIlIIIlIlll(int ???)
    {
      long llIIIllIllllII;
      return ??? >= 0;
    }
    
    public static EnumType byMetadata(int llIIIllllllIIl)
    {
      ;
      if ((!lIlIIIlIlll(llIIIllllllIIl)) || (lIlIIIlIllI(llIIIllllllIlI, META_LOOKUP.length))) {
        llIIIllllllIlI = llIIIIlIl[0];
      }
      return META_LOOKUP[llIIIllllllIlI];
    }
    
    private static boolean lIlIIIllIII(int ???, int arg1)
    {
      int i;
      long llIIIllIlllllI;
      return ??? < i;
    }
    
    private EnumType(int llIIlIIIIIlIlI, String llIIlIIIIIlIIl, String llIIlIIIIIlIII)
    {
      meta = llIIlIIIIIlIlI;
      name = llIIlIIIIIlIIl;
      unlocalizedName = llIIlIIIIIlIII;
    }
    
    static
    {
      lIlIIIIIlIl();
      lIlIIIIIIlI();
      double llIIlIIIIlIIlI;
      Exception llIIlIIIIlIlIl;
      NORMAL = new EnumType(llIIIIIIl[llIIIIlIl[0]], llIIIIlIl[0], llIIIIlIl[0], llIIIIIIl[llIIIIlIl[1]], llIIIIIIl[llIIIIlIl[2]]);
      MOSSY = new EnumType(llIIIIIIl[llIIIIlIl[3]], llIIIIlIl[1], llIIIIlIl[1], llIIIIIIl[llIIIIlIl[4]], llIIIIIIl[llIIIIlIl[5]]);
      ENUM$VALUES = new EnumType[] { NORMAL, MOSSY };
      META_LOOKUP = new EnumType[values().length];
      boolean llIIlIIIIlIIll = (llIIlIIIIlIIlI = values()).length;
      boolean llIIlIIIIlIlII = llIIIIlIl[0];
      "".length();
      if ("   ".length() == ((0x80 ^ 0xBF ^ 0x48 ^ 0x6C) & (0xD1 ^ 0x8F ^ 0x54 ^ 0x11 ^ -" ".length()))) {
        return;
      }
      while (!lIlIIIlIllI(llIIlIIIIlIlII, llIIlIIIIlIIll))
      {
        EnumType llIIlIIIIlIllI = llIIlIIIIlIIlI[llIIlIIIIlIlII];
        META_LOOKUP[llIIlIIIIlIllI.getMetadata()] = llIIlIIIIlIllI;
        llIIlIIIIlIlII++;
      }
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    private static boolean lIlIIIlIllI(int ???, int arg1)
    {
      int i;
      int llIIIlllIIIIlI;
      return ??? >= i;
    }
    
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    private static void lIlIIIIIIlI()
    {
      llIIIIIIl = new String[llIIIIlIl[6]];
      llIIIIIIl[llIIIIlIl[0]] = lIIlllllllI("LBwcCDYu", "bSNEw");
      llIIIIIIl[llIIIIlIl[1]] = lIIllllllll("YMZmqchO+5kVzPSgIIr74A==", "KzIWe");
      llIIIIIIl[llIIIIlIl[2]] = lIIllllllll("8KeE24zT5hY=", "ImbRG");
      llIIIIIIl[llIIIIlIl[3]] = lIIlllllllI("FDwfOTQ=", "YsLjm");
      llIIIIIIl[llIIIIlIl[4]] = lIIllllllll("XpNvJBVjfcAZz9g9aEFJX3YDntsO/RNp", "KHthQ");
      llIIIIIIl[llIIIIlIl[5]] = lIIlllllllI("Hik3BTU=", "sFDvL");
    }
  }
}

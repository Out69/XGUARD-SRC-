package net.minecraft.block;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class BlockNewLog
  extends BlockLog
{
  protected ItemStack createStackedBlock(IBlockState llllllllllllllllIIlllIlIIlIlIIIl)
  {
    ;
    ;
    return new ItemStack(Item.getItemFromBlock(llllllllllllllllIIlllIlIIlIlIIlI), lllIIIIllII[1], ((BlockPlanks.EnumType)llllllllllllllllIIlllIlIIlIlIIIl.getValue(VARIANT)).getMetadata() - lllIIIIllII[2]);
  }
  
  public BlockNewLog()
  {
    llllllllllllllllIIlllIlIIllllIIl.setDefaultState(blockState.getBaseState().withProperty(VARIANT, BlockPlanks.EnumType.ACACIA).withProperty(LOG_AXIS, BlockLog.EnumAxis.Y));
  }
  
  public int getMetaFromState(IBlockState llllllllllllllllIIlllIlIIlIlllIl)
  {
    ;
    ;
    int llllllllllllllllIIlllIlIIlIlllII = lllIIIIllII[0];
    llllllllllllllllIIlllIlIIlIlllII |= ((BlockPlanks.EnumType)llllllllllllllllIIlllIlIIlIllIll.getValue(VARIANT)).getMetadata() - lllIIIIllII[2];
    switch ($SWITCH_TABLE$net$minecraft$block$BlockLog$EnumAxis()[((BlockLog.EnumAxis)llllllllllllllllIIlllIlIIlIllIll.getValue(LOG_AXIS)).ordinal()])
    {
    case 1: 
      llllllllllllllllIIlllIlIIlIlllII |= lllIIIIllII[2];
      "".length();
      if (((0xF0 ^ 0x9B ^ 0xD7 ^ 0x82) & (0x95 ^ 0xAE ^ 0x20 ^ 0x25 ^ -" ".length())) != 0) {
        return (125 + '' - 202 + 92 ^ 69 + '' - 172 + 104) & (118 + 106 - 86 + 1 ^ 18 + 122 - 39 + 29 ^ -" ".length());
      }
      break;
    case 3: 
      llllllllllllllllIIlllIlIIlIlllII |= lllIIIIllII[5];
      "".length();
      if (((0xDC ^ 0x9C) & (0x73 ^ 0x33 ^ 0xFFFFFFFF)) != 0) {
        return (0xFA ^ 0x98) & (0x6F ^ 0xD ^ 0xFFFFFFFF);
      }
      break;
    case 4: 
      llllllllllllllllIIlllIlIIlIlllII |= lllIIIIllII[4];
    }
    return llllllllllllllllIIlllIlIIlIlllII;
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllllIIlllIlIIllIIIlI)
  {
    ;
    ;
    ;
    IBlockState llllllllllllllllIIlllIlIIllIIlII = llllllllllllllllIIlllIlIIllIIIll.getDefaultState().withProperty(VARIANT, BlockPlanks.EnumType.byMetadata((llllllllllllllllIIlllIlIIllIIIlI & lllIIIIllII[3]) + lllIIIIllII[2]));
    switch (llllllllllllllllIIlllIlIIllIIIlI & lllIIIIllII[4])
    {
    case 0: 
      llllllllllllllllIIlllIlIIllIIlII = llllllllllllllllIIlllIlIIllIIlII.withProperty(LOG_AXIS, BlockLog.EnumAxis.Y);
      "".length();
      if ("  ".length() != "  ".length()) {
        return null;
      }
      break;
    case 4: 
      llllllllllllllllIIlllIlIIllIIlII = llllllllllllllllIIlllIlIIllIIlII.withProperty(LOG_AXIS, BlockLog.EnumAxis.X);
      "".length();
      if (-" ".length() >= 0) {
        return null;
      }
      break;
    case 8: 
      llllllllllllllllIIlllIlIIllIIlII = llllllllllllllllIIlllIlIIllIIlII.withProperty(LOG_AXIS, BlockLog.EnumAxis.Z);
      "".length();
      if (" ".length() < 0) {
        return null;
      }
      break;
    default: 
      llllllllllllllllIIlllIlIIllIIlII = llllllllllllllllIIlllIlIIllIIlII.withProperty(LOG_AXIS, BlockLog.EnumAxis.NONE);
    }
    return llllllllllllllllIIlllIlIIllIIlII;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllllIIlllIlIIlIllIII, new IProperty[] { VARIANT, LOG_AXIS });
  }
  
  private static boolean lIlIllIIlIIII(Object ???)
  {
    double llllllllllllllllIIlllIlIIIlllIlI;
    return ??? != null;
  }
  
  public int damageDropped(IBlockState llllllllllllllllIIlllIlIIlIIlllI)
  {
    ;
    return ((BlockPlanks.EnumType)llllllllllllllllIIlllIlIIlIIlllI.getValue(VARIANT)).getMetadata() - lllIIIIllII[2];
  }
  
  private static void lIlIllIIIlIll()
  {
    lllIIIIlIII = new String[lllIIIIllII[1]];
    lllIIIIlIII[lllIIIIllII[0]] = lIlIllIIIlIlI("jEZn4RtBfbo=", "XKSnQ");
  }
  
  private static String lIlIllIIIlIlI(String llllllllllllllllIIlllIlIIIllllll, String llllllllllllllllIIlllIlIIlIIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIlllIlIIlIIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIlllIlIIlIIIIII.getBytes(StandardCharsets.UTF_8)), lllIIIIllII[5]), "DES");
      Cipher llllllllllllllllIIlllIlIIlIIIIll = Cipher.getInstance("DES");
      llllllllllllllllIIlllIlIIlIIIIll.init(lllIIIIllII[6], llllllllllllllllIIlllIlIIlIIIlII);
      return new String(llllllllllllllllIIlllIlIIlIIIIll.doFinal(Base64.getDecoder().decode(llllllllllllllllIIlllIlIIIllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIlllIlIIlIIIIlI)
    {
      llllllllllllllllIIlllIlIIlIIIIlI.printStackTrace();
    }
    return null;
  }
  
  private static void lIlIllIIIllIl()
  {
    lllIIIIllII = new int[9];
    lllIIIIllII[0] = ((0xAD ^ 0xB7) & (0x2F ^ 0x35 ^ 0xFFFFFFFF));
    lllIIIIllII[1] = " ".length();
    lllIIIIllII[2] = (0xB7 ^ 0x9B ^ 0x2 ^ 0x2A);
    lllIIIIllII[3] = "   ".length();
    lllIIIIllII[4] = (0xAA ^ 0x87 ^ 0xA ^ 0x2B);
    lllIIIIllII[5] = (0x80 ^ 0x88);
    lllIIIIllII[6] = "  ".length();
    lllIIIIllII[7] = (0x67 ^ 0x77 ^ 0x62 ^ 0x77);
    lllIIIIllII[8] = (0x6F ^ 0x5 ^ 0x1 ^ 0x6D);
  }
  
  public void getSubBlocks(Item llllllllllllllllIIlllIlIIllIlllI, CreativeTabs llllllllllllllllIIlllIlIIllIllIl, List<ItemStack> llllllllllllllllIIlllIlIIllIllII)
  {
    ;
    ;
    new ItemStack(llllllllllllllllIIlllIlIIllIlllI, lllIIIIllII[1], BlockPlanks.EnumType.ACACIA.getMetadata() - lllIIIIllII[2]);
    "".length();
    new ItemStack(llllllllllllllllIIlllIlIIllIlllI, lllIIIIllII[1], BlockPlanks.EnumType.DARK_OAK.getMetadata() - lllIIIIllII[2]);
    "".length();
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllllIIlllIlIIlllIIll)
  {
    ;
    ;
    BlockPlanks.EnumType llllllllllllllllIIlllIlIIlllIlII = (BlockPlanks.EnumType)llllllllllllllllIIlllIlIIlllIIll.getValue(VARIANT);
    switch ($SWITCH_TABLE$net$minecraft$block$BlockLog$EnumAxis()[((BlockLog.EnumAxis)llllllllllllllllIIlllIlIIlllIlIl.getValue(LOG_AXIS)).ordinal()])
    {
    case 1: 
    case 3: 
    case 4: 
    default: 
      switch ($SWITCH_TABLE$net$minecraft$block$BlockPlanks$EnumType()[llllllllllllllllIIlllIlIIlllIlII.ordinal()])
      {
      case 5: 
      default: 
        return MapColor.stoneColor;
      }
      return BlockPlanks.EnumType.DARK_OAK.func_181070_c();
    }
    return llllllllllllllllIIlllIlIIlllIlII.func_181070_c();
  }
  
  static
  {
    lIlIllIIIllIl();
    lIlIllIIIlIll();
  }
}

package net.minecraft.block;

import java.util.EnumSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;

public class BlockDynamicLiquid
  extends BlockLiquid
{
  private static void llIlIllllIlIIl()
  {
    lIIIllIllIlIl = new int[9];
    lIIIllIllIlIl[0] = "  ".length();
    lIIIllIllIlIl[1] = " ".length();
    lIIIllIllIlIl[2] = (-(0x45 ^ 0x68 ^ 0x13 ^ 0x5A));
    lIIIllIllIlIl[3] = ((0x39 ^ 0x29) & (0x27 ^ 0x37 ^ 0xFFFFFFFF));
    lIIIllIllIlIl[4] = (0x3 ^ 0x3D ^ 0x55 ^ 0x63);
    lIIIllIllIlIl[5] = (-" ".length());
    lIIIllIllIlIl[6] = (0x93 ^ 0x97);
    lIIIllIllIlIl[7] = "   ".length();
    lIIIllIllIlIl[8] = (0xAFEF & 0x53F8);
  }
  
  private static boolean llIlIllllIlIll(int ???)
  {
    int llllllllllllllIlIIlIlIlllIlIIIIl;
    return ??? == 0;
  }
  
  private void placeStaticBlock(World llllllllllllllIlIIlIllIIlIlllIll, BlockPos llllllllllllllIlIIlIllIIlIlllllI, IBlockState llllllllllllllIlIIlIllIIlIllllIl)
  {
    ;
    ;
    ;
    ;
    "".length();
  }
  
  private boolean canFlowInto(World llllllllllllllIlIIlIlIllllIlIIII, BlockPos llllllllllllllIlIIlIlIllllIlIlII, IBlockState llllllllllllllIlIIlIlIllllIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    Material llllllllllllllIlIIlIlIllllIlIIlI = llllllllllllllIlIIlIlIllllIlIIll.getBlock().getMaterial();
    if ((llIlIlllllIlII(llllllllllllllIlIIlIlIllllIlIIlI, blockMaterial)) && (llIlIlllllIlII(llllllllllllllIlIIlIlIllllIlIIlI, Material.lava)) && (llIlIllllIlIll(llllllllllllllIlIIlIlIllllIlIllI.isBlocked(llllllllllllllIlIIlIlIllllIlIIII, llllllllllllllIlIIlIlIllllIlIlII, llllllllllllllIlIIlIlIllllIlIIll)))) {
      return lIIIllIllIlIl[1];
    }
    return lIIIllIllIlIl[3];
  }
  
  private static boolean llIlIllllIlllI(int ???)
  {
    float llllllllllllllIlIIlIlIlllIIlllIl;
    return ??? < 0;
  }
  
  private static boolean llIlIlllllIIII(int ???, int arg1)
  {
    int i;
    float llllllllllllllIlIIlIlIlllIlllIIl;
    return ??? >= i;
  }
  
  private Set<EnumFacing> getPossibleFlowDirections(World llllllllllllllIlIIlIllIIIIIIlIlI, BlockPos llllllllllllllIlIIlIllIIIIIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIIlIllIIIIIIlIII = lIIIllIllIlIl[8];
    Set<EnumFacing> llllllllllllllIlIIlIllIIIIIIIlll = EnumSet.noneOf(EnumFacing.class);
    String llllllllllllllIlIIlIlIlllllllIlI = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if (null != null) {
      return null;
    }
    while (!llIlIllllIlIll(llllllllllllllIlIIlIlIlllllllIlI.hasNext()))
    {
      Object llllllllllllllIlIIlIllIIIIIIIllI = llllllllllllllIlIIlIlIlllllllIlI.next();
      EnumFacing llllllllllllllIlIIlIllIIIIIIIlIl = (EnumFacing)llllllllllllllIlIIlIllIIIIIIIllI;
      BlockPos llllllllllllllIlIIlIllIIIIIIIlII = llllllllllllllIlIIlIllIIIIIIlIIl.offset(llllllllllllllIlIIlIllIIIIIIIlIl);
      IBlockState llllllllllllllIlIIlIllIIIIIIIIll = llllllllllllllIlIIlIlIllllllllll.getBlockState(llllllllllllllIlIIlIllIIIIIIIlII);
      if ((llIlIllllIlIll(llllllllllllllIlIIlIllIIIIIIlIll.isBlocked(llllllllllllllIlIIlIlIllllllllll, llllllllllllllIlIIlIllIIIIIIIlII, llllllllllllllIlIIlIllIIIIIIIIll))) && ((!llIlIllllIlIlI(llllllllllllllIlIIlIllIIIIIIIIll.getBlock().getMaterial(), blockMaterial)) || (llIlIllllIllII(((Integer)llllllllllllllIlIIlIllIIIIIIIIll.getValue(LEVEL)).intValue()))))
      {
        int llllllllllllllIlIIlIllIIIIIIIIIl;
        if (llIlIlllllIIIl(llllllllllllllIlIIlIllIIIIIIlIll.isBlocked(llllllllllllllIlIIlIlIllllllllll, llllllllllllllIlIIlIllIIIIIIIlII.down(), llllllllllllllIlIIlIlIllllllllll.getBlockState(llllllllllllllIlIIlIllIIIIIIIlII.down()))))
        {
          int llllllllllllllIlIIlIllIIIIIIIIlI = llllllllllllllIlIIlIllIIIIIIlIll.func_176374_a(llllllllllllllIlIIlIlIllllllllll, llllllllllllllIlIIlIllIIIIIIIlII, lIIIllIllIlIl[1], llllllllllllllIlIIlIllIIIIIIIlIl.getOpposite());
          "".length();
          if ((0x86 ^ 0x82) <= 0) {
            return null;
          }
        }
        else
        {
          llllllllllllllIlIIlIllIIIIIIIIIl = lIIIllIllIlIl[3];
        }
        if (llIlIllllIllIl(llllllllllllllIlIIlIllIIIIIIIIIl, llllllllllllllIlIIlIllIIIIIIlIII)) {
          llllllllllllllIlIIlIllIIIIIIIlll.clear();
        }
        if (llIlIlllllIlIl(llllllllllllllIlIIlIllIIIIIIIIIl, llllllllllllllIlIIlIllIIIIIIlIII))
        {
          "".length();
          llllllllllllllIlIIlIllIIIIIIlIII = llllllllllllllIlIIlIllIIIIIIIIIl;
        }
      }
    }
    return llllllllllllllIlIIlIllIIIIIIIlll;
  }
  
  private boolean isBlocked(World llllllllllllllIlIIlIlIlllllIllIl, BlockPos llllllllllllllIlIIlIlIlllllIllII, IBlockState llllllllllllllIlIIlIlIlllllIllll)
  {
    ;
    ;
    ;
    Block llllllllllllllIlIIlIlIlllllIlllI = llllllllllllllIlIIlIlIlllllIllIl.getBlockState(llllllllllllllIlIIlIlIllllllIIII).getBlock();
    if ((llIlIllllIlIll(llllllllllllllIlIIlIlIlllllIlllI instanceof BlockDoor)) && (llIlIlllllIlII(llllllllllllllIlIIlIlIlllllIlllI, Blocks.standing_sign)) && (llIlIlllllIlII(llllllllllllllIlIIlIlIlllllIlllI, Blocks.ladder)) && (llIlIlllllIlII(llllllllllllllIlIIlIlIlllllIlllI, Blocks.reeds)))
    {
      if (llIlIllllIlIlI(blockMaterial, Material.portal))
      {
        "".length();
        if ("   ".length() > ((0x93 ^ 0x96) & (0xB2 ^ 0xB7 ^ 0xFFFFFFFF))) {
          break label177;
        }
        return (0xD0 ^ 0x8F) & (0xCC ^ 0x93 ^ 0xFFFFFFFF);
      }
      "".length();
      if (((0x3A ^ 0x63) & (0x4C ^ 0x15 ^ 0xFFFFFFFF)) == 0) {
        break label177;
      }
      return (0xA2 ^ 0xB7) & (0x83 ^ 0x96 ^ 0xFFFFFFFF);
    }
    label177:
    return lIIIllIllIlIl[1];
  }
  
  private static boolean llIlIllllIllII(int ???)
  {
    Exception llllllllllllllIlIIlIlIlllIIllIll;
    return ??? > 0;
  }
  
  private int func_176374_a(World llllllllllllllIlIIlIllIIIIlIIIll, BlockPos llllllllllllllIlIIlIllIIIIllIIII, int llllllllllllllIlIIlIllIIIIlIIIIl, EnumFacing llllllllllllllIlIIlIllIIIIlIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIIlIllIIIIlIlIlI = lIIIllIllIlIl[8];
    char llllllllllllllIlIIlIllIIIIIlllIl = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if (" ".length() != " ".length()) {
      return (0x84 ^ 0x8F ^ 0x76 ^ 0x57) & (9 + 103 - 14 + 79 ^ 34 + 21 - -51 + 49 ^ -" ".length());
    }
    while (!llIlIllllIlIll(llllllllllllllIlIIlIllIIIIIlllIl.hasNext()))
    {
      Object llllllllllllllIlIIlIllIIIIlIlIIl = llllllllllllllIlIIlIllIIIIIlllIl.next();
      EnumFacing llllllllllllllIlIIlIllIIIIlIlIII = (EnumFacing)llllllllllllllIlIIlIllIIIIlIlIIl;
      if (llIlIlllllIlII(llllllllllllllIlIIlIllIIIIlIlIII, llllllllllllllIlIIlIllIIIIlIllII))
      {
        BlockPos llllllllllllllIlIIlIllIIIIlIIlll = llllllllllllllIlIIlIllIIIIlIIIlI.offset(llllllllllllllIlIIlIllIIIIlIlIII);
        IBlockState llllllllllllllIlIIlIllIIIIlIIllI = llllllllllllllIlIIlIllIIIIlIIIll.getBlockState(llllllllllllllIlIIlIllIIIIlIIlll);
        if ((llIlIllllIlIll(llllllllllllllIlIIlIllIIIIllIIlI.isBlocked(llllllllllllllIlIIlIllIIIIlIIIll, llllllllllllllIlIIlIllIIIIlIIlll, llllllllllllllIlIIlIllIIIIlIIllI))) && ((!llIlIllllIlIlI(llllllllllllllIlIIlIllIIIIlIIllI.getBlock().getMaterial(), blockMaterial)) || (llIlIllllIllII(((Integer)llllllllllllllIlIIlIllIIIIlIIllI.getValue(LEVEL)).intValue()))))
        {
          if (llIlIllllIlIll(llllllllllllllIlIIlIllIIIIllIIlI.isBlocked(llllllllllllllIlIIlIllIIIIlIIIll, llllllllllllllIlIIlIllIIIIlIIlll.down(), llllllllllllllIlIIlIllIIIIlIIllI))) {
            return llllllllllllllIlIIlIllIIIIlIIIIl;
          }
          if (llIlIllllIllIl(llllllllllllllIlIIlIllIIIIlIIIIl, lIIIllIllIlIl[6]))
          {
            int llllllllllllllIlIIlIllIIIIlIIlIl = llllllllllllllIlIIlIllIIIIllIIlI.func_176374_a(llllllllllllllIlIIlIllIIIIlIIIll, llllllllllllllIlIIlIllIIIIlIIlll, llllllllllllllIlIIlIllIIIIlIIIIl + lIIIllIllIlIl[1], llllllllllllllIlIIlIllIIIIlIlIII.getOpposite());
            if (llIlIllllIllIl(llllllllllllllIlIIlIllIIIIlIIlIl, llllllllllllllIlIIlIllIIIIlIlIlI)) {
              llllllllllllllIlIIlIllIIIIlIlIlI = llllllllllllllIlIIlIllIIIIlIIlIl;
            }
          }
        }
      }
    }
    return llllllllllllllIlIIlIllIIIIlIlIlI;
  }
  
  private static boolean llIlIlllllIIlI(int ???, int arg1)
  {
    int i;
    int llllllllllllllIlIIlIlIlllIlIllIl;
    return ??? > i;
  }
  
  private static boolean llIlIllllIllll(int ???)
  {
    char llllllllllllllIlIIlIlIlllIIlllll;
    return ??? >= 0;
  }
  
  private void tryFlowInto(World llllllllllllllIlIIlIllIIIlIlIIII, BlockPos llllllllllllllIlIIlIllIIIlIIllll, IBlockState llllllllllllllIlIIlIllIIIlIIlllI, int llllllllllllllIlIIlIllIIIlIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIlIlllllIIIl(llllllllllllllIlIIlIllIIIlIlIIIl.canFlowInto(llllllllllllllIlIIlIllIIIlIlIIII, llllllllllllllIlIIlIllIIIlIlIlII, llllllllllllllIlIIlIllIIIlIIlllI)))
    {
      if (llIlIlllllIlII(llllllllllllllIlIIlIllIIIlIIlllI.getBlock(), Blocks.air)) {
        if (llIlIllllIlIlI(blockMaterial, Material.lava))
        {
          llllllllllllllIlIIlIllIIIlIlIIIl.triggerMixEffects(llllllllllllllIlIIlIllIIIlIlIIII, llllllllllllllIlIIlIllIIIlIlIlII);
          "".length();
          if (" ".length() > 0) {}
        }
        else
        {
          llllllllllllllIlIIlIllIIIlIIlllI.getBlock().dropBlockAsItem(llllllllllllllIlIIlIllIIIlIlIIII, llllllllllllllIlIIlIllIIIlIlIlII, llllllllllllllIlIIlIllIIIlIIlllI, lIIIllIllIlIl[3]);
        }
      }
      "".length();
    }
  }
  
  private static boolean llIlIlllllIlII(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllIlIIlIlIlllIlIlIIl;
    return ??? != localObject;
  }
  
  protected int checkAdjacentBlock(World llllllllllllllIlIIlIlIlllllIIlII, BlockPos llllllllllllllIlIIlIlIlllllIIIll, int llllllllllllllIlIIlIlIlllllIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIIlIlIlllllIIIIl = llllllllllllllIlIIlIlIlllllIIIII.getLevel(llllllllllllllIlIIlIlIlllllIIlII, llllllllllllllIlIIlIlIlllllIIIll);
    if (llIlIllllIlllI(llllllllllllllIlIIlIlIlllllIIIIl)) {
      return llllllllllllllIlIIlIlIlllllIIIlI;
    }
    if (llIlIllllIlIll(llllllllllllllIlIIlIlIlllllIIIIl)) {
      adjacentSourceBlocks += lIIIllIllIlIl[1];
    }
    if (llIlIlllllIIII(llllllllllllllIlIIlIlIlllllIIIIl, lIIIllIllIlIl[4])) {
      llllllllllllllIlIIlIlIlllllIIIIl = lIIIllIllIlIl[3];
    }
    if ((llIlIllllIllll(llllllllllllllIlIIlIlIlllllIIIlI)) && (llIlIlllllIIII(llllllllllllllIlIIlIlIlllllIIIIl, llllllllllllllIlIIlIlIlllllIIIlI)))
    {
      "".length();
      if (null == null) {
        break label105;
      }
      return (0x4B ^ 0xD) & (0xD6 ^ 0x90 ^ 0xFFFFFFFF);
    }
    label105:
    return llllllllllllllIlIIlIlIlllllIIIIl;
  }
  
  static {}
  
  private static boolean llIlIlllllIIIl(int ???)
  {
    short llllllllllllllIlIIlIlIlllIlIIIll;
    return ??? != 0;
  }
  
  public void updateTick(World llllllllllllllIlIIlIllIIlIIlllII, BlockPos llllllllllllllIlIIlIllIIlIIllIlI, IBlockState llllllllllllllIlIIlIllIIlIIllIIl, Random llllllllllllllIlIIlIllIIlIIlIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIIlIllIIlIIlIlIl = ((Integer)llllllllllllllIlIIlIllIIlIIllIIl.getValue(LEVEL)).intValue();
    int llllllllllllllIlIIlIllIIlIIlIlII = lIIIllIllIlIl[1];
    if ((llIlIllllIlIlI(blockMaterial, Material.lava)) && (llIlIllllIlIll(provider.doesWaterVaporize()))) {
      llllllllllllllIlIIlIllIIlIIlIlII = lIIIllIllIlIl[0];
    }
    int llllllllllllllIlIIlIllIIlIIlIIll = llllllllllllllIlIIlIllIIlIIllllI.tickRate(llllllllllllllIlIIlIllIIlIIlllII);
    if (llIlIllllIllII(llllllllllllllIlIIlIllIIlIIlIlIl))
    {
      int llllllllllllllIlIIlIllIIlIIlIIIl = lIIIllIllIlIl[2];
      adjacentSourceBlocks = lIIIllIllIlIl[3];
      llllllllllllllIlIIlIllIIIllIllIl = EnumFacing.Plane.HORIZONTAL.iterator();
      "".length();
      if (null != null) {
        return;
      }
      while (!llIlIllllIlIll(llllllllllllllIlIIlIllIIIllIllIl.hasNext()))
      {
        Object llllllllllllllIlIIlIllIIlIIIllll = llllllllllllllIlIIlIllIIIllIllIl.next();
        EnumFacing llllllllllllllIlIIlIllIIlIIIllIl = (EnumFacing)llllllllllllllIlIIlIllIIlIIIllll;
        llllllllllllllIlIIlIllIIlIIlIIIl = llllllllllllllIlIIlIllIIlIIllllI.checkAdjacentBlock(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl.offset(llllllllllllllIlIIlIllIIlIIIllIl), llllllllllllllIlIIlIllIIlIIlIIIl);
      }
      int llllllllllllllIlIIlIllIIlIIIllII = llllllllllllllIlIIlIllIIlIIlIIIl + llllllllllllllIlIIlIllIIlIIlIlII;
      if ((!llIlIllllIllIl(llllllllllllllIlIIlIllIIlIIIllII, lIIIllIllIlIl[4])) || (llIlIllllIlllI(llllllllllllllIlIIlIllIIlIIlIIIl))) {
        llllllllllllllIlIIlIllIIlIIIllII = lIIIllIllIlIl[5];
      }
      if (llIlIllllIllll(llllllllllllllIlIIlIllIIlIIllllI.getLevel(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl.up())))
      {
        int llllllllllllllIlIIlIllIIlIIIlIlI = llllllllllllllIlIIlIllIIlIIllllI.getLevel(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl.up());
        if (llIlIlllllIIII(llllllllllllllIlIIlIllIIlIIIlIlI, lIIIllIllIlIl[4]))
        {
          llllllllllllllIlIIlIllIIlIIIllII = llllllllllllllIlIIlIllIIlIIIlIlI;
          "".length();
          if ("  ".length() != 0) {}
        }
        else
        {
          llllllllllllllIlIIlIllIIlIIIllII = llllllllllllllIlIIlIllIIlIIIlIlI + lIIIllIllIlIl[4];
        }
      }
      if ((llIlIlllllIIII(adjacentSourceBlocks, lIIIllIllIlIl[0])) && (llIlIllllIlIlI(blockMaterial, Material.water)))
      {
        IBlockState llllllllllllllIlIIlIllIIlIIIlIIl = llllllllllllllIlIIlIllIIlIIlllII.getBlockState(llllllllllllllIlIIlIllIIIlllllIl.down());
        if (llIlIlllllIIIl(llllllllllllllIlIIlIllIIlIIIlIIl.getBlock().getMaterial().isSolid()))
        {
          llllllllllllllIlIIlIllIIlIIIllII = lIIIllIllIlIl[3];
          "".length();
          if (((0xCF ^ 0xC3) & (0x90 ^ 0x9C ^ 0xFFFFFFFF)) == 0) {}
        }
        else if ((llIlIllllIlIlI(llllllllllllllIlIIlIllIIlIIIlIIl.getBlock().getMaterial(), blockMaterial)) && (llIlIllllIlIll(((Integer)llllllllllllllIlIIlIllIIlIIIlIIl.getValue(LEVEL)).intValue())))
        {
          llllllllllllllIlIIlIllIIlIIIllII = lIIIllIllIlIl[3];
        }
      }
      if ((llIlIllllIlIlI(blockMaterial, Material.lava)) && (llIlIllllIllIl(llllllllllllllIlIIlIllIIlIIlIlIl, lIIIllIllIlIl[4])) && (llIlIllllIllIl(llllllllllllllIlIIlIllIIlIIIllII, lIIIllIllIlIl[4])) && (llIlIlllllIIlI(llllllllllllllIlIIlIllIIlIIIllII, llllllllllllllIlIIlIllIIlIIlIlIl)) && (llIlIlllllIIIl(llllllllllllllIlIIlIllIIlIIlIlll.nextInt(lIIIllIllIlIl[6])))) {
        llllllllllllllIlIIlIllIIlIIlIIll *= lIIIllIllIlIl[6];
      }
      if (llIlIlllllIIll(llllllllllllllIlIIlIllIIlIIIllII, llllllllllllllIlIIlIllIIlIIlIlIl))
      {
        llllllllllllllIlIIlIllIIlIIllllI.placeStaticBlock(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl, llllllllllllllIlIIlIllIIlIIllIIl);
        "".length();
        if (null == null) {}
      }
      else
      {
        llllllllllllllIlIIlIllIIlIIlIlIl = llllllllllllllIlIIlIllIIlIIIllII;
        if (llIlIllllIlllI(llllllllllllllIlIIlIllIIlIIIllII))
        {
          "".length();
          "".length();
          if (" ".length() > ((0x32 ^ 0xD) & (0x53 ^ 0x6C ^ 0xFFFFFFFF))) {}
        }
        else
        {
          llllllllllllllIlIIlIllIIlIIllIIl = llllllllllllllIlIIlIllIIlIIllIIl.withProperty(LEVEL, Integer.valueOf(llllllllllllllIlIIlIllIIlIIIllII));
          "".length();
          llllllllllllllIlIIlIllIIlIIlllII.scheduleUpdate(llllllllllllllIlIIlIllIIIlllllIl, llllllllllllllIlIIlIllIIlIIllllI, llllllllllllllIlIIlIllIIlIIlIIll);
          llllllllllllllIlIIlIllIIlIIlllII.notifyNeighborsOfStateChange(llllllllllllllIlIIlIllIIIlllllIl, llllllllllllllIlIIlIllIIlIIllllI);
          "".length();
          if ("   ".length() >= 0) {}
        }
      }
    }
    else
    {
      llllllllllllllIlIIlIllIIlIIllllI.placeStaticBlock(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl, llllllllllllllIlIIlIllIIlIIllIIl);
    }
    IBlockState llllllllllllllIlIIlIllIIlIIIlIII = llllllllllllllIlIIlIllIIlIIlllII.getBlockState(llllllllllllllIlIIlIllIIIlllllIl.down());
    if (llIlIlllllIIIl(llllllllllllllIlIIlIllIIlIIllllI.canFlowInto(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl.down(), llllllllllllllIlIIlIllIIlIIIlIII)))
    {
      if ((llIlIllllIlIlI(blockMaterial, Material.lava)) && (llIlIllllIlIlI(llllllllllllllIlIIlIllIIlIIlllII.getBlockState(llllllllllllllIlIIlIllIIIlllllIl.down()).getBlock().getMaterial(), Material.water)))
      {
        "".length();
        llllllllllllllIlIIlIllIIlIIllllI.triggerMixEffects(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl.down());
        return;
      }
      if (llIlIlllllIIII(llllllllllllllIlIIlIllIIlIIlIlIl, lIIIllIllIlIl[4]))
      {
        llllllllllllllIlIIlIllIIlIIllllI.tryFlowInto(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl.down(), llllllllllllllIlIIlIllIIlIIIlIII, llllllllllllllIlIIlIllIIlIIlIlIl);
        "".length();
        if ("  ".length() > 0) {}
      }
      else
      {
        llllllllllllllIlIIlIllIIlIIllllI.tryFlowInto(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl.down(), llllllllllllllIlIIlIllIIlIIIlIII, llllllllllllllIlIIlIllIIlIIlIlIl + lIIIllIllIlIl[4]);
        "".length();
        if ((30 + '' - 68 + 71 ^ 126 + 86 - 115 + 83) > "  ".length()) {}
      }
    }
    else if ((llIlIllllIllll(llllllllllllllIlIIlIllIIlIIlIlIl)) && ((!llIlIlllllIIIl(llllllllllllllIlIIlIllIIlIIlIlIl)) || (llIlIlllllIIIl(llllllllllllllIlIIlIllIIlIIllllI.isBlocked(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl.down(), llllllllllllllIlIIlIllIIlIIIlIII)))))
    {
      Set<EnumFacing> llllllllllllllIlIIlIllIIlIIIIlll = llllllllllllllIlIIlIllIIlIIllllI.getPossibleFlowDirections(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl);
      int llllllllllllllIlIIlIllIIlIIIIllI = llllllllllllllIlIIlIllIIlIIlIlIl + llllllllllllllIlIIlIllIIlIIlIlII;
      if (llIlIlllllIIII(llllllllllllllIlIIlIllIIlIIlIlIl, lIIIllIllIlIl[4])) {
        llllllllllllllIlIIlIllIIlIIIIllI = lIIIllIllIlIl[1];
      }
      if (llIlIlllllIIII(llllllllllllllIlIIlIllIIlIIIIllI, lIIIllIllIlIl[4])) {
        return;
      }
      llllllllllllllIlIIlIllIIIllIlIIl = llllllllllllllIlIIlIllIIlIIIIlll.iterator();
      "".length();
      if ((0x8F ^ 0x82 ^ 0xA0 ^ 0xA9) <= 0) {
        return;
      }
      while (!llIlIllllIlIll(llllllllllllllIlIIlIllIIIllIlIIl.hasNext()))
      {
        EnumFacing llllllllllllllIlIIlIllIIlIIIIlIl = (EnumFacing)llllllllllllllIlIIlIllIIIllIlIIl.next();
        llllllllllllllIlIIlIllIIlIIllllI.tryFlowInto(llllllllllllllIlIIlIllIIlIIlllII, llllllllllllllIlIIlIllIIIlllllIl.offset(llllllllllllllIlIIlIllIIlIIIIlIl), llllllllllllllIlIIlIllIIlIIlllII.getBlockState(llllllllllllllIlIIlIllIIIlllllIl.offset(llllllllllllllIlIIlIllIIlIIIIlIl)), llllllllllllllIlIIlIllIIlIIIIllI);
      }
    }
  }
  
  protected BlockDynamicLiquid(Material llllllllllllllIlIIlIllIIllIIIlIl)
  {
    llllllllllllllIlIIlIllIIllIIIllI.<init>(llllllllllllllIlIIlIllIIllIIIlIl);
  }
  
  private static boolean llIlIllllIlIlI(Object ???, Object arg1)
  {
    Object localObject;
    boolean llllllllllllllIlIIlIlIlllIlIIlIl;
    return ??? == localObject;
  }
  
  private static boolean llIlIlllllIIll(int ???, int arg1)
  {
    int i;
    String llllllllllllllIlIIlIlIlllIllllIl;
    return ??? == i;
  }
  
  private static boolean llIlIlllllIlIl(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlIIlIlIlllIllIIIl;
    return ??? <= i;
  }
  
  public void onBlockAdded(World llllllllllllllIlIIlIlIllllIIIIll, BlockPos llllllllllllllIlIIlIlIllllIIIllI, IBlockState llllllllllllllIlIIlIlIllllIIIlIl)
  {
    ;
    ;
    ;
    ;
    if (llIlIllllIlIll(llllllllllllllIlIIlIlIllllIIlIII.checkForMixing(llllllllllllllIlIIlIlIllllIIIIll, llllllllllllllIlIIlIlIllllIIIllI, llllllllllllllIlIIlIlIllllIIIlIl))) {
      llllllllllllllIlIIlIlIllllIIIIll.scheduleUpdate(llllllllllllllIlIIlIlIllllIIIllI, llllllllllllllIlIIlIlIllllIIlIII, llllllllllllllIlIIlIlIllllIIlIII.tickRate(llllllllllllllIlIIlIlIllllIIIIll));
    }
  }
  
  private static boolean llIlIllllIllIl(int ???, int arg1)
  {
    int i;
    double llllllllllllllIlIIlIlIlllIllIlIl;
    return ??? < i;
  }
}

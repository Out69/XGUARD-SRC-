package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;

public abstract class BlockDirectional
  extends Block
{
  protected BlockDirectional(Material llllllllllllllllIlIIlllIlIIIllII, MapColor llllllllllllllllIlIIlllIlIIIlIll)
  {
    llllllllllllllllIlIIlllIlIIlIIII.<init>(llllllllllllllllIlIIlllIlIIIllll, llllllllllllllllIlIIlllIlIIIlIll);
  }
  
  static
  {
    lIlIIIlIIIlIl();
    lIlIIIlIIIlII();
  }
  
  protected BlockDirectional(Material llllllllllllllllIlIIlllIlIIlIlII)
  {
    llllllllllllllllIlIIlllIlIIlIlll.<init>(llllllllllllllllIlIIlllIlIIlIlII);
  }
  
  private static void lIlIIIlIIIlIl()
  {
    llIlIlIIlll = new int[2];
    llIlIlIIlll[0] = ((117 + 77 - 107 + 114 ^ 123 + '¬' - 227 + 131) & (0xCE ^ 0x8F ^ 0x15 ^ 0x5A ^ -" ".length()));
    llIlIlIIlll[1] = " ".length();
  }
  
  private static void lIlIIIlIIIlII()
  {
    llIlIlIIllI = new String[llIlIlIIlll[1]];
    llIlIlIIllI[llIlIlIIlll[0]] = lIlIIIlIIIIll("ASwtACwA", "gMNiB");
  }
  
  private static String lIlIIIlIIIIll(String llllllllllllllllIlIIlllIIllllIll, String llllllllllllllllIlIIlllIIlllllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIlIIlllIIllllIll = new String(Base64.getDecoder().decode(llllllllllllllllIlIIlllIIllllIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIlIIlllIIllllllI = new StringBuilder();
    char[] llllllllllllllllIlIIlllIIlllllIl = llllllllllllllllIlIIlllIIlllllll.toCharArray();
    int llllllllllllllllIlIIlllIIlllllII = llIlIlIIlll[0];
    Exception llllllllllllllllIlIIlllIIlllIllI = llllllllllllllllIlIIlllIIllllIll.toCharArray();
    float llllllllllllllllIlIIlllIIlllIlIl = llllllllllllllllIlIIlllIIlllIllI.length;
    byte llllllllllllllllIlIIlllIIlllIlII = llIlIlIIlll[0];
    while (lIlIIIlIIIllI(llllllllllllllllIlIIlllIIlllIlII, llllllllllllllllIlIIlllIIlllIlIl))
    {
      char llllllllllllllllIlIIlllIlIIIIIIl = llllllllllllllllIlIIlllIIlllIllI[llllllllllllllllIlIIlllIIlllIlII];
      "".length();
      "".length();
      if (-"  ".length() > 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIlIIlllIIllllllI);
  }
  
  private static boolean lIlIIIlIIIllI(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllIlIIlllIIllIllll;
    return ??? < i;
  }
}

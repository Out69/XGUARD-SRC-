package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockWallSign
  extends BlockSign
{
  public BlockWallSign()
  {
    llllllllllllllIlIIlIlIlIIIIIIIll.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
  }
  
  private static void llIllIIIIlIIll()
  {
    lIIIlllIIIlll = new String[lIIIlllIIlIII[1]];
    lIIIlllIIIlll[lIIIlllIIlIII[0]] = llIllIIIIlIIlI("CykPCBkK", "mHlaw");
  }
  
  private static void llIllIIIIlIlII()
  {
    lIIIlllIIlIII = new int[7];
    lIIIlllIIlIII[0] = ((0x68 ^ 0x1E ^ 0x21 ^ 0x0) & (0x24 ^ 0x5E ^ 0x8A ^ 0xA7 ^ -" ".length()));
    lIIIlllIIlIII[1] = " ".length();
    lIIIlllIIlIII[2] = (0x46 ^ 0x38 ^ 0x32 ^ 0x4A);
    lIIIlllIIlIII[3] = "   ".length();
    lIIIlllIIlIII[4] = (0x8A ^ 0x96 ^ 0xA2 ^ 0xBA);
    lIIIlllIIlIII[5] = "  ".length();
    lIIIlllIIlIII[6] = (0x5C ^ 0x59);
  }
  
  private static boolean llIllIIIIlIlll(Object ???)
  {
    int llllllllllllllIlIIlIlIIllIlIIIIl;
    return ??? != null;
  }
  
  public void onNeighborBlockChange(World llllllllllllllIlIIlIlIIlllIlllll, BlockPos llllllllllllllIlIIlIlIIlllIllIII, IBlockState llllllllllllllIlIIlIlIIlllIlllIl, Block llllllllllllllIlIIlIlIIlllIlIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllIlIIlIlIIlllIllIll = (EnumFacing)llllllllllllllIlIIlIlIIlllIlllIl.getValue(FACING);
    if (llIllIIIIlIlIl(llllllllllllllIlIIlIlIIlllIlllll.getBlockState(llllllllllllllIlIIlIlIIlllIllllI.offset(llllllllllllllIlIIlIlIIlllIllIll.getOpposite())).getBlock().getMaterial().isSolid()))
    {
      llllllllllllllIlIIlIlIIllllIIIII.dropBlockAsItem(llllllllllllllIlIIlIlIIlllIlllll, llllllllllllllIlIIlIlIIlllIllllI, llllllllllllllIlIIlIlIIlllIlllIl, lIIIlllIIlIII[0]);
      "".length();
    }
    llllllllllllllIlIIlIlIIllllIIIII.onNeighborBlockChange(llllllllllllllIlIIlIlIIlllIlllll, llllllllllllllIlIIlIlIIlllIllllI, llllllllllllllIlIIlIlIIlllIlllIl, llllllllllllllIlIIlIlIIlllIlIllI);
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIlIIlIlIIlllllIlll, BlockPos llllllllllllllIlIIlIlIIlllllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllIlIIlIlIIlllllIlIl = (EnumFacing)llllllllllllllIlIIlIlIIlllllIlll.getBlockState(llllllllllllllIlIIlIlIIlllllIllI).getValue(FACING);
    float llllllllllllllIlIIlIlIIlllllIlII = 0.28125F;
    float llllllllllllllIlIIlIlIIlllllIIll = 0.78125F;
    float llllllllllllllIlIIlIlIIlllllIIlI = 0.0F;
    float llllllllllllllIlIIlIlIIlllllIIIl = 1.0F;
    float llllllllllllllIlIIlIlIIlllllIIII = 0.125F;
    llllllllllllllIlIIlIlIIllllIllll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[llllllllllllllIlIIlIlIIlllllIlIl.ordinal()])
    {
    case 3: 
      llllllllllllllIlIIlIlIIllllIllll.setBlockBounds(llllllllllllllIlIIlIlIIlllllIIlI, llllllllllllllIlIIlIlIIlllllIlII, 1.0F - llllllllllllllIlIIlIlIIlllllIIII, llllllllllllllIlIIlIlIIlllllIIIl, llllllllllllllIlIIlIlIIlllllIIll, 1.0F);
      "".length();
      if (-" ".length() > -" ".length()) {}
      break;
    case 4: 
      llllllllllllllIlIIlIlIIllllIllll.setBlockBounds(llllllllllllllIlIIlIlIIlllllIIlI, llllllllllllllIlIIlIlIIlllllIlII, 0.0F, llllllllllllllIlIIlIlIIlllllIIIl, llllllllllllllIlIIlIlIIlllllIIll, llllllllllllllIlIIlIlIIlllllIIII);
      "".length();
      if (((0xC7 ^ 0x94 ^ 0xFD ^ 0xA0) & (0x39 ^ 0x26 ^ 0x67 ^ 0x76 ^ -" ".length())) > 0) {}
      break;
    case 5: 
      llllllllllllllIlIIlIlIIllllIllll.setBlockBounds(1.0F - llllllllllllllIlIIlIlIIlllllIIII, llllllllllllllIlIIlIlIIlllllIlII, llllllllllllllIlIIlIlIIlllllIIlI, 1.0F, llllllllllllllIlIIlIlIIlllllIIll, llllllllllllllIlIIlIlIIlllllIIIl);
      "".length();
      if ("   ".length() == "  ".length()) {}
      break;
    case 6: 
      llllllllllllllIlIIlIlIIllllIllll.setBlockBounds(0.0F, llllllllllllllIlIIlIlIIlllllIlII, llllllllllllllIlIIlIlIIlllllIIlI, llllllllllllllIlIIlIlIIlllllIIII, llllllllllllllIlIIlIlIIlllllIIll, llllllllllllllIlIIlIlIIlllllIIIl);
    }
  }
  
  private static boolean llIllIIIIllIII(int ???, int arg1)
  {
    int i;
    double llllllllllllllIlIIlIlIIllIlIIlll;
    return ??? < i;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIlIIlIlIIlllIIlIIl)
  {
    ;
    return ((EnumFacing)llllllllllllllIlIIlIlIIlllIIlIIl.getValue(FACING)).getIndex();
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIlIIlIlIIlllIIllIl)
  {
    ;
    ;
    ;
    EnumFacing llllllllllllllIlIIlIlIIlllIIllll = EnumFacing.getFront(llllllllllllllIlIIlIlIIlllIIllIl);
    if (llIllIIIIlIllI(llllllllllllllIlIIlIlIIlllIIllll.getAxis(), EnumFacing.Axis.Y)) {
      llllllllllllllIlIIlIlIIlllIIllll = EnumFacing.NORTH;
    }
    return llllllllllllllIlIIlIlIIlllIlIIIl.getDefaultState().withProperty(FACING, llllllllllllllIlIIlIlIIlllIIllll);
  }
  
  private static boolean llIllIIIIlIllI(Object ???, Object arg1)
  {
    Object localObject;
    float llllllllllllllIlIIlIlIIllIlIIIll;
    return ??? == localObject;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIlIIlIlIIlllIIIllI, new IProperty[] { FACING });
  }
  
  private static boolean llIllIIIIlIlIl(int ???)
  {
    float llllllllllllllIlIIlIlIIllIIlllll;
    return ??? == 0;
  }
  
  private static String llIllIIIIlIIlI(String llllllllllllllIlIIlIlIIllIllIIll, String llllllllllllllIlIIlIlIIllIllIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIlIlIIllIllIIll = new String(Base64.getDecoder().decode(llllllllllllllIlIIlIlIIllIllIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIIlIlIIllIllIllI = new StringBuilder();
    char[] llllllllllllllIlIIlIlIIllIllIlIl = llllllllllllllIlIIlIlIIllIllIIlI.toCharArray();
    int llllllllllllllIlIIlIlIIllIllIlII = lIIIlllIIlIII[0];
    int llllllllllllllIlIIlIlIIllIlIlllI = llllllllllllllIlIIlIlIIllIllIIll.toCharArray();
    double llllllllllllllIlIIlIlIIllIlIllIl = llllllllllllllIlIIlIlIIllIlIlllI.length;
    char llllllllllllllIlIIlIlIIllIlIllII = lIIIlllIIlIII[0];
    while (llIllIIIIllIII(llllllllllllllIlIIlIlIIllIlIllII, llllllllllllllIlIIlIlIIllIlIllIl))
    {
      char llllllllllllllIlIIlIlIIllIlllIIl = llllllllllllllIlIIlIlIIllIlIlllI[llllllllllllllIlIIlIlIIllIlIllII];
      "".length();
      "".length();
      if (-" ".length() > "  ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIIlIlIIllIllIllI);
  }
  
  static
  {
    llIllIIIIlIlII();
    llIllIIIIlIIll();
  }
}

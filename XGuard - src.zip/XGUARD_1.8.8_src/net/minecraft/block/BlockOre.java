package net.minecraft.block;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.UnmodifiableIterator;
import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class BlockOre
  extends Block
{
  static {}
  
  private static boolean lIIIllIIIlI(int ???)
  {
    char llllIIllIllllI;
    return ??? < 0;
  }
  
  private static void lIIIlIllllI()
  {
    lIlIlIlIl = new int[7];
    lIlIlIlIl[0] = (0xB4 ^ 0x85 ^ 0xF7 ^ 0xC2);
    lIlIlIlIl[1] = ('¿' + 16 - 67 + 53 ^ '' + 123 - 110 + 49);
    lIlIlIlIl[2] = " ".length();
    lIlIlIlIl[3] = "  ".length();
    lIlIlIlIl[4] = ((0x4B ^ 0x8) & (0x78 ^ 0x3B ^ 0xFFFFFFFF));
    lIlIlIlIl[5] = "   ".length();
    lIlIlIlIl[6] = (0xA4 ^ 0xA3);
  }
  
  public BlockOre()
  {
    llllIlIIlIIIlI.<init>(Material.rock.getMaterialMapColor());
  }
  
  private static boolean lIIIlIlllll(Object ???, Object arg1)
  {
    Object localObject;
    byte llllIIlllIIIII;
    return ??? == localObject;
  }
  
  private static boolean lIIIllIIIII(int ???)
  {
    Exception llllIIllIlllII;
    return ??? > 0;
  }
  
  public int damageDropped(IBlockState llllIIlllIlIIl)
  {
    ;
    if (lIIIlIlllll(llllIIlllIlIII, Blocks.lapis_ore))
    {
      "".length();
      if ("   ".length() <= "   ".length()) {
        break label56;
      }
      return (0xB5 ^ 0x8A) & (0x68 ^ 0x57 ^ 0xFFFFFFFF);
    }
    label56:
    return lIlIlIlIl[4];
  }
  
  public int getDamageValue(World llllIIlllIllIl, BlockPos llllIIlllIllII)
  {
    return lIlIlIlIl[4];
  }
  
  public BlockOre(MapColor llllIlIIIlllII)
  {
    llllIlIIIlllll.<init>(Material.rock, llllIlIIIlllII);
    "".length();
  }
  
  public Item getItemDropped(IBlockState llllIlIIIllIIl, Random llllIlIIIllIII, int llllIlIIIlIlll)
  {
    ;
    if (lIIIlIlllll(llllIlIIIlIllI, Blocks.coal_ore))
    {
      "".length();
      if ("   ".length() < 0) {
        return null;
      }
    }
    else if (lIIIlIlllll(llllIlIIIlIllI, Blocks.diamond_ore))
    {
      "".length();
      if ("   ".length() < 0) {
        return null;
      }
    }
    else if (lIIIlIlllll(llllIlIIIlIllI, Blocks.lapis_ore))
    {
      "".length();
      if (-" ".length() != -" ".length()) {
        return null;
      }
    }
    else if (lIIIlIlllll(llllIlIIIlIllI, Blocks.emerald_ore))
    {
      "".length();
      if ("   ".length() <= -" ".length()) {
        return null;
      }
    }
    else if (lIIIlIlllll(llllIlIIIlIllI, Blocks.quartz_ore))
    {
      "".length();
      if (null == null) {
        break label158;
      }
      return null;
    }
    label158:
    return Item.getItemFromBlock(llllIlIIIlIllI);
  }
  
  private static boolean lIIIllIIIIl(Object ???, Object arg1)
  {
    Object localObject;
    byte llllIIlllIIlII;
    return ??? != localObject;
  }
  
  public int quantityDroppedWithBonus(int llllIlIIIIIllI, Random llllIlIIIIIlIl)
  {
    ;
    ;
    ;
    ;
    if ((lIIIllIIIII(llllIlIIIIIllI)) && (lIIIllIIIIl(Item.getItemFromBlock(llllIlIIIIlIll), llllIlIIIIlIll.getItemDropped((IBlockState)llllIlIIIIlIll.getBlockState().getValidStates().iterator().next(), llllIlIIIIIlIl, llllIlIIIIlIlI))))
    {
      int llllIlIIIIlIII = llllIlIIIIIlIl.nextInt(llllIlIIIIlIlI + lIlIlIlIl[3]) - lIlIlIlIl[2];
      if (lIIIllIIIlI(llllIlIIIIlIII)) {
        llllIlIIIIlIII = lIlIlIlIl[4];
      }
      return llllIlIIIIlIll.quantityDropped(llllIlIIIIIlIl) * (llllIlIIIIlIII + lIlIlIlIl[2]);
    }
    return llllIlIIIIlIll.quantityDropped(llllIlIIIIIlIl);
  }
  
  public int quantityDropped(Random llllIlIIIlIIII)
  {
    ;
    ;
    if (lIIIlIlllll(llllIlIIIlIIll, Blocks.lapis_ore))
    {
      "".length();
      if (null == null) {
        break label77;
      }
      return (0x58 ^ 0x18 ^ 0xC6 ^ 0x8B) & (0xD0 ^ 0x8A ^ 0xD4 ^ 0x83 ^ -" ".length());
    }
    label77:
    return lIlIlIlIl[2];
  }
  
  public void dropBlockAsItemWithChance(World llllIIllllIlII, BlockPos llllIIllllIIll, IBlockState llllIIlllllIIl, float llllIIlllllIII, int llllIIllllIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllIIllllllII.dropBlockAsItemWithChance(llllIIllllIlII, llllIIllllIIll, llllIIlllllIIl, llllIIlllllIII, llllIIllllIlll);
    if (lIIIllIIIIl(llllIIllllllII.getItemDropped(llllIIlllllIIl, rand, llllIIllllIlll), Item.getItemFromBlock(llllIIllllllII)))
    {
      int llllIIllllIllI = lIlIlIlIl[4];
      if (lIIIlIlllll(llllIIllllllII, Blocks.coal_ore))
      {
        llllIIllllIllI = MathHelper.getRandomIntegerInRange(rand, lIlIlIlIl[4], lIlIlIlIl[3]);
        "".length();
        if (" ".length() <= (5 + '­' - 59 + 58 ^ '¤' + 32 - 78 + 63)) {}
      }
      else if (lIIIlIlllll(llllIIllllllII, Blocks.diamond_ore))
      {
        llllIIllllIllI = MathHelper.getRandomIntegerInRange(rand, lIlIlIlIl[5], lIlIlIlIl[6]);
        "".length();
        if (-" ".length() < 0) {}
      }
      else if (lIIIlIlllll(llllIIllllllII, Blocks.emerald_ore))
      {
        llllIIllllIllI = MathHelper.getRandomIntegerInRange(rand, lIlIlIlIl[5], lIlIlIlIl[6]);
        "".length();
        if (" ".length() > -" ".length()) {}
      }
      else if (lIIIlIlllll(llllIIllllllII, Blocks.lapis_ore))
      {
        llllIIllllIllI = MathHelper.getRandomIntegerInRange(rand, lIlIlIlIl[3], lIlIlIlIl[1]);
        "".length();
        if (null == null) {}
      }
      else if (lIIIlIlllll(llllIIllllllII, Blocks.quartz_ore))
      {
        llllIIllllIllI = MathHelper.getRandomIntegerInRange(rand, lIlIlIlIl[3], lIlIlIlIl[1]);
      }
      llllIIllllllII.dropXpOnBlockBreak(llllIIllllIlII, llllIIllllIIll, llllIIllllIllI);
    }
  }
}

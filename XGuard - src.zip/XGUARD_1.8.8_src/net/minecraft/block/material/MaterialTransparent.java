package net.minecraft.block.material;

public class MaterialTransparent
  extends Material
{
  public boolean blocksMovement()
  {
    return lIlIlllIlll[0];
  }
  
  public MaterialTransparent(MapColor lllllllllllllllllIIIIIIIIIIIIIIl)
  {
    lllllllllllllllllIIIIIIIIIIIIIlI.<init>(lllllllllllllllllIIIIIIIIIIIIIIl);
    "".length();
  }
  
  private static void lIIIIlllIlIlI()
  {
    lIlIlllIlll = new int[1];
    lIlIlllIlll[0] = ((0xF6 ^ 0xBD) & (0x79 ^ 0x32 ^ 0xFFFFFFFF));
  }
  
  public boolean blocksLight()
  {
    return lIlIlllIlll[0];
  }
  
  static {}
  
  public boolean isSolid()
  {
    return lIlIlllIlll[0];
  }
}

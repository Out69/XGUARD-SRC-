package net.minecraft.block.material;

public class MaterialPortal
  extends Material
{
  public boolean blocksLight()
  {
    return lIIIIlllIIIII[0];
  }
  
  static {}
  
  public boolean isSolid()
  {
    return lIIIIlllIIIII[0];
  }
  
  private static void llIIlllIIlllIl()
  {
    lIIIIlllIIIII = new int[1];
    lIIIIlllIIIII[0] = ((0x10 ^ 0x28 ^ 0xFE ^ 0x8F) & (0xDC ^ 0xAA ^ 0x14 ^ 0x2B ^ -" ".length()));
  }
  
  public MaterialPortal(MapColor llllllllllllllIlIlIIlllIllIllIIl)
  {
    llllllllllllllIlIlIIlllIllIllIlI.<init>(llllllllllllllIlIlIIlllIllIllIIl);
  }
  
  public boolean blocksMovement()
  {
    return lIIIIlllIIIII[0];
  }
}

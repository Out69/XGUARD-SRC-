package net.minecraft.block.material;

public class Material
{
  public Material setReplaceable()
  {
    ;
    replaceable = lIIlIlIlIIIl[0];
    return lllllllllllllllIllIIlIIIlllllIII;
  }
  
  public boolean isToolNotRequired()
  {
    ;
    return requiresNoTool;
  }
  
  public Material(MapColor lllllllllllllllIllIIlIIlIIlIIllI)
  {
    materialMapColor = lllllllllllllllIllIIlIIlIIlIIllI;
  }
  
  private Material setTranslucent()
  {
    ;
    isTranslucent = lIIlIlIlIIIl[0];
    return lllllllllllllllIllIIlIIlIIIIllIl;
  }
  
  private static boolean lllIIllIIIlIl(int ???)
  {
    String lllllllllllllllIllIIlIIIllIIlIII;
    return ??? != 0;
  }
  
  protected Material setAdventureModeExempt()
  {
    ;
    isAdventureModeExempt = lIIlIlIlIIIl[0];
    return lllllllllllllllIllIIlIIIllIIlllI;
  }
  
  static
  {
    lllIIllIIIlII();
    air = new MaterialTransparent(MapColor.airColor);
    grass = new Material(MapColor.grassColor);
    ground = new Material(MapColor.dirtColor);
    wood = new Material(MapColor.woodColor).setBurning();
    rock = new Material(MapColor.stoneColor).setRequiresTool();
    iron = new Material(MapColor.ironColor).setRequiresTool();
    anvil = new Material(MapColor.ironColor).setRequiresTool().setImmovableMobility();
    water = new MaterialLiquid(MapColor.waterColor).setNoPushMobility();
    lava = new MaterialLiquid(MapColor.tntColor).setNoPushMobility();
    leaves = new Material(MapColor.foliageColor).setBurning().setTranslucent().setNoPushMobility();
    plants = new MaterialLogic(MapColor.foliageColor).setNoPushMobility();
    vine = new MaterialLogic(MapColor.foliageColor).setBurning().setNoPushMobility().setReplaceable();
    sponge = new Material(MapColor.yellowColor);
    cloth = new Material(MapColor.clothColor).setBurning();
    fire = new MaterialTransparent(MapColor.airColor).setNoPushMobility();
    sand = new Material(MapColor.sandColor);
    circuits = new MaterialLogic(MapColor.airColor).setNoPushMobility();
    carpet = new MaterialLogic(MapColor.clothColor).setBurning();
    glass = new Material(MapColor.airColor).setTranslucent().setAdventureModeExempt();
    redstoneLight = new Material(MapColor.airColor).setAdventureModeExempt();
    tnt = new Material(MapColor.tntColor).setBurning().setTranslucent();
    coral = new Material(MapColor.foliageColor).setNoPushMobility();
    ice = new Material(MapColor.iceColor).setTranslucent().setAdventureModeExempt();
    packedIce = new Material(MapColor.iceColor).setAdventureModeExempt();
    snow = new MaterialLogic(MapColor.snowColor).setReplaceable().setTranslucent().setRequiresTool().setNoPushMobility();
    craftedSnow = new Material(MapColor.snowColor).setRequiresTool();
    cactus = new Material(MapColor.foliageColor).setTranslucent().setNoPushMobility();
    clay = new Material(MapColor.clayColor);
    gourd = new Material(MapColor.foliageColor).setNoPushMobility();
    dragonEgg = new Material(MapColor.foliageColor).setNoPushMobility();
    portal = new MaterialPortal(MapColor.airColor).setImmovableMobility();
    cake = new Material(MapColor.airColor).setNoPushMobility();
    web = new Material(MapColor.clothColor)
    {
      public boolean blocksMovement()
      {
        return lIlIIlIlIlII[0];
      }
      
      static {}
      
      private static void llllllllIllIl()
      {
        lIlIIlIlIlII = new int[1];
        lIlIIlIlIlII[0] = ((0x4B ^ 0x5A ^ 0x6D ^ 0x45) & (0xCA ^ 0xB9 ^ 0xF7 ^ 0xBD ^ -" ".length()));
      }
    }.setRequiresTool().setNoPushMobility();
    piston = new Material(MapColor.stoneColor).setImmovableMobility();
  }
  
  protected Material setBurning()
  {
    ;
    canBurn = lIIlIlIlIIIl[0];
    return lllllllllllllllIllIIlIIlIIIIIIIl;
  }
  
  protected Material setNoPushMobility()
  {
    ;
    mobilityFlag = lIIlIlIlIIIl[0];
    return lllllllllllllllIllIIlIIIllIllIlI;
  }
  
  public boolean isOpaque()
  {
    ;
    if (lllIIllIIIlIl(isTranslucent))
    {
      "".length();
      if (null == null) {
        break label46;
      }
      return (0x7A ^ 0x55) & (0x94 ^ 0xBB ^ 0xFFFFFFFF);
    }
    label46:
    return lllllllllllllllIllIIlIIIlllIlIII.blocksMovement();
  }
  
  private static void lllIIllIIIlII()
  {
    lIIlIlIlIIIl = new int[3];
    lIIlIlIlIIIl[0] = " ".length();
    lIIlIlIlIIIl[1] = ((0x4C ^ 0x49 ^ 0x2E ^ 0x61) & (0x22 ^ 0x1E ^ 0xC7 ^ 0xB1 ^ -" ".length()));
    lIIlIlIlIIIl[2] = "  ".length();
  }
  
  public boolean isLiquid()
  {
    return lIIlIlIlIIIl[1];
  }
  
  protected Material setImmovableMobility()
  {
    ;
    mobilityFlag = lIIlIlIlIIIl[2];
    return lllllllllllllllIllIIlIIIllIlIIIl;
  }
  
  public boolean isReplaceable()
  {
    ;
    return replaceable;
  }
  
  protected Material setRequiresTool()
  {
    ;
    requiresNoTool = lIIlIlIlIIIl[1];
    return lllllllllllllllIllIIlIIlIIIIIllI;
  }
  
  public int getMaterialMobility()
  {
    ;
    return mobilityFlag;
  }
  
  public MapColor getMaterialMapColor()
  {
    ;
    return materialMapColor;
  }
  
  public boolean getCanBurn()
  {
    ;
    return canBurn;
  }
  
  public boolean isSolid()
  {
    return lIIlIlIlIIIl[0];
  }
  
  public boolean blocksMovement()
  {
    return lIIlIlIlIIIl[0];
  }
  
  public boolean blocksLight()
  {
    return lIIlIlIlIIIl[0];
  }
}

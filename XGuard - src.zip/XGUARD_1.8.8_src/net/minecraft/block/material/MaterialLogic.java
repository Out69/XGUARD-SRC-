package net.minecraft.block.material;

public class MaterialLogic
  extends Material
{
  public MaterialLogic(MapColor lIlllIIlIIllIl)
  {
    lIlllIIlIIlllI.<init>(lIlllIIlIIllIl);
    "".length();
  }
  
  static {}
  
  private static void lIlIlIlIlll()
  {
    llIIlIlll = new int[1];
    llIIlIlll[0] = ((0x7D ^ 0x30) & (0x17 ^ 0x5A ^ 0xFFFFFFFF));
  }
  
  public boolean isSolid()
  {
    return llIIlIlll[0];
  }
  
  public boolean blocksMovement()
  {
    return llIIlIlll[0];
  }
  
  public boolean blocksLight()
  {
    return llIIlIlll[0];
  }
}

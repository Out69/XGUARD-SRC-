package net.minecraft.block.material;

public class MaterialLiquid
  extends Material
{
  private static void llIlllIIIIlllI()
  {
    lIIlIIIIlIlIl = new int[2];
    lIIlIIIIlIlIl[0] = " ".length();
    lIIlIIIIlIlIl[1] = ((96 + 16 - 51 + 112 ^ 49 + '' - 174 + 130) & (0x2A ^ 0x47 ^ 0x5B ^ 0x5 ^ -" ".length()));
  }
  
  public MaterialLiquid(MapColor llllllllllllllIlIIIlIllllllIIIIl)
  {
    llllllllllllllIlIIIlIllllllIIIlI.<init>(llllllllllllllIlIIIlIllllllIIIIl);
    "".length();
    "".length();
  }
  
  public boolean isLiquid()
  {
    return lIIlIIIIlIlIl[0];
  }
  
  static {}
  
  public boolean blocksMovement()
  {
    return lIIlIIIIlIlIl[1];
  }
  
  public boolean isSolid()
  {
    return lIIlIIIIlIlIl[1];
  }
}

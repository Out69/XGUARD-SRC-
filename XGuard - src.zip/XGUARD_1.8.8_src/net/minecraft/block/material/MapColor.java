package net.minecraft.block.material;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class MapColor
{
  public int func_151643_b(int lllllllllllllllllIIlllIIIIlIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllllIIlllIIIIlIllll = lIIlIlllllI[73];
    if (lllIllllllIl(lllllllllllllllllIIlllIIIIlIlIlI, lIIlIlllllI[6])) {
      lllllllllllllllllIIlllIIIIlIllll = lIIlIlllllI[74];
    }
    if (lllIllllllIl(lllllllllllllllllIIlllIIIIlIlIlI, lIIlIlllllI[4])) {
      lllllllllllllllllIIlllIIIIlIllll = lIIlIlllllI[75];
    }
    if (lllIllllllIl(lllllllllllllllllIIlllIIIIlIlIlI, lIIlIlllllI[2])) {
      lllllllllllllllllIIlllIIIIlIllll = lIIlIlllllI[73];
    }
    if (lllIlllllllI(lllllllllllllllllIIlllIIIIlIlIlI)) {
      lllllllllllllllllIIlllIIIIlIllll = lIIlIlllllI[76];
    }
    int lllllllllllllllllIIlllIIIIlIlllI = (colorValue >> lIIlIlllllI[32] & lIIlIlllllI[75]) * lllllllllllllllllIIlllIIIIlIllll / lIIlIlllllI[75];
    int lllllllllllllllllIIlllIIIIlIllIl = (colorValue >> lIIlIlllllI[16] & lIIlIlllllI[75]) * lllllllllllllllllIIlllIIIIlIllll / lIIlIlllllI[75];
    int lllllllllllllllllIIlllIIIIlIllII = (colorValue & lIIlIlllllI[75]) * lllllllllllllllllIIlllIIIIlIllll / lIIlIlllllI[75];
    return lIIlIlllllI[77] | lllllllllllllllllIIlllIIIIlIlllI << lIIlIlllllI[32] | lllllllllllllllllIIlllIIIIlIllIl << lIIlIlllllI[16] | lllllllllllllllllIIlllIIIIlIllII;
  }
  
  private static boolean lllIlllllllI(int ???)
  {
    double lllllllllllllllllIIlllIIIIIIllll;
    return ??? == 0;
  }
  
  private static void lllIlllllIIl()
  {
    lIIlIllllIl = new String[lIIlIlllllI[2]];
    lIIlIllllIl[lIIlIlllllI[1]] = lllIllllIIll("gzR9DiECUAr3XB612ukvBoJapYtysPkQywajwCWUiiGX3Rh9grSXo4sEszSBYPZAJHcNh4wwlJI=", "fQEvU");
  }
  
  private static boolean lllIllllllIl(int ???, int arg1)
  {
    int i;
    int lllllllllllllllllIIlllIIIIIlIlIl;
    return ??? == i;
  }
  
  private static void lllIlllllIlI()
  {
    lIIlIlllllI = new int[78];
    lIIlIlllllI[0] = (0x31 ^ 0x71);
    lIIlIlllllI[1] = ((0x8A ^ 0xB0 ^ 0x97 ^ 0x8D) & (0x61 ^ 0x3C ^ 0x42 ^ 0x3F ^ -" ".length()));
    lIIlIlllllI[2] = " ".length();
    lIIlIlllllI[3] = (0xF63C & 0x7FBBFB);
    lIIlIlllllI[4] = "  ".length();
    lIIlIlllllI[5] = (-(0xF77F & 0x1AC5) & 0xFFFFFFEF & 0xF7FBF7);
    lIIlIlllllI[6] = "   ".length();
    lIIlIlllllI[7] = (-(0xB15F & 0x7EB9) & 0xFFFFFFDF & 0xC7F7FF);
    lIIlIlllllI[8] = (0x41 ^ 0x45);
    lIIlIlllllI[9] = (0x887C & 0xFF7783);
    lIIlIlllllI[10] = (0x52 ^ 0x57);
    lIIlIlllllI[11] = (-(0xD9F7 & 0x2F09) & 0xFBFF & 0xA0ADFF);
    lIIlIlllllI[12] = (0x9A ^ 0xA9 ^ 0xA8 ^ 0x9D);
    lIIlIlllllI[13] = (0xEFBF & 0xA7B7E7);
    lIIlIlllllI[14] = (0x49 ^ 0x59 ^ 0x84 ^ 0x93);
    lIIlIlllllI[15] = (0xFCFC & 0x7F03);
    lIIlIlllllI[16] = ('' + '' - 155 + 18 ^ 77 + '' - 179 + 105);
    lIIlIlllllI[17] = (0xFFFFFFFF & 0xFFFFFF);
    lIIlIlllllI[18] = (26 + 30 - 55 + 178 ^ 62 + '' - 162 + 154);
    lIIlIlllllI[19] = (0xFEBE & 0xA4A9F9);
    lIIlIlllllI[20] = (47 + 49 - -31 + 15 ^ 51 + 40 - 90 + 131);
    lIIlIlllllI[21] = (-(123 + 68 - 93 + 81) & 0xEFFF & 0x977DFF);
    lIIlIlllllI[22] = (0x7B ^ 0x70);
    lIIlIlllllI[23] = (-(0xDD2F & 0x2FDB) & 0xFF7F & 0x707DFA);
    lIIlIlllllI[24] = (0x75 ^ 0x79);
    lIIlIlllllI[25] = (-(0xF50F & 0x3FF1) & 0xF7FF & 0x407DFF);
    lIIlIlllllI[26] = (0xF0 ^ 0x85 ^ 0x42 ^ 0x3A);
    lIIlIlllllI[27] = (-(0x43 ^ 0x46) & 0xF74C & 0x8F7FFF);
    lIIlIlllllI[28] = (0xB1 ^ 0x9F ^ 0x51 ^ 0x71);
    lIIlIlllllI[29] = (0xFEFD & 0xFFFDF7);
    lIIlIlllllI[30] = (0x93 ^ 0x9C);
    lIIlIlllllI[31] = (-(67 + '»' - 217 + 168) & 0xFFFFFFFF & 0xD87FFF);
    lIIlIlllllI[32] = (0x71 ^ 0x61);
    lIIlIlllllI[33] = (0xEFD8 & 0xB25CFF);
    lIIlIlllllI[34] = (0x8D ^ 0xB5 ^ 0x2D ^ 0x4);
    lIIlIlllllI[35] = (0x9DFB & 0x66FBDC);
    lIIlIlllllI[36] = (0x23 ^ 0x47 ^ 0xEE ^ 0x98);
    lIIlIlllllI[37] = (0xF7F3 & 0xE5ED3F);
    lIIlIlllllI[38] = (0x6A ^ 0x50 ^ 0x71 ^ 0x58);
    lIIlIlllllI[39] = (0xDD9F & 0x7FEE79);
    lIIlIlllllI[40] = (' ' + '' - 176 + 64 ^ 83 + '' - 84 + 43);
    lIIlIlllllI[41] = (-(0x1A ^ 0x53) & 0xFFFFFFFD & 0xF27FEF);
    lIIlIlllllI[42] = (0x96 ^ 0x83);
    lIIlIlllllI[43] = (-(0xB6DF & 0x69B3) & 0xEFFE & 0x4C7CDF);
    lIIlIlllllI[44] = (0x78 ^ 0x6E);
    lIIlIlllllI[45] = (0x9BF9 & 0x99FD9F);
    lIIlIlllllI[46] = (0x17 ^ 0x0);
    lIIlIlllllI[47] = (0xFFFFFFFB & 0x4C7F9D);
    lIIlIlllllI[48] = (0xD ^ 0x4B ^ 0x1A ^ 0x44);
    lIIlIlllllI[49] = (-(0xF70D & 0x48FF) & 0xFFFFFFFF & 0x7F7FBE);
    lIIlIlllllI[50] = (0xA5 ^ 0xC2 ^ 0xE9 ^ 0x97);
    lIIlIlllllI[51] = (0xEDBE & 0x335EF3);
    lIIlIlllllI[52] = (0x39 ^ 0x23);
    lIIlIlllllI[53] = (0xDD77 & 0x666EBB);
    lIIlIlllllI[54] = (0xB8 ^ 0xA3);
    lIIlIlllllI[55] = (0xFFFFFFBB & 0x667F77);
    lIIlIlllllI[56] = (0xAE ^ 0x83 ^ 0x42 ^ 0x73);
    lIIlIlllllI[57] = (-(0x5D ^ 0x18) & 0xFBFF & 0x993777);
    lIIlIlllllI[58] = (0x38 ^ 0x9 ^ 0x7D ^ 0x51);
    lIIlIlllllI[59] = (0x9BF9 & 0x197D1F);
    lIIlIlllllI[60] = (0x1A ^ 0x4);
    lIIlIlllllI[61] = (0xFFFFFFDD & 0xFAEE6F);
    lIIlIlllllI[62] = (0xDE ^ 0xC1);
    lIIlIlllllI[63] = (0xFFFFFFD5 & 0x5CDBFF);
    lIIlIlllllI[64] = (0x9F ^ 0xBF);
    lIIlIlllllI[65] = (0xC1FF & 0x4ABEFF);
    lIIlIlllllI[66] = (0x44 ^ 0x65);
    lIIlIlllllI[67] = (-(0xBFF6 & 0x60CF) & 0xFDFF & 0xFBFF);
    lIIlIlllllI[68] = (0x6D ^ 0x4F);
    lIIlIlllllI[69] = (-(0xAFFD & 0x7087) & 0xF6BF & 0x817FF5);
    lIIlIlllllI[70] = (29 + 53 - 81 + 138 ^ 125 + '' - 248 + 145);
    lIIlIlllllI[71] = (0xC623 & 0x703BDC);
    lIIlIlllllI[72] = (0x27 ^ 0x18);
    lIIlIlllllI[73] = ((0x1C ^ 0x57) + (43 + 36 - 27 + 135) - (28 + 13 - -18 + 174) + (38 + 77 - 43 + 119));
    lIIlIlllllI[74] = (63 + '' - 143 + 85);
    lIIlIlllllI[75] = (57 + 73 - 50 + 168 + (0x59 ^ 0x5E) - (0x22 ^ 0xF) + (0x37 ^ 0x1A));
    lIIlIlllllI[76] = (126 + 113 - 80 + 21);
    lIIlIlllllI[77] = (-(0xAD52 & 0x10052AD));
  }
  
  private static String lllIllllIIll(String lllllllllllllllllIIlllIIIIIllllI, String lllllllllllllllllIIlllIIIIIllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIlllIIIIlIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIlllIIIIIllIll.getBytes(StandardCharsets.UTF_8)), lIIlIlllllI[16]), "DES");
      Cipher lllllllllllllllllIIlllIIIIlIIIII = Cipher.getInstance("DES");
      lllllllllllllllllIIlllIIIIlIIIII.init(lIIlIlllllI[4], lllllllllllllllllIIlllIIIIlIIIIl);
      return new String(lllllllllllllllllIIlllIIIIlIIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIlllIIIIIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIlllIIIIIlllll)
    {
      lllllllllllllllllIIlllIIIIIlllll.printStackTrace();
    }
    return null;
  }
  
  private MapColor(int lllllllllllllllllIIlllIIIIlllIIl, int lllllllllllllllllIIlllIIIIlllIII)
  {
    if ((lllIlllllIll(lllllllllllllllllIIlllIIIIllllII)) && (lllIllllllII(lllllllllllllllllIIlllIIIIllllII, lIIlIlllllI[72])))
    {
      colorIndex = lllllllllllllllllIIlllIIIIllllII;
      colorValue = lllllllllllllllllIIlllIIIIlllIII;
      mapColorArray[lllllllllllllllllIIlllIIIIllllII] = lllllllllllllllllIIlllIIIIllllIl;
      "".length();
      if ("  ".length() <= 0) {
        throw null;
      }
    }
    else
    {
      throw new IndexOutOfBoundsException(lIIlIllllIl[lIIlIlllllI[1]]);
    }
  }
  
  private static boolean lllIllllllII(int ???, int arg1)
  {
    int i;
    int lllllllllllllllllIIlllIIIIIlIIIl;
    return ??? <= i;
  }
  
  static
  {
    lllIlllllIlI();
    lllIlllllIIl();
    mapColorArray = new MapColor[lIIlIlllllI[0]];
    airColor = new MapColor(lIIlIlllllI[1], lIIlIlllllI[1]);
    grassColor = new MapColor(lIIlIlllllI[2], lIIlIlllllI[3]);
    sandColor = new MapColor(lIIlIlllllI[4], lIIlIlllllI[5]);
    clothColor = new MapColor(lIIlIlllllI[6], lIIlIlllllI[7]);
    tntColor = new MapColor(lIIlIlllllI[8], lIIlIlllllI[9]);
    iceColor = new MapColor(lIIlIlllllI[10], lIIlIlllllI[11]);
    ironColor = new MapColor(lIIlIlllllI[12], lIIlIlllllI[13]);
    foliageColor = new MapColor(lIIlIlllllI[14], lIIlIlllllI[15]);
    snowColor = new MapColor(lIIlIlllllI[16], lIIlIlllllI[17]);
    clayColor = new MapColor(lIIlIlllllI[18], lIIlIlllllI[19]);
    dirtColor = new MapColor(lIIlIlllllI[20], lIIlIlllllI[21]);
    stoneColor = new MapColor(lIIlIlllllI[22], lIIlIlllllI[23]);
    waterColor = new MapColor(lIIlIlllllI[24], lIIlIlllllI[25]);
    woodColor = new MapColor(lIIlIlllllI[26], lIIlIlllllI[27]);
    quartzColor = new MapColor(lIIlIlllllI[28], lIIlIlllllI[29]);
    adobeColor = new MapColor(lIIlIlllllI[30], lIIlIlllllI[31]);
    magentaColor = new MapColor(lIIlIlllllI[32], lIIlIlllllI[33]);
    lightBlueColor = new MapColor(lIIlIlllllI[34], lIIlIlllllI[35]);
    yellowColor = new MapColor(lIIlIlllllI[36], lIIlIlllllI[37]);
    limeColor = new MapColor(lIIlIlllllI[38], lIIlIlllllI[39]);
    pinkColor = new MapColor(lIIlIlllllI[40], lIIlIlllllI[41]);
    grayColor = new MapColor(lIIlIlllllI[42], lIIlIlllllI[43]);
    silverColor = new MapColor(lIIlIlllllI[44], lIIlIlllllI[45]);
    cyanColor = new MapColor(lIIlIlllllI[46], lIIlIlllllI[47]);
    purpleColor = new MapColor(lIIlIlllllI[48], lIIlIlllllI[49]);
    blueColor = new MapColor(lIIlIlllllI[50], lIIlIlllllI[51]);
    brownColor = new MapColor(lIIlIlllllI[52], lIIlIlllllI[53]);
    greenColor = new MapColor(lIIlIlllllI[54], lIIlIlllllI[55]);
    redColor = new MapColor(lIIlIlllllI[56], lIIlIlllllI[57]);
    blackColor = new MapColor(lIIlIlllllI[58], lIIlIlllllI[59]);
    goldColor = new MapColor(lIIlIlllllI[60], lIIlIlllllI[61]);
    diamondColor = new MapColor(lIIlIlllllI[62], lIIlIlllllI[63]);
    lapisColor = new MapColor(lIIlIlllllI[64], lIIlIlllllI[65]);
    emeraldColor = new MapColor(lIIlIlllllI[66], lIIlIlllllI[67]);
    obsidianColor = new MapColor(lIIlIlllllI[68], lIIlIlllllI[69]);
  }
  
  private static boolean lllIlllllIll(int ???)
  {
    boolean lllllllllllllllllIIlllIIIIIIllIl;
    return ??? >= 0;
  }
}

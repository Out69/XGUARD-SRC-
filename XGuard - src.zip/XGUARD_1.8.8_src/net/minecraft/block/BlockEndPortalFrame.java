package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.world.World;

public class BlockEndPortalFrame
  extends Block
{
  static
  {
    lIIllIlllIllIl();
    lIIllIlllIIllI();
    FACING = PropertyDirection.create(llIIlIlllIIl[llIIlIlllllI[0]], EnumFacing.Plane.HORIZONTAL);
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllIIIlIIllIlllIllII, Random lllllllllllllllIIIlIIllIlllIlIll, int lllllllllllllllIIIlIIllIlllIlIlI)
  {
    return null;
  }
  
  public int getComparatorInputOverride(World lllllllllllllllIIIlIIllIllIllIII, BlockPos lllllllllllllllIIIlIIllIllIlIlIl)
  {
    ;
    ;
    if (lIIllIlllIlllI(((Boolean)lllllllllllllllIIIlIIllIllIllIII.getBlockState(lllllllllllllllIIIlIIllIllIlIlIl).getValue(EYE)).booleanValue()))
    {
      "".length();
      if (null == null) {
        break label80;
      }
      return (0x40 ^ 0x10 ^ 0x79 ^ 0x1F) & (0xC3 ^ 0x82 ^ 0xB3 ^ 0xC4 ^ -" ".length());
    }
    label80:
    return llIIlIlllllI[0];
  }
  
  private static void lIIllIlllIIllI()
  {
    llIIlIlllIIl = new String[llIIlIlllllI[5]];
    llIIlIlllIIl[llIIlIlllllI[0]] = lIIllIlllIIlII("LWsHdANZjoE=", "JrjQp");
    llIIlIlllIIl[llIIlIlllllI[1]] = lIIllIlllIIlIl("KHmRKLdEVMw=", "OppQy");
  }
  
  private static String lIIllIlllIIlIl(String lllllllllllllllIIIlIIllIlIlIlllI, String lllllllllllllllIIIlIIllIlIlIllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIIlIIllIlIllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIlIIllIlIlIllll.getBytes(StandardCharsets.UTF_8)), llIIlIlllllI[6]), "DES");
      Cipher lllllllllllllllIIIlIIllIlIllIIlI = Cipher.getInstance("DES");
      lllllllllllllllIIIlIIllIlIllIIlI.init(llIIlIlllllI[5], lllllllllllllllIIIlIIllIlIllIIll);
      return new String(lllllllllllllllIIIlIIllIlIllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIlIIllIlIlIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIIlIIllIlIllIIIl)
    {
      lllllllllllllllIIIlIIllIlIllIIIl.printStackTrace();
    }
    return null;
  }
  
  private static String lIIllIlllIIlII(String lllllllllllllllIIIlIIllIlIlllIll, String lllllllllllllllIIIlIIllIlIlllIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIIlIIllIllIIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIlIIllIlIlllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIIlIIllIlIllllll = Cipher.getInstance("Blowfish");
      lllllllllllllllIIIlIIllIlIllllll.init(llIIlIlllllI[5], lllllllllllllllIIIlIIllIllIIIIII);
      return new String(lllllllllllllllIIIlIIllIlIllllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIlIIllIlIlllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIIlIIllIlIlllllI)
    {
      lllllllllllllllIIIlIIllIlIlllllI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIllIlllIlllI(int ???)
  {
    Exception lllllllllllllllIIIlIIllIlIlIlIIl;
    return ??? != 0;
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIIIlIIllIllIIlIIl)
  {
    ;
    ;
    int lllllllllllllllIIIlIIllIllIIlIlI = llIIlIlllllI[0];
    lllllllllllllllIIIlIIllIllIIlIlI |= ((EnumFacing)lllllllllllllllIIIlIIllIllIIlIll.getValue(FACING)).getHorizontalIndex();
    if (lIIllIlllIlllI(((Boolean)lllllllllllllllIIIlIIllIllIIlIll.getValue(EYE)).booleanValue())) {
      lllllllllllllllIIIlIIllIllIIlIlI |= llIIlIlllllI[3];
    }
    return lllllllllllllllIIIlIIllIllIIlIlI;
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIIIlIIllIllIIllll)
  {
    ;
    ;
    if (lIIllIlllIlllI(lllllllllllllllIIIlIIllIllIIllll & llIIlIlllllI[3]))
    {
      "".length();
      if (-" ".length() <= ((0x11 ^ 0x22) & (0xA1 ^ 0x92 ^ 0xFFFFFFFF))) {
        break label62;
      }
      return null;
    }
    label62:
    return EYE.withProperty(llIIlIlllllI[1], Boolean.valueOf(llIIlIlllllI[0])).withProperty(FACING, EnumFacing.getHorizontal(lllllllllllllllIIIlIIllIllIIllll & llIIlIlllllI[4]));
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    lllllllllllllllIIIlIIlllIIIIIIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.8125F, 1.0F);
  }
  
  public boolean isOpaqueCube()
  {
    return llIIlIlllllI[0];
  }
  
  public IBlockState onBlockPlaced(World lllllllllllllllIIIlIIllIlllIIllI, BlockPos lllllllllllllllIIIlIIllIlllIIlIl, EnumFacing lllllllllllllllIIIlIIllIlllIIlII, float lllllllllllllllIIIlIIllIlllIIIll, float lllllllllllllllIIIlIIllIlllIIIlI, float lllllllllllllllIIIlIIllIlllIIIIl, int lllllllllllllllIIIlIIllIlllIIIII, EntityLivingBase lllllllllllllllIIIlIIllIllIlllll)
  {
    ;
    ;
    return lllllllllllllllIIIlIIllIlllIIlll.getDefaultState().withProperty(FACING, lllllllllllllllIIIlIIllIllIlllll.getHorizontalFacing().getOpposite()).withProperty(EYE, Boolean.valueOf(llIIlIlllllI[0]));
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIIIlIIllIllIIIllI, new IProperty[] { FACING, EYE });
  }
  
  public void addCollisionBoxesToList(World lllllllllllllllIIIlIIllIlllllIlI, BlockPos lllllllllllllllIIIlIIllIllllIIlI, IBlockState lllllllllllllllIIIlIIllIlllllIII, AxisAlignedBB lllllllllllllllIIIlIIllIllllIlll, List<AxisAlignedBB> lllllllllllllllIIIlIIllIlllIllll, Entity lllllllllllllllIIIlIIllIlllIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIlIIllIllllIlII.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.8125F, 1.0F);
    lllllllllllllllIIIlIIllIllllIlII.addCollisionBoxesToList(lllllllllllllllIIIlIIllIlllllIlI, lllllllllllllllIIIlIIllIllllIIlI, lllllllllllllllIIIlIIllIllllIIIl, lllllllllllllllIIIlIIllIllllIlll, lllllllllllllllIIIlIIllIlllIllll, lllllllllllllllIIIlIIllIlllIlllI);
    if (lIIllIlllIlllI(((Boolean)lllllllllllllllIIIlIIllIlllllIlI.getBlockState(lllllllllllllllIIIlIIllIllllIIlI).getValue(EYE)).booleanValue()))
    {
      lllllllllllllllIIIlIIllIllllIlII.setBlockBounds(0.3125F, 0.8125F, 0.3125F, 0.6875F, 1.0F, 0.6875F);
      lllllllllllllllIIIlIIllIllllIlII.addCollisionBoxesToList(lllllllllllllllIIIlIIllIlllllIlI, lllllllllllllllIIIlIIllIllllIIlI, lllllllllllllllIIIlIIllIllllIIIl, lllllllllllllllIIIlIIllIllllIlll, lllllllllllllllIIIlIIllIlllIllll, lllllllllllllllIIIlIIllIlllIlllI);
    }
    lllllllllllllllIIIlIIllIllllIlII.setBlockBoundsForItemRender();
  }
  
  public BlockEndPortalFrame()
  {
    lllllllllllllllIIIlIIlllIIIIIlll.<init>(Material.rock, MapColor.greenColor);
    lllllllllllllllIIIlIIlllIIIIlIII.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(EYE, Boolean.valueOf(llIIlIlllllI[0])));
  }
  
  public boolean hasComparatorInputOverride()
  {
    return llIIlIlllllI[1];
  }
  
  private static void lIIllIlllIllIl()
  {
    llIIlIlllllI = new int[7];
    llIIlIlllllI[0] = ((0x46 ^ 0x4C) & (0x9B ^ 0x91 ^ 0xFFFFFFFF));
    llIIlIlllllI[1] = " ".length();
    llIIlIlllllI[2] = (0xC9 ^ 0xC6);
    llIIlIlllllI[3] = (0x90 ^ 0x94);
    llIIlIlllllI[4] = "   ".length();
    llIIlIlllllI[5] = "  ".length();
    llIIlIlllllI[6] = (0xA1 ^ 0xA9);
  }
}

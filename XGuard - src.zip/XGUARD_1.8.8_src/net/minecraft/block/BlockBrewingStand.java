package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBrewingStand;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;

public class BlockBrewingStand
  extends BlockContainer
{
  private static boolean lIIllIIllllIlI(int ???)
  {
    char lllllllllllllllIIIlIllIIIIlIllll;
    return ??? != 0;
  }
  
  static
  {
    lIIllIIllllIII();
    lIIllIIlllIlIl();
  }
  
  public void randomDisplayTick(World lllllllllllllllIIIlIllIIlIIllIll, BlockPos lllllllllllllllIIIlIllIIlIIllIlI, IBlockState lllllllllllllllIIIlIllIIlIlIIIII, Random lllllllllllllllIIIlIllIIlIIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    double lllllllllllllllIIIlIllIIlIIllllI = lllllllllllllllIIIlIllIIlIIllIlI.getX() + 0.4F + lllllllllllllllIIIlIllIIlIIllIIl.nextFloat() * 0.2F;
    double lllllllllllllllIIIlIllIIlIIlllIl = lllllllllllllllIIIlIllIIlIIllIlI.getY() + 0.7F + lllllllllllllllIIIlIllIIlIIllIIl.nextFloat() * 0.3F;
    double lllllllllllllllIIIlIllIIlIIlllII = lllllllllllllllIIIlIllIIlIIllIlI.getZ() + 0.4F + lllllllllllllllIIIlIllIIlIIllIIl.nextFloat() * 0.2F;
    lllllllllllllllIIIlIllIIlIIllIll.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, lllllllllllllllIIIlIllIIlIIllllI, lllllllllllllllIIIlIllIIlIIlllIl, lllllllllllllllIIIlIllIIlIIlllII, 0.0D, 0.0D, 0.0D, new int[llIIlIIlIIIl[1]]);
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllIIIlIllIIlIIIIlIl, Random lllllllllllllllIIIlIllIIlIIIIlII, int lllllllllllllllIIIlIllIIlIIIIIll)
  {
    return Items.brewing_stand;
  }
  
  private static boolean lIIllIIlllllIl(int ???)
  {
    char lllllllllllllllIIIlIllIIIIlIllIl;
    return ??? > 0;
  }
  
  public int getRenderType()
  {
    return llIIlIIlIIIl[0];
  }
  
  public boolean onBlockActivated(World lllllllllllllllIIIlIllIIlIllllII, BlockPos lllllllllllllllIIIlIllIIlIlllIll, IBlockState lllllllllllllllIIIlIllIIllIIIIll, EntityPlayer lllllllllllllllIIIlIllIIllIIIIlI, EnumFacing lllllllllllllllIIIlIllIIllIIIIIl, float lllllllllllllllIIIlIllIIllIIIIII, float lllllllllllllllIIIlIllIIlIllllll, float lllllllllllllllIIIlIllIIlIlllllI)
  {
    ;
    ;
    ;
    ;
    if (lIIllIIllllIlI(isRemote)) {
      return llIIlIIlIIIl[2];
    }
    TileEntity lllllllllllllllIIIlIllIIlIllllIl = lllllllllllllllIIIlIllIIlIllllII.getTileEntity(lllllllllllllllIIIlIllIIlIlllIll);
    if (lIIllIIllllIlI(lllllllllllllllIIIlIllIIlIllllIl instanceof TileEntityBrewingStand))
    {
      lllllllllllllllIIIlIllIIllIIIIlI.displayGUIChest((TileEntityBrewingStand)lllllllllllllllIIIlIllIIlIllllIl);
      lllllllllllllllIIIlIllIIllIIIIlI.triggerAchievement(StatList.field_181729_M);
    }
    return llIIlIIlIIIl[2];
  }
  
  private static void lIIllIIllllIII()
  {
    llIIlIIlIIIl = new int[5];
    llIIlIIlIIIl[0] = "   ".length();
    llIIlIIlIIIl[1] = ((0x56 ^ 0x49 ^ 0xAB ^ 0xB0) & ('¡' + '' - 219 + 98 ^ 71 + 'µ' - 173 + 117 ^ -" ".length()));
    llIIlIIlIIIl[2] = " ".length();
    llIIlIIlIIIl[3] = "  ".length();
    llIIlIIlIIIl[4] = (0x2F ^ 0x2B);
  }
  
  public boolean isOpaqueCube()
  {
    return llIIlIIlIIIl[1];
  }
  
  public boolean hasComparatorInputOverride()
  {
    return llIIlIIlIIIl[2];
  }
  
  private static String lIIllIIlllIIll(String lllllllllllllllIIIlIllIIIlIlIlII, String lllllllllllllllIIIlIllIIIlIlIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIIlIllIIIlIllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIlIllIIIlIlIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIIlIllIIIlIllIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIIIlIllIIIlIllIII.init(llIIlIIlIIIl[3], lllllllllllllllIIIlIllIIIlIllIIl);
      return new String(lllllllllllllllIIIlIllIIIlIllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIlIllIIIlIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIIlIllIIIlIlIlll)
    {
      lllllllllllllllIIIlIllIIIlIlIlll.printStackTrace();
    }
    return null;
  }
  
  public boolean isFullCube()
  {
    return llIIlIIlIIIl[1];
  }
  
  private static String lIIllIIlllIlII(String lllllllllllllllIIIlIllIIIlIIIIIl, String lllllllllllllllIIIlIllIIIlIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIlIllIIIlIIIIIl = new String(Base64.getDecoder().decode(lllllllllllllllIIIlIllIIIlIIIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIIlIllIIIlIIIlII = new StringBuilder();
    char[] lllllllllllllllIIIlIllIIIlIIIIll = lllllllllllllllIIIlIllIIIlIIIIII.toCharArray();
    int lllllllllllllllIIIlIllIIIlIIIIlI = llIIlIIlIIIl[1];
    float lllllllllllllllIIIlIllIIIIllllII = lllllllllllllllIIIlIllIIIlIIIIIl.toCharArray();
    int lllllllllllllllIIIlIllIIIIlllIll = lllllllllllllllIIIlIllIIIIllllII.length;
    byte lllllllllllllllIIIlIllIIIIlllIlI = llIIlIIlIIIl[1];
    while (lIIllIIlllllll(lllllllllllllllIIIlIllIIIIlllIlI, lllllllllllllllIIIlIllIIIIlllIll))
    {
      char lllllllllllllllIIIlIllIIIlIIIlll = lllllllllllllllIIIlIllIIIIllllII[lllllllllllllllIIIlIllIIIIlllIlI];
      "".length();
      "".length();
      if (-"   ".length() >= 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIIlIllIIIlIIIlII);
  }
  
  public Item getItem(World lllllllllllllllIIIlIllIIlIIIIIIl, BlockPos lllllllllllllllIIIlIllIIlIIIIIII)
  {
    return Items.brewing_stand;
  }
  
  public void breakBlock(World lllllllllllllllIIIlIllIIlIIIllll, BlockPos lllllllllllllllIIIlIllIIlIIIlllI, IBlockState lllllllllllllllIIIlIllIIlIIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    TileEntity lllllllllllllllIIIlIllIIlIIIllII = lllllllllllllllIIIlIllIIlIIIllll.getTileEntity(lllllllllllllllIIIlIllIIlIIIlllI);
    if (lIIllIIllllIlI(lllllllllllllllIIIlIllIIlIIIllII instanceof TileEntityBrewingStand)) {
      InventoryHelper.dropInventoryItems(lllllllllllllllIIIlIllIIlIIIllll, lllllllllllllllIIIlIllIIlIIIlllI, (TileEntityBrewingStand)lllllllllllllllIIIlIllIIlIIIllII);
    }
    lllllllllllllllIIIlIllIIlIIIlIll.breakBlock(lllllllllllllllIIIlIllIIlIIIllll, lllllllllllllllIIIlIllIIlIIIlllI, lllllllllllllllIIIlIllIIlIIIllIl);
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    lllllllllllllllIIIlIllIIllIIlIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIIIlIllIIIlIlllll, new IProperty[] { HAS_BOTTLE[llIIlIIlIIIl[1]], HAS_BOTTLE[llIIlIIlIIIl[2]], HAS_BOTTLE[llIIlIIlIIIl[3]] });
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIIIlIllIIIllIIllI)
  {
    ;
    ;
    ;
    int lllllllllllllllIIIlIllIIIllIIlIl = llIIlIIlIIIl[1];
    int lllllllllllllllIIIlIllIIIllIIlII = llIIlIIlIIIl[1];
    "".length();
    if (" ".length() > "   ".length()) {
      return (0x5D ^ 0x6A) & (0x9 ^ 0x3E ^ 0xFFFFFFFF);
    }
    while (!lIIllIIllllllI(lllllllllllllllIIIlIllIIIllIIlII, llIIlIIlIIIl[0]))
    {
      if (lIIllIIllllIlI(((Boolean)lllllllllllllllIIIlIllIIIllIIIll.getValue(HAS_BOTTLE[lllllllllllllllIIIlIllIIIllIIlII])).booleanValue())) {
        lllllllllllllllIIIlIllIIIllIIlIl |= llIIlIIlIIIl[2] << lllllllllllllllIIIlIllIIIllIIlII;
      }
      lllllllllllllllIIIlIllIIIllIIlII++;
    }
    return lllllllllllllllIIIlIllIIIllIIlIl;
  }
  
  public BlockBrewingStand()
  {
    lllllllllllllllIIIlIllIIlllIlIlI.<init>(Material.iron);
    lllllllllllllllIIIlIllIIlllIlIll.setDefaultState(blockState.getBaseState().withProperty(HAS_BOTTLE[llIIlIIlIIIl[1]], Boolean.valueOf(llIIlIIlIIIl[1])).withProperty(HAS_BOTTLE[llIIlIIlIIIl[2]], Boolean.valueOf(llIIlIIlIIIl[1])).withProperty(HAS_BOTTLE[llIIlIIlIIIl[3]], Boolean.valueOf(llIIlIIlIIIl[1])));
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIIIlIllIIIlllIIIl)
  {
    ;
    ;
    ;
    ;
    IBlockState lllllllllllllllIIIlIllIIIlllIIII = lllllllllllllllIIIlIllIIIllIlllI.getDefaultState();
    int lllllllllllllllIIIlIllIIIllIllll = llIIlIIlIIIl[1];
    "".length();
    if ((66 + 99 - 39 + 69 ^ 105 + '¶' - 119 + 31) <= " ".length()) {
      return null;
    }
    label101:
    while (!lIIllIIllllllI(lllllllllllllllIIIlIllIIIllIllll, llIIlIIlIIIl[0]))
    {
      if (lIIllIIlllllIl(lllllllllllllllIIIlIllIIIlllIIIl & llIIlIIlIIIl[2] << lllllllllllllllIIIlIllIIIllIllll))
      {
        "".length();
        if (-"  ".length() < 0) {
          break label101;
        }
        return null;
      }
      lllllllllllllllIIIlIllIIIlllIIII = HAS_BOTTLE[lllllllllllllllIIIlIllIIIllIllll].withProperty(llIIlIIlIIIl[2], Boolean.valueOf(llIIlIIlIIIl[1]));
    }
    return lllllllllllllllIIIlIllIIIlllIIII;
  }
  
  public int getComparatorInputOverride(World lllllllllllllllIIIlIllIIIllllIIl, BlockPos lllllllllllllllIIIlIllIIIllllIII)
  {
    ;
    ;
    return Container.calcRedstone(lllllllllllllllIIIlIllIIIllllIIl.getTileEntity(lllllllllllllllIIIlIllIIIllllIII));
  }
  
  private static boolean lIIllIIllllllI(int ???, int arg1)
  {
    int i;
    int lllllllllllllllIIIlIllIIIIllIlIl;
    return ??? >= i;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public void onBlockPlacedBy(World lllllllllllllllIIIlIllIIlIllIIll, BlockPos lllllllllllllllIIIlIllIIlIllIIlI, IBlockState lllllllllllllllIIIlIllIIlIllIIIl, EntityLivingBase lllllllllllllllIIIlIllIIlIllIIII, ItemStack lllllllllllllllIIIlIllIIlIlIllll)
  {
    ;
    ;
    ;
    ;
    if (lIIllIIllllIlI(lllllllllllllllIIIlIllIIlIlIllll.hasDisplayName()))
    {
      TileEntity lllllllllllllllIIIlIllIIlIlIlllI = lllllllllllllllIIIlIllIIlIllIIll.getTileEntity(lllllllllllllllIIIlIllIIlIllIIlI);
      if (lIIllIIllllIlI(lllllllllllllllIIIlIllIIlIlIlllI instanceof TileEntityBrewingStand)) {
        ((TileEntityBrewingStand)lllllllllllllllIIIlIllIIlIlIlllI).setName(lllllllllllllllIIIlIllIIlIlIllll.getDisplayName());
      }
    }
  }
  
  public String getLocalizedName()
  {
    return StatCollector.translateToLocal(llIIlIIIllll[llIIlIIlIIIl[0]]);
  }
  
  public TileEntity createNewTileEntity(World lllllllllllllllIIIlIllIIlllIIlIl, int lllllllllllllllIIIlIllIIlllIIlII)
  {
    return new TileEntityBrewingStand();
  }
  
  private static boolean lIIllIIlllllll(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIIIlIllIIIIllIIIl;
    return ??? < i;
  }
  
  private static void lIIllIIlllIlIl()
  {
    llIIlIIIllll = new String[llIIlIIlIIIl[4]];
    llIIlIIIllll[llIIlIIlIIIl[1]] = lIIllIIlllIIll("KnQrfyqBRNM9vlMx6xit2Q==", "fGBDX");
    llIIlIIIllll[llIIlIIlIIIl[2]] = lIIllIIlllIIll("+HQwGUNvLrzmZIXhw9DNZA==", "xnnsf");
    llIIlIIIllll[llIIlIIlIIIl[3]] = lIIllIIlllIlII("DDU/ExgLIDggHztm", "dTLLz");
    llIIlIIIllll[llIIlIIlIIIl[0]] = lIIllIIlllIIll("8e+5sO2lxbiWYHITgln3VmeYsiAGFAX6", "aElyA");
  }
  
  public void addCollisionBoxesToList(World lllllllllllllllIIIlIllIIllIllIlI, BlockPos lllllllllllllllIIIlIllIIllIllIIl, IBlockState lllllllllllllllIIIlIllIIllIllIII, AxisAlignedBB lllllllllllllllIIIlIllIIllIlIIII, List<AxisAlignedBB> lllllllllllllllIIIlIllIIllIlIllI, Entity lllllllllllllllIIIlIllIIllIlIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIlIllIIllIlIlII.setBlockBounds(0.4375F, 0.0F, 0.4375F, 0.5625F, 0.875F, 0.5625F);
    lllllllllllllllIIIlIllIIllIlIlII.addCollisionBoxesToList(lllllllllllllllIIIlIllIIllIllIlI, lllllllllllllllIIIlIllIIllIllIIl, lllllllllllllllIIIlIllIIllIlIIIl, lllllllllllllllIIIlIllIIllIlIIII, lllllllllllllllIIIlIllIIllIlIllI, lllllllllllllllIIIlIllIIllIlIlIl);
    lllllllllllllllIIIlIllIIllIlIlII.setBlockBoundsForItemRender();
    lllllllllllllllIIIlIllIIllIlIlII.addCollisionBoxesToList(lllllllllllllllIIIlIllIIllIllIlI, lllllllllllllllIIIlIllIIllIllIIl, lllllllllllllllIIIlIllIIllIlIIIl, lllllllllllllllIIIlIllIIllIlIIII, lllllllllllllllIIIlIllIIllIlIllI, lllllllllllllllIIIlIllIIllIlIlIl);
  }
}

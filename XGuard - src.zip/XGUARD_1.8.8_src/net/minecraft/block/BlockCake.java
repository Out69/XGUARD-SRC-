package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.stats.StatList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.util.FoodStats;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockCake
  extends Block
{
  public boolean hasComparatorInputOverride()
  {
    return llIllIIlIIII[2];
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public Item getItem(World llllllllllllllIllllllIllIllIlIII, BlockPos llllllllllllllIllllllIllIllIIlll)
  {
    return Items.cake;
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    ;
    ;
    float llllllllllllllIllllllIllllIllIlI = 0.0625F;
    float llllllllllllllIllllllIllllIllIIl = 0.5F;
    llllllllllllllIllllllIllllIllIII.setBlockBounds(llllllllllllllIllllllIllllIllIlI, 0.0F, llllllllllllllIllllllIllllIllIlI, 1.0F - llllllllllllllIllllllIllllIllIlI, llllllllllllllIllllllIllllIllIIl, 1.0F - llllllllllllllIllllllIllllIllIlI);
  }
  
  public AxisAlignedBB getSelectedBoundingBox(World llllllllllllllIllllllIllllIIIIII, BlockPos llllllllllllllIllllllIlllIllllII)
  {
    ;
    ;
    ;
    return llllllllllllllIllllllIllllIIIIIl.getCollisionBoundingBox(llllllllllllllIllllllIlllIllllIl, llllllllllllllIllllllIlllIllllII, llllllllllllllIllllllIlllIllllIl.getBlockState(llllllllllllllIllllllIlllIllllII));
  }
  
  public void onNeighborBlockChange(World llllllllllllllIllllllIllIllllIII, BlockPos llllllllllllllIllllllIllIlllllII, IBlockState llllllllllllllIllllllIllIllllIll, Block llllllllllllllIllllllIllIllllIlI)
  {
    ;
    ;
    ;
    if (lIlIIlIlllIllI(llllllllllllllIllllllIllIllllllI.canBlockStay(llllllllllllllIllllllIllIllllIII, llllllllllllllIllllllIllIlllIlll))) {
      "".length();
    }
  }
  
  public boolean isOpaqueCube()
  {
    return llIllIIlIIII[0];
  }
  
  private static void lIlIIlIllIllll()
  {
    llIllIIIlIlI = new String[llIllIIlIIII[2]];
    llIllIIIlIlI[llIllIIlIIII[0]] = lIlIIlIllIlIlI("mljFoYDp6LQ=", "DNJur");
  }
  
  public int quantityDropped(Random llllllllllllllIllllllIllIllIlllI)
  {
    return llIllIIlIIII[0];
  }
  
  public boolean onBlockActivated(World llllllllllllllIllllllIlllIlIlIlI, BlockPos llllllllllllllIllllllIlllIllIIlI, IBlockState llllllllllllllIllllllIlllIllIIIl, EntityPlayer llllllllllllllIllllllIlllIllIIII, EnumFacing llllllllllllllIllllllIlllIlIllll, float llllllllllllllIllllllIlllIlIlllI, float llllllllllllllIllllllIlllIlIllIl, float llllllllllllllIllllllIlllIlIllII)
  {
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllllllIlllIllIlII.eatCake(llllllllllllllIllllllIlllIlIlIlI, llllllllllllllIllllllIlllIllIIlI, llllllllllllllIllllllIlllIllIIIl, llllllllllllllIllllllIlllIlIIlll);
    return llIllIIlIIII[2];
  }
  
  static
  {
    lIlIIlIlllIIll();
    lIlIIlIllIllll();
  }
  
  public boolean canPlaceBlockAt(World llllllllllllllIllllllIlllIIIIllI, BlockPos llllllllllllllIllllllIlllIIIIlIl)
  {
    ;
    ;
    ;
    if (lIlIIlIlllIlII(llllllllllllllIllllllIlllIIIIlll.canPlaceBlockAt(llllllllllllllIllllllIlllIIIIIll, llllllllllllllIllllllIlllIIIIlIl)))
    {
      "".length();
      if ("   ".length() >= "  ".length()) {
        break label56;
      }
      return (0x7B ^ 0x2E) & (0x24 ^ 0x71 ^ 0xFFFFFFFF);
    }
    label56:
    return llIllIIlIIII[0];
  }
  
  private void eatCake(World llllllllllllllIllllllIlllIIlIlII, BlockPos llllllllllllllIllllllIlllIIlIIll, IBlockState llllllllllllllIllllllIlllIIIllIl, EntityPlayer llllllllllllllIllllllIlllIIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIlIIlIlllIlII(llllllllllllllIllllllIlllIIlIIIl.canEat(llIllIIlIIII[0])))
    {
      llllllllllllllIllllllIlllIIlIIIl.triggerAchievement(StatList.field_181724_H);
      llllllllllllllIllllllIlllIIlIIIl.getFoodStats().addStats(llIllIIlIIII[3], 0.1F);
      int llllllllllllllIllllllIlllIIlIIII = ((Integer)llllllllllllllIllllllIlllIIIllIl.getValue(BITES)).intValue();
      if (lIlIIlIlllIlIl(llllllllllllllIllllllIlllIIlIIII, llIllIIlIIII[1]))
      {
        "".length();
        "".length();
        if ("   ".length() != " ".length()) {}
      }
      else
      {
        "".length();
      }
    }
  }
  
  protected BlockCake()
  {
    llllllllllllllIllllllIllllllIIIl.<init>(Material.cake);
    llllllllllllllIllllllIllllllIIlI.setDefaultState(blockState.getBaseState().withProperty(BITES, Integer.valueOf(llIllIIlIIII[0])));
    "".length();
  }
  
  private boolean canBlockStay(World llllllllllllllIllllllIllIlllIIIl, BlockPos llllllllllllllIllllllIllIlllIIlI)
  {
    ;
    ;
    return llllllllllllllIllllllIllIlllIIIl.getBlockState(llllllllllllllIllllllIllIlllIIlI.down()).getBlock().getMaterial().isSolid();
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIllllllIllIllIllII, Random llllllllllllllIllllllIllIllIlIll, int llllllllllllllIllllllIllIllIlIlI)
  {
    return null;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIllllllIllllIIllll, BlockPos llllllllllllllIllllllIllllIIlIIl, IBlockState llllllllllllllIllllllIllllIIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIllllllIllllIIllII = 0.0625F;
    float llllllllllllllIllllllIllllIIlIll = (llIllIIlIIII[2] + ((Integer)llllllllllllllIllllllIllllIIlIII.getValue(BITES)).intValue() * llIllIIlIIII[3]) / 16.0F;
    float llllllllllllllIllllllIllllIIlIlI = 0.5F;
    return new AxisAlignedBB(llllllllllllllIllllllIllllIIlIIl.getX() + llllllllllllllIllllllIllllIIlIll, llllllllllllllIllllllIllllIIlIIl.getY(), llllllllllllllIllllllIllllIIlIIl.getZ() + llllllllllllllIllllllIllllIIllII, llllllllllllllIllllllIllllIIlIIl.getX() + llIllIIlIIII[2] - llllllllllllllIllllllIllllIIllII, llllllllllllllIllllllIllllIIlIIl.getY() + llllllllllllllIllllllIllllIIlIlI, llllllllllllllIllllllIllllIIlIIl.getZ() + llIllIIlIIII[2] - llllllllllllllIllllllIllllIIllII);
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIllllllIlllllIIIll, BlockPos llllllllllllllIllllllIlllllIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIllllllIlllllIIlll = 0.0625F;
    float llllllllllllllIllllllIlllllIIllI = (llIllIIlIIII[2] + ((Integer)llllllllllllllIllllllIlllllIlIIl.getBlockState(llllllllllllllIllllllIlllllIIIlI).getValue(BITES)).intValue() * llIllIIlIIII[3]) / 16.0F;
    float llllllllllllllIllllllIlllllIIlIl = 0.5F;
    llllllllllllllIllllllIlllllIlIlI.setBlockBounds(llllllllllllllIllllllIlllllIIllI, 0.0F, llllllllllllllIllllllIlllllIIlll, 1.0F - llllllllllllllIllllllIlllllIIlll, llllllllllllllIllllllIlllllIIlIl, 1.0F - llllllllllllllIllllllIlllllIIlll);
  }
  
  public boolean isFullCube()
  {
    return llIllIIlIIII[0];
  }
  
  private static boolean lIlIIlIlllIlIl(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIllllllIllIlIIIIII;
    return ??? < i;
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIllllllIllIllIIIII)
  {
    ;
    ;
    return llllllllllllllIllllllIllIllIIIIl.getDefaultState().withProperty(BITES, Integer.valueOf(llllllllllllllIllllllIllIllIIIII));
  }
  
  private static boolean lIlIIlIlllIlII(int ???)
  {
    long llllllllllllllIllllllIllIIlllllI;
    return ??? != 0;
  }
  
  private static void lIlIIlIlllIIll()
  {
    llIllIIlIIII = new int[6];
    llIllIIlIIII[0] = ((0x3B ^ 0x2F ^ 0x0 ^ 0x51) & ('³' + '¡' - 260 + 120 ^ 78 + 6 - -25 + 32 ^ -" ".length()));
    llIllIIlIIII[1] = (0x1E ^ 0x18);
    llIllIIlIIII[2] = " ".length();
    llIllIIlIIII[3] = "  ".length();
    llIllIIlIIII[4] = "   ".length();
    llIllIIlIIII[5] = (" ".length() ^ 0xC3 ^ 0xC5);
  }
  
  private static boolean lIlIIlIlllIllI(int ???)
  {
    char llllllllllllllIllllllIllIIllllII;
    return ??? == 0;
  }
  
  public void onBlockClicked(World llllllllllllllIllllllIlllIIlllIl, BlockPos llllllllllllllIllllllIlllIIlllII, EntityPlayer llllllllllllllIllllllIlllIIlllll)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIllllllIlllIlIIIlI.eatCake(llllllllllllllIllllllIlllIIlllIl, llllllllllllllIllllllIlllIIlllII, llllllllllllllIllllllIlllIIlllIl.getBlockState(llllllllllllllIllllllIlllIIlllII), llllllllllllllIllllllIlllIIlllll);
  }
  
  public int getComparatorInputOverride(World llllllllllllllIllllllIllIlIlIIll, BlockPos llllllllllllllIllllllIllIlIlIlII)
  {
    ;
    ;
    return (llIllIIlIIII[5] - ((Integer)llllllllllllllIllllllIllIlIlIIll.getBlockState(llllllllllllllIllllllIllIlIlIlII).getValue(BITES)).intValue()) * llIllIIlIIII[3];
  }
  
  private static String lIlIIlIllIlIlI(String llllllllllllllIllllllIllIlIIlIIl, String llllllllllllllIllllllIllIlIIIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllllllIllIlIIllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllllllIllIlIIIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllllllIllIlIIlIll = Cipher.getInstance("Blowfish");
      llllllllllllllIllllllIllIlIIlIll.init(llIllIIlIIII[3], llllllllllllllIllllllIllIlIIllII);
      return new String(llllllllllllllIllllllIllIlIIlIll.doFinal(Base64.getDecoder().decode(llllllllllllllIllllllIllIlIIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllllllIllIlIIlIlI)
    {
      llllllllllllllIllllllIllIlIIlIlI.printStackTrace();
    }
    return null;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIllllllIllIlIlllII)
  {
    ;
    return ((Integer)llllllllllllllIllllllIllIlIlllII.getValue(BITES)).intValue();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIllllllIllIlIllIIl, new IProperty[] { BITES });
  }
}

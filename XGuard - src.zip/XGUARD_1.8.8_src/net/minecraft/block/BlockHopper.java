package net.minecraft.block;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockHopper
  extends BlockContainer
{
  public int getComparatorInputOverride(World lllllllllllllllIIlIIIlllIllIlIll, BlockPos lllllllllllllllIIlIIIlllIllIllII)
  {
    ;
    ;
    return Container.calcRedstone(lllllllllllllllIIlIIIlllIllIlIll.getTileEntity(lllllllllllllllIIlIIIlllIllIllII));
  }
  
  private void updateState(World lllllllllllllllIIlIIIllllIIlIIIl, BlockPos lllllllllllllllIIlIIIllllIIlIlII, IBlockState lllllllllllllllIIlIIIllllIIIllll)
  {
    ;
    ;
    ;
    ;
    if (lIIlIIlllIlIIl(lllllllllllllllIIlIIIllllIIlIIIl.isBlockPowered(lllllllllllllllIIlIIIllllIIlIIII)))
    {
      "".length();
      if (-" ".length() < (0xDD ^ 0xBB ^ 0xCE ^ 0xAC)) {
        break label52;
      }
    }
    label52:
    boolean lllllllllllllllIIlIIIllllIIlIIlI = llIIIIIlIlIl[1];
    if (lIIlIIlllIlIlI(lllllllllllllllIIlIIIllllIIlIIlI, ((Boolean)lllllllllllllllIIlIIIllllIIIllll.getValue(ENABLED)).booleanValue())) {
      "".length();
    }
  }
  
  public boolean isFullCube()
  {
    return llIIIIIlIlIl[0];
  }
  
  public boolean shouldSideBeRendered(IBlockAccess lllllllllllllllIIlIIIlllIllllIlI, BlockPos lllllllllllllllIIlIIIlllIllllIIl, EnumFacing lllllllllllllllIIlIIIlllIllllIII)
  {
    return llIIIIIlIlIl[1];
  }
  
  public static boolean isEnabled(int lllllllllllllllIIlIIIlllIlllIIlI)
  {
    ;
    if (lIIlIIlllIlIlI(lllllllllllllllIIlIIIlllIlllIIlI & llIIIIIlIlIl[5], llIIIIIlIlIl[5])) {
      return llIIIIIlIlIl[1];
    }
    return llIIIIIlIlIl[0];
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT_MIPPED;
  }
  
  private static void lIIlIIlllIIllI()
  {
    llIIIIIlIlII = new String[llIIIIIlIlIl[6]];
    llIIIIIlIlII[llIIIIIlIlIl[0]] = lIIlIIlllIIlII("DUXsYvPZZTY=", "BpFbh");
    llIIIIIlIlII[llIIIIIlIlIl[1]] = lIIlIIlllIIlIl("FAYrNwcUDA==", "qhJUk");
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess lllllllllllllllIIlIIlIIIIIIIlIII, BlockPos lllllllllllllllIIlIIlIIIIIIIIlll)
  {
    ;
    lllllllllllllllIIlIIlIIIIIIIIllI.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  
  private static boolean lIIlIIlllIlIII(Object ???, Object arg1)
  {
    Object localObject;
    Exception lllllllllllllllIIlIIIlllIIlIllII;
    return ??? == localObject;
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIIlIIIlllIlIlllll)
  {
    ;
    ;
    int lllllllllllllllIIlIIIlllIlIllllI = llIIIIIlIlIl[0];
    lllllllllllllllIIlIIIlllIlIllllI |= ((EnumFacing)lllllllllllllllIIlIIIlllIlIlllIl.getValue(FACING)).getIndex();
    if (lIIlIIlllIlIll(((Boolean)lllllllllllllllIIlIIIlllIlIlllIl.getValue(ENABLED)).booleanValue())) {
      lllllllllllllllIIlIIIlllIlIllllI |= llIIIIIlIlIl[5];
    }
    return lllllllllllllllIIlIIIlllIlIllllI;
  }
  
  public static EnumFacing getFacing(int lllllllllllllllIIlIIIlllIlllIlIl)
  {
    ;
    return EnumFacing.getFront(lllllllllllllllIIlIIIlllIlllIlIl & llIIIIIlIlIl[4]);
  }
  
  public boolean hasComparatorInputOverride()
  {
    return llIIIIIlIlIl[1];
  }
  
  public void onBlockPlacedBy(World lllllllllllllllIIlIIIlllllIlIIlI, BlockPos lllllllllllllllIIlIIIlllllIlIIIl, IBlockState lllllllllllllllIIlIIIlllllIlIIII, EntityLivingBase lllllllllllllllIIlIIIlllllIIlIII, ItemStack lllllllllllllllIIlIIIlllllIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIIlllllIlIIll.onBlockPlacedBy(lllllllllllllllIIlIIIlllllIlIIlI, lllllllllllllllIIlIIIlllllIlIIIl, lllllllllllllllIIlIIIlllllIlIIII, lllllllllllllllIIlIIIlllllIIlIII, lllllllllllllllIIlIIIlllllIIlllI);
    if (lIIlIIlllIlIIl(lllllllllllllllIIlIIIlllllIIlllI.hasDisplayName()))
    {
      TileEntity lllllllllllllllIIlIIIlllllIIllIl = lllllllllllllllIIlIIIlllllIlIIlI.getTileEntity(lllllllllllllllIIlIIIlllllIlIIIl);
      if (lIIlIIlllIlIIl(lllllllllllllllIIlIIIlllllIIllIl instanceof TileEntityHopper)) {
        ((TileEntityHopper)lllllllllllllllIIlIIIlllllIIllIl).setCustomName(lllllllllllllllIIlIIIlllllIIlllI.getDisplayName());
      }
    }
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIIlIIIlllIlIllIlI, new IProperty[] { FACING, ENABLED });
  }
  
  public IBlockState onBlockPlaced(World lllllllllllllllIIlIIIllllllIlIIl, BlockPos lllllllllllllllIIlIIIllllllIlIII, EnumFacing lllllllllllllllIIlIIIllllllIIlll, float lllllllllllllllIIlIIIllllllIIllI, float lllllllllllllllIIlIIIllllllIIlIl, float lllllllllllllllIIlIIIllllllIIlII, int lllllllllllllllIIlIIIllllllIIIll, EntityLivingBase lllllllllllllllIIlIIIllllllIIIlI)
  {
    ;
    ;
    ;
    EnumFacing lllllllllllllllIIlIIIllllllIIIIl = lllllllllllllllIIlIIIllllllIIlll.getOpposite();
    if (lIIlIIlllIlIII(lllllllllllllllIIlIIIllllllIIIIl, EnumFacing.UP)) {
      lllllllllllllllIIlIIIllllllIIIIl = EnumFacing.DOWN;
    }
    return lllllllllllllllIIlIIIllllllIlIlI.getDefaultState().withProperty(FACING, lllllllllllllllIIlIIIllllllIIIIl).withProperty(ENABLED, Boolean.valueOf(llIIIIIlIlIl[1]));
  }
  
  public void onNeighborBlockChange(World lllllllllllllllIIlIIIllllIlIIIlI, BlockPos lllllllllllllllIIlIIIllllIlIIIIl, IBlockState lllllllllllllllIIlIIIllllIIllIll, Block lllllllllllllllIIlIIIllllIIlllll)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIIllllIIllllI.updateState(lllllllllllllllIIlIIIllllIlIIIlI, lllllllllllllllIIlIIIllllIIlllII, lllllllllllllllIIlIIIllllIIllIll);
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIIlIIIlllIllIIIll)
  {
    ;
    ;
    return lllllllllllllllIIlIIIlllIllIIlII.getDefaultState().withProperty(FACING, getFacing(lllllllllllllllIIlIIIlllIllIIIll)).withProperty(ENABLED, Boolean.valueOf(isEnabled(lllllllllllllllIIlIIIlllIllIIIll)));
  }
  
  public void addCollisionBoxesToList(World lllllllllllllllIIlIIIlllllllllII, BlockPos lllllllllllllllIIlIIIlllllllIIll, IBlockState lllllllllllllllIIlIIIlllllllIIlI, AxisAlignedBB lllllllllllllllIIlIIIllllllllIIl, List<AxisAlignedBB> lllllllllllllllIIlIIIlllllllIIII, Entity lllllllllllllllIIlIIIlllllllIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIIlllllllllIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.625F, 1.0F);
    lllllllllllllllIIlIIIlllllllllIl.addCollisionBoxesToList(lllllllllllllllIIlIIIlllllllllII, lllllllllllllllIIlIIIlllllllIIll, lllllllllllllllIIlIIIllllllllIlI, lllllllllllllllIIlIIIllllllllIIl, lllllllllllllllIIlIIIlllllllIIII, lllllllllllllllIIlIIIlllllllIlll);
    float lllllllllllllllIIlIIIlllllllIllI = 0.125F;
    lllllllllllllllIIlIIIlllllllllIl.setBlockBounds(0.0F, 0.0F, 0.0F, lllllllllllllllIIlIIIlllllllIllI, 1.0F, 1.0F);
    lllllllllllllllIIlIIIlllllllllIl.addCollisionBoxesToList(lllllllllllllllIIlIIIlllllllllII, lllllllllllllllIIlIIIlllllllIIll, lllllllllllllllIIlIIIllllllllIlI, lllllllllllllllIIlIIIllllllllIIl, lllllllllllllllIIlIIIlllllllIIII, lllllllllllllllIIlIIIlllllllIlll);
    lllllllllllllllIIlIIIlllllllllIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, lllllllllllllllIIlIIIlllllllIllI);
    lllllllllllllllIIlIIIlllllllllIl.addCollisionBoxesToList(lllllllllllllllIIlIIIlllllllllII, lllllllllllllllIIlIIIlllllllIIll, lllllllllllllllIIlIIIllllllllIlI, lllllllllllllllIIlIIIllllllllIIl, lllllllllllllllIIlIIIlllllllIIII, lllllllllllllllIIlIIIlllllllIlll);
    lllllllllllllllIIlIIIlllllllllIl.setBlockBounds(1.0F - lllllllllllllllIIlIIIlllllllIllI, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    lllllllllllllllIIlIIIlllllllllIl.addCollisionBoxesToList(lllllllllllllllIIlIIIlllllllllII, lllllllllllllllIIlIIIlllllllIIll, lllllllllllllllIIlIIIllllllllIlI, lllllllllllllllIIlIIIllllllllIIl, lllllllllllllllIIlIIIlllllllIIII, lllllllllllllllIIlIIIlllllllIlll);
    lllllllllllllllIIlIIIlllllllllIl.setBlockBounds(0.0F, 0.0F, 1.0F - lllllllllllllllIIlIIIlllllllIllI, 1.0F, 1.0F, 1.0F);
    lllllllllllllllIIlIIIlllllllllIl.addCollisionBoxesToList(lllllllllllllllIIlIIIlllllllllII, lllllllllllllllIIlIIIlllllllIIll, lllllllllllllllIIlIIIllllllllIlI, lllllllllllllllIIlIIIllllllllIIl, lllllllllllllllIIlIIIlllllllIIII, lllllllllllllllIIlIIIlllllllIlll);
    lllllllllllllllIIlIIIlllllllllIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  
  public void breakBlock(World lllllllllllllllIIlIIIllllIIIIlll, BlockPos lllllllllllllllIIlIIIllllIIIIllI, IBlockState lllllllllllllllIIlIIIllllIIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    TileEntity lllllllllllllllIIlIIIllllIIIIlII = lllllllllllllllIIlIIIllllIIIIlll.getTileEntity(lllllllllllllllIIlIIIllllIIIIllI);
    if (lIIlIIlllIlIIl(lllllllllllllllIIlIIIllllIIIIlII instanceof TileEntityHopper))
    {
      InventoryHelper.dropInventoryItems(lllllllllllllllIIlIIIllllIIIIlll, lllllllllllllllIIlIIIllllIIIIllI, (TileEntityHopper)lllllllllllllllIIlIIIllllIIIIlII);
      lllllllllllllllIIlIIIllllIIIIlll.updateComparatorOutputLevel(lllllllllllllllIIlIIIllllIIIIllI, lllllllllllllllIIlIIIllllIIIlIII);
    }
    lllllllllllllllIIlIIIllllIIIlIII.breakBlock(lllllllllllllllIIlIIIllllIIIIlll, lllllllllllllllIIlIIIllllIIIIllI, lllllllllllllllIIlIIIllllIIIIIII);
  }
  
  private static void lIIlIIlllIIlll()
  {
    llIIIIIlIlIl = new int[7];
    llIIIIIlIlIl[0] = ((0x22 ^ 0x7B) & (0x53 ^ 0xA ^ 0xFFFFFFFF));
    llIIIIIlIlIl[1] = " ".length();
    llIIIIIlIlIl[2] = (0x89 ^ 0x8D);
    llIIIIIlIlIl[3] = "   ".length();
    llIIIIIlIlIl[4] = (0x68 ^ 0x6F);
    llIIIIIlIlIl[5] = (0xE ^ 0x6);
    llIIIIIlIlIl[6] = "  ".length();
  }
  
  public int getRenderType()
  {
    return llIIIIIlIlIl[3];
  }
  
  private static boolean lIIlIIlllIlIIl(int ???)
  {
    short lllllllllllllllIIlIIIlllIIlIlIlI;
    return ??? != 0;
  }
  
  public boolean isOpaqueCube()
  {
    return llIIIIIlIlIl[0];
  }
  
  public void onBlockAdded(World lllllllllllllllIIlIIIlllllIIIIII, BlockPos lllllllllllllllIIlIIIllllIlllIll, IBlockState lllllllllllllllIIlIIIllllIlllIlI)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIIlllllIIIIIl.updateState(lllllllllllllllIIlIIIlllllIIIIII, lllllllllllllllIIlIIIllllIlllIll, lllllllllllllllIIlIIIllllIlllIlI);
  }
  
  private static boolean lIIlIIlllIlIlI(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIIlIIIlllIIlIIlII;
    return ??? != i;
  }
  
  public boolean onBlockActivated(World lllllllllllllllIIlIIIllllIlIlIll, BlockPos lllllllllllllllIIlIIIllllIlIlIlI, IBlockState lllllllllllllllIIlIIIllllIllIIlI, EntityPlayer lllllllllllllllIIlIIIllllIllIIIl, EnumFacing lllllllllllllllIIlIIIllllIllIIII, float lllllllllllllllIIlIIIllllIlIllll, float lllllllllllllllIIlIIIllllIlIlllI, float lllllllllllllllIIlIIIllllIlIllIl)
  {
    ;
    ;
    ;
    ;
    if (lIIlIIlllIlIIl(isRemote)) {
      return llIIIIIlIlIl[1];
    }
    TileEntity lllllllllllllllIIlIIIllllIlIllII = lllllllllllllllIIlIIIllllIlIlIll.getTileEntity(lllllllllllllllIIlIIIllllIlIlIlI);
    if (lIIlIIlllIlIIl(lllllllllllllllIIlIIIllllIlIllII instanceof TileEntityHopper))
    {
      lllllllllllllllIIlIIIllllIllIIIl.displayGUIChest((TileEntityHopper)lllllllllllllllIIlIIIllllIlIllII);
      lllllllllllllllIIlIIIllllIllIIIl.triggerAchievement(StatList.field_181732_P);
    }
    return llIIIIIlIlIl[1];
  }
  
  static
  {
    lIIlIIlllIIlll();
    lIIlIIlllIIllI();
    FACING = PropertyDirection.create(llIIIIIlIlII[llIIIIIlIlIl[0]], new Predicate()
    {
      private static void lIIlIlllIllI()
      {
        lIlllllIlI = new int[2];
        lIlllllIlI[0] = " ".length();
        lIlllllIlI[1] = ((0x54 ^ 0x7F ^ 0xA9 ^ 0xC5) & (0x20 ^ 0x0 ^ 0x11 ^ 0x76 ^ -" ".length()));
      }
      
      private static boolean lIIlIlllIlll(Object ???, Object arg1)
      {
        Object localObject;
        double llllllllllllllllllllIIIIIIIlllII;
        return ??? != localObject;
      }
      
      public boolean apply(EnumFacing llllllllllllllllllllIIIIIIlIIlIl)
      {
        ;
        if (lIIlIlllIlll(llllllllllllllllllllIIIIIIlIIlIl, EnumFacing.UP)) {
          return lIlllllIlI[0];
        }
        return lIlllllIlI[1];
      }
      
      static {}
    });
  }
  
  private static boolean lIIlIIlllIlIll(int ???)
  {
    float lllllllllllllllIIlIIIlllIIlIlIII;
    return ??? == 0;
  }
  
  private static boolean lIIlIIlllIllII(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIIlIIIlllIIllIIII;
    return ??? < i;
  }
  
  private static String lIIlIIlllIIlIl(String lllllllllllllllIIlIIIlllIIllllII, String lllllllllllllllIIlIIIlllIlIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIIlllIIllllII = new String(Base64.getDecoder().decode(lllllllllllllllIIlIIIlllIIllllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlIIIlllIIllllll = new StringBuilder();
    char[] lllllllllllllllIIlIIIlllIIlllllI = lllllllllllllllIIlIIIlllIlIIIIII.toCharArray();
    int lllllllllllllllIIlIIIlllIIllllIl = llIIIIIlIlIl[0];
    float lllllllllllllllIIlIIIlllIIllIlll = lllllllllllllllIIlIIIlllIIllllII.toCharArray();
    double lllllllllllllllIIlIIIlllIIllIllI = lllllllllllllllIIlIIIlllIIllIlll.length;
    float lllllllllllllllIIlIIIlllIIllIlIl = llIIIIIlIlIl[0];
    while (lIIlIIlllIllII(lllllllllllllllIIlIIIlllIIllIlIl, lllllllllllllllIIlIIIlllIIllIllI))
    {
      char lllllllllllllllIIlIIIlllIlIIIIlI = lllllllllllllllIIlIIIlllIIllIlll[lllllllllllllllIIlIIIlllIIllIlIl];
      "".length();
      "".length();
      if ("   ".length() <= 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlIIIlllIIllllll);
  }
  
  public TileEntity createNewTileEntity(World lllllllllllllllIIlIIIlllllIlllII, int lllllllllllllllIIlIIIlllllIllIll)
  {
    return new TileEntityHopper();
  }
  
  public BlockHopper()
  {
    lllllllllllllllIIlIIlIIIIIIIlIll.<init>(Material.iron, MapColor.stoneColor);
    lllllllllllllllIIlIIlIIIIIIIllII.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.DOWN).withProperty(ENABLED, Boolean.valueOf(llIIIIIlIlIl[1])));
    "".length();
    lllllllllllllllIIlIIlIIIIIIIllII.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  
  private static String lIIlIIlllIIlII(String lllllllllllllllIIlIIIlllIlIlIIIl, String lllllllllllllllIIlIIIlllIlIIlllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlIIIlllIlIlIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlIIIlllIlIIlllI.getBytes(StandardCharsets.UTF_8)), llIIIIIlIlIl[5]), "DES");
      Cipher lllllllllllllllIIlIIIlllIlIlIIll = Cipher.getInstance("DES");
      lllllllllllllllIIlIIIlllIlIlIIll.init(llIIIIIlIlIl[6], lllllllllllllllIIlIIIlllIlIlIlII);
      return new String(lllllllllllllllIIlIIIlllIlIlIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlIIIlllIlIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlIIIlllIlIlIIlI)
    {
      lllllllllllllllIIlIIIlllIlIlIIlI.printStackTrace();
    }
    return null;
  }
}

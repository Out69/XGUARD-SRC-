package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.item.ItemBanner;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntityBanner;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public class BlockCauldron
  extends Block
{
  public int getMetaFromState(IBlockState llllllllllllllIIlllIlllIIIllllll)
  {
    ;
    return ((Integer)llllllllllllllIIlllIlllIIIllllll.getValue(LEVEL)).intValue();
  }
  
  private static void lllIIllIIIlllI()
  {
    lIIlIllIIllIl = new int[5];
    lIIlIllIIllIl[0] = ((0x24 ^ 0x11) & (0x64 ^ 0x51 ^ 0xFFFFFFFF));
    lIIlIllIIllIl[1] = "   ".length();
    lIIlIllIIllIl[2] = " ".length();
    lIIlIllIIllIl[3] = "  ".length();
    lIIlIllIIllIl[4] = (0x2D ^ 0x39);
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIIlllIlllIIlIIIlIl)
  {
    ;
    ;
    return llllllllllllllIIlllIlllIIlIIIlII.getDefaultState().withProperty(LEVEL, Integer.valueOf(llllllllllllllIIlllIlllIIlIIIlIl));
  }
  
  private static boolean lllIIllIIllIII(int ???, int arg1)
  {
    int i;
    String llllllllllllllIIlllIlllIIIlIIIII;
    return ??? == i;
  }
  
  private static boolean lllIIllIIlIlll(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIIlllIlllIIIIllIII;
    return ??? <= i;
  }
  
  public void onEntityCollidedWithBlock(World llllllllllllllIIlllIlllIlIIlIlll, BlockPos llllllllllllllIIlllIlllIlIIlllIl, IBlockState llllllllllllllIIlllIlllIlIIlllII, Entity llllllllllllllIIlllIlllIlIIllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIIlllIlllIlIIllIlI = ((Integer)llllllllllllllIIlllIlllIlIIlllII.getValue(LEVEL)).intValue();
    float llllllllllllllIIlllIlllIlIIllIIl = llllllllllllllIIlllIlllIlIIlIllI.getY() + (6.0F + lIIlIllIIllIl[1] * llllllllllllllIIlllIlllIlIIllIlI) / 16.0F;
    if ((lllIIllIIlIIII(isRemote)) && (lllIIllIIlIIIl(llllllllllllllIIlllIlllIlIIllIll.isBurning())) && (lllIIllIIlIIlI(llllllllllllllIIlllIlllIlIIllIlI)) && (lllIIllIIlIIll(lllIIllIIIllll(getEntityBoundingBoxminY, llllllllllllllIIlllIlllIlIIllIIl))))
    {
      llllllllllllllIIlllIlllIlIIllIll.extinguish();
      llllllllllllllIIlllIlllIlIIlllll.setWaterLevel(llllllllllllllIIlllIlllIlIIlIlll, llllllllllllllIIlllIlllIlIIlIllI, llllllllllllllIIlllIlllIlIIlllII, llllllllllllllIIlllIlllIlIIllIlI - lIIlIllIIllIl[2]);
    }
  }
  
  public boolean isFullCube()
  {
    return lIIlIllIIllIl[0];
  }
  
  public void setWaterLevel(World llllllllllllllIIlllIlllIIllIlIlI, BlockPos llllllllllllllIIlllIlllIIllIIlII, IBlockState llllllllllllllIIlllIlllIIllIlIII, int llllllllllllllIIlllIlllIIllIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    "".length();
    llllllllllllllIIlllIlllIIllIlIlI.updateComparatorOutputLevel(llllllllllllllIIlllIlllIIllIlIIl, llllllllllllllIIlllIlllIIllIIllI);
  }
  
  public void addCollisionBoxesToList(World llllllllllllllIIlllIlllIlIllIIlI, BlockPos llllllllllllllIIlllIlllIlIllIIIl, IBlockState llllllllllllllIIlllIlllIlIllIIII, AxisAlignedBB llllllllllllllIIlllIlllIlIllIlll, List<AxisAlignedBB> llllllllllllllIIlllIlllIlIlIlllI, Entity llllllllllllllIIlllIlllIlIlIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIlllIlllIlIllIIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.3125F, 1.0F);
    llllllllllllllIIlllIlllIlIllIIll.addCollisionBoxesToList(llllllllllllllIIlllIlllIlIllIIlI, llllllllllllllIIlllIlllIlIllIIIl, llllllllllllllIIlllIlllIlIlllIII, llllllllllllllIIlllIlllIlIllIlll, llllllllllllllIIlllIlllIlIlIlllI, llllllllllllllIIlllIlllIlIlIllIl);
    float llllllllllllllIIlllIlllIlIllIlII = 0.125F;
    llllllllllllllIIlllIlllIlIllIIll.setBlockBounds(0.0F, 0.0F, 0.0F, llllllllllllllIIlllIlllIlIllIlII, 1.0F, 1.0F);
    llllllllllllllIIlllIlllIlIllIIll.addCollisionBoxesToList(llllllllllllllIIlllIlllIlIllIIlI, llllllllllllllIIlllIlllIlIllIIIl, llllllllllllllIIlllIlllIlIlllIII, llllllllllllllIIlllIlllIlIllIlll, llllllllllllllIIlllIlllIlIlIlllI, llllllllllllllIIlllIlllIlIlIllIl);
    llllllllllllllIIlllIlllIlIllIIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, llllllllllllllIIlllIlllIlIllIlII);
    llllllllllllllIIlllIlllIlIllIIll.addCollisionBoxesToList(llllllllllllllIIlllIlllIlIllIIlI, llllllllllllllIIlllIlllIlIllIIIl, llllllllllllllIIlllIlllIlIlllIII, llllllllllllllIIlllIlllIlIllIlll, llllllllllllllIIlllIlllIlIlIlllI, llllllllllllllIIlllIlllIlIlIllIl);
    llllllllllllllIIlllIlllIlIllIIll.setBlockBounds(1.0F - llllllllllllllIIlllIlllIlIllIlII, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    llllllllllllllIIlllIlllIlIllIIll.addCollisionBoxesToList(llllllllllllllIIlllIlllIlIllIIlI, llllllllllllllIIlllIlllIlIllIIIl, llllllllllllllIIlllIlllIlIlllIII, llllllllllllllIIlllIlllIlIllIlll, llllllllllllllIIlllIlllIlIlIlllI, llllllllllllllIIlllIlllIlIlIllIl);
    llllllllllllllIIlllIlllIlIllIIll.setBlockBounds(0.0F, 0.0F, 1.0F - llllllllllllllIIlllIlllIlIllIlII, 1.0F, 1.0F, 1.0F);
    llllllllllllllIIlllIlllIlIllIIll.addCollisionBoxesToList(llllllllllllllIIlllIlllIlIllIIlI, llllllllllllllIIlllIlllIlIllIIIl, llllllllllllllIIlllIlllIlIlllIII, llllllllllllllIIlllIlllIlIllIlll, llllllllllllllIIlllIlllIlIlIlllI, llllllllllllllIIlllIlllIlIlIllIl);
    llllllllllllllIIlllIlllIlIllIIll.setBlockBoundsForItemRender();
  }
  
  public boolean isOpaqueCube()
  {
    return lIIlIllIIllIl[0];
  }
  
  private static boolean lllIIllIIlIIlI(int ???)
  {
    float llllllllllllllIIlllIlllIIIIIlIlI;
    return ??? > 0;
  }
  
  public boolean onBlockActivated(World llllllllllllllIIlllIlllIIllllIII, BlockPos llllllllllllllIIlllIlllIIlllIlll, IBlockState llllllllllllllIIlllIlllIlIIIIlIl, EntityPlayer llllllllllllllIIlllIlllIIlllIlIl, EnumFacing llllllllllllllIIlllIlllIlIIIIIll, float llllllllllllllIIlllIlllIlIIIIIlI, float llllllllllllllIIlllIlllIlIIIIIIl, float llllllllllllllIIlllIlllIlIIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIllIIlIIIl(isRemote)) {
      return lIIlIllIIllIl[2];
    }
    ItemStack llllllllllllllIIlllIlllIIlllllll = inventory.getCurrentItem();
    if (lllIIllIIlIlII(llllllllllllllIIlllIlllIIlllllll)) {
      return lIIlIllIIllIl[2];
    }
    int llllllllllllllIIlllIlllIIllllllI = ((Integer)llllllllllllllIIlllIlllIlIIIIlIl.getValue(LEVEL)).intValue();
    Item llllllllllllllIIlllIlllIIlllllIl = llllllllllllllIIlllIlllIIlllllll.getItem();
    if (lllIIllIIlIlIl(llllllllllllllIIlllIlllIIlllllIl, Items.water_bucket))
    {
      if (lllIIllIIlIllI(llllllllllllllIIlllIlllIIllllllI, lIIlIllIIllIl[1]))
      {
        if (lllIIllIIlIIII(capabilities.isCreativeMode)) {
          inventory.setInventorySlotContents(inventory.currentItem, new ItemStack(Items.bucket));
        }
        llllllllllllllIIlllIlllIlIIIIlII.triggerAchievement(StatList.field_181725_I);
        llllllllllllllIIlllIlllIIllllIIl.setWaterLevel(llllllllllllllIIlllIlllIIllllIII, llllllllllllllIIlllIlllIIlllIlll, llllllllllllllIIlllIlllIlIIIIlIl, lIIlIllIIllIl[1]);
      }
      return lIIlIllIIllIl[2];
    }
    if (lllIIllIIlIlIl(llllllllllllllIIlllIlllIIlllllIl, Items.glass_bottle))
    {
      if (lllIIllIIlIIlI(llllllllllllllIIlllIlllIIllllllI))
      {
        if (lllIIllIIlIIII(capabilities.isCreativeMode))
        {
          ItemStack llllllllllllllIIlllIlllIIlllllII = new ItemStack(Items.potionitem, lIIlIllIIllIl[2], lIIlIllIIllIl[0]);
          if (lllIIllIIlIIII(inventory.addItemStackToInventory(llllllllllllllIIlllIlllIIlllllII)))
          {
            new EntityItem(llllllllllllllIIlllIlllIIllllIII, llllllllllllllIIlllIlllIIlllIlll.getX() + 0.5D, llllllllllllllIIlllIlllIIlllIlll.getY() + 1.5D, llllllllllllllIIlllIlllIIlllIlll.getZ() + 0.5D, llllllllllllllIIlllIlllIIlllllII);
            "".length();
            "".length();
            if (((0xBB ^ 0x80) & (0x33 ^ 0x8 ^ 0xFFFFFFFF)) == "   ".length()) {
              return (0xFA ^ 0xB9) & (0x42 ^ 0x1 ^ 0xFFFFFFFF);
            }
          }
          else if (lllIIllIIlIIIl(llllllllllllllIIlllIlllIlIIIIlII instanceof EntityPlayerMP))
          {
            ((EntityPlayerMP)llllllllllllllIIlllIlllIlIIIIlII).sendContainerToPlayer(inventoryContainer);
          }
          llllllllllllllIIlllIlllIlIIIIlII.triggerAchievement(StatList.field_181726_J);
          stackSize -= lIIlIllIIllIl[2];
          if (lllIIllIIlIIll(stackSize)) {
            inventory.setInventorySlotContents(inventory.currentItem, null);
          }
        }
        llllllllllllllIIlllIlllIIllllIIl.setWaterLevel(llllllllllllllIIlllIlllIIllllIII, llllllllllllllIIlllIlllIIlllIlll, llllllllllllllIIlllIlllIlIIIIlIl, llllllllllllllIIlllIlllIIllllllI - lIIlIllIIllIl[2]);
      }
      return lIIlIllIIllIl[2];
    }
    if ((lllIIllIIlIIlI(llllllllllllllIIlllIlllIIllllllI)) && (lllIIllIIlIIIl(llllllllllllllIIlllIlllIIlllllIl instanceof ItemArmor)))
    {
      ItemArmor llllllllllllllIIlllIlllIIllllIll = (ItemArmor)llllllllllllllIIlllIlllIIlllllIl;
      if ((lllIIllIIlIlIl(llllllllllllllIIlllIlllIIllllIll.getArmorMaterial(), ItemArmor.ArmorMaterial.LEATHER)) && (lllIIllIIlIIIl(llllllllllllllIIlllIlllIIllllIll.hasColor(llllllllllllllIIlllIlllIIlllllll))))
      {
        llllllllllllllIIlllIlllIIllllIll.removeColor(llllllllllllllIIlllIlllIIlllllll);
        llllllllllllllIIlllIlllIIllllIIl.setWaterLevel(llllllllllllllIIlllIlllIIllllIII, llllllllllllllIIlllIlllIIlllIlll, llllllllllllllIIlllIlllIlIIIIlIl, llllllllllllllIIlllIlllIIllllllI - lIIlIllIIllIl[2]);
        llllllllllllllIIlllIlllIlIIIIlII.triggerAchievement(StatList.field_181727_K);
        return lIIlIllIIllIl[2];
      }
    }
    if ((lllIIllIIlIIlI(llllllllllllllIIlllIlllIIllllllI)) && (lllIIllIIlIIIl(llllllllllllllIIlllIlllIIlllllIl instanceof ItemBanner)) && (lllIIllIIlIIlI(TileEntityBanner.getPatterns(llllllllllllllIIlllIlllIIlllllll))))
    {
      ItemStack llllllllllllllIIlllIlllIIllllIlI = llllllllllllllIIlllIlllIIlllllll.copy();
      stackSize = lIIlIllIIllIl[2];
      TileEntityBanner.removeBannerData(llllllllllllllIIlllIlllIIllllIlI);
      if ((lllIIllIIlIlll(stackSize, lIIlIllIIllIl[2])) && (lllIIllIIlIIII(capabilities.isCreativeMode)))
      {
        inventory.setInventorySlotContents(inventory.currentItem, llllllllllllllIIlllIlllIIllllIlI);
        "".length();
        if (null != null) {
          return (0x62 ^ 0x38) & (0x9B ^ 0xC1 ^ 0xFFFFFFFF);
        }
      }
      else
      {
        if (lllIIllIIlIIII(inventory.addItemStackToInventory(llllllllllllllIIlllIlllIIllllIlI)))
        {
          new EntityItem(llllllllllllllIIlllIlllIIllllIII, llllllllllllllIIlllIlllIIlllIlll.getX() + 0.5D, llllllllllllllIIlllIlllIIlllIlll.getY() + 1.5D, llllllllllllllIIlllIlllIIlllIlll.getZ() + 0.5D, llllllllllllllIIlllIlllIIllllIlI);
          "".length();
          "".length();
          if ((0x34 ^ 0x30) == 0) {
            return (0x61 ^ 0x76) & (0x6E ^ 0x79 ^ 0xFFFFFFFF);
          }
        }
        else if (lllIIllIIlIIIl(llllllllllllllIIlllIlllIlIIIIlII instanceof EntityPlayerMP))
        {
          ((EntityPlayerMP)llllllllllllllIIlllIlllIlIIIIlII).sendContainerToPlayer(inventoryContainer);
        }
        llllllllllllllIIlllIlllIlIIIIlII.triggerAchievement(StatList.field_181728_L);
        if (lllIIllIIlIIII(capabilities.isCreativeMode)) {
          stackSize -= lIIlIllIIllIl[2];
        }
      }
      if (lllIIllIIlIIII(capabilities.isCreativeMode)) {
        llllllllllllllIIlllIlllIIllllIIl.setWaterLevel(llllllllllllllIIlllIlllIIllllIII, llllllllllllllIIlllIlllIIlllIlll, llllllllllllllIIlllIlllIlIIIIlIl, llllllllllllllIIlllIlllIIllllllI - lIIlIllIIllIl[2]);
      }
      return lIIlIllIIllIl[2];
    }
    return lIIlIllIIllIl[0];
  }
  
  private static boolean lllIIllIIlIlII(Object ???)
  {
    float llllllllllllllIIlllIlllIIIIlIIlI;
    return ??? == null;
  }
  
  public BlockCauldron()
  {
    llllllllllllllIIlllIlllIllIIIlIl.<init>(Material.iron, MapColor.stoneColor);
    llllllllllllllIIlllIlllIllIIIlII.setDefaultState(blockState.getBaseState().withProperty(LEVEL, Integer.valueOf(lIIlIllIIllIl[0])));
  }
  
  public Item getItem(World llllllllllllllIIlllIlllIIlIlIIlI, BlockPos llllllllllllllIIlllIlllIIlIlIIIl)
  {
    return Items.cauldron;
  }
  
  private static boolean lllIIllIIlIIII(int ???)
  {
    float llllllllllllllIIlllIlllIIIIIlllI;
    return ??? == 0;
  }
  
  private static boolean lllIIllIIlIlIl(Object ???, Object arg1)
  {
    Object localObject;
    float llllllllllllllIIlllIlllIIIIlIlII;
    return ??? == localObject;
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIIlllIlllIIlIlIllI, Random llllllllllllllIIlllIlllIIlIlIlIl, int llllllllllllllIIlllIlllIIlIlIlII)
  {
    return Items.cauldron;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIIlllIlllIIIllllIl, new IProperty[] { LEVEL });
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    llllllllllllllIIlllIlllIlIlIlIlI.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  
  public void fillWithRain(World llllllllllllllIIlllIlllIIlIllIlI, BlockPos llllllllllllllIIlllIlllIIlIlllII)
  {
    ;
    ;
    ;
    if (lllIIllIIllIII(rand.nextInt(lIIlIllIIllIl[4]), lIIlIllIIllIl[2]))
    {
      IBlockState llllllllllllllIIlllIlllIIlIllIll = llllllllllllllIIlllIlllIIlIllIlI.getBlockState(llllllllllllllIIlllIlllIIlIlllII);
      if (lllIIllIIlIllI(((Integer)llllllllllllllIIlllIlllIIlIllIll.getValue(LEVEL)).intValue(), lIIlIllIIllIl[1])) {
        "".length();
      }
    }
  }
  
  public int getComparatorInputOverride(World llllllllllllllIIlllIlllIIlIIlIlI, BlockPos llllllllllllllIIlllIlllIIlIIlIll)
  {
    ;
    ;
    return ((Integer)llllllllllllllIIlllIlllIIlIIlIlI.getBlockState(llllllllllllllIIlllIlllIIlIIlIll).getValue(LEVEL)).intValue();
  }
  
  private static int lllIIllIIIllll(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean lllIIllIIlIllI(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIIlllIlllIIIIlllII;
    return ??? < i;
  }
  
  static
  {
    lllIIllIIIlllI();
    lllIIllIIIlIll();
  }
  
  private static boolean lllIIllIIlIIIl(int ???)
  {
    char llllllllllllllIIlllIlllIIIIlIIII;
    return ??? != 0;
  }
  
  private static boolean lllIIllIIlIIll(int ???)
  {
    double llllllllllllllIIlllIlllIIIIIllII;
    return ??? <= 0;
  }
  
  private static String lllIIllIIIlIlI(String llllllllllllllIIlllIlllIIIlIllII, String llllllllllllllIIlllIlllIIIlIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIlllIlllIIIlIllII = new String(Base64.getDecoder().decode(llllllllllllllIIlllIlllIIIlIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIlllIlllIIIlIllll = new StringBuilder();
    char[] llllllllllllllIIlllIlllIIIlIlllI = llllllllllllllIIlllIlllIIIlIlIll.toCharArray();
    int llllllllllllllIIlllIlllIIIlIllIl = lIIlIllIIllIl[0];
    long llllllllllllllIIlllIlllIIIlIIlll = llllllllllllllIIlllIlllIIIlIllII.toCharArray();
    String llllllllllllllIIlllIlllIIIlIIllI = llllllllllllllIIlllIlllIIIlIIlll.length;
    String llllllllllllllIIlllIlllIIIlIIlIl = lIIlIllIIllIl[0];
    while (lllIIllIIlIllI(llllllllllllllIIlllIlllIIIlIIlIl, llllllllllllllIIlllIlllIIIlIIllI))
    {
      char llllllllllllllIIlllIlllIIIllIIlI = llllllllllllllIIlllIlllIIIlIIlll[llllllllllllllIIlllIlllIIIlIIlIl];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIlllIlllIIIlIllll);
  }
  
  private static void lllIIllIIIlIll()
  {
    lIIlIllIIlIll = new String[lIIlIllIIllIl[2]];
    lIIlIllIIlIll[lIIlIllIIllIl[0]] = lllIIllIIIlIlI("AQQeFQs=", "mahpg");
  }
  
  public boolean hasComparatorInputOverride()
  {
    return lIIlIllIIllIl[2];
  }
}

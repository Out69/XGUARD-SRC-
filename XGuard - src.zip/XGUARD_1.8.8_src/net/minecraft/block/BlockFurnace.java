package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class BlockFurnace
  extends BlockContainer
{
  private static boolean llIIllIIlIIllI(int ???)
  {
    Exception llllllllllllllIlIlIlIlllIlllIIII;
    return ??? != 0;
  }
  
  public boolean hasComparatorInputOverride()
  {
    return lIIIIlIllIllI[2];
  }
  
  public TileEntity createNewTileEntity(World llllllllllllllIlIlIlIllllllIIllI, int llllllllllllllIlIlIlIllllllIIlIl)
  {
    return new TileEntityFurnace();
  }
  
  public void randomDisplayTick(World llllllllllllllIlIlIllIIIIIIlllIl, BlockPos llllllllllllllIlIlIllIIIIIIlIIIl, IBlockState llllllllllllllIlIlIllIIIIIIlIIII, Random llllllllllllllIlIlIllIIIIIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIllIIlIIllI(isBurning))
    {
      EnumFacing llllllllllllllIlIlIllIIIIIIllIIl = (EnumFacing)llllllllllllllIlIlIllIIIIIIlIIII.getValue(FACING);
      double llllllllllllllIlIlIllIIIIIIllIII = llllllllllllllIlIlIllIIIIIIlllII.getX() + 0.5D;
      double llllllllllllllIlIlIllIIIIIIlIlll = llllllllllllllIlIlIllIIIIIIlllII.getY() + llllllllllllllIlIlIllIIIIIIIllll.nextDouble() * 6.0D / 16.0D;
      double llllllllllllllIlIlIllIIIIIIlIllI = llllllllllllllIlIlIllIIIIIIlllII.getZ() + 0.5D;
      double llllllllllllllIlIlIllIIIIIIlIlIl = 0.52D;
      double llllllllllllllIlIlIllIIIIIIlIlII = llllllllllllllIlIlIllIIIIIIIllll.nextDouble() * 0.6D - 0.3D;
      switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[llllllllllllllIlIlIllIIIIIIllIIl.ordinal()])
      {
      case 5: 
        llllllllllllllIlIlIllIIIIIIlllIl.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, llllllllllllllIlIlIllIIIIIIllIII - llllllllllllllIlIlIllIIIIIIlIlIl, llllllllllllllIlIlIllIIIIIIlIlll, llllllllllllllIlIlIllIIIIIIlIllI + llllllllllllllIlIlIllIIIIIIlIlII, 0.0D, 0.0D, 0.0D, new int[lIIIIlIllIllI[0]]);
        llllllllllllllIlIlIllIIIIIIlllIl.spawnParticle(EnumParticleTypes.FLAME, llllllllllllllIlIlIllIIIIIIllIII - llllllllllllllIlIlIllIIIIIIlIlIl, llllllllllllllIlIlIllIIIIIIlIlll, llllllllllllllIlIlIllIIIIIIlIllI + llllllllllllllIlIlIllIIIIIIlIlII, 0.0D, 0.0D, 0.0D, new int[lIIIIlIllIllI[0]]);
        "".length();
        if ("   ".length() != "   ".length()) {}
        break;
      case 6: 
        llllllllllllllIlIlIllIIIIIIlllIl.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, llllllllllllllIlIlIllIIIIIIllIII + llllllllllllllIlIlIllIIIIIIlIlIl, llllllllllllllIlIlIllIIIIIIlIlll, llllllllllllllIlIlIllIIIIIIlIllI + llllllllllllllIlIlIllIIIIIIlIlII, 0.0D, 0.0D, 0.0D, new int[lIIIIlIllIllI[0]]);
        llllllllllllllIlIlIllIIIIIIlllIl.spawnParticle(EnumParticleTypes.FLAME, llllllllllllllIlIlIllIIIIIIllIII + llllllllllllllIlIlIllIIIIIIlIlIl, llllllllllllllIlIlIllIIIIIIlIlll, llllllllllllllIlIlIllIIIIIIlIllI + llllllllllllllIlIlIllIIIIIIlIlII, 0.0D, 0.0D, 0.0D, new int[lIIIIlIllIllI[0]]);
        "".length();
        if ("  ".length() == 0) {}
        break;
      case 3: 
        llllllllllllllIlIlIllIIIIIIlllIl.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, llllllllllllllIlIlIllIIIIIIllIII + llllllllllllllIlIlIllIIIIIIlIlII, llllllllllllllIlIlIllIIIIIIlIlll, llllllllllllllIlIlIllIIIIIIlIllI - llllllllllllllIlIlIllIIIIIIlIlIl, 0.0D, 0.0D, 0.0D, new int[lIIIIlIllIllI[0]]);
        llllllllllllllIlIlIllIIIIIIlllIl.spawnParticle(EnumParticleTypes.FLAME, llllllllllllllIlIlIllIIIIIIllIII + llllllllllllllIlIlIllIIIIIIlIlII, llllllllllllllIlIlIllIIIIIIlIlll, llllllllllllllIlIlIllIIIIIIlIllI - llllllllllllllIlIlIllIIIIIIlIlIl, 0.0D, 0.0D, 0.0D, new int[lIIIIlIllIllI[0]]);
        "".length();
        if ("   ".length() < 0) {}
        break;
      case 4: 
        llllllllllllllIlIlIllIIIIIIlllIl.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, llllllllllllllIlIlIllIIIIIIllIII + llllllllllllllIlIlIllIIIIIIlIlII, llllllllllllllIlIlIllIIIIIIlIlll, llllllllllllllIlIlIllIIIIIIlIllI + llllllllllllllIlIlIllIIIIIIlIlIl, 0.0D, 0.0D, 0.0D, new int[lIIIIlIllIllI[0]]);
        llllllllllllllIlIlIllIIIIIIlllIl.spawnParticle(EnumParticleTypes.FLAME, llllllllllllllIlIlIllIIIIIIllIII + llllllllllllllIlIlIllIIIIIIlIlII, llllllllllllllIlIlIllIIIIIIlIlll, llllllllllllllIlIlIllIIIIIIlIllI + llllllllllllllIlIlIllIIIIIIlIlIl, 0.0D, 0.0D, 0.0D, new int[lIIIIlIllIllI[0]]);
      }
    }
  }
  
  private static void llIIllIIlIIIlI()
  {
    lIIIIlIllIlIl = new String[lIIIIlIllIllI[2]];
    lIIIIlIllIlIl[lIIIIlIllIllI[0]] = llIIllIIlIIIIl("NxInIyg2", "QsDJF");
  }
  
  public void onBlockAdded(World llllllllllllllIlIlIllIIIIlIIlIIl, BlockPos llllllllllllllIlIlIllIIIIlIIIlII, IBlockState llllllllllllllIlIlIllIIIIlIIIIll)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIlIlIllIIIIlIIIllI.setDefaultFacing(llllllllllllllIlIlIllIIIIlIIlIIl, llllllllllllllIlIlIllIIIIlIIIlII, llllllllllllllIlIlIllIIIIlIIIIll);
  }
  
  public void breakBlock(World llllllllllllllIlIlIlIllllIlllllI, BlockPos llllllllllllllIlIlIlIllllIllllIl, IBlockState llllllllllllllIlIlIlIllllIllllII)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIIllIIlIIlII(keepInventory))
    {
      TileEntity llllllllllllllIlIlIlIllllIlllIll = llllllllllllllIlIlIlIllllIlllllI.getTileEntity(llllllllllllllIlIlIlIllllIllllIl);
      if (llIIllIIlIIllI(llllllllllllllIlIlIlIllllIlllIll instanceof TileEntityFurnace))
      {
        InventoryHelper.dropInventoryItems(llllllllllllllIlIlIlIllllIlllllI, llllllllllllllIlIlIlIllllIllllIl, (TileEntityFurnace)llllllllllllllIlIlIlIllllIlllIll);
        llllllllllllllIlIlIlIllllIlllllI.updateComparatorOutputLevel(llllllllllllllIlIlIlIllllIllllIl, llllllllllllllIlIlIlIllllIllllll);
      }
    }
    llllllllllllllIlIlIlIllllIllllll.breakBlock(llllllllllllllIlIlIlIllllIlllllI, llllllllllllllIlIlIlIllllIllllIl, llllllllllllllIlIlIlIllllIllllII);
  }
  
  public IBlockState onBlockPlaced(World llllllllllllllIlIlIlIllllllIIIIl, BlockPos llllllllllllllIlIlIlIllllllIIIII, EnumFacing llllllllllllllIlIlIlIlllllIlllll, float llllllllllllllIlIlIlIlllllIllllI, float llllllllllllllIlIlIlIlllllIlllIl, float llllllllllllllIlIlIlIlllllIlllII, int llllllllllllllIlIlIlIlllllIllIll, EntityLivingBase llllllllllllllIlIlIlIlllllIllIlI)
  {
    ;
    ;
    return llllllllllllllIlIlIlIlllllIllIIl.getDefaultState().withProperty(FACING, llllllllllllllIlIlIlIlllllIllIlI.getHorizontalFacing().getOpposite());
  }
  
  public IBlockState getStateForEntityRender(IBlockState llllllllllllllIlIlIlIllllIlIIlll)
  {
    ;
    return llllllllllllllIlIlIlIllllIlIlIII.getDefaultState().withProperty(FACING, EnumFacing.SOUTH);
  }
  
  private static boolean llIIllIIlIIlII(int ???)
  {
    String llllllllllllllIlIlIlIlllIllIlllI;
    return ??? == 0;
  }
  
  private void setDefaultFacing(World llllllllllllllIlIlIllIIIIIlllIIl, BlockPos llllllllllllllIlIlIllIIIIIlllIII, IBlockState llllllllllllllIlIlIllIIIIIlIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIllIIlIIlII(isRemote))
    {
      Block llllllllllllllIlIlIllIIIIIllIllI = llllllllllllllIlIlIllIIIIIlllIIl.getBlockState(llllllllllllllIlIlIllIIIIIllIIII.north()).getBlock();
      Block llllllllllllllIlIlIllIIIIIllIlIl = llllllllllllllIlIlIllIIIIIlllIIl.getBlockState(llllllllllllllIlIlIllIIIIIllIIII.south()).getBlock();
      Block llllllllllllllIlIlIllIIIIIllIlII = llllllllllllllIlIlIllIIIIIlllIIl.getBlockState(llllllllllllllIlIlIllIIIIIllIIII.west()).getBlock();
      Block llllllllllllllIlIlIllIIIIIllIIll = llllllllllllllIlIlIllIIIIIlllIIl.getBlockState(llllllllllllllIlIlIllIIIIIllIIII.east()).getBlock();
      EnumFacing llllllllllllllIlIlIllIIIIIllIIlI = (EnumFacing)llllllllllllllIlIlIllIIIIIlIllll.getValue(FACING);
      if ((llIIllIIlIIlIl(llllllllllllllIlIlIllIIIIIllIIlI, EnumFacing.NORTH)) && (llIIllIIlIIllI(llllllllllllllIlIlIllIIIIIllIllI.isFullBlock())) && (llIIllIIlIIlII(llllllllllllllIlIlIllIIIIIllIlIl.isFullBlock())))
      {
        llllllllllllllIlIlIllIIIIIllIIlI = EnumFacing.SOUTH;
        "".length();
        if (((0x34 ^ 0x15) & (0x42 ^ 0x63 ^ 0xFFFFFFFF)) <= ((0x76 ^ 0x4F) & (0x87 ^ 0xBE ^ 0xFFFFFFFF))) {}
      }
      else if ((llIIllIIlIIlIl(llllllllllllllIlIlIllIIIIIllIIlI, EnumFacing.SOUTH)) && (llIIllIIlIIllI(llllllllllllllIlIlIllIIIIIllIlIl.isFullBlock())) && (llIIllIIlIIlII(llllllllllllllIlIlIllIIIIIllIllI.isFullBlock())))
      {
        llllllllllllllIlIlIllIIIIIllIIlI = EnumFacing.NORTH;
        "".length();
        if (-(82 + 21 - 39 + 70 ^ 46 + 11 - -20 + 53) <= 0) {}
      }
      else if ((llIIllIIlIIlIl(llllllllllllllIlIlIllIIIIIllIIlI, EnumFacing.WEST)) && (llIIllIIlIIllI(llllllllllllllIlIlIllIIIIIllIlII.isFullBlock())) && (llIIllIIlIIlII(llllllllllllllIlIlIllIIIIIllIIll.isFullBlock())))
      {
        llllllllllllllIlIlIllIIIIIllIIlI = EnumFacing.EAST;
        "".length();
        if ((0x4A ^ 0x4E) == (0x8C ^ 0x88)) {}
      }
      else if ((llIIllIIlIIlIl(llllllllllllllIlIlIllIIIIIllIIlI, EnumFacing.EAST)) && (llIIllIIlIIllI(llllllllllllllIlIlIllIIIIIllIIll.isFullBlock())) && (llIIllIIlIIlII(llllllllllllllIlIlIllIIIIIllIlII.isFullBlock())))
      {
        llllllllllllllIlIlIllIIIIIllIIlI = EnumFacing.WEST;
      }
      "".length();
    }
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIlIlIlIllllIlIIIIl)
  {
    ;
    ;
    ;
    EnumFacing llllllllllllllIlIlIlIllllIlIIIII = EnumFacing.getFront(llllllllllllllIlIlIlIllllIlIIIIl);
    if (llIIllIIlIIlIl(llllllllllllllIlIlIlIllllIlIIIII.getAxis(), EnumFacing.Axis.Y)) {
      llllllllllllllIlIlIlIllllIlIIIII = EnumFacing.NORTH;
    }
    return llllllllllllllIlIlIlIllllIIlllll.getDefaultState().withProperty(FACING, llllllllllllllIlIlIlIllllIlIIIII);
  }
  
  public static void setState(boolean llllllllllllllIlIlIlIllllllIllII, World llllllllllllllIlIlIlIlllllllIIII, BlockPos llllllllllllllIlIlIlIllllllIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllIlIlIlIllllllIlllI = llllllllllllllIlIlIlIlllllllIIII.getBlockState(llllllllllllllIlIlIlIllllllIlIlI);
    TileEntity llllllllllllllIlIlIlIllllllIllIl = llllllllllllllIlIlIlIllllllIlIll.getTileEntity(llllllllllllllIlIlIlIllllllIlIlI);
    keepInventory = lIIIIlIllIllI[2];
    if (llIIllIIlIIllI(llllllllllllllIlIlIlIllllllIllII))
    {
      "".length();
      "".length();
      "".length();
      if (-" ".length() <= -" ".length()) {}
    }
    else
    {
      "".length();
      "".length();
    }
    keepInventory = lIIIIlIllIllI[0];
    if (llIIllIIlIIlll(llllllllllllllIlIlIlIllllllIllIl))
    {
      llllllllllllllIlIlIlIllllllIllIl.validate();
      llllllllllllllIlIlIlIllllllIlIll.setTileEntity(llllllllllllllIlIlIlIllllllIlIlI, llllllllllllllIlIlIlIllllllIllIl);
    }
  }
  
  private static void llIIllIIlIIIll()
  {
    lIIIIlIllIllI = new int[7];
    lIIIIlIllIllI[0] = ((0x4A ^ 0x42) & (0x93 ^ 0x9B ^ 0xFFFFFFFF));
    lIIIIlIllIllI[1] = "  ".length();
    lIIIIlIllIllI[2] = " ".length();
    lIIIIlIllIllI[3] = "   ".length();
    lIIIIlIllIllI[4] = (0x8C ^ 0x8A);
    lIIIIlIllIllI[5] = (0x1C ^ 0x54 ^ 0x72 ^ 0x3E);
    lIIIIlIllIllI[6] = (0xE ^ 0xB);
  }
  
  private static boolean llIIllIIlIIlll(Object ???)
  {
    float llllllllllllllIlIlIlIlllIlllIIlI;
    return ??? != null;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIlIlIlIllllIIlIllI, new IProperty[] { FACING });
  }
  
  private static String llIIllIIlIIIIl(String llllllllllllllIlIlIlIllllIIIlIIl, String llllllllllllllIlIlIlIllllIIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIlIlIllllIIIlIIl = new String(Base64.getDecoder().decode(llllllllllllllIlIlIlIllllIIIlIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIlIlIllllIIIIlll = new StringBuilder();
    char[] llllllllllllllIlIlIlIllllIIIIllI = llllllllllllllIlIlIlIllllIIIIIll.toCharArray();
    int llllllllllllllIlIlIlIllllIIIIlIl = lIIIIlIllIllI[0];
    String llllllllllllllIlIlIlIlllIlllllll = llllllllllllllIlIlIlIllllIIIlIIl.toCharArray();
    double llllllllllllllIlIlIlIlllIllllllI = llllllllllllllIlIlIlIlllIlllllll.length;
    Exception llllllllllllllIlIlIlIlllIlllllIl = lIIIIlIllIllI[0];
    while (llIIllIIlIlIII(llllllllllllllIlIlIlIlllIlllllIl, llllllllllllllIlIlIlIlllIllllllI))
    {
      char llllllllllllllIlIlIlIllllIIIlIlI = llllllllllllllIlIlIlIlllIlllllll[llllllllllllllIlIlIlIlllIlllllIl];
      "".length();
      "".length();
      if ((0x1D ^ 0x19) == 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIlIlIllllIIIIlll);
  }
  
  public int getRenderType()
  {
    return lIIIIlIllIllI[3];
  }
  
  static
  {
    llIIllIIlIIIll();
    llIIllIIlIIIlI();
  }
  
  public boolean onBlockActivated(World llllllllllllllIlIlIllIIIIIIIIIll, BlockPos llllllllllllllIlIlIllIIIIIIIIIlI, IBlockState llllllllllllllIlIlIllIIIIIIIIIIl, EntityPlayer llllllllllllllIlIlIlIllllllllIII, EnumFacing llllllllllllllIlIlIlIlllllllllll, float llllllllllllllIlIlIlIllllllllllI, float llllllllllllllIlIlIlIlllllllllIl, float llllllllllllllIlIlIlIlllllllllII)
  {
    ;
    ;
    ;
    ;
    if (llIIllIIlIIllI(isRemote)) {
      return lIIIIlIllIllI[2];
    }
    TileEntity llllllllllllllIlIlIlIllllllllIll = llllllllllllllIlIlIllIIIIIIIIIll.getTileEntity(llllllllllllllIlIlIllIIIIIIIIIlI);
    if (llIIllIIlIIllI(llllllllllllllIlIlIlIllllllllIll instanceof TileEntityFurnace))
    {
      llllllllllllllIlIlIlIllllllllIII.displayGUIChest((TileEntityFurnace)llllllllllllllIlIlIlIllllllllIll);
      llllllllllllllIlIlIlIllllllllIII.triggerAchievement(StatList.field_181741_Y);
    }
    return lIIIIlIllIllI[2];
  }
  
  private static boolean llIIllIIlIlIII(int ???, int arg1)
  {
    int i;
    String llllllllllllllIlIlIlIlllIllllIII;
    return ??? < i;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIlIlIlIllllIIllIIl)
  {
    ;
    return ((EnumFacing)llllllllllllllIlIlIlIllllIIllIIl.getValue(FACING)).getIndex();
  }
  
  public int getComparatorInputOverride(World llllllllllllllIlIlIlIllllIlIllll, BlockPos llllllllllllllIlIlIlIllllIlIlllI)
  {
    ;
    ;
    return Container.calcRedstone(llllllllllllllIlIlIlIllllIlIllll.getTileEntity(llllllllllllllIlIlIlIllllIlIlllI));
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIlIlIllIIIIlIlIIIl, Random llllllllllllllIlIlIllIIIIlIlIIII, int llllllllllllllIlIlIllIIIIlIIllll)
  {
    return Item.getItemFromBlock(Blocks.furnace);
  }
  
  public void onBlockPlacedBy(World llllllllllllllIlIlIlIlllllIlIIII, BlockPos llllllllllllllIlIlIlIlllllIIllll, IBlockState llllllllllllllIlIlIlIlllllIIlllI, EntityLivingBase llllllllllllllIlIlIlIlllllIIIlll, ItemStack llllllllllllllIlIlIlIlllllIIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    "".length();
    if (llIIllIIlIIllI(llllllllllllllIlIlIlIlllllIIIllI.hasDisplayName()))
    {
      TileEntity llllllllllllllIlIlIlIlllllIIlIll = llllllllllllllIlIlIlIlllllIlIIII.getTileEntity(llllllllllllllIlIlIlIlllllIIllll);
      if (llIIllIIlIIllI(llllllllllllllIlIlIlIlllllIIlIll instanceof TileEntityFurnace)) {
        ((TileEntityFurnace)llllllllllllllIlIlIlIlllllIIlIll).setCustomInventoryName(llllllllllllllIlIlIlIlllllIIIllI.getDisplayName());
      }
    }
  }
  
  private static boolean llIIllIIlIIlIl(Object ???, Object arg1)
  {
    Object localObject;
    short llllllllllllllIlIlIlIlllIlllIlII;
    return ??? == localObject;
  }
  
  protected BlockFurnace(boolean llllllllllllllIlIlIllIIIIlIlIlIl)
  {
    llllllllllllllIlIlIllIIIIlIlIlII.<init>(Material.rock);
    llllllllllllllIlIlIllIIIIlIlIlII.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH));
    isBurning = llllllllllllllIlIlIllIIIIlIlIlIl;
  }
  
  public Item getItem(World llllllllllllllIlIlIlIllllIlIllII, BlockPos llllllllllllllIlIlIlIllllIlIlIll)
  {
    return Item.getItemFromBlock(Blocks.furnace);
  }
}

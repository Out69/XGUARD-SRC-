package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityPiston;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockPistonMoving
  extends BlockContainer
{
  public boolean canPlaceBlockAt(World llllllllllllllIllIIllIIIlIIlllII, BlockPos llllllllllllllIllIIllIIIlIIllIll)
  {
    return lllllIIlllIl[0];
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIllIIllIIIIllIIlIl, Random llllllllllllllIllIIllIIIIllIIlII, int llllllllllllllIllIIllIIIIllIIIll)
  {
    return null;
  }
  
  public MovingObjectPosition collisionRayTrace(World llllllllllllllIllIIllIIIIlIIllll, BlockPos llllllllllllllIllIIllIIIIlIIlllI, Vec3 llllllllllllllIllIIllIIIIlIIllIl, Vec3 llllllllllllllIllIIllIIIIlIIllII)
  {
    return null;
  }
  
  private static boolean lIlllllIlIIIll(int ???)
  {
    Exception llllllllllllllIllIIlIllllIIIlIII;
    return ??? > 0;
  }
  
  static {}
  
  public void breakBlock(World llllllllllllllIllIIllIIIlIlIIIIl, BlockPos llllllllllllllIllIIllIIIlIlIIlIl, IBlockState llllllllllllllIllIIllIIIlIlIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    TileEntity llllllllllllllIllIIllIIIlIlIIIll = llllllllllllllIllIIllIIIlIlIIIIl.getTileEntity(llllllllllllllIllIIllIIIlIlIIlIl);
    if (lIlllllIIlIIlI(llllllllllllllIllIIllIIIlIlIIIll instanceof TileEntityPiston))
    {
      ((TileEntityPiston)llllllllllllllIllIIllIIIlIlIIIll).clearPistonTileEntity();
      "".length();
      if (-"  ".length() <= 0) {}
    }
    else
    {
      llllllllllllllIllIIllIIIlIlIIIlI.breakBlock(llllllllllllllIllIIllIIIlIlIIIIl, llllllllllllllIllIIllIIIlIlIIlIl, llllllllllllllIllIIllIIIlIlIIlII);
    }
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIllIIllIIIIIlIlIII, BlockPos llllllllllllllIllIIllIIIIIlIllIl, IBlockState llllllllllllllIllIIllIIIIIlIllII)
  {
    ;
    ;
    ;
    ;
    ;
    TileEntityPiston llllllllllllllIllIIllIIIIIlIlIll = llllllllllllllIllIIllIIIIIlIlIIl.getTileEntity(llllllllllllllIllIIllIIIIIlIlIII, llllllllllllllIllIIllIIIIIlIllIl);
    if (lIlllllIIlIlII(llllllllllllllIllIIllIIIIIlIlIll)) {
      return null;
    }
    float llllllllllllllIllIIllIIIIIlIlIlI = llllllllllllllIllIIllIIIIIlIlIll.getProgress(0.0F);
    if (lIlllllIIlIIlI(llllllllllllllIllIIllIIIIIlIlIll.isExtending())) {
      llllllllllllllIllIIllIIIIIlIlIlI = 1.0F - llllllllllllllIllIIllIIIIIlIlIlI;
    }
    return llllllllllllllIllIIllIIIIIlIlIIl.getBoundingBox(llllllllllllllIllIIllIIIIIlIlIII, llllllllllllllIllIIllIIIIIlIllIl, llllllllllllllIllIIllIIIIIlIlIll.getPistonState(), llllllllllllllIllIIllIIIIIlIlIlI, llllllllllllllIllIIllIIIIIlIlIll.getFacing());
  }
  
  public boolean onBlockActivated(World llllllllllllllIllIIllIIIIlllIIII, BlockPos llllllllllllllIllIIllIIIIllIllll, IBlockState llllllllllllllIllIIllIIIIllIlllI, EntityPlayer llllllllllllllIllIIllIIIIllIllIl, EnumFacing llllllllllllllIllIIllIIIIllIllII, float llllllllllllllIllIIllIIIIllIlIll, float llllllllllllllIllIIllIIIIllIlIlI, float llllllllllllllIllIIllIIIIllIlIIl)
  {
    ;
    ;
    if ((lIlllllIIlIIll(isRemote)) && (lIlllllIIlIlII(llllllllllllllIllIIllIIIIlllIIII.getTileEntity(llllllllllllllIllIIllIIIIllIllll))))
    {
      "".length();
      return lllllIIlllIl[1];
    }
    return lllllIIlllIl[0];
  }
  
  private static boolean lIlllllIIlIlll(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllIllIIlIllllIIllIII;
    return ??? != localObject;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIllIIlIllllIlIIIlI)
  {
    ;
    ;
    int llllllllllllllIllIIlIllllIlIIIIl = lllllIIlllIl[0];
    llllllllllllllIllIIlIllllIlIIIIl |= ((EnumFacing)llllllllllllllIllIIlIllllIlIIIII.getValue(FACING)).getIndex();
    if (lIlllllIIllIII(llllllllllllllIllIIlIllllIlIIIII.getValue(TYPE), BlockPistonExtension.EnumPistonType.STICKY)) {
      llllllllllllllIllIIlIllllIlIIIIl |= lllllIIlllIl[2];
    }
    return llllllllllllllIllIIlIllllIlIIIIl;
  }
  
  private static boolean lIlllllIIllIII(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllIllIIlIllllIIlIIlI;
    return ??? == localObject;
  }
  
  public BlockPistonMoving()
  {
    llllllllllllllIllIIllIIIlIllllII.<init>(Material.piston);
    llllllllllllllIllIIllIIIlIllllIl.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(TYPE, BlockPistonExtension.EnumPistonType.DEFAULT));
    "".length();
  }
  
  public boolean canPlaceBlockOnSide(World llllllllllllllIllIIllIIIlIIllIIl, BlockPos llllllllllllllIllIIllIIIlIIllIII, EnumFacing llllllllllllllIllIIllIIIlIIlIlll)
  {
    return lllllIIlllIl[0];
  }
  
  private static boolean lIlllllIlIIIlI(int ???)
  {
    int llllllllllllllIllIIlIllllIIIlIlI;
    return ??? < 0;
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIllIIlIllllIlIlIII)
  {
    ;
    ;
    if (lIlllllIlIIIll(llllllllllllllIllIIlIllllIlIlIII & lllllIIlllIl[2]))
    {
      "".length();
      if (-" ".length() < (0xAC ^ 0xA8)) {
        break label63;
      }
      return null;
    }
    label63:
    return TYPE.withProperty(BlockPistonExtension.EnumPistonType.STICKY, BlockPistonExtension.EnumPistonType.DEFAULT);
  }
  
  private static boolean lIlllllIIlIIll(int ???)
  {
    long llllllllllllllIllIIlIllllIIIllII;
    return ??? == 0;
  }
  
  private static boolean lIlllllIIlIlIl(Object ???)
  {
    int llllllllllllllIllIIlIllllIIlIllI;
    return ??? != null;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIllIIlIllllIIlllII, new IProperty[] { FACING, TYPE });
  }
  
  private static boolean lIlllllIIlIlII(Object ???)
  {
    String llllllllllllllIllIIlIllllIIlIIII;
    return ??? == null;
  }
  
  public void onBlockDestroyedByPlayer(World llllllllllllllIllIIllIIIlIIIIlII, BlockPos llllllllllllllIllIIllIIIlIIIlIIl, IBlockState llllllllllllllIllIIllIIIlIIIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    BlockPos llllllllllllllIllIIllIIIlIIIIlll = llllllllllllllIllIIllIIIlIIIlIIl.offset(((EnumFacing)llllllllllllllIllIIllIIIlIIIlIII.getValue(FACING)).getOpposite());
    IBlockState llllllllllllllIllIIllIIIlIIIIllI = llllllllllllllIllIIllIIIlIIIIlII.getBlockState(llllllllllllllIllIIllIIIlIIIIlll);
    if ((lIlllllIIlIIlI(llllllllllllllIllIIllIIIlIIIIllI.getBlock() instanceof BlockPistonBase)) && (lIlllllIIlIIlI(((Boolean)llllllllllllllIllIIllIIIlIIIIllI.getValue(BlockPistonBase.EXTENDED)).booleanValue()))) {
      "".length();
    }
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIllIIllIIIIIIIIlIl, BlockPos llllllllllllllIllIIlIllllllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    TileEntityPiston llllllllllllllIllIIllIIIIIIIIIll = llllllllllllllIllIIllIIIIIIIIllI.getTileEntity(llllllllllllllIllIIlIllllllllIIl, llllllllllllllIllIIlIllllllllIII);
    if (lIlllllIIlIlIl(llllllllllllllIllIIllIIIIIIIIIll))
    {
      IBlockState llllllllllllllIllIIllIIIIIIIIIlI = llllllllllllllIllIIllIIIIIIIIIll.getPistonState();
      Block llllllllllllllIllIIllIIIIIIIIIII = llllllllllllllIllIIllIIIIIIIIIlI.getBlock();
      if ((!lIlllllIIlIlll(llllllllllllllIllIIllIIIIIIIIIII, llllllllllllllIllIIllIIIIIIIIllI)) || (lIlllllIIllIII(llllllllllllllIllIIllIIIIIIIIIII.getMaterial(), Material.air))) {
        return;
      }
      float llllllllllllllIllIIlIllllllllllI = llllllllllllllIllIIllIIIIIIIIIll.getProgress(0.0F);
      if (lIlllllIIlIIlI(llllllllllllllIllIIllIIIIIIIIIll.isExtending())) {
        llllllllllllllIllIIlIllllllllllI = 1.0F - llllllllllllllIllIIlIllllllllllI;
      }
      llllllllllllllIllIIllIIIIIIIIIII.setBlockBoundsBasedOnState(llllllllllllllIllIIlIllllllllIIl, llllllllllllllIllIIlIllllllllIII);
      if ((!lIlllllIIlIlll(llllllllllllllIllIIllIIIIIIIIIII, Blocks.piston)) || (lIlllllIIllIII(llllllllllllllIllIIllIIIIIIIIIII, Blocks.sticky_piston))) {
        llllllllllllllIllIIlIllllllllllI = 0.0F;
      }
      EnumFacing llllllllllllllIllIIlIlllllllllIl = llllllllllllllIllIIllIIIIIIIIIll.getFacing();
      minX = (llllllllllllllIllIIllIIIIIIIIIII.getBlockBoundsMinX() - llllllllllllllIllIIlIlllllllllIl.getFrontOffsetX() * llllllllllllllIllIIlIllllllllllI);
      minY = (llllllllllllllIllIIllIIIIIIIIIII.getBlockBoundsMinY() - llllllllllllllIllIIlIlllllllllIl.getFrontOffsetY() * llllllllllllllIllIIlIllllllllllI);
      minZ = (llllllllllllllIllIIllIIIIIIIIIII.getBlockBoundsMinZ() - llllllllllllllIllIIlIlllllllllIl.getFrontOffsetZ() * llllllllllllllIllIIlIllllllllllI);
      maxX = (llllllllllllllIllIIllIIIIIIIIIII.getBlockBoundsMaxX() - llllllllllllllIllIIlIlllllllllIl.getFrontOffsetX() * llllllllllllllIllIIlIllllllllllI);
      maxY = (llllllllllllllIllIIllIIIIIIIIIII.getBlockBoundsMaxY() - llllllllllllllIllIIlIlllllllllIl.getFrontOffsetY() * llllllllllllllIllIIlIllllllllllI);
      maxZ = (llllllllllllllIllIIllIIIIIIIIIII.getBlockBoundsMaxZ() - llllllllllllllIllIIlIlllllllllIl.getFrontOffsetZ() * llllllllllllllIllIIlIllllllllllI);
    }
  }
  
  private static boolean lIlllllIIlIIlI(int ???)
  {
    float llllllllllllllIllIIlIllllIIIlllI;
    return ??? != 0;
  }
  
  public boolean isOpaqueCube()
  {
    return lllllIIlllIl[0];
  }
  
  private static void lIlllllIIlIIIl()
  {
    lllllIIlllIl = new int[4];
    lllllIIlllIl[0] = ("   ".length() & ("   ".length() ^ -" ".length()));
    lllllIIlllIl[1] = " ".length();
    lllllIIlllIl[2] = (0x5F ^ 0x57);
    lllllIIlllIl[3] = "  ".length();
  }
  
  public static TileEntity newTileEntity(IBlockState llllllllllllllIllIIllIIIlIllIlII, EnumFacing llllllllllllllIllIIllIIIlIllIIll, boolean llllllllllllllIllIIllIIIlIllIIlI, boolean llllllllllllllIllIIllIIIlIllIIIl)
  {
    ;
    ;
    ;
    ;
    return new TileEntityPiston(llllllllllllllIllIIllIIIlIllIlII, llllllllllllllIllIIllIIIlIllIIll, llllllllllllllIllIIllIIIlIllIIlI, llllllllllllllIllIIllIIIlIllIIIl);
  }
  
  public AxisAlignedBB getBoundingBox(World llllllllllllllIllIIlIlllllIlllIl, BlockPos llllllllllllllIllIIlIlllllIIllll, IBlockState llllllllllllllIllIIlIlllllIIlllI, float llllllllllllllIllIIlIlllllIllIlI, EnumFacing llllllllllllllIllIIlIlllllIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIlllllIIlIlll(llllllllllllllIllIIlIlllllIIlllI.getBlock(), llllllllllllllIllIIlIlllllIlIIIl)) && (lIlllllIIlIlll(llllllllllllllIllIIlIlllllIIlllI.getBlock().getMaterial(), Material.air)))
    {
      AxisAlignedBB llllllllllllllIllIIlIlllllIllIII = llllllllllllllIllIIlIlllllIIlllI.getBlock().getCollisionBoundingBox(llllllllllllllIllIIlIlllllIlllIl, llllllllllllllIllIIlIlllllIIllll, llllllllllllllIllIIlIlllllIIlllI);
      if (lIlllllIIlIlII(llllllllllllllIllIIlIlllllIllIII)) {
        return null;
      }
      double llllllllllllllIllIIlIlllllIlIlll = minX;
      double llllllllllllllIllIIlIlllllIlIllI = minY;
      double llllllllllllllIllIIlIlllllIlIlIl = minZ;
      double llllllllllllllIllIIlIlllllIlIlII = maxX;
      double llllllllllllllIllIIlIlllllIlIIll = maxY;
      double llllllllllllllIllIIlIlllllIlIIlI = maxZ;
      if (lIlllllIlIIIlI(llllllllllllllIllIIlIlllllIllIIl.getFrontOffsetX()))
      {
        llllllllllllllIllIIlIlllllIlIlll -= llllllllllllllIllIIlIlllllIllIIl.getFrontOffsetX() * llllllllllllllIllIIlIlllllIllIlI;
        "".length();
        if ((0x8A ^ 0x8E) < -" ".length()) {
          return null;
        }
      }
      else
      {
        llllllllllllllIllIIlIlllllIlIlII -= llllllllllllllIllIIlIlllllIllIIl.getFrontOffsetX() * llllllllllllllIllIIlIlllllIllIlI;
      }
      if (lIlllllIlIIIlI(llllllllllllllIllIIlIlllllIllIIl.getFrontOffsetY()))
      {
        llllllllllllllIllIIlIlllllIlIllI -= llllllllllllllIllIIlIlllllIllIIl.getFrontOffsetY() * llllllllllllllIllIIlIlllllIllIlI;
        "".length();
        if (null != null) {
          return null;
        }
      }
      else
      {
        llllllllllllllIllIIlIlllllIlIIll -= llllllllllllllIllIIlIlllllIllIIl.getFrontOffsetY() * llllllllllllllIllIIlIlllllIllIlI;
      }
      if (lIlllllIlIIIlI(llllllllllllllIllIIlIlllllIllIIl.getFrontOffsetZ()))
      {
        llllllllllllllIllIIlIlllllIlIlIl -= llllllllllllllIllIIlIlllllIllIIl.getFrontOffsetZ() * llllllllllllllIllIIlIlllllIllIlI;
        "".length();
        if ("  ".length() != "  ".length()) {
          return null;
        }
      }
      else
      {
        llllllllllllllIllIIlIlllllIlIIlI -= llllllllllllllIllIIlIlllllIllIIl.getFrontOffsetZ() * llllllllllllllIllIIlIlllllIllIlI;
      }
      return new AxisAlignedBB(llllllllllllllIllIIlIlllllIlIlll, llllllllllllllIllIIlIlllllIlIllI, llllllllllllllIllIIlIlllllIlIlIl, llllllllllllllIllIIlIlllllIlIlII, llllllllllllllIllIIlIlllllIlIIll, llllllllllllllIllIIlIlllllIlIIlI);
    }
    return null;
  }
  
  public Item getItem(World llllllllllllllIllIIlIllllIlIllll, BlockPos llllllllllllllIllIIlIllllIlIlllI)
  {
    return null;
  }
  
  private TileEntityPiston getTileEntity(IBlockAccess llllllllllllllIllIIlIllllIllIlII, BlockPos llllllllllllllIllIIlIllllIllIllI)
  {
    ;
    ;
    ;
    TileEntity llllllllllllllIllIIlIllllIllIlIl = llllllllllllllIllIIlIllllIllIlII.getTileEntity(llllllllllllllIllIIlIllllIllIllI);
    if (lIlllllIIlIIlI(llllllllllllllIllIIlIllllIllIlIl instanceof TileEntityPiston))
    {
      "".length();
      if ("   ".length() >= 0) {
        break label40;
      }
      return null;
    }
    label40:
    return null;
  }
  
  public boolean isFullCube()
  {
    return lllllIIlllIl[0];
  }
  
  public TileEntity createNewTileEntity(World llllllllllllllIllIIllIIIlIlllIlI, int llllllllllllllIllIIllIIIlIlllIIl)
  {
    return null;
  }
  
  public void dropBlockAsItemWithChance(World llllllllllllllIllIIllIIIIlIlIlII, BlockPos llllllllllllllIllIIllIIIIlIllIll, IBlockState llllllllllllllIllIIllIIIIlIllIlI, float llllllllllllllIllIIllIIIIlIllIIl, int llllllllllllllIllIIllIIIIlIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIlllllIIlIIll(isRemote))
    {
      TileEntityPiston llllllllllllllIllIIllIIIIlIlIlll = llllllllllllllIllIIllIIIIlIlIlIl.getTileEntity(llllllllllllllIllIIllIIIIlIlIlII, llllllllllllllIllIIllIIIIlIllIll);
      if (lIlllllIIlIlIl(llllllllllllllIllIIllIIIIlIlIlll))
      {
        IBlockState llllllllllllllIllIIllIIIIlIlIllI = llllllllllllllIllIIllIIIIlIlIlll.getPistonState();
        llllllllllllllIllIIllIIIIlIlIllI.getBlock().dropBlockAsItem(llllllllllllllIllIIllIIIIlIlIlII, llllllllllllllIllIIllIIIIlIllIll, llllllllllllllIllIIllIIIIlIlIllI, lllllIIlllIl[0]);
      }
    }
  }
  
  public void onNeighborBlockChange(World llllllllllllllIllIIllIIIIlIIIIll, BlockPos llllllllllllllIllIIllIIIIlIIIlll, IBlockState llllllllllllllIllIIllIIIIlIIIllI, Block llllllllllllllIllIIllIIIIlIIIlIl)
  {
    ;
    ;
    if (lIlllllIIlIIll(isRemote)) {
      "".length();
    }
  }
}

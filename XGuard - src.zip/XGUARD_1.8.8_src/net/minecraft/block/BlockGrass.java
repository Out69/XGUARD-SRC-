package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.ColorizerGrass;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeColorHelper;
import net.minecraft.world.biome.BiomeGenBase;

public class BlockGrass
  extends Block
  implements IGrowable
{
  private static boolean lllIlI(int ???, int arg1)
  {
    int i;
    byte lllllIlIlIIIIll;
    return ??? > i;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllIlIllIIIIl, new IProperty[] { SNOWY });
  }
  
  public Item getItemDropped(IBlockState lllllIllIIlIlIl, Random lllllIllIIlIIlI, int lllllIllIIlIIIl)
  {
    ;
    ;
    return Blocks.dirt.getItemDropped(Blocks.dirt.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.DIRT), lllllIllIIlIIlI, lllllIllIIlIIIl);
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT_MIPPED;
  }
  
  public void updateTick(World lllllIllIIlllll, BlockPos lllllIllIIllllI, IBlockState lllllIllIlIIlIl, Random lllllIllIIlllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIII(isRemote)) {
      if ((lllIIl(lllllIllIIlllll.getLightFromNeighbors(lllllIllIIllllI.up()), llll[2])) && (lllIlI(lllllIllIIlllll.getBlockState(lllllIllIIllllI.up()).getBlock().getLightOpacity(), llll[3])))
      {
        "".length();
        "".length();
        if (((92 + 38 - -97 + 17 ^ 38 + 98 - 86 + 118) & (0x6D ^ 0x1A ^ 0x35 ^ 0x1E ^ -" ".length())) == 0) {}
      }
      else if (lllIll(lllllIllIIlllll.getLightFromNeighbors(lllllIllIIllllI.up()), llll[4]))
      {
        int lllllIllIlIIIll = llll[0];
        "".length();
        if (-" ".length() > 0) {
          return;
        }
        while (!lllIll(lllllIllIlIIIll, llll[2]))
        {
          BlockPos lllllIllIlIIIlI = lllllIllIIllllI.add(lllllIllIIlllIl.nextInt(llll[5]) - llll[1], lllllIllIIlllIl.nextInt(llll[6]) - llll[5], lllllIllIIlllIl.nextInt(llll[5]) - llll[1]);
          Block lllllIllIlIIIIl = lllllIllIIlllll.getBlockState(lllllIllIlIIIlI.up()).getBlock();
          IBlockState lllllIllIlIIIII = lllllIllIIlllll.getBlockState(lllllIllIlIIIlI);
          if ((llllII(lllllIllIlIIIII.getBlock(), Blocks.dirt)) && (llllII(lllllIllIlIIIII.getValue(BlockDirt.VARIANT), BlockDirt.DirtType.DIRT)) && (lllIll(lllllIllIIlllll.getLightFromNeighbors(lllllIllIlIIIlI.up()), llll[2])) && (llllIl(lllllIllIlIIIIl.getLightOpacity(), llll[3]))) {
            "".length();
          }
          lllllIllIlIIIll++;
        }
      }
    }
  }
  
  public int getRenderColor(IBlockState lllllIllIlllIIl)
  {
    ;
    return lllllIllIlllIII.getBlockColor();
  }
  
  private static boolean llllIl(int ???, int arg1)
  {
    int i;
    char lllllIlIlIIIlll;
    return ??? <= i;
  }
  
  private static boolean llIlll(Object ???, Object arg1)
  {
    Object localObject;
    String lllllIlIIllllll;
    return ??? != localObject;
  }
  
  public int colorMultiplier(IBlockAccess lllllIllIllIlII, BlockPos lllllIllIllIIll, int lllllIllIllIIlI)
  {
    ;
    ;
    return BiomeColorHelper.getGrassColorAtPos(lllllIllIllIlII, lllllIllIllIIII);
  }
  
  public int getBlockColor()
  {
    return ColorizerGrass.getGrassColor(0.5D, 1.0D);
  }
  
  private static void llIlIl()
  {
    lllI = new String[llll[1]];
    lllI[llll[0]] = llIlII("a6wHrESjyaI=", "LtpOd");
  }
  
  private static String llIlII(String lllllIlIlIllIII, String lllllIlIlIlIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllIlIlIllIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllIlIlIlIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllIlIlIllIlI = Cipher.getInstance("Blowfish");
      lllllIlIlIllIlI.init(llll[3], lllllIlIlIllIll);
      return new String(lllllIlIlIllIlI.doFinal(Base64.getDecoder().decode(lllllIlIlIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllIlIlIllIIl)
    {
      lllllIlIlIllIIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIll(int ???, int arg1)
  {
    int i;
    double lllllIlIlIIllll;
    return ??? >= i;
  }
  
  public void grow(World lllllIlIllIllll, Random lllllIlIllIlllI, BlockPos lllllIlIllllIIl, IBlockState lllllIlIllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    BlockPos lllllIlIlllIlll = lllllIlIllllIIl.up();
    int lllllIlIlllIllI = llll[0];
    "".length();
    if (((0xC4 ^ 0xC2) & (0x6D ^ 0x6B ^ 0xFFFFFFFF)) != 0) {
      return;
    }
    while (!lllIll(lllllIlIlllIllI, llll[9]))
    {
      BlockPos lllllIlIlllIlIl = lllllIlIlllIlll;
      int lllllIlIlllIlII = llll[0];
      do
      {
        if (lllIll(lllllIlIlllIlII, lllllIlIlllIllI / llll[7]))
        {
          if (!llllII(getBlockStategetBlockblockMaterial, Material.air)) {
            break;
          }
          if (lllIII(lllllIlIllIlllI.nextInt(llll[8])))
          {
            BlockFlower.EnumFlowerType lllllIlIlllIIll = lllllIlIllIllll.getBiomeGenForCoords(lllllIlIlllIlIl).pickRandomFlower(lllllIlIllIlllI, lllllIlIlllIlIl);
            BlockFlower lllllIlIlllIIlI = lllllIlIlllIIll.getBlockType().getBlock();
            IBlockState lllllIlIlllIIIl = lllllIlIlllIIlI.getDefaultState().withProperty(lllllIlIlllIIlI.getTypeProperty(), lllllIlIlllIIll);
            if (!lllllI(lllllIlIlllIIlI.canBlockStay(lllllIlIllIllll, lllllIlIlllIlIl, lllllIlIlllIIIl))) {
              break;
            }
            "".length();
            "".length();
            if ("   ".length() >= 0) {
              break;
            }
            return;
          }
          IBlockState lllllIlIlllIIII = Blocks.tallgrass.getDefaultState().withProperty(BlockTallGrass.TYPE, BlockTallGrass.EnumType.GRASS);
          if (!lllllI(Blocks.tallgrass.canBlockStay(lllllIlIllIllll, lllllIlIlllIlIl, lllllIlIlllIIII))) {
            break;
          }
          "".length();
          "".length();
          if (((0x6B ^ 0x26 ^ 0x90 ^ 0x8D) & (0x3A ^ 0x5A ^ 0xB3 ^ 0x83 ^ -" ".length())) == 0) {
            break;
          }
          return;
        }
        lllllIlIlllIlIl = lllllIlIlllIlIl.add(lllllIlIllIlllI.nextInt(llll[5]) - llll[1], (lllllIlIllIlllI.nextInt(llll[5]) - llll[1]) * lllllIlIllIlllI.nextInt(llll[5]) / llll[3], lllllIlIllIlllI.nextInt(llll[5]) - llll[1]);
        if (!llllII(lllllIlIllIllll.getBlockState(lllllIlIlllIlIl.down()).getBlock(), Blocks.grass)) {
          break;
        }
        if (lllllI(lllllIlIllIllll.getBlockState(lllllIlIlllIlIl).getBlock().isNormalCube()))
        {
          "".length();
          if (null == null) {
            break;
          }
          return;
        }
        lllllIlIlllIlII++;
        "".length();
      } while (((0xE1 ^ 0x80) & (0x2 ^ 0x63 ^ 0xFFFFFFFF)) <= " ".length());
      return;
      lllllIlIlllIllI++;
    }
  }
  
  protected BlockGrass()
  {
    lllllIlllIIlIlI.<init>(Material.grass);
    lllllIlllIIlIll.setDefaultState(blockState.getBaseState().withProperty(SNOWY, Boolean.valueOf(llll[0])));
    "".length();
    "".length();
  }
  
  private static boolean lllIIl(int ???, int arg1)
  {
    int i;
    char lllllIlIlIIlIll;
    return ??? < i;
  }
  
  private static boolean lllIII(int ???)
  {
    float lllllIlIIllIlll;
    return ??? == 0;
  }
  
  public boolean canGrow(World lllllIllIIIllll, BlockPos lllllIllIIIlllI, IBlockState lllllIllIIIllIl, boolean lllllIllIIIllII)
  {
    return llll[1];
  }
  
  public boolean canUseBonemeal(World lllllIllIIIlIlI, Random lllllIllIIIlIIl, BlockPos lllllIllIIIlIII, IBlockState lllllIllIIIIlll)
  {
    return llll[1];
  }
  
  static
  {
    llIllI();
    llIlIl();
  }
  
  public IBlockState getActualState(IBlockState lllllIlllIIIlII, IBlockAccess lllllIlllIIIIll, BlockPos lllllIllIlllllI)
  {
    ;
    ;
    ;
    ;
    Block lllllIlllIIIIIl = lllllIlllIIIIll.getBlockState(lllllIllIlllllI.up()).getBlock();
    if ((llIlll(lllllIlllIIIIIl, Blocks.snow)) && (llIlll(lllllIlllIIIIIl, Blocks.snow_layer)))
    {
      "".length();
      if (((0x4F ^ 0x7A ^ 0x4E ^ 0x33) & (0x4B ^ 0x6 ^ 0x77 ^ 0x72 ^ -" ".length())) >= 0) {
        break label94;
      }
      return null;
    }
    label94:
    return SNOWY.withProperty(llll[0], Boolean.valueOf(llll[1]));
  }
  
  private static boolean llllII(Object ???, Object arg1)
  {
    Object localObject;
    byte lllllIlIIlllIll;
    return ??? == localObject;
  }
  
  private static void llIllI()
  {
    llll = new int[10];
    llll[0] = ((0x92 ^ 0x8F ^ 0x19 ^ 0x8) & ('' + 82 - 102 + 65 ^ 57 + 26 - 53 + 151 ^ -" ".length()));
    llll[1] = " ".length();
    llll[2] = (0xCB ^ 0xAD ^ 0x63 ^ 0x1);
    llll[3] = "  ".length();
    llll[4] = (0x50 ^ 0x59);
    llll[5] = "   ".length();
    llll[6] = (0x4 ^ 0x1);
    llll[7] = (0xBA ^ 0xAA);
    llll[8] = (0x86 ^ 0x8E);
    llll[9] = ((0xA1 ^ 0x9A) + (0xD0 ^ 0x85) - (0xEB ^ 0x9A) + (0xA6 ^ 0xC7));
  }
  
  public int getMetaFromState(IBlockState lllllIlIllIIIll)
  {
    return llll[0];
  }
  
  private static boolean lllllI(int ???)
  {
    float lllllIlIIlllIIl;
    return ??? != 0;
  }
}

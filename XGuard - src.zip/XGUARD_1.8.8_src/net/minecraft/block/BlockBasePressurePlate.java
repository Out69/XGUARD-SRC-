package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockBasePressurePlate
  extends Block
{
  private static boolean llllIIlllIll(int ???)
  {
    boolean lllllllllllllllllIIllIIIIlIlIllI;
    return ??? > 0;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World lllllllllllllllllIIllIIlIIIIllIl, BlockPos lllllllllllllllllIIllIIlIIIIllII, IBlockState lllllllllllllllllIIllIIlIIIIlIll)
  {
    return null;
  }
  
  static
  {
    llllIIlllIlI();
    llllIIllIllI();
  }
  
  public boolean func_181623_g()
  {
    return lIIllIllIIl[0];
  }
  
  private static boolean llllIIllllll(Object ???, Object arg1)
  {
    Object localObject;
    float lllllllllllllllllIIllIIIIlIlllII;
    return ??? == localObject;
  }
  
  public void onNeighborBlockChange(World lllllllllllllllllIIllIIIllllIllI, BlockPos lllllllllllllllllIIllIIIllllIIII, IBlockState lllllllllllllllllIIllIIIllllIlII, Block lllllllllllllllllIIllIIIllllIIll)
  {
    ;
    ;
    ;
    ;
    if (llllIIllllIl(lllllllllllllllllIIllIIIllllIlll.canBePlacedOn(lllllllllllllllllIIllIIIllllIllI, lllllllllllllllllIIllIIIllllIlIl.down())))
    {
      lllllllllllllllllIIllIIIllllIlll.dropBlockAsItem(lllllllllllllllllIIllIIIllllIllI, lllllllllllllllllIIllIIIllllIlIl, lllllllllllllllllIIllIIIllllIlII, lIIllIllIIl[1]);
      "".length();
    }
  }
  
  public int getWeakPower(IBlockAccess lllllllllllllllllIIllIIIlIIIlIll, BlockPos lllllllllllllllllIIllIIIlIIIlIlI, IBlockState lllllllllllllllllIIllIIIlIIIlIIl, EnumFacing lllllllllllllllllIIllIIIlIIIlIII)
  {
    ;
    ;
    return lllllllllllllllllIIllIIIlIIIllII.getRedstoneStrength(lllllllllllllllllIIllIIIlIIIIllI);
  }
  
  public void randomTick(World lllllllllllllllllIIllIIIlllIIllI, BlockPos lllllllllllllllllIIllIIIlllIIlIl, IBlockState lllllllllllllllllIIllIIIlllIIlII, Random lllllllllllllllllIIllIIIlllIIIll) {}
  
  public int getMobilityFlag()
  {
    return lIIllIllIIl[0];
  }
  
  public void breakBlock(World lllllllllllllllllIIllIIIlIIllIlI, BlockPos lllllllllllllllllIIllIIIlIIllIIl, IBlockState lllllllllllllllllIIllIIIlIIllIII)
  {
    ;
    ;
    ;
    ;
    if (llllIIlllIll(lllllllllllllllllIIllIIIlIIlllll.getRedstoneStrength(lllllllllllllllllIIllIIIlIIllIII))) {
      lllllllllllllllllIIllIIIlIIlllll.updateNeighbors(lllllllllllllllllIIllIIIlIIllIlI, lllllllllllllllllIIllIIIlIIllIIl);
    }
    lllllllllllllllllIIllIIIlIIlllll.breakBlock(lllllllllllllllllIIllIIIlIIllIlI, lllllllllllllllllIIllIIIlIIllIIl, lllllllllllllllllIIllIIIlIIllIII);
  }
  
  public int tickRate(World lllllllllllllllllIIllIIlIIIIllll)
  {
    return lIIllIllIIl[2];
  }
  
  public int getStrongPower(IBlockAccess lllllllllllllllllIIllIIIlIIIIIIl, BlockPos lllllllllllllllllIIllIIIlIIIIIII, IBlockState lllllllllllllllllIIllIIIIlllllII, EnumFacing lllllllllllllllllIIllIIIIllllIll)
  {
    ;
    ;
    ;
    if (llllIIllllll(lllllllllllllllllIIllIIIIllllIll, EnumFacing.UP))
    {
      "".length();
      if ("   ".length() > " ".length()) {
        break label54;
      }
      return (0x33 ^ 0x9) & (0x4E ^ 0x74 ^ 0xFFFFFFFF);
    }
    label54:
    return lIIllIllIIl[1];
  }
  
  protected void setBlockBoundsBasedOnState0(IBlockState lllllllllllllllllIIllIIlIIIlIlll)
  {
    ;
    ;
    ;
    ;
    if (llllIIlllIll(lllllllllllllllllIIllIIlIIIlIlII.getRedstoneStrength(lllllllllllllllllIIllIIlIIIlIlll)))
    {
      "".length();
      if ((0x1E ^ 0x1A) >= 0) {
        break label36;
      }
    }
    label36:
    boolean lllllllllllllllllIIllIIlIIIlIllI = lIIllIllIIl[1];
    float lllllllllllllllllIIllIIlIIIlIlIl = 0.0625F;
    if (llllIIllllII(lllllllllllllllllIIllIIlIIIlIllI))
    {
      lllllllllllllllllIIllIIlIIIlIlII.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.03125F, 0.9375F);
      "".length();
      if (" ".length() == " ".length()) {}
    }
    else
    {
      lllllllllllllllllIIllIIlIIIlIlII.setBlockBounds(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.0625F, 0.9375F);
    }
  }
  
  protected BlockBasePressurePlate(Material lllllllllllllllllIIllIIlIIllIIIl)
  {
    lllllllllllllllllIIllIIlIIllIIlI.<init>(lllllllllllllllllIIllIIlIIllIIIl, lllllllllllllllllIIllIIlIIllIIIl.getMaterialMapColor());
  }
  
  private static String lllIlllIllIl(String lllllllllllllllllIIllIIIIllIIlIl, String lllllllllllllllllIIllIIIIllIIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIllIIIIllIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIllIIIIllIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIIllIIIIllIIlll = Cipher.getInstance("Blowfish");
      lllllllllllllllllIIllIIIIllIIlll.init(lIIllIllIIl[3], lllllllllllllllllIIllIIIIllIlIII);
      return new String(lllllllllllllllllIIllIIIIllIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIllIIIIllIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIllIIIIllIIllI)
    {
      lllllllllllllllllIIllIIIIllIIllI.printStackTrace();
    }
    return null;
  }
  
  public boolean canProvidePower()
  {
    return lIIllIllIIl[0];
  }
  
  private static void llllIIlllIlI()
  {
    lIIllIllIIl = new int[4];
    lIIllIllIIl[0] = " ".length();
    lIIllIllIIl[1] = ("  ".length() & ("  ".length() ^ 0xFFFFFFFF));
    lIIllIllIIl[2] = (0x2C ^ 0x22 ^ 0xAD ^ 0xB7);
    lIIllIllIIl[3] = "  ".length();
  }
  
  public void onEntityCollidedWithBlock(World lllllllllllllllllIIllIIIllIIIllI, BlockPos lllllllllllllllllIIllIIIllIIIlIl, IBlockState lllllllllllllllllIIllIIIllIIIlII, Entity lllllllllllllllllIIllIIIllIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (llllIIllllIl(isRemote))
    {
      int lllllllllllllllllIIllIIIllIIlIII = lllllllllllllllllIIllIIIllIIllIl.getRedstoneStrength(lllllllllllllllllIIllIIIllIIIlII);
      if (llllIIllllIl(lllllllllllllllllIIllIIIllIIlIII)) {
        lllllllllllllllllIIllIIIllIIllIl.updateState(lllllllllllllllllIIllIIIllIIIllI, lllllllllllllllllIIllIIIllIIlIll, lllllllllllllllllIIllIIIllIIIlII, lllllllllllllllllIIllIIIllIIlIII);
      }
    }
  }
  
  private static boolean llllIIllllIl(int ???)
  {
    char lllllllllllllllllIIllIIIIlIllIII;
    return ??? == 0;
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    ;
    ;
    ;
    float lllllllllllllllllIIllIIIIlllIlII = 0.5F;
    float lllllllllllllllllIIllIIIIlllIIll = 0.125F;
    float lllllllllllllllllIIllIIIIlllIIlI = 0.5F;
    lllllllllllllllllIIllIIIIlllIlIl.setBlockBounds(0.0F, 0.375F, 0.0F, 1.0F, 0.625F, 1.0F);
  }
  
  public boolean isPassable(IBlockAccess lllllllllllllllllIIllIIlIIIIIlll, BlockPos lllllllllllllllllIIllIIlIIIIIllI)
  {
    return lIIllIllIIl[0];
  }
  
  protected void updateState(World lllllllllllllllllIIllIIIlIlllIIl, BlockPos lllllllllllllllllIIllIIIlIllIIII, IBlockState lllllllllllllllllIIllIIIlIlIllll, int lllllllllllllllllIIllIIIlIlIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllllIIllIIIlIllIlIl = lllllllllllllllllIIllIIIlIlllIlI.computeRedstoneStrength(lllllllllllllllllIIllIIIlIlllIIl, lllllllllllllllllIIllIIIlIlllIII);
    if (llllIIlllIll(lllllllllllllllllIIllIIIlIlIlllI))
    {
      "".length();
      if ((122 + 15 - 52 + 69 ^ 70 + '' - 184 + 123) > 0) {
        break label61;
      }
    }
    label61:
    boolean lllllllllllllllllIIllIIIlIllIlII = lIIllIllIIl[1];
    if (llllIIlllIll(lllllllllllllllllIIllIIIlIllIlIl))
    {
      "".length();
      if (((0x96 ^ 0x98) & (0xB8 ^ 0xB6 ^ 0xFFFFFFFF)) == ((0x26 ^ 0x9) & (0x66 ^ 0x49 ^ 0xFFFFFFFF))) {
        break label121;
      }
    }
    label121:
    boolean lllllllllllllllllIIllIIIlIllIIll = lIIllIllIIl[1];
    if (llllIIlllllI(lllllllllllllllllIIllIIIlIlIlllI, lllllllllllllllllIIllIIIlIllIlIl))
    {
      lllllllllllllllllIIllIIIlIlIllll = lllllllllllllllllIIllIIIlIlllIlI.setRedstoneStrength(lllllllllllllllllIIllIIIlIlIllll, lllllllllllllllllIIllIIIlIllIlIl);
      "".length();
      lllllllllllllllllIIllIIIlIlllIlI.updateNeighbors(lllllllllllllllllIIllIIIlIlllIIl, lllllllllllllllllIIllIIIlIlllIII);
      lllllllllllllllllIIllIIIlIlllIIl.markBlockRangeForRenderUpdate(lllllllllllllllllIIllIIIlIlllIII, lllllllllllllllllIIllIIIlIlllIII);
    }
    if ((llllIIllllIl(lllllllllllllllllIIllIIIlIllIIll)) && (llllIIllllII(lllllllllllllllllIIllIIIlIllIlII)))
    {
      lllllllllllllllllIIllIIIlIlllIIl.playSoundEffect(lllllllllllllllllIIllIIIlIlllIII.getX() + 0.5D, lllllllllllllllllIIllIIIlIlllIII.getY() + 0.1D, lllllllllllllllllIIllIIIlIlllIII.getZ() + 0.5D, lIIlIlllIlI[lIIllIllIIl[1]], 0.3F, 0.5F);
      "".length();
      if ("  ".length() != -" ".length()) {}
    }
    else if ((llllIIllllII(lllllllllllllllllIIllIIIlIllIIll)) && (llllIIllllIl(lllllllllllllllllIIllIIIlIllIlII)))
    {
      lllllllllllllllllIIllIIIlIlllIIl.playSoundEffect(lllllllllllllllllIIllIIIlIlllIII.getX() + 0.5D, lllllllllllllllllIIllIIIlIlllIII.getY() + 0.1D, lllllllllllllllllIIllIIIlIlllIII.getZ() + 0.5D, lIIlIlllIlI[lIIllIllIIl[0]], 0.3F, 0.6F);
    }
    if (llllIIllllII(lllllllllllllllllIIllIIIlIllIIll)) {
      lllllllllllllllllIIllIIIlIlllIIl.scheduleUpdate(lllllllllllllllllIIllIIIlIlllIII, lllllllllllllllllIIllIIIlIlllIlI, lllllllllllllllllIIllIIIlIlllIlI.tickRate(lllllllllllllllllIIllIIIlIlllIIl));
    }
  }
  
  protected BlockBasePressurePlate(Material lllllllllllllllllIIllIIlIIlIlIlI, MapColor lllllllllllllllllIIllIIlIIlIlIIl)
  {
    lllllllllllllllllIIllIIlIIlIlIll.<init>(lllllllllllllllllIIllIIlIIlIIlll, lllllllllllllllllIIllIIlIIlIlIIl);
    "".length();
    "".length();
  }
  
  public void updateTick(World lllllllllllllllllIIllIIIllIlllII, BlockPos lllllllllllllllllIIllIIIllIlIlIl, IBlockState lllllllllllllllllIIllIIIllIllIlI, Random lllllllllllllllllIIllIIIllIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (llllIIllllIl(isRemote))
    {
      int lllllllllllllllllIIllIIIllIllIII = lllllllllllllllllIIllIIIllIlIlll.getRedstoneStrength(lllllllllllllllllIIllIIIllIllIlI);
      if (llllIIlllIll(lllllllllllllllllIIllIIIllIllIII)) {
        lllllllllllllllllIIllIIIllIlIlll.updateState(lllllllllllllllllIIllIIIllIlllII, lllllllllllllllllIIllIIIllIllIll, lllllllllllllllllIIllIIIllIllIlI, lllllllllllllllllIIllIIIllIllIII);
      }
    }
  }
  
  protected abstract int getRedstoneStrength(IBlockState paramIBlockState);
  
  protected AxisAlignedBB getSensitiveAABB(BlockPos lllllllllllllllllIIllIIIlIlIIlIl)
  {
    ;
    ;
    float lllllllllllllllllIIllIIIlIlIIllI = 0.125F;
    return new AxisAlignedBB(lllllllllllllllllIIllIIIlIlIIlll.getX() + 0.125F, lllllllllllllllllIIllIIIlIlIIlll.getY(), lllllllllllllllllIIllIIIlIlIIlll.getZ() + 0.125F, lllllllllllllllllIIllIIIlIlIIlll.getX() + lIIllIllIIl[0] - 0.125F, lllllllllllllllllIIllIIIlIlIIlll.getY() + 0.25D, lllllllllllllllllIIllIIIlIlIIlll.getZ() + lIIllIllIIl[0] - 0.125F);
  }
  
  public boolean canPlaceBlockAt(World lllllllllllllllllIIllIIlIIIIIIII, BlockPos lllllllllllllllllIIllIIIllllllII)
  {
    ;
    ;
    ;
    return lllllllllllllllllIIllIIIlllllllI.canBePlacedOn(lllllllllllllllllIIllIIIllllllIl, lllllllllllllllllIIllIIIllllllII.down());
  }
  
  protected void updateNeighbors(World lllllllllllllllllIIllIIIlIIlIIII, BlockPos lllllllllllllllllIIllIIIlIIlIIlI)
  {
    ;
    ;
    ;
    lllllllllllllllllIIllIIIlIIlIIII.notifyNeighborsOfStateChange(lllllllllllllllllIIllIIIlIIlIIlI, lllllllllllllllllIIllIIIlIIlIIIl);
    lllllllllllllllllIIllIIIlIIlIIll.notifyNeighborsOfStateChange(lllllllllllllllllIIllIIIlIIlIIlI.down(), lllllllllllllllllIIllIIIlIIlIIIl);
  }
  
  private boolean canBePlacedOn(World lllllllllllllllllIIllIIIlllIlIIl, BlockPos lllllllllllllllllIIllIIIlllIlIII)
  {
    ;
    ;
    if ((llllIIllllIl(World.doesBlockHaveSolidTopSurface(lllllllllllllllllIIllIIIlllIlIIl, lllllllllllllllllIIllIIIlllIlIII))) && (llllIIllllIl(lllllllllllllllllIIllIIIlllIlIIl.getBlockState(lllllllllllllllllIIllIIIlllIlIII).getBlock() instanceof BlockFence))) {
      return lIIllIllIIl[1];
    }
    return lIIllIllIIl[0];
  }
  
  protected abstract int computeRedstoneStrength(World paramWorld, BlockPos paramBlockPos);
  
  protected abstract IBlockState setRedstoneStrength(IBlockState paramIBlockState, int paramInt);
  
  public boolean isFullCube()
  {
    return lIIllIllIIl[1];
  }
  
  private static boolean llllIIllllII(int ???)
  {
    long lllllllllllllllllIIllIIIIlIllIlI;
    return ??? != 0;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess lllllllllllllllllIIllIIlIIlIIIIl, BlockPos lllllllllllllllllIIllIIlIIIlllIl)
  {
    ;
    ;
    ;
    lllllllllllllllllIIllIIlIIIlllll.setBlockBoundsBasedOnState0(lllllllllllllllllIIllIIlIIIllllI.getBlockState(lllllllllllllllllIIllIIlIIIlllIl));
  }
  
  private static boolean llllIIlllllI(int ???, int arg1)
  {
    int i;
    String lllllllllllllllllIIllIIIIlIlIIlI;
    return ??? != i;
  }
  
  private static void llllIIllIllI()
  {
    lIIlIlllIlI = new String[lIIllIllIIl[3]];
    lIIlIlllIlI[lIIllIllIIl[1]] = lllIlllIllIl("hwTmgJZGYfOIbKfrjfvGVA==", "FfHEs");
    lIIlIlllIlI[lIIllIllIIl[0]] = lllIlllIllIl("YT6digtR7akzdX/7zD0Qxg==", "glYon");
  }
  
  public boolean isOpaqueCube()
  {
    return lIIllIllIIl[1];
  }
}

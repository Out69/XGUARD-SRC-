package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockFalling
  extends Block
{
  public void onEndFalling(World llllllllllllllllllIlIlIllIllIIII, BlockPos llllllllllllllllllIlIlIllIlIllll) {}
  
  protected void onStartFalling(EntityFallingBlock llllllllllllllllllIlIlIlllIIIIII) {}
  
  public BlockFalling(Material llllllllllllllllllIlIlIlllllIlII)
  {
    llllllllllllllllllIlIlIlllllIlIl.<init>(llllllllllllllllllIlIlIlllllIlII);
  }
  
  public int tickRate(World llllllllllllllllllIlIlIllIlllllI)
  {
    return lllIIIIIIl[1];
  }
  
  public void onBlockAdded(World llllllllllllllllllIlIlIllllIllIl, BlockPos llllllllllllllllllIlIlIllllIlIII, IBlockState llllllllllllllllllIlIlIllllIlIll)
  {
    ;
    ;
    ;
    llllllllllllllllllIlIlIllllIllIl.scheduleUpdate(llllllllllllllllllIlIlIllllIlIII, llllllllllllllllllIlIlIllllIlIlI, llllllllllllllllllIlIlIllllIlIlI.tickRate(llllllllllllllllllIlIlIllllIllIl));
  }
  
  static {}
  
  private static boolean lIllIIlllIll(int ???)
  {
    boolean llllllllllllllllllIlIlIllIlIIlIl;
    return ??? >= 0;
  }
  
  public void updateTick(World llllllllllllllllllIlIlIlllIllIII, BlockPos llllllllllllllllllIlIlIlllIlIlll, IBlockState llllllllllllllllllIlIlIlllIlIllI, Random llllllllllllllllllIlIlIlllIlIlIl)
  {
    ;
    ;
    ;
    if (lIllIIlllIIl(isRemote)) {
      llllllllllllllllllIlIlIlllIlIlII.checkFallable(llllllllllllllllllIlIlIlllIllIII, llllllllllllllllllIlIlIlllIlIIlI);
    }
  }
  
  public void onNeighborBlockChange(World llllllllllllllllllIlIlIllllIIIll, BlockPos llllllllllllllllllIlIlIlllIlllIl, IBlockState llllllllllllllllllIlIlIllllIIIIl, Block llllllllllllllllllIlIlIllllIIIII)
  {
    ;
    ;
    ;
    llllllllllllllllllIlIlIllllIIIll.scheduleUpdate(llllllllllllllllllIlIlIllllIIIlI, llllllllllllllllllIlIlIllllIIlII, llllllllllllllllllIlIlIllllIIlII.tickRate(llllllllllllllllllIlIlIllllIIIll));
  }
  
  public static boolean canFallInto(World llllllllllllllllllIlIlIllIlllIIl, BlockPos llllllllllllllllllIlIlIllIlllIII)
  {
    ;
    ;
    ;
    ;
    Block llllllllllllllllllIlIlIllIllIlll = llllllllllllllllllIlIlIllIlllIIl.getBlockState(llllllllllllllllllIlIlIllIlllIII).getBlock();
    Material llllllllllllllllllIlIlIllIllIllI = blockMaterial;
    if ((lIllIIlllllI(llllllllllllllllllIlIlIllIllIlll, Blocks.fire)) && (lIllIIlllllI(llllllllllllllllllIlIlIllIllIllI, Material.air)) && (lIllIIlllllI(llllllllllllllllllIlIlIllIllIllI, Material.water)) && (lIllIIlllllI(llllllllllllllllllIlIlIllIllIllI, Material.lava))) {
      return lllIIIIIIl[2];
    }
    return lllIIIIIIl[3];
  }
  
  private void checkFallable(World llllllllllllllllllIlIlIlllIIIlIl, BlockPos llllllllllllllllllIlIlIlllIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    if ((lIllIIlllIlI(canFallInto(llllllllllllllllllIlIlIlllIIIlIl, llllllllllllllllllIlIlIlllIIlIlI.down()))) && (lIllIIlllIll(llllllllllllllllllIlIlIlllIIlIlI.getY())))
    {
      int llllllllllllllllllIlIlIlllIIlIIl = lllIIIIIIl[0];
      if ((lIllIIlllIIl(fallInstantly)) && (lIllIIlllIlI(llllllllllllllllllIlIlIlllIIlIll.isAreaLoaded(llllllllllllllllllIlIlIlllIIlIlI.add(-llllllllllllllllllIlIlIlllIIlIIl, -llllllllllllllllllIlIlIlllIIlIIl, -llllllllllllllllllIlIlIlllIIlIIl), llllllllllllllllllIlIlIlllIIlIlI.add(llllllllllllllllllIlIlIlllIIlIIl, llllllllllllllllllIlIlIlllIIlIIl, llllllllllllllllllIlIlIlllIIlIIl)))))
      {
        if (lIllIIlllIIl(isRemote))
        {
          EntityFallingBlock llllllllllllllllllIlIlIlllIIlIII = new EntityFallingBlock(llllllllllllllllllIlIlIlllIIlIll, llllllllllllllllllIlIlIlllIIlIlI.getX() + 0.5D, llllllllllllllllllIlIlIlllIIlIlI.getY(), llllllllllllllllllIlIlIlllIIlIlI.getZ() + 0.5D, llllllllllllllllllIlIlIlllIIlIll.getBlockState(llllllllllllllllllIlIlIlllIIlIlI));
          llllllllllllllllllIlIlIlllIIIllI.onStartFalling(llllllllllllllllllIlIlIlllIIlIII);
          "".length();
          "".length();
          if ("   ".length() <= (0xCB ^ 0xA9 ^ 0x53 ^ 0x35)) {}
        }
      }
      else
      {
        "".length();
        BlockPos llllllllllllllllllIlIlIlllIIIlll = llllllllllllllllllIlIlIlllIIlIlI.down();
        "".length();
        if (-"   ".length() >= 0) {
          return;
        }
        while ((lIllIIlllIlI(canFallInto(llllllllllllllllllIlIlIlllIIlIll, llllllllllllllllllIlIlIlllIIIlll))) && (!lIllIIllllII(llllllllllllllllllIlIlIlllIIIlll.getY()))) {
          llllllllllllllllllIlIlIlllIIIlll = llllllllllllllllllIlIlIlllIIIlll.down();
        }
        if (lIllIIllllIl(llllllllllllllllllIlIlIlllIIIlll.getY())) {
          "".length();
        }
      }
    }
  }
  
  private static boolean lIllIIlllllI(Object ???, Object arg1)
  {
    Object localObject;
    byte llllllllllllllllllIlIlIllIlIlIll;
    return ??? != localObject;
  }
  
  public BlockFalling()
  {
    llllllllllllllllllIlIlIllllllIIl.<init>(Material.sand);
    "".length();
  }
  
  private static boolean lIllIIllllIl(int ???)
  {
    double llllllllllllllllllIlIlIllIlIIIIl;
    return ??? > 0;
  }
  
  private static boolean lIllIIlllIlI(int ???)
  {
    double llllllllllllllllllIlIlIllIlIlIIl;
    return ??? != 0;
  }
  
  private static void lIllIIlllIII()
  {
    lllIIIIIIl = new int[4];
    lllIIIIIIl[0] = (0xA4 ^ 0x98 ^ 0x97 ^ 0x8B);
    lllIIIIIIl[1] = "  ".length();
    lllIIIIIIl[2] = ((0x75 ^ 0x6A ^ 0x97 ^ 0xB1) & (6 + '' - 14 + 12 ^ '' + 119 - 224 + 109 ^ -" ".length()));
    lllIIIIIIl[3] = " ".length();
  }
  
  private static boolean lIllIIllllII(int ???)
  {
    double llllllllllllllllllIlIlIllIlIIIll;
    return ??? <= 0;
  }
  
  private static boolean lIllIIlllIIl(int ???)
  {
    float llllllllllllllllllIlIlIllIlIIlll;
    return ??? == 0;
  }
}

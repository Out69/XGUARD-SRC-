package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.MathHelper;

public class BlockSeaLantern
  extends Block
{
  public MapColor getMapColor(IBlockState llllllllllllllIlIlIllIIIlIllIIll)
  {
    return MapColor.quartzColor;
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIlIlIllIIIlIllIlll, Random llllllllllllllIlIlIllIIIlIllIllI, int llllllllllllllIlIlIllIIIlIllIlIl)
  {
    return Items.prismarine_crystals;
  }
  
  static {}
  
  public int quantityDroppedWithBonus(int llllllllllllllIlIlIllIIIlIllllIl, Random llllllllllllllIlIlIllIIIlIllllII)
  {
    ;
    ;
    ;
    return MathHelper.clamp_int(llllllllllllllIlIlIllIIIlIlllIll.quantityDropped(llllllllllllllIlIlIllIIIlIllllII) + llllllllllllllIlIlIllIIIlIllllII.nextInt(llllllllllllllIlIlIllIIIlIlllIlI + lIIIIlIlIlllI[1]), lIIIIlIlIlllI[1], lIIIIlIlIlllI[2]);
  }
  
  private static void llIIllIIIlllIl()
  {
    lIIIIlIlIlllI = new int[3];
    lIIIIlIlIlllI[0] = "  ".length();
    lIIIIlIlIlllI[1] = " ".length();
    lIIIIlIlIlllI[2] = (0x86 ^ 0x83);
  }
  
  public int quantityDropped(Random llllllllllllllIlIlIllIIIllIIIIll)
  {
    ;
    return lIIIIlIlIlllI[0] + llllllllllllllIlIlIllIIIllIIIIlI.nextInt(lIIIIlIlIlllI[0]);
  }
  
  public BlockSeaLantern(Material llllllllllllllIlIlIllIIIllIIIllI)
  {
    llllllllllllllIlIlIllIIIllIIlIIl.<init>(llllllllllllllIlIlIllIIIllIIIllI);
    "".length();
  }
  
  protected boolean canSilkHarvest()
  {
    return lIIIIlIlIlllI[1];
  }
}

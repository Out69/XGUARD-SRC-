package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.World;

public class BlockSlime
  extends BlockBreakable
{
  public void onLanded(World lllllllllllllllIlIIlIIIIlIllIIII, Entity lllllllllllllllIlIIlIIIIlIlIllll)
  {
    ;
    ;
    ;
    if (lIIIIIIIIllIII(lllllllllllllllIlIIlIIIIlIlIllll.isSneaking()))
    {
      lllllllllllllllIlIIlIIIIlIllIIIl.onLanded(lllllllllllllllIlIIlIIIIlIllIIll, lllllllllllllllIlIIlIIIIlIlIllll);
      "".length();
      if (" ".length() <= " ".length()) {}
    }
    else if (lIIIIIIIIllIlI(lIIIIIIIIllIIl(motionY, 0.0D)))
    {
      motionY = (-motionY);
    }
  }
  
  private static boolean lIIIIIIIIlllII(int ???)
  {
    byte lllllllllllllllIlIIlIIIIlIIlllII;
    return ??? == 0;
  }
  
  public void onFallenUpon(World lllllllllllllllIlIIlIIIIlIlllIll, BlockPos lllllllllllllllIlIIlIIIIlIlllIlI, Entity lllllllllllllllIlIIlIIIIlIlllIIl, float lllllllllllllllIlIIlIIIIlIlllIII)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIIIIIIIllIII(lllllllllllllllIlIIlIIIIlIlllIIl.isSneaking()))
    {
      lllllllllllllllIlIIlIIIIlIllllII.onFallenUpon(lllllllllllllllIlIIlIIIIlIlllIll, lllllllllllllllIlIIlIIIIlIllllll, lllllllllllllllIlIIlIIIIlIlllIIl, lllllllllllllllIlIIlIIIIlIlllIII);
      "".length();
      if (((64 + 53 - 45 + 91 ^ 101 + 115 - 133 + 45) & (4 + 87 - -24 + 15 ^ 104 + 125 - 78 + 10 ^ -" ".length())) == 0) {}
    }
    else
    {
      lllllllllllllllIlIIlIIIIlIlllIIl.fall(lllllllllllllllIlIIlIIIIlIlllIII, 0.0F);
    }
  }
  
  static {}
  
  private static int lIIIIIIIIllIIl(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean lIIIIIIIIllIII(int ???)
  {
    float lllllllllllllllIlIIlIIIIlIIllllI;
    return ??? != 0;
  }
  
  private static void lIIIIIIIIlIlll()
  {
    lIlIIllIIIll = new int[1];
    lIlIIllIIIll[0] = ((0x4C ^ 0x6D ^ 0x3C ^ 0x18) & (0x87 ^ 0xAD ^ 0x58 ^ 0x77 ^ -" ".length()));
  }
  
  public BlockSlime()
  {
    lllllllllllllllIlIIlIIIIllIIlIIl.<init>(Material.clay, lIlIIllIIIll[0], MapColor.grassColor);
    "".length();
    slipperiness = 0.8F;
  }
  
  public void onEntityCollidedWithBlock(World lllllllllllllllIlIIlIIIIlIlIlIII, BlockPos lllllllllllllllIlIIlIIIIlIlIIIlI, Entity lllllllllllllllIlIIlIIIIlIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if ((lIIIIIIIIllIlI(lIIIIIIIIllIll(Math.abs(motionY), 0.1D))) && (lIIIIIIIIlllII(lllllllllllllllIlIIlIIIIlIlIIIIl.isSneaking())))
    {
      double lllllllllllllllIlIIlIIIIlIlIIlIl = 0.4D + Math.abs(motionY) * 0.2D;
      motionX *= lllllllllllllllIlIIlIIIIlIlIIlIl;
      motionZ *= lllllllllllllllIlIIlIIIIlIlIIlIl;
    }
    lllllllllllllllIlIIlIIIIlIlIIlII.onEntityCollidedWithBlock(lllllllllllllllIlIIlIIIIlIlIlIII, lllllllllllllllIlIIlIIIIlIlIIIlI, lllllllllllllllIlIIlIIIIlIlIIIIl);
  }
  
  private static int lIIIIIIIIllIll(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.TRANSLUCENT;
  }
  
  private static boolean lIIIIIIIIllIlI(int ???)
  {
    char lllllllllllllllIlIIlIIIIlIIllIlI;
    return ??? < 0;
  }
}

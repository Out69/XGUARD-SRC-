package net.minecraft.block;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;

public abstract class BlockFlower
  extends BlockBush
{
  private static String lIlIIllIIII(String llIIIIIIllllll, String llIIIIIlIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llIIIIIIllllll = new String(Base64.getDecoder().decode(llIIIIIIllllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llIIIIIlIIIIlI = new StringBuilder();
    char[] llIIIIIlIIIIIl = llIIIIIlIIIIll.toCharArray();
    int llIIIIIlIIIIII = llIIIllll[0];
    long llIIIIIIlllIlI = llIIIIIIllllll.toCharArray();
    String llIIIIIIlllIIl = llIIIIIIlllIlI.length;
    boolean llIIIIIIlllIII = llIIIllll[0];
    while (lIlIIlllllI(llIIIIIIlllIII, llIIIIIIlllIIl))
    {
      char llIIIIIlIIIlIl = llIIIIIIlllIlI[llIIIIIIlllIII];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(llIIIIIlIIIIlI);
  }
  
  private static void lIlIIllIIIl()
  {
    llIIIllIl = new String[llIIIllll[1]];
    llIIIllIl[llIIIllll[0]] = lIlIIllIIII("HxoBKA==", "kcqMo");
  }
  
  public Block.EnumOffsetType getOffsetType()
  {
    return Block.EnumOffsetType.XZ;
  }
  
  private static boolean lIlIIllIIll(Object ???, Object arg1)
  {
    Object localObject;
    boolean llIIIIIIlIlIll;
    return ??? == localObject;
  }
  
  public int getMetaFromState(IBlockState llIIIIIlIlIlIl)
  {
    ;
    ;
    return ((EnumFlowerType)llIIIIIlIlIlIl.getValue(llIIIIIlIlIlII.getTypeProperty())).getMeta();
  }
  
  public int damageDropped(IBlockState llIIIIIlllIlIl)
  {
    ;
    ;
    return ((EnumFlowerType)llIIIIIlllIlIl.getValue(llIIIIIlllIllI.getTypeProperty())).getMeta();
  }
  
  static
  {
    lIlIIllIIlI();
    lIlIIllIIIl();
  }
  
  public void getSubBlocks(Item llIIIIIllIIlll, CreativeTabs llIIIIIllIlIll, List<ItemStack> llIIIIIllIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    Exception llIIIIIllIIIll = (llIIIIIllIIIlI = EnumFlowerType.getTypes(llIIIIIllIlIII.getBlockType())).length;
    int llIIIIIllIIlII = llIIIllll[0];
    "".length();
    if (((123 + 64 - 25 + 11 ^ '' + 105 - 217 + 137) & (0x4B ^ 0x59 ^ 0x78 ^ 0x66 ^ -" ".length())) != ((28 + 106 - 133 + 129 ^ 55 + 28 - 75 + 143) & (0x14 ^ 0x2C ^ 0x5E ^ 0x73 ^ -" ".length()))) {
      return;
    }
    while (!lIlIIllIlII(llIIIIIllIIlII, llIIIIIllIIIll))
    {
      EnumFlowerType llIIIIIllIlIIl = llIIIIIllIIIlI[llIIIIIllIIlII];
      new ItemStack(llIIIIIllIIlll, llIIIllll[1], llIIIIIllIlIIl.getMeta());
      "".length();
    }
  }
  
  private static boolean lIlIIllIlII(int ???, int arg1)
  {
    int i;
    long llIIIIIIllIIll;
    return ??? >= i;
  }
  
  private static void lIlIIllIIlI()
  {
    llIIIllll = new int[2];
    llIIIllll[0] = ((0x4C ^ 0x9) & (0xF0 ^ 0xB5 ^ 0xFFFFFFFF));
    llIIIllll[1] = " ".length();
  }
  
  private static boolean lIlIIlllllI(int ???, int arg1)
  {
    int i;
    byte llIIIIIIlIllll;
    return ??? < i;
  }
  
  protected BlockFlower()
  {
    if (lIlIIllIIll(llIIIIIlllllII.getBlockType(), EnumFlowerColor.RED))
    {
      "".length();
      if (" ".length() != -" ".length()) {
        break label57;
      }
      throw null;
    }
    label57:
    blockState.getBaseState().setDefaultState(llIIIIIlllllII.getTypeProperty().withProperty(EnumFlowerType.POPPY, EnumFlowerType.DANDELION));
  }
  
  public abstract EnumFlowerColor getBlockType();
  
  public IProperty<EnumFlowerType> getTypeProperty()
  {
    ;
    if (lIlIIlllIll(type)) {
      type = PropertyEnum.create(llIIIllIl[llIIIllll[0]], EnumFlowerType.class, new Predicate()
      {
        public boolean apply(BlockFlower.EnumFlowerType lllllllllllllllIlllllllIIllIIllI)
        {
          ;
          ;
          if (llIIlIlIlllll(lllllllllllllllIlllllllIIllIIllI.getBlockType(), getBlockType())) {
            return lIIIIIllIlIl[0];
          }
          return lIIIIIllIlIl[1];
        }
        
        private static void llIIlIlIllllI()
        {
          lIIIIIllIlIl = new int[2];
          lIIIIIllIlIl[0] = " ".length();
          lIIIIIllIlIl[1] = ((0x6E ^ 0x7B) & (0x28 ^ 0x3D ^ 0xFFFFFFFF));
        }
        
        private static boolean llIIlIlIlllll(Object ???, Object arg1)
        {
          Object localObject;
          int lllllllllllllllIlllllllIIlIlllII;
          return ??? == localObject;
        }
        
        static {}
      });
    }
    return type;
  }
  
  public IBlockState getStateFromMeta(int llIIIIIlIllllI)
  {
    ;
    ;
    return llIIIIIlIlllll.getDefaultState().withProperty(llIIIIIlIlllll.getTypeProperty(), EnumFlowerType.getType(llIIIIIlIlllll.getBlockType(), llIIIIIlIllllI));
  }
  
  private static boolean lIlIIlllIll(Object ???)
  {
    long llIIIIIIlIlIIl;
    return ??? == null;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llIIIIIlIlIIII, new IProperty[] { llIIIIIlIlIIII.getTypeProperty() });
  }
  
  public static enum EnumFlowerColor
  {
    YELLOW,  RED;
    
    private static boolean lIIIlllIIIlIll(int ???, int arg1)
    {
      int i;
      String lllllllllllllllIIlIllIlllllIllII;
      return ??? < i;
    }
    
    private static String lIIIlllIIIIIll(String lllllllllllllllIIlIlllIIIIIlIllI, String lllllllllllllllIIlIlllIIIIIlIlIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIlIlllIIIIIllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlIlllIIIIIlIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIIlIlllIIIIIllIII = Cipher.getInstance("Blowfish");
        lllllllllllllllIIlIlllIIIIIllIII.init(lIlllIIIlllI[2], lllllllllllllllIIlIlllIIIIIllIIl);
        return new String(lllllllllllllllIIlIlllIIIIIllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlIlllIIIIIlIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIlIlllIIIIIlIlll)
      {
        lllllllllllllllIIlIlllIIIIIlIlll.printStackTrace();
      }
      return null;
    }
    
    private static void lIIIlllIIIIllI()
    {
      lIlllIIIllII = new String[lIlllIIIlllI[2]];
      lIlllIIIllII[lIlllIIIlllI[0]] = lIIIlllIIIIIll("Oq4221up3U0=", "DNbfj");
      lIlllIIIllII[lIlllIIIlllI[1]] = lIIIlllIIIIlIl("OS03", "khsRZ");
    }
    
    static
    {
      lIIIlllIIIlIIl();
      lIIIlllIIIIllI();
    }
    
    private static boolean lIIIlllIIIlIlI(Object ???, Object arg1)
    {
      Object localObject;
      char lllllllllllllllIIlIllIlllllIlIII;
      return ??? == localObject;
    }
    
    private static void lIIIlllIIIlIIl()
    {
      lIlllIIIlllI = new int[3];
      lIlllIIIlllI[0] = ((0x9 ^ 0x54) & (0xD ^ 0x50 ^ 0xFFFFFFFF));
      lIlllIIIlllI[1] = " ".length();
      lIlllIIIlllI[2] = "  ".length();
    }
    
    public BlockFlower getBlock()
    {
      ;
      if (lIIIlllIIIlIlI(lllllllllllllllIIlIlllIIIIlIlIll, YELLOW))
      {
        "".length();
        if ("  ".length() > 0) {
          break label32;
        }
        return null;
      }
      label32:
      return Blocks.red_flower;
    }
    
    private static String lIIIlllIIIIlIl(String lllllllllllllllIIlIlllIIIIIIIllI, String lllllllllllllllIIlIlllIIIIIIIlIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIIlIlllIIIIIIIllI = new String(Base64.getDecoder().decode(lllllllllllllllIIlIlllIIIIIIIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIIlIlllIIIIIIIlII = new StringBuilder();
      char[] lllllllllllllllIIlIlllIIIIIIIIll = lllllllllllllllIIlIlllIIIIIIIlIl.toCharArray();
      int lllllllllllllllIIlIlllIIIIIIIIlI = lIlllIIIlllI[0];
      Exception lllllllllllllllIIlIllIllllllllII = lllllllllllllllIIlIlllIIIIIIIllI.toCharArray();
      byte lllllllllllllllIIlIllIlllllllIll = lllllllllllllllIIlIllIllllllllII.length;
      double lllllllllllllllIIlIllIlllllllIlI = lIlllIIIlllI[0];
      while (lIIIlllIIIlIll(lllllllllllllllIIlIllIlllllllIlI, lllllllllllllllIIlIllIlllllllIll))
      {
        char lllllllllllllllIIlIlllIIIIIIIlll = lllllllllllllllIIlIllIllllllllII[lllllllllllllllIIlIllIlllllllIlI];
        "".length();
        "".length();
        if (((0xAC ^ 0x90) & (0x87 ^ 0xBB ^ 0xFFFFFFFF)) != 0) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIIlIlllIIIIIIIlII);
    }
  }
  
  public static enum EnumFlowerType
    implements IStringSerializable
  {
    public String getUnlocalizedName()
    {
      ;
      return unlocalizedName;
    }
    
    private static void llIIIIlIIllllI()
    {
      llllllIllllI = new String[lllllllIIlII[26]];
      llllllIllllI[lllllllIIlII[0]] = llIIIIlIIIlIll("g8TOsbhUSTxjF14FDgS5Uw==", "ouOlW");
      llllllIllllI[lllllllIIlII[1]] = llIIIIlIIlIIlI("NyYfITw/Lh4r", "SGqEY");
      llllllIllllI[lllllllIIlII[2]] = llIIIIlIIlIIlI("OBoxISA=", "hUaqy");
      llllllIllllI[lllllllIIlII[3]] = llIIIIlIIlIIll("aMwxDvLzVUM=", "Tuwja");
      llllllIllllI[lllllllIIlII[4]] = llIIIIlIIIlIll("xKJ5F1Zlkmu3Erwl4n3vkw==", "VjBvs");
      llllllIllllI[lllllllIIlII[5]] = llIIIIlIIlIIlI("JAoaCCwpFAwFGiI=", "Ffoms");
      llllllIllllI[lllllllIIlII[6]] = llIIIIlIIlIIll("FOyCRebSPODNZRPWasQIYg==", "OgJCL");
      llllllIllllI[lllllllIIlII[7]] = llIIIIlIIlIIll("iRdaXnRUHTo=", "ZFOWi");
      llllllIllllI[lllllllIIlII[8]] = llIIIIlIIIlIll("1cxNGAk1pP8=", "MgMuo");
      llllllIllllI[lllllllIIlII[9]] = llIIIIlIIlIIlI("AT8YFgIGPgQE", "IpMEV");
      llllllIllllI[lllllllIIlII[10]] = llIIIIlIIlIIll("6PqJVxTEWhNjB/q1+f9OYw==", "XMFYn");
      llllllIllllI[lllllllIIlII[11]] = llIIIIlIIlIIlI("GjwrFQAdNSYa", "HyoJT");
      llllllIllllI[lllllllIIlII[12]] = llIIIIlIIlIIlI("KigoDxUtISUg", "XMLPa");
      llllllIllllI[lllllllIIlII[13]] = llIIIIlIIlIIlI("FRMOAjUzAwY=", "afbkE");
      llllllIllllI[lllllllIIlII[14]] = llIIIIlIIlIIlI("HBYSBy4WGwccJRoU", "SDSIi");
      llllllIllllI[lllllllIIlII[15]] = llIIIIlIIlIIlI("DgosOBcEJzkjHAgI", "axMVp");
      llllllIllllI[lllllllIIlII[16]] = llIIIIlIIIlIll("RuDVcBzSiHh27Kqm1jp3iA==", "oggex");
      llllllIllllI[lllllllIIlII[17]] = llIIIIlIIIlIll("gc2cv/2lnobdq9ZR1Ou9Ng==", "cqhMm");
      llllllIllllI[lllllllIIlII[18]] = llIIIIlIIIlIll("yI9wl9vOvmGllwX2X7xa0w==", "lybqX");
      llllllIllllI[lllllllIIlII[19]] = llIIIIlIIIlIll("+oG1PT2A0dcv9OSWOOioIQ==", "prdzC");
      llllllIllllI[lllllllIIlII[20]] = llIIIIlIIlIIlI("PToKEhs5JggQFA==", "msDYD");
      llllllIllllI[lllllllIIlII[21]] = llIIIIlIIlIIlI("KRw3Kh0tADUoMg==", "YuYAB");
      llllllIllllI[lllllllIIlII[22]] = llIIIIlIIIlIll("BZGsVCWgdB0VhhE/wvJywQ==", "wzgaH");
      llllllIllllI[lllllllIIlII[23]] = llIIIIlIIIlIll("L/plJfCYhmdIWW+XxE1/4g==", "Muukr");
      llllllIllllI[lllllllIIlII[24]] = llIIIIlIIIlIll("2TpeCMPXW55fnQGY7z4pkw==", "FSvoD");
      llllllIllllI[lllllllIIlII[25]] = llIIIIlIIIlIll("2dG7JkeBV0BZHWJKagj3Bg==", "pBTit");
    }
    
    public static EnumFlowerType[] getTypes(BlockFlower.EnumFlowerColor llllllllllllllIllIIIlIIIlIlIIIIl)
    {
      ;
      return TYPES_FOR_BLOCK[llllllllllllllIllIIIlIIIlIlIIIlI.ordinal()];
    }
    
    static
    {
      llIIIIlIIlllll();
      llIIIIlIIllllI();
      int llllllllllllllIllIIIlIIIllIlIllI;
      float llllllllllllllIllIIIlIIIllIlIlll;
      float llllllllllllllIllIIIlIIIllIllIlI;
      DANDELION = new EnumFlowerType(llllllIllllI[lllllllIIlII[0]], lllllllIIlII[0], BlockFlower.EnumFlowerColor.YELLOW, lllllllIIlII[0], llllllIllllI[lllllllIIlII[1]]);
      POPPY = new EnumFlowerType(llllllIllllI[lllllllIIlII[2]], lllllllIIlII[1], BlockFlower.EnumFlowerColor.RED, lllllllIIlII[0], llllllIllllI[lllllllIIlII[3]]);
      BLUE_ORCHID = new EnumFlowerType(llllllIllllI[lllllllIIlII[4]], lllllllIIlII[2], BlockFlower.EnumFlowerColor.RED, lllllllIIlII[1], llllllIllllI[lllllllIIlII[5]], llllllIllllI[lllllllIIlII[6]]);
      ALLIUM = new EnumFlowerType(llllllIllllI[lllllllIIlII[7]], lllllllIIlII[3], BlockFlower.EnumFlowerColor.RED, lllllllIIlII[2], llllllIllllI[lllllllIIlII[8]]);
      HOUSTONIA = new EnumFlowerType(llllllIllllI[lllllllIIlII[9]], lllllllIIlII[4], BlockFlower.EnumFlowerColor.RED, lllllllIIlII[3], llllllIllllI[lllllllIIlII[10]]);
      RED_TULIP = new EnumFlowerType(llllllIllllI[lllllllIIlII[11]], lllllllIIlII[5], BlockFlower.EnumFlowerColor.RED, lllllllIIlII[4], llllllIllllI[lllllllIIlII[12]], llllllIllllI[lllllllIIlII[13]]);
      ORANGE_TULIP = new EnumFlowerType(llllllIllllI[lllllllIIlII[14]], lllllllIIlII[6], BlockFlower.EnumFlowerColor.RED, lllllllIIlII[5], llllllIllllI[lllllllIIlII[15]], llllllIllllI[lllllllIIlII[16]]);
      WHITE_TULIP = new EnumFlowerType(llllllIllllI[lllllllIIlII[17]], lllllllIIlII[7], BlockFlower.EnumFlowerColor.RED, lllllllIIlII[6], llllllIllllI[lllllllIIlII[18]], llllllIllllI[lllllllIIlII[19]]);
      PINK_TULIP = new EnumFlowerType(llllllIllllI[lllllllIIlII[20]], lllllllIIlII[8], BlockFlower.EnumFlowerColor.RED, lllllllIIlII[7], llllllIllllI[lllllllIIlII[21]], llllllIllllI[lllllllIIlII[22]]);
      OXEYE_DAISY = new EnumFlowerType(llllllIllllI[lllllllIIlII[23]], lllllllIIlII[9], BlockFlower.EnumFlowerColor.RED, lllllllIIlII[8], llllllIllllI[lllllllIIlII[24]], llllllIllllI[lllllllIIlII[25]]);
      ENUM$VALUES = new EnumFlowerType[] { DANDELION, POPPY, BLUE_ORCHID, ALLIUM, HOUSTONIA, RED_TULIP, ORANGE_TULIP, WHITE_TULIP, PINK_TULIP, OXEYE_DAISY };
      TYPES_FOR_BLOCK = new EnumFlowerType[BlockFlower.EnumFlowerColor.values().length][];
      int llllllllllllllIllIIIlIIIllIllIII = (llllllllllllllIllIIIlIIIllIlIlll = BlockFlower.EnumFlowerColor.values()).length;
      long llllllllllllllIllIIIlIIIllIllIIl = lllllllIIlII[0];
      "".length();
      if ("   ".length() <= 0) {
        return;
      }
      while (!llIIIIlIlIIIII(llllllllllllllIllIIIlIIIllIllIIl, llllllllllllllIllIIIlIIIllIllIII))
      {
        BlockFlower.EnumFlowerColor llllllllllllllIllIIIlIIIllIlllII = llllllllllllllIllIIIlIIIllIlIlll[llllllllllllllIllIIIlIIIllIllIIl];
        Collection<EnumFlowerType> llllllllllllllIllIIIlIIIllIllIll = Collections2.filter(Lists.newArrayList(values()), new Predicate()
        {
          private static boolean lIIllIllIlIlll(Object ???, Object arg1)
          {
            Object localObject;
            Exception lllllllllllllllIIIlIIlllllIIIIlI;
            return ??? == localObject;
          }
          
          public boolean apply(BlockFlower.EnumFlowerType lllllllllllllllIIIlIIlllllIIlIlI)
          {
            ;
            ;
            if (lIIllIllIlIlll(lllllllllllllllIIIlIIlllllIIlIlI.getBlockType(), BlockFlower.EnumFlowerType.this)) {
              return llIIlIllIlIl[0];
            }
            return llIIlIllIlIl[1];
          }
          
          static {}
          
          private static void lIIllIllIlIllI()
          {
            llIIlIllIlIl = new int[2];
            llIIlIllIlIl[0] = " ".length();
            llIIlIllIlIl[1] = ((0x36 ^ 0x9) & (0x58 ^ 0x67 ^ 0xFFFFFFFF));
          }
        });
        TYPES_FOR_BLOCK[llllllllllllllIllIIIlIIIllIlllII.ordinal()] = ((EnumFlowerType[])llllllllllllllIllIIIlIIIllIllIll.toArray(new EnumFlowerType[llllllllllllllIllIIIlIIIllIllIll.size()]));
        llllllllllllllIllIIIlIIIllIllIIl++;
      }
    }
    
    private static String llIIIIlIIlIIll(String llllllllllllllIllIIIlIIIIllIIIll, String llllllllllllllIllIIIlIIIIllIIIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIllIIIlIIIIllIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIIlIIIIllIIIlI.getBytes(StandardCharsets.UTF_8)), lllllllIIlII[8]), "DES");
        Cipher llllllllllllllIllIIIlIIIIllIIlIl = Cipher.getInstance("DES");
        llllllllllllllIllIIIlIIIIllIIlIl.init(lllllllIIlII[2], llllllllllllllIllIIIlIIIIllIIllI);
        return new String(llllllllllllllIllIIIlIIIIllIIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIIlIIIIllIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIllIIIlIIIIllIIlII)
      {
        llllllllllllllIllIIIlIIIIllIIlII.printStackTrace();
      }
      return null;
    }
    
    public BlockFlower.EnumFlowerColor getBlockType()
    {
      ;
      return blockType;
    }
    
    private static boolean llIIIIlIlIIIlI(int ???, int arg1)
    {
      int i;
      int llllllllllllllIllIIIlIIIIlIlIllI;
      return ??? < i;
    }
    
    private static void llIIIIlIIlllll()
    {
      lllllllIIlII = new int[27];
      lllllllIIlII[0] = ((0xEE ^ 0x90 ^ 0x96 ^ 0xBC) & ('Ó' + 'à' - 297 + 95 ^ '' + 44 - 142 + 140 ^ -" ".length()));
      lllllllIIlII[1] = " ".length();
      lllllllIIlII[2] = "  ".length();
      lllllllIIlII[3] = "   ".length();
      lllllllIIlII[4] = (0x34 ^ 0xE ^ 0x6E ^ 0x50);
      lllllllIIlII[5] = (0x55 ^ 0x4D ^ 0xB5 ^ 0xA8);
      lllllllIIlII[6] = (0x2D ^ 0x2B);
      lllllllIIlII[7] = (0x5F ^ 0x19 ^ 0x67 ^ 0x26);
      lllllllIIlII[8] = (0x82 ^ 0x8A);
      lllllllIIlII[9] = (0x95 ^ 0x9C);
      lllllllIIlII[10] = (0x65 ^ 0x6F);
      lllllllIIlII[11] = (0xF6 ^ 0x94 ^ 0x27 ^ 0x4E);
      lllllllIIlII[12] = (0x1E ^ 0x16 ^ 0x38 ^ 0x3C);
      lllllllIIlII[13] = (0xCC ^ 0x95 ^ 0x4A ^ 0x1E);
      lllllllIIlII[14] = ('' + 'Ì' - 163 + 31 ^ '' + '' - 147 + 39);
      lllllllIIlII[15] = (0x3E ^ 0x2F ^ 0x62 ^ 0x7C);
      lllllllIIlII[16] = (0xBF ^ 0x87 ^ 0x10 ^ 0x38);
      lllllllIIlII[17] = (0x19 ^ 0x39 ^ 0xA2 ^ 0x93);
      lllllllIIlII[18] = (0x3E ^ 0x2C);
      lllllllIIlII[19] = (0x4F ^ 0x65 ^ 0x53 ^ 0x6A);
      lllllllIIlII[20] = ('' + 93 - 150 + 93 ^ 28 + '' - 123 + 115);
      lllllllIIlII[21] = (0x3D ^ 0x28);
      lllllllIIlII[22] = (0x4A ^ 0x5C);
      lllllllIIlII[23] = (0x20 ^ 0x37);
      lllllllIIlII[24] = (0xE ^ 0x5F ^ 0x1E ^ 0x57);
      lllllllIIlII[25] = (124 + 26 - 63 + 48 ^ 60 + '' - 158 + 118);
      lllllllIIlII[26] = (0xDB ^ 0xB5 ^ 0x23 ^ 0x57);
    }
    
    private static String llIIIIlIIIlIll(String llllllllllllllIllIIIlIIIlIIIIllI, String llllllllllllllIllIIIlIIIlIIIIlIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIllIIIlIIIlIIIlIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIIlIIIlIIIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIllIIIlIIIlIIIlIlI = Cipher.getInstance("Blowfish");
        llllllllllllllIllIIIlIIIlIIIlIlI.init(lllllllIIlII[2], llllllllllllllIllIIIlIIIlIIIlIll);
        return new String(llllllllllllllIllIIIlIIIlIIIlIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIIlIIIlIIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIllIIIlIIIlIIIlIIl)
      {
        llllllllllllllIllIIIlIIIlIIIlIIl.printStackTrace();
      }
      return null;
    }
    
    public int getMeta()
    {
      ;
      return meta;
    }
    
    private EnumFlowerType(BlockFlower.EnumFlowerColor llllllllllllllIllIIIlIIIlIllllIl, int llllllllllllllIllIIIlIIIlIllIlIl, String llllllllllllllIllIIIlIIIlIllIlII, String llllllllllllllIllIIIlIIIlIllIIll)
    {
      blockType = llllllllllllllIllIIIlIIIlIllllIl;
      meta = llllllllllllllIllIIIlIIIlIllllII;
      name = llllllllllllllIllIIIlIIIlIllIlII;
      unlocalizedName = llllllllllllllIllIIIlIIIlIllIIll;
    }
    
    private static String llIIIIlIIlIIlI(String llllllllllllllIllIIIlIIIIlllIIll, String llllllllllllllIllIIIlIIIIlllIIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIllIIIlIIIIlllIIll = new String(Base64.getDecoder().decode(llllllllllllllIllIIIlIIIIlllIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIllIIIlIIIIlllIllI = new StringBuilder();
      char[] llllllllllllllIllIIIlIIIIlllIlIl = llllllllllllllIllIIIlIIIIlllIIlI.toCharArray();
      int llllllllllllllIllIIIlIIIIlllIlII = lllllllIIlII[0];
      boolean llllllllllllllIllIIIlIIIIllIlllI = llllllllllllllIllIIIlIIIIlllIIll.toCharArray();
      float llllllllllllllIllIIIlIIIIllIllIl = llllllllllllllIllIIIlIIIIllIlllI.length;
      char llllllllllllllIllIIIlIIIIllIllII = lllllllIIlII[0];
      while (llIIIIlIlIIIlI(llllllllllllllIllIIIlIIIIllIllII, llllllllllllllIllIIIlIIIIllIllIl))
      {
        char llllllllllllllIllIIIlIIIIllllIIl = llllllllllllllIllIIIlIIIIllIlllI[llllllllllllllIllIIIlIIIIllIllII];
        "".length();
        "".length();
        if ((103 + 28 - 122 + 140 ^ 6 + '' - 87 + 96) <= 0) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIllIIIlIIIIlllIllI);
    }
    
    public static EnumFlowerType getType(BlockFlower.EnumFlowerColor llllllllllllllIllIIIlIIIlIlIIllI, int llllllllllllllIllIIIlIIIlIlIIlIl)
    {
      ;
      ;
      ;
      EnumFlowerType[] llllllllllllllIllIIIlIIIlIlIIlll = TYPES_FOR_BLOCK[llllllllllllllIllIIIlIIIlIlIIllI.ordinal()];
      if ((!llIIIIlIlIIIIl(llllllllllllllIllIIIlIIIlIlIIlIl)) || (llIIIIlIlIIIII(llllllllllllllIllIIIlIIIlIlIIlIl, llllllllllllllIllIIIlIIIlIlIIlll.length))) {
        llllllllllllllIllIIIlIIIlIlIIlIl = lllllllIIlII[0];
      }
      return llllllllllllllIllIIIlIIIlIlIIlll[llllllllllllllIllIIIlIIIlIlIIlIl];
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    private static boolean llIIIIlIlIIIII(int ???, int arg1)
    {
      int i;
      int llllllllllllllIllIIIlIIIIlIllIlI;
      return ??? >= i;
    }
    
    private static boolean llIIIIlIlIIIIl(int ???)
    {
      byte llllllllllllllIllIIIlIIIIlIlIlII;
      return ??? >= 0;
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private EnumFlowerType(BlockFlower.EnumFlowerColor llllllllllllllIllIIIlIIIllIIlllI, int llllllllllllllIllIIIlIIIllIIllIl, String llllllllllllllIllIIIlIIIllIIllII)
    {
      llllllllllllllIllIIIlIIIllIIllll.<init>(llllllllllllllIllIIIlIIIllIIlIlI, llllllllllllllIllIIIlIIIllIIlIIl, llllllllllllllIllIIIlIIIllIIlllI, llllllllllllllIllIIIlIIIllIIllIl, llllllllllllllIllIIIlIIIllIIllII, llllllllllllllIllIIIlIIIllIIllII);
    }
  }
}

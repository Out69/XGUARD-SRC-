package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.StatCollector;

public class BlockPrismarine
  extends Block
{
  public MapColor getMapColor(IBlockState llllllllllllllllllIIIIlIllllIIIl)
  {
    ;
    if (llIIlIlIIlIl(llllllllllllllllllIIIIlIllllIIIl.getValue(VARIANT), EnumType.ROUGH))
    {
      "".length();
      if (-" ".length() <= (0x5B ^ 0x5F)) {
        break label46;
      }
      return null;
    }
    label46:
    return MapColor.diamondColor;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllllllIIIIlIlllIlIIl)
  {
    ;
    return ((EnumType)llllllllllllllllllIIIIlIlllIlIIl.getValue(VARIANT)).getMetadata();
  }
  
  private static String llIIIllllIlI(String llllllllllllllllllIIIIlIllIlIIII, String llllllllllllllllllIIIIlIllIIllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIIIIlIllIlIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIIIIlIllIIllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIIIIlIllIlIIlI = Cipher.getInstance("Blowfish");
      llllllllllllllllllIIIIlIllIlIIlI.init(lllllllIlI[2], llllllllllllllllllIIIIlIllIlIIll);
      return new String(llllllllllllllllllIIIIlIllIlIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllllIIIIlIllIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIIIIlIllIlIIIl)
    {
      llllllllllllllllllIIIIlIllIlIIIl.printStackTrace();
    }
    return null;
  }
  
  private static String llIIIlllIlll(String llllllllllllllllllIIIIlIllIIIIIl, String llllllllllllllllllIIIIlIllIIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIIIIlIllIIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIIIIlIllIIIIII.getBytes(StandardCharsets.UTF_8)), lllllllIlI[4]), "DES");
      Cipher llllllllllllllllllIIIIlIllIIIlIl = Cipher.getInstance("DES");
      llllllllllllllllllIIIIlIllIIIlIl.init(lllllllIlI[2], llllllllllllllllllIIIIlIllIIIllI);
      return new String(llllllllllllllllllIIIIlIllIIIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllllllIIIIlIllIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIIIIlIllIIIlII)
    {
      llllllllllllllllllIIIIlIllIIIlII.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIIlIlIIlIl(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllllllIIIIlIlIIllllI;
    return ??? == localObject;
  }
  
  private static String llIIIllllIll(String llllllllllllllllllIIIIlIlIlIlllI, String llllllllllllllllllIIIIlIlIlIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllllIIIIlIlIlIlllI = new String(Base64.getDecoder().decode(llllllllllllllllllIIIIlIlIlIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllIIIIlIlIllIIIl = new StringBuilder();
    char[] llllllllllllllllllIIIIlIlIllIIII = llllllllllllllllllIIIIlIlIlIllIl.toCharArray();
    int llllllllllllllllllIIIIlIlIlIllll = lllllllIlI[0];
    long llllllllllllllllllIIIIlIlIlIlIIl = llllllllllllllllllIIIIlIlIlIlllI.toCharArray();
    int llllllllllllllllllIIIIlIlIlIlIII = llllllllllllllllllIIIIlIlIlIlIIl.length;
    int llllllllllllllllllIIIIlIlIlIIlll = lllllllIlI[0];
    while (llIIlIlIIllI(llllllllllllllllllIIIIlIlIlIIlll, llllllllllllllllllIIIIlIlIlIlIII))
    {
      char llllllllllllllllllIIIIlIlIllIlII = llllllllllllllllllIIIIlIlIlIlIIl[llllllllllllllllllIIIIlIlIlIIlll];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllllIIIIlIlIllIIIl);
  }
  
  private static boolean llIIlIlIIllI(int ???, int arg1)
  {
    int i;
    float llllllllllllllllllIIIIlIlIlIIIlI;
    return ??? < i;
  }
  
  private static void llIIlIlIIlII()
  {
    lllllllIlI = new int[5];
    lllllllIlI[0] = ((0xEC ^ 0xC7) & (0x55 ^ 0x7E ^ 0xFFFFFFFF));
    lllllllIlI[1] = " ".length();
    lllllllIlI[2] = "  ".length();
    lllllllIlI[3] = "   ".length();
    lllllllIlI[4] = (0x38 ^ 0x30);
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllllllIIIIlIlllIIlll, new IProperty[] { VARIANT });
  }
  
  static
  {
    llIIlIlIIlII();
    llIIIlllllII();
    VARIANT = PropertyEnum.create(lllllIllIl[lllllllIlI[0]], EnumType.class);
    ROUGH_META = EnumType.ROUGH.getMetadata();
    BRICKS_META = EnumType.BRICKS.getMetadata();
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllllllIIIIlIlllIIIlI)
  {
    ;
    ;
    return llllllllllllllllllIIIIlIlllIIIll.getDefaultState().withProperty(VARIANT, EnumType.byMetadata(llllllllllllllllllIIIIlIlllIIIlI));
  }
  
  public BlockPrismarine()
  {
    llllllllllllllllllIIIIlIlllllIIl.<init>(Material.rock);
    llllllllllllllllllIIIIlIlllllIII.setDefaultState(blockState.getBaseState().withProperty(VARIANT, EnumType.ROUGH));
    "".length();
  }
  
  public int damageDropped(IBlockState llllllllllllllllllIIIIlIlllIllIl)
  {
    ;
    return ((EnumType)llllllllllllllllllIIIIlIlllIllIl.getValue(VARIANT)).getMetadata();
  }
  
  public String getLocalizedName()
  {
    ;
    return StatCollector.translateToLocal(String.valueOf(new StringBuilder(String.valueOf(llllllllllllllllllIIIIlIllllIllI.getUnlocalizedName())).append(lllllIllIl[lllllllIlI[1]]).append(EnumType.ROUGH.getUnlocalizedName()).append(lllllIllIl[lllllllIlI[2]])));
  }
  
  private static void llIIIlllllII()
  {
    lllllIllIl = new String[lllllllIlI[3]];
    lllllIllIl[lllllllIlI[0]] = llIIIlllIlll("QSWv9NXEqUg=", "OfaFp");
    lllllIllIl[lllllllIlI[1]] = llIIIllllIlI("wQmZs2gzvDA=", "PImSF");
    lllllIllIl[lllllllIlI[2]] = llIIIllllIll("SwMzDAo=", "emRao");
  }
  
  public void getSubBlocks(Item llllllllllllllllllIIIIlIllIllIIl, CreativeTabs llllllllllllllllllIIIIlIllIllIll, List<ItemStack> llllllllllllllllllIIIIlIllIllIII)
  {
    ;
    ;
    new ItemStack(llllllllllllllllllIIIIlIllIllIIl, lllllllIlI[1], ROUGH_META);
    "".length();
    new ItemStack(llllllllllllllllllIIIIlIllIllIIl, lllllllIlI[1], BRICKS_META);
    "".length();
    new ItemStack(llllllllllllllllllIIIIlIllIllIIl, lllllllIlI[1], DARK_META);
    "".length();
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    private static boolean llIIlIlllIlIIl(int ???)
    {
      char llllllllllllllIlIlIllIllIlIIllIl;
      return ??? >= 0;
    }
    
    private EnumType(int llllllllllllllIlIlIllIlllIIlIlIl, String llllllllllllllIlIlIllIlllIIllIlI, String llllllllllllllIlIlIllIlllIIlIIll)
    {
      meta = llllllllllllllIlIlIllIlllIIlIlIl;
      name = llllllllllllllIlIlIllIlllIIllIlI;
      unlocalizedName = llllllllllllllIlIlIllIlllIIlIIll;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    private static String llIIlIlllIIlIl(String llllllllllllllIlIlIllIllIlIlllII, String llllllllllllllIlIlIllIllIlIllIIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIlIllIllIlIlllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIllIllIlIllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIlIlIllIllIlIllllI = Cipher.getInstance("Blowfish");
        llllllllllllllIlIlIllIllIlIllllI.init(lIIIIlIIlllll[2], llllllllllllllIlIlIllIllIlIlllll);
        return new String(llllllllllllllIlIlIllIllIlIllllI.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIllIllIlIlllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIlIllIllIlIlllIl)
      {
        llllllllllllllIlIlIllIllIlIlllIl.printStackTrace();
      }
      return null;
    }
    
    private static void llIIlIlllIIllI()
    {
      lIIIIlIIllllI = new String[lIIIIlIIlllll[9]];
      lIIIIlIIllllI[lIIIIlIIlllll[0]] = llIIlIlllIIlII("PgwsKzs=", "lCyls");
      lIIIIlIIllllI[lIIIIlIIlllll[1]] = llIIlIlllIIlII("Gzg7KwcKODs2Dw==", "kJRXj");
      lIIIIlIIllllI[lIIIIlIIlllll[2]] = llIIlIlllIIlIl("p3o3wH3a0qQ=", "VlQig");
      lIIIIlIIllllI[lIIIIlIIlllll[3]] = llIIlIlllIIlIl("0vZ69j785EI=", "PXjVc");
      lIIIIlIIllllI[lIIIIlIIlllll[4]] = llIIlIlllIIlII("Kj4ZPCw7PhkhJAUuAiYiMT8=", "ZLpOA");
      lIIIIlIIllllI[lIIIIlIIlllll[5]] = llIIlIlllIIlIl("suWWIvJ1A34=", "cglXd");
      lIIIIlIIllllI[lIIIIlIIlllll[6]] = llIIlIlllIIlII("FgURJQ==", "RDCnF");
      lIIIIlIIllllI[lIIIIlIIlllll[7]] = llIIlIlllIIlII("BSM2HgsRMC0GOQAwLRsx", "aBDuT");
      lIIIIlIIllllI[lIIIIlIIlllll[8]] = llIIlIlllIIlIl("T2JlgBah8rM=", "lotQL");
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private static void llIIlIlllIIlll()
    {
      lIIIIlIIlllll = new int[10];
      lIIIIlIIlllll[0] = ((45 + 50 - 50 + 120 ^ 54 + '' - 90 + 51) & (56 + 32 - 23 + 86 ^ 27 + 121 - 55 + 73 ^ -" ".length()));
      lIIIIlIIlllll[1] = " ".length();
      lIIIIlIIlllll[2] = "  ".length();
      lIIIIlIIlllll[3] = "   ".length();
      lIIIIlIIlllll[4] = (0x7F ^ 0x7B);
      lIIIIlIIlllll[5] = (0x48 ^ 0x4D);
      lIIIIlIIlllll[6] = (0xC3 ^ 0xC5);
      lIIIIlIIlllll[7] = (0x3A ^ 0x32 ^ 0xBE ^ 0xB1);
      lIIIIlIIlllll[8] = (0x2D ^ 0x25);
      lIIIIlIIlllll[9] = ('ª' + 21 - 185 + 171 ^ '²' + 65 - 80 + 21);
    }
    
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    public static EnumType byMetadata(int llllllllllllllIlIlIllIlllIIIlIll)
    {
      ;
      if ((!llIIlIlllIlIIl(llllllllllllllIlIlIllIlllIIIlIll)) || (llIIlIlllIlIII(llllllllllllllIlIlIllIlllIIIlIlI, META_LOOKUP.length))) {
        llllllllllllllIlIlIllIlllIIIlIlI = lIIIIlIIlllll[0];
      }
      return META_LOOKUP[llllllllllllllIlIlIllIlllIIIlIlI];
    }
    
    static
    {
      llIIlIlllIIlll();
      llIIlIlllIIllI();
      byte llllllllllllllIlIlIllIlllIlIIIll;
      long llllllllllllllIlIlIllIlllIlIIllI;
      ROUGH = new EnumType(lIIIIlIIllllI[lIIIIlIIlllll[0]], lIIIIlIIlllll[0], lIIIIlIIlllll[0], lIIIIlIIllllI[lIIIIlIIlllll[1]], lIIIIlIIllllI[lIIIIlIIlllll[2]]);
      BRICKS = new EnumType(lIIIIlIIllllI[lIIIIlIIlllll[3]], lIIIIlIIlllll[1], lIIIIlIIlllll[1], lIIIIlIIllllI[lIIIIlIIlllll[4]], lIIIIlIIllllI[lIIIIlIIlllll[5]]);
      DARK = new EnumType(lIIIIlIIllllI[lIIIIlIIlllll[6]], lIIIIlIIlllll[2], lIIIIlIIlllll[2], lIIIIlIIllllI[lIIIIlIIlllll[7]], lIIIIlIIllllI[lIIIIlIIlllll[8]]);
      ENUM$VALUES = new EnumType[] { ROUGH, BRICKS, DARK };
      META_LOOKUP = new EnumType[values().length];
      double llllllllllllllIlIlIllIlllIlIIlII = (llllllllllllllIlIlIllIlllIlIIIll = values()).length;
      long llllllllllllllIlIlIllIlllIlIIlIl = lIIIIlIIlllll[0];
      "".length();
      if (" ".length() != " ".length()) {
        return;
      }
      while (!llIIlIlllIlIII(llllllllllllllIlIlIllIlllIlIIlIl, llllllllllllllIlIlIllIlllIlIIlII))
      {
        EnumType llllllllllllllIlIlIllIlllIlIIlll = llllllllllllllIlIlIllIlllIlIIIll[llllllllllllllIlIlIllIlllIlIIlIl];
        META_LOOKUP[llllllllllllllIlIlIllIlllIlIIlll.getMetadata()] = llllllllllllllIlIlIllIlllIlIIlll;
        llllllllllllllIlIlIllIlllIlIIlIl++;
      }
    }
    
    private static boolean llIIlIlllIlIlI(int ???, int arg1)
    {
      int i;
      String llllllllllllllIlIlIllIllIlIIllll;
      return ??? < i;
    }
    
    private static String llIIlIlllIIlII(String llllllllllllllIlIlIllIllIlllIIIl, String llllllllllllllIlIlIllIllIllIlIll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIlIlIllIllIlllIIIl = new String(Base64.getDecoder().decode(llllllllllllllIlIlIllIllIlllIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIlIlIllIllIllIllll = new StringBuilder();
      char[] llllllllllllllIlIlIllIllIllIlllI = llllllllllllllIlIlIllIllIllIlIll.toCharArray();
      int llllllllllllllIlIlIllIllIllIllIl = lIIIIlIIlllll[0];
      long llllllllllllllIlIlIllIllIllIIlll = llllllllllllllIlIlIllIllIlllIIIl.toCharArray();
      int llllllllllllllIlIlIllIllIllIIllI = llllllllllllllIlIlIllIllIllIIlll.length;
      char llllllllllllllIlIlIllIllIllIIlIl = lIIIIlIIlllll[0];
      while (llIIlIlllIlIlI(llllllllllllllIlIlIllIllIllIIlIl, llllllllllllllIlIlIllIllIllIIllI))
      {
        char llllllllllllllIlIlIllIllIlllIIlI = llllllllllllllIlIlIllIllIllIIlll[llllllllllllllIlIlIllIllIllIIlIl];
        "".length();
        "".length();
        if (((0x31 ^ 0x6F) & (0xD1 ^ 0x8F ^ 0xFFFFFFFF)) < ((0x37 ^ 0x21) & (0xAF ^ 0xB9 ^ 0xFFFFFFFF))) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIlIlIllIllIllIllll);
    }
    
    private static boolean llIIlIlllIlIII(int ???, int arg1)
    {
      int i;
      boolean llllllllllllllIlIlIllIllIlIlIIll;
      return ??? >= i;
    }
    
    public String getUnlocalizedName()
    {
      ;
      return unlocalizedName;
    }
  }
}

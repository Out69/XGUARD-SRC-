package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;

public class BlockSand
  extends BlockFalling
{
  public BlockSand()
  {
    llllllllllllllllIIlIllIllllllIll.setDefaultState(blockState.getBaseState().withProperty(VARIANT, EnumType.SAND));
  }
  
  private static void lIllIIlIIlIIl()
  {
    lllIlIIIIII = new String[lllIlIIIIll[1]];
    lllIlIIIIII[lllIlIIIIll[0]] = lIllIIlIIlIII("kDIn7LuFG4c=", "ZVxvp");
  }
  
  private static void lIllIIlIIllll()
  {
    lllIlIIIIll = new int[4];
    lllIlIIIIll[0] = ((0x7F ^ 0x58) & (0x6B ^ 0x4C ^ 0xFFFFFFFF));
    lllIlIIIIll[1] = " ".length();
    lllIlIIIIll[2] = (0x9C ^ 0x94);
    lllIlIIIIll[3] = "  ".length();
  }
  
  static
  {
    lIllIIlIIllll();
    lIllIIlIIlIIl();
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllllIIlIllIllllIIIll)
  {
    ;
    return ((EnumType)llllllllllllllllIIlIllIllllIIIll.getValue(VARIANT)).getMapColor();
  }
  
  public void getSubBlocks(Item llllllllllllllllIIlIllIllllIlIll, CreativeTabs llllllllllllllllIIlIllIllllIlllI, List<ItemStack> llllllllllllllllIIlIllIllllIlIlI)
  {
    ;
    ;
    ;
    ;
    float llllllllllllllllIIlIllIllllIIlll = (llllllllllllllllIIlIllIllllIIllI = EnumType.values()).length;
    short llllllllllllllllIIlIllIllllIlIII = lllIlIIIIll[0];
    "".length();
    if (null != null) {
      return;
    }
    while (!lIllIIlIlIIII(llllllllllllllllIIlIllIllllIlIII, llllllllllllllllIIlIllIllllIIlll))
    {
      EnumType llllllllllllllllIIlIllIllllIllII = llllllllllllllllIIlIllIllllIIllI[llllllllllllllllIIlIllIllllIlIII];
      new ItemStack(llllllllllllllllIIlIllIllllIlIll, lllIlIIIIll[1], llllllllllllllllIIlIllIllllIllII.getMetadata());
      "".length();
    }
  }
  
  public int damageDropped(IBlockState llllllllllllllllIIlIllIlllllIlll)
  {
    ;
    return ((EnumType)llllllllllllllllIIlIllIlllllIlll.getValue(VARIANT)).getMetadata();
  }
  
  private static boolean lIllIIlIlIIII(int ???, int arg1)
  {
    int i;
    short llllllllllllllllIIlIllIlllIIIlII;
    return ??? >= i;
  }
  
  public int getMetaFromState(IBlockState llllllllllllllllIIlIllIlllIllIII)
  {
    ;
    return ((EnumType)llllllllllllllllIIlIllIlllIllIII.getValue(VARIANT)).getMetadata();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllllIIlIllIlllIlIllI, new IProperty[] { VARIANT });
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllllIIlIllIlllIlllII)
  {
    ;
    ;
    return llllllllllllllllIIlIllIlllIlllIl.getDefaultState().withProperty(VARIANT, EnumType.byMetadata(llllllllllllllllIIlIllIlllIlllII));
  }
  
  private static String lIllIIlIIlIII(String llllllllllllllllIIlIllIlllIIllIl, String llllllllllllllllIIlIllIlllIIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIlIllIlllIlIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIlIllIlllIIllII.getBytes(StandardCharsets.UTF_8)), lllIlIIIIll[2]), "DES");
      Cipher llllllllllllllllIIlIllIlllIIllll = Cipher.getInstance("DES");
      llllllllllllllllIIlIllIlllIIllll.init(lllIlIIIIll[3], llllllllllllllllIIlIllIlllIlIIII);
      return new String(llllllllllllllllIIlIllIlllIIllll.doFinal(Base64.getDecoder().decode(llllllllllllllllIIlIllIlllIIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIlIllIlllIIlllI)
    {
      llllllllllllllllIIlIllIlllIIlllI.printStackTrace();
    }
    return null;
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    private static boolean lIIlIllIIlllII(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllIIIllllIIIllIlIll;
      return ??? < i;
    }
    
    private EnumType(int lllllllllllllllIIIllllIlIIIlIIlI, String lllllllllllllllIIIllllIlIIIlIIII, String lllllllllllllllIIIllllIlIIIlllII, MapColor lllllllllllllllIIIllllIlIIIllIlI)
    {
      meta = lllllllllllllllIIIllllIlIIIlIIlI;
      name = lllllllllllllllIIIllllIlIIIllllI;
      mapColor = lllllllllllllllIIIllllIlIIIllIlI;
      unlocalizedName = lllllllllllllllIIIllllIlIIIlllII;
    }
    
    private static boolean lIIlIllIIllIlI(int ???, int arg1)
    {
      int i;
      float lllllllllllllllIIIllllIIIlllIIlI;
      return ??? >= i;
    }
    
    static
    {
      lIIlIllIIllIIl();
      lIIlIlIlllIlll();
      short lllllllllllllllIIIllllIlIIlllIII;
      int lllllllllllllllIIIllllIlIIlllllI;
      SAND = new EnumType(llIIIlIlIlIl[llIIIlIlIlll[0]], llIIIlIlIlll[0], llIIIlIlIlll[0], llIIIlIlIlIl[llIIIlIlIlll[1]], llIIIlIlIlIl[llIIIlIlIlll[2]], MapColor.sandColor);
      RED_SAND = new EnumType(llIIIlIlIlIl[llIIIlIlIlll[3]], llIIIlIlIlll[1], llIIIlIlIlll[1], llIIIlIlIlIl[llIIIlIlIlll[4]], llIIIlIlIlIl[llIIIlIlIlll[5]], MapColor.adobeColor);
      ENUM$VALUES = new EnumType[] { SAND, RED_SAND };
      META_LOOKUP = new EnumType[values().length];
      String lllllllllllllllIIIllllIlIIlllIlI = (lllllllllllllllIIIllllIlIIlllIII = values()).length;
      long lllllllllllllllIIIllllIlIIllllII = llIIIlIlIlll[0];
      "".length();
      if ("  ".length() <= 0) {
        return;
      }
      while (!lIIlIllIIllIlI(lllllllllllllllIIIllllIlIIllllII, lllllllllllllllIIIllllIlIIlllIlI))
      {
        EnumType lllllllllllllllIIIllllIlIIllllll = lllllllllllllllIIIllllIlIIlllIII[lllllllllllllllIIIllllIlIIllllII];
        META_LOOKUP[lllllllllllllllIIIllllIlIIllllll.getMetadata()] = lllllllllllllllIIIllllIlIIllllll;
        lllllllllllllllIIIllllIlIIllllII++;
      }
    }
    
    private static String lIIlIlIlllIlII(String lllllllllllllllIIIllllIIlIllllII, String lllllllllllllllIIIllllIIlIlllIll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIIIllllIIlIllllII = new String(Base64.getDecoder().decode(lllllllllllllllIIIllllIIlIllllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIIIllllIIllIIIlll = new StringBuilder();
      char[] lllllllllllllllIIIllllIIllIIIlIl = lllllllllllllllIIIllllIIlIlllIll.toCharArray();
      int lllllllllllllllIIIllllIIllIIIIll = llIIIlIlIlll[0];
      int lllllllllllllllIIIllllIIlIllIllI = lllllllllllllllIIIllllIIlIllllII.toCharArray();
      byte lllllllllllllllIIIllllIIlIllIlII = lllllllllllllllIIIllllIIlIllIllI.length;
      short lllllllllllllllIIIllllIIlIllIIll = llIIIlIlIlll[0];
      while (lIIlIllIIlllII(lllllllllllllllIIIllllIIlIllIIll, lllllllllllllllIIIllllIIlIllIlII))
      {
        char lllllllllllllllIIIllllIIllIIlIll = lllllllllllllllIIIllllIIlIllIllI[lllllllllllllllIIIllllIIlIllIIll];
        "".length();
        "".length();
        if (null != null) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIIIllllIIllIIIlll);
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    public String getUnlocalizedName()
    {
      ;
      return unlocalizedName;
    }
    
    private static String lIIlIlIlllIllI(String lllllllllllllllIIIllllIIlIlIIlII, String lllllllllllllllIIIllllIIlIIllllI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIIllllIIlIlIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIllllIIlIIllllI.getBytes(StandardCharsets.UTF_8)), llIIIlIlIlll[7]), "DES");
        Cipher lllllllllllllllIIIllllIIlIlIllII = Cipher.getInstance("DES");
        lllllllllllllllIIIllllIIlIlIllII.init(llIIIlIlIlll[2], lllllllllllllllIIIllllIIlIlIllIl);
        return new String(lllllllllllllllIIIllllIIlIlIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIllllIIlIlIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIIllllIIlIlIIllI)
      {
        lllllllllllllllIIIllllIIlIlIIllI.printStackTrace();
      }
      return null;
    }
    
    public MapColor getMapColor()
    {
      ;
      return mapColor;
    }
    
    public static EnumType byMetadata(int lllllllllllllllIIIllllIIlllllIll)
    {
      ;
      if ((!lIIlIllIIllIll(lllllllllllllllIIIllllIIlllllIll)) || (lIIlIllIIllIlI(lllllllllllllllIIIllllIIlllllIlI, META_LOOKUP.length))) {
        lllllllllllllllIIIllllIIlllllIlI = llIIIlIlIlll[0];
      }
      return META_LOOKUP[lllllllllllllllIIIllllIIlllllIlI];
    }
    
    private static void lIIlIllIIllIIl()
    {
      llIIIlIlIlll = new int[8];
      llIIIlIlIlll[0] = ((0x18 ^ 0x58) & (0x3A ^ 0x7A ^ 0xFFFFFFFF));
      llIIIlIlIlll[1] = " ".length();
      llIIIlIlIlll[2] = "  ".length();
      llIIIlIlIlll[3] = "   ".length();
      llIIIlIlIlll[4] = (82 + 52 - -24 + 41 ^ 15 + '' - -2 + 41);
      llIIIlIlIlll[5] = (0x15 ^ 0x38 ^ 0x1E ^ 0x36);
      llIIIlIlIlll[6] = (0xA7 ^ 0xA1);
      llIIIlIlIlll[7] = (0x2E ^ 0x26);
    }
    
    private static boolean lIIlIllIIllIll(int ???)
    {
      byte lllllllllllllllIIIllllIIIllIIlll;
      return ??? >= 0;
    }
    
    private static void lIIlIlIlllIlll()
    {
      llIIIlIlIlIl = new String[llIIIlIlIlll[6]];
      llIIIlIlIlIl[llIIIlIlIlll[0]] = lIIlIlIlllIlII("CRg5IQ==", "ZYweA");
      llIIIlIlIlIl[llIIIlIlIlll[1]] = lIIlIlIlllIlIl("8FCetSpnbxA=", "zbFyF");
      llIIIlIlIlIl[llIIIlIlIlll[2]] = lIIlIlIlllIlII("FjchIzYeJg==", "rRGBC");
      llIIIlIlIlIl[llIIIlIlIlll[3]] = lIIlIlIlllIllI("01cwSyaci0JVxywcC/ArCA==", "gCAAI");
      llIIIlIlIlIl[llIIIlIlIlll[4]] = lIIlIlIlllIllI("Yt1Xe7kfgwzeHKvr2QU9Gw==", "XMSor");
      llIIIlIlIlIl[llIIIlIlIlll[5]] = lIIlIlIlllIlIl("doMOF8LNI9A=", "ZycUw");
    }
    
    private static String lIIlIlIlllIlIl(String lllllllllllllllIIIllllIIlIIIIIIl, String lllllllllllllllIIIllllIIlIIIIIII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIIllllIIlIIIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIllllIIlIIIIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIIIllllIIlIIIlIll = Cipher.getInstance("Blowfish");
        lllllllllllllllIIIllllIIlIIIlIll.init(llIIIlIlIlll[2], lllllllllllllllIIIllllIIlIIIllIl);
        return new String(lllllllllllllllIIIllllIIlIIIlIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIllllIIlIIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIIllllIIlIIIlIIl)
      {
        lllllllllllllllIIIllllIIlIIIlIIl.printStackTrace();
      }
      return null;
    }
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public class BlockJukebox
  extends BlockContainer
{
  public int getMetaFromState(IBlockState llllllllllllllIIllIllllIIlIIIIII)
  {
    ;
    if (lllIlIIlllIIIl(((Boolean)llllllllllllllIIllIllllIIlIIIIII.getValue(HAS_RECORD)).booleanValue()))
    {
      "".length();
      if ("   ".length() != ((0x2C ^ 0x33) & (0x4B ^ 0x54 ^ 0xFFFFFFFF))) {
        break label74;
      }
      return (0x80 ^ 0xB5) & (0x46 ^ 0x73 ^ 0xFFFFFFFF);
    }
    label74:
    return lIIllIIIIIllI[0];
  }
  
  public TileEntity createNewTileEntity(World llllllllllllllIIllIllllIIlIllIlI, int llllllllllllllIIllIllllIIlIllIIl)
  {
    return new TileEntityJukebox();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIIllIllllIIIllllIl, new IProperty[] { HAS_RECORD });
  }
  
  public void insertRecord(World llllllllllllllIIllIllllIlIIlllll, BlockPos llllllllllllllIIllIllllIlIlIIIll, IBlockState llllllllllllllIIllIllllIlIIlllIl, ItemStack llllllllllllllIIllIllllIlIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIlIIlllIIlI(isRemote))
    {
      TileEntity llllllllllllllIIllIllllIlIlIIIII = llllllllllllllIIllIllllIlIIlllll.getTileEntity(llllllllllllllIIllIllllIlIlIIIll);
      if (lllIlIIlllIIIl(llllllllllllllIIllIllllIlIlIIIII instanceof TileEntityJukebox))
      {
        ((TileEntityJukebox)llllllllllllllIIllIllllIlIlIIIII).setRecord(new ItemStack(llllllllllllllIIllIllllIlIlIIIIl.getItem(), lIIllIIIIIllI[2], llllllllllllllIIllIllllIlIlIIIIl.getMetadata()));
        "".length();
      }
    }
  }
  
  private static boolean lllIlIIlllIIlI(int ???)
  {
    double llllllllllllllIIllIllllIIIlIlIlI;
    return ??? == 0;
  }
  
  public void breakBlock(World llllllllllllllIIllIllllIIllIlllI, BlockPos llllllllllllllIIllIllllIIllIllIl, IBlockState llllllllllllllIIllIllllIIlllIIII)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIIllIllllIIlllIIll.dropRecord(llllllllllllllIIllIllllIIllIlllI, llllllllllllllIIllIllllIIllIllIl, llllllllllllllIIllIllllIIlllIIII);
    llllllllllllllIIllIllllIIlllIIll.breakBlock(llllllllllllllIIllIllllIIllIlllI, llllllllllllllIIllIllllIIllIllIl, llllllllllllllIIllIllllIIlllIIII);
  }
  
  protected BlockJukebox()
  {
    llllllllllllllIIllIllllIlIllllIl.<init>(Material.wood, MapColor.dirtColor);
    llllllllllllllIIllIllllIlIllllII.setDefaultState(blockState.getBaseState().withProperty(HAS_RECORD, Boolean.valueOf(lIIllIIIIIllI[0])));
    "".length();
  }
  
  private static boolean lllIlIIlllIlII(int ???)
  {
    short llllllllllllllIIllIllllIIIlIlIII;
    return ??? > 0;
  }
  
  public void dropBlockAsItemWithChance(World llllllllllllllIIllIllllIIlIlllll, BlockPos llllllllllllllIIllIllllIIlIllllI, IBlockState llllllllllllllIIllIllllIIlIlllIl, float llllllllllllllIIllIllllIIlIlllII, int llllllllllllllIIllIllllIIllIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIlIIlllIIlI(isRemote)) {
      llllllllllllllIIllIllllIIllIIllI.dropBlockAsItemWithChance(llllllllllllllIIllIllllIIlIlllll, llllllllllllllIIllIllllIIlIllllI, llllllllllllllIIllIllllIIlIlllIl, llllllllllllllIIllIllllIIlIlllII, lIIllIIIIIllI[0]);
    }
  }
  
  static
  {
    lllIlIIlllIIII();
    lllIlIIllIllll();
  }
  
  private static boolean lllIlIIlllIIll(Object ???)
  {
    boolean llllllllllllllIIllIllllIIIlIlllI;
    return ??? != null;
  }
  
  private static String lllIlIIllIlllI(String llllllllllllllIIllIllllIIIllIIll, String llllllllllllllIIllIllllIIIllIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllIllllIIIlllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllIllllIIIllIIlI.getBytes(StandardCharsets.UTF_8)), lIIllIIIIIllI[5]), "DES");
      Cipher llllllllllllllIIllIllllIIIllIlll = Cipher.getInstance("DES");
      llllllllllllllIIllIllllIIIllIlll.init(lIIllIIIIIllI[1], llllllllllllllIIllIllllIIIlllIII);
      return new String(llllllllllllllIIllIllllIIIllIlll.doFinal(Base64.getDecoder().decode(llllllllllllllIIllIllllIIIllIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllIllllIIIllIllI)
    {
      llllllllllllllIIllIllllIIIllIllI.printStackTrace();
    }
    return null;
  }
  
  private void dropRecord(World llllllllllllllIIllIllllIlIIIlllI, BlockPos llllllllllllllIIllIllllIlIIIIIIl, IBlockState llllllllllllllIIllIllllIlIIIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIlIIlllIIlI(isRemote))
    {
      TileEntity llllllllllllllIIllIllllIlIIIlIll = llllllllllllllIIllIllllIlIIIlllI.getTileEntity(llllllllllllllIIllIllllIlIIIllIl);
      if (lllIlIIlllIIIl(llllllllllllllIIllIllllIlIIIlIll instanceof TileEntityJukebox))
      {
        TileEntityJukebox llllllllllllllIIllIllllIlIIIlIlI = (TileEntityJukebox)llllllllllllllIIllIllllIlIIIlIll;
        ItemStack llllllllllllllIIllIllllIlIIIlIIl = llllllllllllllIIllIllllIlIIIlIlI.getRecord();
        if (lllIlIIlllIIll(llllllllllllllIIllIllllIlIIIlIIl))
        {
          llllllllllllllIIllIllllIlIIIlllI.playAuxSFX(lIIllIIIIIllI[3], llllllllllllllIIllIllllIlIIIllIl, lIIllIIIIIllI[0]);
          llllllllllllllIIllIllllIlIIIlllI.playRecord(llllllllllllllIIllIllllIlIIIllIl, null);
          llllllllllllllIIllIllllIlIIIlIlI.setRecord(null);
          float llllllllllllllIIllIllllIlIIIlIII = 0.7F;
          double llllllllllllllIIllIllllIlIIIIlll = rand.nextFloat() * llllllllllllllIIllIllllIlIIIlIII + (1.0F - llllllllllllllIIllIllllIlIIIlIII) * 0.5D;
          double llllllllllllllIIllIllllIlIIIIllI = rand.nextFloat() * llllllllllllllIIllIllllIlIIIlIII + (1.0F - llllllllllllllIIllIllllIlIIIlIII) * 0.2D + 0.6D;
          double llllllllllllllIIllIllllIlIIIIlIl = rand.nextFloat() * llllllllllllllIIllIllllIlIIIlIII + (1.0F - llllllllllllllIIllIllllIlIIIlIII) * 0.5D;
          ItemStack llllllllllllllIIllIllllIlIIIIlII = llllllllllllllIIllIllllIlIIIlIIl.copy();
          EntityItem llllllllllllllIIllIllllIlIIIIIll = new EntityItem(llllllllllllllIIllIllllIlIIIlllI, llllllllllllllIIllIllllIlIIIllIl.getX() + llllllllllllllIIllIllllIlIIIIlll, llllllllllllllIIllIllllIlIIIllIl.getY() + llllllllllllllIIllIllllIlIIIIllI, llllllllllllllIIllIllllIlIIIllIl.getZ() + llllllllllllllIIllIllllIlIIIIlIl, llllllllllllllIIllIllllIlIIIIlII);
          llllllllllllllIIllIllllIlIIIIIll.setDefaultPickupDelay();
          "".length();
        }
      }
    }
  }
  
  public boolean onBlockActivated(World llllllllllllllIIllIllllIlIllIllI, BlockPos llllllllllllllIIllIllllIlIllIlIl, IBlockState llllllllllllllIIllIllllIlIlIlIll, EntityPlayer llllllllllllllIIllIllllIlIllIIll, EnumFacing llllllllllllllIIllIllllIlIllIIlI, float llllllllllllllIIllIllllIlIllIIIl, float llllllllllllllIIllIllllIlIllIIII, float llllllllllllllIIllIllllIlIlIllll)
  {
    ;
    ;
    ;
    ;
    if (lllIlIIlllIIIl(((Boolean)llllllllllllllIIllIllllIlIlIlIll.getValue(HAS_RECORD)).booleanValue()))
    {
      llllllllllllllIIllIllllIlIllIlll.dropRecord(llllllllllllllIIllIllllIlIllIllI, llllllllllllllIIllIllllIlIllIlIl, llllllllllllllIIllIllllIlIlIlIll);
      llllllllllllllIIllIllllIlIlIlIll = llllllllllllllIIllIllllIlIlIlIll.withProperty(HAS_RECORD, Boolean.valueOf(lIIllIIIIIllI[0]));
      "".length();
      return lIIllIIIIIllI[2];
    }
    return lIIllIIIIIllI[0];
  }
  
  public boolean hasComparatorInputOverride()
  {
    return lIIllIIIIIllI[2];
  }
  
  public int getComparatorInputOverride(World llllllllllllllIIllIllllIIlIIlllI, BlockPos llllllllllllllIIllIllllIIlIIllIl)
  {
    ;
    ;
    ;
    ;
    TileEntity llllllllllllllIIllIllllIIlIlIIII = llllllllllllllIIllIllllIIlIIlllI.getTileEntity(llllllllllllllIIllIllllIIlIIllIl);
    if (lllIlIIlllIIIl(llllllllllllllIIllIllllIIlIlIIII instanceof TileEntityJukebox))
    {
      ItemStack llllllllllllllIIllIllllIIlIIllll = ((TileEntityJukebox)llllllllllllllIIllIllllIIlIlIIII).getRecord();
      if (lllIlIIlllIIll(llllllllllllllIIllIllllIIlIIllll)) {
        return Item.getIdFromItem(llllllllllllllIIllIllllIIlIIllll.getItem()) + lIIllIIIIIllI[2] - Item.getIdFromItem(Items.record_13);
      }
    }
    return lIIllIIIIIllI[0];
  }
  
  private static void lllIlIIllIllll()
  {
    lIIllIIIIIlIl = new String[lIIllIIIIIllI[2]];
    lIIllIIIIIlIl[lIIllIIIIIllI[0]] = lllIlIIllIlllI("fi3AMcl3OzGSH0FsTyYfsQ==", "OtZQP");
  }
  
  private static boolean lllIlIIlllIIIl(int ???)
  {
    int llllllllllllllIIllIllllIIIlIllII;
    return ??? != 0;
  }
  
  private static void lllIlIIlllIIII()
  {
    lIIllIIIIIllI = new int[6];
    lIIllIIIIIllI[0] = ((0x16 ^ 0x2C) & (0x9C ^ 0xA6 ^ 0xFFFFFFFF));
    lIIllIIIIIllI[1] = "  ".length();
    lIIllIIIIIllI[2] = " ".length();
    lIIllIIIIIllI[3] = (0xEBEF & 0x17FD);
    lIIllIIIIIllI[4] = "   ".length();
    lIIllIIIIIllI[5] = (0x32 ^ 0x3A);
  }
  
  public int getRenderType()
  {
    return lIIllIIIIIllI[4];
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIIllIllllIIlIIIlII)
  {
    ;
    ;
    if (lllIlIIlllIlII(llllllllllllllIIllIllllIIlIIIlII))
    {
      "".length();
      if (-(40 + 100 - 9 + 22 ^ 122 + 38 - 106 + 103) < 0) {
        break label59;
      }
      return null;
    }
    label59:
    return HAS_RECORD.withProperty(lIIllIIIIIllI[2], Boolean.valueOf(lIIllIIIIIllI[0]));
  }
  
  public static class TileEntityJukebox
    extends TileEntity
  {
    public TileEntityJukebox() {}
    
    private static String lIlllIIIlllIII(String llllllllllllllIllIlIllIlIllIllII, String llllllllllllllIllIlIllIlIlllIIII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIllIlIllIlIllIllII = new String(Base64.getDecoder().decode(llllllllllllllIllIlIllIlIllIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIllIlIllIlIllIllll = new StringBuilder();
      char[] llllllllllllllIllIlIllIlIllIlllI = llllllllllllllIllIlIllIlIlllIIII.toCharArray();
      int llllllllllllllIllIlIllIlIllIllIl = llllIIlIllII[0];
      short llllllllllllllIllIlIllIlIllIIlll = llllllllllllllIllIlIllIlIllIllII.toCharArray();
      char llllllllllllllIllIlIllIlIllIIllI = llllllllllllllIllIlIllIlIllIIlll.length;
      double llllllllllllllIllIlIllIlIllIIlIl = llllIIlIllII[0];
      while (lIlllIIIlllllI(llllllllllllllIllIlIllIlIllIIlIl, llllllllllllllIllIlIllIlIllIIllI))
      {
        char llllllllllllllIllIlIllIlIlllIIlI = llllllllllllllIllIlIllIlIllIIlll[llllllllllllllIllIlIllIlIllIIlIl];
        "".length();
        "".length();
        if (((0x98 ^ 0x9C) & (0xB3 ^ 0xB7 ^ 0xFFFFFFFF)) != 0) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIllIlIllIlIllIllll);
    }
    
    private static boolean lIlllIIIlllIll(int ???)
    {
      double llllllllllllllIllIlIllIlIlIIllll;
      return ??? != 0;
    }
    
    private static String lIlllIIIllIlll(String llllllllllllllIllIlIllIlIlIllIlI, String llllllllllllllIllIlIllIlIlIllIll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIllIlIllIlIlIlllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIllIlIlIllIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIllIlIllIlIlIllllI = Cipher.getInstance("Blowfish");
        llllllllllllllIllIlIllIlIlIllllI.init(llllIIlIllII[3], llllllllllllllIllIlIllIlIlIlllll);
        return new String(llllllllllllllIllIlIllIlIlIllllI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIllIlIlIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIllIlIllIlIlIlllIl)
      {
        llllllllllllllIllIlIllIlIlIlllIl.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIlllIIIlllllI(int ???, int arg1)
    {
      int i;
      float llllllllllllllIllIlIllIlIlIlIIll;
      return ??? < i;
    }
    
    private static void lIlllIIIlllIIl()
    {
      llllIIlIlIll = new String[llllIIlIllII[6]];
      llllIIlIlIll[llllIIlIllII[0]] = lIlllIIIllIlll("87e5t+c6cEMkqabsKotKTw==", "NlCDs");
      llllIIlIlIll[llllIIlIllII[2]] = lIlllIIIlllIII("HREIBgQrPR8MGw==", "Otkiv");
      llllIIlIlIll[llllIIlIllII[3]] = lIlllIIIlllIII("Gxc3KSct", "IrTFU");
      llllIIlIlIll[llllIIlIllII[4]] = lIlllIIIlllIII("EAYWFxkm", "Bcuxk");
      llllIIlIlIll[llllIIlIllII[5]] = lIlllIIIlllIII("BA4vPzAyIjg1Lw==", "VkLPB");
    }
    
    public void readFromNBT(NBTTagCompound llllllllllllllIllIlIllIllIIIlIll)
    {
      ;
      ;
      llllllllllllllIllIlIllIllIIIllII.readFromNBT(llllllllllllllIllIlIllIllIIIlIll);
      if (lIlllIIIlllIll(llllllllllllllIllIlIllIllIIIlIll.hasKey(llllIIlIlIll[llllIIlIllII[0]], llllIIlIllII[1])))
      {
        llllllllllllllIllIlIllIllIIIllII.setRecord(ItemStack.loadItemStackFromNBT(llllllllllllllIllIlIllIllIIIlIll.getCompoundTag(llllIIlIlIll[llllIIlIllII[2]])));
        "".length();
        if ("   ".length() == "   ".length()) {}
      }
      else if (lIlllIIIllllII(llllllllllllllIllIlIllIllIIIlIll.getInteger(llllIIlIlIll[llllIIlIllII[3]])))
      {
        llllllllllllllIllIlIllIllIIIllII.setRecord(new ItemStack(Item.getItemById(llllllllllllllIllIlIllIllIIIlIll.getInteger(llllIIlIlIll[llllIIlIllII[4]])), llllIIlIllII[2], llllIIlIllII[0]));
      }
    }
    
    private static boolean lIlllIIIllllII(int ???)
    {
      float llllllllllllllIllIlIllIlIlIIllIl;
      return ??? > 0;
    }
    
    private static boolean lIlllIIIllllIl(Object ???)
    {
      String llllllllllllllIllIlIllIlIlIlIIIl;
      return ??? != null;
    }
    
    public void writeToNBT(NBTTagCompound llllllllllllllIllIlIllIllIIIIlll)
    {
      ;
      ;
      llllllllllllllIllIlIllIllIIIlIII.writeToNBT(llllllllllllllIllIlIllIllIIIIlll);
      if (lIlllIIIllllIl(llllllllllllllIllIlIllIllIIIlIII.getRecord())) {
        llllllllllllllIllIlIllIllIIIIlll.setTag(llllIIlIlIll[llllIIlIllII[5]], llllllllllllllIllIlIllIllIIIlIII.getRecord().writeToNBT(new NBTTagCompound()));
      }
    }
    
    private static void lIlllIIIlllIlI()
    {
      llllIIlIllII = new int[7];
      llllIIlIllII[0] = ((94 + 107 - 59 + 33 ^ 98 + 47 - 46 + 41) & (52 + 126 - 126 + 79 ^ 65 + 86 - 50 + 59 ^ -" ".length()));
      llllIIlIllII[1] = (113 + 16 - -19 + 59 ^ 61 + 111 - -10 + 15);
      llllIIlIllII[2] = " ".length();
      llllIIlIllII[3] = "  ".length();
      llllIIlIllII[4] = "   ".length();
      llllIIlIllII[5] = (0x6F ^ 0x25 ^ 0x61 ^ 0x2F);
      llllIIlIllII[6] = (0xB9 ^ 0xB3 ^ 0x76 ^ 0x79);
    }
    
    static
    {
      lIlllIIIlllIlI();
      lIlllIIIlllIIl();
    }
    
    public void setRecord(ItemStack llllllllllllllIllIlIllIlIlllllII)
    {
      ;
      ;
      record = llllllllllllllIllIlIllIlIlllllII;
      llllllllllllllIllIlIllIlIlllllIl.markDirty();
    }
    
    public ItemStack getRecord()
    {
      ;
      return record;
    }
  }
}

package net.minecraft.block;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockAir
  extends Block
{
  public boolean canCollideCheck(IBlockState llIlIIlIlllIIll, boolean llIlIIlIlllIIlI)
  {
    return llllIIl[1];
  }
  
  protected BlockAir()
  {
    llIlIIlIllllIll.<init>(Material.air);
  }
  
  static {}
  
  private static void lIllIlIll()
  {
    llllIIl = new int[3];
    llllIIl[0] = (-" ".length());
    llllIIl[1] = ((0x1 ^ 0x4C) & (0x3A ^ 0x77 ^ 0xFFFFFFFF));
    llllIIl[2] = " ".length();
  }
  
  public int getRenderType()
  {
    return llllIIl[0];
  }
  
  public void dropBlockAsItemWithChance(World llIlIIlIlllIIII, BlockPos llIlIIlIllIllll, IBlockState llIlIIlIllIlllI, float llIlIIlIllIllIl, int llIlIIlIllIllII) {}
  
  public AxisAlignedBB getCollisionBoundingBox(World llIlIIlIllllIII, BlockPos llIlIIlIlllIlll, IBlockState llIlIIlIlllIllI)
  {
    return null;
  }
  
  public boolean isOpaqueCube()
  {
    return llllIIl[1];
  }
  
  public boolean isReplaceable(World llIlIIlIllIlIlI, BlockPos llIlIIlIllIlIIl)
  {
    return llllIIl[2];
  }
}

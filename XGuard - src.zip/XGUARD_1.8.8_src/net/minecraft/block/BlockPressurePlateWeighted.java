package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class BlockPressurePlateWeighted
  extends BlockBasePressurePlate
{
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIIlIIIIlllllIIlIl, new IProperty[] { POWER });
  }
  
  private static String lIIlIlIIIllIII(String lllllllllllllllIIlIIIIllllIllIIl, String lllllllllllllllIIlIIIIllllIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIIIllllIllIIl = new String(Base64.getDecoder().decode(lllllllllllllllIIlIIIIllllIllIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlIIIIllllIlIlll = new StringBuilder();
    char[] lllllllllllllllIIlIIIIllllIlIllI = lllllllllllllllIIlIIIIllllIlIIll.toCharArray();
    int lllllllllllllllIIlIIIIllllIlIlIl = llIIIIlIllll[0];
    byte lllllllllllllllIIlIIIIllllIIllll = lllllllllllllllIIlIIIIllllIllIIl.toCharArray();
    long lllllllllllllllIIlIIIIllllIIlllI = lllllllllllllllIIlIIIIllllIIllll.length;
    float lllllllllllllllIIlIIIIllllIIllIl = llIIIIlIllll[0];
    while (lIIlIlIIIlllII(lllllllllllllllIIlIIIIllllIIllIl, lllllllllllllllIIlIIIIllllIIlllI))
    {
      char lllllllllllllllIIlIIIIllllIllIlI = lllllllllllllllIIlIIIIllllIIllll[lllllllllllllllIIlIIIIllllIIllIl];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlIIIIllllIlIlll);
  }
  
  private static boolean lIIlIlIIIlllII(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIIlIIIIllllIIlIII;
    return ??? < i;
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIIlIIIIlllllIIlll)
  {
    ;
    return ((Integer)lllllllllllllllIIlIIIIlllllIIlll.getValue(POWER)).intValue();
  }
  
  protected IBlockState setRedstoneStrength(IBlockState lllllllllllllllIIlIIIIllllllIllI, int lllllllllllllllIIlIIIIllllllIIll)
  {
    ;
    ;
    return lllllllllllllllIIlIIIIllllllIllI.withProperty(POWER, Integer.valueOf(lllllllllllllllIIlIIIIllllllIIll));
  }
  
  public int tickRate(World lllllllllllllllIIlIIIIllllllIIIl)
  {
    return llIIIIlIllll[2];
  }
  
  protected int getRedstoneStrength(IBlockState lllllllllllllllIIlIIIIlllllllIll)
  {
    ;
    return ((Integer)lllllllllllllllIIlIIIIlllllllIll.getValue(POWER)).intValue();
  }
  
  private static void lIIlIlIIIllIlI()
  {
    llIIIIlIllll = new int[4];
    llIIIIlIllll[0] = ((0xCA ^ 0xB7 ^ 0x3E ^ 0x5C) & (54 + 124 - 71 + 69 ^ 42 + 6 - -35 + 92 ^ -" ".length()));
    llIIIIlIllll[1] = (0x3D ^ 0x32);
    llIIIIlIllll[2] = (0x99 ^ 0x93);
    llIIIIlIllll[3] = " ".length();
  }
  
  private static boolean lIIlIlIIIllIll(int ???)
  {
    short lllllllllllllllIIlIIIIllllIIIllI;
    return ??? > 0;
  }
  
  protected BlockPressurePlateWeighted(Material lllllllllllllllIIlIIIlIIIIIIllll, int lllllllllllllllIIlIIIlIIIIIlIIlI, MapColor lllllllllllllllIIlIIIlIIIIIlIIIl)
  {
    lllllllllllllllIIlIIIlIIIIIlIlII.<init>(lllllllllllllllIIlIIIlIIIIIIllll, lllllllllllllllIIlIIIlIIIIIlIIIl);
    lllllllllllllllIIlIIIlIIIIIlIlII.setDefaultState(blockState.getBaseState().withProperty(POWER, Integer.valueOf(llIIIIlIllll[0])));
    field_150068_a = lllllllllllllllIIlIIIlIIIIIlIIlI;
  }
  
  protected BlockPressurePlateWeighted(Material lllllllllllllllIIlIIIlIIIIIllIlI, int lllllllllllllllIIlIIIlIIIIIllIIl)
  {
    lllllllllllllllIIlIIIlIIIIIllIll.<init>(lllllllllllllllIIlIIIlIIIIIlllIl, lllllllllllllllIIlIIIlIIIIIllIIl, lllllllllllllllIIlIIIlIIIIIlllIl.getMaterialMapColor());
  }
  
  static
  {
    lIIlIlIIIllIlI();
    lIIlIlIIIllIIl();
  }
  
  private static void lIIlIlIIIllIIl()
  {
    llIIIIlIlllI = new String[llIIIIlIllll[3]];
    llIIIIlIlllI[llIIIIlIllll[0]] = lIIlIlIIIllIII("KSoaMyQ=", "YEmVV");
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIIlIIIIlllllIlIll)
  {
    ;
    ;
    return lllllllllllllllIIlIIIIlllllIlllI.getDefaultState().withProperty(POWER, Integer.valueOf(lllllllllllllllIIlIIIIlllllIlIll));
  }
  
  protected int computeRedstoneStrength(World lllllllllllllllIIlIIIlIIIIIIIllI, BlockPos lllllllllllllllIIlIIIlIIIIIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIIlIIIlIIIIIIIlII = Math.min(lllllllllllllllIIlIIIlIIIIIIIllI.getEntitiesWithinAABB(Entity.class, lllllllllllllllIIlIIIlIIIIIIIlll.getSensitiveAABB(lllllllllllllllIIlIIIlIIIIIIIIII)).size(), field_150068_a);
    if (lIIlIlIIIllIll(lllllllllllllllIIlIIIlIIIIIIIlII))
    {
      float lllllllllllllllIIlIIIlIIIIIIIIll = Math.min(field_150068_a, lllllllllllllllIIlIIIlIIIIIIIlII) / field_150068_a;
      return MathHelper.ceiling_float_int(lllllllllllllllIIlIIIlIIIIIIIIll * 15.0F);
    }
    return llIIIIlIllll[0];
  }
}

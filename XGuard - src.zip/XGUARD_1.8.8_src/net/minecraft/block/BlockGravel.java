package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;

public class BlockGravel
  extends BlockFalling
{
  public Item getItemDropped(IBlockState llllllllllllllllIIlIlllIIIIIlIll, Random llllllllllllllllIIlIlllIIIIIlIlI, int llllllllllllllllIIlIlllIIIIIIllI)
  {
    ;
    ;
    ;
    if (lIllIIlIIIllI(llllllllllllllllIIlIlllIIIIIIllI, lllIIllllll[0])) {
      llllllllllllllllIIlIlllIIIIIIllI = lllIIllllll[0];
    }
    if (lIllIIlIIIlll(llllllllllllllllIIlIlllIIIIIIlll.nextInt(lllIIllllll[1] - llllllllllllllllIIlIlllIIIIIIllI * lllIIllllll[0])))
    {
      "".length();
      if (-"   ".length() < 0) {
        break label65;
      }
      return null;
    }
    label65:
    return Item.getItemFromBlock(llllllllllllllllIIlIlllIIIIIlIII);
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllllIIlIlllIIIIIIlII)
  {
    return MapColor.stoneColor;
  }
  
  public BlockGravel() {}
  
  private static boolean lIllIIlIIIllI(int ???, int arg1)
  {
    int i;
    short llllllllllllllllIIlIlllIIIIIIIII;
    return ??? > i;
  }
  
  static {}
  
  private static boolean lIllIIlIIIlll(int ???)
  {
    short llllllllllllllllIIlIllIllllllllI;
    return ??? == 0;
  }
  
  private static void lIllIIlIIIlIl()
  {
    lllIIllllll = new int[2];
    lllIIllllll[0] = "   ".length();
    lllIIllllll[1] = (0x46 ^ 0x4C);
  }
}

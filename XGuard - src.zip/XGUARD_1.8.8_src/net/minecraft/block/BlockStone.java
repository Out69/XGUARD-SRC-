package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.StatCollector;

public class BlockStone
  extends Block
{
  public BlockStone()
  {
    lllllllllllllllIlIlIllIlIIIllIII.<init>(Material.rock);
    lllllllllllllllIlIlIllIlIIIlIllI.setDefaultState(blockState.getBaseState().withProperty(VARIANT, EnumType.STONE));
    "".length();
  }
  
  static
  {
    llllIlIIlllII();
    llllIlIIlIlII();
  }
  
  public void getSubBlocks(Item lllllllllllllllIlIlIllIIllllIllI, CreativeTabs lllllllllllllllIlIlIllIIlllllIIl, List<ItemStack> lllllllllllllllIlIlIllIIllllIlIl)
  {
    ;
    ;
    ;
    ;
    float lllllllllllllllIlIlIllIIllllIIlI = (lllllllllllllllIlIlIllIIllllIIIl = EnumType.values()).length;
    int lllllllllllllllIlIlIllIIllllIIll = lIIllllIlllI[0];
    "".length();
    if (((0xF5 ^ 0xB5) & (0x1C ^ 0x5C ^ 0xFFFFFFFF)) < ((0x8 ^ 0xC) & (0x3F ^ 0x3B ^ 0xFFFFFFFF))) {
      return;
    }
    while (!llllIlIIllllI(lllllllllllllllIlIlIllIIllllIIll, lllllllllllllllIlIlIllIIllllIIlI))
    {
      EnumType lllllllllllllllIlIlIllIIllllIlll = lllllllllllllllIlIlIllIIllllIIIl[lllllllllllllllIlIlIllIIllllIIll];
      new ItemStack(lllllllllllllllIlIlIllIIllllIllI, lIIllllIlllI[1], lllllllllllllllIlIlIllIIllllIlll.getMetadata());
      "".length();
    }
  }
  
  private static String llllIlIIlIIlI(String lllllllllllllllIlIlIllIIllIllIlI, String lllllllllllllllIlIlIllIIllIllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIllIIllIlllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIllIIllIllIll.getBytes(StandardCharsets.UTF_8)), lIIllllIlllI[4]), "DES");
      Cipher lllllllllllllllIlIlIllIIllIllllI = Cipher.getInstance("DES");
      lllllllllllllllIlIlIllIIllIllllI.init(lIIllllIlllI[2], lllllllllllllllIlIlIllIIllIlllll);
      return new String(lllllllllllllllIlIlIllIIllIllllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIllIIllIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIllIIllIlllIl)
    {
      lllllllllllllllIlIlIllIIllIlllIl.printStackTrace();
    }
    return null;
  }
  
  public int damageDropped(IBlockState lllllllllllllllIlIlIllIlIIIIIIlI)
  {
    ;
    return ((EnumType)lllllllllllllllIlIlIllIlIIIIIIlI.getValue(VARIANT)).getMetadata();
  }
  
  private static String llllIlIIlIIll(String lllllllllllllllIlIlIllIIllIIllII, String lllllllllllllllIlIlIllIIllIIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIllIIllIIllII = new String(Base64.getDecoder().decode(lllllllllllllllIlIlIllIIllIIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlIlIllIIllIIlIlI = new StringBuilder();
    char[] lllllllllllllllIlIlIllIIllIIlIIl = lllllllllllllllIlIlIllIIllIIIllI.toCharArray();
    int lllllllllllllllIlIlIllIIllIIlIII = lIIllllIlllI[0];
    boolean lllllllllllllllIlIlIllIIllIIIIlI = lllllllllllllllIlIlIllIIllIIllII.toCharArray();
    int lllllllllllllllIlIlIllIIllIIIIIl = lllllllllllllllIlIlIllIIllIIIIlI.length;
    double lllllllllllllllIlIlIllIIllIIIIII = lIIllllIlllI[0];
    while (llllIlIIlllll(lllllllllllllllIlIlIllIIllIIIIII, lllllllllllllllIlIlIllIIllIIIIIl))
    {
      char lllllllllllllllIlIlIllIIllIIllIl = lllllllllllllllIlIlIllIIllIIIIlI[lllllllllllllllIlIlIllIIllIIIIII];
      "".length();
      "".length();
      if (-"  ".length() >= 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIlIlIllIIllIIlIlI);
  }
  
  private static boolean llllIlIIlllIl(Object ???, Object arg1)
  {
    Object localObject;
    boolean lllllllllllllllIlIlIllIIlIllIIll;
    return ??? == localObject;
  }
  
  private static boolean llllIlIIllllI(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIlIlIllIIlIlllIll;
    return ??? >= i;
  }
  
  private static boolean llllIlIIlllll(int ???, int arg1)
  {
    int i;
    int lllllllllllllllIlIlIllIIlIllIlll;
    return ??? < i;
  }
  
  private static void llllIlIIlllII()
  {
    lIIllllIlllI = new int[5];
    lIIllllIlllI[0] = (" ".length() & (" ".length() ^ -" ".length()));
    lIIllllIlllI[1] = " ".length();
    lIIllllIlllI[2] = "  ".length();
    lIIllllIlllI[3] = "   ".length();
    lIIllllIlllI[4] = (0xB5 ^ 0xA2 ^ 0x29 ^ 0x36);
  }
  
  public MapColor getMapColor(IBlockState lllllllllllllllIlIlIllIlIIIIllII)
  {
    ;
    return ((EnumType)lllllllllllllllIlIlIllIlIIIIllII.getValue(VARIANT)).func_181072_c();
  }
  
  public String getLocalizedName()
  {
    ;
    return StatCollector.translateToLocal(String.valueOf(new StringBuilder(String.valueOf(lllllllllllllllIlIlIllIlIIIlIIII.getUnlocalizedName())).append(lIIllllIlIll[lIIllllIlllI[1]]).append(EnumType.STONE.getUnlocalizedName()).append(lIIllllIlIll[lIIllllIlllI[2]])));
  }
  
  private static void llllIlIIlIlII()
  {
    lIIllllIlIll = new String[lIIllllIlllI[3]];
    lIIllllIlIll[lIIllllIlllI[0]] = llllIlIIlIIlI("izi6qrCfBOU=", "lWgIX");
    lIIllllIlIll[lIIllllIlllI[1]] = llllIlIIlIIlI("oW4cc5iyeZs=", "qBoWK");
    lIIllllIlIll[lIIllllIlllI[2]] = llllIlIIlIIll("aDojIxM=", "FTBNv");
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIlIlIllIIlllIIlII, new IProperty[] { VARIANT });
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIlIlIllIIlllIlIII)
  {
    ;
    return ((EnumType)lllllllllllllllIlIlIllIIlllIlIII.getValue(VARIANT)).getMetadata();
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllIlIlIllIlIIIIlIIl, Random lllllllllllllllIlIlIllIlIIIIlIII, int lllllllllllllllIlIlIllIlIIIIIlll)
  {
    ;
    if (llllIlIIlllIl(lllllllllllllllIlIlIllIlIIIIlIIl.getValue(VARIANT), EnumType.STONE))
    {
      "".length();
      if (null == null) {
        break label42;
      }
      return null;
    }
    label42:
    return Item.getItemFromBlock(Blocks.stone);
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIlIlIllIIlllIlIll)
  {
    ;
    ;
    return lllllllllllllllIlIlIllIIlllIlllI.getDefaultState().withProperty(VARIANT, EnumType.byMetadata(lllllllllllllllIlIlIllIIlllIlIll));
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    public String getUnlocalizedName()
    {
      ;
      return unlocalizedName;
    }
    
    private static boolean lIlIlIIIlIIII(int ???)
    {
      double llllllllllllllllIlIIIIlIlIIlIllI;
      return ??? >= 0;
    }
    
    private static void lIlIlIIIIlIll()
    {
      llIllIllIlI = new String[llIllIlllII[17]];
      llIllIllIlI[llIllIlllII[0]] = lIlIlIIIIlIII("aI8/x1SEblA=", "QTHRq");
      llIllIllIlI[llIllIlllII[1]] = lIlIlIIIIlIIl("BBABLAA=", "wdnBe");
      llIllIllIlI[llIllIlllII[2]] = lIlIlIIIIlIlI("cO8L+3qa2Qk=", "cVbQQ");
      llIllIllIlI[llIllIlllII[3]] = lIlIlIIIIlIlI("C9sOqNreV9U=", "Vmbja");
      llIllIllIlI[llIllIlllII[4]] = lIlIlIIIIlIIl("DDkJDwUfLhcSAQQkHAk=", "KkHAL");
      llIllIllIlI[llIllIlllII[5]] = lIlIlIIIIlIII("s2NiOrKTQWVeNC4JT05H6g==", "ZDcYv");
      llIllIllIlI[llIllIlllII[6]] = lIlIlIIIIlIlI("k/BR7m1hnN0q10uUeWvtxA==", "Pxwbo");
      llIllIllIlI[llIllIlllII[7]] = lIlIlIIIIlIII("wrRtRg9Z4MA=", "WbXhs");
      llIllIllIlI[llIllIlllII[8]] = lIlIlIIIIlIII("M4H4XWg6GyY=", "NEaXS");
      llIllIllIlI[llIllIlllII[9]] = lIlIlIIIIlIIl("KhMhODo6HzE5PiEVOiI=", "nZnjs");
      llIllIllIlI[llIllIlllII[10]] = lIlIlIIIIlIIl("AwAbHT0YMhAbJgIEABc=", "pmtrI");
      llIllIllIlI[llIllIlllII[11]] = lIlIlIIIIlIlI("eVuCVvdEAyVm3tgyCykouw==", "CHxXg");
      llIllIllIlI[llIllIlllII[12]] = lIlIlIIIIlIIl("GQoJJxYREAg=", "XDMbE");
      llIllIllIlI[llIllIlllII[13]] = lIlIlIIIIlIII("WXchiXbPgRNYM7bW6GSwIQ==", "zAAlD");
      llIllIllIlI[llIllIlllII[14]] = lIlIlIIIIlIlI("7HP8k93A041Sx0fujycPbA==", "aukTV");
      llIllIllIlI[llIllIlllII[15]] = lIlIlIIIIlIlI("jzqOGm0u0HXqz0q55SJYKw==", "DyLWP");
      llIllIllIlI[llIllIlllII[16]] = lIlIlIIIIlIlI("vyRl96DDZ9+SW2vWF0hPBA==", "wJNyJ");
    }
    
    private static boolean lIlIlIIIIllll(int ???, int arg1)
    {
      int i;
      byte llllllllllllllllIlIIIIlIlIIlllII;
      return ??? >= i;
    }
    
    private static void lIlIlIIIIllIl()
    {
      llIllIlllII = new int[18];
      llIllIlllII[0] = ((0x3C ^ 0x3) & (0xB5 ^ 0x8A ^ 0xFFFFFFFF));
      llIllIlllII[1] = " ".length();
      llIllIlllII[2] = "  ".length();
      llIllIlllII[3] = "   ".length();
      llIllIlllII[4] = (0x7D ^ 0x79);
      llIllIlllII[5] = (0x58 ^ 0x5D);
      llIllIlllII[6] = (46 + 57 - 35 + 67 ^ 77 + 35 - -8 + 9);
      llIllIlllII[7] = (0xA ^ 0xD);
      llIllIlllII[8] = (0x63 ^ 0x6B);
      llIllIlllII[9] = (0xBA ^ 0xB3);
      llIllIlllII[10] = (0x5 ^ 0xF);
      llIllIlllII[11] = (0xA ^ 0x1);
      llIllIlllII[12] = (0x77 ^ 0x3 ^ 0x52 ^ 0x2A);
      llIllIlllII[13] = (0x49 ^ 0x44);
      llIllIlllII[14] = (0x29 ^ 0x15 ^ 0x7A ^ 0x48);
      llIllIlllII[15] = (0x63 ^ 0x53 ^ 0xA5 ^ 0x9A);
      llIllIlllII[16] = (0x6A ^ 0x54 ^ 0x97 ^ 0xB9);
      llIllIlllII[17] = (0xBA ^ 0xAB);
    }
    
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    public static EnumType byMetadata(int llllllllllllllllIlIIIIlIlllIIIII)
    {
      ;
      if ((!lIlIlIIIlIIII(llllllllllllllllIlIIIIlIlllIIIII)) || (lIlIlIIIIllll(llllllllllllllllIlIIIIlIlllIIIIl, META_LOOKUP.length))) {
        llllllllllllllllIlIIIIlIlllIIIIl = llIllIlllII[0];
      }
      return META_LOOKUP[llllllllllllllllIlIIIIlIlllIIIIl];
    }
    
    public MapColor func_181072_c()
    {
      ;
      return field_181073_l;
    }
    
    private EnumType(int llllllllllllllllIlIIIIllIIIIIIIl, MapColor llllllllllllllllIlIIIIllIIIIIllI, String llllllllllllllllIlIIIIlIllllllll)
    {
      llllllllllllllllIlIIIIllIIIIlIII.<init>(llllllllllllllllIlIIIIllIIIIIIll, llllllllllllllllIlIIIIllIIIIIIlI, llllllllllllllllIlIIIIllIIIIIIIl, llllllllllllllllIlIIIIllIIIIIllI, llllllllllllllllIlIIIIlIllllllll, llllllllllllllllIlIIIIlIllllllll);
    }
    
    private static String lIlIlIIIIlIIl(String llllllllllllllllIlIIIIlIlIlIlIII, String llllllllllllllllIlIIIIlIlIlIIlll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllllIlIIIIlIlIlIlIII = new String(Base64.getDecoder().decode(llllllllllllllllIlIIIIlIlIlIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllllIlIIIIlIlIlIlIll = new StringBuilder();
      char[] llllllllllllllllIlIIIIlIlIlIlIlI = llllllllllllllllIlIIIIlIlIlIIlll.toCharArray();
      int llllllllllllllllIlIIIIlIlIlIlIIl = llIllIlllII[0];
      long llllllllllllllllIlIIIIlIlIlIIIll = llllllllllllllllIlIIIIlIlIlIlIII.toCharArray();
      String llllllllllllllllIlIIIIlIlIlIIIlI = llllllllllllllllIlIIIIlIlIlIIIll.length;
      double llllllllllllllllIlIIIIlIlIlIIIIl = llIllIlllII[0];
      while (lIlIlIIIlIIIl(llllllllllllllllIlIIIIlIlIlIIIIl, llllllllllllllllIlIIIIlIlIlIIIlI))
      {
        char llllllllllllllllIlIIIIlIlIlIlllI = llllllllllllllllIlIIIIlIlIlIIIll[llllllllllllllllIlIIIIlIlIlIIIIl];
        "".length();
        "".length();
        if (" ".length() < ((0x25 ^ 0x38 ^ 0xD ^ 0x3D) & (63 + 71 - 64 + 167 ^ 47 + 64 - -3 + 78 ^ -" ".length()))) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllllIlIIIIlIlIlIlIll);
    }
    
    private static boolean lIlIlIIIlIIIl(int ???, int arg1)
    {
      int i;
      short llllllllllllllllIlIIIIlIlIIllIII;
      return ??? < i;
    }
    
    static
    {
      lIlIlIIIIllIl();
      lIlIlIIIIlIll();
      int llllllllllllllllIlIIIIllIIIIllll;
      boolean llllllllllllllllIlIIIIllIIIlIIlI;
      STONE = new EnumType(llIllIllIlI[llIllIlllII[0]], llIllIlllII[0], llIllIlllII[0], MapColor.stoneColor, llIllIllIlI[llIllIlllII[1]]);
      GRANITE = new EnumType(llIllIllIlI[llIllIlllII[2]], llIllIlllII[1], llIllIlllII[1], MapColor.dirtColor, llIllIllIlI[llIllIlllII[3]]);
      GRANITE_SMOOTH = new EnumType(llIllIllIlI[llIllIlllII[4]], llIllIlllII[2], llIllIlllII[2], MapColor.dirtColor, llIllIllIlI[llIllIlllII[5]], llIllIllIlI[llIllIlllII[6]]);
      DIORITE = new EnumType(llIllIllIlI[llIllIlllII[7]], llIllIlllII[3], llIllIlllII[3], MapColor.quartzColor, llIllIllIlI[llIllIlllII[8]]);
      DIORITE_SMOOTH = new EnumType(llIllIllIlI[llIllIlllII[9]], llIllIlllII[4], llIllIlllII[4], MapColor.quartzColor, llIllIllIlI[llIllIlllII[10]], llIllIllIlI[llIllIlllII[11]]);
      ANDESITE = new EnumType(llIllIllIlI[llIllIlllII[12]], llIllIlllII[5], llIllIlllII[5], MapColor.stoneColor, llIllIllIlI[llIllIlllII[13]]);
      ANDESITE_SMOOTH = new EnumType(llIllIllIlI[llIllIlllII[14]], llIllIlllII[6], llIllIlllII[6], MapColor.stoneColor, llIllIllIlI[llIllIlllII[15]], llIllIllIlI[llIllIlllII[16]]);
      ENUM$VALUES = new EnumType[] { STONE, GRANITE, GRANITE_SMOOTH, DIORITE, DIORITE_SMOOTH, ANDESITE, ANDESITE_SMOOTH };
      META_LOOKUP = new EnumType[values().length];
      boolean llllllllllllllllIlIIIIllIIIlIIII = (llllllllllllllllIlIIIIllIIIIllll = values()).length;
      float llllllllllllllllIlIIIIllIIIlIIIl = llIllIlllII[0];
      "".length();
      if (" ".length() <= 0) {
        return;
      }
      while (!lIlIlIIIIllll(llllllllllllllllIlIIIIllIIIlIIIl, llllllllllllllllIlIIIIllIIIlIIII))
      {
        EnumType llllllllllllllllIlIIIIllIIIlIIll = llllllllllllllllIlIIIIllIIIIllll[llllllllllllllllIlIIIIllIIIlIIIl];
        META_LOOKUP[llllllllllllllllIlIIIIllIIIlIIll.getMetadata()] = llllllllllllllllIlIIIIllIIIlIIll;
        llllllllllllllllIlIIIIllIIIlIIIl++;
      }
    }
    
    private static String lIlIlIIIIlIII(String llllllllllllllllIlIIIIlIllIIlIlI, String llllllllllllllllIlIIIIlIllIIlIIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllllIlIIIIlIllIIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlIIIIlIllIIlIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllllIlIIIIlIllIIllII = Cipher.getInstance("Blowfish");
        llllllllllllllllIlIIIIlIllIIllII.init(llIllIlllII[2], llllllllllllllllIlIIIIlIllIIllIl);
        return new String(llllllllllllllllIlIIIIlIllIIllII.doFinal(Base64.getDecoder().decode(llllllllllllllllIlIIIIlIllIIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllllIlIIIIlIllIIlIll)
      {
        llllllllllllllllIlIIIIlIllIIlIll.printStackTrace();
      }
      return null;
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private EnumType(int llllllllllllllllIlIIIIlIllllIllI, MapColor llllllllllllllllIlIIIIlIllllIlIl, String llllllllllllllllIlIIIIlIlllIllIl, String llllllllllllllllIlIIIIlIllllIIll)
    {
      meta = llllllllllllllllIlIIIIlIllllIllI;
      name = llllllllllllllllIlIIIIlIlllIllIl;
      unlocalizedName = llllllllllllllllIlIIIIlIllllIIll;
      field_181073_l = llllllllllllllllIlIIIIlIlllIlllI;
    }
    
    private static String lIlIlIIIIlIlI(String llllllllllllllllIlIIIIlIlIlllIll, String llllllllllllllllIlIIIIlIlIllllII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllllIlIIIIlIllIIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlIIIIlIlIllllII.getBytes(StandardCharsets.UTF_8)), llIllIlllII[8]), "DES");
        Cipher llllllllllllllllIlIIIIlIlIllllll = Cipher.getInstance("DES");
        llllllllllllllllIlIIIIlIlIllllll.init(llIllIlllII[2], llllllllllllllllIlIIIIlIllIIIIII);
        return new String(llllllllllllllllIlIIIIlIlIllllll.doFinal(Base64.getDecoder().decode(llllllllllllllllIlIIIIlIlIlllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllllIlIIIIlIlIlllllI)
      {
        llllllllllllllllIlIIIIlIlIlllllI.printStackTrace();
      }
      return null;
    }
    
    public String getName()
    {
      ;
      return name;
    }
  }
}

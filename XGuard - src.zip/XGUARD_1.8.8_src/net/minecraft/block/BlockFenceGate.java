package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockFenceGate
  extends BlockDirectional
{
  private static void lIllIlIIlIlIlI()
  {
    lllIllIIIlII = new String[lllIllIIIlIl[7]];
    lllIllIIIlII[lllIllIIIlIl[0]] = lIllIlIIlIlIIl("DQYKLw==", "bvoAw");
    lllIllIIIlII[lllIllIIIlIl[1]] = lIllIlIIlIlIIl("PT4gKhQoNQ==", "MQWOf");
    lllIllIIIlII[lllIllIIIlIl[2]] = lIllIlIIlIlIIl("Jh4nERQjHA==", "Opxfu");
  }
  
  private static void lIllIlIIlIlIll()
  {
    lllIllIIIlIl = new int[8];
    lllIllIIIlIl[0] = ((3 + 40 - -14 + 124 ^ 113 + 75 - 97 + 44) & (0xDA ^ 0x94 ^ 0x5C ^ 0x20 ^ -" ".length()));
    lllIllIIIlIl[1] = " ".length();
    lllIllIIIlIl[2] = "  ".length();
    lllIllIIIlIl[3] = (0x8BEB & 0x77FF);
    lllIllIIIlIl[4] = (-(0xF97B & 0x4695) & 0xDFFE & 0x63FF);
    lllIllIIIlIl[5] = (0x9B ^ 0xC2 ^ 0x6E ^ 0x33);
    lllIllIIIlIl[6] = (0xAA ^ 0x8D ^ 0x43 ^ 0x6C);
    lllIllIIIlIl[7] = "   ".length();
  }
  
  private static boolean lIllIlIIlIllII(Object ???, Object arg1)
  {
    Object localObject;
    char llllllllllllllIllIllllIIllllIIII;
    return ??? == localObject;
  }
  
  public boolean canPlaceBlockAt(World llllllllllllllIllIllllIlIllllIlI, BlockPos llllllllllllllIllIllllIlIlllllII)
  {
    ;
    ;
    ;
    if (lIllIlIIlIlllI(llllllllllllllIllIllllIlIllllIlI.getBlockState(llllllllllllllIllIllllIlIlllllII.down()).getBlock().getMaterial().isSolid()))
    {
      "".length();
      if (-" ".length() != "  ".length()) {
        break label114;
      }
      return (38 + 123 - 40 + 30 ^ 119 + 21 - 17 + 45) & ('' + 29 - 74 + 157 ^ 66 + '' - 94 + 83 ^ -" ".length());
    }
    label114:
    return lllIllIIIlIl[0];
  }
  
  public BlockFenceGate(BlockPlanks.EnumType llllllllllllllIllIllllIllIIlIIIl)
  {
    llllllllllllllIllIllllIllIIlIIII.<init>(Material.wood, llllllllllllllIllIllllIllIIlIIIl.func_181070_c());
    llllllllllllllIllIllllIllIIlIIII.setDefaultState(blockState.getBaseState().withProperty(OPEN, Boolean.valueOf(lllIllIIIlIl[0])).withProperty(POWERED, Boolean.valueOf(lllIllIIIlIl[0])).withProperty(IN_WALL, Boolean.valueOf(lllIllIIIlIl[0])));
    "".length();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIllIllllIlIIIlIlII, new IProperty[] { FACING, OPEN, POWERED, IN_WALL });
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIllIllllIlIIIllIlI)
  {
    ;
    ;
    int llllllllllllllIllIllllIlIIIllIIl = lllIllIIIlIl[0];
    llllllllllllllIllIllllIlIIIllIIl |= ((EnumFacing)llllllllllllllIllIllllIlIIIllIII.getValue(FACING)).getHorizontalIndex();
    if (lIllIlIIlIlllI(((Boolean)llllllllllllllIllIllllIlIIIllIII.getValue(POWERED)).booleanValue())) {
      llllllllllllllIllIllllIlIIIllIIl |= lllIllIIIlIl[6];
    }
    if (lIllIlIIlIlllI(((Boolean)llllllllllllllIllIllllIlIIIllIII.getValue(OPEN)).booleanValue())) {
      llllllllllllllIllIllllIlIIIllIIl |= lllIllIIIlIl[5];
    }
    return llllllllllllllIllIllllIlIIIllIIl;
  }
  
  public boolean onBlockActivated(World llllllllllllllIllIllllIlIIllllII, BlockPos llllllllllllllIllIllllIlIlIIIlII, IBlockState llllllllllllllIllIllllIlIlIIIIll, EntityPlayer llllllllllllllIllIllllIlIIlllIIl, EnumFacing llllllllllllllIllIllllIlIlIIIIIl, float llllllllllllllIllIllllIlIlIIIIII, float llllllllllllllIllIllllIlIIllllll, float llllllllllllllIllIllllIlIIlllllI)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIllIlIIlIlllI(((Boolean)llllllllllllllIllIllllIlIlIIIIll.getValue(OPEN)).booleanValue()))
    {
      llllllllllllllIllIllllIlIlIIIIll = llllllllllllllIllIllllIlIlIIIIll.withProperty(OPEN, Boolean.valueOf(lllIllIIIlIl[0]));
      "".length();
      "".length();
      if (" ".length() == ((0x1B ^ 0x10) & (0xA3 ^ 0xA8 ^ 0xFFFFFFFF))) {
        return (0x8C ^ 0x92) & (0x7A ^ 0x64 ^ 0xFFFFFFFF);
      }
    }
    else
    {
      EnumFacing llllllllllllllIllIllllIlIIllllIl = EnumFacing.fromAngle(rotationYaw);
      if (lIllIlIIlIllII(llllllllllllllIllIllllIlIlIIIIll.getValue(FACING), llllllllllllllIllIllllIlIIllllIl.getOpposite())) {
        llllllllllllllIllIllllIlIlIIIIll = llllllllllllllIllIllllIlIlIIIIll.withProperty(FACING, llllllllllllllIllIllllIlIIllllIl);
      }
      llllllllllllllIllIllllIlIlIIIIll = llllllllllllllIllIllllIlIlIIIIll.withProperty(OPEN, Boolean.valueOf(lllIllIIIlIl[1]));
      "".length();
    }
    if (lIllIlIIlIlllI(((Boolean)llllllllllllllIllIllllIlIlIIIIll.getValue(OPEN)).booleanValue()))
    {
      "".length();
      if (null == null) {
        break label284;
      }
      return (102 + 26 - 46 + 92 ^ '' + 80 - 197 + 138) & ('' + '' - 148 + 40 ^ 'µ' + 31 - 26 + 2 ^ -" ".length());
    }
    label284:
    llllllllllllllIllIllllIlIIlllIIl.playAuxSFXAtEntity(lllIllIIIlIl[3], lllIllIIIlIl[4], llllllllllllllIllIllllIlIlIIIlII, lllIllIIIlIl[0]);
    return lllIllIIIlIl[1];
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIllIllllIlIIIllllI)
  {
    ;
    ;
    if (lIllIlIIlIlllI(llllllllllllllIllIllllIlIIIllllI & lllIllIIIlIl[5]))
    {
      "".length();
      if (-"  ".length() <= 0) {
        break label59;
      }
      return null;
    }
    label59:
    if (lIllIlIIlIlllI(llllllllllllllIllIllllIlIIIllllI & lllIllIIIlIl[6]))
    {
      "".length();
      if (-(0xE ^ 0xA) <= 0) {
        break label111;
      }
      return null;
    }
    label111:
    return POWERED.withProperty(lllIllIIIlIl[1], Boolean.valueOf(lllIllIIIlIl[0]));
  }
  
  public boolean isOpaqueCube()
  {
    return lllIllIIIlIl[0];
  }
  
  public IBlockState onBlockPlaced(World llllllllllllllIllIllllIlIlIlIlIl, BlockPos llllllllllllllIllIllllIlIlIlIlII, EnumFacing llllllllllllllIllIllllIlIlIlIIll, float llllllllllllllIllIllllIlIlIlIIlI, float llllllllllllllIllIllllIlIlIlIIIl, float llllllllllllllIllIllllIlIlIlIIII, int llllllllllllllIllIllllIlIlIIllll, EntityLivingBase llllllllllllllIllIllllIlIlIIlllI)
  {
    ;
    ;
    return llllllllllllllIllIllllIlIlIlIllI.getDefaultState().withProperty(FACING, llllllllllllllIllIllllIlIlIIlllI.getHorizontalFacing()).withProperty(OPEN, Boolean.valueOf(lllIllIIIlIl[0])).withProperty(POWERED, Boolean.valueOf(lllIllIIIlIl[0])).withProperty(IN_WALL, Boolean.valueOf(lllIllIIIlIl[0]));
  }
  
  private static boolean lIllIlIIllIIII(int ???, int arg1)
  {
    int i;
    char llllllllllllllIllIllllIIlllIlIII;
    return ??? != i;
  }
  
  public void onNeighborBlockChange(World llllllllllllllIllIllllIlIIlIllII, BlockPos llllllllllllllIllIllllIlIIllIIII, IBlockState llllllllllllllIllIllllIlIIlIllll, Block llllllllllllllIllIllllIlIIlIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIllIlIIlIllll(isRemote))
    {
      boolean llllllllllllllIllIllllIlIIlIllIl = llllllllllllllIllIllllIlIIlIllII.isBlockPowered(llllllllllllllIllIllllIlIIllIIII);
      if ((!lIllIlIIlIllll(llllllllllllllIllIllllIlIIlIllIl)) || (lIllIlIIlIlllI(llllllllllllllIllIllllIlIIlIlllI.canProvidePower()))) {
        if ((lIllIlIIlIlllI(llllllllllllllIllIllllIlIIlIllIl)) && (lIllIlIIlIllll(((Boolean)llllllllllllllIllIllllIlIIlIllll.getValue(OPEN)).booleanValue())) && (lIllIlIIlIllll(((Boolean)llllllllllllllIllIllllIlIIlIllll.getValue(POWERED)).booleanValue())))
        {
          "".length();
          llllllllllllllIllIllllIlIIlIllII.playAuxSFXAtEntity(null, lllIllIIIlIl[3], llllllllllllllIllIllllIlIIllIIII, lllIllIIIlIl[0]);
          "".length();
          if (((0x6C ^ 0x52 ^ 0x93 ^ 0xAA) & (122 + 67 - 118 + 107 ^ '­' + 69 - 211 + 150 ^ -" ".length())) <= "   ".length()) {}
        }
        else if ((lIllIlIIlIllll(llllllllllllllIllIllllIlIIlIllIl)) && (lIllIlIIlIlllI(((Boolean)llllllllllllllIllIllllIlIIlIllll.getValue(OPEN)).booleanValue())) && (lIllIlIIlIlllI(((Boolean)llllllllllllllIllIllllIlIIlIllll.getValue(POWERED)).booleanValue())))
        {
          "".length();
          llllllllllllllIllIllllIlIIlIllII.playAuxSFXAtEntity(null, lllIllIIIlIl[4], llllllllllllllIllIllllIlIIllIIII, lllIllIIIlIl[0]);
          "".length();
          if (-"  ".length() < 0) {}
        }
        else if (lIllIlIIllIIII(llllllllllllllIllIllllIlIIlIllIl, ((Boolean)llllllllllllllIllIllllIlIIlIllll.getValue(POWERED)).booleanValue()))
        {
          "".length();
        }
      }
    }
  }
  
  private static boolean lIllIlIIlIllIl(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllIllIllllIIllllIlII;
    return ??? != localObject;
  }
  
  private static boolean lIllIlIIllIIIl(int ???, int arg1)
  {
    int i;
    int llllllllllllllIllIllllIIlllllIII;
    return ??? < i;
  }
  
  private static boolean lIllIlIIlIlllI(int ???)
  {
    double llllllllllllllIllIllllIIlllIlllI;
    return ??? != 0;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIllIllllIlIllIIlII, BlockPos llllllllllllllIllIllllIlIllIIIll)
  {
    ;
    ;
    ;
    ;
    EnumFacing.Axis llllllllllllllIllIllllIlIllIIllI = ((EnumFacing)llllllllllllllIllIllllIlIllIIlII.getBlockState(llllllllllllllIllIllllIlIllIIIll).getValue(FACING)).getAxis();
    if (lIllIlIIlIllII(llllllllllllllIllIllllIlIllIIllI, EnumFacing.Axis.Z))
    {
      llllllllllllllIllIllllIlIllIlIIl.setBlockBounds(0.0F, 0.0F, 0.375F, 1.0F, 1.0F, 0.625F);
      "".length();
      if ("   ".length() != 0) {}
    }
    else
    {
      llllllllllllllIllIllllIlIllIlIIl.setBlockBounds(0.375F, 0.0F, 0.0F, 0.625F, 1.0F, 1.0F);
    }
  }
  
  public boolean shouldSideBeRendered(IBlockAccess llllllllllllllIllIllllIlIIlIIllI, BlockPos llllllllllllllIllIllllIlIIlIIlIl, EnumFacing llllllllllllllIllIllllIlIIlIIlII)
  {
    return lllIllIIIlIl[1];
  }
  
  private static String lIllIlIIlIlIIl(String llllllllllllllIllIllllIlIIIIlIIl, String llllllllllllllIllIllllIlIIIIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIllllIlIIIIlIIl = new String(Base64.getDecoder().decode(llllllllllllllIllIllllIlIIIIlIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIllllIlIIIIIlll = new StringBuilder();
    char[] llllllllllllllIllIllllIlIIIIIllI = llllllllllllllIllIllllIlIIIIlIII.toCharArray();
    int llllllllllllllIllIllllIlIIIIIlIl = lllIllIIIlIl[0];
    boolean llllllllllllllIllIllllIIllllllll = llllllllllllllIllIllllIlIIIIlIIl.toCharArray();
    short llllllllllllllIllIllllIIlllllllI = llllllllllllllIllIllllIIllllllll.length;
    Exception llllllllllllllIllIllllIIllllllIl = lllIllIIIlIl[0];
    while (lIllIlIIllIIIl(llllllllllllllIllIllllIIllllllIl, llllllllllllllIllIllllIIlllllllI))
    {
      char llllllllllllllIllIllllIlIIIIlIlI = llllllllllllllIllIllllIIllllllll[llllllllllllllIllIllllIIllllllIl];
      "".length();
      "".length();
      if ("  ".length() <= -" ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIllllIlIIIIIlll);
  }
  
  public IBlockState getActualState(IBlockState llllllllllllllIllIllllIllIIIlIIl, IBlockAccess llllllllllllllIllIllllIllIIIIlII, BlockPos llllllllllllllIllIllllIllIIIIlll)
  {
    ;
    ;
    ;
    ;
    EnumFacing.Axis llllllllllllllIllIllllIllIIIIllI = ((EnumFacing)llllllllllllllIllIllllIllIIIlIIl.getValue(FACING)).getAxis();
    if (((lIllIlIIlIllII(llllllllllllllIllIllllIllIIIIllI, EnumFacing.Axis.Z)) && ((!lIllIlIIlIllIl(llllllllllllllIllIllllIllIIIlIII.getBlockState(llllllllllllllIllIllllIllIIIIlll.west()).getBlock(), Blocks.cobblestone_wall)) || (!lIllIlIIlIllIl(llllllllllllllIllIllllIllIIIlIII.getBlockState(llllllllllllllIllIllllIllIIIIlll.east()).getBlock(), Blocks.cobblestone_wall)))) || ((lIllIlIIlIllII(llllllllllllllIllIllllIllIIIIllI, EnumFacing.Axis.X)) && ((!lIllIlIIlIllIl(llllllllllllllIllIllllIllIIIlIII.getBlockState(llllllllllllllIllIllllIllIIIIlll.north()).getBlock(), Blocks.cobblestone_wall)) || (lIllIlIIlIllII(llllllllllllllIllIllllIllIIIlIII.getBlockState(llllllllllllllIllIllllIllIIIIlll.south()).getBlock(), Blocks.cobblestone_wall))))) {
      llllllllllllllIllIllllIllIIIlIIl = llllllllllllllIllIllllIllIIIlIIl.withProperty(IN_WALL, Boolean.valueOf(lllIllIIIlIl[1]));
    }
    return llllllllllllllIllIllllIllIIIlIIl;
  }
  
  static
  {
    lIllIlIIlIlIll();
    lIllIlIIlIlIlI();
    OPEN = PropertyBool.create(lllIllIIIlII[lllIllIIIlIl[0]]);
    POWERED = PropertyBool.create(lllIllIIIlII[lllIllIIIlIl[1]]);
  }
  
  private static boolean lIllIlIIlIllll(int ???)
  {
    String llllllllllllllIllIllllIIlllIllII;
    return ??? == 0;
  }
  
  public boolean isPassable(IBlockAccess llllllllllllllIllIllllIlIlIllIlI, BlockPos llllllllllllllIllIllllIlIlIllIIl)
  {
    ;
    ;
    return ((Boolean)llllllllllllllIllIllllIlIlIllIlI.getBlockState(llllllllllllllIllIllllIlIlIllIIl).getValue(OPEN)).booleanValue();
  }
  
  public boolean isFullCube()
  {
    return lllIllIIIlIl[0];
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIllIllllIlIlllIlII, BlockPos llllllllllllllIllIllllIlIlllIIll, IBlockState llllllllllllllIllIllllIlIllIllll)
  {
    ;
    ;
    ;
    if (lIllIlIIlIlllI(((Boolean)llllllllllllllIllIllllIlIllIllll.getValue(OPEN)).booleanValue())) {
      return null;
    }
    EnumFacing.Axis llllllllllllllIllIllllIlIlllIIIl = ((EnumFacing)llllllllllllllIllIllllIlIllIllll.getValue(FACING)).getAxis();
    if (lIllIlIIlIllII(llllllllllllllIllIllllIlIlllIIIl, EnumFacing.Axis.Z))
    {
      new AxisAlignedBB(llllllllllllllIllIllllIlIlllIIll.getX(), llllllllllllllIllIllllIlIlllIIll.getY(), llllllllllllllIllIllllIlIlllIIll.getZ() + 0.375F, llllllllllllllIllIllllIlIlllIIll.getX() + lllIllIIIlIl[1], llllllllllllllIllIllllIlIlllIIll.getY() + 1.5F, llllllllllllllIllIllllIlIlllIIll.getZ() + 0.625F);
      "".length();
      if (((71 + 82 - 71 + 48 ^ 91 + 69 - 72 + 45) & (0x42 ^ 0x57 ^ 0x68 ^ 0x7A ^ -" ".length())) <= "   ".length()) {
        break label225;
      }
      return null;
    }
    label225:
    return new AxisAlignedBB(llllllllllllllIllIllllIlIlllIIll.getX() + 0.375F, llllllllllllllIllIllllIlIlllIIll.getY(), llllllllllllllIllIllllIlIlllIIll.getZ(), llllllllllllllIllIllllIlIlllIIll.getX() + 0.625F, llllllllllllllIllIllllIlIlllIIll.getY() + 1.5F, llllllllllllllIllIllllIlIlllIIll.getZ() + lllIllIIIlIl[1]);
  }
}

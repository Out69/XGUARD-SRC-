package net.minecraft.block;

import com.google.common.cache.LoadingCache;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.block.state.pattern.BlockPattern;
import net.minecraft.block.state.pattern.BlockPattern.PatternHelper;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemMonsterPlacer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumFacing.AxisDirection;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;

public class BlockPortal
  extends BlockBreakable
{
  private static boolean lIIIIIIIIl(int ???)
  {
    int llIIIIlIllIIlII;
    return ??? <= 0;
  }
  
  public BlockPattern.PatternHelper func_181089_f(World llIIIIllIlllIlI, BlockPos llIIIIllIlIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing.Axis llIIIIllIlllIII = EnumFacing.Axis.Z;
    Size llIIIIllIllIlll = new Size(llIIIIllIlllIlI, llIIIIllIlIlIlI, EnumFacing.Axis.X);
    LoadingCache<BlockPos, BlockWorldState> llIIIIllIllIllI = BlockPattern.func_181627_a(llIIIIllIlllIlI, lIlIIIlI[2]);
    if (lIIIIIIIII(llIIIIllIllIlll.func_150860_b()))
    {
      llIIIIllIlllIII = EnumFacing.Axis.X;
      llIIIIllIllIlll = new Size(llIIIIllIlllIlI, llIIIIllIlIlIlI, EnumFacing.Axis.Z);
    }
    if (lIIIIIIIII(llIIIIllIllIlll.func_150860_b())) {
      return new BlockPattern.PatternHelper(llIIIIllIlIlIlI, EnumFacing.NORTH, EnumFacing.UP, llIIIIllIllIllI, lIlIIIlI[2], lIlIIIlI[2], lIlIIIlI[2]);
    }
    int[] llIIIIllIllIlIl = new int[EnumFacing.AxisDirection.values().length];
    EnumFacing llIIIIllIllIlII = field_150866_c.rotateYCCW();
    BlockPos llIIIIllIllIIll = field_150861_f.up(llIIIIllIllIlll.func_181100_a() - lIlIIIlI[2]);
    long llIIIIllIlIIIIl = (llIIIIllIlIIIII = EnumFacing.AxisDirection.values()).length;
    float llIIIIllIlIIIlI = lIlIIIlI[0];
    "".length();
    if (((0x54 ^ 0x76 ^ 0xB7 ^ 0x93) & ('' + 42 - 171 + 170 ^ '¨' + 61 - 103 + 70 ^ -" ".length())) == (0x45 ^ 0x1 ^ 0x81 ^ 0xC1)) {
      return null;
    }
    label301:
    BlockPattern.PatternHelper llIIIIllIllIIIl;
    while (!lIIIIIlIll(llIIIIllIlIIIlI, llIIIIllIlIIIIl))
    {
      EnumFacing.AxisDirection llIIIIllIllIIlI = llIIIIllIlIIIII[llIIIIllIlIIIlI];
      if (lIIIIIIlII(llIIIIllIllIlII.getAxisDirection(), llIIIIllIllIIlI))
      {
        "".length();
        if (-(0xFD ^ 0xA8 ^ 0x97 ^ 0xC6) < 0) {
          break label301;
        }
        return null;
      }
      llIIIIllIllIIll.<init>(llIIIIllIllIIll.offset(field_150866_c, llIIIIllIllIlll.func_181101_b() - lIlIIIlI[2]), EnumFacing.func_181076_a(llIIIIllIllIIlI, llIIIIllIlllIII), EnumFacing.UP, llIIIIllIllIllI, llIIIIllIllIlll.func_181101_b(), llIIIIllIllIlll.func_181100_a(), lIlIIIlI[2]);
      llIIIIllIllIIIl = new net/minecraft/block/state/pattern/BlockPattern$PatternHelper;
      int llIIIIllIllIIII = lIlIIIlI[0];
      "".length();
      if ("   ".length() >= (0x11 ^ 0x6C ^ 0x77 ^ 0xE)) {
        return null;
      }
      while (!lIIIIIlIll(llIIIIllIllIIII, llIIIIllIllIlll.func_181101_b()))
      {
        int llIIIIllIlIllll = lIlIIIlI[0];
        "".length();
        if (null != null) {
          return null;
        }
        while (!lIIIIIlIll(llIIIIllIlIllll, llIIIIllIllIlll.func_181100_a()))
        {
          BlockWorldState llIIIIllIlIlllI = llIIIIllIllIIIl.translateOffset(llIIIIllIllIIII, llIIIIllIlIllll, lIlIIIlI[2]);
          if ((lIIIIIIIll(llIIIIllIlIlllI.getBlockState())) && (lIIIIIlIII(llIIIIllIlIlllI.getBlockState().getBlock().getMaterial(), Material.air))) {
            llIIIIllIllIlIl[llIIIIllIllIIlI.ordinal()] += lIlIIIlI[2];
          }
          llIIIIllIlIllll++;
        }
      }
    }
    EnumFacing.AxisDirection llIIIIllIlIllIl = EnumFacing.AxisDirection.POSITIVE;
    boolean llIIIIllIlIIIII = (llIIIIllIllIIIl = EnumFacing.AxisDirection.values()).length;
    llIIIIllIlIIIIl = lIlIIIlI[0];
    "".length();
    if (-" ".length() > " ".length()) {
      return null;
    }
    while (!lIIIIIlIll(llIIIIllIlIIIIl, llIIIIllIlIIIII))
    {
      EnumFacing.AxisDirection llIIIIllIlIllII = llIIIIllIllIIIl[llIIIIllIlIIIIl];
      if (lllllllll(llIIIIllIllIlIl[llIIIIllIlIllII.ordinal()], llIIIIllIllIlIl[llIIIIllIlIllIl.ordinal()])) {
        llIIIIllIlIllIl = llIIIIllIlIllII;
      }
      llIIIIllIlIIIIl++;
    }
    if (lIIIIIIlII(llIIIIllIllIlII.getAxisDirection(), llIIIIllIlIllIl))
    {
      "".length();
      if (null == null) {
        break label636;
      }
      return null;
    }
    label636:
    llIIIIllIllIIll.<init>(llIIIIllIllIIll.offset(field_150866_c, llIIIIllIllIlll.func_181101_b() - lIlIIIlI[2]), EnumFacing.func_181076_a(llIIIIllIlIllIl, llIIIIllIlllIII), EnumFacing.UP, llIIIIllIllIllI, llIIIIllIllIlll.func_181101_b(), llIIIIllIllIlll.func_181100_a(), lIlIIIlI[2]);
    return new net/minecraft/block/state/pattern/BlockPattern$PatternHelper;
  }
  
  public void onNeighborBlockChange(World llIIIlIIIllllII, BlockPos llIIIlIIIllIlII, IBlockState llIIIlIIIlllIlI, Block llIIIlIIIlllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    EnumFacing.Axis llIIIlIIIlllIII = (EnumFacing.Axis)llIIIlIIIlllIlI.getValue(AXIS);
    if (lIIIIIIlII(llIIIlIIIlllIII, EnumFacing.Axis.X))
    {
      Size llIIIlIIIllIlll = new Size(llIIIlIIIllllII, llIIIlIIIllIlII, EnumFacing.Axis.X);
      if ((!llllllllI(llIIIlIIIllIlll.func_150860_b())) || (lllllllll(field_150864_e, field_150868_h * field_150862_g)))
      {
        "".length();
        "".length();
        if (-" ".length() < "   ".length()) {}
      }
    }
    else if (lIIIIIIlII(llIIIlIIIlllIII, EnumFacing.Axis.Z))
    {
      Size llIIIlIIIllIllI = new Size(llIIIlIIIllllII, llIIIlIIIllIlII, EnumFacing.Axis.Z);
      if ((!llllllllI(llIIIlIIIllIllI.func_150860_b())) || (lllllllll(field_150864_e, field_150868_h * field_150862_g))) {
        "".length();
      }
    }
  }
  
  private static boolean lIIIIIIIlI(int ???)
  {
    long llIIIIlIllIIIlI;
    return ??? > 0;
  }
  
  public static int getMetaForAxis(EnumFacing.Axis llIIIlIIlIlIIIl)
  {
    ;
    if (lIIIIIIlII(llIIIlIIlIlIIIl, EnumFacing.Axis.X))
    {
      "".length();
      if (-"   ".length() > 0) {
        return (0xDD ^ 0x90) & (0x3F ^ 0x72 ^ 0xFFFFFFFF);
      }
    }
    else if (lIIIIIIlII(llIIIlIIlIlIIlI, EnumFacing.Axis.Z))
    {
      "".length();
      if ((0xC0 ^ 0xC5) > 0) {
        break label100;
      }
      return (0xB8 ^ 0xBC) & (0x81 ^ 0x85 ^ 0xFFFFFFFF);
    }
    label100:
    return lIlIIIlI[0];
  }
  
  public Item getItem(World llIIIIlllIllIlI, BlockPos llIIIIlllIllIIl)
  {
    return null;
  }
  
  public boolean func_176548_d(World llIIIlIIlIIlIlI, BlockPos llIIIlIIlIIIlIl)
  {
    ;
    ;
    ;
    ;
    Size llIIIlIIlIIlIII = new Size(llIIIlIIlIIlIlI, llIIIlIIlIIIlIl, EnumFacing.Axis.X);
    if ((llllllllI(llIIIlIIlIIlIII.func_150860_b())) && (lIIIIIIIII(field_150864_e)))
    {
      llIIIlIIlIIlIII.func_150859_c();
      return lIlIIIlI[2];
    }
    Size llIIIlIIlIIIlll = new Size(llIIIlIIlIIlIlI, llIIIlIIlIIIlIl, EnumFacing.Axis.Z);
    if ((llllllllI(llIIIlIIlIIIlll.func_150860_b())) && (lIIIIIIIII(field_150864_e)))
    {
      llIIIlIIlIIIlll.func_150859_c();
      return lIlIIIlI[2];
    }
    return lIlIIIlI[0];
  }
  
  public int quantityDropped(Random llIIIlIIIIIlIll)
  {
    return lIlIIIlI[0];
  }
  
  private static boolean lIIIIIIlII(Object ???, Object arg1)
  {
    Object localObject;
    String llIIIIlIllIllII;
    return ??? == localObject;
  }
  
  public boolean isFullCube()
  {
    return lIlIIIlI[0];
  }
  
  private static String lllllIlIl(String llIIIIllIIlIlII, String llIIIIllIIlIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIIIIllIIlIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llIIIIllIIlIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llIIIIllIIlIllI = Cipher.getInstance("Blowfish");
      llIIIIllIIlIllI.init(lIlIIIlI[1], llIIIIllIIlIlll);
      return new String(llIIIIllIIlIllI.doFinal(Base64.getDecoder().decode(llIIIIllIIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIIIIllIIlIlIl)
    {
      llIIIIllIIlIlIl.printStackTrace();
    }
    return null;
  }
  
  private static void llllllIlI()
  {
    lIIlllll = new String[lIlIIIlI[7]];
    lIIlllll[lIlIIIlI[0]] = lllllIlIl("Z8GwcF0X3pA=", "oqBhh");
    lIIlllll[lIlIIIlI[2]] = lllllIllI("OGBg/t9d/n63C0RD8roH6g==", "UprkG");
    lIIlllll[lIlIIIlI[1]] = lllllIllI("oukhKD0A65cA8kM6XHaJFA==", "hNzPb");
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llIIIlIIllIlIII, BlockPos llIIIlIIllIIlll, IBlockState llIIIlIIllIIllI)
  {
    return null;
  }
  
  public void randomDisplayTick(World llIIIIlllllIIll, BlockPos llIIIIllllIIlII, IBlockState llIIIIlllllIIIl, Random llIIIIllllIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIIIIIII(llIIIIllllIIIlI.nextInt(lIlIIIlI[5]))) {
      llIIIIlllllIIll.playSound(llIIIIlllllIIlI.getX() + 0.5D, llIIIIlllllIIlI.getY() + 0.5D, llIIIIlllllIIlI.getZ() + 0.5D, lIIlllll[lIlIIIlI[1]], 0.5F, llIIIIllllIIIlI.nextFloat() * 0.4F + 0.8F, lIlIIIlI[0]);
    }
    int llIIIIllllIllll = lIlIIIlI[0];
    "".length();
    if ("  ".length() != "  ".length()) {
      return;
    }
    while (!lIIIIIlIll(llIIIIllllIllll, lIlIIIlI[6]))
    {
      double llIIIIllllIlllI = llIIIIlllllIIlI.getX() + llIIIIllllIIIlI.nextFloat();
      double llIIIIllllIllIl = llIIIIlllllIIlI.getY() + llIIIIllllIIIlI.nextFloat();
      double llIIIIllllIllII = llIIIIlllllIIlI.getZ() + llIIIIllllIIIlI.nextFloat();
      double llIIIIllllIlIll = (llIIIIllllIIIlI.nextFloat() - 0.5D) * 0.5D;
      double llIIIIllllIlIlI = (llIIIIllllIIIlI.nextFloat() - 0.5D) * 0.5D;
      double llIIIIllllIlIIl = (llIIIIllllIIIlI.nextFloat() - 0.5D) * 0.5D;
      int llIIIIllllIlIII = llIIIIllllIIIlI.nextInt(lIlIIIlI[1]) * lIlIIIlI[1] - lIlIIIlI[2];
      if ((lIIIIIlIII(llIIIIlllllIIll.getBlockState(llIIIIlllllIIlI.west()).getBlock(), llIIIIlllllIlII)) && (lIIIIIlIII(llIIIIlllllIIll.getBlockState(llIIIIlllllIIlI.east()).getBlock(), llIIIIlllllIlII)))
      {
        llIIIIllllIlllI = llIIIIlllllIIlI.getX() + 0.5D + 0.25D * llIIIIllllIlIII;
        llIIIIllllIlIll = llIIIIllllIIIlI.nextFloat() * 2.0F * llIIIIllllIlIII;
        "".length();
        if (((0xAD ^ 0x8D) & (0x43 ^ 0x63 ^ 0xFFFFFFFF)) <= 0) {}
      }
      else
      {
        llIIIIllllIllII = llIIIIlllllIIlI.getZ() + 0.5D + 0.25D * llIIIIllllIlIII;
        llIIIIllllIlIIl = llIIIIllllIIIlI.nextFloat() * 2.0F * llIIIIllllIlIII;
      }
      llIIIIlllllIIll.spawnParticle(EnumParticleTypes.PORTAL, llIIIIllllIlllI, llIIIIllllIllIl, llIIIIllllIllII, llIIIIllllIlIll, llIIIIllllIlIlI, llIIIIllllIlIIl, new int[lIlIIIlI[0]]);
      llIIIIllllIllll++;
    }
  }
  
  private static boolean lIIIIIIIll(Object ???)
  {
    boolean llIIIIlIlllIIII;
    return ??? != null;
  }
  
  public int getMetaFromState(IBlockState llIIIIlllIlIIII)
  {
    ;
    return getMetaForAxis((EnumFacing.Axis)llIIIIlllIlIIII.getValue(AXIS));
  }
  
  private static boolean lIIIIIlIII(Object ???, Object arg1)
  {
    Object localObject;
    char llIIIIlIlllIIlI;
    return ??? != localObject;
  }
  
  public void onEntityCollidedWithBlock(World llIIIlIIIIIIllI, BlockPos llIIIlIIIIIIlIl, IBlockState llIIIlIIIIIIlII, Entity llIIIlIIIIIIIll)
  {
    ;
    ;
    if ((lIIIIIIlll(ridingEntity)) && (lIIIIIIlll(riddenByEntity))) {
      llIIIlIIIIIIIll.func_181015_d(llIIIlIIIIIIlIl);
    }
  }
  
  private static boolean lIIIIIllII(int ???, int arg1)
  {
    int i;
    short llIIIIlIllllllI;
    return ??? == i;
  }
  
  private static boolean lllllllll(int ???, int arg1)
  {
    int i;
    byte llIIIIlIlllIllI;
    return ??? < i;
  }
  
  static
  {
    lllllllIl();
    llllllIlI();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llIIIIlllIIllIl, new IProperty[] { AXIS });
  }
  
  private static boolean lIIIIIlIll(int ???, int arg1)
  {
    int i;
    byte llIIIIlIllllIlI;
    return ??? >= i;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.TRANSLUCENT;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llIIIlIIlIllllI, BlockPos llIIIlIIlIlllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing.Axis llIIIlIIlIlllII = (EnumFacing.Axis)llIIIlIIlIllllI.getBlockState(llIIIlIIlIlllIl).getValue(AXIS);
    float llIIIlIIlIllIll = 0.125F;
    float llIIIlIIlIllIlI = 0.125F;
    if (lIIIIIIlII(llIIIlIIlIlllII, EnumFacing.Axis.X)) {
      llIIIlIIlIllIll = 0.5F;
    }
    if (lIIIIIIlII(llIIIlIIlIlllII, EnumFacing.Axis.Z)) {
      llIIIlIIlIllIlI = 0.5F;
    }
    llIIIlIIlIllIIl.setBlockBounds(0.5F - llIIIlIIlIllIll, 0.0F, 0.5F - llIIIlIIlIllIlI, 0.5F + llIIIlIIlIllIll, 1.0F, 0.5F + llIIIlIIlIllIlI);
  }
  
  private static String lllllIllI(String llIIIIllIIIIlIl, String llIIIIllIIIIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIIIIllIIIlIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llIIIIllIIIIllI.getBytes(StandardCharsets.UTF_8)), lIlIIIlI[8]), "DES");
      Cipher llIIIIllIIIlIIl = Cipher.getInstance("DES");
      llIIIIllIIIlIIl.init(lIlIIIlI[1], llIIIIllIIIlIlI);
      return new String(llIIIIllIIIlIIl.doFinal(Base64.getDecoder().decode(llIIIIllIIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIIIIllIIIlIII)
    {
      llIIIIllIIIlIII.printStackTrace();
    }
    return null;
  }
  
  public boolean shouldSideBeRendered(IBlockAccess llIIIlIIIIlIlll, BlockPos llIIIlIIIIlIllI, EnumFacing llIIIlIIIIlIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing.Axis llIIIlIIIlIIIII = null;
    IBlockState llIIIlIIIIlllll = llIIIlIIIIlIlll.getBlockState(llIIIlIIIIlIllI);
    if (lIIIIIIlII(llIIIlIIIIlIlll.getBlockState(llIIIlIIIIlIllI).getBlock(), llIIIlIIIIllIII))
    {
      llIIIlIIIlIIIII = (EnumFacing.Axis)llIIIlIIIIlllll.getValue(AXIS);
      if (lIIIIIIlll(llIIIlIIIlIIIII)) {
        return lIlIIIlI[0];
      }
      if ((lIIIIIIlII(llIIIlIIIlIIIII, EnumFacing.Axis.Z)) && (lIIIIIlIII(llIIIlIIIIlIlIl, EnumFacing.EAST)) && (lIIIIIlIII(llIIIlIIIIlIlIl, EnumFacing.WEST))) {
        return lIlIIIlI[0];
      }
      if ((lIIIIIIlII(llIIIlIIIlIIIII, EnumFacing.Axis.X)) && (lIIIIIlIII(llIIIlIIIIlIlIl, EnumFacing.SOUTH)) && (lIIIIIlIII(llIIIlIIIIlIlIl, EnumFacing.NORTH))) {
        return lIlIIIlI[0];
      }
    }
    if ((lIIIIIIlII(llIIIlIIIIlIlll.getBlockState(llIIIlIIIIlIllI.west()).getBlock(), llIIIlIIIIllIII)) && (lIIIIIlIII(llIIIlIIIIlIlll.getBlockState(llIIIlIIIIlIllI.west(lIlIIIlI[1])).getBlock(), llIIIlIIIIllIII)))
    {
      "".length();
      if (null == null) {
        break label234;
      }
      return (0x28 ^ 0x9 ^ 0x18 ^ 0x25) & (0x41 ^ 0x3F ^ 0x6E ^ 0xC ^ -" ".length());
    }
    label234:
    boolean llIIIlIIIIllllI = lIlIIIlI[0];
    if ((lIIIIIIlII(llIIIlIIIIlIlll.getBlockState(llIIIlIIIIlIllI.east()).getBlock(), llIIIlIIIIllIII)) && (lIIIIIlIII(llIIIlIIIIlIlll.getBlockState(llIIIlIIIIlIllI.east(lIlIIIlI[1])).getBlock(), llIIIlIIIIllIII)))
    {
      "".length();
      if (((0x5E ^ 0x6C) & (0x16 ^ 0x24 ^ 0xFFFFFFFF)) == 0) {
        break label331;
      }
      return (0x52 ^ 0x18) & (0x7D ^ 0x37 ^ 0xFFFFFFFF);
    }
    label331:
    boolean llIIIlIIIIlllIl = lIlIIIlI[0];
    if ((lIIIIIIlII(llIIIlIIIIlIlll.getBlockState(llIIIlIIIIlIllI.north()).getBlock(), llIIIlIIIIllIII)) && (lIIIIIlIII(llIIIlIIIIlIlll.getBlockState(llIIIlIIIIlIllI.north(lIlIIIlI[1])).getBlock(), llIIIlIIIIllIII)))
    {
      "".length();
      if ("   ".length() == "   ".length()) {
        break label442;
      }
      return (0x32 ^ 0x3F ^ 0x77 ^ 0x50) & (0x7F ^ 0x30 ^ 0x2C ^ 0x49 ^ -" ".length());
    }
    label442:
    boolean llIIIlIIIIlllII = lIlIIIlI[0];
    if ((lIIIIIIlII(llIIIlIIIIlIlll.getBlockState(llIIIlIIIIlIllI.south()).getBlock(), llIIIlIIIIllIII)) && (lIIIIIlIII(llIIIlIIIIlIlll.getBlockState(llIIIlIIIIlIllI.south(lIlIIIlI[1])).getBlock(), llIIIlIIIIllIII)))
    {
      "".length();
      if (((0x1D ^ 0x37 ^ 0x23 ^ 0x1B) & (0x31 ^ 0x2A ^ 0x49 ^ 0x40 ^ -" ".length())) < (0xD6 ^ 0xB2 ^ 0x7 ^ 0x67)) {
        break label588;
      }
      return (0x6D ^ 0x77 ^ 0xD ^ 0x6) & (0x54 ^ 0x5E ^ 0x84 ^ 0x9F ^ -" ".length());
    }
    label588:
    boolean llIIIlIIIIllIll = lIlIIIlI[0];
    if ((lIIIIIIIII(llIIIlIIIIllllI)) && (lIIIIIIIII(llIIIlIIIIlllIl)) && (lIIIIIlIII(llIIIlIIIlIIIII, EnumFacing.Axis.X)))
    {
      "".length();
      if (null == null) {
        break label655;
      }
      return (0xD2 ^ 0x92) & (0xDA ^ 0x9A ^ 0xFFFFFFFF);
    }
    label655:
    boolean llIIIlIIIIllIlI = lIlIIIlI[2];
    if ((lIIIIIIIII(llIIIlIIIIlllII)) && (lIIIIIIIII(llIIIlIIIIllIll)) && (lIIIIIlIII(llIIIlIIIlIIIII, EnumFacing.Axis.Z)))
    {
      "".length();
      if (-(0xF8 ^ 0x82 ^ 86 + 5 - 54 + 90) < 0) {
        break label765;
      }
      return (" ".length() ^ 0x65 ^ 0x3F) & (29 + 80 - 25 + 112 ^ 0 + '' - 82 + 84 ^ -" ".length());
    }
    label765:
    boolean llIIIlIIIIllIIl = lIlIIIlI[2];
    if ((llllllllI(llIIIlIIIIllIlI)) && (lIIIIIIlII(llIIIlIIIIlIlIl, EnumFacing.WEST)))
    {
      "".length();
      if ("  ".length() == 0) {
        return (0x43 ^ 0x55) & (0x35 ^ 0x23 ^ 0xFFFFFFFF);
      }
    }
    else if ((llllllllI(llIIIlIIIIllIlI)) && (lIIIIIIlII(llIIIlIIIIlIlIl, EnumFacing.EAST)))
    {
      "".length();
      if (((0x47 ^ 0x59 ^ "   ".length()) & (0x95 ^ 0x8C ^ 0x26 ^ 0x22 ^ -" ".length())) >= " ".length()) {
        return (0x2A ^ 0x11 ^ 0xB ^ 0x27) & (0xD8 ^ 0xA4 ^ 0xC8 ^ 0xA3 ^ -" ".length());
      }
    }
    else if ((llllllllI(llIIIlIIIIllIIl)) && (lIIIIIIlII(llIIIlIIIIlIlIl, EnumFacing.NORTH)))
    {
      "".length();
      if (('' + '' - 199 + 82 ^ 81 + 39 - -28 + 4) <= " ".length()) {
        return (0x34 ^ 0x30 ^ 0x5C ^ 0x3) & (0x89 ^ 0x80 ^ 0x20 ^ 0x72 ^ -" ".length());
      }
    }
    else if ((llllllllI(llIIIlIIIIllIIl)) && (lIIIIIIlII(llIIIlIIIIlIlIl, EnumFacing.SOUTH)))
    {
      "".length();
      if (null == null) {
        break label1112;
      }
      return (63 + 50 - 87 + 149 ^ 47 + 85 - 36 + 56) & ('' + 79 - 149 + 78 ^ 3 + 83 - -54 + 45 ^ -" ".length());
    }
    label1112:
    return lIlIIIlI[0];
  }
  
  private static void lllllllIl()
  {
    lIlIIIlI = new int[9];
    lIlIIIlI[0] = ("  ".length() & ("  ".length() ^ -" ".length()));
    lIlIIIlI[1] = "  ".length();
    lIlIIIlI[2] = " ".length();
    lIlIIIlI[3] = (0x87FA & 0x7FD5);
    lIlIIIlI[4] = (0x96 ^ 0xAF);
    lIlIIIlI[5] = (0x65 ^ 0x29 ^ 0x3B ^ 0x13);
    lIlIIIlI[6] = (0x18 ^ 0x79 ^ 0x64 ^ 0x1);
    lIlIIIlI[7] = "   ".length();
    lIlIIIlI[8] = (0xA1 ^ 0xA9);
  }
  
  public void updateTick(World llIIIlIIlllIIII, BlockPos llIIIlIIlllIlll, IBlockState llIIIlIIlllIllI, Random llIIIlIIlllIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llIIIlIIlllIIIl.updateTick(llIIIlIIlllIIII, llIIIlIIllIllll, llIIIlIIlllIllI, llIIIlIIlllIlIl);
    if ((llllllllI(provider.isSurfaceWorld())) && (llllllllI(llIIIlIIlllIIII.getGameRules().getBoolean(lIIlllll[lIlIIIlI[2]]))) && (lllllllll(llIIIlIIlllIlIl.nextInt(lIlIIIlI[3]), llIIIlIIlllIIII.getDifficulty().getDifficultyId())))
    {
      int llIIIlIIlllIlII = llIIIlIIllIllll.getY();
      BlockPos llIIIlIIlllIIll = llIIIlIIllIllll;
      "".length();
      if ("  ".length() <= -" ".length()) {
        return;
      }
      while ((lIIIIIIIII(World.doesBlockHaveSolidTopSurface(llIIIlIIlllIIII, llIIIlIIlllIIll))) && (!lIIIIIIIIl(llIIIlIIlllIIll.getY()))) {
        llIIIlIIlllIIll = llIIIlIIlllIIll.down();
      }
      if ((lIIIIIIIlI(llIIIlIIlllIlII)) && (lIIIIIIIII(llIIIlIIlllIIII.getBlockState(llIIIlIIlllIIll.up()).getBlock().isNormalCube())))
      {
        Entity llIIIlIIlllIIlI = ItemMonsterPlacer.spawnCreature(llIIIlIIlllIIII, lIlIIIlI[4], llIIIlIIlllIIll.getX() + 0.5D, llIIIlIIlllIIll.getY() + 1.1D, llIIIlIIlllIIll.getZ() + 0.5D);
        if (lIIIIIIIll(llIIIlIIlllIIlI)) {
          timeUntilPortal = llIIIlIIlllIIlI.getPortalCooldown();
        }
      }
    }
  }
  
  public BlockPortal()
  {
    llIIIlIlIIIIIlI.<init>(Material.portal, lIlIIIlI[0]);
    llIIIlIlIIIIIll.setDefaultState(blockState.getBaseState().withProperty(AXIS, EnumFacing.Axis.X));
    "".length();
  }
  
  private static boolean lIIIIIIlll(Object ???)
  {
    byte llIIIIlIllIlIlI;
    return ??? == null;
  }
  
  private static boolean llllllllI(int ???)
  {
    short llIIIIlIllIlIII;
    return ??? != 0;
  }
  
  private static boolean lIIIIIIIII(int ???)
  {
    boolean llIIIIlIllIIllI;
    return ??? == 0;
  }
  
  public IBlockState getStateFromMeta(int llIIIIlllIlIlIl)
  {
    ;
    ;
    if (lIIIIIllII(llIIIIlllIlIlIl & lIlIIIlI[7], lIlIIIlI[1]))
    {
      "".length();
      if (((0xF ^ 0x3) & (0xA5 ^ 0xA9 ^ 0xFFFFFFFF)) > -" ".length()) {
        break label63;
      }
      return null;
    }
    label63:
    return AXIS.withProperty(EnumFacing.Axis.Z, EnumFacing.Axis.X);
  }
  
  public static class Size
  {
    static {}
    
    public boolean func_150860_b()
    {
      ;
      if ((llIIllIlIIIlIl(field_150861_f)) && (llIIllIlIIIlII(field_150868_h, lIIIIllIIIIll[3])) && (llIIllIlIIlIIl(field_150868_h, lIIIIllIIIIll[1])) && (llIIllIlIIIlII(field_150862_g, lIIIIllIIIIll[5])) && (llIIllIlIIlIIl(field_150862_g, lIIIIllIIIIll[1]))) {
        return lIIIIllIIIIll[2];
      }
      return lIIIIllIIIIll[0];
    }
    
    protected int func_180120_a(BlockPos llllllllllllllIlIlIlIlIlllIIlIIl, EnumFacing llllllllllllllIlIlIlIlIlllIIIIlI)
    {
      ;
      ;
      ;
      ;
      ;
      int llllllllllllllIlIlIlIlIlllIIIlll = lIIIIllIIIIll[0];
      "".length();
      if (-" ".length() == "   ".length()) {
        return (0xAF ^ 0xB1) & (0x66 ^ 0x78 ^ 0xFFFFFFFF);
      }
      while (!llIIllIlIIIlII(llllllllllllllIlIlIlIlIlllIIIlll, lIIIIllIIIIll[4]))
      {
        BlockPos llllllllllllllIlIlIlIlIlllIIIllI = llllllllllllllIlIlIlIlIlllIIIIll.offset(llllllllllllllIlIlIlIlIlllIIIIlI, llllllllllllllIlIlIlIlIlllIIIlll);
        if (!llIIllIlIIIllI(llllllllllllllIlIlIlIlIlllIIlIlI.func_150857_a(world.getBlockState(llllllllllllllIlIlIlIlIlllIIIllI).getBlock()))) {
          break;
        }
        if (llIIllIlIIIlll(world.getBlockState(llllllllllllllIlIlIlIlIlllIIIllI.down()).getBlock(), Blocks.obsidian))
        {
          "".length();
          if (-"   ".length() <= 0) {
            break;
          }
          return (0x64 ^ 0x51 ^ 0x6E ^ 0x54) & (0x27 ^ 0x56 ^ 0xCF ^ 0xB1 ^ -" ".length());
        }
        llllllllllllllIlIlIlIlIlllIIIlll++;
      }
      Block llllllllllllllIlIlIlIlIlllIIIlIl = world.getBlockState(llllllllllllllIlIlIlIlIlllIIIIll.offset(llllllllllllllIlIlIlIlIlllIIIIlI, llllllllllllllIlIlIlIlIlllIIIlll)).getBlock();
      if (llIIllIIllllll(llllllllllllllIlIlIlIlIlllIIIlIl, Blocks.obsidian))
      {
        "".length();
        if ("  ".length() > 0) {
          break label247;
        }
        return (0x5A ^ 0x32 ^ 0x23 ^ 0x47) & (0x35 ^ 0x51 ^ 0xEA ^ 0x82 ^ -" ".length());
      }
      label247:
      return lIIIIllIIIIll[0];
    }
    
    private static boolean llIIllIlIIIIlI(int ???)
    {
      short llllllllllllllIlIlIlIlIlIlllIIlI;
      return ??? == 0;
    }
    
    protected boolean func_150857_a(Block llllllllllllllIlIlIlIlIllIlIlIIl)
    {
      ;
      if ((llIIllIlIIIlll(blockMaterial, Material.air)) && (llIIllIlIIIlll(llllllllllllllIlIlIlIlIllIlIlIlI, Blocks.fire)) && (llIIllIlIIIlll(llllllllllllllIlIlIlIlIllIlIlIlI, Blocks.portal))) {
        return lIIIIllIIIIll[0];
      }
      return lIIIIllIIIIll[2];
    }
    
    public int func_181101_b()
    {
      ;
      return field_150868_h;
    }
    
    public void func_150859_c()
    {
      ;
      ;
      ;
      ;
      int llllllllllllllIlIlIlIlIllIlIIIII = lIIIIllIIIIll[0];
      "".length();
      if ((0x11 ^ 0x4D ^ 0xDC ^ 0x84) != ('' + 23 - -34 + 5 ^ 54 + 40 - -4 + 88)) {
        return;
      }
      while (!llIIllIlIIIlII(llllllllllllllIlIlIlIlIllIlIIIII, field_150868_h))
      {
        BlockPos llllllllllllllIlIlIlIlIllIIlllll = field_150861_f.offset(field_150866_c, llllllllllllllIlIlIlIlIllIlIIIII);
        int llllllllllllllIlIlIlIlIllIIllllI = lIIIIllIIIIll[0];
        "".length();
        if ((0x97 ^ 0xC2 ^ 0x61 ^ 0x30) == "   ".length()) {
          return;
        }
        while (!llIIllIlIIIlII(llllllllllllllIlIlIlIlIllIIllllI, field_150862_g)) {
          "".length();
        }
      }
    }
    
    public int func_181100_a()
    {
      ;
      return field_150862_g;
    }
    
    private static void llIIllIIlllllI()
    {
      lIIIIllIIIIll = new int[6];
      lIIIIllIIIIll[0] = ((0x59 ^ 0x51) & (0x59 ^ 0x51 ^ 0xFFFFFFFF));
      lIIIIllIIIIll[1] = (63 + 122 - 159 + 143 ^ '²' + 11 - 99 + 98);
      lIIIIllIIIIll[2] = " ".length();
      lIIIIllIIIIll[3] = "  ".length();
      lIIIIllIIIIll[4] = (0xDB ^ 0x89 ^ 0x69 ^ 0x2D);
      lIIIIllIIIIll[5] = "   ".length();
    }
    
    private static boolean llIIllIlIIIlII(int ???, int arg1)
    {
      int i;
      short llllllllllllllIlIlIlIlIllIIIlIII;
      return ??? >= i;
    }
    
    private static boolean llIIllIlIIIIll(int ???)
    {
      boolean llllllllllllllIlIlIlIlIlIlllIIII;
      return ??? >= 0;
    }
    
    private static boolean llIIllIlIIIIII(int ???, int arg1)
    {
      int i;
      Exception llllllllllllllIlIlIlIlIllIIIIIII;
      return ??? > i;
    }
    
    protected int func_150858_a()
    {
      ;
      ;
      ;
      ;
      field_150862_g = lIIIIllIIIIll[0];
      "".length();
      if (((0x55 ^ 0x7D) & (0x62 ^ 0x4A ^ 0xFFFFFFFF)) != ((0xB9 ^ 0xAD) & (0xB5 ^ 0xA1 ^ 0xFFFFFFFF))) {
        return (0x31 ^ 0x1C) & (0xBF ^ 0x92 ^ 0xFFFFFFFF);
      }
      while (!llIIllIlIIIlII(field_150862_g, lIIIIllIIIIll[1]))
      {
        int llllllllllllllIlIlIlIlIllIllIlII = lIIIIllIIIIll[0];
        "".length();
        if ((0xA ^ 0xF) <= 0) {
          return (0x85 ^ 0x8D) & (0x4F ^ 0x47 ^ 0xFFFFFFFF);
        }
        while (!llIIllIlIIIlII(llllllllllllllIlIlIlIlIllIllIlII, field_150868_h))
        {
          BlockPos llllllllllllllIlIlIlIlIllIllIIll = field_150861_f.offset(field_150866_c, llllllllllllllIlIlIlIlIllIllIlII).up(field_150862_g);
          Block llllllllllllllIlIlIlIlIllIllIIlI = world.getBlockState(llllllllllllllIlIlIlIlIllIllIIll).getBlock();
          if (llIIllIlIIIIlI(llllllllllllllIlIlIlIlIllIllIIII.func_150857_a(llllllllllllllIlIlIlIlIllIllIIlI)))
          {
            "".length();
            if (" ".length() == " ".length()) {
              break;
            }
            return (0x54 ^ 0x6F ^ 0x2D ^ 0x6) & (0x28 ^ 0x79 ^ 0x0 ^ 0x41 ^ -" ".length());
          }
          if (llIIllIIllllll(llllllllllllllIlIlIlIlIllIllIIlI, Blocks.portal)) {
            field_150864_e += lIIIIllIIIIll[2];
          }
          if (llIIllIlIIIIlI(llllllllllllllIlIlIlIlIllIllIlII))
          {
            llllllllllllllIlIlIlIlIllIllIIlI = world.getBlockState(llllllllllllllIlIlIlIlIllIllIIll.offset(field_150863_d)).getBlock();
            if (llIIllIlIIIlll(llllllllllllllIlIlIlIlIllIllIIlI, Blocks.obsidian))
            {
              "".length();
              if (((0x87 ^ 0xBD) & (0x5B ^ 0x61 ^ 0xFFFFFFFF)) <= " ".length()) {
                break;
              }
              return (0x68 ^ 0x78) & (0x1 ^ 0x11 ^ 0xFFFFFFFF);
            }
          }
          else if (llIIllIlIIlIII(llllllllllllllIlIlIlIlIllIllIlII, field_150868_h - lIIIIllIIIIll[2]))
          {
            llllllllllllllIlIlIlIlIllIllIIlI = world.getBlockState(llllllllllllllIlIlIlIlIllIllIIll.offset(field_150866_c)).getBlock();
            if (llIIllIlIIIlll(llllllllllllllIlIlIlIlIllIllIIlI, Blocks.obsidian))
            {
              "".length();
              if (-"  ".length() < 0) {
                break;
              }
              return (113 + 'Ç' - 130 + 33 ^ 105 + 45 - 122 + 103) & (0x67 ^ 0x3 ^ 0xBD ^ 0x8D ^ -" ".length());
            }
          }
          llllllllllllllIlIlIlIlIllIllIlII++;
        }
        field_150862_g += lIIIIllIIIIll[2];
      }
      int llllllllllllllIlIlIlIlIllIllIIIl = lIIIIllIIIIll[0];
      "".length();
      if ("  ".length() <= " ".length()) {
        return (0xC4 ^ 0x8E) & (0x20 ^ 0x6A ^ 0xFFFFFFFF);
      }
      while (!llIIllIlIIIlII(llllllllllllllIlIlIlIlIllIllIIIl, field_150868_h))
      {
        if (llIIllIlIIIlll(world.getBlockState(field_150861_f.offset(field_150866_c, llllllllllllllIlIlIlIlIllIllIIIl).up(field_150862_g)).getBlock(), Blocks.obsidian))
        {
          field_150862_g = lIIIIllIIIIll[0];
          "".length();
          if (" ".length() >= " ".length()) {
            break;
          }
          return (32 + '' - 51 + 24 ^ 21 + 9 - -23 + 94) & (0x74 ^ 0x32 ^ 0x2B ^ 0x6A ^ -" ".length());
        }
        llllllllllllllIlIlIlIlIllIllIIIl++;
      }
      if ((llIIllIlIIlIIl(field_150862_g, lIIIIllIIIIll[1])) && (llIIllIlIIIlII(field_150862_g, lIIIIllIIIIll[5]))) {
        return field_150862_g;
      }
      field_150861_f = null;
      field_150868_h = lIIIIllIIIIll[0];
      field_150862_g = lIIIIllIIIIll[0];
      return lIIIIllIIIIll[0];
    }
    
    private static boolean llIIllIlIIlIIl(int ???, int arg1)
    {
      int i;
      byte llllllllllllllIlIlIlIlIllIIIIlII;
      return ??? <= i;
    }
    
    private static boolean llIIllIlIIIIIl(int ???)
    {
      byte llllllllllllllIlIlIlIlIlIllIlllI;
      return ??? > 0;
    }
    
    private static boolean llIIllIIllllll(Object ???, Object arg1)
    {
      Object localObject;
      boolean llllllllllllllIlIlIlIlIlIllllIII;
      return ??? == localObject;
    }
    
    private static boolean llIIllIlIIIlll(Object ???, Object arg1)
    {
      Object localObject;
      double llllllllllllllIlIlIlIlIlIlllllII;
      return ??? != localObject;
    }
    
    public Size(World llllllllllllllIlIlIlIlIlllIlIIll, BlockPos llllllllllllllIlIlIlIlIlllIlIIlI, EnumFacing.Axis llllllllllllllIlIlIlIlIlllIlIlll)
    {
      world = llllllllllllllIlIlIlIlIlllIlIIll;
      axis = llllllllllllllIlIlIlIlIlllIlIlll;
      if (llIIllIIllllll(llllllllllllllIlIlIlIlIlllIlIlll, EnumFacing.Axis.X))
      {
        field_150863_d = EnumFacing.EAST;
        field_150866_c = EnumFacing.WEST;
        "".length();
        if (((0xC4 ^ 0x9E) & (0x6C ^ 0x36 ^ 0xFFFFFFFF)) != 0) {
          throw null;
        }
      }
      else
      {
        field_150863_d = EnumFacing.NORTH;
        field_150866_c = EnumFacing.SOUTH;
      }
      BlockPos llllllllllllllIlIlIlIlIlllIlIllI = llllllllllllllIlIlIlIlIlllIlIIlI;
      "".length();
      if (" ".length() <= 0) {
        throw null;
      }
      while ((llIIllIlIIIIII(llllllllllllllIlIlIlIlIlllIlIIlI.getY(), llllllllllllllIlIlIlIlIlllIlIllI.getY() - lIIIIllIIIIll[1])) && (llIIllIlIIIIIl(llllllllllllllIlIlIlIlIlllIlIIlI.getY())) && (!llIIllIlIIIIlI(llllllllllllllIlIlIlIlIlllIlIlII.func_150857_a(llllllllllllllIlIlIlIlIlllIlIIll.getBlockState(llllllllllllllIlIlIlIlIlllIlIIlI.down()).getBlock())))) {
        llllllllllllllIlIlIlIlIlllIlIIlI = llllllllllllllIlIlIlIlIlllIlIIlI.down();
      }
      int llllllllllllllIlIlIlIlIlllIlIlIl = llllllllllllllIlIlIlIlIlllIlIlII.func_180120_a(llllllllllllllIlIlIlIlIlllIlIIlI, field_150863_d) - lIIIIllIIIIll[2];
      if (llIIllIlIIIIll(llllllllllllllIlIlIlIlIlllIlIlIl))
      {
        field_150861_f = llllllllllllllIlIlIlIlIlllIlIIlI.offset(field_150863_d, llllllllllllllIlIlIlIlIlllIlIlIl);
        field_150868_h = llllllllllllllIlIlIlIlIlllIlIlII.func_180120_a(field_150861_f, field_150866_c);
        if ((!llIIllIlIIIlII(field_150868_h, lIIIIllIIIIll[3])) || (llIIllIlIIIIII(field_150868_h, lIIIIllIIIIll[1])))
        {
          field_150861_f = null;
          field_150868_h = lIIIIllIIIIll[0];
        }
      }
      if (llIIllIlIIIlIl(field_150861_f)) {
        field_150862_g = llllllllllllllIlIlIlIlIlllIlIlII.func_150858_a();
      }
    }
    
    private static boolean llIIllIlIIIlIl(Object ???)
    {
      int llllllllllllllIlIlIlIlIlIlllIllI;
      return ??? != null;
    }
    
    private static boolean llIIllIlIIlIII(int ???, int arg1)
    {
      int i;
      byte llllllllllllllIlIlIlIlIllIIIllII;
      return ??? == i;
    }
    
    private static boolean llIIllIlIIIllI(int ???)
    {
      short llllllllllllllIlIlIlIlIlIlllIlII;
      return ??? != 0;
    }
  }
}

package net.minecraft.block.state;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockPistonBase;
import net.minecraft.block.material.Material;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.World;

public class BlockPistonStructureHelper
{
  public BlockPistonStructureHelper(World llllllllllllllIllIIlIlIlllIIllII, BlockPos llllllllllllllIllIIlIlIlllIIlIll, EnumFacing llllllllllllllIllIIlIlIlllIIllll, boolean llllllllllllllIllIIlIlIlllIIlllI)
  {
    world = llllllllllllllIllIIlIlIlllIIllII;
    pistonPos = llllllllllllllIllIIlIlIlllIlIIII;
    if (lIllllllIIlIIl(llllllllllllllIllIIlIlIlllIIlllI))
    {
      moveDirection = llllllllllllllIllIIlIlIlllIIllll;
      blockToMove = llllllllllllllIllIIlIlIlllIlIIII.offset(llllllllllllllIllIIlIlIlllIIllll);
      "".length();
      if (-" ".length() >= 0) {
        throw null;
      }
    }
    else
    {
      moveDirection = llllllllllllllIllIIlIlIlllIIllll.getOpposite();
      blockToMove = llllllllllllllIllIIlIlIlllIlIIII.offset(llllllllllllllIllIIlIlIlllIIllll, lllllIlIllIl[0]);
    }
  }
  
  private static boolean lIllllllIlIIlI(int ???)
  {
    byte llllllllllllllIllIIlIlIlIlIlIlIl;
    return ??? < 0;
  }
  
  private static boolean lIllllllIIlIlI(int ???)
  {
    Exception llllllllllllllIllIIlIlIlIlIlIlll;
    return ??? == 0;
  }
  
  private static boolean lIllllllIIllII(Object ???, Object arg1)
  {
    Object localObject;
    byte llllllllllllllIllIIlIlIlIlIlllll;
    return ??? == localObject;
  }
  
  public boolean canMove()
  {
    ;
    ;
    ;
    ;
    toMove.clear();
    toDestroy.clear();
    Block llllllllllllllIllIIlIlIlllIIIIll = world.getBlockState(blockToMove).getBlock();
    if (lIllllllIIlIlI(BlockPistonBase.canPush(llllllllllllllIllIIlIlIlllIIIIll, world, blockToMove, moveDirection, lllllIlIllIl[1])))
    {
      if (lIllllllIIlIll(llllllllllllllIllIIlIlIlllIIIIll.getMobilityFlag(), lllllIlIllIl[2])) {
        return lllllIlIllIl[1];
      }
      "".length();
      return lllllIlIllIl[2];
    }
    if (lIllllllIIlIlI(llllllllllllllIllIIlIlIlllIIIIII.func_177251_a(blockToMove))) {
      return lllllIlIllIl[1];
    }
    int llllllllllllllIllIIlIlIlllIIIIlI = lllllIlIllIl[1];
    "".length();
    if (((0xC6 ^ 0xBA ^ 0x8F ^ 0xAB) & (0xD5 ^ 0x85 ^ 0xA4 ^ 0xAC ^ -" ".length())) >= "  ".length()) {
      return ('' + 26 - 49 + 97 ^ 4 + 50 - 25 + 106) & (0x3D ^ 0x68 ^ " ".length() ^ -" ".length());
    }
    while (!lIllllllIIllIl(llllllllllllllIllIIlIlIlllIIIIlI, toMove.size()))
    {
      BlockPos llllllllllllllIllIIlIlIlllIIIIIl = (BlockPos)toMove.get(llllllllllllllIllIIlIlIlllIIIIlI);
      if ((lIllllllIIllII(world.getBlockState(llllllllllllllIllIIlIlIlllIIIIIl).getBlock(), Blocks.slime_block)) && (lIllllllIIlIlI(llllllllllllllIllIIlIlIlllIIIIII.func_177250_b(llllllllllllllIllIIlIlIlllIIIIIl)))) {
        return lllllIlIllIl[1];
      }
      llllllllllllllIllIIlIlIlllIIIIlI++;
    }
    return lllllIlIllIl[2];
  }
  
  public List<BlockPos> getBlocksToMove()
  {
    ;
    return toMove;
  }
  
  private boolean func_177251_a(BlockPos llllllllllllllIllIIlIlIllIllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Block llllllllllllllIllIIlIlIllIllIIII = world.getBlockState(llllllllllllllIllIIlIlIllIllIIIl).getBlock();
    if (lIllllllIIllII(llllllllllllllIllIIlIlIllIllIIII.getMaterial(), Material.air)) {
      return lllllIlIllIl[2];
    }
    if (lIllllllIIlIlI(BlockPistonBase.canPush(llllllllllllllIllIIlIlIllIllIIII, world, llllllllllllllIllIIlIlIllIllIIIl, moveDirection, lllllIlIllIl[1]))) {
      return lllllIlIllIl[2];
    }
    if (lIllllllIIlIIl(llllllllllllllIllIIlIlIllIllIIIl.equals(pistonPos))) {
      return lllllIlIllIl[2];
    }
    if (lIllllllIIlIIl(toMove.contains(llllllllllllllIllIIlIlIllIllIIIl))) {
      return lllllIlIllIl[2];
    }
    int llllllllllllllIllIIlIlIllIlIllll = lllllIlIllIl[2];
    if (lIllllllIIlllI(llllllllllllllIllIIlIlIllIlIllll + toMove.size(), lllllIlIllIl[3])) {
      return lllllIlIllIl[1];
    }
    while (!lIllllllIlIIII(llllllllllllllIllIIlIlIllIllIIII, Blocks.slime_block))
    {
      BlockPos llllllllllllllIllIIlIlIllIlIlllI = llllllllllllllIllIIlIlIllIllIIIl.offset(moveDirection.getOpposite(), llllllllllllllIllIIlIlIllIlIllll);
      llllllllllllllIllIIlIlIllIllIIII = world.getBlockState(llllllllllllllIllIIlIlIllIlIlllI).getBlock();
      if ((!lIllllllIlIIII(llllllllllllllIllIIlIlIllIllIIII.getMaterial(), Material.air)) || (!lIllllllIIlIIl(BlockPistonBase.canPush(llllllllllllllIllIIlIlIllIllIIII, world, llllllllllllllIllIIlIlIllIlIlllI, moveDirection, lllllIlIllIl[1])))) {
        break;
      }
      if (lIllllllIIlIIl(llllllllllllllIllIIlIlIllIlIlllI.equals(pistonPos)))
      {
        "".length();
        if ((126 + 66 - 165 + 144 ^ 114 + 27 - 89 + 123) <= (0xDC ^ 0x8F ^ 0xFD ^ 0xAA)) {
          break;
        }
        return (0x60 ^ 0x51 ^ 0xDC ^ 0xC5) & (61 + 58 - -18 + 53 ^ 57 + 99 - 53 + 47 ^ -" ".length());
      }
      llllllllllllllIllIIlIlIllIlIllll++;
      if (lIllllllIIlllI(llllllllllllllIllIIlIlIllIlIllll + toMove.size(), lllllIlIllIl[3])) {
        return lllllIlIllIl[1];
      }
    }
    int llllllllllllllIllIIlIlIllIlIllIl = lllllIlIllIl[1];
    int llllllllllllllIllIIlIlIllIlIllII = llllllllllllllIllIIlIlIllIlIllll - lllllIlIllIl[2];
    "".length();
    if (-(0x6C ^ 0x69) >= 0) {
      return (0xCC ^ 0x91) & (0x49 ^ 0x14 ^ 0xFFFFFFFF);
    }
    while (!lIllllllIlIIlI(llllllllllllllIllIIlIlIllIlIllII)) {
      "".length();
    }
    llllllllllllllIllIIlIlIllIlIlIll = ;;;;
    do
    {
      int llllllllllllllIllIIlIlIllIlIlIll;
      BlockPos llllllllllllllIllIIlIlIllIlIlIlI;
      int llllllllllllllIllIIlIlIllIlIlIIl;
      if (lIllllllIIlllI(llllllllllllllIllIIlIlIllIlIlIIl, lllllIlIllIl[4]))
      {
        llllllllllllllIllIIlIlIllIllIIlI.func_177255_a(llllllllllllllIllIIlIlIllIlIllIl, llllllllllllllIllIIlIlIllIlIlIIl);
        int llllllllllllllIllIIlIlIllIlIlIII = lllllIlIllIl[1];
        "".length();
        if (((3 + '' - -27 + 52 ^ '«' + '' - 298 + 154) & (60 + 121 - 149 + 187 ^ 12 + 34 - -105 + 34 ^ -" ".length())) >= (0x3B ^ 0x2D ^ 0x48 ^ 0x5A)) {
          return "  ".length() & ("  ".length() ^ -" ".length());
        }
        while (!lIllllllIIlllI(llllllllllllllIllIIlIlIllIlIlIII, llllllllllllllIllIIlIlIllIlIlIIl + llllllllllllllIllIIlIlIllIlIllIl))
        {
          BlockPos llllllllllllllIllIIlIlIllIlIIlll = (BlockPos)toMove.get(llllllllllllllIllIIlIlIllIlIlIII);
          if ((lIllllllIIllII(world.getBlockState(llllllllllllllIllIIlIlIllIlIIlll).getBlock(), Blocks.slime_block)) && (lIllllllIIlIlI(llllllllllllllIllIIlIlIllIllIIlI.func_177250_b(llllllllllllllIllIIlIlIllIlIIlll)))) {
            return lllllIlIllIl[1];
          }
          llllllllllllllIllIIlIlIllIlIlIII++;
        }
        return lllllIlIllIl[2];
      }
      llllllllllllllIllIIlIlIllIllIIII = world.getBlockState(llllllllllllllIllIIlIlIllIlIlIlI).getBlock();
      if (lIllllllIIllII(llllllllllllllIllIIlIlIllIllIIII.getMaterial(), Material.air)) {
        return lllllIlIllIl[2];
      }
      if ((!lIllllllIIlIIl(BlockPistonBase.canPush(llllllllllllllIllIIlIlIllIllIIII, world, llllllllllllllIllIIlIlIllIlIlIlI, moveDirection, lllllIlIllIl[2]))) || (lIllllllIIlIIl(llllllllllllllIllIIlIlIllIlIlIlI.equals(pistonPos)))) {
        return lllllIlIllIl[1];
      }
      if (lIllllllIlIllI(llllllllllllllIllIIlIlIllIllIIII.getMobilityFlag(), lllllIlIllIl[2]))
      {
        "".length();
        return lllllIlIllIl[2];
      }
      if (lIllllllIIllIl(toMove.size(), lllllIlIllIl[3])) {
        return lllllIlIllIl[1];
      }
      "".length();
      "".length();
    } while (null == null);
    return (4 + '' - 41 + 126 ^ '' + 38 - 55 + 66) & (0x1B ^ 0x11 ^ 0xAD ^ 0x8A ^ -" ".length());
  }
  
  private static boolean lIllllllIlIIII(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllIllIIlIlIlIllIIllI;
    return ??? != localObject;
  }
  
  static {}
  
  public List<BlockPos> getBlocksToDestroy()
  {
    ;
    return toDestroy;
  }
  
  private static void lIllllllIIlIII()
  {
    lllllIlIllIl = new int[5];
    lllllIlIllIl[0] = "  ".length();
    lllllIlIllIl[1] = ((0x6F ^ 0x49 ^ 0x22 ^ 0x51) & (0x5C ^ 0x76 ^ 64 + 64 - 51 + 50 ^ -" ".length()));
    lllllIlIllIl[2] = " ".length();
    lllllIlIllIl[3] = (0xA3 ^ 0xAF);
    lllllIlIllIl[4] = (-" ".length());
  }
  
  private static boolean lIllllllIIlIll(int ???, int arg1)
  {
    int i;
    long llllllllllllllIllIIlIlIlIlIIlllI;
    return ??? != i;
  }
  
  private static boolean lIllllllIIllIl(int ???, int arg1)
  {
    int i;
    long llllllllllllllIllIIlIlIlIllIlllI;
    return ??? >= i;
  }
  
  private void func_177255_a(int llllllllllllllIllIIlIlIllIIlIlIl, int llllllllllllllIllIIlIlIllIIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    List<BlockPos> llllllllllllllIllIIlIlIllIIlIIll = Lists.newArrayList();
    List<BlockPos> llllllllllllllIllIIlIlIllIIlIIlI = Lists.newArrayList();
    List<BlockPos> llllllllllllllIllIIlIlIllIIlIIIl = Lists.newArrayList();
    "".length();
    "".length();
    "".length();
    toMove.clear();
    "".length();
    "".length();
    "".length();
  }
  
  private boolean func_177250_b(BlockPos llllllllllllllIllIIlIlIllIIIIIll)
  {
    ;
    ;
    ;
    ;
    short llllllllllllllIllIIlIlIlIlllllIl = (llllllllllllllIllIIlIlIlIlllllII = EnumFacing.values()).length;
    long llllllllllllllIllIIlIlIlIllllllI = lllllIlIllIl[1];
    "".length();
    if (((0x13 ^ 0x5B ^ 0x30 ^ 0x2E) & (65 + 15 - -54 + 60 ^ 9 + 19 - -119 + 1 ^ -" ".length())) != ((0x6A ^ 0x8 ^ (0x1F ^ 0x5D) & (0x5D ^ 0x1F ^ 0xFFFFFFFF)) & (0x7C ^ 0x18 ^ 0x15 ^ 0x13 ^ -" ".length()))) {
      return (0x5F ^ 0x66 ^ 0x52 ^ 0x6D) & (118 + 4 - 0 + 23 ^ 41 + 53 - 64 + 121 ^ -" ".length());
    }
    while (!lIllllllIIllIl(llllllllllllllIllIIlIlIlIllllllI, llllllllllllllIllIIlIlIlIlllllIl))
    {
      EnumFacing llllllllllllllIllIIlIlIllIIIIIlI = llllllllllllllIllIIlIlIlIlllllII[llllllllllllllIllIIlIlIlIllllllI];
      if ((lIllllllIlIIII(llllllllllllllIllIIlIlIllIIIIIlI.getAxis(), moveDirection.getAxis())) && (lIllllllIIlIlI(llllllllllllllIllIIlIlIllIIIIIIl.func_177251_a(llllllllllllllIllIIlIlIllIIIIIll.offset(llllllllllllllIllIIlIlIllIIIIIlI))))) {
        return lllllIlIllIl[1];
      }
      llllllllllllllIllIIlIlIlIllllllI++;
    }
    return lllllIlIllIl[2];
  }
  
  private static boolean lIllllllIIlllI(int ???, int arg1)
  {
    int i;
    short llllllllllllllIllIIlIlIlIllIlIlI;
    return ??? > i;
  }
  
  private static boolean lIllllllIIlIIl(int ???)
  {
    byte llllllllllllllIllIIlIlIlIlIllIlI;
    return ??? != 0;
  }
  
  private static boolean lIllllllIlIllI(int ???, int arg1)
  {
    int i;
    short llllllllllllllIllIIlIlIlIlllIIlI;
    return ??? == i;
  }
}

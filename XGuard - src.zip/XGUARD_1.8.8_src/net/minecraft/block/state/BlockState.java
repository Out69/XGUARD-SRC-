package net.minecraft.block.state;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.base.Objects;
import com.google.common.base.Objects.ToStringHelper;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableTable;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Table;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.util.Cartesian;
import net.minecraft.util.MapPopulator;
import net.minecraft.util.RegistryNamespacedDefaultedByKey;

public class BlockState
{
  static
  {
    llIIlIIllIlI();
    llIIlIIllIII();
    COMMA_JOINER = Joiner.on(llllllIllI[llllllIlll[0]]);
  }
  
  private List<Iterable<Comparable>> getAllowedValues()
  {
    ;
    ;
    ;
    List<Iterable<Comparable>> llllllllllllllllllIIIIllIIlllIlI = Lists.newArrayList();
    int llllllllllllllllllIIIIllIIlllIIl = llllllIlll[0];
    "".length();
    if ((78 + '' - 154 + 102 ^ '' + '' - 205 + 112) <= 0) {
      return null;
    }
    while (!llIIlIIlllII(llllllllllllllllllIIIIllIIlllIIl, properties.size())) {
      "".length();
    }
    return llllllllllllllllllIIIIllIIlllIlI;
  }
  
  public Collection<IProperty> getProperties()
  {
    ;
    return properties;
  }
  
  private static void llIIlIIllIII()
  {
    llllllIllI = new String[llllllIlll[3]];
    llllllIllI[llllllIlll[0]] = llIIlIIlIIll("WVE=", "uqLzH");
    llllllIllI[llllllIlll[1]] = llIIlIIlIIll("IR0XGhI=", "Cqxyy");
    llllllIllI[llllllIlll[2]] = llIIlIIlIllI("kib1AR2Mc0cEQLF1PQA25g==", "wkjlp");
  }
  
  public ImmutableList<IBlockState> getValidStates()
  {
    ;
    return validStates;
  }
  
  private static void llIIlIIllIlI()
  {
    llllllIlll = new int[5];
    llllllIlll[0] = ((0x37 ^ 0x2D) & (0x34 ^ 0x2E ^ 0xFFFFFFFF));
    llllllIlll[1] = " ".length();
    llllllIlll[2] = "  ".length();
    llllllIlll[3] = "   ".length();
    llllllIlll[4] = (0x48 ^ 0x1C ^ 0xD7 ^ 0x8B);
  }
  
  private static boolean llIIlIIlllIl(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllllIIIIlIllllllIl;
    return ??? < i;
  }
  
  public BlockState(Block llllllllllllllllllIIIIllIlIIlIIl, IProperty... llllllllllllllllllIIIIllIlIIlIII)
  {
    block = llllllllllllllllllIIIIllIlIlIIlI;
    Arrays.sort(llllllllllllllllllIIIIllIlIIlIII, new Comparator()
    {
      public int compare(IProperty lllllllIllllII, IProperty lllllllIlllIIl)
      {
        ;
        ;
        return lllllllIllllII.getName().compareTo(lllllllIlllIIl.getName());
      }
    });
    properties = ImmutableList.copyOf(llllllllllllllllllIIIIllIlIIlIII);
    Map<Map<IProperty, Comparable>, StateImplementation> llllllllllllllllllIIIIllIlIlIIII = Maps.newLinkedHashMap();
    List<StateImplementation> llllllllllllllllllIIIIllIlIIllll = Lists.newArrayList();
    int llllllllllllllllllIIIIllIlIIIlII = Cartesian.cartesianProduct(llllllllllllllllllIIIIllIlIIlIlI.getAllowedValues()).iterator();
    "".length();
    if (null != null) {
      throw null;
    }
    while (!llIIlIIllIll(llllllllllllllllllIIIIllIlIIIlII.hasNext()))
    {
      List<Comparable> llllllllllllllllllIIIIllIlIIlllI = (List)llllllllllllllllllIIIIllIlIIIlII.next();
      Map<IProperty, Comparable> llllllllllllllllllIIIIllIlIIllIl = MapPopulator.createMap(properties, llllllllllllllllllIIIIllIlIIlllI);
      StateImplementation llllllllllllllllllIIIIllIlIIllII = new StateImplementation(llllllllllllllllllIIIIllIlIlIIlI, ImmutableMap.copyOf(llllllllllllllllllIIIIllIlIIllIl), null);
      "".length();
      "".length();
    }
    llllllllllllllllllIIIIllIlIIIlII = llllllllllllllllllIIIIllIlIIllll.iterator();
    "".length();
    if (((0xAD ^ 0x8A) & (0x2 ^ 0x25 ^ 0xFFFFFFFF)) > 0) {
      throw null;
    }
    while (!llIIlIIllIll(llllllllllllllllllIIIIllIlIIIlII.hasNext()))
    {
      StateImplementation llllllllllllllllllIIIIllIlIIlIll = (StateImplementation)llllllllllllllllllIIIIllIlIIIlII.next();
      llllllllllllllllllIIIIllIlIIlIll.buildPropertyValueTable(llllllllllllllllllIIIIllIlIlIIII);
    }
    validStates = ImmutableList.copyOf(llllllllllllllllllIIIIllIlIIllll);
  }
  
  private static String llIIlIIlIIll(String llllllllllllllllllIIIIllIIIlllll, String llllllllllllllllllIIIIllIIIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllllIIIIllIIIlllll = new String(Base64.getDecoder().decode(llllllllllllllllllIIIIllIIIlllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllIIIIllIIIlllIl = new StringBuilder();
    char[] llllllllllllllllllIIIIllIIIlllII = llllllllllllllllllIIIIllIIIllIIl.toCharArray();
    int llllllllllllllllllIIIIllIIIllIll = llllllIlll[0];
    boolean llllllllllllllllllIIIIllIIIlIlIl = llllllllllllllllllIIIIllIIIlllll.toCharArray();
    boolean llllllllllllllllllIIIIllIIIlIlII = llllllllllllllllllIIIIllIIIlIlIl.length;
    int llllllllllllllllllIIIIllIIIlIIll = llllllIlll[0];
    while (llIIlIIlllIl(llllllllllllllllllIIIIllIIIlIIll, llllllllllllllllllIIIIllIIIlIlII))
    {
      char llllllllllllllllllIIIIllIIlIIIII = llllllllllllllllllIIIIllIIIlIlIl[llllllllllllllllllIIIIllIIIlIIll];
      "".length();
      "".length();
      if (((0x19 ^ 0x77 ^ 0x1F ^ 0x5B) & (0xDF ^ 0xB9 ^ 0x6D ^ 0x21 ^ -" ".length()) & (('¢' + 120 - 239 + 188 ^ 73 + '' - 56 + 2) & (83 + '' - 170 + 171 ^ 71 + 29 - 81 + 153 ^ -" ".length()) ^ -" ".length())) >= "   ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllllIIIIllIIIlllIl);
  }
  
  private static String llIIlIIlIllI(String llllllllllllllllllIIIIllIIIIlIII, String llllllllllllllllllIIIIllIIIIlIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIIIIllIIIIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIIIIllIIIIlIIl.getBytes(StandardCharsets.UTF_8)), llllllIlll[4]), "DES");
      Cipher llllllllllllllllllIIIIllIIIIllII = Cipher.getInstance("DES");
      llllllllllllllllllIIIIllIIIIllII.init(llllllIlll[2], llllllllllllllllllIIIIllIIIIllIl);
      return new String(llllllllllllllllllIIIIllIIIIllII.doFinal(Base64.getDecoder().decode(llllllllllllllllllIIIIllIIIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIIIIllIIIIlIll)
    {
      llllllllllllllllllIIIIllIIIIlIll.printStackTrace();
    }
    return null;
  }
  
  public String toString()
  {
    ;
    return Objects.toStringHelper(llllllllllllllllllIIIIllIIlIlIlI).add(llllllIllI[llllllIlll[1]], Block.blockRegistry.getNameForObject(block)).add(llllllIllI[llllllIlll[2]], Iterables.transform(properties, GET_NAME_FUNC)).toString();
  }
  
  public IBlockState getBaseState()
  {
    ;
    return (IBlockState)validStates.get(llllllIlll[0]);
  }
  
  private static boolean llIIlIIllIll(int ???)
  {
    short llllllllllllllllllIIIIlIlllllIll;
    return ??? == 0;
  }
  
  private static boolean llIIlIIlllII(int ???, int arg1)
  {
    int i;
    long llllllllllllllllllIIIIllIIIIIIIl;
    return ??? >= i;
  }
  
  public Block getBlock()
  {
    ;
    return block;
  }
  
  static class StateImplementation
    extends BlockStateBase
  {
    static
    {
      llllIlllIIlIl();
      llllIllIllIll();
    }
    
    public void buildPropertyValueTable(Map<Map<IProperty, Comparable>, StateImplementation> lllllllllllllllIlIlIIllllIlIlIII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      if (llllIlllIlIIl(propertyValueTable)) {
        throw new IllegalStateException();
      }
      Table<IProperty, Comparable, IBlockState> lllllllllllllllIlIlIIllllIlIllII = HashBasedTable.create();
      Exception lllllllllllllllIlIlIIllllIlIIlIl = properties.keySet().iterator();
      "".length();
      if (-" ".length() > "   ".length()) {
        return;
      }
      while (!llllIlllIIllI(lllllllllllllllIlIlIIllllIlIIlIl.hasNext()))
      {
        IProperty<? extends Comparable> lllllllllllllllIlIlIIllllIlIlIll = (IProperty)lllllllllllllllIlIlIIllllIlIIlIl.next();
        lllllllllllllllIlIlIIllllIlIIIll = lllllllllllllllIlIlIIllllIlIlIll.getAllowedValues().iterator();
        "".length();
        if ("   ".length() != "   ".length()) {
          return;
        }
        while (!llllIlllIIllI(lllllllllllllllIlIlIIllllIlIIIll.hasNext()))
        {
          Comparable lllllllllllllllIlIlIIllllIlIlIlI = (Comparable)lllllllllllllllIlIlIIllllIlIIIll.next();
          if (llllIlllIlIll(lllllllllllllllIlIlIIllllIlIlIlI, properties.get(lllllllllllllllIlIlIIllllIlIlIll))) {
            "".length();
          }
        }
      }
      propertyValueTable = ImmutableTable.copyOf(lllllllllllllllIlIlIIllllIlIllII);
    }
    
    public Collection<IProperty> getPropertyNames()
    {
      ;
      return Collections.unmodifiableCollection(properties.keySet());
    }
    
    private static boolean llllIlllIlIll(Object ???, Object arg1)
    {
      Object localObject;
      String lllllllllllllllIlIlIIlllIlIlIlll;
      return ??? != localObject;
    }
    
    private static void llllIlllIIlIl()
    {
      lIlIIIIIlIIl = new int[9];
      lIlIIIIIlIIl[0] = ((0x60 ^ 0x4F) & (0xAB ^ 0x84 ^ 0xFFFFFFFF));
      lIlIIIIIlIIl[1] = " ".length();
      lIlIIIIIlIIl[2] = "  ".length();
      lIlIIIIIlIIl[3] = "   ".length();
      lIlIIIIIlIIl[4] = (66 + 125 - 64 + 4 ^ 87 + 108 - 142 + 82);
      lIlIIIIIlIIl[5] = (0x2B ^ 0x2E);
      lIlIIIIIlIIl[6] = (0x13 ^ 0xF ^ 0x2D ^ 0x37);
      lIlIIIIIlIIl[7] = (0x99 ^ 0x9E);
      lIlIIIIIlIIl[8] = (0x46 ^ 0x4E);
    }
    
    private static boolean llllIlllIllII(int ???, int arg1)
    {
      int i;
      short lllllllllllllllIlIlIIlllIlIllIll;
      return ??? < i;
    }
    
    public <T extends Comparable<T>, V extends T> IBlockState withProperty(IProperty<T> lllllllllllllllIlIlIIlllllIIIllI, V lllllllllllllllIlIlIIlllllIIlIII)
    {
      ;
      ;
      ;
      if (llllIlllIIllI(properties.containsKey(lllllllllllllllIlIlIIlllllIIlIIl))) {
        throw new IllegalArgumentException(String.valueOf(new StringBuilder(lIlIIIIIIlIl[lIlIIIIIlIIl[2]]).append(lllllllllllllllIlIlIIlllllIIlIIl).append(lIlIIIIIIlIl[lIlIIIIIlIIl[3]]).append(block.getBlockState())));
      }
      if (llllIlllIIllI(lllllllllllllllIlIlIIlllllIIlIIl.getAllowedValues().contains(lllllllllllllllIlIlIIlllllIIlIII))) {
        throw new IllegalArgumentException(String.valueOf(new StringBuilder(lIlIIIIIIlIl[lIlIIIIIlIIl[4]]).append(lllllllllllllllIlIlIIlllllIIlIIl).append(lIlIIIIIIlIl[lIlIIIIIlIIl[5]]).append(lllllllllllllllIlIlIIlllllIIlIII).append(lIlIIIIIIlIl[lIlIIIIIlIIl[6]]).append(Block.blockRegistry.getNameForObject(block)).append(lIlIIIIIIlIl[lIlIIIIIlIIl[7]])));
      }
      if (llllIlllIlIII(properties.get(lllllllllllllllIlIlIIlllllIIlIIl), lllllllllllllllIlIlIIlllllIIlIII))
      {
        "".length();
        if ((0xDB ^ 0xBD ^ 0x2D ^ 0x4E) > 0) {
          break label223;
        }
        return null;
      }
      label223:
      return (IBlockState)propertyValueTable.get(lllllllllllllllIlIlIIlllllIIlIIl, lllllllllllllllIlIlIIlllllIIlIII);
    }
    
    private static boolean llllIlllIIllI(int ???)
    {
      float lllllllllllllllIlIlIIlllIlIIllll;
      return ??? == 0;
    }
    
    private static String llllIllIllIlI(String lllllllllllllllIlIlIIlllIllIIlII, String lllllllllllllllIlIlIIlllIllIIIIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIlIlIIlllIllIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIIlllIllIIIIl.getBytes(StandardCharsets.UTF_8)), lIlIIIIIlIIl[8]), "DES");
        Cipher lllllllllllllllIlIlIIlllIllIIllI = Cipher.getInstance("DES");
        lllllllllllllllIlIlIIlllIllIIllI.init(lIlIIIIIlIIl[2], lllllllllllllllIlIlIIlllIllIIlll);
        return new String(lllllllllllllllIlIlIIlllIllIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIIlllIllIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIlIlIIlllIllIIlIl)
      {
        lllllllllllllllIlIlIIlllIllIIlIl.printStackTrace();
      }
      return null;
    }
    
    private StateImplementation(Block lllllllllllllllIlIlIIlllllIllIII, ImmutableMap<IProperty, Comparable> lllllllllllllllIlIlIIlllllIlIlll)
    {
      block = lllllllllllllllIlIlIIlllllIllIll;
      properties = lllllllllllllllIlIlIIlllllIlIlll;
    }
    
    public ImmutableMap<IProperty, Comparable> getProperties()
    {
      ;
      return properties;
    }
    
    private static boolean llllIlllIlIII(Object ???, Object arg1)
    {
      Object localObject;
      Exception lllllllllllllllIlIlIIlllIlIlIIll;
      return ??? == localObject;
    }
    
    public <T extends Comparable<T>> T getValue(IProperty<T> lllllllllllllllIlIlIIlllllIIlllI)
    {
      ;
      ;
      if (llllIlllIIllI(properties.containsKey(lllllllllllllllIlIlIIlllllIIlllI))) {
        throw new IllegalArgumentException(String.valueOf(new StringBuilder(lIlIIIIIIlIl[lIlIIIIIlIIl[0]]).append(lllllllllllllllIlIlIIlllllIIlllI).append(lIlIIIIIIlIl[lIlIIIIIlIIl[1]]).append(block.getBlockState())));
      }
      return (Comparable)lllllllllllllllIlIlIIlllllIIlllI.getValueClass().cast(properties.get(lllllllllllllllIlIlIIlllllIIlllI));
    }
    
    private Map<IProperty, Comparable> getPropertiesWithValue(IProperty lllllllllllllllIlIlIIllllIIllIIl, Comparable lllllllllllllllIlIlIIllllIIlllII)
    {
      ;
      ;
      ;
      ;
      Map<IProperty, Comparable> lllllllllllllllIlIlIIllllIIllIll = Maps.newHashMap(properties);
      "".length();
      return lllllllllllllllIlIlIIllllIIllIll;
    }
    
    public Block getBlock()
    {
      ;
      return block;
    }
    
    public boolean equals(Object lllllllllllllllIlIlIIllllIlllIll)
    {
      ;
      ;
      if (llllIlllIlIII(lllllllllllllllIlIlIIllllIllllII, lllllllllllllllIlIlIIllllIlllIll)) {
        return lIlIIIIIlIIl[1];
      }
      return lIlIIIIIlIIl[0];
    }
    
    private static String llllIllIllIII(String lllllllllllllllIlIlIIlllIlllIIIl, String lllllllllllllllIlIlIIlllIllIlllI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIlIlIIlllIlllIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIIlllIllIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIlIlIIlllIlllIIll = Cipher.getInstance("Blowfish");
        lllllllllllllllIlIlIIlllIlllIIll.init(lIlIIIIIlIIl[2], lllllllllllllllIlIlIIlllIlllIlII);
        return new String(lllllllllllllllIlIlIIlllIlllIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIIlllIlllIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIlIlIIlllIlllIIlI)
      {
        lllllllllllllllIlIlIIlllIlllIIlI.printStackTrace();
      }
      return null;
    }
    
    public int hashCode()
    {
      ;
      return properties.hashCode();
    }
    
    private static String llllIllIllIIl(String lllllllllllllllIlIlIIllllIIIIIIl, String lllllllllllllllIlIlIIllllIIIIIII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIlIlIIllllIIIIIIl = new String(Base64.getDecoder().decode(lllllllllllllllIlIlIIllllIIIIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIlIlIIllllIIIIlII = new StringBuilder();
      char[] lllllllllllllllIlIlIIllllIIIIIll = lllllllllllllllIlIlIIllllIIIIIII.toCharArray();
      int lllllllllllllllIlIlIIllllIIIIIlI = lIlIIIIIlIIl[0];
      int lllllllllllllllIlIlIIlllIlllllII = lllllllllllllllIlIlIIllllIIIIIIl.toCharArray();
      long lllllllllllllllIlIlIIlllIllllIll = lllllllllllllllIlIlIIlllIlllllII.length;
      boolean lllllllllllllllIlIlIIlllIllllIlI = lIlIIIIIlIIl[0];
      while (llllIlllIllII(lllllllllllllllIlIlIIlllIllllIlI, lllllllllllllllIlIlIIlllIllllIll))
      {
        char lllllllllllllllIlIlIIllllIIIIlll = lllllllllllllllIlIlIIlllIlllllII[lllllllllllllllIlIlIIlllIllllIlI];
        "".length();
        "".length();
        if (((0x28 ^ 0x42 ^ 0xDF ^ 0xA6) & (105 + 120 - 95 + 26 ^ 72 + 103 - 53 + 21 ^ -" ".length())) != ((24 + '' - 3 + 64 ^ 125 + 85 - 138 + 59) & (0xCA ^ 0xBE ^ 0x2 ^ 0x16 ^ -" ".length()))) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIlIlIIllllIIIIlII);
    }
    
    private static boolean llllIlllIlIIl(Object ???)
    {
      String lllllllllllllllIlIlIIlllIlIlIIIl;
      return ??? != null;
    }
    
    private static void llllIllIllIll()
    {
      lIlIIIIIIlIl = new String[lIlIIIIIlIIl[8]];
      lIlIIIIIIlIl[lIlIIIIIlIIl[0]] = llllIllIllIII("b/J7E8SqL9gIlodlaHVgX6PSFKWifaff", "wyoEr");
      lIlIIIIIIlIl[lIlIIIIIlIIl[1]] = llllIllIllIII("UyvmnplaKn1NxiNHnR2rOfuQHiSJsUaf25ZsZmvQWOY=", "XFWNm");
      lIlIIIIIIlIl[lIlIIIIIlIIl[2]] = llllIllIllIIl("BCgNAgIzaRAJGWc5EQMdIjsXFU0=", "GIclm");
      lIlIIIIIIlIl[lIlIIIIIlIIl[3]] = llllIllIllIIl("WA4DZysMTxQoJwtPHig2WAoILjEMTxkpYg==", "xopGB");
      lIlIIIIIIlIl[lIlIIIIIlIIl[4]] = llllIllIllIII("/gb3GkrN2Gg4HTpn029dy1Cc/Uql89rl", "NnEtp");
      lIlIIIIIIlIl[lIlIIIIIlIIl[5]] = llllIllIllIlI("ns0lxl0wEOc=", "XYfTs");
      lIlIIIIIIlIl[lIlIIIIIlIIl[6]] = llllIllIllIIl("QQs2RRsNCzsOWQ==", "adXey");
      lIlIIIIIIlIl[lIlIIIIIlIIl[7]] = llllIllIllIlI("h/3i2l6dmiQa8IynK2PjCMSJDXlHGcHpOmUkDPg9hAE=", "OJPsI");
    }
  }
}

package net.minecraft.block.state;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.ImmutableMap;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map.Entry;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.util.RegistryNamespacedDefaultedByKey;
import net.minecraft.util.ResourceLocation;

public abstract class BlockStateBase
  implements IBlockState
{
  public int getBlockId()
  {
    ;
    if (lIllllIllIIlI(blockId)) {
      blockId = Block.getIdFromBlock(llllllllllllllllIIIllIllIIlllIlI.getBlock());
    }
    return blockId;
  }
  
  public ResourceLocation getBlockLocation()
  {
    ;
    if (lIllllIllIIll(blockLocation)) {
      blockLocation = ((ResourceLocation)Block.blockRegistry.getNameForObject(llllllllllllllllIIIllIllIIllIIIl.getBlock()));
    }
    return blockLocation;
  }
  
  private static boolean lIllllIllIIll(Object ???)
  {
    float llllllllllllllllIIIllIlIllllllIl;
    return ??? == null;
  }
  
  private static String lIllllIlIllll(String llllllllllllllllIIIllIllIIIIlIll, String llllllllllllllllIIIllIllIIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIIllIllIIIIlIll = new String(Base64.getDecoder().decode(llllllllllllllllIIIllIllIIIIlIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIIIllIllIIIIlllI = new StringBuilder();
    char[] llllllllllllllllIIIllIllIIIIllIl = llllllllllllllllIIIllIllIIIIllll.toCharArray();
    int llllllllllllllllIIIllIllIIIIllII = llllIllIIlI[0];
    boolean llllllllllllllllIIIllIllIIIIIllI = llllllllllllllllIIIllIllIIIIlIll.toCharArray();
    long llllllllllllllllIIIllIllIIIIIlIl = llllllllllllllllIIIllIllIIIIIllI.length;
    byte llllllllllllllllIIIllIllIIIIIlII = llllIllIIlI[0];
    while (lIllllIllIllI(llllllllllllllllIIIllIllIIIIIlII, llllllllllllllllIIIllIllIIIIIlIl))
    {
      char llllllllllllllllIIIllIllIIIlIIIl = llllllllllllllllIIIllIllIIIIIllI[llllllllllllllllIIIllIllIIIIIlII];
      "".length();
      "".length();
      if ("  ".length() <= ((0x4C ^ 0xE ^ 0x3 ^ 0x1B) & (0xC0 ^ 0xA2 ^ 0x79 ^ 0x41 ^ -" ".length()))) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIIIllIllIIIIlllI);
  }
  
  private static void lIllllIllIIII()
  {
    llllIllIIIl = new String[llllIllIIlI[5]];
    llllIllIIIl[llllIllIIlI[0]] = lIllllIlIllll("FSM6REVmX1dERmQ=", "Voetu");
    llllIllIIIl[llllIllIIlI[3]] = lIllllIlIllll("FQ==", "NsfZj");
    llllIllIIIl[llllIllIIlI[4]] = lIllllIlIllll("Cg==", "WkPXU");
  }
  
  public String toString()
  {
    ;
    ;
    StringBuilder llllllllllllllllIIIllIllIIIlllIl = new StringBuilder();
    "".length();
    if (lIllllIllIlIl(llllllllllllllllIIIllIllIIIllllI.getProperties().isEmpty()))
    {
      "".length();
      "".length();
      "".length();
    }
    return String.valueOf(llllllllllllllllIIIllIllIIIlllIl);
  }
  
  private static boolean lIllllIllIlII(int ???)
  {
    int llllllllllllllllIIIllIlIlllllIll;
    return ??? != 0;
  }
  
  protected static Object cyclePropertyValue(Collection llllllllllllllllIIIllIllIIlIIllI, Object llllllllllllllllIIIllIllIIlIIIlI)
  {
    ;
    ;
    ;
    Iterator llllllllllllllllIIIllIllIIlIIlII = llllllllllllllllIIIllIllIIlIIllI.iterator();
    "".length();
    if (((0xFD ^ 0xB3) & (0x7E ^ 0x30 ^ 0xFFFFFFFF)) < 0) {
      return null;
    }
    while (!lIllllIllIlIl(llllllllllllllllIIIllIllIIlIIlII.hasNext())) {
      if (lIllllIllIlII(llllllllllllllllIIIllIllIIlIIlII.next().equals(llllllllllllllllIIIllIllIIlIIIlI)))
      {
        if (lIllllIllIlII(llllllllllllllllIIIllIllIIlIIlII.hasNext())) {
          return llllllllllllllllIIIllIllIIlIIlII.next();
        }
        return llllllllllllllllIIIllIllIIlIIllI.iterator().next();
      }
    }
    return llllllllllllllllIIIllIllIIlIIlII.next();
  }
  
  private static boolean lIllllIllIlIl(int ???)
  {
    int llllllllllllllllIIIllIlIlllllIIl;
    return ??? == 0;
  }
  
  private static boolean lIllllIllIIlI(int ???)
  {
    char llllllllllllllllIIIllIlIllllIlll;
    return ??? < 0;
  }
  
  public IBlockState cycleProperty(IProperty llllllllllllllllIIIllIllIIlIllII)
  {
    ;
    ;
    return llllllllllllllllIIIllIllIIlIlIll.withProperty(llllllllllllllllIIIllIllIIlIllII, (Comparable)cyclePropertyValue(llllllllllllllllIIIllIllIIlIllII.getAllowedValues(), llllllllllllllllIIIllIllIIlIlIll.getValue(llllllllllllllllIIIllIllIIlIllII)));
  }
  
  private static boolean lIllllIllIllI(int ???, int arg1)
  {
    int i;
    String llllllllllllllllIIIllIlIllllllll;
    return ??? < i;
  }
  
  private static void lIllllIllIIIl()
  {
    llllIllIIlI = new int[6];
    llllIllIIlI[0] = ((0xE3 ^ 0xA3 ^ 0xC8 ^ 0xA6) & (123 + 117 - 129 + 49 ^ 96 + '' - 227 + 137 ^ -" ".length()));
    llllIllIIlI[1] = (0x8A ^ 0xBF ^ 0x55 ^ 0x4C);
    llllIllIIlI[2] = (-" ".length());
    llllIllIIlI[3] = " ".length();
    llllIllIIlI[4] = "  ".length();
    llllIllIIlI[5] = "   ".length();
  }
  
  public int getMetadata()
  {
    ;
    if (lIllllIllIIlI(metadata)) {
      metadata = llllllllllllllllIIIllIllIIllIIll.getBlock().getMetaFromState(llllllllllllllllIIIllIllIIllIIll);
    }
    return metadata;
  }
  
  public BlockStateBase() {}
  
  public int getBlockStateId()
  {
    ;
    if (lIllllIllIIlI(blockStateId)) {
      blockStateId = Block.getStateId(llllllllllllllllIIIllIllIIllIlll);
    }
    return blockStateId;
  }
  
  static
  {
    lIllllIllIIIl();
    lIllllIllIIII();
    __OBFID = llllIllIIIl[llllIllIIlI[0]];
    COMMA_JOINER = Joiner.on(llllIllIIlI[1]);
  }
}

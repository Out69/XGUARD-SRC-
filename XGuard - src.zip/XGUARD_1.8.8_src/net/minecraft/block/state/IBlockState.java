package net.minecraft.block.state;

import com.google.common.collect.ImmutableMap;
import java.util.Collection;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;

public abstract interface IBlockState
{
  public abstract ImmutableMap<IProperty, Comparable> getProperties();
  
  public abstract <T extends Comparable<T>> IBlockState cycleProperty(IProperty<T> paramIProperty);
  
  public abstract Collection<IProperty> getPropertyNames();
  
  public abstract <T extends Comparable<T>> T getValue(IProperty<T> paramIProperty);
  
  public abstract Block getBlock();
  
  public abstract <T extends Comparable<T>, V extends T> IBlockState withProperty(IProperty<T> paramIProperty, V paramV);
}

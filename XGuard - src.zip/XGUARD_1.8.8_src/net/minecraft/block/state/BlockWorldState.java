package net.minecraft.block.state;

import com.google.common.base.Predicate;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockWorldState
{
  private static boolean lllIIIllIlll(int ???)
  {
    long lllllllllllllllllIlIIlllllIllIll;
    return ??? != 0;
  }
  
  public IBlockState getBlockState()
  {
    ;
    if ((lllIIIllIlIl(state)) && ((!lllIIIllIllI(field_181628_c)) || (lllIIIllIlll(world.isBlockLoaded(pos))))) {
      state = world.getBlockState(pos);
    }
    return state;
  }
  
  private static void lllIIIllIlII()
  {
    lIIIllllIIl = new int[1];
    lIIIllllIIl[0] = " ".length();
  }
  
  public static Predicate<BlockWorldState> hasState(Predicate<IBlockState> lllllllllllllllllIlIIlllllIlllll)
  {
    ;
    new Predicate()
    {
      private static boolean lllIIIllIIIIl(Object ???)
      {
        String lllllllllllllllIllIIllllIlIllIIl;
        return ??? != null;
      }
      
      public boolean apply(BlockWorldState lllllllllllllllIllIIllllIlIlllll)
      {
        ;
        ;
        if ((lllIIIllIIIIl(lllllllllllllllIllIIllllIlIlllll)) && (lllIIIllIIIlI(BlockWorldState.this.apply(lllllllllllllllIllIIllllIlIlllll.getBlockState())))) {
          return lIIlIIllIIII[0];
        }
        return lIIlIIllIIII[1];
      }
      
      private static boolean lllIIIllIIIlI(int ???)
      {
        boolean lllllllllllllllIllIIllllIlIlIlll;
        return ??? != 0;
      }
      
      private static void lllIIIllIIIII()
      {
        lIIlIIllIIII = new int[2];
        lIIlIIllIIII[0] = " ".length();
        lIIlIIllIIII[1] = ((0xC ^ 0x2E) & (0x48 ^ 0x6A ^ 0xFFFFFFFF));
      }
      
      static {}
    };
  }
  
  private static boolean lllIIIllIllI(int ???)
  {
    int lllllllllllllllllIlIIlllllIllIIl;
    return ??? == 0;
  }
  
  public TileEntity getTileEntity()
  {
    ;
    if ((lllIIIllIlIl(tileEntity)) && (lllIIIllIllI(tileEntityInitialized)))
    {
      tileEntity = world.getTileEntity(pos);
      tileEntityInitialized = lIIIllllIIl[0];
    }
    return tileEntity;
  }
  
  public BlockPos getPos()
  {
    ;
    return pos;
  }
  
  static {}
  
  public BlockWorldState(World lllllllllllllllllIlIIllllllIllIl, BlockPos lllllllllllllllllIlIIllllllIllII, boolean lllllllllllllllllIlIIllllllIllll)
  {
    world = lllllllllllllllllIlIIllllllIllIl;
    pos = lllllllllllllllllIlIIllllllIllII;
    field_181628_c = lllllllllllllllllIlIIllllllIllll;
  }
  
  private static boolean lllIIIllIlIl(Object ???)
  {
    Exception lllllllllllllllllIlIIlllllIlllIl;
    return ??? == null;
  }
}

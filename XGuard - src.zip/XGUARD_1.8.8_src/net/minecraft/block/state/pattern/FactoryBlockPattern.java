package net.minecraft.block.state.pattern;

import com.google.common.base.Joiner;
import com.google.common.base.Predicate;
import com.google.common.collect.Lists;
import java.lang.reflect.Array;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.state.BlockWorldState;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

public class FactoryBlockPattern
{
  private static boolean llIIllIlllIlII(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIlIlIlIIlIIIIllllI;
    return ??? >= i;
  }
  
  public BlockPattern build()
  {
    ;
    return new BlockPattern(llllllllllllllIlIlIlIIlIIllllIlI.makePredicateArray());
  }
  
  static
  {
    llIIllIlllIIII();
    llIIllIllIlllI();
  }
  
  private FactoryBlockPattern()
  {
    "".length();
  }
  
  private static void llIIllIlllIIII()
  {
    lIIIIllIIlllI = new int[12];
    lIIIIllIIlllI[0] = ((0x25 ^ 0x0 ^ 0x40 ^ 0x5E) & (19 + 89 - 8 + 47 ^ 91 + '' - 227 + 158 ^ -" ".length()));
    lIIIIllIIlllI[1] = (0x71 ^ 0x62 ^ 0x9A ^ 0xA9);
    lIIIIllIIlllI[2] = " ".length();
    lIIIIllIIlllI[3] = "  ".length();
    lIIIIllIIlllI[4] = "   ".length();
    lIIIIllIIlllI[5] = (56 + '' - 103 + 71 ^ 117 + 62 - 124 + 99);
    lIIIIllIIlllI[6] = (0x70 ^ 0x75);
    lIIIIllIIlllI[7] = (33 + 119 - 41 + 40 ^ 64 + 104 - 132 + 109);
    lIIIIllIIlllI[8] = (0x1E ^ 0x19);
    lIIIIllIIlllI[9] = (0x35 ^ 0x3D);
    lIIIIllIIlllI[10] = (0x23 ^ 0x2A);
    lIIIIllIIlllI[11] = (0x76 ^ 0x7C);
  }
  
  private static boolean llIIllIlllIlIl(Object ???)
  {
    byte llllllllllllllIlIlIlIIlIIIIllIII;
    return ??? == null;
  }
  
  private static String llIIllIlIllIIl(String llllllllllllllIlIlIlIIlIIIllIlll, String llllllllllllllIlIlIlIIlIIIllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIlIlIIlIIIllIlll = new String(Base64.getDecoder().decode(llllllllllllllIlIlIlIIlIIIllIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIlIlIIlIIIlllIlI = new StringBuilder();
    char[] llllllllllllllIlIlIlIIlIIIlllIIl = llllllllllllllIlIlIlIIlIIIllIllI.toCharArray();
    int llllllllllllllIlIlIlIIlIIIlllIII = lIIIIllIIlllI[0];
    byte llllllllllllllIlIlIlIIlIIIllIIlI = llllllllllllllIlIlIlIIlIIIllIlll.toCharArray();
    int llllllllllllllIlIlIlIIlIIIllIIIl = llllllllllllllIlIlIlIIlIIIllIIlI.length;
    float llllllllllllllIlIlIlIIlIIIllIIII = lIIIIllIIlllI[0];
    while (llIIllIlllIllI(llllllllllllllIlIlIlIIlIIIllIIII, llllllllllllllIlIlIlIIlIIIllIIIl))
    {
      char llllllllllllllIlIlIlIIlIIIllllIl = llllllllllllllIlIlIlIIlIIIllIIlI[llllllllllllllIlIlIlIIlIIIllIIII];
      "".length();
      "".length();
      if (-"  ".length() >= 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIlIlIIlIIIlllIlI);
  }
  
  public static FactoryBlockPattern start()
  {
    return new FactoryBlockPattern();
  }
  
  private static String llIIllIllIllIl(String llllllllllllllIlIlIlIIlIIIlIIlll, String llllllllllllllIlIlIlIIlIIIlIIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIlIlIIlIIIlIlIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIlIIlIIIlIIlII.getBytes(StandardCharsets.UTF_8)), lIIIIllIIlllI[9]), "DES");
      Cipher llllllllllllllIlIlIlIIlIIIlIlIIl = Cipher.getInstance("DES");
      llllllllllllllIlIlIlIIlIIIlIlIIl.init(lIIIIllIIlllI[3], llllllllllllllIlIlIlIIlIIIlIlIlI);
      return new String(llllllllllllllIlIlIlIIlIIIlIlIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIlIIlIIIlIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIlIlIIlIIIlIlIII)
    {
      llllllllllllllIlIlIlIIlIIIlIlIII.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIIllIlllIllI(int ???, int arg1)
  {
    int i;
    char llllllllllllllIlIlIlIIlIIIIllIlI;
    return ??? < i;
  }
  
  private static boolean llIIllIlllIIIl(int ???)
  {
    String llllllllllllllIlIlIlIIlIIIIlIlII;
    return ??? == 0;
  }
  
  public FactoryBlockPattern where(char llllllllllllllIlIlIlIIlIlIIIIIII, Predicate<BlockWorldState> llllllllllllllIlIlIlIIlIIlllllII)
  {
    ;
    ;
    ;
    "".length();
    return llllllllllllllIlIlIlIIlIlIIIIIIl;
  }
  
  private static void llIIllIllIlllI()
  {
    lIIIIllIIllII = new String[lIIIIllIIlllI[11]];
    lIIIIllIIllII[lIIIIllIIlllI[0]] = llIIllIlIllIIl("TQ==", "awCSu");
    lIIIIllIIllII[lIIIIllIIlllI[2]] = llIIllIlIllIlI("VMJWFh4PEL99FiPTUVrvIkHX8IJ1fvY0CIs42VQgnoc=", "ZzcdN");
    lIIIIllIIllII[lIIIIllIIlllI[3]] = llIIllIlIllIIl("f2YoFyRzMSsRcDQvPAc+cykkB3AkLz4KcDJmIgc5NC4+Qj81Zg==", "SFJbP");
    lIIIIllIIllII[lIIIIllIIlllI[4]] = llIIllIlIllIlI("4KzsibB0z1U=", "hAhfj");
    lIIIIllIIllII[lIIIIllIIlllI[5]] = llIIllIlIllIIl("JT8MRyYHPFgVKBwjWA4pSyQQAmcMOQ4CKUsxERQrDnAZFSJLJBACZwg/ChUiCCRYEC4PJBBHbw4oCAIkHzUcRw==", "kPxgG");
    lIIIIllIIllII[lIIIIllIIlllI[6]] = llIIllIlIllIlI("kTiontdIl95E/N7T0FPtMOcpzWPZCpEd", "WmGop");
    lIIIIllIIllII[lIIIIllIIlllI[7]] = llIIllIlIllIlI("wcGG1Ow0VJA=", "iAeqA");
    lIIIIllIIllII[lIIIIllIIlllI[8]] = llIIllIlIllIIl("LywkIwxKMTUjAQ8zOncTBTN0NhwZLTE=", "jATWu");
    lIIIIllIIllII[lIIIIllIIlllI[9]] = llIIllIllIllIl("XdcJetJi8NUdx8cSU5K5eQX42rfAxgx3vQIDZhxs1Y0=", "jNPLl");
    lIIIIllIIllII[lIIIIllIIlllI[10]] = llIIllIlIllIlI("thpc0Z55Aub+sPZceXseAg==", "TyNHE");
  }
  
  private static boolean llIIllIlllIIlI(int ???)
  {
    String llllllllllllllIlIlIlIIlIIIIlIllI;
    return ??? != 0;
  }
  
  private Predicate<BlockWorldState>[][][] makePredicateArray()
  {
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIlIlIIlIIllIIlIl.checkMissingPredicates();
    Predicate[][][] llllllllllllllIlIlIlIIlIIllIllIl = (Predicate[][][])Array.newInstance(Predicate.class, new int[] { depth.size(), aisleHeight, rowWidth });
    int llllllllllllllIlIlIlIIlIIllIllII = lIIIIllIIlllI[0];
    "".length();
    if ("  ".length() != "  ".length()) {
      return null;
    }
    while (!llIIllIlllIlII(llllllllllllllIlIlIlIIlIIllIllII, depth.size()))
    {
      int llllllllllllllIlIlIlIIlIIllIlIll = lIIIIllIIlllI[0];
      "".length();
      if ((0x62 ^ 0x66) == 0) {
        return null;
      }
      while (!llIIllIlllIlII(llllllllllllllIlIlIlIIlIIllIlIll, aisleHeight))
      {
        int llllllllllllllIlIlIlIIlIIllIlIlI = lIIIIllIIlllI[0];
        "".length();
        if (((0x4C ^ 0x4) & (0xFF ^ 0xB7 ^ 0xFFFFFFFF)) > 0) {
          return null;
        }
        while (!llIIllIlllIlII(llllllllllllllIlIlIlIIlIIllIlIlI, rowWidth))
        {
          llllllllllllllIlIlIlIIlIIllIllIl[llllllllllllllIlIlIlIIlIIllIllII][llllllllllllllIlIlIlIIlIIllIlIll][llllllllllllllIlIlIlIIlIIllIlIlI] = ((Predicate)symbolMap.get(Character.valueOf(((String[])depth.get(llllllllllllllIlIlIlIIlIIllIllII))[llllllllllllllIlIlIlIIlIIllIlIll].charAt(llllllllllllllIlIlIlIIlIIllIlIlI))));
          llllllllllllllIlIlIlIIlIIllIlIlI++;
        }
        llllllllllllllIlIlIlIIlIIllIlIll++;
      }
      llllllllllllllIlIlIlIIlIIllIllII++;
    }
    return llllllllllllllIlIlIlIIlIIllIllIl;
  }
  
  private void checkMissingPredicates()
  {
    ;
    ;
    ;
    List<Character> llllllllllllllIlIlIlIIlIIlIllIIl = Lists.newArrayList();
    int llllllllllllllIlIlIlIIlIIlIlIlII = symbolMap.entrySet().iterator();
    "".length();
    if (null != null) {
      return;
    }
    while (!llIIllIlllIIIl(llllllllllllllIlIlIlIIlIIlIlIlII.hasNext()))
    {
      Map.Entry<Character, Predicate<BlockWorldState>> llllllllllllllIlIlIlIIlIIlIllIII = (Map.Entry)llllllllllllllIlIlIlIIlIIlIlIlII.next();
      if (llIIllIlllIlIl(llllllllllllllIlIlIlIIlIIlIllIII.getValue())) {
        "".length();
      }
    }
    if (llIIllIlllIIIl(llllllllllllllIlIlIlIIlIIlIllIIl.isEmpty())) {
      throw new IllegalStateException(String.valueOf(new StringBuilder(lIIIIllIIllII[lIIIIllIIlllI[9]]).append(COMMA_JOIN.join(llllllllllllllIlIlIlIIlIIlIllIIl)).append(lIIIIllIIllII[lIIIIllIIlllI[10]])));
    }
  }
  
  private static boolean llIIllIlllIIll(int ???, int arg1)
  {
    int i;
    int llllllllllllllIlIlIlIIlIIIIlIIII;
    return ??? != i;
  }
  
  public FactoryBlockPattern aisle(String... llllllllllllllIlIlIlIIlIlIIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((llIIllIlllIIIl(ArrayUtils.isEmpty(llllllllllllllIlIlIlIIlIlIIlIIIl))) && (llIIllIlllIIIl(StringUtils.isEmpty(llllllllllllllIlIlIlIIlIlIIlIIIl[lIIIIllIIlllI[0]]))))
    {
      if (llIIllIlllIIlI(depth.isEmpty()))
      {
        aisleHeight = llllllllllllllIlIlIlIIlIlIIlIIIl.length;
        rowWidth = llllllllllllllIlIlIlIIlIlIIlIIIl[lIIIIllIIlllI[0]].length();
      }
      if (llIIllIlllIIll(llllllllllllllIlIlIlIIlIlIIlIIIl.length, aisleHeight)) {
        throw new IllegalArgumentException(String.valueOf(new StringBuilder(lIIIIllIIllII[lIIIIllIIlllI[2]]).append(aisleHeight).append(lIIIIllIIllII[lIIIIllIIlllI[3]]).append(llllllllllllllIlIlIlIIlIlIIlIIIl.length).append(lIIIIllIIllII[lIIIIllIIlllI[4]])));
      }
      llllllllllllllIlIlIlIIlIlIIIlIlI = (llllllllllllllIlIlIlIIlIlIIIlIIl = llllllllllllllIlIlIlIIlIlIIlIIIl).length;
      llllllllllllllIlIlIlIIlIlIIIlIll = lIIIIllIIlllI[0];
      "".length();
      if (((0x28 ^ 0x6 ^ 0xB2 ^ 0x81) & (91 + '' - 150 + 68 ^ 49 + 29 - 30 + 103 ^ -" ".length())) > (0xFF ^ 0x88 ^ 0x31 ^ 0x42)) {
        return null;
      }
      while (!llIIllIlllIlII(llllllllllllllIlIlIlIIlIlIIIlIll, llllllllllllllIlIlIlIIlIlIIIlIlI))
      {
        String llllllllllllllIlIlIlIIlIlIIlIIII = llllllllllllllIlIlIlIIlIlIIIlIIl[llllllllllllllIlIlIlIIlIlIIIlIll];
        if (llIIllIlllIIll(llllllllllllllIlIlIlIIlIlIIlIIII.length(), rowWidth)) {
          throw new IllegalArgumentException(String.valueOf(new StringBuilder(lIIIIllIIllII[lIIIIllIIlllI[5]]).append(rowWidth).append(lIIIIllIIllII[lIIIIllIIlllI[6]]).append(llllllllllllllIlIlIlIIlIlIIlIIII.length()).append(lIIIIllIIllII[lIIIIllIIlllI[7]])));
        }
        llllllllllllllIlIlIlIIlIlIIIIllI = (llllllllllllllIlIlIlIIlIlIIIIlIl = llllllllllllllIlIlIlIIlIlIIlIIII.toCharArray()).length;
        llllllllllllllIlIlIlIIlIlIIIIlll = lIIIIllIIlllI[0];
        "".length();
        if ("   ".length() != "   ".length()) {
          return null;
        }
        while (!llIIllIlllIlII(llllllllllllllIlIlIlIIlIlIIIIlll, llllllllllllllIlIlIlIIlIlIIIIllI))
        {
          char llllllllllllllIlIlIlIIlIlIIIllll = llllllllllllllIlIlIlIIlIlIIIIlIl[llllllllllllllIlIlIlIIlIlIIIIlll];
          if (llIIllIlllIIIl(symbolMap.containsKey(Character.valueOf(llllllllllllllIlIlIlIIlIlIIIllll)))) {
            "".length();
          }
          llllllllllllllIlIlIlIIlIlIIIIlll++;
        }
      }
      "".length();
      return llllllllllllllIlIlIlIIlIlIIIlllI;
    }
    throw new IllegalArgumentException(lIIIIllIIllII[lIIIIllIIlllI[8]]);
  }
  
  private static String llIIllIlIllIlI(String llllllllllllllIlIlIlIIlIIlIIlIlI, String llllllllllllllIlIlIlIIlIIlIIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIlIlIIlIIlIIllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIlIIlIIlIIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIlIlIIlIIlIIlllI = Cipher.getInstance("Blowfish");
      llllllllllllllIlIlIlIIlIIlIIlllI.init(lIIIIllIIlllI[3], llllllllllllllIlIlIlIIlIIlIIllll);
      return new String(llllllllllllllIlIlIlIIlIIlIIlllI.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIlIIlIIlIIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIlIlIIlIIlIIllIl)
    {
      llllllllllllllIlIlIlIIlIIlIIllIl.printStackTrace();
    }
    return null;
  }
}

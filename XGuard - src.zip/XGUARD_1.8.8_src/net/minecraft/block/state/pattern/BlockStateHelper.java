package net.minecraft.block.state.pattern;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;

public class BlockStateHelper
  implements Predicate<IBlockState>
{
  private static boolean llIlIIlllIIIll(int ???)
  {
    double llllllllllllllIlIIlllIllIllIlllI;
    return ??? != 0;
  }
  
  public boolean apply(IBlockState llllllllllllllIlIIlllIlllIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    if ((llIlIIlllIIIlI(llllllllllllllIlIIlllIlllIIlIIll)) && (llIlIIlllIIIll(llllllllllllllIlIIlllIlllIIlIIll.getBlock().equals(blockstate.getBlock()))))
    {
      llllllllllllllIlIIlllIlllIIIllIl = propertyPredicates.entrySet().iterator();
      "".length();
      if (" ".length() <= 0) {
        return (122 + 117 - 191 + 112 ^ 5 + 40 - -54 + 78) & (0x21 ^ 0x6C ^ 0x15 ^ 0x49 ^ -" ".length());
      }
      while (!llIlIIlllIIlII(llllllllllllllIlIIlllIlllIIIllIl.hasNext()))
      {
        Map.Entry<IProperty, Predicate> llllllllllllllIlIIlllIlllIIlIIlI = (Map.Entry)llllllllllllllIlIIlllIlllIIIllIl.next();
        Object llllllllllllllIlIIlllIlllIIlIIIl = llllllllllllllIlIIlllIlllIIlIIll.getValue((IProperty)llllllllllllllIlIIlllIlllIIlIIlI.getKey());
        if (llIlIIlllIIlII(((Predicate)llllllllllllllIlIIlllIlllIIlIIlI.getValue()).apply(llllllllllllllIlIIlllIlllIIlIIIl))) {
          return lIIIlIlIlIIlI[0];
        }
      }
      return lIIIlIlIlIIlI[1];
    }
    return lIIIlIlIlIIlI[0];
  }
  
  private static boolean llIlIIlllIIIlI(Object ???)
  {
    long llllllllllllllIlIIlllIllIlllIIII;
    return ??? != null;
  }
  
  private static void llIlIIlllIIIIl()
  {
    lIIIlIlIlIIlI = new int[3];
    lIIIlIlIlIIlI[0] = ((0xF2 ^ 0xA9) & (0xC1 ^ 0x9A ^ 0xFFFFFFFF));
    lIIIlIlIlIIlI[1] = " ".length();
    lIIIlIlIlIIlI[2] = "  ".length();
  }
  
  static
  {
    llIlIIlllIIIIl();
    llIlIIllIlllll();
  }
  
  private static boolean llIlIIlllIIlII(int ???)
  {
    boolean llllllllllllllIlIIlllIllIllIllII;
    return ??? == 0;
  }
  
  private static String llIlIIllIllllI(String llllllllllllllIlIIlllIllIlllIlll, String llllllllllllllIlIIlllIllIlllIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIlllIllIllllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIlllIllIlllIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIIlllIllIllllIIl = Cipher.getInstance("Blowfish");
      llllllllllllllIlIIlllIllIllllIIl.init(lIIIlIlIlIIlI[2], llllllllllllllIlIIlllIllIllllIlI);
      return new String(llllllllllllllIlIIlllIllIllllIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIlllIllIlllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIlllIllIllllIII)
    {
      llllllllllllllIlIIlllIllIllllIII.printStackTrace();
    }
    return null;
  }
  
  public <V extends Comparable<V>> BlockStateHelper where(IProperty<V> llllllllllllllIlIIlllIlllIIIIlII, Predicate<? extends V> llllllllllllllIlIIlllIlllIIIIllI)
  {
    ;
    ;
    ;
    if (llIlIIlllIIlII(blockstate.getProperties().contains(llllllllllllllIlIIlllIlllIIIIlll))) {
      throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(blockstate).append(lIIIlIlIlIIIl[lIIIlIlIlIIlI[0]]).append(llllllllllllllIlIIlllIlllIIIIlll)));
    }
    "".length();
    return llllllllllllllIlIIlllIlllIIIIlIl;
  }
  
  private static void llIlIIllIlllll()
  {
    lIIIlIlIlIIIl = new String[lIIIlIlIlIIlI[1]];
    lIIIlIlIlIIIl[lIIIlIlIlIIlI[0]] = llIlIIllIllllI("1EgzLevPI7oAxyDqMl/1qXYOFln4cmS+bOgfXZrwwOs=", "BNWQD");
  }
  
  private BlockStateHelper(BlockState llllllllllllllIlIIlllIlllIIlllll)
  {
    blockstate = llllllllllllllIlIIlllIlllIIlllll;
  }
  
  public static BlockStateHelper forBlock(Block llllllllllllllIlIIlllIlllIIllIlI)
  {
    ;
    return new BlockStateHelper(llllllllllllllIlIIlllIlllIIllIll.getBlockState());
  }
}

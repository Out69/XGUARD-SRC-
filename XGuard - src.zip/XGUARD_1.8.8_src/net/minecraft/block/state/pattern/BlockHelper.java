package net.minecraft.block.state.pattern;

import com.google.common.base.Predicate;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;

public class BlockHelper
  implements Predicate<IBlockState>
{
  public static BlockHelper forBlock(Block lllllllllllllllIIIlIIIlIIIlIlIlI)
  {
    ;
    return new BlockHelper(lllllllllllllllIIIlIIIlIIIlIlIll);
  }
  
  static {}
  
  private BlockHelper(Block lllllllllllllllIIIlIIIlIIIlIllll)
  {
    block = lllllllllllllllIIIlIIIlIIIlIllll;
  }
  
  private static boolean lIIlllIlIIlIll(Object ???)
  {
    byte lllllllllllllllIIIlIIIlIIIIllllI;
    return ??? != null;
  }
  
  private static boolean lIIlllIlIIllII(Object ???, Object arg1)
  {
    Object localObject;
    long lllllllllllllllIIIlIIIlIIIIllIlI;
    return ??? == localObject;
  }
  
  private static void lIIlllIlIIlIIl()
  {
    llIIlllIIlII = new int[2];
    llIIlllIIlII[0] = " ".length();
    llIIlllIIlII[1] = ((0x52 ^ 0x5C) & (0x7 ^ 0x9 ^ 0xFFFFFFFF));
  }
  
  public boolean apply(IBlockState lllllllllllllllIIIlIIIlIIIlIIlII)
  {
    ;
    ;
    if ((lIIlllIlIIlIll(lllllllllllllllIIIlIIIlIIIlIIlII)) && (lIIlllIlIIllII(lllllllllllllllIIIlIIIlIIIlIIlII.getBlock(), block))) {
      return llIIlllIIlII[0];
    }
    return llIIlllIIlII[1];
  }
}

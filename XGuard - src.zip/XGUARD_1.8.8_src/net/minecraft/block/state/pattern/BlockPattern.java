package net.minecraft.block.state.pattern;

import com.google.common.base.Objects;
import com.google.common.base.Objects.ToStringHelper;
import com.google.common.base.Predicate;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.state.BlockWorldState;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3i;
import net.minecraft.world.World;

public class BlockPattern
{
  public BlockPattern(Predicate<BlockWorldState>[][][] lllllllllllllllIllIIlIllIIlIllIl)
  {
    blockMatches = lllllllllllllllIllIIlIllIIlIllIl;
    fingerLength = lllllllllllllllIllIIlIllIIlIllIl.length;
    if (lllIIlIlIIIII(fingerLength))
    {
      thumbLength = lllllllllllllllIllIIlIllIIlIllIl[lIIlIlIIIIll[0]].length;
      if (lllIIlIlIIIII(thumbLength))
      {
        palmLength = lllllllllllllllIllIIlIllIIlIllIl[lIIlIlIIIIll[0]][lIIlIlIIIIll[0]].length;
        "".length();
        if ("  ".length() > (0x9C ^ 0x98)) {
          throw null;
        }
      }
      else
      {
        palmLength = lIIlIlIIIIll[0];
        "".length();
        if (((0x2B ^ 0x17) & (0x15 ^ 0x29 ^ 0xFFFFFFFF)) != 0) {
          throw null;
        }
      }
    }
    else
    {
      thumbLength = lIIlIlIIIIll[0];
      palmLength = lIIlIlIIIIll[0];
    }
  }
  
  public static LoadingCache<BlockPos, BlockWorldState> func_181627_a(World lllllllllllllllIllIIlIlIllIlllll, boolean lllllllllllllllIllIIlIlIlllIIIII)
  {
    ;
    ;
    return CacheBuilder.newBuilder().build(new CacheLoader(lllllllllllllllIllIIlIlIllIlllll, lllllllllllllllIllIIlIlIlllIIIII));
  }
  
  private static boolean lllIIlIlIIIIl(int ???)
  {
    double lllllllllllllllIllIIlIlIlIlIlIlI;
    return ??? == 0;
  }
  
  public PatternHelper match(World lllllllllllllllIllIIlIlIllllIIlI, BlockPos lllllllllllllllIllIIlIlIllllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    LoadingCache<BlockPos, BlockWorldState> lllllllllllllllIllIIlIlIlllllIIl = func_181627_a(lllllllllllllllIllIIlIlIllllIIlI, lIIlIlIIIIll[0]);
    int lllllllllllllllIllIIlIlIlllllIII = Math.max(Math.max(palmLength, thumbLength), fingerLength);
    float lllllllllllllllIllIIlIlIlllIllIl = BlockPos.getAllInBox(lllllllllllllllIllIIlIlIllllIIIl, lllllllllllllllIllIIlIlIllllIIIl.add(lllllllllllllllIllIIlIlIlllllIII - lIIlIlIIIIll[1], lllllllllllllllIllIIlIlIlllllIII - lIIlIlIIIIll[1], lllllllllllllllIllIIlIlIlllllIII - lIIlIlIIIIll[1])).iterator();
    "".length();
    if (null != null) {
      return null;
    }
    while (!lllIIlIlIIIIl(lllllllllllllllIllIIlIlIlllIllIl.hasNext()))
    {
      BlockPos lllllllllllllllIllIIlIlIllllIlll = (BlockPos)lllllllllllllllIllIIlIlIlllIllIl.next();
      lllllllllllllllIllIIlIlIlllIlIlI = (lllllllllllllllIllIIlIlIlllIlIIl = EnumFacing.values()).length;
      lllllllllllllllIllIIlIlIlllIlIll = lIIlIlIIIIll[0];
      "".length();
      if ((0xB7 ^ 0xB3) <= 0) {
        return null;
      }
      while (!lllIIlIlIIIlI(lllllllllllllllIllIIlIlIlllIlIll, lllllllllllllllIllIIlIlIlllIlIlI))
      {
        EnumFacing lllllllllllllllIllIIlIlIllllIllI = lllllllllllllllIllIIlIlIlllIlIIl[lllllllllllllllIllIIlIlIlllIlIll];
        lllllllllllllllIllIIlIlIlllIIllI = (lllllllllllllllIllIIlIlIlllIIlIl = EnumFacing.values()).length;
        lllllllllllllllIllIIlIlIlllIIlll = lIIlIlIIIIll[0];
        "".length();
        if (null != null) {
          return null;
        }
        while (!lllIIlIlIIIlI(lllllllllllllllIllIIlIlIlllIIlll, lllllllllllllllIllIIlIlIlllIIllI))
        {
          EnumFacing lllllllllllllllIllIIlIlIllllIlIl = lllllllllllllllIllIIlIlIlllIIlIl[lllllllllllllllIllIIlIlIlllIIlll];
          if ((lllIIlIlIIIll(lllllllllllllllIllIIlIlIllllIlIl, lllllllllllllllIllIIlIlIllllIllI)) && (lllIIlIlIIIll(lllllllllllllllIllIIlIlIllllIlIl, lllllllllllllllIllIIlIlIllllIllI.getOpposite())))
          {
            PatternHelper lllllllllllllllIllIIlIlIllllIlII = lllllllllllllllIllIIlIlIllllIIll.checkPatternAt(lllllllllllllllIllIIlIlIllllIlll, lllllllllllllllIllIIlIlIllllIllI, lllllllllllllllIllIIlIlIllllIlIl, lllllllllllllllIllIIlIlIlllllIIl);
            if (lllIIlIlIIlII(lllllllllllllllIllIIlIlIllllIlII)) {
              return lllllllllllllllIllIIlIlIllllIlII;
            }
          }
          lllllllllllllllIllIIlIlIlllIIlll++;
        }
        lllllllllllllllIllIIlIlIlllIlIll++;
      }
    }
    return null;
  }
  
  static
  {
    lllIIlIIlllll();
    lllIIlIIllllI();
  }
  
  protected static BlockPos translateOffset(BlockPos lllllllllllllllIllIIlIlIllIlIlII, EnumFacing lllllllllllllllIllIIlIlIllIlIIll, EnumFacing lllllllllllllllIllIIlIlIllIlIIlI, int lllllllllllllllIllIIlIlIllIlIIIl, int lllllllllllllllIllIIlIlIllIIIlll, int lllllllllllllllIllIIlIlIllIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lllIIlIlIIIll(lllllllllllllllIllIIlIlIllIlIIll, lllllllllllllllIllIIlIlIllIlIIlI)) && (lllIIlIlIIIll(lllllllllllllllIllIIlIlIllIlIIll, lllllllllllllllIllIIlIlIllIlIIlI.getOpposite())))
    {
      Vec3i lllllllllllllllIllIIlIlIllIIlllI = new Vec3i(lllllllllllllllIllIIlIlIllIlIIll.getFrontOffsetX(), lllllllllllllllIllIIlIlIllIlIIll.getFrontOffsetY(), lllllllllllllllIllIIlIlIllIlIIll.getFrontOffsetZ());
      Vec3i lllllllllllllllIllIIlIlIllIIllIl = new Vec3i(lllllllllllllllIllIIlIlIllIlIIlI.getFrontOffsetX(), lllllllllllllllIllIIlIlIllIlIIlI.getFrontOffsetY(), lllllllllllllllIllIIlIlIllIlIIlI.getFrontOffsetZ());
      Vec3i lllllllllllllllIllIIlIlIllIIllII = lllllllllllllllIllIIlIlIllIIlllI.crossProduct(lllllllllllllllIllIIlIlIllIIllIl);
      return lllllllllllllllIllIIlIlIllIlIlII.add(lllllllllllllllIllIIlIlIllIIllIl.getX() * -lllllllllllllllIllIIlIlIllIIIlll + lllllllllllllllIllIIlIlIllIIllII.getX() * lllllllllllllllIllIIlIlIllIlIIIl + lllllllllllllllIllIIlIlIllIIlllI.getX() * lllllllllllllllIllIIlIlIllIIllll, lllllllllllllllIllIIlIlIllIIllIl.getY() * -lllllllllllllllIllIIlIlIllIIIlll + lllllllllllllllIllIIlIlIllIIllII.getY() * lllllllllllllllIllIIlIlIllIlIIIl + lllllllllllllllIllIIlIlIllIIlllI.getY() * lllllllllllllllIllIIlIlIllIIllll, lllllllllllllllIllIIlIlIllIIllIl.getZ() * -lllllllllllllllIllIIlIlIllIIIlll + lllllllllllllllIllIIlIlIllIIllII.getZ() * lllllllllllllllIllIIlIlIllIlIIIl + lllllllllllllllIllIIlIlIllIIlllI.getZ() * lllllllllllllllIllIIlIlIllIIllll);
    }
    throw new IllegalArgumentException(lIIlIlIIIIlI[lIIlIlIIIIll[0]]);
  }
  
  private static String lllIIlIIlllIl(String lllllllllllllllIllIIlIlIlIlllIIl, String lllllllllllllllIllIIlIlIlIlllIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIIlIlIlIlllllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIlIlIlllIlI.getBytes(StandardCharsets.UTF_8)), lIIlIlIIIIll[2]), "DES");
      Cipher lllllllllllllllIllIIlIlIlIllllIl = Cipher.getInstance("DES");
      lllllllllllllllIllIIlIlIlIllllIl.init(lIIlIlIIIIll[3], lllllllllllllllIllIIlIlIlIlllllI);
      return new String(lllllllllllllllIllIIlIlIlIllllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIlIlIlllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIIlIlIlIllllII)
    {
      lllllllllllllllIllIIlIlIlIllllII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIlIlIIIll(Object ???, Object arg1)
  {
    Object localObject;
    char lllllllllllllllIllIIlIlIlIlIlllI;
    return ??? != localObject;
  }
  
  private static void lllIIlIIlllll()
  {
    lIIlIlIIIIll = new int[4];
    lIIlIlIIIIll[0] = ((35 + 'è' - 141 + 107 ^ 43 + 27 - 29 + 146) & (0x50 ^ 0x3C ^ 0x23 ^ 0x1D ^ -" ".length()));
    lIIlIlIIIIll[1] = " ".length();
    lIIlIlIIIIll[2] = (0x1 ^ 0x9);
    lIIlIlIIIIll[3] = "  ".length();
  }
  
  private static void lllIIlIIllllI()
  {
    lIIlIlIIIIlI = new String[lIIlIlIIIIll[1]];
    lIIlIlIIIIlI[lIIlIlIIIIll[0]] = lllIIlIIlllIl("grR463Z5lYJUFU97bqaTJhLAHZsju73QsL+V9TrL0m4xde8P+3vMGg==", "cRDkG");
  }
  
  private PatternHelper checkPatternAt(BlockPos lllllllllllllllIllIIlIllIIIllIll, EnumFacing lllllllllllllllIllIIlIllIIIllIlI, EnumFacing lllllllllllllllIllIIlIllIIIlIIIl, LoadingCache<BlockPos, BlockWorldState> lllllllllllllllIllIIlIllIIIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIllIIlIllIIIlIlll = lIIlIlIIIIll[0];
    "".length();
    if (null != null) {
      return null;
    }
    while (!lllIIlIlIIIlI(lllllllllllllllIllIIlIllIIIlIlll, palmLength))
    {
      int lllllllllllllllIllIIlIllIIIlIllI = lIIlIlIIIIll[0];
      "".length();
      if (null != null) {
        return null;
      }
      while (!lllIIlIlIIIlI(lllllllllllllllIllIIlIllIIIlIllI, thumbLength))
      {
        int lllllllllllllllIllIIlIllIIIlIlIl = lIIlIlIIIIll[0];
        "".length();
        if (-"  ".length() >= 0) {
          return null;
        }
        while (!lllIIlIlIIIlI(lllllllllllllllIllIIlIllIIIlIlIl, fingerLength))
        {
          if (lllIIlIlIIIIl(blockMatches[lllllllllllllllIllIIlIllIIIlIlIl][lllllllllllllllIllIIlIllIIIlIllI][lllllllllllllllIllIIlIllIIIlIlll].apply((BlockWorldState)lllllllllllllllIllIIlIllIIIlIIII.getUnchecked(translateOffset(lllllllllllllllIllIIlIllIIIllIll, lllllllllllllllIllIIlIllIIIlIIlI, lllllllllllllllIllIIlIllIIIlIIIl, lllllllllllllllIllIIlIllIIIlIlll, lllllllllllllllIllIIlIllIIIlIllI, lllllllllllllllIllIIlIllIIIlIlIl))))) {
            return null;
          }
          lllllllllllllllIllIIlIllIIIlIlIl++;
        }
        lllllllllllllllIllIIlIllIIIlIllI++;
      }
      lllllllllllllllIllIIlIllIIIlIlll++;
    }
    return new PatternHelper(lllllllllllllllIllIIlIllIIIllIll, lllllllllllllllIllIIlIllIIIlIIlI, lllllllllllllllIllIIlIllIIIlIIIl, lllllllllllllllIllIIlIllIIIlIIII, palmLength, thumbLength, fingerLength);
  }
  
  private static boolean lllIIlIlIIIII(int ???)
  {
    short lllllllllllllllIllIIlIlIlIlIlIII;
    return ??? > 0;
  }
  
  public int getPalmLength()
  {
    ;
    return palmLength;
  }
  
  private static boolean lllIIlIlIIIlI(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIllIIlIlIlIllIIlI;
    return ??? >= i;
  }
  
  private static boolean lllIIlIlIIlII(Object ???)
  {
    float lllllllllllllllIllIIlIlIlIlIllII;
    return ??? != null;
  }
  
  public int getThumbLength()
  {
    ;
    return thumbLength;
  }
  
  public static class PatternHelper
  {
    public BlockPos func_181117_a()
    {
      ;
      return pos;
    }
    
    public BlockWorldState translateOffset(int lllllllllllllllllIIllIIllllIlllI, int lllllllllllllllllIIllIIllllIlIIl, int lllllllllllllllllIIllIIllllIllII)
    {
      ;
      ;
      ;
      ;
      return (BlockWorldState)lcache.getUnchecked(BlockPattern.translateOffset(pos, lllllllllllllllllIIllIIllllIllll.getFinger(), lllllllllllllllllIIllIIllllIllll.getThumb(), lllllllllllllllllIIllIIllllIlllI, lllllllllllllllllIIllIIllllIlIIl, lllllllllllllllllIIllIIllllIllII));
    }
    
    private static String llllIIlIIIIl(String lllllllllllllllllIIllIIlllIllIlI, String lllllllllllllllllIIllIIlllIllIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllllIIllIIlllIllIlI = new String(Base64.getDecoder().decode(lllllllllllllllllIIllIIlllIllIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllllIIllIIlllIllIII = new StringBuilder();
      char[] lllllllllllllllllIIllIIlllIlIlll = lllllllllllllllllIIllIIlllIllIIl.toCharArray();
      int lllllllllllllllllIIllIIlllIlIllI = lIIllIlIIII[0];
      double lllllllllllllllllIIllIIlllIlIIII = lllllllllllllllllIIllIIlllIllIlI.toCharArray();
      char lllllllllllllllllIIllIIlllIIllll = lllllllllllllllllIIllIIlllIlIIII.length;
      byte lllllllllllllllllIIllIIlllIIlllI = lIIllIlIIII[0];
      while (llllIIlIlIIl(lllllllllllllllllIIllIIlllIIlllI, lllllllllllllllllIIllIIlllIIllll))
      {
        char lllllllllllllllllIIllIIlllIllIll = lllllllllllllllllIIllIIlllIlIIII[lllllllllllllllllIIllIIlllIIlllI];
        "".length();
        "".length();
        if (" ".length() >= "  ".length()) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllllIIllIIlllIllIII);
    }
    
    public PatternHelper(BlockPos lllllllllllllllllIIllIlIIIIIlIIl, EnumFacing lllllllllllllllllIIllIlIIIIlIIII, EnumFacing lllllllllllllllllIIllIlIIIIIIlll, LoadingCache<BlockPos, BlockWorldState> lllllllllllllllllIIllIlIIIIIlllI, int lllllllllllllllllIIllIlIIIIIIlIl, int lllllllllllllllllIIllIlIIIIIIlII, int lllllllllllllllllIIllIlIIIIIlIll)
    {
      pos = lllllllllllllllllIIllIlIIIIIlIIl;
      finger = lllllllllllllllllIIllIlIIIIlIIII;
      thumb = lllllllllllllllllIIllIlIIIIIIlll;
      lcache = lllllllllllllllllIIllIlIIIIIlllI;
      field_181120_e = lllllllllllllllllIIllIlIIIIIIlIl;
      field_181121_f = lllllllllllllllllIIllIlIIIIIIlII;
      field_181122_g = lllllllllllllllllIIllIlIIIIIlIll;
    }
    
    private static boolean llllIIlIlIIl(int ???, int arg1)
    {
      int i;
      int lllllllllllllllllIIllIIllIllllII;
      return ??? < i;
    }
    
    private static String llllIIIlllll(String lllllllllllllllllIIllIIlllIIIlIl, String lllllllllllllllllIIllIIlllIIIIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllllIIllIIlllIIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIllIIlllIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllllIIllIIlllIIIlll = Cipher.getInstance("Blowfish");
        lllllllllllllllllIIllIIlllIIIlll.init(lIIllIlIIII[2], lllllllllllllllllIIllIIlllIIlIII);
        return new String(lllllllllllllllllIIllIIlllIIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIllIIlllIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllllIIllIIlllIIIllI)
      {
        lllllllllllllllllIIllIIlllIIIllI.printStackTrace();
      }
      return null;
    }
    
    public int func_181119_e()
    {
      ;
      return field_181121_f;
    }
    
    public String toString()
    {
      ;
      return Objects.toStringHelper(lllllllllllllllllIIllIIllllIIllI).add(lIIllIIlIlI[lIIllIlIIII[0]], thumb).add(lIIllIIlIlI[lIIllIlIIII[1]], finger).add(lIIllIIlIlI[lIIllIlIIII[2]], pos).toString();
    }
    
    public EnumFacing getFinger()
    {
      ;
      return finger;
    }
    
    private static void llllIIlIlIII()
    {
      lIIllIlIIII = new int[4];
      lIIllIlIIII[0] = ((0x88 ^ 0xA3 ^ 0x87 ^ 0xBF) & (0x63 ^ 0x16 ^ 0xF0 ^ 0x96 ^ -" ".length()));
      lIIllIlIIII[1] = " ".length();
      lIIllIlIIII[2] = "  ".length();
      lIIllIlIIII[3] = "   ".length();
    }
    
    static
    {
      llllIIlIlIII();
      llllIIlIIlII();
    }
    
    public int func_181118_d()
    {
      ;
      return field_181120_e;
    }
    
    private static void llllIIlIIlII()
    {
      lIIllIIlIlI = new String[lIIllIlIIII[3]];
      lIIllIIlIlI[lIIllIlIIII[0]] = llllIIIlllll("xvh91CNkHN4=", "abnjy");
      lIIllIIlIlI[lIIllIlIIII[1]] = llllIIlIIIIl("EQ4iGDUFBSM=", "waPoT");
      lIIllIIlIlI[lIIllIlIIII[2]] = llllIIIlllll("IKsWGKcC+VLbjmS7ZK32qw==", "uTMCY");
    }
    
    public EnumFacing getThumb()
    {
      ;
      return thumb;
    }
  }
  
  static class CacheLoader
    extends CacheLoader<BlockPos, BlockWorldState>
  {
    public BlockWorldState load(BlockPos lIlIllIIllll)
      throws Exception
    {
      ;
      ;
      return new BlockWorldState(world, lIlIllIIllll, field_181626_b);
    }
    
    public CacheLoader(World lIlIllIllIIl, boolean lIlIllIlIlIl)
    {
      world = lIlIllIlIllI;
      field_181626_b = lIlIllIlIlIl;
    }
  }
}

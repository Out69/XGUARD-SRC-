package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;

public abstract class BlockLiquid
  extends Block
{
  public int tickRate(World lllllllllllllllIIlllIlIIIllIIlIl)
  {
    ;
    ;
    if (lIIIIlllllIIIl(blockMaterial, Material.water))
    {
      "".length();
      if (-"   ".length() > 0) {
        return (0x26 ^ 0x57 ^ 0x52 ^ 0x79) & (0x18 ^ 0x2E ^ 0x71 ^ 0x1D ^ -" ".length());
      }
    }
    else if (lIIIIlllllIIIl(blockMaterial, Material.lava))
    {
      if (lIIIIlllllIIll(provider.getHasNoSky()))
      {
        "".length();
        if (" ".length() <= "  ".length()) {
          break label202;
        }
        return (0x46 ^ 0x5B ^ 0x6E ^ 0x5E) & (27 + 5 - 26 + 127 ^ 76 + '' - 43 + 0 ^ -" ".length());
      }
      "".length();
      if ("   ".length() <= (0x4E ^ 0x4A)) {
        break label202;
      }
      return (0x4D ^ 0x46) & (0x32 ^ 0x39 ^ 0xFFFFFFFF);
    }
    label202:
    return lIlIlllllIII[0];
  }
  
  protected void triggerMixEffects(World lllllllllllllllIIlllIIllllIIllll, BlockPos lllllllllllllllIIlllIIllllIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    double lllllllllllllllIIlllIIllllIlIIll = lllllllllllllllIIlllIIllllIIlllI.getX();
    double lllllllllllllllIIlllIIllllIlIIlI = lllllllllllllllIIlllIIllllIIlllI.getY();
    double lllllllllllllllIIlllIIllllIlIIIl = lllllllllllllllIIlllIIllllIIlllI.getZ();
    lllllllllllllllIIlllIIllllIIllll.playSoundEffect(lllllllllllllllIIlllIIllllIlIIll + 0.5D, lllllllllllllllIIlllIIllllIlIIlI + 0.5D, lllllllllllllllIIlllIIllllIlIIIl + 0.5D, lIlIllllIllI[lIlIlllllIII[16]], 0.5F, 2.6F + (rand.nextFloat() - rand.nextFloat()) * 0.8F);
    int lllllllllllllllIIlllIIllllIlIIII = lIlIlllllIII[0];
    "".length();
    if (null != null) {
      return;
    }
    while (!lIIIIlllllIIlI(lllllllllllllllIIlllIIllllIlIIII, lIlIlllllIII[4]))
    {
      lllllllllllllllIIlllIIllllIIllll.spawnParticle(EnumParticleTypes.SMOKE_LARGE, lllllllllllllllIIlllIIllllIlIIll + Math.random(), lllllllllllllllIIlllIIllllIlIIlI + 1.2D, lllllllllllllllIIlllIIllllIlIIIl + Math.random(), 0.0D, 0.0D, 0.0D, new int[lIlIlllllIII[0]]);
      lllllllllllllllIIlllIIllllIlIIII++;
    }
  }
  
  private static void lIIIIllllIlIlI()
  {
    lIlIllllIllI = new String[lIlIlllllIII[18]];
    lIlIllllIllI[lIlIlllllIII[0]] = lIIIIllllIIlIl("eR5HtroiClQ=", "qPmbz");
    lIlIllllIllI[lIlIlllllIII[2]] = lIIIIllllIIllI("BxgFLSAPXwM5PQ4D", "kqtXI");
    lIlIllllIllI[lIlIlllllIII[13]] = lIIIIllllIIlll("2spLDCecEf/6A0IZJr0+QA==", "zLOid");
    lIlIllllIllI[lIlIlllllIII[15]] = lIIIIllllIIlIl("o06J0Xgv6jJF7lyHY1sTjA==", "GXOIa");
    lIlIllllIllI[lIlIlllllIII[16]] = lIIIIllllIIllI("EwcAMhsMSAg/Dhs=", "afnVt");
    lIlIllllIllI[lIlIlllllIII[6]] = lIIIIllllIIlIl("jUgC7b9FfItHPfFXnYVXGUmiKHok5lHz", "WQXhc");
    lIlIllllIllI[lIlIlllllIII[17]] = lIIIIllllIIlIl("zpmRKXvd/EFwsuYsQ7mwySR/1+WDeG/+", "mVnvU");
  }
  
  public static float getLiquidHeightPercent(int lllllllllllllllIIlllIlIIllllIlll)
  {
    ;
    if (lIIIIlllllIIlI(lllllllllllllllIIlllIlIIllllIlll, lIlIlllllIII[4])) {
      lllllllllllllllIIlllIlIIllllIllI = lIlIlllllIII[0];
    }
    return (lllllllllllllllIIlllIlIIllllIllI + lIlIlllllIII[2]) / 9.0F;
  }
  
  private static boolean lIIIIlllllIIIl(Object ???, Object arg1)
  {
    Object localObject;
    long lllllllllllllllIIlllIIllIllIllIl;
    return ??? == localObject;
  }
  
  private static boolean lIIIIllllllIII(int ???)
  {
    long lllllllllllllllIIlllIIllIllIIIll;
    return ??? > 0;
  }
  
  protected int getEffectiveFlowDecay(IBlockAccess lllllllllllllllIIlllIlIIlllIIlll, BlockPos lllllllllllllllIIlllIlIIlllIIIlI)
  {
    ;
    ;
    ;
    ;
    int lllllllllllllllIIlllIlIIlllIIlIl = lllllllllllllllIIlllIlIIlllIIlII.getLevel(lllllllllllllllIIlllIlIIlllIIIll, lllllllllllllllIIlllIlIIlllIIIlI);
    if (lIIIIlllllIIlI(lllllllllllllllIIlllIlIIlllIIlIl, lIlIlllllIII[4]))
    {
      "".length();
      if ("  ".length() >= 0) {
        break label55;
      }
      return (0x77 ^ 0x70) & (0xBE ^ 0xB9 ^ 0xFFFFFFFF);
    }
    label55:
    return lllllllllllllllIIlllIlIIlllIIlIl;
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllIIlllIIllllIIIlII)
  {
    ;
    ;
    return lllllllllllllllIIlllIIllllIIIlIl.getDefaultState().withProperty(LEVEL, Integer.valueOf(lllllllllllllllIIlllIIllllIIIlII));
  }
  
  protected int getLevel(IBlockAccess lllllllllllllllIIlllIlIIllllIIIl, BlockPos lllllllllllllllIIlllIlIIllllIIII)
  {
    ;
    ;
    ;
    if (lIIIIlllllIIIl(lllllllllllllllIIlllIlIIllllIIIl.getBlockState(lllllllllllllllIIlllIlIIllllIIII).getBlock().getMaterial(), blockMaterial))
    {
      "".length();
      if (-"  ".length() <= 0) {
        break label112;
      }
      return (0x36 ^ 0x2E ^ 0xF4 ^ 0xA8) & ('' + 1 - 55 + 145 ^ 97 + 16 - 67 + 126 ^ -" ".length());
    }
    label112:
    return lIlIlllllIII[5];
  }
  
  private static int lIIIlIIIIIIIIl(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public void onBlockAdded(World lllllllllllllllIIlllIlIIIIIIIlIl, BlockPos lllllllllllllllIIlllIlIIIIIIlIII, IBlockState lllllllllllllllIIlllIlIIIIIIIIll)
  {
    ;
    ;
    ;
    ;
    "".length();
  }
  
  public int colorMultiplier(IBlockAccess lllllllllllllllIIlllIlIIlllllllI, BlockPos lllllllllllllllIIlllIlIIlllllIIl, int lllllllllllllllIIlllIlIIllllllII)
  {
    ;
    ;
    ;
    if (lIIIIlllllIIIl(blockMaterial, Material.water))
    {
      "".length();
      if (null == null) {
        break label47;
      }
      return (0x68 ^ 0x21) & (0x6A ^ 0x23 ^ 0xFFFFFFFF);
    }
    label47:
    return lIlIlllllIII[3];
  }
  
  private static String lIIIIllllIIlIl(String lllllllllllllllIIlllIIlllIlIIIlI, String lllllllllllllllIIlllIIlllIlIIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlllIIlllIlIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlllIIlllIlIIIIl.getBytes(StandardCharsets.UTF_8)), lIlIlllllIII[4]), "DES");
      Cipher lllllllllllllllIIlllIIlllIlIIlII = Cipher.getInstance("DES");
      lllllllllllllllIIlllIIlllIlIIlII.init(lIlIlllllIII[13], lllllllllllllllIIlllIIlllIlIIlIl);
      return new String(lllllllllllllllIIlllIIlllIlIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlllIIlllIlIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlllIIlllIlIIIll)
    {
      lllllllllllllllIIlllIIlllIlIIIll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIIlllllIlIl(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllIIlllIIllIlllIlIl;
    return ??? > i;
  }
  
  private static boolean lIIIIllllIllll(Object ???, Object arg1)
  {
    Object localObject;
    float lllllllllllllllIIlllIIllIlllIIIl;
    return ??? != localObject;
  }
  
  public int quantityDropped(Random lllllllllllllllIIlllIlIIlIIllIlI)
  {
    return lIlIlllllIII[0];
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllIIlllIIllllIIIIII)
  {
    ;
    return ((Integer)lllllllllllllllIIlllIIllllIIIIII.getValue(LEVEL)).intValue();
  }
  
  private static boolean lIIIIlllllIIll(int ???)
  {
    String lllllllllllllllIIlllIIllIllIlIll;
    return ??? != 0;
  }
  
  public int getRenderType()
  {
    return lIlIlllllIII[2];
  }
  
  private static String lIIIIllllIIlll(String lllllllllllllllIIlllIIlllIlIllIl, String lllllllllllllllIIlllIIlllIlIlllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlllIIlllIllIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlllIIlllIlIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIlllIIlllIllIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIIlllIIlllIllIIIl.init(lIlIlllllIII[13], lllllllllllllllIIlllIIlllIllIIlI);
      return new String(lllllllllllllllIIlllIIlllIllIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlllIIlllIlIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlllIIlllIllIIII)
    {
      lllllllllllllllIIlllIIlllIllIIII.printStackTrace();
    }
    return null;
  }
  
  public static BlockStaticLiquid getStaticBlock(Material lllllllllllllllIIlllIIlllIlllIII)
  {
    ;
    if (lIIIIlllllIIIl(lllllllllllllllIIlllIIlllIlllIII, Material.water)) {
      return Blocks.water;
    }
    if (lIIIIlllllIIIl(lllllllllllllllIIlllIIlllIllIlll, Material.lava)) {
      return Blocks.lava;
    }
    throw new IllegalArgumentException(lIlIllllIllI[lIlIlllllIII[17]]);
  }
  
  public void randomDisplayTick(World lllllllllllllllIIlllIlIIIIlIIlll, BlockPos lllllllllllllllIIlllIlIIIIlIIllI, IBlockState lllllllllllllllIIlllIlIIIIllIlIl, Random lllllllllllllllIIlllIlIIIIllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    double lllllllllllllllIIlllIlIIIIllIIll = lllllllllllllllIIlllIlIIIIlIIllI.getX();
    double lllllllllllllllIIlllIlIIIIllIIlI = lllllllllllllllIIlllIlIIIIllIllI.getY();
    double lllllllllllllllIIlllIlIIIIllIIIl = lllllllllllllllIIlllIlIIIIllIllI.getZ();
    if (lIIIIlllllIIIl(blockMaterial, Material.water))
    {
      int lllllllllllllllIIlllIlIIIIllIIII = ((Integer)lllllllllllllllIIlllIlIIIIllIlIl.getValue(LEVEL)).intValue();
      if ((lIIIIllllllIII(lllllllllllllllIIlllIlIIIIllIIII)) && (lIIIIllllllIIl(lllllllllllllllIIlllIlIIIIllIIII, lIlIlllllIII[4])))
      {
        if (lIIIIlllllIlII(lllllllllllllllIIlllIlIIIIllIlII.nextInt(lIlIlllllIII[11])))
        {
          lllllllllllllllIIlllIlIIIIlIIlll.playSound(lllllllllllllllIIlllIlIIIIllIIll + 0.5D, lllllllllllllllIIlllIlIIIIllIIlI + 0.5D, lllllllllllllllIIlllIlIIIIllIIIl + 0.5D, lIlIllllIllI[lIlIlllllIII[2]], lllllllllllllllIIlllIlIIIIllIlII.nextFloat() * 0.25F + 0.75F, lllllllllllllllIIlllIlIIIIllIlII.nextFloat() * 1.0F + 0.5F, lIlIlllllIII[0]);
          "".length();
          if ("  ".length() >= ((0x56 ^ 0x7E ^ 0xD8 ^ 0xB4) & (0xAD ^ 0x96 ^ 29 + 27 - 39 + 110 ^ -" ".length()))) {}
        }
      }
      else if (lIIIIlllllIlII(lllllllllllllllIIlllIlIIIIllIlII.nextInt(lIlIlllllIII[7]))) {
        lllllllllllllllIIlllIlIIIIlIIlll.spawnParticle(EnumParticleTypes.SUSPENDED, lllllllllllllllIIlllIlIIIIllIIll + lllllllllllllllIIlllIlIIIIllIlII.nextFloat(), lllllllllllllllIIlllIlIIIIllIIlI + lllllllllllllllIIlllIlIIIIllIlII.nextFloat(), lllllllllllllllIIlllIlIIIIllIIIl + lllllllllllllllIIlllIlIIIIllIlII.nextFloat(), 0.0D, 0.0D, 0.0D, new int[lIlIlllllIII[0]]);
      }
    }
    if ((lIIIIlllllIIIl(blockMaterial, Material.lava)) && (lIIIIlllllIIIl(lllllllllllllllIIlllIlIIIIlIIlll.getBlockState(lllllllllllllllIIlllIlIIIIllIllI.up()).getBlock().getMaterial(), Material.air)) && (lIIIIlllllIlII(lllllllllllllllIIlllIlIIIIlIIlll.getBlockState(lllllllllllllllIIlllIlIIIIllIllI.up()).getBlock().isOpaqueCube())))
    {
      if (lIIIIlllllIlII(lllllllllllllllIIlllIlIIIIllIlII.nextInt(lIlIlllllIII[12])))
      {
        double lllllllllllllllIIlllIlIIIIlIllll = lllllllllllllllIIlllIlIIIIllIIll + lllllllllllllllIIlllIlIIIIllIlII.nextFloat();
        double lllllllllllllllIIlllIlIIIIlIlllI = lllllllllllllllIIlllIlIIIIllIIlI + maxY;
        double lllllllllllllllIIlllIlIIIIlIllIl = lllllllllllllllIIlllIlIIIIllIIIl + lllllllllllllllIIlllIlIIIIllIlII.nextFloat();
        lllllllllllllllIIlllIlIIIIlIIlll.spawnParticle(EnumParticleTypes.LAVA, lllllllllllllllIIlllIlIIIIlIllll, lllllllllllllllIIlllIlIIIIlIlllI, lllllllllllllllIIlllIlIIIIlIllIl, 0.0D, 0.0D, 0.0D, new int[lIlIlllllIII[0]]);
        lllllllllllllllIIlllIlIIIIlIIlll.playSound(lllllllllllllllIIlllIlIIIIlIllll, lllllllllllllllIIlllIlIIIIlIlllI, lllllllllllllllIIlllIlIIIIlIllIl, lIlIllllIllI[lIlIlllllIII[13]], 0.2F + lllllllllllllllIIlllIlIIIIllIlII.nextFloat() * 0.2F, 0.9F + lllllllllllllllIIlllIlIIIIllIlII.nextFloat() * 0.15F, lIlIlllllIII[0]);
      }
      if (lIIIIlllllIlII(lllllllllllllllIIlllIlIIIIllIlII.nextInt(lIlIlllllIII[14]))) {
        lllllllllllllllIIlllIlIIIIlIIlll.playSound(lllllllllllllllIIlllIlIIIIllIIll, lllllllllllllllIIlllIlIIIIllIIlI, lllllllllllllllIIlllIlIIIIllIIIl, lIlIllllIllI[lIlIlllllIII[15]], 0.2F + lllllllllllllllIIlllIlIIIIllIlII.nextFloat() * 0.2F, 0.9F + lllllllllllllllIIlllIlIIIIllIlII.nextFloat() * 0.15F, lIlIlllllIII[0]);
      }
    }
    if ((lIIIIlllllIlII(lllllllllllllllIIlllIlIIIIllIlII.nextInt(lIlIlllllIII[7]))) && (lIIIIlllllIIll(World.doesBlockHaveSolidTopSurface(lllllllllllllllIIlllIlIIIIlIIlll, lllllllllllllllIIlllIlIIIIllIllI.down()))))
    {
      Material lllllllllllllllIIlllIlIIIIlIllII = lllllllllllllllIIlllIlIIIIlIIlll.getBlockState(lllllllllllllllIIlllIlIIIIllIllI.down(lIlIlllllIII[13])).getBlock().getMaterial();
      if ((lIIIIlllllIlII(lllllllllllllllIIlllIlIIIIlIllII.blocksMovement())) && (lIIIIlllllIlII(lllllllllllllllIIlllIlIIIIlIllII.isLiquid())))
      {
        double lllllllllllllllIIlllIlIIIIlIlIll = lllllllllllllllIIlllIlIIIIllIIll + lllllllllllllllIIlllIlIIIIllIlII.nextFloat();
        double lllllllllllllllIIlllIlIIIIlIlIlI = lllllllllllllllIIlllIlIIIIllIIlI - 1.05D;
        double lllllllllllllllIIlllIlIIIIlIlIIl = lllllllllllllllIIlllIlIIIIllIIIl + lllllllllllllllIIlllIlIIIIllIlII.nextFloat();
        if (lIIIIlllllIIIl(blockMaterial, Material.water))
        {
          lllllllllllllllIIlllIlIIIIlIIlll.spawnParticle(EnumParticleTypes.DRIP_WATER, lllllllllllllllIIlllIlIIIIlIlIll, lllllllllllllllIIlllIlIIIIlIlIlI, lllllllllllllllIIlllIlIIIIlIlIIl, 0.0D, 0.0D, 0.0D, new int[lIlIlllllIII[0]]);
          "".length();
          if ("   ".length() >= 0) {}
        }
        else
        {
          lllllllllllllllIIlllIlIIIIlIIlll.spawnParticle(EnumParticleTypes.DRIP_LAVA, lllllllllllllllIIlllIlIIIIlIlIll, lllllllllllllllIIlllIlIIIIlIlIlI, lllllllllllllllIIlllIlIIIIlIlIIl, 0.0D, 0.0D, 0.0D, new int[lIlIlllllIII[0]]);
        }
      }
    }
  }
  
  private static boolean lIIIIlllllIllI(int ???)
  {
    int lllllllllllllllIIlllIIllIllIIlIl;
    return ??? < 0;
  }
  
  public boolean isBlockSolid(IBlockAccess lllllllllllllllIIlllIlIIllIlIIIl, BlockPos lllllllllllllllIIlllIlIIllIlIIII, EnumFacing lllllllllllllllIIlllIlIIllIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    Material lllllllllllllllIIlllIlIIllIIlllI = lllllllllllllllIIlllIlIIllIlIIIl.getBlockState(lllllllllllllllIIlllIlIIllIlIIII).getBlock().getMaterial();
    if (lIIIIlllllIIIl(lllllllllllllllIIlllIlIIllIIlllI, blockMaterial))
    {
      "".length();
      if (((120 + 'ð' - 256 + 140 ^ '' + 120 - 134 + 39) & (40 + 'Û' - 238 + 203 ^ 4 + 30 - -82 + 70 ^ -" ".length())) >= "  ".length()) {
        return (97 + 102 - 173 + 118 ^ 75 + '' - 204 + 168) & (0x72 ^ 0x69 ^ 0x2 ^ 0x38 ^ -" ".length());
      }
    }
    else if (lIIIIlllllIIIl(lllllllllllllllIIlllIlIIllIIlIlI, EnumFacing.UP))
    {
      "".length();
      if ("   ".length() <= 0) {
        return (0x40 ^ 0x4C) & (0x26 ^ 0x2A ^ 0xFFFFFFFF);
      }
    }
    else if (lIIIIlllllIIIl(lllllllllllllllIIlllIlIIllIIlllI, Material.ice))
    {
      "".length();
      if (((0x3E ^ 0x2D) & (0x73 ^ 0x60 ^ 0xFFFFFFFF)) == 0) {
        break label257;
      }
      return (0x60 ^ 0x2B) & (0x44 ^ 0xF ^ 0xFFFFFFFF);
    }
    label257:
    return lllllllllllllllIIlllIlIIllIlIIlI.isBlockSolid(lllllllllllllllIIlllIlIIllIlIIIl, lllllllllllllllIIlllIlIIllIlIIII, lllllllllllllllIIlllIlIIllIIlIlI);
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    ;
    if (lIIIIlllllIIIl(blockMaterial, Material.water))
    {
      "".length();
      if ((7 + 24 - 23 + 136 ^ 32 + 32 - -81 + 3) >= "   ".length()) {
        break label58;
      }
      return null;
    }
    label58:
    return EnumWorldBlockLayer.SOLID;
  }
  
  private static boolean lIIIlIIIIIIlIl(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIIlllIIllIllllIIl;
    return ??? <= i;
  }
  
  private static boolean lIIIIlllllIlII(int ???)
  {
    boolean lllllllllllllllIIlllIIllIllIlIIl;
    return ??? == 0;
  }
  
  public boolean isOpaqueCube()
  {
    return lIlIlllllIII[0];
  }
  
  public static BlockDynamicLiquid getFlowingBlock(Material lllllllllllllllIIlllIIlllIlllIlI)
  {
    ;
    if (lIIIIlllllIIIl(lllllllllllllllIIlllIIlllIlllIlI, Material.water)) {
      return Blocks.flowing_water;
    }
    if (lIIIIlllllIIIl(lllllllllllllllIIlllIIlllIlllIll, Material.lava)) {
      return Blocks.flowing_lava;
    }
    throw new IllegalArgumentException(lIlIllllIllI[lIlIlllllIII[6]]);
  }
  
  protected Vec3 getFlowVector(IBlockAccess lllllllllllllllIIlllIlIIlIIIllIl, BlockPos lllllllllllllllIIlllIlIIlIIIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Vec3 lllllllllllllllIIlllIlIIlIIIlIll = new Vec3(0.0D, 0.0D, 0.0D);
    int lllllllllllllllIIlllIlIIlIIIlIlI = lllllllllllllllIIlllIlIIlIIIIIII.getEffectiveFlowDecay(lllllllllllllllIIlllIlIIIlllllll, lllllllllllllllIIlllIlIIlIIIllII);
    byte lllllllllllllllIIlllIlIIIllllIlI = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if (null != null) {
      return null;
    }
    while (!lIIIIlllllIlII(lllllllllllllllIIlllIlIIIllllIlI.hasNext()))
    {
      Object lllllllllllllllIIlllIlIIlIIIlIIl = lllllllllllllllIIlllIlIIIllllIlI.next();
      EnumFacing lllllllllllllllIIlllIlIIlIIIlIII = (EnumFacing)lllllllllllllllIIlllIlIIlIIIlIIl;
      BlockPos lllllllllllllllIIlllIlIIlIIIIlll = lllllllllllllllIIlllIlIIlIIIllII.offset(lllllllllllllllIIlllIlIIlIIIlIII);
      int lllllllllllllllIIlllIlIIlIIIIllI = lllllllllllllllIIlllIlIIlIIIIIII.getEffectiveFlowDecay(lllllllllllllllIIlllIlIIIlllllll, lllllllllllllllIIlllIlIIlIIIIlll);
      if (lIIIIlllllIllI(lllllllllllllllIIlllIlIIlIIIIllI))
      {
        if (lIIIIlllllIlII(lllllllllllllllIIlllIlIIIlllllll.getBlockState(lllllllllllllllIIlllIlIIlIIIIlll).getBlock().getMaterial().blocksMovement()))
        {
          lllllllllllllllIIlllIlIIlIIIIllI = lllllllllllllllIIlllIlIIlIIIIIII.getEffectiveFlowDecay(lllllllllllllllIIlllIlIIIlllllll, lllllllllllllllIIlllIlIIlIIIIlll.down());
          if (lIIIIlllllIlll(lllllllllllllllIIlllIlIIlIIIIllI))
          {
            int lllllllllllllllIIlllIlIIlIIIIlIl = lllllllllllllllIIlllIlIIlIIIIllI - (lllllllllllllllIIlllIlIIlIIIlIlI - lIlIlllllIII[4]);
            lllllllllllllllIIlllIlIIlIIIlIll = lllllllllllllllIIlllIlIIlIIIlIll.addVector((lllllllllllllllIIlllIlIIlIIIIlll.getX() - lllllllllllllllIIlllIlIIlIIIllII.getX()) * lllllllllllllllIIlllIlIIlIIIIlIl, (lllllllllllllllIIlllIlIIlIIIIlll.getY() - lllllllllllllllIIlllIlIIlIIIllII.getY()) * lllllllllllllllIIlllIlIIlIIIIlIl, (lllllllllllllllIIlllIlIIlIIIIlll.getZ() - lllllllllllllllIIlllIlIIlIIIllII.getZ()) * lllllllllllllllIIlllIlIIlIIIIlIl);
            "".length();
            if (-(0x15 ^ 0x31 ^ 0xB7 ^ 0x96) >= 0) {
              return null;
            }
          }
        }
      }
      else if (lIIIIlllllIlll(lllllllllllllllIIlllIlIIlIIIIllI))
      {
        int lllllllllllllllIIlllIlIIlIIIIlII = lllllllllllllllIIlllIlIIlIIIIllI - lllllllllllllllIIlllIlIIlIIIlIlI;
        lllllllllllllllIIlllIlIIlIIIlIll = lllllllllllllllIIlllIlIIlIIIlIll.addVector((lllllllllllllllIIlllIlIIlIIIIlll.getX() - lllllllllllllllIIlllIlIIlIIIllII.getX()) * lllllllllllllllIIlllIlIIlIIIIlII, (lllllllllllllllIIlllIlIIlIIIIlll.getY() - lllllllllllllllIIlllIlIIlIIIllII.getY()) * lllllllllllllllIIlllIlIIlIIIIlII, (lllllllllllllllIIlllIlIIlIIIIlll.getZ() - lllllllllllllllIIlllIlIIlIIIllII.getZ()) * lllllllllllllllIIlllIlIIlIIIIlII);
      }
    }
    if (lIIIIlllllIIlI(((Integer)lllllllllllllllIIlllIlIIIlllllll.getBlockState(lllllllllllllllIIlllIlIIlIIIllII).getValue(LEVEL)).intValue(), lIlIlllllIII[4]))
    {
      lllllllllllllllIIlllIlIIIllllIlI = EnumFacing.Plane.HORIZONTAL.iterator();
      "".length();
      if ((67 + 33 - -20 + 38 ^ 82 + '' - 102 + 29) != (50 + 94 - 36 + 37 ^ 71 + 100 - 61 + 39)) {
        return null;
      }
      while (!lIIIIlllllIlII(lllllllllllllllIIlllIlIIIllllIlI.hasNext()))
      {
        Object lllllllllllllllIIlllIlIIlIIIIIll = lllllllllllllllIIlllIlIIIllllIlI.next();
        EnumFacing lllllllllllllllIIlllIlIIlIIIIIlI = (EnumFacing)lllllllllllllllIIlllIlIIlIIIIIll;
        BlockPos lllllllllllllllIIlllIlIIlIIIIIIl = lllllllllllllllIIlllIlIIlIIIllII.offset(lllllllllllllllIIlllIlIIlIIIIIlI);
        if ((!lIIIIlllllIlII(lllllllllllllllIIlllIlIIlIIIIIII.isBlockSolid(lllllllllllllllIIlllIlIIIlllllll, lllllllllllllllIIlllIlIIlIIIIIIl, lllllllllllllllIIlllIlIIlIIIIIlI))) || (lIIIIlllllIIll(lllllllllllllllIIlllIlIIlIIIIIII.isBlockSolid(lllllllllllllllIIlllIlIIIlllllll, lllllllllllllllIIlllIlIIlIIIIIIl.up(), lllllllllllllllIIlllIlIIlIIIIIlI))))
        {
          lllllllllllllllIIlllIlIIlIIIlIll = lllllllllllllllIIlllIlIIlIIIlIll.normalize().addVector(0.0D, -6.0D, 0.0D);
          "".length();
          if ("  ".length() == "  ".length()) {
            break;
          }
          return null;
        }
      }
    }
    return lllllllllllllllIIlllIlIIlIIIlIll.normalize();
  }
  
  private static boolean lIIIIllllllIIl(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIIlllIIllIlllllIl;
    return ??? < i;
  }
  
  public Vec3 modifyAcceleration(World lllllllllllllllIIlllIlIIIlllIIII, BlockPos lllllllllllllllIIlllIlIIIllIlIlI, Entity lllllllllllllllIIlllIlIIIllIlllI, Vec3 lllllllllllllllIIlllIlIIIllIlIIl)
  {
    ;
    ;
    ;
    ;
    return lllllllllllllllIIlllIlIIIllIlIIl.add(lllllllllllllllIIlllIlIIIlllIIIl.getFlowVector(lllllllllllllllIIlllIlIIIlllIIII, lllllllllllllllIIlllIlIIIllIllll));
  }
  
  public boolean checkForMixing(World lllllllllllllllIIlllIIlllllIlIll, BlockPos lllllllllllllllIIlllIIlllllIIIll, IBlockState lllllllllllllllIIlllIIlllllIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIIlllllIIIl(blockMaterial, Material.lava))
    {
      boolean lllllllllllllllIIlllIIlllllIlIII = lIlIlllllIII[0];
      lllllllllllllllIIlllIIllllIllllI = (lllllllllllllllIIlllIIllllIlllIl = EnumFacing.values()).length;
      lllllllllllllllIIlllIIllllIlllll = lIlIlllllIII[0];
      "".length();
      if (((0xDD ^ 0x85) & (0x73 ^ 0x2B ^ 0xFFFFFFFF)) >= "   ".length()) {
        return (0x66 ^ 0x28) & (0x64 ^ 0x2A ^ 0xFFFFFFFF);
      }
      while (!lIIIIlllllIIlI(lllllllllllllllIIlllIIllllIlllll, lllllllllllllllIIlllIIllllIllllI))
      {
        EnumFacing lllllllllllllllIIlllIIlllllIIlll = lllllllllllllllIIlllIIllllIlllIl[lllllllllllllllIIlllIIllllIlllll];
        if ((lIIIIllllIllll(lllllllllllllllIIlllIIlllllIIlll, EnumFacing.DOWN)) && (lIIIIlllllIIIl(lllllllllllllllIIlllIIlllllIlIll.getBlockState(lllllllllllllllIIlllIIlllllIIIll.offset(lllllllllllllllIIlllIIlllllIIlll)).getBlock().getMaterial(), Material.water)))
        {
          lllllllllllllllIIlllIIlllllIlIII = lIlIlllllIII[2];
          "".length();
          if (null == null) {
            break;
          }
          return (0xC1 ^ 0xA2) & (0x18 ^ 0x7B ^ 0xFFFFFFFF);
        }
        lllllllllllllllIIlllIIllllIlllll++;
      }
      if (lIIIIlllllIIll(lllllllllllllllIIlllIIlllllIlIII))
      {
        Integer lllllllllllllllIIlllIIlllllIIllI = (Integer)lllllllllllllllIIlllIIlllllIIIlI.getValue(LEVEL);
        if (lIIIIlllllIlII(lllllllllllllllIIlllIIlllllIIllI.intValue()))
        {
          "".length();
          lllllllllllllllIIlllIIlllllIllII.triggerMixEffects(lllllllllllllllIIlllIIlllllIlIll, lllllllllllllllIIlllIIlllllIIIll);
          return lIlIlllllIII[2];
        }
        if (lIIIlIIIIIIlIl(lllllllllllllllIIlllIIlllllIIllI.intValue(), lIlIlllllIII[16]))
        {
          "".length();
          lllllllllllllllIIlllIIlllllIllII.triggerMixEffects(lllllllllllllllIIlllIIlllllIlIll, lllllllllllllllIIlllIIlllllIIIll);
          return lIlIlllllIII[2];
        }
      }
    }
    return lIlIlllllIII[0];
  }
  
  public static double getFlowDirection(IBlockAccess lllllllllllllllIIlllIlIIIIIlIllI, BlockPos lllllllllllllllIIlllIlIIIIIlIlIl, Material lllllllllllllllIIlllIlIIIIIlIlII)
  {
    ;
    ;
    ;
    ;
    Vec3 lllllllllllllllIIlllIlIIIIIlIIll = getFlowingBlock(lllllllllllllllIIlllIlIIIIIlIlII).getFlowVector(lllllllllllllllIIlllIlIIIIIlIllI, lllllllllllllllIIlllIlIIIIIlIIIl);
    if ((lIIIIlllllIlII(lIIIlIIIIIIIIl(xCoord, 0.0D))) && (lIIIIlllllIlII(lIIIlIIIIIIIIl(zCoord, 0.0D))))
    {
      "".length();
      if (-" ".length() < "   ".length()) {
        break label78;
      }
      return 0.0D;
    }
    label78:
    return MathHelper.func_181159_b(zCoord, xCoord) - 1.5707963267948966D;
  }
  
  public boolean canCollideCheck(IBlockState lllllllllllllllIIlllIlIIllIllIIl, boolean lllllllllllllllIIlllIlIIllIllIII)
  {
    ;
    ;
    if ((lIIIIlllllIIll(lllllllllllllllIIlllIlIIllIllIII)) && (lIIIIlllllIlII(((Integer)lllllllllllllllIIlllIlIIllIllIIl.getValue(LEVEL)).intValue()))) {
      return lIlIlllllIII[2];
    }
    return lIlIlllllIII[0];
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllIIlllIIlllIllllIl, new IProperty[] { LEVEL });
  }
  
  private static boolean lIIIIlllllIlll(int ???)
  {
    String lllllllllllllllIIlllIIllIllIIlll;
    return ??? >= 0;
  }
  
  public boolean isFullCube()
  {
    return lIlIlllllIII[0];
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllIIlllIlIIlIIllllI, Random lllllllllllllllIIlllIlIIlIIlllIl, int lllllllllllllllIIlllIlIIlIIlllII)
  {
    return null;
  }
  
  private static String lIIIIllllIIllI(String lllllllllllllllIIlllIIlllIIIllIl, String lllllllllllllllIIlllIIlllIIIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlllIIlllIIIllIl = new String(Base64.getDecoder().decode(lllllllllllllllIIlllIIlllIIIllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlllIIlllIIlIIII = new StringBuilder();
    char[] lllllllllllllllIIlllIIlllIIIllll = lllllllllllllllIIlllIIlllIIIllII.toCharArray();
    int lllllllllllllllIIlllIIlllIIIlllI = lIlIlllllIII[0];
    byte lllllllllllllllIIlllIIlllIIIlIII = lllllllllllllllIIlllIIlllIIIllIl.toCharArray();
    float lllllllllllllllIIlllIIlllIIIIlll = lllllllllllllllIIlllIIlllIIIlIII.length;
    Exception lllllllllllllllIIlllIIlllIIIIllI = lIlIlllllIII[0];
    while (lIIIIllllllIIl(lllllllllllllllIIlllIIlllIIIIllI, lllllllllllllllIIlllIIlllIIIIlll))
    {
      char lllllllllllllllIIlllIIlllIIlIIll = lllllllllllllllIIlllIIlllIIIlIII[lllllllllllllllIIlllIIlllIIIIllI];
      "".length();
      "".length();
      if ((0x2D ^ 0x55 ^ 0xC0 ^ 0xBC) <= "  ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlllIIlllIIlIIII);
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World lllllllllllllllIIlllIlIIlIlIIIll, BlockPos lllllllllllllllIIlllIlIIlIlIIIlI, IBlockState lllllllllllllllIIlllIlIIlIlIIIIl)
  {
    return null;
  }
  
  public int getMixedBrightnessForBlock(IBlockAccess lllllllllllllllIIlllIlIIIlIllIIl, BlockPos lllllllllllllllIIlllIlIIIlIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIIlllIlIIIlIlIlll = lllllllllllllllIIlllIlIIIlIllIIl.getCombinedLight(lllllllllllllllIIlllIlIIIlIlIIII, lIlIlllllIII[0]);
    int lllllllllllllllIIlllIlIIIlIlIllI = lllllllllllllllIIlllIlIIIlIllIIl.getCombinedLight(lllllllllllllllIIlllIlIIIlIlIIII.up(), lIlIlllllIII[0]);
    int lllllllllllllllIIlllIlIIIlIlIlIl = lllllllllllllllIIlllIlIIIlIlIlll & lIlIlllllIII[9];
    int lllllllllllllllIIlllIlIIIlIlIlII = lllllllllllllllIIlllIlIIIlIlIllI & lIlIlllllIII[9];
    int lllllllllllllllIIlllIlIIIlIlIIll = lllllllllllllllIIlllIlIIIlIlIlll >> lIlIlllllIII[10] & lIlIlllllIII[9];
    int lllllllllllllllIIlllIlIIIlIlIIlI = lllllllllllllllIIlllIlIIIlIlIllI >> lIlIlllllIII[10] & lIlIlllllIII[9];
    if (lIIIIlllllIlIl(lllllllllllllllIIlllIlIIIlIlIlIl, lllllllllllllllIIlllIlIIIlIlIlII))
    {
      "".length();
      if ("   ".length() >= 0) {
        break label171;
      }
      return (6 + '' - -7 + 59 ^ 74 + 45 - 90 + 105) & (66 + 0 - 55 + 183 ^ 75 + 80 - 134 + 126 ^ -" ".length());
    }
    label171:
    if (lIIIIlllllIlIl(lllllllllllllllIIlllIlIIIlIlIIll, lllllllllllllllIIlllIlIIIlIlIIlI))
    {
      "".length();
      if ((0x73 ^ 0x42 ^ 0x2D ^ 0x18) > " ".length()) {
        break label259;
      }
      return (0x50 ^ 0x2B ^ 0x2A ^ 0x32) & ('' + '¦' - 176 + 87 ^ '' + 83 - 203 + 142 ^ -" ".length());
    }
    label259:
    return lllllllllllllllIIlllIlIIIlIlIIll | lllllllllllllllIIlllIlIIIlIlIIlI << lIlIlllllIII[10];
  }
  
  public boolean shouldSideBeRendered(IBlockAccess lllllllllllllllIIlllIlIIlIllllll, BlockPos lllllllllllllllIIlllIlIIllIIIIlI, EnumFacing lllllllllllllllIIlllIlIIllIIIIIl)
  {
    ;
    ;
    ;
    ;
    if (lIIIIlllllIIIl(lllllllllllllllIIlllIlIIlIllllll.getBlockState(lllllllllllllllIIlllIlIIllIIIIlI).getBlock().getMaterial(), blockMaterial))
    {
      "".length();
      if ((0x7B ^ 0xA ^ 0x5B ^ 0x2E) == 0) {
        return (80 + 74 - 128 + 102 ^ 77 + 126 - 110 + 57) & (47 + '' - 138 + 105 ^ 90 + 3 - 29 + 71 ^ -" ".length());
      }
    }
    else if (lIIIIlllllIIIl(lllllllllllllllIIlllIlIIllIIIIIl, EnumFacing.UP))
    {
      "".length();
      if (-"  ".length() <= 0) {
        break label179;
      }
      return (0x80 ^ 0xA4 ^ 0xE ^ 0x65) & (0xD8 ^ 0x8B ^ 0x35 ^ 0x29 ^ -" ".length());
    }
    label179:
    return lllllllllllllllIIlllIlIIllIIIlII.shouldSideBeRendered(lllllllllllllllIIlllIlIIlIllllll, lllllllllllllllIIlllIlIIllIIIIlI, lllllllllllllllIIlllIlIIllIIIIIl);
  }
  
  private static boolean lIIIIlllllIIlI(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIIlllIIlllIIIIIIl;
    return ??? >= i;
  }
  
  protected BlockLiquid(Material lllllllllllllllIIlllIlIlIIIIlIlI)
  {
    lllllllllllllllIIlllIlIlIIIIlIll.<init>(lllllllllllllllIIlllIlIlIIIIlIlI);
    lllllllllllllllIIlllIlIlIIIIlIll.setDefaultState(blockState.getBaseState().withProperty(LEVEL, Integer.valueOf(lIlIlllllIII[0])));
    lllllllllllllllIIlllIlIlIIIIlIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    "".length();
  }
  
  public boolean func_176364_g(IBlockAccess lllllllllllllllIIlllIlIIlIlIlIll, BlockPos lllllllllllllllIIlllIlIIlIlIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIIlllIlIIlIllIIIl = lIlIlllllIII[5];
    "".length();
    if (" ".length() <= 0) {
      return (0xD5 ^ 0xB5) & (0xE8 ^ 0x88 ^ 0xFFFFFFFF);
    }
    while (!lIIIIlllllIlIl(lllllllllllllllIIlllIlIIlIllIIIl, lIlIlllllIII[2]))
    {
      int lllllllllllllllIIlllIlIIlIllIIII = lIlIlllllIII[5];
      "".length();
      if (-" ".length() >= 0) {
        return (0xB4 ^ 0xB1) & (0x95 ^ 0x90 ^ 0xFFFFFFFF);
      }
      while (!lIIIIlllllIlIl(lllllllllllllllIIlllIlIIlIllIIII, lIlIlllllIII[2]))
      {
        IBlockState lllllllllllllllIIlllIlIIlIlIllll = lllllllllllllllIIlllIlIIlIllIIll.getBlockState(lllllllllllllllIIlllIlIIlIlIlIlI.add(lllllllllllllllIIlllIlIIlIllIIIl, lIlIlllllIII[0], lllllllllllllllIIlllIlIIlIllIIII));
        Block lllllllllllllllIIlllIlIIlIlIlllI = lllllllllllllllIIlllIlIIlIlIllll.getBlock();
        Material lllllllllllllllIIlllIlIIlIlIllIl = lllllllllllllllIIlllIlIIlIlIlllI.getMaterial();
        if ((lIIIIllllIllll(lllllllllllllllIIlllIlIIlIlIllIl, blockMaterial)) && (lIIIIlllllIlII(lllllllllllllllIIlllIlIIlIlIlllI.isFullBlock()))) {
          return lIlIlllllIII[2];
        }
        lllllllllllllllIIlllIlIIlIllIIII++;
      }
      lllllllllllllllIIlllIlIIlIllIIIl++;
    }
    return lIlIlllllIII[0];
  }
  
  public boolean isPassable(IBlockAccess lllllllllllllllIIlllIlIlIIIIIlIl, BlockPos lllllllllllllllIIlllIlIlIIIIIlII)
  {
    ;
    if (lIIIIllllIllll(blockMaterial, Material.lava)) {
      return lIlIlllllIII[2];
    }
    return lIlIlllllIII[0];
  }
  
  public void onNeighborBlockChange(World lllllllllllllllIIlllIIllllllllIl, BlockPos lllllllllllllllIIlllIIllllllIlll, IBlockState lllllllllllllllIIlllIIllllllIllI, Block lllllllllllllllIIlllIIlllllllIlI)
  {
    ;
    ;
    ;
    ;
    "".length();
  }
  
  static
  {
    lIIIIllllIlllI();
    lIIIIllllIlIlI();
  }
  
  private static void lIIIIllllIlllI()
  {
    lIlIlllllIII = new int[19];
    lIlIlllllIII[0] = ((69 + 119 - 131 + 82 ^ 69 + 112 - 108 + 82) & (0xD5 ^ 0xA1 ^ 0x7 ^ 0x63 ^ -" ".length()));
    lIlIlllllIII[1] = (0x12 ^ 0x17 ^ 0x5E ^ 0x54);
    lIlIlllllIII[2] = " ".length();
    lIlIlllllIII[3] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIlIlllllIII[4] = (0x5 ^ 0xD);
    lIlIlllllIII[5] = (-" ".length());
    lIlIlllllIII[6] = (0xB4 ^ 0xA1 ^ 0x28 ^ 0x38);
    lIlIlllllIII[7] = (0x91 ^ 0x9B);
    lIlIlllllIII[8] = (0xBB ^ 0xA5);
    lIlIlllllIII[9] = (8 + '¥' - -52 + 30);
    lIlIlllllIII[10] = (0x9A ^ 0x8A);
    lIlIlllllIII[11] = (0xF3 ^ 0xB3);
    lIlIlllllIII[12] = (0x1E ^ 0x36 ^ 0x49 ^ 0x5);
    lIlIlllllIII[13] = "  ".length();
    lIlIlllllIII[14] = ((0x64 ^ 0x18) + (0xF4 ^ 0x92) - (0xA9 ^ 0x98) + (0x3 ^ 0x14));
    lIlIlllllIII[15] = "   ".length();
    lIlIlllllIII[16] = (0x16 ^ 0x12);
    lIlIlllllIII[17] = (0xA ^ 0xC);
    lIlIlllllIII[18] = (0x6 ^ 0x1);
  }
}

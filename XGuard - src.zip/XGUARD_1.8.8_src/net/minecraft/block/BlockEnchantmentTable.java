package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityEnchantmentTable;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class BlockEnchantmentTable
  extends BlockContainer
{
  public void randomDisplayTick(World lllllllllllllllllIIIIIlIIlIIIlIl, BlockPos lllllllllllllllllIIIIIlIIlIIllIl, IBlockState lllllllllllllllllIIIIIlIIlIIIIll, Random lllllllllllllllllIIIIIlIIlIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIIIlIIlIIIllI.randomDisplayTick(lllllllllllllllllIIIIIlIIlIIIlIl, lllllllllllllllllIIIIIlIIlIIIlII, lllllllllllllllllIIIIIlIIlIIIIll, lllllllllllllllllIIIIIlIIlIIIIlI);
    int lllllllllllllllllIIIIIlIIlIIlIlI = lIlIllIlIlI[1];
    "".length();
    if ("  ".length() <= 0) {
      return;
    }
    while (!lIIIIllIIllII(lllllllllllllllllIIIIIlIIlIIlIlI, lIlIllIlIlI[2]))
    {
      int lllllllllllllllllIIIIIlIIlIIlIIl = lIlIllIlIlI[1];
      "".length();
      if (('' + 67 - 53 + 30 ^ 'º' + '' - 313 + 186) <= 0) {
        return;
      }
      while (!lIIIIllIIllII(lllllllllllllllllIIIIIlIIlIIlIIl, lIlIllIlIlI[2]))
      {
        if ((lIIIIllIIllII(lllllllllllllllllIIIIIlIIlIIlIlI, lIlIllIlIlI[1])) && (lIIIIllIIllIl(lllllllllllllllllIIIIIlIIlIIlIlI, lIlIllIlIlI[2])) && (lIIIIllIIlllI(lllllllllllllllllIIIIIlIIlIIlIIl, lIlIllIlIlI[3]))) {
          lllllllllllllllllIIIIIlIIlIIlIIl = lIlIllIlIlI[2];
        }
        if (lIIIIllIlIIII(lllllllllllllllllIIIIIlIIlIIIIlI.nextInt(lIlIllIlIlI[4])))
        {
          int lllllllllllllllllIIIIIlIIlIIlIII = lIlIllIlIlI[0];
          "".length();
          if (" ".length() <= 0) {
            return;
          }
          while (!lIIIIllIIllII(lllllllllllllllllIIIIIlIIlIIlIII, lIlIllIlIlI[5]))
          {
            BlockPos lllllllllllllllllIIIIIlIIlIIIlll = lllllllllllllllllIIIIIlIIlIIIlII.add(lllllllllllllllllIIIIIlIIlIIlIlI, lllllllllllllllllIIIIIlIIlIIlIII, lllllllllllllllllIIIIIlIIlIIlIIl);
            if (lIIIIllIlIIIl(lllllllllllllllllIIIIIlIIlIIIlIl.getBlockState(lllllllllllllllllIIIIIlIIlIIIlll).getBlock(), Blocks.bookshelf))
            {
              if (lIIIIllIlIIII(lllllllllllllllllIIIIIlIIlIIIlIl.isAirBlock(lllllllllllllllllIIIIIlIIlIIIlII.add(lllllllllllllllllIIIIIlIIlIIlIlI / lIlIllIlIlI[2], lIlIllIlIlI[0], lllllllllllllllllIIIIIlIIlIIlIIl / lIlIllIlIlI[2]))))
              {
                "".length();
                if (-"   ".length() <= 0) {
                  break;
                }
                return;
              }
              lllllllllllllllllIIIIIlIIlIIIlIl.spawnParticle(EnumParticleTypes.ENCHANTMENT_TABLE, lllllllllllllllllIIIIIlIIlIIIlII.getX() + 0.5D, lllllllllllllllllIIIIIlIIlIIIlII.getY() + 2.0D, lllllllllllllllllIIIIIlIIlIIIlII.getZ() + 0.5D, lllllllllllllllllIIIIIlIIlIIlIlI + lllllllllllllllllIIIIIlIIlIIIIlI.nextFloat() - 0.5D, lllllllllllllllllIIIIIlIIlIIlIII - lllllllllllllllllIIIIIlIIlIIIIlI.nextFloat() - 1.0F, lllllllllllllllllIIIIIlIIlIIlIIl + lllllllllllllllllIIIIIlIIlIIIIlI.nextFloat() - 0.5D, new int[lIlIllIlIlI[0]]);
            }
            lllllllllllllllllIIIIIlIIlIIlIII++;
          }
        }
        lllllllllllllllllIIIIIlIIlIIlIIl++;
      }
      lllllllllllllllllIIIIIlIIlIIlIlI++;
    }
  }
  
  private static boolean lIIIIllIlIIlI(int ???)
  {
    double lllllllllllllllllIIIIIlIIIIIIIII;
    return ??? != 0;
  }
  
  public boolean isOpaqueCube()
  {
    return lIlIllIlIlI[0];
  }
  
  private static boolean lIIIIllIIllIl(int ???, int arg1)
  {
    int i;
    int lllllllllllllllllIIIIIlIIIIIlIlI;
    return ??? < i;
  }
  
  public TileEntity createNewTileEntity(World lllllllllllllllllIIIIIlIIIlllIlI, int lllllllllllllllllIIIIIlIIIlllIIl)
  {
    return new TileEntityEnchantmentTable();
  }
  
  static {}
  
  private static boolean lIIIIllIlIIII(int ???)
  {
    long lllllllllllllllllIIIIIIllllllllI;
    return ??? == 0;
  }
  
  public boolean onBlockActivated(World lllllllllllllllllIIIIIlIIIlIlIlI, BlockPos lllllllllllllllllIIIIIlIIIllIIlI, IBlockState lllllllllllllllllIIIIIlIIIllIIIl, EntityPlayer lllllllllllllllllIIIIIlIIIllIIII, EnumFacing lllllllllllllllllIIIIIlIIIlIllll, float lllllllllllllllllIIIIIlIIIlIlllI, float lllllllllllllllllIIIIIlIIIlIllIl, float lllllllllllllllllIIIIIlIIIlIllII)
  {
    ;
    ;
    ;
    ;
    if (lIIIIllIlIIlI(isRemote)) {
      return lIlIllIlIlI[5];
    }
    TileEntity lllllllllllllllllIIIIIlIIIlIlIll = lllllllllllllllllIIIIIlIIIlIlIlI.getTileEntity(lllllllllllllllllIIIIIlIIIllIIlI);
    if (lIIIIllIlIIlI(lllllllllllllllllIIIIIlIIIlIlIll instanceof TileEntityEnchantmentTable)) {
      lllllllllllllllllIIIIIlIIIllIIII.displayGui((TileEntityEnchantmentTable)lllllllllllllllllIIIIIlIIIlIlIll);
    }
    return lIlIllIlIlI[5];
  }
  
  public boolean isFullCube()
  {
    return lIlIllIlIlI[0];
  }
  
  private static boolean lIIIIllIIllII(int ???, int arg1)
  {
    int i;
    float lllllllllllllllllIIIIIlIIIIIIllI;
    return ??? > i;
  }
  
  private static boolean lIIIIllIlIIIl(Object ???, Object arg1)
  {
    Object localObject;
    String lllllllllllllllllIIIIIlIIIIIIIlI;
    return ??? == localObject;
  }
  
  protected BlockEnchantmentTable()
  {
    lllllllllllllllllIIIIIlIIlIllIlI.<init>(Material.rock, MapColor.redColor);
    lllllllllllllllllIIIIIlIIlIllIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.75F, 1.0F);
    "".length();
    "".length();
  }
  
  public void onBlockPlacedBy(World lllllllllllllllllIIIIIlIIIIllllI, BlockPos lllllllllllllllllIIIIIlIIIIlllIl, IBlockState lllllllllllllllllIIIIIlIIIIlIlIl, EntityLivingBase lllllllllllllllllIIIIIlIIIIllIll, ItemStack lllllllllllllllllIIIIIlIIIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIIIlIIIIlllll.onBlockPlacedBy(lllllllllllllllllIIIIIlIIIIllllI, lllllllllllllllllIIIIIlIIIIlllIl, lllllllllllllllllIIIIIlIIIIlIlIl, lllllllllllllllllIIIIIlIIIIllIll, lllllllllllllllllIIIIIlIIIIlIIll);
    if (lIIIIllIlIIlI(lllllllllllllllllIIIIIlIIIIlIIll.hasDisplayName()))
    {
      TileEntity lllllllllllllllllIIIIIlIIIIllIIl = lllllllllllllllllIIIIIlIIIIllllI.getTileEntity(lllllllllllllllllIIIIIlIIIIlllIl);
      if (lIIIIllIlIIlI(lllllllllllllllllIIIIIlIIIIllIIl instanceof TileEntityEnchantmentTable)) {
        ((TileEntityEnchantmentTable)lllllllllllllllllIIIIIlIIIIllIIl).setCustomName(lllllllllllllllllIIIIIlIIIIlIIll.getDisplayName());
      }
    }
  }
  
  private static void lIIIIllIIlIll()
  {
    lIlIllIlIlI = new int[7];
    lIlIllIlIlI[0] = ((0xF4 ^ 0xBB ^ 0x5 ^ 0x19) & (0x4F ^ 0x4 ^ 0x51 ^ 0x49 ^ -" ".length()));
    lIlIllIlIlI[1] = (-"  ".length());
    lIlIllIlIlI[2] = "  ".length();
    lIlIllIlIlI[3] = (-" ".length());
    lIlIllIlIlI[4] = (54 + 104 - 74 + 53 ^ 55 + 91 - 42 + 49);
    lIlIllIlIlI[5] = " ".length();
    lIlIllIlIlI[6] = "   ".length();
  }
  
  public int getRenderType()
  {
    return lIlIllIlIlI[6];
  }
  
  private static boolean lIIIIllIIlllI(int ???, int arg1)
  {
    int i;
    float lllllllllllllllllIIIIIlIIIIIlllI;
    return ??? == i;
  }
}

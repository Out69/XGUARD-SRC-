package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockPane
  extends Block
{
  private static boolean lIIIIlIllllIl(Object ???, Object arg1)
  {
    Object localObject;
    long lllllllllllllllllIIIIIlIlIlIlIIl;
    return ??? != localObject;
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllllIIIIIllIlIIlIIl, Random lllllllllllllllllIIIIIllIlIIlIII, int lllllllllllllllllIIIIIllIlIIIIll)
  {
    ;
    ;
    ;
    ;
    if (lIIIIlIlllIlI(canDrop))
    {
      "".length();
      if (((0x2E ^ 0xE ^ 0xB ^ 0x3) & (0xD4 ^ 0x8F ^ 0xF6 ^ 0x85 ^ -" ".length())) == 0) {
        break label62;
      }
      return null;
    }
    label62:
    return lllllllllllllllllIIIIIllIlIIlIlI.getItemDropped(lllllllllllllllllIIIIIllIlIIlIIl, lllllllllllllllllIIIIIllIlIIlIII, lllllllllllllllllIIIIIllIlIIIIll);
  }
  
  protected boolean canSilkHarvest()
  {
    return lIlIllIIlII[1];
  }
  
  static
  {
    lIIIIlIlllIIl();
    lIIIIlIlIlIlI();
    NORTH = PropertyBool.create(lIlIllIIIlI[lIlIllIIlII[0]]);
    EAST = PropertyBool.create(lIlIllIIIlI[lIlIllIIlII[1]]);
    SOUTH = PropertyBool.create(lIlIllIIIlI[lIlIllIIlII[2]]);
  }
  
  protected BlockPane(Material lllllllllllllllllIIIIIllIlIlllll, boolean lllllllllllllllllIIIIIllIlIllllI)
  {
    lllllllllllllllllIIIIIllIllIIIII.<init>(lllllllllllllllllIIIIIllIlIlllII);
    lllllllllllllllllIIIIIllIllIIIII.setDefaultState(blockState.getBaseState().withProperty(NORTH, Boolean.valueOf(lIlIllIIlII[0])).withProperty(EAST, Boolean.valueOf(lIlIllIIlII[0])).withProperty(SOUTH, Boolean.valueOf(lIlIllIIlII[0])).withProperty(WEST, Boolean.valueOf(lIlIllIIlII[0])));
    canDrop = lllllllllllllllllIIIIIllIlIllllI;
    "".length();
  }
  
  private static boolean lIIIIlIlllIlI(int ???)
  {
    double lllllllllllllllllIIIIIlIlIlIIIIl;
    return ??? == 0;
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    lllllllllllllllllIIIIIllIIIlIIIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  
  private static boolean lIIIIlIllllII(int ???)
  {
    double lllllllllllllllllIIIIIlIlIlIIIll;
    return ??? != 0;
  }
  
  private static void lIIIIlIlllIIl()
  {
    lIlIllIIlII = new int[6];
    lIlIllIIlII[0] = (('Ï' + 22 - 100 + 94 ^ 80 + 112 - 124 + 85) & (0x4E ^ 0x7F ^ 0xE1 ^ 0x96 ^ -" ".length()));
    lIlIllIIlII[1] = " ".length();
    lIlIllIIlII[2] = "  ".length();
    lIlIllIIlII[3] = "   ".length();
    lIlIllIIlII[4] = (0x5A ^ 0x5E);
    lIlIllIIlII[5] = (0x4D ^ 0x30 ^ 0x5A ^ 0x2F);
  }
  
  public void addCollisionBoxesToList(World lllllllllllllllllIIIIIllIIlIlIII, BlockPos lllllllllllllllllIIIIIllIIlIIlll, IBlockState lllllllllllllllllIIIIIllIIIllIll, AxisAlignedBB lllllllllllllllllIIIIIllIIlIIlIl, List<AxisAlignedBB> lllllllllllllllllIIIIIllIIlIIlII, Entity lllllllllllllllllIIIIIllIIlIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    boolean lllllllllllllllllIIIIIllIIlIIIlI = lllllllllllllllllIIIIIllIIIllllI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIIlIlIII.getBlockState(lllllllllllllllllIIIIIllIIlIIlll.north()).getBlock());
    boolean lllllllllllllllllIIIIIllIIlIIIIl = lllllllllllllllllIIIIIllIIIllllI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIIlIlIII.getBlockState(lllllllllllllllllIIIIIllIIlIIlll.south()).getBlock());
    boolean lllllllllllllllllIIIIIllIIlIIIII = lllllllllllllllllIIIIIllIIIllllI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIIlIlIII.getBlockState(lllllllllllllllllIIIIIllIIlIIlll.west()).getBlock());
    boolean lllllllllllllllllIIIIIllIIIlllll = lllllllllllllllllIIIIIllIIIllllI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIIlIlIII.getBlockState(lllllllllllllllllIIIIIllIIlIIlll.east()).getBlock());
    if (((!lIIIIlIllllII(lllllllllllllllllIIIIIllIIlIIIII)) || (lIIIIlIlllIlI(lllllllllllllllllIIIIIllIIIlllll))) && ((!lIIIIlIlllIlI(lllllllllllllllllIIIIIllIIlIIIII)) || (!lIIIIlIlllIlI(lllllllllllllllllIIIIIllIIIlllll)) || (!lIIIIlIlllIlI(lllllllllllllllllIIIIIllIIlIIIlI)) || (lIIIIlIllllII(lllllllllllllllllIIIIIllIIlIIIIl))))
    {
      if (lIIIIlIllllII(lllllllllllllllllIIIIIllIIlIIIII))
      {
        lllllllllllllllllIIIIIllIIIllllI.setBlockBounds(0.0F, 0.0F, 0.4375F, 0.5F, 1.0F, 0.5625F);
        lllllllllllllllllIIIIIllIIIllllI.addCollisionBoxesToList(lllllllllllllllllIIIIIllIIlIlIII, lllllllllllllllllIIIIIllIIlIIlll, lllllllllllllllllIIIIIllIIlIIllI, lllllllllllllllllIIIIIllIIlIIlIl, lllllllllllllllllIIIIIllIIlIIlII, lllllllllllllllllIIIIIllIIlIIIll);
        "".length();
        if (-" ".length() <= (0x39 ^ 0x3D)) {}
      }
      else if (lIIIIlIllllII(lllllllllllllllllIIIIIllIIIlllll))
      {
        lllllllllllllllllIIIIIllIIIllllI.setBlockBounds(0.5F, 0.0F, 0.4375F, 1.0F, 1.0F, 0.5625F);
        lllllllllllllllllIIIIIllIIIllllI.addCollisionBoxesToList(lllllllllllllllllIIIIIllIIlIlIII, lllllllllllllllllIIIIIllIIlIIlll, lllllllllllllllllIIIIIllIIlIIllI, lllllllllllllllllIIIIIllIIlIIlIl, lllllllllllllllllIIIIIllIIlIIlII, lllllllllllllllllIIIIIllIIlIIIll);
        "".length();
        if (-(0x79 ^ 0x7C) < 0) {}
      }
    }
    else
    {
      lllllllllllllllllIIIIIllIIIllllI.setBlockBounds(0.0F, 0.0F, 0.4375F, 1.0F, 1.0F, 0.5625F);
      lllllllllllllllllIIIIIllIIIllllI.addCollisionBoxesToList(lllllllllllllllllIIIIIllIIlIlIII, lllllllllllllllllIIIIIllIIlIIlll, lllllllllllllllllIIIIIllIIlIIllI, lllllllllllllllllIIIIIllIIlIIlIl, lllllllllllllllllIIIIIllIIlIIlII, lllllllllllllllllIIIIIllIIlIIIll);
    }
    if (((!lIIIIlIllllII(lllllllllllllllllIIIIIllIIlIIIlI)) || (lIIIIlIlllIlI(lllllllllllllllllIIIIIllIIlIIIIl))) && ((!lIIIIlIlllIlI(lllllllllllllllllIIIIIllIIlIIIII)) || (!lIIIIlIlllIlI(lllllllllllllllllIIIIIllIIIlllll)) || (!lIIIIlIlllIlI(lllllllllllllllllIIIIIllIIlIIIlI)) || (lIIIIlIllllII(lllllllllllllllllIIIIIllIIlIIIIl))))
    {
      if (lIIIIlIllllII(lllllllllllllllllIIIIIllIIlIIIlI))
      {
        lllllllllllllllllIIIIIllIIIllllI.setBlockBounds(0.4375F, 0.0F, 0.0F, 0.5625F, 1.0F, 0.5F);
        lllllllllllllllllIIIIIllIIIllllI.addCollisionBoxesToList(lllllllllllllllllIIIIIllIIlIlIII, lllllllllllllllllIIIIIllIIlIIlll, lllllllllllllllllIIIIIllIIlIIllI, lllllllllllllllllIIIIIllIIlIIlIl, lllllllllllllllllIIIIIllIIlIIlII, lllllllllllllllllIIIIIllIIlIIIll);
        "".length();
        if ("   ".length() > ((0x55 ^ 0x64) & (0x8C ^ 0xBD ^ 0xFFFFFFFF))) {}
      }
      else if (lIIIIlIllllII(lllllllllllllllllIIIIIllIIlIIIIl))
      {
        lllllllllllllllllIIIIIllIIIllllI.setBlockBounds(0.4375F, 0.0F, 0.5F, 0.5625F, 1.0F, 1.0F);
        lllllllllllllllllIIIIIllIIIllllI.addCollisionBoxesToList(lllllllllllllllllIIIIIllIIlIlIII, lllllllllllllllllIIIIIllIIlIIlll, lllllllllllllllllIIIIIllIIlIIllI, lllllllllllllllllIIIIIllIIlIIlIl, lllllllllllllllllIIIIIllIIlIIlII, lllllllllllllllllIIIIIllIIlIIIll);
        "".length();
        if (((35 + 123 - 112 + 106 ^ 106 + 42 - -2 + 6) & (52 + 50 - 21 + 99 ^ 33 + '' - 43 + 43 ^ -" ".length())) != (0xFD ^ 0xA8 ^ 0x4D ^ 0x1C)) {}
      }
    }
    else
    {
      lllllllllllllllllIIIIIllIIIllllI.setBlockBounds(0.4375F, 0.0F, 0.0F, 0.5625F, 1.0F, 1.0F);
      lllllllllllllllllIIIIIllIIIllllI.addCollisionBoxesToList(lllllllllllllllllIIIIIllIIlIlIII, lllllllllllllllllIIIIIllIIlIIlll, lllllllllllllllllIIIIIllIIlIIllI, lllllllllllllllllIIIIIllIIlIIlIl, lllllllllllllllllIIIIIllIIlIIlII, lllllllllllllllllIIIIIllIIlIIIll);
    }
  }
  
  public IBlockState getActualState(IBlockState lllllllllllllllllIIIIIllIlIlIIIl, IBlockAccess lllllllllllllllllIIIIIllIlIlIIII, BlockPos lllllllllllllllllIIIIIllIlIIllll)
  {
    ;
    ;
    ;
    ;
    return lllllllllllllllllIIIIIllIlIlIIIl.withProperty(NORTH, Boolean.valueOf(lllllllllllllllllIIIIIllIlIlIllI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIlIlIIII.getBlockState(lllllllllllllllllIIIIIllIlIIllll.north()).getBlock()))).withProperty(SOUTH, Boolean.valueOf(lllllllllllllllllIIIIIllIlIlIllI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIlIlIIII.getBlockState(lllllllllllllllllIIIIIllIlIIllll.south()).getBlock()))).withProperty(WEST, Boolean.valueOf(lllllllllllllllllIIIIIllIlIlIllI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIlIlIIII.getBlockState(lllllllllllllllllIIIIIllIlIIllll.west()).getBlock()))).withProperty(EAST, Boolean.valueOf(lllllllllllllllllIIIIIllIlIlIllI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIlIlIIII.getBlockState(lllllllllllllllllIIIIIllIlIIllll.east()).getBlock())));
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT_MIPPED;
  }
  
  private static boolean lIIIIlIlllllI(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllllIIIIIlIlIlIllIl;
    return ??? < i;
  }
  
  private static String lIIIIlIlIIlll(String lllllllllllllllllIIIIIlIllIIllII, String lllllllllllllllllIIIIIlIllIIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIIIIlIllIlIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIIIlIllIIlIll.getBytes(StandardCharsets.UTF_8)), lIlIllIIlII[5]), "DES");
      Cipher lllllllllllllllllIIIIIlIllIlIIII = Cipher.getInstance("DES");
      lllllllllllllllllIIIIIlIllIlIIII.init(lIlIllIIlII[2], lllllllllllllllllIIIIIlIllIlIIIl);
      return new String(lllllllllllllllllIIIIIlIllIlIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIIIlIllIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIIIIlIllIIllll)
    {
      lllllllllllllllllIIIIIlIllIIllll.printStackTrace();
    }
    return null;
  }
  
  private static String lIIIIlIlIlIIl(String lllllllllllllllllIIIIIlIllIllIIl, String lllllllllllllllllIIIIIlIllIllIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIIIIlIllIllllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIIIlIllIllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIIIIIlIllIlllIl = Cipher.getInstance("Blowfish");
      lllllllllllllllllIIIIIlIllIlllIl.init(lIlIllIIlII[2], lllllllllllllllllIIIIIlIllIllllI);
      return new String(lllllllllllllllllIIIIIlIllIlllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIIIlIllIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIIIIlIllIlllII)
    {
      lllllllllllllllllIIIIIlIllIlllII.printStackTrace();
    }
    return null;
  }
  
  public boolean isOpaqueCube()
  {
    return lIlIllIIlII[0];
  }
  
  public boolean isFullCube()
  {
    return lIlIllIIlII[0];
  }
  
  private static boolean lIIIIlIlllIll(Object ???, Object arg1)
  {
    Object localObject;
    String lllllllllllllllllIIIIIlIlIlIIlIl;
    return ??? == localObject;
  }
  
  private static String lIIIIlIlIlIII(String lllllllllllllllllIIIIIlIlIlllllI, String lllllllllllllllllIIIIIlIlIlllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIIIlIlIlllllI = new String(Base64.getDecoder().decode(lllllllllllllllllIIIIIlIlIlllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIIIIlIlIllllII = new StringBuilder();
    char[] lllllllllllllllllIIIIIlIlIlllIll = lllllllllllllllllIIIIIlIlIlllIII.toCharArray();
    int lllllllllllllllllIIIIIlIlIlllIlI = lIlIllIIlII[0];
    boolean lllllllllllllllllIIIIIlIlIllIlII = lllllllllllllllllIIIIIlIlIlllllI.toCharArray();
    String lllllllllllllllllIIIIIlIlIllIIll = lllllllllllllllllIIIIIlIlIllIlII.length;
    float lllllllllllllllllIIIIIlIlIllIIlI = lIlIllIIlII[0];
    while (lIIIIlIlllllI(lllllllllllllllllIIIIIlIlIllIIlI, lllllllllllllllllIIIIIlIlIllIIll))
    {
      char lllllllllllllllllIIIIIlIlIllllll = lllllllllllllllllIIIIIlIlIllIlII[lllllllllllllllllIIIIIlIlIllIIlI];
      "".length();
      "".length();
      if ("  ".length() != "  ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIIIIIlIlIllllII);
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllllIIIIIlIlllIIllI)
  {
    return lIlIllIIlII[0];
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllllIIIIIlIlllIIIll, new IProperty[] { NORTH, EAST, WEST, SOUTH });
  }
  
  public boolean shouldSideBeRendered(IBlockAccess lllllllllllllllllIIIIIllIIllIlll, BlockPos lllllllllllllllllIIIIIllIIllIllI, EnumFacing lllllllllllllllllIIIIIllIIlllIIl)
  {
    ;
    ;
    ;
    ;
    if (lIIIIlIlllIll(lllllllllllllllllIIIIIllIIllIlll.getBlockState(lllllllllllllllllIIIIIllIIllIllI).getBlock(), lllllllllllllllllIIIIIllIIlllIII))
    {
      "".length();
      if (null == null) {
        break label86;
      }
      return (67 + 98 - 53 + 44 ^ 123 + 119 - 104 + 28) & (0x4A ^ 0xC ^ 0xEC ^ 0x90 ^ -" ".length());
    }
    label86:
    return lllllllllllllllllIIIIIllIIlllIII.shouldSideBeRendered(lllllllllllllllllIIIIIllIIllIlll, lllllllllllllllllIIIIIllIIllIllI, lllllllllllllllllIIIIIllIIlllIIl);
  }
  
  public final boolean canPaneConnectToBlock(Block lllllllllllllllllIIIIIlIlllIllII)
  {
    ;
    ;
    if ((lIIIIlIlllIlI(lllllllllllllllllIIIIIlIlllIllII.isFullBlock())) && (lIIIIlIllllIl(lllllllllllllllllIIIIIlIlllIllII, lllllllllllllllllIIIIIlIlllIlIll)) && (lIIIIlIllllIl(lllllllllllllllllIIIIIlIlllIllII, Blocks.glass)) && (lIIIIlIllllIl(lllllllllllllllllIIIIIlIlllIllII, Blocks.stained_glass)) && (lIIIIlIllllIl(lllllllllllllllllIIIIIlIlllIllII, Blocks.stained_glass_pane)) && (lIIIIlIlllIlI(lllllllllllllllllIIIIIlIlllIllII instanceof BlockPane))) {
      return lIlIllIIlII[0];
    }
    return lIlIllIIlII[1];
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess lllllllllllllllllIIIIIlIlllllIIl, BlockPos lllllllllllllllllIIIIIllIIIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllllIIIIIllIIIIIIlI = 0.4375F;
    float lllllllllllllllllIIIIIllIIIIIIIl = 0.5625F;
    float lllllllllllllllllIIIIIllIIIIIIII = 0.4375F;
    float lllllllllllllllllIIIIIlIllllllll = 0.5625F;
    boolean lllllllllllllllllIIIIIlIlllllllI = lllllllllllllllllIIIIIlIlllllIlI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIIIIIlII.getBlockState(lllllllllllllllllIIIIIllIIIIIIll.north()).getBlock());
    boolean lllllllllllllllllIIIIIlIllllllIl = lllllllllllllllllIIIIIlIlllllIlI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIIIIIlII.getBlockState(lllllllllllllllllIIIIIllIIIIIIll.south()).getBlock());
    boolean lllllllllllllllllIIIIIlIllllllII = lllllllllllllllllIIIIIlIlllllIlI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIIIIIlII.getBlockState(lllllllllllllllllIIIIIllIIIIIIll.west()).getBlock());
    boolean lllllllllllllllllIIIIIlIlllllIll = lllllllllllllllllIIIIIlIlllllIlI.canPaneConnectToBlock(lllllllllllllllllIIIIIllIIIIIlII.getBlockState(lllllllllllllllllIIIIIllIIIIIIll.east()).getBlock());
    if (((!lIIIIlIllllII(lllllllllllllllllIIIIIlIllllllII)) || (lIIIIlIlllIlI(lllllllllllllllllIIIIIlIlllllIll))) && ((!lIIIIlIlllIlI(lllllllllllllllllIIIIIlIllllllII)) || (!lIIIIlIlllIlI(lllllllllllllllllIIIIIlIlllllIll)) || (!lIIIIlIlllIlI(lllllllllllllllllIIIIIlIlllllllI)) || (lIIIIlIllllII(lllllllllllllllllIIIIIlIllllllIl))))
    {
      if (lIIIIlIllllII(lllllllllllllllllIIIIIlIllllllII))
      {
        lllllllllllllllllIIIIIllIIIIIIlI = 0.0F;
        "".length();
        if ((0xF8 ^ 0x8F ^ 0x1A ^ 0x69) >= 0) {}
      }
      else if (lIIIIlIllllII(lllllllllllllllllIIIIIlIlllllIll))
      {
        lllllllllllllllllIIIIIllIIIIIIIl = 1.0F;
        "".length();
        if (" ".length() >= ((0x40 ^ 0x0) & (0x62 ^ 0x22 ^ 0xFFFFFFFF))) {}
      }
    }
    else
    {
      lllllllllllllllllIIIIIllIIIIIIlI = 0.0F;
      lllllllllllllllllIIIIIllIIIIIIIl = 1.0F;
    }
    if (((!lIIIIlIllllII(lllllllllllllllllIIIIIlIlllllllI)) || (lIIIIlIlllIlI(lllllllllllllllllIIIIIlIllllllIl))) && ((!lIIIIlIlllIlI(lllllllllllllllllIIIIIlIllllllII)) || (!lIIIIlIlllIlI(lllllllllllllllllIIIIIlIlllllIll)) || (!lIIIIlIlllIlI(lllllllllllllllllIIIIIlIlllllllI)) || (lIIIIlIllllII(lllllllllllllllllIIIIIlIllllllIl))))
    {
      if (lIIIIlIllllII(lllllllllllllllllIIIIIlIlllllllI))
      {
        lllllllllllllllllIIIIIllIIIIIIII = 0.0F;
        "".length();
        if (-"   ".length() <= 0) {}
      }
      else if (lIIIIlIllllII(lllllllllllllllllIIIIIlIllllllIl))
      {
        lllllllllllllllllIIIIIlIllllllll = 1.0F;
        "".length();
        if (((0x59 ^ 0x3B) & (0x70 ^ 0x12 ^ 0xFFFFFFFF)) < " ".length()) {}
      }
    }
    else
    {
      lllllllllllllllllIIIIIllIIIIIIII = 0.0F;
      lllllllllllllllllIIIIIlIllllllll = 1.0F;
    }
    lllllllllllllllllIIIIIlIlllllIlI.setBlockBounds(lllllllllllllllllIIIIIllIIIIIIlI, 0.0F, lllllllllllllllllIIIIIllIIIIIIII, lllllllllllllllllIIIIIllIIIIIIIl, 1.0F, lllllllllllllllllIIIIIlIllllllll);
  }
  
  private static void lIIIIlIlIlIlI()
  {
    lIlIllIIIlI = new String[lIlIllIIlII[4]];
    lIlIllIIIlI[lIlIllIIlII[0]] = lIIIIlIlIIlll("UBI7+/grKq0=", "aQNaj");
    lIlIllIIIlI[lIlIllIIlII[1]] = lIIIIlIlIIlll("LQBsGNHNS04=", "vTZwF");
    lIlIllIIIlI[lIlIllIIlII[2]] = lIIIIlIlIlIII("BCcEGh0=", "wHqnu");
    lIlIllIIIlI[lIlIllIIlII[3]] = lIIIIlIlIlIIl("63Zr5UR6PZA=", "Gdcjx");
  }
}

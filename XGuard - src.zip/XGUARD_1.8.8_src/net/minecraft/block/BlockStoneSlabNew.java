package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;

public abstract class BlockStoneSlabNew
  extends BlockSlab
{
  public int getMetaFromState(IBlockState llllllllllllllIlIllIlIlIllIlIlll)
  {
    ;
    ;
    ;
    int llllllllllllllIlIllIlIlIllIllIIl = lIIIIIlIIllIl[0];
    llllllllllllllIlIllIlIlIllIllIIl |= ((EnumType)llllllllllllllIlIllIlIlIllIlIlll.getValue(VARIANT)).getMetadata();
    if (llIIIlllllIlll(llllllllllllllIlIllIlIlIllIllIll.isDouble()))
    {
      if (llIIIlllllIlll(((Boolean)llllllllllllllIlIllIlIlIllIlIlll.getValue(SEAMLESS)).booleanValue()))
      {
        llllllllllllllIlIllIlIlIllIllIIl |= lIIIIIlIIllIl[5];
        "".length();
        if (((0x40 ^ 0x46) & (0xAC ^ 0xAA ^ 0xFFFFFFFF)) > "   ".length()) {
          return (0x66 ^ 0x2D) & (0x23 ^ 0x68 ^ 0xFFFFFFFF);
        }
      }
    }
    else if (llIIIllllllIll(llllllllllllllIlIllIlIlIllIlIlll.getValue(HALF), BlockSlab.EnumBlockHalf.TOP)) {
      llllllllllllllIlIllIlIlIllIllIIl |= lIIIIIlIIllIl[5];
    }
    return llllllllllllllIlIllIlIlIllIllIIl;
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllIlIllIlIlIllIIllll)
  {
    ;
    return ((EnumType)llllllllllllllIlIllIlIlIllIIllll.getValue(VARIANT)).func_181068_c();
  }
  
  private static boolean llIIIllllllIIl(int ???, int arg1)
  {
    int i;
    int llllllllllllllIlIllIlIlIlIIlIlIl;
    return ??? >= i;
  }
  
  private static boolean llIIIllllllIlI(int ???)
  {
    double llllllllllllllIlIllIlIlIlIIIIlIl;
    return ??? == 0;
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIlIllIlIllIIIIlIIl, Random llllllllllllllIlIllIlIllIIIIlIII, int llllllllllllllIlIllIlIllIIIIIlll)
  {
    return Item.getItemFromBlock(Blocks.stone_slab2);
  }
  
  private static void llIIIlllllIlIl()
  {
    lIIIIIlIIllII = new String[lIIIIIlIIllIl[6]];
    lIIIIIlIIllII[lIIIIIlIIllIl[0]] = llIIIlllllIIII("GwMDACANFRE=", "hfbmL");
    lIIIIIlIIllII[lIIIIIlIIllIl[1]] = llIIIlllllIIIl("ccGzcGGE124=", "qZUOL");
    lIIIIIlIIllII[lIIIIIlIIllIl[2]] = llIIIlllllIlII("NlhqGnoye2IRbe2n4RwGyNf2zduqXsYO", "WEjec");
    lIIIIIlIIllII[lIIIIIlIIllIl[3]] = llIIIlllllIlII("aOLn+lN5p4c=", "unhqw");
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIlIllIlIlIlllIIIll)
  {
    ;
    ;
    ;
    IBlockState llllllllllllllIlIllIlIlIlllIIIlI = llllllllllllllIlIllIlIlIlllIIlII.getDefaultState().withProperty(VARIANT, EnumType.byMetadata(llllllllllllllIlIllIlIlIlllIIIll & lIIIIIlIIllIl[4]));
    if (llIIIlllllIlll(llllllllllllllIlIllIlIlIlllIIlII.isDouble()))
    {
      if (llIIIlllllIlll(llllllllllllllIlIllIlIlIlllIIIll & lIIIIIlIIllIl[5]))
      {
        "".length();
        if (((72 + 66 - 8 + 80 ^ 3 + 21 - -30 + 74) & ('°' + 103 - 123 + 58 ^ 117 + 97 - 110 + 28 ^ -" ".length())) < "   ".length()) {
          break label130;
        }
        return null;
      }
      label130:
      llllllllllllllIlIllIlIlIlllIIIlI = SEAMLESS.withProperty(lIIIIIlIIllIl[1], Boolean.valueOf(lIIIIIlIIllIl[0]));
      "".length();
      if ((0x71 ^ 0x74) <= 0) {
        return null;
      }
    }
    else
    {
      if (llIIIllllllIlI(llllllllllllllIlIllIlIlIlllIIIll & lIIIIIlIIllIl[5]))
      {
        "".length();
        if (-(31 + 3 - -61 + 79 ^ 67 + 109 - 115 + 109) < 0) {
          break label212;
        }
        return null;
      }
      label212:
      llllllllllllllIlIllIlIlIlllIIIlI = HALF.withProperty(BlockSlab.EnumBlockHalf.BOTTOM, BlockSlab.EnumBlockHalf.TOP);
    }
    return llllllllllllllIlIllIlIlIlllIIIlI;
  }
  
  public String getUnlocalizedName(int llllllllllllllIlIllIlIlIlllllllI)
  {
    ;
    ;
    return String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlIllIlIllIIIIIIIl.getUnlocalizedName())).append(lIIIIIlIIllII[lIIIIIlIIllIl[3]]).append(EnumType.byMetadata(llllllllllllllIlIllIlIlIlllllllI).getUnlocalizedName()));
  }
  
  private static String llIIIlllllIIIl(String llllllllllllllIlIllIlIlIllIIIIll, String llllllllllllllIlIllIlIlIllIIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIllIlIlIllIIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIllIlIlIllIIIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIllIlIlIllIIIlIl = Cipher.getInstance("Blowfish");
      llllllllllllllIlIllIlIlIllIIIlIl.init(lIIIIIlIIllIl[2], llllllllllllllIlIllIlIlIllIIIllI);
      return new String(llllllllllllllIlIllIlIlIllIIIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlIllIlIlIllIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIllIlIlIllIIIlII)
    {
      llllllllllllllIlIllIlIlIllIIIlII.printStackTrace();
    }
    return null;
  }
  
  public BlockStoneSlabNew()
  {
    llllllllllllllIlIllIlIllIIIIllll.<init>(Material.rock);
    IBlockState llllllllllllllIlIllIlIllIIIlIIII = blockState.getBaseState();
    if (llIIIlllllIlll(llllllllllllllIlIllIlIllIIIlIIIl.isDouble()))
    {
      llllllllllllllIlIllIlIllIIIlIIII = llllllllllllllIlIllIlIllIIIlIIII.withProperty(SEAMLESS, Boolean.valueOf(lIIIIIlIIllIl[0]));
      "".length();
      if (null != null) {
        throw null;
      }
    }
    else
    {
      llllllllllllllIlIllIlIllIIIlIIII = llllllllllllllIlIllIlIllIIIlIIII.withProperty(HALF, BlockSlab.EnumBlockHalf.BOTTOM);
    }
    llllllllllllllIlIllIlIllIIIlIIIl.setDefaultState(llllllllllllllIlIllIlIllIIIlIIII.withProperty(VARIANT, EnumType.RED_SANDSTONE));
    "".length();
  }
  
  private static boolean llIIIlllllllII(int ???, int arg1)
  {
    int i;
    long llllllllllllllIlIllIlIlIlIIlIIIl;
    return ??? < i;
  }
  
  private static void llIIIlllllIllI()
  {
    lIIIIIlIIllIl = new int[7];
    lIIIIIlIIllIl[0] = ((0x3C ^ 0x7F) & (0x6B ^ 0x28 ^ 0xFFFFFFFF));
    lIIIIIlIIllIl[1] = " ".length();
    lIIIIIlIIllIl[2] = "  ".length();
    lIIIIIlIIllIl[3] = "   ".length();
    lIIIIIlIIllIl[4] = (0xAB ^ 0xAC);
    lIIIIIlIIllIl[5] = ('¥' + '' - 264 + 119 ^ 17 + 33 - -7 + 106);
    lIIIIIlIIllIl[6] = (69 + 53 - 119 + 151 ^ 111 + '' - 176 + 78);
  }
  
  private static String llIIIlllllIIII(String llllllllllllllIlIllIlIlIlIllIIll, String llllllllllllllIlIllIlIlIlIllIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIllIlIlIlIllIIll = new String(Base64.getDecoder().decode(llllllllllllllIlIllIlIlIlIllIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIllIlIlIlIllIIIl = new StringBuilder();
    char[] llllllllllllllIlIllIlIlIlIllIIII = llllllllllllllIlIllIlIlIlIllIIlI.toCharArray();
    int llllllllllllllIlIllIlIlIlIlIllll = lIIIIIlIIllIl[0];
    String llllllllllllllIlIllIlIlIlIlIlIIl = llllllllllllllIlIllIlIlIlIllIIll.toCharArray();
    char llllllllllllllIlIllIlIlIlIlIlIII = llllllllllllllIlIllIlIlIlIlIlIIl.length;
    char llllllllllllllIlIllIlIlIlIlIIlll = lIIIIIlIIllIl[0];
    while (llIIIlllllllII(llllllllllllllIlIllIlIlIlIlIIlll, llllllllllllllIlIllIlIlIlIlIlIII))
    {
      char llllllllllllllIlIllIlIlIlIllIlII = llllllllllllllIlIllIlIlIlIlIlIIl[llllllllllllllIlIllIlIlIlIlIIlll];
      "".length();
      "".length();
      if (((0x4D ^ 0x6A ^ 0xAC ^ 0xB0) & (0x78 ^ 0x76 ^ 0x25 ^ 0x10 ^ -" ".length())) >= "   ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIllIlIlIlIllIIIl);
  }
  
  public Item getItem(World llllllllllllllIlIllIlIllIIIIIlIl, BlockPos llllllllllllllIlIllIlIllIIIIIlII)
  {
    return Item.getItemFromBlock(Blocks.stone_slab2);
  }
  
  protected BlockState createBlockState()
  {
    ;
    if (llIIIlllllIlll(llllllllllllllIlIllIlIlIllIlIIll.isDouble()))
    {
      new BlockState(llllllllllllllIlIllIlIlIllIlIlII, tmp33_23);
      "".length();
      if (null == null) {
        break label94;
      }
      return null;
    }
    label94:
    return new BlockState(llllllllllllllIlIllIlIlIllIlIlII, new IProperty[] { HALF, VARIANT });
  }
  
  public Object getVariant(ItemStack llllllllllllllIlIllIlIlIlllllIIl)
  {
    ;
    return EnumType.byMetadata(llllllllllllllIlIllIlIlIlllllIIl.getMetadata() & lIIIIIlIIllIl[4]);
  }
  
  private static boolean llIIIllllllIII(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllIlIllIlIlIlIIIllIl;
    return ??? != localObject;
  }
  
  static
  {
    llIIIlllllIllI();
    llIIIlllllIlIl();
    SEAMLESS = PropertyBool.create(lIIIIIlIIllII[lIIIIIlIIllIl[0]]);
  }
  
  public IProperty<?> getVariantProperty()
  {
    return VARIANT;
  }
  
  private static boolean llIIIlllllIlll(int ???)
  {
    short llllllllllllllIlIllIlIlIlIIIIlll;
    return ??? != 0;
  }
  
  private static boolean llIIIllllllIll(Object ???, Object arg1)
  {
    Object localObject;
    double llllllllllllllIlIllIlIlIlIIIlIIl;
    return ??? == localObject;
  }
  
  public void getSubBlocks(Item llllllllllllllIlIllIlIlIlllIllIl, CreativeTabs llllllllllllllIlIllIlIlIllllIIII, List<ItemStack> llllllllllllllIlIllIlIlIlllIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIIllllllIII(llllllllllllllIlIllIlIlIlllIllIl, Item.getItemFromBlock(Blocks.double_stone_slab2)))
    {
      llllllllllllllIlIllIlIlIlllIlIIl = (llllllllllllllIlIllIlIlIlllIlIII = EnumType.values()).length;
      llllllllllllllIlIllIlIlIlllIlIlI = lIIIIIlIIllIl[0];
      "".length();
      if ("  ".length() <= -" ".length()) {
        return;
      }
      while (!llIIIllllllIIl(llllllllllllllIlIllIlIlIlllIlIlI, llllllllllllllIlIllIlIlIlllIlIIl))
      {
        EnumType llllllllllllllIlIllIlIlIlllIlllI = llllllllllllllIlIllIlIlIlllIlIII[llllllllllllllIlIllIlIlIlllIlIlI];
        new ItemStack(llllllllllllllIlIllIlIlIlllIllIl, lIIIIIlIIllIl[1], llllllllllllllIlIllIlIlIlllIlllI.getMetadata());
        "".length();
      }
    }
  }
  
  public String getLocalizedName()
  {
    ;
    return StatCollector.translateToLocal(String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlIllIlIllIIIIlIll.getUnlocalizedName())).append(lIIIIIlIIllII[lIIIIIlIIllIl[2]])));
  }
  
  private static String llIIIlllllIlII(String llllllllllllllIlIllIlIlIlIIlllII, String llllllllllllllIlIllIlIlIlIIlllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIllIlIlIlIlIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIllIlIlIlIIlllIl.getBytes(StandardCharsets.UTF_8)), lIIIIIlIIllIl[5]), "DES");
      Cipher llllllllllllllIlIllIlIlIlIlIIIII = Cipher.getInstance("DES");
      llllllllllllllIlIllIlIlIlIlIIIII.init(lIIIIIlIIllIl[2], llllllllllllllIlIllIlIlIlIlIIIIl);
      return new String(llllllllllllllIlIllIlIlIlIlIIIII.doFinal(Base64.getDecoder().decode(llllllllllllllIlIllIlIlIlIIlllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIllIlIlIlIIlllll)
    {
      llllllllllllllIlIllIlIlIlIIlllll.printStackTrace();
    }
    return null;
  }
  
  public int damageDropped(IBlockState llllllllllllllIlIllIlIlIllIIlIll)
  {
    ;
    return ((EnumType)llllllllllllllIlIllIlIlIllIIlIll.getValue(VARIANT)).getMetadata();
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    private static boolean llIIlIIIllllI(int ???, int arg1)
    {
      int i;
      long llllllllllllllllIIIIIIIllIIllIlI;
      return ??? < i;
    }
    
    public static EnumType byMetadata(int llllllllllllllllIIIIIIIlllIlIlIl)
    {
      ;
      if ((!llIIlIIIlllIl(llllllllllllllllIIIIIIIlllIlIlIl)) || (llIIlIIIlllII(llllllllllllllllIIIIIIIlllIlIllI, META_LOOKUP.length))) {
        llllllllllllllllIIIIIIIlllIlIllI = lIIIIIIllIII[0];
      }
      return META_LOOKUP[llllllllllllllllIIIIIIIlllIlIllI];
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private static void llIIlIIIlIIIl()
    {
      lIIIIIIlIIIl = new String[lIIIIIIllIII[2]];
      lIIIIIIlIIIl[lIIIIIIllIII[0]] = llIIlIIIIllll("3FbepbaS0h86fMdnSYGbnA==", "zUtRs");
      lIIIIIIlIIIl[lIIIIIIllIII[1]] = llIIlIIIlIIII("HjMjJzoNOCMLPQM4Ig==", "lVGxI");
    }
    
    private static void llIIlIIIllIll()
    {
      lIIIIIIllIII = new int[4];
      lIIIIIIllIII[0] = ((0x8B ^ 0x91) & (0x21 ^ 0x3B ^ 0xFFFFFFFF));
      lIIIIIIllIII[1] = " ".length();
      lIIIIIIllIII[2] = "  ".length();
      lIIIIIIllIII[3] = (0x6B ^ 0x63);
    }
    
    public MapColor func_181068_c()
    {
      ;
      return field_181069_e;
    }
    
    private EnumType(int llllllllllllllllIIIIIIIllllIlIIl, String llllllllllllllllIIIIIIIllllIIIlI, MapColor llllllllllllllllIIIIIIIllllIIlll)
    {
      meta = llllllllllllllllIIIIIIIllllIlIIl;
      name = llllllllllllllllIIIIIIIllllIIIlI;
      field_181069_e = llllllllllllllllIIIIIIIllllIIlll;
    }
    
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    private static boolean llIIlIIIlllIl(int ???)
    {
      byte llllllllllllllllIIIIIIIllIIllIII;
      return ??? >= 0;
    }
    
    private static String llIIlIIIlIIII(String llllllllllllllllIIIIIIIllIllllII, String llllllllllllllllIIIIIIIllIlllIll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllllIIIIIIIllIllllII = new String(Base64.getDecoder().decode(llllllllllllllllIIIIIIIllIllllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllllIIIIIIIllIlllIlI = new StringBuilder();
      char[] llllllllllllllllIIIIIIIllIlllIIl = llllllllllllllllIIIIIIIllIlllIll.toCharArray();
      int llllllllllllllllIIIIIIIllIlllIII = lIIIIIIllIII[0];
      long llllllllllllllllIIIIIIIllIllIIlI = llllllllllllllllIIIIIIIllIllllII.toCharArray();
      short llllllllllllllllIIIIIIIllIllIIIl = llllllllllllllllIIIIIIIllIllIIlI.length;
      int llllllllllllllllIIIIIIIllIllIIII = lIIIIIIllIII[0];
      while (llIIlIIIllllI(llllllllllllllllIIIIIIIllIllIIII, llllllllllllllllIIIIIIIllIllIIIl))
      {
        char llllllllllllllllIIIIIIIllIllllIl = llllllllllllllllIIIIIIIllIllIIlI[llllllllllllllllIIIIIIIllIllIIII];
        "".length();
        "".length();
        if (((92 + 'È' - 90 + 32 ^ '' + 12 - 101 + 127) & (0x94 ^ 0xB4 ^ 0xE2 ^ 0x86 ^ -" ".length())) == "   ".length()) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllllIIIIIIIllIlllIlI);
    }
    
    public String getUnlocalizedName()
    {
      ;
      return name;
    }
    
    private static boolean llIIlIIIlllII(int ???, int arg1)
    {
      int i;
      boolean llllllllllllllllIIIIIIIllIIllllI;
      return ??? >= i;
    }
    
    private static String llIIlIIIIllll(String llllllllllllllllIIIIIIIllIlIIlIl, String llllllllllllllllIIIIIIIllIlIIllI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllllIIIIIIIllIlIlIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIIIIIIllIlIIllI.getBytes(StandardCharsets.UTF_8)), lIIIIIIllIII[3]), "DES");
        Cipher llllllllllllllllIIIIIIIllIlIlIIl = Cipher.getInstance("DES");
        llllllllllllllllIIIIIIIllIlIlIIl.init(lIIIIIIllIII[2], llllllllllllllllIIIIIIIllIlIlIlI);
        return new String(llllllllllllllllIIIIIIIllIlIlIIl.doFinal(Base64.getDecoder().decode(llllllllllllllllIIIIIIIllIlIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllllIIIIIIIllIlIlIII)
      {
        llllllllllllllllIIIIIIIllIlIlIII.printStackTrace();
      }
      return null;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    static
    {
      llIIlIIIllIll();
      llIIlIIIlIIIl();
      Exception llllllllllllllllIIIIIIIlllllIIIl;
      float llllllllllllllllIIIIIIIlllllIlII;
      RED_SANDSTONE = new EnumType(lIIIIIIlIIIl[lIIIIIIllIII[0]], lIIIIIIllIII[0], lIIIIIIllIII[0], lIIIIIIlIIIl[lIIIIIIllIII[1]], BlockSand.EnumType.RED_SAND.getMapColor());
      ENUM$VALUES = new EnumType[] { RED_SANDSTONE };
      META_LOOKUP = new EnumType[values().length];
      char llllllllllllllllIIIIIIIlllllIIlI = (llllllllllllllllIIIIIIIlllllIIIl = values()).length;
      long llllllllllllllllIIIIIIIlllllIIll = lIIIIIIllIII[0];
      "".length();
      if (" ".length() > (0x8B ^ 0x8F ^ (0x2E ^ 0x5) & (0xA7 ^ 0x8C ^ 0xFFFFFFFF))) {
        return;
      }
      while (!llIIlIIIlllII(llllllllllllllllIIIIIIIlllllIIll, llllllllllllllllIIIIIIIlllllIIlI))
      {
        EnumType llllllllllllllllIIIIIIIlllllIlIl = llllllllllllllllIIIIIIIlllllIIIl[llllllllllllllllIIIIIIIlllllIIll];
        META_LOOKUP[llllllllllllllllIIIIIIIlllllIlIl.getMetadata()] = llllllllllllllllIIIIIIIlllllIlIl;
        llllllllllllllllIIIIIIIlllllIIll++;
      }
    }
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.StatCollector;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.WorldGenBigTree;
import net.minecraft.world.gen.feature.WorldGenCanopyTree;
import net.minecraft.world.gen.feature.WorldGenForest;
import net.minecraft.world.gen.feature.WorldGenMegaJungle;
import net.minecraft.world.gen.feature.WorldGenMegaPineTree;
import net.minecraft.world.gen.feature.WorldGenSavannaTree;
import net.minecraft.world.gen.feature.WorldGenTaiga2;
import net.minecraft.world.gen.feature.WorldGenTrees;
import net.minecraft.world.gen.feature.WorldGenerator;

public class BlockSapling
  extends BlockBush
  implements IGrowable
{
  private boolean func_181624_a(World lllllllllllllllllIlIlllIlIllIIll, BlockPos lllllllllllllllllIlIlllIlIlIllII, int lllllllllllllllllIlIlllIlIllIIIl, int lllllllllllllllllIlIlllIlIllIIII, BlockPlanks.EnumType lllllllllllllllllIlIlllIlIlIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((llIlIlIllIll(lllllllllllllllllIlIlllIlIlIlllI.isTypeAt(lllllllllllllllllIlIlllIlIllIIll, lllllllllllllllllIlIlllIlIlIllII.add(lllllllllllllllllIlIlllIlIllIIIl, lIIIIlIIlIl[0], lllllllllllllllllIlIlllIlIllIIII), lllllllllllllllllIlIlllIlIlIllll))) && (llIlIlIllIll(lllllllllllllllllIlIlllIlIlIlllI.isTypeAt(lllllllllllllllllIlIlllIlIllIIll, lllllllllllllllllIlIlllIlIlIllII.add(lllllllllllllllllIlIlllIlIllIIIl + lIIIIlIIlIl[1], lIIIIlIIlIl[0], lllllllllllllllllIlIlllIlIllIIII), lllllllllllllllllIlIlllIlIlIllll))) && (llIlIlIllIll(lllllllllllllllllIlIlllIlIlIlllI.isTypeAt(lllllllllllllllllIlIlllIlIllIIll, lllllllllllllllllIlIlllIlIlIllII.add(lllllllllllllllllIlIlllIlIllIIIl, lIIIIlIIlIl[0], lllllllllllllllllIlIlllIlIllIIII + lIIIIlIIlIl[1]), lllllllllllllllllIlIlllIlIlIllll))) && (llIlIlIllIll(lllllllllllllllllIlIlllIlIlIlllI.isTypeAt(lllllllllllllllllIlIlllIlIllIIll, lllllllllllllllllIlIlllIlIlIllII.add(lllllllllllllllllIlIlllIlIllIIIl + lIIIIlIIlIl[1], lIIIIlIIlIl[0], lllllllllllllllllIlIlllIlIllIIII + lIIIIlIIlIl[1]), lllllllllllllllllIlIlllIlIlIllll)))) {
      return lIIIIlIIlIl[1];
    }
    return lIIIIlIIlIl[0];
  }
  
  private static int llIlllIIIlII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean llIlIlIlllII(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllllIlIlllIIIIllllI;
    return ??? < i;
  }
  
  private static String llIIlIIIIIlI(String lllllllllllllllllIlIlllIIIlIlllI, String lllllllllllllllllIlIlllIIIlIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIlIlllIIIlIlllI = new String(Base64.getDecoder().decode(lllllllllllllllllIlIlllIIIlIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIlIlllIIIllIIIl = new StringBuilder();
    char[] lllllllllllllllllIlIlllIIIllIIII = lllllllllllllllllIlIlllIIIlIllIl.toCharArray();
    int lllllllllllllllllIlIlllIIIlIllll = lIIIIlIIlIl[0];
    Exception lllllllllllllllllIlIlllIIIlIlIIl = lllllllllllllllllIlIlllIIIlIlllI.toCharArray();
    Exception lllllllllllllllllIlIlllIIIlIlIII = lllllllllllllllllIlIlllIIIlIlIIl.length;
    float lllllllllllllllllIlIlllIIIlIIlll = lIIIIlIIlIl[0];
    while (llIlIlIlllII(lllllllllllllllllIlIlllIIIlIIlll, lllllllllllllllllIlIlllIIIlIlIII))
    {
      char lllllllllllllllllIlIlllIIIllIlII = lllllllllllllllllIlIlllIIIlIlIIl[lllllllllllllllllIlIlllIIIlIIlll];
      "".length();
      "".length();
      if ((0xB9 ^ 0xBC) == 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIlIlllIIIllIIIl);
  }
  
  public void getSubBlocks(Item lllllllllllllllllIlIlllIlIIIlIlI, CreativeTabs lllllllllllllllllIlIlllIlIIIllIl, List<ItemStack> lllllllllllllllllIlIlllIlIIIlIIl)
  {
    ;
    ;
    ;
    ;
    char lllllllllllllllllIlIlllIlIIIIllI = (lllllllllllllllllIlIlllIlIIIIlIl = BlockPlanks.EnumType.values()).length;
    int lllllllllllllllllIlIlllIlIIIIlll = lIIIIlIIlIl[0];
    "".length();
    if (-" ".length() != -" ".length()) {
      return;
    }
    while (!llIlIlIllIlI(lllllllllllllllllIlIlllIlIIIIlll, lllllllllllllllllIlIlllIlIIIIllI))
    {
      BlockPlanks.EnumType lllllllllllllllllIlIlllIlIIIlIll = lllllllllllllllllIlIlllIlIIIIlIl[lllllllllllllllllIlIlllIlIIIIlll];
      new ItemStack(lllllllllllllllllIlIlllIlIIIlIlI, lIIIIlIIlIl[1], lllllllllllllllllIlIlllIlIIIlIll.getMetadata());
      "".length();
    }
  }
  
  static
  {
    llIlIlIllIII();
    llIIlIIIIlII();
  }
  
  private static void llIlIlIllIII()
  {
    lIIIIlIIlIl = new int[13];
    lIIIIlIIlIl[0] = ((0xA5 ^ 0xC3 ^ 0xDB ^ 0xB8) & (0x52 ^ 0x73 ^ 0xF ^ 0x2B ^ -" ".length()));
    lIIIIlIIlIl[1] = " ".length();
    lIIIIlIIlIl[2] = "  ".length();
    lIIIIlIIlIl[3] = "   ".length();
    lIIIIlIIlIl[4] = (0x93 ^ 0x9A);
    lIIIIlIIlIl[5] = (0x65 ^ 0x3C ^ 0x3E ^ 0x60);
    lIIIIlIIlIl[6] = (0x89 ^ 0x8D);
    lIIIIlIIlIl[7] = (0x1F ^ 0x15);
    lIIIIlIIlIl[8] = (-" ".length());
    lIIIIlIIlIl[9] = (0xC ^ 0x18);
    lIIIIlIIlIl[10] = (0x43 ^ 0x6C ^ 0xAE ^ 0x89);
    lIIIIlIIlIl[11] = (0x5A ^ 0x5F);
    lIIIIlIIlIl[12] = (0x3D ^ 0x3B);
  }
  
  public boolean canUseBonemeal(World lllllllllllllllllIlIlllIIlllllIl, Random lllllllllllllllllIlIlllIIlllllII, BlockPos lllllllllllllllllIlIlllIIllllIll, IBlockState lllllllllllllllllIlIlllIIllllIlI)
  {
    ;
    if (llIlllIIIlIl(llIlllIIIlII(rand.nextFloat(), 0.45D))) {
      return lIIIIlIIlIl[1];
    }
    return lIIIIlIIlIl[0];
  }
  
  private static boolean llIlllIIIIll(Object ???, Object arg1)
  {
    Object localObject;
    double lllllllllllllllllIlIlllIIIIllIlI;
    return ??? == localObject;
  }
  
  public void grow(World lllllllllllllllllIlIlllIlllIIlIl, BlockPos lllllllllllllllllIlIlllIllIlllll, IBlockState lllllllllllllllllIlIlllIllIllllI, Random lllllllllllllllllIlIlllIlllIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIlIlIllIIl(((Integer)lllllllllllllllllIlIlllIllIllllI.getValue(STAGE)).intValue()))
    {
      "".length();
      "".length();
      if (((0x39 ^ 0x3C) & (0x5E ^ 0x5B ^ 0xFFFFFFFF)) < " ".length()) {}
    }
    else
    {
      lllllllllllllllllIlIlllIlllIIllI.generateTree(lllllllllllllllllIlIlllIlllIIlIl, lllllllllllllllllIlIlllIlllIIlII, lllllllllllllllllIlIlllIllIllllI, lllllllllllllllllIlIlllIlllIIIlI);
    }
  }
  
  private static boolean llIlllIIIllI(Object ???)
  {
    byte lllllllllllllllllIlIlllIIIIllIII;
    return ??? != null;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllllIlIlllIIlIllIll, new IProperty[] { TYPE, STAGE });
  }
  
  private static boolean llIlllIIIlIl(int ???)
  {
    float lllllllllllllllllIlIlllIIIIlIIlI;
    return ??? < 0;
  }
  
  private static boolean llIlIlIllIlI(int ???, int arg1)
  {
    int i;
    float lllllllllllllllllIlIlllIIIlIIIlI;
    return ??? >= i;
  }
  
  public void generateTree(World lllllllllllllllllIlIlllIllIlIIII, BlockPos lllllllllllllllllIlIlllIllIIIIll, IBlockState lllllllllllllllllIlIlllIllIIlllI, Random lllllllllllllllllIlIlllIllIIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIlIlIllIIl(lllllllllllllllllIlIlllIllIIIIIl.nextInt(lIIIIlIIlIl[7])))
    {
      new WorldGenBigTree(lIIIIlIIlIl[1]);
      "".length();
      if ((0x5C ^ 0x4D ^ 0x41 ^ 0x54) == (0x61 ^ 0x27 ^ 0x5E ^ 0x1C)) {
        break label73;
      }
    }
    label73:
    WorldGenerator lllllllllllllllllIlIlllIllIIllII = new WorldGenTrees(lIIIIlIIlIl[1]);
    int lllllllllllllllllIlIlllIllIIlIll = lIIIIlIIlIl[0];
    int lllllllllllllllllIlIlllIllIIlIlI = lIIIIlIIlIl[0];
    boolean lllllllllllllllllIlIlllIllIIlIIl = lIIIIlIIlIl[0];
    switch ($SWITCH_TABLE$net$minecraft$block$BlockPlanks$EnumType()[((BlockPlanks.EnumType)lllllllllllllllllIlIlllIllIIlllI.getValue(TYPE)).ordinal()])
    {
    case 2: 
      lllllllllllllllllIlIlllIllIIlIll = lIIIIlIIlIl[0];
      "".length();
      if (-" ".length() < -" ".length()) {
        return;
      }
      while (!llIlIlIlllII(lllllllllllllllllIlIlllIllIIlIll, lIIIIlIIlIl[8]))
      {
        lllllllllllllllllIlIlllIllIIlIlI = lIIIIlIIlIl[0];
        "".length();
        if ((121 + 53 - 110 + 117 ^ 77 + 30 - -31 + 39) == "  ".length()) {
          return;
        }
        while (!llIlIlIlllII(lllllllllllllllllIlIlllIllIIlIlI, lIIIIlIIlIl[8]))
        {
          if (llIlIlIllIll(lllllllllllllllllIlIlllIllIlIIIl.func_181624_a(lllllllllllllllllIlIlllIllIlIIII, lllllllllllllllllIlIlllIllIIllll, lllllllllllllllllIlIlllIllIIlIll, lllllllllllllllllIlIlllIllIIlIlI, BlockPlanks.EnumType.SPRUCE)))
          {
            lllllllllllllllllIlIlllIllIIllII = new WorldGenMegaPineTree(lIIIIlIIlIl[0], lllllllllllllllllIlIlllIllIIIIIl.nextBoolean());
            lllllllllllllllllIlIlllIllIIlIIl = lIIIIlIIlIl[1];
            "".length();
            if ("   ".length() >= 0) {
              break;
            }
            return;
          }
          lllllllllllllllllIlIlllIllIIlIlI--;
        }
      }
      if (llIlIlIllIIl(lllllllllllllllllIlIlllIllIIlIIl))
      {
        lllllllllllllllllIlIlllIllIIlIlI = lIIIIlIIlIl[0];
        lllllllllllllllllIlIlllIllIIlIll = lIIIIlIIlIl[0];
        lllllllllllllllllIlIlllIllIIllII = new WorldGenTaiga2(lIIIIlIIlIl[1]);
        "".length();
        if (-(0x7B ^ 0x7F) > 0) {
          return;
        }
      }
      break;
    case 3: 
      lllllllllllllllllIlIlllIllIIllII = new WorldGenForest(lIIIIlIIlIl[1], lIIIIlIIlIl[0]);
      "".length();
      if ("  ".length() == (0x9 ^ 0xD)) {
        return;
      }
      break;
    case 4: 
      IBlockState lllllllllllllllllIlIlllIllIIlIII = Blocks.log.getDefaultState().withProperty(BlockOldLog.VARIANT, BlockPlanks.EnumType.JUNGLE);
      IBlockState lllllllllllllllllIlIlllIllIIIlll = Blocks.leaves.getDefaultState().withProperty(BlockOldLeaf.VARIANT, BlockPlanks.EnumType.JUNGLE).withProperty(BlockLeaves.CHECK_DECAY, Boolean.valueOf(lIIIIlIIlIl[0]));
      lllllllllllllllllIlIlllIllIIlIll = lIIIIlIIlIl[0];
      "".length();
      if (null != null) {
        return;
      }
      while (!llIlIlIlllII(lllllllllllllllllIlIlllIllIIlIll, lIIIIlIIlIl[8]))
      {
        lllllllllllllllllIlIlllIllIIlIlI = lIIIIlIIlIl[0];
        "".length();
        if (-"   ".length() >= 0) {
          return;
        }
        while (!llIlIlIlllII(lllllllllllllllllIlIlllIllIIlIlI, lIIIIlIIlIl[8]))
        {
          if (llIlIlIllIll(lllllllllllllllllIlIlllIllIlIIIl.func_181624_a(lllllllllllllllllIlIlllIllIlIIII, lllllllllllllllllIlIlllIllIIllll, lllllllllllllllllIlIlllIllIIlIll, lllllllllllllllllIlIlllIllIIlIlI, BlockPlanks.EnumType.JUNGLE)))
          {
            lllllllllllllllllIlIlllIllIIllII = new WorldGenMegaJungle(lIIIIlIIlIl[1], lIIIIlIIlIl[7], lIIIIlIIlIl[9], lllllllllllllllllIlIlllIllIIlIII, lllllllllllllllllIlIlllIllIIIlll);
            lllllllllllllllllIlIlllIllIIlIIl = lIIIIlIIlIl[1];
            "".length();
            if (" ".length() > 0) {
              break;
            }
            return;
          }
          lllllllllllllllllIlIlllIllIIlIlI--;
        }
      }
      if (llIlIlIllIIl(lllllllllllllllllIlIlllIllIIlIIl))
      {
        lllllllllllllllllIlIlllIllIIlIlI = lIIIIlIIlIl[0];
        lllllllllllllllllIlIlllIllIIlIll = lIIIIlIIlIl[0];
        lllllllllllllllllIlIlllIllIIllII = new WorldGenTrees(lIIIIlIIlIl[1], lIIIIlIIlIl[6] + lllllllllllllllllIlIlllIllIIIIIl.nextInt(lIIIIlIIlIl[5]), lllllllllllllllllIlIlllIllIIlIII, lllllllllllllllllIlIlllIllIIIlll, lIIIIlIIlIl[0]);
        "".length();
        if ((0x3E ^ 0x5D ^ 0xDD ^ 0xBB) == 0) {
          return;
        }
      }
      break;
    case 5: 
      lllllllllllllllllIlIlllIllIIllII = new WorldGenSavannaTree(lIIIIlIIlIl[1]);
      "".length();
      if ("   ".length() != "   ".length()) {
        return;
      }
      break;
    case 6: 
      lllllllllllllllllIlIlllIllIIlIll = lIIIIlIIlIl[0];
      "".length();
      if (-"   ".length() >= 0) {
        return;
      }
      while (!llIlIlIlllII(lllllllllllllllllIlIlllIllIIlIll, lIIIIlIIlIl[8]))
      {
        lllllllllllllllllIlIlllIllIIlIlI = lIIIIlIIlIl[0];
        "".length();
        if (((0x2F ^ 0x18 ^ 0x8B ^ 0xA7) & (0xB0 ^ 0x96 ^ 0x35 ^ 0x8 ^ -" ".length())) != ((0xA6 ^ 0xB2 ^ 0xB1 ^ 0x85) & (0x36 ^ 0x7E ^ 0xCA ^ 0xA2 ^ -" ".length()))) {
          return;
        }
        while (!llIlIlIlllII(lllllllllllllllllIlIlllIllIIlIlI, lIIIIlIIlIl[8]))
        {
          if (llIlIlIllIll(lllllllllllllllllIlIlllIllIlIIIl.func_181624_a(lllllllllllllllllIlIlllIllIlIIII, lllllllllllllllllIlIlllIllIIllll, lllllllllllllllllIlIlllIllIIlIll, lllllllllllllllllIlIlllIllIIlIlI, BlockPlanks.EnumType.DARK_OAK)))
          {
            lllllllllllllllllIlIlllIllIIllII = new WorldGenCanopyTree(lIIIIlIIlIl[1]);
            lllllllllllllllllIlIlllIllIIlIIl = lIIIIlIIlIl[1];
            "".length();
            if ((0xE9 ^ 0xC0 ^ 0x7B ^ 0x56) > ((62 + '' - 53 + 76 ^ 32 + '' - 127 + 142) & (10 + 5 - -56 + 169 ^ 27 + 49 - -36 + 71 ^ -" ".length()))) {
              break;
            }
            return;
          }
          lllllllllllllllllIlIlllIllIIlIlI--;
        }
      }
      if (llIlIlIllIIl(lllllllllllllllllIlIlllIllIIlIIl)) {
        return;
      }
      break;
    }
    IBlockState lllllllllllllllllIlIlllIllIIIllI = ;;
    if (llIlIlIllIll(lllllllllllllllllIlIlllIllIIlIIl))
    {
      "".length();
      "".length();
      "".length();
      "".length();
      "".length();
      if (((0x3E ^ 0x2) & (0x17 ^ 0x2B ^ 0xFFFFFFFF)) <= " ".length()) {}
    }
    else
    {
      "".length();
    }
    if (llIlIlIllIIl(lllllllllllllllllIlIlllIllIIllII.generate(lllllllllllllllllIlIlllIllIlIIII, lllllllllllllllllIlIlllIllIIIIIl, lllllllllllllllllIlIlllIllIIllll.add(lllllllllllllllllIlIlllIllIIlIll, lIIIIlIIlIl[0], lllllllllllllllllIlIlllIllIIlIlI)))) {
      if (llIlIlIllIll(lllllllllllllllllIlIlllIllIIlIIl))
      {
        "".length();
        "".length();
        "".length();
        "".length();
        "".length();
        if (null == null) {}
      }
      else
      {
        "".length();
      }
    }
  }
  
  public int damageDropped(IBlockState lllllllllllllllllIlIlllIlIIlIllI)
  {
    ;
    return ((BlockPlanks.EnumType)lllllllllllllllllIlIlllIlIIlIllI.getValue(TYPE)).getMetadata();
  }
  
  public boolean isTypeAt(World lllllllllllllllllIlIlllIlIIlllIl, BlockPos lllllllllllllllllIlIlllIlIlIIIIl, BlockPlanks.EnumType lllllllllllllllllIlIlllIlIIllIll)
  {
    ;
    ;
    ;
    ;
    ;
    IBlockState lllllllllllllllllIlIlllIlIIlllll = lllllllllllllllllIlIlllIlIIlllIl.getBlockState(lllllllllllllllllIlIlllIlIlIIIIl);
    if ((llIlllIIIIll(lllllllllllllllllIlIlllIlIIlllll.getBlock(), lllllllllllllllllIlIlllIlIIllllI)) && (llIlllIIIIll(lllllllllllllllllIlIlllIlIIlllll.getValue(TYPE), lllllllllllllllllIlIlllIlIIllIll))) {
      return lIIIIlIIlIl[1];
    }
    return lIIIIlIIlIl[0];
  }
  
  public void grow(World lllllllllllllllllIlIlllIIlllIIlI, Random lllllllllllllllllIlIlllIIlllIIIl, BlockPos lllllllllllllllllIlIlllIIllIlIll, IBlockState lllllllllllllllllIlIlllIIllIllll)
  {
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIlIlllIIlllIIll.grow(lllllllllllllllllIlIlllIIlllIIlI, lllllllllllllllllIlIlllIIllIlIll, lllllllllllllllllIlIlllIIllIllll, lllllllllllllllllIlIlllIIllIllII);
  }
  
  private static void llIIlIIIIlII()
  {
    llllllIIIl = new String[lIIIIlIIlIl[6]];
    llllllIIIl[lIIIIlIIlIl[0]] = llIIlIIIIIIl("D2L3HkFVLwM=", "NroVM");
    llllllIIIl[lIIIIlIIlIl[1]] = llIIlIIIIIlI("BTcmLjU=", "vCGIP");
    llllllIIIl[lIIIIlIIlIl[2]] = llIIlIIIIIIl("xVVR9TYGbvg=", "OSHbT");
    llllllIIIl[lIIIIlIIlIl[3]] = llIIlIIIIIll("OZwO0W4+7/o=", "tParT");
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllllIlIlllIIllIIlII)
  {
    ;
    ;
    return lllllllllllllllllIlIlllIIllIIlll.getDefaultState().withProperty(TYPE, BlockPlanks.EnumType.byMetadata(lllllllllllllllllIlIlllIIllIIlII & lIIIIlIIlIl[5])).withProperty(STAGE, Integer.valueOf((lllllllllllllllllIlIlllIIllIIlII & lIIIIlIIlIl[10]) >> lIIIIlIIlIl[3]));
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllllIlIlllIIllIIIII)
  {
    ;
    ;
    int lllllllllllllllllIlIlllIIlIlllll = lIIIIlIIlIl[0];
    lllllllllllllllllIlIlllIIlIlllll |= ((BlockPlanks.EnumType)lllllllllllllllllIlIlllIIlIllllI.getValue(TYPE)).getMetadata();
    lllllllllllllllllIlIlllIIlIlllll |= ((Integer)lllllllllllllllllIlIlllIIlIllllI.getValue(STAGE)).intValue() << lIIIIlIIlIl[3];
    return lllllllllllllllllIlIlllIIlIlllll;
  }
  
  protected BlockSapling()
  {
    lllllllllllllllllIlIllllIIIIIIIl.setDefaultState(blockState.getBaseState().withProperty(TYPE, BlockPlanks.EnumType.OAK).withProperty(STAGE, Integer.valueOf(lIIIIlIIlIl[0])));
    float lllllllllllllllllIlIllllIIIIIIII = 0.4F;
    lllllllllllllllllIlIllllIIIIIIIl.setBlockBounds(0.5F - lllllllllllllllllIlIllllIIIIIIII, 0.0F, 0.5F - lllllllllllllllllIlIllllIIIIIIII, 0.5F + lllllllllllllllllIlIllllIIIIIIII, lllllllllllllllllIlIllllIIIIIIII * 2.0F, 0.5F + lllllllllllllllllIlIllllIIIIIIII);
    "".length();
  }
  
  private static String llIIlIIIIIIl(String lllllllllllllllllIlIlllIIlIlIIII, String lllllllllllllllllIlIlllIIlIIllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIlIlllIIlIlIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIlllIIlIIllIl.getBytes(StandardCharsets.UTF_8)), lIIIIlIIlIl[10]), "DES");
      Cipher lllllllllllllllllIlIlllIIlIlIIlI = Cipher.getInstance("DES");
      lllllllllllllllllIlIlllIIlIlIIlI.init(lIIIIlIIlIl[2], lllllllllllllllllIlIlllIIlIlIIll);
      return new String(lllllllllllllllllIlIlllIIlIlIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIlllIIlIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIlIlllIIlIlIIIl)
    {
      lllllllllllllllllIlIlllIIlIlIIIl.printStackTrace();
    }
    return null;
  }
  
  public boolean canGrow(World lllllllllllllllllIlIlllIlIIIIIll, BlockPos lllllllllllllllllIlIlllIlIIIIIlI, IBlockState lllllllllllllllllIlIlllIlIIIIIIl, boolean lllllllllllllllllIlIlllIlIIIIIII)
  {
    return lIIIIlIIlIl[1];
  }
  
  private static String llIIlIIIIIll(String lllllllllllllllllIlIlllIIlIIIIIl, String lllllllllllllllllIlIlllIIlIIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIlIlllIIlIIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIlllIIlIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIlIlllIIlIIIlIl = Cipher.getInstance("Blowfish");
      lllllllllllllllllIlIlllIIlIIIlIl.init(lIIIIlIIlIl[2], lllllllllllllllllIlIlllIIlIIIllI);
      return new String(lllllllllllllllllIlIlllIIlIIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIlllIIlIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIlIlllIIlIIIlII)
    {
      lllllllllllllllllIlIlllIIlIIIlII.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIlIlIllIll(int ???)
  {
    long lllllllllllllllllIlIlllIIIIlIllI;
    return ??? != 0;
  }
  
  private static boolean llIlIlIllIIl(int ???)
  {
    double lllllllllllllllllIlIlllIIIIlIlII;
    return ??? == 0;
  }
  
  public String getLocalizedName()
  {
    ;
    return StatCollector.translateToLocal(String.valueOf(new StringBuilder(String.valueOf(lllllllllllllllllIlIlllIlllllIll.getUnlocalizedName())).append(llllllIIIl[lIIIIlIIlIl[2]]).append(BlockPlanks.EnumType.OAK.getUnlocalizedName()).append(llllllIIIl[lIIIIlIIlIl[3]])));
  }
  
  public void updateTick(World lllllllllllllllllIlIlllIllllIlII, BlockPos lllllllllllllllllIlIlllIlllIlllI, IBlockState lllllllllllllllllIlIlllIllllIIlI, Random lllllllllllllllllIlIlllIllllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIlIlIllIIl(isRemote))
    {
      lllllllllllllllllIlIlllIllllIlIl.updateTick(lllllllllllllllllIlIlllIllllIlII, lllllllllllllllllIlIlllIllllIIll, lllllllllllllllllIlIlllIllllIIlI, lllllllllllllllllIlIlllIllllIIIl);
      if ((llIlIlIllIlI(lllllllllllllllllIlIlllIllllIlII.getLightFromNeighbors(lllllllllllllllllIlIlllIllllIIll.up()), lIIIIlIIlIl[4])) && (llIlIlIllIIl(lllllllllllllllllIlIlllIllllIIIl.nextInt(lIIIIlIIlIl[5])))) {
        lllllllllllllllllIlIlllIllllIlIl.grow(lllllllllllllllllIlIlllIllllIlII, lllllllllllllllllIlIlllIllllIIll, lllllllllllllllllIlIlllIllllIIlI, lllllllllllllllllIlIlllIllllIIIl);
      }
    }
  }
}

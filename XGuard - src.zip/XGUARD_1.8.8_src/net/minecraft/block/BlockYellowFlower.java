package net.minecraft.block;

public class BlockYellowFlower
  extends BlockFlower
{
  public BlockYellowFlower() {}
  
  public BlockFlower.EnumFlowerColor getBlockType()
  {
    return BlockFlower.EnumFlowerColor.YELLOW;
  }
}

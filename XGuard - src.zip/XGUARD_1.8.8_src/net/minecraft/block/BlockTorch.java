package net.minecraft.block;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Iterator;
import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class BlockTorch
  extends Block
{
  private static boolean lIlIIIIlIIlI(int ???)
  {
    String lllllllllllllllllllIIllIllllllII;
    return ??? != 0;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  static
  {
    lIlIIIIlIIIl();
    lIlIIIIIIlII();
  }
  
  protected boolean checkForDrop(World lllllllllllllllllllIIlllllllllII, BlockPos lllllllllllllllllllIIllllllllIlI, IBlockState lllllllllllllllllllIIlllllllIIII)
  {
    ;
    ;
    ;
    ;
    if ((lIlIIIIllIll(lllllllllllllllllllIIlllllllIIII.getBlock(), lllllllllllllllllllIIllllllllllI)) && (lIlIIIIlIIlI(lllllllllllllllllllIIllllllllllI.canPlaceAt(lllllllllllllllllllIIlllllllllII, lllllllllllllllllllIIllllllllIlI, (EnumFacing)lllllllllllllllllllIIlllllllIIII.getValue(FACING))))) {
      return llIIlIllII[1];
    }
    if (lIlIIIIllIll(lllllllllllllllllllIIlllllllllII.getBlockState(lllllllllllllllllllIIllllllllIlI).getBlock(), lllllllllllllllllllIIllllllllllI))
    {
      lllllllllllllllllllIIllllllllllI.dropBlockAsItem(lllllllllllllllllllIIlllllllllII, lllllllllllllllllllIIllllllllIlI, lllllllllllllllllllIIlllllllIIII, llIIlIllII[0]);
      "".length();
    }
    return llIIlIllII[0];
  }
  
  public void onNeighborBlockChange(World lllllllllllllllllllIlIIIIIlllIII, BlockPos lllllllllllllllllllIlIIIIlIIIIII, IBlockState lllllllllllllllllllIlIIIIIllIlII, Block lllllllllllllllllllIlIIIIIllllII)
  {
    ;
    ;
    ;
    ;
    "".length();
  }
  
  public void randomDisplayTick(World lllllllllllllllllllIIllllIlIIIlI, BlockPos lllllllllllllllllllIIllllIIlIlIl, IBlockState lllllllllllllllllllIIllllIlIIIII, Random lllllllllllllllllllIIllllIIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing lllllllllllllllllllIIllllIIllllI = (EnumFacing)lllllllllllllllllllIIllllIlIIIII.getValue(FACING);
    double lllllllllllllllllllIIllllIIlllIl = lllllllllllllllllllIIllllIIlIlIl.getX() + 0.5D;
    double lllllllllllllllllllIIllllIIlllII = lllllllllllllllllllIIllllIIlIlIl.getY() + 0.7D;
    double lllllllllllllllllllIIllllIIllIll = lllllllllllllllllllIIllllIIlIlIl.getZ() + 0.5D;
    double lllllllllllllllllllIIllllIIllIlI = 0.22D;
    double lllllllllllllllllllIIllllIIllIIl = 0.27D;
    if (lIlIIIIlIIlI(lllllllllllllllllllIIllllIIllllI.getAxis().isHorizontal()))
    {
      EnumFacing lllllllllllllllllllIIllllIIllIII = lllllllllllllllllllIIllllIIllllI.getOpposite();
      lllllllllllllllllllIIllllIlIIIlI.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, lllllllllllllllllllIIllllIIlllIl + lllllllllllllllllllIIllllIIllIIl * lllllllllllllllllllIIllllIIllIII.getFrontOffsetX(), lllllllllllllllllllIIllllIIlllII + lllllllllllllllllllIIllllIIllIlI, lllllllllllllllllllIIllllIIllIll + lllllllllllllllllllIIllllIIllIIl * lllllllllllllllllllIIllllIIllIII.getFrontOffsetZ(), 0.0D, 0.0D, 0.0D, new int[llIIlIllII[0]]);
      lllllllllllllllllllIIllllIlIIIlI.spawnParticle(EnumParticleTypes.FLAME, lllllllllllllllllllIIllllIIlllIl + lllllllllllllllllllIIllllIIllIIl * lllllllllllllllllllIIllllIIllIII.getFrontOffsetX(), lllllllllllllllllllIIllllIIlllII + lllllllllllllllllllIIllllIIllIlI, lllllllllllllllllllIIllllIIllIll + lllllllllllllllllllIIllllIIllIIl * lllllllllllllllllllIIllllIIllIII.getFrontOffsetZ(), 0.0D, 0.0D, 0.0D, new int[llIIlIllII[0]]);
      "".length();
      if (null == null) {}
    }
    else
    {
      lllllllllllllllllllIIllllIlIIIlI.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, lllllllllllllllllllIIllllIIlllIl, lllllllllllllllllllIIllllIIlllII, lllllllllllllllllllIIllllIIllIll, 0.0D, 0.0D, 0.0D, new int[llIIlIllII[0]]);
      lllllllllllllllllllIIllllIlIIIlI.spawnParticle(EnumParticleTypes.FLAME, lllllllllllllllllllIIllllIIlllIl, lllllllllllllllllllIIllllIIlllII, lllllllllllllllllllIIllllIIllIll, 0.0D, 0.0D, 0.0D, new int[llIIlIllII[0]]);
    }
  }
  
  public void onBlockAdded(World lllllllllllllllllllIlIIIIlIlIIll, BlockPos lllllllllllllllllllIlIIIIlIlIIlI, IBlockState lllllllllllllllllllIlIIIIlIIllII)
  {
    ;
    ;
    ;
    ;
    "".length();
  }
  
  private static boolean lIlIIIIllIll(Object ???, Object arg1)
  {
    Object localObject;
    short lllllllllllllllllllIIlllIIIIIlII;
    return ??? == localObject;
  }
  
  protected boolean onNeighborChangeInternal(World lllllllllllllllllllIlIIIIIIllllI, BlockPos lllllllllllllllllllIlIIIIIIlllIl, IBlockState lllllllllllllllllllIlIIIIIlIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIIIIlIIll(lllllllllllllllllllIlIIIIIlIlIlI.checkForDrop(lllllllllllllllllllIlIIIIIIllllI, lllllllllllllllllllIlIIIIIIlllIl, lllllllllllllllllllIlIIIIIlIIlll))) {
      return llIIlIllII[1];
    }
    EnumFacing lllllllllllllllllllIlIIIIIlIIllI = (EnumFacing)lllllllllllllllllllIlIIIIIlIIlll.getValue(FACING);
    EnumFacing.Axis lllllllllllllllllllIlIIIIIlIIlIl = lllllllllllllllllllIlIIIIIlIIllI.getAxis();
    EnumFacing lllllllllllllllllllIlIIIIIlIIlII = lllllllllllllllllllIlIIIIIlIIllI.getOpposite();
    boolean lllllllllllllllllllIlIIIIIlIIIlI = llIIlIllII[0];
    if ((lIlIIIIlIIlI(lllllllllllllllllllIlIIIIIlIIlIl.isHorizontal())) && (lIlIIIIlIIll(lllllllllllllllllllIlIIIIIIllllI.isBlockNormalCube(lllllllllllllllllllIlIIIIIIlllIl.offset(lllllllllllllllllllIlIIIIIlIIlII), llIIlIllII[1]))))
    {
      lllllllllllllllllllIlIIIIIlIIIlI = llIIlIllII[1];
      "".length();
      if (-"  ".length() > 0) {
        return (0x3A ^ 0xD) & (0x0 ^ 0x37 ^ 0xFFFFFFFF);
      }
    }
    else if ((lIlIIIIlIIlI(lllllllllllllllllllIlIIIIIlIIlIl.isVertical())) && (lIlIIIIlIIll(lllllllllllllllllllIlIIIIIlIlIlI.canPlaceOn(lllllllllllllllllllIlIIIIIIllllI, lllllllllllllllllllIlIIIIIIlllIl.offset(lllllllllllllllllllIlIIIIIlIIlII)))))
    {
      lllllllllllllllllllIlIIIIIlIIIlI = llIIlIllII[1];
    }
    if (lIlIIIIlIIlI(lllllllllllllllllllIlIIIIIlIIIlI))
    {
      lllllllllllllllllllIlIIIIIlIlIlI.dropBlockAsItem(lllllllllllllllllllIlIIIIIIllllI, lllllllllllllllllllIlIIIIIIlllIl, lllllllllllllllllllIlIIIIIlIIlll, llIIlIllII[0]);
      "".length();
      return llIIlIllII[1];
    }
    return llIIlIllII[0];
  }
  
  private static boolean lIlIIIIlIIll(int ???)
  {
    short lllllllllllllllllllIIllIllllIlll;
    return ??? == 0;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllllllIIlllIlIlllII, new IProperty[] { FACING });
  }
  
  private static boolean lIlIIIlIIIIl(int ???, int arg1)
  {
    int i;
    long lllllllllllllllllllIIlllIIIlIlII;
    return ??? < i;
  }
  
  private static void lIlIIIIIIlII()
  {
    llIIlIlIIl = new String[llIIlIllII[1]];
    llIIlIlIIl[llIIlIllII[0]] = lIlIIIIIIIll("HiQhDD8f", "xEBeQ");
  }
  
  private boolean canPlaceOn(World lllllllllllllllllllIlIIIllIIIIll, BlockPos lllllllllllllllllllIlIIIlIllllll)
  {
    ;
    ;
    ;
    if (lIlIIIIlIIlI(World.doesBlockHaveSolidTopSurface(lllllllllllllllllllIlIIIllIIIIll, lllllllllllllllllllIlIIIlIllllll))) {
      return llIIlIllII[1];
    }
    Block lllllllllllllllllllIlIIIllIIIIIl = lllllllllllllllllllIlIIIllIIIIll.getBlockState(lllllllllllllllllllIlIIIlIllllll).getBlock();
    if ((lIlIIIIlIIll(lllllllllllllllllllIlIIIllIIIIIl instanceof BlockFence)) && (lIlIIIIlIlIl(lllllllllllllllllllIlIIIllIIIIIl, Blocks.glass)) && (lIlIIIIlIlIl(lllllllllllllllllllIlIIIllIIIIIl, Blocks.cobblestone_wall)) && (lIlIIIIlIlIl(lllllllllllllllllllIlIIIllIIIIIl, Blocks.stained_glass))) {
      return llIIlIllII[0];
    }
    return llIIlIllII[1];
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllllllIIllllIIIIIlI)
  {
    ;
    ;
    ;
    IBlockState lllllllllllllllllllIIllllIIIIllI = lllllllllllllllllllIIllllIIIIlII.getDefaultState();
    switch (lllllllllllllllllllIIllllIIIIIlI)
    {
    case '\001': 
      lllllllllllllllllllIIllllIIIIllI = lllllllllllllllllllIIllllIIIIllI.withProperty(FACING, EnumFacing.EAST);
      "".length();
      if (((0x4A ^ 0x70) & (0xA ^ 0x30 ^ 0xFFFFFFFF)) >= " ".length()) {
        return null;
      }
      break;
    case '\002': 
      lllllllllllllllllllIIllllIIIIllI = lllllllllllllllllllIIllllIIIIllI.withProperty(FACING, EnumFacing.WEST);
      "".length();
      if (-" ".length() > ((0x1D ^ 0x30) & (0xA6 ^ 0x8B ^ 0xFFFFFFFF))) {
        return null;
      }
      break;
    case '\003': 
      lllllllllllllllllllIIllllIIIIllI = lllllllllllllllllllIIllllIIIIllI.withProperty(FACING, EnumFacing.SOUTH);
      "".length();
      if (-" ".length() > "   ".length()) {
        return null;
      }
      break;
    case '\004': 
      lllllllllllllllllllIIllllIIIIllI = lllllllllllllllllllIIllllIIIIllI.withProperty(FACING, EnumFacing.NORTH);
      "".length();
      if (" ".length() < -" ".length()) {
        return null;
      }
      break;
    case '\005': 
    default: 
      lllllllllllllllllllIIllllIIIIllI = lllllllllllllllllllIIllllIIIIllI.withProperty(FACING, EnumFacing.UP);
    }
    return lllllllllllllllllllIIllllIIIIllI;
  }
  
  private static String lIlIIIIIIIll(String lllllllllllllllllllIIlllIIlIIlll, String lllllllllllllllllllIIlllIIlIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIIlllIIlIIlll = new String(Base64.getDecoder().decode(lllllllllllllllllllIIlllIIlIIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllllIIlllIIlIIlIl = new StringBuilder();
    char[] lllllllllllllllllllIIlllIIlIIlII = lllllllllllllllllllIIlllIIlIIllI.toCharArray();
    int lllllllllllllllllllIIlllIIlIIIll = llIIlIllII[0];
    String lllllllllllllllllllIIlllIIIlllIl = lllllllllllllllllllIIlllIIlIIlll.toCharArray();
    byte lllllllllllllllllllIIlllIIIlllII = lllllllllllllllllllIIlllIIIlllIl.length;
    double lllllllllllllllllllIIlllIIIllIll = llIIlIllII[0];
    while (lIlIIIlIIIIl(lllllllllllllllllllIIlllIIIllIll, lllllllllllllllllllIIlllIIIlllII))
    {
      char lllllllllllllllllllIIlllIIlIlIII = lllllllllllllllllllIIlllIIIlllIl[lllllllllllllllllllIIlllIIIllIll];
      "".length();
      "".length();
      if (((0x10 ^ 0xB ^ (0x60 ^ 0x46) & (0x7E ^ 0x58 ^ 0xFFFFFFFF)) & (0x21 ^ 0x51 ^ 0x7D ^ 0x16 ^ -" ".length())) >= "   ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllllIIlllIIlIIlIl);
  }
  
  public boolean isFullCube()
  {
    return llIIlIllII[0];
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllllllIIlllIllIlIII)
  {
    ;
    ;
    int lllllllllllllllllllIIlllIllIlIlI = llIIlIllII[0];
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[((EnumFacing)lllllllllllllllllllIIlllIllIllII.getValue(FACING)).ordinal()])
    {
    case 6: 
      lllllllllllllllllllIIlllIllIlIlI |= llIIlIllII[1];
      "".length();
      if (((0x4 ^ 0x4E) & (0x25 ^ 0x6F ^ 0xFFFFFFFF) & ((0x87 ^ 0x89) & (0x79 ^ 0x77 ^ 0xFFFFFFFF) ^ 0xFFFFFFFF)) < 0) {
        return (0x3B ^ 0x4) & (0xC ^ 0x33 ^ 0xFFFFFFFF);
      }
      break;
    case 5: 
      lllllllllllllllllllIIlllIllIlIlI |= llIIlIllII[2];
      "".length();
      if ((0x1 ^ 0x13 ^ 0x34 ^ 0x22) == 0) {
        return (88 + 47 - 44 + 140 ^ 60 + 35 - -11 + 80) & (0xCF ^ 0xB9 ^ 0xA2 ^ 0x89 ^ -" ".length());
      }
      break;
    case 4: 
      lllllllllllllllllllIIlllIllIlIlI |= llIIlIllII[3];
      "".length();
      if ((0xA1 ^ 0xBA ^ 0x51 ^ 0x4F) == 0) {
        return ('µ' + 36 - 82 + 69 ^ 118 + 81 - 166 + 111) & (0xE0 ^ 0xB3 ^ 0x7F ^ 0x70 ^ -" ".length());
      }
      break;
    case 3: 
      lllllllllllllllllllIIlllIllIlIlI |= llIIlIllII[4];
      "".length();
      if (null != null) {
        return (0xD3 ^ 0xB0 ^ 0xDB ^ 0x83) & (0x37 ^ 0x42 ^ 0x2B ^ 0x65 ^ -" ".length());
      }
      break;
    case 1: 
    case 2: 
    default: 
      lllllllllllllllllllIIlllIllIlIlI |= llIIlIllII[5];
    }
    return lllllllllllllllllllIIlllIllIlIlI;
  }
  
  private boolean canPlaceAt(World lllllllllllllllllllIlIIIlIIllllI, BlockPos lllllllllllllllllllIlIIIlIIlIIII, EnumFacing lllllllllllllllllllIlIIIlIIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    BlockPos lllllllllllllllllllIlIIIlIIllIII = lllllllllllllllllllIlIIIlIIlIIII.offset(lllllllllllllllllllIlIIIlIIIlllI.getOpposite());
    boolean lllllllllllllllllllIlIIIlIIlIllI = lllllllllllllllllllIlIIIlIIIlllI.getAxis().isHorizontal();
    if (((!lIlIIIIlIIlI(lllllllllllllllllllIlIIIlIIlIllI)) || (lIlIIIIlIIll(lllllllllllllllllllIlIIIlIIllllI.isBlockNormalCube(lllllllllllllllllllIlIIIlIIllIII, llIIlIllII[1])))) && ((!lIlIIIIlIIlI(lllllllllllllllllllIlIIIlIIIlllI.equals(EnumFacing.UP))) || (lIlIIIIlIIll(lllllllllllllllllllIlIIIlIlIIIII.canPlaceOn(lllllllllllllllllllIlIIIlIIllllI, lllllllllllllllllllIlIIIlIIllIII))))) {
      return llIIlIllII[0];
    }
    return llIIlIllII[1];
  }
  
  public IBlockState onBlockPlaced(World lllllllllllllllllllIlIIIIllIIIII, BlockPos lllllllllllllllllllIlIIIIlIlllll, EnumFacing lllllllllllllllllllIlIIIIlIllllI, float lllllllllllllllllllIlIIIIllIllIl, float lllllllllllllllllllIlIIIIllIlIll, float lllllllllllllllllllIlIIIIllIlIIl, int lllllllllllllllllllIlIIIIllIIlll, EntityLivingBase lllllllllllllllllllIlIIIIllIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIIIIlIIlI(lllllllllllllllllllIlIIIIlllIIll.canPlaceAt(lllllllllllllllllllIlIIIIllIIIII, lllllllllllllllllllIlIIIIlIlllll, lllllllllllllllllllIlIIIIlIllllI))) {
      return lllllllllllllllllllIlIIIIlllIIll.getDefaultState().withProperty(FACING, lllllllllllllllllllIlIIIIlIllllI);
    }
    float lllllllllllllllllllIlIIIIlIlllII = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if ("   ".length() <= "  ".length()) {
      return null;
    }
    while (!lIlIIIIlIIll(lllllllllllllllllllIlIIIIlIlllII.hasNext()))
    {
      Object lllllllllllllllllllIlIIIIllIIIll = lllllllllllllllllllIlIIIIlIlllII.next();
      EnumFacing lllllllllllllllllllIlIIIIllIIIlI = (EnumFacing)lllllllllllllllllllIlIIIIllIIIll;
      if (lIlIIIIlIIlI(lllllllllllllllllllIlIIIIllIIIII.isBlockNormalCube(lllllllllllllllllllIlIIIIlIlllll.offset(lllllllllllllllllllIlIIIIllIIIlI.getOpposite()), llIIlIllII[1]))) {
        return lllllllllllllllllllIlIIIIlllIIll.getDefaultState().withProperty(FACING, lllllllllllllllllllIlIIIIllIIIlI);
      }
    }
    return lllllllllllllllllllIlIIIIlllIIll.getDefaultState();
  }
  
  private static boolean lIlIIIIlIlIl(Object ???, Object arg1)
  {
    Object localObject;
    byte lllllllllllllllllllIIlllIIIIlIlI;
    return ??? != localObject;
  }
  
  public boolean canPlaceBlockAt(World lllllllllllllllllllIlIIIlIllIIll, BlockPos lllllllllllllllllllIlIIIlIllIllI)
  {
    ;
    ;
    ;
    ;
    int lllllllllllllllllllIlIIIlIllIIII = FACING.getAllowedValues().iterator();
    "".length();
    if (" ".length() == 0) {
      return (0x8D ^ 0x84 ^ 0x33 ^ 0x29) & (0xF6 ^ 0xB1 ^ 0x42 ^ 0x16 ^ -" ".length());
    }
    while (!lIlIIIIlIIll(lllllllllllllllllllIlIIIlIllIIII.hasNext()))
    {
      EnumFacing lllllllllllllllllllIlIIIlIllIlIl = (EnumFacing)lllllllllllllllllllIlIIIlIllIIII.next();
      if (lIlIIIIlIIlI(lllllllllllllllllllIlIIIlIllIlII.canPlaceAt(lllllllllllllllllllIlIIIlIllIlll, lllllllllllllllllllIlIIIlIllIllI, lllllllllllllllllllIlIIIlIllIlIl))) {
        return llIIlIllII[1];
      }
    }
    return llIIlIllII[0];
  }
  
  private static void lIlIIIIlIIIl()
  {
    llIIlIllII = new int[7];
    llIIlIllII[0] = ("   ".length() & ("   ".length() ^ -" ".length()));
    llIIlIllII[1] = " ".length();
    llIIlIllII[2] = "  ".length();
    llIIlIllII[3] = "   ".length();
    llIIlIllII[4] = (0x49 ^ 0x5B ^ 0x0 ^ 0x16);
    llIIlIllII[5] = (0xCE ^ 0x86 ^ 0x61 ^ 0x2C);
    llIIlIllII[6] = (81 + 16 - 43 + 113 ^ 121 + 19 - 101 + 122);
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World lllllllllllllllllllIlIIIllIlIIll, BlockPos lllllllllllllllllllIlIIIllIlIIlI, IBlockState lllllllllllllllllllIlIIIllIlIIIl)
  {
    return null;
  }
  
  protected BlockTorch()
  {
    lllllllllllllllllllIlIIIllIlIllI.<init>(Material.circuits);
    lllllllllllllllllllIlIIIllIlIlIl.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.UP));
    "".length();
    "".length();
  }
  
  public MovingObjectPosition collisionRayTrace(World lllllllllllllllllllIIlllllIlIlII, BlockPos lllllllllllllllllllIIlllllIlIIll, Vec3 lllllllllllllllllllIIlllllIIlIll, Vec3 lllllllllllllllllllIIlllllIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing lllllllllllllllllllIIlllllIlIIII = (EnumFacing)lllllllllllllllllllIIlllllIlIlII.getBlockState(lllllllllllllllllllIIlllllIIllII).getValue(FACING);
    float lllllllllllllllllllIIlllllIIllll = 0.15F;
    if (lIlIIIIllIll(lllllllllllllllllllIIlllllIlIIII, EnumFacing.EAST))
    {
      lllllllllllllllllllIIlllllIIlllI.setBlockBounds(0.0F, 0.2F, 0.5F - lllllllllllllllllllIIlllllIIllll, lllllllllllllllllllIIlllllIIllll * 2.0F, 0.8F, 0.5F + lllllllllllllllllllIIlllllIIllll);
      "".length();
      if ((0x3 ^ 0x60 ^ 0x1D ^ 0x7A) < "  ".length()) {
        return null;
      }
    }
    else if (lIlIIIIllIll(lllllllllllllllllllIIlllllIlIIII, EnumFacing.WEST))
    {
      lllllllllllllllllllIIlllllIIlllI.setBlockBounds(1.0F - lllllllllllllllllllIIlllllIIllll * 2.0F, 0.2F, 0.5F - lllllllllllllllllllIIlllllIIllll, 1.0F, 0.8F, 0.5F + lllllllllllllllllllIIlllllIIllll);
      "".length();
      if ("  ".length() <= -" ".length()) {
        return null;
      }
    }
    else if (lIlIIIIllIll(lllllllllllllllllllIIlllllIlIIII, EnumFacing.SOUTH))
    {
      lllllllllllllllllllIIlllllIIlllI.setBlockBounds(0.5F - lllllllllllllllllllIIlllllIIllll, 0.2F, 0.0F, 0.5F + lllllllllllllllllllIIlllllIIllll, 0.8F, lllllllllllllllllllIIlllllIIllll * 2.0F);
      "".length();
      if ("   ".length() == 0) {
        return null;
      }
    }
    else if (lIlIIIIllIll(lllllllllllllllllllIIlllllIlIIII, EnumFacing.NORTH))
    {
      lllllllllllllllllllIIlllllIIlllI.setBlockBounds(0.5F - lllllllllllllllllllIIlllllIIllll, 0.2F, 1.0F - lllllllllllllllllllIIlllllIIllll * 2.0F, 0.5F + lllllllllllllllllllIIlllllIIllll, 0.8F, 1.0F);
      "".length();
      if (-"   ".length() >= 0) {
        return null;
      }
    }
    else
    {
      lllllllllllllllllllIIlllllIIllll = 0.1F;
      lllllllllllllllllllIIlllllIIlllI.setBlockBounds(0.5F - lllllllllllllllllllIIlllllIIllll, 0.0F, 0.5F - lllllllllllllllllllIIlllllIIllll, 0.5F + lllllllllllllllllllIIlllllIIllll, 0.6F, 0.5F + lllllllllllllllllllIIlllllIIllll);
    }
    return lllllllllllllllllllIIlllllIIlllI.collisionRayTrace(lllllllllllllllllllIIlllllIlIlII, lllllllllllllllllllIIlllllIIllII, lllllllllllllllllllIIlllllIIlIll, lllllllllllllllllllIIlllllIIlIlI);
  }
  
  public boolean isOpaqueCube()
  {
    return llIIlIllII[0];
  }
  
  private static boolean lIlIIIlIIIII(Object ???)
  {
    Exception lllllllllllllllllllIIlllIIIIIIlI;
    return ??? != null;
  }
}

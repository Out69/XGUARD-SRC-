package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockSoulSand
  extends Block
{
  public BlockSoulSand()
  {
    llllllllllllllIllIllIlllIlllIIll.<init>(Material.sand, MapColor.brownColor);
    "".length();
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIllIllIlllIllIlllI, BlockPos llllllllllllllIllIllIlllIllIllIl, IBlockState llllllllllllllIllIllIlllIllIllII)
  {
    ;
    ;
    float llllllllllllllIllIllIlllIllIlIll = 0.125F;
    return new AxisAlignedBB(llllllllllllllIllIllIlllIllIllIl.getX(), llllllllllllllIllIllIlllIllIllIl.getY(), llllllllllllllIllIllIlllIllIllIl.getZ(), llllllllllllllIllIllIlllIllIllIl.getX() + lllIlllIlIIl[0], llllllllllllllIllIllIlllIllIllIl.getY() + lllIlllIlIIl[0] - llllllllllllllIllIllIlllIllIlIll, llllllllllllllIllIllIlllIllIllIl.getZ() + lllIlllIlIIl[0]);
  }
  
  static {}
  
  public void onEntityCollidedWithBlock(World llllllllllllllIllIllIlllIllIIllI, BlockPos llllllllllllllIllIllIlllIllIIlIl, IBlockState llllllllllllllIllIllIlllIllIIlII, Entity llllllllllllllIllIllIlllIllIIIlI)
  {
    ;
    motionX *= 0.4D;
    motionZ *= 0.4D;
  }
  
  private static void lIllIlIlllllll()
  {
    lllIlllIlIIl = new int[1];
    lllIlllIlIIl[0] = " ".length();
  }
}

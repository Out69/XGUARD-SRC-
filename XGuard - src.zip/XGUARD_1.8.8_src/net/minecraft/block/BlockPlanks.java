package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;

public class BlockPlanks
  extends Block
{
  public IBlockState getStateFromMeta(int llllllllllllllIlIIIlIIllllIIlIll)
  {
    ;
    ;
    return llllllllllllllIlIIIlIIllllIIlllI.getDefaultState().withProperty(VARIANT, EnumType.byMetadata(llllllllllllllIlIIIlIIllllIIlIll));
  }
  
  public int damageDropped(IBlockState llllllllllllllIlIIIlIIlllllIIIll)
  {
    ;
    return ((EnumType)llllllllllllllIlIIIlIIlllllIIIll.getValue(VARIANT)).getMetadata();
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllIlIIIlIIllllIIIlll)
  {
    ;
    return ((EnumType)llllllllllllllIlIIIlIIllllIIIlll.getValue(VARIANT)).func_181070_c();
  }
  
  public BlockPlanks()
  {
    llllllllllllllIlIIIlIIlllllIIllI.<init>(Material.wood);
    llllllllllllllIlIIIlIIlllllIIlll.setDefaultState(blockState.getBaseState().withProperty(VARIANT, EnumType.OAK));
    "".length();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIlIIIlIIllllIIIIIl, new IProperty[] { VARIANT });
  }
  
  private static String llIlllIlIlIlll(String llllllllllllllIlIIIlIIlllIllIllI, String llllllllllllllIlIIIlIIlllIllIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIIlIIlllIlllIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIIlIIlllIllIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIIIlIIlllIlllIlI = Cipher.getInstance("Blowfish");
      llllllllllllllIlIIIlIIlllIlllIlI.init(lIIlIIIlIlIII[2], llllllllllllllIlIIIlIIlllIlllIll);
      return new String(llllllllllllllIlIIIlIIlllIlllIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIIlIIlllIllIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIIlIIlllIlllIIl)
    {
      llllllllllllllIlIIIlIIlllIlllIIl.printStackTrace();
    }
    return null;
  }
  
  private static void llIlllIlIllIIl()
  {
    lIIlIIIlIlIII = new int[3];
    lIIlIIIlIlIII[0] = ((0x75 ^ 0x6A) & (0xA1 ^ 0xBE ^ 0xFFFFFFFF));
    lIIlIIIlIlIII[1] = " ".length();
    lIIlIIIlIlIII[2] = "  ".length();
  }
  
  private static void llIlllIlIllIII()
  {
    lIIlIIIlIIlll = new String[lIIlIIIlIlIII[1]];
    lIIlIIIlIIlll[lIIlIIIlIlIII[0]] = llIlllIlIlIlll("AwImCj9nksE=", "nGtXU");
  }
  
  static
  {
    llIlllIlIllIIl();
    llIlllIlIllIII();
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIlIIIlIIllllIIIlII)
  {
    ;
    return ((EnumType)llllllllllllllIlIIIlIIllllIIIlII.getValue(VARIANT)).getMetadata();
  }
  
  public void getSubBlocks(Item llllllllllllllIlIIIlIIllllIllIlI, CreativeTabs llllllllllllllIlIIIlIIllllIllIIl, List<ItemStack> llllllllllllllIlIIIlIIllllIlIlIl)
  {
    ;
    ;
    ;
    ;
    double llllllllllllllIlIIIlIIllllIlIIlI = (llllllllllllllIlIIIlIIllllIlIIIl = EnumType.values()).length;
    short llllllllllllllIlIIIlIIllllIlIIll = lIIlIIIlIlIII[0];
    "".length();
    if (((0x10 ^ 0x42 ^ 0xC0 ^ 0x8B) & (0xCC ^ 0x9F ^ 0x1B ^ 0x51 ^ -" ".length())) != 0) {
      return;
    }
    while (!llIlllIlIllIlI(llllllllllllllIlIIIlIIllllIlIIll, llllllllllllllIlIIIlIIllllIlIIlI))
    {
      EnumType llllllllllllllIlIIIlIIllllIlIlll = llllllllllllllIlIIIlIIllllIlIIIl[llllllllllllllIlIIIlIIllllIlIIll];
      new ItemStack(llllllllllllllIlIIIlIIllllIllIlI, lIIlIIIlIlIII[1], llllllllllllllIlIIIlIIllllIlIlll.getMetadata());
      "".length();
    }
  }
  
  private static boolean llIlllIlIllIlI(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIlIIIlIIlllIlIllll;
    return ??? >= i;
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    private static boolean lIIIlIIlIIIIII(int ???, int arg1)
    {
      int i;
      byte lllllllllllllllIIllIllllIllIIIII;
      return ??? < i;
    }
    
    public MapColor func_181070_c()
    {
      ;
      return field_181071_k;
    }
    
    private EnumType(int lllllllllllllllIIllIlllllIlllllI, String lllllllllllllllIIllIlllllIllIllI, String lllllllllllllllIIllIlllllIllllII, MapColor lllllllllllllllIIllIlllllIlllIll)
    {
      meta = lllllllllllllllIIllIlllllIlllllI;
      name = lllllllllllllllIIllIlllllIllllIl;
      unlocalizedName = lllllllllllllllIIllIlllllIllllII;
      field_181071_k = lllllllllllllllIIllIlllllIlllIll;
    }
    
    public static EnumType byMetadata(int lllllllllllllllIIllIlllllIlIlIIl)
    {
      ;
      if ((!lIIIlIIIllllll(lllllllllllllllIIllIlllllIlIlIIl)) || (lIIIlIIIlllllI(lllllllllllllllIIllIlllllIlIlIII, META_LOOKUP.length))) {
        lllllllllllllllIIllIlllllIlIlIII = lIllIIIlIllI[0];
      }
      return META_LOOKUP[lllllllllllllllIIllIlllllIlIlIII];
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private static boolean lIIIlIIIllllll(int ???)
    {
      double lllllllllllllllIIllIllllIlIllllI;
      return ??? >= 0;
    }
    
    private EnumType(int lllllllllllllllIIllIllllllIIllll, String lllllllllllllllIIllIllllllIIlIII, MapColor lllllllllllllllIIllIllllllIIIlll)
    {
      lllllllllllllllIIllIllllllIIllII.<init>(lllllllllllllllIIllIllllllIIlIll, lllllllllllllllIIllIllllllIIlIlI, lllllllllllllllIIllIllllllIIllll, lllllllllllllllIIllIllllllIIlIII, lllllllllllllllIIllIllllllIIlIII, lllllllllllllllIIllIllllllIIIlll);
    }
    
    private static String lIIIlIIIlllIlI(String lllllllllllllllIIllIlllllIIlIIII, String lllllllllllllllIIllIlllllIIlIIIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIllIlllllIIlIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIlllllIIlIIIl.getBytes(StandardCharsets.UTF_8)), lIllIIIlIllI[8]), "DES");
        Cipher lllllllllllllllIIllIlllllIIlIlII = Cipher.getInstance("DES");
        lllllllllllllllIIllIlllllIIlIlII.init(lIllIIIlIllI[2], lllllllllllllllIIllIlllllIIlIlIl);
        return new String(lllllllllllllllIIllIlllllIIlIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIlllllIIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIllIlllllIIlIIll)
      {
        lllllllllllllllIIllIlllllIIlIIll.printStackTrace();
      }
      return null;
    }
    
    private static void lIIIlIIIlllIll()
    {
      lIllIIIlIIll = new String[lIllIIIlIllI[13]];
      lIllIIIlIIll[lIllIIIlIllI[0]] = lIIIlIIIlllIII("BDsk", "KzoWh");
      lIllIIIlIIll[lIllIIIlIllI[1]] = lIIIlIIIlllIIl("JmgibIR5uAM=", "aZreW");
      lIllIIIlIIll[lIllIIIlIllI[2]] = lIIIlIIIlllIlI("HoDwmYDrP28=", "MTOxh");
      lIllIIIlIIll[lIllIIIlIllI[3]] = lIIIlIIIlllIlI("smhTUMlpnNI=", "ArvXR");
      lIllIIIlIIll[lIllIIIlIllI[4]] = lIIIlIIIlllIlI("OxkfChVN5do=", "HjvFw");
      lIllIIIlIIll[lIllIIIlIllI[5]] = lIIIlIIIlllIII("FSIDIQk=", "wKqBa");
      lIllIIIlIIll[lIllIIIlIllI[6]] = lIIIlIIIlllIlI("fwc1hE3QgAU=", "wJysd");
      lIllIIIlIIll[lIllIIIlIllI[7]] = lIIIlIIIlllIlI("hSAIwyNs0XQ=", "SheVp");
      lIllIIIlIIll[lIllIIIlIllI[8]] = lIIIlIIIlllIII("CS0pFBMJ", "HnhWZ");
      lIllIIIlIIll[lIllIIIlIllI[9]] = lIIIlIIIlllIII("ECoIOh8Q", "qIiYv");
      lIllIIIlIIll[lIllIIIlIllI[10]] = lIIIlIIIlllIlI("oJVa2xtBd0+pNh6ju8U7+A==", "RnJiN");
      lIllIIIlIIll[lIllIIIlIllI[11]] = lIIIlIIIlllIIl("5lCsADye31A5sTkSWoTVRw==", "AvnBm");
      lIllIIIlIIll[lIllIIIlIllI[12]] = lIIIlIIIlllIIl("pUc80ksjjgg=", "WkaOA");
    }
    
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    private static void lIIIlIIIllllIl()
    {
      lIllIIIlIllI = new int[14];
      lIllIIIlIllI[0] = ((0xA7 ^ 0x8D ^ 0x79 ^ 0x5F) & (0x6D ^ 0xF ^ 0xAA ^ 0xC4 ^ -" ".length()));
      lIllIIIlIllI[1] = " ".length();
      lIllIIIlIllI[2] = "  ".length();
      lIllIIIlIllI[3] = "   ".length();
      lIllIIIlIllI[4] = (0xB1 ^ 0xB5);
      lIllIIIlIllI[5] = (0x69 ^ 0x6C);
      lIllIIIlIllI[6] = (124 + 124 - 176 + 78 ^ 8 + 22 - -24 + 90);
      lIllIIIlIllI[7] = (0x9D ^ 0x9B ^ " ".length());
      lIllIIIlIllI[8] = (0x6D ^ 0x65);
      lIllIIIlIllI[9] = (0x6B ^ 0x62);
      lIllIIIlIllI[10] = (0x8E ^ 0xB8 ^ 0x26 ^ 0x1A);
      lIllIIIlIllI[11] = (0x10 ^ 0x59 ^ 0x3E ^ 0x7C);
      lIllIIIlIllI[12] = (0x6B ^ 0x67);
      lIllIIIlIllI[13] = (0x3D ^ 0x30);
    }
    
    private static String lIIIlIIIlllIII(String lllllllllllllllIIllIllllIlllIlIl, String lllllllllllllllIIllIllllIllIllll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIIllIllllIlllIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIIllIllllIlllIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIIllIllllIlllIIll = new StringBuilder();
      char[] lllllllllllllllIIllIllllIlllIIlI = lllllllllllllllIIllIllllIllIllll.toCharArray();
      int lllllllllllllllIIllIllllIlllIIIl = lIllIIIlIllI[0];
      short lllllllllllllllIIllIllllIllIlIll = lllllllllllllllIIllIllllIlllIlIl.toCharArray();
      double lllllllllllllllIIllIllllIllIlIlI = lllllllllllllllIIllIllllIllIlIll.length;
      double lllllllllllllllIIllIllllIllIlIIl = lIllIIIlIllI[0];
      while (lIIIlIIlIIIIII(lllllllllllllllIIllIllllIllIlIIl, lllllllllllllllIIllIllllIllIlIlI))
      {
        char lllllllllllllllIIllIllllIlllIllI = lllllllllllllllIIllIllllIllIlIll[lllllllllllllllIIllIllllIllIlIIl];
        "".length();
        "".length();
        if (-" ".length() > (0x55 ^ 0x0 ^ 0xD7 ^ 0x86)) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIIllIllllIlllIIll);
    }
    
    private static boolean lIIIlIIIlllllI(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllIIllIllllIllIIlII;
      return ??? >= i;
    }
    
    private static String lIIIlIIIlllIIl(String lllllllllllllllIIllIlllllIIIIlIl, String lllllllllllllllIIllIlllllIIIIIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIllIlllllIIIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIlllllIIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIIllIlllllIIIIlll = Cipher.getInstance("Blowfish");
        lllllllllllllllIIllIlllllIIIIlll.init(lIllIIIlIllI[2], lllllllllllllllIIllIlllllIIIlIII);
        return new String(lllllllllllllllIIllIlllllIIIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIlllllIIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIllIlllllIIIIllI)
      {
        lllllllllllllllIIllIlllllIIIIllI.printStackTrace();
      }
      return null;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    public String getUnlocalizedName()
    {
      ;
      return unlocalizedName;
    }
    
    static
    {
      lIIIlIIIllllIl();
      lIIIlIIIlllIll();
      String lllllllllllllllIIllIllllllIlIlll;
      boolean lllllllllllllllIIllIllllllIllIlI;
      OAK = new EnumType(lIllIIIlIIll[lIllIIIlIllI[0]], lIllIIIlIllI[0], lIllIIIlIllI[0], lIllIIIlIIll[lIllIIIlIllI[1]], MapColor.woodColor);
      SPRUCE = new EnumType(lIllIIIlIIll[lIllIIIlIllI[2]], lIllIIIlIllI[1], lIllIIIlIllI[1], lIllIIIlIIll[lIllIIIlIllI[3]], MapColor.obsidianColor);
      BIRCH = new EnumType(lIllIIIlIIll[lIllIIIlIllI[4]], lIllIIIlIllI[2], lIllIIIlIllI[2], lIllIIIlIIll[lIllIIIlIllI[5]], MapColor.sandColor);
      JUNGLE = new EnumType(lIllIIIlIIll[lIllIIIlIllI[6]], lIllIIIlIllI[3], lIllIIIlIllI[3], lIllIIIlIIll[lIllIIIlIllI[7]], MapColor.dirtColor);
      ACACIA = new EnumType(lIllIIIlIIll[lIllIIIlIllI[8]], lIllIIIlIllI[4], lIllIIIlIllI[4], lIllIIIlIIll[lIllIIIlIllI[9]], MapColor.adobeColor);
      DARK_OAK = new EnumType(lIllIIIlIIll[lIllIIIlIllI[10]], lIllIIIlIllI[5], lIllIIIlIllI[5], lIllIIIlIIll[lIllIIIlIllI[11]], lIllIIIlIIll[lIllIIIlIllI[12]], MapColor.brownColor);
      ENUM$VALUES = new EnumType[] { OAK, SPRUCE, BIRCH, JUNGLE, ACACIA, DARK_OAK };
      META_LOOKUP = new EnumType[values().length];
      byte lllllllllllllllIIllIllllllIllIII = (lllllllllllllllIIllIllllllIlIlll = values()).length;
      boolean lllllllllllllllIIllIllllllIllIIl = lIllIIIlIllI[0];
      "".length();
      if (" ".length() != " ".length()) {
        return;
      }
      while (!lIIIlIIIlllllI(lllllllllllllllIIllIllllllIllIIl, lllllllllllllllIIllIllllllIllIII))
      {
        EnumType lllllllllllllllIIllIllllllIllIll = lllllllllllllllIIllIllllllIlIlll[lllllllllllllllIIllIllllllIllIIl];
        META_LOOKUP[lllllllllllllllIIllIllllllIllIll.getMetadata()] = lllllllllllllllIIllIllllllIllIll;
        lllllllllllllllIIllIllllllIllIIl++;
      }
    }
  }
}

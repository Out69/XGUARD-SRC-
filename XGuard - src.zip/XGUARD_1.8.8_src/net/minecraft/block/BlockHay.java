package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.world.World;

public class BlockHay
  extends BlockRotatedPillar
{
  private static void lIlIIIIlI()
  {
    llIlllI = new int[5];
    llIlllI[0] = (0x6 ^ 0xA);
    llIlllI[1] = (67 + '' - 132 + 95 ^ '' + 40 - 37 + 38);
    llIlllI[2] = (0xC9 ^ 0xC1);
    llIlllI[3] = ((0xD3 ^ 0xB3) & (0x66 ^ 0x6 ^ 0xFFFFFFFF));
    llIlllI[4] = " ".length();
  }
  
  protected ItemStack createStackedBlock(IBlockState llIlIllIllIIIIl)
  {
    ;
    return new ItemStack(Item.getItemFromBlock(llIlIllIllIIIII), llIlllI[4], llIlllI[3]);
  }
  
  public IBlockState getStateFromMeta(int llIlIllIlllIlll)
  {
    ;
    ;
    ;
    ;
    EnumFacing.Axis llIlIllIlllIllI = EnumFacing.Axis.Y;
    int llIlIllIlllIlIl = llIlIllIlllIlll & llIlllI[0];
    if (lIlIIIIll(llIlIllIlllIlIl, llIlllI[1]))
    {
      llIlIllIlllIllI = EnumFacing.Axis.X;
      "".length();
      if (null != null) {
        return null;
      }
    }
    else if (lIlIIIIll(llIlIllIlllIlIl, llIlllI[2]))
    {
      llIlIllIlllIllI = EnumFacing.Axis.Z;
    }
    return llIlIllIlllIlII.getDefaultState().withProperty(AXIS, llIlIllIlllIllI);
  }
  
  static {}
  
  private static boolean lIlIIIlII(Object ???, Object arg1)
  {
    Object localObject;
    char llIlIllIIllllIl;
    return ??? == localObject;
  }
  
  public IBlockState onBlockPlaced(World llIlIllIlIlIlIl, BlockPos llIlIllIlIIlIll, EnumFacing llIlIllIlIIlIlI, float llIlIllIlIIlIIl, float llIlIllIlIIlIII, float llIlIllIlIIIlll, int llIlIllIlIIllll, EntityLivingBase llIlIllIlIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    return llIlIllIlIlIllI.onBlockPlaced(llIlIllIlIlIlIl, llIlIllIlIIlIll, llIlIllIlIIlIlI, llIlIllIlIlIIlI, llIlIllIlIIlIII, llIlIllIlIIIlll, llIlIllIlIIllll, llIlIllIlIIlllI).withProperty(AXIS, llIlIllIlIIlIlI.getAxis());
  }
  
  public BlockHay()
  {
    llIlIllIllllllI.<init>(Material.grass, MapColor.yellowColor);
    llIlIllIlllllIl.setDefaultState(blockState.getBaseState().withProperty(AXIS, EnumFacing.Axis.Y));
    "".length();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llIlIllIllIIlIl, new IProperty[] { AXIS });
  }
  
  private static boolean lIlIIIIll(int ???, int arg1)
  {
    int i;
    int llIlIllIlIIIIIl;
    return ??? == i;
  }
  
  public int getMetaFromState(IBlockState llIlIllIllIlIIl)
  {
    ;
    ;
    ;
    int llIlIllIllIlIll = llIlllI[3];
    EnumFacing.Axis llIlIllIllIlIlI = (EnumFacing.Axis)llIlIllIllIllII.getValue(AXIS);
    if (lIlIIIlII(llIlIllIllIlIlI, EnumFacing.Axis.X))
    {
      llIlIllIllIlIll |= llIlllI[1];
      "".length();
      if (-(44 + 74 - 40 + 55 ^ 11 + 33 - -83 + 1) >= 0) {
        return (0xA6 ^ 0x8C ^ 0x5D ^ 0x56) & (0xDE ^ 0xBF ^ 0x34 ^ 0x74 ^ -" ".length()) & ((86 + 13 - -11 + 119 ^ 64 + 28 - -60 + 18) & (0xAD ^ 0x80 ^ 0x41 ^ 0x23 ^ -" ".length()) ^ -" ".length());
      }
    }
    else if (lIlIIIlII(llIlIllIllIlIlI, EnumFacing.Axis.Z))
    {
      llIlIllIllIlIll |= llIlllI[2];
    }
    return llIlIllIllIlIll;
  }
}

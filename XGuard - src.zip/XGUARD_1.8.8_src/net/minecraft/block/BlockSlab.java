package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockSlab
  extends Block
{
  private static boolean lllIllIlIIIIlI(int ???)
  {
    String llllllllllllllIIllIlIIIIIIlIlIIl;
    return ??? != 0;
  }
  
  public abstract Object getVariant(ItemStack paramItemStack);
  
  public int quantityDropped(Random llllllllllllllIIllIlIIIIIllllIlI)
  {
    ;
    if (lllIllIlIIIIlI(llllllllllllllIIllIlIIIIIllllIll.isDouble()))
    {
      "".length();
      if (-" ".length() != (0x46 ^ 0x42)) {
        break label56;
      }
      return (0x50 ^ 0x75) & (0x9F ^ 0xBA ^ 0xFFFFFFFF);
    }
    label56:
    return lIIllIllllIII[1];
  }
  
  public void addCollisionBoxesToList(World llllllllllllllIIllIlIIIIlIlIlIlI, BlockPos llllllllllllllIIllIlIIIIlIlIlIIl, IBlockState llllllllllllllIIllIlIIIIlIlIlIII, AxisAlignedBB llllllllllllllIIllIlIIIIlIlIIlll, List<AxisAlignedBB> llllllllllllllIIllIlIIIIlIlIIllI, Entity llllllllllllllIIllIlIIIIlIIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIlIIIIlIlIIlII.setBlockBoundsBasedOnState(llllllllllllllIIllIlIIIIlIlIlIlI, llllllllllllllIIllIlIIIIlIlIlIIl);
    llllllllllllllIIllIlIIIIlIlIIlII.addCollisionBoxesToList(llllllllllllllIIllIlIIIIlIlIlIlI, llllllllllllllIIllIlIIIIlIlIlIIl, llllllllllllllIIllIlIIIIlIlIIIIl, llllllllllllllIIllIlIIIIlIlIIlll, llllllllllllllIIllIlIIIIlIlIIllI, llllllllllllllIIllIlIIIIlIIllllI);
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIIllIlIIIIlIllllII, BlockPos llllllllllllllIIllIlIIIIlIllIlll)
  {
    ;
    ;
    ;
    ;
    if (lllIllIlIIIIlI(llllllllllllllIIllIlIIIIlIlllIIl.isDouble()))
    {
      llllllllllllllIIllIlIIIIlIlllIIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
      "".length();
      if ("   ".length() != 0) {}
    }
    else
    {
      IBlockState llllllllllllllIIllIlIIIIlIlllIlI = llllllllllllllIIllIlIIIIlIlllIII.getBlockState(llllllllllllllIIllIlIIIIlIllIlll);
      if (lllIllIlIIIIll(llllllllllllllIIllIlIIIIlIlllIlI.getBlock(), llllllllllllllIIllIlIIIIlIlllIIl)) {
        if (lllIllIlIIIIll(llllllllllllllIIllIlIIIIlIlllIlI.getValue(HALF), EnumBlockHalf.TOP))
        {
          llllllllllllllIIllIlIIIIlIlllIIl.setBlockBounds(0.0F, 0.5F, 0.0F, 1.0F, 1.0F, 1.0F);
          "".length();
          if ((96 + 54 - 95 + 108 ^ 13 + 40 - -50 + 63) != 0) {}
        }
        else
        {
          llllllllllllllIIllIlIIIIlIlllIIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
        }
      }
    }
  }
  
  private static void lllIllIlIIIIIl()
  {
    lIIllIllllIII = new int[5];
    lIIllIllllIII[0] = ((0x0 ^ 0x5 ^ 0x6C ^ 0x5B) & (103 + 55 - 135 + 114 ^ 87 + 99 - 115 + 116 ^ -" ".length()));
    lIIllIllllIII[1] = " ".length();
    lIIllIllllIII[2] = ((0xDE ^ 0xBF) + ('' + 11 - 109 + 152) - (0x57 ^ 0x8) + (0x1C ^ 0x5A));
    lIIllIllllIII[3] = "  ".length();
    lIIllIllllIII[4] = (0xA6 ^ 0xA1);
  }
  
  private static void lllIllIlIIIIII()
  {
    lIIllIlllIlll = new String[lIIllIllllIII[1]];
    lIIllIlllIlll[lIIllIllllIII[0]] = lllIllIIllllll("HDEuLQ==", "tPBKd");
  }
  
  public BlockSlab(Material llllllllllllllIIllIlIIIIllIIIIll)
  {
    llllllllllllllIIllIlIIIIllIIIllI.<init>(llllllllllllllIIllIlIIIIllIIIIll);
    if (lllIllIlIIIIlI(llllllllllllllIIllIlIIIIllIIIllI.isDouble()))
    {
      fullBlock = lIIllIllllIII[1];
      "".length();
      if (-(2 + 38 - 24 + 138 ^ 91 + '' - 82 + 8) >= 0) {
        throw null;
      }
    }
    else
    {
      llllllllllllllIIllIlIIIIllIIIllI.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
    }
    "".length();
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    if (lllIllIlIIIIlI(llllllllllllllIIllIlIIIIlIllIIll.isDouble()))
    {
      llllllllllllllIIllIlIIIIlIllIlII.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
      "".length();
      if (" ".length() == " ".length()) {}
    }
    else
    {
      llllllllllllllIIllIlIIIIlIllIlII.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
    }
  }
  
  private static boolean lllIllIlIIIlll(int ???)
  {
    short llllllllllllllIIllIlIIIIIIlIIlll;
    return ??? == 0;
  }
  
  public abstract IProperty<?> getVariantProperty();
  
  static
  {
    lllIllIlIIIIIl();
    lllIllIlIIIIII();
  }
  
  public boolean shouldSideBeRendered(IBlockAccess llllllllllllllIIllIlIIIIIllIIIlI, BlockPos llllllllllllllIIllIlIIIIIllIIIIl, EnumFacing llllllllllllllIIllIlIIIIIllIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIllIlIIIIlI(llllllllllllllIIllIlIIIIIllIllII.isDouble())) {
      return llllllllllllllIIllIlIIIIIllIllII.shouldSideBeRendered(llllllllllllllIIllIlIIIIIllIIIlI, llllllllllllllIIllIlIIIIIllIIIIl, llllllllllllllIIllIlIIIIIllIIIII);
    }
    if ((lllIllIlIIIlIl(llllllllllllllIIllIlIIIIIllIIIII, EnumFacing.UP)) && (lllIllIlIIIlIl(llllllllllllllIIllIlIIIIIllIIIII, EnumFacing.DOWN)) && (lllIllIlIIIlll(llllllllllllllIIllIlIIIIIllIllII.shouldSideBeRendered(llllllllllllllIIllIlIIIIIllIIIlI, llllllllllllllIIllIlIIIIIllIIIIl, llllllllllllllIIllIlIIIIIllIIIII)))) {
      return lIIllIllllIII[0];
    }
    BlockPos llllllllllllllIIllIlIIIIIllIlIII = llllllllllllllIIllIlIIIIIllIIIIl.offset(llllllllllllllIIllIlIIIIIllIIIII.getOpposite());
    IBlockState llllllllllllllIIllIlIIIIIllIIlll = llllllllllllllIIllIlIIIIIllIIIlI.getBlockState(llllllllllllllIIllIlIIIIIllIIIIl);
    IBlockState llllllllllllllIIllIlIIIIIllIIllI = llllllllllllllIIllIlIIIIIllIIIlI.getBlockState(llllllllllllllIIllIlIIIIIllIlIII);
    if ((lllIllIlIIIIlI(isSlab(llllllllllllllIIllIlIIIIIllIIlll.getBlock()))) && (lllIllIlIIIIll(llllllllllllllIIllIlIIIIIllIIlll.getValue(HALF), EnumBlockHalf.TOP)))
    {
      "".length();
      if (null == null) {
        break label157;
      }
      return (0x12 ^ 0x1E) & (0xA7 ^ 0xAB ^ 0xFFFFFFFF);
    }
    label157:
    boolean llllllllllllllIIllIlIIIIIllIIlIl = lIIllIllllIII[0];
    if ((lllIllIlIIIIlI(isSlab(llllllllllllllIIllIlIIIIIllIIllI.getBlock()))) && (lllIllIlIIIIll(llllllllllllllIIllIlIIIIIllIIllI.getValue(HALF), EnumBlockHalf.TOP)))
    {
      "".length();
      if ("  ".length() == "  ".length()) {
        break label256;
      }
      return (0x7B ^ 0x7F ^ 0x6E ^ 0x60) & (" ".length() ^ 0x9D ^ 0x96 ^ -" ".length());
    }
    label256:
    boolean llllllllllllllIIllIlIIIIIllIIlII = lIIllIllllIII[0];
    if (lllIllIlIIIIlI(llllllllllllllIIllIlIIIIIllIIlII))
    {
      if (lllIllIlIIIIll(llllllllllllllIIllIlIIIIIllIIIII, EnumFacing.DOWN))
      {
        "".length();
        if ("   ".length() <= -" ".length()) {
          return (39 + 8 - -66 + 75 ^ 21 + '' - -8 + 22) & (0x1 ^ 0x5D ^ 0x47 ^ 0x1C ^ -" ".length());
        }
      }
      else if ((lllIllIlIIIIll(llllllllllllllIIllIlIIIIIllIIIII, EnumFacing.UP)) && (lllIllIlIIIIlI(llllllllllllllIIllIlIIIIIllIllII.shouldSideBeRendered(llllllllllllllIIllIlIIIIIllIIIlI, llllllllllllllIIllIlIIIIIllIIIIl, llllllllllllllIIllIlIIIIIllIIIII))))
      {
        "".length();
        if ((0x81 ^ 0x85) <= -" ".length()) {
          return (0x97 ^ 0xAB) & (0x88 ^ 0xB4 ^ 0xFFFFFFFF);
        }
      }
      else if ((lllIllIlIIIIlI(isSlab(llllllllllllllIIllIlIIIIIllIIlll.getBlock()))) && (lllIllIlIIIIlI(llllllllllllllIIllIlIIIIIllIIlIl)))
      {
        "".length();
        if ("   ".length() <= 0) {
          return (0xD6 ^ 0x8C) & (0xEC ^ 0xB6 ^ 0xFFFFFFFF);
        }
      }
      else
      {
        "".length();
        if (((113 + 15 - 61 + 82 ^ 35 + 20 - -16 + 100) & (0xB2 ^ 0xB6 ^ 0x13 ^ 0x29 ^ -" ".length())) < -" ".length()) {
          return (0x68 ^ 0xB ^ 0x86 ^ 0xA5) & (0x8A ^ 0x82 ^ 0x58 ^ 0x10 ^ -" ".length());
        }
      }
    }
    else if (lllIllIlIIIIll(llllllllllllllIIllIlIIIIIllIIIII, EnumFacing.UP))
    {
      "".length();
      if (null != null) {
        return (108 + 104 - 136 + 78 ^ 24 + 84 - 42 + 62) & (0x8D ^ 0x93 ^ 0x21 ^ 0x25 ^ -" ".length());
      }
    }
    else if ((lllIllIlIIIIll(llllllllllllllIIllIlIIIIIllIIIII, EnumFacing.DOWN)) && (lllIllIlIIIIlI(llllllllllllllIIllIlIIIIIllIllII.shouldSideBeRendered(llllllllllllllIIllIlIIIIIllIIIlI, llllllllllllllIIllIlIIIIIllIIIIl, llllllllllllllIIllIlIIIIIllIIIII))))
    {
      "".length();
      if (-"   ".length() >= 0) {
        return (0xB8 ^ 0x88) & (0x9 ^ 0x39 ^ 0xFFFFFFFF);
      }
    }
    else if ((lllIllIlIIIIlI(isSlab(llllllllllllllIIllIlIIIIIllIIlll.getBlock()))) && (lllIllIlIIIlll(llllllllllllllIIllIlIIIIIllIIlIl)))
    {
      "".length();
      if ("   ".length() != " ".length()) {
        break label785;
      }
      return (0x1F ^ 0x3 ^ 0x5D ^ 0x64) & (0x79 ^ 0x59 ^ 0x47 ^ 0x42 ^ -" ".length());
    }
    label785:
    return lIIllIllllIII[1];
  }
  
  private static int lllIllIlIIIlII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public int getDamageValue(World llllllllllllllIIllIlIIIIIlIlIIII, BlockPos llllllllllllllIIllIlIIIIIlIIllll)
  {
    ;
    ;
    ;
    return llllllllllllllIIllIlIIIIIlIlIlII.getDamageValue(llllllllllllllIIllIlIIIIIlIlIIll, llllllllllllllIIllIlIIIIIlIIllll) & lIIllIllllIII[4];
  }
  
  private static boolean lllIllIlIIlIlI(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIIllIlIIIIIIllIIll;
    return ??? < i;
  }
  
  private static boolean lllIllIlIIIllI(int ???)
  {
    String llllllllllllllIIllIlIIIIIIlIIlIl;
    return ??? <= 0;
  }
  
  public boolean isOpaqueCube()
  {
    ;
    return llllllllllllllIIllIlIIIIlIIllIll.isDouble();
  }
  
  public abstract boolean isDouble();
  
  public boolean isFullCube()
  {
    ;
    return llllllllllllllIIllIlIIIIIlllIlll.isDouble();
  }
  
  private static boolean lllIllIlIIIIll(Object ???, Object arg1)
  {
    Object localObject;
    byte llllllllllllllIIllIlIIIIIIlIlIll;
    return ??? == localObject;
  }
  
  public IBlockState onBlockPlaced(World llllllllllllllIIllIlIIIIlIIIIlIl, BlockPos llllllllllllllIIllIlIIIIlIIIIlII, EnumFacing llllllllllllllIIllIlIIIIlIIIllIl, float llllllllllllllIIllIlIIIIlIIIIIlI, float llllllllllllllIIllIlIIIIlIIIIIIl, float llllllllllllllIIllIlIIIIlIIIIIII, int llllllllllllllIIllIlIIIIlIIIlIIl, EntityLivingBase llllllllllllllIIllIlIIIIlIIIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllIIllIlIIIIlIIIIlll = llllllllllllllIIllIlIIIIlIIlIIII.onBlockPlaced(llllllllllllllIIllIlIIIIlIIIIlIl, llllllllllllllIIllIlIIIIlIIIIlII, llllllllllllllIIllIlIIIIlIIIllIl, llllllllllllllIIllIlIIIIlIIIllII, llllllllllllllIIllIlIIIIlIIIIIIl, llllllllllllllIIllIlIIIIlIIIIIII, llllllllllllllIIllIlIIIIlIIIlIIl, llllllllllllllIIllIlIIIIlIIIlIII).withProperty(HALF, EnumBlockHalf.BOTTOM);
    if (lllIllIlIIIIlI(llllllllllllllIIllIlIIIIlIIlIIII.isDouble()))
    {
      "".length();
      if (-" ".length() >= "  ".length()) {
        return null;
      }
    }
    else if ((lllIllIlIIIlIl(llllllllllllllIIllIlIIIIlIIIllIl, EnumFacing.DOWN)) && ((!lllIllIlIIIlIl(llllllllllllllIIllIlIIIIlIIIllIl, EnumFacing.UP)) || (lllIllIlIIIllI(lllIllIlIIIlII(llllllllllllllIIllIlIIIIlIIIIIIl, 0.5D)))))
    {
      "".length();
      if (" ".length() <= ('³' + 96 - 206 + 130 ^ '¿' + 77 - 73 + 0)) {
        break label156;
      }
      return null;
    }
    label156:
    return llllllllllllllIIllIlIIIIlIIIIlll.withProperty(HALF, EnumBlockHalf.TOP);
  }
  
  private static String lllIllIIllllll(String llllllllllllllIIllIlIIIIIIllllll, String llllllllllllllIIllIlIIIIIlIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIlIIIIIIllllll = new String(Base64.getDecoder().decode(llllllllllllllIIllIlIIIIIIllllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIllIlIIIIIlIIIIlI = new StringBuilder();
    char[] llllllllllllllIIllIlIIIIIlIIIIIl = llllllllllllllIIllIlIIIIIlIIIIll.toCharArray();
    int llllllllllllllIIllIlIIIIIlIIIIII = lIIllIllllIII[0];
    int llllllllllllllIIllIlIIIIIIlllIlI = llllllllllllllIIllIlIIIIIIllllll.toCharArray();
    short llllllllllllllIIllIlIIIIIIlllIIl = llllllllllllllIIllIlIIIIIIlllIlI.length;
    byte llllllllllllllIIllIlIIIIIIlllIII = lIIllIllllIII[0];
    while (lllIllIlIIlIlI(llllllllllllllIIllIlIIIIIIlllIII, llllllllllllllIIllIlIIIIIIlllIIl))
    {
      char llllllllllllllIIllIlIIIIIlIIIlIl = llllllllllllllIIllIlIIIIIIlllIlI[llllllllllllllIIllIlIIIIIIlllIII];
      "".length();
      "".length();
      if (((0x99 ^ 0xB0 ^ 0x66 ^ 0x75) & (93 + 23 - 87 + 119 ^ 103 + 16 - 62 + 117 ^ -" ".length())) >= "   ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIllIlIIIIIlIIIIlI);
  }
  
  protected boolean canSilkHarvest()
  {
    return lIIllIllllIII[0];
  }
  
  private static boolean lllIllIlIIIlIl(Object ???, Object arg1)
  {
    Object localObject;
    String llllllllllllllIIllIlIIIIIIlIllll;
    return ??? != localObject;
  }
  
  protected static boolean isSlab(Block llllllllllllllIIllIlIIIIIlIllIII)
  {
    ;
    if ((lllIllIlIIIlIl(llllllllllllllIIllIlIIIIIlIllIII, Blocks.stone_slab)) && (lllIllIlIIIlIl(llllllllllllllIIllIlIIIIIlIllIIl, Blocks.wooden_slab)) && (lllIllIlIIIlIl(llllllllllllllIIllIlIIIIIlIllIIl, Blocks.stone_slab2))) {
      return lIIllIllllIII[0];
    }
    return lIIllIllllIII[1];
  }
  
  public abstract String getUnlocalizedName(int paramInt);
  
  public static enum EnumBlockHalf
    implements IStringSerializable
  {
    TOP(lIIIlIllIlII[lIIIlIlllIIl[1]]),  BOTTOM(lIIIlIllIlII[lIIIlIlllIIl[3]]);
    
    private static String llIlIllllIIIl(String lllllllllllllllIlllIIllIIIlllIll, String lllllllllllllllIlllIIllIIIlllIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIlllIIllIIlIIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIllIIIlllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIlllIIllIIIllllll = Cipher.getInstance("Blowfish");
        lllllllllllllllIlllIIllIIIllllll.init(lIIIlIlllIIl[2], lllllllllllllllIlllIIllIIlIIIIII);
        return new String(lllllllllllllllIlllIIllIIIllllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIIlllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIlllIIllIIIlllllI)
      {
        lllllllllllllllIlllIIllIIIlllllI.printStackTrace();
      }
      return null;
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private EnumBlockHalf(String lllllllllllllllIlllIIllIIllIllll)
    {
      name = lllllllllllllllIlllIIllIIllIllll;
    }
    
    private static void llIlIllllIlll()
    {
      lIIIlIllIlII = new String[lIIIlIlllIIl[4]];
      lIIIlIllIlII[lIIIlIlllIIl[0]] = llIlIllllIIIl("3x7E6CjRq6M=", "aKlmR");
      lIIIlIllIlII[lIIIlIlllIIl[1]] = llIlIllllIlIl("PQMg", "IlPwf");
      lIIIlIllIlII[lIIIlIlllIIl[2]] = llIlIllllIIIl("B488tywgCWo=", "wBtYX");
      lIIIlIllIlII[lIIIlIlllIIl[3]] = llIlIllllIllI("KPr71QuJiaU=", "NduHr");
    }
    
    private static String llIlIllllIlIl(String lllllllllllllllIlllIIllIIlIlIIlI, String lllllllllllllllIlllIIllIIlIlIIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIlllIIllIIlIlIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIlIlIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIlllIIllIIlIlIIII = new StringBuilder();
      char[] lllllllllllllllIlllIIllIIlIIllll = lllllllllllllllIlllIIllIIlIlIIIl.toCharArray();
      int lllllllllllllllIlllIIllIIlIIlllI = lIIIlIlllIIl[0];
      int lllllllllllllllIlllIIllIIlIIlIII = lllllllllllllllIlllIIllIIlIlIIlI.toCharArray();
      byte lllllllllllllllIlllIIllIIlIIIlll = lllllllllllllllIlllIIllIIlIIlIII.length;
      float lllllllllllllllIlllIIllIIlIIIllI = lIIIlIlllIIl[0];
      while (llIlIllllllll(lllllllllllllllIlllIIllIIlIIIllI, lllllllllllllllIlllIIllIIlIIIlll))
      {
        char lllllllllllllllIlllIIllIIlIlIIll = lllllllllllllllIlllIIllIIlIIlIII[lllllllllllllllIlllIIllIIlIIIllI];
        "".length();
        "".length();
        if ((0xD ^ 0x68 ^ 0x69 ^ 0x8) < -" ".length()) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIlllIIllIIlIlIIII);
    }
    
    private static boolean llIlIllllllll(int ???, int arg1)
    {
      int i;
      String lllllllllllllllIlllIIllIIIlIIlll;
      return ??? < i;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    private static void llIlIlllllllI()
    {
      lIIIlIlllIIl = new int[6];
      lIIIlIlllIIl[0] = ((0x3F ^ 0x63) & (0x14 ^ 0x48 ^ 0xFFFFFFFF));
      lIIIlIlllIIl[1] = " ".length();
      lIIIlIlllIIl[2] = "  ".length();
      lIIIlIlllIIl[3] = "   ".length();
      lIIIlIlllIIl[4] = (24 + 10 - 27 + 160 ^ '' + '' - 239 + 100);
      lIIIlIlllIIl[5] = (0x6B ^ 0x3E ^ 0xEB ^ 0xB6);
    }
    
    private static String llIlIllllIllI(String lllllllllllllllIlllIIllIIIlIlllI, String lllllllllllllllIlllIIllIIIlIllIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIlllIIllIIIllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIllIIIlIllIl.getBytes(StandardCharsets.UTF_8)), lIIIlIlllIIl[5]), "DES");
        Cipher lllllllllllllllIlllIIllIIIllIIlI = Cipher.getInstance("DES");
        lllllllllllllllIlllIIllIIIllIIlI.init(lIIIlIlllIIl[2], lllllllllllllllIlllIIllIIIllIIll);
        return new String(lllllllllllllllIlllIIllIIIllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIllIIIlIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIlllIIllIIIllIIIl)
      {
        lllllllllllllllIlllIIllIIIllIIIl.printStackTrace();
      }
      return null;
    }
    
    static
    {
      llIlIlllllllI();
      llIlIllllIlll();
    }
  }
}

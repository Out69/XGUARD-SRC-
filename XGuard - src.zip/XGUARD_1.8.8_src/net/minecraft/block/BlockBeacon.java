package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBeacon;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;

public class BlockBeacon
  extends BlockContainer
{
  public void onBlockPlacedBy(World lllllllllllllllIIlllIIIlIlIlIIIl, BlockPos lllllllllllllllIIlllIIIlIlIIlIIl, IBlockState lllllllllllllllIIlllIIIlIlIIlIII, EntityLivingBase lllllllllllllllIIlllIIIlIlIIlllI, ItemStack lllllllllllllllIIlllIIIlIlIIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlllIIIlIlIIlIll.onBlockPlacedBy(lllllllllllllllIIlllIIIlIlIlIIIl, lllllllllllllllIIlllIIIlIlIIlIIl, lllllllllllllllIIlllIIIlIlIIlIII, lllllllllllllllIIlllIIIlIlIIlllI, lllllllllllllllIIlllIIIlIlIIIllI);
    if (lIIIlIIIlIIIlI(lllllllllllllllIIlllIIIlIlIIIllI.hasDisplayName()))
    {
      TileEntity lllllllllllllllIIlllIIIlIlIIllII = lllllllllllllllIIlllIIIlIlIlIIIl.getTileEntity(lllllllllllllllIIlllIIIlIlIIlIIl);
      if (lIIIlIIIlIIIlI(lllllllllllllllIIlllIIIlIlIIllII instanceof TileEntityBeacon)) {
        ((TileEntityBeacon)lllllllllllllllIIlllIIIlIlIIllII).setName(lllllllllllllllIIlllIIIlIlIIIllI.getDisplayName());
      }
    }
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public boolean isFullCube()
  {
    return lIllIIIIlIlI[1];
  }
  
  public static void updateColorAsync(World lllllllllllllllIIlllIIIlIIllIIll, final BlockPos lllllllllllllllIIlllIIIlIIllIIII)
  {
    ;
    ;
    new Runnable();
    {
      private static void llIIIIllIIllIl()
      {
        lllllllIllII = new int[1];
        lllllllIllII[0] = " ".length();
      }
      
      private static boolean llIIIIllIlIIII(int ???)
      {
        String llllllllllllllIllIIIIlIIlllIIIIl;
        return ??? < 0;
      }
      
      public void run()
      {
        ;
        ;
        ;
        ;
        ;
        Chunk llllllllllllllIllIIIIlIIllllIIIl = getChunkFromBlockCoords(lllllllllllllllIIlllIIIlIIllIIII);
        int llllllllllllllIllIIIIlIIllllIIII = lllllllllllllllIIlllIIIlIIllIIII.getY() - lllllllIllII[0];
        "".length();
        if (((0x23 ^ 0x13) & (0xA6 ^ 0x96 ^ 0xFFFFFFFF)) >= "  ".length()) {
          return;
        }
        while (!llIIIIllIlIIII(llllllllllllllIllIIIIlIIllllIIII))
        {
          final BlockPos llllllllllllllIllIIIIlIIlllIllll = new BlockPos(lllllllllllllllIIlllIIIlIIllIIII.getX(), llllllllllllllIllIIIIlIIllllIIII, lllllllllllllllIIlllIIIlIIllIIII.getZ());
          if (llIIIIllIIlllI(llllllllllllllIllIIIIlIIllllIIIl.canSeeSky(llllllllllllllIllIIIIlIIlllIllll)))
          {
            "".length();
            if ("  ".length() >= ((0x65 ^ 0x45) & (0x92 ^ 0xB2 ^ 0xFFFFFFFF))) {
              break;
            }
            return;
          }
          IBlockState llllllllllllllIllIIIIlIIlllIlllI = getBlockState(llllllllllllllIllIIIIlIIlllIllll);
          if (llIIIIllIIllll(llllllllllllllIllIIIIlIIlllIlllI.getBlock(), Blocks.beacon))
          {
            new Runnable();
            {
              private static void lIIIIllIIlI()
              {
                lIlIIlIIl = new int[2];
                lIlIIlIIl[0] = " ".length();
                lIlIIlIIl[1] = ((26 + 59 - 22 + 79 ^ '' + 59 - 35 + 4) & (0x9E ^ 0xBE ^ 0x8B ^ 0x82 ^ -" ".length()));
              }
              
              private static boolean lIIIIllIIll(int ???)
              {
                double llllllIIllllll;
                return ??? != 0;
              }
              
              static {}
              
              public void run()
              {
                ;
                ;
                TileEntity llllllIlIIIIll = val$worldIn.getTileEntity(llllllllllllllIllIIIIlIIlllIllll);
                if (lIIIIllIIll(llllllIlIIIIll instanceof TileEntityBeacon))
                {
                  ((TileEntityBeacon)llllllIlIIIIll).updateBeacon();
                  val$worldIn.addBlockEvent(llllllllllllllIllIIIIlIIlllIllll, Blocks.beacon, lIlIIlIIl[0], lIlIIlIIl[1]);
                }
              }
            };
            "".length();
          }
          llllllllllllllIllIIIIlIIllllIIII--;
        }
      }
      
      private static boolean llIIIIllIIllll(Object ???, Object arg1)
      {
        Object localObject;
        long llllllllllllllIllIIIIlIIlllIIlIl;
        return ??? == localObject;
      }
      
      static {}
      
      private static boolean llIIIIllIIlllI(int ???)
      {
        double llllllllllllllIllIIIIlIIlllIIIll;
        return ??? == 0;
      }
    };
    "".length();
  }
  
  public int getRenderType()
  {
    return lIllIIIIlIlI[2];
  }
  
  public void onNeighborBlockChange(World lllllllllllllllIIlllIIIlIIllllll, BlockPos lllllllllllllllIIlllIIIlIIlllIII, IBlockState lllllllllllllllIIlllIIIlIIllllIl, Block lllllllllllllllIIlllIIIlIIllllII)
  {
    ;
    ;
    ;
    ;
    TileEntity lllllllllllllllIIlllIIIlIIlllIll = lllllllllllllllIIlllIIIlIIllllll.getTileEntity(lllllllllllllllIIlllIIIlIIlllllI);
    if (lIIIlIIIlIIIlI(lllllllllllllllIIlllIIIlIIlllIll instanceof TileEntityBeacon))
    {
      ((TileEntityBeacon)lllllllllllllllIIlllIIIlIIlllIll).updateBeacon();
      lllllllllllllllIIlllIIIlIIllllll.addBlockEvent(lllllllllllllllIIlllIIIlIIlllllI, lllllllllllllllIIlllIIIlIIlllIlI, lIllIIIIlIlI[0], lIllIIIIlIlI[1]);
    }
  }
  
  public TileEntity createNewTileEntity(World lllllllllllllllIIlllIIIlIlllIIII, int lllllllllllllllIIlllIIIlIllIllll)
  {
    return new TileEntityBeacon();
  }
  
  static {}
  
  public BlockBeacon()
  {
    lllllllllllllllIIlllIIIlIlllIIll.<init>(Material.glass, MapColor.diamondColor);
    "".length();
    "".length();
  }
  
  public boolean onBlockActivated(World lllllllllllllllIIlllIIIlIllIIIII, BlockPos lllllllllllllllIIlllIIIlIllIlIII, IBlockState lllllllllllllllIIlllIIIlIllIIlll, EntityPlayer lllllllllllllllIIlllIIIlIllIIllI, EnumFacing lllllllllllllllIIlllIIIlIllIIlIl, float lllllllllllllllIIlllIIIlIllIIlII, float lllllllllllllllIIlllIIIlIllIIIll, float lllllllllllllllIIlllIIIlIllIIIlI)
  {
    ;
    ;
    ;
    ;
    if (lIIIlIIIlIIIlI(isRemote)) {
      return lIllIIIIlIlI[0];
    }
    TileEntity lllllllllllllllIIlllIIIlIllIIIIl = lllllllllllllllIIlllIIIlIllIIIII.getTileEntity(lllllllllllllllIIlllIIIlIllIlIII);
    if (lIIIlIIIlIIIlI(lllllllllllllllIIlllIIIlIllIIIIl instanceof TileEntityBeacon))
    {
      lllllllllllllllIIlllIIIlIllIIllI.displayGUIChest((TileEntityBeacon)lllllllllllllllIIlllIIIlIllIIIIl);
      lllllllllllllllIIlllIIIlIllIIllI.triggerAchievement(StatList.field_181730_N);
    }
    return lIllIIIIlIlI[0];
  }
  
  private static boolean lIIIlIIIlIIIlI(int ???)
  {
    float lllllllllllllllIIlllIIIlIIlIlllI;
    return ??? != 0;
  }
  
  private static void lIIIlIIIlIIIIl()
  {
    lIllIIIIlIlI = new int[3];
    lIllIIIIlIlI[0] = " ".length();
    lIllIIIIlIlI[1] = ((0x12 ^ 0x6A ^ 0x48 ^ 0x2) & (43 + 112 - -70 + 15 ^ 100 + '¼' - 243 + 149 ^ -" ".length()));
    lIllIIIIlIlI[2] = "   ".length();
  }
  
  public boolean isOpaqueCube()
  {
    return lIllIIIIlIlI[1];
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.stats.StatList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityNote;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class BlockNote
  extends BlockContainer
{
  private static boolean llIlIIlllIllI(int ???)
  {
    float lllllllllllllllIlllIllIllIIIlIIl;
    return ??? == 0;
  }
  
  public void onBlockClicked(World lllllllllllllllIlllIlllIIIlllIIl, BlockPos lllllllllllllllIlllIlllIIIlllIII, EntityPlayer lllllllllllllllIlllIlllIIIllIlll)
  {
    ;
    ;
    ;
    ;
    if (llIlIIlllIllI(isRemote))
    {
      TileEntity lllllllllllllllIlllIlllIIIllIllI = lllllllllllllllIlllIlllIIIlllIIl.getTileEntity(lllllllllllllllIlllIlllIIIllIlII);
      if (llIlIIlllIlII(lllllllllllllllIlllIlllIIIllIllI instanceof TileEntityNote))
      {
        ((TileEntityNote)lllllllllllllllIlllIlllIIIllIllI).triggerNote(lllllllllllllllIlllIlllIIIlllIIl, lllllllllllllllIlllIlllIIIllIlII);
        lllllllllllllllIlllIlllIIIllIlll.triggerAchievement(StatList.field_181734_R);
      }
    }
  }
  
  private static boolean llIlIIlllIlIl(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIlllIllIllIIIIIll;
    return ??? != i;
  }
  
  public int getRenderType()
  {
    return lIIIlIIIlIlI[4];
  }
  
  public BlockNote()
  {
    lllllllllllllllIlllIlllIlIIlIlII.<init>(Material.wood);
    "".length();
  }
  
  private String getInstrument(int lllllllllllllllIlllIlllIIIlIIIlI)
  {
    ;
    if ((!llIlIIlllIlll(lllllllllllllllIlllIlllIIIlIIIlI)) || (llIlIIllllIII(lllllllllllllllIlllIlllIIIlIIIII, INSTRUMENTS.size()))) {
      lllllllllllllllIlllIlllIIIlIIIII = lIIIlIIIlIlI[1];
    }
    return (String)INSTRUMENTS.get(lllllllllllllllIlllIlllIIIlIIIII);
  }
  
  public TileEntity createNewTileEntity(World lllllllllllllllIlllIlllIIIlIlllI, int lllllllllllllllIlllIlllIIIlIllII)
  {
    return new TileEntityNote();
  }
  
  private static boolean llIlIIllllIIl(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIlllIllIllIIIllIl;
    return ??? < i;
  }
  
  private static void llIlIIlllIIIl()
  {
    lIIIlIIIlIlI = new int[9];
    lIIIlIIIlIlI[0] = (20 + 36 - 5 + 112 ^ '¢' + '' - 252 + 113);
    lIIIlIIIlIlI[1] = ((2 + 7 - -28 + 119 ^ 80 + '¬' - 250 + 197) & (0xC9 ^ 0xC2 ^ 0x48 ^ 0x18 ^ -" ".length()));
    lIIIlIIIlIlI[2] = " ".length();
    lIIIlIIIlIlI[3] = "  ".length();
    lIIIlIIIlIlI[4] = "   ".length();
    lIIIlIIIlIlI[5] = (0x4 ^ 0x0);
    lIIIlIIIlIlI[6] = (0x6F ^ 0x48 ^ 0x8D ^ 0xA6);
    lIIIlIIIlIlI[7] = (0x3D ^ 0x6B ^ 0x77 ^ 0x27);
    lIIIlIIIlIlI[8] = (0x97 ^ 0x9F);
  }
  
  public boolean onBlockActivated(World lllllllllllllllIlllIlllIIlIIllll, BlockPos lllllllllllllllIlllIlllIIlIIllIl, IBlockState lllllllllllllllIlllIlllIIlIllllI, EntityPlayer lllllllllllllllIlllIlllIIlIlllIl, EnumFacing lllllllllllllllIlllIlllIIlIllIll, float lllllllllllllllIlllIlllIIlIllIIl, float lllllllllllllllIlllIlllIIlIlIlll, float lllllllllllllllIlllIlllIIlIlIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIlIIlllIlII(isRemote)) {
      return lIIIlIIIlIlI[2];
    }
    TileEntity lllllllllllllllIlllIlllIIlIlIIll = lllllllllllllllIlllIlllIIlIIllll.getTileEntity(lllllllllllllllIlllIlllIIlIIllIl);
    if (llIlIIlllIlII(lllllllllllllllIlllIlllIIlIlIIll instanceof TileEntityNote))
    {
      TileEntityNote lllllllllllllllIlllIlllIIlIlIIIl = (TileEntityNote)lllllllllllllllIlllIlllIIlIlIIll;
      lllllllllllllllIlllIlllIIlIlIIIl.changePitch();
      lllllllllllllllIlllIlllIIlIlIIIl.triggerNote(lllllllllllllllIlllIlllIIlIIllll, lllllllllllllllIlllIlllIIlIIllIl);
      lllllllllllllllIlllIlllIIlIlllIl.triggerAchievement(StatList.field_181735_S);
    }
    return lIIIlIIIlIlI[2];
  }
  
  private static boolean llIlIIlllIlII(int ???)
  {
    float lllllllllllllllIlllIllIllIIIlIll;
    return ??? != 0;
  }
  
  private static String llIlIIllIlIII(String lllllllllllllllIlllIllIllllIIIlI, String lllllllllllllllIlllIllIllllIIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlllIllIllllIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIllllIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIllIllllIIllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIllIllllIIllI.init(lIIIlIIIlIlI[3], lllllllllllllllIlllIllIllllIIlll);
      return new String(lllllllllllllllIlllIllIllllIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIllllIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlllIllIllllIIlIl)
    {
      lllllllllllllllIlllIllIllllIIlIl.printStackTrace();
    }
    return null;
  }
  
  static
  {
    llIlIIlllIIIl();
    llIlIIllIlIll();
  }
  
  private static void llIlIIllIlIll()
  {
    lIIIlIIIIlll = new String[lIIIlIIIlIlI[7]];
    lIIIlIIIIlll[lIIIlIIIlIlI[1]] = llIlIIllIIllI("nJD2B/rIfw0=", "rSMOI");
    lIIIlIIIIlll[lIIIlIIIlIlI[2]] = llIlIIllIIlll("JSw=", "GHAKY");
    lIIIlIIIIlll[lIIIlIIIlIlI[3]] = llIlIIllIlIII("3WUhiMpWKJs=", "SVmaM");
    lIIIlIIIIlll[lIIIlIIIlIlI[4]] = llIlIIllIIllI("p0UzsCSjY90=", "sSdgN");
    lIIIlIIIIlll[lIIIlIIIlIlI[5]] = llIlIIllIlIII("q1oDg7nh/AnKYEJZ0KYGCg==", "mLMTm");
    lIIIlIIIIlll[lIIIlIIIlIlI[0]] = llIlIIllIlIII("FyFzi7D100o=", "UYoxS");
  }
  
  private static String llIlIIllIIlll(String lllllllllllllllIlllIllIllIlllIlI, String lllllllllllllllIlllIllIllIlllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlllIllIllIlllIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlllIllIllIlllIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIllIlllIIIIII = new StringBuilder();
    char[] lllllllllllllllIlllIllIllIlllllI = lllllllllllllllIlllIllIllIlllIII.toCharArray();
    int lllllllllllllllIlllIllIllIllllII = lIIIlIIIlIlI[1];
    float lllllllllllllllIlllIllIllIllIIIl = lllllllllllllllIlllIllIllIlllIlI.toCharArray();
    boolean lllllllllllllllIlllIllIllIllIIII = lllllllllllllllIlllIllIllIllIIIl.length;
    boolean lllllllllllllllIlllIllIllIlIllll = lIIIlIIIlIlI[1];
    while (llIlIIllllIIl(lllllllllllllllIlllIllIllIlIllll, lllllllllllllllIlllIllIllIllIIII))
    {
      char lllllllllllllllIlllIllIlllIIIlIl = lllllllllllllllIlllIllIllIllIIIl[lllllllllllllllIlllIllIllIlIllll];
      "".length();
      "".length();
      if (-" ".length() >= 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIlllIllIlllIIIIII);
  }
  
  private static boolean llIlIIlllIlll(int ???)
  {
    boolean lllllllllllllllIlllIllIllIIIIlll;
    return ??? >= 0;
  }
  
  private static boolean llIlIIllllIII(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIlllIllIllIIlIIIl;
    return ??? >= i;
  }
  
  private static String llIlIIllIIllI(String lllllllllllllllIlllIllIllIIlllll, String lllllllllllllllIlllIllIllIIllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlllIllIllIlIIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIllIllIIllIll.getBytes(StandardCharsets.UTF_8)), lIIIlIIIlIlI[8]), "DES");
      Cipher lllllllllllllllIlllIllIllIlIIIlI = Cipher.getInstance("DES");
      lllllllllllllllIlllIllIllIlIIIlI.init(lIIIlIIIlIlI[3], lllllllllllllllIlllIllIllIlIIIll);
      return new String(lllllllllllllllIlllIllIllIlIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIllIllIIlllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlllIllIllIlIIIIl)
    {
      lllllllllllllllIlllIllIllIlIIIIl.printStackTrace();
    }
    return null;
  }
  
  public boolean onBlockEventReceived(World lllllllllllllllIlllIlllIIIIIIIII, BlockPos lllllllllllllllIlllIllIllllllllI, IBlockState lllllllllllllllIlllIlllIIIIIIlll, int lllllllllllllllIlllIllIlllllllIl, int lllllllllllllllIlllIlllIIIIIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIlllIlllIIIIIIIll = (float)Math.pow(2.0D, (lllllllllllllllIlllIlllIIIIIIlIl - lIIIlIIIlIlI[6]) / 12.0D);
    lllllllllllllllIlllIlllIIIIIIIII.playSoundEffect(lllllllllllllllIlllIllIllllllllI.getX() + 0.5D, lllllllllllllllIlllIllIllllllllI.getY() + 0.5D, lllllllllllllllIlllIllIllllllllI.getZ() + 0.5D, String.valueOf(new StringBuilder(lIIIlIIIIlll[lIIIlIIIlIlI[0]]).append(lllllllllllllllIlllIlllIIIIIIIIl.getInstrument(lllllllllllllllIlllIllIlllllllIl))), 3.0F, lllllllllllllllIlllIlllIIIIIIIll);
    lllllllllllllllIlllIlllIIIIIIIII.spawnParticle(EnumParticleTypes.NOTE, lllllllllllllllIlllIllIllllllllI.getX() + 0.5D, lllllllllllllllIlllIllIllllllllI.getY() + 1.2D, lllllllllllllllIlllIllIllllllllI.getZ() + 0.5D, lllllllllllllllIlllIlllIIIIIIlIl / 24.0D, 0.0D, 0.0D, new int[lIIIlIIIlIlI[1]]);
    return lIIIlIIIlIlI[2];
  }
  
  public void onNeighborBlockChange(World lllllllllllllllIlllIlllIIlllIIlI, BlockPos lllllllllllllllIlllIlllIIlllIIIl, IBlockState lllllllllllllllIlllIlllIIlllIlll, Block lllllllllllllllIlllIlllIIlllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    boolean lllllllllllllllIlllIlllIIlllIlIl = lllllllllllllllIlllIlllIIlllIIlI.isBlockPowered(lllllllllllllllIlllIlllIIlllIIIl);
    TileEntity lllllllllllllllIlllIlllIIlllIlII = lllllllllllllllIlllIlllIIlllIIlI.getTileEntity(lllllllllllllllIlllIlllIIlllIIIl);
    if (llIlIIlllIlII(lllllllllllllllIlllIlllIIlllIlII instanceof TileEntityNote))
    {
      TileEntityNote lllllllllllllllIlllIlllIIlllIIll = (TileEntityNote)lllllllllllllllIlllIlllIIlllIlII;
      if (llIlIIlllIlIl(previousRedstoneState, lllllllllllllllIlllIlllIIlllIlIl))
      {
        if (llIlIIlllIlII(lllllllllllllllIlllIlllIIlllIlIl)) {
          lllllllllllllllIlllIlllIIlllIIll.triggerNote(lllllllllllllllIlllIlllIIlllIIlI, lllllllllllllllIlllIlllIIlllIIIl);
        }
        previousRedstoneState = lllllllllllllllIlllIlllIIlllIlIl;
      }
    }
  }
}

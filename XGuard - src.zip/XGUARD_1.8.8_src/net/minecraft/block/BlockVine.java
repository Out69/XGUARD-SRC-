package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.ColorizerFoliage;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase;

public class BlockVine
  extends Block
{
  public boolean isFullCube()
  {
    return lIIIlIIIIll[0];
  }
  
  private static boolean llIlllIIllll(int ???, int arg1)
  {
    int i;
    double lllllllllllllllllIlIllIIlIlIIlll;
    return ??? < i;
  }
  
  private static boolean llIlllIIllII(Object ???, Object arg1)
  {
    Object localObject;
    boolean lllllllllllllllllIlIllIIlIIlllll;
    return ??? != localObject;
  }
  
  private static String llIIlIlIIIlI(String lllllllllllllllllIlIllIIlIllIlll, String lllllllllllllllllIlIllIIlIllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIlIllIIlIllIlll = new String(Base64.getDecoder().decode(lllllllllllllllllIlIllIIlIllIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIlIllIIlIlllIlI = new StringBuilder();
    char[] lllllllllllllllllIlIllIIlIlllIIl = lllllllllllllllllIlIllIIlIllIllI.toCharArray();
    int lllllllllllllllllIlIllIIlIlllIII = lIIIlIIIIll[0];
    Exception lllllllllllllllllIlIllIIlIllIIlI = lllllllllllllllllIlIllIIlIllIlll.toCharArray();
    boolean lllllllllllllllllIlIllIIlIllIIIl = lllllllllllllllllIlIllIIlIllIIlI.length;
    boolean lllllllllllllllllIlIllIIlIllIIII = lIIIlIIIIll[0];
    while (llIlllIIllll(lllllllllllllllllIlIllIIlIllIIII, lllllllllllllllllIlIllIIlIllIIIl))
    {
      char lllllllllllllllllIlIllIIlIllllIl = lllllllllllllllllIlIllIIlIllIIlI[lllllllllllllllllIlIllIIlIllIIII];
      "".length();
      "".length();
      if (" ".length() > "  ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIlIllIIlIlllIlI);
  }
  
  public void updateTick(World lllllllllllllllllIlIllIlIlIlIlIl, BlockPos lllllllllllllllllIlIllIlIlIlIlII, IBlockState lllllllllllllllllIlIllIlIlIlIIll, Random lllllllllllllllllIlIllIlIlllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((llIlllIIlIIl(isRemote)) && (llIlllIIlIIl(rand.nextInt(lIIIlIIIIll[4]))))
    {
      int lllllllllllllllllIlIllIlIlllIIll = lIIIlIIIIll[4];
      int lllllllllllllllllIlIllIlIlllIIlI = lIIIlIIIIll[5];
      boolean lllllllllllllllllIlIllIlIlllIIIl = lIIIlIIIIll[0];
      int lllllllllllllllllIlIllIlIlllIIII = -lllllllllllllllllIlIllIlIlllIIll;
      "".length();
      if (-(0xB8 ^ 0xBC) >= 0) {
        return;
      }
      while (!llIlllIIlllI(lllllllllllllllllIlIllIlIlllIIII, lllllllllllllllllIlIllIlIlllIIll))
      {
        int lllllllllllllllllIlIllIlIllIllll = -lllllllllllllllllIlIllIlIlllIIll;
        "".length();
        if ((0x34 ^ 0x31) == 0) {
          return;
        }
        while (!llIlllIIlllI(lllllllllllllllllIlIllIlIllIllll, lllllllllllllllllIlIllIlIlllIIll))
        {
          int lllllllllllllllllIlIllIlIllIlllI = lIIIlIIIIll[6];
          "".length();
          if ("  ".length() < -" ".length()) {
            return;
          }
          while (!llIlllIIlllI(lllllllllllllllllIlIllIlIllIlllI, lIIIlIIIIll[1]))
          {
            if (llIlllIIlIlI(lllllllllllllllllIlIllIlIlIlIlIl.getBlockState(lllllllllllllllllIlIllIlIlllIllI.add(lllllllllllllllllIlIllIlIlllIIII, lllllllllllllllllIlIllIlIllIlllI, lllllllllllllllllIlIllIlIllIllll)).getBlock(), lllllllllllllllllIlIllIlIllllIII))
            {
              lllllllllllllllllIlIllIlIlllIIlI--;
              if (llIlllIIllIl(lllllllllllllllllIlIllIlIlllIIlI))
              {
                lllllllllllllllllIlIllIlIlllIIIl = lIIIlIIIIll[1];
                "".length();
                if (" ".length() > 0) {
                  break;
                }
                return;
              }
            }
            lllllllllllllllllIlIllIlIllIlllI++;
          }
          lllllllllllllllllIlIllIlIllIllll++;
        }
        lllllllllllllllllIlIllIlIlllIIII++;
      }
      EnumFacing lllllllllllllllllIlIllIlIllIllIl = EnumFacing.random(lllllllllllllllllIlIllIlIlllIlII);
      BlockPos lllllllllllllllllIlIllIlIllIllII = lllllllllllllllllIlIllIlIlllIllI.up();
      if ((llIlllIIlIlI(lllllllllllllllllIlIllIlIllIllIl, EnumFacing.UP)) && (llIlllIIllll(lllllllllllllllllIlIllIlIlllIllI.getY(), lIIIlIIIIll[7])) && (llIlllIIlIII(lllllllllllllllllIlIllIlIlIlIlIl.isAirBlock(lllllllllllllllllIlIllIlIllIllII))))
      {
        if (llIlllIIlIIl(lllllllllllllllllIlIllIlIlllIIIl))
        {
          IBlockState lllllllllllllllllIlIllIlIllIlIll = lllllllllllllllllIlIllIlIlIlIIll;
          lllllllllllllllllIlIllIlIlIIlIlI = EnumFacing.Plane.HORIZONTAL.iterator();
          "".length();
          if ("   ".length() == 0) {
            return;
          }
          while (!llIlllIIlIIl(lllllllllllllllllIlIllIlIlIIlIlI.hasNext()))
          {
            Object lllllllllllllllllIlIllIlIllIlIlI = lllllllllllllllllIlIllIlIlIIlIlI.next();
            EnumFacing lllllllllllllllllIlIllIlIllIlIIl = (EnumFacing)lllllllllllllllllIlIllIlIllIlIlI;
            if ((!llIlllIIlIIl(lllllllllllllllllIlIllIlIlllIlII.nextBoolean())) || (llIlllIIlIIl(lllllllllllllllllIlIllIlIllllIII.canPlaceOn(lllllllllllllllllIlIllIlIlIlIlIl.getBlockState(lllllllllllllllllIlIllIlIllIllII.offset(lllllllllllllllllIlIllIlIllIlIIl)).getBlock())))) {
              lllllllllllllllllIlIllIlIllIlIll = lllllllllllllllllIlIllIlIllIlIll.withProperty(getPropertyFor(lllllllllllllllllIlIllIlIllIlIIl), Boolean.valueOf(lIIIlIIIIll[0]));
            }
          }
          if ((!llIlllIIlIIl(((Boolean)lllllllllllllllllIlIllIlIllIlIll.getValue(NORTH)).booleanValue())) || (!llIlllIIlIIl(((Boolean)lllllllllllllllllIlIllIlIllIlIll.getValue(EAST)).booleanValue())) || (!llIlllIIlIIl(((Boolean)lllllllllllllllllIlIllIlIllIlIll.getValue(SOUTH)).booleanValue())) || (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIlIllIlIll.getValue(WEST)).booleanValue())))
          {
            "".length();
            "".length();
            if (null == null) {}
          }
        }
      }
      else
      {
        boolean lllllllllllllllllIlIllIlIllIIIll;
        if ((llIlllIIlIII(lllllllllllllllllIlIllIlIllIllIl.getAxis().isHorizontal())) && (llIlllIIlIIl(((Boolean)lllllllllllllllllIlIllIlIlIlIIll.getValue(getPropertyFor(lllllllllllllllllIlIllIlIllIllIl))).booleanValue())))
        {
          if (llIlllIIlIIl(lllllllllllllllllIlIllIlIlllIIIl))
          {
            BlockPos lllllllllllllllllIlIllIlIllIlIII = lllllllllllllllllIlIllIlIlllIllI.offset(lllllllllllllllllIlIllIlIllIllIl);
            Block lllllllllllllllllIlIllIlIllIIlll = lllllllllllllllllIlIllIlIlIlIlIl.getBlockState(lllllllllllllllllIlIllIlIllIlIII).getBlock();
            if (llIlllIIlIlI(blockMaterial, Material.air))
            {
              EnumFacing lllllllllllllllllIlIllIlIllIIllI = lllllllllllllllllIlIllIlIllIllIl.rotateY();
              EnumFacing lllllllllllllllllIlIllIlIllIIlIl = lllllllllllllllllIlIllIlIllIllIl.rotateYCCW();
              boolean lllllllllllllllllIlIllIlIllIIlII = ((Boolean)lllllllllllllllllIlIllIlIlIlIIll.getValue(getPropertyFor(lllllllllllllllllIlIllIlIllIIllI))).booleanValue();
              lllllllllllllllllIlIllIlIllIIIll = ((Boolean)lllllllllllllllllIlIllIlIlIlIIll.getValue(getPropertyFor(lllllllllllllllllIlIllIlIllIIlIl))).booleanValue();
              BlockPos lllllllllllllllllIlIllIlIllIIIlI = lllllllllllllllllIlIllIlIllIlIII.offset(lllllllllllllllllIlIllIlIllIIllI);
              BlockPos lllllllllllllllllIlIllIlIllIIIIl = lllllllllllllllllIlIllIlIllIlIII.offset(lllllllllllllllllIlIllIlIllIIlIl);
              if ((llIlllIIlIII(lllllllllllllllllIlIllIlIllIIlII)) && (llIlllIIlIII(lllllllllllllllllIlIllIlIllllIII.canPlaceOn(lllllllllllllllllIlIllIlIlIlIlIl.getBlockState(lllllllllllllllllIlIllIlIllIIIlI).getBlock()))))
              {
                "".length();
                "".length();
                if (-" ".length() < " ".length()) {}
              }
              else if ((llIlllIIlIII(lllllllllllllllllIlIllIlIllIIIll)) && (llIlllIIlIII(lllllllllllllllllIlIllIlIllllIII.canPlaceOn(lllllllllllllllllIlIllIlIlIlIlIl.getBlockState(lllllllllllllllllIlIllIlIllIIIIl).getBlock()))))
              {
                "".length();
                "".length();
                if ((60 + '' - 89 + 31 ^ 99 + 44 - 81 + 92) != 0) {}
              }
              else if ((llIlllIIlIII(lllllllllllllllllIlIllIlIllIIlII)) && (llIlllIIlIII(lllllllllllllllllIlIllIlIlIlIlIl.isAirBlock(lllllllllllllllllIlIllIlIllIIIlI))) && (llIlllIIlIII(lllllllllllllllllIlIllIlIllllIII.canPlaceOn(lllllllllllllllllIlIllIlIlIlIlIl.getBlockState(lllllllllllllllllIlIllIlIlllIllI.offset(lllllllllllllllllIlIllIlIllIIllI)).getBlock()))))
              {
                "".length();
                "".length();
                if (null == null) {}
              }
              else if ((llIlllIIlIII(lllllllllllllllllIlIllIlIllIIIll)) && (llIlllIIlIII(lllllllllllllllllIlIllIlIlIlIlIl.isAirBlock(lllllllllllllllllIlIllIlIllIIIIl))) && (llIlllIIlIII(lllllllllllllllllIlIllIlIllllIII.canPlaceOn(lllllllllllllllllIlIllIlIlIlIlIl.getBlockState(lllllllllllllllllIlIllIlIlllIllI.offset(lllllllllllllllllIlIllIlIllIIlIl)).getBlock()))))
              {
                "".length();
                "".length();
                if (((0x71 ^ 0x11) & (0x52 ^ 0x32 ^ 0xFFFFFFFF)) < (0x81 ^ 0x85)) {}
              }
              else if (llIlllIIlIII(lllllllllllllllllIlIllIlIllllIII.canPlaceOn(lllllllllllllllllIlIllIlIlIlIlIl.getBlockState(lllllllllllllllllIlIllIlIllIlIII.up()).getBlock())))
              {
                "".length();
                "".length();
                if (((0x73 ^ 0x5E) & (0x3 ^ 0x2E ^ 0xFFFFFFFF)) == 0) {}
              }
            }
            else if ((llIlllIIlIII(blockMaterial.isOpaque())) && (llIlllIIlIII(lllllllllllllllllIlIllIlIllIIlll.isFullCube())))
            {
              "".length();
              "".length();
              if (-" ".length() <= " ".length()) {}
            }
          }
        }
        else if (llIlllIIlllI(lllllllllllllllllIlIllIlIlllIllI.getY(), lIIIlIIIIll[1]))
        {
          BlockPos lllllllllllllllllIlIllIlIllIIIII = lllllllllllllllllIlIllIlIlllIllI.down();
          IBlockState lllllllllllllllllIlIllIlIlIlllll = lllllllllllllllllIlIllIlIlIlIlIl.getBlockState(lllllllllllllllllIlIllIlIllIIIII);
          Block lllllllllllllllllIlIllIlIlIllllI = lllllllllllllllllIlIllIlIlIlllll.getBlock();
          if (llIlllIIlIlI(blockMaterial, Material.air))
          {
            IBlockState lllllllllllllllllIlIllIlIlIlllIl = lllllllllllllllllIlIllIlIlIlIIll;
            lllllllllllllllllIlIllIlIllIIIll = EnumFacing.Plane.HORIZONTAL.iterator();
            "".length();
            if ((0x64 ^ 0x61) <= 0) {
              return;
            }
            while (!llIlllIIlIIl(lllllllllllllllllIlIllIlIllIIIll.hasNext()))
            {
              Object lllllllllllllllllIlIllIlIlIlllII = lllllllllllllllllIlIllIlIllIIIll.next();
              EnumFacing lllllllllllllllllIlIllIlIlIllIll = (EnumFacing)lllllllllllllllllIlIllIlIlIlllII;
              if (llIlllIIlIII(lllllllllllllllllIlIllIlIlllIlII.nextBoolean())) {
                lllllllllllllllllIlIllIlIlIlllIl = lllllllllllllllllIlIllIlIlIlllIl.withProperty(getPropertyFor(lllllllllllllllllIlIllIlIlIllIll), Boolean.valueOf(lIIIlIIIIll[0]));
              }
            }
            if ((!llIlllIIlIIl(((Boolean)lllllllllllllllllIlIllIlIlIlllIl.getValue(NORTH)).booleanValue())) || (!llIlllIIlIIl(((Boolean)lllllllllllllllllIlIllIlIlIlllIl.getValue(EAST)).booleanValue())) || (!llIlllIIlIIl(((Boolean)lllllllllllllllllIlIllIlIlIlllIl.getValue(SOUTH)).booleanValue())) || (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIlIlIlllIl.getValue(WEST)).booleanValue())))
            {
              "".length();
              "".length();
              if (-" ".length() < "  ".length()) {}
            }
          }
          else if (llIlllIIlIlI(lllllllllllllllllIlIllIlIlIllllI, lllllllllllllllllIlIllIlIllllIII))
          {
            IBlockState lllllllllllllllllIlIllIlIlIllIlI = lllllllllllllllllIlIllIlIlIlllll;
            lllllllllllllllllIlIllIlIllIIIll = EnumFacing.Plane.HORIZONTAL.iterator();
            "".length();
            if (" ".length() < " ".length()) {
              return;
            }
            while (!llIlllIIlIIl(lllllllllllllllllIlIllIlIllIIIll.hasNext()))
            {
              Object lllllllllllllllllIlIllIlIlIllIIl = lllllllllllllllllIlIllIlIllIIIll.next();
              EnumFacing lllllllllllllllllIlIllIlIlIllIII = (EnumFacing)lllllllllllllllllIlIllIlIlIllIIl;
              PropertyBool lllllllllllllllllIlIllIlIlIlIlll = getPropertyFor(lllllllllllllllllIlIllIlIlIllIII);
              if ((llIlllIIlIII(lllllllllllllllllIlIllIlIlllIlII.nextBoolean())) && (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIlIlIlIIll.getValue(lllllllllllllllllIlIllIlIlIlIlll)).booleanValue()))) {
                lllllllllllllllllIlIllIlIlIllIlI = lllllllllllllllllIlIllIlIlIllIlI.withProperty(lllllllllllllllllIlIllIlIlIlIlll, Boolean.valueOf(lIIIlIIIIll[1]));
              }
            }
            if ((!llIlllIIlIIl(((Boolean)lllllllllllllllllIlIllIlIlIllIlI.getValue(NORTH)).booleanValue())) || (!llIlllIIlIIl(((Boolean)lllllllllllllllllIlIllIlIlIllIlI.getValue(EAST)).booleanValue())) || (!llIlllIIlIIl(((Boolean)lllllllllllllllllIlIllIlIlIllIlI.getValue(SOUTH)).booleanValue())) || (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIlIlIllIlI.getValue(WEST)).booleanValue()))) {
              "".length();
            }
          }
        }
      }
    }
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    lllllllllllllllllIlIllIllllllIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  
  private boolean recheckGrownSides(World lllllllllllllllllIlIllIllIlIlIll, BlockPos lllllllllllllllllIlIllIllIlIlIlI, IBlockState lllllllllllllllllIlIllIllIlIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState lllllllllllllllllIlIllIllIllIIIl = lllllllllllllllllIlIllIllIlIlIIl;
    short lllllllllllllllllIlIllIllIlIIllI = EnumFacing.Plane.HORIZONTAL.iterator();
    "".length();
    if (-" ".length() >= "  ".length()) {
      return (0x51 ^ 0xD) & (0x57 ^ 0xB ^ 0xFFFFFFFF);
    }
    while (!llIlllIIlIIl(lllllllllllllllllIlIllIllIlIIllI.hasNext()))
    {
      Object lllllllllllllllllIlIllIllIllIIII = lllllllllllllllllIlIllIllIlIIllI.next();
      EnumFacing lllllllllllllllllIlIllIllIlIllll = (EnumFacing)lllllllllllllllllIlIllIllIllIIII;
      PropertyBool lllllllllllllllllIlIllIllIlIlllI = getPropertyFor(lllllllllllllllllIlIllIllIlIllll);
      if ((llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIllIlIlIIl.getValue(lllllllllllllllllIlIllIllIlIlllI)).booleanValue())) && (llIlllIIlIIl(lllllllllllllllllIlIllIllIlIllII.canPlaceOn(lllllllllllllllllIlIllIllIlIlIll.getBlockState(lllllllllllllllllIlIllIllIlIlIlI.offset(lllllllllllllllllIlIllIllIlIllll)).getBlock()))))
      {
        IBlockState lllllllllllllllllIlIllIllIlIllIl = lllllllllllllllllIlIllIllIlIlIll.getBlockState(lllllllllllllllllIlIllIllIlIlIlI.up());
        if ((!llIlllIIlIlI(lllllllllllllllllIlIllIllIlIllIl.getBlock(), lllllllllllllllllIlIllIllIlIllII)) || (llIlllIIlIIl(((Boolean)lllllllllllllllllIlIllIllIlIllIl.getValue(lllllllllllllllllIlIllIllIlIlllI)).booleanValue()))) {
          lllllllllllllllllIlIllIllIlIlIIl = lllllllllllllllllIlIllIllIlIlIIl.withProperty(lllllllllllllllllIlIllIllIlIlllI, Boolean.valueOf(lIIIlIIIIll[0]));
        }
      }
    }
    if (llIlllIIlIIl(getNumGrownFaces(lllllllllllllllllIlIllIllIlIlIIl))) {
      return lIIIlIIIIll[0];
    }
    if (llIlllIIllII(lllllllllllllllllIlIllIllIllIIIl, lllllllllllllllllIlIllIllIlIlIIl)) {
      "".length();
    }
    return lIIIlIIIIll[1];
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllllIlIllIlIIIIlIll)
  {
    ;
    ;
    int lllllllllllllllllIlIllIlIIIIllII = lIIIlIIIIll[0];
    if (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIlIIIIllIl.getValue(SOUTH)).booleanValue())) {
      lllllllllllllllllIlIllIlIIIIllII |= lIIIlIIIIll[1];
    }
    if (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIlIIIIllIl.getValue(WEST)).booleanValue())) {
      lllllllllllllllllIlIllIlIIIIllII |= lIIIlIIIIll[2];
    }
    if (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIlIIIIllIl.getValue(NORTH)).booleanValue())) {
      lllllllllllllllllIlIllIlIIIIllII |= lIIIlIIIIll[4];
    }
    if (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIlIIIIllIl.getValue(EAST)).booleanValue())) {
      lllllllllllllllllIlIllIlIIIIllII |= lIIIlIIIIll[8];
    }
    return lllllllllllllllllIlIllIlIIIIllII;
  }
  
  private static boolean llIlllIlIIlI(int ???)
  {
    int lllllllllllllllllIlIllIIlIIlIIIl;
    return ??? > 0;
  }
  
  public boolean canPlaceBlockOnSide(World lllllllllllllllllIlIllIlllIIlIlI, BlockPos lllllllllllllllllIlIllIlllIIIlIl, EnumFacing lllllllllllllllllIlIllIlllIIlIII)
  {
    ;
    ;
    ;
    ;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[lllllllllllllllllIlIllIlllIIlIII.ordinal()])
    {
    case 2: 
      return lllllllllllllllllIlIllIlllIIlIll.canPlaceOn(lllllllllllllllllIlIllIlllIIlIlI.getBlockState(lllllllllllllllllIlIllIlllIIIlIl.up()).getBlock());
    case 3: 
    case 4: 
    case 5: 
    case 6: 
      return lllllllllllllllllIlIllIlllIIlIll.canPlaceOn(lllllllllllllllllIlIllIlllIIlIlI.getBlockState(lllllllllllllllllIlIllIlllIIIlIl.offset(lllllllllllllllllIlIllIlllIIlIII.getOpposite())).getBlock());
    }
    return lIIIlIIIIll[0];
  }
  
  private static boolean llIlllIIlIlI(Object ???, Object arg1)
  {
    Object localObject;
    long lllllllllllllllllIlIllIIlIIllIll;
    return ??? == localObject;
  }
  
  public static int getNumGrownFaces(IBlockState lllllllllllllllllIlIllIIlllIIIII)
  {
    ;
    ;
    ;
    ;
    int lllllllllllllllllIlIllIIlllIIlII = lIIIlIIIIll[0];
    String lllllllllllllllllIlIllIIllIllIII = (lllllllllllllllllIlIllIIllIlIllI = ALL_FACES).length;
    double lllllllllllllllllIlIllIIllIllIlI = lIIIlIIIIll[0];
    "".length();
    if ((0x23 ^ 0x27) > (0x9F ^ 0x9B)) {
      return (0xB5 ^ 0xAB) & (0x17 ^ 0x9 ^ 0xFFFFFFFF);
    }
    while (!llIlllIlIIll(lllllllllllllllllIlIllIIllIllIlI, lllllllllllllllllIlIllIIllIllIII))
    {
      PropertyBool lllllllllllllllllIlIllIIlllIIIlI = lllllllllllllllllIlIllIIllIlIllI[lllllllllllllllllIlIllIIllIllIlI];
      if (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIIlllIIllI.getValue(lllllllllllllllllIlIllIIlllIIIlI)).booleanValue())) {
        lllllllllllllllllIlIllIIlllIIlII++;
      }
      lllllllllllllllllIlIllIIllIllIlI++;
    }
    return lllllllllllllllllIlIllIIlllIIlII;
  }
  
  private static boolean llIlllIIllIl(int ???)
  {
    boolean lllllllllllllllllIlIllIIlIIlIIll;
    return ??? <= 0;
  }
  
  public BlockVine()
  {
    lllllllllllllllllIlIlllIIIIIIlll.<init>(Material.vine);
    lllllllllllllllllIlIlllIIIIIlIII.setDefaultState(blockState.getBaseState().withProperty(UP, Boolean.valueOf(lIIIlIIIIll[0])).withProperty(NORTH, Boolean.valueOf(lIIIlIIIIll[0])).withProperty(EAST, Boolean.valueOf(lIIIlIIIIll[0])).withProperty(SOUTH, Boolean.valueOf(lIIIlIIIIll[0])).withProperty(WEST, Boolean.valueOf(lIIIlIIIIll[0])));
    "".length();
    "".length();
  }
  
  public IBlockState getStateFromMeta(int lllllllllllllllllIlIllIlIIIlIllI)
  {
    ;
    ;
    if (llIlllIlIIlI(lllllllllllllllllIlIllIlIIIlIllI & lIIIlIIIIll[1]))
    {
      "".length();
      if (-"  ".length() < 0) {
        break label47;
      }
      return null;
    }
    label47:
    if (llIlllIlIIlI(lllllllllllllllllIlIllIlIIIlIllI & lIIIlIIIIll[2]))
    {
      "".length();
      if (((0xA2 ^ 0xA9) & (0x36 ^ 0x3D ^ 0xFFFFFFFF)) <= 0) {
        break label107;
      }
      return null;
    }
    label107:
    if (llIlllIlIIlI(lllllllllllllllllIlIllIlIIIlIllI & lIIIlIIIIll[4]))
    {
      "".length();
      if ("  ".length() > " ".length()) {
        break label162;
      }
      return null;
    }
    label162:
    if (llIlllIlIIlI(lllllllllllllllllIlIllIlIIIlIllI & lIIIlIIIIll[8]))
    {
      "".length();
      if ((0x2B ^ 0x6 ^ 0x3B ^ 0x12) != 0) {
        break label219;
      }
      return null;
    }
    label219:
    return EAST.withProperty(lIIIlIIIIll[1], Boolean.valueOf(lIIIlIIIIll[0]));
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public IBlockState getActualState(IBlockState lllllllllllllllllIlIllIlllllllll, IBlockAccess lllllllllllllllllIlIllIllllllllI, BlockPos lllllllllllllllllIlIlllIIIIIIIII)
  {
    ;
    ;
    ;
    return lllllllllllllllllIlIllIlllllllll.withProperty(UP, Boolean.valueOf(lllllllllllllllllIlIlllIIIIIIIIl.getBlockState(lllllllllllllllllIlIlllIIIIIIIII.up()).getBlock().isBlockNormalCube()));
  }
  
  public boolean isReplaceable(World lllllllllllllllllIlIllIlllllIllI, BlockPos lllllllllllllllllIlIllIlllllIlIl)
  {
    return lIIIlIIIIll[1];
  }
  
  private static void llIlllIIIlll()
  {
    lIIIlIIIIll = new int[10];
    lIIIlIIIIll[0] = ((0x20 ^ 0x1D ^ 0x9 ^ 0x63) & (0x97 ^ 0x8A ^ 0xD ^ 0x47 ^ -" ".length()) & ((0xF4 ^ 0xB4 ^ 0xEF ^ 0xA2) & (0x21 ^ 0x78 ^ 0x66 ^ 0x32 ^ -" ".length()) ^ -" ".length()));
    lIIIlIIIIll[1] = " ".length();
    lIIIlIIIIll[2] = "  ".length();
    lIIIlIIIIll[3] = "   ".length();
    lIIIlIIIIll[4] = (0xC ^ 0x68 ^ 0xD6 ^ 0xB6);
    lIIIlIIIIll[5] = (0xAD ^ 0xA8);
    lIIIlIIIIll[6] = (-" ".length());
    lIIIlIIIIll[7] = ((0x50 ^ 0x55) + (0xCF ^ 0x85) - -(0x48 ^ 0x44) + ('' + 86 - 105 + 38));
    lIIIlIIIIll[8] = (0xD ^ 0x5);
    lIIIlIIIIll[9] = (0xC9 ^ 0xAF ^ 0x3C ^ 0x5C);
  }
  
  public static PropertyBool getPropertyFor(EnumFacing lllllllllllllllllIlIllIIllllIlll)
  {
    ;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[lllllllllllllllllIlIllIIllllIlIl.ordinal()])
    {
    case 2: 
      return UP;
    case 3: 
      return NORTH;
    case 4: 
      return SOUTH;
    case 6: 
      return EAST;
    case 5: 
      return WEST;
    }
    throw new IllegalArgumentException(String.valueOf(new StringBuilder().append(lllllllllllllllllIlIllIIllllIlIl).append(lllllllIIl[lIIIlIIIIll[5]])));
  }
  
  public void onNeighborBlockChange(World lllllllllllllllllIlIllIllIIIllIl, BlockPos lllllllllllllllllIlIllIllIIIllII, IBlockState lllllllllllllllllIlIllIllIIlIIII, Block lllllllllllllllllIlIllIllIIIllll)
  {
    ;
    ;
    ;
    ;
    if ((llIlllIIlIIl(isRemote)) && (llIlllIIlIIl(lllllllllllllllllIlIllIllIIlIIll.recheckGrownSides(lllllllllllllllllIlIllIllIIIllIl, lllllllllllllllllIlIllIllIIlIIIl, lllllllllllllllllIlIllIllIIlIIII))))
    {
      lllllllllllllllllIlIllIllIIlIIll.dropBlockAsItem(lllllllllllllllllIlIllIllIIIllIl, lllllllllllllllllIlIllIllIIlIIIl, lllllllllllllllllIlIllIllIIlIIII, lIIIlIIIIll[0]);
      "".length();
    }
  }
  
  private static boolean llIlllIlIIII(Object ???)
  {
    short lllllllllllllllllIlIllIIlIIllIIl;
    return ??? != null;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World lllllllllllllllllIlIllIlllIlIIlI, BlockPos lllllllllllllllllIlIllIlllIlIIIl, IBlockState lllllllllllllllllIlIllIlllIlIIII)
  {
    return null;
  }
  
  private static boolean llIlllIIlllI(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllllIlIllIIlIlIIIll;
    return ??? > i;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess lllllllllllllllllIlIllIlllIlllIl, BlockPos lllllllllllllllllIlIllIllllIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllllIlIllIllllIIllI = 0.0625F;
    float lllllllllllllllllIlIllIllllIIlIl = 1.0F;
    float lllllllllllllllllIlIllIllllIIlII = 1.0F;
    float lllllllllllllllllIlIllIllllIIIll = 1.0F;
    float lllllllllllllllllIlIllIllllIIIlI = 0.0F;
    float lllllllllllllllllIlIllIllllIIIIl = 0.0F;
    float lllllllllllllllllIlIllIllllIIIII = 0.0F;
    boolean lllllllllllllllllIlIllIlllIlllll = lIIIlIIIIll[0];
    if (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIllllIlIII.getBlockState(lllllllllllllllllIlIllIllllIIlll).getValue(WEST)).booleanValue()))
    {
      lllllllllllllllllIlIllIllllIIIlI = Math.max(lllllllllllllllllIlIllIllllIIIlI, 0.0625F);
      lllllllllllllllllIlIllIllllIIlIl = 0.0F;
      lllllllllllllllllIlIllIllllIIlII = 0.0F;
      lllllllllllllllllIlIllIllllIIIIl = 1.0F;
      lllllllllllllllllIlIllIllllIIIll = 0.0F;
      lllllllllllllllllIlIllIllllIIIII = 1.0F;
      lllllllllllllllllIlIllIlllIlllll = lIIIlIIIIll[1];
    }
    if (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIllllIlIII.getBlockState(lllllllllllllllllIlIllIllllIIlll).getValue(EAST)).booleanValue()))
    {
      lllllllllllllllllIlIllIllllIIlIl = Math.min(lllllllllllllllllIlIllIllllIIlIl, 0.9375F);
      lllllllllllllllllIlIllIllllIIIlI = 1.0F;
      lllllllllllllllllIlIllIllllIIlII = 0.0F;
      lllllllllllllllllIlIllIllllIIIIl = 1.0F;
      lllllllllllllllllIlIllIllllIIIll = 0.0F;
      lllllllllllllllllIlIllIllllIIIII = 1.0F;
      lllllllllllllllllIlIllIlllIlllll = lIIIlIIIIll[1];
    }
    if (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIllllIlIII.getBlockState(lllllllllllllllllIlIllIllllIIlll).getValue(NORTH)).booleanValue()))
    {
      lllllllllllllllllIlIllIllllIIIII = Math.max(lllllllllllllllllIlIllIllllIIIII, 0.0625F);
      lllllllllllllllllIlIllIllllIIIll = 0.0F;
      lllllllllllllllllIlIllIllllIIlIl = 0.0F;
      lllllllllllllllllIlIllIllllIIIlI = 1.0F;
      lllllllllllllllllIlIllIllllIIlII = 0.0F;
      lllllllllllllllllIlIllIllllIIIIl = 1.0F;
      lllllllllllllllllIlIllIlllIlllll = lIIIlIIIIll[1];
    }
    if (llIlllIIlIII(((Boolean)lllllllllllllllllIlIllIllllIlIII.getBlockState(lllllllllllllllllIlIllIllllIIlll).getValue(SOUTH)).booleanValue()))
    {
      lllllllllllllllllIlIllIllllIIIll = Math.min(lllllllllllllllllIlIllIllllIIIll, 0.9375F);
      lllllllllllllllllIlIllIllllIIIII = 1.0F;
      lllllllllllllllllIlIllIllllIIlIl = 0.0F;
      lllllllllllllllllIlIllIllllIIIlI = 1.0F;
      lllllllllllllllllIlIllIllllIIlII = 0.0F;
      lllllllllllllllllIlIllIllllIIIIl = 1.0F;
      lllllllllllllllllIlIllIlllIlllll = lIIIlIIIIll[1];
    }
    if ((llIlllIIlIIl(lllllllllllllllllIlIllIlllIlllll)) && (llIlllIIlIII(lllllllllllllllllIlIllIlllIllllI.canPlaceOn(lllllllllllllllllIlIllIllllIlIII.getBlockState(lllllllllllllllllIlIllIllllIIlll.up()).getBlock()))))
    {
      lllllllllllllllllIlIllIllllIIlII = Math.min(lllllllllllllllllIlIllIllllIIlII, 0.9375F);
      lllllllllllllllllIlIllIllllIIIIl = 1.0F;
      lllllllllllllllllIlIllIllllIIlIl = 0.0F;
      lllllllllllllllllIlIllIllllIIIlI = 1.0F;
      lllllllllllllllllIlIllIllllIIIll = 0.0F;
      lllllllllllllllllIlIllIllllIIIII = 1.0F;
    }
    lllllllllllllllllIlIllIlllIllllI.setBlockBounds(lllllllllllllllllIlIllIllllIIlIl, lllllllllllllllllIlIllIllllIIlII, lllllllllllllllllIlIllIllllIIIll, lllllllllllllllllIlIllIllllIIIlI, lllllllllllllllllIlIllIllllIIIIl, lllllllllllllllllIlIllIllllIIIII);
  }
  
  private static boolean llIlllIIlIIl(int ???)
  {
    int lllllllllllllllllIlIllIIlIIlIlIl;
    return ??? == 0;
  }
  
  public int quantityDropped(Random lllllllllllllllllIlIllIlIIlIllll)
  {
    return lIIIlIIIIll[0];
  }
  
  private boolean canPlaceOn(Block lllllllllllllllllIlIllIlllIIIIIl)
  {
    ;
    if ((llIlllIIlIII(lllllllllllllllllIlIllIlllIIIIIl.isFullCube())) && (llIlllIIlIII(blockMaterial.blocksMovement()))) {
      return lIIIlIIIIll[1];
    }
    return lIIIlIIIIll[0];
  }
  
  private static boolean llIlllIIlIII(int ???)
  {
    short lllllllllllllllllIlIllIIlIIlIlll;
    return ??? != 0;
  }
  
  public int getBlockColor()
  {
    return ColorizerFoliage.getFoliageColorBasic();
  }
  
  public int colorMultiplier(IBlockAccess lllllllllllllllllIlIllIllIIlllII, BlockPos lllllllllllllllllIlIllIllIIllIll, int lllllllllllllllllIlIllIllIIllIlI)
  {
    ;
    ;
    return lllllllllllllllllIlIllIllIIlllII.getBiomeGenForCoords(lllllllllllllllllIlIllIllIIllIII).getFoliageColorAtPos(lllllllllllllllllIlIllIllIIllIII);
  }
  
  private static void llIIlIlIIIll()
  {
    lllllllIIl = new String[lIIIlIIIIll[9]];
    lllllllIIl[lIIIlIIIIll[0]] = llIIlIlIIIIl("OTteEdhpQ28=", "eoRyr");
    lllllllIIl[lIIIlIIIIll[1]] = llIIlIlIIIIl("6VIcavfDv28=", "GrxFw");
    lllllllIIl[lIIIlIIIIll[2]] = llIIlIlIIIlI("DiYUPw==", "kGgKE");
    lllllllIIl[lIIIlIIIIll[3]] = llIIlIlIIIIl("UxfDYdJDVAQ=", "WDybj");
    lllllllIIl[lIIIlIIIIll[4]] = llIIlIlIIIlI("EhMCPQ==", "evqIQ");
    lllllllIIl[lIIIlIIIIll[5]] = llIIlIlIIIIl("1WUOSexO5oQLLLFK4aMFLDce2CvafY29", "ixFFw");
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllllllllllllllllIlIllIIllllllll, new IProperty[] { UP, NORTH, EAST, SOUTH, WEST });
  }
  
  public void harvestBlock(World lllllllllllllllllIlIllIlIIlIIlll, EntityPlayer lllllllllllllllllIlIllIlIIlIIllI, BlockPos lllllllllllllllllIlIllIlIIIlllll, IBlockState lllllllllllllllllIlIllIlIIlIIlII, TileEntity lllllllllllllllllIlIllIlIIIlllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((llIlllIIlIIl(isRemote)) && (llIlllIlIIII(lllllllllllllllllIlIllIlIIlIIllI.getCurrentEquippedItem())) && (llIlllIIlIlI(lllllllllllllllllIlIllIlIIlIIllI.getCurrentEquippedItem().getItem(), Items.shears)))
    {
      lllllllllllllllllIlIllIlIIlIIllI.triggerAchievement(net.minecraft.stats.StatList.mineBlockStatArray[Block.getIdFromBlock(lllllllllllllllllIlIllIlIIlIlIII)]);
      spawnAsEntity(lllllllllllllllllIlIllIlIIlIIlll, lllllllllllllllllIlIllIlIIIlllll, new ItemStack(Blocks.vine, lIIIlIIIIll[1], lIIIlIIIIll[0]));
      "".length();
      if (" ".length() == " ".length()) {}
    }
    else
    {
      lllllllllllllllllIlIllIlIIlIlIII.harvestBlock(lllllllllllllllllIlIllIlIIlIIlll, lllllllllllllllllIlIllIlIIlIIllI, lllllllllllllllllIlIllIlIIIlllll, lllllllllllllllllIlIllIlIIlIIlII, lllllllllllllllllIlIllIlIIIlllIl);
    }
  }
  
  private static String llIIlIlIIIIl(String lllllllllllllllllIlIllIIllIIllII, String lllllllllllllllllIlIllIIllIIlIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIlIllIIllIIllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIllIIllIIlIIl.getBytes(StandardCharsets.UTF_8)), lIIIlIIIIll[8]), "DES");
      Cipher lllllllllllllllllIlIllIIllIIlllI = Cipher.getInstance("DES");
      lllllllllllllllllIlIllIIllIIlllI.init(lIIIlIIIIll[2], lllllllllllllllllIlIllIIllIIllll);
      return new String(lllllllllllllllllIlIllIIllIIlllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIllIIllIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIlIllIIllIIllIl)
    {
      lllllllllllllllllIlIllIIllIIllIl.printStackTrace();
    }
    return null;
  }
  
  public IBlockState onBlockPlaced(World lllllllllllllllllIlIllIlIlIIIIII, BlockPos lllllllllllllllllIlIllIlIIllllll, EnumFacing lllllllllllllllllIlIllIlIIllIllI, float lllllllllllllllllIlIllIlIIllllIl, float lllllllllllllllllIlIllIlIIllllII, float lllllllllllllllllIlIllIlIIlllIll, int lllllllllllllllllIlIllIlIIlllIlI, EntityLivingBase lllllllllllllllllIlIllIlIIlllIIl)
  {
    ;
    ;
    ;
    IBlockState lllllllllllllllllIlIllIlIIlllIII = lllllllllllllllllIlIllIlIIllIlll.getDefaultState().withProperty(UP, Boolean.valueOf(lIIIlIIIIll[0])).withProperty(NORTH, Boolean.valueOf(lIIIlIIIIll[0])).withProperty(EAST, Boolean.valueOf(lIIIlIIIIll[0])).withProperty(SOUTH, Boolean.valueOf(lIIIlIIIIll[0])).withProperty(WEST, Boolean.valueOf(lIIIlIIIIll[0]));
    if (llIlllIIlIII(lllllllllllllllllIlIllIlIIllIllI.getAxis().isHorizontal()))
    {
      "".length();
      if ("  ".length() > -" ".length()) {
        break label145;
      }
      return null;
    }
    label145:
    return lllllllllllllllllIlIllIlIIlllIII;
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllllIlIllIlIIllIIll, Random lllllllllllllllllIlIllIlIIllIIlI, int lllllllllllllllllIlIllIlIIllIIIl)
  {
    return null;
  }
  
  private static boolean llIlllIlIIll(int ???, int arg1)
  {
    int i;
    float lllllllllllllllllIlIllIIlIlIlIll;
    return ??? >= i;
  }
  
  static
  {
    llIlllIIIlll();
    llIIlIlIIIll();
    UP = PropertyBool.create(lllllllIIl[lIIIlIIIIll[0]]);
    NORTH = PropertyBool.create(lllllllIIl[lIIIlIIIIll[1]]);
    EAST = PropertyBool.create(lllllllIIl[lIIIlIIIIll[2]]);
    SOUTH = PropertyBool.create(lllllllIIl[lIIIlIIIIll[3]]);
    WEST = PropertyBool.create(lllllllIIl[lIIIlIIIIll[4]]);
  }
  
  public int getRenderColor(IBlockState lllllllllllllllllIlIllIllIlIIIII)
  {
    return ColorizerFoliage.getFoliageColorBasic();
  }
  
  public boolean isOpaqueCube()
  {
    return lIIIlIIIIll[0];
  }
}

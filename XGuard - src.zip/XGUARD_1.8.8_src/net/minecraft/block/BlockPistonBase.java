package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockPistonStructureHelper;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityPiston;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraft.world.border.WorldBorder;

public class BlockPistonBase
  extends Block
{
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllllIIlllIlIllIllIlI, new IProperty[] { FACING, EXTENDED });
  }
  
  public void onBlockPlacedBy(World llllllllllllllllIIlllIlllllllIII, BlockPos llllllllllllllllIIlllIllllllllIl, IBlockState llllllllllllllllIIlllIllllllllII, EntityLivingBase llllllllllllllllIIlllIllllllIlIl, ItemStack llllllllllllllllIIlllIlllllllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    "".length();
    if (lIlIlIlllIlII(isRemote)) {
      llllllllllllllllIIlllIllllllllll.checkForMove(llllllllllllllllIIlllIlllllllIII, llllllllllllllllIIlllIllllllllIl, llllllllllllllllIIlllIllllllllII);
    }
  }
  
  private static boolean lIlIlIlllllll(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllIIlllIlIlIIlllll;
    return ??? > i;
  }
  
  public IBlockState onBlockPlaced(World llllllllllllllllIIlllIllllIIllIl, BlockPos llllllllllllllllIIlllIllllIlIlIl, EnumFacing llllllllllllllllIIlllIllllIlIlII, float llllllllllllllllIIlllIllllIlIIll, float llllllllllllllllIIlllIllllIlIIlI, float llllllllllllllllIIlllIllllIlIIIl, int llllllllllllllllIIlllIllllIlIIII, EntityLivingBase llllllllllllllllIIlllIllllIIllll)
  {
    ;
    ;
    ;
    ;
    return llllllllllllllllIIlllIllllIlIlll.getDefaultState().withProperty(FACING, getFacingFromEntity(llllllllllllllllIIlllIllllIIllIl, llllllllllllllllIIlllIllllIlIlIl, llllllllllllllllIIlllIllllIIllll)).withProperty(EXTENDED, Boolean.valueOf(lllIIIIIlII[0]));
  }
  
  private static int lIlIllIIIIlII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static String lIlIlIlIlllII(String llllllllllllllllIIlllIlIllIIllIl, String llllllllllllllllIIlllIlIllIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIlllIlIllIIllIl = new String(Base64.getDecoder().decode(llllllllllllllllIIlllIlIllIIllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIIlllIlIllIIlIll = new StringBuilder();
    char[] llllllllllllllllIIlllIlIllIIlIlI = llllllllllllllllIIlllIlIllIIIlll.toCharArray();
    int llllllllllllllllIIlllIlIllIIlIIl = lllIIIIIlII[0];
    String llllllllllllllllIIlllIlIllIIIIll = llllllllllllllllIIlllIlIllIIllIl.toCharArray();
    long llllllllllllllllIIlllIlIllIIIIlI = llllllllllllllllIIlllIlIllIIIIll.length;
    char llllllllllllllllIIlllIlIllIIIIIl = lllIIIIIlII[0];
    while (lIlIllIIIlIIl(llllllllllllllllIIlllIlIllIIIIIl, llllllllllllllllIIlllIlIllIIIIlI))
    {
      char llllllllllllllllIIlllIlIllIIlllI = llllllllllllllllIIlllIlIllIIIIll[llllllllllllllllIIlllIlIllIIIIIl];
      "".length();
      "".length();
      if ("  ".length() == -" ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIIlllIlIllIIlIll);
  }
  
  public void addCollisionBoxesToList(World llllllllllllllllIIlllIllIlIlIlIl, BlockPos llllllllllllllllIIlllIllIlIllIll, IBlockState llllllllllllllllIIlllIllIlIlIIll, AxisAlignedBB llllllllllllllllIIlllIllIlIlIIlI, List<AxisAlignedBB> llllllllllllllllIIlllIllIlIlIIIl, Entity llllllllllllllllIIlllIllIlIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIlllIllIlIlIllI.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
    llllllllllllllllIIlllIllIlIlIllI.addCollisionBoxesToList(llllllllllllllllIIlllIllIlIlIlIl, llllllllllllllllIIlllIllIlIllIll, llllllllllllllllIIlllIllIlIllIlI, llllllllllllllllIIlllIllIlIlIIlI, llllllllllllllllIIlllIllIlIlIIIl, llllllllllllllllIIlllIllIlIlIIII);
  }
  
  public static EnumFacing getFacing(int llllllllllllllllIIlllIllIIlllllI)
  {
    ;
    ;
    int llllllllllllllllIIlllIllIIllllll = llllllllllllllllIIlllIllIIlllllI & lllIIIIIlII[4];
    if (lIlIlIlllllll(llllllllllllllllIIlllIllIIllllll, lllIIIIIlII[5]))
    {
      "".length();
      if (" ".length() == " ".length()) {
        break label46;
      }
      return null;
    }
    label46:
    return EnumFacing.getFront(llllllllllllllllIIlllIllIIllllll);
  }
  
  private boolean doMove(World llllllllllllllllIIlllIlIlllllIll, BlockPos llllllllllllllllIIlllIllIIIlIIlI, EnumFacing llllllllllllllllIIlllIllIIIlIIIl, boolean llllllllllllllllIIlllIlIlllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIlIlllIlII(llllllllllllllllIIlllIlIlllllIII)) {
      "".length();
    }
    BlockPistonStructureHelper llllllllllllllllIIlllIllIIIIllll = new BlockPistonStructureHelper(llllllllllllllllIIlllIlIlllllIll, llllllllllllllllIIlllIlIlllllIlI, llllllllllllllllIIlllIllIIIlIIIl, llllllllllllllllIIlllIlIlllllIII);
    List<BlockPos> llllllllllllllllIIlllIllIIIIlllI = llllllllllllllllIIlllIllIIIIllll.getBlocksToMove();
    List<BlockPos> llllllllllllllllIIlllIllIIIIllIl = llllllllllllllllIIlllIllIIIIllll.getBlocksToDestroy();
    if (lIlIlIlllIlII(llllllllllllllllIIlllIllIIIIllll.canMove())) {
      return lllIIIIIlII[0];
    }
    int llllllllllllllllIIlllIllIIIIllII = llllllllllllllllIIlllIllIIIIlllI.size() + llllllllllllllllIIlllIllIIIIllIl.size();
    Block[] llllllllllllllllIIlllIllIIIIlIll = new Block[llllllllllllllllIIlllIllIIIIllII];
    if (lIlIlIlllIlll(llllllllllllllllIIlllIlIlllllIII))
    {
      "".length();
      if ("  ".length() == "  ".length()) {
        break label159;
      }
      return (0xFA ^ 0x96 ^ 0xC0 ^ 0x87) & (0x43 ^ 0x48 ^ 0x74 ^ 0x54 ^ -" ".length());
    }
    label159:
    EnumFacing llllllllllllllllIIlllIllIIIIlIlI = llllllllllllllllIIlllIllIIIlIIIl.getOpposite();
    int llllllllllllllllIIlllIllIIIIlIIl = llllllllllllllllIIlllIllIIIIllIl.size() - lllIIIIIlII[1];
    "".length();
    if (((0xD0 ^ 0xA6 ^ 0xFE ^ 0xA3) & (77 + 52 - 109 + 127 ^ 24 + 76 - -7 + 77 ^ -" ".length())) != ((0x93 ^ 0xBD ^ 0x29 ^ 0x2E) & (0x83 ^ 0x8B ^ 0x5F ^ 0x7E ^ -" ".length()))) {
      return (0xE2 ^ 0xBD ^ 0x41 ^ 0x3C) & (0x64 ^ 0x0 ^ 0xDB ^ 0x9D ^ -" ".length()) & ((0x9 ^ 0x1A ^ 0xB ^ 0x4B) & (0x8A ^ 0xB2 ^ 0x74 ^ 0x1F ^ -" ".length()) ^ -" ".length());
    }
    while (!lIlIllIIIIIlI(llllllllllllllllIIlllIllIIIIlIIl))
    {
      BlockPos llllllllllllllllIIlllIllIIIIlIII = (BlockPos)llllllllllllllllIIlllIllIIIIllIl.get(llllllllllllllllIIlllIllIIIIlIIl);
      Block llllllllllllllllIIlllIllIIIIIlll = llllllllllllllllIIlllIlIlllllIll.getBlockState(llllllllllllllllIIlllIllIIIIlIII).getBlock();
      llllllllllllllllIIlllIllIIIIIlll.dropBlockAsItem(llllllllllllllllIIlllIlIlllllIll, llllllllllllllllIIlllIllIIIIlIII, llllllllllllllllIIlllIlIlllllIll.getBlockState(llllllllllllllllIIlllIllIIIIlIII), lllIIIIIlII[0]);
      "".length();
      llllllllllllllllIIlllIllIIIIlIll[llllllllllllllllIIlllIllIIIIllII] = llllllllllllllllIIlllIllIIIIIlll;
    }
    int llllllllllllllllIIlllIllIIIIIllI = llllllllllllllllIIlllIllIIIIlllI.size() - lllIIIIIlII[1];
    "".length();
    if ((0xA6 ^ 0xA3) == 0) {
      return (0x67 ^ 0x75) & (0x59 ^ 0x4B ^ 0xFFFFFFFF);
    }
    while (!lIlIllIIIIIlI(llllllllllllllllIIlllIllIIIIIllI))
    {
      BlockPos llllllllllllllllIIlllIllIIIIIlIl = (BlockPos)llllllllllllllllIIlllIllIIIIlllI.get(llllllllllllllllIIlllIllIIIIIllI);
      IBlockState llllllllllllllllIIlllIllIIIIIlII = llllllllllllllllIIlllIlIlllllIll.getBlockState(llllllllllllllllIIlllIllIIIIIlIl);
      Block llllllllllllllllIIlllIllIIIIIIll = llllllllllllllllIIlllIllIIIIIlII.getBlock();
      "".length();
      "".length();
      llllllllllllllllIIlllIllIIIIIlIl = llllllllllllllllIIlllIllIIIIIlIl.offset(llllllllllllllllIIlllIllIIIIlIlI);
      "".length();
      llllllllllllllllIIlllIlIlllllIll.setTileEntity(llllllllllllllllIIlllIllIIIIIlIl, BlockPistonMoving.newTileEntity(llllllllllllllllIIlllIllIIIIIlII, llllllllllllllllIIlllIllIIIlIIIl, llllllllllllllllIIlllIlIlllllIII, lllIIIIIlII[0]));
      llllllllllllllllIIlllIllIIIIlIll[llllllllllllllllIIlllIllIIIIllII] = llllllllllllllllIIlllIllIIIIIIll;
    }
    BlockPos llllllllllllllllIIlllIllIIIIIIlI = ;;
    if (lIlIlIlllIlll(llllllllllllllllIIlllIlIlllllIII))
    {
      if (lIlIlIlllIlll(isSticky))
      {
        "".length();
        if (-" ".length() <= ((1 + 28 - -34 + 152 ^ 70 + 43 - 87 + 131) & ('' + 'Å' - 137 + 33 ^ 62 + 77 - 66 + 114 ^ -" ".length()))) {
          break label735;
        }
        return (0x52 ^ 0x2B ^ 0x43 ^ 0x36) & (0x55 ^ 0x0 ^ 0x37 ^ 0x6E ^ -" ".length());
      }
      label735:
      BlockPistonExtension.EnumPistonType llllllllllllllllIIlllIllIIIIIIIl = BlockPistonExtension.EnumPistonType.DEFAULT;
      IBlockState llllllllllllllllIIlllIllIIIIIIII = Blocks.piston_head.getDefaultState().withProperty(BlockPistonExtension.FACING, llllllllllllllllIIlllIllIIIlIIIl).withProperty(BlockPistonExtension.TYPE, llllllllllllllllIIlllIllIIIIIIIl);
      if (lIlIlIlllIlll(isSticky))
      {
        "".length();
        if (null == null) {
          break label851;
        }
        return (0x12 ^ 0xF ^ 0x10 ^ 0x36) & ((0x49 ^ 0xF) & (0xDF ^ 0x99 ^ 0xFFFFFFFF) ^ 0x8E ^ 0xB5 ^ -" ".length());
      }
      label851:
      IBlockState llllllllllllllllIIlllIlIllllllll = BlockPistonMoving.TYPE.withProperty(BlockPistonExtension.EnumPistonType.STICKY, BlockPistonExtension.EnumPistonType.DEFAULT);
      "".length();
      llllllllllllllllIIlllIlIlllllIll.setTileEntity(llllllllllllllllIIlllIllIIIIIIlI, BlockPistonMoving.newTileEntity(llllllllllllllllIIlllIllIIIIIIII, llllllllllllllllIIlllIllIIIlIIIl, lllIIIIIlII[1], lllIIIIIlII[0]));
    }
    int llllllllllllllllIIlllIlIlllllllI = llllllllllllllllIIlllIllIIIIllIl.size() - lllIIIIIlII[1];
    "".length();
    if ("  ".length() < 0) {
      return (0xFD ^ 0xB7) & (0xFE ^ 0xB4 ^ 0xFFFFFFFF);
    }
    while (!lIlIllIIIIIlI(llllllllllllllllIIlllIlIlllllllI)) {
      llllllllllllllllIIlllIlIlllllIll.notifyNeighborsOfStateChange((BlockPos)llllllllllllllllIIlllIllIIIIllIl.get(llllllllllllllllIIlllIlIlllllllI), llllllllllllllllIIlllIllIIIIlIll[(llllllllllllllllIIlllIllIIIIllII++)]);
    }
    int llllllllllllllllIIlllIlIllllllIl = llllllllllllllllIIlllIllIIIIlllI.size() - lllIIIIIlII[1];
    "".length();
    if ((0x8B ^ 0x8F) < "  ".length()) {
      return (0x5 ^ 0x57) & (0xF8 ^ 0xAA ^ 0xFFFFFFFF);
    }
    while (!lIlIllIIIIIlI(llllllllllllllllIIlllIlIllllllIl)) {
      llllllllllllllllIIlllIlIlllllIll.notifyNeighborsOfStateChange((BlockPos)llllllllllllllllIIlllIllIIIIlllI.get(llllllllllllllllIIlllIlIllllllIl), llllllllllllllllIIlllIllIIIIlIll[(llllllllllllllllIIlllIllIIIIllII++)]);
    }
    llllllllllllllllIIlllIlIllllllIl--;
    if (lIlIlIlllIlll(llllllllllllllllIIlllIlIlllllIII))
    {
      llllllllllllllllIIlllIlIlllllIll.notifyNeighborsOfStateChange(llllllllllllllllIIlllIllIIIIIIlI, Blocks.piston_head);
      llllllllllllllllIIlllIlIlllllIll.notifyNeighborsOfStateChange(llllllllllllllllIIlllIlIlllllIlI, llllllllllllllllIIlllIlIllllllII);
    }
    return lllIIIIIlII[1];
  }
  
  public void onNeighborBlockChange(World llllllllllllllllIIlllIlllllIlIlI, BlockPos llllllllllllllllIIlllIlllllIlllI, IBlockState llllllllllllllllIIlllIlllllIlIII, Block llllllllllllllllIIlllIlllllIllII)
  {
    ;
    ;
    ;
    ;
    if (lIlIlIlllIlII(isRemote)) {
      llllllllllllllllIIlllIlllllIlIll.checkForMove(llllllllllllllllIIlllIlllllIlIlI, llllllllllllllllIIlllIlllllIlIIl, llllllllllllllllIIlllIlllllIlIII);
    }
  }
  
  private static boolean lIlIllIIIlIIl(int ???, int arg1)
  {
    int i;
    float llllllllllllllllIIlllIlIlIlIIlll;
    return ??? < i;
  }
  
  private static void lIlIlIlIllllI()
  {
    llIllllIIll = new String[lllIIIIIlII[6]];
    llIllllIIll[lllIIIIIlII[0]] = lIlIlIlIllIll("KS/Ra0cuZ7g=", "kkUGQ");
    llIllllIIll[lllIIIIIlII[1]] = lIlIlIlIllIll("M/GFMgdEEx/WEj9E/vyNtA==", "eXsEE");
    llIllllIIll[lllIIIIIlII[2]] = lIlIlIlIlllII("Oh0qMVc+HTUgFiBaKSEN", "NtFTy");
    llIllllIIll[lllIIIIIlII[3]] = lIlIlIlIllIll("S/yoNPUP4hgi0vaPkHwpcQ==", "nFscN");
  }
  
  private static boolean lIlIlIlllIlII(int ???)
  {
    short llllllllllllllllIIlllIlIlIIIllll;
    return ??? == 0;
  }
  
  private static boolean lIlIlIlllllIl(Object ???, Object arg1)
  {
    Object localObject;
    String llllllllllllllllIIlllIlIlIIlIlll;
    return ??? == localObject;
  }
  
  public static EnumFacing getFacingFromEntity(World llllllllllllllllIIlllIllIIlllIIl, BlockPos llllllllllllllllIIlllIllIIllIlIl, EntityLivingBase llllllllllllllllIIlllIllIIllIlll)
  {
    ;
    ;
    ;
    if ((lIlIllIIIIIlI(lIlIllIIIIIII(MathHelper.abs((float)posX - llllllllllllllllIIlllIllIIllIlIl.getX()), 2.0F))) && (lIlIllIIIIIlI(lIlIllIIIIIII(MathHelper.abs((float)posZ - llllllllllllllllIIlllIllIIllIlIl.getZ()), 2.0F))))
    {
      double llllllllllllllllIIlllIllIIllIllI = posY + llllllllllllllllIIlllIllIIllIlll.getEyeHeight();
      if (lIlIllIIIIIll(lIlIllIIIIIIl(llllllllllllllllIIlllIllIIllIllI - llllllllllllllllIIlllIllIIllIlIl.getY(), 2.0D))) {
        return EnumFacing.UP;
      }
      if (lIlIllIIIIIll(lIlIllIIIIIIl(llllllllllllllllIIlllIllIIllIlIl.getY() - llllllllllllllllIIlllIllIIllIllI, 0.0D))) {
        return EnumFacing.DOWN;
      }
    }
    return llllllllllllllllIIlllIllIIllIlll.getHorizontalFacing().getOpposite();
  }
  
  private static boolean lIlIlIlllIllI(Object ???)
  {
    char llllllllllllllllIIlllIlIlIIlIIll;
    return ??? == null;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllllIIlllIllIlIIlIlI, BlockPos llllllllllllllllIIlllIllIlIIlIIl, IBlockState llllllllllllllllIIlllIllIlIIIlII)
  {
    ;
    ;
    ;
    ;
    llllllllllllllllIIlllIllIlIIIlll.setBlockBoundsBasedOnState(llllllllllllllllIIlllIllIlIIlIlI, llllllllllllllllIIlllIllIlIIlIIl);
    return llllllllllllllllIIlllIllIlIIIlll.getCollisionBoundingBox(llllllllllllllllIIlllIllIlIIlIlI, llllllllllllllllIIlllIllIlIIlIIl, llllllllllllllllIIlllIllIlIIIlII);
  }
  
  private static boolean lIlIlIlllIlll(int ???)
  {
    float llllllllllllllllIIlllIlIlIIlIIIl;
    return ??? != 0;
  }
  
  public IBlockState getStateForEntityRender(IBlockState llllllllllllllllIIlllIlIlllIlIll)
  {
    ;
    return llllllllllllllllIIlllIlIlllIlIlI.getDefaultState().withProperty(FACING, EnumFacing.UP);
  }
  
  private static boolean lIlIllIIIIIll(int ???)
  {
    float llllllllllllllllIIlllIlIlIIIlIIl;
    return ??? > 0;
  }
  
  public void setBlockBoundsForItemRender()
  {
    ;
    llllllllllllllllIIlllIllIllIIlIl.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
  }
  
  private static boolean lIlIllIIIIllI(int ???, int arg1)
  {
    int i;
    char llllllllllllllllIIlllIlIlIlIIIll;
    return ??? <= i;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllllIIlllIllIllIllII, BlockPos llllllllllllllllIIlllIllIlllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllllIIlllIllIlllIIII = llllllllllllllllIIlllIllIllIllII.getBlockState(llllllllllllllllIIlllIllIlllIIIl);
    EnumFacing llllllllllllllllIIlllIllIllIlllI;
    if ((lIlIlIlllllIl(llllllllllllllllIIlllIllIlllIIII.getBlock(), llllllllllllllllIIlllIllIlllIIll)) && (lIlIlIlllIlll(((Boolean)llllllllllllllllIIlllIllIlllIIII.getValue(EXTENDED)).booleanValue())))
    {
      float llllllllllllllllIIlllIllIllIllll = 0.25F;
      llllllllllllllllIIlllIllIllIlllI = (EnumFacing)llllllllllllllllIIlllIllIlllIIII.getValue(FACING);
      if (!lIlIlIllllllI(llllllllllllllllIIlllIllIllIlllI)) {}
    }
    else
    {
      switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[llllllllllllllllIIlllIllIllIlllI.ordinal()])
      {
      case 1: 
        llllllllllllllllIIlllIllIlllIIll.setBlockBounds(0.0F, 0.25F, 0.0F, 1.0F, 1.0F, 1.0F);
        "".length();
        if (-" ".length() > "  ".length()) {}
        break;
      case 2: 
        llllllllllllllllIIlllIllIlllIIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.75F, 1.0F);
        "".length();
        if ((0x4C ^ 0x48) < "  ".length()) {}
        break;
      case 3: 
        llllllllllllllllIIlllIllIlllIIll.setBlockBounds(0.0F, 0.0F, 0.25F, 1.0F, 1.0F, 1.0F);
        "".length();
        if (null != null) {}
        break;
      case 4: 
        llllllllllllllllIIlllIllIlllIIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.75F);
        "".length();
        if ((115 + 72 - 104 + 46 ^ 57 + 23 - 24 + 76) == 0) {}
        break;
      case 5: 
        llllllllllllllllIIlllIllIlllIIll.setBlockBounds(0.25F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        "".length();
        if (null != null) {}
        break;
      case 6: 
        llllllllllllllllIIlllIllIlllIIll.setBlockBounds(0.0F, 0.0F, 0.0F, 0.75F, 1.0F, 1.0F);
      default: 
        "".length();
        if ((0x28 ^ 0x2C) < 0)
        {
          return;
          llllllllllllllllIIlllIllIlllIIll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
        }
        break;
      }
    }
  }
  
  private static boolean lIlIlIllllIll(int ???, int arg1)
  {
    int i;
    int llllllllllllllllIIlllIlIlIlIllll;
    return ??? == i;
  }
  
  private static int lIlIllIIIIIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIlIlIllllllI(Object ???)
  {
    long llllllllllllllllIIlllIlIlIIlIlIl;
    return ??? != null;
  }
  
  private static String lIlIlIlIllIll(String llllllllllllllllIIlllIlIlIlllIII, String llllllllllllllllIIlllIlIlIllIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIlllIlIlIlllIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIlllIlIlIllIlll.getBytes(StandardCharsets.UTF_8)), lllIIIIIlII[7]), "DES");
      Cipher llllllllllllllllIIlllIlIlIlllIlI = Cipher.getInstance("DES");
      llllllllllllllllIIlllIlIlIlllIlI.init(lllIIIIIlII[2], llllllllllllllllIIlllIlIlIlllIll);
      return new String(llllllllllllllllIIlllIlIlIlllIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllIIlllIlIlIlllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIlllIlIlIlllIIl)
    {
      llllllllllllllllIIlllIlIlIlllIIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlIllIIIIlll(int ???, int arg1)
  {
    int i;
    int llllllllllllllllIIlllIlIlIIIIlIl;
    return ??? != i;
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllllIIlllIlIlllIIlII)
  {
    ;
    ;
    if (lIlIllIIIIIll(llllllllllllllllIIlllIlIlllIIlII & lllIIIIIlII[7]))
    {
      "".length();
      if ("   ".length() > 0) {
        break label60;
      }
      return null;
    }
    label60:
    return EXTENDED.withProperty(lllIIIIIlII[1], Boolean.valueOf(lllIIIIIlII[0]));
  }
  
  public BlockPistonBase(boolean llllllllllllllllIIllllIIIIIIIllI)
  {
    llllllllllllllllIIllllIIIIIIlIIl.<init>(Material.piston);
    llllllllllllllllIIllllIIIIIIlIIl.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(EXTENDED, Boolean.valueOf(lllIIIIIlII[0])));
    isSticky = llllllllllllllllIIllllIIIIIIIllI;
    "".length();
    "".length();
    "".length();
  }
  
  private static boolean lIlIllIIIIlIl(int ???)
  {
    float llllllllllllllllIIlllIlIlIIIllIl;
    return ??? >= 0;
  }
  
  public boolean isOpaqueCube()
  {
    return lllIIIIIlII[0];
  }
  
  private static boolean lIlIllIIIIIlI(int ???)
  {
    long llllllllllllllllIIlllIlIlIIIlIll;
    return ??? < 0;
  }
  
  private static void lIlIlIlllIIIl()
  {
    lllIIIIIlII = new int[9];
    lllIIIIIlII[0] = ((0x16 ^ 0x39) & (0xEF ^ 0xC0 ^ 0xFFFFFFFF));
    lllIIIIIlII[1] = " ".length();
    lllIIIIIlII[2] = "  ".length();
    lllIIIIIlII[3] = "   ".length();
    lllIIIIIlII[4] = (0x18 ^ 0x1F);
    lllIIIIIlII[5] = ('' + 64 - 218 + 182 ^ '' + 56 - 180 + 167);
    lllIIIIIlII[6] = (0xFD ^ 0x87 ^ 0xC9 ^ 0xB7);
    lllIIIIIlII[7] = (0x72 ^ 0x4F ^ 0x5D ^ 0x68);
    lllIIIIIlII[8] = (0x1 ^ 0x7);
  }
  
  public void onBlockAdded(World llllllllllllllllIIlllIllllIllllI, BlockPos llllllllllllllllIIlllIllllIlllIl, IBlockState llllllllllllllllIIlllIlllllIIIII)
  {
    ;
    ;
    ;
    ;
    if ((lIlIlIlllIlII(isRemote)) && (lIlIlIlllIllI(llllllllllllllllIIlllIllllIllllI.getTileEntity(llllllllllllllllIIlllIllllIlllIl)))) {
      llllllllllllllllIIlllIlllllIIIll.checkForMove(llllllllllllllllIIlllIllllIllllI, llllllllllllllllIIlllIllllIlllIl, llllllllllllllllIIlllIlllllIIIII);
    }
  }
  
  private static int lIlIllIIIIIIl(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public boolean onBlockEventReceived(World llllllllllllllllIIlllIlllIIIIlIl, BlockPos llllllllllllllllIIlllIlllIIIIlII, IBlockState llllllllllllllllIIlllIlllIIlIIIl, int llllllllllllllllIIlllIlllIIlIIII, int llllllllllllllllIIlllIlllIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllllIIlllIlllIIIlllI = (EnumFacing)llllllllllllllllIIlllIlllIIlIIIl.getValue(FACING);
    if (lIlIlIlllIlII(isRemote))
    {
      boolean llllllllllllllllIIlllIlllIIIllIl = llllllllllllllllIIlllIlllIIIIllI.shouldBeExtended(llllllllllllllllIIlllIlllIIIIlIl, llllllllllllllllIIlllIlllIIIIlII, llllllllllllllllIIlllIlllIIIlllI);
      if ((lIlIlIlllIlll(llllllllllllllllIIlllIlllIIIllIl)) && (lIlIlIllllIll(llllllllllllllllIIlllIlllIIlIIII, lllIIIIIlII[1])))
      {
        "".length();
        return lllIIIIIlII[0];
      }
      if ((lIlIlIlllIlII(llllllllllllllllIIlllIlllIIIllIl)) && (lIlIlIlllIlII(llllllllllllllllIIlllIlllIIlIIII))) {
        return lllIIIIIlII[0];
      }
    }
    if (lIlIlIlllIlII(llllllllllllllllIIlllIlllIIlIIII))
    {
      if (lIlIlIlllIlII(llllllllllllllllIIlllIlllIIIIllI.doMove(llllllllllllllllIIlllIlllIIIIlIl, llllllllllllllllIIlllIlllIIIIlII, llllllllllllllllIIlllIlllIIIlllI, lllIIIIIlII[1]))) {
        return lllIIIIIlII[0];
      }
      "".length();
      llllllllllllllllIIlllIlllIIIIlIl.playSoundEffect(llllllllllllllllIIlllIlllIIIIlII.getX() + 0.5D, llllllllllllllllIIlllIlllIIIIlII.getY() + 0.5D, llllllllllllllllIIlllIlllIIIIlII.getZ() + 0.5D, llIllllIIll[lllIIIIIlII[2]], 0.5F, rand.nextFloat() * 0.25F + 0.6F);
      "".length();
      if ("  ".length() < 0) {
        return (0x7 ^ 0x67) & (0x5C ^ 0x3C ^ 0xFFFFFFFF);
      }
    }
    else if (lIlIlIllllIll(llllllllllllllllIIlllIlllIIlIIII, lllIIIIIlII[1]))
    {
      TileEntity llllllllllllllllIIlllIlllIIIllII = llllllllllllllllIIlllIlllIIIIlIl.getTileEntity(llllllllllllllllIIlllIlllIIIIlII.offset(llllllllllllllllIIlllIlllIIIlllI));
      if (lIlIlIlllIlll(llllllllllllllllIIlllIlllIIIllII instanceof TileEntityPiston)) {
        ((TileEntityPiston)llllllllllllllllIIlllIlllIIIllII).clearPistonTileEntity();
      }
      if (lIlIlIlllIlll(isSticky))
      {
        "".length();
        if ((44 + '' - 162 + 151 ^ '' + 9 - 20 + 66) >= -" ".length()) {
          break label435;
        }
        return (" ".length() ^ 0x72 ^ 0x75) & (85 + 123 - 102 + 89 ^ 59 + '' - 122 + 113 ^ -" ".length());
      }
      label435:
      "".length();
      llllllllllllllllIIlllIlllIIIIlIl.setTileEntity(llllllllllllllllIIlllIlllIIIIlII, BlockPistonMoving.newTileEntity(llllllllllllllllIIlllIlllIIIIllI.getStateFromMeta(llllllllllllllllIIlllIlllIIIllll), llllllllllllllllIIlllIlllIIIlllI, lllIIIIIlII[0], lllIIIIIlII[1]));
      if (lIlIlIlllIlll(isSticky))
      {
        BlockPos llllllllllllllllIIlllIlllIIIlIll = llllllllllllllllIIlllIlllIIIIlII.add(llllllllllllllllIIlllIlllIIIlllI.getFrontOffsetX() * lllIIIIIlII[2], llllllllllllllllIIlllIlllIIIlllI.getFrontOffsetY() * lllIIIIIlII[2], llllllllllllllllIIlllIlllIIIlllI.getFrontOffsetZ() * lllIIIIIlII[2]);
        Block llllllllllllllllIIlllIlllIIIlIlI = llllllllllllllllIIlllIlllIIIIlIl.getBlockState(llllllllllllllllIIlllIlllIIIlIll).getBlock();
        boolean llllllllllllllllIIlllIlllIIIlIIl = lllIIIIIlII[0];
        if (lIlIlIlllllIl(llllllllllllllllIIlllIlllIIIlIlI, Blocks.piston_extension))
        {
          TileEntity llllllllllllllllIIlllIlllIIIlIII = llllllllllllllllIIlllIlllIIIIlIl.getTileEntity(llllllllllllllllIIlllIlllIIIlIll);
          if (lIlIlIlllIlll(llllllllllllllllIIlllIlllIIIlIII instanceof TileEntityPiston))
          {
            TileEntityPiston llllllllllllllllIIlllIlllIIIIlll = (TileEntityPiston)llllllllllllllllIIlllIlllIIIlIII;
            if ((lIlIlIlllllIl(llllllllllllllllIIlllIlllIIIIlll.getFacing(), llllllllllllllllIIlllIlllIIIlllI)) && (lIlIlIlllIlll(llllllllllllllllIIlllIlllIIIIlll.isExtending())))
            {
              llllllllllllllllIIlllIlllIIIIlll.clearPistonTileEntity();
              llllllllllllllllIIlllIlllIIIlIIl = lllIIIIIlII[1];
            }
          }
        }
        if ((lIlIlIlllIlII(llllllllllllllllIIlllIlllIIIlIIl)) && (lIlIlIllllIIl(llllllllllllllllIIlllIlllIIIlIlI.getMaterial(), Material.air)) && (lIlIlIlllIlll(canPush(llllllllllllllllIIlllIlllIIIlIlI, llllllllllllllllIIlllIlllIIIIlIl, llllllllllllllllIIlllIlllIIIlIll, llllllllllllllllIIlllIlllIIIlllI.getOpposite(), lllIIIIIlII[0]))) && ((!lIlIlIlllIlll(llllllllllllllllIIlllIlllIIIlIlI.getMobilityFlag())) || (!lIlIlIllllIIl(llllllllllllllllIIlllIlllIIIlIlI, Blocks.piston)) || (lIlIlIlllllIl(llllllllllllllllIIlllIlllIIIlIlI, Blocks.sticky_piston))))
        {
          "".length();
          "".length();
          if ((0x7A ^ 0x66 ^ 0x2D ^ 0x35) <= "  ".length()) {
            return (0x81 ^ 0xA7 ^ 0x24 ^ 0x1A) & (0xD ^ 0x3E ^ 0x66 ^ 0x4D ^ -" ".length());
          }
        }
      }
      else
      {
        "".length();
      }
      llllllllllllllllIIlllIlllIIIIlIl.playSoundEffect(llllllllllllllllIIlllIlllIIIIlII.getX() + 0.5D, llllllllllllllllIIlllIlllIIIIlII.getY() + 0.5D, llllllllllllllllIIlllIlllIIIIlII.getZ() + 0.5D, llIllllIIll[lllIIIIIlII[3]], 0.5F, rand.nextFloat() * 0.15F + 0.6F);
    }
    return lllIIIIIlII[1];
  }
  
  public static boolean canPush(Block llllllllllllllllIIlllIllIIlIlIII, World llllllllllllllllIIlllIllIIlIIlll, BlockPos llllllllllllllllIIlllIllIIlIIllI, EnumFacing llllllllllllllllIIlllIllIIlIIlIl, boolean llllllllllllllllIIlllIllIIlIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIlIlIlllllIl(llllllllllllllllIIlllIllIIlIlIII, Blocks.obsidian)) {
      return lllIIIIIlII[0];
    }
    if (lIlIlIlllIlII(llllllllllllllllIIlllIllIIlIIlll.getWorldBorder().contains(llllllllllllllllIIlllIllIIlIlIll))) {
      return lllIIIIIlII[0];
    }
    if ((lIlIllIIIIlIl(llllllllllllllllIIlllIllIIlIlIll.getY())) && ((!lIlIlIlllllIl(llllllllllllllllIIlllIllIIlIIlIl, EnumFacing.DOWN)) || (lIlIlIlllIlll(llllllllllllllllIIlllIllIIlIlIll.getY()))))
    {
      if ((lIlIllIIIIllI(llllllllllllllllIIlllIllIIlIlIll.getY(), llllllllllllllllIIlllIllIIlIIlll.getHeight() - lllIIIIIlII[1])) && ((!lIlIlIlllllIl(llllllllllllllllIIlllIllIIlIIlIl, EnumFacing.UP)) || (lIlIllIIIIlll(llllllllllllllllIIlllIllIIlIlIll.getY(), llllllllllllllllIIlllIllIIlIIlll.getHeight() - lllIIIIIlII[1]))))
      {
        if ((lIlIlIllllIIl(llllllllllllllllIIlllIllIIlIlIII, Blocks.piston)) && (lIlIlIllllIIl(llllllllllllllllIIlllIllIIlIlIII, Blocks.sticky_piston)))
        {
          if (lIlIlIlllIlII(lIlIllIIIIlII(llllllllllllllllIIlllIllIIlIlIII.getBlockHardness(llllllllllllllllIIlllIllIIlIIlll, llllllllllllllllIIlllIllIIlIlIll), -1.0F))) {
            return lllIIIIIlII[0];
          }
          if (lIlIlIllllIll(llllllllllllllllIIlllIllIIlIlIII.getMobilityFlag(), lllIIIIIlII[2])) {
            return lllIIIIIlII[0];
          }
          if (lIlIlIllllIll(llllllllllllllllIIlllIllIIlIlIII.getMobilityFlag(), lllIIIIIlII[1]))
          {
            if (lIlIlIlllIlII(llllllllllllllllIIlllIllIIlIIlII)) {
              return lllIIIIIlII[0];
            }
            return lllIIIIIlII[1];
          }
        }
        else if (lIlIlIlllIlll(((Boolean)llllllllllllllllIIlllIllIIlIIlll.getBlockState(llllllllllllllllIIlllIllIIlIlIll).getValue(EXTENDED)).booleanValue()))
        {
          return lllIIIIIlII[0];
        }
        if (lIlIlIlllIlll(llllllllllllllllIIlllIllIIlIlIII instanceof ITileEntityProvider))
        {
          "".length();
          if (-"  ".length() <= 0) {
            break label341;
          }
          return (44 + 35 - -13 + 43 ^ 97 + 1 - 35 + 98) & (84 + '' - 191 + 141 ^ 87 + 92 - 165 + 133 ^ -" ".length());
        }
        label341:
        return lllIIIIIlII[1];
      }
      return lllIIIIIlII[0];
    }
    return lllIIIIIlII[0];
  }
  
  public int getMetaFromState(IBlockState llllllllllllllllIIlllIlIlllIIIII)
  {
    ;
    ;
    int llllllllllllllllIIlllIlIllIlllll = lllIIIIIlII[0];
    llllllllllllllllIIlllIlIllIlllll |= ((EnumFacing)llllllllllllllllIIlllIlIllIllllI.getValue(FACING)).getIndex();
    if (lIlIlIlllIlll(((Boolean)llllllllllllllllIIlllIlIllIllllI.getValue(EXTENDED)).booleanValue())) {
      llllllllllllllllIIlllIlIllIlllll |= lllIIIIIlII[7];
    }
    return llllllllllllllllIIlllIlIllIlllll;
  }
  
  public boolean isFullCube()
  {
    return lllIIIIIlII[0];
  }
  
  private static boolean lIlIlIllllIIl(Object ???, Object arg1)
  {
    Object localObject;
    float llllllllllllllllIIlllIlIlIIllIll;
    return ??? != localObject;
  }
  
  static
  {
    lIlIlIlllIIIl();
    lIlIlIlIllllI();
  }
  
  private boolean shouldBeExtended(World llllllllllllllllIIlllIlllIlIlIIl, BlockPos llllllllllllllllIIlllIlllIlIlllI, EnumFacing llllllllllllllllIIlllIlllIlIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    Exception llllllllllllllllIIlllIlllIlIIlII = (llllllllllllllllIIlllIlllIlIIIll = EnumFacing.values()).length;
    int llllllllllllllllIIlllIlllIlIIlIl = lllIIIIIlII[0];
    "".length();
    if ("   ".length() < -" ".length()) {
      return (0x40 ^ 0x3E ^ 0x8F ^ 0xA7) & (91 + 54 - 92 + 94 ^ '' + '' - 209 + 117 ^ -" ".length());
    }
    while (!lIlIlIllllIlI(llllllllllllllllIIlllIlllIlIIlIl, llllllllllllllllIIlllIlllIlIIlII))
    {
      EnumFacing llllllllllllllllIIlllIlllIlIllII = llllllllllllllllIIlllIlllIlIIIll[llllllllllllllllIIlllIlllIlIIlIl];
      if ((lIlIlIllllIIl(llllllllllllllllIIlllIlllIlIllII, llllllllllllllllIIlllIlllIlIIlll)) && (lIlIlIlllIlll(llllllllllllllllIIlllIlllIlIlIIl.isSidePowered(llllllllllllllllIIlllIlllIlIlIII.offset(llllllllllllllllIIlllIlllIlIllII), llllllllllllllllIIlllIlllIlIllII)))) {
        return lllIIIIIlII[1];
      }
      llllllllllllllllIIlllIlllIlIIlIl++;
    }
    if (lIlIlIlllIlll(llllllllllllllllIIlllIlllIlIlIIl.isSidePowered(llllllllllllllllIIlllIlllIlIlIII, EnumFacing.DOWN))) {
      return lllIIIIIlII[1];
    }
    BlockPos llllllllllllllllIIlllIlllIlIlIll = llllllllllllllllIIlllIlllIlIlIII.up();
    float llllllllllllllllIIlllIlllIlIIIll = (llllllllllllllllIIlllIlllIlIIIlI = EnumFacing.values()).length;
    llllllllllllllllIIlllIlllIlIIlII = lllIIIIIlII[0];
    "".length();
    if (null != null) {
      return (0x4A ^ 0xD ^ 0xEB ^ 0xBD) & (0xBC ^ 0xC1 ^ 0xE9 ^ 0x85 ^ -" ".length());
    }
    while (!lIlIlIllllIlI(llllllllllllllllIIlllIlllIlIIlII, llllllllllllllllIIlllIlllIlIIIll))
    {
      EnumFacing llllllllllllllllIIlllIlllIlIlIlI = llllllllllllllllIIlllIlllIlIIIlI[llllllllllllllllIIlllIlllIlIIlII];
      if ((lIlIlIllllIIl(llllllllllllllllIIlllIlllIlIlIlI, EnumFacing.DOWN)) && (lIlIlIlllIlll(llllllllllllllllIIlllIlllIlIlIIl.isSidePowered(llllllllllllllllIIlllIlllIlIlIll.offset(llllllllllllllllIIlllIlllIlIlIlI), llllllllllllllllIIlllIlllIlIlIlI)))) {
        return lllIIIIIlII[1];
      }
      llllllllllllllllIIlllIlllIlIIlII++;
    }
    return lllIIIIIlII[0];
  }
  
  private void checkForMove(World llllllllllllllllIIlllIlllIllllIl, BlockPos llllllllllllllllIIlllIllllIIIIlI, IBlockState llllllllllllllllIIlllIlllIlllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllllIIlllIllllIIIIII = (EnumFacing)llllllllllllllllIIlllIlllIlllIll.getValue(FACING);
    boolean llllllllllllllllIIlllIlllIllllll = llllllllllllllllIIlllIllllIIIlII.shouldBeExtended(llllllllllllllllIIlllIlllIllllIl, llllllllllllllllIIlllIllllIIIIlI, llllllllllllllllIIlllIllllIIIIII);
    if ((lIlIlIlllIlll(llllllllllllllllIIlllIlllIllllll)) && (lIlIlIlllIlII(((Boolean)llllllllllllllllIIlllIlllIlllIll.getValue(EXTENDED)).booleanValue())))
    {
      if (lIlIlIlllIlll(new BlockPistonStructureHelper(llllllllllllllllIIlllIlllIllllIl, llllllllllllllllIIlllIllllIIIIlI, llllllllllllllllIIlllIllllIIIIII, lllIIIIIlII[1]).canMove()))
      {
        llllllllllllllllIIlllIlllIllllIl.addBlockEvent(llllllllllllllllIIlllIllllIIIIlI, llllllllllllllllIIlllIllllIIIlII, lllIIIIIlII[0], llllllllllllllllIIlllIllllIIIIII.getIndex());
        "".length();
        if ((0x54 ^ 0x50) > " ".length()) {}
      }
    }
    else if ((lIlIlIlllIlII(llllllllllllllllIIlllIlllIllllll)) && (lIlIlIlllIlll(((Boolean)llllllllllllllllIIlllIlllIlllIll.getValue(EXTENDED)).booleanValue())))
    {
      "".length();
      llllllllllllllllIIlllIlllIllllIl.addBlockEvent(llllllllllllllllIIlllIllllIIIIlI, llllllllllllllllIIlllIllllIIIlII, lllIIIIIlII[1], llllllllllllllllIIlllIllllIIIIII.getIndex());
    }
  }
  
  private static boolean lIlIlIllllIlI(int ???, int arg1)
  {
    int i;
    float llllllllllllllllIIlllIlIlIlIlIll;
    return ??? >= i;
  }
}

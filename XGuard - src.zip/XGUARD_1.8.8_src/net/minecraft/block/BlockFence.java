package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemLead;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockFence
  extends Block
{
  private static boolean lIIIIllIllIl(int ???)
  {
    long llIIlIIlll;
    return ??? == 0;
  }
  
  public boolean onBlockActivated(World lllIIIIlII, BlockPos lllIIIIIll, IBlockState lllIIIIIlI, EntityPlayer lllIIIIIIl, EnumFacing lllIIIIIII, float llIlllllll, float llIllllllI, float llIlllllIl)
  {
    ;
    ;
    ;
    if (lIIIIllIllII(isRemote))
    {
      "".length();
      if (" ".length() != 0) {
        break label82;
      }
      return (48 + '' - -17 + 49 ^ 53 + 84 - -6 + 27) & (0xBF ^ 0x85 ^ 0x48 ^ 0x2B ^ -" ".length());
    }
    label82:
    return ItemLead.attachToFence(lllIIIIIIl, lllIIIIlII, lllIIIIIll);
  }
  
  public boolean isFullCube()
  {
    return lIlIIlIllI[0];
  }
  
  public void addCollisionBoxesToList(World llllIIllII, BlockPos llllIIlIll, IBlockState llllIIlIlI, AxisAlignedBB llllIllIII, List<AxisAlignedBB> llllIlIlll, Entity llllIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    boolean llllIlIlIl = llllIIllIl.canConnectTo(llllIIllII, llllIIlIll.north());
    boolean llllIlIlII = llllIIllIl.canConnectTo(llllIIllII, llllIIlIll.south());
    boolean llllIlIIll = llllIIllIl.canConnectTo(llllIIllII, llllIIlIll.west());
    boolean llllIlIIlI = llllIIllIl.canConnectTo(llllIIllII, llllIIlIll.east());
    float llllIlIIIl = 0.375F;
    float llllIlIIII = 0.625F;
    float llllIIllll = 0.375F;
    float llllIIlllI = 0.625F;
    if (lIIIIllIllII(llllIlIlIl)) {
      llllIIllll = 0.0F;
    }
    if (lIIIIllIllII(llllIlIlII)) {
      llllIIlllI = 1.0F;
    }
    if ((!lIIIIllIllIl(llllIlIlIl)) || (lIIIIllIllII(llllIlIlII)))
    {
      llllIIllIl.setBlockBounds(llllIlIIIl, 0.0F, llllIIllll, llllIlIIII, 1.5F, llllIIlllI);
      llllIIllIl.addCollisionBoxesToList(llllIIllII, llllIIlIll, llllIllIIl, llllIllIII, llllIlIlll, llllIIIlll);
    }
    llllIIllll = 0.375F;
    llllIIlllI = 0.625F;
    if (lIIIIllIllII(llllIlIIll)) {
      llllIlIIIl = 0.0F;
    }
    if (lIIIIllIllII(llllIlIIlI)) {
      llllIlIIII = 1.0F;
    }
    if ((!lIIIIllIllIl(llllIlIIll)) || (!lIIIIllIllIl(llllIlIIlI)) || ((lIIIIllIllIl(llllIlIlIl)) && (lIIIIllIllIl(llllIlIlII))))
    {
      llllIIllIl.setBlockBounds(llllIlIIIl, 0.0F, llllIIllll, llllIlIIII, 1.5F, llllIIlllI);
      llllIIllIl.addCollisionBoxesToList(llllIIllII, llllIIlIll, llllIllIIl, llllIllIII, llllIlIlll, llllIIIlll);
    }
    if (lIIIIllIllII(llllIlIlIl)) {
      llllIIllll = 0.0F;
    }
    if (lIIIIllIllII(llllIlIlII)) {
      llllIIlllI = 1.0F;
    }
    llllIIllIl.setBlockBounds(llllIlIIIl, 0.0F, llllIIllll, llllIlIIII, 1.0F, llllIIlllI);
  }
  
  private static String lIIIIllIlIIl(String llIlIIIlII, String llIIlllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llIlIIIlII = new String(Base64.getDecoder().decode(llIlIIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llIlIIIIlI = new StringBuilder();
    char[] llIlIIIIIl = llIIlllllI.toCharArray();
    int llIlIIIIII = lIlIIlIllI[0];
    String llIIlllIlI = llIlIIIlII.toCharArray();
    float llIIlllIIl = llIIlllIlI.length;
    Exception llIIlllIII = lIlIIlIllI[0];
    while (lIIIIlllIIII(llIIlllIII, llIIlllIIl))
    {
      char llIlIIIlIl = llIIlllIlI[llIIlllIII];
      "".length();
      "".length();
      if ("  ".length() == 0) {
        return null;
      }
    }
    return String.valueOf(llIlIIIIlI);
  }
  
  private static String lIIIIllIlIII(String llIllIIIIl, String llIllIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIllIIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llIllIIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llIllIIIll = Cipher.getInstance("Blowfish");
      llIllIIIll.init(lIlIIlIllI[2], llIllIIlII);
      return new String(llIllIIIll.doFinal(Base64.getDecoder().decode(llIllIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIllIIIlI)
    {
      llIllIIIlI.printStackTrace();
    }
    return null;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess lllIllIIlI, BlockPos lllIllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    boolean lllIllIIII = lllIlIlIII.canConnectTo(lllIlIIlll, lllIllIIIl.north());
    boolean lllIlIllll = lllIlIlIII.canConnectTo(lllIlIIlll, lllIllIIIl.south());
    boolean lllIlIlllI = lllIlIlIII.canConnectTo(lllIlIIlll, lllIllIIIl.west());
    boolean lllIlIllIl = lllIlIlIII.canConnectTo(lllIlIIlll, lllIllIIIl.east());
    float lllIlIllII = 0.375F;
    float lllIlIlIll = 0.625F;
    float lllIlIlIlI = 0.375F;
    float lllIlIlIIl = 0.625F;
    if (lIIIIllIllII(lllIllIIII)) {
      lllIlIlIlI = 0.0F;
    }
    if (lIIIIllIllII(lllIlIllll)) {
      lllIlIlIIl = 1.0F;
    }
    if (lIIIIllIllII(lllIlIlllI)) {
      lllIlIllII = 0.0F;
    }
    if (lIIIIllIllII(lllIlIllIl)) {
      lllIlIlIll = 1.0F;
    }
    lllIlIlIII.setBlockBounds(lllIlIllII, 0.0F, lllIlIlIlI, lllIlIlIll, 1.0F, lllIlIlIIl);
  }
  
  public boolean canConnectTo(IBlockAccess lllIIlIIll, BlockPos lllIIIlllI)
  {
    ;
    ;
    ;
    ;
    Block lllIIlIIIl = lllIIlIIll.getBlockState(lllIIIlllI).getBlock();
    if (lIIIIllIlllI(lllIIlIIIl, Blocks.barrier))
    {
      "".length();
      if (-" ".length() >= 0) {
        return (118 + 25 - -16 + 11 ^ 74 + 15 - 35 + 80) & (101 + 53 - 144 + 150 ^ 127 + 20 - 53 + 46 ^ -" ".length());
      }
    }
    else if (((!lIIIIllIllII(lllIIlIIIl instanceof BlockFence)) || (lIIIIllIllll(blockMaterial, blockMaterial))) && (lIIIIllIllIl(lllIIlIIIl instanceof BlockFenceGate)))
    {
      if ((lIIIIllIllII(blockMaterial.isOpaque())) && (lIIIIllIllII(lllIIlIIIl.isFullCube())))
      {
        if (lIIIIllIllll(blockMaterial, Material.gourd))
        {
          "".length();
          if ((0x28 ^ 0x2C) >= 0) {
            break label351;
          }
          return (0x6E ^ 0x30) & (0x68 ^ 0x36 ^ 0xFFFFFFFF);
        }
        "".length();
        if ((0x40 ^ 0x59 ^ 0x5F ^ 0x42) >= " ".length()) {
          break label351;
        }
        return ('' + 14 - 146 + 152 ^ '' + 33 - 84 + 85) & (0x34 ^ 0x3 ^ 0x70 ^ 0x49 ^ -" ".length());
      }
      "".length();
      if ("  ".length() < (0x82 ^ 0xBA ^ 0x27 ^ 0x1B)) {
        break label351;
      }
      return (0xAC ^ 0x93 ^ 0x59 ^ 0x6D) & (0xA ^ 0x44 ^ 0xD0 ^ 0x95 ^ -" ".length());
    }
    label351:
    return lIlIIlIllI[1];
  }
  
  public IBlockState getActualState(IBlockState llIlllIIlI, IBlockAccess llIllIllIl, BlockPos llIllIllII)
  {
    ;
    ;
    ;
    ;
    return llIlllIIlI.withProperty(NORTH, Boolean.valueOf(llIlllIIll.canConnectTo(llIllIllIl, llIllIllII.north()))).withProperty(EAST, Boolean.valueOf(llIlllIIll.canConnectTo(llIllIllIl, llIllIllII.east()))).withProperty(SOUTH, Boolean.valueOf(llIlllIIll.canConnectTo(llIllIllIl, llIllIllII.south()))).withProperty(WEST, Boolean.valueOf(llIlllIIll.canConnectTo(llIllIllIl, llIllIllII.west())));
  }
  
  static
  {
    lIIIIllIlIll();
    lIIIIllIlIlI();
    NORTH = PropertyBool.create(lIlIIlIlIl[lIlIIlIllI[0]]);
    EAST = PropertyBool.create(lIlIIlIlIl[lIlIIlIllI[1]]);
    SOUTH = PropertyBool.create(lIlIIlIlIl[lIlIIlIllI[2]]);
  }
  
  private static String lIIIIllIIlll(String llIlIlIIlI, String llIlIlIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIlIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llIlIlIIll.getBytes(StandardCharsets.UTF_8)), lIlIIlIllI[5]), "DES");
      Cipher llIlIlIllI = Cipher.getInstance("DES");
      llIlIlIllI.init(lIlIIlIllI[2], llIlIlIlll);
      return new String(llIlIlIllI.doFinal(Base64.getDecoder().decode(llIlIlIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIlIlIlIl)
    {
      llIlIlIlIl.printStackTrace();
    }
    return null;
  }
  
  public BlockFence(Material llllllIlll)
  {
    lllllllIII.<init>(llllllIlll, llllllIlll.getMaterialMapColor());
  }
  
  private static boolean lIIIIllIlllI(Object ???, Object arg1)
  {
    Object localObject;
    byte llIIlIlIll;
    return ??? == localObject;
  }
  
  public boolean shouldSideBeRendered(IBlockAccess lllIIIlIll, BlockPos lllIIIlIlI, EnumFacing lllIIIlIIl)
  {
    return lIlIIlIllI[1];
  }
  
  private static void lIIIIllIlIll()
  {
    lIlIIlIllI = new int[6];
    lIlIIlIllI[0] = ((61 + '¡' - 168 + 112 ^ 115 + 70 - 76 + 64) & (0x69 ^ 0x35 ^ 0x45 ^ 0x12 ^ -" ".length()));
    lIlIIlIllI[1] = " ".length();
    lIlIIlIllI[2] = "  ".length();
    lIlIIlIllI[3] = "   ".length();
    lIlIIlIllI[4] = (0x1D ^ 0x1 ^ 0x16 ^ 0xE);
    lIlIIlIllI[5] = (0x23 ^ 0x2B);
  }
  
  private static boolean lIIIIlllIIII(int ???, int arg1)
  {
    int i;
    int llIIllIIll;
    return ??? < i;
  }
  
  private static boolean lIIIIllIllII(int ???)
  {
    int llIIlIlIIl;
    return ??? != 0;
  }
  
  public int getMetaFromState(IBlockState llIllllIII)
  {
    return lIlIIlIllI[0];
  }
  
  private static boolean lIIIIllIllll(Object ???, Object arg1)
  {
    Object localObject;
    long llIIlIllll;
    return ??? != localObject;
  }
  
  public boolean isOpaqueCube()
  {
    return lIlIIlIllI[0];
  }
  
  public BlockFence(Material lllllIllIl, MapColor lllllIllII)
  {
    lllllIlllI.<init>(llllllIIII, lllllIllII);
    lllllIlllI.setDefaultState(blockState.getBaseState().withProperty(NORTH, Boolean.valueOf(lIlIIlIllI[0])).withProperty(EAST, Boolean.valueOf(lIlIIlIllI[0])).withProperty(SOUTH, Boolean.valueOf(lIlIIlIllI[0])).withProperty(WEST, Boolean.valueOf(lIlIIlIllI[0])));
    "".length();
  }
  
  private static void lIIIIllIlIlI()
  {
    lIlIIlIlIl = new String[lIlIIlIllI[4]];
    lIlIIlIlIl[lIlIIlIllI[0]] = lIIIIllIIlll("lzWLh2otjjE=", "riZHC");
    lIlIIlIlIl[lIlIIlIllI[1]] = lIIIIllIlIII("Cqabcx45w4U=", "eEJrj");
    lIlIIlIlIl[lIlIIlIllI[2]] = lIIIIllIlIIl("Gj82DSc=", "iPCyO");
    lIlIIlIlIl[lIlIIlIllI[3]] = lIIIIllIlIII("ZGROjjUMZ0Y=", "qJtMY");
  }
  
  public boolean isPassable(IBlockAccess lllIIllIlI, BlockPos lllIIllIIl)
  {
    return lIlIIlIllI[0];
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llIllIlIIl, new IProperty[] { NORTH, EAST, WEST, SOUTH });
  }
}

package net.minecraft.block;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.command.server.CommandBlockLogic;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityMinecartCommandBlock;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockRailDetector
  extends BlockRailBase
{
  private static boolean lIIlIlIlIII(int ???, int arg1)
  {
    int i;
    char lllIIlIllllIII;
    return ??? != i;
  }
  
  public IBlockState getStateFromMeta(int lllIIllIlllIIl)
  {
    ;
    ;
    if (lIIlIlIlIlI(lllIIllIlllIIl & lIllIlIlI[6]))
    {
      "".length();
      if (null == null) {
        break label61;
      }
      return null;
    }
    label61:
    return POWERED.withProperty(lIllIlIlI[1], Boolean.valueOf(lIllIlIlI[0]));
  }
  
  private static boolean lIIlIlIIlIl(int ???)
  {
    int lllIIlIllllllI;
    return ??? == 0;
  }
  
  private static String lIIlIIlIIIl(String lllIIllIIIllIl, String lllIIllIIIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllIIllIIlIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllIIllIIIllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllIIllIIlIIIl = Cipher.getInstance("Blowfish");
      lllIIllIIlIIIl.init(lIllIlIlI[7], lllIIllIIlIIlI);
      return new String(lllIIllIIlIIIl.doFinal(Base64.getDecoder().decode(lllIIllIIIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllIIllIIlIIII)
    {
      lllIIllIIlIIII.printStackTrace();
    }
    return null;
  }
  
  public IProperty<BlockRailBase.EnumRailDirection> getShapeProperty()
  {
    return SHAPE;
  }
  
  public void onBlockAdded(World lllIIllllIllll, BlockPos lllIIllllIlllI, IBlockState lllIIllllIlIIl)
  {
    ;
    ;
    ;
    ;
    lllIIlllllIIII.onBlockAdded(lllIIllllIllll, lllIIllllIlllI, lllIIllllIlIIl);
    lllIIlllllIIII.updatePoweredState(lllIIllllIllll, lllIIllllIlllI, lllIIllllIlIIl);
  }
  
  protected <T extends EntityMinecart> List<T> findMinecarts(World lllIIlllIIlIlI, BlockPos lllIIlllIIllll, Class<T> lllIIlllIIlIII, Predicate<Entity>... lllIIlllIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    AxisAlignedBB lllIIlllIIllII = lllIIlllIIlIll.getDectectionBox(lllIIlllIIlIIl);
    if (lIIlIlIlIII(lllIIlllIIIlll.length, lIllIlIlI[1]))
    {
      "".length();
      if ("  ".length() >= -" ".length()) {
        break label65;
      }
      return null;
    }
    label65:
    return lllIIlllIIlIlI.getEntitiesWithinAABB(lllIIlllIIlIII, lllIIlllIIllII, lllIIlllIIIlll[lIllIlIlI[0]]);
  }
  
  private static boolean lIIlIlIIllI(int ???)
  {
    Exception lllIIllIIIIIII;
    return ??? != 0;
  }
  
  private static boolean lIIlIlIlIlI(int ???)
  {
    boolean lllIIlIlllllII;
    return ??? > 0;
  }
  
  public void updateTick(World lllIlIIIIlllII, BlockPos lllIlIIIlIIIII, IBlockState lllIlIIIIlllll, Random lllIlIIIIllllI)
  {
    ;
    ;
    ;
    ;
    if ((lIIlIlIIlIl(isRemote)) && (lIIlIlIIllI(((Boolean)lllIlIIIIlllll.getValue(POWERED)).booleanValue()))) {
      lllIlIIIlIIIlI.updatePoweredState(lllIlIIIIlllII, lllIlIIIIllIll, lllIlIIIIlllll);
    }
  }
  
  public void onEntityCollidedWithBlock(World lllIlIIIlIlllI, BlockPos lllIlIIIlIllIl, IBlockState lllIlIIIlIllII, Entity lllIlIIIllIIII)
  {
    ;
    ;
    ;
    ;
    if ((lIIlIlIIlIl(isRemote)) && (lIIlIlIIlIl(((Boolean)lllIlIIIlIllII.getValue(POWERED)).booleanValue()))) {
      lllIlIIIlIllll.updatePoweredState(lllIlIIIlIlllI, lllIlIIIllIIlI, lllIlIIIlIllII);
    }
  }
  
  private static boolean lIIlIlIIlll(Object ???, Object arg1)
  {
    Object localObject;
    boolean lllIIllIIIIIlI;
    return ??? == localObject;
  }
  
  public int getWeakPower(IBlockAccess lllIlIIIIlIlll, BlockPos lllIlIIIIlIllI, IBlockState lllIlIIIIlIIll, EnumFacing lllIlIIIIlIlII)
  {
    ;
    if (lIIlIlIIllI(((Boolean)lllIlIIIIlIIll.getValue(POWERED)).booleanValue()))
    {
      "".length();
      if (-" ".length() >= -" ".length()) {
        break label87;
      }
      return (0x45 ^ 0x7C ^ 0x2E ^ 0x1E) & (0xA6 ^ 0x9F ^ 0xAF ^ 0x9F ^ -" ".length());
    }
    label87:
    return lIllIlIlI[0];
  }
  
  public int getMetaFromState(IBlockState lllIIllIllIIll)
  {
    ;
    ;
    int lllIIllIllIlII = lIllIlIlI[0];
    lllIIllIllIlII |= ((BlockRailBase.EnumRailDirection)lllIIllIllIlIl.getValue(SHAPE)).getMetadata();
    if (lIIlIlIIllI(((Boolean)lllIIllIllIlIl.getValue(POWERED)).booleanValue())) {
      lllIIllIllIlII |= lIllIlIlI[6];
    }
    return lllIIllIllIlII;
  }
  
  private static String lIIlIIlIIlI(String lllIIllIlIIlII, String lllIIllIlIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllIIllIlIIlII = new String(Base64.getDecoder().decode(lllIIllIlIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllIIllIlIIIlI = new StringBuilder();
    char[] lllIIllIlIIIIl = lllIIllIlIIIll.toCharArray();
    int lllIIllIlIIIII = lIllIlIlI[0];
    byte lllIIllIIllIlI = lllIIllIlIIlII.toCharArray();
    float lllIIllIIllIIl = lllIIllIIllIlI.length;
    float lllIIllIIllIII = lIllIlIlI[0];
    while (lIIlIlIllII(lllIIllIIllIII, lllIIllIIllIIl))
    {
      char lllIIllIlIIlIl = lllIIllIIllIlI[lllIIllIIllIII];
      "".length();
      "".length();
      if (-" ".length() > 0) {
        return null;
      }
    }
    return String.valueOf(lllIIllIlIIIlI);
  }
  
  private void updatePoweredState(World lllIlIIIIIIIIl, BlockPos lllIIllllllIIl, IBlockState lllIIllllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    boolean lllIIllllllllI = ((Boolean)lllIIllllllIII.getValue(POWERED)).booleanValue();
    boolean lllIIlllllllIl = lIllIlIlI[0];
    List<EntityMinecart> lllIIlllllllII = lllIIllllllIll.findMinecarts(lllIlIIIIIIIIl, lllIIllllllIIl, EntityMinecart.class, new Predicate[lIllIlIlI[0]]);
    if (lIIlIlIIlIl(lllIIlllllllII.isEmpty())) {
      lllIIlllllllIl = lIllIlIlI[1];
    }
    if ((lIIlIlIIllI(lllIIlllllllIl)) && (lIIlIlIIlIl(lllIIllllllllI)))
    {
      "".length();
      lllIlIIIIIIIIl.notifyNeighborsOfStateChange(lllIIllllllIIl, lllIIllllllIll);
      lllIlIIIIIIIIl.notifyNeighborsOfStateChange(lllIIllllllIIl.down(), lllIIllllllIll);
      lllIlIIIIIIIIl.markBlockRangeForRenderUpdate(lllIIllllllIIl, lllIIllllllIIl);
    }
    if ((lIIlIlIIlIl(lllIIlllllllIl)) && (lIIlIlIIllI(lllIIllllllllI)))
    {
      "".length();
      lllIlIIIIIIIIl.notifyNeighborsOfStateChange(lllIIllllllIIl, lllIIllllllIll);
      lllIlIIIIIIIIl.notifyNeighborsOfStateChange(lllIIllllllIIl.down(), lllIIllllllIll);
      lllIlIIIIIIIIl.markBlockRangeForRenderUpdate(lllIIllllllIIl, lllIIllllllIIl);
    }
    if (lIIlIlIIllI(lllIIlllllllIl)) {
      lllIlIIIIIIIIl.scheduleUpdate(lllIIllllllIIl, lllIIllllllIll, lllIIllllllIll.tickRate(lllIlIIIIIIIIl));
    }
    lllIlIIIIIIIIl.updateComparatorOutputLevel(lllIIllllllIIl, lllIIllllllIll);
  }
  
  private static void lIIlIlIIlII()
  {
    lIllIlIlI = new int[8];
    lIllIlIlI[0] = ((0x59 ^ 0x4D) & (0x86 ^ 0x92 ^ 0xFFFFFFFF));
    lIllIlIlI[1] = " ".length();
    lIllIlIlI[2] = (0x38 ^ 0x2C);
    lIllIlIlI[3] = (0x7F ^ 0x70);
    lIllIlIlI[4] = "   ".length();
    lIllIlIlI[5] = (21 + 76 - 27 + 116 ^ 63 + '' - 130 + 116);
    lIllIlIlI[6] = (0x50 ^ 0x58);
    lIllIlIlI[7] = "  ".length();
  }
  
  static
  {
    lIIlIlIIlII();
    lIIlIIlIIll();
    SHAPE = PropertyEnum.create(lIllIIlIl[lIllIlIlI[0]], BlockRailBase.EnumRailDirection.class, new Predicate()
    {
      private static void llllIlIIlI()
      {
        lIIIllllI = new int[2];
        lIIIllllI[0] = " ".length();
        lIIIllllI[1] = ((0x41 ^ 0x10) & (0x15 ^ 0x44 ^ 0xFFFFFFFF));
      }
      
      private static boolean llllIlIIll(Object ???, Object arg1)
      {
        Object localObject;
        double lIIIIllllIIIllI;
        return ??? != localObject;
      }
      
      public boolean apply(BlockRailBase.EnumRailDirection lIIIIllllIIllll)
      {
        ;
        if ((llllIlIIll(lIIIIllllIIllll, BlockRailBase.EnumRailDirection.NORTH_EAST)) && (llllIlIIll(lIIIIllllIIlllI, BlockRailBase.EnumRailDirection.NORTH_WEST)) && (llllIlIIll(lIIIIllllIIlllI, BlockRailBase.EnumRailDirection.SOUTH_EAST)) && (llllIlIIll(lIIIIllllIIlllI, BlockRailBase.EnumRailDirection.SOUTH_WEST))) {
          return lIIIllllI[0];
        }
        return lIIIllllI[1];
      }
      
      static {}
    });
  }
  
  public BlockRailDetector()
  {
    lllIlIIIllllII.<init>(lIllIlIlI[1]);
    lllIlIIIllllIl.setDefaultState(blockState.getBaseState().withProperty(POWERED, Boolean.valueOf(lIllIlIlI[0])).withProperty(SHAPE, BlockRailBase.EnumRailDirection.NORTH_SOUTH));
    "".length();
  }
  
  public boolean canProvidePower()
  {
    return lIllIlIlI[1];
  }
  
  public int tickRate(World lllIlIIIlllIlI)
  {
    return lIllIlIlI[2];
  }
  
  public boolean hasComparatorInputOverride()
  {
    return lIllIlIlI[1];
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllIIllIllIIII, new IProperty[] { SHAPE, POWERED });
  }
  
  private AxisAlignedBB getDectectionBox(BlockPos lllIIlllIIIIlI)
  {
    ;
    ;
    float lllIIlllIIIIIl = 0.2F;
    return new AxisAlignedBB(lllIIlllIIIIII.getX() + 0.2F, lllIIlllIIIIII.getY(), lllIIlllIIIIII.getZ() + 0.2F, lllIIlllIIIIII.getX() + lIllIlIlI[1] - 0.2F, lllIIlllIIIIII.getY() + lIllIlIlI[1] - 0.2F, lllIIlllIIIIII.getZ() + lIllIlIlI[1] - 0.2F);
  }
  
  public int getStrongPower(IBlockAccess lllIlIIIIIllll, BlockPos lllIlIIIIIlllI, IBlockState lllIlIIIIIlIll, EnumFacing lllIlIIIIIllII)
  {
    ;
    ;
    if (lIIlIlIIlIl(((Boolean)lllIlIIIIIlIll.getValue(POWERED)).booleanValue()))
    {
      "".length();
      if ("  ".length() <= " ".length()) {
        return ('' + 'Í' - 270 + 134 ^ 32 + '' - 39 + 20) & (0x7A ^ 0x15 ^ 0xBE ^ 0x98 ^ -" ".length());
      }
    }
    else if (lIIlIlIIlll(lllIlIIIIIllII, EnumFacing.UP))
    {
      "".length();
      if ((0x11 ^ 0x15) > 0) {
        break label146;
      }
      return (0x84 ^ 0xBA) & (0x6B ^ 0x55 ^ 0xFFFFFFFF);
    }
    label146:
    return lIllIlIlI[0];
  }
  
  private static boolean lIIlIlIllII(int ???, int arg1)
  {
    int i;
    int lllIIllIIIIllI;
    return ??? < i;
  }
  
  public int getComparatorInputOverride(World lllIIllllIIIII, BlockPos lllIIlllIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIlIlIIllI(((Boolean)lllIIllllIIIII.getBlockState(lllIIlllIlllll).getValue(POWERED)).booleanValue()))
    {
      List<EntityMinecartCommandBlock> lllIIlllIllllI = lllIIlllIlllII.findMinecarts(lllIIlllIllIll, lllIIlllIlllll, EntityMinecartCommandBlock.class, new Predicate[lIllIlIlI[0]]);
      if (lIIlIlIIlIl(lllIIlllIllllI.isEmpty())) {
        return ((EntityMinecartCommandBlock)lllIIlllIllllI.get(lIllIlIlI[0])).getCommandBlockLogic().getSuccessCount();
      }
      List<EntityMinecart> lllIIlllIlllIl = lllIIlllIlllII.findMinecarts(lllIIlllIllIll, lllIIlllIlllll, EntityMinecart.class, new Predicate[] { EntitySelectors.selectInventories });
      if (lIIlIlIIlIl(lllIIlllIlllIl.isEmpty())) {
        return Container.calcRedstoneFromInventory((IInventory)lllIIlllIlllIl.get(lIllIlIlI[0]));
      }
    }
    return lIllIlIlI[0];
  }
  
  private static void lIIlIIlIIll()
  {
    lIllIIlIl = new String[lIllIlIlI[7]];
    lIllIIlIl[lIllIlIlI[0]] = lIIlIIlIIIl("Ad4KNoI1rFA=", "ecjnx");
    lIllIIlIl[lIllIlIlI[1]] = lIIlIIlIIlI("OzcGCTouPA==", "KXqlH");
  }
  
  public void randomTick(World lllIlIIIlIlIlI, BlockPos lllIlIIIlIlIIl, IBlockState lllIlIIIlIlIII, Random lllIlIIIlIIlll) {}
}

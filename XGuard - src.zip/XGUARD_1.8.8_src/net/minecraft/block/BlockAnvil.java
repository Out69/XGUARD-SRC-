package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.World;

public class BlockAnvil
  extends BlockFalling
{
  public IBlockState onBlockPlaced(World llllllllllllllIlIlIIIIlIllIIIIIl, BlockPos llllllllllllllIlIlIIIIlIlIllIllI, EnumFacing llllllllllllllIlIlIIIIlIlIllllll, float llllllllllllllIlIlIIIIlIlIllIlII, float llllllllllllllIlIlIIIIlIlIllllIl, float llllllllllllllIlIlIIIIlIlIllIIlI, int llllllllllllllIlIlIIIIlIlIllIIIl, EntityLivingBase llllllllllllllIlIlIIIIlIlIllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllIlIlIIIIlIlIlllIIl = llllllllllllllIlIlIIIIlIlIllIIII.getHorizontalFacing().rotateY();
    return llllllllllllllIlIlIIIIlIllIIIIlI.onBlockPlaced(llllllllllllllIlIlIIIIlIllIIIIIl, llllllllllllllIlIlIIIIlIlIllIllI, llllllllllllllIlIlIIIIlIlIllllll, llllllllllllllIlIlIIIIlIlIlllllI, llllllllllllllIlIlIIIIlIlIllllIl, llllllllllllllIlIlIIIIlIlIllIIlI, llllllllllllllIlIlIIIIlIlIllIIIl, llllllllllllllIlIlIIIIlIlIllIIII).withProperty(FACING, llllllllllllllIlIlIIIIlIlIlllIIl).withProperty(DAMAGE, Integer.valueOf(llllllllllllllIlIlIIIIlIlIllIIIl >> lIIIlIIllIIIl[2]));
  }
  
  public int damageDropped(IBlockState llllllllllllllIlIlIIIIlIlIIlllII)
  {
    ;
    return ((Integer)llllllllllllllIlIlIIIIlIlIIlllII.getValue(DAMAGE)).intValue();
  }
  
  protected void onStartFalling(EntityFallingBlock llllllllllllllIlIlIIIIlIlIIIIlII)
  {
    ;
    llllllllllllllIlIlIIIIlIlIIIIlII.setHurtEntities(lIIIlIIllIIIl[1]);
  }
  
  private static boolean llIlIIlIIIIIll(int ???)
  {
    char llllllllllllllIlIlIIIIlIIlIlIIlI;
    return ??? == 0;
  }
  
  public boolean isOpaqueCube()
  {
    return lIIIlIIllIIIl[0];
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIlIlIIIIlIIllIIllI, new IProperty[] { FACING, DAMAGE });
  }
  
  private static void llIlIIIllllIll()
  {
    lIIIlIIlIllIl = new String[lIIIlIIllIIIl[2]];
    lIIIlIIlIllIl[lIIIlIIllIIIl[0]] = llIlIIIllllIIl("DWfyxdGAHRY=", "RxEaH");
    lIIIlIIlIllIl[lIIIlIIllIIIl[1]] = llIlIIIllllIIl("O3Gu0lfS214=", "zVIUE");
  }
  
  public void getSubBlocks(Item llllllllllllllIlIlIIIIlIlIIIlIIl, CreativeTabs llllllllllllllIlIlIIIIlIlIIIlIll, List<ItemStack> llllllllllllllIlIlIIIIlIlIIIlIlI)
  {
    ;
    ;
    new ItemStack(llllllllllllllIlIlIIIIlIlIIIlIIl, lIIIlIIllIIIl[1], lIIIlIIllIIIl[0]);
    "".length();
    new ItemStack(llllllllllllllIlIlIIIIlIlIIIlIIl, lIIIlIIllIIIl[1], lIIIlIIllIIIl[1]);
    "".length();
    new ItemStack(llllllllllllllIlIlIIIIlIlIIIlIIl, lIIIlIIllIIIl[1], lIIIlIIllIIIl[2]);
    "".length();
  }
  
  private static boolean llIlIIlIIIIlII(Object ???, Object arg1)
  {
    Object localObject;
    float llllllllllllllIlIlIIIIlIIlIlIlII;
    return ??? == localObject;
  }
  
  public boolean isFullCube()
  {
    return lIIIlIIllIIIl[0];
  }
  
  public void onEndFalling(World llllllllllllllIlIlIIIIlIIllllllI, BlockPos llllllllllllllIlIlIIIIlIIlllllIl)
  {
    ;
    ;
    llllllllllllllIlIlIIIIlIIllllllI.playAuxSFX(lIIIlIIllIIIl[3], llllllllllllllIlIlIIIIlIIlllllIl, lIIIlIIllIIIl[0]);
  }
  
  public boolean onBlockActivated(World llllllllllllllIlIlIIIIlIlIlIlIlI, BlockPos llllllllllllllIlIlIIIIlIlIlIlIIl, IBlockState llllllllllllllIlIlIIIIlIlIlIlIII, EntityPlayer llllllllllllllIlIlIIIIlIlIlIIIII, EnumFacing llllllllllllllIlIlIIIIlIlIlIIllI, float llllllllllllllIlIlIIIIlIlIlIIlIl, float llllllllllllllIlIlIIIIlIlIlIIlII, float llllllllllllllIlIlIIIIlIlIlIIIll)
  {
    ;
    ;
    ;
    if (llIlIIlIIIIIll(isRemote)) {
      llllllllllllllIlIlIIIIlIlIlIIIII.displayGui(new Anvil(llllllllllllllIlIlIIIIlIlIlIlIlI, llllllllllllllIlIlIIIIlIlIlIlIIl));
    }
    return lIIIlIIllIIIl[1];
  }
  
  private static String llIlIIIllllIIl(String llllllllllllllIlIlIIIIlIIlIllIll, String llllllllllllllIlIlIIIIlIIlIlllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIlIIIIlIIllIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIIIIlIIlIlllII.getBytes(StandardCharsets.UTF_8)), lIIIlIIllIIIl[6]), "DES");
      Cipher llllllllllllllIlIlIIIIlIIlIlllll = Cipher.getInstance("DES");
      llllllllllllllIlIlIIIIlIIlIlllll.init(lIIIlIIllIIIl[2], llllllllllllllIlIlIIIIlIIllIIIII);
      return new String(llllllllllllllIlIlIIIIlIIlIlllll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIIIIlIIlIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIlIIIIlIIlIllllI)
    {
      llllllllllllllIlIlIIIIlIIlIllllI.printStackTrace();
    }
    return null;
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIlIlIIIIlIIllIllll)
  {
    ;
    ;
    return llllllllllllllIlIlIIIIlIIlllIIII.getDefaultState().withProperty(FACING, EnumFacing.getHorizontal(llllllllllllllIlIlIIIIlIIllIllll & lIIIlIIllIIIl[4])).withProperty(DAMAGE, Integer.valueOf((llllllllllllllIlIlIIIIlIIllIllll & lIIIlIIllIIIl[5]) >> lIIIlIIllIIIl[2]));
  }
  
  public boolean shouldSideBeRendered(IBlockAccess llllllllllllllIlIlIIIIlIIllllIll, BlockPos llllllllllllllIlIlIIIIlIIllllIlI, EnumFacing llllllllllllllIlIlIIIIlIIllllIIl)
  {
    return lIIIlIIllIIIl[1];
  }
  
  public IBlockState getStateForEntityRender(IBlockState llllllllllllllIlIlIIIIlIIlllIllI)
  {
    ;
    return llllllllllllllIlIlIIIIlIIlllIlll.getDefaultState().withProperty(FACING, EnumFacing.SOUTH);
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIlIlIIIIlIIllIlIll)
  {
    ;
    ;
    int llllllllllllllIlIlIIIIlIIllIlIlI = lIIIlIIllIIIl[0];
    llllllllllllllIlIlIIIIlIIllIlIlI |= ((EnumFacing)llllllllllllllIlIlIIIIlIIllIlIIl.getValue(FACING)).getHorizontalIndex();
    llllllllllllllIlIlIIIIlIIllIlIlI |= ((Integer)llllllllllllllIlIlIIIIlIIllIlIIl.getValue(DAMAGE)).intValue() << lIIIlIIllIIIl[2];
    return llllllllllllllIlIlIIIIlIIllIlIlI;
  }
  
  private static void llIlIIlIIIIIlI()
  {
    lIIIlIIllIIIl = new int[7];
    lIIIlIIllIIIl[0] = ((0x81 ^ 0xBC) & (0x24 ^ 0x19 ^ 0xFFFFFFFF));
    lIIIlIIllIIIl[1] = " ".length();
    lIIIlIIllIIIl[2] = "  ".length();
    lIIIlIIllIIIl[3] = (0xC7FF & 0x3BFE);
    lIIIlIIllIIIl[4] = "   ".length();
    lIIIlIIllIIIl[5] = ('' + 61 - 59 + 4 ^ 37 + '«' - 174 + 138);
    lIIIlIIllIIIl[6] = (0x98 ^ 0xA9 ^ 0xAB ^ 0x92);
  }
  
  static
  {
    llIlIIlIIIIIlI();
    llIlIIIllllIll();
  }
  
  protected BlockAnvil()
  {
    llllllllllllllIlIlIIIIlIllIIllll.<init>(Material.anvil);
    llllllllllllllIlIlIIIIlIllIlIIII.setDefaultState(blockState.getBaseState().withProperty(FACING, EnumFacing.NORTH).withProperty(DAMAGE, Integer.valueOf(lIIIlIIllIIIl[0])));
    "".length();
    "".length();
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess llllllllllllllIlIlIIIIlIlIIlIIlI, BlockPos llllllllllllllIlIlIIIIlIlIIlIlIl)
  {
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllIlIlIIIIlIlIIlIlII = (EnumFacing)llllllllllllllIlIlIIIIlIlIIlIIlI.getBlockState(llllllllllllllIlIlIIIIlIlIIlIlIl).getValue(FACING);
    if (llIlIIlIIIIlII(llllllllllllllIlIlIIIIlIlIIlIlII.getAxis(), EnumFacing.Axis.X))
    {
      llllllllllllllIlIlIIIIlIlIIlIIll.setBlockBounds(0.0F, 0.0F, 0.125F, 1.0F, 1.0F, 0.875F);
      "".length();
      if (" ".length() == " ".length()) {}
    }
    else
    {
      llllllllllllllIlIlIIIIlIlIIlIIll.setBlockBounds(0.125F, 0.0F, 0.0F, 0.875F, 1.0F, 1.0F);
    }
  }
  
  public static class Anvil
    implements IInteractionObject
  {
    private static String lIllIIlIIllII(String llllllllllllllllIIlIllIllIIlIllI, String llllllllllllllllIIlIllIllIIlIlIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllllIIlIllIllIIlIllI = new String(Base64.getDecoder().decode(llllllllllllllllIIlIllIllIIlIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllllIIlIllIllIIlIlII = new StringBuilder();
      char[] llllllllllllllllIIlIllIllIIlIIll = llllllllllllllllIIlIllIllIIlIlIl.toCharArray();
      int llllllllllllllllIIlIllIllIIlIIlI = lllIlIIIlII[0];
      String llllllllllllllllIIlIllIllIIIllII = llllllllllllllllIIlIllIllIIlIllI.toCharArray();
      Exception llllllllllllllllIIlIllIllIIIlIll = llllllllllllllllIIlIllIllIIIllII.length;
      Exception llllllllllllllllIIlIllIllIIIlIlI = lllIlIIIlII[0];
      while (lIllIIlIlIIlI(llllllllllllllllIIlIllIllIIIlIlI, llllllllllllllllIIlIllIllIIIlIll))
      {
        char llllllllllllllllIIlIllIllIIlIlll = llllllllllllllllIIlIllIllIIIllII[llllllllllllllllIIlIllIllIIIlIlI];
        "".length();
        "".length();
        if (-(0x46 ^ 0x37 ^ 0xF6 ^ 0x82) >= 0) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllllIIlIllIllIIlIlII);
    }
    
    public Container createContainer(InventoryPlayer llllllllllllllllIIlIllIllIllIIII, EntityPlayer llllllllllllllllIIlIllIllIllIIlI)
    {
      ;
      ;
      ;
      return new ContainerRepair(llllllllllllllllIIlIllIllIllIIll, world, position, llllllllllllllllIIlIllIllIllIIlI);
    }
    
    public IChatComponent getDisplayName()
    {
      return new ChatComponentTranslation(String.valueOf(new StringBuilder(String.valueOf(Blocks.anvil.getUnlocalizedName())).append(lllIlIIIIlI[lllIlIIIlII[1]])), new Object[lllIlIIIlII[0]]);
    }
    
    private static void lIllIIlIIlllI()
    {
      lllIlIIIIlI = new String[lllIlIIIlII[3]];
      lllIlIIIIlI[lllIlIIIlII[0]] = lIllIIlIIllII("EA0gBSg=", "qcVlD");
      lllIlIIIIlI[lllIlIIIlII[1]] = lIllIIlIIllIl("oR402DINpJA=", "Iiltg");
      lllIlIIIIlI[lllIlIIIlII[2]] = lIllIIlIIllIl("omSEszL7PRJr78Yay3TLxQ==", "Efavn");
    }
    
    private static String lIllIIlIIllIl(String llllllllllllllllIIlIllIllIlIIllI, String llllllllllllllllIIlIllIllIlIIIll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllllIIlIllIllIlIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIlIllIllIlIIIll.getBytes(StandardCharsets.UTF_8)), lllIlIIIlII[4]), "DES");
        Cipher llllllllllllllllIIlIllIllIlIlIII = Cipher.getInstance("DES");
        llllllllllllllllIIlIllIllIlIlIII.init(lllIlIIIlII[2], llllllllllllllllIIlIllIllIlIlIIl);
        return new String(llllllllllllllllIIlIllIllIlIlIII.doFinal(Base64.getDecoder().decode(llllllllllllllllIIlIllIllIlIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllllIIlIllIllIlIIlll)
      {
        llllllllllllllllIIlIllIllIlIIlll.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIllIIlIlIIlI(int ???, int arg1)
    {
      int i;
      String llllllllllllllllIIlIllIllIIIIlIl;
      return ??? < i;
    }
    
    public String getName()
    {
      return lllIlIIIIlI[lllIlIIIlII[0]];
    }
    
    static
    {
      lIllIIlIlIIIl();
      lIllIIlIIlllI();
    }
    
    public Anvil(World llllllllllllllllIIlIllIllIllllll, BlockPos llllllllllllllllIIlIllIllIlllIll)
    {
      world = llllllllllllllllIIlIllIllIllllII;
      position = llllllllllllllllIIlIllIllIlllIll;
    }
    
    public String getGuiID()
    {
      return lllIlIIIIlI[lllIlIIIlII[2]];
    }
    
    private static void lIllIIlIlIIIl()
    {
      lllIlIIIlII = new int[5];
      lllIlIIIlII[0] = ((0x7D ^ 0x65) & (0x48 ^ 0x50 ^ 0xFFFFFFFF));
      lllIlIIIlII[1] = " ".length();
      lllIlIIIlII[2] = "  ".length();
      lllIlIIIlII[3] = "   ".length();
      lllIlIIIlII[4] = (0xC ^ 0x4);
    }
    
    public boolean hasCustomName()
    {
      return lllIlIIIlII[0];
    }
  }
}

package net.minecraft.block;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockNewLeaf
  extends BlockLeaves
{
  private static void llIllIll()
  {
    llllIl = new String[lllllI[1]];
    llllIl[lllllI[0]] = llIllIlI("T+ihAMRBKuk=", "nvouK");
  }
  
  private static boolean llIlllIl(Object ???, Object arg1)
  {
    Object localObject;
    int lllIIlIlllllIII;
    return ??? == localObject;
  }
  
  public BlockPlanks.EnumType getWoodType(int lllIIllIIIllllI)
  {
    ;
    return BlockPlanks.EnumType.byMetadata((lllIIllIIIllllI & lllllI[2]) + lllllI[3]);
  }
  
  private static boolean llIllllI(int ???)
  {
    float lllIIlIllllIIlI;
    return ??? == 0;
  }
  
  private static void llIlllII()
  {
    lllllI = new int[6];
    lllllI[0] = ("  ".length() & ("  ".length() ^ -" ".length()));
    lllllI[1] = " ".length();
    lllllI[2] = "   ".length();
    lllllI[3] = (0x75 ^ 0x71);
    lllllI[4] = (0x7C ^ 0x74);
    lllllI[5] = "  ".length();
  }
  
  private static boolean llIlllll(int ???)
  {
    short lllIIlIllllIIII;
    return ??? > 0;
  }
  
  protected void dropApple(World lllIIllIlIIlllI, BlockPos lllIIllIlIIllIl, IBlockState lllIIllIlIlIIII, int lllIIllIlIIlIll)
  {
    ;
    ;
    ;
    ;
    if ((llIlllIl(lllIIllIlIlIIII.getValue(VARIANT), BlockPlanks.EnumType.DARK_OAK)) && (llIllllI(rand.nextInt(lllIIllIlIIlIll)))) {
      spawnAsEntity(lllIIllIlIIlllI, lllIIllIlIIllIl, new ItemStack(Items.apple, lllllI[1], lllllI[0]));
    }
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lllIIllIIIlllII, new IProperty[] { VARIANT, CHECK_DECAY, DECAYABLE });
  }
  
  public int damageDropped(IBlockState lllIIllIlIIlIII)
  {
    ;
    return ((BlockPlanks.EnumType)lllIIllIlIIlIII.getValue(VARIANT)).getMetadata();
  }
  
  private static boolean lllIIIII(int ???)
  {
    float lllIIlIllllIlII;
    return ??? != 0;
  }
  
  public int getDamageValue(World lllIIllIlIIIIlI, BlockPos lllIIllIlIIIIIl)
  {
    ;
    ;
    ;
    IBlockState lllIIllIlIIIIII = lllIIllIlIIIIlI.getBlockState(lllIIllIlIIIIIl);
    return lllIIllIlIIIIII.getBlock().getMetaFromState(lllIIllIlIIIIII) & lllllI[2];
  }
  
  public int getMetaFromState(IBlockState lllIIllIIlIIIll)
  {
    ;
    ;
    int lllIIllIIlIIlII = lllllI[0];
    lllIIllIIlIIlII |= ((BlockPlanks.EnumType)lllIIllIIlIIlIl.getValue(VARIANT)).getMetadata() - lllllI[3];
    if (llIllllI(((Boolean)lllIIllIIlIIlIl.getValue(DECAYABLE)).booleanValue())) {
      lllIIllIIlIIlII |= lllllI[3];
    }
    if (lllIIIII(((Boolean)lllIIllIIlIIlIl.getValue(CHECK_DECAY)).booleanValue())) {
      lllIIllIIlIIlII |= lllllI[4];
    }
    return lllIIllIIlIIlII;
  }
  
  private static String llIllIlI(String lllIIllIIIIIIIl, String lllIIllIIIIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllIIllIIIIIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllIIllIIIIIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllIIllIIIIIIll = Cipher.getInstance("Blowfish");
      lllIIllIIIIIIll.init(lllllI[5], lllIIllIIIIIlII);
      return new String(lllIIllIIIIIIll.doFinal(Base64.getDecoder().decode(lllIIllIIIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllIIllIIIIIIlI)
    {
      lllIIllIIIIIIlI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIIIl(Object ???)
  {
    byte lllIIlIllllIllI;
    return ??? != null;
  }
  
  public IBlockState getStateFromMeta(int lllIIllIIlIlIIl)
  {
    ;
    ;
    if (llIllllI(lllIIllIIlIlIIl & lllllI[3]))
    {
      "".length();
      if (((0xC8 ^ 0x9B) & (0x30 ^ 0x63 ^ 0xFFFFFFFF)) == ((0x15 ^ 0x39) & (0x7B ^ 0x57 ^ 0xFFFFFFFF))) {
        break label83;
      }
      return null;
    }
    label83:
    if (llIlllll(lllIIllIIlIlIIl & lllllI[4]))
    {
      "".length();
      if ((0x5 ^ 0x1) <= (0xBD ^ 0xB9)) {
        break label139;
      }
      return null;
    }
    label139:
    return CHECK_DECAY.withProperty(lllllI[1], Boolean.valueOf(lllllI[0]));
  }
  
  public void harvestBlock(World lllIIllIIIlIIll, EntityPlayer lllIIllIIIlIIlI, BlockPos lllIIllIIIIlIll, IBlockState lllIIllIIIlIIII, TileEntity lllIIllIIIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((llIllllI(isRemote)) && (lllIIIIl(lllIIllIIIlIIlI.getCurrentEquippedItem())) && (llIlllIl(lllIIllIIIlIIlI.getCurrentEquippedItem().getItem(), Items.shears)))
    {
      lllIIllIIIlIIlI.triggerAchievement(net.minecraft.stats.StatList.mineBlockStatArray[Block.getIdFromBlock(lllIIllIIIlIlII)]);
      spawnAsEntity(lllIIllIIIlIIll, lllIIllIIIIlIll, new ItemStack(Item.getItemFromBlock(lllIIllIIIlIlII), lllllI[1], ((BlockPlanks.EnumType)lllIIllIIIlIIII.getValue(VARIANT)).getMetadata() - lllllI[3]));
      "".length();
      if (((9 + 26 - 65404 + 16 ^ '¢' + 104 - 180 + 83) & (0xB5 ^ 0xAD ^ 0xC5 ^ 0xC3 ^ -" ".length())) == ((0x8B ^ 0x91 ^ 0x14 ^ 0x2F) & (0x54 ^ 0x23 ^ 0x72 ^ 0x24 ^ -" ".length()))) {}
    }
    else
    {
      lllIIllIIIlIlII.harvestBlock(lllIIllIIIlIIll, lllIIllIIIlIIlI, lllIIllIIIIlIll, lllIIllIIIlIIII, lllIIllIIIIlIIl);
    }
  }
  
  protected ItemStack createStackedBlock(IBlockState lllIIllIIlIllll)
  {
    ;
    ;
    return new ItemStack(Item.getItemFromBlock(lllIIllIIllIIII), lllllI[1], ((BlockPlanks.EnumType)lllIIllIIlIllll.getValue(VARIANT)).getMetadata() - lllllI[3]);
  }
  
  public BlockNewLeaf()
  {
    lllIIllIlIllIIl.setDefaultState(blockState.getBaseState().withProperty(VARIANT, BlockPlanks.EnumType.ACACIA).withProperty(CHECK_DECAY, Boolean.valueOf(lllllI[1])).withProperty(DECAYABLE, Boolean.valueOf(lllllI[1])));
  }
  
  public void getSubBlocks(Item lllIIllIIlllIIl, CreativeTabs lllIIllIIlllIII, List<ItemStack> lllIIllIIllIlIl)
  {
    ;
    ;
    new ItemStack(lllIIllIIlllIIl, lllllI[1], lllllI[0]);
    "".length();
    new ItemStack(lllIIllIIlllIIl, lllllI[1], lllllI[1]);
    "".length();
  }
  
  static
  {
    llIlllII();
    llIllIll();
  }
}

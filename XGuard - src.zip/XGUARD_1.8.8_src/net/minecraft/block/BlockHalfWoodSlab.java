package net.minecraft.block;

public class BlockHalfWoodSlab
  extends BlockWoodSlab
{
  private static void lIIlIlllIlIl()
  {
    lIlllllIII = new int[1];
    lIlllllIII[0] = ((0x19 ^ 0xD ^ 0x47 ^ 0x5B) & (82 + 50 - 125 + 163 ^ 61 + 108 - 66 + 59 ^ -" ".length()));
  }
  
  public boolean isDouble()
  {
    return lIlllllIII[0];
  }
  
  static {}
  
  public BlockHalfWoodSlab() {}
}

package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;

public class BlockIce
  extends BlockBreakable
{
  private static boolean lIllIIIlIIlII(Object ???)
  {
    float llllllllllllllllIIllIIIIIllIIIIl;
    return ??? != null;
  }
  
  public int getMobilityFlag()
  {
    return lllIIlIlllI[0];
  }
  
  public void harvestBlock(World llllllllllllllllIIllIIIIIllllIlI, EntityPlayer llllllllllllllllIIllIIIIlIIIIIlI, BlockPos llllllllllllllllIIllIIIIIllllIII, IBlockState llllllllllllllllIIllIIIIlIIIIIII, TileEntity llllllllllllllllIIllIIIIIlllllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIllIIIIlIIIIIlI.triggerAchievement(net.minecraft.stats.StatList.mineBlockStatArray[Block.getIdFromBlock(llllllllllllllllIIllIIIIIllllIll)]);
    llllllllllllllllIIllIIIIlIIIIIlI.addExhaustion(0.025F);
    if ((lIllIIIlIIIll(llllllllllllllllIIllIIIIIllllIll.canSilkHarvest())) && (lIllIIIlIIIll(EnchantmentHelper.getSilkTouchModifier(llllllllllllllllIIllIIIIlIIIIIlI))))
    {
      ItemStack llllllllllllllllIIllIIIIIllllllI = llllllllllllllllIIllIIIIIllllIll.createStackedBlock(llllllllllllllllIIllIIIIlIIIIIII);
      if (lIllIIIlIIlII(llllllllllllllllIIllIIIIIllllllI))
      {
        spawnAsEntity(llllllllllllllllIIllIIIIIllllIlI, llllllllllllllllIIllIIIIIllllIII, llllllllllllllllIIllIIIIIllllllI);
        "".length();
        if (" ".length() >= " ".length()) {}
      }
    }
    else
    {
      if (lIllIIIlIIIll(provider.doesWaterVaporize()))
      {
        "".length();
        return;
      }
      int llllllllllllllllIIllIIIIIlllllIl = EnchantmentHelper.getFortuneModifier(llllllllllllllllIIllIIIIlIIIIIlI);
      llllllllllllllllIIllIIIIIllllIll.dropBlockAsItem(llllllllllllllllIIllIIIIIllllIlI, llllllllllllllllIIllIIIIIllllIII, llllllllllllllllIIllIIIIlIIIIIII, llllllllllllllllIIllIIIIIlllllIl);
      Material llllllllllllllllIIllIIIIIlllllII = llllllllllllllllIIllIIIIIllllIlI.getBlockState(llllllllllllllllIIllIIIIIllllIII.down()).getBlock().getMaterial();
      if ((!lIllIIIlIIlIl(llllllllllllllllIIllIIIIIlllllII.blocksMovement())) || (lIllIIIlIIIll(llllllllllllllllIIllIIIIIlllllII.isLiquid()))) {
        "".length();
      }
    }
  }
  
  private static void lIllIIIlIIIlI()
  {
    lllIIlIlllI = new int[3];
    lllIIlIlllI[0] = ((0x6D ^ 0x2D) & (0x79 ^ 0x39 ^ 0xFFFFFFFF));
    lllIIlIlllI[1] = " ".length();
    lllIIlIlllI[2] = (0x36 ^ 0x3D);
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.TRANSLUCENT;
  }
  
  public void updateTick(World llllllllllllllllIIllIIIIIllIlllI, BlockPos llllllllllllllllIIllIIIIIllIllIl, IBlockState llllllllllllllllIIllIIIIIllIllII, Random llllllllllllllllIIllIIIIIllIlIll)
  {
    ;
    ;
    ;
    if (lIllIIIlIIllI(llllllllllllllllIIllIIIIIllIlllI.getLightFor(EnumSkyBlock.BLOCK, llllllllllllllllIIllIIIIIllIlIII), lllIIlIlllI[2] - llllllllllllllllIIllIIIIIllIllll.getLightOpacity())) {
      if (lIllIIIlIIIll(provider.doesWaterVaporize()))
      {
        "".length();
        "".length();
        if (null == null) {}
      }
      else
      {
        llllllllllllllllIIllIIIIIllIllll.dropBlockAsItem(llllllllllllllllIIllIIIIIllIlllI, llllllllllllllllIIllIIIIIllIlIII, llllllllllllllllIIllIIIIIllIlllI.getBlockState(llllllllllllllllIIllIIIIIllIlIII), lllIIlIlllI[0]);
        "".length();
      }
    }
  }
  
  private static boolean lIllIIIlIIlIl(int ???)
  {
    float llllllllllllllllIIllIIIIIlIlllIl;
    return ??? == 0;
  }
  
  static {}
  
  private static boolean lIllIIIlIIllI(int ???, int arg1)
  {
    int i;
    int llllllllllllllllIIllIIIIIllIIIll;
    return ??? > i;
  }
  
  public int quantityDropped(Random llllllllllllllllIIllIIIIIlllIIll)
  {
    return lllIIlIlllI[0];
  }
  
  public BlockIce()
  {
    llllllllllllllllIIllIIIIlIIlIIlI.<init>(Material.ice, lllIIlIlllI[0]);
    slipperiness = 0.98F;
    "".length();
    "".length();
  }
  
  private static boolean lIllIIIlIIIll(int ???)
  {
    short llllllllllllllllIIllIIIIIlIlllll;
    return ??? != 0;
  }
}

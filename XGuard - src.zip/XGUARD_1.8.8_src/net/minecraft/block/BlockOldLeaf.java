package net.minecraft.block;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.world.ColorizerFoliage;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockOldLeaf
  extends BlockLeaves
{
  public int getMetaFromState(IBlockState lIlIIIllllIlIll)
  {
    ;
    ;
    int lIlIIIllllIlIlI = llllIIIl[0];
    lIlIIIllllIlIlI |= ((BlockPlanks.EnumType)lIlIIIllllIlIIl.getValue(VARIANT)).getMetadata();
    if (llIIIIlIlI(((Boolean)lIlIIIllllIlIIl.getValue(DECAYABLE)).booleanValue())) {
      lIlIIIllllIlIlI |= llllIIIl[3];
    }
    if (llIIIIllII(((Boolean)lIlIIIllllIlIIl.getValue(CHECK_DECAY)).booleanValue())) {
      lIlIIIllllIlIlI |= llllIIIl[4];
    }
    return lIlIIIllllIlIlI;
  }
  
  protected ItemStack createStackedBlock(IBlockState lIlIIIlllllIlll)
  {
    ;
    ;
    return new ItemStack(Item.getItemFromBlock(lIlIIIlllllIllI), llllIIIl[1], ((BlockPlanks.EnumType)lIlIIIlllllIlll.getValue(VARIANT)).getMetadata());
  }
  
  private static void llIIIIIlll()
  {
    llllIIIl = new int[7];
    llllIIIl[0] = ((0x62 ^ 0x33) & (0x6A ^ 0x3B ^ 0xFFFFFFFF));
    llllIIIl[1] = " ".length();
    llllIIIl[2] = (63 + 2 - 35 + 161 ^ '' + 3 - 12 + 30);
    llllIIIl[3] = (0x28 ^ 0x2C);
    llllIIIl[4] = (0xE5 ^ 0xB1 ^ 0x5D ^ 0x1);
    llllIIIl[5] = "   ".length();
    llllIIIl[6] = "  ".length();
  }
  
  public int getRenderColor(IBlockState lIlIIlIIIlIllII)
  {
    ;
    ;
    ;
    if (llIIIIlIII(lIlIIlIIIlIllII.getBlock(), lIlIIlIIIlIllIl)) {
      return lIlIIlIIIlIllIl.getRenderColor(lIlIIlIIIlIllII);
    }
    BlockPlanks.EnumType lIlIIlIIIlIlIll = (BlockPlanks.EnumType)lIlIIlIIIlIllII.getValue(VARIANT);
    if (llIIIIlIIl(lIlIIlIIIlIlIll, BlockPlanks.EnumType.SPRUCE))
    {
      "".length();
      if (null != null) {
        return (0x2A ^ 0x78) & (0x61 ^ 0x33 ^ 0xFFFFFFFF);
      }
    }
    else if (llIIIIlIIl(lIlIIlIIIlIlIll, BlockPlanks.EnumType.BIRCH))
    {
      "".length();
      if (((0x19 ^ 0x54 ^ 0x1D ^ 0x6B) & (86 + 21 - -54 + 25 ^ 25 + 20 - -2 + 82 ^ -" ".length())) < " ".length()) {
        break label200;
      }
      return ('´' + 33 - 98 + 113 ^ 38 + 33 - -70 + 56) & (4 + '' - 78 + 84 ^ 125 + 48 - 138 + 94 ^ -" ".length());
    }
    label200:
    return lIlIIlIIIlIllIl.getRenderColor(lIlIIlIIIlIllII);
  }
  
  private static boolean llIIIIlIll(int ???)
  {
    char lIlIIIllIlIlllI;
    return ??? > 0;
  }
  
  public int colorMultiplier(IBlockAccess lIlIIlIIIIllIlI, BlockPos lIlIIlIIIIlllll, int lIlIIlIIIIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState lIlIIlIIIIlllIl = lIlIIlIIIIllIlI.getBlockState(lIlIIlIIIIlllll);
    if (llIIIIlIIl(lIlIIlIIIIlllIl.getBlock(), lIlIIlIIIlIIIIl))
    {
      BlockPlanks.EnumType lIlIIlIIIIlllII = (BlockPlanks.EnumType)lIlIIlIIIIlllIl.getValue(VARIANT);
      if (llIIIIlIIl(lIlIIlIIIIlllII, BlockPlanks.EnumType.SPRUCE)) {
        return ColorizerFoliage.getFoliageColorPine();
      }
      if (llIIIIlIIl(lIlIIlIIIIlllII, BlockPlanks.EnumType.BIRCH)) {
        return ColorizerFoliage.getFoliageColorBirch();
      }
    }
    return lIlIIlIIIlIIIIl.colorMultiplier(lIlIIlIIIIllIlI, lIlIIlIIIIlllll, lIlIIlIIIIllIII);
  }
  
  private static String llIIIIIlIl(String lIlIIIlllIIIIIl, String lIlIIIlllIIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIlIIIlllIIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIlIIIlllIIIIlI.getBytes(StandardCharsets.UTF_8)), llllIIIl[4]), "DES");
      Cipher lIlIIIlllIIIlIl = Cipher.getInstance("DES");
      lIlIIIlllIIIlIl.init(llllIIIl[6], lIlIIIlllIIIllI);
      return new String(lIlIIIlllIIIlIl.doFinal(Base64.getDecoder().decode(lIlIIIlllIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIlIIIlllIIIlII)
    {
      lIlIIIlllIIIlII.printStackTrace();
    }
    return null;
  }
  
  public void harvestBlock(World lIlIIIlllIIllll, EntityPlayer lIlIIIlllIlIlII, BlockPos lIlIIIlllIlIIll, IBlockState lIlIIIlllIlIIlI, TileEntity lIlIIIlllIIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((llIIIIlIlI(isRemote)) && (llIIIIllIl(lIlIIIlllIlIlII.getCurrentEquippedItem())) && (llIIIIlIIl(lIlIIIlllIlIlII.getCurrentEquippedItem().getItem(), Items.shears)))
    {
      lIlIIIlllIlIlII.triggerAchievement(net.minecraft.stats.StatList.mineBlockStatArray[Block.getIdFromBlock(lIlIIIlllIlIIII)]);
      spawnAsEntity(lIlIIIlllIIllll, lIlIIIlllIlIIll, new ItemStack(Item.getItemFromBlock(lIlIIIlllIlIIII), llllIIIl[1], ((BlockPlanks.EnumType)lIlIIIlllIlIIlI.getValue(VARIANT)).getMetadata()));
      "".length();
      if ((0xA0 ^ 0x8F ^ 0x8E ^ 0xA5) != ((4 + '' - 15 + 36 ^ 108 + 42 - 134 + 115) & (93 + 1 - 73 + 170 ^ 54 + 61 - 97 + 114 ^ -" ".length()))) {}
    }
    else
    {
      lIlIIIlllIlIIII.harvestBlock(lIlIIIlllIIllll, lIlIIIlllIlIlII, lIlIIIlllIlIIll, lIlIIIlllIlIIlI, lIlIIIlllIIlIll);
    }
  }
  
  protected void dropApple(World lIlIIlIIIIIllII, BlockPos lIlIIlIIIIIlIll, IBlockState lIlIIlIIIIIlllI, int lIlIIlIIIIIlIIl)
  {
    ;
    ;
    ;
    ;
    if ((llIIIIlIIl(lIlIIlIIIIIlllI.getValue(VARIANT), BlockPlanks.EnumType.OAK)) && (llIIIIlIlI(rand.nextInt(lIlIIlIIIIIlIIl)))) {
      spawnAsEntity(lIlIIlIIIIIllII, lIlIIlIIIIIlIll, new ItemStack(Items.apple, llllIIIl[1], llllIIIl[0]));
    }
  }
  
  public IBlockState getStateFromMeta(int lIlIIIlllllIIIl)
  {
    ;
    ;
    if (llIIIIlIlI(lIlIIIlllllIIIl & llllIIIl[3]))
    {
      "".length();
      if (-"   ".length() < 0) {
        break label60;
      }
      return null;
    }
    label60:
    if (llIIIIlIll(lIlIIIlllllIIIl & llllIIIl[4]))
    {
      "".length();
      if (null == null) {
        break label106;
      }
      return null;
    }
    label106:
    return CHECK_DECAY.withProperty(llllIIIl[1], Boolean.valueOf(llllIIIl[0]));
  }
  
  private static boolean llIIIIlIlI(int ???)
  {
    boolean lIlIIIllIllIIII;
    return ??? == 0;
  }
  
  public BlockOldLeaf()
  {
    lIlIIlIIIllIIIl.setDefaultState(blockState.getBaseState().withProperty(VARIANT, BlockPlanks.EnumType.OAK).withProperty(CHECK_DECAY, Boolean.valueOf(llllIIIl[1])).withProperty(DECAYABLE, Boolean.valueOf(llllIIIl[1])));
  }
  
  static
  {
    llIIIIIlll();
    llIIIIIllI();
  }
  
  public void getSubBlocks(Item lIlIIIlllllllII, CreativeTabs lIlIIIllllllllI, List<ItemStack> lIlIIIllllllIll)
  {
    ;
    ;
    new ItemStack(lIlIIIlllllllII, llllIIIl[1], BlockPlanks.EnumType.OAK.getMetadata());
    "".length();
    new ItemStack(lIlIIIlllllllII, llllIIIl[1], BlockPlanks.EnumType.SPRUCE.getMetadata());
    "".length();
    new ItemStack(lIlIIIlllllllII, llllIIIl[1], BlockPlanks.EnumType.BIRCH.getMetadata());
    "".length();
    new ItemStack(lIlIIIlllllllII, llllIIIl[1], BlockPlanks.EnumType.JUNGLE.getMetadata());
    "".length();
  }
  
  private static boolean llIIIIllII(int ???)
  {
    long lIlIIIllIllIIlI;
    return ??? != 0;
  }
  
  private static boolean llIIIIllIl(Object ???)
  {
    long lIlIIIllIllIlII;
    return ??? != null;
  }
  
  protected int getSaplingDropChance(IBlockState lIlIIlIIIIIIlIl)
  {
    ;
    ;
    if (llIIIIlIIl(lIlIIlIIIIIIlIl.getValue(VARIANT), BlockPlanks.EnumType.JUNGLE))
    {
      "".length();
      if (-" ".length() < " ".length()) {
        break label96;
      }
      return ('Ó' + 45 - 248 + 206 ^ 60 + 98 - 106 + 104) & (0x13 ^ 0x69 ^ 0xB3 ^ 0x83 ^ -" ".length());
    }
    label96:
    return lIlIIlIIIIIIlII.getSaplingDropChance(lIlIIlIIIIIIlIl);
  }
  
  public BlockPlanks.EnumType getWoodType(int lIlIIIllllIIlIl)
  {
    ;
    return BlockPlanks.EnumType.byMetadata((lIlIIIllllIIlIl & llllIIIl[5]) % llllIIIl[3]);
  }
  
  private static boolean llIIIIlIIl(Object ???, Object arg1)
  {
    Object localObject;
    Exception lIlIIIllIllIllI;
    return ??? == localObject;
  }
  
  private static boolean llIIIIlIII(Object ???, Object arg1)
  {
    Object localObject;
    int lIlIIIllIlllIlI;
    return ??? != localObject;
  }
  
  public int damageDropped(IBlockState lIlIIIlllIlllIl)
  {
    ;
    return ((BlockPlanks.EnumType)lIlIIIlllIlllIl.getValue(VARIANT)).getMetadata();
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(lIlIIIllllIIIIl, new IProperty[] { VARIANT, CHECK_DECAY, DECAYABLE });
  }
  
  private static void llIIIIIllI()
  {
    llllIIII = new String[llllIIIl[1]];
    llllIIII[llllIIIl[0]] = llIIIIIlIl("5mZzwT5ntKo=", "hymiZ");
  }
}

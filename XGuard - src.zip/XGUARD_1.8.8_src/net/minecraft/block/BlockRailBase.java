package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Plane;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public abstract class BlockRailBase
  extends Block
{
  public AxisAlignedBB getCollisionBoundingBox(World lIllIIIllIIlll, BlockPos lIllIIIllIIllI, IBlockState lIllIIIllIIlIl)
  {
    return null;
  }
  
  public boolean isFullCube()
  {
    return llIlIllIl[0];
  }
  
  public boolean isOpaqueCube()
  {
    return llIlIllIl[0];
  }
  
  private static boolean lIllIIIIIlI(Object ???)
  {
    int lIlIllllllIIIl;
    return ??? != null;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public void setBlockBoundsBasedOnState(IBlockAccess lIllIIIlIIlllI, BlockPos lIllIIIlIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    IBlockState lIllIIIlIIllII = lIllIIIlIIlllI.getBlockState(lIllIIIlIIllIl);
    if (lIllIIIIIIl(lIllIIIlIIllII.getBlock(), lIllIIIlIIllll))
    {
      "".length();
      if ("   ".length() != 0) {
        break label50;
      }
    }
    label50:
    EnumRailDirection lIllIIIlIIlIll = null;
    if ((lIllIIIIIlI(lIllIIIlIIlIll)) && (lIllIIIIIll(lIllIIIlIIlIll.isAscending())))
    {
      lIllIIIlIIllll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.625F, 1.0F);
      "".length();
      if (null == null) {}
    }
    else
    {
      lIllIIIlIIllll.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
    }
  }
  
  public int getMobilityFlag()
  {
    return llIlIllIl[0];
  }
  
  static {}
  
  public boolean canPlaceBlockAt(World lIllIIIIllllll, BlockPos lIllIIIlIIIIII)
  {
    ;
    ;
    return World.doesBlockHaveSolidTopSurface(lIllIIIIllllll, lIllIIIlIIIIII.down());
  }
  
  public abstract IProperty<EnumRailDirection> getShapeProperty();
  
  private static boolean lIllIIIIlII(int ???)
  {
    double lIlIlllllIllIl;
    return ??? == 0;
  }
  
  private static boolean lIllIIIIIll(int ???)
  {
    String lIlIlllllIllll;
    return ??? != 0;
  }
  
  public static boolean isRailBlock(World lIllIIIllllIII, BlockPos lIllIIIlllIlIl)
  {
    ;
    ;
    return isRailBlock(lIllIIIllllIII.getBlockState(lIllIIIlllIlIl));
  }
  
  protected BlockRailBase(boolean lIllIIIllIlIll)
  {
    lIllIIIllIlIlI.<init>(Material.circuits);
    isPowered = lIllIIIllIlIll;
    lIllIIIllIlIlI.setBlockBounds(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
    "".length();
  }
  
  public static boolean isRailBlock(IBlockState lIllIIIlllIIII)
  {
    ;
    ;
    Block lIllIIIlllIIIl = lIllIIIlllIIII.getBlock();
    if ((lIllIIIIIII(lIllIIIlllIIIl, Blocks.rail)) && (lIllIIIIIII(lIllIIIlllIIIl, Blocks.golden_rail)) && (lIllIIIIIII(lIllIIIlllIIIl, Blocks.detector_rail)) && (lIllIIIIIII(lIllIIIlllIIIl, Blocks.activator_rail))) {
      return llIlIllIl[0];
    }
    return llIlIllIl[1];
  }
  
  public MovingObjectPosition collisionRayTrace(World lIllIIIlIllIII, BlockPos lIllIIIlIlllII, Vec3 lIllIIIlIlIllI, Vec3 lIllIIIlIlIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    lIllIIIlIllllI.setBlockBoundsBasedOnState(lIllIIIlIllIII, lIllIIIlIlIlll);
    return lIllIIIlIllllI.collisionRayTrace(lIllIIIlIllIII, lIllIIIlIlIlll, lIllIIIlIlIllI, lIllIIIlIlIlIl);
  }
  
  private static boolean lIllIIIIIII(Object ???, Object arg1)
  {
    Object localObject;
    int lIlIllllllIlll;
    return ??? != localObject;
  }
  
  public void breakBlock(World lIllIIIIIIIIIl, BlockPos lIlIllllllllII, IBlockState lIlIlllllllIll)
  {
    ;
    ;
    ;
    ;
    lIllIIIIIIIIlI.breakBlock(lIllIIIIIIIIIl, lIlIllllllllII, lIlIlllllllIll);
    if (lIllIIIIIll(((EnumRailDirection)lIlIlllllllIll.getValue(lIllIIIIIIIIlI.getShapeProperty())).isAscending())) {
      lIllIIIIIIIIIl.notifyNeighborsOfStateChange(lIlIllllllllII.up(), lIllIIIIIIIIlI);
    }
    if (lIllIIIIIll(isPowered))
    {
      lIllIIIIIIIIIl.notifyNeighborsOfStateChange(lIlIllllllllII, lIllIIIIIIIIlI);
      lIllIIIIIIIIIl.notifyNeighborsOfStateChange(lIlIllllllllII.down(), lIllIIIIIIIIlI);
    }
  }
  
  public void onBlockAdded(World lIllIIIIlllIII, BlockPos lIllIIIIllIIll, IBlockState lIllIIIIllIllI)
  {
    ;
    ;
    ;
    ;
    if (lIllIIIIlII(isRemote))
    {
      lIllIIIIllIllI = lIllIIIIllIlIl.func_176564_a(lIllIIIIlllIII, lIllIIIIllIIll, lIllIIIIllIllI, llIlIllIl[1]);
      if (lIllIIIIIll(isPowered)) {
        lIllIIIIllIlIl.onNeighborBlockChange(lIllIIIIlllIII, lIllIIIIllIIll, lIllIIIIllIllI, lIllIIIIllIlIl);
      }
    }
  }
  
  protected IBlockState func_176564_a(World lIllIIIIIlIIIl, BlockPos lIllIIIIIlIIII, IBlockState lIllIIIIIIllll, boolean lIllIIIIIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIllIIIIIll(isRemote))
    {
      "".length();
      if (((0x25 ^ 0x7F) & (0x65 ^ 0x3F ^ 0xFFFFFFFF)) < " ".length()) {
        break label65;
      }
      return null;
    }
    label65:
    return new Rail(lIllIIIIIlIIIl, lIllIIIIIIlIll, lIllIIIIIIllll).func_180364_a(lIllIIIIIlIIIl.isBlockPowered(lIllIIIIIIlIll), lIllIIIIIIlIIl).getBlockState();
  }
  
  private static void lIlIlllllll()
  {
    llIlIllIl = new int[2];
    llIlIllIl[0] = ((0x5E ^ 0x17) & (0x2 ^ 0x4B ^ 0xFFFFFFFF));
    llIlIllIl[1] = " ".length();
  }
  
  public void onNeighborBlockChange(World lIllIIIIlIlIIl, BlockPos lIllIIIIlIlIII, IBlockState lIllIIIIlIIlll, Block lIllIIIIIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllIIIIlII(isRemote))
    {
      EnumRailDirection lIllIIIIlIIlIl = (EnumRailDirection)lIllIIIIlIIlll.getValue(lIllIIIIlIIIll.getShapeProperty());
      boolean lIllIIIIlIIlII = llIlIllIl[0];
      if (lIllIIIIlII(World.doesBlockHaveSolidTopSurface(lIllIIIIlIlIIl, lIllIIIIlIIIIl.down()))) {
        lIllIIIIlIIlII = llIlIllIl[1];
      }
      if ((lIllIIIIIIl(lIllIIIIlIIlIl, EnumRailDirection.ASCENDING_EAST)) && (lIllIIIIlII(World.doesBlockHaveSolidTopSurface(lIllIIIIlIlIIl, lIllIIIIlIIIIl.east()))))
      {
        lIllIIIIlIIlII = llIlIllIl[1];
        "".length();
        if (-"  ".length() < 0) {}
      }
      else if ((lIllIIIIIIl(lIllIIIIlIIlIl, EnumRailDirection.ASCENDING_WEST)) && (lIllIIIIlII(World.doesBlockHaveSolidTopSurface(lIllIIIIlIlIIl, lIllIIIIlIIIIl.west()))))
      {
        lIllIIIIlIIlII = llIlIllIl[1];
        "".length();
        if (((0x2D ^ 0x3A) & (0x7F ^ 0x68 ^ 0xFFFFFFFF)) == 0) {}
      }
      else if ((lIllIIIIIIl(lIllIIIIlIIlIl, EnumRailDirection.ASCENDING_NORTH)) && (lIllIIIIlII(World.doesBlockHaveSolidTopSurface(lIllIIIIlIlIIl, lIllIIIIlIIIIl.north()))))
      {
        lIllIIIIlIIlII = llIlIllIl[1];
        "".length();
        if (-(0x3E ^ 0x3A) < 0) {}
      }
      else if ((lIllIIIIIIl(lIllIIIIlIIlIl, EnumRailDirection.ASCENDING_SOUTH)) && (lIllIIIIlII(World.doesBlockHaveSolidTopSurface(lIllIIIIlIlIIl, lIllIIIIlIIIIl.south()))))
      {
        lIllIIIIlIIlII = llIlIllIl[1];
      }
      if (lIllIIIIIll(lIllIIIIlIIlII))
      {
        lIllIIIIlIIIll.dropBlockAsItem(lIllIIIIlIlIIl, lIllIIIIlIIIIl, lIllIIIIlIIlll, llIlIllIl[0]);
        "".length();
        "".length();
        if ("   ".length() >= 0) {}
      }
      else
      {
        lIllIIIIlIIIll.onNeighborChangedInternal(lIllIIIIlIlIIl, lIllIIIIlIIIIl, lIllIIIIlIIlll, lIllIIIIIlllll);
      }
    }
  }
  
  private static boolean lIllIIIIIIl(Object ???, Object arg1)
  {
    Object localObject;
    Exception lIlIllllllIIll;
    return ??? == localObject;
  }
  
  protected void onNeighborChangedInternal(World lIllIIIIIllIll, BlockPos lIllIIIIIllIlI, IBlockState lIllIIIIIllIIl, Block lIllIIIIIllIII) {}
  
  public class Rail
  {
    private boolean func_150653_a(Rail lIllllllllIl)
    {
      ;
      ;
      return llIIIIIIIIII.func_180363_c(pos);
    }
    
    private static boolean lllllIlIlll(int ???)
    {
      long lIllIllIllII;
      return ??? == 0;
    }
    
    public Rail func_180364_a(boolean lIlllIIlIlIl, boolean lIlllIlIIIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      BlockPos lIlllIlIIIIl = pos.north();
      BlockPos lIlllIlIIIII = pos.south();
      BlockPos lIlllIIlllll = pos.west();
      BlockPos lIlllIIllllI = pos.east();
      boolean lIlllIIlllIl = lIlllIIlIllI.func_180361_d(lIlllIlIIIIl);
      boolean lIlllIIlllII = lIlllIIlIllI.func_180361_d(lIlllIlIIIII);
      boolean lIlllIIllIll = lIlllIIlIllI.func_180361_d(lIlllIIlllll);
      boolean lIlllIIllIlI = lIlllIIlIllI.func_180361_d(lIlllIIllllI);
      BlockRailBase.EnumRailDirection lIlllIIllIIl = null;
      if (((!lllllIlIlll(lIlllIIlllIl)) || (lllllIlIlIl(lIlllIIlllII))) && (lllllIlIlll(lIlllIIllIll)) && (lllllIlIlll(lIlllIIllIlI))) {
        lIlllIIllIIl = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
      }
      if (((!lllllIlIlll(lIlllIIllIll)) || (lllllIlIlIl(lIlllIIllIlI))) && (lllllIlIlll(lIlllIIlllIl)) && (lllllIlIlll(lIlllIIlllII))) {
        lIlllIIllIIl = BlockRailBase.EnumRailDirection.EAST_WEST;
      }
      if (lllllIlIlll(isPowered))
      {
        if ((lllllIlIlIl(lIlllIIlllII)) && (lllllIlIlIl(lIlllIIllIlI)) && (lllllIlIlll(lIlllIIlllIl)) && (lllllIlIlll(lIlllIIllIll))) {
          lIlllIIllIIl = BlockRailBase.EnumRailDirection.SOUTH_EAST;
        }
        if ((lllllIlIlIl(lIlllIIlllII)) && (lllllIlIlIl(lIlllIIllIll)) && (lllllIlIlll(lIlllIIlllIl)) && (lllllIlIlll(lIlllIIllIlI))) {
          lIlllIIllIIl = BlockRailBase.EnumRailDirection.SOUTH_WEST;
        }
        if ((lllllIlIlIl(lIlllIIlllIl)) && (lllllIlIlIl(lIlllIIllIll)) && (lllllIlIlll(lIlllIIlllII)) && (lllllIlIlll(lIlllIIllIlI))) {
          lIlllIIllIIl = BlockRailBase.EnumRailDirection.NORTH_WEST;
        }
        if ((lllllIlIlIl(lIlllIIlllIl)) && (lllllIlIlIl(lIlllIIllIlI)) && (lllllIlIlll(lIlllIIlllII)) && (lllllIlIlll(lIlllIIllIll))) {
          lIlllIIllIIl = BlockRailBase.EnumRailDirection.NORTH_EAST;
        }
      }
      if (lllllIllIlI(lIlllIIllIIl))
      {
        if ((!lllllIlIlll(lIlllIIlllIl)) || (lllllIlIlIl(lIlllIIlllII))) {
          lIlllIIllIIl = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
        }
        if ((!lllllIlIlll(lIlllIIllIll)) || (lllllIlIlIl(lIlllIIllIlI))) {
          lIlllIIllIIl = BlockRailBase.EnumRailDirection.EAST_WEST;
        }
        if (lllllIlIlll(isPowered)) {
          if (lllllIlIlIl(lIlllIlIIIll))
          {
            if ((lllllIlIlIl(lIlllIIlllII)) && (lllllIlIlIl(lIlllIIllIlI))) {
              lIlllIIllIIl = BlockRailBase.EnumRailDirection.SOUTH_EAST;
            }
            if ((lllllIlIlIl(lIlllIIllIll)) && (lllllIlIlIl(lIlllIIlllII))) {
              lIlllIIllIIl = BlockRailBase.EnumRailDirection.SOUTH_WEST;
            }
            if ((lllllIlIlIl(lIlllIIllIlI)) && (lllllIlIlIl(lIlllIIlllIl))) {
              lIlllIIllIIl = BlockRailBase.EnumRailDirection.NORTH_EAST;
            }
            if ((lllllIlIlIl(lIlllIIlllIl)) && (lllllIlIlIl(lIlllIIllIll)))
            {
              lIlllIIllIIl = BlockRailBase.EnumRailDirection.NORTH_WEST;
              "".length();
              if (((0x16 ^ 0x39) & (0xAB ^ 0x84 ^ 0xFFFFFFFF)) != ("  ".length() & ("  ".length() ^ 0xFFFFFFFF))) {
                return null;
              }
            }
          }
          else
          {
            if ((lllllIlIlIl(lIlllIIlllIl)) && (lllllIlIlIl(lIlllIIllIll))) {
              lIlllIIllIIl = BlockRailBase.EnumRailDirection.NORTH_WEST;
            }
            if ((lllllIlIlIl(lIlllIIllIlI)) && (lllllIlIlIl(lIlllIIlllIl))) {
              lIlllIIllIIl = BlockRailBase.EnumRailDirection.NORTH_EAST;
            }
            if ((lllllIlIlIl(lIlllIIllIll)) && (lllllIlIlIl(lIlllIIlllII))) {
              lIlllIIllIIl = BlockRailBase.EnumRailDirection.SOUTH_WEST;
            }
            if ((lllllIlIlIl(lIlllIIlllII)) && (lllllIlIlIl(lIlllIIllIlI))) {
              lIlllIIllIIl = BlockRailBase.EnumRailDirection.SOUTH_EAST;
            }
          }
        }
      }
      if (lllllIllIIl(lIlllIIllIIl, BlockRailBase.EnumRailDirection.NORTH_SOUTH))
      {
        if (lllllIlIlIl(BlockRailBase.isRailBlock(world, lIlllIlIIIIl.up()))) {
          lIlllIIllIIl = BlockRailBase.EnumRailDirection.ASCENDING_NORTH;
        }
        if (lllllIlIlIl(BlockRailBase.isRailBlock(world, lIlllIlIIIII.up()))) {
          lIlllIIllIIl = BlockRailBase.EnumRailDirection.ASCENDING_SOUTH;
        }
      }
      if (lllllIllIIl(lIlllIIllIIl, BlockRailBase.EnumRailDirection.EAST_WEST))
      {
        if (lllllIlIlIl(BlockRailBase.isRailBlock(world, lIlllIIllllI.up()))) {
          lIlllIIllIIl = BlockRailBase.EnumRailDirection.ASCENDING_EAST;
        }
        if (lllllIlIlIl(BlockRailBase.isRailBlock(world, lIlllIIlllll.up()))) {
          lIlllIIllIIl = BlockRailBase.EnumRailDirection.ASCENDING_WEST;
        }
      }
      if (lllllIllIlI(lIlllIIllIIl)) {
        lIlllIIllIIl = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
      }
      lIlllIIlIllI.func_180360_a(lIlllIIllIIl);
      state = state.withProperty(block.getShapeProperty(), lIlllIIllIIl);
      if ((!lllllIlIlll(lIlllIlIIIlI)) || (lllllIllIll(world.getBlockState(pos), state)))
      {
        "".length();
        int lIlllIIllIII = lIIllIIllI[0];
        "".length();
        if (" ".length() >= (117 + '±' - 124 + 28 ^ 1 + 9 - 65394 + 42)) {
          return null;
        }
        while (!lllllIlIllI(lIlllIIllIII, field_150657_g.size()))
        {
          Rail lIlllIIlIlll = lIlllIIlIllI.findRailAt((BlockPos)field_150657_g.get(lIlllIIllIII));
          if (lllllIlIlII(lIlllIIlIlll))
          {
            lIlllIIlIlll.func_150651_b();
            if (lllllIlIlIl(lIlllIIlIlll.func_150649_b(lIlllIIlIllI))) {
              lIlllIIlIlll.func_150645_c(lIlllIIlIllI);
            }
          }
          lIlllIIllIII++;
        }
      }
      return lIlllIIlIllI;
    }
    
    private boolean func_150649_b(Rail lIllllIlllll)
    {
      ;
      ;
      if ((lllllIlIlll(lIllllIllllI.func_150653_a(lIllllIlllll))) && (lllllIllIII(field_150657_g.size(), lIIllIIllI[2]))) {
        return lIIllIIllI[0];
      }
      return lIIllIIllI[1];
    }
    
    private static boolean lllllIlIlIl(int ???)
    {
      boolean lIllIllIlllI;
      return ??? != 0;
    }
    
    private void func_150645_c(Rail lIllllIlIIII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      "".length();
      BlockPos lIllllIIllll = pos.north();
      BlockPos lIllllIIlllI = pos.south();
      BlockPos lIllllIIllIl = pos.west();
      BlockPos lIllllIIllII = pos.east();
      boolean lIllllIIlIll = lIllllIlIIIl.func_180363_c(lIllllIIllll);
      boolean lIllllIIlIlI = lIllllIlIIIl.func_180363_c(lIllllIIlllI);
      boolean lIllllIIlIIl = lIllllIlIIIl.func_180363_c(lIllllIIllIl);
      boolean lIllllIIlIII = lIllllIlIIIl.func_180363_c(lIllllIIllII);
      BlockRailBase.EnumRailDirection lIllllIIIlll = null;
      if ((!lllllIlIlll(lIllllIIlIll)) || (lllllIlIlIl(lIllllIIlIlI))) {
        lIllllIIIlll = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
      }
      if ((!lllllIlIlll(lIllllIIlIIl)) || (lllllIlIlIl(lIllllIIlIII))) {
        lIllllIIIlll = BlockRailBase.EnumRailDirection.EAST_WEST;
      }
      if (lllllIlIlll(isPowered))
      {
        if ((lllllIlIlIl(lIllllIIlIlI)) && (lllllIlIlIl(lIllllIIlIII)) && (lllllIlIlll(lIllllIIlIll)) && (lllllIlIlll(lIllllIIlIIl))) {
          lIllllIIIlll = BlockRailBase.EnumRailDirection.SOUTH_EAST;
        }
        if ((lllllIlIlIl(lIllllIIlIlI)) && (lllllIlIlIl(lIllllIIlIIl)) && (lllllIlIlll(lIllllIIlIll)) && (lllllIlIlll(lIllllIIlIII))) {
          lIllllIIIlll = BlockRailBase.EnumRailDirection.SOUTH_WEST;
        }
        if ((lllllIlIlIl(lIllllIIlIll)) && (lllllIlIlIl(lIllllIIlIIl)) && (lllllIlIlll(lIllllIIlIlI)) && (lllllIlIlll(lIllllIIlIII))) {
          lIllllIIIlll = BlockRailBase.EnumRailDirection.NORTH_WEST;
        }
        if ((lllllIlIlIl(lIllllIIlIll)) && (lllllIlIlIl(lIllllIIlIII)) && (lllllIlIlll(lIllllIIlIlI)) && (lllllIlIlll(lIllllIIlIIl))) {
          lIllllIIIlll = BlockRailBase.EnumRailDirection.NORTH_EAST;
        }
      }
      if (lllllIllIIl(lIllllIIIlll, BlockRailBase.EnumRailDirection.NORTH_SOUTH))
      {
        if (lllllIlIlIl(BlockRailBase.isRailBlock(world, lIllllIIllll.up()))) {
          lIllllIIIlll = BlockRailBase.EnumRailDirection.ASCENDING_NORTH;
        }
        if (lllllIlIlIl(BlockRailBase.isRailBlock(world, lIllllIIlllI.up()))) {
          lIllllIIIlll = BlockRailBase.EnumRailDirection.ASCENDING_SOUTH;
        }
      }
      if (lllllIllIIl(lIllllIIIlll, BlockRailBase.EnumRailDirection.EAST_WEST))
      {
        if (lllllIlIlIl(BlockRailBase.isRailBlock(world, lIllllIIllII.up()))) {
          lIllllIIIlll = BlockRailBase.EnumRailDirection.ASCENDING_EAST;
        }
        if (lllllIlIlIl(BlockRailBase.isRailBlock(world, lIllllIIllIl.up()))) {
          lIllllIIIlll = BlockRailBase.EnumRailDirection.ASCENDING_WEST;
        }
      }
      if (lllllIllIlI(lIllllIIIlll)) {
        lIllllIIIlll = BlockRailBase.EnumRailDirection.NORTH_SOUTH;
      }
      state = state.withProperty(block.getShapeProperty(), lIllllIIIlll);
      "".length();
    }
    
    private static boolean lllllIlIllI(int ???, int arg1)
    {
      int i;
      float lIllIlllllII;
      return ??? >= i;
    }
    
    static {}
    
    private static boolean lllllIllIll(Object ???, Object arg1)
    {
      Object localObject;
      long lIllIllllIII;
      return ??? != localObject;
    }
    
    private static boolean lllllIlIlII(Object ???)
    {
      byte lIllIlllIllI;
      return ??? != null;
    }
    
    private boolean hasRailAt(BlockPos llIIIIIlIIIl)
    {
      ;
      ;
      if ((lllllIlIlll(BlockRailBase.isRailBlock(world, llIIIIIlIIIl))) && (lllllIlIlll(BlockRailBase.isRailBlock(world, llIIIIIlIIIl.up()))) && (lllllIlIlll(BlockRailBase.isRailBlock(world, llIIIIIlIIIl.down())))) {
        return lIIllIIllI[0];
      }
      return lIIllIIllI[1];
    }
    
    private static void lllllIlIIll()
    {
      lIIllIIllI = new int[11];
      lIIllIIllI[0] = ((0x66 ^ 0x7E ^ 0x2B ^ 0x39) & (0x27 ^ 0x63 ^ 0x6B ^ 0x25 ^ -" ".length()));
      lIIllIIllI[1] = " ".length();
      lIIllIIllI[2] = "  ".length();
      lIIllIIllI[3] = "   ".length();
      lIIllIIllI[4] = (0x10 ^ 0x3D ^ 0x9B ^ 0xB3);
      lIIllIIllI[5] = (0x35 ^ 0x33);
      lIIllIIllI[6] = (0x61 ^ 0x37 ^ 0x2D ^ 0x7F);
      lIIllIIllI[7] = (0x40 ^ 0x4A);
      lIIllIIllI[8] = (0x69 ^ 0x60);
      lIIllIIllI[9] = (0x38 ^ 0x3F);
      lIIllIIllI[10] = (0x4D ^ 0x52 ^ 0xB9 ^ 0xAE);
    }
    
    private static boolean lllllIllIII(int ???, int arg1)
    {
      int i;
      float lIlllIIIIIII;
      return ??? == i;
    }
    
    private Rail findRailAt(BlockPos llIIIIIIlIIl)
    {
      ;
      ;
      ;
      ;
      IBlockState llIIIIIIlIII = world.getBlockState(llIIIIIIlIIl);
      if (lllllIlIlIl(BlockRailBase.isRailBlock(llIIIIIIlIII)))
      {
        BlockRailBase tmp27_24 = BlockRailBase.this;
        "".length();
        tmp27_24.<init>(tmp27_24.getClass(), world, llIIIIIIlIIl, llIIIIIIlIII);
        return new net/minecraft/block/BlockRailBase$Rail;
      }
      BlockPos llIIIIIIIlll = llIIIIIIlIIl.up();
      llIIIIIIlIII = world.getBlockState(llIIIIIIIlll);
      if (lllllIlIlIl(BlockRailBase.isRailBlock(llIIIIIIlIII)))
      {
        BlockRailBase tmp79_76 = BlockRailBase.this;
        "".length();
        tmp79_76.<init>(tmp79_76.getClass(), world, llIIIIIIIlll, llIIIIIIlIII);
        return new net/minecraft/block/BlockRailBase$Rail;
      }
      llIIIIIIIlll = llIIIIIIlIIl.down();
      llIIIIIIlIII = world.getBlockState(llIIIIIIIlll);
      if (lllllIlIlIl(BlockRailBase.isRailBlock(llIIIIIIlIII)))
      {
        BlockRailBase tmp131_128 = BlockRailBase.this;
        "".length();
        tmp131_128.<init>(tmp131_128.getClass(), world, llIIIIIIIlll, llIIIIIIlIII);
        "".length();
        if (null == null) {
          break label163;
        }
        return null;
      }
      label163:
      return null;
    }
    
    protected int countAdjacentRails()
    {
      ;
      ;
      ;
      ;
      int lIlllllIlIlI = lIIllIIllI[0];
      float lIlllllIIlII = EnumFacing.Plane.HORIZONTAL.iterator();
      "".length();
      if ("  ".length() > "   ".length()) {
        return (0x1B ^ 0x36 ^ 0xE ^ 0x15) & (0x3 ^ 0x51 ^ 0xC3 ^ 0xA7 ^ -" ".length());
      }
      while (!lllllIlIlll(lIlllllIIlII.hasNext()))
      {
        Object lIlllllIlIIl = lIlllllIIlII.next();
        EnumFacing lIlllllIlIII = (EnumFacing)lIlllllIlIIl;
        if (lllllIlIlIl(lIlllllIlIll.hasRailAt(pos.offset(lIlllllIlIII)))) {
          lIlllllIlIlI++;
        }
      }
      return lIlllllIlIlI;
    }
    
    private boolean func_180363_c(BlockPos lIllllllIIll)
    {
      ;
      ;
      ;
      ;
      int lIllllllIllI = lIIllIIllI[0];
      "".length();
      if (null != null) {
        return (0x3C ^ 0x38) & (0xF ^ 0xB ^ 0xFFFFFFFF);
      }
      while (!lllllIlIllI(lIllllllIllI, field_150657_g.size()))
      {
        BlockPos lIllllllIlIl = (BlockPos)field_150657_g.get(lIllllllIllI);
        if ((lllllIllIII(lIllllllIlIl.getX(), lIllllllIIll.getX())) && (lllllIllIII(lIllllllIlIl.getZ(), lIllllllIIll.getZ()))) {
          return lIIllIIllI[1];
        }
        lIllllllIllI++;
      }
      return lIIllIIllI[0];
    }
    
    private static boolean lllllIllIlI(Object ???)
    {
      float lIllIlllIIII;
      return ??? == null;
    }
    
    private boolean func_180361_d(BlockPos lIlllIllIlII)
    {
      ;
      ;
      ;
      Rail lIlllIllIllI = lIlllIlllIII.findRailAt(lIlllIllIlII);
      if (lllllIllIlI(lIlllIllIllI)) {
        return lIIllIIllI[0];
      }
      lIlllIllIllI.func_150651_b();
      return lIlllIllIllI.func_150649_b(lIlllIlllIII);
    }
    
    public IBlockState getBlockState()
    {
      ;
      return state;
    }
    
    public Rail(World llIIIIlIIlll, BlockPos llIIIIlIllII, IBlockState llIIIIlIIlIl)
    {
      world = llIIIIlIIlll;
      pos = llIIIIlIllII;
      state = llIIIIlIIlIl;
      block = ((BlockRailBase)llIIIIlIIlIl.getBlock());
      BlockRailBase.EnumRailDirection llIIIIlIlIlI = (BlockRailBase.EnumRailDirection)llIIIIlIIlIl.getValue(getShapeProperty());
      isPowered = block.isPowered;
      llIIIIlIlllI.func_180360_a(llIIIIlIlIlI);
    }
    
    private static boolean lllllIllIIl(Object ???, Object arg1)
    {
      Object localObject;
      long lIllIlllIIlI;
      return ??? == localObject;
    }
    
    private void func_180360_a(BlockRailBase.EnumRailDirection llIIIIlIIIII)
    {
      ;
      ;
      field_150657_g.clear();
      switch ($SWITCH_TABLE$net$minecraft$block$BlockRailBase$EnumRailDirection()[llIIIIlIIIII.ordinal()])
      {
      case 1: 
        "".length();
        "".length();
        "".length();
        if (((0xD9 ^ 0x9D) & (0xD5 ^ 0x91 ^ 0xFFFFFFFF)) != 0) {}
        break;
      case 2: 
        "".length();
        "".length();
        "".length();
        if ("  ".length() == " ".length()) {}
        break;
      case 3: 
        "".length();
        "".length();
        "".length();
        if ("  ".length() < 0) {}
        break;
      case 4: 
        "".length();
        "".length();
        "".length();
        if ("  ".length() == 0) {}
        break;
      case 5: 
        "".length();
        "".length();
        "".length();
        if (-"   ".length() > 0) {}
        break;
      case 6: 
        "".length();
        "".length();
        "".length();
        if ((0x99 ^ 0x9D) < -" ".length()) {}
        break;
      case 7: 
        "".length();
        "".length();
        "".length();
        if (" ".length() <= 0) {}
        break;
      case 8: 
        "".length();
        "".length();
        "".length();
        if (((0xD ^ 0x30) & (0x6D ^ 0x50 ^ 0xFFFFFFFF)) != 0) {}
        break;
      case 9: 
        "".length();
        "".length();
        "".length();
        if (((0xAC ^ 0xBC) & (0x77 ^ 0x67 ^ 0xFFFFFFFF)) >= "   ".length()) {}
        break;
      case 10: 
        "".length();
        "".length();
      }
    }
    
    private void func_150651_b()
    {
      ;
      ;
      ;
      int llIIIIIllIIl = lIIllIIllI[0];
      "".length();
      if ("   ".length() <= 0) {
        return;
      }
      while (!lllllIlIllI(llIIIIIllIIl, field_150657_g.size()))
      {
        Rail llIIIIIllIII = llIIIIIllIlI.findRailAt((BlockPos)field_150657_g.get(llIIIIIllIIl));
        if ((lllllIlIlII(llIIIIIllIII)) && (lllllIlIlIl(llIIIIIllIII.func_150653_a(llIIIIIllIlI))))
        {
          "".length();
          "".length();
          if (-(82 + 121 - 187 + 156 ^ 111 + 46 - 13 + 24) < 0) {}
        }
        else
        {
          "".length();
        }
        llIIIIIllIIl++;
      }
    }
  }
  
  public static enum EnumRailDirection
    implements IStringSerializable
  {
    public String getName()
    {
      ;
      return name;
    }
    
    private EnumRailDirection(int lllllllllllllllIllIlIIlIllIIIlll, String lllllllllllllllIllIlIIlIllIIllII)
    {
      meta = lllllllllllllllIllIlIIlIllIIllIl;
      name = lllllllllllllllIllIlIIlIllIIllII;
    }
    
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    private static boolean lllIIIIIlIlll(int ???, int arg1)
    {
      int i;
      float lllllllllllllllIllIlIIlIIlIIlIII;
      return ??? >= i;
    }
    
    private static boolean lllIIIIIllIlI(int ???, int arg1)
    {
      int i;
      short lllllllllllllllIllIlIIlIIlIIIlII;
      return ??? < i;
    }
    
    private static String lllIIIIIIllII(String lllllllllllllllIllIlIIlIIlllllII, String lllllllllllllllIllIlIIlIIllllllI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIllIlIIlIlIIIIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlIIllllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIllIlIIlIlIIIIIIl = Cipher.getInstance("Blowfish");
        lllllllllllllllIllIlIIlIlIIIIIIl.init(lIIlIIIlIIIl[2], lllllllllllllllIllIlIIlIlIIIIIlI);
        return new String(lllllllllllllllIllIlIIlIlIIIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIIlllllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIllIlIIlIlIIIIIII)
      {
        lllllllllllllllIllIlIIlIlIIIIIII.printStackTrace();
      }
      return null;
    }
    
    private static void lllIIIIIIllIl()
    {
      lIIlIIIIlllI = new String[lIIlIIIlIIIl[20]];
      lIIlIIIIlllI[lIIlIIIlIIIl[0]] = lllIIIIIIlIlI("DSwfHgQcMAIfGAs=", "CcMJL");
      lIIlIIIIlllI[lIIlIIIlIIIl[1]] = lllIIIIIIlIlI("KxYVMyEaCggyPS0=", "EygGI");
      lIIlIIIIlllI[lIIlIIIlIIIl[2]] = lllIIIIIIlIll("Tljm/54xk45gS9tCT0ooPA==", "NKcxA");
      lIIlIIIIlllI[lIIlIIIlIIIl[3]] = lllIIIIIIlIlI("HysAPDoNLwA8", "zJsHe");
      lIIlIIIIlllI[lIIlIIIlIIIl[4]] = lllIIIIIIlIlI("BgI6FwkDGDcVGAIQKgY=", "GQyRG");
      lIIlIIIIlllI[lIIlIIIlIIIl[5]] = lllIIIIIIlIll("mMZyvqHlVxOz5UYZz2akTg==", "ASTVW");
      lIIlIIIIlllI[lIIlIIIlIIIl[6]] = lllIIIIIIlIll("i8FWoTzLrE74k2nmb4yD7g==", "RhXll");
      lIIlIIIIlllI[lIIlIIIlIIIl[7]] = lllIIIIIIllII("gBZ646YezhKaWL4Ij5K1tw==", "cWgFk");
      lIIlIIIIlllI[lIIlIIIlIIIl[8]] = lllIIIIIIllII("wANwSApRv81TTJQw6sl5bQ==", "UvDfv");
      lIIlIIIIlllI[lIIlIIIlIIIl[9]] = lllIIIIIIlIll("iSYb/bY43KqXI+7tjy/7Zg==", "PGKOw");
      lIIlIIIIlllI[lIIlIIIlIIIl[10]] = lllIIIIIIlIll("8mpxBFx4phoexhiPWO+6IA==", "stdOg");
      lIIlIIIIlllI[lIIlIIIlIIIl[11]] = lllIIIIIIlIlI("LTwKBx0oJgcFLD8gHBYb", "LOibs");
      lIIlIIIIlllI[lIIlIIIlIIIl[12]] = lllIIIIIIlIll("LAdxUd4fz/0okqcWHuc+Ow==", "oiAiN");
      lIIlIIIIlllI[lIIlIIIlIIIl[13]] = lllIIIIIIllII("QOZVOOmguyJqyNyKjBXI1g==", "geDPx");
      lIIlIIIIlllI[lIIlIIIlIIIl[14]] = lllIIIIIIllII("w3JuJEcVU034sztyGW9sgA==", "OtvpT");
      lIIlIIIIlllI[lIIlIIIlIIIl[15]] = lllIIIIIIlIll("4z/fWQmaGRJpLtY/VML0uQ==", "SmPPr");
      lIIlIIIIlllI[lIIlIIIlIIIl[16]] = lllIIIIIIlIlI("DAg4DDwdEC8LIA==", "BGjXt");
      lIIlIIIIlllI[lIIlIIIlIIIl[17]] = lllIIIIIIllII("DFUnGY0TxzZLbJPgxEcWCg==", "IOstU");
      lIIlIIIIlllI[lIIlIIIlIIIl[18]] = lllIIIIIIlIll("7dpFKmLhFS0qfedehKFDDw==", "XwsHF");
      lIIlIIIIlllI[lIIlIIIlIIIl[19]] = lllIIIIIIllII("b9AIRc6R/vht8A2eGMn9Jg==", "YTfkb");
    }
    
    private static boolean lllIIIIIllIII(Object ???, Object arg1)
    {
      Object localObject;
      Exception lllllllllllllllIllIlIIlIIlIIIIII;
      return ??? != localObject;
    }
    
    static
    {
      lllIIIIIlIllI();
      lllIIIIIIllIl();
      Exception lllllllllllllllIllIlIIlIllIlIlII;
      char lllllllllllllllIllIlIIlIllIlIlll;
      NORTH_SOUTH = new EnumRailDirection(lIIlIIIIlllI[lIIlIIIlIIIl[0]], lIIlIIIlIIIl[0], lIIlIIIlIIIl[0], lIIlIIIIlllI[lIIlIIIlIIIl[1]]);
      EAST_WEST = new EnumRailDirection(lIIlIIIIlllI[lIIlIIIlIIIl[2]], lIIlIIIlIIIl[1], lIIlIIIlIIIl[1], lIIlIIIIlllI[lIIlIIIlIIIl[3]]);
      ASCENDING_EAST = new EnumRailDirection(lIIlIIIIlllI[lIIlIIIlIIIl[4]], lIIlIIIlIIIl[2], lIIlIIIlIIIl[2], lIIlIIIIlllI[lIIlIIIlIIIl[5]]);
      ASCENDING_WEST = new EnumRailDirection(lIIlIIIIlllI[lIIlIIIlIIIl[6]], lIIlIIIlIIIl[3], lIIlIIIlIIIl[3], lIIlIIIIlllI[lIIlIIIlIIIl[7]]);
      ASCENDING_NORTH = new EnumRailDirection(lIIlIIIIlllI[lIIlIIIlIIIl[8]], lIIlIIIlIIIl[4], lIIlIIIlIIIl[4], lIIlIIIIlllI[lIIlIIIlIIIl[9]]);
      ASCENDING_SOUTH = new EnumRailDirection(lIIlIIIIlllI[lIIlIIIlIIIl[10]], lIIlIIIlIIIl[5], lIIlIIIlIIIl[5], lIIlIIIIlllI[lIIlIIIlIIIl[11]]);
      SOUTH_EAST = new EnumRailDirection(lIIlIIIIlllI[lIIlIIIlIIIl[12]], lIIlIIIlIIIl[6], lIIlIIIlIIIl[6], lIIlIIIIlllI[lIIlIIIlIIIl[13]]);
      SOUTH_WEST = new EnumRailDirection(lIIlIIIIlllI[lIIlIIIlIIIl[14]], lIIlIIIlIIIl[7], lIIlIIIlIIIl[7], lIIlIIIIlllI[lIIlIIIlIIIl[15]]);
      NORTH_WEST = new EnumRailDirection(lIIlIIIIlllI[lIIlIIIlIIIl[16]], lIIlIIIlIIIl[8], lIIlIIIlIIIl[8], lIIlIIIIlllI[lIIlIIIlIIIl[17]]);
      NORTH_EAST = new EnumRailDirection(lIIlIIIIlllI[lIIlIIIlIIIl[18]], lIIlIIIlIIIl[9], lIIlIIIlIIIl[9], lIIlIIIIlllI[lIIlIIIlIIIl[19]]);
      ENUM$VALUES = new EnumRailDirection[] { NORTH_SOUTH, EAST_WEST, ASCENDING_EAST, ASCENDING_WEST, ASCENDING_NORTH, ASCENDING_SOUTH, SOUTH_EAST, SOUTH_WEST, NORTH_WEST, NORTH_EAST };
      META_LOOKUP = new EnumRailDirection[values().length];
      byte lllllllllllllllIllIlIIlIllIlIlIl = (lllllllllllllllIllIlIIlIllIlIlII = values()).length;
      String lllllllllllllllIllIlIIlIllIlIllI = lIIlIIIlIIIl[0];
      "".length();
      if (-"  ".length() > 0) {
        return;
      }
      while (!lllIIIIIlIlll(lllllllllllllllIllIlIIlIllIlIllI, lllllllllllllllIllIlIIlIllIlIlIl))
      {
        EnumRailDirection lllllllllllllllIllIlIIlIllIllIII = lllllllllllllllIllIlIIlIllIlIlII[lllllllllllllllIllIlIIlIllIlIllI];
        META_LOOKUP[lllllllllllllllIllIlIIlIllIllIII.getMetadata()] = lllllllllllllllIllIlIIlIllIllIII;
        lllllllllllllllIllIlIIlIllIlIllI++;
      }
    }
    
    public boolean isAscending()
    {
      ;
      if ((lllIIIIIllIII(lllllllllllllllIllIlIIlIlIlIllll, ASCENDING_NORTH)) && (lllIIIIIllIII(lllllllllllllllIllIlIIlIlIlIlllI, ASCENDING_EAST)) && (lllIIIIIllIII(lllllllllllllllIllIlIIlIlIlIlllI, ASCENDING_SOUTH)) && (lllIIIIIllIII(lllllllllllllllIllIlIIlIlIlIlllI, ASCENDING_WEST))) {
        return lIIlIIIlIIIl[0];
      }
      return lIIlIIIlIIIl[1];
    }
    
    private static String lllIIIIIIlIlI(String lllllllllllllllIllIlIIlIIllIIllI, String lllllllllllllllIllIlIIlIIllIIIII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIllIlIIlIIllIIllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIIllIIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllIlIIlIIllIIlII = new StringBuilder();
      char[] lllllllllllllllIllIlIIlIIllIIIll = lllllllllllllllIllIlIIlIIllIIIII.toCharArray();
      int lllllllllllllllIllIlIIlIIllIIIlI = lIIlIIIlIIIl[0];
      Exception lllllllllllllllIllIlIIlIIlIlllII = lllllllllllllllIllIlIIlIIllIIllI.toCharArray();
      float lllllllllllllllIllIlIIlIIlIllIll = lllllllllllllllIllIlIIlIIlIlllII.length;
      short lllllllllllllllIllIlIIlIIlIllIlI = lIIlIIIlIIIl[0];
      while (lllIIIIIllIlI(lllllllllllllllIllIlIIlIIlIllIlI, lllllllllllllllIllIlIIlIIlIllIll))
      {
        char lllllllllllllllIllIlIIlIIllIIlll = lllllllllllllllIllIlIIlIIlIlllII[lllllllllllllllIllIlIIlIIlIllIlI];
        "".length();
        "".length();
        if (("  ".length() & ("  ".length() ^ 0xFFFFFFFF)) >= "  ".length()) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIllIlIIlIIllIIlII);
    }
    
    private static boolean lllIIIIIllIIl(int ???)
    {
      float lllllllllllllllIllIlIIlIIIlllllI;
      return ??? >= 0;
    }
    
    public static EnumRailDirection byMetadata(int lllllllllllllllIllIlIIlIlIlIlIII)
    {
      ;
      if ((!lllIIIIIllIIl(lllllllllllllllIllIlIIlIlIlIlIII)) || (lllIIIIIlIlll(lllllllllllllllIllIlIIlIlIlIlIIl, META_LOOKUP.length))) {
        lllllllllllllllIllIlIIlIlIlIlIIl = lIIlIIIlIIIl[0];
      }
      return META_LOOKUP[lllllllllllllllIllIlIIlIlIlIlIIl];
    }
    
    private static String lllIIIIIIlIll(String lllllllllllllllIllIlIIlIIlIIllll, String lllllllllllllllIllIlIIlIIlIlIIII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIllIlIIlIIlIlIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIlIIlIlIIII.getBytes(StandardCharsets.UTF_8)), lIIlIIIlIIIl[8]), "DES");
        Cipher lllllllllllllllIllIlIIlIIlIlIIll = Cipher.getInstance("DES");
        lllllllllllllllIllIlIIlIIlIlIIll.init(lIIlIIIlIIIl[2], lllllllllllllllIllIlIIlIIlIlIlII);
        return new String(lllllllllllllllIllIlIIlIIlIlIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIlIIlIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIllIlIIlIIlIlIIlI)
      {
        lllllllllllllllIllIlIIlIIlIlIIlI.printStackTrace();
      }
      return null;
    }
    
    private static void lllIIIIIlIllI()
    {
      lIIlIIIlIIIl = new int[21];
      lIIlIIIlIIIl[0] = ((106 + 108 - 180 + 152 ^ '' + '' - 234 + 140) & (0xCC ^ 0x86 ^ 0x15 ^ 0x56 ^ -" ".length()));
      lIIlIIIlIIIl[1] = " ".length();
      lIIlIIIlIIIl[2] = "  ".length();
      lIIlIIIlIIIl[3] = "   ".length();
      lIIlIIIlIIIl[4] = (0x2 ^ 0x6);
      lIIlIIIlIIIl[5] = (0xA1 ^ 0xA4);
      lIIlIIIlIIIl[6] = (0xB ^ 0x4B ^ 0x63 ^ 0x25);
      lIIlIIIlIIIl[7] = (0x61 ^ 0x66);
      lIIlIIIlIIIl[8] = (0x1E ^ 0x16);
      lIIlIIIlIIIl[9] = (0x13 ^ 0x45 ^ 0x7C ^ 0x23);
      lIIlIIIlIIIl[10] = (0x95 ^ 0x93 ^ 0x74 ^ 0x78);
      lIIlIIIlIIIl[11] = (0x51 ^ 0x5A);
      lIIlIIIlIIIl[12] = (0xA1 ^ 0x81 ^ 0x8D ^ 0xA1);
      lIIlIIIlIIIl[13] = (0xBA ^ 0xB7);
      lIIlIIIlIIIl[14] = (0x1D ^ 0x13);
      lIIlIIIlIIIl[15] = (0xC0 ^ 0x84 ^ 0x3C ^ 0x77);
      lIIlIIIlIIIl[16] = (0x99 ^ 0x89);
      lIIlIIIlIIIl[17] = (0x5B ^ 0x4A);
      lIIlIIIlIIIl[18] = (23 + 26 - -45 + 88 ^ 10 + 15 - -29 + 110);
      lIIlIIIlIIIl[19] = (0x2B ^ 0x24 ^ 0x71 ^ 0x6D);
      lIIlIIIlIIIl[20] = (0x7 ^ 0x13);
    }
  }
}

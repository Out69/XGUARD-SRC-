package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;

public class BlockClay
  extends Block
{
  static {}
  
  public int quantityDropped(Random llllllllllllllIlllllllIlllIIIIll)
  {
    return llIlIlllIIll[0];
  }
  
  public BlockClay()
  {
    llllllllllllllIlllllllIlllIIlIIl.<init>(Material.clay);
    "".length();
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIlllllllIlllIIIlll, Random llllllllllllllIlllllllIlllIIIllI, int llllllllllllllIlllllllIlllIIIlIl)
  {
    return Items.clay_ball;
  }
  
  private static void lIlIIlIlIIlIlI()
  {
    llIlIlllIIll = new int[1];
    llIlIlllIIll[0] = (0x91 ^ 0x95);
  }
}

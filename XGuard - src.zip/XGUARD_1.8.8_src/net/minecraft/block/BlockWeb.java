package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.World;

public class BlockWeb
  extends Block
{
  protected boolean canSilkHarvest()
  {
    return lIIIIIIlllIll[1];
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIlIllIllIlIIlIIlII, Random llllllllllllllIlIllIllIlIIlIIIll, int llllllllllllllIlIllIllIlIIlIIIlI)
  {
    return Items.string;
  }
  
  public EnumWorldBlockLayer getBlockLayer()
  {
    return EnumWorldBlockLayer.CUTOUT;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIlIllIllIlIIlIlIIl, BlockPos llllllllllllllIlIllIllIlIIlIlIII, IBlockState llllllllllllllIlIllIllIlIIlIIlll)
  {
    return null;
  }
  
  public boolean isFullCube()
  {
    return lIIIIIIlllIll[0];
  }
  
  public boolean isOpaqueCube()
  {
    return lIIIIIIlllIll[0];
  }
  
  private static void llIIIlllIIlllI()
  {
    lIIIIIIlllIll = new int[2];
    lIIIIIIlllIll[0] = ((0x4B ^ 0x17) & (0x74 ^ 0x28 ^ 0xFFFFFFFF));
    lIIIIIIlllIll[1] = " ".length();
  }
  
  public void onEntityCollidedWithBlock(World llllllllllllllIlIllIllIlIIllIIII, BlockPos llllllllllllllIlIllIllIlIIlIllll, IBlockState llllllllllllllIlIllIllIlIIlIlllI, Entity llllllllllllllIlIllIllIlIIlIllIl)
  {
    ;
    llllllllllllllIlIllIllIlIIlIllIl.setInWeb();
  }
  
  static {}
  
  public BlockWeb()
  {
    llllllllllllllIlIllIllIlIIllIlII.<init>(Material.web);
    "".length();
  }
}

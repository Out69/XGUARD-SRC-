package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IStringSerializable;
import net.minecraft.world.World;

public class BlockQuartz
  extends Block
{
  private static String lIllIIIllllIlI(String llllllllllllllIlllIIIllIlIlIlIlI, String llllllllllllllIlllIIIllIlIlIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlllIIIllIlIlIllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllIIIllIlIlIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlllIIIllIlIlIlllI = Cipher.getInstance("Blowfish");
      llllllllllllllIlllIIIllIlIlIlllI.init(lllIlIIIIlIl[2], llllllllllllllIlllIIIllIlIlIllll);
      return new String(llllllllllllllIlllIIIllIlIlIlllI.doFinal(Base64.getDecoder().decode(llllllllllllllIlllIIIllIlIlIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlllIIIllIlIlIllIl)
    {
      llllllllllllllIlllIIIllIlIlIllIl.printStackTrace();
    }
    return null;
  }
  
  private static void lIllIIIllllIll()
  {
    lllIlIIIIlII = new String[lllIlIIIIlIl[1]];
    lllIlIIIIlII[lllIlIIIIlIl[0]] = lIllIIIllllIlI("idfcPTfhbvc=", "owVVU");
  }
  
  protected ItemStack createStackedBlock(IBlockState llllllllllllllIlllIIIllIllIIlllI)
  {
    ;
    ;
    ;
    EnumType llllllllllllllIlllIIIllIllIlIIII = (EnumType)llllllllllllllIlllIIIllIllIIlllI.getValue(VARIANT);
    if ((lIllIIIllllllI(llllllllllllllIlllIIIllIllIlIIII, EnumType.LINES_X)) && (lIllIIIllllllI(llllllllllllllIlllIIIllIllIlIIII, EnumType.LINES_Z)))
    {
      "".length();
      if (null == null) {
        break label72;
      }
      return null;
    }
    label72:
    return new ItemStack(Item.getItemFromBlock(llllllllllllllIlllIIIllIllIIllll), lllIlIIIIlIl[1], EnumType.LINES_Y.getMetadata());
  }
  
  public BlockQuartz()
  {
    llllllllllllllIlllIIIllIlllIllIl.<init>(Material.rock);
    llllllllllllllIlllIIIllIlllIllII.setDefaultState(blockState.getBaseState().withProperty(VARIANT, EnumType.DEFAULT));
    "".length();
  }
  
  public IBlockState onBlockPlaced(World llllllllllllllIlllIIIllIlllIIlll, BlockPos llllllllllllllIlllIIIllIlllIIllI, EnumFacing llllllllllllllIlllIIIllIlllIIlIl, float llllllllllllllIlllIIIllIlllIIlII, float llllllllllllllIlllIIIllIlllIIIll, float llllllllllllllIlllIIIllIlllIIIlI, int llllllllllllllIlllIIIllIllIlllIl, EntityLivingBase llllllllllllllIlllIIIllIlllIIIII)
  {
    ;
    ;
    ;
    if (lIllIIIlllllIl(llllllllllllllIlllIIIllIllIlllIl, EnumType.LINES_Y.getMetadata()))
    {
      switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing$Axis()[llllllllllllllIlllIIIllIlllIIlIl.getAxis().ordinal()])
      {
      case 3: 
        return llllllllllllllIlllIIIllIllIlllll.getDefaultState().withProperty(VARIANT, EnumType.LINES_Z);
      case 1: 
        return llllllllllllllIlllIIIllIllIlllll.getDefaultState().withProperty(VARIANT, EnumType.LINES_X);
      }
      return llllllllllllllIlllIIIllIllIlllll.getDefaultState().withProperty(VARIANT, EnumType.LINES_Y);
    }
    if (lIllIIIlllllIl(llllllllllllllIlllIIIllIllIlllIl, EnumType.CHISELED.getMetadata()))
    {
      "".length();
      if (-" ".length() <= " ".length()) {
        break label166;
      }
      return null;
    }
    label166:
    return llllllllllllllIlllIIIllIllIlllll.getDefaultState().withProperty(VARIANT, EnumType.DEFAULT);
  }
  
  public void getSubBlocks(Item llllllllllllllIlllIIIllIllIIIllI, CreativeTabs llllllllllllllIlllIIIllIllIIlIII, List<ItemStack> llllllllllllllIlllIIIllIllIIIlll)
  {
    ;
    ;
    new ItemStack(llllllllllllllIlllIIIllIllIIIllI, lllIlIIIIlIl[1], EnumType.DEFAULT.getMetadata());
    "".length();
    new ItemStack(llllllllllllllIlllIIIllIllIIIllI, lllIlIIIIlIl[1], EnumType.CHISELED.getMetadata());
    "".length();
    new ItemStack(llllllllllllllIlllIIIllIllIIIllI, lllIlIIIIlIl[1], EnumType.LINES_Y.getMetadata());
    "".length();
  }
  
  private static void lIllIIIlllllII()
  {
    lllIlIIIIlIl = new int[4];
    lllIlIIIIlIl[0] = ((0x6 ^ 0x53) & (0x5E ^ 0xB ^ 0xFFFFFFFF));
    lllIlIIIIlIl[1] = " ".length();
    lllIlIIIIlIl[2] = "  ".length();
    lllIlIIIIlIl[3] = "   ".length();
  }
  
  private static boolean lIllIIIllllllI(Object ???, Object arg1)
  {
    Object localObject;
    char llllllllllllllIlllIIIllIlIIlllll;
    return ??? != localObject;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIlllIIIllIlIllIllI, new IProperty[] { VARIANT });
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIlllIIIllIlIlllIlI)
  {
    ;
    return ((EnumType)llllllllllllllIlllIIIllIlIlllIlI.getValue(VARIANT)).getMetadata();
  }
  
  public MapColor getMapColor(IBlockState llllllllllllllIlllIIIllIllIIIIll)
  {
    return MapColor.quartzColor;
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIlllIIIllIlIllllIl)
  {
    ;
    ;
    return llllllllllllllIlllIIIllIlIlllllI.getDefaultState().withProperty(VARIANT, EnumType.byMetadata(llllllllllllllIlllIIIllIlIllllIl));
  }
  
  static
  {
    lIllIIIlllllII();
    lIllIIIllllIll();
  }
  
  public int damageDropped(IBlockState llllllllllllllIlllIIIllIllIlIlll)
  {
    ;
    ;
    EnumType llllllllllllllIlllIIIllIllIllIII = (EnumType)llllllllllllllIlllIIIllIllIlIlll.getValue(VARIANT);
    if ((lIllIIIllllllI(llllllllllllllIlllIIIllIllIllIII, EnumType.LINES_X)) && (lIllIIIllllllI(llllllllllllllIlllIIIllIllIllIII, EnumType.LINES_Z)))
    {
      "".length();
      if ("   ".length() > ((0x26 ^ 0x76) & (0x71 ^ 0x21 ^ 0xFFFFFFFF))) {
        break label85;
      }
      return (0x21 ^ 0x3E) & (0x7D ^ 0x62 ^ 0xFFFFFFFF);
    }
    label85:
    return EnumType.LINES_Y.getMetadata();
  }
  
  private static boolean lIllIIIlllllIl(int ???, int arg1)
  {
    int i;
    short llllllllllllllIlllIIIllIlIlIIIll;
    return ??? == i;
  }
  
  private static boolean lIllIIIlllllll(Object ???)
  {
    int llllllllllllllIlllIIIllIlIIlllIl;
    return ??? != null;
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    public String getName()
    {
      ;
      return field_176805_h;
    }
    
    private static boolean lIllIIlIIIIIlI(int ???)
    {
      int llllllllllllllIlllIIIllIIIllIlII;
      return ??? >= 0;
    }
    
    private static boolean lIllIIlIIIIIIl(int ???, int arg1)
    {
      int i;
      float llllllllllllllIlllIIIllIIIlllIlI;
      return ??? >= i;
    }
    
    private static String lIllIIIllllIII(String llllllllllllllIlllIIIllIIlIIIIll, String llllllllllllllIlllIIIllIIlIIIIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlllIIIllIIlIIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllIIIllIIlIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIlllIIIllIIlIIIlIl = Cipher.getInstance("Blowfish");
        llllllllllllllIlllIIIllIIlIIIlIl.init(lllIlIIIIllI[2], llllllllllllllIlllIIIllIIlIIIllI);
        return new String(llllllllllllllIlllIIIllIIlIIIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlllIIIllIIlIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlllIIIllIIlIIIlII)
      {
        llllllllllllllIlllIIIllIIlIIIlII.printStackTrace();
      }
      return null;
    }
    
    public static EnumType byMetadata(int llllllllllllllIlllIIIllIIllllIll)
    {
      ;
      if ((!lIllIIlIIIIIlI(llllllllllllllIlllIIIllIIllllIll)) || (lIllIIlIIIIIIl(llllllllllllllIlllIIIllIIlllllII, META_LOOKUP.length))) {
        llllllllllllllIlllIIIllIIlllllII = lllIlIIIIllI[0];
      }
      return META_LOOKUP[llllllllllllllIlllIIIllIIlllllII];
    }
    
    private static String lIllIIIlllIlll(String llllllllllllllIlllIIIllIIlIIlllI, String llllllllllllllIlllIIIllIIlIIllIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlllIIIllIIlIlIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllIIIllIIlIIllIl.getBytes(StandardCharsets.UTF_8)), lllIlIIIIllI[8]), "DES");
        Cipher llllllllllllllIlllIIIllIIlIlIIlI = Cipher.getInstance("DES");
        llllllllllllllIlllIIIllIIlIlIIlI.init(lllIlIIIIllI[2], llllllllllllllIlllIIIllIIlIlIIll);
        return new String(llllllllllllllIlllIIIllIIlIlIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIlllIIIllIIlIIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlllIIIllIIlIlIIIl)
      {
        llllllllllllllIlllIIIllIIlIlIIIl.printStackTrace();
      }
      return null;
    }
    
    private static void lIllIIlIIIIIII()
    {
      lllIlIIIIllI = new int[16];
      lllIlIIIIllI[0] = ((0xDF ^ 0x8C) & (0xD7 ^ 0x84 ^ 0xFFFFFFFF));
      lllIlIIIIllI[1] = " ".length();
      lllIlIIIIllI[2] = "  ".length();
      lllIlIIIIllI[3] = "   ".length();
      lllIlIIIIllI[4] = (0x48 ^ 0x4C);
      lllIlIIIIllI[5] = (0x43 ^ 0x46);
      lllIlIIIIllI[6] = (0x25 ^ 0x23);
      lllIlIIIIllI[7] = (0xBD ^ 0xBA);
      lllIlIIIIllI[8] = (117 + '' - 248 + 143 ^ 121 + 102 - 110 + 34);
      lllIlIIIIllI[9] = ('¢' + 48 - 83 + 45 ^ 98 + 17 - 101 + 151);
      lllIlIIIIllI[10] = (0x69 ^ 0x63);
      lllIlIIIIllI[11] = (0x2 ^ 0x9);
      lllIlIIIIllI[12] = (66 + '' - 141 + 80 ^ 61 + 88 - 139 + 140);
      lllIlIIIIllI[13] = (43 + 75 - 4 + 44 ^ 98 + 39 - 96 + 106);
      lllIlIIIIllI[14] = (0x45 ^ 0x4B);
      lllIlIIIIllI[15] = (0x70 ^ 0x7F);
    }
    
    public String toString()
    {
      ;
      return unlocalizedName;
    }
    
    static
    {
      lIllIIlIIIIIII();
      lIllIIIllllIIl();
      boolean llllllllllllllIlllIIIllIlIIlIlII;
      double llllllllllllllIlllIIIllIlIIlIlll;
      DEFAULT = new EnumType(lllIlIIIIIlI[lllIlIIIIllI[0]], lllIlIIIIllI[0], lllIlIIIIllI[0], lllIlIIIIIlI[lllIlIIIIllI[1]], lllIlIIIIIlI[lllIlIIIIllI[2]]);
      CHISELED = new EnumType(lllIlIIIIIlI[lllIlIIIIllI[3]], lllIlIIIIllI[1], lllIlIIIIllI[1], lllIlIIIIIlI[lllIlIIIIllI[4]], lllIlIIIIIlI[lllIlIIIIllI[5]]);
      LINES_Y = new EnumType(lllIlIIIIIlI[lllIlIIIIllI[6]], lllIlIIIIllI[2], lllIlIIIIllI[2], lllIlIIIIIlI[lllIlIIIIllI[7]], lllIlIIIIIlI[lllIlIIIIllI[8]]);
      LINES_X = new EnumType(lllIlIIIIIlI[lllIlIIIIllI[9]], lllIlIIIIllI[3], lllIlIIIIllI[3], lllIlIIIIIlI[lllIlIIIIllI[10]], lllIlIIIIIlI[lllIlIIIIllI[11]]);
      LINES_Z = new EnumType(lllIlIIIIIlI[lllIlIIIIllI[12]], lllIlIIIIllI[4], lllIlIIIIllI[4], lllIlIIIIIlI[lllIlIIIIllI[13]], lllIlIIIIIlI[lllIlIIIIllI[14]]);
      ENUM$VALUES = new EnumType[] { DEFAULT, CHISELED, LINES_Y, LINES_X, LINES_Z };
      META_LOOKUP = new EnumType[values().length];
      int llllllllllllllIlllIIIllIlIIlIlIl = (llllllllllllllIlllIIIllIlIIlIlII = values()).length;
      String llllllllllllllIlllIIIllIlIIlIllI = lllIlIIIIllI[0];
      "".length();
      if (-(0x4F ^ 0x6C ^ 0x4A ^ 0x6D) >= 0) {
        return;
      }
      while (!lIllIIlIIIIIIl(llllllllllllllIlllIIIllIlIIlIllI, llllllllllllllIlllIIIllIlIIlIlIl))
      {
        EnumType llllllllllllllIlllIIIllIlIIllIII = llllllllllllllIlllIIIllIlIIlIlII[llllllllllllllIlllIIIllIlIIlIllI];
        META_LOOKUP[llllllllllllllIlllIIIllIlIIllIII.getMetadata()] = llllllllllllllIlllIIIllIlIIllIII;
        llllllllllllllIlllIIIllIlIIlIllI++;
      }
    }
    
    private static boolean lIllIIlIIIIIll(int ???, int arg1)
    {
      int i;
      Exception llllllllllllllIlllIIIllIIIllIllI;
      return ??? < i;
    }
    
    private static void lIllIIIllllIIl()
    {
      lllIlIIIIIlI = new String[lllIlIIIIllI[15]];
      lllIlIIIIIlI[lllIlIIIIllI[0]] = lIllIIIlllIllI("Kz8yMCAjLg==", "oztqu");
      lllIlIIIIIlI[lllIlIIIIllI[1]] = lIllIIIlllIllI("CzUONyMDJA==", "oPhVV");
      lllIlIIIIIlI[lllIlIIIIllI[2]] = lIllIIIlllIllI("LQ8uNx4lHg==", "IjHVk");
      lllIlIIIIIlI[lllIlIIIIllI[3]] = lIllIIIlllIllI("Mhs5Ai89FjQ=", "qSpQj");
      lllIlIIIIIlI[lllIlIIIIllI[4]] = lIllIIIlllIlll("0JW60BcnMGntAt2RufEP1g==", "PyeSk");
      lllIlIIIIIlI[lllIlIIIIllI[5]] = lIllIIIlllIllI("EhEMGAgdHAE=", "qyekm");
      lllIlIIIIIlI[lllIlIIIIllI[6]] = lIllIIIllllIII("uaBzereY1wU=", "sDEqv");
      lllIlIIIIIlI[lllIlIIIIllI[7]] = lIllIIIlllIlll("5rYfS9GUIS4=", "JTwrf");
      lllIlIIIIIlI[lllIlIIIIllI[8]] = lIllIIIllllIII("PkIgnH9UGsI=", "iHZNy");
      lllIlIIIIIlI[lllIlIIIIllI[9]] = lIllIIIlllIllI("Px8MDQYsDg==", "sVBHU");
      lllIlIIIIIlI[lllIlIIIIllI[10]] = lIllIIIlllIlll("9omNwh6AeEU=", "EfzqD");
      lllIlIIIIIlI[lllIlIIIIllI[11]] = lIllIIIllllIII("iz+l6C201yE=", "ApNTO");
      lllIlIIIIIlI[lllIlIIIIllI[12]] = lIllIIIlllIlll("i9apcbBfFys=", "oVQSf");
      lllIlIIIIIlI[lllIlIIIIllI[13]] = lIllIIIlllIllI("OxwvCz0IDw==", "WuAnN");
      lllIlIIIIIlI[lllIlIIIIllI[14]] = lIllIIIlllIllI("Fj4mNR0=", "zWHPn");
    }
    
    private static String lIllIIIlllIllI(String llllllllllllllIlllIIIllIIllIIIII, String llllllllllllllIlllIIIllIIlIlllll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIlllIIIllIIllIIIII = new String(Base64.getDecoder().decode(llllllllllllllIlllIIIllIIllIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIlllIIIllIIllIIIll = new StringBuilder();
      char[] llllllllllllllIlllIIIllIIllIIIlI = llllllllllllllIlllIIIllIIlIlllll.toCharArray();
      int llllllllllllllIlllIIIllIIllIIIIl = lllIlIIIIllI[0];
      int llllllllllllllIlllIIIllIIlIllIll = llllllllllllllIlllIIIllIIllIIIII.toCharArray();
      float llllllllllllllIlllIIIllIIlIllIlI = llllllllllllllIlllIIIllIIlIllIll.length;
      String llllllllllllllIlllIIIllIIlIllIIl = lllIlIIIIllI[0];
      while (lIllIIlIIIIIll(llllllllllllllIlllIIIllIIlIllIIl, llllllllllllllIlllIIIllIIlIllIlI))
      {
        char llllllllllllllIlllIIIllIIllIIllI = llllllllllllllIlllIIIllIIlIllIll[llllllllllllllIlllIIIllIIlIllIIl];
        "".length();
        "".length();
        if ("  ".length() < 0) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIlllIIIllIIllIIIll);
    }
    
    private EnumType(int llllllllllllllIlllIIIllIlIIIllII, String llllllllllllllIlllIIIllIlIIIIlIl, String llllllllllllllIlllIIIllIlIIIIlII)
    {
      meta = llllllllllllllIlllIIIllIlIIIllII;
      field_176805_h = llllllllllllllIlllIIIllIlIIIIlIl;
      unlocalizedName = llllllllllllllIlllIIIllIlIIIIlII;
    }
  }
}

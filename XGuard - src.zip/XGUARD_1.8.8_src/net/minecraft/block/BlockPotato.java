package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class BlockPotato
  extends BlockCrops
{
  private static boolean lIIlIIIllll(int ???, int arg1)
  {
    int i;
    float lllIllIIlllIII;
    return ??? >= i;
  }
  
  public void dropBlockAsItemWithChance(World lllIllIlIIIIII, BlockPos lllIllIlIIIlIl, IBlockState lllIllIlIIIlII, float lllIllIIllllIl, int lllIllIlIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllIllIlIIIIIl.dropBlockAsItemWithChance(lllIllIlIIIIII, lllIllIlIIIlIl, lllIllIlIIIlII, lllIllIIllllIl, lllIllIlIIIIlI);
    if ((lIIlIIIlllI(isRemote)) && (lIIlIIIllll(((Integer)lllIllIlIIIlII.getValue(AGE)).intValue(), lIllIIlII[0])) && (lIIlIIIlllI(rand.nextInt(lIllIIlII[1])))) {
      spawnAsEntity(lllIllIlIIIIII, lllIllIlIIIlIl, new ItemStack(Items.poisonous_potato));
    }
  }
  
  private static void lIIlIIIllIl()
  {
    lIllIIlII = new int[2];
    lIllIIlII[0] = (0x95 ^ 0x92);
    lIllIIlII[1] = (73 + 92 - 122 + 95 ^ '' + '' - 193 + 90);
  }
  
  private static boolean lIIlIIIlllI(int ???)
  {
    long lllIllIIllIllI;
    return ??? == 0;
  }
  
  protected Item getCrop()
  {
    return Items.potato;
  }
  
  protected Item getSeed()
  {
    return Items.potato;
  }
  
  static {}
  
  public BlockPotato() {}
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockMycelium
  extends Block
{
  private static void lIlIlllIlIlIIl()
  {
    lllIIlIIIlll = new int[8];
    lllIIlIIIlll[0] = ((0x70 ^ 0x28) & (0xE3 ^ 0xBB ^ 0xFFFFFFFF));
    lllIIlIIIlll[1] = " ".length();
    lllIIlIIIlll[2] = ('' + 35 - 105 + 88 ^ '' + 42 - 186 + 158);
    lllIIlIIIlll[3] = "  ".length();
    lllIIlIIIlll[4] = (0x6 ^ 0xF);
    lllIIlIIIlll[5] = "   ".length();
    lllIIlIIIlll[6] = ('' + 22 - 113 + 121 ^ 17 + 32 - -59 + 65);
    lllIIlIIIlll[7] = (0xA4 ^ 0xAE);
  }
  
  private static boolean lIlIlllIlIlIll(int ???)
  {
    short llllllllllllllIlllIlIlIlIIlllllI;
    return ??? == 0;
  }
  
  public void updateTick(World llllllllllllllIlllIlIlIllIIIIlll, BlockPos llllllllllllllIlllIlIlIllIIIIllI, IBlockState llllllllllllllIlllIlIlIllIIIlllI, Random llllllllllllllIlllIlIlIllIIIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIlllIlIlIll(isRemote)) {
      if ((lIlIlllIlIllII(llllllllllllllIlllIlIlIllIIIIlll.getLightFromNeighbors(llllllllllllllIlllIlIlIllIIIllll.up()), lllIIlIIIlll[2])) && (lIlIlllIlIllIl(llllllllllllllIlllIlIlIllIIIIlll.getBlockState(llllllllllllllIlllIlIlIllIIIllll.up()).getBlock().getLightOpacity(), lllIIlIIIlll[3])))
      {
        "".length();
        "".length();
        if ((0x59 ^ 0x74 ^ 0x9F ^ 0xB6) >= ((118 + '' - 178 + 66 ^ '°' + 35 - 183 + 170) & ('¢' + 22 - 72 + 95 ^ 74 + 90 - 123 + 102 ^ -" ".length()))) {}
      }
      else if (lIlIlllIlIlllI(llllllllllllllIlllIlIlIllIIIIlll.getLightFromNeighbors(llllllllllllllIlllIlIlIllIIIllll.up()), lllIIlIIIlll[4]))
      {
        int llllllllllllllIlllIlIlIllIIIllII = lllIIlIIIlll[0];
        "".length();
        if ((0x3E ^ 0x3A) == 0) {
          return;
        }
        while (!lIlIlllIlIlllI(llllllllllllllIlllIlIlIllIIIllII, lllIIlIIIlll[2]))
        {
          BlockPos llllllllllllllIlllIlIlIllIIIlIll = llllllllllllllIlllIlIlIllIIIllll.add(llllllllllllllIlllIlIlIllIIIIlIl.nextInt(lllIIlIIIlll[5]) - lllIIlIIIlll[1], llllllllllllllIlllIlIlIllIIIIlIl.nextInt(lllIIlIIIlll[6]) - lllIIlIIIlll[5], llllllllllllllIlllIlIlIllIIIIlIl.nextInt(lllIIlIIIlll[5]) - lllIIlIIIlll[1]);
          IBlockState llllllllllllllIlllIlIlIllIIIlIlI = llllllllllllllIlllIlIlIllIIIIlll.getBlockState(llllllllllllllIlllIlIlIllIIIlIll);
          Block llllllllllllllIlllIlIlIllIIIlIIl = llllllllllllllIlllIlIlIllIIIIlll.getBlockState(llllllllllllllIlllIlIlIllIIIlIll.up()).getBlock();
          if ((lIlIlllIlIllll(llllllllllllllIlllIlIlIllIIIlIlI.getBlock(), Blocks.dirt)) && (lIlIlllIlIllll(llllllllllllllIlllIlIlIllIIIlIlI.getValue(BlockDirt.VARIANT), BlockDirt.DirtType.DIRT)) && (lIlIlllIlIlllI(llllllllllllllIlllIlIlIllIIIIlll.getLightFromNeighbors(llllllllllllllIlllIlIlIllIIIlIll.up()), lllIIlIIIlll[2])) && (lIlIlllIllIIII(llllllllllllllIlllIlIlIllIIIlIIl.getLightOpacity(), lllIIlIIIlll[3]))) {
            "".length();
          }
          llllllllllllllIlllIlIlIllIIIllII++;
        }
      }
    }
  }
  
  static
  {
    lIlIlllIlIlIIl();
    lIlIlllIlIlIII();
  }
  
  private static boolean lIlIlllIlIllll(Object ???, Object arg1)
  {
    Object localObject;
    byte llllllllllllllIlllIlIlIlIlIIIIII;
    return ??? == localObject;
  }
  
  protected BlockMycelium()
  {
    llllllllllllllIlllIlIlIllIlIIlll.<init>(Material.grass, MapColor.purpleColor);
    llllllllllllllIlllIlIlIllIlIlIII.setDefaultState(blockState.getBaseState().withProperty(SNOWY, Boolean.valueOf(lllIIlIIIlll[0])));
    "".length();
    "".length();
  }
  
  private static String lIlIlllIlIIlll(String llllllllllllllIlllIlIlIlIlIllIll, String llllllllllllllIlllIlIlIlIlIlllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlllIlIlIlIllIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllIlIlIlIlIlllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlllIlIlIlIlIlllll = Cipher.getInstance("Blowfish");
      llllllllllllllIlllIlIlIlIlIlllll.init(lllIIlIIIlll[3], llllllllllllllIlllIlIlIlIllIIIII);
      return new String(llllllllllllllIlllIlIlIlIlIlllll.doFinal(Base64.getDecoder().decode(llllllllllllllIlllIlIlIlIlIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlllIlIlIlIlIllllI)
    {
      llllllllllllllIlllIlIlIlIlIllllI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlIlllIlIlIlI(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllIlllIlIlIlIlIIIlII;
    return ??? != localObject;
  }
  
  private static boolean lIlIlllIlIlllI(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlllIlIlIlIlIlIlII;
    return ??? >= i;
  }
  
  private static boolean lIlIlllIlIllII(int ???, int arg1)
  {
    int i;
    double llllllllllllllIlllIlIlIlIlIlIIII;
    return ??? < i;
  }
  
  private static boolean lIlIlllIllIIII(int ???, int arg1)
  {
    int i;
    double llllllllllllllIlllIlIlIlIlIIllII;
    return ??? <= i;
  }
  
  private static boolean lIlIlllIlIllIl(int ???, int arg1)
  {
    int i;
    double llllllllllllllIlllIlIlIlIlIIlIII;
    return ??? > i;
  }
  
  private static void lIlIlllIlIlIII()
  {
    lllIIlIIIllI = new String[lllIIlIIIlll[1]];
    lllIIlIIIllI[lllIIlIIIlll[0]] = lIlIlllIlIIlll("6EtEEJMOTJU=", "CEZOh");
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIlllIlIlIlIllIlIII)
  {
    return lllIIlIIIlll[0];
  }
  
  public IBlockState getActualState(IBlockState llllllllllllllIlllIlIlIllIlIIIIl, IBlockAccess llllllllllllllIlllIlIlIllIIlllII, BlockPos llllllllllllllIlllIlIlIllIIllIll)
  {
    ;
    ;
    ;
    ;
    Block llllllllllllllIlllIlIlIllIIllllI = llllllllllllllIlllIlIlIllIIlllII.getBlockState(llllllllllllllIlllIlIlIllIIllIll.up()).getBlock();
    if ((lIlIlllIlIlIlI(llllllllllllllIlllIlIlIllIIllllI, Blocks.snow)) && (lIlIlllIlIlIlI(llllllllllllllIlllIlIlIllIIllllI, Blocks.snow_layer)))
    {
      "".length();
      if (-" ".length() <= "  ".length()) {
        break label75;
      }
      return null;
    }
    label75:
    return SNOWY.withProperty(lllIIlIIIlll[0], Boolean.valueOf(lllIIlIIIlll[1]));
  }
  
  public Item getItemDropped(IBlockState llllllllllllllIlllIlIlIlIllIlllI, Random llllllllllllllIlllIlIlIlIllIllIl, int llllllllllllllIlllIlIlIlIllIlIlI)
  {
    ;
    ;
    return Blocks.dirt.getItemDropped(Blocks.dirt.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.DIRT), llllllllllllllIlllIlIlIlIllIllIl, llllllllllllllIlllIlIlIlIllIlIlI);
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIlllIlIlIlIllIIlIl, new IProperty[] { SNOWY });
  }
  
  public void randomDisplayTick(World llllllllllllllIlllIlIlIlIlllIlIl, BlockPos llllllllllllllIlllIlIlIlIllllIIl, IBlockState llllllllllllllIlllIlIlIlIlllIIll, Random llllllllllllllIlllIlIlIlIlllIlll)
  {
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlllIlIlIlIllllIll.randomDisplayTick(llllllllllllllIlllIlIlIlIlllIlIl, llllllllllllllIlllIlIlIlIlllIlII, llllllllllllllIlllIlIlIlIlllIIll, llllllllllllllIlllIlIlIlIlllIlll);
    if (lIlIlllIlIlIll(llllllllllllllIlllIlIlIlIlllIlll.nextInt(lllIIlIIIlll[7]))) {
      llllllllllllllIlllIlIlIlIlllIlIl.spawnParticle(EnumParticleTypes.TOWN_AURA, llllllllllllllIlllIlIlIlIlllIlII.getX() + llllllllllllllIlllIlIlIlIlllIlll.nextFloat(), llllllllllllllIlllIlIlIlIlllIlII.getY() + 1.1F, llllllllllllllIlllIlIlIlIlllIlII.getZ() + llllllllllllllIlllIlIlIlIlllIlll.nextFloat(), 0.0D, 0.0D, 0.0D, new int[lllIIlIIIlll[0]]);
    }
  }
}

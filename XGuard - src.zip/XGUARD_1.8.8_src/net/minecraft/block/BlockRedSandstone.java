package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;

public class BlockRedSandstone
  extends Block
{
  private static void lIlllIIlIIllII()
  {
    llllIIllIlII = new int[4];
    llllIIllIlII[0] = (" ".length() & (" ".length() ^ -" ".length()));
    llllIIllIlII[1] = " ".length();
    llllIIllIlII[2] = (0x1A ^ 0x12);
    llllIIllIlII[3] = "  ".length();
  }
  
  public IBlockState getStateFromMeta(int llllllllllllllIllIlIllIIlIllllIl)
  {
    ;
    ;
    return llllllllllllllIllIlIllIIlIlllllI.getDefaultState().withProperty(TYPE, EnumType.byMetadata(llllllllllllllIllIlIllIIlIllllIl));
  }
  
  static
  {
    lIlllIIlIIllII();
    lIlllIIlIIlIIl();
  }
  
  public BlockRedSandstone()
  {
    llllllllllllllIllIlIllIIllIlIlll.<init>(Material.rock, BlockSand.EnumType.RED_SAND.getMapColor());
    llllllllllllllIllIlIllIIllIlIllI.setDefaultState(blockState.getBaseState().withProperty(TYPE, EnumType.DEFAULT));
    "".length();
  }
  
  private static boolean lIlllIIlIIllll(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIllIlIllIIlIlIIIll;
    return ??? >= i;
  }
  
  protected BlockState createBlockState()
  {
    ;
    return new BlockState(llllllllllllllIllIlIllIIlIllIlII, new IProperty[] { TYPE });
  }
  
  private static void lIlllIIlIIlIIl()
  {
    llllIIllIIlI = new String[llllIIllIlII[1]];
    llllIIllIIlI[llllIIllIlII[0]] = lIlllIIlIIlIII("YU61VSLDSDQ=", "uIPyR");
  }
  
  public void getSubBlocks(Item llllllllllllllIllIlIllIIllIIlIlI, CreativeTabs llllllllllllllIllIlIllIIllIIlIIl, List<ItemStack> llllllllllllllIllIlIllIIllIIlIII)
  {
    ;
    ;
    ;
    ;
    float llllllllllllllIllIlIllIIllIIIIlI = (llllllllllllllIllIlIllIIllIIIIIl = EnumType.values()).length;
    Exception llllllllllllllIllIlIllIIllIIIIll = llllIIllIlII[0];
    "".length();
    if (" ".length() >= "  ".length()) {
      return;
    }
    while (!lIlllIIlIIllll(llllllllllllllIllIlIllIIllIIIIll, llllllllllllllIllIlIllIIllIIIIlI))
    {
      EnumType llllllllllllllIllIlIllIIllIIIlll = llllllllllllllIllIlIllIIllIIIIIl[llllllllllllllIllIlIllIIllIIIIll];
      new ItemStack(llllllllllllllIllIlIllIIllIIlIlI, llllIIllIlII[1], llllllllllllllIllIlIllIIllIIIlll.getMetadata());
      "".length();
    }
  }
  
  private static String lIlllIIlIIlIII(String llllllllllllllIllIlIllIIlIlIlIlI, String llllllllllllllIllIlIllIIlIlIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIlIllIIlIlIllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIllIIlIlIlIll.getBytes(StandardCharsets.UTF_8)), llllIIllIlII[2]), "DES");
      Cipher llllllllllllllIllIlIllIIlIlIlllI = Cipher.getInstance("DES");
      llllllllllllllIllIlIllIIlIlIlllI.init(llllIIllIlII[3], llllllllllllllIllIlIllIIlIlIllll);
      return new String(llllllllllllllIllIlIllIIlIlIlllI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIllIIlIlIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIlIllIIlIlIllIl)
    {
      llllllllllllllIllIlIllIIlIlIllIl.printStackTrace();
    }
    return null;
  }
  
  public int damageDropped(IBlockState llllllllllllllIllIlIllIIllIlIIlI)
  {
    ;
    return ((EnumType)llllllllllllllIllIlIllIIllIlIIlI.getValue(TYPE)).getMetadata();
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIllIlIllIIlIlllIII)
  {
    ;
    return ((EnumType)llllllllllllllIllIlIllIIlIlllIII.getValue(TYPE)).getMetadata();
  }
  
  public static enum EnumType
    implements IStringSerializable
  {
    private static String llIIllllIlIlIl(String llllllllllllllIlIlIIlIlIllIIlllI, String llllllllllllllIlIlIIlIlIllIIllll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIlIIlIlIllIlIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIIlIlIllIIllll.getBytes(StandardCharsets.UTF_8)), lIIIIllllIIlI[8]), "DES");
        Cipher llllllllllllllIlIlIIlIlIllIlIIlI = Cipher.getInstance("DES");
        llllllllllllllIlIlIIlIlIllIlIIlI.init(lIIIIllllIIlI[2], llllllllllllllIlIlIIlIlIllIlIIll);
        return new String(llllllllllllllIlIlIIlIlIllIlIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIIlIlIllIIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIlIIlIlIllIlIIIl)
      {
        llllllllllllllIlIlIIlIlIllIlIIIl.printStackTrace();
      }
      return null;
    }
    
    private static String llIIllllIIIlIl(String llllllllllllllIlIlIIlIlIlIlllIll, String llllllllllllllIlIlIIlIlIlIllllll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIlIlIIlIlIlIlllIll = new String(Base64.getDecoder().decode(llllllllllllllIlIlIIlIlIlIlllIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIlIlIIlIlIlIlllllI = new StringBuilder();
      char[] llllllllllllllIlIlIIlIlIlIllllIl = llllllllllllllIlIlIIlIlIlIllllll.toCharArray();
      int llllllllllllllIlIlIIlIlIlIllllII = lIIIIllllIIlI[0];
      boolean llllllllllllllIlIlIIlIlIlIllIllI = llllllllllllllIlIlIIlIlIlIlllIll.toCharArray();
      byte llllllllllllllIlIlIIlIlIlIllIlIl = llllllllllllllIlIlIIlIlIlIllIllI.length;
      byte llllllllllllllIlIlIIlIlIlIllIlII = lIIIIllllIIlI[0];
      while (llIIlllllIIIII(llllllllllllllIlIlIIlIlIlIllIlII, llllllllllllllIlIlIIlIlIlIllIlIl))
      {
        char llllllllllllllIlIlIIlIlIllIIIIIl = llllllllllllllIlIlIIlIlIlIllIllI[llllllllllllllIlIlIIlIlIlIllIlII];
        "".length();
        "".length();
        if (((50 + 98 - 76 + 80 ^ 47 + 19 - -3 + 103) & (23 + '' - 91 + 73 ^ '' + 28 - 100 + 106 ^ -" ".length())) >= " ".length()) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIlIlIIlIlIlIlllllI);
    }
    
    private static void llIIllllIlIllI()
    {
      lIIIIlllIllIl = new String[lIIIIllllIIlI[9]];
      lIIIIlllIllIl[lIIIIllllIIlI[0]] = llIIllllIIIlIl("EjQlAiUaJQ==", "VqcCp");
      lIIIIlllIllIl[lIIIIllllIIlI[1]] = llIIllllIIIlIl("OgIwHSUpCTAxIicJMQ==", "HgTBV");
      lIIIIlllIllIl[lIIIIllllIIlI[2]] = llIIllllIIIlIl("IQcNKR8pFg==", "EbkHj");
      lIIIIlllIllIl[lIIIIllllIIlI[3]] = llIIllllIIIllI("GI/uNiZSpMLJmnvQfQHkvw==", "iJxsb");
      lIIIIlllIllIl[lIIIIllllIIlI[4]] = llIIllllIIIllI("kvfHXIamfaVE/t3V7oJxRsIIYfIiBsx6", "BHwhT");
      lIIIIlllIllIl[lIIIIllllIIlI[5]] = llIIllllIlIlIl("Awt5Kxvph1JuLxcH40p18w==", "PKRyp");
      lIIIIlllIllIl[lIIIIllllIIlI[6]] = llIIllllIIIlIl("AyMZGhoY", "PnVUN");
      lIIIIlllIllIl[lIIIIllllIIlI[7]] = llIIllllIlIlIl("zfI8gLPyqhj5yMjeoQIQRKbXtpHeG8LW", "dqUse");
      lIIIIlllIllIl[lIIIIllllIIlI[8]] = llIIllllIlIlIl("qvgUYZjJqI4=", "KMjme");
    }
    
    private static boolean llIIllllIllIlI(int ???, int arg1)
    {
      int i;
      long llllllllllllllIlIlIIlIlIlIlIllll;
      return ??? >= i;
    }
    
    public int getMetadata()
    {
      ;
      return meta;
    }
    
    public String getUnlocalizedName()
    {
      ;
      return unlocalizedName;
    }
    
    private static boolean llIIlllllIIIII(int ???, int arg1)
    {
      int i;
      char llllllllllllllIlIlIIlIlIlIlIlIll;
      return ??? < i;
    }
    
    public String getName()
    {
      ;
      return name;
    }
    
    private static void llIIllllIllIIl()
    {
      lIIIIllllIIlI = new int[10];
      lIIIIllllIIlI[0] = ((0xBC ^ 0x81) & (0x5B ^ 0x66 ^ 0xFFFFFFFF));
      lIIIIllllIIlI[1] = " ".length();
      lIIIIllllIIlI[2] = "  ".length();
      lIIIIllllIIlI[3] = "   ".length();
      lIIIIllllIIlI[4] = (0x20 ^ 0x24);
      lIIIIllllIIlI[5] = (0x95 ^ 0xC6 ^ 0x7C ^ 0x2A);
      lIIIIllllIIlI[6] = (0x1 ^ 0x7);
      lIIIIllllIIlI[7] = (0x4F ^ 0x48);
      lIIIIllllIIlI[8] = (73 + '' - 201 + 154 ^ 92 + 14 - -73 + 6);
      lIIIIllllIIlI[9] = (0xB8 ^ 0xB1);
    }
    
    private static String llIIllllIIIllI(String llllllllllllllIlIlIIlIlIlllIIIll, String llllllllllllllIlIlIIlIlIlllIIIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIlIIlIlIlllIllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIIlIlIlllIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIlIlIIlIlIlllIlIlI = Cipher.getInstance("Blowfish");
        llllllllllllllIlIlIIlIlIlllIlIlI.init(lIIIIllllIIlI[2], llllllllllllllIlIlIIlIlIlllIllII);
        return new String(llllllllllllllIlIlIIlIlIlllIlIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIIlIlIlllIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIlIIlIlIlllIlIIl)
      {
        llllllllllllllIlIlIIlIlIlllIlIIl.printStackTrace();
      }
      return null;
    }
    
    public static EnumType byMetadata(int llllllllllllllIlIlIIlIllIIlIIIll)
    {
      ;
      if ((!llIIllllIllIll(llllllllllllllIlIlIIlIllIIlIIIll)) || (llIIllllIllIlI(llllllllllllllIlIlIIlIllIIlIIIlI, META_LOOKUP.length))) {
        llllllllllllllIlIlIIlIllIIlIIIlI = lIIIIllllIIlI[0];
      }
      return META_LOOKUP[llllllllllllllIlIlIIlIllIIlIIIlI];
    }
    
    public String toString()
    {
      ;
      return name;
    }
    
    static
    {
      llIIllllIllIIl();
      llIIllllIlIllI();
      boolean llllllllllllllIlIlIIlIllIlIIIIIl;
      double llllllllllllllIlIlIIlIllIlIIIlII;
      DEFAULT = new EnumType(lIIIIlllIllIl[lIIIIllllIIlI[0]], lIIIIllllIIlI[0], lIIIIllllIIlI[0], lIIIIlllIllIl[lIIIIllllIIlI[1]], lIIIIlllIllIl[lIIIIllllIIlI[2]]);
      CHISELED = new EnumType(lIIIIlllIllIl[lIIIIllllIIlI[3]], lIIIIllllIIlI[1], lIIIIllllIIlI[1], lIIIIlllIllIl[lIIIIllllIIlI[4]], lIIIIlllIllIl[lIIIIllllIIlI[5]]);
      SMOOTH = new EnumType(lIIIIlllIllIl[lIIIIllllIIlI[6]], lIIIIllllIIlI[2], lIIIIllllIIlI[2], lIIIIlllIllIl[lIIIIllllIIlI[7]], lIIIIlllIllIl[lIIIIllllIIlI[8]]);
      ENUM$VALUES = new EnumType[] { DEFAULT, CHISELED, SMOOTH };
      META_LOOKUP = new EnumType[values().length];
      byte llllllllllllllIlIlIIlIllIlIIIIlI = (llllllllllllllIlIlIIlIllIlIIIIIl = values()).length;
      boolean llllllllllllllIlIlIIlIllIlIIIIll = lIIIIllllIIlI[0];
      "".length();
      if (((0xB4 ^ 0xAF) & (0x90 ^ 0x8B ^ 0xFFFFFFFF)) == -" ".length()) {
        return;
      }
      while (!llIIllllIllIlI(llllllllllllllIlIlIIlIllIlIIIIll, llllllllllllllIlIlIIlIllIlIIIIlI))
      {
        EnumType llllllllllllllIlIlIIlIllIlIIIlIl = llllllllllllllIlIlIIlIllIlIIIIIl[llllllllllllllIlIlIIlIllIlIIIIll];
        META_LOOKUP[llllllllllllllIlIlIIlIllIlIIIlIl.getMetadata()] = llllllllllllllIlIlIIlIllIlIIIlIl;
        llllllllllllllIlIlIIlIllIlIIIIll++;
      }
    }
    
    private EnumType(int llllllllllllllIlIlIIlIllIIllIIll, String llllllllllllllIlIlIIlIllIIllIIlI, String llllllllllllllIlIlIIlIllIIllIIIl)
    {
      meta = llllllllllllllIlIlIIlIllIIllIIll;
      name = llllllllllllllIlIlIIlIllIIllIIlI;
      unlocalizedName = llllllllllllllIlIlIIlIllIIllIIIl;
    }
    
    private static boolean llIIllllIllIll(int ???)
    {
      short llllllllllllllIlIlIIlIlIlIlIlIIl;
      return ??? >= 0;
    }
  }
}

package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public abstract class BlockWoodSlab
  extends BlockSlab
{
  public IBlockState getStateFromMeta(int lllllllllllllllllIIlllIIlIIIlIll)
  {
    ;
    ;
    ;
    IBlockState lllllllllllllllllIIlllIIlIIIllIl = lllllllllllllllllIIlllIIlIIIllll.getDefaultState().withProperty(VARIANT, BlockPlanks.EnumType.byMetadata(lllllllllllllllllIIlllIIlIIIlIll & lIIlIllllII[2]));
    if (lllIllllIIlI(lllllllllllllllllIIlllIIlIIIllll.isDouble()))
    {
      if (lllIllllIIlI(lllllllllllllllllIIlllIIlIIIlIll & lIIlIllllII[3]))
      {
        "".length();
        if ("  ".length() != " ".length()) {
          break label77;
        }
        return null;
      }
      label77:
      lllllllllllllllllIIlllIIlIIIllIl = HALF.withProperty(BlockSlab.EnumBlockHalf.BOTTOM, BlockSlab.EnumBlockHalf.TOP);
    }
    return lllllllllllllllllIIlllIIlIIIllIl;
  }
  
  private static void lllIllllIIII()
  {
    lIIlIlllIll = new String[lIIlIllllII[4]];
    lIIlIlllIll[lIIlIllllII[0]] = lllIlllIlllI("NCc/ExcsMg==", "BFMzv");
    lIIlIlllIll[lIIlIllllII[1]] = lllIlllIllll("K8+PDaUIl2o=", "SwHzx");
  }
  
  private static boolean lllIlllllIII(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllllIIlllIIIlIIllIl;
    return ??? < i;
  }
  
  public BlockWoodSlab()
  {
    lllllllllllllllllIIlllIIlIllllIl.<init>(Material.wood);
    IBlockState lllllllllllllllllIIlllIIlIllllII = blockState.getBaseState();
    if (lllIllllIIlI(lllllllllllllllllIIlllIIlIlllIll.isDouble())) {
      lllllllllllllllllIIlllIIlIllllII = lllllllllllllllllIIlllIIlIllllII.withProperty(HALF, BlockSlab.EnumBlockHalf.BOTTOM);
    }
    lllllllllllllllllIIlllIIlIlllIll.setDefaultState(lllllllllllllllllIIlllIIlIllllII.withProperty(VARIANT, BlockPlanks.EnumType.OAK));
    "".length();
  }
  
  protected BlockState createBlockState()
  {
    ;
    if (lllIllllIlll(lllllllllllllllllIIlllIIIllllllI.isDouble()))
    {
      new BlockState(lllllllllllllllllIIlllIIIlllllll, tmp23_20);
      "".length();
      if (-" ".length() < (('' + 34 - 144 + 114 ^ 45 + 22 - 32 + 139) & (0x74 ^ 0x11 ^ 0x19 ^ 0x59 ^ -" ".length()))) {
        break label134;
      }
      return null;
    }
    label134:
    return new BlockState(lllllllllllllllllIIlllIIIlllllll, new IProperty[] { HALF, VARIANT });
  }
  
  public void getSubBlocks(Item lllllllllllllllllIIlllIIlIIlllII, CreativeTabs lllllllllllllllllIIlllIIlIIllIll, List<ItemStack> lllllllllllllllllIIlllIIlIIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIllllIlII(lllllllllllllllllIIlllIIlIIlllII, Item.getItemFromBlock(Blocks.double_wooden_slab)))
    {
      lllllllllllllllllIIlllIIlIIlIlII = (lllllllllllllllllIIlllIIlIIlIIll = BlockPlanks.EnumType.values()).length;
      lllllllllllllllllIIlllIIlIIlIlIl = lIIlIllllII[0];
      "".length();
      if (((0x76 ^ 0x4F) & (0x8A ^ 0xB3 ^ 0xFFFFFFFF)) != 0) {
        return;
      }
      while (!lllIllllIlIl(lllllllllllllllllIIlllIIlIIlIlIl, lllllllllllllllllIIlllIIlIIlIlII))
      {
        BlockPlanks.EnumType lllllllllllllllllIIlllIIlIIllIIl = lllllllllllllllllIIlllIIlIIlIIll[lllllllllllllllllIIlllIIlIIlIlIl];
        new ItemStack(lllllllllllllllllIIlllIIlIIlllII, lIIlIllllII[1], lllllllllllllllllIIlllIIlIIllIIl.getMetadata());
        "".length();
      }
    }
  }
  
  private static String lllIlllIllll(String lllllllllllllllllIIlllIIIlllIIlI, String lllllllllllllllllIIlllIIIlllIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIlllIIIlllIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIlllIIIlllIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIIlllIIIlllIlII = Cipher.getInstance("Blowfish");
      lllllllllllllllllIIlllIIIlllIlII.init(lIIlIllllII[4], lllllllllllllllllIIlllIIIlllIlIl);
      return new String(lllllllllllllllllIIlllIIIlllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIlllIIIlllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIlllIIIlllIIll)
    {
      lllllllllllllllllIIlllIIIlllIIll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIllllIlll(int ???)
  {
    double lllllllllllllllllIIlllIIIlIIIIll;
    return ??? != 0;
  }
  
  public Object getVariant(ItemStack lllllllllllllllllIIlllIIlIlIIlII)
  {
    ;
    return BlockPlanks.EnumType.byMetadata(lllllllllllllllllIIlllIIlIlIIlII.getMetadata() & lIIlIllllII[2]);
  }
  
  public IProperty<?> getVariantProperty()
  {
    return VARIANT;
  }
  
  private static boolean lllIllllIlIl(int ???, int arg1)
  {
    int i;
    long lllllllllllllllllIIlllIIIlIlIIIl;
    return ??? >= i;
  }
  
  public Item getItem(World lllllllllllllllllIIlllIIlIllIIII, BlockPos lllllllllllllllllIIlllIIlIlIllll)
  {
    return Item.getItemFromBlock(Blocks.wooden_slab);
  }
  
  private static void lllIllllIIIl()
  {
    lIIlIllllII = new int[5];
    lIIlIllllII[0] = ((0x39 ^ 0x73 ^ 0xE0 ^ 0xBF) & (0x7D ^ 0x14 ^ 0x73 ^ 0xF ^ -" ".length()));
    lIIlIllllII[1] = " ".length();
    lIIlIllllII[2] = (0x8D ^ 0x8A);
    lIIlIllllII[3] = (30 + 77 - 29 + 92 ^ 82 + 80 - 131 + 131);
    lIIlIllllII[4] = "  ".length();
  }
  
  public int damageDropped(IBlockState lllllllllllllllllIIlllIIIllllIll)
  {
    ;
    return ((BlockPlanks.EnumType)lllllllllllllllllIIlllIIIllllIll.getValue(VARIANT)).getMetadata();
  }
  
  private static boolean lllIllllIllI(Object ???, Object arg1)
  {
    Object localObject;
    char lllllllllllllllllIIlllIIIlIIIlIl;
    return ??? == localObject;
  }
  
  public MapColor getMapColor(IBlockState lllllllllllllllllIIlllIIlIllIllI)
  {
    ;
    return ((BlockPlanks.EnumType)lllllllllllllllllIIlllIIlIllIllI.getValue(VARIANT)).func_181070_c();
  }
  
  public Item getItemDropped(IBlockState lllllllllllllllllIIlllIIlIllIlII, Random lllllllllllllllllIIlllIIlIllIIll, int lllllllllllllllllIIlllIIlIllIIlI)
  {
    return Item.getItemFromBlock(Blocks.wooden_slab);
  }
  
  private static String lllIlllIlllI(String lllllllllllllllllIIlllIIIllIIIlI, String lllllllllllllllllIIlllIIIlIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIlllIIIllIIIlI = new String(Base64.getDecoder().decode(lllllllllllllllllIIlllIIIllIIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIlllIIIllIIIII = new StringBuilder();
    char[] lllllllllllllllllIIlllIIIlIlllll = lllllllllllllllllIIlllIIIlIlllII.toCharArray();
    int lllllllllllllllllIIlllIIIlIllllI = lIIlIllllII[0];
    long lllllllllllllllllIIlllIIIlIllIII = lllllllllllllllllIIlllIIIllIIIlI.toCharArray();
    long lllllllllllllllllIIlllIIIlIlIlll = lllllllllllllllllIIlllIIIlIllIII.length;
    String lllllllllllllllllIIlllIIIlIlIllI = lIIlIllllII[0];
    while (lllIlllllIII(lllllllllllllllllIIlllIIIlIlIllI, lllllllllllllllllIIlllIIIlIlIlll))
    {
      char lllllllllllllllllIIlllIIIllIIIll = lllllllllllllllllIIlllIIIlIllIII[lllllllllllllllllIIlllIIIlIlIllI];
      "".length();
      "".length();
      if (-"  ".length() >= 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIIlllIIIllIIIII);
  }
  
  public int getMetaFromState(IBlockState lllllllllllllllllIIlllIIlIIIIlIl)
  {
    ;
    ;
    ;
    int lllllllllllllllllIIlllIIlIIIIlII = lIIlIllllII[0];
    lllllllllllllllllIIlllIIlIIIIlII |= ((BlockPlanks.EnumType)lllllllllllllllllIIlllIIlIIIIlIl.getValue(VARIANT)).getMetadata();
    if ((lllIllllIIlI(lllllllllllllllllIIlllIIlIIIIIll.isDouble())) && (lllIllllIllI(lllllllllllllllllIIlllIIlIIIIlIl.getValue(HALF), BlockSlab.EnumBlockHalf.TOP))) {
      lllllllllllllllllIIlllIIlIIIIlII |= lIIlIllllII[3];
    }
    return lllllllllllllllllIIlllIIlIIIIlII;
  }
  
  private static boolean lllIllllIlII(Object ???, Object arg1)
  {
    Object localObject;
    boolean lllllllllllllllllIIlllIIIlIIlIIl;
    return ??? != localObject;
  }
  
  static
  {
    lllIllllIIIl();
    lllIllllIIII();
  }
  
  private static boolean lllIllllIIlI(int ???)
  {
    String lllllllllllllllllIIlllIIIlIIIIIl;
    return ??? == 0;
  }
  
  public String getUnlocalizedName(int lllllllllllllllllIIlllIIlIlIlIIl)
  {
    ;
    ;
    return String.valueOf(new StringBuilder(String.valueOf(lllllllllllllllllIIlllIIlIlIlIlI.getUnlocalizedName())).append(lIIlIlllIll[lIIlIllllII[1]]).append(BlockPlanks.EnumType.byMetadata(lllllllllllllllllIIlllIIlIlIlIIl).getUnlocalizedName()));
  }
}

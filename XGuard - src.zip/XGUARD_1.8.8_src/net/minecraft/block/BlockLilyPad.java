package net.minecraft.block;

import java.util.List;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.init.Blocks;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class BlockLilyPad
  extends BlockBush
{
  private static boolean lllIlIllIIlIIl(int ???)
  {
    short llllllllllllllIIllIllIIlIIIllIIl;
    return ??? >= 0;
  }
  
  protected BlockLilyPad()
  {
    float llllllllllllllIIllIllIIlIllIIIII = 0.5F;
    float llllllllllllllIIllIllIIlIlIlllll = 0.015625F;
    llllllllllllllIIllIllIIlIlIllllI.setBlockBounds(0.5F - llllllllllllllIIllIllIIlIllIIIII, 0.0F, 0.5F - llllllllllllllIIllIllIIlIllIIIII, 0.5F + llllllllllllllIIllIllIIlIllIIIII, llllllllllllllIIllIllIIlIlIlllll, 0.5F + llllllllllllllIIllIllIIlIllIIIII);
    "".length();
  }
  
  public int getBlockColor()
  {
    return lIIllIIllIllI[0];
  }
  
  public int getMetaFromState(IBlockState llllllllllllllIIllIllIIlIIlIIlll)
  {
    return lIIllIIllIllI[3];
  }
  
  private static boolean lllIlIllIIIlll(int ???)
  {
    String llllllllllllllIIllIllIIlIIIllIll;
    return ??? == 0;
  }
  
  public void addCollisionBoxesToList(World llllllllllllllIIllIllIIlIlIlIIll, BlockPos llllllllllllllIIllIllIIlIlIlIIlI, IBlockState llllllllllllllIIllIllIIlIlIIlIlI, AxisAlignedBB llllllllllllllIIllIllIIlIlIlIIII, List<AxisAlignedBB> llllllllllllllIIllIllIIlIlIIllll, Entity llllllllllllllIIllIllIIlIlIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((!lllIlIllIIIllI(llllllllllllllIIllIllIIlIlIIlllI)) || (lllIlIllIIIlll(llllllllllllllIIllIllIIlIlIIlllI instanceof EntityBoat))) {
      llllllllllllllIIllIllIIlIlIIllIl.addCollisionBoxesToList(llllllllllllllIIllIllIIlIlIlIIll, llllllllllllllIIllIllIIlIlIlIIlI, llllllllllllllIIllIllIIlIlIlIIIl, llllllllllllllIIllIllIIlIlIlIIII, llllllllllllllIIllIllIIlIlIIllll, llllllllllllllIIllIllIIlIlIIlllI);
    }
  }
  
  private static boolean lllIlIllIIlIII(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllIIllIllIIlIIIlllIl;
    return ??? == localObject;
  }
  
  private static boolean lllIlIllIIIllI(Object ???)
  {
    String llllllllllllllIIllIllIIlIIlIIIIl;
    return ??? != null;
  }
  
  protected boolean canPlaceBlockOn(Block llllllllllllllIIllIllIIlIIllIlIl)
  {
    ;
    if (lllIlIllIIlIII(llllllllllllllIIllIllIIlIIllIlIl, Blocks.water)) {
      return lIIllIIllIllI[2];
    }
    return lIIllIIllIllI[3];
  }
  
  private static boolean lllIlIllIIlIlI(int ???, int arg1)
  {
    int i;
    double llllllllllllllIIllIllIIlIIlIIIll;
    return ??? < i;
  }
  
  public AxisAlignedBB getCollisionBoundingBox(World llllllllllllllIIllIllIIlIlIIIIll, BlockPos llllllllllllllIIllIllIIlIIllllll, IBlockState llllllllllllllIIllIllIIlIlIIIIIl)
  {
    ;
    ;
    return new AxisAlignedBB(llllllllllllllIIllIllIIlIlIIIIlI.getX() + minX, llllllllllllllIIllIllIIlIlIIIIlI.getY() + minY, llllllllllllllIIllIllIIlIlIIIIlI.getZ() + minZ, llllllllllllllIIllIllIIlIlIIIIlI.getX() + maxX, llllllllllllllIIllIllIIlIlIIIIlI.getY() + maxY, llllllllllllllIIllIllIIlIlIIIIlI.getZ() + maxZ);
  }
  
  public boolean canBlockStay(World llllllllllllllIIllIllIIlIIlIlIll, BlockPos llllllllllllllIIllIllIIlIIlIlllI, IBlockState llllllllllllllIIllIllIIlIIlIllIl)
  {
    ;
    ;
    ;
    if ((lllIlIllIIlIIl(llllllllllllllIIllIllIIlIIlIlllI.getY())) && (lllIlIllIIlIlI(llllllllllllllIIllIllIIlIIlIlIlI.getY(), lIIllIIllIllI[4])))
    {
      IBlockState llllllllllllllIIllIllIIlIIlIllII = llllllllllllllIIllIllIIlIIlIlIll.getBlockState(llllllllllllllIIllIllIIlIIlIlIlI.down());
      if ((lllIlIllIIlIII(llllllllllllllIIllIllIIlIIlIllII.getBlock().getMaterial(), Material.water)) && (lllIlIllIIIlll(((Integer)llllllllllllllIIllIllIIlIIlIllII.getValue(BlockLiquid.LEVEL)).intValue()))) {
        return lIIllIIllIllI[2];
      }
      return lIIllIIllIllI[3];
    }
    return lIIllIIllIllI[3];
  }
  
  static {}
  
  public int getRenderColor(IBlockState llllllllllllllIIllIllIIlIIllllII)
  {
    return lIIllIIllIllI[0];
  }
  
  private static void lllIlIllIIIlIl()
  {
    lIIllIIllIllI = new int[5];
    lIIllIIllIllI[0] = (0xD75E & 0x71EBFD);
    lIIllIIllIllI[1] = (-(0xBFCF & 0x7EB9) & 0xBFFA & 0x20FEBD);
    lIIllIIllIllI[2] = " ".length();
    lIIllIIllIllI[3] = ((0x60 ^ 0x74 ^ 0x32 ^ 0x2F) & ('¬' + 10 - 84 + 80 ^ 127 + '' - 222 + 141 ^ -" ".length()));
    lIIllIIllIllI[4] = (0xB72E & 0x49D1);
  }
  
  public int colorMultiplier(IBlockAccess llllllllllllllIIllIllIIlIIlllIlI, BlockPos llllllllllllllIIllIllIIlIIlllIIl, int llllllllllllllIIllIllIIlIIlllIII)
  {
    return lIIllIIllIllI[1];
  }
}

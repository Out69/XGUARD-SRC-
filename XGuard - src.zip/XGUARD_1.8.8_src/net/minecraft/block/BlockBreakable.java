package net.minecraft.block;

import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.world.IBlockAccess;

public class BlockBreakable
  extends Block
{
  public boolean shouldSideBeRendered(IBlockAccess lllllllllllllllIIlIllllIlllIIIIl, BlockPos lllllllllllllllIIlIllllIlllIIIII, EnumFacing lllllllllllllllIIlIllllIllIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState lllllllllllllllIIlIllllIllIllllI = lllllllllllllllIIlIllllIlllIIIIl.getBlockState(lllllllllllllllIIlIllllIlllIIIII);
    Block lllllllllllllllIIlIllllIllIlllIl = lllllllllllllllIIlIllllIllIllllI.getBlock();
    if ((!lIIIllIlIlllII(lllllllllllllllIIlIllllIlllIIIlI, Blocks.glass)) || (lIIIllIlIlllIl(lllllllllllllllIIlIllllIlllIIIlI, Blocks.stained_glass)))
    {
      if (lIIIllIlIlllII(lllllllllllllllIIlIllllIlllIIIIl.getBlockState(lllllllllllllllIIlIllllIlllIIIII.offset(lllllllllllllllIIlIllllIllIllIIl.getOpposite())), lllllllllllllllIIlIllllIllIllllI)) {
        return lIlllIIIIIIl[1];
      }
      if (lIIIllIlIlllIl(lllllllllllllllIIlIllllIllIlllIl, lllllllllllllllIIlIllllIlllIIIlI)) {
        return lIlllIIIIIIl[0];
      }
    }
    if ((lIIIllIlIllllI(ignoreSimilarity)) && (lIIIllIlIlllIl(lllllllllllllllIIlIllllIllIlllIl, lllllllllllllllIIlIllllIlllIIIlI)))
    {
      "".length();
      if ((0xBA ^ 0xBE) >= 0) {
        break label144;
      }
      return (0x58 ^ 0x68) & (0x8D ^ 0xBD ^ 0xFFFFFFFF);
    }
    label144:
    return lllllllllllllllIIlIllllIlllIIIlI.shouldSideBeRendered(lllllllllllllllIIlIllllIlllIIIIl, lllllllllllllllIIlIllllIlllIIIII, lllllllllllllllIIlIllllIllIllIIl);
  }
  
  private static boolean lIIIllIlIlllIl(Object ???, Object arg1)
  {
    Object localObject;
    boolean lllllllllllllllIIlIllllIllIIllll;
    return ??? == localObject;
  }
  
  private static void lIIIllIlIllIll()
  {
    lIlllIIIIIIl = new int[2];
    lIlllIIIIIIl[0] = ((0x52 ^ 0x64 ^ 0x4B ^ 0x41) & (0x6B ^ 0x1E ^ 0x2E ^ 0x67 ^ -" ".length()));
    lIlllIIIIIIl[1] = " ".length();
  }
  
  private static boolean lIIIllIlIllllI(int ???)
  {
    byte lllllllllllllllIIlIllllIllIIllIl;
    return ??? == 0;
  }
  
  private static boolean lIIIllIlIlllII(Object ???, Object arg1)
  {
    Object localObject;
    byte lllllllllllllllIIlIllllIllIlIIll;
    return ??? != localObject;
  }
  
  public boolean isOpaqueCube()
  {
    return lIlllIIIIIIl[0];
  }
  
  static {}
  
  protected BlockBreakable(Material lllllllllllllllIIlIllllIlllIllII, boolean lllllllllllllllIIlIllllIlllIlIll, MapColor lllllllllllllllIIlIllllIlllIlIlI)
  {
    lllllllllllllllIIlIllllIllllIIIl.<init>(lllllllllllllllIIlIllllIlllIllII, lllllllllllllllIIlIllllIlllIlIlI);
    ignoreSimilarity = lllllllllllllllIIlIllllIlllIlIll;
  }
  
  protected BlockBreakable(Material lllllllllllllllIIlIllllIlllllIlI, boolean lllllllllllllllIIlIllllIllllIllI)
  {
    lllllllllllllllIIlIllllIlllllIII.<init>(lllllllllllllllIIlIllllIllllIlll, lllllllllllllllIIlIllllIllllIllI, lllllllllllllllIIlIllllIllllIlll.getMaterialMapColor());
  }
}

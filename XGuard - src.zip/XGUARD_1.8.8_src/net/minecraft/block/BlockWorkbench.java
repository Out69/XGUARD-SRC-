package net.minecraft.block;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerWorkbench;
import net.minecraft.stats.StatList;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.World;

public class BlockWorkbench
  extends Block
{
  static {}
  
  protected BlockWorkbench()
  {
    lllllllllllllllIlIIIIlIlIIlIIIII.<init>(Material.wood);
    "".length();
  }
  
  private static boolean lIIIIIlllIIIIl(int ???)
  {
    boolean lllllllllllllllIlIIIIlIlIIIIlIII;
    return ??? != 0;
  }
  
  private static void lIIIIIlllIIIII()
  {
    lIlIlIIlIIIl = new int[1];
    lIlIlIIlIIIl[0] = " ".length();
  }
  
  public boolean onBlockActivated(World lllllllllllllllIlIIIIlIlIIIlIIlI, BlockPos lllllllllllllllIlIIIIlIlIIIllIIl, IBlockState lllllllllllllllIlIIIIlIlIIIllIII, EntityPlayer lllllllllllllllIlIIIIlIlIIIlIlll, EnumFacing lllllllllllllllIlIIIIlIlIIIlIllI, float lllllllllllllllIlIIIIlIlIIIlIlIl, float lllllllllllllllIlIIIIlIlIIIlIlII, float lllllllllllllllIlIIIIlIlIIIlIIll)
  {
    ;
    ;
    ;
    if (lIIIIIlllIIIIl(isRemote)) {
      return lIlIlIIlIIIl[0];
    }
    lllllllllllllllIlIIIIlIlIIIlIlll.displayGui(new InterfaceCraftingTable(lllllllllllllllIlIIIIlIlIIIlIIlI, lllllllllllllllIlIIIIlIlIIIllIIl));
    lllllllllllllllIlIIIIlIlIIIlIlll.triggerAchievement(StatList.field_181742_Z);
    return lIlIlIIlIIIl[0];
  }
  
  public static class InterfaceCraftingTable
    implements IInteractionObject
  {
    public boolean hasCustomName()
    {
      return lIIlllIIIlIII[0];
    }
    
    private static void lllIllIllIlllI()
    {
      lIIlllIIIIlll = new String[lIIlllIIIlIII[2]];
      lIIlllIIIIlll[lIIlllIIIlIII[0]] = lllIllIllIllIl("a5m0lr8NJ/8=", "ldqiA");
      lIIlllIIIIlll[lIIlllIIIlIII[1]] = lllIllIllIllIl("5U5iEKtc4Nwm4xKvCSkR7QHc8jlTdI3hmINQqdfjHO4=", "ZAURR");
    }
    
    private static String lllIllIllIllIl(String llllllllllllllIIllIIlllIIIIllIIl, String llllllllllllllIIllIIlllIIIIllIII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIIllIIlllIIIIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllIIlllIIIIllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIIllIIlllIIIIllIll = Cipher.getInstance("Blowfish");
        llllllllllllllIIllIIlllIIIIllIll.init(lIIlllIIIlIII[2], llllllllllllllIIllIIlllIIIIlllII);
        return new String(llllllllllllllIIllIIlllIIIIllIll.doFinal(Base64.getDecoder().decode(llllllllllllllIIllIIlllIIIIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIIllIIlllIIIIllIlI)
      {
        llllllllllllllIIllIIlllIIIIllIlI.printStackTrace();
      }
      return null;
    }
    
    private static void lllIllIllIllll()
    {
      lIIlllIIIlIII = new int[3];
      lIIlllIIIlIII[0] = ((0xA2 ^ 0x8D) & (0x81 ^ 0xAE ^ 0xFFFFFFFF));
      lIIlllIIIlIII[1] = " ".length();
      lIIlllIIIlIII[2] = "  ".length();
    }
    
    public InterfaceCraftingTable(World llllllllllllllIIllIIlllIIIllIIII, BlockPos llllllllllllllIIllIIlllIIIlIllll)
    {
      world = llllllllllllllIIllIIlllIIIlIllIl;
      position = llllllllllllllIIllIIlllIIIlIllll;
    }
    
    static
    {
      lllIllIllIllll();
      lllIllIllIlllI();
    }
    
    public Container createContainer(InventoryPlayer llllllllllllllIIllIIlllIIIlIIlIl, EntityPlayer llllllllllllllIIllIIlllIIIlIIlII)
    {
      ;
      ;
      return new ContainerWorkbench(llllllllllllllIIllIIlllIIIlIIIlI, world, position);
    }
    
    public String getName()
    {
      return null;
    }
    
    public IChatComponent getDisplayName()
    {
      return new ChatComponentTranslation(String.valueOf(new StringBuilder(String.valueOf(Blocks.crafting_table.getUnlocalizedName())).append(lIIlllIIIIlll[lIIlllIIIlIII[0]])), new Object[lIIlllIIIlIII[0]]);
    }
    
    public String getGuiID()
    {
      return lIIlllIIIIlll[lIIlllIIIlIII[1]];
    }
  }
}

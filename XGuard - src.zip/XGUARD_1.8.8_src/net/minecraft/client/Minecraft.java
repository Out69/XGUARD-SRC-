package net.minecraft.client;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListenableFutureTask;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.properties.Property;
import com.mojang.authlib.properties.PropertyMap;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.Proxy;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.imageio.ImageIO;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.audio.MusicTicker;
import net.minecraft.client.audio.MusicTicker.MusicType;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiControls;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiMemoryErrorScreen;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSleepMP;
import net.minecraft.client.gui.GuiSpectator;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.gui.MapItemRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.achievement.GuiAchievement;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.gui.stream.GuiStreamUnavailable;
import net.minecraft.client.main.GameConfiguration;
import net.minecraft.client.main.GameConfiguration.DisplayInformation;
import net.minecraft.client.main.GameConfiguration.FolderInformation;
import net.minecraft.client.main.GameConfiguration.GameInformation;
import net.minecraft.client.main.GameConfiguration.ServerInformation;
import net.minecraft.client.main.GameConfiguration.UserInformation;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerLoginClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.particle.EffectRenderer;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.DefaultResourcePack;
import net.minecraft.client.resources.FoliageColorReloadListener;
import net.minecraft.client.resources.GrassColorReloadListener;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.IReloadableResourceManager;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourcePack;
import net.minecraft.client.resources.Language;
import net.minecraft.client.resources.LanguageManager;
import net.minecraft.client.resources.ResourceIndex;
import net.minecraft.client.resources.ResourcePackRepository;
import net.minecraft.client.resources.ResourcePackRepository.Entry;
import net.minecraft.client.resources.SimpleReloadableResourceManager;
import net.minecraft.client.resources.SkinManager;
import net.minecraft.client.resources.data.AnimationMetadataSection;
import net.minecraft.client.resources.data.AnimationMetadataSectionSerializer;
import net.minecraft.client.resources.data.FontMetadataSection;
import net.minecraft.client.resources.data.FontMetadataSectionSerializer;
import net.minecraft.client.resources.data.IMetadataSerializer;
import net.minecraft.client.resources.data.LanguageMetadataSection;
import net.minecraft.client.resources.data.LanguageMetadataSectionSerializer;
import net.minecraft.client.resources.data.PackMetadataSection;
import net.minecraft.client.resources.data.PackMetadataSectionSerializer;
import net.minecraft.client.resources.data.TextureMetadataSection;
import net.minecraft.client.resources.data.TextureMetadataSectionSerializer;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.GameSettings.Options;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.client.stream.IStream;
import net.minecraft.client.stream.NullStream;
import net.minecraft.client.stream.TwitchStream;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.DataWatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLeashKnot;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.boss.BossStatus;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.item.EntityPainting;
import net.minecraft.entity.player.EntityPlayer.EnumChatVisibility;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.init.Bootstrap;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.NetworkSystem;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.login.client.C00PacketLoginStart;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.network.play.client.C16PacketClientStatus.EnumState;
import net.minecraft.profiler.IPlayerUsage;
import net.minecraft.profiler.PlayerUsageSnooper;
import net.minecraft.profiler.Profiler;
import net.minecraft.profiler.Profiler.Result;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.stats.IStatStringFormat;
import net.minecraft.stats.StatFileWriter;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.FrameTimer;
import net.minecraft.util.IThreadListener;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MinecraftError;
import net.minecraft.util.MouseHelper;
import net.minecraft.util.MovementInputFromOptions;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.util.ReportedException;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.ScreenShotHelper;
import net.minecraft.util.Session;
import net.minecraft.util.Timer;
import net.minecraft.util.Util;
import net.minecraft.util.Util.EnumOS;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraft.world.WorldProviderEnd;
import net.minecraft.world.WorldProviderHell;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.chunk.storage.AnvilSaveConverter;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.ISaveHandler;
import net.minecraft.world.storage.WorldInfo;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.opengl.OpenGLException;
import org.lwjgl.opengl.PixelFormat;
import org.lwjgl.util.glu.GLU;
import pl.xguard.base.XGUARD;
import pl.xguard.blacklist.BlacklistManage;
import pl.xguard.gui.GuiInGameHook;
import pl.xguard.gui.GuiUpdateCheck;
import pl.xguard.loaders.ItemMadufakaSrakaManager;
import pl.xguard.loaders.OgunekManager;
import pl.xguard.loaders.WingsManager;
import pl.xguard.utils.ConnectionUtils;

public class Minecraft
  implements IThreadListener, IPlayerUsage
{
  public void runTick()
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIlIIIlI(rightClickDelayTimer)) {
      rightClickDelayTimer -= llllIIll[1];
    }
    mcProfiler.startSection(llIlIlII[llllIIll[118]]);
    if (llIIlIIlIl(isGamePaused)) {
      ingameGUI.updateTick();
    }
    mcProfiler.endSection();
    entityRenderer.getMouseOver(1.0F);
    mcProfiler.startSection(llIlIlII[llllIIll[119]]);
    if ((llIIlIIlIl(isGamePaused)) && (llIIlIIIll(theWorld))) {
      playerController.updateController();
    }
    mcProfiler.endStartSection(llIlIlII[llllIIll[120]]);
    if (llIIlIIlIl(isGamePaused)) {
      renderEngine.tick();
    }
    if ((llIIlIIIIl(currentScreen)) && (llIIlIIIll(thePlayer)))
    {
      if (llIIlIlIlI(llIIllIIlI(thePlayer.getHealth(), 0.0F)))
      {
        lIIlllIIIlIlIll.displayGuiScreen(null);
        "".length();
        if (-(0x29 ^ 0x2D) <= 0) {}
      }
      else if ((llIIlIIlII(thePlayer.isPlayerSleeping())) && (llIIlIIIll(theWorld)))
      {
        lIIlllIIIlIlIll.displayGuiScreen(new GuiSleepMP());
        "".length();
        if (null == null) {}
      }
    }
    else if ((llIIlIIIll(currentScreen)) && (llIIlIIlII(currentScreen instanceof GuiSleepMP)) && (llIIlIIlIl(thePlayer.isPlayerSleeping()))) {
      lIIlllIIIlIlIll.displayGuiScreen(null);
    }
    if (llIIlIIIll(currentScreen)) {
      leftClickCounter = llllIIll[114];
    }
    if (llIIlIIIll(currentScreen))
    {
      try
      {
        currentScreen.handleInput();
        "".length();
        if ("   ".length() <= "  ".length()) {
          return;
        }
      }
      catch (Throwable lIIlllIIIllllII)
      {
        CrashReport lIIlllIIIlllIll = CrashReport.makeCrashReport(lIIlllIIIllllII, llIlIlII[llllIIll[121]]);
        CrashReportCategory lIIlllIIIlllIlI = lIIlllIIIlllIll.makeCategory(llIlIlII[llllIIll[122]]);
        lIIlllIIIlllIlI.addCrashSectionCallable(llIlIlII[llllIIll[123]], new Callable()
        {
          public String call()
            throws Exception
          {
            ;
            return currentScreen.getClass().getCanonicalName();
          }
        });
        throw new ReportedException(lIIlllIIIlllIll);
      }
      if (llIIlIIIll(currentScreen)) {
        try
        {
          currentScreen.updateScreen();
          "".length();
          if (-" ".length() != -" ".length()) {
            return;
          }
        }
        catch (Throwable lIIlllIIIlllIIl)
        {
          CrashReport lIIlllIIIlllIII = CrashReport.makeCrashReport(lIIlllIIIlllIIl, llIlIlII[llllIIll[124]]);
          CrashReportCategory lIIlllIIIllIlll = lIIlllIIIlllIII.makeCategory(llIlIlII[llllIIll[125]]);
          lIIlllIIIllIlll.addCrashSectionCallable(llIlIlII[llllIIll[126]], new Callable()
          {
            public String call()
              throws Exception
            {
              ;
              return currentScreen.getClass().getCanonicalName();
            }
          });
          throw new ReportedException(lIIlllIIIlllIII);
        }
      }
    }
    if ((!llIIlIIIll(currentScreen)) || (llIIlIIlII(currentScreen.allowUserInput)))
    {
      mcProfiler.endStartSection(llIlIlII[llllIIll[127]]);
      "".length();
      if (" ".length() <= 0) {
        return;
      }
      label766:
      while (!llIIlIIlIl(Mouse.next()))
      {
        int lIIlllIIIllIllI = Mouse.getEventButton();
        KeyBinding.setKeyBindState(lIIlllIIIllIllI - llllIIll[121], Mouse.getEventButtonState());
        if (llIIlIIlII(Mouse.getEventButtonState())) {
          if ((llIIlIIlII(thePlayer.isSpectator())) && (llIIlIlIII(lIIlllIIIllIllI, llllIIll[3])))
          {
            ingameGUI.getSpectatorGui().func_175261_b();
            "".length();
            if ("   ".length() > " ".length()) {}
          }
          else
          {
            KeyBinding.onTick(lIIlllIIIllIllI - llllIIll[121]);
          }
        }
        long lIIlllIIIllIlIl = getSystemTime() - systemTime;
        if (llIIlIlIlI(llIIllIIll(lIIlllIIIllIlIl, 200L)))
        {
          int lIIlllIIIllIlII = Mouse.getEventDWheel();
          if (llIIlIIlII(lIIlllIIIllIlII)) {
            if (llIIlIIlII(thePlayer.isSpectator()))
            {
              if (llIIlIlllI(lIIlllIIIllIlII))
              {
                "".length();
                if ("  ".length() < "   ".length()) {
                  break label766;
                }
              }
              lIIlllIIIllIlII = llllIIll[1];
              if (llIIlIIlII(ingameGUI.getSpectatorGui().func_175262_a()))
              {
                ingameGUI.getSpectatorGui().func_175259_b(-lIIlllIIIllIlII);
                "".length();
                if (-"  ".length() <= 0) {}
              }
              else
              {
                float lIIlllIIIllIIll = MathHelper.clamp_float(thePlayer.capabilities.getFlySpeed() + lIIlllIIIllIlII * 0.005F, 0.0F, 0.2F);
                thePlayer.capabilities.setFlySpeed(lIIlllIIIllIIll);
                "".length();
                if (-(0x4C ^ 0x14 ^ 0x69 ^ 0x35) <= 0) {}
              }
            }
            else
            {
              thePlayer.inventory.changeCurrentItem(lIIlllIIIllIlII);
            }
          }
          if (llIIlIIIIl(currentScreen))
          {
            if ((llIIlIIlIl(inGameHasFocus)) && (llIIlIIlII(Mouse.getEventButtonState())))
            {
              lIIlllIIIlIlIll.setIngameFocus();
              "".length();
              if ("   ".length() == "   ".length()) {}
            }
          }
          else if (llIIlIIIll(currentScreen)) {
            currentScreen.handleMouseInput();
          }
        }
      }
      if (llIIlIIIlI(leftClickCounter)) {
        leftClickCounter -= llllIIll[1];
      }
      mcProfiler.endStartSection(llIlIlII[llllIIll['']]);
      "".length();
      if (" ".length() == "   ".length()) {
        return;
      }
      label1082:
      label1732:
      label1850:
      label1932:
      label2007:
      label2076:
      label2142:
      label2352:
      while (!llIIlIIlIl(Keyboard.next()))
      {
        if (llIIlIIlIl(Keyboard.getEventKey()))
        {
          "".length();
          if ("   ".length() >= -" ".length()) {
            break label1082;
          }
        }
        int lIIlllIIIllIIlI = Keyboard.getEventKey();
        KeyBinding.setKeyBindState(lIIlllIIIllIIlI, Keyboard.getEventKeyState());
        if (llIIlIIlII(Keyboard.getEventKeyState())) {
          KeyBinding.onTick(lIIlllIIIllIIlI);
        }
        if (llIIlIIIlI(llIIllIIll(debugCrashKeyPressTime, 0L)))
        {
          if (llIIllIIII(llIIllIIll(getSystemTime() - debugCrashKeyPressTime, 6000L))) {
            throw new ReportedException(new CrashReport(llIlIlII[llllIIll['']], new Throwable()));
          }
          if ((!llIIlIIlII(Keyboard.isKeyDown(llllIIll[61]))) || (llIIlIIlIl(Keyboard.isKeyDown(llllIIll[77]))))
          {
            debugCrashKeyPressTime = -1L;
            "".length();
            if ((((0x31 ^ 0x3B) & (0x62 ^ 0x68 ^ 0xFFFFFFFF) ^ 0x77 ^ 0x35) & (61 + '' - 182 + 177 ^ 51 + 90 - 36 + 25 ^ -" ".length())) == 0) {}
          }
        }
        else if ((llIIlIIlII(Keyboard.isKeyDown(llllIIll[61]))) && (llIIlIIlII(Keyboard.isKeyDown(llllIIll[77]))))
        {
          debugCrashKeyPressTime = getSystemTime();
        }
        lIIlllIIIlIlIll.dispatchKeypresses();
        if (llIIlIIlII(Keyboard.getEventKeyState()))
        {
          if ((llIIlIlIII(lIIlllIIIllIIlI, llllIIll[78])) && (llIIlIIIll(entityRenderer))) {
            entityRenderer.switchUseShader();
          }
          if (llIIlIIIll(currentScreen))
          {
            currentScreen.handleKeyboardInput();
            "".length();
            if ("  ".length() <= "   ".length()) {}
          }
          else
          {
            if (llIIlIlIII(lIIlllIIIllIIlI, llllIIll[1])) {
              lIIlllIIIlIlIll.displayInGameMenu();
            }
            if ((llIIlIlIII(lIIlllIIIllIIlI, llllIIll[43])) && (llIIlIIlII(Keyboard.isKeyDown(llllIIll[77]))) && (llIIlIIIll(ingameGUI))) {
              ingameGUI.getChatGUI().clearChatMessages();
            }
            if ((llIIlIlIII(lIIlllIIIllIIlI, llllIIll[42])) && (llIIlIIlII(Keyboard.isKeyDown(llllIIll[77])))) {
              lIIlllIIIlIlIll.refreshResources();
            }
            if (((!llIIlIlIII(lIIlllIIIllIIlI, llllIIll[22])) || (!llIIlIIlII(Keyboard.isKeyDown(llllIIll[77])))) || (((!llIIlIlIII(lIIlllIIIllIIlI, llllIIll[23])) || (!llIIlIIlII(Keyboard.isKeyDown(llllIIll[77])))) || (((!llIIlIlIII(lIIlllIIIllIIlI, llllIIll[62])) || (!llIIlIIlII(Keyboard.isKeyDown(llllIIll[77])))) || (((!llIIlIlIII(lIIlllIIIllIIlI, llllIIll[49])) || (!llIIlIIlII(Keyboard.isKeyDown(llllIIll[77])))) || (((!llIIlIlIII(lIIlllIIIllIIlI, llllIIll[33])) || (!llIIlIIlII(Keyboard.isKeyDown(llllIIll[77])))) || ((llIIlIlIII(lIIlllIIIllIIlI, llllIIll[31])) && (llIIlIIlII(Keyboard.isKeyDown(llllIIll[77]))))))))) {
              lIIlllIIIlIlIll.refreshResources();
            }
            if ((llIIlIlIII(lIIlllIIIllIIlI, llllIIll[44])) && (llIIlIIlII(Keyboard.isKeyDown(llllIIll[77]))))
            {
              if (llIIlIIlII(GuiScreen.isShiftKeyDown()))
              {
                "".length();
                if (-(0x7A ^ 0x7E) < 0) {
                  break label1732;
                }
              }
              GameSettings.Options.RENDER_DISTANCE.setOptionValue(llllIIll[50], llllIIll[1]);
            }
            if ((llIIlIlIII(lIIlllIIIllIIlI, llllIIll[41])) && (llIIlIIlII(Keyboard.isKeyDown(llllIIll[77])))) {
              renderGlobal.loadRenderers();
            }
            if ((llIIlIlIII(lIIlllIIIllIIlI, llllIIll[46])) && (llIIlIIlII(Keyboard.isKeyDown(llllIIll[77]))))
            {
              if (llIIlIIlII(gameSettings.advancedItemTooltips))
              {
                "".length();
                if (-" ".length() == -" ".length()) {
                  break label1850;
                }
              }
              llllIIll0advancedItemTooltips = llllIIll[1];
              gameSettings.saveOptions();
            }
            if ((llIIlIlIII(lIIlllIIIllIIlI, llllIIll[63])) && (llIIlIIlII(Keyboard.isKeyDown(llllIIll[77]))))
            {
              if (llIIlIIlII(renderManager.isDebugBoundingBox()))
              {
                "".length();
                if (" ".length() >= 0) {
                  break label1932;
                }
              }
              llllIIll[0].setDebugBoundingBox(llllIIll[1]);
            }
            if ((llIIlIlIII(lIIlllIIIllIIlI, llllIIll[36])) && (llIIlIIlII(Keyboard.isKeyDown(llllIIll[77]))))
            {
              if (llIIlIIlII(gameSettings.pauseOnLostFocus))
              {
                "".length();
                if (" ".length() != 0) {
                  break label2007;
                }
              }
              llllIIll0pauseOnLostFocus = llllIIll[1];
              gameSettings.saveOptions();
            }
            if (llIIlIlIII(lIIlllIIIllIIlI, llllIIll[75]))
            {
              if (llIIlIIlII(gameSettings.hideGUI))
              {
                "".length();
                if (-(0x95 ^ 0x90) < 0) {
                  break label2076;
                }
              }
              llllIIll0hideGUI = llllIIll[1];
            }
            if (llIIlIlIII(lIIlllIIIllIIlI, llllIIll[77]))
            {
              if (llIIlIIlII(gameSettings.showDebugInfo))
              {
                "".length();
                if (" ".length() < "  ".length()) {
                  break label2142;
                }
              }
              llllIIll0showDebugInfo = llllIIll[1];
              gameSettings.showDebugProfilerChart = GuiScreen.isShiftKeyDown();
              gameSettings.field_181657_aC = GuiScreen.isAltKeyDown();
            }
            if (llIIlIIlII(gameSettings.keyBindTogglePerspective.isPressed()))
            {
              gameSettings.thirdPersonView += llllIIll[1];
              if (llIIllIlII(gameSettings.thirdPersonView, llllIIll[3])) {
                gameSettings.thirdPersonView = llllIIll[0];
              }
              if (llIIlIIlIl(gameSettings.thirdPersonView))
              {
                entityRenderer.loadEntityShader(lIIlllIIIlIlIll.getRenderViewEntity());
                "".length();
                if (null == null) {}
              }
              else if (llIIlIlIII(gameSettings.thirdPersonView, llllIIll[1]))
              {
                entityRenderer.loadEntityShader(null);
              }
              renderGlobal.setDisplayListEntitiesDirty();
            }
            if (llIIlIIlII(gameSettings.keyBindSmoothCamera.isPressed()))
            {
              if (llIIlIIlII(gameSettings.smoothCamera))
              {
                "".length();
                if (null == null) {
                  break label2352;
                }
              }
              llllIIll0smoothCamera = llllIIll[1];
            }
          }
          if ((llIIlIIlII(gameSettings.showDebugInfo)) && (llIIlIIlII(gameSettings.showDebugProfilerChart)))
          {
            if (llIIlIlIII(lIIlllIIIllIIlI, llllIIll[16])) {
              lIIlllIIIlIlIll.updateDebugProfilerName(llllIIll[0]);
            }
            int lIIlllIIIllIIIl = llllIIll[0];
            "".length();
            if ((0x73 ^ 0x12 ^ 0x45 ^ 0x20) <= 0) {
              return;
            }
            while (!llIIlIIlll(lIIlllIIIllIIIl, llllIIll[14]))
            {
              if (llIIlIlIII(lIIlllIIIllIIlI, llllIIll[3] + lIIlllIIIllIIIl)) {
                lIIlllIIIlIlIll.updateDebugProfilerName(lIIlllIIIllIIIl + llllIIll[1]);
              }
              lIIlllIIIllIIIl++;
            }
          }
        }
      }
      int lIIlllIIIllIIII = llllIIll[0];
      "".length();
      if ((34 + '¤' - 110 + 81 ^ 'ª' + 25 - 158 + 136) <= "   ".length()) {
        return;
      }
      while (!llIIlIIlll(lIIlllIIIllIIII, llllIIll[14]))
      {
        if (llIIlIIlII(gameSettings.keyBindsHotbar[lIIlllIIIllIIII].isPressed())) {
          if (llIIlIIlII(thePlayer.isSpectator()))
          {
            ingameGUI.getSpectatorGui().func_175260_a(lIIlllIIIllIIII);
            "".length();
            if ((0x4D ^ 0x49) >= "  ".length()) {}
          }
          else
          {
            thePlayer.inventory.currentItem = lIIlllIIIllIIII;
          }
        }
        lIIlllIIIllIIII++;
      }
      if (llIIlIIllI(gameSettings.chatVisibility, EntityPlayer.EnumChatVisibility.HIDDEN))
      {
        "".length();
        if (null == null) {
          break label2660;
        }
      }
      label2660:
      boolean lIIlllIIIlIllll = llllIIll[0];
      "".length();
      if ((34 + 15 - 4 + 82 ^ 0xE8 ^ 0x93) < 0) {
        return;
      }
      while (!llIIlIIlIl(gameSettings.keyBindInventory.isPressed())) {
        if (llIIlIIlII(playerController.isRidingHorse()))
        {
          thePlayer.sendHorseInventory();
          "".length();
          if ((0x73 ^ 0x49 ^ 0x6E ^ 0x50) != -" ".length()) {}
        }
        else
        {
          lIIlllIIIlIlIll.getNetHandler().addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.OPEN_INVENTORY_ACHIEVEMENT));
          lIIlllIIIlIlIll.displayGuiScreen(new GuiInventory(thePlayer));
        }
      }
      "".length();
      if (null != null) {
        return;
      }
      while (!llIIlIIlIl(gameSettings.keyBindDrop.isPressed())) {
        if (llIIlIIlIl(thePlayer.isSpectator())) {
          "".length();
        }
      }
      "".length();
      if (((87 + 116 - 115 + 105 ^ '' + 28 - 59 + 33) & (2 + 13 - 65405 + 78 ^ '' + '' - 221 + 101 ^ -" ".length())) > "  ".length()) {
        return;
      }
      while ((llIIlIIlII(gameSettings.keyBindChat.isPressed())) && (!llIIlIIlIl(lIIlllIIIlIllll))) {
        lIIlllIIIlIlIll.displayGuiScreen(new GuiChat());
      }
      if ((llIIlIIIIl(currentScreen)) && (llIIlIIlII(gameSettings.keyBindCommand.isPressed())) && (llIIlIIlII(lIIlllIIIlIllll))) {
        lIIlllIIIlIlIll.displayGuiScreen(new GuiChat(llIlIlII[llllIIll['']]));
      }
      if (llIIlIIlII(thePlayer.isUsingItem()))
      {
        if (llIIlIIlIl(gameSettings.keyBindUseItem.isKeyDown())) {
          playerController.onStoppedUsingItem(thePlayer);
        }
        while (!llIIlIIlIl(gameSettings.keyBindAttack.isPressed())) {}
        while (!llIIlIIlIl(gameSettings.keyBindUseItem.isPressed())) {}
        while (!llIIlIIlIl(gameSettings.keyBindPickBlock.isPressed())) {}
        "".length();
        if (" ".length() > ((0x71 ^ 0x49 ^ 0x1E ^ 0x63) & (50 + '­' - 192 + 192 ^ '' + 49 - 135 + 99 ^ -" ".length()))) {}
      }
      else
      {
        while (!llIIlIIlIl(gameSettings.keyBindAttack.isPressed())) {
          lIIlllIIIlIlIll.clickMouse();
        }
        "".length();
        if (((0x4F ^ 0x52) & (0x18 ^ 0x5 ^ 0xFFFFFFFF)) != 0) {
          return;
        }
        while (!llIIlIIlIl(gameSettings.keyBindUseItem.isPressed())) {
          lIIlllIIIlIlIll.rightClickMouse();
        }
        "".length();
        if ("   ".length() <= (("   ".length() ^ 0x9B ^ 0xAB) & (0xD9 ^ 0xC2 ^ 0x9 ^ 0x21 ^ -" ".length()))) {
          return;
        }
        while (!llIIlIIlIl(gameSettings.keyBindPickBlock.isPressed())) {
          lIIlllIIIlIlIll.middleClickMouse();
        }
      }
      if ((llIIlIIlII(gameSettings.keyBindUseItem.isKeyDown())) && (llIIlIIlIl(rightClickDelayTimer)) && (llIIlIIlIl(thePlayer.isUsingItem()))) {
        lIIlllIIIlIlIll.rightClickMouse();
      }
      if ((llIIlIIIIl(currentScreen)) && (llIIlIIlII(gameSettings.keyBindAttack.isKeyDown())) && (llIIlIIlII(inGameHasFocus)))
      {
        "".length();
        if (" ".length() != 0) {
          break label3406;
        }
      }
      label3406:
      llllIIll[1].sendClickBlockToController(llllIIll[0]);
    }
    if (llIIlIIIll(theWorld))
    {
      if (llIIlIIIll(thePlayer))
      {
        joinPlayerCounter += llllIIll[1];
        if (llIIlIlIII(joinPlayerCounter, llllIIll[41]))
        {
          joinPlayerCounter = llllIIll[0];
          theWorld.joinEntityInSurroundings(thePlayer);
        }
      }
      mcProfiler.endStartSection(llIlIlII[llllIIll['']]);
      if (llIIlIIlIl(isGamePaused)) {
        entityRenderer.updateRenderer();
      }
      mcProfiler.endStartSection(llIlIlII[llllIIll['']]);
      if (llIIlIIlIl(isGamePaused)) {
        renderGlobal.updateClouds();
      }
      mcProfiler.endStartSection(llIlIlII[llllIIll['']]);
      if (llIIlIIlIl(isGamePaused))
      {
        if (llIIlIIIlI(theWorld.getLastLightningBolt())) {
          theWorld.setLastLightningBolt(theWorld.getLastLightningBolt() - llllIIll[1]);
        }
        theWorld.updateEntities();
        "".length();
        if (-" ".length() <= "  ".length()) {}
      }
    }
    else if (llIIlIIlII(entityRenderer.isShaderActive()))
    {
      entityRenderer.func_181022_b();
    }
    if (llIIlIIlIl(isGamePaused))
    {
      mcMusicTicker.update();
      mcSoundHandler.update();
    }
    if (llIIlIIIll(theWorld))
    {
      if (llIIlIIlIl(isGamePaused))
      {
        if (llIIlIIllI(theWorld.getDifficulty(), EnumDifficulty.PEACEFUL))
        {
          "".length();
          if (-"  ".length() <= 0) {
            break label3753;
          }
        }
        label3753:
        llllIIll[1].setAllowedSpawnTypes(llllIIll[0], llllIIll[1]);
        try
        {
          theWorld.tick();
          "".length();
          if ("  ".length() != "  ".length()) {
            return;
          }
        }
        catch (Throwable lIIlllIIIlIlllI)
        {
          CrashReport lIIlllIIIlIllIl = CrashReport.makeCrashReport(lIIlllIIIlIlllI, llIlIlII[llllIIll['']]);
          if (llIIlIIIIl(theWorld))
          {
            CrashReportCategory lIIlllIIIlIllII = lIIlllIIIlIllIl.makeCategory(llIlIlII[llllIIll['']]);
            lIIlllIIIlIllII.addCrashSection(llIlIlII[llllIIll['']], llIlIlII[llllIIll['']]);
            "".length();
            if (" ".length() > 0) {}
          }
          else
          {
            "".length();
          }
          throw new ReportedException(lIIlllIIIlIllIl);
        }
      }
      mcProfiler.endStartSection(llIlIlII[llllIIll['']]);
      if ((llIIlIIlIl(isGamePaused)) && (llIIlIIIll(theWorld))) {
        theWorld.doVoidFogParticles(MathHelper.floor_double(thePlayer.posX), MathHelper.floor_double(thePlayer.posY), MathHelper.floor_double(thePlayer.posZ));
      }
      mcProfiler.endStartSection(llIlIlII[llllIIll['']]);
      if (llIIlIIlIl(isGamePaused))
      {
        effectRenderer.updateEffects();
        "".length();
        if (((59 + 48 - -48 + 24 ^ 112 + 122 - 190 + 130) & (0xF ^ 0x4E ^ 0x2F ^ 0x73 ^ -" ".length())) == 0) {}
      }
    }
    else if (llIIlIIIll(myNetworkManager))
    {
      mcProfiler.endStartSection(llIlIlII[llllIIll['']]);
      myNetworkManager.processReceivedPackets();
    }
    mcProfiler.endSection();
    systemTime = getSystemTime();
  }
  
  private void registerMetadataSerializers()
  {
    ;
    metadataSerializer_.registerMetadataSectionType(new TextureMetadataSectionSerializer(), TextureMetadataSection.class);
    metadataSerializer_.registerMetadataSectionType(new FontMetadataSectionSerializer(), FontMetadataSection.class);
    metadataSerializer_.registerMetadataSectionType(new AnimationMetadataSectionSerializer(), AnimationMetadataSection.class);
    metadataSerializer_.registerMetadataSectionType(new PackMetadataSectionSerializer(), PackMetadataSection.class);
    metadataSerializer_.registerMetadataSectionType(new LanguageMetadataSectionSerializer(), LanguageMetadataSection.class);
  }
  
  public NetHandlerPlayClient getNetHandler()
  {
    ;
    if (llIIlIIIll(thePlayer))
    {
      "".length();
      if (((0x71 ^ 0x7B ^ 0x2C ^ 0x23) & (100 + 104 - 128 + 55 ^ 0 + 57 - -75 + 2 ^ -" ".length())) >= 0) {
        break label72;
      }
      return null;
    }
    label72:
    return null;
  }
  
  private static int llIIlIllll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llIIlIIIll(Object ???)
  {
    int lIIllIIlIIIlIll;
    return ??? != null;
  }
  
  public SkinManager getSkinManager()
  {
    ;
    return skinManager;
  }
  
  public void run()
  {
    ;
    ;
    ;
    running = llllIIll[1];
    try
    {
      lIlIIIIIIIlllIl.startGame();
      "".length();
      if (-(0xF0 ^ 0xBD ^ 0x46 ^ 0xF) > 0) {
        return;
      }
    }
    catch (Throwable lIlIIIIIIlIIlII)
    {
      CrashReport lIlIIIIIIlIIIll = CrashReport.makeCrashReport(lIlIIIIIIlIIlII, llIlIlII[llllIIll[12]]);
      "".length();
      lIlIIIIIIIlllIl.displayCrashReport(lIlIIIIIIIlllIl.addGraphicsAndWorldToCrashReport(lIlIIIIIIlIIIll));
      return;
    }
    try
    {
      do
      {
        if ((!llIIlIIlII(hasCrashed)) || (llIIlIIIIl(crashReporter))) {
          try
          {
            lIlIIIIIIIlllIl.runGameLoop();
            "".length();
            if (" ".length() >= 0) {
              continue;
            }
            return;
          }
          catch (OutOfMemoryError lIlIIIIIIlIIIlI)
          {
            lIlIIIIIIIlllIl.freeMemory();
            lIlIIIIIIIlllIl.displayGuiScreen(new GuiMemoryErrorScreen());
            System.gc();
            "".length();
            if ((0x62 ^ 0xD ^ 0x67 ^ 0xC) > " ".length()) {
              continue;
            }
          }
        } else {
          lIlIIIIIIIlllIl.displayCrashReport(crashReporter);
        }
      } while (!llIIlIIlIl(running));
      "".length();
      if (" ".length() == (('¨' + 14 - 75 + 99 ^ 4 + 67 - 22 + 148) & (0xF5 ^ 0x80 ^ 0x69 ^ 0x17 ^ -" ".length()))) {
        return;
      }
    }
    catch (MinecraftError lIlIIIIIIlIIIIl)
    {
      lIlIIIIIIIlllIl.shutdownMinecraftApplet();
      "".length();
      if (-(3 + 34 - -89 + 72 ^ 39 + 69 - 96 + 183) < 0) {
        return;
      }
      return;
    }
    catch (ReportedException lIlIIIIIIlIIIII)
    {
      "".length();
      lIlIIIIIIIlllIl.freeMemory();
      logger.fatal(llIlIlII[llllIIll[14]], lIlIIIIIIlIIIII);
      lIlIIIIIIIlllIl.displayCrashReport(lIlIIIIIIlIIIII.getCrashReport());
      lIlIIIIIIIlllIl.shutdownMinecraftApplet();
      "".length();
      if (" ".length() != 0) {
        return;
      }
      return;
    }
    catch (Throwable lIlIIIIIIIlllll)
    {
      CrashReport lIlIIIIIIIllllI = lIlIIIIIIIlllIl.addGraphicsAndWorldToCrashReport(new CrashReport(llIlIlII[llllIIll[15]], lIlIIIIIIIlllll));
      lIlIIIIIIIlllIl.freeMemory();
      logger.fatal(llIlIlII[llllIIll[16]], lIlIIIIIIIlllll);
      lIlIIIIIIIlllIl.displayCrashReport(lIlIIIIIIIllllI);
      lIlIIIIIIIlllIl.shutdownMinecraftApplet();
      "".length();
      if (-" ".length() <= "   ".length()) {
        return;
      }
      return;
    }
    finally
    {
      lIlIIIIIIIlllIl.shutdownMinecraftApplet();
    }
    lIlIIIIIIIlllIl.shutdownMinecraftApplet();
    return;
  }
  
  public PropertyMap func_181037_M()
  {
    ;
    ;
    if (llIIlIIlII(field_181038_N.isEmpty()))
    {
      GameProfile lIIllIlIlIIIlll = lIIllIlIlIIlIII.getSessionService().fillProfileProperties(session.getProfile(), llllIIll[0]);
      "".length();
    }
    return field_181038_N;
  }
  
  private static boolean llIIlIIlII(int ???)
  {
    String lIIllIIlIIIIlll;
    return ??? != 0;
  }
  
  public void setRenderViewEntity(Entity lIIllIlIIIlIIIl)
  {
    ;
    ;
    renderViewEntity = lIIllIlIIIlIIIl;
    entityRenderer.loadEntityShader(lIIllIlIIIlIIIl);
  }
  
  private static int llIlIIIIII(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  public IResourceManager getResourceManager()
  {
    ;
    return mcResourceManager;
  }
  
  private static boolean llIIlIIlIl(int ???)
  {
    short lIIllIIlIIIIlIl;
    return ??? == 0;
  }
  
  public void refreshResources()
  {
    ;
    ;
    ;
    List<IResourcePack> lIIlllllIlllIII = Lists.newArrayList(defaultResourcePacks);
    int lIIlllllIllIIlI = mcResourcePackRepository.getRepositoryEntries().iterator();
    "".length();
    if ((78 + 13 - 90 + 134 ^ 12 + 96 - 29 + 52) == 0) {
      return;
    }
    while (!llIIlIIlIl(lIIlllllIllIIlI.hasNext()))
    {
      ResourcePackRepository.Entry lIIlllllIllIlll = (ResourcePackRepository.Entry)lIIlllllIllIIlI.next();
      "".length();
    }
    if (llIIlIIIll(mcResourcePackRepository.getResourcePackInstance())) {
      "".length();
    }
    try
    {
      mcResourceManager.reloadResources(lIIlllllIlllIII);
      "".length();
      if (" ".length() == "  ".length()) {
        return;
      }
    }
    catch (RuntimeException lIIlllllIllIllI)
    {
      logger.info(llIlIlII[llllIIll[54]], lIIlllllIllIllI);
      lIIlllllIlllIII.clear();
      "".length();
      mcResourcePackRepository.setRepositories(Collections.emptyList());
      mcResourceManager.reloadResources(lIIlllllIlllIII);
      gameSettings.resourcePacks.clear();
      gameSettings.field_183018_l.clear();
      gameSettings.saveOptions();
      mcLanguageManager.parseLanguageMetadata(lIIlllllIlllIII);
      if (llIIlIIIll(renderGlobal)) {
        renderGlobal.loadRenderers();
      }
    }
  }
  
  private static boolean llIIlIlIlI(int ???)
  {
    char lIIllIIIlllllll;
    return ??? <= 0;
  }
  
  private void startGame()
    throws IOException, LWJGLException
  {
    ;
    ;
    gameSettings = new GameSettings(lIlIIIIIIIlIlIl, mcDataDir);
    "".length();
    lIlIIIIIIIlIlIl.startTimerHackThread();
    if ((llIIlIIIlI(gameSettings.overrideHeight)) && (llIIlIIIlI(gameSettings.overrideWidth)))
    {
      displayWidth = gameSettings.overrideWidth;
      displayHeight = gameSettings.overrideHeight;
    }
    logger.info(String.valueOf(new StringBuilder(llIlIlII[llllIIll[17]]).append(Sys.getVersion())));
    lIlIIIIIIIlIlIl.setWindowIcon();
    lIlIIIIIIIlIlIl.setInitialDisplayMode();
    lIlIIIIIIIlIlIl.createDisplay();
    OpenGlHelper.initializeTextures();
    framebufferMc = new Framebuffer(displayWidth, displayHeight, llllIIll[1]);
    framebufferMc.setFramebufferColor(0.0F, 0.0F, 0.0F, 0.0F);
    lIlIIIIIIIlIlIl.registerMetadataSerializers();
    mcResourcePackRepository = new ResourcePackRepository(fileResourcepacks, new File(mcDataDir, llIlIlII[llllIIll[18]]), mcDefaultResourcePack, metadataSerializer_, gameSettings);
    mcResourceManager = new SimpleReloadableResourceManager(metadataSerializer_);
    mcLanguageManager = new LanguageManager(metadataSerializer_, gameSettings.language);
    mcResourceManager.registerReloadListener(mcLanguageManager);
    lIlIIIIIIIlIlIl.refreshResources();
    renderEngine = new TextureManager(mcResourceManager);
    mcResourceManager.registerReloadListener(renderEngine);
    lIlIIIIIIIlIlIl.drawSplashScreen(renderEngine);
    lIlIIIIIIIlIlIl.initStream();
    skinManager = new SkinManager(renderEngine, new File(fileAssets, llIlIlII[llllIIll[19]]), sessionService);
    saveLoader = new AnvilSaveConverter(new File(mcDataDir, llIlIlII[llllIIll[20]]));
    mcSoundHandler = new SoundHandler(mcResourceManager, gameSettings);
    mcResourceManager.registerReloadListener(mcSoundHandler);
    mcMusicTicker = new MusicTicker(lIlIIIIIIIlIlIl);
    fontRendererObj = new FontRenderer(gameSettings, new ResourceLocation(llIlIlII[llllIIll[21]]), renderEngine, llllIIll[0]);
    if (llIIlIIIll(gameSettings.language))
    {
      fontRendererObj.setUnicodeFlag(lIlIIIIIIIlIlIl.isUnicode());
      fontRendererObj.setBidiFlag(mcLanguageManager.isCurrentLanguageBidirectional());
    }
    standardGalacticFontRenderer = new FontRenderer(gameSettings, new ResourceLocation(llIlIlII[llllIIll[22]]), renderEngine, llllIIll[0]);
    mcResourceManager.registerReloadListener(fontRendererObj);
    mcResourceManager.registerReloadListener(standardGalacticFontRenderer);
    mcResourceManager.registerReloadListener(new GrassColorReloadListener());
    mcResourceManager.registerReloadListener(new FoliageColorReloadListener());
    new IStatStringFormat();
    {
      private static String lIlIlIIIllIll(String llllllllllllllllIlIIIIlIIIlIIIIl, String llllllllllllllllIlIIIIlIIIlIIlIl)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        llllllllllllllllIlIIIIlIIIlIIIIl = new String(Base64.getDecoder().decode(llllllllllllllllIlIIIIlIIIlIIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder llllllllllllllllIlIIIIlIIIlIIlII = new StringBuilder();
        char[] llllllllllllllllIlIIIIlIIIlIIIll = llllllllllllllllIlIIIIlIIIlIIlIl.toCharArray();
        int llllllllllllllllIlIIIIlIIIlIIIlI = llIlllIIIIl[1];
        double llllllllllllllllIlIIIIlIIIIllIIl = llllllllllllllllIlIIIIlIIIlIIIIl.toCharArray();
        int llllllllllllllllIlIIIIlIIIIllIII = llllllllllllllllIlIIIIlIIIIllIIl.length;
        short llllllllllllllllIlIIIIlIIIIlIlll = llIlllIIIIl[1];
        while (lIlIlIIIllllI(llllllllllllllllIlIIIIlIIIIlIlll, llllllllllllllllIlIIIIlIIIIllIII))
        {
          char llllllllllllllllIlIIIIlIIIlIIlll = llllllllllllllllIlIIIIlIIIIllIIl[llllllllllllllllIlIIIIlIIIIlIlll];
          "".length();
          "".length();
          if ("   ".length() == 0) {
            return null;
          }
        }
        return String.valueOf(llllllllllllllllIlIIIIlIIIlIIlII);
      }
      
      private static void lIlIlIIIlllIl()
      {
        llIlllIIIIl = new int[2];
        llIlllIIIIl[0] = " ".length();
        llIlllIIIIl[1] = ((92 + 21 - 109 + 125 ^ 57 + 27 - -28 + 67) & (0x9F ^ 0xA5 ^ 0x11 ^ 0x19 ^ -" ".length()));
      }
      
      private static void lIlIlIIIlllII()
      {
        llIllIlllll = new String[llIlllIIIIl[0]];
        llIllIlllll[llIlllIIIIl[1]] = lIlIlIIIllIll("KxgTIBxUSg==", "njaOn");
      }
      
      public String formatString(String llllllllllllllllIlIIIIlIIIllIlIl)
      {
        try
        {
          ;
          ;
          ;
          return String.format(llllllllllllllllIlIIIIlIIIllIlIl, new Object[] { GameSettings.getKeyDisplayString(gameSettings.keyBindInventory.getKeyCode()) });
        }
        catch (Exception llllllllllllllllIlIIIIlIIIllIlII)
        {
          return String.valueOf(new StringBuilder(llIllIlllll[llIlllIIIIl[1]]).append(llllllllllllllllIlIIIIlIIIllIlII.getLocalizedMessage()));
        }
      }
      
      private static boolean lIlIlIIIllllI(int ???, int arg1)
      {
        int i;
        short llllllllllllllllIlIIIIlIIIIlIIII;
        return ??? < i;
      }
      
      static
      {
        lIlIlIIIlllIl();
        lIlIlIIIlllII();
      }
    };
    "".length();
    mouseHelper = new MouseHelper();
    lIlIIIIIIIlIlIl.checkGLError(llIlIlII[llllIIll[23]]);
    GlStateManager.enableTexture2D();
    GlStateManager.shadeModel(llllIIll[24]);
    GlStateManager.clearDepth(1.0D);
    GlStateManager.enableDepth();
    GlStateManager.depthFunc(llllIIll[25]);
    GlStateManager.enableAlpha();
    GlStateManager.alphaFunc(llllIIll[26], 0.1F);
    GlStateManager.cullFace(llllIIll[27]);
    GlStateManager.matrixMode(llllIIll[28]);
    GlStateManager.loadIdentity();
    GlStateManager.matrixMode(llllIIll[29]);
    lIlIIIIIIIlIlIl.checkGLError(llIlIlII[llllIIll[30]]);
    textureMapBlocks = new TextureMap(llIlIlII[llllIIll[31]]);
    textureMapBlocks.setMipmapLevels(gameSettings.mipmapLevels);
    "".length();
    renderEngine.bindTexture(TextureMap.locationBlocksTexture);
    if (llIIlIIIlI(gameSettings.mipmapLevels))
    {
      "".length();
      if (((0x5A ^ 0x12 ^ 0x51 ^ 0x7A) & (41 + 88 - -26 + 66 ^ '´' + 73 - 133 + 70 ^ -" ".length())) == (('' + '' - 226 + 113 ^ 77 + 90 - 94 + 69) & (0xA1 ^ 0xA7 ^ 0x66 ^ 0x42 ^ -" ".length()))) {
        break label943;
      }
    }
    label943:
    llllIIll[0].setBlurMipmapDirect(llllIIll[1], llllIIll[0]);
    modelManager = new ModelManager(textureMapBlocks);
    mcResourceManager.registerReloadListener(modelManager);
    renderItem = new RenderItem(renderEngine, modelManager);
    renderManager = new RenderManager(renderEngine, renderItem);
    itemRenderer = new ItemRenderer(lIlIIIIIIIlIlIl);
    mcResourceManager.registerReloadListener(renderItem);
    entityRenderer = new EntityRenderer(lIlIIIIIIIlIlIl, mcResourceManager);
    mcResourceManager.registerReloadListener(entityRenderer);
    blockRenderDispatcher = new BlockRendererDispatcher(modelManager.getBlockModelShapes(), gameSettings);
    mcResourceManager.registerReloadListener(blockRenderDispatcher);
    renderGlobal = new RenderGlobal(lIlIIIIIIIlIlIl);
    mcResourceManager.registerReloadListener(renderGlobal);
    guiAchievement = new GuiAchievement(lIlIIIIIIIlIlIl);
    GlStateManager.viewport(llllIIll[0], llllIIll[0], displayWidth, displayHeight);
    effectRenderer = new EffectRenderer(theWorld, renderEngine);
    lIlIIIIIIIlIlIl.checkGLError(llIlIlII[llllIIll[32]]);
    ingameGUI = new GuiInGameHook(lIlIIIIIIIlIlIl);
    if (llIIlIIIll(serverName))
    {
      lIlIIIIIIIlIlIl.displayGuiScreen(new GuiConnecting(new GuiMainMenu(), lIlIIIIIIIlIlIl, serverName, serverPort));
      "".length();
      if (-" ".length() <= ((20 + 12 - -35 + 103 ^ 50 + '' - 131 + 113) & (0x52 ^ 0x70 ^ 0x2A ^ 0xF ^ -" ".length()))) {}
    }
    else if (llIIlIIlII(ConnectionUtils.check()))
    {
      lIlIIIIIIIlIlIl.displayGuiScreen(new GuiUpdateCheck());
    }
    renderEngine.deleteTexture(mojangLogo);
    mojangLogo = null;
    loadingScreen = new LoadingScreenRenderer(lIlIIIIIIIlIlIl);
    if ((llIIlIIlII(gameSettings.fullScreen)) && (llIIlIIlIl(fullscreen))) {
      lIlIIIIIIIlIlIl.toggleFullscreen();
    }
    try
    {
      Display.setVSyncEnabled(gameSettings.enableVsync);
      "".length();
      if ((0x48 ^ 0x27 ^ 0xAB ^ 0xC0) != (39 + '' - 69 + 33 ^ 124 + 94 - 125 + 65)) {
        return;
      }
    }
    catch (OpenGLException lIlIIIIIIIlIllI)
    {
      gameSettings.enableVsync = llllIIll[0];
      gameSettings.saveOptions();
      renderGlobal.makeEntityOutlineShader();
      XGUARD.startClient();
      BlacklistManage.check(lIlIIIIIIIlIlIl);
    }
  }
  
  public TextureManager getTextureManager()
  {
    ;
    return renderEngine;
  }
  
  public String getVersion()
  {
    ;
    return launchedVersion;
  }
  
  private void rightClickMouse()
  {
    ;
    ;
    ;
    ;
    ;
    if (llIIlIIlIl(playerController.func_181040_m()))
    {
      rightClickDelayTimer = llllIIll[9];
      boolean lIIlllIIllIIlIl = llllIIll[1];
      ItemStack lIIlllIIllIIlII = thePlayer.inventory.getCurrentItem();
      if (llIIlIIIIl(objectMouseOver))
      {
        logger.warn(llIlIlII[llllIIll[116]]);
        "".length();
        if ((87 + '' - 157 + 97 ^ 71 + 73 - 73 + 90) >= ((0xF9 ^ 0xA8 ^ 0xE7 ^ 0x86) & (0x40 ^ 0x62 ^ 0x28 ^ 0x3A ^ -" ".length()))) {}
      }
      else
      {
        switch ($SWITCH_TABLE$net$minecraft$util$MovingObjectPosition$MovingObjectType()[objectMouseOver.typeOfHit.ordinal()])
        {
        case 3: 
          if (llIIlIIlII(playerController.func_178894_a(thePlayer, objectMouseOver.entityHit, objectMouseOver)))
          {
            lIIlllIIllIIlIl = llllIIll[0];
            "".length();
            if (" ".length() != (('¥' + 99 - 82 + 59 ^ '' + 7 - 47 + 96) & (0x1A ^ 0x55 ^ 77 + 103 - 157 + 104 ^ -" ".length()))) {
              break;
            }
          }
          else if (llIIlIIlII(playerController.interactWithEntitySendPacket(thePlayer, objectMouseOver.entityHit)))
          {
            lIIlllIIllIIlIl = llllIIll[0];
            "".length();
            if (" ".length() <= 0) {
              return;
            }
          }
          break;
        case 2: 
          BlockPos lIIlllIIllIIIll = objectMouseOver.getBlockPos();
          if (llIIlIIllI(theWorld.getBlockState(lIIlllIIllIIIll).getBlock().getMaterial(), Material.air))
          {
            if (llIIlIIIll(lIIlllIIllIIlII))
            {
              "".length();
              if (" ".length() < "   ".length()) {
                break label398;
              }
            }
            label398:
            int lIIlllIIllIIIlI = llllIIll[0];
            if (llIIlIIlII(playerController.onPlayerRightClick(thePlayer, theWorld, lIIlllIIllIIlII, lIIlllIIllIIIll, objectMouseOver.sideHit, objectMouseOver.hitVec)))
            {
              lIIlllIIllIIlIl = llllIIll[0];
              thePlayer.swingItem();
            }
            if (llIIlIIIIl(lIIlllIIllIIlII)) {
              return;
            }
            if (llIIlIIlIl(stackSize))
            {
              thePlayer.inventory.mainInventory[thePlayer.inventory.currentItem] = null;
              "".length();
              if (null == null) {
                break;
              }
            }
            else if ((!llIIlIlIII(stackSize, lIIlllIIllIIIlI)) || (llIIlIIlII(playerController.isInCreativeMode())))
            {
              entityRenderer.itemRenderer.resetEquippedProgress();
            }
          }
          break;
        }
      }
      if (llIIlIIlII(lIIlllIIllIIlIl))
      {
        ItemStack lIIlllIIllIIIIl = thePlayer.inventory.getCurrentItem();
        if ((llIIlIIIll(lIIlllIIllIIIIl)) && (llIIlIIlII(playerController.sendUseItem(thePlayer, theWorld, lIIlllIIllIIIIl)))) {
          entityRenderer.itemRenderer.resetEquippedProgress2();
        }
      }
    }
  }
  
  public static boolean isGuiEnabled()
  {
    if ((llIIlIIIll(theMinecraft)) && (llIIlIIlII(theMinecraftgameSettings.hideGUI))) {
      return llllIIll[0];
    }
    return llllIIll[1];
  }
  
  public boolean isFullScreen()
  {
    ;
    return fullscreen;
  }
  
  public ListenableFuture<Object> scheduleResourcesRefresh()
  {
    ;
    lIIllIllIIlIIlI.addScheduledTask(new Runnable()
    {
      public void run()
      {
        ;
        refreshResources();
      }
    });
  }
  
  public static int getGLMaximumTextureSize()
  {
    ;
    ;
    int lIIllIlIlllIIlI = llllIIll['ĥ'];
    "".length();
    if (-"   ".length() > 0) {
      return (118 + '²' - 144 + 47 ^ 33 + 116 - 124 + 111) & ('©' + '' - 116 + 29 ^ '' + 103 - 181 + 101 ^ -" ".length());
    }
    while (!llIIlIlIlI(lIIllIlIlllIIlI))
    {
      GL11.glTexImage2D(llllIIll['Ħ'], llllIIll[0], llllIIll['ħ'], lIIllIlIlllIIlI, lIIllIlIlllIIlI, llllIIll[0], llllIIll['ħ'], llllIIll['Ĩ'], null);
      int lIIllIlIlllIIIl = GL11.glGetTexLevelParameteri(llllIIll['Ħ'], llllIIll[0], llllIIll['ĩ']);
      if (llIIlIIlII(lIIllIlIlllIIIl)) {
        return lIIllIlIlllIIlI;
      }
      lIIllIlIlllIIlI >>= llllIIll[1];
    }
    return llllIIll[50];
  }
  
  public void setIngameNotInFocus()
  {
    ;
    if (llIIlIIlII(inGameHasFocus))
    {
      KeyBinding.unPressAllKeys();
      inGameHasFocus = llllIIll[0];
      mouseHelper.ungrabMouseCursor();
    }
  }
  
  public void launchIntegratedServer(String lIIlllIIIIllIll, String lIIlllIIIIIlllI, WorldSettings lIIlllIIIIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lIIlllIIIIlIIII.loadWorld(null);
    System.gc();
    ISaveHandler lIIlllIIIIllIII = saveLoader.getSaveLoader(lIIlllIIIIllIll, llllIIll[0]);
    WorldInfo lIIlllIIIIlIlll = lIIlllIIIIllIII.loadWorldInfo();
    if ((llIIlIIIIl(lIIlllIIIIlIlll)) && (llIIlIIIll(lIIlllIIIIllIIl)))
    {
      lIIlllIIIIlIlll = new WorldInfo(lIIlllIIIIllIIl, lIIlllIIIIllIll);
      lIIlllIIIIllIII.saveWorldInfo(lIIlllIIIIlIlll);
    }
    if (llIIlIIIIl(lIIlllIIIIllIIl)) {
      lIIlllIIIIllIIl = new WorldSettings(lIIlllIIIIlIlll);
    }
    try
    {
      theIntegratedServer = new IntegratedServer(lIIlllIIIIlIIII, lIIlllIIIIllIll, lIIlllIIIIIlllI, lIIlllIIIIllIIl);
      theIntegratedServer.startServerThread();
      integratedServerIsRunning = llllIIll[1];
      "".length();
      if ("  ".length() == " ".length()) {
        return;
      }
    }
    catch (Throwable lIIlllIIIIlIllI)
    {
      CrashReport lIIlllIIIIlIlIl = CrashReport.makeCrashReport(lIIlllIIIIlIllI, llIlIlII[llllIIll['']]);
      CrashReportCategory lIIlllIIIIlIlII = lIIlllIIIIlIlIl.makeCategory(llIlIlII[llllIIll['']]);
      lIIlllIIIIlIlII.addCrashSection(llIlIlII[llllIIll['']], lIIlllIIIIllIll);
      lIIlllIIIIlIlII.addCrashSection(llIlIlII[llllIIll['']], lIIlllIIIIIlllI);
      throw new ReportedException(lIIlllIIIIlIlIl);
    }
    loadingScreen.displaySavingString(I18n.format(llIlIlII[llllIIll['']], new Object[llllIIll[0]]));
    "".length();
    if (((0x8D ^ 0x95) & (0x1C ^ 0x4 ^ 0xFFFFFFFF)) > 0) {
      return;
    }
    while (!llIIlIIlII(theIntegratedServer.serverIsInRunLoop()))
    {
      String lIIlllIIIIlIIll = theIntegratedServer.getUserMessage();
      if (llIIlIIIll(lIIlllIIIIlIIll))
      {
        loadingScreen.displayLoadingString(I18n.format(lIIlllIIIIlIIll, new Object[llllIIll[0]]));
        "".length();
        if (-"   ".length() <= 0) {}
      }
      else
      {
        loadingScreen.displayLoadingString(llIlIlII[llllIIll['']]);
      }
      try
      {
        Thread.sleep(200L);
        "".length();
        if (((0x73 ^ 0x25) & (0xF ^ 0x59 ^ 0xFFFFFFFF)) <= -" ".length()) {
          return;
        }
      }
      catch (InterruptedException localInterruptedException) {}
    }
    lIIlllIIIIlIIII.displayGuiScreen(null);
    SocketAddress lIIlllIIIIlIIlI = theIntegratedServer.getNetworkSystem().addLocalEndpoint();
    NetworkManager lIIlllIIIIlIIIl = NetworkManager.provideLocalClient(lIIlllIIIIlIIlI);
    lIIlllIIIIlIIIl.setNetHandler(new NetHandlerLoginClient(lIIlllIIIIlIIIl, lIIlllIIIIlIIII, null));
    lIIlllIIIIlIIIl.sendPacket(new C00Handshake(llllIIll[62], lIIlllIIIIlIIlI.toString(), llllIIll[0], EnumConnectionState.LOGIN));
    lIIlllIIIIlIIIl.sendPacket(new C00PacketLoginStart(lIIlllIIIIlIIII.getSession().getProfile()));
    myNetworkManager = lIIlllIIIIlIIIl;
  }
  
  private static boolean llIIllIIII(int ???)
  {
    float lIIllIIlIIIIIll;
    return ??? >= 0;
  }
  
  private static boolean llIIllIIIl(int ???, int arg1)
  {
    int i;
    boolean lIIllIIlIIllIIl;
    return ??? < i;
  }
  
  private void drawSplashScreen(TextureManager lIIllllIllIIIII)
    throws LWJGLException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ScaledResolution lIIllllIllIllII = new ScaledResolution(lIIllllIllIIIIl);
    int lIIllllIllIlIll = lIIllllIllIllII.getScaleFactor();
    Framebuffer lIIllllIllIlIlI = new Framebuffer(ScaledResolution.getScaledWidth() * lIIllllIllIlIll, lIIllllIllIllII.getScaledHeight() * lIIllllIllIlIll, llllIIll[1]);
    lIIllllIllIlIlI.bindFramebuffer(llllIIll[0]);
    GlStateManager.matrixMode(llllIIll[28]);
    GlStateManager.loadIdentity();
    GlStateManager.ortho(0.0D, ScaledResolution.getScaledWidth(), lIIllllIllIllII.getScaledHeight(), 0.0D, 1000.0D, 3000.0D);
    GlStateManager.matrixMode(llllIIll[29]);
    GlStateManager.loadIdentity();
    GlStateManager.translate(0.0F, 0.0F, -2000.0F);
    GlStateManager.disableLighting();
    GlStateManager.disableFog();
    GlStateManager.disableDepth();
    GlStateManager.enableTexture2D();
    InputStream lIIllllIllIlIIl = null;
    try
    {
      lIIllllIllIlIIl = mcDefaultResourcePack.getInputStream(locationMojangPng);
      mojangLogo = lIIllllIllIIIII.getDynamicTextureLocation(llIlIlII[llllIIll[56]], new DynamicTexture(ImageIO.read(lIIllllIllIlIIl)));
      lIIllllIllIIIII.bindTexture(mojangLogo);
      "".length();
      if ("  ".length() < 0) {
        return;
      }
    }
    catch (IOException lIIllllIllIlIII)
    {
      lIIllllIllIlIII = lIIllllIllIlIII;
      logger.error(String.valueOf(new StringBuilder(llIlIlII[llllIIll[57]]).append(locationMojangPng)), lIIllllIllIlIII);
      IOUtils.closeQuietly(lIIllllIllIlIIl);
      "".length();
      if ("   ".length() == "   ".length()) {
        break label264;
      }
      return;
    }
    finally
    {
      lIIllllIlIllIII = finally;
      IOUtils.closeQuietly(lIIllllIllIlIIl);
      throw lIIllllIlIllIII;
    }
    IOUtils.closeQuietly(lIIllllIllIlIIl);
    label264:
    Tessellator lIIllllIllIIlll = Tessellator.getInstance();
    WorldRenderer lIIllllIllIIllI = lIIllllIllIIlll.getWorldRenderer();
    lIIllllIllIIllI.begin(llllIIll[12], DefaultVertexFormats.POSITION_TEX_COLOR);
    lIIllllIllIIllI.pos(0.0D, displayHeight, 0.0D).tex(0.0D, 0.0D).color(llllIIll[55], llllIIll[55], llllIIll[55], llllIIll[55]).endVertex();
    lIIllllIllIIllI.pos(displayWidth, displayHeight, 0.0D).tex(0.0D, 0.0D).color(llllIIll[55], llllIIll[55], llllIIll[55], llllIIll[55]).endVertex();
    lIIllllIllIIllI.pos(displayWidth, 0.0D, 0.0D).tex(0.0D, 0.0D).color(llllIIll[55], llllIIll[55], llllIIll[55], llllIIll[55]).endVertex();
    lIIllllIllIIllI.pos(0.0D, 0.0D, 0.0D).tex(0.0D, 0.0D).color(llllIIll[55], llllIIll[55], llllIIll[55], llllIIll[55]).endVertex();
    lIIllllIllIIlll.draw();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    int lIIllllIllIIlII = llllIIll[58];
    int lIIllllIllIIIll = llllIIll[58];
    lIIllllIllIIIIl.func_181536_a((ScaledResolution.getScaledWidth() - lIIllllIllIIlII) / llllIIll[3], (lIIllllIllIllII.getScaledHeight() - lIIllllIllIIIll) / llllIIll[3], llllIIll[0], llllIIll[0], lIIllllIllIIlII, lIIllllIllIIIll, llllIIll[55], llllIIll[55], llllIIll[55], llllIIll[55]);
    GlStateManager.disableLighting();
    GlStateManager.disableFog();
    lIIllllIllIlIlI.unbindFramebuffer();
    lIIllllIllIlIlI.framebufferRender(ScaledResolution.getScaledWidth() * lIIllllIllIlIll, lIIllllIllIllII.getScaledHeight() * lIIllllIllIlIll);
    GlStateManager.enableAlpha();
    GlStateManager.alphaFunc(llllIIll[26], 0.1F);
    lIIllllIllIIIIl.updateDisplay();
  }
  
  public IStream getTwitchStream()
  {
    ;
    return stream;
  }
  
  private static String lIlIlIIIll(String lIIllIIlIlIlIlI, String lIIllIIlIlIlIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIllIIlIlIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIIllIIlIlIlIIl.getBytes(StandardCharsets.UTF_8)), llllIIll[13]), "DES");
      Cipher lIIllIIlIlIllII = Cipher.getInstance("DES");
      lIIllIIlIlIllII.init(llllIIll[3], lIIllIIlIlIllIl);
      return new String(lIIllIIlIlIllII.doFinal(Base64.getDecoder().decode(lIIllIIlIlIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIllIIlIlIlIll)
    {
      lIIllIIlIlIlIll.printStackTrace();
    }
    return null;
  }
  
  public PropertyMap getTwitchDetails()
  {
    ;
    return twitchDetails;
  }
  
  public static long getSystemTime()
  {
    return Sys.getTime() * 1000L / Sys.getTimerResolution();
  }
  
  private void updateDebugProfilerName(int lIIlllIllIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    List<Profiler.Result> lIIlllIllIlIlIl = mcProfiler.getProfilingData(debugProfilerName);
    if ((llIIlIIIll(lIIlllIllIlIlIl)) && (llIIlIIlIl(lIIlllIllIlIlIl.isEmpty())))
    {
      Profiler.Result lIIlllIllIlIlII = (Profiler.Result)lIIlllIllIlIlIl.remove(llllIIll[0]);
      if (llIIlIIlIl(lIIlllIllIlIIIl))
      {
        if (llIIlIIIlI(field_76331_c.length()))
        {
          int lIIlllIllIlIIll = debugProfilerName.lastIndexOf(llIlIlII[llllIIll[94]]);
          if (llIIllIIII(lIIlllIllIlIIll))
          {
            debugProfilerName = debugProfilerName.substring(llllIIll[0], lIIlllIllIlIIll);
            "".length();
            if ("   ".length() >= "   ".length()) {}
          }
        }
      }
      else
      {
        lIIlllIllIlIIIl--;
        if ((llIIllIIIl(lIIlllIllIlIIIl, lIIlllIllIlIlIl.size())) && (llIIlIIlIl(getfield_76331_c.equals(llIlIlII[llllIIll[95]]))))
        {
          if (llIIlIIIlI(debugProfilerName.length())) {
            debugProfilerName = String.valueOf(new StringBuilder(String.valueOf(debugProfilerName)).append(llIlIlII[llllIIll[96]]));
          }
          debugProfilerName = String.valueOf(new StringBuilder(String.valueOf(debugProfilerName)).append(getfield_76331_c));
        }
      }
    }
  }
  
  private static String lIlIlIIIlI(String lIIllIIlIllIlIl, String lIIllIIlIllIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIllIIlIlllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIIllIIlIllIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIIllIIlIlllIIl = Cipher.getInstance("Blowfish");
      lIIllIIlIlllIIl.init(llllIIll[3], lIIllIIlIlllIlI);
      return new String(lIIllIIlIlllIIl.doFinal(Base64.getDecoder().decode(lIIllIIlIllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIllIIlIlllIII)
    {
      lIIllIIlIlllIII.printStackTrace();
    }
    return null;
  }
  
  public void toggleFullscreen()
  {
    try
    {
      ;
      ;
      if (llIIlIIlII(fullscreen))
      {
        "".length();
        if (" ".length() > 0) {
          break label38;
        }
      }
      label38:
      llllIIll0fullscreen = llllIIll[1];
      gameSettings.fullScreen = fullscreen;
      if (llIIlIIlII(fullscreen))
      {
        lIIlllIIlIllIIl.updateDisplayMode();
        displayWidth = Display.getDisplayMode().getWidth();
        displayHeight = Display.getDisplayMode().getHeight();
        if (llIIlIlIlI(displayWidth)) {
          displayWidth = llllIIll[1];
        }
        if (llIIlIlIlI(displayHeight))
        {
          displayHeight = llllIIll[1];
          "".length();
          if ("   ".length() == "   ".length()) {}
        }
      }
      else
      {
        Display.setDisplayMode(new DisplayMode(tempDisplayWidth, tempDisplayHeight));
        displayWidth = tempDisplayWidth;
        displayHeight = tempDisplayHeight;
        if (llIIlIlIlI(displayWidth)) {
          displayWidth = llllIIll[1];
        }
        if (llIIlIlIlI(displayHeight)) {
          displayHeight = llllIIll[1];
        }
      }
      if (llIIlIIIll(currentScreen))
      {
        lIIlllIIlIllIIl.resize(displayWidth, displayHeight);
        "".length();
        if ("   ".length() != 0) {}
      }
      else
      {
        lIIlllIIlIllIIl.updateFramebufferSize();
      }
      Display.setFullscreen(fullscreen);
      Display.setVSyncEnabled(gameSettings.enableVsync);
      lIIlllIIlIllIIl.updateDisplay();
      "".length();
      if (-" ".length() > 0) {}
    }
    catch (Exception lIIlllIIlIllIII)
    {
      logger.error(llIlIlII[llllIIll[117]], lIIlllIIlIllIII);
    }
  }
  
  public boolean isSingleplayer()
  {
    ;
    if ((llIIlIIlII(integratedServerIsRunning)) && (llIIlIIIll(theIntegratedServer))) {
      return llllIIll[1];
    }
    return llllIIll[0];
  }
  
  public boolean isCallingFromMinecraftThread()
  {
    ;
    if (llIIlIIIII(Thread.currentThread(), mcThread)) {
      return llllIIll[1];
    }
    return llllIIll[0];
  }
  
  public void displayInGameMenu()
  {
    ;
    if (llIIlIIIIl(currentScreen))
    {
      lIIlllIIllllIll.displayGuiScreen(new GuiIngameMenu());
      if ((llIIlIIlII(lIIlllIIllllIll.isSingleplayer())) && (llIIlIIlIl(theIntegratedServer.getPublic()))) {
        mcSoundHandler.pauseSounds();
      }
    }
  }
  
  public MusicTicker func_181535_r()
  {
    ;
    return mcMusicTicker;
  }
  
  public static Minecraft getMinecraft()
  {
    return theMinecraft;
  }
  
  private static boolean isJvm64bit()
  {
    ;
    ;
    ;
    String[] lIIlllllllIIlIl = { llIlIlII[llllIIll[40]], llIlIlII[llllIIll[41]], llIlIlII[llllIIll[42]] };
    double lIIllllllIllllI = lIIlllllllIIlIl;
    short lIIllllllIlllll = lIIlllllllIIlIl.length;
    Exception lIIlllllllIIIII = llllIIll[0];
    "".length();
    if (null != null) {
      return (0xFE ^ 0xB0) & (0xD9 ^ 0x97 ^ 0xFFFFFFFF);
    }
    while (!llIIlIIlll(lIIlllllllIIIII, lIIllllllIlllll))
    {
      String lIIlllllllIIlII = lIIllllllIllllI[lIIlllllllIIIII];
      String lIIlllllllIIIll = System.getProperty(lIIlllllllIIlII);
      if ((llIIlIIIll(lIIlllllllIIIll)) && (llIIlIIlII(lIIlllllllIIIll.contains(llIlIlII[llllIIll[43]])))) {
        return llllIIll[1];
      }
      lIIlllllllIIIII++;
    }
    return llllIIll[0];
  }
  
  private void runGameLoop()
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    long lIIlllIlllllllI = System.nanoTime();
    mcProfiler.startSection(llIlIlII[llllIIll[63]]);
    if ((llIIlIIlII(Display.isCreated())) && (llIIlIIlII(Display.isCloseRequested()))) {
      lIIlllIllllllll.shutdown();
    }
    if ((llIIlIIlII(isGamePaused)) && (llIIlIIIll(theWorld)))
    {
      float lIIlllIllllllIl = timer.renderPartialTicks;
      timer.updateTimer();
      timer.renderPartialTicks = lIIlllIllllllIl;
      "".length();
      if (null == null) {}
    }
    else
    {
      timer.updateTimer();
    }
    mcProfiler.startSection(llIlIlII[llllIIll[64]]);
    synchronized (scheduledTasks)
    {
      "".length();
      if ("  ".length() >= "   ".length()) {
        return;
      }
      while (!llIIlIIlII(scheduledTasks.isEmpty())) {
        "".length();
      }
      "".length();
      if ((0x7 ^ 0x3) < 0) {
        return;
      }
    }
    mcProfiler.endSection();
    long lIIlllIllllllII = System.nanoTime();
    mcProfiler.startSection(llIlIlII[llllIIll[65]]);
    int lIIlllIlllllIll = llllIIll[0];
    "".length();
    if ((0x55 ^ 0x51) == 0) {
      return;
    }
    while (!llIIlIIlll(lIIlllIlllllIll, timer.elapsedTicks)) {
      lIIlllIllllllll.runTick();
    }
    mcProfiler.endStartSection(llIlIlII[llllIIll[66]]);
    long lIIlllIlllllIlI = System.nanoTime() - lIIlllIllllllII;
    lIIlllIllllllll.checkGLError(llIlIlII[llllIIll[67]]);
    mcProfiler.endStartSection(llIlIlII[llllIIll[68]]);
    mcSoundHandler.setListener(thePlayer, timer.renderPartialTicks);
    mcProfiler.endSection();
    mcProfiler.startSection(llIlIlII[llllIIll[69]]);
    GlStateManager.pushMatrix();
    GlStateManager.clear(llllIIll[70]);
    framebufferMc.bindFramebuffer(llllIIll[1]);
    mcProfiler.startSection(llIlIlII[llllIIll[71]]);
    GlStateManager.enableTexture2D();
    if ((llIIlIIIll(thePlayer)) && (llIIlIIlII(thePlayer.isEntityInsideOpaqueBlock()))) {
      gameSettings.thirdPersonView = llllIIll[0];
    }
    mcProfiler.endSection();
    if (llIIlIIlIl(skipRenderWorld))
    {
      mcProfiler.endStartSection(llIlIlII[llllIIll[72]]);
      entityRenderer.func_181560_a(timer.renderPartialTicks, lIIlllIlllllllI);
      mcProfiler.endSection();
    }
    mcProfiler.endSection();
    if ((llIIlIIlII(gameSettings.showDebugInfo)) && (llIIlIIlII(gameSettings.showDebugProfilerChart)) && (llIIlIIlIl(gameSettings.hideGUI)))
    {
      if (llIIlIIlIl(mcProfiler.profilingEnabled)) {
        mcProfiler.clearProfiling();
      }
      mcProfiler.profilingEnabled = llllIIll[1];
      lIIlllIllllllll.displayDebugInfo(lIIlllIlllllIlI);
      "".length();
      if ((0xAD ^ 0xA9) > -" ".length()) {}
    }
    else
    {
      mcProfiler.profilingEnabled = llllIIll[0];
      prevFrameTime = System.nanoTime();
    }
    guiAchievement.updateAchievementWindow();
    framebufferMc.unbindFramebuffer();
    GlStateManager.popMatrix();
    GlStateManager.pushMatrix();
    framebufferMc.framebufferRender(displayWidth, displayHeight);
    GlStateManager.popMatrix();
    GlStateManager.pushMatrix();
    entityRenderer.renderStreamIndicator(timer.renderPartialTicks);
    GlStateManager.popMatrix();
    mcProfiler.startSection(llIlIlII[llllIIll[73]]);
    lIIlllIllllllll.updateDisplay();
    Thread.yield();
    mcProfiler.startSection(llIlIlII[llllIIll[74]]);
    mcProfiler.startSection(llIlIlII[llllIIll[75]]);
    stream.func_152935_j();
    mcProfiler.endStartSection(llIlIlII[llllIIll[76]]);
    stream.func_152922_k();
    mcProfiler.endSection();
    mcProfiler.endSection();
    lIIlllIllllllll.checkGLError(llIlIlII[llllIIll[77]]);
    fpsCounter += llllIIll[1];
    if ((llIIlIIlII(lIIlllIllllllll.isSingleplayer())) && (llIIlIIIll(currentScreen)) && (llIIlIIlII(currentScreen.doesGuiPauseGame())) && (llIIlIIlIl(theIntegratedServer.getPublic())))
    {
      "".length();
      if ("   ".length() != 0) {
        break label912;
      }
    }
    label912:
    llllIIll1isGamePaused = llllIIll[0];
    long lIIlllIlllllIIl = System.nanoTime();
    field_181542_y.func_181747_a(lIIlllIlllllIIl - field_181543_z);
    field_181543_z = lIIlllIlllllIIl;
    "".length();
    if (((0x35 ^ 0x16) & (0x1C ^ 0x3F ^ 0xFFFFFFFF)) != ((0x91 ^ 0x83) & (0x48 ^ 0x5A ^ 0xFFFFFFFF))) {
      return;
    }
    label1089:
    label1152:
    label1299:
    label1379:
    label1477:
    label1531:
    while (!llIIlIlllI(llIIlIllII(getSystemTime(), debugUpdateTime + 1000L)))
    {
      debugFPS = fpsCounter;
      if (llIIlIllIl(RenderChunk.renderChunksUpdated, llllIIll[1]))
      {
        "".length();
        if ("   ".length() >= 0) {
          break label1089;
        }
      }
      llllIIll[3][llIlIlII[llllIIll[79]]] = llIlIlII[llllIIll[80]];
      if (llIIlIIlIl(llIIlIlIll(gameSettings.limitFramerate, GameSettings.Options.FRAMERATE_LIMIT.getValueMax())))
      {
        "".length();
        if (null == null) {
          break label1152;
        }
      }
      llllIIll[8][llIlIlII[llllIIll[81]]] = Integer.valueOf(gameSettings.limitFramerate);
      if (llIIlIIlII(gameSettings.enableVsync))
      {
        "".length();
        if (((0x73 ^ 0x9 ^ 0x84 ^ 0xA7) & (0x20 ^ 0xF ^ 0xC1 ^ 0xB7 ^ -" ".length())) == ((0 + '' - 33 + 60 ^ 75 + 117 - 183 + 138) & (44 + 113 - 118 + 121 ^ 71 + '¦' - 199 + 134 ^ -" ".length()))) {
          break label1299;
        }
      }
      llllIIll[9][llIlIlII[llllIIll[82]]] = llIlIlII[llllIIll[83]];
      if (llIIlIIlII(gameSettings.fancyGraphics))
      {
        "".length();
        if (((0x63 ^ 0x5B) & (0x80 ^ 0xB8 ^ 0xFFFFFFFF)) <= ((0x7B ^ 0x6F) & (0x12 ^ 0x6 ^ 0xFFFFFFFF))) {
          break label1379;
        }
      }
      llllIIll[10][llIlIlII[llllIIll[84]]] = llIlIlII[llllIIll[85]];
      if (llIIlIIlIl(gameSettings.clouds))
      {
        "".length();
        if (" ".length() != 0) {}
      }
      else if (llIIlIlIII(gameSettings.clouds, llllIIll[1]))
      {
        "".length();
        if (null == null) {
          break label1477;
        }
      }
      llIlIlII[llllIIll[86]][llIlIlII[llllIIll[87]]] = llIlIlII[llllIIll[88]];
      tmp1478_1386 = llllIIll[11];
      if (llIIlIIlII(OpenGlHelper.useVbo()))
      {
        "".length();
        if (" ".length() > 0) {
          break label1531;
        }
      }
      llllIIll[12][llIlIlII[llllIIll[89]]] = llIlIlII[llllIIll[90]];
      valueOfdebugFPSvalueOfrenderChunksUpdateddebug = String.format(tmp1478_1386, tmp1478_1386);
      RenderChunk.renderChunksUpdated = llllIIll[0];
      debugUpdateTime += 1000L;
      fpsCounter = llllIIll[91];
      usageSnooper.addMemoryStatsToSnooper();
      if (llIIlIIlIl(usageSnooper.isSnooperRunning())) {
        usageSnooper.startSnooper();
      }
    }
    if (llIIlIIlII(lIIlllIllllllll.isFramerateLimitBelowMax()))
    {
      mcProfiler.startSection(llIlIlII[llllIIll[92]]);
      Display.sync(lIIlllIllllllll.getLimitFramerate());
      mcProfiler.endSection();
    }
    mcProfiler.endSection();
  }
  
  public SoundHandler getSoundHandler()
  {
    ;
    return mcSoundHandler;
  }
  
  public <V> ListenableFuture<V> addScheduledTask(Callable<V> lIIllIlIIIIlIIl)
  {
    ;
    ;
    ;
    ;
    "".length();
    if (llIIlIIlIl(lIIllIlIIIIlIlI.isCallingFromMinecraftThread()))
    {
      ListenableFutureTask<V> lIIllIlIIIIlIII = ListenableFutureTask.create(lIIllIlIIIIlIIl);
      synchronized (scheduledTasks)
      {
        "".length();
        return lIIllIlIIIIlIII;
      }
    }
    try
    {
      return Futures.immediateFuture(lIIllIlIIIIlIIl.call());
    }
    catch (Exception lIIllIlIIIIIlll)
    {
      return Futures.immediateFailedCheckedFuture(lIIllIlIIIIIlll);
    }
  }
  
  public static void stopIntegratedServer()
  {
    ;
    if (llIIlIIIll(theMinecraft))
    {
      IntegratedServer lIIllIlIlIllIII = theMinecraft.getIntegratedServer();
      if (llIIlIIIll(lIIllIlIlIllIII)) {
        lIIllIlIlIllIII.stopServer();
      }
    }
  }
  
  public void setDimensionAndSpawnPlayer(int lIIllIllllIllll)
  {
    ;
    ;
    ;
    ;
    ;
    theWorld.setInitialSpawnLocation();
    theWorld.removeAllEntities();
    int lIIllIllllIlllI = llllIIll[0];
    String lIIllIllllIllIl = null;
    if (llIIlIIIll(thePlayer))
    {
      lIIllIllllIlllI = thePlayer.getEntityId();
      theWorld.removeEntity(thePlayer);
      lIIllIllllIllIl = thePlayer.getClientBrand();
    }
    renderViewEntity = null;
    EntityPlayerSP lIIllIllllIllII = thePlayer;
    if (llIIlIIIIl(thePlayer))
    {
      "".length();
      if (null == null) {
        break label115;
      }
    }
    label115:
    playerController.thePlayer = theWorld.func_178892_a(new StatFileWriter(), thePlayer.getStatFileWriter());
    thePlayer.getDataWatcher().updateWatchedObjectsFromList(lIIllIllllIllII.getDataWatcher().getAllWatched());
    thePlayer.dimension = lIIllIllllIllll;
    renderViewEntity = thePlayer;
    thePlayer.preparePlayerToSpawn();
    thePlayer.setClientBrand(lIIllIllllIllIl);
    "".length();
    playerController.flipPlayer(thePlayer);
    thePlayer.movementInput = new MovementInputFromOptions(gameSettings);
    thePlayer.setEntityId(lIIllIllllIlllI);
    playerController.setPlayerCapabilities(thePlayer);
    thePlayer.setReducedDebug(lIIllIllllIllII.hasReducedDebug());
    if (llIIlIIlII(currentScreen instanceof GuiGameOver)) {
      lIIllIllllIlIll.displayGuiScreen(null);
    }
  }
  
  private ItemStack func_181036_a(Item lIIllIllIlIlIlI, int lIIllIllIlIIIII, TileEntity lIIllIllIIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ItemStack lIIllIllIlIIlll = new ItemStack(lIIllIllIlIlIlI, llllIIll[1], lIIllIllIlIlIIl);
    NBTTagCompound lIIllIllIlIIllI = new NBTTagCompound();
    lIIllIllIIlllll.writeToNBT(lIIllIllIlIIllI);
    if ((llIIlIIIII(lIIllIllIlIlIlI, Items.skull)) && (llIIlIIlII(lIIllIllIlIIllI.hasKey(llIlIlII[llllIIll['']]))))
    {
      NBTTagCompound lIIllIllIlIIlIl = lIIllIllIlIIllI.getCompoundTag(llIlIlII[llllIIll['']]);
      NBTTagCompound lIIllIllIlIIlII = new NBTTagCompound();
      lIIllIllIlIIlII.setTag(llIlIlII[llllIIll['']], lIIllIllIlIIlIl);
      lIIllIllIlIIlll.setTagCompound(lIIllIllIlIIlII);
      return lIIllIllIlIIlll;
    }
    lIIllIllIlIIlll.setTagInfo(llIlIlII[llllIIll['']], lIIllIllIlIIllI);
    NBTTagCompound lIIllIllIlIIIll = new NBTTagCompound();
    NBTTagList lIIllIllIlIIIlI = new NBTTagList();
    lIIllIllIlIIIlI.appendTag(new NBTTagString(llIlIlII[llllIIll['']]));
    lIIllIllIlIIIll.setTag(llIlIlII[llllIIll['']], lIIllIllIlIIIlI);
    lIIllIllIlIIlll.setTagInfo(llIlIlII[llllIIll['']], lIIllIllIlIIIll);
    return lIIllIllIlIIlll;
  }
  
  public TextureMap getTextureMapBlocks()
  {
    ;
    return textureMapBlocks;
  }
  
  public void shutdown()
  {
    ;
    running = llllIIll[0];
  }
  
  public Entity getRenderViewEntity()
  {
    ;
    return renderViewEntity;
  }
  
  private void updateFramebufferSize()
  {
    ;
    framebufferMc.createBindFramebuffer(displayWidth, displayHeight);
    if (llIIlIIIll(entityRenderer)) {
      entityRenderer.updateShaderGroupSize(displayWidth, displayHeight);
    }
  }
  
  public PlayerUsageSnooper getPlayerUsageSnooper()
  {
    ;
    return usageSnooper;
  }
  
  public void func_181536_a(int lIIllllIlIIIIll, int lIIllllIlIIIIlI, int lIIllllIIllIlII, int lIIllllIIllIIll, int lIIllllIIllllll, int lIIllllIIlllllI, int lIIllllIIllIIII, int lIIllllIIllllII, int lIIllllIIlIlllI, int lIIllllIIlIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lIIllllIIlllIIl = 0.00390625F;
    float lIIllllIIlllIII = 0.00390625F;
    WorldRenderer lIIllllIIllIlll = Tessellator.getInstance().getWorldRenderer();
    lIIllllIIllIlll.begin(llllIIll[12], DefaultVertexFormats.POSITION_TEX_COLOR);
    lIIllllIIllIlll.pos(lIIllllIlIIIIll, lIIllllIlIIIIlI + lIIllllIIlllllI, 0.0D).tex(lIIllllIIllIlII * lIIllllIIlllIIl, (lIIllllIIllIIll + lIIllllIIlllllI) * lIIllllIIlllIII).color(lIIllllIIllIIII, lIIllllIIllllII, lIIllllIIlIlllI, lIIllllIIlIllIl).endVertex();
    lIIllllIIllIlll.pos(lIIllllIlIIIIll + lIIllllIIllllll, lIIllllIlIIIIlI + lIIllllIIlllllI, 0.0D).tex((lIIllllIIllIlII + lIIllllIIllllll) * lIIllllIIlllIIl, (lIIllllIIllIIll + lIIllllIIlllllI) * lIIllllIIlllIII).color(lIIllllIIllIIII, lIIllllIIllllII, lIIllllIIlIlllI, lIIllllIIlIllIl).endVertex();
    lIIllllIIllIlll.pos(lIIllllIlIIIIll + lIIllllIIllllll, lIIllllIlIIIIlI, 0.0D).tex((lIIllllIIllIlII + lIIllllIIllllll) * lIIllllIIlllIIl, lIIllllIIllIIll * lIIllllIIlllIII).color(lIIllllIIllIIII, lIIllllIIllllII, lIIllllIIlIlllI, lIIllllIIlIllIl).endVertex();
    lIIllllIIllIlll.pos(lIIllllIlIIIIll, lIIllllIlIIIIlI, 0.0D).tex(lIIllllIIllIlII * lIIllllIIlllIIl, lIIllllIIllIIll * lIIllllIIlllIII).color(lIIllllIIllIIII, lIIllllIIllllII, lIIllllIIlIlllI, lIIllllIIlIllIl).endVertex();
    Tessellator.getInstance().draw();
  }
  
  public void setIngameFocus()
  {
    ;
    if ((llIIlIIlII(Display.isActive())) && (llIIlIIlIl(inGameHasFocus)))
    {
      inGameHasFocus = llllIIll[1];
      mouseHelper.grabMouseCursor();
      lIIlllIlIIIIIIl.displayGuiScreen(null);
      leftClickCounter = llllIIll[114];
    }
  }
  
  private static int llIIlIllII(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  public void loadWorld(WorldClient lIIllIllllllIII, String lIIllIllllllIll)
  {
    ;
    ;
    ;
    ;
    if (llIIlIIIIl(lIIllIllllllIII))
    {
      NetHandlerPlayClient lIIllIllllllIlI = lIIllIllllllIIl.getNetHandler();
      if (llIIlIIIll(lIIllIllllllIlI)) {
        lIIllIllllllIlI.cleanup();
      }
      if ((llIIlIIIll(theIntegratedServer)) && (llIIlIIlII(theIntegratedServer.isAnvilFileSet())))
      {
        theIntegratedServer.initiateShutdown();
        theIntegratedServer.setStaticInstance();
      }
      theIntegratedServer = null;
      guiAchievement.clearAchievements();
      entityRenderer.getMapItemRenderer().clearLoadedMaps();
    }
    renderViewEntity = null;
    myNetworkManager = null;
    if (llIIlIIIll(loadingScreen))
    {
      loadingScreen.resetProgressAndMessage(lIIllIllllllIll);
      loadingScreen.displayLoadingString(llIlIlII[llllIIll['']]);
    }
    if ((llIIlIIIIl(lIIllIlllllllII)) && (llIIlIIIll(theWorld)))
    {
      mcResourcePackRepository.func_148529_f();
      ingameGUI.func_181029_i();
      lIIllIllllllIIl.setServerData(null);
      integratedServerIsRunning = llllIIll[0];
    }
    mcSoundHandler.stopSounds();
    theWorld = lIIllIlllllllII;
    if (llIIlIIIll(lIIllIlllllllII))
    {
      if (llIIlIIIll(renderGlobal)) {
        renderGlobal.setWorldAndLoadRenderers(lIIllIlllllllII);
      }
      if (llIIlIIIll(effectRenderer)) {
        effectRenderer.clearEffects(lIIllIlllllllII);
      }
      if (llIIlIIIIl(thePlayer))
      {
        thePlayer = playerController.func_178892_a(lIIllIlllllllII, new StatFileWriter());
        playerController.flipPlayer(thePlayer);
      }
      thePlayer.preparePlayerToSpawn();
      "".length();
      thePlayer.movementInput = new MovementInputFromOptions(gameSettings);
      playerController.setPlayerCapabilities(thePlayer);
      renderViewEntity = thePlayer;
      "".length();
      if ("   ".length() > "  ".length()) {}
    }
    else
    {
      saveLoader.flushCache();
      thePlayer = null;
    }
    System.gc();
    systemTime = 0L;
  }
  
  public CrashReport addGraphicsAndWorldToCrashReport(CrashReport lIIllIllIIlIlIl)
  {
    ;
    ;
    lIIllIllIIlIlIl.getCategory().addCrashSectionCallable(llIlIlII[llllIIll['']], new Callable()
    {
      public String call()
        throws Exception
      {
        ;
        return launchedVersion;
      }
    });
    lIIllIllIIlIlIl.getCategory().addCrashSectionCallable(llIlIlII[llllIIll['']], new Callable()
    {
      public String call()
      {
        return Sys.getVersion();
      }
    });
    lIIllIllIIlIlIl.getCategory().addCrashSectionCallable(llIlIlII[llllIIll['']], new Callable()
    {
      private static String lIIIllIlllIlI(String llllllllllllllllIlllIIlIIlIlIIll, String llllllllllllllllIlllIIlIIlIlIIlI)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllllIlllIIlIIlIlIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlllIIlIIlIlIIlI.getBytes(StandardCharsets.UTF_8)), lIlllIIllIl[6]), "DES");
          Cipher llllllllllllllllIlllIIlIIlIlIlIl = Cipher.getInstance("DES");
          llllllllllllllllIlllIIlIIlIlIlIl.init(lIlllIIllIl[5], llllllllllllllllIlllIIlIIlIlIllI);
          return new String(llllllllllllllllIlllIIlIIlIlIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllllIlllIIlIIlIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllllIlllIIlIIlIlIlII)
        {
          llllllllllllllllIlllIIlIIlIlIlII.printStackTrace();
        }
        return null;
      }
      
      private static void lIIIllIlllIll()
      {
        lIlllIIlIlI = new String[lIlllIIllIl[5]];
        lIlllIIlIlI[lIlllIIllIl[1]] = lIIIllIlllIlI("8ovFXOTXA+5KXixiQ1LUZA==", "icKGg");
        lIlllIIlIlI[lIlllIIllIl[3]] = lIIIllIlllIlI("A9vTz95h0Oo=", "JSLDv");
      }
      
      public String call()
      {
        return String.valueOf(new StringBuilder(String.valueOf(GL11.glGetString(lIlllIIllIl[0]))).append(lIlllIIlIlI[lIlllIIllIl[1]]).append(GL11.glGetString(lIlllIIllIl[2])).append(lIlllIIlIlI[lIlllIIllIl[3]]).append(GL11.glGetString(lIlllIIllIl[4])));
      }
      
      static
      {
        lIIIllIlllllI();
        lIIIllIlllIll();
      }
      
      private static void lIIIllIlllllI()
      {
        lIlllIIllIl = new int[7];
        lIlllIIllIl[0] = (0xFF35 & 0x1FCB);
        lIlllIIllIl[1] = (((0x5B ^ 0xE) & (0x27 ^ 0x72 ^ 0xFFFFFFFF) ^ 0xA8 ^ 0x8A) & (0xE ^ 0x2A ^ 0x2A ^ 0x2C ^ -" ".length()));
        lIlllIIllIl[2] = (-(0xAAFF & 0x75E1) & 0xFFFFFFF7 & 0x3FEA);
        lIlllIIllIl[3] = " ".length();
        lIlllIIllIl[4] = (0xDF03 & 0x3FFC);
        lIlllIIllIl[5] = "  ".length();
        lIlllIIllIl[6] = (0x78 ^ 0x70);
      }
    });
    lIIllIllIIlIlIl.getCategory().addCrashSectionCallable(llIlIlII[llllIIll['']], new Callable()
    {
      public String call()
      {
        return OpenGlHelper.getLogText();
      }
    });
    lIIllIllIIlIlIl.getCategory().addCrashSectionCallable(llIlIlII[llllIIll[' ']], new Callable()
    {
      private static boolean lIIIIIlIlIlllI(int ???, int arg1)
      {
        int i;
        char lllllllllllllllIlIIIIlllIlIIlIIl;
        return ??? < i;
      }
      
      private static void lIIIIIlIlIllII()
      {
        lIlIlIIIIlII = new int[3];
        lIlIlIIIIlII[0] = ((0x45 ^ 0x9 ^ 0xCD ^ 0xA4) & (0x8F ^ 0xAC ^ 0x33 ^ 0x35 ^ -" ".length()));
        lIlIlIIIIlII[1] = " ".length();
        lIlIlIIIIlII[2] = "  ".length();
      }
      
      private static void lIIIIIlIIlllIl()
      {
        lIlIIlllllll = new String[lIlIlIIIIlII[2]];
        lIlIIlllllll[lIlIlIIIIlII[0]] = lIIIIIlIIllIll("CzE8", "RTONt");
        lIlIIlllllll[lIlIlIIIIlII[1]] = lIIIIIlIIlllII("6uY4dDGgJcc=", "JpiYT");
      }
      
      private static String lIIIIIlIIllIll(String lllllllllllllllIlIIIIlllIlIlIlIl, String lllllllllllllllIlIIIIlllIlIllIIl)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        lllllllllllllllIlIIIIlllIlIlIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIlIIIIlllIlIlIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder lllllllllllllllIlIIIIlllIlIllIII = new StringBuilder();
        char[] lllllllllllllllIlIIIIlllIlIlIlll = lllllllllllllllIlIIIIlllIlIllIIl.toCharArray();
        int lllllllllllllllIlIIIIlllIlIlIllI = lIlIlIIIIlII[0];
        Exception lllllllllllllllIlIIIIlllIlIlIIII = lllllllllllllllIlIIIIlllIlIlIlIl.toCharArray();
        long lllllllllllllllIlIIIIlllIlIIllll = lllllllllllllllIlIIIIlllIlIlIIII.length;
        String lllllllllllllllIlIIIIlllIlIIlllI = lIlIlIIIIlII[0];
        while (lIIIIIlIlIlllI(lllllllllllllllIlIIIIlllIlIIlllI, lllllllllllllllIlIIIIlllIlIIllll))
        {
          char lllllllllllllllIlIIIIlllIlIllIll = lllllllllllllllIlIIIIlllIlIlIIII[lllllllllllllllIlIIIIlllIlIIlllI];
          "".length();
          "".length();
          if (" ".length() > " ".length()) {
            return null;
          }
        }
        return String.valueOf(lllllllllllllllIlIIIIlllIlIllIII);
      }
      
      private static boolean lIIIIIlIlIllIl(int ???)
      {
        float lllllllllllllllIlIIIIlllIlIIIlll;
        return ??? != 0;
      }
      
      public String call()
      {
        ;
        if (lIIIIIlIlIllIl(gameSettings.useVbo))
        {
          "".length();
          if ((0x67 ^ 0x63) != 0) {
            break label50;
          }
          return null;
        }
        label50:
        return lIlIIlllllll[lIlIlIIIIlII[1]];
      }
      
      private static String lIIIIIlIIlllII(String lllllllllllllllIlIIIIlllIllIlIlI, String lllllllllllllllIlIIIIlllIllIlIIl)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllllllllllllllIlIIIIlllIllIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIIIIlllIllIlIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher lllllllllllllllIlIIIIlllIllIllII = Cipher.getInstance("Blowfish");
          lllllllllllllllIlIIIIlllIllIllII.init(lIlIlIIIIlII[2], lllllllllllllllIlIIIIlllIllIllIl);
          return new String(lllllllllllllllIlIIIIlllIllIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIIIIlllIllIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllllllllllllllIlIIIIlllIllIlIll)
        {
          lllllllllllllllIlIIIIlllIllIlIll.printStackTrace();
        }
        return null;
      }
      
      static
      {
        lIIIIIlIlIllII();
        lIIIIIlIIlllIl();
      }
    });
    lIIllIllIIlIlIl.getCategory().addCrashSectionCallable(llIlIlII[llllIIll['¡']], new Callable()
    {
      private static boolean llIlIIIlIllll(int ???)
      {
        int lllllllllllllllIllllIIIlIlIlIllI;
        return ??? == 0;
      }
      
      private static void llIlIIIlIlllI()
      {
        lIIIIlllIIll = new int[7];
        lIIIIlllIIll[0] = ((0x4B ^ 0x43) & (0x8B ^ 0x83 ^ 0xFFFFFFFF));
        lIIIIlllIIll[1] = " ".length();
        lIIIIlllIIll[2] = "  ".length();
        lIIIIlllIIll[3] = "   ".length();
        lIIIIlllIIll[4] = (0x6A ^ 0x6E);
        lIIIIlllIIll[5] = (0xA9 ^ 0xAC);
        lIIIIlllIIll[6] = (0xB5 ^ 0xBD);
      }
      
      public String call()
        throws Exception
      {
        ;
        String lllllllllllllllIllllIIIllIIlIIll = ClientBrandRetriever.getClientModName();
        if (llIlIIIlIllll(lllllllllllllllIllllIIIllIIlIIll.equals(lIIIIlllIIlI[lIIIIlllIIll[0]])))
        {
          new StringBuilder(lIIIIlllIIlI[lIIIIlllIIll[1]]);
          "".length();
          if (null != null) {
            return null;
          }
        }
        else if (llIlIIIllIIII(Minecraft.class.getSigners()))
        {
          "".length();
          if (-"   ".length() < 0) {
            break label116;
          }
          return null;
        }
        label116:
        return lIIIIlllIIlI[lIIIIlllIIll[4]];
      }
      
      private static boolean llIlIIIllIIII(Object ???)
      {
        double lllllllllllllllIllllIIIlIlIllIII;
        return ??? == null;
      }
      
      private static void llIlIIIlIlIll()
      {
        lIIIIlllIIlI = new String[lIIIIlllIIll[5]];
        lIIIIlllIIlI[lIIIIlllIIll[0]] = llIlIIIlIIlll("hqOYYjcjd4E=", "LEEsP");
        lIIIIlllIIlI[lIIIIlllIIll[1]] = llIlIIIlIlIIl("Mgw/LiAfHTwrN01JGisnEwctZywECDcjbhUBOCkpEw15MyFWTg==", "viYGN");
        lIIIIlllIIlI[lIIIIlllIIll[2]] = llIlIIIlIlIIl("bg==", "IEJcY");
        lIIIIlllIIlI[lIIIIlllIIll[3]] = llIlIIIlIlIlI("5rEKkpfq5fBcXJy7U8Gz9ITwnERe0TKUTE1GOImIiLUJngPUd4EMcg==", "XTMDO");
        lIIIIlllIIlI[lIIIIlllIIll[4]] = llIlIIIlIIlll("A/Fs2fZb+FIh4MiFvCEtM/X9wZ2IdNwg7xoSzSneV473G0Rc+SyeXZKSHl0uorTVHti29Z1sqiaqwVYuycQh1pDdVsuKmQNQ", "JyeUN");
      }
      
      private static boolean llIlIIIllIIIl(int ???, int arg1)
      {
        int i;
        short lllllllllllllllIllllIIIlIlIllIlI;
        return ??? < i;
      }
      
      private static String llIlIIIlIIlll(String lllllllllllllllIllllIIIlIllIIIIl, String lllllllllllllllIllllIIIlIllIIIlI)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllllllllllllllIllllIIIlIllIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIlIllIIIlI.getBytes(StandardCharsets.UTF_8)), lIIIIlllIIll[6]), "DES");
          Cipher lllllllllllllllIllllIIIlIllIIlIl = Cipher.getInstance("DES");
          lllllllllllllllIllllIIIlIllIIlIl.init(lIIIIlllIIll[2], lllllllllllllllIllllIIIlIllIIllI);
          return new String(lllllllllllllllIllllIIIlIllIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIlIllIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllllllllllllllIllllIIIlIllIIlII)
        {
          lllllllllllllllIllllIIIlIllIIlII.printStackTrace();
        }
        return null;
      }
      
      static
      {
        llIlIIIlIlllI();
        llIlIIIlIlIll();
      }
      
      private static String llIlIIIlIlIlI(String lllllllllllllllIllllIIIlIlllIIII, String lllllllllllllllIllllIIIlIllIllIl)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllllllllllllllIllllIIIlIlllIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIlIllIllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher lllllllllllllllIllllIIIlIlllIIlI = Cipher.getInstance("Blowfish");
          lllllllllllllllIllllIIIlIlllIIlI.init(lIIIIlllIIll[2], lllllllllllllllIllllIIIlIlllIIll);
          return new String(lllllllllllllllIllllIIIlIlllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIlIlllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllllllllllllllIllllIIIlIlllIIIl)
        {
          lllllllllllllllIllllIIIlIlllIIIl.printStackTrace();
        }
        return null;
      }
      
      private static String llIlIIIlIlIIl(String lllllllllllllllIllllIIIllIIIIlIl, String lllllllllllllllIllllIIIllIIIIlII)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        lllllllllllllllIllllIIIllIIIIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIllllIIIllIIIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder lllllllllllllllIllllIIIllIIIIIll = new StringBuilder();
        char[] lllllllllllllllIllllIIIllIIIIIlI = lllllllllllllllIllllIIIllIIIIlII.toCharArray();
        int lllllllllllllllIllllIIIllIIIIIIl = lIIIIlllIIll[0];
        double lllllllllllllllIllllIIIlIllllIll = lllllllllllllllIllllIIIllIIIIlIl.toCharArray();
        float lllllllllllllllIllllIIIlIllllIlI = lllllllllllllllIllllIIIlIllllIll.length;
        int lllllllllllllllIllllIIIlIllllIIl = lIIIIlllIIll[0];
        while (llIlIIIllIIIl(lllllllllllllllIllllIIIlIllllIIl, lllllllllllllllIllllIIIlIllllIlI))
        {
          char lllllllllllllllIllllIIIllIIIIllI = lllllllllllllllIllllIIIlIllllIll[lllllllllllllllIllllIIIlIllllIIl];
          "".length();
          "".length();
          if (((0xA8 ^ 0xB8) & (0x10 ^ 0x0 ^ 0xFFFFFFFF)) != 0) {
            return null;
          }
        }
        return String.valueOf(lllllllllllllllIllllIIIllIIIIIll);
      }
    });
    lIIllIllIIlIlIl.getCategory().addCrashSectionCallable(llIlIlII[llllIIll['¢']], new Callable()
    {
      private static void lIIIllIIlIIIlI()
      {
        lIllIlIlllll = new int[4];
        lIllIlIlllll[0] = ((0x5E ^ 0x6A) & (0xBA ^ 0x8E ^ 0xFFFFFFFF));
        lIllIlIlllll[1] = " ".length();
        lIllIlIlllll[2] = (0x90 ^ 0x98);
        lIllIlIlllll[3] = "  ".length();
      }
      
      public String call()
        throws Exception
      {
        return lIllIlIllllI[lIllIlIlllll[0]];
      }
      
      private static String lIIIllIIlIIIII(String lllllllllllllllIIllIIIlIIlIIIlll, String lllllllllllllllIIllIIIlIIlIIIlII)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllllllllllllllIIllIIIlIIlIIlIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIIIlIIlIIIlII.getBytes(StandardCharsets.UTF_8)), lIllIlIlllll[2]), "DES");
          Cipher lllllllllllllllIIllIIIlIIlIIlIIl = Cipher.getInstance("DES");
          lllllllllllllllIIllIIIlIIlIIlIIl.init(lIllIlIlllll[3], lllllllllllllllIIllIIIlIIlIIlIlI);
          return new String(lllllllllllllllIIllIIIlIIlIIlIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIIIlIIlIIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllllllllllllllIIllIIIlIIlIIlIII)
        {
          lllllllllllllllIIllIIIlIIlIIlIII.printStackTrace();
        }
        return null;
      }
      
      static
      {
        lIIIllIIlIIIlI();
        lIIIllIIlIIIIl();
      }
      
      private static void lIIIllIIlIIIIl()
      {
        lIllIlIllllI = new String[lIllIlIlllll[1]];
        lIllIlIllllI[lIllIlIlllll[0]] = lIIIllIIlIIIII("OSTAP1dHJWRE20rpqJaLl/fKWifNZaLU", "rOtov");
      }
    });
    lIIllIllIIlIlIl.getCategory().addCrashSectionCallable(llIlIlII[llllIIll['£']], new Callable()
    {
      private static String lIIIlllllIl(String lllIllIllllIlI, String lllIllIlllIlll)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllIllIlllllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllIllIlllIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher lllIllIlllllII = Cipher.getInstance("Blowfish");
          lllIllIlllllII.init(lIllIIIlI[2], lllIllIlllllIl);
          return new String(lllIllIlllllII.doFinal(Base64.getDecoder().decode(lllIllIllllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllIllIllllIll)
        {
          lllIllIllllIll.printStackTrace();
        }
        return null;
      }
      
      private static void lIIlIIIIlll()
      {
        lIllIIIlI = new int[3];
        lIllIIIlI[0] = ((113 + '»' - 158 + 58 ^ 67 + 20 - -72 + 35) & (94 + 48 - 113 + 173 ^ 31 + 80 - 60 + 141 ^ -" ".length()));
        lIllIIIlI[1] = " ".length();
        lIllIIIlI[2] = "  ".length();
      }
      
      private static String lIIIllllllI(String lllIllIllIlIlI, String lllIllIllIlIIl)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        lllIllIllIlIlI = new String(Base64.getDecoder().decode(lllIllIllIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder lllIllIllIlIII = new StringBuilder();
        char[] lllIllIllIIlll = lllIllIllIlIIl.toCharArray();
        int lllIllIllIIllI = lIllIIIlI[0];
        float lllIllIllIIIII = lllIllIllIlIlI.toCharArray();
        long lllIllIlIlllll = lllIllIllIIIII.length;
        int lllIllIlIllllI = lIllIIIlI[0];
        while (lIIlIIIlIll(lllIllIlIllllI, lllIllIlIlllll))
        {
          char lllIllIllIlIll = lllIllIllIIIII[lllIllIlIllllI];
          "".length();
          "".length();
          if (((0x87 ^ 0x90) & (0x4D ^ 0x5A ^ 0xFFFFFFFF)) > ((0x30 ^ 0x60) & (0x7C ^ 0x2C ^ 0xFFFFFFFF))) {
            return null;
          }
        }
        return String.valueOf(lllIllIllIlIII);
      }
      
      public String call()
        throws Exception
      {
        ;
        ;
        ;
        StringBuilder lllIlllIIIlIIl = new StringBuilder();
        float lllIlllIIIIlII = gameSettings.resourcePacks.iterator();
        "".length();
        if (((0xFA ^ 0xBF) & (0xF8 ^ 0xBD ^ 0xFFFFFFFF)) != 0) {
          return null;
        }
        while (!lIIlIIIlIlI(lllIlllIIIIlII.hasNext()))
        {
          Object lllIlllIIIlIII = lllIlllIIIIlII.next();
          if (lIIlIIIlIII(lllIlllIIIlIIl.length())) {
            "".length();
          }
          "".length();
          if (lIIlIIIlIIl(gameSettings.field_183018_l.contains(lllIlllIIIlIII))) {
            "".length();
          }
        }
        return String.valueOf(lllIlllIIIlIIl);
      }
      
      private static boolean lIIlIIIlIIl(int ???)
      {
        int lllIllIlIlIlll;
        return ??? != 0;
      }
      
      private static boolean lIIlIIIlIll(int ???, int arg1)
      {
        int i;
        char lllIllIlIllIIl;
        return ??? < i;
      }
      
      private static boolean lIIlIIIlIlI(int ???)
      {
        int lllIllIlIlIlIl;
        return ??? == 0;
      }
      
      private static void lIIIlllllll()
      {
        lIlIlllII = new String[lIllIIIlI[2]];
        lIlIlllII[lIllIIIlI[0]] = lIIIlllllIl("Jf/1bA6KdRI=", "dPsru");
        lIlIlllII[lIllIIIlI[1]] = lIIIllllllI("ekk+KjU1DCclIjMDOyF/", "ZaWDV");
      }
      
      private static boolean lIIlIIIlIII(int ???)
      {
        short lllIllIlIlIIll;
        return ??? > 0;
      }
      
      static
      {
        lIIlIIIIlll();
        lIIIlllllll();
      }
    });
    lIIllIllIIlIlIl.getCategory().addCrashSectionCallable(llIlIlII[llllIIll['¤']], new Callable()
    {
      public String call()
        throws Exception
      {
        ;
        return mcLanguageManager.getCurrentLanguage().toString();
      }
    });
    lIIllIllIIlIlIl.getCategory().addCrashSectionCallable(llIlIlII[llllIIll['¥']], new Callable()
    {
      static
      {
        lIIIIlllIllll();
        lIIIIlllIlllI();
      }
      
      private static void lIIIIlllIlllI()
      {
        lIlIllllIII = new String[lIlIllllIll[1]];
        lIlIllllIII[lIlIllllIll[0]] = lIIIIlllIllIl("AWjojnlllewygna5opf9PA==", "KrjbG");
      }
      
      private static boolean lIIIIllllIIII(int ???)
      {
        int llllllllllllllllIlllllllllIllIIl;
        return ??? != 0;
      }
      
      public String call()
        throws Exception
      {
        ;
        if (lIIIIllllIIII(mcProfiler.profilingEnabled))
        {
          "".length();
          if (" ".length() >= " ".length()) {
            break label56;
          }
          return null;
        }
        label56:
        return lIlIllllIII[lIlIllllIll[0]];
      }
      
      private static void lIIIIlllIllll()
      {
        lIlIllllIll = new int[3];
        lIlIllllIll[0] = ((0x49 ^ 0x31 ^ 0xD4 ^ 0x80) & (0xAF ^ 0x95 ^ 0x17 ^ 0x1 ^ -" ".length()));
        lIlIllllIll[1] = " ".length();
        lIlIllllIll[2] = "  ".length();
      }
      
      private static String lIIIIlllIllIl(String llllllllllllllllIllllllllllIIIII, String llllllllllllllllIlllllllllIlllIl)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllllIllllllllllIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlllllllllIlllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher llllllllllllllllIllllllllllIIIlI = Cipher.getInstance("Blowfish");
          llllllllllllllllIllllllllllIIIlI.init(lIlIllllIll[2], llllllllllllllllIllllllllllIIIll);
          return new String(llllllllllllllllIllllllllllIIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllIllllllllllIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllllIllllllllllIIIIl)
        {
          llllllllllllllllIllllllllllIIIIl.printStackTrace();
        }
        return null;
      }
    });
    lIIllIllIIlIlIl.getCategory().addCrashSectionCallable(llIlIlII[llllIIll['¦']], new Callable()
    {
      public String call()
      {
        return OpenGlHelper.func_183029_j();
      }
    });
    if (llIIlIIIll(theWorld)) {
      "".length();
    }
    return lIIllIllIIlIlIl;
  }
  
  public Minecraft(GameConfiguration lIlIIIIIIlIlIlI)
  {
    theMinecraft = lIlIIIIIIlIlIll;
    mcDataDir = folderInfo.mcDataDir;
    fileAssets = folderInfo.assetsDir;
    fileResourcepacks = folderInfo.resourcePacksDir;
    launchedVersion = gameInfo.version;
    twitchDetails = userInfo.userProperties;
    field_181038_N = userInfo.field_181172_c;
    mcDefaultResourcePack = new DefaultResourcePack(new ResourceIndex(folderInfo.assetsDir, folderInfo.assetIndex).getResourceMap());
    if (llIIlIIIIl(userInfo.proxy))
    {
      "".length();
      if (" ".length() > 0) {
        break label373;
      }
      throw null;
    }
    label373:
    NO_PROXYproxy = userInfo.proxy;
    sessionService = new YggdrasilAuthenticationService(userInfo.proxy, UUID.randomUUID().toString()).createMinecraftSessionService();
    session = userInfo.session;
    logger.info(String.valueOf(new StringBuilder(llIlIlII[llllIIll[9]]).append(session.getUsername())));
    logger.info(String.valueOf(new StringBuilder(llIlIlII[llllIIll[10]]).append(session.getSessionID()).append(llIlIlII[llllIIll[11]])));
    isDemo = gameInfo.isDemo;
    if (llIIlIIIlI(displayInfo.width))
    {
      "".length();
      if ((0x98 ^ 0x9D) != 0) {
        break label559;
      }
      throw null;
    }
    label559:
    displayInfo.width.displayWidth = llllIIll[1];
    if (llIIlIIIlI(displayInfo.height))
    {
      "".length();
      if (-" ".length() != "   ".length()) {
        break label613;
      }
      throw null;
    }
    label613:
    displayInfo.height.displayHeight = llllIIll[1];
    tempDisplayWidth = displayInfo.width;
    tempDisplayHeight = displayInfo.height;
    fullscreen = displayInfo.fullscreen;
    jvm64bit = isJvm64bit();
    theIntegratedServer = new IntegratedServer(lIlIIIIIIlIlIll);
    if (llIIlIIIll(serverInfo.serverName))
    {
      serverName = serverInfo.serverName;
      serverPort = serverInfo.serverPort;
    }
    ImageIO.setUseCache(llllIIll[0]);
    Bootstrap.register();
    WingsManager.loadWings();
    OgunekManager.loadWings();
    ItemMadufakaSrakaManager.loadWings();
  }
  
  public ListenableFuture<Object> addScheduledTask(Runnable lIIllIIllllllll)
  {
    ;
    ;
    "".length();
    return lIIllIIlllllllI.addScheduledTask(Executors.callable(lIIllIIllllllll));
  }
  
  private void resize(int lIIlllIIlIlIIII, int lIIlllIIlIIlIll)
  {
    ;
    ;
    ;
    ;
    displayWidth = Math.max(llllIIll[1], lIIlllIIlIIllII);
    displayHeight = Math.max(llllIIll[1], lIIlllIIlIIlIll);
    if (llIIlIIIll(currentScreen))
    {
      ScaledResolution lIIlllIIlIIlllI = new ScaledResolution(lIIlllIIlIlIIIl);
      currentScreen.onResize(lIIlllIIlIlIIIl, ScaledResolution.getScaledWidth(), lIIlllIIlIIlllI.getScaledHeight());
    }
    loadingScreen = new LoadingScreenRenderer(lIIlllIIlIlIIIl);
    lIIlllIIlIlIIIl.updateFramebufferSize();
  }
  
  public boolean isUnicode()
  {
    ;
    if ((llIIlIIlIl(mcLanguageManager.isCurrentLocaleUnicode())) && (llIIlIIlIl(gameSettings.forceUnicodeFont))) {
      return llllIIll[0];
    }
    return llllIIll[1];
  }
  
  private static boolean llIIlIIIII(Object ???, Object arg1)
  {
    Object localObject;
    double lIIllIIlIIIllIl;
    return ??? == localObject;
  }
  
  private void middleClickMouse()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIlIIIll(objectMouseOver))
    {
      boolean lIIllIlllIlIllI = thePlayer.capabilities.isCreativeMode;
      int lIIllIlllIlIlIl = llllIIll[0];
      boolean lIIllIlllIlIlII = llllIIll[0];
      TileEntity lIIllIlllIlIIll = null;
      label193:
      Item lIIllIlllIIIlIl;
      if (llIIlIIIII(objectMouseOver.typeOfHit, MovingObjectPosition.MovingObjectType.BLOCK))
      {
        BlockPos lIIllIlllIIIlII = objectMouseOver.getBlockPos();
        Block lIIllIlllIIIIll = theWorld.getBlockState(lIIllIlllIIIlII).getBlock();
        if (llIIlIIIII(lIIllIlllIIIIll.getMaterial(), Material.air)) {
          return;
        }
        Item lIIllIlllIlIIlI = lIIllIlllIIIIll.getItem(theWorld, lIIllIlllIIIlII);
        if (llIIlIIIIl(lIIllIlllIlIIlI)) {
          return;
        }
        if ((llIIlIIlII(lIIllIlllIlIllI)) && (llIIlIIlII(GuiScreen.isCtrlKeyDown()))) {
          lIIllIlllIlIIll = theWorld.getTileEntity(lIIllIlllIIIlII);
        }
        if ((llIIlIIlII(lIIllIlllIlIIlI instanceof ItemBlock)) && (llIIlIIlIl(lIIllIlllIIIIll.isFlowerPot())))
        {
          "".length();
          if ("  ".length() < "   ".length()) {
            break label193;
          }
        }
        Block lIIllIlllIIIIlI = lIIllIlllIIIIll;
        lIIllIlllIlIlIl = lIIllIlllIIIIlI.getDamageValue(theWorld, lIIllIlllIIIlII);
        lIIllIlllIlIlII = lIIllIlllIlIIlI.getHasSubtypes();
        "".length();
        if (null == null) {}
      }
      else
      {
        if ((!llIIlIIIII(objectMouseOver.typeOfHit, MovingObjectPosition.MovingObjectType.ENTITY)) || (!llIIlIIIll(objectMouseOver.entityHit)) || (llIIlIIlIl(lIIllIlllIlIllI))) {
          return;
        }
        if (llIIlIIlII(objectMouseOver.entityHit instanceof EntityPainting))
        {
          Item lIIllIlllIlIIIl = Items.painting;
          "".length();
          if (((0xDB ^ 0xC6 ^ 0xD ^ 0x36) & (0x25 ^ 0x1A ^ 0x87 ^ 0x9E ^ -" ".length())) != "   ".length()) {}
        }
        else if (llIIlIIlII(objectMouseOver.entityHit instanceof EntityLeashKnot))
        {
          Item lIIllIlllIlIIII = Items.lead;
          "".length();
          if (null == null) {}
        }
        else if (llIIlIIlII(objectMouseOver.entityHit instanceof EntityItemFrame))
        {
          EntityItemFrame lIIllIlllIIIIIl = (EntityItemFrame)objectMouseOver.entityHit;
          ItemStack lIIllIlllIIIIII = lIIllIlllIIIIIl.getDisplayedItem();
          if (llIIlIIIIl(lIIllIlllIIIIII))
          {
            Item lIIllIlllIIllll = Items.item_frame;
            "".length();
            if ("   ".length() != ((0x65 ^ 0x25) & (0x48 ^ 0x8 ^ 0xFFFFFFFF))) {}
          }
          else
          {
            Item lIIllIlllIIlllI = lIIllIlllIIIIII.getItem();
            lIIllIlllIlIlIl = lIIllIlllIIIIII.getMetadata();
            lIIllIlllIlIlII = llllIIll[1];
            "".length();
            if ("  ".length() >= 0) {}
          }
        }
        else if (llIIlIIlII(objectMouseOver.entityHit instanceof EntityMinecart))
        {
          EntityMinecart lIIllIllIllllll = (EntityMinecart)objectMouseOver.entityHit;
          switch ($SWITCH_TABLE$net$minecraft$entity$item$EntityMinecart$EnumMinecartType()[lIIllIllIllllll.getMinecartType().ordinal()])
          {
          case 3: 
            Item lIIllIlllIIllIl = Items.furnace_minecart;
            "".length();
            if ("  ".length() >= 0) {
              break;
            }
            return;
          case 2: 
            Item lIIllIlllIIllII = Items.chest_minecart;
            "".length();
            if (-" ".length() != ((0xE7 ^ 0xC7) & (0x17 ^ 0x37 ^ 0xFFFFFFFF))) {
              break;
            }
            return;
          case 4: 
            Item lIIllIlllIIlIll = Items.tnt_minecart;
            "".length();
            if (-" ".length() <= ((0x8A ^ 0x98) & (0x64 ^ 0x76 ^ 0xFFFFFFFF))) {
              break;
            }
            return;
          case 6: 
            Item lIIllIlllIIlIlI = Items.hopper_minecart;
            "".length();
            if ((0x10 ^ 0x25 ^ 0x7C ^ 0x4D) >= 0) {
              break;
            }
            return;
          case 7: 
            Item lIIllIlllIIlIIl = Items.command_block_minecart;
            "".length();
            if ("  ".length() != 0) {
              break;
            }
            return;
          case 5: 
          default: 
            Item lIIllIlllIIlIII = Items.minecart;
            "".length();
            if (((0x52 ^ 0x7A) & (0x4F ^ 0x67 ^ 0xFFFFFFFF)) <= " ".length()) {
              break;
            }
            return;
          }
        }
        else if (llIIlIIlII(objectMouseOver.entityHit instanceof EntityBoat))
        {
          Item lIIllIlllIIIlll = Items.boat;
          "".length();
          if (-"  ".length() <= 0) {}
        }
        else if (llIIlIIlII(objectMouseOver.entityHit instanceof EntityArmorStand))
        {
          Item lIIllIlllIIIllI = Items.armor_stand;
          "".length();
          if ((0xB9 ^ 0xBC) > 0) {}
        }
        else
        {
          lIIllIlllIIIlIl = Items.spawn_egg;
          lIIllIlllIlIlIl = EntityList.getEntityID(objectMouseOver.entityHit);
          lIIllIlllIlIlII = llllIIll[1];
          if (llIIlIIlIl(EntityList.entityEggs.containsKey(Integer.valueOf(lIIllIlllIlIlIl)))) {
            return;
          }
        }
      }
      InventoryPlayer lIIllIllIlllllI = thePlayer.inventory;
      if (llIIlIIIIl(lIIllIlllIlIIll))
      {
        lIIllIllIlllllI.setCurrentItem(lIIllIlllIIIlIl, lIIllIlllIlIlIl, lIIllIlllIlIlII, lIIllIlllIlIllI);
        "".length();
        if (null == null) {}
      }
      else
      {
        ItemStack lIIllIllIllllIl = lIIllIllIlllIll.func_181036_a(lIIllIlllIIIlIl, lIIllIlllIlIlIl, lIIllIlllIlIIll);
        lIIllIllIlllllI.setInventorySlotContents(currentItem, lIIllIllIllllIl);
      }
      if (llIIlIIlII(lIIllIlllIlIllI))
      {
        int lIIllIllIllllII = thePlayer.inventoryContainer.inventorySlots.size() - llllIIll[14] + currentItem;
        playerController.sendSlotPacket(lIIllIllIlllllI.getStackInSlot(currentItem), lIIllIllIllllII);
      }
    }
  }
  
  private static int llIIllIIll(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  private ByteBuffer readImageToBuffer(InputStream lIIlllllIlIIIll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    BufferedImage lIIlllllIlIIlll = ImageIO.read(lIIlllllIlIIIll);
    int[] lIIlllllIlIIllI = lIIlllllIlIIlll.getRGB(llllIIll[0], llllIIll[0], lIIlllllIlIIlll.getWidth(), lIIlllllIlIIlll.getHeight(), null, llllIIll[0], lIIlllllIlIIlll.getWidth());
    ByteBuffer lIIlllllIlIIlIl = ByteBuffer.allocate(llllIIll[9] * lIIlllllIlIIllI.length);
    long lIIlllllIIlllIl = (lIIlllllIIlllII = lIIlllllIlIIllI).length;
    byte lIIlllllIIllllI = llllIIll[0];
    "".length();
    if (((0x2C ^ 0x63) & (0x2A ^ 0x65 ^ 0xFFFFFFFF)) != 0) {
      return null;
    }
    while (!llIIlIIlll(lIIlllllIIllllI, lIIlllllIIlllIl))
    {
      int lIIlllllIlIIlII = lIIlllllIIlllII[lIIlllllIIllllI];
      "".length();
    }
    "".length();
    return lIIlllllIlIIlIl;
  }
  
  public void addServerTypeToSnooper(PlayerUsageSnooper lIIllIlIlllIllI)
  {
    ;
    ;
    ;
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['º']], GL11.glGetString(llllIIll['»']));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['¼']], GL11.glGetString(llllIIll['½']));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['¾']], ClientBrandRetriever.getClientModName());
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['¿']], launchedVersion);
    ContextCapabilities lIIllIlIllllIII = GLContext.getCapabilities();
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['À']], Boolean.valueOf(GL_ARB_arrays_of_arrays));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Á']], Boolean.valueOf(GL_ARB_base_instance));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Â']], Boolean.valueOf(GL_ARB_blend_func_extended));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ã']], Boolean.valueOf(GL_ARB_clear_buffer_object));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ä']], Boolean.valueOf(GL_ARB_color_buffer_float));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Å']], Boolean.valueOf(GL_ARB_compatibility));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Æ']], Boolean.valueOf(GL_ARB_compressed_texture_pixel_storage));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ç']], Boolean.valueOf(GL_ARB_compute_shader));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['È']], Boolean.valueOf(GL_ARB_copy_buffer));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['É']], Boolean.valueOf(GL_ARB_copy_image));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ê']], Boolean.valueOf(GL_ARB_depth_buffer_float));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ë']], Boolean.valueOf(GL_ARB_compute_shader));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ì']], Boolean.valueOf(GL_ARB_copy_buffer));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Í']], Boolean.valueOf(GL_ARB_copy_image));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Î']], Boolean.valueOf(GL_ARB_depth_buffer_float));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ï']], Boolean.valueOf(GL_ARB_depth_clamp));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ð']], Boolean.valueOf(GL_ARB_depth_texture));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ñ']], Boolean.valueOf(GL_ARB_draw_buffers));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ò']], Boolean.valueOf(GL_ARB_draw_buffers_blend));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ó']], Boolean.valueOf(GL_ARB_draw_elements_base_vertex));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ô']], Boolean.valueOf(GL_ARB_draw_indirect));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Õ']], Boolean.valueOf(GL_ARB_draw_instanced));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ö']], Boolean.valueOf(GL_ARB_explicit_attrib_location));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['×']], Boolean.valueOf(GL_ARB_explicit_uniform_location));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ø']], Boolean.valueOf(GL_ARB_fragment_layer_viewport));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ù']], Boolean.valueOf(GL_ARB_fragment_program));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ú']], Boolean.valueOf(GL_ARB_fragment_shader));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Û']], Boolean.valueOf(GL_ARB_fragment_program_shadow));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ü']], Boolean.valueOf(GL_ARB_framebuffer_object));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ý']], Boolean.valueOf(GL_ARB_framebuffer_sRGB));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll[98]], Boolean.valueOf(GL_ARB_geometry_shader4));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Þ']], Boolean.valueOf(GL_ARB_gpu_shader5));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ß']], Boolean.valueOf(GL_ARB_half_float_pixel));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['à']], Boolean.valueOf(GL_ARB_half_float_vertex));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['á']], Boolean.valueOf(GL_ARB_instanced_arrays));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['â']], Boolean.valueOf(GL_ARB_map_buffer_alignment));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ã']], Boolean.valueOf(GL_ARB_map_buffer_range));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ä']], Boolean.valueOf(GL_ARB_multisample));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['å']], Boolean.valueOf(GL_ARB_multitexture));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['æ']], Boolean.valueOf(GL_ARB_occlusion_query2));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ç']], Boolean.valueOf(GL_ARB_pixel_buffer_object));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['è']], Boolean.valueOf(GL_ARB_seamless_cube_map));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['é']], Boolean.valueOf(GL_ARB_shader_objects));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ê']], Boolean.valueOf(GL_ARB_shader_stencil_export));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ë']], Boolean.valueOf(GL_ARB_shader_texture_lod));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ì']], Boolean.valueOf(GL_ARB_shadow));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['í']], Boolean.valueOf(GL_ARB_shadow_ambient));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['î']], Boolean.valueOf(GL_ARB_stencil_texturing));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ï']], Boolean.valueOf(GL_ARB_sync));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ð']], Boolean.valueOf(GL_ARB_tessellation_shader));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ñ']], Boolean.valueOf(GL_ARB_texture_border_clamp));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ò']], Boolean.valueOf(GL_ARB_texture_buffer_object));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ó']], Boolean.valueOf(GL_ARB_texture_cube_map));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ô']], Boolean.valueOf(GL_ARB_texture_cube_map_array));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['õ']], Boolean.valueOf(GL_ARB_texture_non_power_of_two));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ö']], Boolean.valueOf(GL_ARB_uniform_buffer_object));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['÷']], Boolean.valueOf(GL_ARB_vertex_blend));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ø']], Boolean.valueOf(GL_ARB_vertex_buffer_object));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ù']], Boolean.valueOf(GL_ARB_vertex_program));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ú']], Boolean.valueOf(GL_ARB_vertex_shader));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['û']], Boolean.valueOf(GL_EXT_bindable_uniform));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ü']], Boolean.valueOf(GL_EXT_blend_equation_separate));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ý']], Boolean.valueOf(GL_EXT_blend_func_separate));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['þ']], Boolean.valueOf(GL_EXT_blend_minmax));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ÿ']], Boolean.valueOf(GL_EXT_blend_subtract));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ā']], Boolean.valueOf(GL_EXT_draw_instanced));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ā']], Boolean.valueOf(GL_EXT_framebuffer_multisample));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ă']], Boolean.valueOf(GL_EXT_framebuffer_object));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ă']], Boolean.valueOf(GL_EXT_framebuffer_sRGB));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ą']], Boolean.valueOf(GL_EXT_geometry_shader4));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ą']], Boolean.valueOf(GL_EXT_gpu_program_parameters));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ć']], Boolean.valueOf(GL_EXT_gpu_shader4));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ć']], Boolean.valueOf(GL_EXT_multi_draw_arrays));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ĉ']], Boolean.valueOf(GL_EXT_packed_depth_stencil));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ĉ']], Boolean.valueOf(GL_EXT_paletted_texture));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ċ']], Boolean.valueOf(GL_EXT_rescale_normal));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ċ']], Boolean.valueOf(GL_EXT_separate_shader_objects));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Č']], Boolean.valueOf(GL_EXT_shader_image_load_store));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['č']], Boolean.valueOf(GL_EXT_shadow_funcs));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ď']], Boolean.valueOf(GL_EXT_shared_texture_palette));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ď']], Boolean.valueOf(GL_EXT_stencil_clear_tag));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Đ']], Boolean.valueOf(GL_EXT_stencil_two_side));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['đ']], Boolean.valueOf(GL_EXT_stencil_wrap));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ē']], Boolean.valueOf(GL_EXT_texture_3d));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ē']], Boolean.valueOf(GL_EXT_texture_array));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll[55]], Boolean.valueOf(GL_EXT_texture_buffer_object));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll[58]], Boolean.valueOf(GL_EXT_texture_integer));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ĕ']], Boolean.valueOf(GL_EXT_texture_lod_bias));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ĕ']], Boolean.valueOf(GL_EXT_texture_sRGB));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ė']], Boolean.valueOf(GL_EXT_vertex_shader));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['ė']], Boolean.valueOf(GL_EXT_vertex_weighting));
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ę']], Integer.valueOf(GL11.glGetInteger(llllIIll['ę'])));
    "".length();
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ě']], Integer.valueOf(GL11.glGetInteger(llllIIll['ě'])));
    "".length();
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ĝ']], Integer.valueOf(GL11.glGetInteger(llllIIll['ĝ'])));
    "".length();
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ğ']], Integer.valueOf(GL11.glGetInteger(llllIIll['ğ'])));
    "".length();
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ġ']], Integer.valueOf(GL11.glGetInteger(llllIIll['ġ'])));
    "".length();
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ģ']], Integer.valueOf(GL11.glGetInteger(llllIIll['ģ'])));
    "".length();
    lIIllIlIlllIllI.addStatToSnooper(llIlIlII[llllIIll['Ĥ']], Integer.valueOf(getGLMaximumTextureSize()));
  }
  
  private static String lIlIlIIlII(String lIIllIIllIIllII, String lIIllIIllIIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIIllIIllIIllII = new String(Base64.getDecoder().decode(lIIllIIllIIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIIllIIllIIlIlI = new StringBuilder();
    char[] lIIllIIllIIlIIl = lIIllIIllIIIllI.toCharArray();
    int lIIllIIllIIlIII = llllIIll[0];
    int lIIllIIllIIIIlI = lIIllIIllIIllII.toCharArray();
    short lIIllIIllIIIIIl = lIIllIIllIIIIlI.length;
    Exception lIIllIIllIIIIII = llllIIll[0];
    while (llIIllIIIl(lIIllIIllIIIIII, lIIllIIllIIIIIl))
    {
      char lIIllIIllIIllIl = lIIllIIllIIIIlI[lIIllIIllIIIIII];
      "".length();
      "".length();
      if (('' + 95 - 186 + 105 ^ '' + 79 - 209 + 132) < 0) {
        return null;
      }
    }
    return String.valueOf(lIIllIIllIIlIlI);
  }
  
  public void dispatchKeypresses()
  {
    ;
    ;
    if (llIIlIIlIl(Keyboard.getEventKey()))
    {
      "".length();
      if (" ".length() >= ((0x7F ^ 0x4 ^ 0x9D ^ 0xBC) & ('' + 96 - 190 + 173 ^ 4 + '' - 38 + 39 ^ -" ".length()))) {
        break label79;
      }
    }
    label79:
    int lIIllIlIIlIIIII = Keyboard.getEventKey();
    if ((llIIlIIlII(lIIllIlIIlIIIII)) && (llIIlIIlIl(Keyboard.isRepeatEvent())) && ((!llIIlIIlII(currentScreen instanceof GuiControls)) || (llIIlIlIlI(llIlIIIIII(currentScreen).time, getSystemTime() - 20L))))) {
      if (llIIlIIlII(Keyboard.getEventKeyState()))
      {
        if (llIIlIlIII(lIIllIlIIlIIIII, gameSettings.keyBindStreamStartStop.getKeyCode()))
        {
          if (llIIlIIlII(lIIllIlIIIlllll.getTwitchStream().isBroadcasting()))
          {
            lIIllIlIIIlllll.getTwitchStream().stopBroadcasting();
            "".length();
            if ("  ".length() > 0) {}
          }
          else if (llIIlIIlII(lIIllIlIIIlllll.getTwitchStream().isReadyToBroadcast()))
          {
            lIIllIlIIIlllll.displayGuiScreen(new GuiYesNo(new GuiYesNoCallback()
            {
              private static boolean lllIlllllII(int ???)
              {
                String lIIIIlIllllII;
                return ??? != 0;
              }
              
              public void confirmClicked(boolean lIIIIllIIIIIl, int lIIIIllIIIIII)
              {
                ;
                ;
                if (lllIlllllII(lIIIIllIIIIIl)) {
                  getTwitchStream().func_152930_t();
                }
                displayGuiScreen(null);
              }
            }, I18n.format(llIlIlII[llllIIll['Ī']], new Object[llllIIll[0]]), llIlIlII[llllIIll['ī']], llllIIll[0]));
            "".length();
            if ("   ".length() > 0) {}
          }
          else if ((llIIlIIlII(lIIllIlIIIlllll.getTwitchStream().func_152928_D())) && (llIIlIIlII(lIIllIlIIIlllll.getTwitchStream().func_152936_l())))
          {
            if (llIIlIIIll(theWorld))
            {
              ingameGUI.getChatGUI().printChatMessage(new ChatComponentText(llIlIlII[llllIIll['Ĭ']]));
              "".length();
              if (-"  ".length() < 0) {}
            }
          }
          else
          {
            GuiStreamUnavailable.func_152321_a(currentScreen);
            "".length();
            if (('¡' + 97 - 194 + 118 ^ '' + '' - 154 + 49) >= " ".length()) {}
          }
        }
        else if (llIIlIlIII(lIIllIlIIlIIIII, gameSettings.keyBindStreamPauseUnpause.getKeyCode()))
        {
          if (llIIlIIlII(lIIllIlIIIlllll.getTwitchStream().isBroadcasting())) {
            if (llIIlIIlII(lIIllIlIIIlllll.getTwitchStream().isPaused()))
            {
              lIIllIlIIIlllll.getTwitchStream().unpause();
              "".length();
              if (" ".length() >= 0) {}
            }
            else
            {
              lIIllIlIIIlllll.getTwitchStream().pause();
              "".length();
              if (-" ".length() < 0) {}
            }
          }
        }
        else if (llIIlIlIII(lIIllIlIIlIIIII, gameSettings.keyBindStreamCommercials.getKeyCode()))
        {
          if (llIIlIIlII(lIIllIlIIIlllll.getTwitchStream().isBroadcasting()))
          {
            lIIllIlIIIlllll.getTwitchStream().requestCommercial();
            "".length();
            if (" ".length() > -" ".length()) {}
          }
        }
        else if (llIIlIlIII(lIIllIlIIlIIIII, gameSettings.keyBindStreamToggleMic.getKeyCode()))
        {
          stream.muteMicrophone(llllIIll[1]);
          "".length();
          if (("   ".length() & ("   ".length() ^ -" ".length())) == 0) {}
        }
        else if (llIIlIlIII(lIIllIlIIlIIIII, gameSettings.keyBindFullscreen.getKeyCode()))
        {
          lIIllIlIIIlllll.toggleFullscreen();
          "".length();
          if ("   ".length() != "  ".length()) {}
        }
        else if (llIIlIlIII(lIIllIlIIlIIIII, gameSettings.keyBindScreenshot.getKeyCode()))
        {
          ingameGUI.getChatGUI().printChatMessage(ScreenShotHelper.saveScreenshot(mcDataDir, displayWidth, displayHeight, framebufferMc));
          "".length();
          if (((0xBF ^ 0x82) & (0xA8 ^ 0x95 ^ 0xFFFFFFFF)) != "   ".length()) {}
        }
      }
      else if (llIIlIlIII(lIIllIlIIlIIIII, gameSettings.keyBindStreamToggleMic.getKeyCode())) {
        stream.muteMicrophone(llllIIll[0]);
      }
    }
  }
  
  private static boolean llIIllIlII(int ???, int arg1)
  {
    int i;
    boolean lIIllIIlIIlIlIl;
    return ??? > i;
  }
  
  public void updateDisplay()
  {
    ;
    mcProfiler.startSection(llIlIlII[llllIIll[93]]);
    Display.update();
    mcProfiler.endSection();
    lIIlllIllllIIlI.checkWindowResize();
  }
  
  private static boolean llIIlIIIlI(int ???)
  {
    short lIIllIIIlllllIl;
    return ??? > 0;
  }
  
  private static void llIIIlllll()
  {
    llllIIll = new int['Ĳ'];
    llllIIll[0] = ((1 + 87 - 36 + 109 ^ 14 + 43 - -26 + 76) & (0xF9 ^ 0xB0 ^ 0x8 ^ 0x7F ^ -" ".length()));
    llllIIll[1] = " ".length();
    llllIIll[2] = (-(0xECD7 & 0x57EE) & 0xFCD7 & 0xA047ED);
    llllIIll[3] = "  ".length();
    llllIIll[4] = (-(0xFFFFFFD7 & 0x16C) & 0xFBDB & 0xF67);
    llllIIll[5] = (0xC748 & 0x3EF7);
    llllIIll[6] = (-(0xE71A & 0x3CF5) & 0xBF6F & 0x6FDF);
    llllIIll[7] = (0x8F79 & 0x778E);
    llllIIll[8] = "   ".length();
    llllIIll[9] = (0x8 ^ 0x3 ^ 0x77 ^ 0x78);
    llllIIll[10] = (6 + 16 - -77 + 32 ^ 96 + 94 - 146 + 90);
    llllIIll[11] = (91 + 27 - 3 + 84 ^ 26 + 85 - -75 + 7);
    llllIIll[12] = (0x4C ^ 0x4B);
    llllIIll[13] = (0x8B ^ 0xA8 ^ 0x46 ^ 0x6D);
    llllIIll[14] = (0x1A ^ 0x13);
    llllIIll[15] = (0x45 ^ 0x31 ^ 0x26 ^ 0x58);
    llllIIll[16] = (68 + 23 - -53 + 37 ^ 99 + 61 - 78 + 108);
    llllIIll[17] = (0x5C ^ 0x50);
    llllIIll[18] = (0x51 ^ 0x5C);
    llllIIll[19] = (109 + 33 - 131 + 121 ^ 95 + 69 - 54 + 28);
    llllIIll[20] = (21 + 26 - -39 + 60 ^ '' + '' - 151 + 26);
    llllIIll[21] = (0x97 ^ 0x8D ^ 0x70 ^ 0x7A);
    llllIIll[22] = (0xCF ^ 0x94 ^ 0x72 ^ 0x38);
    llllIIll[23] = (0x50 ^ 0xA ^ 0x70 ^ 0x38);
    llllIIll[24] = (0x9FD9 & 0x7D27);
    llllIIll[25] = (-(0xAD67 & 0x7BF9) & 0xEB77 & 0x3FEB);
    llllIIll[26] = (0xDF37 & 0x22CC);
    llllIIll[27] = (-(0xEB79 & 0x1CD7) & 0xBCFF & 0x4F55);
    llllIIll[28] = (-(0xE41F & 0x5BE3) & 0xF7AB & 0x5F57);
    llllIIll[29] = (0xF77E & 0x1F81);
    llllIIll[30] = (111 + 10 - 53 + 98 ^ '¤' + 35 - 90 + 72);
    llllIIll[31] = (118 + 105 - 129 + 92 ^ '' + 56 - 140 + 100);
    llllIIll[32] = (0x98 ^ 0x93 ^ 0x1C ^ 0x2);
    llllIIll[33] = (0x2D ^ 0x3B);
    llllIIll[34] = (0xE8 ^ 0xBB ^ 0x64 ^ 0x20);
    llllIIll[35] = (0x78 ^ 0x60);
    llllIIll[36] = ('' + '' - 142 + 13 ^ '' + '' - 183 + 92);
    llllIIll[37] = (125 + 21 - 11 + 4 ^ 59 + 67 - 100 + 119);
    llllIIll[38] = (0x8C ^ 0x97);
    llllIIll[39] = (0x30 ^ 0x2C);
    llllIIll[40] = (0x9A ^ 0x87);
    llllIIll[41] = (0xAF ^ 0xB1);
    llllIIll[42] = (61 + '' - 134 + 84 ^ 54 + 34 - -31 + 28);
    llllIIll[43] = (48 + 35 - -85 + 21 ^ '' + 98 - 102 + 17);
    llllIIll[44] = (0x18 ^ 0x74 ^ 0x43 ^ 0xE);
    llllIIll[45] = (101 + '¢' - 179 + 98 ^ 75 + 65 - 14 + 22);
    llllIIll[46] = (123 + 117 - 89 + 6 ^ 126 + 45 - 142 + 161);
    llllIIll[47] = (0x87 ^ 0xA3);
    llllIIll[48] = (0xB3 ^ 0x96);
    llllIIll[49] = (0x10 ^ 0x21 ^ 0x34 ^ 0x23);
    llllIIll[50] = (-" ".length());
    llllIIll[51] = (0x39 ^ 0x1E);
    llllIIll[52] = (0x33 ^ 0x1B);
    llllIIll[53] = (-"  ".length());
    llllIIll[54] = (0x47 ^ 0x64 ^ 0x1E ^ 0x14);
    llllIIll[55] = (84 + '¶' - 225 + 214);
    llllIIll[56] = (0xEB ^ 0x90 ^ 0xC4 ^ 0x95);
    llllIIll[57] = (0x0 ^ 0x2B);
    llllIIll[58] = (-(0xFEBE & 0x7B75) & 0xFF3F & 0x7BF3);
    llllIIll[59] = (0x51 ^ 0x1D ^ 0x34 ^ 0x54);
    llllIIll[60] = (0x9D ^ 0xA7 ^ 0x4 ^ 0x13);
    llllIIll[61] = (0x55 ^ 0x3 ^ 0x1A ^ 0x62);
    llllIIll[62] = (0xA5 ^ 0x8A);
    llllIIll[63] = (0x7B ^ 0x45 ^ 0x6A ^ 0x64);
    llllIIll[64] = (0x64 ^ 0x55);
    llllIIll[65] = ('' + '' - 209 + 99 ^ 35 + 20 - -57 + 43);
    llllIIll[66] = (0x5F ^ 0x6C);
    llllIIll[67] = (0x5B ^ 0x6F);
    llllIIll[68] = (0x3E ^ 0x2B ^ 0x5E ^ 0x7E);
    llllIIll[69] = (40 + '' - 127 + 91 ^ 76 + 26 - -72 + 1);
    llllIIll[70] = (0xC10B & 0x7FF4);
    llllIIll[71] = (98 + 16 - 90 + 120 ^ 16 + 71 - -59 + 21);
    llllIIll[72] = (0xFC ^ 0xC4);
    llllIIll[73] = (120 + 107 - 177 + 198 ^ 3 + '¹' - 92 + 97);
    llllIIll[74] = (0xC ^ 0x36);
    llllIIll[75] = (0xD8 ^ 0x8A ^ 0x55 ^ 0x3C);
    llllIIll[76] = (0x52 ^ 0x5D ^ 0x79 ^ 0x4A);
    llllIIll[77] = (0x96 ^ 0xAB);
    llllIIll[78] = (66 + 100 - 143 + 151 ^ '' + 67 - 64 + 8);
    llllIIll[79] = (75 + 75 - 60 + 67 ^ 99 + 5 - 85 + 143);
    llllIIll[80] = ('' + 103 - 216 + 196 ^ 119 + 12 - -7 + 23);
    llllIIll[81] = (0x79 ^ 0x33 ^ 0x7F ^ 0x74);
    llllIIll[82] = (34 + 98 - 63 + 58 ^ 0xFC ^ 0xC1);
    llllIIll[83] = (0x5E ^ 0x1D);
    llllIIll[84] = (0x4A ^ 0xE);
    llllIIll[85] = (0x76 ^ 0x51 ^ 0x52 ^ 0x30);
    llllIIll[86] = (0xD5 ^ 0x93);
    llllIIll[87] = (0xCB ^ 0x9F ^ 0x80 ^ 0x93);
    llllIIll[88] = (0xCD ^ 0x85);
    llllIIll[89] = (0x1D ^ 0x54);
    llllIIll[90] = (0x55 ^ 0x7A ^ 0x44 ^ 0x21);
    llllIIll[91] = (0x93AF & 0x6D7C);
    llllIIll[92] = (0xF4 ^ 0xC7 ^ 0xA ^ 0x72);
    llllIIll[93] = ('' + '´' - 305 + 184 ^ 17 + 92 - 55 + 85);
    llllIIll[94] = (0x89 ^ 0xA2 ^ 0xFB ^ 0x9D);
    llllIIll[95] = (0xCE ^ 0x9C ^ 0x8A ^ 0x96);
    llllIIll[96] = (0x3 ^ 0x4C);
    llllIIll[97] = (21 + 7 - -47 + 85);
    llllIIll[98] = ((0x32 ^ 0x6D) + (0x63 ^ 0x2A) - (0x1E ^ 0x38) + (0x12 ^ 0x54));
    llllIIll[99] = (0xEE ^ 0x81 ^ 0xBC ^ 0x83);
    llllIIll[100] = (0x7F ^ 0x2E);
    llllIIll[101] = (0x19 ^ 0x4B);
    llllIIll[102] = (0xFD ^ 0xAE);
    llllIIll[103] = (0xA5 ^ 0xA8 ^ 0x14 ^ 0x4D);
    llllIIll[104] = (0xCB ^ 0x9E);
    llllIIll[105] = (0xFFFFFFFF & 0xFFFFFF);
    llllIIll[106] = (0xF6 ^ 0xA0);
    llllIIll[107] = (0xDB ^ 0x8C);
    llllIIll[108] = (0xEB ^ 0xB3);
    llllIIll[109] = (0x77 ^ 0x2E);
    llllIIll[110] = (0x49 ^ 0x47 ^ 0xFF ^ 0xAB);
    llllIIll[111] = (0xC9 ^ 0x92);
    llllIIll[112] = (0x6C ^ 0x30);
    llllIIll[113] = (0xCC ^ 0x91);
    llllIIll[114] = (0xEFFC & 0x3713);
    llllIIll[115] = ('' + 'ª' - 112 + 19 ^ '' + 52 - 122 + 116);
    llllIIll[116] = (0x79 ^ 0x26);
    llllIIll[117] = (0x3 ^ 0x63);
    llllIIll[118] = (0x38 ^ 0x74 ^ 0xED ^ 0xC0);
    llllIIll[119] = (9 + '¯' - 0 + 46 ^ 99 + 62 - 86 + 57);
    llllIIll[120] = (0x45 ^ 0x1E ^ 0x68 ^ 0x50);
    llllIIll[121] = (117 + 'Â' - 128 + 14 ^ '' + 56 - 132 + 80);
    llllIIll[122] = (0xD3 ^ 0x85 ^ 0x15 ^ 0x26);
    llllIIll[123] = (0x8 ^ 0x6E);
    llllIIll[124] = (0xD8 ^ 0xBF);
    llllIIll[125] = (0xED ^ 0x85);
    llllIIll[126] = (0x1D ^ 0x74);
    llllIIll[127] = (0x9C ^ 0x85 ^ 0x7A ^ 0x9);
    llllIIll[''] = (0x31 ^ 0x5A);
    llllIIll[''] = ('' + 111 - 86 + 59 ^ 17 + 120 - 53 + 55);
    llllIIll[''] = ('¡' + 24 - 61 + 87 ^ 82 + 16 - 26 + 118);
    llllIIll[''] = (36 + 33 - -34 + 90 ^ 74 + 19 - 56 + 138);
    llllIIll[''] = (0x34 ^ 0x5B);
    llllIIll[''] = (0xB5 ^ 0xC5);
    llllIIll[''] = ('À' + 1 - 8 + 12 ^ 23 + 9 - -4 + 144);
    llllIIll[''] = (0x49 ^ 0x66 ^ 0xD0 ^ 0x8D);
    llllIIll[''] = (0x14 ^ 0x38 ^ 0xDE ^ 0x81);
    llllIIll[''] = (127 + 'ß' - 343 + 223 ^ 44 + 9 - -66 + 27);
    llllIIll[''] = (0x64 ^ 0x11);
    llllIIll[''] = (0x76 ^ 0x0);
    llllIIll[''] = (11 + '' - 120 + 173 ^ 5 + 28 - -81 + 57);
    llllIIll[''] = (0x1F ^ 0x67);
    llllIIll[''] = (0x72 ^ 0xB);
    llllIIll[''] = (0x36 ^ 0x58 ^ 0xBE ^ 0xAA);
    llllIIll[''] = (0x69 ^ 0x12);
    llllIIll[''] = (0xEF ^ 0x93);
    llllIIll[''] = ('Ø' + 'Å' - 160 + 2 ^ 115 + 34 - 58 + 39);
    llllIIll[''] = (0x6E ^ 0x10);
    llllIIll[''] = (0 + 53 - -54 + 20);
    llllIIll[''] = (2 + 126 - 80 + 80);
    llllIIll[''] = (3 + 75 - -34 + 17);
    llllIIll[''] = (22 + 121 - 86 + 73);
    llllIIll[''] = ((0x2D ^ 0x11) + (0x48 ^ 0x62) - (0xB3 ^ 0x8E) + (0x3C ^ 0x66));
    llllIIll[''] = ((0xEA ^ 0xBC) + (0xBB ^ 0xB5) - -(0xBC ^ 0xBA) + (0x9B ^ 0x81));
    llllIIll[''] = ((0x86 ^ 0xB0) + (0x52 ^ 0x1D) - (0x6E ^ 0x22) + (0xD7 ^ 0x9B));
    llllIIll[''] = ((0xBF ^ 0xBB) + (0x86 ^ 0xAB) - (0x34 ^ 0x30) + (0xF3 ^ 0xAA));
    llllIIll[''] = ((0x85 ^ 0xC3) + (0xAC ^ 0xB0) - -(0x5D ^ 0x53) + (0x94 ^ 0x83));
    llllIIll[''] = (48 + 39 - -10 + 39);
    llllIIll[''] = ((0x4B ^ 0x6F) + (0xA1 ^ 0xC7) - (0x77 ^ 0x18) + (0x2F ^ 0x41));
    llllIIll[''] = (13 + 69 - -24 + 32);
    llllIIll[' '] = ((0x5C ^ 0x5) + (0xAB ^ 0x88) - (0xCE ^ 0xAA) + (0x29 ^ 0x5A));
    llllIIll['¡'] = ((0x1A ^ 0x30) + (0x9A ^ 0x8A) - -(0x11 ^ 0x35) + (0x72 ^ 0x5C));
    llllIIll['¢'] = ((0x52 ^ 0x2) + (0x4E ^ 0x3) - (0x34 ^ 0x1E) + (0x5C ^ 0x46));
    llllIIll['£'] = (29 + 102 - 15 + 26);
    llllIIll['¤'] = (96 + 122 - 86 + 11);
    llllIIll['¥'] = (106 + 59 - 40 + 19);
    llllIIll['¦'] = ((0x8D ^ 0xB0) + (0x8F ^ 0xB5) - (0xFC ^ 0xBA) + (0xD8 ^ 0xB8));
    llllIIll['§'] = ((0x47 ^ 0x7C) + (0xDD ^ 0x83) - (0x3 ^ 0xE) + (0x2 ^ 0x4));
    llllIIll['¨'] = (99 + '' - 127 + 37);
    llllIIll['©'] = ((0x33 ^ 0x54) + (0x3C ^ 0x52) - (0x74 ^ 0x24) + (0x17 ^ 0x18));
    llllIIll['ª'] = ((0xDC ^ 0x9A) + (0x14 ^ 0x3E) - (0x3D ^ 0x78) + (0x2B ^ 0x41));
    llllIIll['«'] = (111 + '' - 215 + 116 + (0x55 ^ 0x1C) - ('À' + 116 - 227 + 125) + (119 + 75 - 147 + 88));
    llllIIll['¬'] = (36 + 46 - 63 + 132);
    llllIIll['­'] = (54 + 72 - 40 + 66);
    llllIIll['®'] = ((0x47 ^ 0xF) + ('' + 5 - 27 + 24) - (0x54 ^ 0xE) + (0x79 ^ 0x50));
    llllIIll['¯'] = (26 + '' - 35 + 19);
    llllIIll['°'] = (26 + 89 - 99 + 139);
    llllIIll['±'] = (84 + 18 - 83 + 137);
    llllIIll['²'] = ('' + '' - 203 + 76);
    llllIIll['³'] = (7 + 14 - -89 + 48);
    llllIIll['´'] = ('' + '' - 210 + 82);
    llllIIll['µ'] = ((0x5F ^ 0x63) + (0x23 ^ 0x79) - (0x99 ^ 0x8F) + (0x24 ^ 0x5));
    llllIIll['¶'] = ((0x7E ^ 0x45) + ("  ".length() & ("  ".length() ^ 0xFFFFFFFF)) - -(0x4D ^ 0x7) + (0x70 ^ 0x6D));
    llllIIll['·'] = ((0xE7 ^ 0xA7) + (0x38 ^ 0xD) - (0xB6 ^ 0x9D) + (0x7B ^ 0x22));
    llllIIll['¸'] = (122 + 45 - 78 + 75);
    llllIIll['¹'] = ((0x59 ^ 0x3D) + (0x76 ^ 0x3C) - (0x44 ^ 0x12) + (0xE0 ^ 0xAD));
    llllIIll['º'] = ((0xE ^ 0x64) + (0x55 ^ 0x5B) - (0x8 ^ 0x79) + (111 + '' - 214 + 125));
    llllIIll['»'] = (0x9FFF & 0x7F02);
    llllIIll['¼'] = ((0x26 ^ 0x4C) + (0x4B ^ 0x3A) - (127 + 113 - 175 + 63) + (0x12 ^ 0x5E));
    llllIIll['½'] = (0xFF55 & 0x1FAA);
    llllIIll['¾'] = ((0x0 ^ 0x58) + (0xC8 ^ 0x9E) - (0x26 ^ 0x62) + (0x97 ^ 0xA9));
    llllIIll['¿'] = (78 + 83 - 7 + 15);
    llllIIll['À'] = ('' + '' - 190 + 70 + (0x16 ^ 0x58) - (71 + 68 - 32 + 41) + (0x24 ^ 0x6E));
    llllIIll['Á'] = (2 + 90 - 64 + 124 + (0xC ^ 0x28) - (0xD3 ^ 0xC5) + (0x4C ^ 0x49));
    llllIIll['Â'] = (67 + '' - 152 + 100 + (42 + 99 - 103 + 95) - (117 + 9 - 4 + 23) + (0x4D ^ 0x58));
    llllIIll['Ã'] = ('' + 80 - 148 + 96);
    llllIIll['Ä'] = (3 + 101 - 87 + 116 + (0xAC ^ 0xA2) - (13 + 59 - -13 + 48) + (39 + '' - 117 + 100));
    llllIIll['Å'] = ('¤' + 40 - 170 + 141);
    llllIIll['Æ'] = (53 + 85 - 104 + 142);
    llllIIll['Ç'] = ((0xB ^ 0x31) + (0x70 ^ 0x6F) - -(0x44 ^ 0x6) + (0x2A ^ 0x3C));
    llllIIll['È'] = ('¥' + 3 - 68 + 78);
    llllIIll['É'] = ((0xC5 ^ 0x9D) + (45 + 97 - 74 + 61) - (0xF8 ^ 0x89) + (0x4E ^ 0x5));
    llllIIll['Ê'] = ((0x4E ^ 0x77) + (0x2E ^ 0x39) - (0xE4 ^ 0xA9) + (39 + ' ' - 146 + 124));
    llllIIll['Ë'] = ("  ".length() + (96 + 117 - 103 + 22) - (0x4D ^ 0x8) + (0xF0 ^ 0x84));
    llllIIll['Ì'] = ((0x8A ^ 0x8E) + (0x90 ^ 0x99) - -(0x58 ^ 0x4C) + (101 + 115 - 134 + 67));
    llllIIll['Í'] = (95 + '£' - 203 + 128);
    llllIIll['Î'] = (80 + '²' - 85 + 11);
    llllIIll['Ï'] = (26 + 96 - 41 + 104);
    llllIIll['Ð'] = (46 + 122 - 8 + 26);
    llllIIll['Ñ'] = (115 + 81 - 156 + 87 + (0x61 ^ 0x8) - ('' + '' - 287 + 164) + (0x8 ^ 0x76));
    llllIIll['Ò'] = (9 + 67 - 69 + 181);
    llllIIll['Ó'] = ((0x31 ^ 0x1A) + (59 + 46 - -32 + 18) - (0xC ^ 0x53) + (0x7B ^ 0x2D));
    llllIIll['Ô'] = ((0x2B ^ 0x5E) + (0x76 ^ 0x58) - (0x55 ^ 0x5) + (0xC ^ 0x67));
    llllIIll['Õ'] = ('¤' + '³' - 225 + 73);
    llllIIll['Ö'] = (1 + 20 - -35 + 85 + (0xD9 ^ 0xB0) - (19 + '´' - 196 + 182) + (49 + 74 - 92 + 100));
    llllIIll['×'] = ((0xD2 ^ 0xB6) + ('«' + 9 - -5 + 3) - (0xD7 ^ 0xB5) + "   ".length());
    llllIIll['Ø'] = ((0x28 ^ 0x6F) + (41 + '' - 29 + 35) - (0x4A ^ 0x3C) + (0x71 ^ 0x43));
    llllIIll['Ù'] = (' ' + 64 - 175 + 146);
    llllIIll['Ú'] = (69 + 118 - 181 + 190);
    llllIIll['Û'] = ((0x3B ^ 0x55) + (0xC4 ^ 0x90) - (0x45 ^ 0x1A) + (0xF8 ^ 0x9A));
    llllIIll['Ü'] = ('' + 112 - 236 + 188);
    llllIIll['Ý'] = (100 + '' - 224 + 132 + (54 + '' - 167 + 145) - (0xD149 & 0x2FFE) + (74 + '' - 131 + 102));
    llllIIll['Þ'] = (51 + 94 - 2 + 58);
    llllIIll['ß'] = (10 + 111 - -76 + 5);
    llllIIll['à'] = ((0x97 ^ 0xBB) + (0x3C ^ 0x2C) - -(0x1 ^ 0x62) + (0x94 ^ 0xB8));
    llllIIll['á'] = ((0x86 ^ 0x92) + (0xF3 ^ 0xA0) - -(0x11 ^ 0x57) + (0x71 ^ 0x6E));
    llllIIll['â'] = (23 + 77 - 42 + 102 + (0x34 ^ 0x15) - (0xB3 ^ 0x92) + (0xA1 ^ 0x8C));
    llllIIll['ã'] = (103 + 64 - 162 + 201);
    llllIIll['ä'] = (71 + 78 - -47 + 0 + (20 + 116 - 120 + 143) - (0xFD7B & 0x3D5) + (119 + 32 - 126 + 164));
    llllIIll['å'] = ((0xC ^ 0x6B) + (94 + 110 - 78 + 65) - (0xE6 ^ 0x8D) + (0x6D ^ 0x78));
    llllIIll['æ'] = (43 + 27 - -114 + 9 + (26 + 82 - 50 + 95) - ('' + '' - 267 + 171) + (0x88 ^ 0xA3));
    llllIIll['ç'] = ((0x21 ^ 0x49) + (0x4D ^ 0xA) - (0x54 ^ 0x46) + (0x33 ^ 0x6));
    llllIIll['è'] = ((0xC ^ 0x5) + (0xA4 ^ 0xB3) - -(90 + '' - 152 + 67) + (0xA7 ^ 0x80));
    llllIIll['é'] = ('«' + 61 - 92 + 51 + ('' + 7 - 101 + 107) - (6 + 62 - 8 + 131) + (0x84 ^ 0xB5));
    llllIIll['ê'] = ((0xCC ^ 0xB8) + (13 + 23 - -120 + 22) - ('Ä' + 76 - 187 + 143) + (8 + 87 - 28 + 80));
    llllIIll['ë'] = ("  ".length() + ('' + 'Ã' - 287 + 174) - (0x2C ^ 0x51) + (0x1 ^ 0x7F));
    llllIIll['ì'] = (122 + 109 - 179 + 83 + (0x8 ^ 0x34) - ('' + 83 - 91 + 28) + (103 + 80 - 76 + 70));
    llllIIll['í'] = ('Ô' + 121 - 223 + 106);
    llllIIll['î'] = ((0x75 ^ 0x1B) + (0x38 ^ 0x6) - (81 + 11 - -61 + 17) + ('Ö' + 90 - 170 + 81));
    llllIIll['ï'] = (' ' + '°' - 181 + 63);
    llllIIll['ð'] = (72 + 104 - 12 + 19 + ('' + 24 - 131 + 181) - (0x8F5D & 0x71EF) + (94 + 5 - -10 + 43));
    llllIIll['ñ'] = (71 + 35 - -3 + 111);
    llllIIll['ò'] = ('£' + '©' - 286 + 128 + ('' + '' - 250 + 137) - (0xFDFF & 0x337) + (47 + '' - 170 + 139));
    llllIIll['ó'] = (68 + 6 - 46 + 115 + (46 + '¦' - 45 + 16) - ('¯' + 28 - 21 + 42) + (0xED ^ 0x95));
    llllIIll['ô'] = (102 + 120 - 161 + 94 + (0x7D ^ 0x5) - ('' + 30 - 184 + 158) + (0x3F ^ 0x50));
    llllIIll['õ'] = ('¶' + 'Á' - 358 + 207);
    llllIIll['ö'] = (87 + 115 - 151 + 174);
    llllIIll['÷'] = (105 + 109 - 186 + 144 + (0x32 ^ 0x1F) - (0x71 ^ 0x47) + (0x86 ^ 0xB9));
    llllIIll['ø'] = ((0x59 ^ 0x3) + (0xE2 ^ 0x99) - (0x2 ^ 0x1A) + (0x1E ^ 0x38));
    llllIIll['ù'] = ('²' + '' - 191 + 99);
    llllIIll['ú'] = ('¯' + '¯' - 216 + 88 + (85 + 119 - 187 + 121) - (0x8DEB & 0x735F) + ('³' + '«' - 225 + 75));
    llllIIll['û'] = (113 + 91 - 84 + 110);
    llllIIll['ü'] = (94 + '©' - 161 + 98 + (0x8F ^ 0xC0) - (0x7F ^ 0x40) + (0xCD ^ 0xC2));
    llllIIll['ý'] = ((0x68 ^ 0x3B) + (32 + '' - 36 + 33) - (126 + 84 - 73 + 69) + ('' + 24 - 105 + 117));
    llllIIll['þ'] = ((0x28 ^ 0x56) + (0x20 ^ 0x4C) - (0x23 ^ 0x51) + (0xD1 ^ 0xA0));
    llllIIll['ÿ'] = ((0x30 ^ 0x8) + (47 + 'Í' - 39 + 3) - ('' + 6 - 10 + 34) + (50 + 111 - 52 + 19));
    llllIIll['Ā'] = (15 + 54 - 3 + 127 + (0x4C ^ 0x34) - (0x8768 & 0x79B7) + ('ª' + '±' - 311 + 174));
    llllIIll['ā'] = ((0x1D ^ 0x47) + (0xC4 ^ 0xA0) - -"   ".length() + (0x48 ^ 0x63));
    llllIIll['Ă'] = ('è' + 'È' - 422 + 227);
    llllIIll['ă'] = ((0x33 ^ 0xA) + ('¡' + '°' - 205 + 80) - (0xE90E & 0x17FB) + (42 + 75 - -33 + 85));
    llllIIll['Ą'] = (41 + 42 - -65 + 91);
    llllIIll['ą'] = (46 + 5 - -119 + 46 + (127 + 78 - 129 + 88) - ('' + 125 - 130 + 56) + (0xF6 ^ 0xC7));
    llllIIll['Ć'] = ('º' + 109 - 274 + 220);
    llllIIll['ć'] = ('â' + '«' - 172 + 17);
    llllIIll['Ĉ'] = (122 + 12 - -57 + 52);
    llllIIll['ĉ'] = (15 + 123 - -83 + 23);
    llllIIll['Ċ'] = (90 + 98 - 185 + 242);
    llllIIll['ċ'] = (26 + 'é' - 237 + 224);
    llllIIll['Č'] = ((0xF2 ^ 0x83) + (0x71 ^ 0x55) - (0x50 ^ 0x61) + (35 + 35 - -73 + 4));
    llllIIll['č'] = ('' + 104 - 194 + 193);
    llllIIll['Ď'] = ((0x75 ^ 0xC) + (122 + 1 - -35 + 12) - ('' + 41 - 116 + 129) + (38 + 74 - 24 + 65));
    llllIIll['ď'] = ((0xEE ^ 0xA7) + ('Û' + 51 - 150 + 103) - (0xA9FF & 0x5711) + ('' + 84 - 146 + 160));
    llllIIll['Đ'] = ('ð' + '¡' - 383 + 233);
    llllIIll['đ'] = ('û' + 'µ' - 343 + 163);
    llllIIll['Ē'] = ((0xC1 ^ 0x95) + (0xB1 ^ 0xB8) - -(0x6B ^ 0x21) + (0x7D ^ 0x2B));
    llllIIll['ē'] = ((0x98 ^ 0x96) + (62 + 9 - 65407 + 9) - -(0xAB ^ 0xB0) + (0xC4 ^ 0xC0));
    llllIIll['Ĕ'] = (0x9341 & 0x6DBF);
    llllIIll['ĕ'] = (0xAB76 & 0x558B);
    llllIIll['Ė'] = (-(0xCFFF & 0x72E9) & 0xD3EB & 0x6FFF);
    llllIIll['ė'] = (-(0xDD59 & 0x66FF) & 0xD5FC & 0x6F5F);
    llllIIll['Ę'] = (0x89AF & 0x7755);
    llllIIll['ę'] = (-(0xF5EB & 0x3EB6) & 0xBFEF & 0xFFFB);
    llllIIll['Ě'] = (0x9DBF & 0x6346);
    llllIIll['ě'] = (-(0xDCBF & 0x63D7) & 0xDBDF & 0xEFFF);
    llllIIll['Ĝ'] = (-(0xFE65 & 0x1DFB) & 0xDDE7 & 0x3F7F);
    llllIIll['ĝ'] = (0xB879 & 0xCFEF);
    llllIIll['Ğ'] = (-(0xDFFF & 0x7A57) & 0xFBFE & 0x5F5F);
    llllIIll['ğ'] = (0xBFDC & 0xCB6F);
    llllIIll['Ġ'] = (-(0xFDE3 & 0x66FD) & 0xE7ED & 0x7DFB);
    llllIIll['ġ'] = (0xBCFA & 0xCB77);
    llllIIll['Ģ'] = (0x835F & 0x7DAA);
    llllIIll['ģ'] = (0xBDFF & 0xCAFF);
    llllIIll['Ĥ'] = (-(0xFF5F & 0x4EE1) & 0xCF7B & 0x7FCF);
    llllIIll['ĥ'] = (0xEA10 & 0x55EF);
    llllIIll['Ħ'] = (-(0xFFFFFFBB & 0x1956) & 0xFB75 & 0x9DFF);
    llllIIll['ħ'] = (-(0xEEDF & 0x57E2) & 0xFFFFFFEB & 0x5FDD);
    llllIIll['Ĩ'] = (-(0xDB1F & 0x6FF3) & 0xDF17 & 0x7FFB);
    llllIIll['ĩ'] = (-(0xC7EF & 0x3EFF) & 0xDFFE & 0x36EF);
    llllIIll['Ī'] = (-(0xF67F & 0x2BC1) & 0xF3DD & 0x2F6E);
    llllIIll['ī'] = (0xE97D & 0x178F);
    llllIIll['Ĭ'] = (-(0xE6EA & 0x7FF7) & 0xFFFFFFEF & 0x67FF);
    llllIIll['ĭ'] = (-(0xEB75 & 0x76FB) & 0xF37F & 0x6FFF);
    llllIIll['Į'] = (-(0xEAFF & 0x7FEB) & 0xFFFFFFFE & 0x6BFB);
    llllIIll['į'] = (0xBDFF & 0x4311);
    llllIIll['İ'] = (-(0xBEE9 & 0x65FF) & 0xB5FA & 0x6FFF);
    llllIIll['ı'] = (0x9753 & 0x69BF);
  }
  
  private void initStream()
  {
    try
    {
      ;
      ;
      stream = new TwitchStream(lIlIIIIIIIIlllI, (Property)Iterables.getFirst(twitchDetails.get(llIlIlII[llllIIll[33]]), null));
      "".length();
      if (-" ".length() > 0) {}
    }
    catch (Throwable lIlIIIIIIIIllIl)
    {
      stream = new NullStream(lIlIIIIIIIIllIl);
      logger.error(llIlIlII[llllIIll[34]]);
    }
  }
  
  public boolean isFramerateLimitBelowMax()
  {
    ;
    if (llIIlIlllI(llIIlIllll(lIIlllIlllIIIlI.getLimitFramerate(), GameSettings.Options.FRAMERATE_LIMIT.getValueMax()))) {
      return llllIIll[1];
    }
    return llllIIll[0];
  }
  
  public RenderManager getRenderManager()
  {
    ;
    return renderManager;
  }
  
  public MusicTicker.MusicType getAmbientMusicType()
  {
    ;
    if (llIIlIIIll(thePlayer))
    {
      if (llIIlIIlII(thePlayer.worldObj.provider instanceof WorldProviderHell))
      {
        "".length();
        if (((82 + 31 - -7 + 115 ^ 125 + 66 - 44 + 40) & (0xDA ^ 0xC6 ^ 0xF6 ^ 0xBA ^ -" ".length())) <= 0) {
          break label284;
        }
        return null;
      }
      if (llIIlIIlII(thePlayer.worldObj.provider instanceof WorldProviderEnd))
      {
        if ((llIIlIIIll(BossStatus.bossName)) && (llIIlIIIlI(BossStatus.statusBarTime)))
        {
          "".length();
          if ("  ".length() != ((0xBE ^ 0x9E) & (0xA9 ^ 0x89 ^ 0xFFFFFFFF))) {
            break label284;
          }
          return null;
        }
        "".length();
        if (((0x4C ^ 0x53) & (0xDC ^ 0xC3 ^ 0xFFFFFFFF)) == 0) {
          break label284;
        }
        return null;
      }
      if ((llIIlIIlII(thePlayer.capabilities.isCreativeMode)) && (llIIlIIlII(thePlayer.capabilities.allowFlying)))
      {
        "".length();
        if (null == null) {
          break label284;
        }
        return null;
      }
      "".length();
      if (((0x85 ^ 0xAD) & (0x7A ^ 0x52 ^ 0xFFFFFFFF)) <= (0xB4 ^ 0xB0)) {
        break label284;
      }
      return null;
    }
    label284:
    return MusicTicker.MusicType.MENU;
  }
  
  public ResourcePackRepository getResourcePackRepository()
  {
    ;
    return mcResourcePackRepository;
  }
  
  public final boolean isDemo()
  {
    ;
    return isDemo;
  }
  
  private static boolean llIIlIlIII(int ???, int arg1)
  {
    int i;
    short lIIllIIlIlIIIIl;
    return ??? == i;
  }
  
  public void addServerStatsToSnooper(PlayerUsageSnooper lIIllIllIIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    lIIllIllIIIlIlI.addClientStat(llIlIlII[llllIIll['§']], Integer.valueOf(debugFPS));
    lIIllIllIIIlIlI.addClientStat(llIlIlII[llllIIll['¨']], Boolean.valueOf(gameSettings.enableVsync));
    lIIllIllIIIlIlI.addClientStat(llIlIlII[llllIIll['©']], Integer.valueOf(Display.getDisplayMode().getFrequency()));
    if (llIIlIIlII(fullscreen))
    {
      "".length();
      if (null == null) {
        break label126;
      }
    }
    label126:
    llIlIlII[llllIIll['ª']].addClientStat(llIlIlII[llllIIll['«']], llIlIlII[llllIIll['¬']]);
    lIIllIllIIIlIlI.addClientStat(llIlIlII[llllIIll['­']], Long.valueOf((MinecraftServer.getCurrentTimeMillis() - lIIllIllIIIlIlI.getMinecraftStartTimeMillis()) / 60L * 1000L));
    lIIllIllIIIlIlI.addClientStat(llIlIlII[llllIIll['®']], lIIllIllIIIlIll.func_181538_aA());
    if (llIIlIIIII(ByteOrder.nativeOrder(), ByteOrder.LITTLE_ENDIAN))
    {
      "".length();
      if ((0xAB ^ 0x9C ^ 0x40 ^ 0x73) > 0) {
        break label240;
      }
    }
    label240:
    String lIIllIllIIIlIIl = llIlIlII[llllIIll['°']];
    lIIllIllIIIlIlI.addClientStat(llIlIlII[llllIIll['±']], lIIllIllIIIlIIl);
    lIIllIllIIIlIlI.addClientStat(llIlIlII[llllIIll['²']], Integer.valueOf(mcResourcePackRepository.getRepositoryEntries().size()));
    int lIIllIllIIIlIII = llllIIll[0];
    char lIIllIllIIIIIIl = mcResourcePackRepository.getRepositoryEntries().iterator();
    "".length();
    if (((0x4D ^ 0x6B) & (0x2A ^ 0xC ^ 0xFFFFFFFF)) >= (0xB3 ^ 0xB7)) {
      return;
    }
    while (!llIIlIIlIl(lIIllIllIIIIIIl.hasNext()))
    {
      ResourcePackRepository.Entry lIIllIllIIIIlll = (ResourcePackRepository.Entry)lIIllIllIIIIIIl.next();
      lIIllIllIIIlIlI.addClientStat(String.valueOf(new StringBuilder(llIlIlII[llllIIll['³']]).append(lIIllIllIIIlIII++).append(llIlIlII[llllIIll['´']])), lIIllIllIIIIlll.getResourcePackName());
    }
    if ((llIIlIIIll(theIntegratedServer)) && (llIIlIIIll(theIntegratedServer.getPlayerUsageSnooper()))) {
      lIIllIllIIIlIlI.addClientStat(llIlIlII[llllIIll[97]], theIntegratedServer.getPlayerUsageSnooper().getUniqueID());
    }
  }
  
  private void setInitialDisplayMode()
    throws LWJGLException
  {
    ;
    ;
    if (llIIlIIlII(fullscreen))
    {
      Display.setFullscreen(llllIIll[1]);
      DisplayMode lIIllllllllllll = Display.getDisplayMode();
      displayWidth = Math.max(llllIIll[1], lIIllllllllllll.getWidth());
      displayHeight = Math.max(llllIIll[1], lIIllllllllllll.getHeight());
      "".length();
      if (null == null) {}
    }
    else
    {
      Display.setDisplayMode(new DisplayMode(displayWidth, displayHeight));
    }
  }
  
  public void displayCrashReport(CrashReport lIIllllllIIIIll)
  {
    ;
    ;
    ;
    File lIIllllllIIIlIl = new File(getMinecraftmcDataDir, llIlIlII[llllIIll[45]]);
    File lIIllllllIIIlII = new File(lIIllllllIIIlIl, String.valueOf(new StringBuilder(llIlIlII[llllIIll[46]]).append(new SimpleDateFormat(llIlIlII[llllIIll[47]]).format(new Date())).append(llIlIlII[llllIIll[48]])));
    Bootstrap.printToSYSOUT(lIIllllllIIIllI.getCompleteReport());
    if (llIIlIIIll(lIIllllllIIIllI.getFile()))
    {
      Bootstrap.printToSYSOUT(String.valueOf(new StringBuilder(llIlIlII[llllIIll[49]]).append(lIIllllllIIIllI.getFile())));
      System.exit(llllIIll[50]);
      "".length();
      if ((0xA7 ^ 0x92 ^ 0x66 ^ 0x57) == (124 + 32 - 49 + 24 ^ 112 + 118 - 202 + 107)) {}
    }
    else if (llIIlIIlII(lIIllllllIIIllI.saveToFile(lIIllllllIIIlII)))
    {
      Bootstrap.printToSYSOUT(String.valueOf(new StringBuilder(llIlIlII[llllIIll[51]]).append(lIIllllllIIIlII.getAbsolutePath())));
      System.exit(llllIIll[50]);
      "".length();
      if (((0x9F ^ 0xBB) & (0x96 ^ 0xB2 ^ 0xFFFFFFFF)) == 0) {}
    }
    else
    {
      Bootstrap.printToSYSOUT(llIlIlII[llllIIll[52]]);
      System.exit(llllIIll[53]);
    }
  }
  
  protected void checkWindowResize()
  {
    ;
    ;
    ;
    if ((llIIlIIlIl(fullscreen)) && (llIIlIIlII(Display.wasResized())))
    {
      int lIIlllIlllIllII = displayWidth;
      int lIIlllIlllIlIll = displayHeight;
      displayWidth = Display.getWidth();
      displayHeight = Display.getHeight();
      if ((!llIIlIlIII(displayWidth, lIIlllIlllIllII)) || (llIIlIllIl(displayHeight, lIIlllIlllIlIll)))
      {
        if (llIIlIlIlI(displayWidth)) {
          displayWidth = llllIIll[1];
        }
        if (llIIlIlIlI(displayHeight)) {
          displayHeight = llllIIll[1];
        }
        lIIlllIlllIllIl.resize(displayWidth, displayHeight);
      }
    }
  }
  
  public static Map<String, String> getSessionInfo()
  {
    ;
    Map<String, String> lIIllIIlllIlIIl = Maps.newHashMap();
    "".length();
    "".length();
    "".length();
    return lIIllIIlllIlIIl;
  }
  
  public ItemRenderer getItemRenderer()
  {
    ;
    return itemRenderer;
  }
  
  public boolean isGamePaused()
  {
    ;
    return isGamePaused;
  }
  
  private void startTimerHackThread()
  {
    ;
    ;
    Thread lIIllllllIlIIll = new Thread(llIlIlII[llllIIll[44]])
    {
      public void run()
      {
        ;
        ;
        "".length();
        if ((30 + 3 - 17 + 176 ^ 44 + 75 - 40 + 117) == " ".length()) {
          return;
        }
        while (!lIIIlIIIlllIl(running)) {
          try
          {
            Thread.sleep(2147483647L);
            "".length();
            if ("   ".length() < -" ".length()) {
              return;
            }
          }
          catch (InterruptedException localInterruptedException) {}
        }
      }
      
      private static boolean lIIIlIIIlllIl(int ???)
      {
        float llllllllllllllllIlllllIlIlllIIIl;
        return ??? == 0;
      }
    };
    lIIllllllIlIIll.setDaemon(llllIIll[1]);
    lIIllllllIlIIll.start();
  }
  
  private void createDisplay()
    throws LWJGLException
  {
    ;
    ;
    ;
    Display.setResizable(llllIIll[1]);
    Display.setTitle(llIlIlII[llllIIll[35]]);
    try
    {
      Display.create(new PixelFormat().withDepthBits(llllIIll[35]));
      "".length();
      if (-" ".length() > "   ".length()) {}
    }
    catch (LWJGLException lIlIIIIIIIIIllI)
    {
      logger.error(llIlIlII[llllIIll[36]], lIlIIIIIIIIIllI);
      try
      {
        Thread.sleep(1000L);
        "".length();
        if ("   ".length() == -" ".length()) {
          return;
        }
      }
      catch (InterruptedException localInterruptedException)
      {
        if (llIIlIIlII(fullscreen)) {
          lIlIIIIIIIIIlIl.updateDisplayMode();
        }
        Display.create();
      }
    }
  }
  
  public Proxy getProxy()
  {
    ;
    return proxy;
  }
  
  private static int llIIlIlIll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llIIlIIllI(Object ???, Object arg1)
  {
    Object localObject;
    double lIIllIIlIIlIIIl;
    return ??? != localObject;
  }
  
  private void checkGLError(String lIIllllIIIIlllI)
  {
    ;
    ;
    ;
    ;
    if (llIIlIIlII(enableGLErrorChecking))
    {
      int lIIllllIIIlIIIl = GL11.glGetError();
      if (llIIlIIlII(lIIllllIIIlIIIl))
      {
        String lIIllllIIIlIIII = GLU.gluErrorString(lIIllllIIIlIIIl);
        logger.error(llIlIlII[llllIIll[59]]);
        logger.error(String.valueOf(new StringBuilder(llIlIlII[llllIIll[60]]).append(lIIllllIIIIlllI)));
        logger.error(String.valueOf(new StringBuilder(String.valueOf(lIIllllIIIlIIIl)).append(llIlIlII[llllIIll[61]]).append(lIIllllIIIlIIII)));
      }
    }
  }
  
  public void displayGuiScreen(GuiScreen lIIllllIIIllIll)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIIlIIIll(currentScreen)) {
      currentScreen.onGuiClosed();
    }
    if ((llIIlIIIIl(lIIllllIIIllIll)) && (llIIlIIIIl(theWorld)))
    {
      lIIllllIIIllIll = new GuiMainMenu();
      "".length();
      if (-"  ".length() < 0) {}
    }
    else if ((llIIlIIIIl(lIIllllIIIllIll)) && (llIIlIlIlI(llIIlIlIIl(thePlayer.getHealth(), 0.0F))))
    {
      lIIllllIIIllIll = new GuiGameOver();
    }
    if (llIIlIIlII(lIIllllIIIllIll instanceof GuiMainMenu))
    {
      gameSettings.showDebugInfo = llllIIll[0];
      ingameGUI.getChatGUI().clearChatMessages();
    }
    currentScreen = lIIllllIIIllIll;
    if (llIIlIIIll(lIIllllIIIllIll))
    {
      lIIllllIIlIIIIl.setIngameNotInFocus();
      ScaledResolution lIIllllIIIlllll = new ScaledResolution(lIIllllIIlIIIIl);
      int lIIllllIIIllllI = ScaledResolution.getScaledWidth();
      int lIIllllIIIlllIl = lIIllllIIIlllll.getScaledHeight();
      lIIllllIIIllIll.setWorldAndResolution(lIIllllIIlIIIIl, lIIllllIIIllllI, lIIllllIIIlllIl);
      skipRenderWorld = llllIIll[0];
      "".length();
      if (" ".length() != 0) {}
    }
    else
    {
      mcSoundHandler.resumeSounds();
      lIIllllIIlIIIIl.setIngameFocus();
    }
  }
  
  public static boolean isFancyGraphicsEnabled()
  {
    if ((llIIlIIIll(theMinecraft)) && (llIIlIIlII(theMinecraftgameSettings.fancyGraphics))) {
      return llllIIll[1];
    }
    return llllIIll[0];
  }
  
  private void displayDebugInfo(long lIIlllIlIlllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIlIIlII(mcProfiler.profilingEnabled))
    {
      List<Profiler.Result> lIIlllIlIllIlll = mcProfiler.getProfilingData(debugProfilerName);
      Profiler.Result lIIlllIlIllIllI = (Profiler.Result)lIIlllIlIllIlll.remove(llllIIll[0]);
      GlStateManager.clear(llllIIll[58]);
      GlStateManager.matrixMode(llllIIll[28]);
      GlStateManager.enableColorMaterial();
      GlStateManager.loadIdentity();
      GlStateManager.ortho(0.0D, displayWidth, displayHeight, 0.0D, 1000.0D, 3000.0D);
      GlStateManager.matrixMode(llllIIll[29]);
      GlStateManager.loadIdentity();
      GlStateManager.translate(0.0F, 0.0F, -2000.0F);
      GL11.glLineWidth(1.0F);
      GlStateManager.disableTexture2D();
      Tessellator lIIlllIlIllIlIl = Tessellator.getInstance();
      WorldRenderer lIIlllIlIllIlII = lIIlllIlIllIlIl.getWorldRenderer();
      int lIIlllIlIllIIll = llllIIll[97];
      int lIIlllIlIllIIlI = displayWidth - lIIlllIlIllIIll - llllIIll[15];
      int lIIlllIlIllIIIl = displayHeight - lIIlllIlIllIIll * llllIIll[3];
      GlStateManager.enableBlend();
      lIIlllIlIllIlII.begin(llllIIll[12], DefaultVertexFormats.POSITION_COLOR);
      lIIlllIlIllIlII.pos(lIIlllIlIllIIlI - lIIlllIlIllIIll * 1.1F, lIIlllIlIllIIIl - lIIlllIlIllIIll * 0.6F - 16.0F, 0.0D).color(llllIIll[98], llllIIll[0], llllIIll[0], llllIIll[0]).endVertex();
      lIIlllIlIllIlII.pos(lIIlllIlIllIIlI - lIIlllIlIllIIll * 1.1F, lIIlllIlIllIIIl + lIIlllIlIllIIll * llllIIll[3], 0.0D).color(llllIIll[98], llllIIll[0], llllIIll[0], llllIIll[0]).endVertex();
      lIIlllIlIllIlII.pos(lIIlllIlIllIIlI + lIIlllIlIllIIll * 1.1F, lIIlllIlIllIIIl + lIIlllIlIllIIll * llllIIll[3], 0.0D).color(llllIIll[98], llllIIll[0], llllIIll[0], llllIIll[0]).endVertex();
      lIIlllIlIllIlII.pos(lIIlllIlIllIIlI + lIIlllIlIllIIll * 1.1F, lIIlllIlIllIIIl - lIIlllIlIllIIll * 0.6F - 16.0F, 0.0D).color(llllIIll[98], llllIIll[0], llllIIll[0], llllIIll[0]).endVertex();
      lIIlllIlIllIlIl.draw();
      GlStateManager.disableBlend();
      double lIIlllIlIllIIII = 0.0D;
      int lIIlllIlIlIllll = llllIIll[0];
      "".length();
      if ((0x3F ^ 0x5B ^ 0xFD ^ 0x9D) == 0) {
        return;
      }
      while (!llIIlIIlll(lIIlllIlIlIllll, lIIlllIlIllIlll.size()))
      {
        Profiler.Result lIIlllIlIlIlllI = (Profiler.Result)lIIlllIlIllIlll.get(lIIlllIlIlIllll);
        int lIIlllIlIlIllIl = MathHelper.floor_double(field_76332_a / 4.0D) + llllIIll[1];
        lIIlllIlIllIlII.begin(llllIIll[11], DefaultVertexFormats.POSITION_COLOR);
        int lIIlllIlIlIllII = lIIlllIlIlIlllI.func_76329_a();
        int lIIlllIlIlIlIll = lIIlllIlIlIllII >> llllIIll[21] & llllIIll[55];
        int lIIlllIlIlIlIlI = lIIlllIlIlIllII >> llllIIll[13] & llllIIll[55];
        int lIIlllIlIlIlIIl = lIIlllIlIlIllII & llllIIll[55];
        lIIlllIlIllIlII.pos(lIIlllIlIllIIlI, lIIlllIlIllIIIl, 0.0D).color(lIIlllIlIlIlIll, lIIlllIlIlIlIlI, lIIlllIlIlIlIIl, llllIIll[55]).endVertex();
        int lIIlllIlIlIlIII = lIIlllIlIlIllIl;
        "".length();
        if (" ".length() == ((0x9E ^ 0xC2) & (0xE4 ^ 0xB8 ^ 0xFFFFFFFF))) {
          return;
        }
        while (!llIIlIlllI(lIIlllIlIlIlIII))
        {
          float lIIlllIlIlIIlll = (float)((lIIlllIlIllIIII + field_76332_a * lIIlllIlIlIlIII / lIIlllIlIlIllIl) * 3.141592653589793D * 2.0D / 100.0D);
          float lIIlllIlIlIIllI = MathHelper.sin(lIIlllIlIlIIlll) * lIIlllIlIllIIll;
          float lIIlllIlIlIIlIl = MathHelper.cos(lIIlllIlIlIIlll) * lIIlllIlIllIIll * 0.5F;
          lIIlllIlIllIlII.pos(lIIlllIlIllIIlI + lIIlllIlIlIIllI, lIIlllIlIllIIIl - lIIlllIlIlIIlIl, 0.0D).color(lIIlllIlIlIlIll, lIIlllIlIlIlIlI, lIIlllIlIlIlIIl, llllIIll[55]).endVertex();
          lIIlllIlIlIlIII--;
        }
        lIIlllIlIllIlIl.draw();
        lIIlllIlIllIlII.begin(llllIIll[10], DefaultVertexFormats.POSITION_COLOR);
        int lIIlllIlIlIIlII = lIIlllIlIlIllIl;
        "".length();
        if (((0x5B ^ 0x6F) & (0x81 ^ 0xB5 ^ 0xFFFFFFFF)) != 0) {
          return;
        }
        while (!llIIlIlllI(lIIlllIlIlIIlII))
        {
          float lIIlllIlIlIIIll = (float)((lIIlllIlIllIIII + field_76332_a * lIIlllIlIlIIlII / lIIlllIlIlIllIl) * 3.141592653589793D * 2.0D / 100.0D);
          float lIIlllIlIlIIIlI = MathHelper.sin(lIIlllIlIlIIIll) * lIIlllIlIllIIll;
          float lIIlllIlIlIIIIl = MathHelper.cos(lIIlllIlIlIIIll) * lIIlllIlIllIIll * 0.5F;
          lIIlllIlIllIlII.pos(lIIlllIlIllIIlI + lIIlllIlIlIIIlI, lIIlllIlIllIIIl - lIIlllIlIlIIIIl, 0.0D).color(lIIlllIlIlIlIll >> llllIIll[1], lIIlllIlIlIlIlI >> llllIIll[1], lIIlllIlIlIlIIl >> llllIIll[1], llllIIll[55]).endVertex();
          lIIlllIlIllIlII.pos(lIIlllIlIllIIlI + lIIlllIlIlIIIlI, lIIlllIlIllIIIl - lIIlllIlIlIIIIl + 10.0F, 0.0D).color(lIIlllIlIlIlIll >> llllIIll[1], lIIlllIlIlIlIlI >> llllIIll[1], lIIlllIlIlIlIIl >> llllIIll[1], llllIIll[55]).endVertex();
          lIIlllIlIlIIlII--;
        }
        lIIlllIlIllIlIl.draw();
        lIIlllIlIllIIII += field_76332_a;
        lIIlllIlIlIllll++;
      }
      DecimalFormat lIIlllIlIlIIIII = new DecimalFormat(llIlIlII[llllIIll[99]]);
      GlStateManager.enableTexture2D();
      String lIIlllIlIIlllll = llIlIlII[llllIIll[100]];
      if (llIIlIIlIl(field_76331_c.equals(llIlIlII[llllIIll[101]]))) {
        lIIlllIlIIlllll = String.valueOf(new StringBuilder(String.valueOf(lIIlllIlIIlllll)).append(llIlIlII[llllIIll[102]]));
      }
      if (llIIlIIlIl(field_76331_c.length()))
      {
        lIIlllIlIIlllll = String.valueOf(new StringBuilder(String.valueOf(lIIlllIlIIlllll)).append(llIlIlII[llllIIll[103]]));
        "".length();
        if (-(0x2A ^ 0x60 ^ 0xEF ^ 0xA1) <= 0) {}
      }
      else
      {
        lIIlllIlIIlllll = String.valueOf(new StringBuilder(String.valueOf(lIIlllIlIIlllll)).append(field_76331_c).append(llIlIlII[llllIIll[104]]));
      }
      int lIIlllIlIIllllI = llllIIll[105];
      "".length();
      lIIlllIlIIlllll = String.valueOf(new StringBuilder(String.valueOf(lIIlllIlIlIIIII.format(field_76330_b))).append(llIlIlII[llllIIll[106]]));
      "".length();
      int lIIlllIlIIlllIl = llllIIll[0];
      "".length();
      if ((0x16 ^ 0x12) > (0xC ^ 0x8)) {
        return;
      }
      while (!llIIlIIlll(lIIlllIlIIlllIl, lIIlllIlIllIlll.size()))
      {
        Profiler.Result lIIlllIlIIlllII = (Profiler.Result)lIIlllIlIllIlll.get(lIIlllIlIIlllIl);
        String lIIlllIlIIllIll = llIlIlII[llllIIll[107]];
        if (llIIlIIlII(field_76331_c.equals(llIlIlII[llllIIll[108]])))
        {
          lIIlllIlIIllIll = String.valueOf(new StringBuilder(String.valueOf(lIIlllIlIIllIll)).append(llIlIlII[llllIIll[109]]));
          "".length();
          if (-"  ".length() <= 0) {}
        }
        else
        {
          lIIlllIlIIllIll = String.valueOf(new StringBuilder(String.valueOf(lIIlllIlIIllIll)).append(llIlIlII[llllIIll[110]]).append(lIIlllIlIIlllIl + llllIIll[1]).append(llIlIlII[llllIIll[111]]));
        }
        lIIlllIlIIllIll = String.valueOf(new StringBuilder(String.valueOf(lIIlllIlIIllIll)).append(field_76331_c));
        "".length();
        lIIlllIlIIllIll = String.valueOf(new StringBuilder(String.valueOf(lIIlllIlIlIIIII.format(field_76332_a))).append(llIlIlII[llllIIll[112]]));
        "".length();
        lIIlllIlIIllIll = String.valueOf(new StringBuilder(String.valueOf(lIIlllIlIlIIIII.format(field_76330_b))).append(llIlIlII[llllIIll[113]]));
        "".length();
      }
    }
  }
  
  public boolean isIntegratedServerRunning()
  {
    ;
    return integratedServerIsRunning;
  }
  
  private static boolean llIIlIlllI(int ???)
  {
    Exception lIIllIIlIIIIIIl;
    return ??? < 0;
  }
  
  public MinecraftSessionService getSessionService()
  {
    ;
    return sessionService;
  }
  
  private static void llIIIIlllI()
  {
    llIlIlII = new String[llllIIll['ı']];
    llIlIlII[llllIIll[0]] = lIlIlIIIlI("H8YtKpPsa44GWym7W/ndNnrYw2Ve2yPyE2KZyBWG0o4=", "YFFpn");
    llIlIlII[llllIIll[1]] = lIlIlIIIll("igYRHBH5zk4=", "TnjHa");
    llIlIlII[llllIIll[3]] = lIlIlIIIlI("TjFPCO/kHRw=", "kuWcw");
    llIlIlII[llllIIll[8]] = lIlIlIIlII("NCQoDQ==", "FKGyt");
    llIlIlII[llllIIll[9]] = lIlIlIIIll("MaD8+HLcXWTzUvEtYUU/TQ==", "eBoPf");
    llIlIlII[llllIIll[10]] = lIlIlIIlII("XiUVBSYfGR5WHDJWGQV1", "vvpvU");
    llIlIlII[llllIIll[11]] = lIlIlIIlII("WQ==", "pPHBb");
    llIlIlII[llllIIll[12]] = lIlIlIIIll("KzWVMn8uJVeJFdYb/+1XmvjXxi6roed4", "omqws");
    llIlIlII[llllIIll[13]] = lIlIlIIIlI("39EBD735CA6w6+O5B8JTvA==", "TAeWn");
    llIlIlII[llllIIll[14]] = lIlIlIIIll("aGpAtTGLUA3aBPlUReMe5dQ4/U/2e06gUEIHjKx7TpA=", "uHMdV");
    llIlIlII[llllIIll[15]] = lIlIlIIIll("42hGzJSnyGbMS+ik/x+8z/f2QMj0Jjrg", "VVHPy");
    llIlIlII[llllIIll[16]] = lIlIlIIIlI("nov267xNOVG+BuUnT40RcVo1RPcilR2bgydMIPadgig=", "EdIUu");
    llIlIlII[llllIIll[17]] = lIlIlIIIll("TX2A8IvubgaOAoNQBOmFUw==", "HXiXa");
    llIlIlII[llllIIll[18]] = lIlIlIIIlI("ITMy+fNOM2uo83xQctRbe3LR3+qFyf04", "HDyAg");
    llIlIlII[llllIIll[19]] = lIlIlIIIlI("bKFfTkcn27w=", "SXxaL");
    llIlIlII[llllIIll[20]] = lIlIlIIIlI("zLl2kPmy5mo=", "HKMYD");
    llIlIlII[llllIIll[21]] = lIlIlIIlII("OxQUIAI9FB97ESAfGHsWPBIFPVk/Hws=", "OqlTw");
    llIlIlII[llllIIll[22]] = lIlIlIIlII("Lig7ATQoKDBaJzUjN1ogKS4qHB4pKiJbMTQq", "ZMCuA");
    llIlIlII[llllIIll[23]] = lIlIlIIlII("PBUdSjQYBgoeMhw=", "lgxjG");
    llIlIlII[llllIIll[30]] = lIlIlIIlII("IyYJBxcFIg==", "pRhuc");
    llIlIlII[llllIIll[31]] = lIlIlIIIll("xjvIFAqtFvoKHW3L12rESA==", "ERFlX");
    llIlIlII[llllIIll[32]] = lIlIlIIIll("EikJ6RljSYzDLiScPDNWtw==", "IzXyJ");
    llIlIlII[llllIIll[33]] = lIlIlIIIll("p4wgF6+U4lSKBMRIG8KByFaKOVHMqkKo", "yNCJW");
    llIlIlII[llllIIll[34]] = lIlIlIIIll("iSRRaDz9bl7vVCOwpiHdp6GvSVsxr+L7g2FOwMcdcI4OodCkJX9dnA==", "pRcdj");
    llIlIlII[llllIIll[35]] = lIlIlIIlII("AGsPIggKAmhGZ2BocFdmeBEkFioiJyYeLHghOg4=", "XFHwI");
    llIlIlII[llllIIll[36]] = lIlIlIIIll("Eyif7fC5AL4R0WCuOK9nPTuVx++QX1P02knzbj4o9Ws=", "FrXGu");
    llIlIlII[llllIIll[37]] = lIlIlIIlII("Hy88JTpZJTAkJyl9ZTN4QGIjJS4=", "vLSKI");
    llIlIlII[llllIIll[38]] = lIlIlIIIll("jUU09zy/9s9D4HWvWMxDPoEPBhBhtf6q", "ysANh");
    llIlIlII[llllIIll[39]] = lIlIlIIlII("EAUlCAw9TSREGzYecA0LPAQ=", "SjPdh");
    llIlIlII[llllIIll[40]] = lIlIlIIIlI("6MqX1jsrlOwkZyXEKSxFEBtHcbNFHe+H", "QjOyF");
    llIlIlII[llllIIll[41]] = lIlIlIIlII("MhkvYy0zG2w7KX8UKzkpPhIn", "QvBMD");
    llIlIlII[llllIIll[42]] = lIlIlIIIlI("icH8UI8xGbc=", "QVKjp");
    llIlIlII[llllIIll[43]] = lIlIlIIIlI("PF0wYo7sf8U=", "nDwsN");
    llIlIlII[llllIIll[44]] = lIlIlIIIll("JQEQE6QY5mZEzNjv8PFt6ZQW4QG5D3lw", "LUNyP");
    llIlIlII[llllIIll[45]] = lIlIlIIIll("zKjYmw+73LPKHT328K+L8g==", "IQYuQ");
    llIlIlII[llllIIll[46]] = lIlIlIIIll("hhlnfD9TM/k=", "AOUlI");
    llIlIlII[llllIIll[47]] = lIlIlIIIll("0kJB7sl7StT/iMc/2TxqpEL8OcyH0NoF", "QITnE");
    llIlIlII[llllIIll[48]] = lIlIlIIIlI("OX5LCicUMDmagPPerU7J4g==", "ujeDf");
    llIlIlII[llllIIll[49]] = lIlIlIIIll("tmmbF96oXQKSEA19Y2tjTjH3uY0sHI/BvooE3wKyLMCuI0YO827J+YQgJaLHVnkw35sLDs1hrmo=", "xwFpz");
    llIlIlII[llllIIll[51]] = lIlIlIIIll("GCjVTxwXdHI4uO+MjyfmShHjrR06d6u9b5AdM5Ytes/U5Fuf4H0Ak0VYIadAZSsgzRK/18htNd4=", "KegXl");
    llIlIlII[llllIIll[52]] = lIlIlIIIll("baZf2Ebb2l0T8lVx7SOKSy+o8iZMwFv4C3JY+WNUu+N5a41mxvCLVEoThSpojSu3D5nrEZPmTefq0BkoddtqGg==", "WnABb");
    llIlIlII[llllIIll[54]] = lIlIlIIlII("Oy8MCjEMbhwfKxc8WR4tEToaBTAWKVVNKx0jFhswFilZDDUUbhgeKhEpFwg9WDwcHjYNPBoIKRktEh4=", "xNymY");
    llIlIlII[llllIIll[56]] = lIlIlIIIlI("/ypPvPTZYSY=", "KWYLr");
    llIlIlII[llllIIll[57]] = lIlIlIIlII("MQ00ACEBQyENbQgMNAZtCAwyDXdE", "dcUbM");
    llIlIlII[llllIIll[59]] = lIlIlIIIll("FgSo+bWw89zdMsoAnbkD/lr/+GTlS+dTVMKvl0cY9Xk=", "DFOpc");
    llIlIlII[llllIIll[60]] = lIlIlIIIll("9KbQGbULXng=", "EXJiX");
    llIlIlII[llllIIll[61]] = lIlIlIIlII("fWk=", "GIXuW");
    llIlIlII[llllIIll[62]] = lIlIlIIIlI("OtkbLAEZOovbJd9CmyF4Dg==", "hyQzO");
    llIlIlII[llllIIll[63]] = lIlIlIIIlI("w1yOp4N08tM=", "xcqXK");
    llIlIlII[llllIIll[64]] = lIlIlIIlII("CSg5JCkPJzQlCAIuMjQ5Gyk9JD4=", "zKQAM");
    llIlIlII[llllIIll[65]] = lIlIlIIIll("w2O8BSjT4PY=", "XyTtu");
    llIlIlII[llllIIll[66]] = lIlIlIIlII("EScEPhEPMQQeMRMnDh4H", "aUalt");
    llIlIlII[llllIIll[67]] = lIlIlIIlII("Bx4zSwQyAjIOBA==", "WlVkv");
    llIlIlII[llllIIll[68]] = lIlIlIIlII("CTwxGCc=", "zSDvC");
    llIlIlII[llllIIll[69]] = lIlIlIIlII("Bx0rCzYH", "uxEoS");
    llIlIlII[llllIIll[71]] = lIlIlIIIll("uHm/5tvI8qI=", "HpoeX");
    llIlIlII[llllIIll[72]] = lIlIlIIlII("NQ4OKwQ3AQcrJDcd", "RocNV");
    llIlIlII[llllIIll[73]] = lIlIlIIlII("MTkqHQ==", "CVEid");
    llIlIlII[llllIIll[74]] = lIlIlIIIlI("yXomvY0DxS4=", "QyORE");
    llIlIlII[llllIIll[75]] = lIlIlIIIlI("QTR7B86pYQ4=", "NtYNU");
    llIlIlII[llllIIll[76]] = lIlIlIIIll("Z2kMzvFeCa8=", "TnSbR");
    llIlIlII[llllIIll[77]] = lIlIlIIIll("XEL0vfbRQ5ghTIJJQE9O0Q==", "YirWV");
    llIlIlII[llllIIll[78]] = lIlIlIIlII("VSpYDzMDblBMJ1AtEBwtG24NGScROh1MMFluLFNjVT1dGmYDawtMMA==", "pNxiC");
    llIlIlII[llllIIll[79]] = lIlIlIIlII("Og==", "IrtxJ");
    llIlIlII[llllIIll[80]] = lIlIlIIIlI("ihBDMMKr7A8=", "QnRls");
    llIlIlII[llllIIll[81]] = lIlIlIIIll("unyvY+Z3094=", "WmhwL");
    llIlIlII[llllIIll[82]] = lIlIlIIIll("y7EZiqJwUs4=", "QGwRB");
    llIlIlII[llllIIll[83]] = lIlIlIIIll("MrRsOSjlyfM=", "BPJXG");
    llIlIlII[llllIIll[84]] = lIlIlIIIlI("YGOXkaAohuE=", "JQnEV");
    llIlIlII[llllIIll[85]] = lIlIlIIIlI("7kcQEus+rX4=", "wnYqj");
    llIlIlII[llllIIll[86]] = lIlIlIIIll("Y9F6rcBGIbc=", "RYVxW");
    llIlIlII[llllIIll[87]] = lIlIlIIlII("dB8mJyR5Gis7JTAK", "TyGTP");
    llIlIlII[llllIIll[88]] = lIlIlIIIlI("LIsHESFpY2OVaKt5f06gVg==", "pBTpA");
    llIlIlII[llllIIll[89]] = lIlIlIIIlI("WXRYgjlBNT0=", "HUNVX");
    llIlIlII[llllIIll[90]] = lIlIlIIIlI("lLKi1wx6flo=", "RqMOb");
    llIlIlII[llllIIll[92]] = lIlIlIIIlI("fAx2/UBsc23S7Ujy8hsEVA==", "kHivF");
    llIlIlII[llllIIll[93]] = lIlIlIIIll("5xmVUenudl5+ZKH0pMEgOQ==", "iZNnW");
    llIlIlII[llllIIll[94]] = lIlIlIIlII("dw==", "YklJX");
    llIlIlII[llllIIll[95]] = lIlIlIIIll("uNjavUzk1ub40hVhwSMwBw==", "zvyfB");
    llIlIlII[llllIIll[96]] = lIlIlIIIlI("hNkfSXgAKow=", "RObzC");
    llIlIlII[llllIIll[99]] = lIlIlIIIll("ggSI54mJIZg=", "sLQMJ");
    llIlIlII[llllIIll[100]] = lIlIlIIIll("FjDaN2UGbKw=", "FQint");
    llIlIlII[llllIIll[101]] = lIlIlIIIlI("h02HxAuNQWzlPpa2AVWR+Q==", "FEYRB");
    llIlIlII[llllIIll[102]] = lIlIlIIIlI("cuaTJio4W/8=", "nPqMS");
    llIlIlII[llllIIll[103]] = lIlIlIIIlI("3F38YcmOThQ=", "WPDVo");
    llIlIlII[llllIIll[104]] = lIlIlIIIll("drM+pMF3FeM=", "YzQra");
    llIlIlII[llllIIll[106]] = lIlIlIIIll("9pLDtZZeZIw=", "MQCOV");
    llIlIlII[llllIIll[107]] = lIlIlIIIll("wcFi1aqRoI8=", "KQrdh");
    llIlIlII[llllIIll[108]] = lIlIlIIlII("MykfNA8lLgotDyI=", "FGlDj");
    llIlIlII[llllIIll[109]] = lIlIlIIlII("L2ozaA==", "tUnHc");
    llIlIlII[llllIIll[110]] = lIlIlIIIll("cRPrk3jp7CE=", "ASCIq");
    llIlIlII[llllIIll[111]] = lIlIlIIIlI("aTwsRFeQQcc=", "ZpxGH");
    llIlIlII[llllIIll[112]] = lIlIlIIIll("o2+Lt4D7aSo=", "DsWcB");
    llIlIlII[llllIIll[113]] = lIlIlIIlII("Rg==", "cbWhH");
    llIlIlII[llllIIll[115]] = lIlIlIIlII("LTIABkwRIhgfHg0iCEoNEGdLAgUXFQkZGQ8zS0ZMFy8FGUwQLwMfAAcpSx5MCyYcGgkNZg==", "cGljl");
    llIlIlII[llllIIll[116]] = lIlIlIIlII("ADwlBUw8LD0cHiAsLUkNPWluAQU6GywaGSI9bkVMOiEgGkw9ISYcAConbh1MJig5GQkgaA==", "NIIil");
    llIlIlII[llllIIll[117]] = lIlIlIIIll("qeIAXDILaN8rojhKRQKU+5ONnhoeK+IyeaYsedjamxs=", "bvSmX");
    llIlIlII[llllIIll[118]] = lIlIlIIlII("NA8g", "SzIYq");
    llIlIlII[llllIIll[119]] = lIlIlIIlII("NzgkEx0/PSw=", "PYIvP");
    llIlIlII[llllIIll[120]] = lIlIlIIlII("MRQZGDg3FBI=", "EqalM");
    llIlIlII[llllIIll[121]] = lIlIlIIIlI("sOFfjsVMsrONF8/T7OijklhTxYyNN6zQ", "OJfGD");
    llIlIlII[llllIIll[122]] = lIlIlIIIlI("NdAD+u9der5KTZgcSuqQvg==", "RDPQd");
    llIlIlII[llllIIll[123]] = lIlIlIIIll("jqVBbJ7SpMerX5rxbFjKhQ==", "BbkjC");
    llIlIlII[llllIIll[124]] = lIlIlIIIlI("L9bAycZ3bYrqMEdVrElvrg==", "eIPPh");
    llIlIlII[llllIIll[125]] = lIlIlIIlII("CTMxJyA8MDNiMCsnMict", "HUWBC");
    llIlIlII[llllIIll[126]] = lIlIlIIIll("N18holVwCsN2whmkTruGsQ==", "vhgvv");
    llIlIlII[llllIIll[127]] = lIlIlIIlII("HyYNPA0=", "rIxOh");
    llIlIlII[llllIIll['']] = lIlIlIIIll("sl7UKkH/FohLm11bvHUTAg==", "slnCj");
    llIlIlII[llllIIll['']] = lIlIlIIIll("VWjUWmeG5cFtzQYtXqBe+DF9z8Q0ntCWK+Jr6FD6/dM=", "WlMpG");
    llIlIlII[llllIIll['']] = lIlIlIIIll("V5qsRxLugZc=", "lnrmZ");
    llIlIlII[llllIIll['']] = lIlIlIIIlI("BICtCQtltOaCVhTdINmywQ==", "AeJPX");
    llIlIlII[llllIIll['']] = lIlIlIIIlI("uakyUEJzBtJTXKNQQZCFDg==", "iqRHI");
    llIlIlII[llllIIll['']] = lIlIlIIIlI("1rsDrMXlph0=", "qWcVG");
    llIlIlII[llllIIll['']] = lIlIlIIIlI("TNbDHIhb85QpF/PV/JgxRyVWegVY88ML", "imrDb");
    llIlIlII[llllIIll['']] = lIlIlIIIlI("52CT1B3uy79X1lue3mNYzw==", "TfJHW");
    llIlIlII[llllIIll['']] = lIlIlIIIlI("VVlMXwg45mg=", "rPnvU");
    llIlIlII[llllIIll['']] = lIlIlIIlII("IRcVCxpNGxBOGBgeD08=", "mrcnv");
    llIlIlII[llllIIll['']] = lIlIlIIIll("YLrx4NloJcEDoQkXR/MgLA==", "mRZIQ");
    llIlIlII[llllIIll['']] = lIlIlIIIlI("CaNjHCErZGjercFMBXDy9A==", "PRTrx");
    llIlIlII[llllIIll['']] = lIlIlIIIll("pAsBxFmNZ1tzYX4dBM/kh9BgnLkR4iD7", "GcfPZ");
    llIlIlII[llllIIll['']] = lIlIlIIIll("A78oqLI/R1xj9e5xrhm5fwByeMXsp4ncBS9jMyA2eC8=", "QrJTS");
    llIlIlII[llllIIll['']] = lIlIlIIIll("PUS+SXQMuF9AS6GIaP2RB8NGQsUjvJeF3Jge8A1o0sM=", "lFymW");
    llIlIlII[llllIIll['']] = lIlIlIIIlI("h/ymLs5aZGoXAT0748r3ZA==", "FCdmX");
    llIlIlII[llllIIll['']] = lIlIlIIlII("CSscFzhlAAsfMQ==", "ENjrT");
    llIlIlII[llllIIll['']] = lIlIlIIIll("oCLYVT/LIEpyUTnvcW5sbdw0Z2yXvdWM", "yiWKx");
    llIlIlII[llllIIll['']] = lIlIlIIIll("jatCY6sXk0Q=", "ApShq");
    llIlIlII[llllIIll['']] = lIlIlIIlII("", "zYHrv");
    llIlIlII[llllIIll['']] = lIlIlIIIll("tKIZ6FX+tjs=", "osvGh");
    llIlIlII[llllIIll['']] = lIlIlIIlII("CiEZLho=", "EVwKh");
    llIlIlII[llllIIll['']] = lIlIlIIIlI("InGMkFD0zMo=", "DHqLT");
    llIlIlII[llllIIll['']] = lIlIlIIIll("eIfdG1fo+YVBTBNN23kXLw==", "ScxSX");
    llIlIlII[llllIIll['']] = lIlIlIIIlI("e6ayg3NJfEt2zDEPmgkBZg==", "ZEPNK");
    llIlIlII[llllIIll['']] = lIlIlIIlII("cl8sKDBz", "Ztbjd");
    llIlIlII[llllIIll['']] = lIlIlIIIll("9H+Plvm1Om8=", "TKnHK");
    llIlIlII[llllIIll['']] = lIlIlIIIll("JjXB3cEcMBg=", "vHQql");
    llIlIlII[llllIIll['']] = lIlIlIIlII("Kxs7ByIPHypJFwIIPQAuCQ==", "gzNiA");
    llIlIlII[llllIIll['']] = lIlIlIIIll("QFCUKBjCvTE=", "ggocX");
    llIlIlII[llllIIll['']] = lIlIlIIlII("FjENJzcV", "YAhIp");
    llIlIlII[llllIIll['']] = lIlIlIIlII("AzpQDyo0BQ==", "DvpLK");
    llIlIlII[llllIIll[' ']] = lIlIlIIIll("ZaU3U5k8Kpy7MJOnN4hKiQ==", "nsSYO");
    llIlIlII[llllIIll['¡']] = lIlIlIIlII("Ez5rPTY+KS4U", "ZMKpY");
    llIlIlII[llllIIll['¢']] = lIlIlIIIlI("SsQMsiKMDH0=", "nisyU");
    llIlIlII[llllIIll['£']] = lIlIlIIlII("CA8gAiQoCTZNATsJOB4=", "ZjSmQ");
    llIlIlII[llllIIll['¤']] = lIlIlIIlII("NSwdOQoYLU8HDhg+GioIEw==", "vYoKo");
    llIlIlII[llllIIll['¥']] = lIlIlIIIll("wtpv3e8eWOS4R2jZunGC0oFX5ehT0aTK", "gqdXk");
    llIlIlII[llllIIll['¦']] = lIlIlIIIll("388sY3O4Tig=", "dqMBR");
    llIlIlII[llllIIll['§']] = lIlIlIIIlI("8lNYp+uJBEU=", "PmIPM");
    llIlIlII[llllIIll['¨']] = lIlIlIIIlI("QAfoo8gsnrTcuY0UhMqWSg==", "CHgVC");
    llIlIlII[llllIIll['©']] = lIlIlIIIll("k2qxdIXBYsQWts4O4YsHNtGP1/fOwAQv", "qhACH");
    llIlIlII[llllIIll['ª']] = lIlIlIIIll("mg+Y5M3+bB2hF1eP1i7GQw==", "rSJKD");
    llIlIlII[llllIIll['«']] = lIlIlIIlII("LCINHQIpJQQUHw==", "JWaqq");
    llIlIlII[llllIIll['¬']] = lIlIlIIlII("JgAPNQcmDAU=", "QiaQh");
    llIlIlII[llllIIll['­']] = lIlIlIIlII("BQYGCzEeHg0=", "wshTE");
    llIlIlII[llllIIll['®']] = lIlIlIIIll("nrnReIAYeGU7D5T4Oje1sA==", "mArMD");
    llIlIlII[llllIIll['¯']] = lIlIlIIlII("Ljo9Dicn", "BSIzK");
    llIlIlII[llllIIll['°']] = lIlIlIIIll("z0C6Z7s8200=", "qUlHP");
    llIlIlII[llllIIll['±']] = lIlIlIIIlI("FnVi6bSOnZl1LMy9fL2Z1g==", "ozwZc");
    llIlIlII[llllIIll['²']] = lIlIlIIIlI("DbLNaVB6xS1FWUf6Olk5Yg==", "cSIEi");
    llIlIlII[llllIIll['³']] = lIlIlIIlII("ARQyGTQBEiQpMRISKi0=", "sqAvA");
    llIlIlII[llllIIll['´']] = lIlIlIIIll("DuXmyp4Zl6o=", "RMybv");
    llIlIlII[llllIIll[97]] = lIlIlIIIlI("+DqGh0/JhcSzNCyWpKBnVQ==", "qUumF");
    llIlIlII[llllIIll['µ']] = lIlIlIIIlI("fIiyF9cS3GNRMrR5X0AzhQ==", "ythpf");
    llIlIlII[llllIIll['¶']] = lIlIlIIIll("JTumeOViaAZLmd9aBrP5Vw==", "cfDZw");
    llIlIlII[llllIIll['·']] = lIlIlIIIll("DJMG37sCCrpSMCMQcW+0ug==", "bTiOB");
    llIlIlII[llllIIll['¸']] = lIlIlIIIlI("oxKBehfEGI/+Wu6q7eoB8g==", "XKmEk");
    llIlIlII[llllIIll['¹']] = lIlIlIIIlI("hnPWSPrZtPI/xtTJgqfSVA==", "fQsqc");
    llIlIlII[llllIIll['º']] = lIlIlIIIll("we78mLzt51xjtv7yTS73og==", "lGlOu");
    llIlIlII[llllIIll['¼']] = lIlIlIIIlI("8rOSrclySlxqETkRs/Irrg==", "vEutE");
    llIlIlII[llllIIll['¾']] = lIlIlIIlII("ACcwCA0XFDsfAg0v", "cKYmc");
    llIlIlII[llllIIll['¿']] = lIlIlIIIlI("4V0ePlfo8JjO+FJUj+UaijETSDmp+uWO", "lkdaL");
    llIlIlII[llllIIll['À']] = lIlIlIIIlI("9Mx9HD9wYLNj0uwVEFQURuAkKyGXmIb7Ho3hlo7S7Kk=", "maqas");
    llIlIlII[llllIIll['Á']] = lIlIlIIIlI("AGBAUsfgEcISt53UYWReg86gRysMyxOCEovA9JuYi8g=", "gNlNG");
    llIlIlII[llllIIll['Â']] = lIlIlIIIll("uG5nNT/Aesn8chljp57MzwJ8Pcu67dsgChK64QDwI9asEsunns068A==", "PivSe");
    llIlIlII[llllIIll['Ã']] = lIlIlIIIll("/fzboIJMQu3vC++1qtpCULv35lKhX9Rxjj6T0J9TbKIeYpxlYQ979w==", "qANkM");
    llIlIlII[llllIIll['Ä']] = lIlIlIIIlI("/lEyIfOc8etajVzmQFMjah4U4eWPdO6FofiFGWq0Eos=", "AacAy");
    llIlIlII[llllIIll['Å']] = lIlIlIIlII("DhU3EzsZCjMxCCsmCx83GRgcGTgAFQEEIzQ=", "iyhpZ");
    llIlIlII[llllIIll['Æ']] = lIlIlIIIll("kjRaBV6tFgvLE/0wULbbdd7dUiNViQHIlG6FbBHnCHxi0EnauHjKx0eEPEd16mVk", "Cmltc");
    llIlIlII[llllIIll['Ç']] = lIlIlIIlII("DSs3CAoaNDMqOSgYCwQGGjIcDjQZLwkPDhga", "jGhkk");
    llIlIlII[llllIIll['È']] = lIlIlIIIll("rgtzA5gvMvdcM1z7T7e2wopF/DrzubMjpQlCyJsmju8=", "YDPHF");
    llIlIlII[llllIIll['É']] = lIlIlIIIlI("HdYtxmgm3oEuk5eHsPnFF6+wWrcwTKqe", "bZEEN");
    llIlIlII[llllIIll['Ê']] = lIlIlIIIll("j2BfMisynfRBGmmxw3vq4HWnjB0XiwiDToqEM8vr0og=", "RZWib");
    llIlIlII[llllIIll['Ë']] = lIlIlIIIlI("9hQTn/V+vcm7PSa29kBTLIR6lk4z2oFxisUVAGAtZPI=", "QzcZp");
    llIlIlII[llllIIll['Ì']] = lIlIlIIIll("x5qhBPOwHr7J7g/08AhxA/jpPVj+2pdEc2s8CBovl54=", "LujwA");
    llIlIlII[llllIIll['Í']] = lIlIlIIIlI("9YdxnnSrgLRhZWn38O6wfavCXphJ19PW", "psEZU");
    llIlIlII[llllIIll['Î']] = lIlIlIIIlI("pEkTiPkQENAFE9KAtfQ9NzeVfYC9c59JekfsDhZu9aA=", "gjufB");
    llIlIlII[llllIIll['Ï']] = lIlIlIIIll("k8qSj/1C5ubc8BND8rsdQ8npuJL2fjWvidGZhRb3H/Y=", "wolgV");
    llIlIlII[llllIIll['Ð']] = lIlIlIIlII("BSMzCTYSPDcrBSAQCA8nFiczHjIaOxkYMj8=", "bOljW");
    llIlIlII[llllIIll['Ñ']] = lIlIlIIIlI("HJwSYkkbHe0xnurXXTBogh9qtjwMCQHsVFSTwVlwiHA=", "bmrLL");
    llIlIlII[llllIIll['Ò']] = lIlIlIIlII("EwEZARUEHh0jJjYyIhAVAzIkFxISCDQRKxYBIwwQKQ==", "tmFbt");
    llIlIlII[llllIIll['Ó']] = lIlIlIIIlI("EmmMne7Y3ibrFqpjUGVMLU7Hnnq6Bc0hxJ24Xa0sZFZnt+871pGG0Q==", "eeaXv");
    llIlIlII[llllIIll['Ô']] = lIlIlIIlII("Ly86FyM4MD41EAocAQYjPxwMGiYhMQAXNhU=", "HCetB");
    llIlIlII[llllIIll['Õ']] = lIlIlIIlII("EjopBDcFJS0mBDcJEhU3AgkfCSUBNxgEMxEL", "uVvgV");
    llIlIlII[llllIIll['Ö']] = lIlIlIIlII("LjoOGQw5JQo7PwsJNAIdJT8yExkWNyUOHyA0DhYCKjclEwInCw==", "IVQzm");
    llIlIlII[llllIIll['×']] = lIlIlIIIll("0+hcEncmLcbUxZYw/waTPbeNdIxA5EiPrcR/4GTuGkP+VTbnY1sbtw==", "NzIbb");
    llIlIlII[llllIIll['Ø']] = lIlIlIIIll("MdksESeA60NW5/i5ckZQ8NlCzqco8hxouSfm5gr6sdtaAxH/XdCUtQ==", "yzdiq");
    llIlIlII[llllIIll['Ù']] = lIlIlIIIlI("AOKVHz7wA7Ucz7DwSi5COnqYFIQHfIY8BT91EjA6HkI=", "fdEcs");
    llIlIlII[llllIIll['Ú']] = lIlIlIIIlI("YXnXfk91qL8k0UEOYMK7x1xdS8ufL1CafJrrKIigHFo=", "wCMks");
    llIlIlII[llllIIll['Û']] = lIlIlIIIll("kaAKL9L1cKcW1f2klLMxR7DOHnAwqaC4vFixUtC7CE2Z9Tzh4TJ4dw==", "RrKRh");
    llIlIlII[llllIIll['Ü']] = lIlIlIIIll("7M0tSm0ZJF4BYPuyZPFtrs7igQuG8QmNmF0g3cY4jf4=", "gfwHj");
    llIlIlII[llllIIll['Ý']] = lIlIlIIIlI("CUoZtmVcj8Vaeglzea8ZWKhoH5q8kneHmz4qk9zlP00=", "UnmqA");
    llIlIlII[llllIIll[98]] = lIlIlIIlII("MyQbOwckOx8ZNBYXIz0JOS0wKh8LOyw5AjE6cAU=", "THDXf");
    llIlIlII[llllIIll['Þ']] = lIlIlIIIll("BapxIM/QpvqQ7Q6KZ9riAmaER+cgGUzxE15yZLqiqkg=", "fSVCb");
    llIlIlII[llllIIll['ß']] = lIlIlIIIlI("S/k24G48bq/QK13d4eMVV0cnCtSJsDhHYR+pLyJ/b/w=", "gcAqu");
    llIlIlII[llllIIll['à']] = lIlIlIIIll("HPzQuwAhSPKbRgP2/hoX2SoyqgS3JgAV06qAKK1c+G8=", "hmCpd");
    llIlIlII[llllIIll['á']] = lIlIlIIlII("Hz02EzIIIjIxAToOAB4gDDAHEzYcDggCIRkoGi0=", "xQipS");
    llIlIlII[llllIIll['â']] = lIlIlIIlII("PiMzIjIpPDcAARsQASAjBi0ZJzU8PTMgPzAoAiw2Nzsx", "YOlAS");
    llIlIlII[llllIIll['ã']] = lIlIlIIlII("PxgFLC0oBwEOHhorNy48BxYvKSo9BgU9LTYTPxI=", "XtZOL");
    llIlIlII[llllIIll['ä']] = lIlIlIIlII("Ky89EQM8MDkzMA4cDwcOOCoREw88Lwcv", "LCbrb");
    llIlIlII[llllIIll['å']] = lIlIlIIIlI("AFsaMx8ErDueIQayYkOZ0IpBv1kAMDAuTksq7LnfSdo=", "fSzWw");
    llIlIlII[llllIIll['æ']] = lIlIlIIIll("RfIlcYH1zTKmSLb5ozF8N8FnUbALYHdlKe/WmEbOReY=", "jhLWs");
    llIlIlII[llllIIll['ç']] = lIlIlIIIll("s9WB4TBpxJ0nBaVGzCckImfEsIacrhBob+NccWdRbtcTYFj8btL6cg==", "DfpGH");
    llIlIlII[llllIIll['è']] = lIlIlIIIlI("lYN9BeO1SOu8f6t9FXM7ANmVkoALrx51Xq4bXGAghcE=", "NKOSJ");
    llIlIlII[llllIIll['é']] = lIlIlIIIlI("sGPcM7C0eshxoZKaOT4F9zoLK+iTHaBCjA6FpNuyyEw=", "ChQWs");
    llIlIlII[llllIIll['ê']] = lIlIlIIlII("CyU1Ji0cOjEEHi4WGS0tCCwYGj8YLAQmJQAWDz08AzseGA==", "lIjEL");
    llIlIlII[llllIIll['ë']] = lIlIlIIIll("+c5eAMMPupeerKfEHxgc90+14JkXvXqKPUwNbLKIpgs=", "kzQdV");
    llIlIlII[llllIIll['ì']] = lIlIlIIlII("DwkKJSUYFg4HFio6Ji4lDAoiGw==", "heUFD");
    llIlIlII[llllIIll['í']] = lIlIlIIIll("5XNNcY/ewqoQTLYs3HKUOCu/dc0XQOPU4rV1EZ34bqg=", "occrB");
    llIlIlII[llllIIll['î']] = lIlIlIIIlI("rnYhOWNGuQWA5fchh+qHtu5F1cps0i8PJwU/gLankbY=", "NFhVz");
    llIlIlII[llllIIll['ï']] = lIlIlIIIlI("aK5+5dg19CFYAEMdjNj1d1IyvkSDzMyO", "OIdWB");
    llIlIlII[llllIIll['ð']] = lIlIlIIIlI("53t0p8DkdoomsLsZOdsYwGs73gWI85ETizI74PGtD1jyZwOBN1zgnA==", "HFfTw");
    llIlIlII[llllIIll['ñ']] = lIlIlIIIll("Y2ZPzdqrE667wpSInMJwDfX48yE3MizGMKM24HAyDAKH6yGrSbNsFg==", "TmRwF");
    llIlIlII[llllIIll['ò']] = lIlIlIIIlI("8TLXGluCfvmOgHV4aOZzGbpGItk4uz+SBAmsB/m5eIaMhtULMH2CWA==", "ANCvP");
    llIlIlII[llllIIll['ó']] = lIlIlIIIll("x0NM5fOvB6LRMObObM+zfvKu7i0kVJ25/NRyspgZtJc=", "KyjJx");
    llIlIlII[llllIIll['ô']] = lIlIlIIlII("NAAIKAIjHwwKMREzIy4bJxklLjwwGTUuPD4NJxQCIR42Mj4=", "SlWKc");
    llIlIlII[llllIIll['õ']] = lIlIlIIIlI("OAXMWU+sgBDrJE6uLsKUU0/iFOPXPb4Qkv4IQEPymzyshjg/dwEWoQ==", "rqvLJ");
    llIlIlII[llllIIll['ö']] = lIlIlIIlII("LCkGBhY7NgIkJQkaLAseLSorCCgpMD8DEjkaNgcdLiYtOA==", "KEYew");
    llIlIlII[llllIIll['÷']] = lIlIlIIIlI("LC85MHOD89CZljCJSS+ZLUWC2Lf9udOp/Bm5UQxXErU=", "HCFqi");
    llIlIlII[llllIIll['ø']] = lIlIlIIIlI("2HMS36TaeI4gxmb7ul/U2rsqoIQ+adj+LdD2mrcGS+Fz4PS0wiaLLg==", "xwUwI");
    llIlIlII[llllIIll['ù']] = lIlIlIIlII("NxUKMAsgCg4SOBImIzYYJBwtDBoiFjIhCz0k", "PyUSj");
    llIlIlII[llllIIll['ú']] = lIlIlIIIll("0NfLFKbi1gNGhC3e/J/lijoteKjQRSXzGzaid5ZausA=", "EyvNd");
    llIlIlII[llllIIll['û']] = lIlIlIIlII("Cyo2KzMcNTINCjgZCyE8CCcLJDczMwchNAM0BBU=", "lFiHR");
    llIlIlII[llllIIll['ü']] = lIlIlIIIll("UaHp9cOPn3jyYpvPQTYA0PfHkXjhfd6ewuwWPLHfXaf0LVh4xXQZMQ==", "uWJiB");
    llIlIlII[llllIIll['ý']] = lIlIlIIIll("8uObkbIvLCVu/TB6dfMADEhPqXMOjWpt9ueUAwm1y0tGVlqSQAhOew==", "rFxUI");
    llIlIlII[llllIIll['þ']] = lIlIlIIIll("6IZtSR5PhlUsxzH9pdUVC2gMce02LcFsVdtkg/l+I+w=", "xwsKk");
    llIlIlII[llllIIll['ÿ']] = lIlIlIIlII("Dx8+LRIYADoLKzwsAyIWBhc+PQYKBxMvEBwu", "hsaNs");
    llIlIlII[llllIIll['Ā']] = lIlIlIIIlI("1TlBK1STpC+Mt4OW9obokJpBP8gokZWUetptCuMF3fQ=", "JMPKb");
    llIlIlII[llllIIll['ā']] = lIlIlIIIll("lMvCqusSvRMfioJDlz2XFME+SuEkYRr+lhcsDDqdRjLo1pTiajO9DQ==", "vbYwX");
    llIlIlII[llllIIll['Ă']] = lIlIlIIIlI("kD5mSX/4WqkMA/rKPBHHL6l+Hqfo2iJB+IG2/PpA2C0=", "ounhd");
    llIlIlII[llllIIll['ă']] = lIlIlIIIlI("vPk4z7hlORWqBXtSSMozDlCwRF7ET4MKNCpOTPDtbEg=", "uNsxU");
    llIlIlII[llllIIll['Ą']] = lIlIlIIIlI("3sXx0fBwhMJBhP3FChgZ0MgVkWdheJfsIBvv3PWvCbA=", "FUVyA");
    llIlIlII[llllIIll['ą']] = lIlIlIIIll("ZNRjURJbQEzgNPZ4DJO7Al/CzKu4mr3BRU+nySvT4MUTCJgcPpAC9A==", "GxiXE");
    llIlIlII[llllIIll['Ć']] = lIlIlIIlII("DiMeEAUZPBo2PD0QJgMRNjwpEgAMPXUu", "iOAsd");
    llIlIlII[llllIIll['ć']] = lIlIlIIIll("havDDYL0/Eu5P8YlcuKoRcizpfYsqSzRKcamI/7bAV4=", "ehJmO");
    llIlIlII[llllIIll['Ĉ']] = lIlIlIIIll("NQ9NTQs+4t44juPPmZrlr1I2+pPaQ9lD44INuyJm62PL65KiyjO5mA==", "jHJre");
    llIlIlII[llllIIll['ĉ']] = lIlIlIIIlI("ilQ7ATa2CPJjMVu+Tw4eyEe/jrK4FDsxe2rGXSJNCA8=", "MCmQz");
    llIlIlII[llllIIll['Ċ']] = lIlIlIIIll("+Tgj2in9bqYvLLO8qi1OJQZr7AwxZ7gv0zAmZs410Qg=", "HQgZc");
    llIlIlII[llllIIll['ċ']] = lIlIlIIIlI("UZF2jy3dwsYE6t/MLcGfcXNF46T7UkTIsmfiY3zxLi9pMrhyyLZP0w==", "Asvng");
    llIlIlII[llllIIll['Č']] = lIlIlIIlII("PhY2KwYpCTINPw0lGiAGPR8bFw40Gw4tODUVCCw4Kg4GOgIE", "YziHg");
    llIlIlII[llllIIll['č']] = lIlIlIIIlI("5ssc6buQ+t0AOyhJrZ54lwd+lAHwHjqM3qmLspmQdho=", "IekYZ");
    llIlIlII[llllIIll['Ď']] = lIlIlIIlII("Cjw2GQkdIzI/MDkPGhIJHzUNJRwIKB0PGggPGRsECCQdHzU=", "mPizh");
    llIlIlII[llllIIll['ď']] = lIlIlIIIlI("UOjTJU7um3FewWhbxbrSzeW5ZwYhDDeN6I1kuCzvtPY=", "RUuxZ");
    llIlIlII[llllIIll['Đ']] = lIlIlIIlII("JT47BhYyIT8gLxYNFxESLDENCSg2JQs6BCs2ATg=", "BRdew");
    llIlIlII[llllIIll['đ']] = lIlIlIIIll("mfHBBFRI2Zh+F+ZO+Mocjw0vss8iXJCgl9wuVuniKVw=", "mexYG");
    llIlIlII[llllIIll['Ē']] = lIlIlIIIll("xfLU6idowN4scVIIOBw1WfQou0OA90bz", "Gpqyh");
    llIlIlII[llllIIll['ē']] = lIlIlIIIlI("5yW57G9BySpDBYxCTTAVT2l7WF2CH0l+E2uDLlV7unc=", "CLWhq");
    llIlIlII[llllIIll[55]] = lIlIlIIlII("DzgcDTkYJxgrADwLNwsgHCExCwcKISUIPRoLLAwyDTc3Mw==", "hTCnX");
    llIlIlII[llllIIll[58]] = lIlIlIIIlI("uXLxVgwqcDdrKrjWhb8ia3IwACiZl3sI4o7XIZwKMzE=", "dsWfA");
    llIlIlII[llllIIll['Ĕ']] = lIlIlIIlII("AiYOBCkVOQoiEDEVJQIwET8jAhcJJTU4KgwrIjo=", "eJQgH");
    llIlIlII[llllIIll['ĕ']] = lIlIlIIIll("rhouJS62+qgCmS7K0yXnPG7ton02BKzMV4UqLuEK83Q=", "hkfCD");
    llIlIlII[llllIIll['Ė']] = lIlIlIIlII("MAcyLiMnGDYIGgM0GygwIw4VEjE/CgkoMAo=", "WkmMB");
    llIlIlII[llllIIll['ė']] = lIlIlIIIlI("zpoo1IXcPbDE+sq8DaLWPww1oeAkvOX8SiKHbnF2KUY=", "fIgjK");
    llIlIlII[llllIIll['Ę']] = lIlIlIIIlI("Grpnde7CQ1fB6C5xFt7yTcxE4R/5TVgVUMbmj8XpTCc=", "DnNUv");
    llIlIlII[llllIIll['Ě']] = lIlIlIIIll("xPbVGgx16aFsgL6MW+eRTkK50QZ7IFRRQDG2NntXb0rFbU8KpPPJAQ==", "EENWT");
    llIlIlII[llllIIll['Ĝ']] = lIlIlIIIll("O2LpIZrb1D0a/J8xnweTsBlxvXJw08KRnA8CL2Af8z4=", "gBYWJ");
    llIlIlII[llllIIll['Ğ']] = lIlIlIIIlI("I25M+KcoLOJU5yexuuwUdZdHEqOvBZFqBRFftBO48QcQYUjnEmVxGF4CWLH1aYLT", "Ctlso");
    llIlIlII[llllIIll['Ġ']] = lIlIlIIlII("Hw0SOi0IEhY+ICcMLCETDAQ1LTkKBBIwIRkGKAY5Fgg5KhE=", "xaMYL");
    llIlIlII[llllIIll['Ģ']] = lIlIlIIIll("nds8wPo3brN/IvHK7JP8Kov+f27cMNgmqX3IHyQUKm5/1fU0NMw5Pg==", "MqxfY");
    llIlIlII[llllIIll['Ĥ']] = lIlIlIIlII("BgcLKRcZNCAhDhUeJiEpEgIuIQ==", "akTDv");
    llIlIlII[llllIIll['Ī']] = lIlIlIIIll("FBsbWlZYVUMajTC9p6b1aC/cz4C6rDiB", "fFHTJ");
    llIlIlII[llllIIll['ī']] = lIlIlIIIlI("1ObkDJi7xfc=", "bkBFA");
    llIlIlII[llllIIll['Ĭ']] = lIlIlIIlII("LCIDcBMHLBMpQRYiVyMVAz8DcBIWPxIxDAsjEHAYBzlW", "bMwPa");
    llIlIlII[llllIIll['ĭ']] = lIlIlIIIll("PkUrG+JygXYGBt/db6x01y697V5prIvH", "xyGHU");
    llIlIlII[llllIIll['Į']] = lIlIlIIIll("6Xon7lsJRYkQjhjcxYPJ1gGr1mfclY1U", "ZxLgU");
    llIlIlII[llllIIll['į']] = lIlIlIIIll("9fcO/dl+Ag+WDs3t6pLHzUSuRxUR2qsI", "NwZjM");
    llIlIlII[llllIIll['İ']] = lIlIlIIIll("TU9X7msapi0=", "iYpjT");
  }
  
  public void freeMemory()
  {
    try
    {
      ;
      ;
      memoryReserve = new byte[llllIIll[0]];
      renderGlobal.deleteAllDisplayLists();
      "".length();
      if (null != null) {
        return;
      }
    }
    catch (Throwable localThrowable)
    {
      try
      {
        System.gc();
        lIIlllIllIllllI.loadWorld(null);
        "".length();
        if (-" ".length() >= " ".length()) {
          return;
        }
      }
      catch (Throwable localThrowable1)
      {
        System.gc();
      }
    }
  }
  
  public ISaveFormat getSaveLoader()
  {
    ;
    return saveLoader;
  }
  
  public RenderItem getRenderItem()
  {
    ;
    return renderItem;
  }
  
  public void func_181537_a(boolean lIIllIIllIlllll)
  {
    ;
    ;
    field_181541_X = lIIllIIllIlllll;
  }
  
  public static boolean isAmbientOcclusionEnabled()
  {
    if ((llIIlIIIll(theMinecraft)) && (llIIlIIlII(theMinecraftgameSettings.ambientOcclusion))) {
      return llllIIll[1];
    }
    return llllIIll[0];
  }
  
  private void clickMouse()
  {
    ;
    ;
    if (llIIlIlIlI(leftClickCounter))
    {
      thePlayer.swingItem();
      if (llIIlIIIIl(objectMouseOver))
      {
        logger.error(llIlIlII[llllIIll[115]]);
        if (llIIlIIlII(playerController.isNotCreative()))
        {
          leftClickCounter = llllIIll[15];
          "".length();
          if (" ".length() <= "   ".length()) {}
        }
      }
      else
      {
        switch ($SWITCH_TABLE$net$minecraft$util$MovingObjectPosition$MovingObjectType()[objectMouseOver.typeOfHit.ordinal()])
        {
        case 3: 
          playerController.attackEntity(thePlayer, objectMouseOver.entityHit);
          "".length();
          if ((0x1C ^ 0x35 ^ 0xEE ^ 0xC3) > 0) {
            return;
          }
          return;
        case 2: 
          BlockPos lIIlllIIllIlllI = objectMouseOver.getBlockPos();
          if (llIIlIIllI(theWorld.getBlockState(lIIlllIIllIlllI).getBlock().getMaterial(), Material.air))
          {
            "".length();
            "".length();
            if ((0x42 ^ 0x28 ^ 0x48 ^ 0x26) != "   ".length()) {
              return;
            }
            return;
          }
          break;
        }
        if (llIIlIIlII(playerController.isNotCreative())) {
          leftClickCounter = llllIIll[15];
        }
      }
    }
  }
  
  public int getLimitFramerate()
  {
    ;
    if ((llIIlIIIIl(theWorld)) && (llIIlIIIll(currentScreen)))
    {
      "".length();
      if (-" ".length() < 0) {
        break label66;
      }
      return (0xB4 ^ 0xB1) & (0x3D ^ 0x38 ^ 0xFFFFFFFF);
    }
    label66:
    return gameSettings.limitFramerate;
  }
  
  public boolean func_181540_al()
  {
    ;
    return field_181541_X;
  }
  
  public IntegratedServer getIntegratedServer()
  {
    ;
    return theIntegratedServer;
  }
  
  public void loadWorld(WorldClient lIIlllIIIIIIIlI)
  {
    ;
    ;
    lIIlllIIIIIIlIl.loadWorld(lIIlllIIIIIIIlI, llIlIlII[llllIIll['']]);
  }
  
  private void sendClickBlockToController(boolean lIIlllIIlllIIll)
  {
    ;
    ;
    ;
    if (llIIlIIlIl(lIIlllIIlllIIll)) {
      leftClickCounter = llllIIll[0];
    }
    if ((llIIlIlIlI(leftClickCounter)) && (llIIlIIlIl(thePlayer.isUsingItem()))) {
      if ((llIIlIIlII(lIIlllIIlllIIll)) && (llIIlIIIll(objectMouseOver)) && (llIIlIIIII(objectMouseOver.typeOfHit, MovingObjectPosition.MovingObjectType.BLOCK)))
      {
        BlockPos lIIlllIIlllIlIl = objectMouseOver.getBlockPos();
        if ((llIIlIIllI(theWorld.getBlockState(lIIlllIIlllIlIl).getBlock().getMaterial(), Material.air)) && (llIIlIIlII(playerController.onPlayerDamageBlock(lIIlllIIlllIlIl, objectMouseOver.sideHit))))
        {
          effectRenderer.addBlockHitEffects(lIIlllIIlllIlIl, objectMouseOver.sideHit);
          thePlayer.swingItem();
          "".length();
          if ("  ".length() >= 0) {}
        }
      }
      else
      {
        playerController.resetBlockRemoving();
      }
    }
  }
  
  private void setWindowIcon()
  {
    ;
    ;
    ;
    ;
    ;
    Util.EnumOS lIIllllllllIlIl = Util.getOSType();
    if (llIIlIIllI(lIIllllllllIlIl, Util.EnumOS.OSX))
    {
      InputStream lIIllllllllIlII = null;
      InputStream lIIllllllllIIll = null;
      try
      {
        lIIllllllllIlII = mcDefaultResourcePack.getInputStreamAssets(new ResourceLocation(llIlIlII[llllIIll[37]]));
        lIIllllllllIIll = mcDefaultResourcePack.getInputStreamAssets(new ResourceLocation(llIlIlII[llllIIll[38]]));
        if ((llIIlIIIll(lIIllllllllIlII)) && (llIIlIIIll(lIIllllllllIIll)))
        {
          "".length();
          "".length();
          if ("   ".length() > (0x66 ^ 0x2 ^ 0xA3 ^ 0xC3)) {
            return;
          }
        }
      }
      catch (IOException lIIllllllllIIlI)
      {
        lIIllllllllIIlI = lIIllllllllIIlI;
        logger.error(llIlIlII[llllIIll[39]], lIIllllllllIIlI);
        IOUtils.closeQuietly(lIIllllllllIlII);
        IOUtils.closeQuietly(lIIllllllllIIll);
        "".length();
        if ((0x83 ^ 0x86) != 0) {
          return;
        }
        return;
      }
      finally
      {
        lIIlllllllIllII = finally;
        IOUtils.closeQuietly(lIIllllllllIlII);
        IOUtils.closeQuietly(lIIllllllllIIll);
        throw lIIlllllllIllII;
      }
      IOUtils.closeQuietly(lIIllllllllIlII);
      IOUtils.closeQuietly(lIIllllllllIIll);
    }
  }
  
  public BlockRendererDispatcher getBlockRendererDispatcher()
  {
    ;
    return blockRenderDispatcher;
  }
  
  private static boolean llIIlIllIl(int ???, int arg1)
  {
    int i;
    char lIIllIIIllllIIl;
    return ??? != i;
  }
  
  public void setServerData(ServerData lIIllIlIllIIllI)
  {
    ;
    ;
    currentServerData = lIIllIlIllIIllI;
  }
  
  public boolean isJava64bit()
  {
    ;
    return jvm64bit;
  }
  
  public ServerData getCurrentServerData()
  {
    ;
    return currentServerData;
  }
  
  public Session getSession()
  {
    ;
    return session;
  }
  
  private void updateDisplayMode()
    throws LWJGLException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Set<DisplayMode> lIIlllllIIlIIlI = Sets.newHashSet();
    "".length();
    DisplayMode lIIlllllIIlIIIl = Display.getDesktopDisplayMode();
    if ((llIIlIIlIl(lIIlllllIIlIIlI.contains(lIIlllllIIlIIIl))) && (llIIlIIIII(Util.getOSType(), Util.EnumOS.OSX)))
    {
      lIIlllllIIIIlll = macDisplayModes.iterator();
      "".length();
      if ((0xB6 ^ 0xB2) <= "  ".length()) {
        return;
      }
      while (!llIIlIIlIl(lIIlllllIIIIlll.hasNext()))
      {
        DisplayMode lIIlllllIIlIIII = (DisplayMode)lIIlllllIIIIlll.next();
        boolean lIIlllllIIIllll = llllIIll[1];
        lIIlllllIIIIlII = lIIlllllIIlIIlI.iterator();
        "".length();
        if ("  ".length() <= ((0x23 ^ 0x2F ^ 0x6A ^ 0x4F) & (64 + 11 - -6 + 52 ^ 107 + 97 - 54 + 22 ^ -" ".length()))) {
          return;
        }
        while (!llIIlIIlIl(lIIlllllIIIIlII.hasNext()))
        {
          DisplayMode lIIlllllIIIlllI = (DisplayMode)lIIlllllIIIIlII.next();
          if ((llIIlIlIII(lIIlllllIIIlllI.getBitsPerPixel(), llllIIll[43])) && (llIIlIlIII(lIIlllllIIIlllI.getWidth(), lIIlllllIIlIIII.getWidth())) && (llIIlIlIII(lIIlllllIIIlllI.getHeight(), lIIlllllIIlIIII.getHeight())))
          {
            lIIlllllIIIllll = llllIIll[0];
            "".length();
            if ((0x37 ^ 0x3D ^ 0x84 ^ 0x8A) >= "  ".length()) {
              break;
            }
            return;
          }
        }
        if (llIIlIIlIl(lIIlllllIIIllll))
        {
          Iterator lIIlllllIIIllIl = lIIlllllIIlIIlI.iterator();
          DisplayMode lIIlllllIIIllII;
          do
          {
            if (llIIlIIlIl(lIIlllllIIIllIl.hasNext()))
            {
              "".length();
              if ((19 + 21 - 0 + 120 ^ '' + '' - 141 + 31) > 0) {
                break;
              }
              return;
            }
            lIIlllllIIIllII = (DisplayMode)lIIlllllIIIllIl.next();
          } while ((!llIIlIlIII(lIIlllllIIIllII.getBitsPerPixel(), llllIIll[43])) || (!llIIlIlIII(lIIlllllIIIllII.getWidth(), lIIlllllIIlIIII.getWidth() / llllIIll[3])) || (!llIIlIlIII(lIIlllllIIIllII.getHeight(), lIIlllllIIlIIII.getHeight() / llllIIll[3])));
          lIIlllllIIlIIIl = lIIlllllIIIllII;
        }
      }
    }
    Display.setDisplayMode(lIIlllllIIlIIIl);
    displayWidth = lIIlllllIIlIIIl.getWidth();
    displayHeight = lIIlllllIIlIIIl.getHeight();
  }
  
  public Framebuffer getFramebuffer()
  {
    ;
    return framebufferMc;
  }
  
  public FrameTimer func_181539_aj()
  {
    ;
    return field_181542_y;
  }
  
  private static boolean llIIlIIlll(int ???, int arg1)
  {
    int i;
    long lIIllIIlIIlllIl;
    return ??? >= i;
  }
  
  private static boolean llIIlIIIIl(Object ???)
  {
    long lIIllIIlIIIlIIl;
    return ??? == null;
  }
  
  public void crashed(CrashReport lIIllllllIIlIll)
  {
    ;
    ;
    hasCrashed = llllIIll[1];
    crashReporter = lIIllllllIIlIll;
  }
  
  public static int getDebugFPS()
  {
    return debugFPS;
  }
  
  public LanguageManager getLanguageManager()
  {
    ;
    return mcLanguageManager;
  }
  
  public boolean isSnooperEnabled()
  {
    ;
    return gameSettings.snooperEnabled;
  }
  
  private static int llIIllIIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private String func_181538_aA()
  {
    ;
    if (llIIlIIIll(theIntegratedServer))
    {
      if (llIIlIIlII(theIntegratedServer.getPublic()))
      {
        "".length();
        if (" ".length() >= "  ".length()) {
          return null;
        }
      }
      else
      {
        "".length();
        if ("   ".length() < 0) {
          return null;
        }
      }
    }
    else if (llIIlIIIll(currentServerData))
    {
      if (llIIlIIlII(currentServerData.func_181041_d()))
      {
        "".length();
        if (" ".length() != ((0x6D ^ 0x5C ^ 0x32 ^ 0x5F) & (0x5F ^ 0x28 ^ 0x81 ^ 0xAA ^ -" ".length()))) {
          break label219;
        }
        return null;
      }
      "".length();
      if ((0x6D ^ 0xD ^ 0xC9 ^ 0xAD) >= 0) {
        break label219;
      }
      return null;
    }
    label219:
    return llIlIlII[llllIIll['¹']];
  }
  
  private static int llIIlIlIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  static
  {
    llIIIlllll();
    llIIIIlllI();
    logger = LogManager.getLogger();
    locationMojangPng = new ResourceLocation(llIlIlII[llllIIll[0]]);
    if (llIIlIIIII(Util.getOSType(), Util.EnumOS.OSX))
    {
      "".length();
      if ((('Ò' + '»' - 163 + 11 ^ 78 + '¢' - 230 + 173) & (0xDD ^ 0x9A ^ 0x65 ^ 0x60 ^ -" ".length())) >= 0) {
        break label115;
      }
    }
    label115:
    isRunningOnMac = llllIIll[0];
  }
  
  public void shutdownMinecraftApplet()
  {
    try
    {
      ;
      ;
      stream.shutdownStream();
      logger.info(llIlIlII[llllIIll[62]]);
      try
      {
        lIIllllIIIIIlll.loadWorld(null);
        "".length();
        if (((0xE3 ^ 0x84 ^ 0x67 ^ 0x8) & ('' + 43 - 104 + 84 ^ 71 + 17 - 39 + 100 ^ -" ".length())) <= -" ".length()) {
          return;
        }
      }
      catch (Throwable localThrowable)
      {
        mcSoundHandler.unloadSounds();
        "".length();
        if (((0xC0 ^ 0x8D) & (0x63 ^ 0x2E ^ 0xFFFFFFFF)) == 0) {
          break label154;
        }
      }
      return;
    }
    finally
    {
      Display.destroy();
      if (llIIlIIlIl(hasCrashed)) {
        System.exit(llllIIll[0]);
      }
    }
    label154:
    Display.destroy();
    if (llIIlIIlIl(hasCrashed)) {
      System.exit(llllIIll[0]);
    }
    System.gc();
  }
}

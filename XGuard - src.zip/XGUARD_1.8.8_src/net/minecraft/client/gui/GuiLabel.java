package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;

public class GuiLabel
  extends Gui
{
  private static void lllIIIIIIllIIl()
  {
    lIIlIIllIIlIl = new int[9];
    lIIlIIllIIlIl[0] = (126 + 45 - 32 + 19 + (0x0 ^ 0x47) - (33 + 117 - 93 + 135) + (50 + '' - 54 + 36));
    lIIlIIllIIlIl[1] = (0x5F ^ 0x4B);
    lIIlIIllIIlIl[2] = " ".length();
    lIIlIIllIIlIl[3] = ((0x56 ^ 0x36) & (0xE7 ^ 0x87 ^ 0xFFFFFFFF));
    lIIlIIllIIlIl[4] = (-" ".length());
    lIIlIIllIIlIl[5] = (0xFB26 & 0x7DB);
    lIIlIIllIIlIl[6] = (-(0xF8E7 & 0x4FDD) & 0xEFF7 & 0x5BCF);
    lIIlIIllIIlIl[7] = "  ".length();
    lIIlIIllIIlIl[8] = (0xCA ^ 0xC0);
  }
  
  public GuiLabel setCentered()
  {
    ;
    centered = lIIlIIllIIlIl[2];
    return llllllllllllllIlIIIIlIIIIIIIIlII;
  }
  
  public void func_175202_a(String llllllllllllllIlIIIIlIIIIIIIIllI)
  {
    ;
    ;
    "".length();
  }
  
  private static boolean lllIIIIIIllIlI(int ???)
  {
    String llllllllllllllIlIIIIIlllllIlIllI;
    return ??? != 0;
  }
  
  private static boolean lllIIIIIIlllII(int ???, int arg1)
  {
    int i;
    int llllllllllllllIlIIIIIlllllIllIII;
    return ??? >= i;
  }
  
  public GuiLabel(FontRenderer llllllllllllllIlIIIIlIIIIIIllIlI, int llllllllllllllIlIIIIlIIIIIIllIIl, int llllllllllllllIlIIIIlIIIIIIllIII, int llllllllllllllIlIIIIlIIIIIIIllll, int llllllllllllllIlIIIIlIIIIIIlIllI, int llllllllllllllIlIIIIlIIIIIIIllIl, int llllllllllllllIlIIIIlIIIIIIlIlII)
  {
    fontRenderer = llllllllllllllIlIIIIlIIIIIIllIlI;
    field_175204_i = llllllllllllllIlIIIIlIIIIIIllIIl;
    field_146162_g = llllllllllllllIlIIIIlIIIIIIllIII;
    field_146174_h = llllllllllllllIlIIIIlIIIIIIIllll;
    field_146167_a = llllllllllllllIlIIIIlIIIIIIlIllI;
    field_146161_f = llllllllllllllIlIIIIlIIIIIIIllIl;
    field_146173_k = Lists.newArrayList();
    centered = lIIlIIllIIlIl[3];
    labelBgEnabled = lIIlIIllIIlIl[3];
    field_146168_n = llllllllllllllIlIIIIlIIIIIIlIlII;
    field_146169_o = lIIlIIllIIlIl[4];
    field_146166_p = lIIlIIllIIlIl[4];
    field_146165_q = lIIlIIllIIlIl[4];
    field_146163_s = lIIlIIllIIlIl[3];
  }
  
  static {}
  
  public void drawLabel(Minecraft llllllllllllllIlIIIIIllllllllIlI, int llllllllllllllIlIIIIIllllllllIIl, int llllllllllllllIlIIIIIllllllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIIIIIllIlI(visible))
    {
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(lIIlIIllIIlIl[5], lIIlIIllIIlIl[6], lIIlIIllIIlIl[2], lIIlIIllIIlIl[3]);
      llllllllllllllIlIIIIIlllllllIlII.drawLabelBackground(llllllllllllllIlIIIIIllllllllIlI, llllllllllllllIlIIIIIllllllllIIl, llllllllllllllIlIIIIIllllllllIII);
      int llllllllllllllIlIIIIIlllllllIlll = field_146174_h + field_146161_f / lIIlIIllIIlIl[7] + field_146163_s / lIIlIIllIIlIl[7];
      int llllllllllllllIlIIIIIlllllllIllI = llllllllllllllIlIIIIIlllllllIlll - field_146173_k.size() * lIIlIIllIIlIl[8] / lIIlIIllIIlIl[7];
      int llllllllllllllIlIIIIIlllllllIlIl = lIIlIIllIIlIl[3];
      "".length();
      if ("   ".length() != "   ".length()) {
        return;
      }
      while (!lllIIIIIIlllII(llllllllllllllIlIIIIIlllllllIlIl, field_146173_k.size()))
      {
        if (lllIIIIIIllIlI(centered))
        {
          llllllllllllllIlIIIIIlllllllIlII.drawCenteredString(fontRenderer, (String)field_146173_k.get(llllllllllllllIlIIIIIlllllllIlIl), field_146162_g + field_146167_a / lIIlIIllIIlIl[7], llllllllllllllIlIIIIIlllllllIllI + llllllllllllllIlIIIIIlllllllIlIl * lIIlIIllIIlIl[8], field_146168_n);
          "".length();
          if (" ".length() > -" ".length()) {}
        }
        else
        {
          llllllllllllllIlIIIIIlllllllIlII.drawString(fontRenderer, (String)field_146173_k.get(llllllllllllllIlIIIIIlllllllIlIl), field_146162_g, llllllllllllllIlIIIIIlllllllIllI + llllllllllllllIlIIIIIlllllllIlIl * lIIlIIllIIlIl[8], field_146168_n);
        }
        llllllllllllllIlIIIIIlllllllIlIl++;
      }
    }
  }
  
  protected void drawLabelBackground(Minecraft llllllllllllllIlIIIIIllllllIIlll, int llllllllllllllIlIIIIIllllllIIllI, int llllllllllllllIlIIIIIllllllIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIIIIIIllIlI(labelBgEnabled))
    {
      int llllllllllllllIlIIIIIllllllIIlII = field_146167_a + field_146163_s * lIIlIIllIIlIl[7];
      int llllllllllllllIlIIIIIllllllIIIll = field_146161_f + field_146163_s * lIIlIIllIIlIl[7];
      int llllllllllllllIlIIIIIllllllIIIlI = field_146162_g - field_146163_s;
      int llllllllllllllIlIIIIIllllllIIIIl = field_146174_h - field_146163_s;
      drawRect(llllllllllllllIlIIIIIllllllIIIlI, llllllllllllllIlIIIIIllllllIIIIl, llllllllllllllIlIIIIIllllllIIIlI + llllllllllllllIlIIIIIllllllIIlII, llllllllllllllIlIIIIIllllllIIIIl + llllllllllllllIlIIIIIllllllIIIll, field_146169_o);
      llllllllllllllIlIIIIIllllllIIIII.drawHorizontalLine(llllllllllllllIlIIIIIllllllIIIlI, llllllllllllllIlIIIIIllllllIIIlI + llllllllllllllIlIIIIIllllllIIlII, llllllllllllllIlIIIIIllllllIIIIl, field_146166_p);
      llllllllllllllIlIIIIIllllllIIIII.drawHorizontalLine(llllllllllllllIlIIIIIllllllIIIlI, llllllllllllllIlIIIIIllllllIIIlI + llllllllllllllIlIIIIIllllllIIlII, llllllllllllllIlIIIIIllllllIIIIl + llllllllllllllIlIIIIIllllllIIIll, field_146165_q);
      llllllllllllllIlIIIIIllllllIIIII.drawVerticalLine(llllllllllllllIlIIIIIllllllIIIlI, llllllllllllllIlIIIIIllllllIIIIl, llllllllllllllIlIIIIIllllllIIIIl + llllllllllllllIlIIIIIllllllIIIll, field_146166_p);
      llllllllllllllIlIIIIIllllllIIIII.drawVerticalLine(llllllllllllllIlIIIIIllllllIIIlI + llllllllllllllIlIIIIIllllllIIlII, llllllllllllllIlIIIIIllllllIIIIl, llllllllllllllIlIIIIIllllllIIIIl + llllllllllllllIlIIIIIllllllIIIll, field_146165_q);
    }
  }
}

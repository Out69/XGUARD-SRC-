package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundCategory;
import net.minecraft.client.audio.SoundEventAccessorComposite;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.stream.GuiStreamOptions;
import net.minecraft.client.gui.stream.GuiStreamUnavailable;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.GameSettings.Options;
import net.minecraft.client.stream.IStream;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.storage.WorldInfo;
import pl.xguard.gui.GuiClientOptions;

public class GuiOptions
  extends GuiScreen
  implements GuiYesNoCallback
{
  protected void actionPerformed(GuiButton lIlIlIlllIIIII)
    throws IOException
  {
    ;
    ;
    ;
    if (lIllIIllIIl(enabled))
    {
      if ((lIllIIllllI(id, llIllIllI[23])) && (lIllIIllIIl(lIlIlIlllIIIII instanceof GuiOptionButton)))
      {
        GameSettings.Options lIlIlIlllIIlII = ((GuiOptionButton)lIlIlIlllIIIII).returnEnumOptions();
        game_settings_1.setOptionValue(lIlIlIlllIIlII, llIllIllI[0]);
        displayString = game_settings_1.getKeyBinding(GameSettings.Options.getEnumOptions(id));
      }
      if (lIllIIlllIl(id, llIllIllI[8]))
      {
        mc.theWorld.getWorldInfo().setDifficulty(EnumDifficulty.getDifficultyEnum(mc.theWorld.getDifficulty().getDifficultyId() + llIllIllI[0]));
        field_175357_i.displayString = lIlIlIlllIIlll.func_175355_a(mc.theWorld.getDifficulty());
      }
      if (lIllIIlllIl(id, llIllIllI[11])) {
        mc.displayGuiScreen(new GuiYesNo(lIlIlIlllIIlll, new ChatComponentTranslation(llIIlIlIl[llIllIllI[44]], new Object[llIllIllI[1]]).getFormattedText(), new ChatComponentTranslation(llIIlIlIl[llIllIllI[45]], new Object[] { new ChatComponentTranslation(mc.theWorld.getWorldInfo().getDifficulty().getDifficultyResourceKey(), new Object[llIllIllI[1]]) }).getFormattedText(), llIllIllI[11]));
      }
      if (lIllIIlllIl(id, llIllIllI[12]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(new GuiCustomizeSkin(lIlIlIlllIIlll));
      }
      if (lIllIIlllIl(id, llIllIllI[14])) {
        mc.entityRenderer.activateNextShader();
      }
      if (lIllIIlllIl(id, llIllIllI[21]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(new GuiVideoSettings(lIlIlIlllIIlll, game_settings_1));
      }
      if (lIllIIlllIl(id, llIllIllI[23]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(new GuiControls(lIlIlIlllIIlll, game_settings_1));
      }
      if (lIllIIlllIl(id, llIllIllI[25]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(new GuiLanguage(lIlIlIlllIIlll, game_settings_1, mc.getLanguageManager()));
      }
      if (lIllIIlllIl(id, llIllIllI[28]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(new ScreenChatOptions(lIlIlIlllIIlll, game_settings_1));
      }
      if (lIllIIlllIl(id, llIllIllI[33]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(new GuiSnooper(lIlIlIlllIIlll, game_settings_1));
      }
      if (lIllIIlllIl(id, llIllIllI[35]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(field_146441_g);
      }
      if (lIllIIlllIl(id, llIllIllI[30]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(new GuiScreenResourcePacks(lIlIlIlllIIlll));
      }
      if (lIllIIlllIl(id, llIllIllI[17]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(new GuiScreenOptionsSounds(lIlIlIlllIIlll, game_settings_1));
      }
      if (lIllIIlllIl(id, llIllIllI[20]))
      {
        mc.gameSettings.saveOptions();
        IStream lIlIlIlllIIIll = mc.getTwitchStream();
        if ((lIllIIllIIl(lIlIlIlllIIIll.func_152936_l())) && (lIllIIllIIl(lIlIlIlllIIIll.func_152928_D())))
        {
          mc.displayGuiScreen(new GuiStreamOptions(lIlIlIlllIIlll, game_settings_1));
          "".length();
          if ("   ".length() == "   ".length()) {}
        }
        else
        {
          GuiStreamUnavailable.func_152321_a(lIlIlIlllIIlll);
        }
      }
      if (lIllIIlllIl(id, llIllIllI[37])) {
        mc.displayGuiScreen(new GuiClientOptions(lIlIlIlllIIlll));
      }
    }
  }
  
  private static boolean lIllIIlllIl(int ???, int arg1)
  {
    int i;
    boolean lIlIlIIllIllII;
    return ??? == i;
  }
  
  private static void lIllIIllIII()
  {
    llIllIllI = new int[48];
    llIllIllI[0] = " ".length();
    llIllIllI[1] = ((0x4E ^ 0x1D) & (0xF ^ 0x5C ^ 0xFFFFFFFF));
    llIllIllI[2] = "  ".length();
    llIllIllI[3] = (125 + 91 - 120 + 59);
    llIllIllI[4] = ((0x4E ^ 0x36) + (83 + 78 - 159 + 134) - (0xFB ^ 0x93) + (0x10 ^ 0x18));
    llIllIllI[5] = (0x80 ^ 0x9D ^ 0x46 ^ 0x5D);
    llIllIllI[6] = (0x2 ^ 0xF ^ " ".length());
    llIllIllI[7] = (0x49 ^ 0x51);
    llIllIllI[8] = (0x8A ^ 0xA0 ^ 0x3A ^ 0x7C);
    llIllIllI[9] = (54 + 106 - 124 + 114);
    llIllIllI[10] = (0x9A ^ 0x8E);
    llIllIllI[11] = ('' + 'ê' - 326 + 199 ^ 9 + 1 - -40 + 107);
    llIllIllI[12] = (0xC4 ^ 0xAA);
    llIllIllI[13] = (0xB5 ^ 0xC4 ^ 0xCE ^ 0x8F);
    llIllIllI[14] = (-(0xA713 & 0x78FF) & 0xFFFFFFFF & 0x847FFF);
    llIllIllI[15] = (0xC4 ^ 0xC1);
    llIllIllI[16] = "   ".length();
    llIllIllI[17] = (0x32 ^ 0x58);
    llIllIllI[18] = (0x59 ^ 0x7B ^ 0x28 ^ 0x42);
    llIllIllI[19] = (0xE ^ 0x5C ^ 0x47 ^ 0x11);
    llIllIllI[20] = ('ò' + '' - 317 + 189 ^ 23 + 24 - 29 + 139);
    llIllIllI[21] = (0xFD ^ 0x98);
    llIllIllI[22] = (0x4F ^ 0x2F);
    llIllIllI[23] = (106 + '' - 97 + 53 ^ 60 + '¢' - 69 + 16);
    llIllIllI[24] = (0xA3 ^ 0xA4);
    llIllIllI[25] = (0x5A ^ 0x3C);
    llIllIllI[26] = (0x2D ^ 0x55);
    llIllIllI[27] = (0xB0 ^ 0xB8);
    llIllIllI[28] = (0x1F ^ 0x78);
    llIllIllI[29] = (0xB5 ^ 0xBC);
    llIllIllI[30] = (0xA9 ^ 0xC1 ^ " ".length());
    llIllIllI[31] = ((0x4A ^ 0x1B) + (0x9A ^ 0xAB) - (0x85 ^ 0xBE) + (0x51 ^ 0x18));
    llIllIllI[32] = (0x11 ^ 0x31 ^ 0xEE ^ 0xC4);
    llIllIllI[33] = (0x5A ^ 0x33 ^ " ".length());
    llIllIllI[34] = (0x5F ^ 0x54);
    llIllIllI[35] = ((0xB2 ^ 0xA3) + (31 + 46 - 52 + 135) - (0xEC ^ 0xC3) + (0xFF ^ 0xB9));
    llIllIllI[36] = (64 + 38 - 7 + 46 + (32 + 28 - 0 + 89) - (84 + 5 - 48 + 213) + (74 + 85 - 150 + 123));
    llIllIllI[37] = ('' + 49 - 80 + 93);
    llIllIllI[38] = (0xDA ^ 0x91);
    llIllIllI[39] = (66 + 106 - 21 + 24 ^ 105 + 2 - 105 + 183);
    llIllIllI[40] = (" ".length() ^ 0x6B ^ 0x67);
    llIllIllI[41] = (0x3F ^ 0x31);
    llIllIllI[42] = (0x99 ^ 0x96);
    llIllIllI[43] = (0xB ^ 0x1B);
    llIllIllI[44] = (0x5A ^ 0x4B);
    llIllIllI[45] = (0x7E ^ 0x6C);
    llIllIllI[46] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    llIllIllI[47] = (114 + 110 - 100 + 22 ^ 108 + 121 - 112 + 12);
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    ;
    int lIlIllIIIIlllI = llIllIllI[1];
    field_146442_a = I18n.format(llIIlIlIl[llIllIllI[0]], new Object[llIllIllI[1]]);
    boolean lIlIllIIIIIllI = (lIlIllIIIIIlIl = field_146440_f).length;
    char lIlIllIIIIIlll = llIllIllI[1];
    "".length();
    if ("   ".length() <= "  ".length()) {
      return;
    }
    while (!lIllIIllIlI(lIlIllIIIIIlll, lIlIllIIIIIllI))
    {
      GameSettings.Options lIlIllIIIIllIl = lIlIllIIIIIlIl[lIlIllIIIIIlll];
      if (lIllIIllIIl(lIlIllIIIIllIl.getEnumFloat()))
      {
        new GuiOptionSlider(lIlIllIIIIllIl.returnEnumOrdinal(), width / llIllIllI[2] - llIllIllI[3] + lIlIllIIIIlllI % llIllIllI[2] * llIllIllI[4], height / llIllIllI[5] - llIllIllI[6] + llIllIllI[7] * (lIlIllIIIIlllI >> llIllIllI[0]), lIlIllIIIIllIl);
        "".length();
        "".length();
        if (null == null) {}
      }
      else
      {
        GuiOptionButton lIlIllIIIIllII = new GuiOptionButton(lIlIllIIIIllIl.returnEnumOrdinal(), width / llIllIllI[2] - llIllIllI[3] + lIlIllIIIIlllI % llIllIllI[2] * llIllIllI[4], height / llIllIllI[5] - llIllIllI[6] + llIllIllI[7] * (lIlIllIIIIlllI >> llIllIllI[0]), lIlIllIIIIllIl, game_settings_1.getKeyBinding(lIlIllIIIIllIl));
        "".length();
      }
      lIlIllIIIIlllI++;
    }
    if (lIllIIllIll(mc.theWorld))
    {
      EnumDifficulty lIlIllIIIIlIll = mc.theWorld.getDifficulty();
      field_175357_i = new GuiButton(llIllIllI[8], width / llIllIllI[2] - llIllIllI[3] + lIlIllIIIIlllI % llIllIllI[2] * llIllIllI[4], height / llIllIllI[5] - llIllIllI[6] + llIllIllI[7] * (lIlIllIIIIlllI >> llIllIllI[0]), llIllIllI[9], llIllIllI[10], lIlIllIIIIllll.func_175355_a(lIlIllIIIIlIll));
      "".length();
      if ((lIllIIllIIl(mc.isSingleplayer())) && (lIllIIlllII(mc.theWorld.getWorldInfo().isHardcoreModeEnabled())))
      {
        field_175357_i.setWidth(field_175357_i.getButtonWidth() - llIllIllI[10]);
        field_175356_r = new GuiLockIconButton(llIllIllI[11], field_175357_i.xPosition + field_175357_i.getButtonWidth(), field_175357_i.yPosition);
        "".length();
        field_175356_r.func_175229_b(mc.theWorld.getWorldInfo().isDifficultyLocked());
        if (lIllIIllIIl(field_175356_r.func_175230_c()))
        {
          "".length();
          if (" ".length() < "  ".length()) {
            break label613;
          }
        }
        label613:
        llIllIllI1enabled = llIllIllI[0];
        if (lIllIIllIIl(field_175356_r.func_175230_c()))
        {
          "".length();
          if ("   ".length() > 0) {
            break label658;
          }
        }
        label658:
        llIllIllI1enabled = llIllIllI[0];
        "".length();
        if ("  ".length() > 0) {}
      }
      else
      {
        field_175357_i.enabled = llIllIllI[1];
      }
    }
    new GuiButton(llIllIllI[12], width / llIllIllI[2] - llIllIllI[3], height / llIllIllI[5] + llIllIllI[13] - llIllIllI[5], llIllIllI[9], llIllIllI[10], I18n.format(llIIlIlIl[llIllIllI[2]], new Object[llIllIllI[1]]));
    "".length();
    new GuiButton(llIllIllI[14], width / llIllIllI[2] + llIllIllI[15], height / llIllIllI[5] + llIllIllI[13] - llIllIllI[5], llIllIllI[9], llIllIllI[10], llIIlIlIl[llIllIllI[16]]);
    {
      public void playPressSound(SoundHandler lllllllllllllllllIlIllllllIlllII)
      {
        ;
        ;
        SoundEventAccessorComposite lllllllllllllllllIlIllllllIllIll = lllllllllllllllllIlIllllllIlllII.getRandomSoundFromCategories(new SoundCategory[] { SoundCategory.ANIMALS, SoundCategory.BLOCKS, SoundCategory.MOBS, SoundCategory.PLAYERS, SoundCategory.WEATHER });
        if (llIllIllIIIl(lllllllllllllllllIlIllllllIllIll)) {
          lllllllllllllllllIlIllllllIllIlI.playSound(PositionedSoundRecord.create(lllllllllllllllllIlIllllllIllIll.getSoundEventLocation(), 0.5F));
        }
      }
      
      private static boolean llIllIllIIIl(Object ???)
      {
        short lllllllllllllllllIlIllllllIlIlll;
        return ??? != null;
      }
      
      private static void llIllIllIIII()
      {
        lIIIIlllIll = new int[6];
        lIIIIlllIll[0] = (0x3E ^ 0x3B);
        lIIIIlllIll[1] = ((0xCC ^ 0x99) & (0xC5 ^ 0x90 ^ 0xFFFFFFFF));
        lIIIIlllIll[2] = " ".length();
        lIIIIlllIll[3] = "  ".length();
        lIIIIlllIll[4] = "   ".length();
        lIIIIlllIll[5] = (0x8E ^ 0x8A);
      }
      
      static {}
    };
    "".length();
    new GuiButton(llIllIllI[17], width / llIllIllI[2] - llIllIllI[3], height / llIllIllI[5] + llIllIllI[18] - llIllIllI[5], llIllIllI[9], llIllIllI[10], I18n.format(llIIlIlIl[llIllIllI[19]], new Object[llIllIllI[1]]));
    "".length();
    new GuiButton(llIllIllI[20], width / llIllIllI[2] + llIllIllI[15], height / llIllIllI[5] + llIllIllI[18] - llIllIllI[5], llIllIllI[9], llIllIllI[10], I18n.format(llIIlIlIl[llIllIllI[15]], new Object[llIllIllI[1]]));
    "".length();
    new GuiButton(llIllIllI[21], width / llIllIllI[2] - llIllIllI[3], height / llIllIllI[5] + llIllIllI[22] - llIllIllI[5], llIllIllI[9], llIllIllI[10], I18n.format(llIIlIlIl[llIllIllI[5]], new Object[llIllIllI[1]]));
    "".length();
    new GuiButton(llIllIllI[23], width / llIllIllI[2] + llIllIllI[15], height / llIllIllI[5] + llIllIllI[22] - llIllIllI[5], llIllIllI[9], llIllIllI[10], I18n.format(llIIlIlIl[llIllIllI[24]], new Object[llIllIllI[1]]));
    "".length();
    new GuiButton(llIllIllI[25], width / llIllIllI[2] - llIllIllI[3], height / llIllIllI[5] + llIllIllI[26] - llIllIllI[5], llIllIllI[9], llIllIllI[10], I18n.format(llIIlIlIl[llIllIllI[27]], new Object[llIllIllI[1]]));
    "".length();
    new GuiButton(llIllIllI[28], width / llIllIllI[2] + llIllIllI[15], height / llIllIllI[5] + llIllIllI[26] - llIllIllI[5], llIllIllI[9], llIllIllI[10], I18n.format(llIIlIlIl[llIllIllI[29]], new Object[llIllIllI[1]]));
    "".length();
    new GuiButton(llIllIllI[30], width / llIllIllI[2] - llIllIllI[3], height / llIllIllI[5] + llIllIllI[31] - llIllIllI[5], llIllIllI[9], llIllIllI[10], I18n.format(llIIlIlIl[llIllIllI[32]], new Object[llIllIllI[1]]));
    "".length();
    new GuiButton(llIllIllI[33], width / llIllIllI[2] + llIllIllI[15], height / llIllIllI[5] + llIllIllI[31] - llIllIllI[5], llIllIllI[9], llIllIllI[10], I18n.format(llIIlIlIl[llIllIllI[34]], new Object[llIllIllI[1]]));
    "".length();
    new GuiButton(llIllIllI[35], width / llIllIllI[2] - llIllIllI[23], height / llIllIllI[5] + llIllIllI[36], I18n.format(llIIlIlIl[llIllIllI[6]], new Object[llIllIllI[1]]));
    "".length();
    new GuiButton(llIllIllI[37], width / llIllIllI[2] - llIllIllI[38], height / llIllIllI[5] + llIllIllI[39] - llIllIllI[5], llIllIllI[9], llIllIllI[10], I18n.format(llIIlIlIl[llIllIllI[40]], new Object[llIllIllI[1]]));
    "".length();
  }
  
  private static boolean lIllIIllIlI(int ???, int arg1)
  {
    int i;
    float lIlIlIIllIlIII;
    return ??? >= i;
  }
  
  public void drawScreen(int lIlIlIllIIlIll, int lIlIlIllIIIlIl, float lIlIlIllIIlIII)
  {
    ;
    ;
    ;
    ;
    lIlIlIllIIIlll.drawDefaultBackground();
    lIlIlIllIIIlll.drawCenteredString(fontRendererObj, field_146442_a, width / llIllIllI[2], llIllIllI[42], llIllIllI[46]);
    lIlIlIllIIIlll.drawScreen(lIlIlIllIIlIll, lIlIlIllIIIlIl, lIlIlIllIIlIII);
  }
  
  private static boolean lIllIIllIIl(int ???)
  {
    float lIlIlIIllIIIII;
    return ??? != 0;
  }
  
  private static boolean lIllIIllllI(int ???, int arg1)
  {
    int i;
    long lIlIlIIllIIlII;
    return ??? < i;
  }
  
  private static String lIllIIIIlll(String lIlIlIIllllIII, String lIlIlIIlllllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIlIlIIllllIII = new String(Base64.getDecoder().decode(lIlIlIIllllIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIlIlIIlllllII = new StringBuilder();
    char[] lIlIlIIllllIlI = lIlIlIIlllllIl.toCharArray();
    int lIlIlIIllllIIl = llIllIllI[1];
    char lIlIlIIlllIIll = lIlIlIIllllIII.toCharArray();
    float lIlIlIIlllIIlI = lIlIlIIlllIIll.length;
    char lIlIlIIlllIIIl = llIllIllI[1];
    while (lIllIIllllI(lIlIlIIlllIIIl, lIlIlIIlllIIlI))
    {
      char lIlIlIlIIIIIII = lIlIlIIlllIIll[lIlIlIIlllIIIl];
      "".length();
      "".length();
      if ((0x13 ^ 0x5A ^ 0xDA ^ 0x97) < "   ".length()) {
        return null;
      }
    }
    return String.valueOf(lIlIlIIlllllII);
  }
  
  private static void lIllIIIllIl()
  {
    llIIlIlIl = new String[llIllIllI[47]];
    llIIlIlIl[llIllIllI[1]] = lIlIlIllIII("BUi4Tu3DCAs=", "hzIPD");
    llIIlIlIl[llIllIllI[0]] = lIlIlIllIII("mRK08voCi5U45are/VMJfw==", "OVKfh");
    llIIlIlIl[llIllIllI[2]] = lIlIlIllIII("RdJ4IKeoENZwbSiTXkj2sB3OeGA1kN78vilhEyzZcXA=", "FbFpJ");
    llIIlIlIl[llIllIllI[16]] = lIlIlIllIII("ZpQPWN8h58FxZZv+KSGIFHkLvBfK+iBSP4xdPJrHWxE=", "VuHCX");
    llIIlIlIl[llIllIllI[19]] = lIllIIIIlll("CgMYHQYLAEIHBhAdCAc=", "eslti");
    llIIlIlIl[llIllIllI[15]] = lIlIlIllIII("6QajppJMuVC1937NuYiCcA==", "FskKH");
    llIIlIlIl[llIllIllI[5]] = lIlIlIllIII("TOkvXclYZQzahxfVT+weqA==", "qOJBW");
    llIIlIlIl[llIllIllI[24]] = lIllIIIlIII("2e2Ifp3BqOg/f6vqMU/r0UJxngoif03P", "aGGTy");
    llIIlIlIl[llIllIllI[27]] = lIllIIIIlll("Hyg4LQkeK2IoBx4/OSUBFQ==", "pXLDf");
    llIIlIlIl[llIllIllI[29]] = lIllIIIIlll("JgIwOSMnAWozJCgGaiQlPR4h", "IrDPL");
    llIIlIlIl[llIllIllI[32]] = lIllIIIlIII("b7043wvYhy1e+dYhOxBZhHCRW3bHIQTH", "Iqumd");
    llIIlIlIl[llIllIllI[34]] = lIllIIIIlll("CjMeLjwLMEQ0PQosGiIhSzUDIiQ=", "eCjGS");
    llIIlIlIl[llIllIllI[6]] = lIlIlIllIII("ux4AHvs4JgStZ8hLpMllGQ==", "KxoNG");
    llIIlIlIl[llIllIllI[40]] = lIllIIIlIII("evJ/I0o1uOwNzIPBNIafghEMVBDfSiAG", "RTNBn");
    llIIlIlIl[llIllIllI[41]] = lIllIIIlIII("ICaaZZIFL3M=", "cfZjQ");
    llIIlIlIl[llIllIllI[42]] = lIlIlIllIII("0vQvnVdCQGZXtj1N6c6umczLKLPtRlfl", "uzkrh");
    llIIlIlIl[llIllIllI[43]] = lIlIlIllIII("kRTdKXzlug8=", "IRSJh");
    llIIlIlIl[llIllIllI[44]] = lIllIIIIlll("ICAJMi0nPAMgPWolADcvaj0GICgh", "DIoTD");
    llIIlIlIl[llIllIllI[45]] = lIlIlIllIII("itXHPqD2yc2FG6sug/7seTkdS2xyukQO6YBwAkEc48Y=", "PsHMP");
  }
  
  private static boolean lIllIIllIll(Object ???)
  {
    short lIlIlIIllIIIlI;
    return ??? != null;
  }
  
  private static String lIllIIIlIII(String lIlIlIlIIllIlI, String lIlIlIlIIllIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIlIlIlIIlllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIlIlIlIIllIII.getBytes(StandardCharsets.UTF_8)), llIllIllI[27]), "DES");
      Cipher lIlIlIlIIllllI = Cipher.getInstance("DES");
      lIlIlIlIIllllI.init(llIllIllI[2], lIlIlIlIIlllll);
      return new String(lIlIlIlIIllllI.doFinal(Base64.getDecoder().decode(lIlIlIlIIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIlIlIlIIlllIl)
    {
      lIlIlIlIIlllIl.printStackTrace();
    }
    return null;
  }
  
  public void confirmClicked(boolean lIlIlIllllIlIl, int lIlIlIllllIlll)
  {
    ;
    ;
    ;
    mc.displayGuiScreen(lIlIlIllllIllI);
    if ((lIllIIlllIl(lIlIlIllllIlll, llIllIllI[11])) && (lIllIIllIIl(lIlIlIlllllIII)) && (lIllIIllIll(mc.theWorld)))
    {
      mc.theWorld.getWorldInfo().setDifficultyLocked(llIllIllI[0]);
      field_175356_r.func_175229_b(llIllIllI[0]);
      field_175356_r.enabled = llIllIllI[1];
      field_175357_i.enabled = llIllIllI[1];
    }
  }
  
  public String func_175355_a(EnumDifficulty lIlIllIIIIIIII)
  {
    ;
    ;
    IChatComponent lIlIlIllllllll = new ChatComponentText(llIIlIlIl[llIllIllI[41]]);
    new ChatComponentTranslation(llIIlIlIl[llIllIllI[42]], new Object[llIllIllI[1]]);
    "".length();
    "".length();
    new ChatComponentTranslation(lIlIlIlllllllI.getDifficultyResourceKey(), new Object[llIllIllI[1]]);
    "".length();
    return lIlIlIllllllll.getFormattedText();
  }
  
  public GuiOptions(GuiScreen lIlIllIIIllIII, GameSettings lIlIllIIIllIlI)
  {
    field_146441_g = lIlIllIIIllIll;
    game_settings_1 = lIlIllIIIllIlI;
  }
  
  private static boolean lIllIIlllII(int ???)
  {
    short lIlIlIIlIllllI;
    return ??? == 0;
  }
  
  static
  {
    lIllIIllIII();
    lIllIIIllIl();
  }
  
  private static String lIlIlIllIII(String lIlIlIlIlIlIll, String lIlIlIlIlIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIlIlIlIllIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIlIlIlIlIllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIlIlIlIllIIlI = Cipher.getInstance("Blowfish");
      lIlIlIlIllIIlI.init(llIllIllI[2], lIlIlIlIllIllI);
      return new String(lIlIlIlIllIIlI.doFinal(Base64.getDecoder().decode(lIlIlIlIlIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIlIlIlIllIIII)
    {
      lIlIlIlIllIIII.printStackTrace();
    }
    return null;
  }
}

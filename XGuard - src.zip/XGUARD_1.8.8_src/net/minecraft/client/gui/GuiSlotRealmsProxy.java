package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.realms.RealmsScrolledSelectionList;

public class GuiSlotRealmsProxy
  extends GuiSlot
{
  protected int getScrollBarX()
  {
    ;
    return selectionList.getScrollbarPosition();
  }
  
  protected void drawSlot(int lllllllllllllllllIIlIlllIIIIIllI, int lllllllllllllllllIIlIlllIIIIIlIl, int lllllllllllllllllIIlIlllIIIIIlII, int lllllllllllllllllIIlIllIllllllII, int lllllllllllllllllIIlIlllIIIIIIlI, int lllllllllllllllllIIlIllIlllllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    selectionList.renderItem(lllllllllllllllllIIlIlllIIIIIllI, lllllllllllllllllIIlIlllIIIIIlIl, lllllllllllllllllIIlIllIllllllIl, lllllllllllllllllIIlIllIllllllII, lllllllllllllllllIIlIlllIIIIIIlI, lllllllllllllllllIIlIllIlllllIlI);
  }
  
  protected void elementClicked(int lllllllllllllllllIIlIlllIIIllIll, boolean lllllllllllllllllIIlIlllIIIlllll, int lllllllllllllllllIIlIlllIIIllllI, int lllllllllllllllllIIlIlllIIIlllIl)
  {
    ;
    ;
    ;
    ;
    ;
    selectionList.selectItem(lllllllllllllllllIIlIlllIIIllIll, lllllllllllllllllIIlIlllIIIllIlI, lllllllllllllllllIIlIlllIIIllllI, lllllllllllllllllIIlIlllIIIlllIl);
  }
  
  public int func_154337_m()
  {
    ;
    return mouseX;
  }
  
  public GuiSlotRealmsProxy(RealmsScrolledSelectionList lllllllllllllllllIIlIlllIIlIllll, int lllllllllllllllllIIlIlllIIlIlllI, int lllllllllllllllllIIlIlllIIlIllIl, int lllllllllllllllllIIlIlllIIlIllII, int lllllllllllllllllIIlIlllIIlIlIll, int lllllllllllllllllIIlIlllIIlIlIlI)
  {
    lllllllllllllllllIIlIlllIIllIIII.<init>(Minecraft.getMinecraft(), lllllllllllllllllIIlIlllIIlIlllI, lllllllllllllllllIIlIlllIIllIlII, lllllllllllllllllIIlIlllIIlIllII, lllllllllllllllllIIlIlllIIlIlIll, lllllllllllllllllIIlIlllIIlIlIlI);
    selectionList = lllllllllllllllllIIlIlllIIlIllll;
  }
  
  public void handleMouseInput()
  {
    ;
    lllllllllllllllllIIlIllIlllIlIII.handleMouseInput();
  }
  
  protected void drawBackground()
  {
    ;
    selectionList.renderBackground();
  }
  
  public int func_154339_l()
  {
    ;
    return mouseY;
  }
  
  protected int getContentHeight()
  {
    ;
    return selectionList.getMaxPosition();
  }
  
  protected int getSize()
  {
    ;
    return selectionList.getItemCount();
  }
  
  public int func_154338_k()
  {
    ;
    return width;
  }
  
  protected boolean isSelected(int lllllllllllllllllIIlIlllIIIlIIlI)
  {
    ;
    ;
    return selectionList.isSelectedItem(lllllllllllllllllIIlIlllIIIlIIlI);
  }
}

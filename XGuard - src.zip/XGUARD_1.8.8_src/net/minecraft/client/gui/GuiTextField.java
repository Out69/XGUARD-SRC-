package net.minecraft.client.gui;

import com.google.common.base.Predicate;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.MathHelper;

public class GuiTextField
  extends Gui
{
  public void setCursorPositionZero()
  {
    ;
    llllllllllllllIlIlIIIIIlIlIlIlII.setCursorPosition(lIIIlIIlIllll[0]);
  }
  
  public int getNthWordFromPos(int llllllllllllllIlIlIIIIIllIIIIIlI, int llllllllllllllIlIlIIIIIllIIIIIIl)
  {
    ;
    ;
    ;
    return llllllllllllllIlIlIIIIIllIIIIllI.func_146197_a(llllllllllllllIlIlIIIIIllIIIIlIl, llllllllllllllIlIlIIIIIllIIIIIIl, lIIIlIIlIllll[2]);
  }
  
  private static String llIlIIIIlIlIII(String llllllllllllllIlIlIIIIIIIlIllIIl, String llllllllllllllIlIlIIIIIIIlIllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIlIIIIIIIllIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIIIIIIIlIllIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIlIIIIIIIllIIIIl = Cipher.getInstance("Blowfish");
      llllllllllllllIlIlIIIIIIIllIIIIl.init(lIIIlIIlIllll[5], llllllllllllllIlIlIIIIIIIllIIIll);
      return new String(llllllllllllllIlIlIIIIIIIllIIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIIIIIIIlIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIlIIIIIIIlIlllll)
    {
      llllllllllllllIlIlIIIIIIIlIlllll.printStackTrace();
    }
    return null;
  }
  
  public boolean getVisible()
  {
    ;
    return visible;
  }
  
  private static boolean llIlIIlIIIlIlI(int ???)
  {
    long llllllllllllllIlIlIIIIIIIIIlIIII;
    return ??? > 0;
  }
  
  private static boolean llIlIIlIIIIllI(int ???)
  {
    char llllllllllllllIlIlIIIIIIIIIllIII;
    return ??? != 0;
  }
  
  public void setText(String llllllllllllllIlIlIIIIIlllIlIlIl)
  {
    ;
    ;
    if (llIlIIlIIIIllI(field_175209_y.apply(llllllllllllllIlIlIIIIIlllIlIlIl)))
    {
      if (llIlIIlIIIIlll(llllllllllllllIlIlIIIIIlllIlIlIl.length(), maxStringLength))
      {
        text = llllllllllllllIlIlIIIIIlllIlIlIl.substring(lIIIlIIlIllll[0], maxStringLength);
        "".length();
        if (-" ".length() < "   ".length()) {}
      }
      else
      {
        text = llllllllllllllIlIlIIIIIlllIlIlIl;
      }
      llllllllllllllIlIlIIIIIlllIlIllI.setCursorPositionEnd();
    }
  }
  
  private static boolean llIlIIlIIIIlll(int ???, int arg1)
  {
    int i;
    float llllllllllllllIlIlIIIIIIIIIlllII;
    return ??? > i;
  }
  
  public void setCursorPosition(int llllllllllllllIlIlIIIIIlIlIllIll)
  {
    ;
    ;
    ;
    cursorPosition = llllllllllllllIlIlIIIIIlIlIllIll;
    int llllllllllllllIlIlIIIIIlIlIllIlI = text.length();
    cursorPosition = MathHelper.clamp_int(cursorPosition, lIIIlIIlIllll[0], llllllllllllllIlIlIIIIIlIlIllIlI);
    llllllllllllllIlIlIIIIIlIlIlllII.setSelectionPos(cursorPosition);
  }
  
  public String getSelectedText()
  {
    ;
    ;
    ;
    if (llIlIIlIIIlIII(cursorPosition, selectionEnd))
    {
      "".length();
      if (((66 + 123 - 182 + 120 ^ 0xA5 ^ 0xC5) & (0x77 ^ 0x27 ^ 0xEB ^ 0xA4 ^ -" ".length())) == 0) {
        break label74;
      }
      return null;
    }
    label74:
    int llllllllllllllIlIlIIIIIlllIIllIl = selectionEnd;
    if (llIlIIlIIIlIII(cursorPosition, selectionEnd))
    {
      "".length();
      if (((0x36 ^ 0x5 ^ 0x82 ^ 0x98) & (0xBC ^ 0xA9 ^ 0x33 ^ 0xF ^ -" ".length())) >= 0) {
        break label141;
      }
      return null;
    }
    label141:
    int llllllllllllllIlIlIIIIIlllIIllII = cursorPosition;
    return text.substring(llllllllllllllIlIlIIIIIlllIIllIl, llllllllllllllIlIlIIIIIlllIIllII);
  }
  
  public void func_175205_a(Predicate<String> llllllllllllllIlIlIIIIIlllIIIlIl)
  {
    ;
    ;
    field_175209_y = llllllllllllllIlIlIIIIIlllIIIlIl;
  }
  
  private static boolean llIlIIlIIIllll(int ???)
  {
    boolean llllllllllllllIlIlIIIIIIIIIlIIlI;
    return ??? < 0;
  }
  
  public int getId()
  {
    ;
    return id;
  }
  
  private static boolean llIlIIlIIIlllI(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIlIlIIIIIIIIIIllII;
    return ??? != i;
  }
  
  private static String llIlIIIIlIIlll(String llllllllllllllIlIlIIIIIIIlllIIll, String llllllllllllllIlIlIIIIIIIlllIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIlIIIIIIIllllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIIIIIIIlllIIlI.getBytes(StandardCharsets.UTF_8)), lIIIlIIlIllll[13]), "DES");
      Cipher llllllllllllllIlIlIIIIIIIlllIlll = Cipher.getInstance("DES");
      llllllllllllllIlIlIIIIIIIlllIlll.init(lIIIlIIlIllll[5], llllllllllllllIlIlIIIIIIIllllIII);
      return new String(llllllllllllllIlIlIIIIIIIlllIlll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIIIIIIIlllIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIlIIIIIIIlllIllI)
    {
      llllllllllllllIlIlIIIIIIIlllIllI.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIlIIlIIIllII(Object ???)
  {
    int llllllllllllllIlIlIIIIIIIIIllIlI;
    return ??? != null;
  }
  
  public void func_175207_a(GuiPageButtonList.GuiResponder llllllllllllllIlIlIIIIIlllIllllI)
  {
    ;
    ;
    field_175210_x = llllllllllllllIlIlIIIIIlllIllllI;
  }
  
  public int getSelectionEnd()
  {
    ;
    return selectionEnd;
  }
  
  public int getMaxStringLength()
  {
    ;
    return maxStringLength;
  }
  
  public void moveCursorBy(int llllllllllllllIlIlIIIIIlIllIIIlI)
  {
    ;
    ;
    llllllllllllllIlIlIIIIIlIllIIIIl.setCursorPosition(selectionEnd + llllllllllllllIlIlIIIIIlIllIIIlI);
  }
  
  public String getText()
  {
    ;
    return text;
  }
  
  public void setMaxStringLength(int llllllllllllllIlIlIIIIIIlllIlllI)
  {
    ;
    ;
    maxStringLength = llllllllllllllIlIlIIIIIIlllIlllI;
    if (llIlIIlIIIIlll(text.length(), llllllllllllllIlIlIIIIIIlllIlllI)) {
      text = text.substring(lIIIlIIlIllll[0], llllllllllllllIlIlIIIIIIlllIlllI);
    }
  }
  
  public void setTextColor(int llllllllllllllIlIlIIIIIIllIllIIl)
  {
    ;
    ;
    enabledColor = llllllllllllllIlIlIIIIIIllIllIIl;
  }
  
  public void setCanLoseFocus(boolean llllllllllllllIlIlIIIIIIlIIlIlIl)
  {
    ;
    ;
    canLoseFocus = llllllllllllllIlIlIIIIIIlIIlIlIl;
  }
  
  public void setDisabledTextColour(int llllllllllllllIlIlIIIIIIllIlIIll)
  {
    ;
    ;
    disabledColor = llllllllllllllIlIlIIIIIIllIlIIll;
  }
  
  public void deleteWords(int llllllllllllllIlIlIIIIIllIlIIlll)
  {
    ;
    ;
    if (llIlIIlIIIIllI(text.length())) {
      if (llIlIIlIIIlllI(selectionEnd, cursorPosition))
      {
        llllllllllllllIlIlIIIIIllIlIlIII.writeText(lIIIlIIIlIIIl[lIIIlIIlIllll[5]]);
        "".length();
        if ("  ".length() != 0) {}
      }
      else
      {
        llllllllllllllIlIlIIIIIllIlIlIII.deleteFromCursor(llllllllllllllIlIlIIIIIllIlIlIII.getNthWordFromCursor(llllllllllllllIlIlIIIIIllIlIIlll) - cursorPosition);
      }
    }
  }
  
  private static boolean llIlIIlIIlIIlI(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIlIlIIIIIIIIlIllII;
    return ??? == i;
  }
  
  public void drawTextBox()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIlIIlIIlIl.getVisible()))
    {
      if (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIlIIIlIlll.getEnableBackgroundDrawing()))
      {
        drawRect(xPosition - lIIIlIIlIllll[2], yPosition - lIIIlIIlIllll[2], xPosition + width + lIIIlIIlIllll[2], yPosition + height + lIIIlIIlIllll[2], lIIIlIIlIllll[10]);
        drawRect(xPosition, yPosition, xPosition + width, yPosition + height, lIIIlIIlIllll[11]);
      }
      if (llIlIIlIIIIllI(isEnabled))
      {
        "".length();
        if (-(0x78 ^ 0x7C) <= 0) {
          break label148;
        }
      }
      label148:
      int llllllllllllllIlIlIIIIIlIIlIIlII = disabledColor;
      int llllllllllllllIlIlIIIIIlIIlIIIll = cursorPosition - lineScrollOffset;
      int llllllllllllllIlIlIIIIIlIIlIIIlI = selectionEnd - lineScrollOffset;
      String llllllllllllllIlIlIIIIIlIIlIIIIl = fontRendererInstance.trimStringToWidth(text.substring(lineScrollOffset), llllllllllllllIlIlIIIIIlIIIlIlll.getWidth());
      if ((llIlIIlIIlIIII(llllllllllllllIlIlIIIIIlIIlIIIll)) && (llIlIIlIIlIlII(llllllllllllllIlIlIIIIIlIIlIIIll, llllllllllllllIlIlIIIIIlIIlIIIIl.length())))
      {
        "".length();
        if (" ".length() != "  ".length()) {
          break label243;
        }
      }
      label243:
      boolean llllllllllllllIlIlIIIIIlIIlIIIII = lIIIlIIlIllll[0];
      if ((llIlIIlIIIIllI(isFocused)) && (llIlIIlIIlIIIl(cursorCounter / lIIIlIIlIllll[12] % lIIIlIIlIllll[5])) && (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIlIIlIIIII)))
      {
        "".length();
        if (null == null) {
          break label307;
        }
      }
      label307:
      boolean llllllllllllllIlIlIIIIIlIIIlllll = lIIIlIIlIllll[0];
      if (llIlIIlIIIIllI(enableBackgroundDrawing))
      {
        "".length();
        if ("   ".length() > 0) {
          break label349;
        }
      }
      label349:
      int llllllllllllllIlIlIIIIIlIIIllllI = xPosition;
      if (llIlIIlIIIIllI(enableBackgroundDrawing))
      {
        "".length();
        if ("  ".length() > 0) {
          break label403;
        }
      }
      label403:
      int llllllllllllllIlIlIIIIIlIIIlllIl = yPosition;
      int llllllllllllllIlIlIIIIIlIIIlllII = llllllllllllllIlIlIIIIIlIIIllllI;
      if (llIlIIlIIIIlll(llllllllllllllIlIlIIIIIlIIlIIIlI, llllllllllllllIlIlIIIIIlIIlIIIIl.length())) {
        llllllllllllllIlIlIIIIIlIIlIIIlI = llllllllllllllIlIlIIIIIlIIlIIIIl.length();
      }
      if (llIlIIlIIIlIlI(llllllllllllllIlIlIIIIIlIIlIIIIl.length()))
      {
        if (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIlIIlIIIII))
        {
          "".length();
          if ((0xE ^ 0x38 ^ 0x9 ^ 0x3A) != 0) {
            break label480;
          }
        }
        label480:
        String llllllllllllllIlIlIIIIIlIIIllIll = llllllllllllllIlIlIIIIIlIIlIIIIl;
        llllllllllllllIlIlIIIIIlIIIlllII = fontRendererInstance.drawStringWithShadow(llllllllllllllIlIlIIIIIlIIIllIll, llllllllllllllIlIlIIIIIlIIIllllI, llllllllllllllIlIlIIIIIlIIIlllIl, llllllllllllllIlIlIIIIIlIIlIIlII);
      }
      if ((llIlIIlIIlIIll(cursorPosition, text.length())) && (llIlIIlIIIlIII(text.length(), llllllllllllllIlIlIIIIIlIIIlIlll.getMaxStringLength())))
      {
        "".length();
        if (-(0x48 ^ 0x4D) < 0) {
          break label560;
        }
      }
      label560:
      boolean llllllllllllllIlIlIIIIIlIIIllIlI = lIIIlIIlIllll[2];
      int llllllllllllllIlIlIIIIIlIIIllIIl = llllllllllllllIlIlIIIIIlIIIlllII;
      if (llIlIIlIIlIIIl(llllllllllllllIlIlIIIIIlIIlIIIII))
      {
        if (llIlIIlIIIlIlI(llllllllllllllIlIlIIIIIlIIlIIIll))
        {
          "".length();
          if (" ".length() == " ".length()) {
            break label610;
          }
        }
        label610:
        llllllllllllllIlIlIIIIIlIIIllIIl = llllllllllllllIlIlIIIIIlIIIllllI;
        "".length();
        if ("   ".length() <= "   ".length()) {}
      }
      else if (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIlIIIllIlI))
      {
        llllllllllllllIlIlIIIIIlIIIllIIl = llllllllllllllIlIlIIIIIlIIIlllII - lIIIlIIlIllll[2];
      }
      if (llIlIIlIIIlIlI(llllllllllllllIlIlIIIIIlIIlIIIIl.length()))
      {
        llllllllllllllIlIlIIIIIlIIIlllII--;
        if ((llIlIIlIIIIllI(llllllllllllllIlIlIIIIIlIIlIIIII)) && (llIlIIlIIIlIII(llllllllllllllIlIlIIIIIlIIlIIIll, llllllllllllllIlIlIIIIIlIIlIIIIl.length()))) {
          llllllllllllllIlIlIIIIIlIIIlllII = fontRendererInstance.drawStringWithShadow(llllllllllllllIlIlIIIIIlIIlIIIIl.substring(llllllllllllllIlIlIIIIIlIIlIIIll), llllllllllllllIlIlIIIIIlIIIlllII, llllllllllllllIlIlIIIIIlIIIlllIl, llllllllllllllIlIlIIIIIlIIlIIlII);
        }
      }
      if (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIlIIIlllll)) {
        if (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIlIIIllIlI))
        {
          Gui.drawRect(llllllllllllllIlIlIIIIIlIIIllIIl, llllllllllllllIlIlIIIIIlIIIlllIl - lIIIlIIlIllll[2], llllllllllllllIlIlIIIIIlIIIllIIl + lIIIlIIlIllll[2], llllllllllllllIlIlIIIIIlIIIlllIl + lIIIlIIlIllll[2] + fontRendererInstance.FONT_HEIGHT, lIIIlIIlIllll[14]);
          "".length();
          if (((0x6D ^ 0x53) & (0x64 ^ 0x5A ^ 0xFFFFFFFF)) == 0) {}
        }
        else
        {
          "".length();
        }
      }
      if (llIlIIlIIIlllI(llllllllllllllIlIlIIIIIlIIlIIIlI, llllllllllllllIlIlIIIIIlIIlIIIll))
      {
        int llllllllllllllIlIlIIIIIlIIIllIII = llllllllllllllIlIlIIIIIlIIIllllI + fontRendererInstance.getStringWidth(llllllllllllllIlIlIIIIIlIIlIIIIl.substring(lIIIlIIlIllll[0], llllllllllllllIlIlIIIIIlIIlIIIlI));
        llllllllllllllIlIlIIIIIlIIIlIlll.drawCursorVertical(llllllllllllllIlIlIIIIIlIIIllIIl, llllllllllllllIlIlIIIIIlIIIlllIl - lIIIlIIlIllll[2], llllllllllllllIlIlIIIIIlIIIllIII - lIIIlIIlIllll[2], llllllllllllllIlIlIIIIIlIIIlllIl + lIIIlIIlIllll[2] + fontRendererInstance.FONT_HEIGHT);
      }
    }
  }
  
  public int getWidth()
  {
    ;
    if (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIIlIlllllI.getEnableBackgroundDrawing()))
    {
      "".length();
      if (" ".length() != 0) {
        break label84;
      }
      return ('¢' + 'µ' - 276 + 136 ^ 27 + 122 - 84 + 91) & (0x0 ^ 0x12 ^ 0x2 ^ 0x47 ^ -" ".length());
    }
    label84:
    return width;
  }
  
  private void drawCursorVertical(int llllllllllllllIlIlIIIIIlIIIIIIlI, int llllllllllllllIlIlIIIIIIlllllIII, int llllllllllllllIlIlIIIIIIllllIlll, int llllllllllllllIlIlIIIIIIllllllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIlIIlIIIlIII(llllllllllllllIlIlIIIIIlIIIIIIlI, llllllllllllllIlIlIIIIIIllllIlll))
    {
      int llllllllllllllIlIlIIIIIIlllllllI = llllllllllllllIlIlIIIIIlIIIIIIlI;
      llllllllllllllIlIlIIIIIlIIIIIIlI = llllllllllllllIlIlIIIIIIllllIlll;
      llllllllllllllIlIlIIIIIIllllIlll = llllllllllllllIlIlIIIIIIlllllllI;
    }
    if (llIlIIlIIIlIII(llllllllllllllIlIlIIIIIlIIIIIIIl, llllllllllllllIlIlIIIIIIllllllll))
    {
      int llllllllllllllIlIlIIIIIIllllllIl = llllllllllllllIlIlIIIIIlIIIIIIIl;
      llllllllllllllIlIlIIIIIlIIIIIIIl = llllllllllllllIlIlIIIIIIllllllll;
      llllllllllllllIlIlIIIIIIllllllll = llllllllllllllIlIlIIIIIIllllllIl;
    }
    if (llIlIIlIIIIlll(llllllllllllllIlIlIIIIIIllllIlll, xPosition + width)) {
      llllllllllllllIlIlIIIIIIllllIlll = xPosition + width;
    }
    if (llIlIIlIIIIlll(llllllllllllllIlIlIIIIIlIIIIIIlI, xPosition + width)) {
      llllllllllllllIlIlIIIIIlIIIIIIlI = xPosition + width;
    }
    Tessellator llllllllllllllIlIlIIIIIIllllllII = Tessellator.getInstance();
    WorldRenderer llllllllllllllIlIlIIIIIIlllllIll = llllllllllllllIlIlIIIIIIllllllII.getWorldRenderer();
    GlStateManager.color(0.0F, 0.0F, 255.0F, 255.0F);
    GlStateManager.disableTexture2D();
    GlStateManager.enableColorLogic();
    GlStateManager.colorLogicOp(lIIIlIIlIllll[15]);
    llllllllllllllIlIlIIIIIIlllllIll.begin(lIIIlIIlIllll[16], DefaultVertexFormats.POSITION);
    llllllllllllllIlIlIIIIIIlllllIll.pos(llllllllllllllIlIlIIIIIlIIIIIIlI, llllllllllllllIlIlIIIIIIllllllll, 0.0D).endVertex();
    llllllllllllllIlIlIIIIIIlllllIll.pos(llllllllllllllIlIlIIIIIIllllIlll, llllllllllllllIlIlIIIIIIllllllll, 0.0D).endVertex();
    llllllllllllllIlIlIIIIIIlllllIll.pos(llllllllllllllIlIlIIIIIIllllIlll, llllllllllllllIlIlIIIIIlIIIIIIIl, 0.0D).endVertex();
    llllllllllllllIlIlIIIIIIlllllIll.pos(llllllllllllllIlIlIIIIIlIIIIIIlI, llllllllllllllIlIlIIIIIlIIIIIIIl, 0.0D).endVertex();
    llllllllllllllIlIlIIIIIIllllllII.draw();
    GlStateManager.disableColorLogic();
    GlStateManager.enableTexture2D();
  }
  
  public boolean getEnableBackgroundDrawing()
  {
    ;
    return enableBackgroundDrawing;
  }
  
  public void setCursorPositionEnd()
  {
    ;
    llllllllllllllIlIlIIIIIlIlIlIIlI.setCursorPosition(text.length());
  }
  
  private static void llIlIIlIIIIlIl()
  {
    lIIIlIIlIllll = new int[17];
    lIIIlIIlIllll[0] = ((0x27 ^ 0x4F ^ 0x81 ^ 0xC0) & (0x2A ^ 0x63 ^ 0x7 ^ 0x67 ^ -" ".length()));
    lIIIlIIlIllll[1] = (0x7F ^ 0x65 ^ 0x35 ^ 0xF);
    lIIIlIIlIllll[2] = " ".length();
    lIIIlIIlIllll[3] = (0xE1F5 & 0xE0FEEA);
    lIIIlIIlIllll[4] = (0xF671 & 0x7079FE);
    lIIIlIIlIllll[5] = "  ".length();
    lIIIlIIlIllll[6] = "   ".length();
    lIIIlIIlIllll[7] = (0x47 ^ 0x43);
    lIIIlIIlIllll[8] = (-" ".length());
    lIIIlIIlIllll[9] = (0xB5 ^ 0xB0);
    lIIIlIIlIllll[10] = (-(-(0xBDB9 & 0x62D7) & 0xFFFFFFFE & 0x5F7FF1));
    lIIIlIIlIllll[11] = (-(-(0xF7FF & 0x39BE) & 0xF3FF & 0x1003DBD));
    lIIIlIIlIllll[12] = (0x84 ^ 0x82);
    lIIIlIIlIllll[13] = (0x7F ^ 0x5D ^ 0x1F ^ 0x35);
    lIIIlIIlIllll[14] = (-(0xFFFFFFB8 & 0x2F2F77));
    lIIIlIIlIllll[15] = (-(0xA267 & 0x7D99) & 0xF78F & 0x3D7B);
    lIIIlIIlIllll[16] = (0x88 ^ 0x8F);
  }
  
  static
  {
    llIlIIlIIIIlIl();
    llIlIIIIlIlIIl();
  }
  
  private static boolean llIlIIlIIlIIll(int ???, int arg1)
  {
    int i;
    float llllllllllllllIlIlIIIIIIIIlIlIII;
    return ??? >= i;
  }
  
  public boolean textboxKeyTyped(char llllllllllllllIlIlIIIIIlIlIIlIIl, int llllllllllllllIlIlIIIIIlIlIIlIll)
  {
    ;
    ;
    ;
    if (llIlIIlIIlIIIl(isFocused)) {
      return lIIIlIIlIllll[0];
    }
    if (llIlIIlIIIIllI(GuiScreen.isKeyComboCtrlA(llllllllllllllIlIlIIIIIlIlIIlIll)))
    {
      llllllllllllllIlIlIIIIIlIlIIlIlI.setCursorPositionEnd();
      llllllllllllllIlIlIIIIIlIlIIlIlI.setSelectionPos(lIIIlIIlIllll[0]);
      return lIIIlIIlIllll[2];
    }
    if (llIlIIlIIIIllI(GuiScreen.isKeyComboCtrlC(llllllllllllllIlIlIIIIIlIlIIlIll)))
    {
      GuiScreen.setClipboardString(llllllllllllllIlIlIIIIIlIlIIlIlI.getSelectedText());
      return lIIIlIIlIllll[2];
    }
    if (llIlIIlIIIIllI(GuiScreen.isKeyComboCtrlV(llllllllllllllIlIlIIIIIlIlIIlIll)))
    {
      if (llIlIIlIIIIllI(isEnabled)) {
        llllllllllllllIlIlIIIIIlIlIIlIlI.writeText(GuiScreen.getClipboardString());
      }
      return lIIIlIIlIllll[2];
    }
    if (llIlIIlIIIIllI(GuiScreen.isKeyComboCtrlX(llllllllllllllIlIlIIIIIlIlIIlIll)))
    {
      GuiScreen.setClipboardString(llllllllllllllIlIlIIIIIlIlIIlIlI.getSelectedText());
      if (llIlIIlIIIIllI(isEnabled)) {
        llllllllllllllIlIlIIIIIlIlIIlIlI.writeText(lIIIlIIIlIIIl[lIIIlIIlIllll[9]]);
      }
      return lIIIlIIlIllll[2];
    }
    switch (llllllllllllllIlIlIIIIIlIlIIlIll)
    {
    case 14: 
      if (llIlIIlIIIIllI(GuiScreen.isCtrlKeyDown()))
      {
        if (llIlIIlIIIIllI(isEnabled))
        {
          llllllllllllllIlIlIIIIIlIlIIlIlI.deleteWords(lIIIlIIlIllll[8]);
          "".length();
          if ((0x76 ^ 0x72) < "  ".length()) {
            return (0x60 ^ 0x4C) & (0xA8 ^ 0x84 ^ 0xFFFFFFFF);
          }
        }
      }
      else if (llIlIIlIIIIllI(isEnabled)) {
        llllllllllllllIlIlIIIIIlIlIIlIlI.deleteFromCursor(lIIIlIIlIllll[8]);
      }
      return lIIIlIIlIllll[2];
    case 199: 
      if (llIlIIlIIIIllI(GuiScreen.isShiftKeyDown()))
      {
        llllllllllllllIlIlIIIIIlIlIIlIlI.setSelectionPos(lIIIlIIlIllll[0]);
        "".length();
        if (-" ".length() >= (0x8 ^ 0x43 ^ 0x72 ^ 0x3D)) {
          return (0x86 ^ 0xBF ^ 0x66 ^ 0x7C) & (0xC3 ^ 0x88 ^ 0x22 ^ 0x4A ^ -" ".length());
        }
      }
      else
      {
        llllllllllllllIlIlIIIIIlIlIIlIlI.setCursorPositionZero();
      }
      return lIIIlIIlIllll[2];
    case 203: 
      if (llIlIIlIIIIllI(GuiScreen.isShiftKeyDown()))
      {
        if (llIlIIlIIIIllI(GuiScreen.isCtrlKeyDown()))
        {
          llllllllllllllIlIlIIIIIlIlIIlIlI.setSelectionPos(llllllllllllllIlIlIIIIIlIlIIlIlI.getNthWordFromPos(lIIIlIIlIllll[8], llllllllllllllIlIlIIIIIlIlIIlIlI.getSelectionEnd()));
          "".length();
          if (null != null) {
            return (0x5B ^ 0x40) & (0x2B ^ 0x30 ^ 0xFFFFFFFF);
          }
        }
        else
        {
          llllllllllllllIlIlIIIIIlIlIIlIlI.setSelectionPos(llllllllllllllIlIlIIIIIlIlIIlIlI.getSelectionEnd() - lIIIlIIlIllll[2]);
          "".length();
          if (" ".length() != " ".length()) {
            return (0x88 ^ 0x94) & (0x76 ^ 0x6A ^ 0xFFFFFFFF);
          }
        }
      }
      else if (llIlIIlIIIIllI(GuiScreen.isCtrlKeyDown()))
      {
        llllllllllllllIlIlIIIIIlIlIIlIlI.setCursorPosition(llllllllllllllIlIlIIIIIlIlIIlIlI.getNthWordFromCursor(lIIIlIIlIllll[8]));
        "".length();
        if (null != null) {
          return (0xEB ^ 0x88) & (0x71 ^ 0x12 ^ 0xFFFFFFFF);
        }
      }
      else
      {
        llllllllllllllIlIlIIIIIlIlIIlIlI.moveCursorBy(lIIIlIIlIllll[8]);
      }
      return lIIIlIIlIllll[2];
    case 205: 
      if (llIlIIlIIIIllI(GuiScreen.isShiftKeyDown()))
      {
        if (llIlIIlIIIIllI(GuiScreen.isCtrlKeyDown()))
        {
          llllllllllllllIlIlIIIIIlIlIIlIlI.setSelectionPos(llllllllllllllIlIlIIIIIlIlIIlIlI.getNthWordFromPos(lIIIlIIlIllll[2], llllllllllllllIlIlIIIIIlIlIIlIlI.getSelectionEnd()));
          "".length();
          if (" ".length() <= -" ".length()) {
            return (0x9 ^ 0x1A) & (0x78 ^ 0x6B ^ 0xFFFFFFFF);
          }
        }
        else
        {
          llllllllllllllIlIlIIIIIlIlIIlIlI.setSelectionPos(llllllllllllllIlIlIIIIIlIlIIlIlI.getSelectionEnd() + lIIIlIIlIllll[2]);
          "".length();
          if (null != null) {
            return (0x5D ^ 0x67) & (0x27 ^ 0x1D ^ 0xFFFFFFFF);
          }
        }
      }
      else if (llIlIIlIIIIllI(GuiScreen.isCtrlKeyDown()))
      {
        llllllllllllllIlIlIIIIIlIlIIlIlI.setCursorPosition(llllllllllllllIlIlIIIIIlIlIIlIlI.getNthWordFromCursor(lIIIlIIlIllll[2]));
        "".length();
        if ("   ".length() <= 0) {
          return "  ".length() & ("  ".length() ^ 0xFFFFFFFF);
        }
      }
      else
      {
        llllllllllllllIlIlIIIIIlIlIIlIlI.moveCursorBy(lIIIlIIlIllll[2]);
      }
      return lIIIlIIlIllll[2];
    case 207: 
      if (llIlIIlIIIIllI(GuiScreen.isShiftKeyDown()))
      {
        llllllllllllllIlIlIIIIIlIlIIlIlI.setSelectionPos(text.length());
        "".length();
        if ("  ".length() <= ((0x2 ^ 0x6E ^ 0x24 ^ 0x2A) & (9 + 87 - 45 + 165 ^ 46 + '·' - 172 + 129 ^ -" ".length()))) {
          return (0xD7 ^ 0xAE ^ 0x72 ^ 0x23) & (0x36 ^ 0x7D ^ 0x15 ^ 0x76 ^ -" ".length());
        }
      }
      else
      {
        llllllllllllllIlIlIIIIIlIlIIlIlI.setCursorPositionEnd();
      }
      return lIIIlIIlIllll[2];
    case 211: 
      if (llIlIIlIIIIllI(GuiScreen.isCtrlKeyDown()))
      {
        if (llIlIIlIIIIllI(isEnabled))
        {
          llllllllllllllIlIlIIIIIlIlIIlIlI.deleteWords(lIIIlIIlIllll[2]);
          "".length();
          if ("  ".length() < "  ".length()) {
            return (0xC9 ^ 0xC0) & (0x61 ^ 0x68 ^ 0xFFFFFFFF);
          }
        }
      }
      else if (llIlIIlIIIIllI(isEnabled)) {
        llllllllllllllIlIlIIIIIlIlIIlIlI.deleteFromCursor(lIIIlIIlIllll[2]);
      }
      return lIIIlIIlIllll[2];
    }
    if (llIlIIlIIIIllI(ChatAllowedCharacters.isAllowedCharacter(llllllllllllllIlIlIIIIIlIlIIllII)))
    {
      if (llIlIIlIIIIllI(isEnabled)) {
        llllllllllllllIlIlIIIIIlIlIIlIlI.writeText(Character.toString(llllllllllllllIlIlIIIIIlIlIIllII));
      }
      return lIIIlIIlIllll[2];
    }
    return lIIIlIIlIllll[0];
  }
  
  public void setVisible(boolean llllllllllllllIlIlIIIIIIlIIIlIII)
  {
    ;
    ;
    visible = llllllllllllllIlIlIIIIIIlIIIlIII;
  }
  
  private static boolean llIlIIlIIlIlII(int ???, int arg1)
  {
    int i;
    char llllllllllllllIlIlIIIIIIIIlIIIII;
    return ??? <= i;
  }
  
  public void mouseClicked(int llllllllllllllIlIlIIIIIlIIllllll, int llllllllllllllIlIlIIIIIlIIllIlll, int llllllllllllllIlIlIIIIIlIIllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((llIlIIlIIlIIll(llllllllllllllIlIlIIIIIlIIllllll, xPosition)) && (llIlIIlIIIlIII(llllllllllllllIlIlIIIIIlIIllllll, xPosition + width)) && (llIlIIlIIlIIll(llllllllllllllIlIlIIIIIlIIllIlll, yPosition)) && (llIlIIlIIIlIII(llllllllllllllIlIlIIIIIlIIllIlll, yPosition + height)))
    {
      "".length();
      if (-(0x7E ^ 0x7A) <= 0) {
        break label80;
      }
    }
    label80:
    boolean llllllllllllllIlIlIIIIIlIIllllII = lIIIlIIlIllll[0];
    if (llIlIIlIIIIllI(canLoseFocus)) {
      llllllllllllllIlIlIIIIIlIlIIIIII.setFocused(llllllllllllllIlIlIIIIIlIIllllII);
    }
    if ((llIlIIlIIIIllI(isFocused)) && (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIlIIllllII)) && (llIlIIlIIlIIIl(llllllllllllllIlIlIIIIIlIIllIllI)))
    {
      int llllllllllllllIlIlIIIIIlIIlllIll = llllllllllllllIlIlIIIIIlIIllllll - xPosition;
      if (llIlIIlIIIIllI(enableBackgroundDrawing)) {
        llllllllllllllIlIlIIIIIlIIlllIll -= 4;
      }
      String llllllllllllllIlIlIIIIIlIIlllIlI = fontRendererInstance.trimStringToWidth(text.substring(lineScrollOffset), llllllllllllllIlIlIIIIIlIlIIIIII.getWidth());
      llllllllllllllIlIlIIIIIlIlIIIIII.setCursorPosition(fontRendererInstance.trimStringToWidth(llllllllllllllIlIlIIIIIlIIlllIlI, llllllllllllllIlIlIIIIIlIIlllIll).length() + lineScrollOffset);
    }
  }
  
  public int getNthWordFromCursor(int llllllllllllllIlIlIIIIIllIIIlIlI)
  {
    ;
    ;
    return llllllllllllllIlIlIIIIIllIIIlIll.getNthWordFromPos(llllllllllllllIlIlIIIIIllIIIlIlI, llllllllllllllIlIlIIIIIllIIIlIll.getCursorPosition());
  }
  
  private static boolean llIlIIlIIlIIIl(int ???)
  {
    double llllllllllllllIlIlIIIIIIIIIlIllI;
    return ??? == 0;
  }
  
  public boolean isFocused()
  {
    ;
    return isFocused;
  }
  
  private static void llIlIIIIlIlIIl()
  {
    lIIIlIIIlIIIl = new String[lIIIlIIlIllll[16]];
    lIIIlIIIlIIIl[lIIIlIIlIllll[0]] = llIlIIIIlIIllI("", "yKFFg");
    lIIIlIIIlIIIl[lIIIlIIlIllll[2]] = llIlIIIIlIIlll("QjDjN2GUoNw=", "eMCCW");
    lIIIlIIIlIIIl[lIIIlIIlIllll[5]] = llIlIIIIlIlIII("777VjL2H53c=", "KPJaZ");
    lIIIlIIIlIIIl[lIIIlIIlIllll[6]] = llIlIIIIlIIlll("9vy31OREb6c=", "nPfYi");
    lIIIlIIIlIIIl[lIIIlIIlIllll[7]] = llIlIIIIlIlIII("kGcvlE7vbRc=", "MIZSP");
    lIIIlIIIlIIIl[lIIIlIIlIllll[9]] = llIlIIIIlIIlll("7qTlku3h5QM=", "xidIL");
    lIIIlIIIlIIIl[lIIIlIIlIllll[12]] = llIlIIIIlIIlll("yvu8tHToA5Q=", "yvjAr");
  }
  
  public void updateCursorCounter()
  {
    ;
    cursorCounter += lIIIlIIlIllll[2];
  }
  
  public void deleteFromCursor(int llllllllllllllIlIlIIIIIllIIlIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIlIIlIIIIllI(text.length())) {
      if (llIlIIlIIIlllI(selectionEnd, cursorPosition))
      {
        llllllllllllllIlIlIIIIIllIIllllI.writeText(lIIIlIIIlIIIl[lIIIlIIlIllll[6]]);
        "".length();
        if (((0x7F ^ 0x57) & (0x4 ^ 0x2C ^ 0xFFFFFFFF)) == 0) {}
      }
      else
      {
        if (llIlIIlIIIllll(llllllllllllllIlIlIIIIIllIIlIlll))
        {
          "".length();
          if (((0x3 ^ 0x2E) & (0x5B ^ 0x76 ^ 0xFFFFFFFF)) == 0) {
            break label102;
          }
        }
        label102:
        boolean llllllllllllllIlIlIIIIIllIIlllII = lIIIlIIlIllll[0];
        if (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIllIIlllII))
        {
          "".length();
          if (null == null) {
            break label131;
          }
        }
        label131:
        int llllllllllllllIlIlIIIIIllIIllIll = cursorPosition;
        if (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIllIIlllII))
        {
          "".length();
          if (-(0x8D ^ 0xA5 ^ 0x25 ^ 0x9) < 0) {
            break label173;
          }
        }
        label173:
        int llllllllllllllIlIlIIIIIllIIllIlI = cursorPosition + llllllllllllllIlIlIIIIIllIIlIlll;
        String llllllllllllllIlIlIIIIIllIIllIIl = lIIIlIIIlIIIl[lIIIlIIlIllll[7]];
        if (llIlIIlIIlIIII(llllllllllllllIlIlIIIIIllIIllIll)) {
          llllllllllllllIlIlIIIIIllIIllIIl = text.substring(lIIIlIIlIllll[0], llllllllllllllIlIlIIIIIllIIllIll);
        }
        if (llIlIIlIIIlIII(llllllllllllllIlIlIIIIIllIIllIlI, text.length())) {
          llllllllllllllIlIlIIIIIllIIllIIl = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlIlIIIIIllIIllIIl)).append(text.substring(llllllllllllllIlIlIIIIIllIIllIlI)));
        }
        if (llIlIIlIIIIllI(field_175209_y.apply(llllllllllllllIlIlIIIIIllIIllIIl)))
        {
          text = llllllllllllllIlIlIIIIIllIIllIIl;
          if (llIlIIlIIIIllI(llllllllllllllIlIlIIIIIllIIlllII)) {
            llllllllllllllIlIlIIIIIllIIllllI.moveCursorBy(llllllllllllllIlIlIIIIIllIIlIlll);
          }
          if (llIlIIlIIIllII(field_175210_x)) {
            field_175210_x.func_175319_a(id, text);
          }
        }
      }
    }
  }
  
  public void setEnableBackgroundDrawing(boolean llllllllllllllIlIlIIIIIIlllIIIIl)
  {
    ;
    ;
    enableBackgroundDrawing = llllllllllllllIlIlIIIIIIlllIIIIl;
  }
  
  public void writeText(String llllllllllllllIlIlIIIIIllIlllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    String llllllllllllllIlIlIIIIIllIlllIII = lIIIlIIIlIIIl[lIIIlIIlIllll[2]];
    String llllllllllllllIlIlIIIIIllIllIlll = ChatAllowedCharacters.filterAllowedCharacters(llllllllllllllIlIlIIIIIllIlllIIl);
    if (llIlIIlIIIlIII(cursorPosition, selectionEnd))
    {
      "".length();
      if (null == null) {
        break label48;
      }
    }
    label48:
    int llllllllllllllIlIlIIIIIllIllIllI = selectionEnd;
    if (llIlIIlIIIlIII(cursorPosition, selectionEnd))
    {
      "".length();
      if ("  ".length() < (0xB4 ^ 0xB0)) {
        break label95;
      }
    }
    label95:
    int llllllllllllllIlIlIIIIIllIllIlIl = cursorPosition;
    int llllllllllllllIlIlIIIIIllIllIlII = maxStringLength - text.length() - (llllllllllllllIlIlIIIIIllIllIllI - llllllllllllllIlIlIIIIIllIllIlIl);
    int llllllllllllllIlIlIIIIIllIllIIll = lIIIlIIlIllll[0];
    if (llIlIIlIIIlIlI(text.length())) {
      llllllllllllllIlIlIIIIIllIlllIII = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlIlIIIIIllIlllIII)).append(text.substring(lIIIlIIlIllll[0], llllllllllllllIlIlIIIIIllIllIllI)));
    }
    if (llIlIIlIIIlIII(llllllllllllllIlIlIIIIIllIllIlII, llllllllllllllIlIlIIIIIllIllIlll.length()))
    {
      llllllllllllllIlIlIIIIIllIlllIII = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlIlIIIIIllIlllIII)).append(llllllllllllllIlIlIIIIIllIllIlll.substring(lIIIlIIlIllll[0], llllllllllllllIlIlIIIIIllIllIlII)));
      llllllllllllllIlIlIIIIIllIllIIll = llllllllllllllIlIlIIIIIllIllIlII;
      "".length();
      if ("  ".length() > -" ".length()) {}
    }
    else
    {
      llllllllllllllIlIlIIIIIllIlllIII = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlIlIIIIIllIlllIII)).append(llllllllllllllIlIlIIIIIllIllIlll));
      llllllllllllllIlIlIIIIIllIllIIll = llllllllllllllIlIlIIIIIllIllIlll.length();
    }
    if ((llIlIIlIIIlIlI(text.length())) && (llIlIIlIIIlIII(llllllllllllllIlIlIIIIIllIllIlIl, text.length()))) {
      llllllllllllllIlIlIIIIIllIlllIII = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlIlIIIIIllIlllIII)).append(text.substring(llllllllllllllIlIlIIIIIllIllIlIl)));
    }
    if (llIlIIlIIIIllI(field_175209_y.apply(llllllllllllllIlIlIIIIIllIlllIII)))
    {
      text = llllllllllllllIlIlIIIIIllIlllIII;
      llllllllllllllIlIlIIIIIllIllIIlI.moveCursorBy(llllllllllllllIlIlIIIIIllIllIllI - selectionEnd + llllllllllllllIlIlIIIIIllIllIIll);
      if (llIlIIlIIIllII(field_175210_x)) {
        field_175210_x.func_175319_a(id, text);
      }
    }
  }
  
  public void setFocused(boolean llllllllllllllIlIlIIIIIIllIIllIl)
  {
    ;
    ;
    if ((llIlIIlIIIIllI(llllllllllllllIlIlIIIIIIllIIllIl)) && (llIlIIlIIlIIIl(isFocused))) {
      cursorCounter = lIIIlIIlIllll[0];
    }
    isFocused = llllllllllllllIlIlIIIIIIllIIllIl;
  }
  
  public int func_146197_a(int llllllllllllllIlIlIIIIIlIllIllIl, int llllllllllllllIlIlIIIIIlIllIllII, boolean llllllllllllllIlIlIIIIIlIllIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIlIIIIIlIlllIIll = llllllllllllllIlIlIIIIIlIllIllII;
    if (llIlIIlIIIllll(llllllllllllllIlIlIIIIIlIllIllIl))
    {
      "".length();
      if (((0xCB ^ 0x90 ^ 0xB0 ^ 0xBC) & (0x34 ^ 0x3E ^ 0x1A ^ 0x47 ^ -" ".length())) <= ((0x2B ^ 0x75 ^ 0x7 ^ 0x72) & ('' + 74 - 92 + 54 ^ 48 + 102 - 41 + 44 ^ -" ".length()))) {
        break label154;
      }
      return (0x27 ^ 0x4F ^ 0xEC ^ 0x9D) & ('' + 121 - 156 + 47 ^ 72 + '' - 81 + 17 ^ -" ".length());
    }
    label154:
    boolean llllllllllllllIlIlIIIIIlIlllIIlI = lIIIlIIlIllll[0];
    int llllllllllllllIlIlIIIIIlIlllIIIl = Math.abs(llllllllllllllIlIlIIIIIlIllIllIl);
    int llllllllllllllIlIlIIIIIlIlllIIII = lIIIlIIlIllll[0];
    "".length();
    if (-" ".length() > 0) {
      return (0x10 ^ 0x17) & (0x71 ^ 0x76 ^ 0xFFFFFFFF);
    }
    while (!llIlIIlIIlIIll(llllllllllllllIlIlIIIIIlIlllIIII, llllllllllllllIlIlIIIIIlIlllIIIl))
    {
      if (llIlIIlIIlIIIl(llllllllllllllIlIlIIIIIlIlllIIlI))
      {
        int llllllllllllllIlIlIIIIIlIllIllll = text.length();
        llllllllllllllIlIlIIIIIlIlllIIll = text.indexOf(lIIIlIIlIllll[1], llllllllllllllIlIlIIIIIlIlllIIll);
        if (llIlIIlIIlIIlI(llllllllllllllIlIlIIIIIlIlllIIll, lIIIlIIlIllll[8]))
        {
          llllllllllllllIlIlIIIIIlIlllIIll = llllllllllllllIlIlIIIIIlIllIllll;
          "".length();
          if ((105 + 21 - 41 + 68 ^ 25 + '' - 49 + 27) == 0) {
            return (0xE6 ^ 0xA9 ^ 0x10 ^ 0xD) & (96 + 110 - 111 + 32 ^ 0xC ^ 0x21 ^ -" ".length());
          }
        }
        else
        {
          do
          {
            llllllllllllllIlIlIIIIIlIlllIIll++;
            if ((!llIlIIlIIIIllI(llllllllllllllIlIlIIIIIlIllIlIll)) || (!llIlIIlIIIlIII(llllllllllllllIlIlIIIIIlIlllIIll, llllllllllllllIlIlIIIIIlIllIllll))) {
              break;
            }
          } while (!llIlIIlIIIlllI(text.charAt(llllllllllllllIlIlIIIIIlIlllIIll), lIIIlIIlIllll[1]));
          "".length();
          if (((0x33 ^ 0x1F) & (0x83 ^ 0xAF ^ 0xFFFFFFFF)) < 0) {
            return (0x20 ^ 0x17) & (0x89 ^ 0xBE ^ 0xFFFFFFFF);
          }
        }
      }
      else
      {
        do
        {
          llllllllllllllIlIlIIIIIlIlllIIll--;
          if ((!llIlIIlIIIIllI(llllllllllllllIlIlIIIIIlIllIlIll)) || (!llIlIIlIIIlIlI(llllllllllllllIlIlIIIIIlIlllIIll))) {
            break;
          }
        } while (!llIlIIlIIIlllI(text.charAt(llllllllllllllIlIlIIIIIlIlllIIll - lIIIlIIlIllll[2]), lIIIlIIlIllll[1]));
        "".length();
        if (null != null) {
          return (0xCC ^ 0x97) & (0x41 ^ 0x1A ^ 0xFFFFFFFF);
        }
        while ((llIlIIlIIIlIlI(llllllllllllllIlIlIIIIIlIlllIIll)) && (!llIlIIlIIlIIlI(text.charAt(llllllllllllllIlIlIIIIIlIlllIIll - lIIIlIIlIllll[2]), lIIIlIIlIllll[1]))) {
          llllllllllllllIlIlIIIIIlIlllIIll--;
        }
      }
      llllllllllllllIlIlIIIIIlIlllIIII++;
    }
    return llllllllllllllIlIlIIIIIlIlllIIll;
  }
  
  private static boolean llIlIIlIIIlIII(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIlIlIIIIIIIIlIIlII;
    return ??? < i;
  }
  
  public GuiTextField(int llllllllllllllIlIlIIIIIlllllIIII, FontRenderer llllllllllllllIlIlIIIIIllllIlIII, int llllllllllllllIlIlIIIIIllllIIlll, int llllllllllllllIlIlIIIIIllllIIllI, int llllllllllllllIlIlIIIIIllllIIlIl, int llllllllllllllIlIlIIIIIllllIlIll)
  {
    id = llllllllllllllIlIlIIIIIlllllIIII;
    fontRendererInstance = llllllllllllllIlIlIIIIIllllIlIII;
    xPosition = llllllllllllllIlIlIIIIIllllIlllI;
    yPosition = llllllllllllllIlIlIIIIIllllIIllI;
    width = llllllllllllllIlIlIIIIIllllIIlIl;
    height = llllllllllllllIlIlIIIIIllllIlIll;
  }
  
  public int getCursorPosition()
  {
    ;
    return cursorPosition;
  }
  
  private static boolean llIlIIlIIlIIII(int ???)
  {
    short llllllllllllllIlIlIIIIIIIIIlIlII;
    return ??? >= 0;
  }
  
  private static String llIlIIIIlIIllI(String llllllllllllllIlIlIIIIIIIIllllIl, String llllllllllllllIlIlIIIIIIIIllllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIlIIIIIIIIllllIl = new String(Base64.getDecoder().decode(llllllllllllllIlIlIIIIIIIIllllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIlIIIIIIIIlllIll = new StringBuilder();
    char[] llllllllllllllIlIlIIIIIIIIlllIlI = llllllllllllllIlIlIIIIIIIIllllII.toCharArray();
    int llllllllllllllIlIlIIIIIIIIlllIIl = lIIIlIIlIllll[0];
    short llllllllllllllIlIlIIIIIIIIllIIll = llllllllllllllIlIlIIIIIIIIllllIl.toCharArray();
    float llllllllllllllIlIlIIIIIIIIllIIlI = llllllllllllllIlIlIIIIIIIIllIIll.length;
    byte llllllllllllllIlIlIIIIIIIIllIIIl = lIIIlIIlIllll[0];
    while (llIlIIlIIIlIII(llllllllllllllIlIlIIIIIIIIllIIIl, llllllllllllllIlIlIIIIIIIIllIIlI))
    {
      char llllllllllllllIlIlIIIIIIIIlllllI = llllllllllllllIlIlIIIIIIIIllIIll[llllllllllllllIlIlIIIIIIIIllIIIl];
      "".length();
      "".length();
      if ((0xA ^ 0xE) == 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIlIIIIIIIIlllIll);
  }
  
  public void setSelectionPos(int llllllllllllllIlIlIIIIIIlIllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIlIIIIIIlIllIIII = text.length();
    if (llIlIIlIIIIlll(llllllllllllllIlIlIIIIIIlIllIIIl, llllllllllllllIlIlIIIIIIlIllIIII)) {
      llllllllllllllIlIlIIIIIIlIllIIIl = llllllllllllllIlIlIIIIIIlIllIIII;
    }
    if (llIlIIlIIIllll(llllllllllllllIlIlIIIIIIlIllIIIl)) {
      llllllllllllllIlIlIIIIIIlIllIIIl = lIIIlIIlIllll[0];
    }
    selectionEnd = llllllllllllllIlIlIIIIIIlIllIIIl;
    if (llIlIIlIIIllII(fontRendererInstance))
    {
      if (llIlIIlIIIIlll(lineScrollOffset, llllllllllllllIlIlIIIIIIlIllIIII)) {
        lineScrollOffset = llllllllllllllIlIlIIIIIIlIllIIII;
      }
      int llllllllllllllIlIlIIIIIIlIlIllll = llllllllllllllIlIlIIIIIIlIllIIlI.getWidth();
      String llllllllllllllIlIlIIIIIIlIlIlllI = fontRendererInstance.trimStringToWidth(text.substring(lineScrollOffset), llllllllllllllIlIlIIIIIIlIlIllll);
      int llllllllllllllIlIlIIIIIIlIlIllIl = llllllllllllllIlIlIIIIIIlIlIlllI.length() + lineScrollOffset;
      if (llIlIIlIIlIIlI(llllllllllllllIlIlIIIIIIlIllIIIl, lineScrollOffset)) {
        lineScrollOffset -= fontRendererInstance.trimStringToWidth(text, llllllllllllllIlIlIIIIIIlIlIllll, lIIIlIIlIllll[2]).length();
      }
      if (llIlIIlIIIIlll(llllllllllllllIlIlIIIIIIlIllIIIl, llllllllllllllIlIlIIIIIIlIlIllIl))
      {
        lineScrollOffset += llllllllllllllIlIlIIIIIIlIllIIIl - llllllllllllllIlIlIIIIIIlIlIllIl;
        "".length();
        if (-" ".length() < 0) {}
      }
      else if (llIlIIlIIlIlII(llllllllllllllIlIlIIIIIIlIllIIIl, lineScrollOffset))
      {
        lineScrollOffset -= lineScrollOffset - llllllllllllllIlIlIIIIIIlIllIIIl;
      }
      lineScrollOffset = MathHelper.clamp_int(lineScrollOffset, lIIIlIIlIllll[0], llllllllllllllIlIlIIIIIIlIllIIII);
    }
  }
  
  public void setEnabled(boolean llllllllllllllIlIlIIIIIIllIIIllI)
  {
    ;
    ;
    isEnabled = llllllllllllllIlIlIIIIIIllIIIllI;
  }
}

package net.minecraft.client.gui;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.stream.GuiTwitchUserMode;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.stream.IStream;
import net.minecraft.event.ClickEvent;
import net.minecraft.event.ClickEvent.Action;
import net.minecraft.event.HoverEvent;
import net.minecraft.event.HoverEvent.Action;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.JsonToNBT;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTException;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.stats.Achievement;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatList;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.ChatStyle;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ResourceLocation;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import tv.twitch.chat.ChatUserInfo;

public abstract class GuiScreen
  extends Gui
  implements GuiYesNoCallback
{
  static
  {
    lIIIIIIlllIlll();
    lIIIIIIllIllII();
    LOGGER = LogManager.getLogger();
  }
  
  private static boolean lIIIIIIlllllII(int ???)
  {
    Exception lllllllllllllllIlIIIlIIlIIlIIIIl;
    return ??? != 0;
  }
  
  private static String lIIIIIIlIlllll(String lllllllllllllllIlIIIlIIlIllIIlIl, String lllllllllllllllIlIIIlIIlIllIIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIIIlIIlIllIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIIIlIIlIllIIlII.getBytes(StandardCharsets.UTF_8)), lIlIIlllIllI[5]), "DES");
      Cipher lllllllllllllllIlIIIlIIlIllIIlll = Cipher.getInstance("DES");
      lllllllllllllllIlIIIlIIlIllIIlll.init(lIlIIlllIllI[0], lllllllllllllllIlIIIlIIlIllIlIII);
      return new String(lllllllllllllllIlIIIlIIlIllIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIIIlIIlIllIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIIIlIIlIllIIllI)
    {
      lllllllllllllllIlIIIlIIlIllIIllI.printStackTrace();
    }
    return null;
  }
  
  public static boolean isKeyComboCtrlX(int lllllllllllllllIlIIIlIIllIIIIIll)
  {
    ;
    if ((lIIIIIIllllIIl(lllllllllllllllIlIIIlIIllIIIIIll, lIlIIlllIllI[45])) && (lIIIIIIlllllII(isCtrlKeyDown())) && (lIIIIIIlllllIl(isShiftKeyDown())) && (lIIIIIIlllllIl(isAltKeyDown()))) {
      return lIlIIlllIllI[2];
    }
    return lIlIIlllIllI[1];
  }
  
  public void setWorldAndResolution(Minecraft lllllllllllllllIlIIIlIIlllIIIlIl, int lllllllllllllllIlIIIlIIlllIIIIII, int lllllllllllllllIlIIIlIIlllIIIIll)
  {
    ;
    ;
    ;
    ;
    mc = lllllllllllllllIlIIIlIIlllIIIlIl;
    itemRender = lllllllllllllllIlIIIlIIlllIIIlIl.getRenderItem();
    fontRendererObj = Minecraft.fontRendererObj;
    width = lllllllllllllllIlIIIlIIlllIIIIII;
    height = lllllllllllllllIlIIIlIIlllIIIIll;
    buttonList.clear();
    lllllllllllllllIlIIIlIIlllIIIIlI.initGui();
  }
  
  protected boolean handleComponentClick(IChatComponent lllllllllllllllIlIIIlIlIIIIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIIIIIllllIlI(lllllllllllllllIlIIIlIlIIIIIIIlI)) {
      return lIlIIlllIllI[1];
    }
    ClickEvent lllllllllllllllIlIIIlIlIIIIIlIIl = lllllllllllllllIlIIIlIlIIIIIIIlI.getChatStyle().getChatClickEvent();
    if (lIIIIIIlllllII(isShiftKeyDown()))
    {
      if (lIIIIIIllllIll(lllllllllllllllIlIIIlIlIIIIIIIlI.getChatStyle().getInsertion()))
      {
        lllllllllllllllIlIIIlIlIIIIIlIll.setText(lllllllllllllllIlIIIlIlIIIIIIIlI.getChatStyle().getInsertion(), lIlIIlllIllI[1]);
        "".length();
        if (null != null) {
          return " ".length() & (" ".length() ^ 0xFFFFFFFF);
        }
      }
    }
    else if (lIIIIIIllllIll(lllllllllllllllIlIIIlIlIIIIIlIIl))
    {
      if (lIIIIIlIIIIIIl(lllllllllllllllIlIIIlIlIIIIIlIIl.getAction(), ClickEvent.Action.OPEN_URL))
      {
        if (lIIIIIIlllllIl(mc.gameSettings.chatLinks)) {
          return lIlIIlllIllI[1];
        }
        try
        {
          URI lllllllllllllllIlIIIlIlIIIIIlIII = new URI(lllllllllllllllIlIIIlIlIIIIIlIIl.getValue());
          String lllllllllllllllIlIIIlIlIIIIIIlll = lllllllllllllllIlIIIlIlIIIIIlIII.getScheme();
          if (lIIIIIIllllIlI(lllllllllllllllIlIIIlIlIIIIIIlll)) {
            throw new URISyntaxException(lllllllllllllllIlIIIlIlIIIIIlIIl.getValue(), lIlIIlllIlII[lIlIIlllIllI[24]]);
          }
          if (lIIIIIIlllllIl(PROTOCOLS.contains(lllllllllllllllIlIIIlIlIIIIIIlll.toLowerCase()))) {
            throw new URISyntaxException(lllllllllllllllIlIIIlIlIIIIIlIIl.getValue(), String.valueOf(new StringBuilder(lIlIIlllIlII[lIlIIlllIllI[25]]).append(lllllllllllllllIlIIIlIlIIIIIIlll.toLowerCase())));
          }
          if (lIIIIIIlllllII(mc.gameSettings.chatLinksPrompt))
          {
            clickedLinkURI = lllllllllllllllIlIIIlIlIIIIIlIII;
            mc.displayGuiScreen(new GuiConfirmOpenLink(lllllllllllllllIlIIIlIlIIIIIlIll, lllllllllllllllIlIIIlIlIIIIIlIIl.getValue(), lIlIIlllIllI[26], lIlIIlllIllI[1]));
            "".length();
            if (null == null) {
              break label941;
            }
            return ('Â' + 110 - 103 + 54 ^ '«' + 47 - 43 + 8) & ('' + '' - 110 + 25 ^ 120 + 66 - 162 + 116 ^ -" ".length());
          }
          lllllllllllllllIlIIIlIlIIIIIlIll.openWebLink(lllllllllllllllIlIIIlIlIIIIIlIII);
          "".length();
          if (" ".length() >= 0) {
            break label941;
          }
          return (38 + 95 - 16 + 39 ^ 52 + 35 - 56 + 120) & (114 + '' - 141 + 51 ^ 5 + 45 - 28 + 141 ^ -" ".length());
        }
        catch (URISyntaxException lllllllllllllllIlIIIlIlIIIIIIllI)
        {
          LOGGER.error(String.valueOf(new StringBuilder(lIlIIlllIlII[lIlIIlllIllI[27]]).append(lllllllllllllllIlIIIlIlIIIIIlIIl)), lllllllllllllllIlIIIlIlIIIIIIllI);
          "".length();
          if ("  ".length() > ((0x7D ^ 0x70) & (0x10 ^ 0x1D ^ 0xFFFFFFFF))) {
            break label941;
          }
        }
        return (0x1B ^ 0x4B) & (0x16 ^ 0x46 ^ 0xFFFFFFFF);
      }
      else if (lIIIIIlIIIIIIl(lllllllllllllllIlIIIlIlIIIIIlIIl.getAction(), ClickEvent.Action.OPEN_FILE))
      {
        URI lllllllllllllllIlIIIlIlIIIIIIlIl = new File(lllllllllllllllIlIIIlIlIIIIIlIIl.getValue()).toURI();
        lllllllllllllllIlIIIlIlIIIIIlIll.openWebLink(lllllllllllllllIlIIIlIlIIIIIIlIl);
        "".length();
        if (((0x52 ^ 0x6E) & (0x30 ^ 0xC ^ 0xFFFFFFFF)) < -" ".length()) {
          return (0x64 ^ 0x60) & (0x6F ^ 0x6B ^ 0xFFFFFFFF);
        }
      }
      else if (lIIIIIlIIIIIIl(lllllllllllllllIlIIIlIlIIIIIlIIl.getAction(), ClickEvent.Action.SUGGEST_COMMAND))
      {
        lllllllllllllllIlIIIlIlIIIIIlIll.setText(lllllllllllllllIlIIIlIlIIIIIlIIl.getValue(), lIlIIlllIllI[2]);
        "".length();
        if ("  ".length() == "   ".length()) {
          return " ".length() & (" ".length() ^ -" ".length());
        }
      }
      else if (lIIIIIlIIIIIIl(lllllllllllllllIlIIIlIlIIIIIlIIl.getAction(), ClickEvent.Action.RUN_COMMAND))
      {
        lllllllllllllllIlIIIlIlIIIIIlIll.sendChatMessage(lllllllllllllllIlIIIlIlIIIIIlIIl.getValue(), lIlIIlllIllI[1]);
        "".length();
        if ("   ".length() < 0) {
          return (91 + 7 - 62 + 110 ^ 53 + 62 - 102 + 136) & (8 + 56 - 2 + 133 ^ 70 + 28 - 3 + 101 ^ -" ".length());
        }
      }
      else if (lIIIIIlIIIIIIl(lllllllllllllllIlIIIlIlIIIIIlIIl.getAction(), ClickEvent.Action.TWITCH_USER_INFO))
      {
        ChatUserInfo lllllllllllllllIlIIIlIlIIIIIIlII = mc.getTwitchStream().func_152926_a(lllllllllllllllIlIIIlIlIIIIIlIIl.getValue());
        if (lIIIIIIllllIll(lllllllllllllllIlIIIlIlIIIIIIlII))
        {
          mc.displayGuiScreen(new GuiTwitchUserMode(mc.getTwitchStream(), lllllllllllllllIlIIIlIlIIIIIIlII));
          "".length();
          if (" ".length() == (0x3D ^ 0x39)) {
            return (0x80 ^ 0xA0) & (0x5A ^ 0x7A ^ 0xFFFFFFFF);
          }
        }
        else
        {
          LOGGER.error(lIlIIlllIlII[lIlIIlllIllI[28]]);
          "".length();
          if (" ".length() <= 0) {
            return (0x17 ^ 0x4A) & (0x5B ^ 0x6 ^ 0xFFFFFFFF);
          }
        }
      }
      else
      {
        LOGGER.error(String.valueOf(new StringBuilder(lIlIIlllIlII[lIlIIlllIllI[29]]).append(lllllllllllllllIlIIIlIlIIIIIlIIl)));
      }
      label941:
      return lIlIIlllIllI[2];
    }
    return lIlIIlllIllI[1];
  }
  
  public void drawDefaultBackground()
  {
    ;
    lllllllllllllllIlIIIlIIllIlIIlIl.drawWorldBackground(lIlIIlllIllI[1]);
  }
  
  private static String lIIIIIIllIIlII(String lllllllllllllllIlIIIlIIlIIlllllI, String lllllllllllllllIlIIIlIIlIIllllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIIIlIIlIlIIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIIIlIIlIIllllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlIIIlIIlIlIIIIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlIIIlIIlIlIIIIlI.init(lIlIIlllIllI[0], lllllllllllllllIlIIIlIIlIlIIIIll);
      return new String(lllllllllllllllIlIIIlIIlIlIIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIIIlIIlIIlllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIIIlIIlIlIIIIIl)
    {
      lllllllllllllllIlIIIlIIlIlIIIIIl.printStackTrace();
    }
    return null;
  }
  
  protected void setText(String lllllllllllllllIlIIIlIlIIIIlIIlI, boolean lllllllllllllllIlIIIlIlIIIIlIIIl) {}
  
  public static String getClipboardString()
  {
    try
    {
      ;
      Transferable lllllllllllllllIlIIIlIlIlIIIIlll = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
      if ((lIIIIIIllllIll(lllllllllllllllIlIIIlIlIlIIIIlll)) && (lIIIIIIlllllII(lllllllllllllllIlIIIlIlIlIIIIlll.isDataFlavorSupported(DataFlavor.stringFlavor)))) {
        return (String)lllllllllllllllIlIIIlIlIlIIIIlll.getTransferData(DataFlavor.stringFlavor);
      }
    }
    catch (Exception localException) {}
    return lIlIIlllIlII[lIlIIlllIllI[0]];
  }
  
  public static boolean isKeyComboCtrlC(int lllllllllllllllIlIIIlIIlIlllllII)
  {
    ;
    if ((lIIIIIIllllIIl(lllllllllllllllIlIIIlIIlIlllllII, lIlIIlllIllI[47])) && (lIIIIIIlllllII(isCtrlKeyDown())) && (lIIIIIIlllllIl(isShiftKeyDown())) && (lIIIIIIlllllIl(isAltKeyDown()))) {
      return lIlIIlllIllI[2];
    }
    return lIlIIlllIllI[1];
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllIlIIIlIIlllIIlIll)
    throws IOException
  {}
  
  protected void mouseClickMove(int lllllllllllllllIlIIIlIIlllIlIIII, int lllllllllllllllIlIIIlIIlllIIllll, int lllllllllllllllIlIIIlIIlllIIlllI, long lllllllllllllllIlIIIlIIlllIIllIl) {}
  
  public static boolean isCtrlKeyDown()
  {
    if (lIIIIIIlllllII(Minecraft.isRunningOnMac))
    {
      if ((lIIIIIIlllllIl(Keyboard.isKeyDown(lIlIIlllIllI[37]))) && (lIIIIIIlllllIl(Keyboard.isKeyDown(lIlIIlllIllI[38]))))
      {
        "".length();
        if (((0x20 ^ 0x33 ^ 0x38 ^ 0x14) & ('' + 62 - 88 + 48 ^ 32 + 104 - 30 + 54 ^ -" ".length())) < 0) {
          return ('ø' + 'ä' - 405 + 179 ^ 113 + 116 - 205 + 128) & (0x69 ^ 0x7B ^ 0x47 ^ 0x37 ^ -" ".length());
        }
      }
      else
      {
        "".length();
        if (-" ".length() > 0) {
          return (0xD8 ^ 0x9F) & (0x40 ^ 0x7 ^ 0xFFFFFFFF);
        }
      }
    }
    else if ((lIIIIIIlllllIl(Keyboard.isKeyDown(lIlIIlllIllI[39]))) && (lIIIIIIlllllIl(Keyboard.isKeyDown(lIlIIlllIllI[40]))))
    {
      "".length();
      if (((0x43 ^ 0x5 ^ 0x3 ^ 0x6C) & ('é' + 87 - 247 + 162 ^ '©' + 48 - 150 + 127 ^ -" ".length())) <= 0) {
        break label347;
      }
      return (92 + '' - 205 + 149 ^ 92 + '' - 213 + 144) & ('´' + '¼' - 248 + 78 ^ 12 + 57 - -21 + 74 ^ -" ".length());
    }
    label347:
    return lIlIIlllIllI[2];
  }
  
  private static boolean lIIIIIIllllIIl(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIlIIIlIIlIIllIlll;
    return ??? == i;
  }
  
  public void confirmClicked(boolean lllllllllllllllIlIIIlIIllIIlIlII, int lllllllllllllllIlIIIlIIllIIlIIll)
  {
    ;
    ;
    ;
    if (lIIIIIIllllIIl(lllllllllllllllIlIIIlIIllIIlIIll, lIlIIlllIllI[26]))
    {
      if (lIIIIIIlllllII(lllllllllllllllIlIIIlIIllIIlIIIl)) {
        lllllllllllllllIlIIIlIIllIIlIIlI.openWebLink(clickedLinkURI);
      }
      clickedLinkURI = null;
      mc.displayGuiScreen(lllllllllllllllIlIIIlIIllIIlIIlI);
    }
  }
  
  public GuiScreen() {}
  
  public boolean doesGuiPauseGame()
  {
    return lIlIIlllIllI[2];
  }
  
  public static boolean isAltKeyDown()
  {
    if ((lIIIIIIlllllIl(Keyboard.isKeyDown(lIlIIlllIllI[43]))) && (lIIIIIIlllllIl(Keyboard.isKeyDown(lIlIIlllIllI[44])))) {
      return lIlIIlllIllI[1];
    }
    return lIlIIlllIllI[2];
  }
  
  private static boolean lIIIIIIllllIlI(Object ???)
  {
    double lllllllllllllllIlIIIlIIlIIlIIIll;
    return ??? == null;
  }
  
  protected void keyTyped(char lllllllllllllllIlIIIlIlIlIIIllII, int lllllllllllllllIlIIIlIlIlIIIlIIl)
    throws IOException
  {
    ;
    ;
    if (lIIIIIIllllIIl(lllllllllllllllIlIIIlIlIlIIIlIIl, lIlIIlllIllI[2]))
    {
      mc.displayGuiScreen(null);
      if (lIIIIIIllllIlI(mc.currentScreen)) {
        mc.setIngameFocus();
      }
    }
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIlIIIlIIllIllIlII = Mouse.getEventX() * width / mc.displayWidth;
    int lllllllllllllllIlIIIlIIllIllIIll = height - Mouse.getEventY() * height / mc.displayHeight - lIlIIlllIllI[2];
    int lllllllllllllllIlIIIlIIllIllIIlI = Mouse.getEventButton();
    if (lIIIIIIlllllII(Mouse.getEventButtonState()))
    {
      if (lIIIIIIlllllII(mc.gameSettings.touchscreen))
      {
        int tmp79_76 = touchValue;
        touchValue = (tmp79_76 + lIlIIlllIllI[2]);
        if (lIIIIIlIIIIlII(tmp79_76)) {
          return;
        }
      }
      eventButton = lllllllllllllllIlIIIlIIllIllIIlI;
      lastMouseEvent = Minecraft.getSystemTime();
      lllllllllllllllIlIIIlIIllIllIlIl.mouseClicked(lllllllllllllllIlIIIlIIllIllIlII, lllllllllllllllIlIIIlIIllIllIIll, eventButton);
      "".length();
      if ("   ".length() >= 0) {}
    }
    else if (lIIIIIlIIIIlIl(lllllllllllllllIlIIIlIIllIllIIlI, lIlIIlllIllI[14]))
    {
      if ((lIIIIIIlllllII(mc.gameSettings.touchscreen)) && (lIIIIIlIIIIlII(lllllllllllllllIlIIIlIIllIllIlIl.touchValue -= lIlIIlllIllI[2]))) {
        return;
      }
      eventButton = lIlIIlllIllI[14];
      lllllllllllllllIlIIIlIIllIllIlIl.mouseReleased(lllllllllllllllIlIIIlIIllIllIlII, lllllllllllllllIlIIIlIIllIllIIll, lllllllllllllllIlIIIlIIllIllIIlI);
      "".length();
      if ("  ".length() < "   ".length()) {}
    }
    else if ((lIIIIIlIIIIlIl(eventButton, lIlIIlllIllI[14])) && (lIIIIIlIIIIlII(lIIIIIlIIIIIll(lastMouseEvent, 0L))))
    {
      long lllllllllllllllIlIIIlIIllIllIIIl = Minecraft.getSystemTime() - lastMouseEvent;
      lllllllllllllllIlIIIlIIllIllIlIl.mouseClickMove(lllllllllllllllIlIIIlIIllIllIlII, lllllllllllllllIlIIIlIIllIllIIll, eventButton, lllllllllllllllIlIIIlIIllIllIIIl);
    }
  }
  
  public static boolean isShiftKeyDown()
  {
    if ((lIIIIIIlllllIl(Keyboard.isKeyDown(lIlIIlllIllI[41]))) && (lIIIIIIlllllIl(Keyboard.isKeyDown(lIlIIlllIllI[42])))) {
      return lIlIIlllIllI[1];
    }
    return lIlIIlllIllI[2];
  }
  
  private static int lIIIIIlIIIIIll(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  public void onResize(Minecraft lllllllllllllllIlIIIlIIlIlllIIll, int lllllllllllllllIlIIIlIIlIllIlllI, int lllllllllllllllIlIIIlIIlIlllIIIl)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIlIIIlIIlIlllIlII.setWorldAndResolution(lllllllllllllllIlIIIlIIlIlllIIll, lllllllllllllllIlIIIlIIlIllIlllI, lllllllllllllllIlIIIlIIlIlllIIIl);
  }
  
  public static void setClipboardString(String lllllllllllllllIlIIIlIlIlIIIIIll)
  {
    ;
    ;
    if (lIIIIIIlllllIl(StringUtils.isEmpty(lllllllllllllllIlIIIlIlIlIIIIIll))) {
      try
      {
        StringSelection lllllllllllllllIlIIIlIlIlIIIIIlI = new StringSelection(lllllllllllllllIlIIIlIlIlIIIIIIl);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(lllllllllllllllIlIIIlIlIlIIIIIlI, null);
        "".length();
        if (-" ".length() > 0) {}
      }
      catch (Exception localException) {}
    }
  }
  
  private static void lIIIIIIllIllII()
  {
    lIlIIlllIlII = new String[lIlIIlllIllI[49]];
    lIlIIlllIlII[lIlIIlllIllI[1]] = lIIIIIIlIllllI("DxYnPw==", "gbSOh");
    lIlIIlllIlII[lIlIIlllIllI[2]] = lIIIIIIlIllllI("AichND0=", "jSUDN");
    lIlIIlllIlII[lIlIIlllIllI[0]] = lIIIIIIlIlllll("b/Cdgq2QFps=", "brend");
    lIlIIlllIlII[lIlIIlllIllI[9]] = lIIIIIIlIllllI("GR0jEzw5F3U7JDUedA==", "PsUrP");
    lIlIIlllIlII[lIlIIlllIllI[10]] = lIIIIIIllIIlII("lNppm+Da1Eo=", "AjVEc");
    lIlIIlllIlII[lIlIIlllIllI[15]] = lIIIIIIlIllllI("PwkGCQ==", "KpvlS");
    lIlIIlllIlII[lIlIIlllIllI[7]] = lIIIIIIlIlllll("o4N+NyNRMLg=", "OeJKf");
    lIlIIlllIlII[lIlIIlllIllI[16]] = lIIIIIIlIlllll("K7QgnPZy3SI=", "XGGNe");
    lIlIIlllIlII[lIlIIlllIllI[5]] = lIIIIIIllIIlII("imm+oEiM48s=", "WzXWo");
    lIlIIlllIlII[lIlIIlllIllI[17]] = lIIIIIIlIllllI("eA==", "QjsRr");
    lIlIIlllIlII[lIlIIlllIllI[3]] = lIIIIIIlIlllll("aIQhkgyaTGU=", "Rlwux");
    lIlIIlllIlII[lIlIIlllIllI[18]] = lIIIIIIlIllllI("MD4fKjYQNEkONA05HTJ7", "yPiKZ");
    lIlIIlllIlII[lIlIIlllIllI[4]] = lIIIIIIlIllllI("BjofJwomMEkDCDs9HT9H", "OTiFf");
    lIlIIlllIlII[lIlIIlllIllI[19]] = lIIIIIIlIllllI("GicYMj5HJxYpIR06CWg5ECMcaA==", "iSyFM");
    lIlIIlllIlII[lIlIIlllIllI[20]] = lIIIIIIllIIlII("0bvRwnV0nMsyMpVg0F6rSw==", "uQPay");
    lIlIIlllIlII[lIlIIlllIllI[21]] = lIIIIIIlIllllI("BBgIEx8EGAAE", "wligv");
    lIlIIlllIlII[lIlIIlllIllI[23]] = lIIIIIIllIIlII("Bp1WeboSabDoxuNWGy+zRzgatCCAS15TKsGd+4FiQ8w=", "gSfGT");
    lIlIIlllIlII[lIlIIlllIllI[24]] = lIIIIIIlIlllll("oRtPqYqg6zhlOiFgzJ7bmZzim14vdIbM", "oJZqO");
    lIlIIlllIlII[lIlIIlllIllI[25]] = lIIIIIIllIIlII("T5fcD0TREgkiZCS6qMOXeAzzTNCx1MjF", "sXYTf");
    lIlIIlllIlII[lIlIIlllIllI[27]] = lIIIIIIllIIlII("uH2nXqbKNhj/lO+hrO2+1zTWJ6fMTJT6", "vOgbb");
    lIlIIlllIlII[lIlIIlllIllI[28]] = lIIIIIIlIllllI("LDE+NhxYNzhzEBktMz8dWDcgOgwbK3cmCx0xdzENDGM0PA0UJzl0DFglPj0cWDc/NhVZ", "xCWSx");
    lIlIIlllIlII[lIlIIlllIllI[29]] = lIIIIIIllIIlII("O80JwaylP5AoS4NwlY54bN3GJcbwg95y1DZOt0RrAu0=", "wRMUx");
    lIlIIlllIlII[lIlIIlllIllI[32]] = lIIIIIIlIlllll("fdZRicLRHC1cFM05fNWqxI8/d9pWC2Q4Q+TmkwG+aZo=", "FWjLA");
    lIlIIlllIlII[lIlIIlllIllI[33]] = lIIIIIIlIllllI("Eik7BV4ZPzlKNB07JhAfCA==", "xHMdp");
    lIlIIlllIlII[lIlIIlllIllI[34]] = lIIIIIIlIllllI("FjMxBgsCPTEtHg==", "qVEBn");
    lIlIIlllIlII[lIlIIlllIllI[35]] = lIIIIIIllIIlII("xr+5eJcC4gg=", "GQjXg");
    lIlIIlllIlII[lIlIIlllIllI[36]] = lIIIIIIlIlllll("QUTvGKM2q/NY0+lmSpdjAbm9pSy7SNRs", "MOEmO");
  }
  
  private static boolean lIIIIIlIIIIlIl(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIlIIIlIIlIIIllIIl;
    return ??? != i;
  }
  
  public static boolean isKeyComboCtrlA(int lllllllllllllllIlIIIlIIlIllllIlI)
  {
    ;
    if ((lIIIIIIllllIIl(lllllllllllllllIlIIIlIIlIllllIlI, lIlIIlllIllI[48])) && (lIIIIIIlllllII(isCtrlKeyDown())) && (lIIIIIIlllllIl(isShiftKeyDown())) && (lIIIIIIlllllIl(isAltKeyDown()))) {
      return lIlIIlllIllI[2];
    }
    return lIlIIlllIllI[1];
  }
  
  public void initGui() {}
  
  public void sendChatMessage(String lllllllllllllllIlIIIlIIlllllIIIl, boolean lllllllllllllllIlIIIlIIlllllIIll)
  {
    ;
    ;
    ;
    if (lIIIIIIlllllII(lllllllllllllllIlIIIlIIlllllIIll)) {
      mc.ingameGUI.getChatGUI().addToSentMessages(lllllllllllllllIlIIIlIIlllllIlII);
    }
    mc.thePlayer.sendChatMessage(lllllllllllllllIlIIIlIIlllllIlII);
  }
  
  public static boolean isKeyComboCtrlV(int lllllllllllllllIlIIIlIIlIlllllll)
  {
    ;
    if ((lIIIIIIllllIIl(lllllllllllllllIlIIIlIIlIlllllll, lIlIIlllIllI[46])) && (lIIIIIIlllllII(isCtrlKeyDown())) && (lIIIIIIlllllIl(isShiftKeyDown())) && (lIIIIIIlllllIl(isAltKeyDown()))) {
      return lIlIIlllIllI[2];
    }
    return lIlIIlllIllI[1];
  }
  
  private static void lIIIIIIlllIlll()
  {
    lIlIIlllIllI = new int[50];
    lIlIIlllIllI[0] = "  ".length();
    lIlIIlllIllI[1] = (('ò' + 'ø' - 336 + 101 ^ 30 + 16 - -1 + 123) & (0xF1 ^ 0xAA ^ 0x29 ^ 0x27 ^ -" ".length()));
    lIlIIlllIllI[2] = " ".length();
    lIlIIlllIllI[3] = (4 + '' - 25 + 84 ^ 102 + '' - 224 + 188);
    lIlIIlllIllI[4] = (0x2 ^ 0xE);
    lIlIIlllIllI[5] = (0x48 ^ 0xD ^ 0x29 ^ 0x64);
    lIlIIlllIllI[6] = (0x85 ^ 0xAE ^ 0x64 ^ 0x53);
    lIlIIlllIllI[7] = (12 + 66 - -21 + 59 ^ 32 + 107 - 61 + 74);
    lIlIIlllIllI[8] = (-(-"   ".length() & 0xFFFFFFFA & 0xFEFFFF7));
    lIlIIlllIllI[9] = "   ".length();
    lIlIIlllIllI[10] = (0xA8 ^ 0xAC);
    lIlIIlllIllI[11] = (0xB2FF & 0x50504DFF);
    lIlIIlllIllI[12] = (-"  ".length() & 0xFFFFFFFF & 0xFEFEFF);
    lIlIIlllIllI[13] = (-(-(0x9D6F & 0x7696) & 0xD64F & 0x1003DB5));
    lIlIIlllIllI[14] = (-" ".length());
    lIlIIlllIllI[15] = (0x81 ^ 0x84);
    lIlIIlllIllI[16] = (0xE1 ^ 0xB7 ^ 0x6D ^ 0x3C);
    lIlIIlllIllI[17] = (0xF ^ 0x6);
    lIlIIlllIllI[18] = (0x13 ^ 0x18);
    lIlIIlllIllI[19] = (0xCF ^ 0xC2);
    lIlIIlllIllI[20] = (0xAE ^ 0xC4 ^ 0x4C ^ 0x28);
    lIlIIlllIllI[21] = (0xD2 ^ 0x8F ^ 0x68 ^ 0x3A);
    lIlIIlllIllI[22] = ((0x10 ^ 0x6C) + (0x6C ^ 0x4E) - (0x2D ^ 0x44) + (0x52 ^ 0x33));
    lIlIIlllIllI[23] = (7 + 125 - 120 + 129 ^ '' + 79 - 92 + 30);
    lIlIIlllIllI[24] = (0x6E ^ 0x7F);
    lIlIIlllIllI[25] = (0x3E ^ 0x2C);
    lIlIIlllIllI[26] = (0xBD3D & 0x1DAD6FB);
    lIlIIlllIllI[27] = ('' + '' - 141 + 33 ^ 37 + 12 - -62 + 61);
    lIlIIlllIllI[28] = (0x97 ^ 0x83);
    lIlIIlllIllI[29] = (0xA ^ 0x1F);
    lIlIIlllIllI[30] = (-(-(0xB34A & 0x5CBF) & 0xFFFFFFF9 & 0x3FEFFFFF));
    lIlIIlllIllI[31] = (-(0xEFF9 & 0x2FEFFFF6));
    lIlIIlllIllI[32] = (0x37 ^ 0x21);
    lIlIIlllIllI[33] = ((0x6D ^ 0x46) & (0x1 ^ 0x2A ^ 0xFFFFFFFF) ^ 0xBD ^ 0xAA);
    lIlIIlllIllI[34] = (0x24 ^ 0x3C);
    lIlIIlllIllI[35] = (0x1E ^ 0x7);
    lIlIIlllIllI[36] = (0xBC ^ 0x98 ^ 0x35 ^ 0xB);
    lIlIIlllIllI[37] = (77 + 27 - 21 + 136);
    lIlIIlllIllI[38] = ('­' + '' - 239 + 131);
    lIlIIlllIllI[39] = (0x19 ^ 0x4);
    lIlIIlllIllI[40] = (111 + '' - 166 + 76);
    lIlIIlllIllI[41] = ('Õ' + 37 - 94 + 80 ^ 58 + '©' - 125 + 96);
    lIlIIlllIllI[42] = (0x13 ^ 0x50 ^ 0x13 ^ 0x66);
    lIlIIlllIllI[43] = (0x4 ^ 0x3C);
    lIlIIlllIllI[44] = ('' + 97 - 126 + 83);
    lIlIIlllIllI[45] = (0xED ^ 0xC0);
    lIlIIlllIllI[46] = (0xEB ^ 0xC4);
    lIlIIlllIllI[47] = (0x63 ^ 0x1F ^ 0xD5 ^ 0x87);
    lIlIIlllIllI[48] = (97 + '¼' - 216 + 122 ^ 63 + 17 - -79 + 2);
    lIlIIlllIllI[49] = (0x29 ^ 0x4 ^ 0x67 ^ 0x51);
  }
  
  public void onGuiClosed() {}
  
  protected void handleComponentHover(IChatComponent lllllllllllllllIlIIIlIlIIIIlllII, int lllllllllllllllIlIIIlIlIIIIllIll, int lllllllllllllllIlIIIlIlIIIlIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIIIIIIllllIll(lllllllllllllllIlIIIlIlIIIIlllII)) && (lIIIIIIllllIll(lllllllllllllllIlIIIlIlIIIIlllII.getChatStyle().getChatHoverEvent())))
    {
      HoverEvent lllllllllllllllIlIIIlIlIIIlIlIlI = lllllllllllllllIlIIIlIlIIIIlllII.getChatStyle().getChatHoverEvent();
      if (lIIIIIlIIIIIIl(lllllllllllllllIlIIIlIlIIIlIlIlI.getAction(), HoverEvent.Action.SHOW_ITEM))
      {
        ItemStack lllllllllllllllIlIIIlIlIIIlIlIIl = null;
        try
        {
          NBTBase lllllllllllllllIlIIIlIlIIIlIlIII = JsonToNBT.getTagFromJson(lllllllllllllllIlIIIlIlIIIlIlIlI.getValue().getUnformattedText());
          if (lIIIIIIlllllII(lllllllllllllllIlIIIlIlIIIlIlIII instanceof NBTTagCompound))
          {
            lllllllllllllllIlIIIlIlIIIlIlIIl = ItemStack.loadItemStackFromNBT((NBTTagCompound)lllllllllllllllIlIIIlIlIIIlIlIII);
            "".length();
            if (-" ".length() > -" ".length()) {
              return;
            }
          }
        }
        catch (NBTException localNBTException1)
        {
          if (lIIIIIIllllIll(lllllllllllllllIlIIIlIlIIIlIlIIl))
          {
            lllllllllllllllIlIIIlIlIIIlIlllI.renderToolTip(lllllllllllllllIlIIIlIlIIIlIlIIl, lllllllllllllllIlIIIlIlIIIIllIll, lllllllllllllllIlIIIlIlIIIlIlIll);
            "".length();
            if (((87 + 70 - 149 + 144 ^ 89 + 64 - 140 + 126) & (0xCF ^ 0x97 ^ 0x67 ^ 0x2C ^ -" ".length())) <= 0) {
              break label1131;
            }
            return;
          }
          lllllllllllllllIlIIIlIlIIIlIlllI.drawCreativeTabHoveringText(String.valueOf(new StringBuilder().append(EnumChatFormatting.RED).append(lIlIIlllIlII[lIlIIlllIllI[9]])), lllllllllllllllIlIIIlIlIIIIllIll, lllllllllllllllIlIIIlIlIIIlIlIll);
          "".length();
          if ((0x34 ^ 0x30) >= 0) {
            break label1131;
          }
        }
        return;
      }
      if (lIIIIIlIIIIIIl(lllllllllllllllIlIIIlIlIIIlIlIlI.getAction(), HoverEvent.Action.SHOW_ENTITY))
      {
        if (lIIIIIIlllllII(mc.gameSettings.advancedItemTooltips)) {
          try
          {
            NBTBase lllllllllllllllIlIIIlIlIIIlIIlll = JsonToNBT.getTagFromJson(lllllllllllllllIlIIIlIlIIIlIlIlI.getValue().getUnformattedText());
            if (lIIIIIIlllllII(lllllllllllllllIlIIIlIlIIIlIIlll instanceof NBTTagCompound))
            {
              List<String> lllllllllllllllIlIIIlIlIIIlIIllI = Lists.newArrayList();
              NBTTagCompound lllllllllllllllIlIIIlIlIIIlIIlIl = (NBTTagCompound)lllllllllllllllIlIIIlIlIIIlIIlll;
              "".length();
              if (lIIIIIIlllllII(lllllllllllllllIlIIIlIlIIIlIIlIl.hasKey(lIlIIlllIlII[lIlIIlllIllI[15]], lIlIIlllIllI[5])))
              {
                String lllllllllllllllIlIIIlIlIIIlIIlII = lllllllllllllllIlIIIlIlIIIlIIlIl.getString(lIlIIlllIlII[lIlIIlllIllI[7]]);
                new StringBuilder(lIlIIlllIlII[lIlIIlllIllI[16]]);
                "".length();
              }
              "".length();
              lllllllllllllllIlIIIlIlIIIlIlllI.drawHoveringText(lllllllllllllllIlIIIlIlIIIlIIllI, lllllllllllllllIlIIIlIlIIIIllIll, lllllllllllllllIlIIIlIlIIIlIlIll);
              "".length();
              if (" ".length() != 0) {
                break label1131;
              }
              return;
            }
            lllllllllllllllIlIIIlIlIIIlIlllI.drawCreativeTabHoveringText(String.valueOf(new StringBuilder().append(EnumChatFormatting.RED).append(lIlIIlllIlII[lIlIIlllIllI[18]])), lllllllllllllllIlIIIlIlIIIIllIll, lllllllllllllllIlIIIlIlIIIlIlIll);
            "".length();
            if (-" ".length() <= 0) {
              break label1131;
            }
            return;
          }
          catch (NBTException lllllllllllllllIlIIIlIlIIIlIIIll)
          {
            lllllllllllllllIlIIIlIlIIIlIlllI.drawCreativeTabHoveringText(String.valueOf(new StringBuilder().append(EnumChatFormatting.RED).append(lIlIIlllIlII[lIlIIlllIllI[4]])), lllllllllllllllIlIIIlIlIIIIllIll, lllllllllllllllIlIIIlIlIIIlIlIll);
            "".length();
            if ((0xB4 ^ 0xB1) > 0) {
              break label1131;
            }
          }
        }
      }
      else if (lIIIIIlIIIIIIl(lllllllllllllllIlIIIlIlIIIlIlIlI.getAction(), HoverEvent.Action.SHOW_TEXT))
      {
        lllllllllllllllIlIIIlIlIIIlIlllI.drawHoveringText(NEWLINE_SPLITTER.splitToList(lllllllllllllllIlIIIlIlIIIlIlIlI.getValue().getFormattedText()), lllllllllllllllIlIIIlIlIIIIllIll, lllllllllllllllIlIIIlIlIIIlIlIll);
        "".length();
        if (((0x54 ^ 0x3A ^ 0x89 ^ 0xA8) & (0x5A ^ 0x5C ^ 0x6D ^ 0x24 ^ -" ".length())) == 0) {}
      }
      else if (lIIIIIlIIIIIIl(lllllllllllllllIlIIIlIlIIIlIlIlI.getAction(), HoverEvent.Action.SHOW_ACHIEVEMENT))
      {
        StatBase lllllllllllllllIlIIIlIlIIIlIIIlI = StatList.getOneShotStat(lllllllllllllllIlIIIlIlIIIlIlIlI.getValue().getUnformattedText());
        if (lIIIIIIllllIll(lllllllllllllllIlIIIlIlIIIlIIIlI))
        {
          IChatComponent lllllllllllllllIlIIIlIlIIIlIIIIl = lllllllllllllllIlIIIlIlIIIlIIIlI.getStatName();
          if (lIIIIIIlllllII(lllllllllllllllIlIIIlIlIIIlIIIlI.isAchievement()))
          {
            "".length();
            if (null == null) {
              break label799;
            }
          }
          label799:
          new StringBuilder(lIlIIlllIlII[lIlIIlllIllI[19]]).<init>(String.valueOf(lIlIIlllIlII[lIlIIlllIllI[20]].append(lIlIIlllIlII[lIlIIlllIllI[21]])), new Object[lIlIIlllIllI[1]]);
          IChatComponent lllllllllllllllIlIIIlIlIIIlIIIII = new net/minecraft/util/ChatComponentTranslation;
          "".length();
          if (lIIIIIIlllllII(lllllllllllllllIlIIIlIlIIIlIIIlI instanceof Achievement))
          {
            "".length();
            if (((0x72 ^ 0x33 ^ 0x50 ^ 0x1F) & (55 + 76 - 128 + 134 ^ 68 + 57 - 45 + 55 ^ -" ".length())) == ((0x3E ^ 0x45 ^ 0xBB ^ 0x9F) & (0x50 ^ 0x43 ^ 0x63 ^ 0x2F ^ -" ".length()))) {
              break label952;
            }
          }
          label952:
          String lllllllllllllllIlIIIlIlIIIIlllll = null;
          List<String> lllllllllllllllIlIIIlIlIIIIllllI = Lists.newArrayList(new String[] { lllllllllllllllIlIIIlIlIIIlIIIIl.getFormattedText(), lllllllllllllllIlIIIlIlIIIlIIIII.getFormattedText() });
          if (lIIIIIIllllIll(lllllllllllllllIlIIIlIlIIIIlllll)) {
            "".length();
          }
          lllllllllllllllIlIIIlIlIIIlIlllI.drawHoveringText(lllllllllllllllIlIIIlIlIIIIllllI, lllllllllllllllIlIIIlIlIIIIllIll, lllllllllllllllIlIIIlIlIIIlIlIll);
          "".length();
          if (" ".length() > ((74 + 33 - 70 + 90 ^ 0x19 ^ 0x41) & (0x3C ^ 0x55 ^ 0xEC ^ 0xA2 ^ -" ".length()))) {}
        }
        else
        {
          lllllllllllllllIlIIIlIlIIIlIlllI.drawCreativeTabHoveringText(String.valueOf(new StringBuilder().append(EnumChatFormatting.RED).append(lIlIIlllIlII[lIlIIlllIllI[23]])), lllllllllllllllIlIIIlIlIIIIllIll, lllllllllllllllIlIIIlIlIIIlIlIll);
        }
      }
      label1131:
      GlStateManager.disableLighting();
    }
  }
  
  public void drawScreen(int lllllllllllllllIlIIIlIlIlIIlIIlI, int lllllllllllllllIlIIIlIlIlIIlIIIl, float lllllllllllllllIlIIIlIlIlIIlIllI)
  {
    ;
    ;
    ;
    ;
    int lllllllllllllllIlIIIlIlIlIIlIlIl = lIlIIlllIllI[1];
    "".length();
    if ((0x6F ^ 0x21 ^ 0xF2 ^ 0xB8) > (0xF5 ^ 0x84 ^ 0xE6 ^ 0x93)) {
      return;
    }
    while (!lIIIIIIllllIII(lllllllllllllllIlIIIlIlIlIIlIlIl, buttonList.size()))
    {
      ((GuiButton)buttonList.get(lllllllllllllllIlIIIlIlIlIIlIlIl)).drawButton(mc, lllllllllllllllIlIIIlIlIlIIlIIlI, lllllllllllllllIlIIIlIlIlIIlIIIl);
      lllllllllllllllIlIIIlIlIlIIlIlIl++;
    }
    int lllllllllllllllIlIIIlIlIlIIlIlII = lIlIIlllIllI[1];
    "".length();
    if (" ".length() < 0) {
      return;
    }
    while (!lIIIIIIllllIII(lllllllllllllllIlIIIlIlIlIIlIlII, labelList.size()))
    {
      ((GuiLabel)labelList.get(lllllllllllllllIlIIIlIlIlIIlIlII)).drawLabel(mc, lllllllllllllllIlIIIlIlIlIIlIIlI, lllllllllllllllIlIIIlIlIlIIlIIIl);
      lllllllllllllllIlIIIlIlIlIIlIlII++;
    }
  }
  
  protected void mouseClicked(int lllllllllllllllIlIIIlIIllllIIIlI, int lllllllllllllllIlIIIlIIllllIIlll, int lllllllllllllllIlIIIlIIllllIIllI)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIIIIlllllIl(lllllllllllllllIlIIIlIIllllIIllI))
    {
      int lllllllllllllllIlIIIlIIllllIIlIl = lIlIIlllIllI[1];
      "".length();
      if ("   ".length() == ((75 + 80 - 92 + 64 ^ 0x7A ^ 0x26) & ('' + 45 - 131 + 101 ^ 34 + 0 - 31 + 174 ^ -" ".length()))) {
        return;
      }
      while (!lIIIIIIllllIII(lllllllllllllllIlIIIlIIllllIIlIl, buttonList.size()))
      {
        GuiButton lllllllllllllllIlIIIlIIllllIIlII = (GuiButton)buttonList.get(lllllllllllllllIlIIIlIIllllIIlIl);
        if (lIIIIIIlllllII(lllllllllllllllIlIIIlIIllllIIlII.mousePressed(mc, lllllllllllllllIlIIIlIIllllIIIlI, lllllllllllllllIlIIIlIIllllIIlll)))
        {
          selectedButton = lllllllllllllllIlIIIlIIllllIIlII;
          lllllllllllllllIlIIIlIIllllIIlII.playPressSound(mc.getSoundHandler());
          lllllllllllllllIlIIIlIIllllIIIll.actionPerformed(lllllllllllllllIlIIIlIIllllIIlII);
        }
        lllllllllllllllIlIIIlIIllllIIlIl++;
      }
    }
  }
  
  public void sendChatMessage(String lllllllllllllllIlIIIlIIllllllIll)
  {
    ;
    ;
    lllllllllllllllIlIIIlIIllllllIlI.sendChatMessage(lllllllllllllllIlIIIlIIllllllIll, lIlIIlllIllI[2]);
  }
  
  private static boolean lIIIIIIllllIll(Object ???)
  {
    String lllllllllllllllIlIIIlIIlIIlIlIIl;
    return ??? != null;
  }
  
  private void openWebLink(URI lllllllllllllllIlIIIlIIllIIIIlll)
  {
    try
    {
      ;
      ;
      ;
      Class<?> lllllllllllllllIlIIIlIIllIIIlIlI = Class.forName(lIlIIlllIlII[lIlIIlllIllI[33]]);
      Object lllllllllllllllIlIIIlIIllIIIlIIl = lllllllllllllllIlIIIlIIllIIIlIlI.getMethod(lIlIIlllIlII[lIlIIlllIllI[34]], new Class[lIlIIlllIllI[1]]).invoke(null, new Object[lIlIIlllIllI[1]]);
      "".length();
      "".length();
      if (((0x67 ^ 0x7D) & (0x7A ^ 0x60 ^ 0xFFFFFFFF)) > (0x95 ^ 0x91)) {}
    }
    catch (Throwable lllllllllllllllIlIIIlIIllIIIlIII)
    {
      LOGGER.error(lIlIIlllIlII[lIlIIlllIllI[36]], lllllllllllllllIlIIIlIIllIIIlIII);
    }
  }
  
  protected void mouseReleased(int lllllllllllllllIlIIIlIIlllIllIII, int lllllllllllllllIlIIIlIIlllIlIlll, int lllllllllllllllIlIIIlIIlllIlIIlI)
  {
    ;
    ;
    ;
    ;
    if ((lIIIIIIllllIll(selectedButton)) && (lIIIIIIlllllIl(lllllllllllllllIlIIIlIIlllIlIIlI)))
    {
      selectedButton.mouseReleased(lllllllllllllllIlIIIlIIlllIllIII, lllllllllllllllIlIIIlIIlllIlIlll);
      selectedButton = null;
    }
  }
  
  private static boolean lIIIIIIlllllIl(int ???)
  {
    boolean lllllllllllllllIlIIIlIIlIIIlllll;
    return ??? == 0;
  }
  
  private static boolean lIIIIIIllllllI(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllIlIIIlIIlIIlIlIll;
    return ??? > i;
  }
  
  private static boolean lIIIIIIllllIII(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIlIIIlIIlIIllIIll;
    return ??? >= i;
  }
  
  public void drawWorldBackground(int lllllllllllllllIlIIIlIIllIIllllI)
  {
    ;
    ;
    if (lIIIIIIllllIll(mc.theWorld))
    {
      lllllllllllllllIlIIIlIIllIlIIIIl.drawGradientRect(lIlIIlllIllI[1], lIlIIlllIllI[1], width, height, lIlIIlllIllI[30], lIlIIlllIllI[31]);
      "".length();
      if (-" ".length() <= 0) {}
    }
    else
    {
      lllllllllllllllIlIIIlIIllIlIIIIl.drawBackground(lllllllllllllllIlIIIlIIllIIllllI);
    }
  }
  
  public void handleInput()
    throws IOException
  {
    ;
    if (lIIIIIIlllllII(Mouse.isCreated()))
    {
      "".length();
      if (-" ".length() > ((0x77 ^ 0x67) & (0xB7 ^ 0xA7 ^ 0xFFFFFFFF))) {
        return;
      }
      while (!lIIIIIIlllllIl(Mouse.next())) {
        lllllllllllllllIlIIIlIIllIllllII.handleMouseInput();
      }
    }
    if (lIIIIIIlllllII(Keyboard.isCreated()))
    {
      "".length();
      if ((11 + '¥' - 74 + 88 ^ 59 + '' - 195 + 185) <= 0) {
        return;
      }
      while (!lIIIIIIlllllIl(Keyboard.next())) {
        lllllllllllllllIlIIIlIIllIllllII.handleKeyboardInput();
      }
    }
  }
  
  protected void drawHoveringText(List<String> lllllllllllllllIlIIIlIlIIlIlIIll, int lllllllllllllllIlIIIlIlIIlIlIIlI, int lllllllllllllllIlIIIlIlIIlIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIIIIlllllIl(lllllllllllllllIlIIIlIlIIlIlIIll.isEmpty()))
    {
      GlStateManager.disableRescaleNormal();
      RenderHelper.disableStandardItemLighting();
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      int lllllllllllllllIlIIIlIlIIlIlIIII = lIlIIlllIllI[1];
      lllllllllllllllIlIIIlIlIIIllllll = lllllllllllllllIlIIIlIlIIlIlIIll.iterator();
      "".length();
      if (" ".length() == "   ".length()) {
        return;
      }
      while (!lIIIIIIlllllIl(lllllllllllllllIlIIIlIlIIIllllll.hasNext()))
      {
        String lllllllllllllllIlIIIlIlIIlIIllll = (String)lllllllllllllllIlIIIlIlIIIllllll.next();
        int lllllllllllllllIlIIIlIlIIlIIlllI = fontRendererObj.getStringWidth(lllllllllllllllIlIIIlIlIIlIIllll);
        if (lIIIIIIllllllI(lllllllllllllllIlIIIlIlIIlIIlllI, lllllllllllllllIlIIIlIlIIlIlIIII)) {
          lllllllllllllllIlIIIlIlIIlIlIIII = lllllllllllllllIlIIIlIlIIlIIlllI;
        }
      }
      int lllllllllllllllIlIIIlIlIIlIIllIl = lllllllllllllllIlIIIlIlIIlIlIIlI + lIlIIlllIllI[4];
      int lllllllllllllllIlIIIlIlIIlIIllII = lllllllllllllllIlIIIlIlIIlIlIIIl - lIlIIlllIllI[4];
      int lllllllllllllllIlIIIlIlIIlIIlIll = lIlIIlllIllI[5];
      if (lIIIIIIllllllI(lllllllllllllllIlIIIlIlIIlIlIIll.size(), lIlIIlllIllI[2])) {
        lllllllllllllllIlIIIlIlIIlIIlIll += lIlIIlllIllI[0] + (lllllllllllllllIlIIIlIlIIlIlIIll.size() - lIlIIlllIllI[2]) * lIlIIlllIllI[3];
      }
      if (lIIIIIIllllllI(lllllllllllllllIlIIIlIlIIlIIllIl + lllllllllllllllIlIIIlIlIIlIlIIII, width)) {
        lllllllllllllllIlIIIlIlIIlIIllIl -= lIlIIlllIllI[6] + lllllllllllllllIlIIIlIlIIlIlIIII;
      }
      if (lIIIIIIllllllI(lllllllllllllllIlIIIlIlIIlIIllII + lllllllllllllllIlIIIlIlIIlIIlIll + lIlIIlllIllI[7], height)) {
        lllllllllllllllIlIIIlIlIIlIIllII = height - lllllllllllllllIlIIIlIlIIlIIlIll - lIlIIlllIllI[7];
      }
      zLevel = 300.0F;
      itemRender.zLevel = 300.0F;
      int lllllllllllllllIlIIIlIlIIlIIlIlI = lIlIIlllIllI[8];
      lllllllllllllllIlIIIlIlIIlIIIlIl.drawGradientRect(lllllllllllllllIlIIIlIlIIlIIllIl - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII - lIlIIlllIllI[10], lllllllllllllllIlIIIlIlIIlIIllIl + lllllllllllllllIlIIIlIlIIlIlIIII + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIlIlI, lllllllllllllllIlIIIlIlIIlIIlIlI);
      lllllllllllllllIlIIIlIlIIlIIIlIl.drawGradientRect(lllllllllllllllIlIIIlIlIIlIIllIl - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII + lllllllllllllllIlIIIlIlIIlIIlIll + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllIl + lllllllllllllllIlIIIlIlIIlIlIIII + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII + lllllllllllllllIlIIIlIlIIlIIlIll + lIlIIlllIllI[10], lllllllllllllllIlIIIlIlIIlIIlIlI, lllllllllllllllIlIIIlIlIIlIIlIlI);
      lllllllllllllllIlIIIlIlIIlIIIlIl.drawGradientRect(lllllllllllllllIlIIIlIlIIlIIllIl - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllIl + lllllllllllllllIlIIIlIlIIlIlIIII + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII + lllllllllllllllIlIIIlIlIIlIIlIll + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIlIlI, lllllllllllllllIlIIIlIlIIlIIlIlI);
      lllllllllllllllIlIIIlIlIIlIIIlIl.drawGradientRect(lllllllllllllllIlIIIlIlIIlIIllIl - lIlIIlllIllI[10], lllllllllllllllIlIIIlIlIIlIIllII - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllIl - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII + lllllllllllllllIlIIIlIlIIlIIlIll + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIlIlI, lllllllllllllllIlIIIlIlIIlIIlIlI);
      lllllllllllllllIlIIIlIlIIlIIIlIl.drawGradientRect(lllllllllllllllIlIIIlIlIIlIIllIl + lllllllllllllllIlIIIlIlIIlIlIIII + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllIl + lllllllllllllllIlIIIlIlIIlIlIIII + lIlIIlllIllI[10], lllllllllllllllIlIIIlIlIIlIIllII + lllllllllllllllIlIIIlIlIIlIIlIll + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIlIlI, lllllllllllllllIlIIIlIlIIlIIlIlI);
      int lllllllllllllllIlIIIlIlIIlIIlIIl = lIlIIlllIllI[11];
      int lllllllllllllllIlIIIlIlIIlIIlIII = (lllllllllllllllIlIIIlIlIIlIIlIIl & lIlIIlllIllI[12]) >> lIlIIlllIllI[2] | lllllllllllllllIlIIIlIlIIlIIlIIl & lIlIIlllIllI[13];
      lllllllllllllllIlIIIlIlIIlIIIlIl.drawGradientRect(lllllllllllllllIlIIIlIlIIlIIllIl - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII - lIlIIlllIllI[9] + lIlIIlllIllI[2], lllllllllllllllIlIIIlIlIIlIIllIl - lIlIIlllIllI[9] + lIlIIlllIllI[2], lllllllllllllllIlIIIlIlIIlIIllII + lllllllllllllllIlIIIlIlIIlIIlIll + lIlIIlllIllI[9] - lIlIIlllIllI[2], lllllllllllllllIlIIIlIlIIlIIlIIl, lllllllllllllllIlIIIlIlIIlIIlIII);
      lllllllllllllllIlIIIlIlIIlIIIlIl.drawGradientRect(lllllllllllllllIlIIIlIlIIlIIllIl + lllllllllllllllIlIIIlIlIIlIlIIII + lIlIIlllIllI[0], lllllllllllllllIlIIIlIlIIlIIllII - lIlIIlllIllI[9] + lIlIIlllIllI[2], lllllllllllllllIlIIIlIlIIlIIllIl + lllllllllllllllIlIIIlIlIIlIlIIII + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII + lllllllllllllllIlIIIlIlIIlIIlIll + lIlIIlllIllI[9] - lIlIIlllIllI[2], lllllllllllllllIlIIIlIlIIlIIlIIl, lllllllllllllllIlIIIlIlIIlIIlIII);
      lllllllllllllllIlIIIlIlIIlIIIlIl.drawGradientRect(lllllllllllllllIlIIIlIlIIlIIllIl - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllIl + lllllllllllllllIlIIIlIlIIlIlIIII + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII - lIlIIlllIllI[9] + lIlIIlllIllI[2], lllllllllllllllIlIIIlIlIIlIIlIIl, lllllllllllllllIlIIIlIlIIlIIlIIl);
      lllllllllllllllIlIIIlIlIIlIIIlIl.drawGradientRect(lllllllllllllllIlIIIlIlIIlIIllIl - lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII + lllllllllllllllIlIIIlIlIIlIIlIll + lIlIIlllIllI[0], lllllllllllllllIlIIIlIlIIlIIllIl + lllllllllllllllIlIIIlIlIIlIlIIII + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIllII + lllllllllllllllIlIIIlIlIIlIIlIll + lIlIIlllIllI[9], lllllllllllllllIlIIIlIlIIlIIlIII, lllllllllllllllIlIIIlIlIIlIIlIII);
      int lllllllllllllllIlIIIlIlIIlIIIlll = lIlIIlllIllI[1];
      "".length();
      if (-"  ".length() >= 0) {
        return;
      }
      while (!lIIIIIIllllIII(lllllllllllllllIlIIIlIlIIlIIIlll, lllllllllllllllIlIIIlIlIIlIlIIll.size()))
      {
        String lllllllllllllllIlIIIlIlIIlIIIllI = (String)lllllllllllllllIlIIIlIlIIlIlIIll.get(lllllllllllllllIlIIIlIlIIlIIIlll);
        "".length();
        if (lIIIIIIlllllIl(lllllllllllllllIlIIIlIlIIlIIIlll)) {
          lllllllllllllllIlIIIlIlIIlIIllII += 2;
        }
        lllllllllllllllIlIIIlIlIIlIIllII += 10;
      }
      zLevel = 0.0F;
      itemRender.zLevel = 0.0F;
      GlStateManager.enableLighting();
      GlStateManager.enableDepth();
      RenderHelper.enableStandardItemLighting();
      GlStateManager.enableRescaleNormal();
    }
  }
  
  private static String lIIIIIIlIllllI(String lllllllllllllllIlIIIlIIlIlIlIlIl, String lllllllllllllllIlIIIlIIlIlIlIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIIIlIIlIlIlIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIlIIIlIIlIlIlIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlIIIlIIlIlIlIIll = new StringBuilder();
    char[] lllllllllllllllIlIIIlIIlIlIlIIlI = lllllllllllllllIlIIIlIIlIlIlIlII.toCharArray();
    int lllllllllllllllIlIIIlIIlIlIlIIIl = lIlIIlllIllI[1];
    Exception lllllllllllllllIlIIIlIIlIlIIlIll = lllllllllllllllIlIIIlIIlIlIlIlIl.toCharArray();
    int lllllllllllllllIlIIIlIIlIlIIlIlI = lllllllllllllllIlIIIlIIlIlIIlIll.length;
    float lllllllllllllllIlIIIlIIlIlIIlIIl = lIlIIlllIllI[1];
    while (lIIIIIlIIIIllI(lllllllllllllllIlIIIlIIlIlIIlIIl, lllllllllllllllIlIIIlIIlIlIIlIlI))
    {
      char lllllllllllllllIlIIIlIIlIlIlIllI = lllllllllllllllIlIIIlIIlIlIIlIll[lllllllllllllllIlIIIlIIlIlIIlIIl];
      "".length();
      "".length();
      if (" ".length() < 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIlIIIlIIlIlIlIIll);
  }
  
  public void handleKeyboardInput()
    throws IOException
  {
    ;
    if (lIIIIIIlllllII(Keyboard.getEventKeyState())) {
      lllllllllllllllIlIIIlIIllIlIlIIl.keyTyped(Keyboard.getEventCharacter(), Keyboard.getEventKey());
    }
    mc.dispatchKeypresses();
  }
  
  public void updateScreen() {}
  
  public void drawBackground(int lllllllllllllllIlIIIlIIllIIllIll)
  {
    ;
    GlStateManager.disableLighting();
    GlStateManager.disableFog();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(new ResourceLocation(lIlIIlllIlII[lIlIIlllIllI[32]]));
    Gui.drawScaledCustomSizeModalRect(lIlIIlllIllI[1], lIlIIlllIllI[1], 0.0F, 0.0F, width, height, width, height, width, height);
  }
  
  protected void renderToolTip(ItemStack lllllllllllllllIlIIIlIlIIllllIII, int lllllllllllllllIlIIIlIlIIlllIIIl, int lllllllllllllllIlIIIlIlIIlllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    List<String> lllllllllllllllIlIIIlIlIIlllIlIl = lllllllllllllllIlIIIlIlIIllllIII.getTooltip(mc.thePlayer, mc.gameSettings.advancedItemTooltips);
    int lllllllllllllllIlIIIlIlIIlllIlII = lIlIIlllIllI[1];
    "".length();
    if (" ".length() != " ".length()) {
      return;
    }
    while (!lIIIIIIllllIII(lllllllllllllllIlIIIlIlIIlllIlII, lllllllllllllllIlIIIlIlIIlllIlIl.size()))
    {
      if (lIIIIIIlllllIl(lllllllllllllllIlIIIlIlIIlllIlII))
      {
        new StringBuilder();
        "".length();
        "".length();
        if ((0x5 ^ 0x1) != 0) {}
      }
      else
      {
        new StringBuilder();
        "".length();
      }
      lllllllllllllllIlIIIlIlIIlllIlII++;
    }
    lllllllllllllllIlIIIlIlIIlllIIll.drawHoveringText(lllllllllllllllIlIIIlIlIIlllIlIl, lllllllllllllllIlIIIlIlIIlllIIIl, lllllllllllllllIlIIIlIlIIlllIllI);
  }
  
  protected void drawCreativeTabHoveringText(String lllllllllllllllIlIIIlIlIIllIlIII, int lllllllllllllllIlIIIlIlIIllIIlll, int lllllllllllllllIlIIIlIlIIllIIllI)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIlIIIlIlIIllIIlIl.drawHoveringText(Arrays.asList(new String[] { lllllllllllllllIlIIIlIlIIllIlIII }), lllllllllllllllIlIIIlIlIIllIIlll, lllllllllllllllIlIIIlIlIIllIIllI);
  }
  
  private static boolean lIIIIIlIIIIlII(int ???)
  {
    byte lllllllllllllllIlIIIlIIlIIIlllIl;
    return ??? > 0;
  }
  
  private static boolean lIIIIIlIIIIllI(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIlIIIlIIlIIlIllll;
    return ??? < i;
  }
  
  private static boolean lIIIIIlIIIIIIl(Object ???, Object arg1)
  {
    Object localObject;
    String lllllllllllllllIlIIIlIIlIIlIIlIl;
    return ??? == localObject;
  }
}

package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.ResourcePackListEntry;

public class GuiResourcePackAvailable
  extends GuiResourcePackList
{
  protected String getListHeader()
  {
    return I18n.format(lIlllllIIll[lIlllllIlII[0]], new Object[lIlllllIlII[0]]);
  }
  
  private static String lIIlIIlIIlIII(String llllllllllllllllIllIlIllIlIIIlII, String llllllllllllllllIllIlIllIlIIIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIllIlIllIlIIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllIlIllIlIIIlIl.getBytes(StandardCharsets.UTF_8)), lIlllllIlII[2]), "DES");
      Cipher llllllllllllllllIllIlIllIlIIlIII = Cipher.getInstance("DES");
      llllllllllllllllIllIlIllIlIIlIII.init(lIlllllIlII[3], llllllllllllllllIllIlIllIlIIlIIl);
      return new String(llllllllllllllllIllIlIllIlIIlIII.doFinal(Base64.getDecoder().decode(llllllllllllllllIllIlIllIlIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIllIlIllIlIIIlll)
    {
      llllllllllllllllIllIlIllIlIIIlll.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIIlIIlIIlIlI();
    lIIlIIlIIlIIl();
  }
  
  public GuiResourcePackAvailable(Minecraft llllllllllllllllIllIlIllIlIlIlll, int llllllllllllllllIllIlIllIlIlIllI, int llllllllllllllllIllIlIllIlIlIlIl, List<ResourcePackListEntry> llllllllllllllllIllIlIllIlIIllll)
  {
    llllllllllllllllIllIlIllIlIlIIll.<init>(llllllllllllllllIllIlIllIlIlIlll, llllllllllllllllIllIlIllIlIlIIIl, llllllllllllllllIllIlIllIlIlIlIl, llllllllllllllllIllIlIllIlIIllll);
  }
  
  private static void lIIlIIlIIlIIl()
  {
    lIlllllIIll = new String[lIlllllIlII[1]];
    lIlllllIIll[lIlllllIlII[0]] = lIIlIIlIIlIII("fWm9OyRddbn4p/hw8H6nuKZq3aUdN271rOXGe9vHYCc=", "KPYki");
  }
  
  private static void lIIlIIlIIlIlI()
  {
    lIlllllIlII = new int[4];
    lIlllllIlII[0] = ((0x5 ^ 0xC) & (0xB4 ^ 0xBD ^ 0xFFFFFFFF));
    lIlllllIlII[1] = " ".length();
    lIlllllIlII[2] = (0x41 ^ 0x49);
    lIlllllIlII[3] = "  ".length();
  }
}

package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.gen.FlatGeneratorInfo;
import net.minecraft.world.gen.FlatLayerInfo;

public class GuiCreateFlatWorld
  extends GuiScreen
{
  private static void lllIIIllIIll()
  {
    lIIIlllIlII = new String[lIIIlllllII[25]];
    lIIIlllIlII[lIIIlllllII[0]] = lllIIIlIlIII("A2B2D3kjj/4M4WWYRO1AuGu/cK5J3PS2mADGtoPxiffK7gNB+SAZFw==", "KKtmY");
    lIIIlllIlII[lIIIlllllII[1]] = lllIIIlIlIII("J4BcRWb0PuLtRMSlhUbxDn5782Am/lCq6cmKz0ZT6BY=", "ctmKG");
    lIIIlllIlII[lIIIlllllII[2]] = lllIIIllIIIl("R0NNIUwqjYpZAKAZbItK1dvsk6ggHTr/p9jDJk4qLiEPGTLI546fXQ==", "ZEzIL");
    lIIIlllIlII[lIIIlllllII[7]] = lllIIIllIIlI("GzcWFzIdEhwEKhxrEAM1DCoeHzwdaxUaJwxrEhIiNCQKEzQ=", "xEsvF");
    lIIIlllIlII[lIIIlllllII[8]] = lllIIIllIIlI("WXscHBxQ", "ySREU");
    lIIIlllIlII[lIIIlllllII[10]] = lllIIIllIIIl("CStcOJ/2gWLBNZQETAKzTibdCvg0WBc7DdiGFNNCJsqFMi0nrxg4BQ==", "UqLsh");
    lIIIlllIlII[lIIIlllllII[11]] = lllIIIllIIlI("VHwsPR1d", "tTbdT");
    lIIIlllIlII[lIIIlllllII[14]] = lllIIIlIlIII("dRhv1yGanWatbyXqWZNilOYea+DrxYdAkhK16tKnXf9nHHPUih/3nw==", "wFPFK");
    lIIIlllIlII[lIIIlllllII[16]] = lllIIIllIIIl("IGW5kLMrNRehETrfmNCDqA==", "tAPOV");
    lIIIlllIlII[lIIIlllllII[17]] = lllIIIlIlIII("xwDG8eTG62iL0cSrcrzVBj40E4ee/Z/9Foi7zpjvy5g=", "gWjiY");
    lIIIlllIlII[lIIIlllllII[18]] = lllIIIllIIIl("6PV/89k8+Erh9Qpnx2w2xQ==", "exOTT");
  }
  
  public void func_146383_a(String lllllllllllllllllIlIIlllIIIIlIlI)
  {
    ;
    ;
    theFlatGeneratorInfo = FlatGeneratorInfo.createFlatGeneratorFromString(lllllllllllllllllIlIIlllIIIIlIlI);
  }
  
  private static String lllIIIlIlIII(String lllllllllllllllllIlIIllIllIllIIl, String lllllllllllllllllIlIIllIllIllIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIlIIllIllIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIIllIllIllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIlIIllIllIllIll = Cipher.getInstance("Blowfish");
      lllllllllllllllllIlIIllIllIllIll.init(lIIIlllllII[2], lllllllllllllllllIlIIllIllIlllII);
      return new String(lllllllllllllllllIlIIllIllIllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIIllIllIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIlIIllIllIllIlI)
    {
      lllllllllllllllllIlIIllIllIllIlI.printStackTrace();
    }
    return null;
  }
  
  private static void lllIIlIIIIII()
  {
    lIIIlllllII = new int[26];
    lIIIlllllII[0] = ((0x7E ^ 0x8 ^ 0x55 ^ 0x60) & (0xBD ^ 0x8F ^ 0x41 ^ 0x30 ^ -" ".length()));
    lIIIlllllII[1] = " ".length();
    lIIIlllllII[2] = "  ".length();
    lIIIlllllII[3] = (119 + 115 - 180 + 100);
    lIIIlllllII[4] = ('' + 26 - 53 + 61 ^ 122 + 92 - 97 + 25);
    lIIIlllllII[5] = (0x3C ^ 0x58);
    lIIIlllllII[6] = (0x6C ^ 0x78);
    lIIIlllllII[7] = "   ".length();
    lIIIlllllII[8] = ("  ".length() ^ 0x7C ^ 0x7A);
    lIIIlllllII[9] = (0x53 ^ 0x61);
    lIIIlllllII[10] = (100 + 46 - 66 + 92 ^ '' + 101 - 86 + 19);
    lIIIlllllII[11] = (0x1 ^ 0x6B ^ 0xDF ^ 0xB3);
    lIIIlllllII[12] = ('' + '' - 249 + 99);
    lIIIlllllII[13] = (31 + 55 - -11 + 53);
    lIIIlllllII[14] = (0x25 ^ 0x22);
    lIIIlllllII[15] = (9 + 109 - -30 + 1 ^ 97 + 42 - 101 + 99);
    lIIIlllllII[16] = (0x7D ^ 0x75);
    lIIIlllllII[17] = (0x2 ^ 0x2E ^ 0x3E ^ 0x1B);
    lIIIlllllII[18] = (94 + 83 - 91 + 85 ^ 18 + 117 - 66 + 92);
    lIIIlllllII[19] = (-" ".length());
    lIIIlllllII[20] = (0xFFFFFFFF & 0xFFFFFF);
    lIIIlllllII[21] = (0x5E ^ 0x2);
    lIIIlllllII[22] = (0x41 ^ 0x51);
    lIIIlllllII[23] = (2 + 84 - 69 + 132 ^ 47 + 110 - -5 + 19);
    lIIIlllllII[24] = (104 + '§' - 153 + 95);
    lIIIlllllII[25] = (0x9A ^ 0x91);
  }
  
  private boolean func_146382_i()
  {
    ;
    if ((lllIIlIIIlII(createFlatWorldListSlotGui.field_148228_k, lIIIlllllII[19])) && (lllIIlIIIlIl(createFlatWorldListSlotGui.field_148228_k, theFlatGeneratorInfo.getFlatLayers().size()))) {
      return lIIIlllllII[1];
    }
    return lIIIlllllII[0];
  }
  
  private static boolean lllIIlIIIlIl(int ???, int arg1)
  {
    int i;
    int lllllllllllllllllIlIIllIlIlIIlll;
    return ??? < i;
  }
  
  public void func_146375_g()
  {
    ;
    ;
    boolean lllllllllllllllllIlIIllIllllIlll = lllllllllllllllllIlIIllIlllllIII.func_146382_i();
    field_146386_v.enabled = lllllllllllllllllIlIIllIllllIlll;
    field_146388_u.enabled = lllllllllllllllllIlIIllIllllIlll;
    field_146388_u.enabled = lIIIlllllII[0];
    field_146389_t.enabled = lIIIlllllII[0];
  }
  
  private static boolean lllIIlIIIIlI(int ???)
  {
    Exception lllllllllllllllllIlIIllIlIIlllll;
    return ??? == 0;
  }
  
  public String func_146384_e()
  {
    ;
    return theFlatGeneratorInfo.toString();
  }
  
  private static boolean lllIIlIIIIll(int ???)
  {
    long lllllllllllllllllIlIIllIlIlIIIIl;
    return ??? != 0;
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllllIlIIllIllllllII)
    throws IOException
  {
    ;
    ;
    ;
    int lllllllllllllllllIlIIllIlllllllI = theFlatGeneratorInfo.getFlatLayers().size() - createFlatWorldListSlotGui.field_148228_k - lIIIlllllII[1];
    if (lllIIlIIIIIl(id, lIIIlllllII[1]))
    {
      mc.displayGuiScreen(createWorldGui);
      "".length();
      if (-" ".length() != "   ".length()) {}
    }
    else if (lllIIlIIIIlI(id))
    {
      createWorldGui.chunkProviderSettingsJson = lllllllllllllllllIlIIlllIIIIIIII.func_146384_e();
      mc.displayGuiScreen(createWorldGui);
      "".length();
      if (((0x25 ^ 0x1) & (0xE5 ^ 0xC1 ^ 0xFFFFFFFF)) < "   ".length()) {}
    }
    else if (lllIIlIIIIIl(id, lIIIlllllII[10]))
    {
      mc.displayGuiScreen(new GuiFlatPresets(lllllllllllllllllIlIIlllIIIIIIII));
      "".length();
      if ((0xC5 ^ 0xC0) > 0) {}
    }
    else if ((lllIIlIIIIIl(id, lIIIlllllII[8])) && (lllIIlIIIIll(lllllllllllllllllIlIIlllIIIIIIII.func_146382_i())))
    {
      "".length();
      createFlatWorldListSlotGui.field_148228_k = Math.min(createFlatWorldListSlotGui.field_148228_k, theFlatGeneratorInfo.getFlatLayers().size() - lIIIlllllII[1]);
    }
    theFlatGeneratorInfo.func_82645_d();
    lllllllllllllllllIlIIlllIIIIIIII.func_146375_g();
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    lllllllllllllllllIlIIlllIIIIIlII.handleMouseInput();
    createFlatWorldListSlotGui.handleMouseInput();
  }
  
  public void drawScreen(int lllllllllllllllllIlIIllIlllIlIll, int lllllllllllllllllIlIIllIlllIlIlI, float lllllllllllllllllIlIIllIlllIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIlIIllIlllIllII.drawDefaultBackground();
    createFlatWorldListSlotGui.drawScreen(lllllllllllllllllIlIIllIlllIlIll, lllllllllllllllllIlIIllIlllIlIlI, lllllllllllllllllIlIIllIlllIIlII);
    lllllllllllllllllIlIIllIlllIllII.drawCenteredString(fontRendererObj, flatWorldTitle, width / lIIIlllllII[2], lIIIlllllII[16], lIIIlllllII[20]);
    int lllllllllllllllllIlIIllIlllIlIII = width / lIIIlllllII[2] - lIIIlllllII[21] - lIIIlllllII[22];
    lllllllllllllllllIlIIllIlllIllII.drawString(fontRendererObj, field_146394_i, lllllllllllllllllIlIIllIlllIlIII, lIIIlllllII[23], lIIIlllllII[20]);
    lllllllllllllllllIlIIllIlllIllII.drawString(fontRendererObj, field_146391_r, lllllllllllllllllIlIIllIlllIlIII + lIIIlllllII[2] + lIIIlllllII[24] - fontRendererObj.getStringWidth(field_146391_r), lIIIlllllII[23], lIIIlllllII[20]);
    lllllllllllllllllIlIIllIlllIllII.drawScreen(lllllllllllllllllIlIIllIlllIlIll, lllllllllllllllllIlIIllIlllIlIlI, lllllllllllllllllIlIIllIlllIIlII);
  }
  
  private static boolean lllIIlIIIlII(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllllIlIIllIlIlIIIll;
    return ??? > i;
  }
  
  private static String lllIIIllIIlI(String lllllllllllllllllIlIIllIlIllIlll, String lllllllllllllllllIlIIllIlIlllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIlIIllIlIllIlll = new String(Base64.getDecoder().decode(lllllllllllllllllIlIIllIlIllIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIlIIllIlIlllIlI = new StringBuilder();
    char[] lllllllllllllllllIlIIllIlIlllIIl = lllllllllllllllllIlIIllIlIlllIll.toCharArray();
    int lllllllllllllllllIlIIllIlIlllIII = lIIIlllllII[0];
    long lllllllllllllllllIlIIllIlIllIIlI = lllllllllllllllllIlIIllIlIllIlll.toCharArray();
    String lllllllllllllllllIlIIllIlIllIIIl = lllllllllllllllllIlIIllIlIllIIlI.length;
    double lllllllllllllllllIlIIllIlIllIIII = lIIIlllllII[0];
    while (lllIIlIIIlIl(lllllllllllllllllIlIIllIlIllIIII, lllllllllllllllllIlIIllIlIllIIIl))
    {
      char lllllllllllllllllIlIIllIlIllllIl = lllllllllllllllllIlIIllIlIllIIlI[lllllllllllllllllIlIIllIlIllIIII];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIlIIllIlIlllIlI);
  }
  
  public GuiCreateFlatWorld(GuiCreateWorld lllllllllllllllllIlIIlllIIIlIlII, String lllllllllllllllllIlIIlllIIIlIIll)
  {
    createWorldGui = lllllllllllllllllIlIIlllIIIlIlll;
    lllllllllllllllllIlIIlllIIIlIlIl.func_146383_a(lllllllllllllllllIlIIlllIIIlIIll);
  }
  
  private static String lllIIIllIIIl(String lllllllllllllllllIlIIllIllIIllII, String lllllllllllllllllIlIIllIllIIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIlIIllIllIIllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIIllIllIIlIll.getBytes(StandardCharsets.UTF_8)), lIIIlllllII[16]), "DES");
      Cipher lllllllllllllllllIlIIllIllIIlllI = Cipher.getInstance("DES");
      lllllllllllllllllIlIIllIllIIlllI.init(lIIIlllllII[2], lllllllllllllllllIlIIllIllIIllll);
      return new String(lllllllllllllllllIlIIllIllIIlllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIIllIllIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIlIIllIllIIllIl)
    {
      lllllllllllllllllIlIIllIllIIllIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIlIIIIIl(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllllIlIIllIlIlIlIll;
    return ??? == i;
  }
  
  public void initGui()
  {
    ;
    buttonList.clear();
    flatWorldTitle = I18n.format(lIIIlllIlII[lIIIlllllII[0]], new Object[lIIIlllllII[0]]);
    field_146394_i = I18n.format(lIIIlllIlII[lIIIlllllII[1]], new Object[lIIIlllllII[0]]);
    field_146391_r = I18n.format(lIIIlllIlII[lIIIlllllII[2]], new Object[lIIIlllllII[0]]);
    createFlatWorldListSlotGui = new Details();
    field_146389_t = new GuiButton(lIIIlllllII[2], width / lIIIlllllII[2] - lIIIlllllII[3], height - lIIIlllllII[4], lIIIlllllII[5], lIIIlllllII[6], String.valueOf(new StringBuilder(String.valueOf(I18n.format(lIIIlllIlII[lIIIlllllII[7]], new Object[lIIIlllllII[0]]))).append(lIIIlllIlII[lIIIlllllII[8]])));
    "".length();
    field_146388_u = new GuiButton(lIIIlllllII[7], width / lIIIlllllII[2] - lIIIlllllII[9], height - lIIIlllllII[4], lIIIlllllII[5], lIIIlllllII[6], String.valueOf(new StringBuilder(String.valueOf(I18n.format(lIIIlllIlII[lIIIlllllII[10]], new Object[lIIIlllllII[0]]))).append(lIIIlllIlII[lIIIlllllII[11]])));
    "".length();
    field_146386_v = new GuiButton(lIIIlllllII[8], width / lIIIlllllII[2] - lIIIlllllII[12], height - lIIIlllllII[4], lIIIlllllII[13], lIIIlllllII[6], I18n.format(lIIIlllIlII[lIIIlllllII[14]], new Object[lIIIlllllII[0]]));
    "".length();
    new GuiButton(lIIIlllllII[0], width / lIIIlllllII[2] - lIIIlllllII[12], height - lIIIlllllII[15], lIIIlllllII[13], lIIIlllllII[6], I18n.format(lIIIlllIlII[lIIIlllllII[16]], new Object[lIIIlllllII[0]]));
    "".length();
    new GuiButton(lIIIlllllII[10], width / lIIIlllllII[2] + lIIIlllllII[10], height - lIIIlllllII[4], lIIIlllllII[13], lIIIlllllII[6], I18n.format(lIIIlllIlII[lIIIlllllII[17]], new Object[lIIIlllllII[0]]));
    "".length();
    new GuiButton(lIIIlllllII[1], width / lIIIlllllII[2] + lIIIlllllII[10], height - lIIIlllllII[15], lIIIlllllII[13], lIIIlllllII[6], I18n.format(lIIIlllIlII[lIIIlllllII[18]], new Object[lIIIlllllII[0]]));
    "".length();
    field_146389_t.visible = (field_146388_u.visible = lIIIlllllII[0]);
    theFlatGeneratorInfo.func_82645_d();
    lllllllllllllllllIlIIlllIIIIIlll.func_146375_g();
  }
  
  static
  {
    lllIIlIIIIII();
    lllIIIllIIll();
  }
  
  class Details
    extends GuiSlot
  {
    private void func_148224_c(int lllllllllllllllllIIIllIlIIIIIIlI, int lllllllllllllllllIIIllIlIIIIIIIl, int lllllllllllllllllIIIllIlIIIIlIll, int lllllllllllllllllIIIllIlIIIIlIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      mc.getTextureManager().bindTexture(Gui.statIcons);
      float lllllllllllllllllIIIllIlIIIIlIIl = 0.0078125F;
      float lllllllllllllllllIIIllIlIIIIlIII = 0.0078125F;
      int lllllllllllllllllIIIllIlIIIIIlll = lIlIIlIllll[7];
      int lllllllllllllllllIIIllIlIIIIIllI = lIlIIlIllll[7];
      Tessellator lllllllllllllllllIIIllIlIIIIIlIl = Tessellator.getInstance();
      WorldRenderer lllllllllllllllllIIIllIlIIIIIlII = lllllllllllllllllIIIllIlIIIIIlIl.getWorldRenderer();
      lllllllllllllllllIIIllIlIIIIIlII.begin(lIlIIlIllll[8], DefaultVertexFormats.POSITION_TEX);
      lllllllllllllllllIIIllIlIIIIIlII.pos(lllllllllllllllllIIIllIlIIIIIIlI + lIlIIlIllll[6], lllllllllllllllllIIIllIlIIIIllII + lIlIIlIllll[7], zLevel).tex((lllllllllllllllllIIIllIlIIIIlIll + lIlIIlIllll[6]) * 0.0078125F, (lllllllllllllllllIIIllIlIIIIlIlI + lIlIIlIllll[7]) * 0.0078125F).endVertex();
      lllllllllllllllllIIIllIlIIIIIlII.pos(lllllllllllllllllIIIllIlIIIIIIlI + lIlIIlIllll[7], lllllllllllllllllIIIllIlIIIIllII + lIlIIlIllll[7], zLevel).tex((lllllllllllllllllIIIllIlIIIIlIll + lIlIIlIllll[7]) * 0.0078125F, (lllllllllllllllllIIIllIlIIIIlIlI + lIlIIlIllll[7]) * 0.0078125F).endVertex();
      lllllllllllllllllIIIllIlIIIIIlII.pos(lllllllllllllllllIIIllIlIIIIIIlI + lIlIIlIllll[7], lllllllllllllllllIIIllIlIIIIllII + lIlIIlIllll[6], zLevel).tex((lllllllllllllllllIIIllIlIIIIlIll + lIlIIlIllll[7]) * 0.0078125F, (lllllllllllllllllIIIllIlIIIIlIlI + lIlIIlIllll[6]) * 0.0078125F).endVertex();
      lllllllllllllllllIIIllIlIIIIIlII.pos(lllllllllllllllllIIIllIlIIIIIIlI + lIlIIlIllll[6], lllllllllllllllllIIIllIlIIIIllII + lIlIIlIllll[6], zLevel).tex((lllllllllllllllllIIIllIlIIIIlIll + lIlIIlIllll[6]) * 0.0078125F, (lllllllllllllllllIIIllIlIIIIlIlI + lIlIIlIllll[6]) * 0.0078125F).endVertex();
      lllllllllllllllllIIIllIlIIIIIlIl.draw();
    }
    
    static
    {
      lIIIIIIIIIIlI();
      lIIIIIIIIIIIl();
    }
    
    protected int getScrollBarX()
    {
      ;
      return width - lIlIIlIllll[13];
    }
    
    private static boolean lIIIIIIIIIlll(Object ???, Object arg1)
    {
      Object localObject;
      long lllllllllllllllllIIIllIIlIIIllII;
      return ??? != localObject;
    }
    
    private static boolean lIIIIIIIIlIll(int ???)
    {
      long lllllllllllllllllIIIllIIlIIIIIlI;
      return ??? == 0;
    }
    
    private static void lIIIIIIIIIIlI()
    {
      lIlIIlIllll = new int[15];
      lIlIIlIllll[0] = (0x44 ^ 0x6F);
      lIlIIlIllll[1] = (0x40 ^ 0x7C);
      lIlIIlIllll[2] = (113 + 24 - 112 + 114 ^ '' + 27 - 151 + 125);
      lIlIIlIllll[3] = (-" ".length());
      lIlIIlIllll[4] = " ".length();
      lIlIIlIllll[5] = "  ".length();
      lIlIIlIllll[6] = ((102 + '' - 216 + 154 ^ 16 + 44 - -79 + 16) & (0x94 ^ 0x85 ^ 0x6B ^ 0x52 ^ -" ".length()));
      lIlIIlIllll[7] = (0x43 ^ 0x3E ^ 0xD0 ^ 0xBF);
      lIlIIlIllll[8] = (0x48 ^ 0x4F);
      lIlIIlIllll[9] = (0xB1 ^ 0xB4);
      lIlIIlIllll[10] = "   ".length();
      lIlIIlIllll[11] = (0xFFFFFFFF & 0xFFFFFF);
      lIlIIlIllll[12] = ('' + 13 - 60 + 67 + (0x50 ^ 0x62) - (14 + '' - -41 + 13) + ('¶' + 84 - 146 + 82));
      lIlIIlIllll[13] = (0x5 ^ 0x2C ^ 0x1 ^ 0x6E);
      lIlIIlIllll[14] = (0x1D ^ 0x36 ^ 0xB0 ^ 0x9F);
    }
    
    protected boolean isSelected(int lllllllllllllllllIIIllIIlllIlIIl)
    {
      ;
      ;
      if (lIIIIIIIIIllI(lllllllllllllllllIIIllIIlllIlIIl, field_148228_k)) {
        return lIlIIlIllll[4];
      }
      return lIlIIlIllll[6];
    }
    
    public Details()
    {
      lllllllllllllllllIIIllIlIIllIIII.<init>(mc, width, height, lIlIIlIllll[0], height - lIlIIlIllll[1], lIlIIlIllll[2]);
    }
    
    private void func_148225_a(int lllllllllllllllllIIIllIlIIlIIlIl, int lllllllllllllllllIIIllIlIIlIlIII, ItemStack lllllllllllllllllIIIllIlIIlIIIll)
    {
      ;
      ;
      ;
      ;
      lllllllllllllllllIIIllIlIIlIlIlI.func_148226_e(lllllllllllllllllIIIllIlIIlIIlIl + lIlIIlIllll[4], lllllllllllllllllIIIllIlIIlIlIII + lIlIIlIllll[4]);
      GlStateManager.enableRescaleNormal();
      if ((lIIIIIIIIIlIl(lllllllllllllllllIIIllIlIIlIIIll)) && (lIIIIIIIIIlIl(lllllllllllllllllIIIllIlIIlIIIll.getItem())))
      {
        RenderHelper.enableGUIStandardItemLighting();
        itemRender.renderItemIntoGUI(lllllllllllllllllIIIllIlIIlIIIll, lllllllllllllllllIIIllIlIIlIIlIl + lIlIIlIllll[5], lllllllllllllllllIIIllIlIIlIlIII + lIlIIlIllll[5]);
        RenderHelper.disableStandardItemLighting();
      }
      GlStateManager.disableRescaleNormal();
    }
    
    private void func_148226_e(int lllllllllllllllllIIIllIlIIIllIll, int lllllllllllllllllIIIllIlIIIlllIl)
    {
      ;
      ;
      ;
      lllllllllllllllllIIIllIlIIIlllII.func_148224_c(lllllllllllllllllIIIllIlIIIllllI, lllllllllllllllllIIIllIlIIIlllIl, lIlIIlIllll[6], lIlIIlIllll[6]);
    }
    
    protected void drawBackground() {}
    
    protected void elementClicked(int lllllllllllllllllIIIllIIllllIIlI, boolean lllllllllllllllllIIIllIIllllIIIl, int lllllllllllllllllIIIllIIllllIIII, int lllllllllllllllllIIIllIIlllIllll)
    {
      ;
      ;
      field_148228_k = lllllllllllllllllIIIllIIllllIIlI;
      func_146375_g();
    }
    
    private static boolean lIIIIIIIIlIlI(Object ???, Object arg1)
    {
      Object localObject;
      float lllllllllllllllllIIIllIIlIIIIllI;
      return ??? == localObject;
    }
    
    protected void drawSlot(int lllllllllllllllllIIIllIIllIllIIl, int lllllllllllllllllIIIllIIllIIlIII, int lllllllllllllllllIIIllIIllIlIlll, int lllllllllllllllllIIIllIIllIlIllI, int lllllllllllllllllIIIllIIllIlIlIl, int lllllllllllllllllIIIllIIllIlIlII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      FlatLayerInfo lllllllllllllllllIIIllIIllIlIIll = (FlatLayerInfo)theFlatGeneratorInfo.getFlatLayers().get(theFlatGeneratorInfo.getFlatLayers().size() - lllllllllllllllllIIIllIIllIllIIl - lIlIIlIllll[4]);
      IBlockState lllllllllllllllllIIIllIIllIlIIlI = lllllllllllllllllIIIllIIllIlIIll.func_175900_c();
      Block lllllllllllllllllIIIllIIllIlIIIl = lllllllllllllllllIIIllIIllIlIIlI.getBlock();
      Item lllllllllllllllllIIIllIIllIlIIII = Item.getItemFromBlock(lllllllllllllllllIIIllIIllIlIIIl);
      if ((lIIIIIIIIIlll(lllllllllllllllllIIIllIIllIlIIIl, Blocks.air)) && (lIIIIIIIIIlIl(lllllllllllllllllIIIllIIllIlIIII)))
      {
        new ItemStack(lllllllllllllllllIIIllIIllIlIIII, lIlIIlIllll[4], lllllllllllllllllIIIllIIllIlIIIl.getMetaFromState(lllllllllllllllllIIIllIIllIlIIlI));
        "".length();
        if ((0x7E ^ 0x7A) >= ((0x1F ^ 0x10) & (0xAB ^ 0xA4 ^ 0xFFFFFFFF))) {
          break label138;
        }
      }
      label138:
      ItemStack lllllllllllllllllIIIllIIllIIllll = null;
      if (lIIIIIIIIlIII(lllllllllllllllllIIIllIIllIIllll))
      {
        "".length();
        if (((0x2B ^ 0x63) & (0x55 ^ 0x1D ^ 0xFFFFFFFF)) >= -" ".length()) {
          break label195;
        }
      }
      label195:
      String lllllllllllllllllIIIllIIllIIlllI = lllllllllllllllllIIIllIIllIlIIII.getItemStackDisplayName(lllllllllllllllllIIIllIIllIIllll);
      if (lIIIIIIIIlIII(lllllllllllllllllIIIllIIllIlIIII))
      {
        if ((lIIIIIIIIIlll(lllllllllllllllllIIIllIIllIlIIIl, Blocks.water)) && (lIIIIIIIIIlll(lllllllllllllllllIIIllIIllIlIIIl, Blocks.flowing_water)))
        {
          if ((!lIIIIIIIIIlll(lllllllllllllllllIIIllIIllIlIIIl, Blocks.lava)) || (lIIIIIIIIlIlI(lllllllllllllllllIIIllIIllIlIIIl, Blocks.flowing_lava)))
          {
            lllllllllllllllllIIIllIIllIlIIII = Items.lava_bucket;
            "".length();
            if (" ".length() <= "  ".length()) {}
          }
        }
        else {
          lllllllllllllllllIIIllIIllIlIIII = Items.water_bucket;
        }
        if (lIIIIIIIIIlIl(lllllllllllllllllIIIllIIllIlIIII))
        {
          lllllllllllllllllIIIllIIllIIllll = new ItemStack(lllllllllllllllllIIIllIIllIlIIII, lIlIIlIllll[4], lllllllllllllllllIIIllIIllIlIIIl.getMetaFromState(lllllllllllllllllIIIllIIllIlIIlI));
          lllllllllllllllllIIIllIIllIIlllI = lllllllllllllllllIIIllIIllIlIIIl.getLocalizedName();
        }
      }
      lllllllllllllllllIIIllIIllIllIlI.func_148225_a(lllllllllllllllllIIIllIIllIIlIII, lllllllllllllllllIIIllIIllIIIlll, lllllllllllllllllIIIllIIllIIllll);
      "".length();
      String lllllllllllllllllIIIllIIllIIlIll;
      if (lIIIIIIIIlIll(lllllllllllllllllIIIllIIllIllIIl))
      {
        String lllllllllllllllllIIIllIIllIIllIl = I18n.format(lIlIIlIllIl[lIlIIlIllll[4]], new Object[] { Integer.valueOf(lllllllllllllllllIIIllIIllIlIIll.getLayerCount()) });
        "".length();
        if (-"   ".length() < 0) {}
      }
      else if (lIIIIIIIIIllI(lllllllllllllllllIIIllIIllIllIIl, theFlatGeneratorInfo.getFlatLayers().size() - lIlIIlIllll[4]))
      {
        String lllllllllllllllllIIIllIIllIIllII = I18n.format(lIlIIlIllIl[lIlIIlIllll[5]], new Object[] { Integer.valueOf(lllllllllllllllllIIIllIIllIlIIll.getLayerCount()) });
        "".length();
        if (" ".length() != 0) {}
      }
      else
      {
        lllllllllllllllllIIIllIIllIIlIll = I18n.format(lIlIIlIllIl[lIlIIlIllll[10]], new Object[] { Integer.valueOf(lllllllllllllllllIIIllIIllIlIIll.getLayerCount()) });
      }
      "".length();
    }
    
    private static boolean lIIIIIIIIIlIl(Object ???)
    {
      byte lllllllllllllllllIIIllIIlIIIlIlI;
      return ??? != null;
    }
    
    protected int getSize()
    {
      ;
      return theFlatGeneratorInfo.getFlatLayers().size();
    }
    
    private static boolean lIIIIIIIIlIII(Object ???)
    {
      char lllllllllllllllllIIIllIIlIIIIlII;
      return ??? == null;
    }
    
    private static String lIIIIIIIIIIII(String lllllllllllllllllIIIllIIlIllIIlI, String lllllllllllllllllIIIllIIlIlIllII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllllIIIllIIlIllIIlI = new String(Base64.getDecoder().decode(lllllllllllllllllIIIllIIlIllIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllllIIIllIIlIllIIII = new StringBuilder();
      char[] lllllllllllllllllIIIllIIlIlIllll = lllllllllllllllllIIIllIIlIlIllII.toCharArray();
      int lllllllllllllllllIIIllIIlIlIlllI = lIlIIlIllll[6];
      char lllllllllllllllllIIIllIIlIlIlIII = lllllllllllllllllIIIllIIlIllIIlI.toCharArray();
      float lllllllllllllllllIIIllIIlIlIIlll = lllllllllllllllllIIIllIIlIlIlIII.length;
      char lllllllllllllllllIIIllIIlIlIIllI = lIlIIlIllll[6];
      while (lIIIIIIIIllII(lllllllllllllllllIIIllIIlIlIIllI, lllllllllllllllllIIIllIIlIlIIlll))
      {
        char lllllllllllllllllIIIllIIlIllIIll = lllllllllllllllllIIIllIIlIlIlIII[lllllllllllllllllIIIllIIlIlIIllI];
        "".length();
        "".length();
        if (" ".length() < 0) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllllIIIllIIlIllIIII);
    }
    
    private static boolean lIIIIIIIIIllI(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllllIIIllIIlIIlIlII;
      return ??? == i;
    }
    
    private static boolean lIIIIIIIIllII(int ???, int arg1)
    {
      int i;
      boolean lllllllllllllllllIIIllIIlIIlIIII;
      return ??? < i;
    }
    
    private static void lIIIIIIIIIIIl()
    {
      lIlIIlIllIl = new String[lIlIIlIllll[14]];
      lIlIIlIllIl[lIlIIlIllll[6]] = llllllllllll("xgROjo1QoTI=", "LByxw");
      lIlIIlIllIl[lIlIIlIllll[4]] = lIIIIIIIIIIII("MRwcEyY3ORYAPjZAGgchJgEUGyg3QB8eMyZAFRMrNxxXBj0i", "RnyrR");
      lIlIIlIllIl[lIlIIlIllll[5]] = llllllllllll("XfRbi6mfX5zirZ9QjNd3/XlHxNf0THhAlU4pXEwSV+FjaLi0CwWQ+w==", "RMLuS");
      lIlIIlIllIl[lIlIIlIllll[10]] = llllllllllll("vzTUIykNFsaReTD6/PcG7vZbMQt/pfGj1eiF0DcLfzkZ4iq0Q/baXA==", "LAnAb");
    }
    
    private static String llllllllllll(String lllllllllllllllllIIIllIIlIIlllIl, String lllllllllllllllllIIIllIIlIIlllII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllllIIIllIIlIlIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIllIIlIIlllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllllIIIllIIlIIlllll = Cipher.getInstance("Blowfish");
        lllllllllllllllllIIIllIIlIIlllll.init(lIlIIlIllll[5], lllllllllllllllllIIIllIIlIlIIIII);
        return new String(lllllllllllllllllIIIllIIlIIlllll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIllIIlIIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllllIIIllIIlIIllllI)
      {
        lllllllllllllllllIIIllIIlIIllllI.printStackTrace();
      }
      return null;
    }
  }
}

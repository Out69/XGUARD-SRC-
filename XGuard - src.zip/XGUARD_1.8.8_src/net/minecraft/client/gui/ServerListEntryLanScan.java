package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;

public class ServerListEntryLanScan
  implements GuiListExtended.IGuiListEntry
{
  public void setSelected(int lllllllllllllllllIIIlllIIIIlIlII, int lllllllllllllllllIIIlllIIIIlIIll, int lllllllllllllllllIIIlllIIIIlIIlI) {}
  
  static
  {
    llllllllIlll();
    llllllllIllI();
  }
  
  private static boolean llllllllllII(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllllIIIllIlllIllIll;
    return ??? < i;
  }
  
  private static String llllllllIlII(String lllllllllllllllllIIIllIllllIIlII, String lllllllllllllllllIIIllIllllIIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIIllIllllIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIllIllllIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIIIllIllllIIllI = Cipher.getInstance("Blowfish");
      lllllllllllllllllIIIllIllllIIllI.init(lIlIIlIlIll[0], lllllllllllllllllIIIllIllllIIlll);
      return new String(lllllllllllllllllIIIllIllllIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIllIllllIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIIllIllllIIlIl)
    {
      lllllllllllllllllIIIllIllllIIlIl.printStackTrace();
    }
    return null;
  }
  
  public ServerListEntryLanScan() {}
  
  public boolean mousePressed(int lllllllllllllllllIIIlllIIIIlIIII, int lllllllllllllllllIIIlllIIIIIllll, int lllllllllllllllllIIIlllIIIIIlllI, int lllllllllllllllllIIIlllIIIIIllIl, int lllllllllllllllllIIIlllIIIIIllII, int lllllllllllllllllIIIlllIIIIIlIll)
  {
    return lIlIIlIlIll[1];
  }
  
  private static void llllllllIllI()
  {
    lIlIIlIlIlI = new String[lIlIIlIlIll[7]];
    lIlIIlIlIlI[lIlIIlIlIll[1]] = llllllllIlII("xsjf2AjALKG4FblEcpJaRPEYIXlEq6zy", "wQDXA");
    lIlIIlIlIlI[lIlIIlIlIll[2]] = llllllllIlII("X7zaqrH3AW5X3iASfOVMpflLuTM/WZH7", "WqvNl");
    lIlIIlIlIlI[lIlIIlIlIll[0]] = llllllllIlII("qXFpT5L3j/s=", "eVUfZ");
    lIlIIlIlIlI[lIlIIlIlIll[4]] = llllllllIlIl("PmkZVQY=", "QIVui");
    lIlIIlIlIlI[lIlIIlIlIll[5]] = llllllllIlIl("N1ECbyc=", "XqmOh");
  }
  
  public void mouseReleased(int lllllllllllllllllIIIlllIIIIIlIIl, int lllllllllllllllllIIIlllIIIIIlIII, int lllllllllllllllllIIIlllIIIIIIlll, int lllllllllllllllllIIIlllIIIIIIllI, int lllllllllllllllllIIIlllIIIIIIlIl, int lllllllllllllllllIIIlllIIIIIIlII) {}
  
  public void drawEntry(int lllllllllllllllllIIIlllIIIlIIllI, int lllllllllllllllllIIIlllIIIlIIlIl, int lllllllllllllllllIIIlllIIIIllIIl, int lllllllllllllllllIIIlllIIIlIIIll, int lllllllllllllllllIIIlllIIIlIIIlI, int lllllllllllllllllIIIlllIIIlIIIIl, int lllllllllllllllllIIIlllIIIlIIIII, boolean lllllllllllllllllIIIlllIIIIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllllIIIlllIIIIllllI = lllllllllllllllllIIIlllIIIIllIIl + lllllllllllllllllIIIlllIIIlIIIlI / lIlIIlIlIll[0] - fontRendererObjFONT_HEIGHT / lIlIIlIlIll[0];
    "".length();
    String lllllllllllllllllIIIlllIIIIllIll;
    switch ((int)(Minecraft.getSystemTime() / 300L % 4L))
    {
    case 0: 
    default: 
      String lllllllllllllllllIIIlllIIIIlllIl = lIlIIlIlIlI[lIlIIlIlIll[0]];
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 1: 
    case 3: 
      String lllllllllllllllllIIIlllIIIIlllII = lIlIIlIlIlI[lIlIIlIlIll[4]];
      "".length();
      if ((0x1E ^ 0x1A) < "   ".length()) {
        return;
      }
      break;
    case 2: 
      lllllllllllllllllIIIlllIIIIllIll = lIlIIlIlIlI[lIlIIlIlIll[5]];
    }
    "".length();
  }
  
  private static void llllllllIlll()
  {
    lIlIIlIlIll = new int[8];
    lIlIIlIlIll[0] = "  ".length();
    lIlIIlIlIll[1] = ((0x9A ^ 0x9F) & (0x35 ^ 0x30 ^ 0xFFFFFFFF));
    lIlIIlIlIll[2] = " ".length();
    lIlIIlIlIll[3] = (0xFFFFFFFF & 0xFFFFFF);
    lIlIIlIlIll[4] = "   ".length();
    lIlIIlIlIll[5] = ('' + 27 - 112 + 89 ^ 124 + 20 - 123 + 119);
    lIlIIlIlIll[6] = (-(0xFFFFFFFF & 0x5D53) & 0xFFFFFFD3 & 0x80DDFE);
    lIlIIlIlIll[7] = (' ' + 31 - 64 + 66 ^ 51 + '¸' - 195 + 156);
  }
  
  private static String llllllllIlIl(String lllllllllllllllllIIIllIlllllIlII, String lllllllllllllllllIIIllIllllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIllIlllllIlII = new String(Base64.getDecoder().decode(lllllllllllllllllIIIllIlllllIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIIllIlllllIlll = new StringBuilder();
    char[] lllllllllllllllllIIIllIlllllIllI = lllllllllllllllllIIIllIllllllIII.toCharArray();
    int lllllllllllllllllIIIllIlllllIlIl = lIlIIlIlIll[1];
    char lllllllllllllllllIIIllIllllIllll = lllllllllllllllllIIIllIlllllIlII.toCharArray();
    boolean lllllllllllllllllIIIllIllllIlllI = lllllllllllllllllIIIllIllllIllll.length;
    Exception lllllllllllllllllIIIllIllllIllIl = lIlIIlIlIll[1];
    while (llllllllllII(lllllllllllllllllIIIllIllllIllIl, lllllllllllllllllIIIllIllllIlllI))
    {
      char lllllllllllllllllIIIllIllllllIlI = lllllllllllllllllIIIllIllllIllll[lllllllllllllllllIIIllIllllIllIl];
      "".length();
      "".length();
      if ((0x1 ^ 0x34 ^ 0x88 ^ 0xB9) < 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIIIllIlllllIlll);
  }
}

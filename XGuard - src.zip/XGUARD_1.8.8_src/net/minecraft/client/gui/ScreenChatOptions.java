package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.GameSettings.Options;

public class ScreenChatOptions
  extends GuiScreen
{
  private static void lIIllIIl()
  {
    lIIlII = new int[19];
    lIIlII[0] = (0x32 ^ 0x38);
    lIIlII[1] = ((102 + 21 - 73 + 82 ^ 104 + 53 - 15 + 40) & (0xD2 ^ 0x85 ^ 0xE0 ^ 0x85 ^ -" ".length()));
    lIIlII[2] = " ".length();
    lIIlII[3] = "  ".length();
    lIIlII[4] = "   ".length();
    lIIlII[5] = (0x9A ^ 0x84 ^ 0x6 ^ 0x1C);
    lIIlII[6] = ('' + '' - 233 + 129 ^ 66 + 83 - 116 + 141);
    lIIlII[7] = (0x4C ^ 0x4A);
    lIIlII[8] = (0x49 ^ 0x4E);
    lIIlII[9] = (0x79 ^ 0x5A ^ 0x65 ^ 0x4E);
    lIIlII[10] = (0xFF ^ 0x99 ^ 0x3C ^ 0x53);
    lIIlII[11] = (90 + 39 - 109 + 135);
    lIIlII[12] = (99 + '' - 112 + 16 + (0x6A ^ 0x5) - (0xDD ^ 0xA4) + (0xD ^ 0x16));
    lIIlII[13] = (0x32 ^ 0x57 ^ 0xF6 ^ 0x8B);
    lIIlII[14] = ('' + 90 - 53 + 11 + (0xA9 ^ 0xC5) - (47 + 86 - -6 + 20) + (0x36 ^ 0xE));
    lIIlII[15] = (88 + '' - 79 + 71 ^ 117 + 32 - 18 + 50);
    lIIlII[16] = (0x6B ^ 0x13);
    lIIlII[17] = (0x2B ^ 0x3F);
    lIIlII[18] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
  }
  
  private static String lIIIlIlI(String lllIllIlIIIllII, String lllIllIlIIIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllIllIlIIlIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllIllIlIIIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllIllIlIIlIIII = Cipher.getInstance("Blowfish");
      lllIllIlIIlIIII.init(lIIlII[3], lllIllIlIIlIIIl);
      return new String(lllIllIlIIlIIII.doFinal(Base64.getDecoder().decode(lllIllIlIIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllIllIlIIIllll)
    {
      lllIllIlIIIllll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIllIlI(int ???)
  {
    String lllIllIIllllIll;
    return ??? != 0;
  }
  
  private static boolean lIIlllIl(int ???, int arg1)
  {
    int i;
    double lllIllIlIIIIlIl;
    return ??? == i;
  }
  
  public ScreenChatOptions(GuiScreen lllIllIllIlIIII, GameSettings lllIllIllIlIIlI)
  {
    parentScreen = lllIllIllIlIIll;
    game_settings = lllIllIllIlIIlI;
  }
  
  private static String lIIIlIIl(String lllIllIlIlIIIll, String lllIllIlIIlllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllIllIlIlIIIll = new String(Base64.getDecoder().decode(lllIllIlIlIIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllIllIlIlIIIIl = new StringBuilder();
    char[] lllIllIlIlIIIII = lllIllIlIIlllIl.toCharArray();
    int lllIllIlIIlllll = lIIlII[1];
    Exception lllIllIlIIllIIl = lllIllIlIlIIIll.toCharArray();
    int lllIllIlIIllIII = lllIllIlIIllIIl.length;
    int lllIllIlIIlIlll = lIIlII[1];
    while (lIIlllII(lllIllIlIIlIlll, lllIllIlIIllIII))
    {
      char lllIllIlIlIIlII = lllIllIlIIllIIl[lllIllIlIIlIlll];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(lllIllIlIlIIIIl);
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    int lllIllIllIIIlll = lIIlII[1];
    field_146401_i = I18n.format(lllII[lIIlII[1]], new Object[lIIlII[1]]);
    short lllIllIllIIIIIl = (lllIllIllIIIIII = field_146399_a).length;
    char lllIllIllIIIIlI = lIIlII[1];
    "".length();
    if (null != null) {
      return;
    }
    while (!lIIllIll(lllIllIllIIIIlI, lllIllIllIIIIIl))
    {
      GameSettings.Options lllIllIllIIIllI = lllIllIllIIIIII[lllIllIllIIIIlI];
      if (lIIllIlI(lllIllIllIIIllI.getEnumFloat()))
      {
        new GuiOptionSlider(lllIllIllIIIllI.returnEnumOrdinal(), width / lIIlII[3] - lIIlII[11] + lllIllIllIIIlll % lIIlII[3] * lIIlII[12], height / lIIlII[7] + lIIlII[13] * (lllIllIllIIIlll >> lIIlII[2]), lllIllIllIIIllI);
        "".length();
        "".length();
        if (((0x16 ^ 0x33) & (0x48 ^ 0x6D ^ 0xFFFFFFFF)) == 0) {}
      }
      else
      {
        new GuiOptionButton(lllIllIllIIIllI.returnEnumOrdinal(), width / lIIlII[3] - lIIlII[11] + lllIllIllIIIlll % lIIlII[3] * lIIlII[12], height / lIIlII[7] + lIIlII[13] * (lllIllIllIIIlll >> lIIlII[2]), lllIllIllIIIllI, game_settings.getKeyBinding(lllIllIllIIIllI));
        "".length();
      }
      lllIllIllIIIlll++;
    }
    new GuiButton(lIIlII[14], width / lIIlII[3] - lIIlII[15], height / lIIlII[7] + lIIlII[16], I18n.format(lllII[lIIlII[2]], new Object[lIIlII[1]]));
    "".length();
  }
  
  private static boolean lIIlllII(int ???, int arg1)
  {
    int i;
    String lllIllIIlllllIl;
    return ??? < i;
  }
  
  private static boolean lIIllIll(int ???, int arg1)
  {
    int i;
    float lllIllIlIIIIIIl;
    return ??? >= i;
  }
  
  protected void actionPerformed(GuiButton lllIllIlIllllII)
    throws IOException
  {
    ;
    ;
    if (lIIllIlI(enabled))
    {
      if ((lIIlllII(id, lIIlII[15])) && (lIIllIlI(lllIllIlIllllII instanceof GuiOptionButton)))
      {
        game_settings.setOptionValue(((GuiOptionButton)lllIllIlIllllII).returnEnumOptions(), lIIlII[2]);
        displayString = game_settings.getKeyBinding(GameSettings.Options.getEnumOptions(id));
      }
      if (lIIlllIl(id, lIIlII[14]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(parentScreen);
      }
    }
  }
  
  public void drawScreen(int lllIllIlIllIIII, int lllIllIlIllIIll, float lllIllIlIlIlllI)
  {
    ;
    ;
    ;
    ;
    lllIllIlIllIlIl.drawDefaultBackground();
    lllIllIlIllIlIl.drawCenteredString(fontRendererObj, field_146401_i, width / lIIlII[3], lIIlII[17], lIIlII[18]);
    lllIllIlIllIlIl.drawScreen(lllIllIlIllIIII, lllIllIlIllIIll, lllIllIlIlIlllI);
  }
  
  private static void lIIIlIll()
  {
    lllII = new String[lIIlII[3]];
    lllII[lIIlII[1]] = lIIIlIIl("OyQZACs6J0MKLDUgQx0tIDgI", "TTmiD");
    lllII[lIIlII[2]] = lIIIlIlI("qWeypr1Lrtn09qq+od0dfg==", "TYnRk");
  }
  
  static
  {
    lIIllIIl();
    lIIIlIll();
  }
}

package net.minecraft.client.gui;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.particle.EffectRenderer;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.profiler.Profiler;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.management.ServerConfigurationManager;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.FrameTimer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.chunk.Chunk;
import optfine.Reflector;
import optfine.ReflectorMethod;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;

public class GuiOverlayDebug
  extends Gui
{
  protected void renderDebugInfoRight(ScaledResolution lIlllllIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    List lIlllllIllIII = lIlllllIlIIIl.getDebugInfoRight();
    int lIlllllIlIlll = lIIIlIIIII[0];
    "".length();
    if (-(0x36 ^ 0x32) > 0) {
      return;
    }
    while (!llIllllIlII(lIlllllIlIlll, lIlllllIllIII.size()))
    {
      String lIlllllIlIllI = (String)lIlllllIllIII.get(lIlllllIlIlll);
      if (llIllllIIll(Strings.isNullOrEmpty(lIlllllIlIllI)))
      {
        int lIlllllIlIlIl = fontRenderer.FONT_HEIGHT;
        int lIlllllIlIlII = fontRenderer.getStringWidth(lIlllllIlIllI);
        int lIlllllIlIIll = ScaledResolution.getScaledWidth() - lIIIlIIIII[2] - lIlllllIlIlII;
        int lIlllllIlIIlI = lIIIlIIIII[2] + lIlllllIlIlIl * lIlllllIlIlll;
        drawRect(lIlllllIlIIll - lIIIlIIIII[1], lIlllllIlIIlI - lIIIlIIIII[1], lIlllllIlIIll + lIlllllIlIlII + lIIIlIIIII[1], lIlllllIlIIlI + lIlllllIlIlIl - lIIIlIIIII[1], lIIIlIIIII[3]);
        "".length();
      }
      lIlllllIlIlll++;
    }
  }
  
  private boolean isReducedDebug()
  {
    ;
    if ((llIllllIIll(mc.thePlayer.hasReducedDebug())) && (llIllllIIll(mc.gameSettings.reducedDebugInfo))) {
      return lIIIlIIIII[0];
    }
    return lIIIlIIIII[1];
  }
  
  private static boolean llIlllllIIl(int ???, int arg1)
  {
    int i;
    boolean lIllIlllllIlI;
    return ??? == i;
  }
  
  private static boolean llIllllIlIl(int ???)
  {
    Exception lIllIlllIIIlI;
    return ??? != 0;
  }
  
  private int func_181552_c(int lIlllIllIIIll, int lIlllIllIIlll, int lIlllIllIIIlI, int lIlllIllIIlIl)
  {
    ;
    ;
    ;
    ;
    if (llIlllllIll(lIlllIllIIIll, lIlllIllIIIlI))
    {
      "".length();
      if (-" ".length() < ((0x69 ^ 0x5D) & (0x97 ^ 0xA3 ^ 0xFFFFFFFF))) {
        break label99;
      }
      return (0x26 ^ 0x21) & (0x1C ^ 0x1B ^ 0xFFFFFFFF);
    }
    label99:
    return lIlllIllIlIIl.func_181553_a(lIIIlIIIII[57], lIIIlIIIII[58], (lIlllIllIIIll - lIlllIllIIIlI) / (lIlllIllIIlIl - lIlllIllIIIlI));
  }
  
  protected List call()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    BlockPos lIllllIllllll = new BlockPos(mc.getRenderViewEntity().posX, mc.getRenderViewEntity().getEntityBoundingBox().minY, mc.getRenderViewEntity().posZ);
    if (llIllllIlIl(lIllllIllIllI.isReducedDebug())) {
      return Lists.newArrayList(new String[] { String.valueOf(new StringBuilder(lIIIIlllll[lIIIlIIIII[1]]).append(mc.getVersion()).append(lIIIIlllll[lIIIlIIIII[2]]).append(ClientBrandRetriever.getClientModName()).append(lIIIIlllll[lIIIlIIIII[6]])), mc.debug, mc.renderGlobal.getDebugInfoRenders(), mc.renderGlobal.getDebugInfoEntities(), String.valueOf(new StringBuilder(lIIIIlllll[lIIIlIIIII[7]]).append(mc.effectRenderer.getStatistics()).append(lIIIIlllll[lIIIlIIIII[8]]).append(mc.theWorld.getDebugLoadedEntities())), mc.theWorld.getProviderName(), lIIIIlllll[lIIIlIIIII[9]], String.format(lIIIIlllll[lIIIlIIIII[10]], new Object[] { Integer.valueOf(lIllllIllllll.getX() & lIIIlIIIII[11]), Integer.valueOf(lIllllIllllll.getY() & lIIIlIIIII[11]), Integer.valueOf(lIllllIllllll.getZ() & lIIIlIIIII[11]) }) });
    }
    Entity lIllllIlllllI = mc.getRenderViewEntity();
    EnumFacing lIllllIllllIl = lIllllIlllllI.getHorizontalFacing();
    String lIllllIllllII = lIIIIlllll[lIIIlIIIII[5]];
    switch (GuiOverlayDebug.1.field_178907_a[lIllllIllllIl.ordinal()])
    {
    case 1: 
      lIllllIllllII = lIIIIlllll[lIIIlIIIII[12]];
      "".length();
      if (((0xFB ^ 0x8B ^ 0x1B ^ 0x5B) & ('' + 74 - 124 + 69 ^ 2 + 100 - 2 + 55 ^ -" ".length())) >= " ".length()) {
        return null;
      }
      break;
    case 2: 
      lIllllIllllII = lIIIIlllll[lIIIlIIIII[13]];
      "".length();
      if ("  ".length() < 0) {
        return null;
      }
      break;
    case 3: 
      lIllllIllllII = lIIIIlllll[lIIIlIIIII[14]];
      "".length();
      if (null != null) {
        return null;
      }
      break;
    case 4: 
      lIllllIllllII = lIIIIlllll[lIIIlIIIII[15]];
    }
    ArrayList lIllllIlllIll = Lists.newArrayList(new String[] { String.valueOf(new StringBuilder(lIIIIlllll[lIIIlIIIII[16]]).append(mc.getVersion()).append(lIIIIlllll[lIIIlIIIII[17]]).append(ClientBrandRetriever.getClientModName()).append(lIIIIlllll[lIIIlIIIII[11]])), mc.debug, mc.renderGlobal.getDebugInfoRenders(), mc.renderGlobal.getDebugInfoEntities(), String.valueOf(new StringBuilder(lIIIIlllll[lIIIlIIIII[18]]).append(mc.effectRenderer.getStatistics()).append(lIIIIlllll[lIIIlIIIII[19]]).append(mc.theWorld.getDebugLoadedEntities())), mc.theWorld.getProviderName(), lIIIIlllll[lIIIlIIIII[20]], String.format(lIIIIlllll[lIIIlIIIII[21]], new Object[] { Double.valueOf(mc.getRenderViewEntity().posX), Double.valueOf(mc.getRenderViewEntity().getEntityBoundingBox().minY), Double.valueOf(mc.getRenderViewEntity().posZ) }), String.format(lIIIIlllll[lIIIlIIIII[22]], new Object[] { Integer.valueOf(lIllllIllllll.getX()), Integer.valueOf(lIllllIllllll.getY()), Integer.valueOf(lIllllIllllll.getZ()) }), String.format(lIIIIlllll[lIIIlIIIII[23]], new Object[] { Integer.valueOf(lIllllIllllll.getX() & lIIIlIIIII[11]), Integer.valueOf(lIllllIllllll.getY() & lIIIlIIIII[11]), Integer.valueOf(lIllllIllllll.getZ() & lIIIlIIIII[11]), Integer.valueOf(lIllllIllllll.getX() >> lIIIlIIIII[7]), Integer.valueOf(lIllllIllllll.getY() >> lIIIlIIIII[7]), Integer.valueOf(lIllllIllllll.getZ() >> lIIIlIIIII[7]) }), String.format(lIIIIlllll[lIIIlIIIII[24]], new Object[] { lIllllIllllIl, lIllllIllllII, Float.valueOf(MathHelper.wrapAngleTo180_float(rotationYaw)), Float.valueOf(MathHelper.wrapAngleTo180_float(rotationPitch)) }) });
    if ((llIllllIllI(mc.theWorld)) && (llIllllIlIl(mc.theWorld.isBlockLoaded(lIllllIllllll))))
    {
      Chunk lIllllIlllIlI = mc.theWorld.getChunkFromBlockCoords(lIllllIllllll);
      new StringBuilder(lIIIIlllll[lIIIlIIIII[25]]);
      "".length();
      new StringBuilder(lIIIIlllll[lIIIlIIIII[26]]);
      "".length();
      DifficultyInstance lIllllIlllIIl = mc.theWorld.getDifficultyForLocation(lIllllIllllll);
      if ((llIllllIlIl(mc.isIntegratedServerRunning())) && (llIllllIllI(mc.getIntegratedServer())))
      {
        EntityPlayerMP lIllllIlllIII = mc.getIntegratedServer().getConfigurationManager().getPlayerByUUID(mc.thePlayer.getUniqueID());
        if (llIllllIllI(lIllllIlllIII)) {
          lIllllIlllIIl = worldObj.getDifficultyForLocation(new BlockPos(lIllllIlllIII));
        }
      }
      "".length();
    }
    if ((llIllllIllI(mc.entityRenderer)) && (llIllllIlIl(mc.entityRenderer.isShaderActive())))
    {
      new StringBuilder(lIIIIlllll[lIIIlIIIII[31]]);
      "".length();
    }
    if ((llIllllIllI(mc.objectMouseOver)) && (llIllllIlll(mc.objectMouseOver.typeOfHit, MovingObjectPosition.MovingObjectType.BLOCK)) && (llIllllIllI(mc.objectMouseOver.getBlockPos())))
    {
      BlockPos lIllllIllIlll = mc.objectMouseOver.getBlockPos();
      "".length();
    }
    return lIllllIlllIll;
  }
  
  private int func_181553_a(int lIlllIlIlIIII, int lIlllIlIIIIII, float lIlllIlIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lIlllIlIIllIl = lIlllIlIlIIII >> lIIIlIIIII[26] & lIIIlIIIII[59];
    int lIlllIlIIllII = lIlllIlIlIIII >> lIIIlIIIII[18] & lIIIlIIIII[59];
    int lIlllIlIIlIll = lIlllIlIlIIII >> lIIIlIIIII[5] & lIIIlIIIII[59];
    int lIlllIlIIlIlI = lIlllIlIlIIII & lIIIlIIIII[59];
    int lIlllIlIIlIIl = lIlllIlIIllll >> lIIIlIIIII[26] & lIIIlIIIII[59];
    int lIlllIlIIlIII = lIlllIlIIllll >> lIIIlIIIII[18] & lIIIlIIIII[59];
    int lIlllIlIIIlll = lIlllIlIIllll >> lIIIlIIIII[5] & lIIIlIIIII[59];
    int lIlllIlIIIllI = lIlllIlIIllll & lIIIlIIIII[59];
    int lIlllIlIIIlIl = MathHelper.clamp_int((int)(lIlllIlIIllIl + (lIlllIlIIlIIl - lIlllIlIIllIl) * lIlllIlIIlllI), lIIIlIIIII[0], lIIIlIIIII[59]);
    int lIlllIlIIIlII = MathHelper.clamp_int((int)(lIlllIlIIllII + (lIlllIlIIlIII - lIlllIlIIllII) * lIlllIlIIlllI), lIIIlIIIII[0], lIIIlIIIII[59]);
    int lIlllIlIIIIll = MathHelper.clamp_int((int)(lIlllIlIIlIll + (lIlllIlIIIlll - lIlllIlIIlIll) * lIlllIlIIlllI), lIIIlIIIII[0], lIIIlIIIII[59]);
    int lIlllIlIIIIlI = MathHelper.clamp_int((int)(lIlllIlIIlIlI + (lIlllIlIIIllI - lIlllIlIIlIlI) * lIlllIlIIlllI), lIIIlIIIII[0], lIIIlIIIII[59]);
    return lIlllIlIIIlIl << lIIIlIIIII[26] | lIlllIlIIIlII << lIIIlIIIII[18] | lIlllIlIIIIll << lIIIlIIIII[5] | lIlllIlIIIIlI;
  }
  
  private static String llIllllIIII(String lIlllIIIIIIIl, String lIlllIIIIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIlllIIIIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIlllIIIIIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIlllIIIIIlIl = Cipher.getInstance("Blowfish");
      lIlllIIIIIlIl.init(lIIIlIIIII[2], lIlllIIIIIllI);
      return new String(lIlllIIIIIlIl.doFinal(Base64.getDecoder().decode(lIlllIIIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIlllIIIIIlII)
    {
      lIlllIIIIIlII.printStackTrace();
    }
    return null;
  }
  
  private static long bytesToMb(long lIlllIIllIIII)
  {
    ;
    return lIlllIIllIIII / 1024L / 1024L;
  }
  
  private static boolean llIllllIllI(Object ???)
  {
    char lIllIlllIlIII;
    return ??? != null;
  }
  
  protected List getDebugInfoRight()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    long lIllllIlIIIIl = Runtime.getRuntime().maxMemory();
    long lIllllIlIIIII = Runtime.getRuntime().totalMemory();
    long lIllllIIlllll = Runtime.getRuntime().freeMemory();
    long lIllllIIllllI = lIllllIlIIIII - lIllllIIlllll;
    if (llIllllIlIl(mc.isJava64bit()))
    {
      "".length();
      if (-(0x31 ^ 0x35) < 0) {
        break label129;
      }
      return null;
    }
    label129:
    lIIIlIIIII[1][lIIIlIIIII[35]] = Integer.valueOf(lIIIlIIIII[34]);
    lIIIlIIIII[0][lIIIIlllll[lIIIlIIIII[33]]] = String.format(tmp81_61, new Object[] { System.getProperty(lIIIIlllll[lIIIlIIIII[34]]) });
    String[] tmp137_34 = new String[lIIIlIIIII[12]];
    tmp137_34[lIIIlIIIII[1]] = String.format(lIIIIlllll[lIIIlIIIII[36]], new Object[] { Long.valueOf(lIllllIIllllI * 100L / lIllllIlIIIIl), Long.valueOf(bytesToMb(lIllllIIllllI)), Long.valueOf(bytesToMb(lIllllIlIIIIl)) });
    String[] tmp213_137 = tmp137_34;
    tmp213_137[lIIIlIIIII[2]] = String.format(lIIIIlllll[lIIIlIIIII[37]], new Object[] { Long.valueOf(lIllllIlIIIII * 100L / lIllllIlIIIIl), Long.valueOf(bytesToMb(lIllllIlIIIII)) });
    String[] tmp272_213 = tmp213_137;
    tmp272_213[lIIIlIIIII[6]] = lIIIIlllll[lIIIlIIIII[38]];
    String[] tmp290_272 = tmp272_213;
    tmp290_272[lIIIlIIIII[7]] = String.format(lIIIIlllll[lIIIlIIIII[39]], new Object[] { OpenGlHelper.func_183029_j() });
    String[] tmp329_290 = tmp290_272;
    tmp329_290[lIIIlIIIII[8]] = lIIIIlllll[lIIIlIIIII[40]];
    String[] tmp347_329 = tmp329_290;
    tmp347_329[lIIIlIIIII[9]] = String.format(lIIIIlllll[lIIIlIIIII[41]], new Object[] { Integer.valueOf(Display.getWidth()), Integer.valueOf(Display.getHeight()), GL11.glGetString(lIIIlIIIII[42]) });
    String[] tmp419_347 = tmp347_329;
    tmp419_347[lIIIlIIIII[10]] = GL11.glGetString(lIIIlIIIII[43]);
    String[] tmp436_419 = tmp419_347;
    tmp436_419[lIIIlIIIII[5]] = GL11.glGetString(lIIIlIIIII[44]);
    ArrayList lIllllIIlllIl = Lists.newArrayList(tmp436_419);
    if (llIllllIlIl(Reflector.FMLCommonHandler_getBrandings.exists()))
    {
      Object lIllllIIlllII = Reflector.call(Reflector.FMLCommonHandler_instance, new Object[lIIIlIIIII[0]]);
      "".length();
      "".length();
    }
    if (llIllllIlIl(lIllllIIlIllI.isReducedDebug())) {
      return lIllllIIlllIl;
    }
    if ((llIllllIllI(mc.objectMouseOver)) && (llIllllIlll(mc.objectMouseOver.typeOfHit, MovingObjectPosition.MovingObjectType.BLOCK)) && (llIllllIllI(mc.objectMouseOver.getBlockPos())))
    {
      BlockPos lIllllIIllIll = mc.objectMouseOver.getBlockPos();
      IBlockState lIllllIIllIlI = mc.theWorld.getBlockState(lIllllIIllIll);
      if (llIlllllIII(mc.theWorld.getWorldType(), WorldType.DEBUG_WORLD)) {
        lIllllIIllIlI = lIllllIIllIlI.getBlock().getActualState(lIllllIIllIlI, mc.theWorld, lIllllIIllIll);
      }
      "".length();
      "".length();
      Iterator lIllllIIlIlll = lIllllIIllIlI.getProperties().entrySet().iterator();
      "".length();
      if ((0x37 ^ 0x33) == 0) {
        return null;
      }
      while (!llIllllIIll(lIllllIIlIlll.hasNext()))
      {
        Map.Entry lIllllIIllIIl = (Map.Entry)lIllllIIlIlll.next();
        String lIllllIIllIII = ((Comparable)lIllllIIllIIl.getValue()).toString();
        if (llIllllIlll(lIllllIIllIIl.getValue(), Boolean.TRUE))
        {
          lIllllIIllIII = String.valueOf(new StringBuilder().append(EnumChatFormatting.GREEN).append(lIllllIIllIII));
          "".length();
          if (-(0x24 ^ 0x74 ^ 0x11 ^ 0x45) >= 0) {
            return null;
          }
        }
        else if (llIllllIlll(lIllllIIllIIl.getValue(), Boolean.FALSE))
        {
          lIllllIIllIII = String.valueOf(new StringBuilder().append(EnumChatFormatting.RED).append(lIllllIIllIII));
        }
        new StringBuilder(String.valueOf(((IProperty)lIllllIIllIIl.getKey()).getName()));
        "".length();
      }
    }
    return lIllllIIlllIl;
  }
  
  private static boolean llIllllIlII(int ???, int arg1)
  {
    int i;
    int lIllIllllIllI;
    return ??? >= i;
  }
  
  protected void renderDebugInfoLeft()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    List lIlllllllIIIl = lIlllllllIIlI.call();
    int lIlllllllIIII = lIIIlIIIII[0];
    "".length();
    if (null != null) {
      return;
    }
    while (!llIllllIlII(lIlllllllIIII, lIlllllllIIIl.size()))
    {
      String lIllllllIllll = (String)lIlllllllIIIl.get(lIlllllllIIII);
      if (llIllllIIll(Strings.isNullOrEmpty(lIllllllIllll)))
      {
        int lIllllllIlllI = fontRenderer.FONT_HEIGHT;
        int lIllllllIllIl = fontRenderer.getStringWidth(lIllllllIllll);
        boolean lIllllllIllII = lIIIlIIIII[1];
        int lIllllllIlIll = lIIIlIIIII[2] + lIllllllIlllI * lIlllllllIIII;
        drawRect(lIIIlIIIII[1], lIllllllIlIll - lIIIlIIIII[1], lIIIlIIIII[2] + lIllllllIllIl + lIIIlIIIII[1], lIllllllIlIll + lIllllllIlllI - lIIIlIIIII[1], lIIIlIIIII[3]);
        "".length();
      }
      lIlllllllIIII++;
    }
  }
  
  private static void llIllllIIlI()
  {
    lIIIlIIIII = new int[62];
    lIIIlIIIII[0] = ((0x1A ^ 0x2A) & (0xB2 ^ 0x82 ^ 0xFFFFFFFF));
    lIIIlIIIII[1] = " ".length();
    lIIIlIIIII[2] = "  ".length();
    lIIIlIIIII[3] = (-(0xAFFC & 0x6FAFFFB3));
    lIIIlIIIII[4] = (-(0x930F & 0x7FF1) & 0xFFFFFFF0 & 0xE0F3EF);
    lIIIlIIIII[5] = (0x77 ^ 0x60 ^ 0x1B ^ 0x4);
    lIIIlIIIII[6] = "   ".length();
    lIIIlIIIII[7] = (0x21 ^ 0x25);
    lIIIlIIIII[8] = (0xD1 ^ 0x9C ^ 0xF4 ^ 0xBC);
    lIIIlIIIII[9] = (0xE7 ^ 0xBF ^ 0xCD ^ 0x93);
    lIIIlIIIII[10] = (0x10 ^ 0x78 ^ 0x36 ^ 0x59);
    lIIIlIIIII[11] = (0x37 ^ 0x38);
    lIIIlIIIII[12] = (0x63 ^ 0x6A);
    lIIIlIIIII[13] = (0xF7 ^ 0x96 ^ 0xAC ^ 0xC7);
    lIIIlIIIII[14] = (0x42 ^ 0x49);
    lIIIlIIIII[15] = (86 + 99 - 66 + 23 ^ 99 + 66 - 39 + 4);
    lIIIlIIIII[16] = (0x40 ^ 0x4D);
    lIIIlIIIII[17] = (0x66 ^ 0x68);
    lIIIlIIIII[18] = (86 + 12 - -90 + 0 ^ 41 + 93 - 119 + 157);
    lIIIlIIIII[19] = (0x70 ^ 0x24 ^ 0xEE ^ 0xAB);
    lIIIlIIIII[20] = (0xE4 ^ 0x82 ^ 0x2B ^ 0x5F);
    lIIIlIIIII[21] = (0x12 ^ 0x1);
    lIIIlIIIII[22] = (0xA2 ^ 0xB5 ^ "   ".length());
    lIIIlIIIII[23] = (0xAF ^ 0xBA);
    lIIIlIIIII[24] = (98 + 15 - 8 + 50 ^ 72 + 94 - 141 + 116);
    lIIIlIIIII[25] = (0xB4 ^ 0xA3);
    lIIIlIIIII[26] = (0x76 ^ 0x1 ^ 0xE5 ^ 0x8A);
    lIIIlIIIII[27] = (0x6B ^ 0x1F ^ 0x4B ^ 0x26);
    lIIIlIIIII[28] = (0x99 ^ 0x83);
    lIIIlIIIII[29] = (0x2 ^ 0x19);
    lIIIlIIIII[30] = (0x41 ^ 0x5D);
    lIIIlIIIII[31] = (0x84 ^ 0x99);
    lIIIlIIIII[32] = (0x79 ^ 0x4D ^ 0x1D ^ 0x37);
    lIIIlIIIII[33] = (0x3E ^ 0x21);
    lIIIlIIIII[34] = ('' + 126 - 107 + 4 ^ 51 + 125 - 129 + 93);
    lIIIlIIIII[35] = (0x58 ^ 0x5D ^ 0xD1 ^ 0x94);
    lIIIlIIIII[36] = (0x34 ^ 0x15);
    lIIIlIIIII[37] = (0x45 ^ 0x67);
    lIIIlIIIII[38] = (0x4C ^ 0x68 ^ 0x2D ^ 0x2A);
    lIIIlIIIII[39] = (0x74 ^ 0x50);
    lIIIlIIIII[40] = (0xAB ^ 0x8E);
    lIIIlIIIII[41] = (0x22 ^ 0x4);
    lIIIlIIIII[42] = (-(0xCF7E & 0x70F9) & 0xFFFFFFFF & 0x5F77);
    lIIIlIIIII[43] = (-(0xF3EF & 0x2CFF) & 0xBFEF & 0x7FFF);
    lIIIlIIIII[44] = (-(116 + 9 - -2 + 71) & 0xDFD7 & 0x3FEF);
    lIIIlIIIII[45] = (0x6C ^ 0x15 ^ 0x7 ^ 0x59);
    lIIIlIIIII[46] = (0x2C ^ 0x1F ^ 0x7C ^ 0x67);
    lIIIlIIIII[47] = (0xAD ^ 0x84);
    lIIIlIIIII[48] = (17 + 96 - -4 + 45 ^ 89 + 9 - 67 + 127);
    lIIIlIIIII[49] = (48 + '' - 109 + 143);
    lIIIlIIIII[50] = (0x99 ^ 0x9E ^ 0x16 ^ 0x3B);
    lIIIlIIIII[51] = ((0x12 ^ 0x2B) + (29 + 117 - 106 + 183) - (93 + 25 - 31 + 65) + (0x52 ^ 0x3D));
    lIIIlIIIII[52] = (-" ".length());
    lIIIlIIIII[53] = (0x18 ^ 0x9 ^ 0x14 ^ 0x2E);
    lIIIlIIIII[54] = (0x74 ^ 0xC);
    lIIIlIIIII[55] = (-(0xC789 & 0xFF3877));
    lIIIlIIIII[56] = (-(0xBB6D & 0xFF4592));
    lIIIlIIIII[57] = (-(-(0xED6B & 0x769F) & 0xEDFB & 0x770E));
    lIIIlIIIII[58] = (-(-(0x8FF5 & 0x796F) & 0xFFFFFFEE & 0x10975));
    lIIIlIIIII[59] = (101 + 42 - -71 + 41);
    lIIIlIIIII[60] = (0x5B ^ 0x71 ^ 0xB1 ^ 0xB7);
    lIIIlIIIII[61] = (0x74 ^ 0x68 ^ 0xB9 ^ 0x88);
  }
  
  private static String llIlllIlllI(String lIlllIIlIIIII, String lIlllIIIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIlllIIlIIIII = new String(Base64.getDecoder().decode(lIlllIIlIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIlllIIlIIIll = new StringBuilder();
    char[] lIlllIIlIIIlI = lIlllIIIlllll.toCharArray();
    int lIlllIIlIIIIl = lIIIlIIIII[0];
    String lIlllIIIllIll = lIlllIIlIIIII.toCharArray();
    double lIlllIIIllIlI = lIlllIIIllIll.length;
    int lIlllIIIllIIl = lIIIlIIIII[0];
    while (llIlllllIll(lIlllIIIllIIl, lIlllIIIllIlI))
    {
      char lIlllIIlIIllI = lIlllIIIllIll[lIlllIIIllIIl];
      "".length();
      "".length();
      if ((0xA8 ^ 0xAD) == 0) {
        return null;
      }
    }
    return String.valueOf(lIlllIIlIIIll);
  }
  
  private static void llIllllIIIl()
  {
    lIIIIlllll = new String[lIIIlIIIII[61]];
    lIIIIlllll[lIIIlIIIII[0]] = llIlllIlllI("HjcxOwM=", "zRSNd");
    lIIIIlllll[lIIIlIIIII[1]] = llIlllIllll("zkwIUvwW6zEl0RKxlcQUGjWW5aKln+qF", "gHUkL");
    lIIIIlllll[lIIIlIIIII[2]] = llIllllIIII("FTbkJd/wMTY=", "OcRSv");
    lIIIIlllll[lIIIlIIIII[6]] = llIlllIllll("u9h21UdND6k=", "UphDk");
    lIIIIlllll[lIIIlIIIII[7]] = llIlllIlllI("Bmpo", "VPHup");
    lIIIIlllll[lIIIlIIIII[8]] = llIlllIlllI("XGcQXXo=", "rGDgZ");
    lIIIIlllll[lIIIlIIIII[9]] = llIllllIIII("bHtwu2MoSPU=", "pNnIv");
    lIIIIlllll[lIIIlIIIII[10]] = llIllllIIII("KxA4APrKvC+35C3kvk4EDqJwS6daTa1yeLen6bXcobU=", "qQAIh");
    lIIIIlllll[lIIIlIIIII[5]] = llIlllIlllI("OwIEFwIbCA==", "rlrvn");
    lIIIIlllll[lIIIlIIIII[12]] = llIlllIlllI("JxUzBD8XCWQLKBQbMAw7Floe", "szDeM");
    lIIIIlllll[lIIIlIIIII[13]] = llIlllIllll("Lpvdj3gsaclEileCRHs2Xlk/+xFc2pLV", "IDWEr");
    lIIIIlllll[lIIIlIIIII[14]] = llIllllIIII("uwMIlFPMyfStwP7hNL2gojbzUlsU3Tg/", "NGsgr");
    lIIIIlllll[lIIIlIIIII[15]] = llIlllIllll("8zxUP7OaWaVsSyTYIHRqR6K8/wksxwi5", "qjJYr");
    lIIIIlllll[lIIIlIIIII[16]] = llIlllIlllI("FxojHAsoEisNSGtddVdQels=", "ZsMyh");
    lIIIIlllll[lIIIlIIIII[17]] = llIlllIlllI("aA==", "GmemG");
    lIIIIlllll[lIIIlIIIII[11]] = llIlllIllll("5yH/zkf9KDE=", "oqucL");
    lIIIIlllll[lIIIlIIIII[18]] = llIllllIIII("W4isoKzUZBY=", "ZILCe");
    lIIIIlllll[lIIIlIIIII[19]] = llIllllIIII("i/swjBnQH3Y=", "MfGER");
    lIIIIlllll[lIIIlIIIII[20]] = llIlllIllll("OsQnEpkLWyA=", "lIDYd");
    lIIIIlllll[lIIIlIIIII[21]] = llIlllIllll("UdoxsLd0oHjzfIhQRBQGTLnKt3REXnhR", "XCIZk");
    lIIIIlllll[lIIIlIIIII[22]] = llIlllIlllI("BzYEAAN/ek4HSGA+S0YM", "EZkch");
    lIIIIlllll[lIIIlIIIII[23]] = llIlllIllll("HaBKzvVg4lsMrw8lxlfWSSscE9nvYxVdvoWQizcZ4tM=", "VudKW");
    lIIIIlllll[lIIIlIIIII[24]] = llIlllIlllI("FzItCx02aW5HAHF7axFacXtrTEI3c2FCVn9iKEs=", "QSNbs");
    lIIIIlllll[lIIIlIIIII[25]] = llIlllIllll("JlD5napJrbs=", "NwqWa");
    lIIIIlllll[lIIIlIIIII[26]] = llIlllIlllI("Ah8wESR0Vg==", "NvWyP");
    lIIIIlllll[lIIIlIIIII[27]] = llIlllIllll("u9Joo+9bpcw=", "ztlwQ");
    lIIIIlllll[lIIIlIIIII[28]] = llIlllIlllI("ThoeCENO", "niuqo");
    lIIIIlllll[lIIIlIIIII[29]] = llIllllIIII("xZW9eWC6MqI=", "mlTcR");
    lIIIIlllll[lIIIlIIIII[30]] = llIlllIlllI("Az8sERlvFCYWEyYzOhwBNmpvVVt9Nm9YMS4pb1URZg==", "OPOpu");
    lIIIIlllll[lIIIlIIIII[31]] = llIlllIllll("pY7SrpmGVzSa470ZeIPHgA==", "lEzbP");
    lIIIIlllll[lIIIlIIIII[32]] = llIlllIlllI("PzomDhgdMmkEBUl1bAFRVjFpQBU=", "sUIeq");
    lIIIIlllll[lIIIlIIIII[33]] = llIlllIlllI("MhUbBVxYUR5EQxwWBBA=", "xtmdf");
    lIIIIlllll[lIIIlIIIII[34]] = llIlllIllll("S6zsYP8qQ6+bmj/Mv9J/dQ==", "tGKyH");
    lIIIIlllll[lIIIlIIIII[36]] = llIllllIIII("d/mPrJRK4eb47ytM0Itzt7mZfWOWQAsd", "DNxlj");
    lIIIIlllll[lIIIlIIIII[37]] = llIllllIIII("GTUkJ7iQN6XE/oWleBJ1qk68XzT3xSDO0cVbQXOmXGc=", "bPfdl");
    lIIIIlllll[lIIIlIIIII[38]] = llIlllIllll("zgrl28UHSSg=", "eloGa");
    lIIIIlllll[lIIIlIIIII[39]] = llIllllIIII("tj8xemyCFEY=", "oFUca");
    lIIIIlllll[lIIIlIIIII[40]] = llIlllIllll("RgwtiCiaPu4=", "mBkGE");
    lIIIIlllll[lIIIlIIIII[41]] = llIlllIllll("qDBQy1eXnN5U1bWsoMxW6itlT30e6lME", "qoCqh");
    lIIIIlllll[lIIIlIIIII[45]] = llIllllIIII("8bEwzOP/6M4=", "INoLw");
    lIIIIlllll[lIIIlIIIII[46]] = llIllllIIII("ZaTC5nRitJQ=", "NfMRl");
    lIIIIlllll[lIIIlIIIII[47]] = llIlllIlllI("b0Y=", "UfYVa");
    lIIIIlllll[lIIIlIIIII[50]] = llIlllIlllI("Yl8=", "ToWKw");
    lIIIIlllll[lIIIlIIIII[53]] = llIllllIIII("pZLafOml014=", "DqCdR");
    lIIIIlllll[lIIIlIIIII[60]] = llIlllIlllI("IjUcal1RSXJjWFc=", "ayCZm");
  }
  
  public GuiOverlayDebug(Minecraft llIIIIIIIIllI)
  {
    mc = llIIIIIIIIllI;
    fontRenderer = Minecraft.fontRendererObj;
  }
  
  private static String llIlllIllll(String lIlllIIIlIIII, String lIlllIIIIllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIlllIIIlIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIlllIIIIllIl.getBytes(StandardCharsets.UTF_8)), lIIIlIIIII[5]), "DES");
      Cipher lIlllIIIlIIlI = Cipher.getInstance("DES");
      lIlllIIIlIIlI.init(lIIIlIIIII[2], lIlllIIIlIIll);
      return new String(lIlllIIIlIIlI.doFinal(Base64.getDecoder().decode(lIlllIIIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIlllIIIlIIIl)
    {
      lIlllIIIlIIIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIlllllIII(Object ???, Object arg1)
  {
    Object localObject;
    byte lIllIlllIlIlI;
    return ??? != localObject;
  }
  
  public void renderDebugInfo(ScaledResolution llIIIIIIIIIII)
  {
    ;
    ;
    mc.mcProfiler.startSection(lIIIIlllll[lIIIlIIIII[0]]);
    GlStateManager.pushMatrix();
    lIlllllllllll.renderDebugInfoLeft();
    lIlllllllllll.renderDebugInfoRight(llIIIIIIIIIII);
    GlStateManager.popMatrix();
    mc.mcProfiler.endSection();
  }
  
  private static boolean llIlllllIlI(int ???, int arg1)
  {
    int i;
    double lIllIlllIlllI;
    return ??? <= i;
  }
  
  private void func_181554_e()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.disableDepth();
    FrameTimer lIllllIIIIIII = mc.func_181539_aj();
    int lIlllIlllllll = lIllllIIIIIII.func_181749_a();
    int lIlllIllllllI = lIllllIIIIIII.func_181750_b();
    long[] lIlllIlllllIl = lIllllIIIIIII.func_181746_c();
    ScaledResolution lIlllIlllllII = new ScaledResolution(mc);
    int lIlllIllllIll = lIlllIlllllll;
    int lIlllIllllIlI = lIIIlIIIII[0];
    drawRect(lIIIlIIIII[0], lIlllIlllllII.getScaledHeight() - lIIIlIIIII[48], lIIIlIIIII[49], lIlllIlllllII.getScaledHeight(), lIIIlIIIII[3]);
    "".length();
    if ("   ".length() == (24 + 100 - 43 + 46 ^ 0x40 ^ 0x3B)) {
      return;
    }
    while (!llIlllllIIl(lIlllIllllIll, lIlllIllllllI))
    {
      int lIlllIllllIIl = lIllllIIIIIII.func_181748_a(lIlllIlllllIl[lIlllIllllIll], lIIIlIIIII[32]);
      int lIlllIllllIII = lIllllIIIIIIl.func_181552_c(MathHelper.clamp_int(lIlllIllllIIl, lIIIlIIIII[0], lIIIlIIIII[48]), lIIIlIIIII[0], lIIIlIIIII[32], lIIIlIIIII[48]);
      lIllllIIIIIIl.drawVerticalLine(lIlllIllllIlI, lIlllIlllllII.getScaledHeight(), lIlllIlllllII.getScaledHeight() - lIlllIllllIIl, lIlllIllllIII);
      lIlllIllllIlI++;
      lIlllIllllIll = lIllllIIIIIII.func_181751_b(lIlllIllllIll + lIIIlIIIII[1]);
    }
    drawRect(lIIIlIIIII[1], lIlllIlllllII.getScaledHeight() - lIIIlIIIII[32] + lIIIlIIIII[1], lIIIlIIIII[17], lIlllIlllllII.getScaledHeight() - lIIIlIIIII[32] + lIIIlIIIII[13], lIIIlIIIII[3]);
    "".length();
    lIllllIIIIIIl.drawHorizontalLine(lIIIlIIIII[0], lIIIlIIIII[51], lIlllIlllllII.getScaledHeight() - lIIIlIIIII[32], lIIIlIIIII[52]);
    drawRect(lIIIlIIIII[1], lIlllIlllllII.getScaledHeight() - lIIIlIIIII[48] + lIIIlIIIII[1], lIIIlIIIII[17], lIlllIlllllII.getScaledHeight() - lIIIlIIIII[48] + lIIIlIIIII[13], lIIIlIIIII[3]);
    "".length();
    lIllllIIIIIIl.drawHorizontalLine(lIIIlIIIII[0], lIIIlIIIII[51], lIlllIlllllII.getScaledHeight() - lIIIlIIIII[48], lIIIlIIIII[52]);
    lIllllIIIIIIl.drawHorizontalLine(lIIIlIIIII[0], lIIIlIIIII[51], lIlllIlllllII.getScaledHeight() - lIIIlIIIII[1], lIIIlIIIII[52]);
    lIllllIIIIIIl.drawVerticalLine(lIIIlIIIII[0], lIlllIlllllII.getScaledHeight() - lIIIlIIIII[48], lIlllIlllllII.getScaledHeight(), lIIIlIIIII[52]);
    lIllllIIIIIIl.drawVerticalLine(lIIIlIIIII[51], lIlllIlllllII.getScaledHeight() - lIIIlIIIII[48], lIlllIlllllII.getScaledHeight(), lIIIlIIIII[52]);
    if (llIlllllIlI(mc.gameSettings.limitFramerate, lIIIlIIIII[54])) {
      lIllllIIIIIIl.drawHorizontalLine(lIIIlIIIII[0], lIIIlIIIII[51], lIlllIlllllII.getScaledHeight() - lIIIlIIIII[48] + mc.gameSettings.limitFramerate / lIIIlIIIII[2], lIIIlIIIII[55]);
    }
    GlStateManager.enableDepth();
  }
  
  private static boolean llIllllIIll(int ???)
  {
    long lIllIlllIIIII;
    return ??? == 0;
  }
  
  private static boolean llIllllIlll(Object ???, Object arg1)
  {
    Object localObject;
    String lIllIlllIIlII;
    return ??? == localObject;
  }
  
  static
  {
    llIllllIIlI();
    llIllllIIIl();
  }
  
  private static boolean llIlllllIll(int ???, int arg1)
  {
    int i;
    byte lIllIllllIIlI;
    return ??? < i;
  }
}

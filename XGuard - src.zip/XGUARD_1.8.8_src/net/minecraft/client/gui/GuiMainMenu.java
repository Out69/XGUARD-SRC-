package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.IResource;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.realms.RealmsBridge;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.demo.DemoWorldServer;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.WorldInfo;
import org.apache.commons.io.Charsets;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.ContextCapabilities;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLContext;
import org.lwjgl.util.glu.Project;
import pl.xguard.loaders.WingsManager;
import pl.xguard.utils.RenderUtils;

public class GuiMainMenu
  extends GuiScreen
  implements GuiYesNoCallback
{
  private static boolean llIIIIlllII(int ???, int arg1)
  {
    int i;
    Exception lIIIlIllIlIIIl;
    return ??? == i;
  }
  
  private static void llIIIIlIlll()
  {
    llllIIIlI = new int[62];
    llllIIIlI[0] = ((62 + 13 - -62 + 8 ^ 25 + 80 - -15 + 21) & (123 + 49 - 109 + 108 ^ 91 + '' - 65 + 14 ^ -" ".length()));
    llllIIIlI[1] = " ".length();
    llllIIIlI[2] = (30 + 58 - 37 + 101 ^ 12 + 24 - -66 + 56);
    llllIIIlI[3] = "  ".length();
    llllIIIlI[4] = "   ".length();
    llllIIIlI[5] = (0x9B ^ 0x9F);
    llllIIIlI[6] = ('´' + 120 - 171 + 57 ^ '´' + 110 - 112 + 13);
    llllIIIlI[7] = (0x75 ^ 0x2D ^ 0xA ^ 0x55);
    llllIIIlI[8] = (104 + 0 - -37 + 49 ^ 0 + 110 - -30 + 42);
    llllIIIlI[9] = (0x84 ^ 0x8D);
    llllIIIlI[10] = (0x60 ^ 0x6A);
    llllIIIlI[11] = (0xA7 ^ 0xAC);
    llllIIIlI[12] = (-(0xDBB7 & 0x34D9) & 0xF7FF & 0x77F5BBF);
    llllIIIlI[13] = (0x10 ^ 0x1C);
    llllIIIlI[14] = (0x38 ^ 0x5A ^ 0xD5 ^ 0xBA);
    llllIIIlI[15] = (0xAE ^ 0xA0);
    llllIIIlI[16] = (0xE9 ^ 0xC2 ^ 0x73 ^ 0x57);
    llllIIIlI[17] = (-(0xFA8B & 0x57F7) & 0xFFFFFFF6 & 0x538B);
    llllIIIlI[18] = (3 + 59 - 1 + 70 ^ 67 + 99 - 68 + 49);
    llllIIIlI[19] = (46 + '' - 110 + 86 ^ 68 + 101 - 132 + 93);
    llllIIIlI[20] = (0x4C ^ 0x2B ^ 0xF2 ^ 0x84);
    llllIIIlI[21] = (0x21 ^ 0x33);
    llllIIIlI[22] = (0x5 ^ 0x1A);
    llllIIIlI[23] = (0xBF ^ 0xAC);
    llllIIIlI[24] = (0x70 ^ 0x40);
    llllIIIlI[25] = (0x5D ^ 0x37 ^ 0x62 ^ 0x6C);
    llllIIIlI[26] = (0x7B ^ 0x33);
    llllIIIlI[27] = (0xE ^ 0x6C);
    llllIIIlI[28] = (0x4B ^ 0x5F);
    llllIIIlI[29] = (0x70 ^ 0x65);
    llllIIIlI[30] = (0xF2 ^ 0x8E);
    llllIIIlI[31] = (0x53 ^ 0x21 ^ 0x1 ^ 0x65);
    llllIIIlI[32] = (0x1F ^ 0x8);
    llllIIIlI[33] = (0x8E ^ 0xC6 ^ 0x22 ^ 0x73);
    llllIIIlI[34] = (0x6A ^ 0xF ^ 27 + 3 - -2 + 95);
    llllIIIlI[35] = (0xAA ^ 0xB1);
    llllIIIlI[36] = (0x96 ^ 0x8A);
    llllIIIlI[37] = (0x3B ^ 0x12 ^ 0xF2 ^ 0xC6);
    llllIIIlI[38] = (0xF0 ^ 0x85 ^ 0x62 ^ 0x9);
    llllIIIlI[39] = (0x2E ^ 0xE);
    llllIIIlI[40] = (72 + 103 - 52 + 7 ^ 4 + '' - 83 + 114);
    llllIIIlI[41] = (0x8 ^ 0x2A);
    llllIIIlI[42] = (0x1C ^ 0x3F);
    llllIIIlI[43] = (0xDF13 & 0x37ED);
    llllIIIlI[44] = (0xF755 & 0x1FAA);
    llllIIIlI[45] = (-(0x9F76 & 0x70CF) & 0xBBEF & 0x5757);
    llllIIIlI[46] = (-(0x99F9 & 0x7E6F) & 0xBB7F & 0x5FEB);
    llllIIIlI[47] = (13 + 42 - -49 + 151);
    llllIIIlI[48] = (-(0xB2EF & 0x5F17) & 0xDFF7 & 0x3FEF);
    llllIIIlI[49] = (-(0xD6A7 & 0x7FFD) & 0xFFFFFFEF & 0x7EB5);
    llllIIIlI[50] = (-(0xFEED & 0x59DF) & 0xFEDF & 0x7FED);
    llllIIIlI[51] = (-(0xF750 & 0xEEF) & 0xEF3F & 0x3EFF);
    llllIIIlI[52] = (70 + 23 - -85 + 5 ^ 34 + 104 - 32 + 41);
    llllIIIlI[53] = (0x3E ^ 0x1B);
    llllIIIlI[54] = (-(0xB9F7 & 0x4E0D) & 0xBFCC & 0x5BBF);
    llllIIIlI[55] = (13 + 27 - -58 + 59 ^ '' + '' - 116 + 18);
    llllIIIlI[56] = (0x39 ^ 0x1E);
    llllIIIlI[57] = (-" ".length());
    llllIIIlI[58] = (0x38 ^ 0x10);
    llllIIIlI[59] = (0x31 ^ 0x6A ^ 0x20 ^ 0x52);
    llllIIIlI[60] = (0xBDE3 & 0x5520421C);
    llllIIIlI[61] = (0xAE ^ 0xBE ^ 0x72 ^ 0x48);
  }
  
  private void rotateAndBlurSkybox(float lIIIllIllIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    mc.getTextureManager().bindTexture(backgroundTexture);
    GL11.glTexParameteri(llllIIIlI[48], llllIIIlI[49], llllIIIlI[50]);
    GL11.glTexParameteri(llllIIIlI[48], llllIIIlI[51], llllIIIlI[50]);
    GL11.glCopyTexSubImage2D(llllIIIlI[48], llllIIIlI[0], llllIIIlI[0], llllIIIlI[0], llllIIIlI[0], llllIIIlI[0], llllIIIlI[17], llllIIIlI[17]);
    GlStateManager.enableBlend();
    GlStateManager.tryBlendFuncSeparate(llllIIIlI[45], llllIIIlI[46], llllIIIlI[1], llllIIIlI[0]);
    GlStateManager.colorMask(llllIIIlI[1], llllIIIlI[1], llllIIIlI[1], llllIIIlI[0]);
    Tessellator lIIIllIllIIlIl = Tessellator.getInstance();
    WorldRenderer lIIIllIllIIlII = lIIIllIllIIlIl.getWorldRenderer();
    lIIIllIllIIlII.begin(llllIIIlI[7], DefaultVertexFormats.POSITION_TEX_COLOR);
    GlStateManager.disableAlpha();
    int lIIIllIllIIIll = llllIIIlI[4];
    int lIIIllIllIIIlI = llllIIIlI[0];
    "".length();
    if (-" ".length() >= 0) {
      return;
    }
    while (!llIIIIllllI(lIIIllIllIIIlI, lIIIllIllIIIll))
    {
      float lIIIllIllIIIIl = 1.0F / (lIIIllIllIIIlI + llllIIIlI[1]);
      int lIIIllIllIIIII = width;
      int lIIIllIlIlllll = height;
      float lIIIllIlIllllI = (lIIIllIllIIIlI - lIIIllIllIIIll / llllIIIlI[3]) / 256.0F;
      lIIIllIllIIlII.pos(lIIIllIllIIIII, lIIIllIlIlllll, zLevel).tex(0.0F + lIIIllIlIllllI, 1.0D).color(1.0F, 1.0F, 1.0F, lIIIllIllIIIIl).endVertex();
      lIIIllIllIIlII.pos(lIIIllIllIIIII, 0.0D, zLevel).tex(1.0F + lIIIllIlIllllI, 1.0D).color(1.0F, 1.0F, 1.0F, lIIIllIllIIIIl).endVertex();
      lIIIllIllIIlII.pos(0.0D, 0.0D, zLevel).tex(1.0F + lIIIllIlIllllI, 0.0D).color(1.0F, 1.0F, 1.0F, lIIIllIllIIIIl).endVertex();
      lIIIllIllIIlII.pos(0.0D, lIIIllIlIlllll, zLevel).tex(0.0F + lIIIllIlIllllI, 0.0D).color(1.0F, 1.0F, 1.0F, lIIIllIllIIIIl).endVertex();
      lIIIllIllIIIlI++;
    }
    lIIIllIllIIlIl.draw();
    GlStateManager.enableAlpha();
    GlStateManager.colorMask(llllIIIlI[1], llllIIIlI[1], llllIIIlI[1], llllIIIlI[1]);
  }
  
  private static boolean llIIIIlllIl(int ???)
  {
    String lIIIlIlIlllIll;
    return ??? != 0;
  }
  
  private static boolean llIIIlIIllI(int ???, int arg1)
  {
    int i;
    double lIIIlIllIIIlIl;
    return ??? <= i;
  }
  
  public void updateScreen()
  {
    ;
    panoramaTimer += llllIIIlI[1];
  }
  
  private static void llIIIIlIIll()
  {
    llllIIIII = new String[llllIIIlI[61]];
    llllIIIII[llllIIIlI[0]] = llIIIIIIlll("ukc+dPbIM/JdS1RiD752rHDRDuodiBsa", "EkhQy");
    llllIIIII[llllIIIlI[1]] = llIIIIIlIII("MwwBOxo1DApgCDIAVjsGMwUcYAIuBxwsHSYPDWEfKQ4=", "GiyOo");
    llllIIIII[llllIIIlI[3]] = llIIIIIIlll("YGTCBfXqpj412nC/VkZaWEHdsngvUgSmI2rEFzsVY5wcJ+im5UTYUspjDOJyg1oY", "zVGuy");
    llllIIIII[llllIIIlI[4]] = llIIIIIIlll("uTDnBlZuLN+/89XoY7YGTFoTukGQ9vS1kOuzbhBULmKggXiXk68EcWb51Y4y9n+k", "jfSdP");
    llllIIIII[llllIIIlI[5]] = llIIIIIlIII("Hi85Hy8YLzJEPR8jbh8zHiYkRDgLKSoMKAU/Lw91GisvBCgLJyA0aEQ6Lww=", "jJAkZ");
    llllIIIII[llllIIIlI[6]] = llIIIIIlIII("HCEqBQQaISFeFh0tfQUYHCg3XhMJJzkWAwcxPBVeGCU8HgMJKTMuQkY0PBY=", "hDRqq");
    llllIIIII[llllIIIlI[2]] = llIIIIIlIIl("u7Wj0NXgpsVBRKXoZcpXwAOhEbjvNaYM993P4TqXSiTOm9tEyyps/VX4bARh5Cmf", "rGjgL");
    llllIIIII[llllIIIlI[7]] = llIIIIIlIII("Gx0BIjMdHQp5IRoRViIvGxQceSQOGxIxNAANFzJpHxkXOTQOFRgJc0EIFzE=", "oxyVF");
    llllIIIII[llllIIIlI[8]] = llIIIIIlIII("CCgLBxY9ZA0KDDsvTg==", "XDnfe");
    llllIIIII[llllIIIlI[9]] = llIIIIIlIIl("jcq3AoU5Rj8=", "bDjTY");
    llllIIIII[llllIIIlI[10]] = llIIIIIIlll("zO/8748qn6wCoase/eb7QP4336VR2asb", "CeHaU");
    llllIIIII[llllIIIlI[11]] = llIIIIIlIIl("D0747oB14S8ArlMYrqEgtA==", "ocsyp");
    llllIIIII[llllIIIlI[13]] = llIIIIIlIIl("ubeSjKCMx1Y=", "QLKdh");
    llllIIIII[llllIIIlI[14]] = llIIIIIlIII("BQYeDwNfAAYHAR1e", "qojcf");
    llllIIIII[llllIIIlI[15]] = llIIIIIlIIl("wzaApa1eEeSaOeCStQ6Isw==", "zHgoW");
    llllIIIII[llllIIIlI[16]] = llIIIIIlIIl("KcghUhLvJTlR2hRBrP2xNis/4ajVaLdxFrJpBhw6GdR3s1uyMSNwswOdkV3V93p9Bm7mHH8r94oEjN0k3kVXCQ6HhPyyrllK", "igVoD");
    llllIIIII[llllIIIlI[18]] = llIIIIIlIII("GjEJLykKPx8qKg==", "xPjDN");
    llllIIIII[llllIIIlI[20]] = llIIIIIlIII("HQkwMxFwNG8sCSNN", "PlBAh");
    llllIIIII[llllIIIlI[21]] = llIIIIIlIIl("h1ieCGRuhf4whl9djODCoQ==", "qEJnr");
    llllIIIII[llllIIIlI[23]] = llIIIIIlIIl("2w9ol9kJZtpd9nsv1Yn0XBFVkC6v91FR", "mTabs");
    llllIIIII[llllIIIlI[28]] = llIIIIIlIII("DC8YHkIOOgICAw85", "aJvkl");
    llllIIIII[llllIIIlI[29]] = llIIIIIlIIl("F4OZQj4UaKVMVGPBeZRnNA==", "SQvld");
    llllIIIII[llllIIIlI[31]] = llIIIIIIlll("kzvF3aivG2fYyWVz+fo9RkN/v9iZC6f0", "hHzCZ");
    llllIIIII[llllIIIlI[32]] = llIIIIIlIII("Cj82EEAKLzQRBxc2ORwLFQ==", "gZXen");
    llllIIIII[llllIIIlI[19]] = llIIIIIlIIl("/sW0fptntfw=", "SUYTx");
    llllIIIII[llllIIIlI[33]] = llIIIIIIlll("67bTGV6ew+c4qL2vIfxC4g==", "AluLh");
    llllIIIII[llllIIIlI[34]] = llIIIIIIlll("QXVctctyaDgmJQMOVNCsuA==", "dNofT");
    llllIIIII[llllIIIlI[35]] = llIIIIIIlll("3sGI19B5Mp2FLl8NZo9OmQ==", "QFCml");
    llllIIIII[llllIIIlI[36]] = llIIIIIIlll("dqIZyKWtPXN3kY+QCeHEPA==", "MjuvP");
    llllIIIII[llllIIIlI[37]] = llIIIIIlIII("LS0PBis+JxAFEA==", "iHbit");
    llllIIIII[llllIIIlI[38]] = llIIIIIIlll("GJLsegyxusFReROVAV98cA==", "JejMb");
    llllIIIII[llllIIIlI[22]] = llIIIIIlIII("CxcgPQoYHT8+MQ==", "OrMRU");
    llllIIIII[llllIIIlI[39]] = llIIIIIlIII("IjYFKVcpIAdmPS0kGDwWOA==", "HWsHy");
    llllIIIII[llllIIIlI[40]] = llIIIIIIlll("gYj4iwgamYy03AHzYbu4iw==", "fBAKi");
    llllIIIII[llllIIIlI[41]] = llIIIIIlIII("Nh43IwUx", "TlXTv");
    llllIIIII[llllIIIlI[42]] = llIIIIIIlll("HHOzq+U2VJq2Vogmr/tNZ2tWsGMKSzOb", "gvKpA");
    llllIIIII[llllIIIlI[52]] = llIIIIIIlll("AQp9x1+TloY=", "APIbJ");
    llllIIIII[llllIIIlI[53]] = llIIIIIIlll("ihTt6c5zy8c=", "JnFQM");
    llllIIIII[llllIIIlI[55]] = llIIIIIlIII("", "HohuK");
    llllIIIII[llllIIIlI[56]] = llIIIIIlIIl("HacB6/blCdE=", "NjzWe");
    llllIIIII[llllIIIlI[58]] = llIIIIIIlll("NtcM3NzRynW74jTgj+Hi0VhY2GsWEv15A3EMLKfNA9NbUWyqNKjxVw==", "PGDjO");
    llllIIIII[llllIIIlI[59]] = llIIIIIlIIl("CJfhvh/tD4Gx9wIjnwCMEKFHWXYN9zD31X2w6Iebwjg=", "YXoJC");
  }
  
  protected void actionPerformed(GuiButton lIIIlllIllIIIl)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    if (llIIIIllIII(id)) {
      mc.displayGuiScreen(new GuiOptions(lIIIlllIllIlll, mc.gameSettings));
    }
    if (llIIIIlllII(id, llllIIIlI[6])) {
      mc.displayGuiScreen(new GuiLanguage(lIIIlllIllIlll, mc.gameSettings, mc.getLanguageManager()));
    }
    if (llIIIIlllII(id, llllIIIlI[1])) {
      mc.displayGuiScreen(new GuiSelectWorld(lIIIlllIllIlll));
    }
    if (llIIIIlllII(id, llllIIIlI[3])) {
      mc.displayGuiScreen(new GuiMultiplayer(lIIIlllIllIlll));
    }
    if ((llIIIIlllII(id, llllIIIlI[15])) && (llIIIIlllIl(realmsButton.visible))) {
      lIIIlllIllIlll.switchToRealms();
    }
    if (llIIIIlllII(id, llllIIIlI[5])) {
      mc.shutdown();
    }
    if (llIIIIlllII(id, llllIIIlI[11])) {
      mc.launchIntegratedServer(llllIIIII[llllIIIlI[36]], llllIIIII[llllIIIlI[37]], DemoWorldServer.demoWorldSettings);
    }
    if (llIIIIlllII(id, llllIIIlI[13]))
    {
      ISaveFormat lIIIlllIllIlIl = mc.getSaveLoader();
      WorldInfo lIIIlllIllIlII = lIIIlllIllIlIl.getWorldInfo(llllIIIII[llllIIIlI[38]]);
      if (llIIIIllIll(lIIIlllIllIlII))
      {
        GuiYesNo lIIIlllIllIIll = GuiSelectWorld.func_152129_a(lIIIlllIllIlll, lIIIlllIllIlII.getWorldName(), llllIIIlI[13]);
        mc.displayGuiScreen(lIIIlllIllIIll);
      }
    }
  }
  
  public boolean doesGuiPauseGame()
  {
    return llllIIIlI[0];
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    viewportTexture = new DynamicTexture(llllIIIlI[17], llllIIIlI[17]);
    backgroundTexture = mc.getTextureManager().getDynamicTextureLocation(llllIIIII[llllIIIlI[18]], viewportTexture);
    Calendar lIIIllllIllllI = Calendar.getInstance();
    lIIIllllIllllI.setTime(new Date());
    if ((llIIIIlllII(lIIIllllIllllI.get(llllIIIlI[3]) + llllIIIlI[1], llllIIIlI[13])) && (llIIIIlllII(lIIIllllIllllI.get(llllIIIlI[6]), llllIIIlI[19])))
    {
      splashText = llllIIIII[llllIIIlI[20]];
      "".length();
      if (((0x3D ^ 0x78) & (0x76 ^ 0x33 ^ 0xFFFFFFFF)) <= " ".length()) {}
    }
    else if ((llIIIIlllII(lIIIllllIllllI.get(llllIIIlI[3]) + llllIIIlI[1], llllIIIlI[1])) && (llIIIIlllII(lIIIllllIllllI.get(llllIIIlI[6]), llllIIIlI[1])))
    {
      splashText = llllIIIII[llllIIIlI[21]];
      "".length();
      if (-"  ".length() < 0) {}
    }
    else if ((llIIIIlllII(lIIIllllIllllI.get(llllIIIlI[3]) + llllIIIlI[1], llllIIIlI[10])) && (llIIIIlllII(lIIIllllIllllI.get(llllIIIlI[6]), llllIIIlI[22])))
    {
      splashText = llllIIIII[llllIIIlI[23]];
    }
    int lIIIllllIlllIl = llllIIIlI[19];
    int lIIIllllIlllII = height / llllIIIlI[5] + llllIIIlI[24];
    if (llIIIIlllIl(mc.isDemo()))
    {
      lIIIllllIllIlI.addDemoButtons(lIIIllllIlllII, llllIIIlI[19]);
      "".length();
      if (-" ".length() <= "   ".length()) {}
    }
    else
    {
      lIIIllllIllIlI.addSingleplayerMultiplayerButtons(lIIIllllIlllII, llllIIIlI[19]);
    }
    new GuiButton(llllIIIlI[0], width / llllIIIlI[3] - llllIIIlI[25], lIIIllllIlllII + llllIIIlI[26] + llllIIIlI[13], llllIIIlI[27], llllIIIlI[28], I18n.format(llllIIIII[llllIIIlI[28]], new Object[llllIIIlI[0]]));
    "".length();
    new GuiButton(llllIIIlI[5], width / llllIIIlI[3] + llllIIIlI[3], lIIIllllIlllII + llllIIIlI[26] + llllIIIlI[13], llllIIIlI[27], llllIIIlI[28], I18n.format(llllIIIII[llllIIIlI[29]], new Object[llllIIIlI[0]]));
    "".length();
    new GuiButtonLanguage(llllIIIlI[6], width / llllIIIlI[3] - llllIIIlI[30], lIIIllllIlllII + llllIIIlI[26] + llllIIIlI[13]);
    "".length();
    synchronized (threadLock)
    {
      field_92023_s = fontRendererObj.getStringWidth(openGLWarning1);
      field_92024_r = fontRendererObj.getStringWidth(openGLWarning2);
      int lIIIllllIllIll = Math.max(field_92023_s, field_92024_r);
      field_92022_t = ((width - lIIIllllIllIll) / llllIIIlI[3]);
      field_92021_u = (buttonList.get(llllIIIlI[0])).yPosition - llllIIIlI[19]);
      field_92020_v = (field_92022_t + lIIIllllIllIll);
      field_92019_w = (field_92021_u + llllIIIlI[19]);
      "".length();
      if ("  ".length() < 0) {
        return;
      }
    }
    mc.func_181537_a(llllIIIlI[0]);
  }
  
  public void confirmClicked(boolean lIIIlllIlIIIIl, int lIIIlllIIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if ((llIIIIlllIl(lIIIlllIlIIIIl)) && (llIIIIlllII(lIIIlllIIllIIl, llllIIIlI[13])))
    {
      ISaveFormat lIIIlllIIlllll = mc.getSaveLoader();
      lIIIlllIIlllll.flushCache();
      "".length();
      mc.displayGuiScreen(lIIIlllIIllIll);
      "".length();
      if (" ".length() > 0) {}
    }
    else if (llIIIIlllII(lIIIlllIIllIIl, llllIIIlI[14]))
    {
      if (llIIIIlllIl(lIIIlllIIllIlI)) {
        try
        {
          Class<?> lIIIlllIIllllI = Class.forName(llllIIIII[llllIIIlI[39]]);
          Object lIIIlllIIlllIl = lIIIlllIIllllI.getMethod(llllIIIII[llllIIIlI[40]], new Class[llllIIIlI[0]]).invoke(null, new Object[llllIIIlI[0]]);
          "".length();
          "".length();
          if ("   ".length() < "  ".length()) {
            return;
          }
        }
        catch (Throwable lIIIlllIIlllII)
        {
          logger.error(llllIIIII[llllIIIlI[42]], lIIIlllIIlllII);
        }
      }
      mc.displayGuiScreen(lIIIlllIIllIll);
    }
  }
  
  private static String llIIIIIlIIl(String lIIIlIllIllIII, String lIIIlIllIlIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIIlIllIlllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIIIlIllIlIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIIIlIllIlllII = Cipher.getInstance("Blowfish");
      lIIIlIllIlllII.init(llllIIIlI[3], lIIIlIllIlllIl);
      return new String(lIIIlIllIlllII.doFinal(Base64.getDecoder().decode(lIIIlIllIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIIlIllIllIll)
    {
      lIIIlIllIllIll.printStackTrace();
    }
    return null;
  }
  
  private void switchToRealms()
  {
    ;
    ;
    RealmsBridge lIIIlllIlIlIlI = new RealmsBridge();
    lIIIlllIlIlIlI.switchToRealms(lIIIlllIlIlIIl);
  }
  
  private static boolean llIIIlIIlII(int ???)
  {
    Exception lIIIlIlIllIlll;
    return ??? > 0;
  }
  
  private static boolean llIIIIllIll(Object ???)
  {
    double lIIIlIlIllllll;
    return ??? != null;
  }
  
  private static String llIIIIIlIII(String lIIIlIllllllII, String lIIIlIllllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIIIlIllllllII = new String(Base64.getDecoder().decode(lIIIlIllllllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIIIlIlllllIlI = new StringBuilder();
    char[] lIIIlIlllllIIl = lIIIlIllllIllI.toCharArray();
    int lIIIlIlllllIII = llllIIIlI[0];
    short lIIIlIllllIIlI = lIIIlIllllllII.toCharArray();
    short lIIIlIllllIIIl = lIIIlIllllIIlI.length;
    int lIIIlIllllIIII = llllIIIlI[0];
    while (llIIIlIIlll(lIIIlIllllIIII, lIIIlIllllIIIl))
    {
      char lIIIlIllllllIl = lIIIlIllllIIlI[lIIIlIllllIIII];
      "".length();
      "".length();
      if ("   ".length() != "   ".length()) {
        return null;
      }
    }
    return String.valueOf(lIIIlIlllllIlI);
  }
  
  private static boolean llIIIIllllI(int ???, int arg1)
  {
    int i;
    String lIIIlIllIIllIl;
    return ??? >= i;
  }
  
  private int getRainbow(int lIIIllIIlIllll, int lIIIllIIlIlllI)
  {
    ;
    ;
    ;
    float lIIIllIIlIllIl = (float)((System.currentTimeMillis() + lIIIllIIlIlllI) % lIIIllIIlIllll);
    lIIIllIIlIllIl /= lIIIllIIlIllll;
    return Color.getHSBColor(lIIIllIIlIllIl, 1.0F, 1.0F).getRGB();
  }
  
  public GuiMainMenu()
  {
    BufferedReader lIIIllllllIllI = null;
    try
    {
      List<String> lIIIllllllIlIl = Lists.newArrayList();
      lIIIllllllIllI = new BufferedReader(new InputStreamReader(Minecraft.getMinecraft().getResourceManager().getResource(splashTexts).getInputStream(), Charsets.UTF_8));
      "".length();
      if ("   ".length() < ("   ".length() & ("   ".length() ^ 0xFFFFFFFF))) {
        throw null;
      }
      String lIIIllllllIIll;
      while (!llIIIIllIIl(lIIIllllllIIll = lIIIllllllIllI.readLine()))
      {
        String lIIIllllllIlII = lIIIllllllIlII.trim();
        if (llIIIIllIII(lIIIllllllIlII.isEmpty())) {
          "".length();
        }
      }
      if (llIIIIllIII(lIIIllllllIlIl.isEmpty()))
      {
        do
        {
          splashText = ((String)lIIIllllllIlIl.get(RANDOM.nextInt(lIIIllllllIlIl.size())));
        } while (!llIIIIllIlI(splashText.hashCode(), llllIIIlI[12]));
        "".length();
        if (-(0x56 ^ 0x52) > 0) {
          throw null;
        }
      }
    }
    catch (IOException localIOException)
    {
      localIOException = localIOException;
      if (!llIIIIllIll(lIIIllllllIllI)) {
        break label375;
      }
      try
      {
        lIIIllllllIllI.close();
        "".length();
        if (-" ".length() < 0) {
          break label375;
        }
        throw null;
      }
      catch (IOException localIOException1)
      {
        "".length();
        if (-" ".length() <= 0) {
          break label375;
        }
      }
      throw null;
    }
    finally
    {
      lIIIlllllIlllI = finally;
      if (llIIIIllIll(lIIIllllllIllI)) {
        try
        {
          lIIIllllllIllI.close();
          "".length();
          if ((0xC2 ^ 0x81 ^ 0x14 ^ 0x53) > (95 + 56 - 145 + 156 ^ 108 + 6 - 54 + 106)) {
            throw null;
          }
        }
        catch (IOException localIOException2) {}
      }
      throw lIIIlllllIlllI;
    }
    if (llIIIIllIll(lIIIllllllIllI)) {
      try
      {
        lIIIllllllIllI.close();
        "".length();
        if (-"  ".length() >= 0) {
          throw null;
        }
      }
      catch (IOException localIOException3) {}
    }
    label375:
    updateCounter = RANDOM.nextFloat();
    openGLWarning1 = llllIIIII[llllIIIlI[13]];
    if ((llIIIIllIII(getCapabilitiesOpenGL20)) && (llIIIIllIII(OpenGlHelper.areShadersSupported())))
    {
      openGLWarning1 = I18n.format(llllIIIII[llllIIIlI[14]], new Object[llllIIIlI[0]]);
      openGLWarning2 = I18n.format(llllIIIII[llllIIIlI[15]], new Object[llllIIIlI[0]]);
      openGLWarningLink = llllIIIII[llllIIIlI[16]];
    }
  }
  
  static
  {
    llIIIIlIlll();
    llIIIIlIIll();
    field_175373_f = new AtomicInteger(llllIIIlI[0]);
    logger = LogManager.getLogger();
    RANDOM = new Random();
    splashTexts = new ResourceLocation(llllIIIII[llllIIIlI[0]]);
    minecraftTitleTextures = new ResourceLocation(llllIIIII[llllIIIlI[1]]);
  }
  
  private void addDemoButtons(int lIIIllllIIIlIl, int lIIIlllIllllll)
  {
    ;
    ;
    ;
    ;
    ;
    new GuiButton(llllIIIlI[11], width / llllIIIlI[3] - llllIIIlI[25], lIIIllllIIIIII, I18n.format(llllIIIII[llllIIIlI[33]], new Object[llllIIIlI[0]]));
    "".length();
    buttonResetDemo = new GuiButton(llllIIIlI[13], width / llllIIIlI[3] - llllIIIlI[25], lIIIllllIIIIII + lIIIlllIllllll * llllIIIlI[1], I18n.format(llllIIIII[llllIIIlI[34]], new Object[llllIIIlI[0]]));
    "".length();
    ISaveFormat lIIIllllIIIIll = mc.getSaveLoader();
    WorldInfo lIIIllllIIIIlI = lIIIllllIIIIll.getWorldInfo(llllIIIII[llllIIIlI[35]]);
    if (llIIIIllIIl(lIIIllllIIIIlI)) {
      buttonResetDemo.enabled = llllIIIlI[0];
    }
  }
  
  private static boolean llIIIIllIIl(Object ???)
  {
    int lIIIlIlIllllIl;
    return ??? == null;
  }
  
  protected void keyTyped(char lIIIlllllIIlll, int lIIIlllllIIllI)
    throws IOException
  {}
  
  protected void mouseClicked(int lIIIllIIIIlIll, int lIIIllIIIIllll, int lIIIllIIIIlllI)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIIIllIIIIllII.mouseClicked(lIIIllIIIIlIll, lIIIllIIIIllll, lIIIllIIIIlllI);
    synchronized (threadLock)
    {
      if ((llIIIlIIlII(openGLWarning1.length())) && (llIIIIllllI(lIIIllIIIIlIll, field_92022_t)) && (llIIIlIIllI(lIIIllIIIIlIll, field_92020_v)) && (llIIIIllllI(lIIIllIIIIllll, field_92021_u)) && (llIIIlIIllI(lIIIllIIIIllll, field_92019_w)))
      {
        GuiConfirmOpenLink lIIIllIIIIllIl = new GuiConfirmOpenLink(lIIIllIIIIllII, openGLWarningLink, llllIIIlI[14], llllIIIlI[1]);
        lIIIllIIIIllIl.disableSecurityWarning();
        mc.displayGuiScreen(lIIIllIIIIllIl);
      }
      "".length();
      if (((0xAA ^ 0xAD ^ 0x9F ^ 0xA7) & (0xF1 ^ 0x82 ^ 0x53 ^ 0x1F ^ -" ".length())) >= (0xA2 ^ 0xB5 ^ 0x66 ^ 0x75)) {}
    }
  }
  
  private static boolean llIIIIllIlI(int ???, int arg1)
  {
    int i;
    char lIIIlIlIllIIll;
    return ??? != i;
  }
  
  private static boolean llIIIlIIIlI(int ???, int arg1)
  {
    int i;
    double lIIIlIllIIIIIl;
    return ??? > i;
  }
  
  public void drawScreen(int lIIIllIIlIIIlI, int lIIIllIIIllIll, float lIIIllIIlIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIIIllIIIlllIl.drawDefaultBackground();
    RenderUtils.drawString(3.0D, llllIIIII[llllIIIlI[52]], width / llllIIIlI[2] - fontRendererObj.getStringWidth(llllIIIII[llllIIIlI[53]]) / llllIIIlI[3], height / llllIIIlI[13], lIIIllIIIlllIl.getRainbow(llllIIIlI[54], llllIIIlI[16]));
    String lIIIllIIIlllll = llllIIIII[llllIIIlI[55]];
    if (llIIIIlllIl(mc.isDemo())) {
      lIIIllIIIlllll = String.valueOf(new StringBuilder(String.valueOf(lIIIllIIIlllll)).append(llllIIIII[llllIIIlI[56]]));
    }
    lIIIllIIIlllIl.drawString(fontRendererObj, lIIIllIIIlllll, llllIIIlI[3], height - llllIIIlI[10], llllIIIlI[57]);
    String lIIIllIIIllllI = llllIIIII[llllIIIlI[58]];
    lIIIllIIIlllIl.drawString(fontRendererObj, lIIIllIIIllllI, width - fontRendererObj.getStringWidth(lIIIllIIIllllI) - llllIIIlI[3], height - llllIIIlI[10], llllIIIlI[57]);
    lIIIllIIIlllIl.drawString(fontRendererObj, String.valueOf(new StringBuilder(llllIIIII[llllIIIlI[59]]).append(WingsManager.userList.size())), llllIIIlI[3], height - llllIIIlI[10], llllIIIlI[57]);
    if ((llIIIIllIll(openGLWarning1)) && (llIIIlIIlII(openGLWarning1.length())))
    {
      drawRect(field_92022_t - llllIIIlI[3], field_92021_u - llllIIIlI[3], field_92020_v + llllIIIlI[3], field_92019_w - llllIIIlI[1], llllIIIlI[60]);
      lIIIllIIIlllIl.drawString(fontRendererObj, openGLWarning1, field_92022_t, field_92021_u, llllIIIlI[57]);
      lIIIllIIIlllIl.drawString(fontRendererObj, openGLWarning2, (width - field_92024_r) / llllIIIlI[3], buttonList.get(llllIIIlI[0])).yPosition - llllIIIlI[13], llllIIIlI[57]);
    }
    lIIIllIIIlllIl.drawScreen(lIIIllIIlIIIlI, lIIIllIIIllIll, lIIIllIIlIIIII);
  }
  
  private static String llIIIIIIlll(String lIIIlIlllIIlIl, String lIIIlIlllIIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIIlIlllIlIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIIIlIlllIIlII.getBytes(StandardCharsets.UTF_8)), llllIIIlI[8]), "DES");
      Cipher lIIIlIlllIlIIl = Cipher.getInstance("DES");
      lIIIlIlllIlIIl.init(llllIIIlI[3], lIIIlIlllIlIlI);
      return new String(lIIIlIlllIlIIl.doFinal(Base64.getDecoder().decode(lIIIlIlllIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIIlIlllIlIII)
    {
      lIIIlIlllIlIII.printStackTrace();
    }
    return null;
  }
  
  private void addSingleplayerMultiplayerButtons(int lIIIllllIIllIl, int lIIIllllIIllII)
  {
    ;
    ;
    ;
    new GuiButton(llllIIIlI[1], width / llllIIIlI[3] - llllIIIlI[25], lIIIllllIlIIII, I18n.format(llllIIIII[llllIIIlI[31]], new Object[llllIIIlI[0]]));
    "".length();
    new GuiButton(llllIIIlI[3], width / llllIIIlI[3] - llllIIIlI[25], lIIIllllIlIIII + lIIIllllIIllII * llllIIIlI[1], I18n.format(llllIIIII[llllIIIlI[32]], new Object[llllIIIlI[0]]));
    "".length();
    new GuiButton(llllIIIlI[4], width / llllIIIlI[3] - llllIIIlI[25], lIIIllllIlIIII + lIIIllllIIllII * llllIIIlI[3], I18n.format(llllIIIII[llllIIIlI[19]], new Object[llllIIIlI[0]]));
    "".length();
  }
  
  private void drawPanorama(int lIIIlllIIIlIIl, int lIIIlllIIIlIII, float lIIIllIllllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Tessellator lIIIlllIIIIllI = Tessellator.getInstance();
    WorldRenderer lIIIlllIIIIlIl = lIIIlllIIIIllI.getWorldRenderer();
    GlStateManager.matrixMode(llllIIIlI[43]);
    GlStateManager.pushMatrix();
    GlStateManager.loadIdentity();
    Project.gluPerspective(120.0F, 1.0F, 0.05F, 10.0F);
    GlStateManager.matrixMode(llllIIIlI[44]);
    GlStateManager.pushMatrix();
    GlStateManager.loadIdentity();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.rotate(180.0F, 1.0F, 0.0F, 0.0F);
    GlStateManager.rotate(90.0F, 0.0F, 0.0F, 1.0F);
    GlStateManager.enableBlend();
    GlStateManager.disableAlpha();
    GlStateManager.disableCull();
    GlStateManager.depthMask(llllIIIlI[0]);
    GlStateManager.tryBlendFuncSeparate(llllIIIlI[45], llllIIIlI[46], llllIIIlI[1], llllIIIlI[0]);
    int lIIIlllIIIIlII = llllIIIlI[8];
    int lIIIlllIIIIIll = llllIIIlI[0];
    "".length();
    if (null != null) {
      return;
    }
    while (!llIIIIllllI(lIIIlllIIIIIll, lIIIlllIIIIlII * lIIIlllIIIIlII))
    {
      GlStateManager.pushMatrix();
      float lIIIlllIIIIIlI = (lIIIlllIIIIIll % lIIIlllIIIIlII / lIIIlllIIIIlII - 0.5F) / 64.0F;
      float lIIIlllIIIIIIl = (lIIIlllIIIIIll / lIIIlllIIIIlII / lIIIlllIIIIlII - 0.5F) / 64.0F;
      float lIIIlllIIIIIII = 0.0F;
      GlStateManager.translate(lIIIlllIIIIIlI, lIIIlllIIIIIIl, lIIIlllIIIIIII);
      GlStateManager.rotate(MathHelper.sin((panoramaTimer + lIIIllIllllIll) / 400.0F) * 25.0F + 20.0F, 1.0F, 0.0F, 0.0F);
      GlStateManager.rotate(-(panoramaTimer + lIIIllIllllIll) * 0.1F, 0.0F, 1.0F, 0.0F);
      int lIIIllIlllllll = llllIIIlI[0];
      "".length();
      if ((0x9B ^ 0x9E) == 0) {
        return;
      }
      while (!llIIIIllllI(lIIIllIlllllll, llllIIIlI[2]))
      {
        GlStateManager.pushMatrix();
        if (llIIIIlllII(lIIIllIlllllll, llllIIIlI[1])) {
          GlStateManager.rotate(90.0F, 0.0F, 1.0F, 0.0F);
        }
        if (llIIIIlllII(lIIIllIlllllll, llllIIIlI[3])) {
          GlStateManager.rotate(180.0F, 0.0F, 1.0F, 0.0F);
        }
        if (llIIIIlllII(lIIIllIlllllll, llllIIIlI[4])) {
          GlStateManager.rotate(-90.0F, 0.0F, 1.0F, 0.0F);
        }
        if (llIIIIlllII(lIIIllIlllllll, llllIIIlI[5])) {
          GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
        }
        if (llIIIIlllII(lIIIllIlllllll, llllIIIlI[6])) {
          GlStateManager.rotate(-90.0F, 1.0F, 0.0F, 0.0F);
        }
        mc.getTextureManager().bindTexture(titlePanoramaPaths[lIIIllIlllllll]);
        lIIIlllIIIIlIl.begin(llllIIIlI[7], DefaultVertexFormats.POSITION_TEX_COLOR);
        int lIIIllIllllllI = llllIIIlI[47] / (lIIIlllIIIIIll + llllIIIlI[1]);
        float lIIIllIlllllIl = 0.0F;
        lIIIlllIIIIlIl.pos(-1.0D, -1.0D, 1.0D).tex(0.0D, 0.0D).color(llllIIIlI[47], llllIIIlI[47], llllIIIlI[47], lIIIllIllllllI).endVertex();
        lIIIlllIIIIlIl.pos(1.0D, -1.0D, 1.0D).tex(1.0D, 0.0D).color(llllIIIlI[47], llllIIIlI[47], llllIIIlI[47], lIIIllIllllllI).endVertex();
        lIIIlllIIIIlIl.pos(1.0D, 1.0D, 1.0D).tex(1.0D, 1.0D).color(llllIIIlI[47], llllIIIlI[47], llllIIIlI[47], lIIIllIllllllI).endVertex();
        lIIIlllIIIIlIl.pos(-1.0D, 1.0D, 1.0D).tex(0.0D, 1.0D).color(llllIIIlI[47], llllIIIlI[47], llllIIIlI[47], lIIIllIllllllI).endVertex();
        lIIIlllIIIIllI.draw();
        GlStateManager.popMatrix();
        lIIIllIlllllll++;
      }
      GlStateManager.popMatrix();
      GlStateManager.colorMask(llllIIIlI[1], llllIIIlI[1], llllIIIlI[1], llllIIIlI[0]);
      lIIIlllIIIIIll++;
    }
    lIIIlllIIIIlIl.setTranslation(0.0D, 0.0D, 0.0D);
    GlStateManager.colorMask(llllIIIlI[1], llllIIIlI[1], llllIIIlI[1], llllIIIlI[1]);
    GlStateManager.matrixMode(llllIIIlI[43]);
    GlStateManager.popMatrix();
    GlStateManager.matrixMode(llllIIIlI[44]);
    GlStateManager.popMatrix();
    GlStateManager.depthMask(llllIIIlI[1]);
    GlStateManager.enableCull();
    GlStateManager.enableDepth();
  }
  
  private static boolean llIIIIllIII(int ???)
  {
    long lIIIlIlIlllIIl;
    return ??? == 0;
  }
  
  private void renderSkybox(int lIIIllIIllllIl, int lIIIllIIllllII, float lIIIllIlIIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    mc.getFramebuffer().unbindFramebuffer();
    GlStateManager.viewport(llllIIIlI[0], llllIIIlI[0], llllIIIlI[17], llllIIIlI[17]);
    lIIIllIlIIlIIl.drawPanorama(lIIIllIIllllIl, lIIIllIIllllII, lIIIllIlIIIllI);
    lIIIllIlIIlIIl.rotateAndBlurSkybox(lIIIllIlIIIllI);
    lIIIllIlIIlIIl.rotateAndBlurSkybox(lIIIllIlIIIllI);
    lIIIllIlIIlIIl.rotateAndBlurSkybox(lIIIllIlIIIllI);
    lIIIllIlIIlIIl.rotateAndBlurSkybox(lIIIllIlIIIllI);
    lIIIllIlIIlIIl.rotateAndBlurSkybox(lIIIllIlIIIllI);
    lIIIllIlIIlIIl.rotateAndBlurSkybox(lIIIllIlIIIllI);
    lIIIllIlIIlIIl.rotateAndBlurSkybox(lIIIllIlIIIllI);
    mc.getFramebuffer().bindFramebuffer(llllIIIlI[1]);
    GlStateManager.viewport(llllIIIlI[0], llllIIIlI[0], mc.displayWidth, mc.displayHeight);
    if (llIIIlIIIlI(width, height))
    {
      "".length();
      if ((0xF3 ^ 0xBA ^ 0x23 ^ 0x6E) >= ("   ".length() & ("   ".length() ^ -" ".length()))) {
        break label192;
      }
    }
    label192:
    float lIIIllIlIIIlIl = 120.0F / height;
    float lIIIllIlIIIlII = height * lIIIllIlIIIlIl / 256.0F;
    float lIIIllIlIIIIll = width * lIIIllIlIIIlIl / 256.0F;
    int lIIIllIlIIIIlI = width;
    int lIIIllIlIIIIIl = height;
    Tessellator lIIIllIlIIIIII = Tessellator.getInstance();
    WorldRenderer lIIIllIIllllll = lIIIllIlIIIIII.getWorldRenderer();
    lIIIllIIllllll.begin(llllIIIlI[7], DefaultVertexFormats.POSITION_TEX_COLOR);
    lIIIllIIllllll.pos(0.0D, lIIIllIlIIIIIl, zLevel).tex(0.5F - lIIIllIlIIIlII, 0.5F + lIIIllIlIIIIll).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
    lIIIllIIllllll.pos(lIIIllIlIIIIlI, lIIIllIlIIIIIl, zLevel).tex(0.5F - lIIIllIlIIIlII, 0.5F - lIIIllIlIIIIll).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
    lIIIllIIllllll.pos(lIIIllIlIIIIlI, 0.0D, zLevel).tex(0.5F + lIIIllIlIIIlII, 0.5F - lIIIllIlIIIIll).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
    lIIIllIIllllll.pos(0.0D, 0.0D, zLevel).tex(0.5F + lIIIllIlIIIlII, 0.5F + lIIIllIlIIIIll).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
    lIIIllIlIIIIII.draw();
  }
  
  private static boolean llIIIlIIlll(int ???, int arg1)
  {
    int i;
    boolean lIIIlIllIIlIIl;
    return ??? < i;
  }
}

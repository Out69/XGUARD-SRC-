package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.GameSettings.Options;
import net.minecraft.client.settings.KeyBinding;

public class GuiControls
  extends GuiScreen
{
  private static boolean lllllIIlllIII(int ???)
  {
    int lllllllllllllllIlIlIIIIllIlIlllI;
    return ??? > 0;
  }
  
  public void drawScreen(int lllllllllllllllIlIlIIIIllllIIIll, int lllllllllllllllIlIlIIIIllllIlIII, float lllllllllllllllIlIlIIIIllllIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIIIIllllIlIlI.drawDefaultBackground();
    keyBindingList.drawScreen(lllllllllllllllIlIlIIIIllllIIIll, lllllllllllllllIlIlIIIIllllIlIII, lllllllllllllllIlIlIIIIllllIIIIl);
    lllllllllllllllIlIlIIIIllllIlIlI.drawCenteredString(fontRendererObj, screenTitle, width / lIlIIIIlIlll[3], lIlIIIIlIlll[16], lIlIIIIlIlll[17]);
    boolean lllllllllllllllIlIlIIIIllllIIllI = lIlIIIIlIlll[2];
    short lllllllllllllllIlIlIIIIlllIlllIl = (lllllllllllllllIlIlIIIIlllIlllII = options.keyBindings).length;
    int lllllllllllllllIlIlIIIIlllIllllI = lIlIIIIlIlll[1];
    "".length();
    if (" ".length() <= 0) {
      return;
    }
    while (!lllllIIllIIll(lllllllllllllllIlIlIIIIlllIllllI, lllllllllllllllIlIlIIIIlllIlllIl))
    {
      KeyBinding lllllllllllllllIlIlIIIIllllIIlIl = lllllllllllllllIlIlIIIIlllIlllII[lllllllllllllllIlIlIIIIlllIllllI];
      if (lllllIIlllIIl(lllllllllllllllIlIlIIIIllllIIlIl.getKeyCode(), lllllllllllllllIlIlIIIIllllIIlIl.getKeyCodeDefault()))
      {
        lllllllllllllllIlIlIIIIllllIIllI = lIlIIIIlIlll[1];
        "".length();
        if ("  ".length() != 0) {
          break;
        }
        return;
      }
      lllllllllllllllIlIlIIIIlllIllllI++;
    }
    if (lllllIIllIIlI(lllllllllllllllIlIlIIIIllllIIllI))
    {
      "".length();
      if (-" ".length() <= 0) {
        break label186;
      }
    }
    label186:
    lIlIIIIlIlll1enabled = lIlIIIIlIlll[2];
    lllllllllllllllIlIlIIIIllllIlIlI.drawScreen(lllllllllllllllIlIlIIIIllllIIIll, lllllllllllllllIlIlIIIIllllIlIII, lllllllllllllllIlIlIIIIllllIIIIl);
  }
  
  public GuiControls(GuiScreen lllllllllllllllIlIlIIIlIIIlllIlI, GameSettings lllllllllllllllIlIlIIIlIIIllIllI)
  {
    parentScreen = lllllllllllllllIlIlIIIlIIIllIlll;
    options = lllllllllllllllIlIlIIIlIIIllIllI;
  }
  
  protected void keyTyped(char lllllllllllllllIlIlIIIIllllllIII, int lllllllllllllllIlIlIIIIlllllIlll)
    throws IOException
  {
    ;
    ;
    ;
    if (lllllIIllIllI(buttonId))
    {
      if (lllllIIllIlII(lllllllllllllllIlIlIIIIlllllIlll, lIlIIIIlIlll[2]))
      {
        options.setOptionKeyBinding(buttonId, lIlIIIIlIlll[1]);
        "".length();
        if (((0x2B ^ 0x41 ^ 0x6E ^ 0x3E) & (0x25 ^ 0x14 ^ 0x5E ^ 0x55 ^ -" ".length())) == 0) {}
      }
      else if (lllllIIllIIlI(lllllllllllllllIlIlIIIIlllllIlll))
      {
        options.setOptionKeyBinding(buttonId, lllllllllllllllIlIlIIIIlllllIlll);
        "".length();
        if ("  ".length() >= 0) {}
      }
      else if (lllllIIlllIII(lllllllllllllllIlIlIIIIlllllIlIl))
      {
        options.setOptionKeyBinding(buttonId, lllllllllllllllIlIlIIIIlllllIlIl + lIlIIIIlIlll[15]);
      }
      buttonId = null;
      time = Minecraft.getSystemTime();
      KeyBinding.resetKeyBindingArrayAndHash();
      "".length();
      if (null == null) {}
    }
    else
    {
      lllllllllllllllIlIlIIIIlllllIllI.keyTyped(lllllllllllllllIlIlIIIIlllllIlIl, lllllllllllllllIlIlIIIIlllllIlll);
    }
  }
  
  private static void lllllIIllIIIl()
  {
    lIlIIIIlIlll = new int[19];
    lIlIIIIlIlll[0] = "   ".length();
    lIlIIIIlIlll[1] = (((0x1A ^ 0x40) & (0xC2 ^ 0x98 ^ 0xFFFFFFFF) ^ 0x9F ^ 0x90) & (0x72 ^ 0x6E ^ 0x1 ^ 0x12 ^ -" ".length()));
    lIlIIIIlIlll[2] = " ".length();
    lIlIIIIlIlll[3] = "  ".length();
    lIlIIIIlIlll[4] = ((0x26 ^ 0x65) + (32 + '' - 67 + 40) - ('' + 96 - 195 + 146) + (19 + 75 - 67 + 128));
    lIlIIIIlIlll[5] = ((0x98 ^ 0x95) + (0x58 ^ 0x41) - (0x45 ^ 0x5A) + (69 + 117 - 120 + 82));
    lIlIIIIlIlll[6] = (0x6F ^ 0x72);
    lIlIIIIlIlll[7] = (83 + 87 - 75 + 47 + (0x90 ^ 0x84) - (0x67 ^ 0x4C) + (0x8A ^ 0x95));
    lIlIIIIlIlll[8] = (0x64 ^ 0x70);
    lIlIIIIlIlll[9] = ('§' + 57 - 164 + 141);
    lIlIIIIlIlll[10] = (63 + 68 - -11 + 18);
    lIlIIIIlIlll[11] = (105 + '' - 107 + 15 ^ 100 + 96 - 163 + 144);
    lIlIIIIlIlll[12] = (0x9A ^ 0x83 ^ " ".length());
    lIlIIIIlIlll[13] = (0x7B ^ 0x1F);
    lIlIIIIlIlll[14] = (-(0x3F ^ 0x26 ^ 0xD4 ^ 0xA9));
    lIlIIIIlIlll[15] = (-(0xE2FB & 0x7FFC) & 0xF7F7 & 0x6BFF);
    lIlIIIIlIlll[16] = (0xBA ^ 0xB2);
    lIlIIIIlIlll[17] = (0xFFFFFFFF & 0xFFFFFF);
    lIlIIIIlIlll[18] = (0xA4 ^ 0x99 ^ 0x4 ^ 0x3D);
  }
  
  private static boolean lllllIIllIllI(Object ???)
  {
    boolean lllllllllllllllIlIlIIIIllIllIlII;
    return ??? != null;
  }
  
  private static boolean lllllIIllIIlI(int ???)
  {
    long lllllllllllllllIlIlIIIIllIllIIlI;
    return ??? != 0;
  }
  
  private static boolean lllllIIllIlII(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIlIlIIIIllIlllllI;
    return ??? == i;
  }
  
  protected void mouseClicked(int lllllllllllllllIlIlIIIlIIIIIlIll, int lllllllllllllllIlIlIIIlIIIIIlIlI, int lllllllllllllllIlIlIIIlIIIIIlIIl)
    throws IOException
  {
    ;
    ;
    ;
    ;
    if (lllllIIllIllI(buttonId))
    {
      options.setOptionKeyBinding(buttonId, lIlIIIIlIlll[14] + lllllllllllllllIlIlIIIlIIIIIlIIl);
      buttonId = null;
      KeyBinding.resetKeyBindingArrayAndHash();
      "".length();
      if (-"  ".length() <= 0) {}
    }
    else if ((!lllllIIllIlll(lllllllllllllllIlIlIIIlIIIIIlIIl)) || (lllllIIllIlll(keyBindingList.mouseClicked(lllllllllllllllIlIlIIIlIIIIIlIll, lllllllllllllllIlIlIIIlIIIIIlIlI, lllllllllllllllIlIlIIIlIIIIIlIIl))))
    {
      lllllllllllllllIlIlIIIlIIIIIllII.mouseClicked(lllllllllllllllIlIlIIIlIIIIIlIll, lllllllllllllllIlIlIIIlIIIIIlIlI, lllllllllllllllIlIlIIIlIIIIIlIIl);
    }
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    lllllllllllllllIlIlIIIlIIIlIIlII.handleMouseInput();
    keyBindingList.handleMouseInput();
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    keyBindingList = new GuiKeyBindingList(lllllllllllllllIlIlIIIlIIIlIllll, mc);
    new GuiButton(lIlIIIIlIlll[4], width / lIlIIIIlIlll[3] - lIlIIIIlIlll[5], height - lIlIIIIlIlll[6], lIlIIIIlIlll[7], lIlIIIIlIlll[8], I18n.format(lIlIIIIlIllI[lIlIIIIlIlll[2]], new Object[lIlIIIIlIlll[1]]));
    "".length();
    buttonReset = new GuiButton(lIlIIIIlIlll[9], width / lIlIIIIlIlll[3] - lIlIIIIlIlll[5] + lIlIIIIlIlll[10], height - lIlIIIIlIlll[6], lIlIIIIlIlll[7], lIlIIIIlIlll[8], I18n.format(lIlIIIIlIllI[lIlIIIIlIlll[3]], new Object[lIlIIIIlIlll[1]]));
    "".length();
    screenTitle = I18n.format(lIlIIIIlIllI[lIlIIIIlIlll[0]], new Object[lIlIIIIlIlll[1]]);
    int lllllllllllllllIlIlIIIlIIIlIlllI = lIlIIIIlIlll[1];
    short lllllllllllllllIlIlIIIlIIIlIlIII = (lllllllllllllllIlIlIIIlIIIlIIlll = optionsArr).length;
    int lllllllllllllllIlIlIIIlIIIlIlIIl = lIlIIIIlIlll[1];
    "".length();
    if (((0x5C ^ 0x15) & (0x2A ^ 0x63 ^ 0xFFFFFFFF)) != 0) {
      return;
    }
    while (!lllllIIllIIll(lllllllllllllllIlIlIIIlIIIlIlIIl, lllllllllllllllIlIlIIIlIIIlIlIII))
    {
      GameSettings.Options lllllllllllllllIlIlIIIlIIIlIllIl = lllllllllllllllIlIlIIIlIIIlIIlll[lllllllllllllllIlIlIIIlIIIlIlIIl];
      if (lllllIIllIIlI(lllllllllllllllIlIlIIIlIIIlIllIl.getEnumFloat()))
      {
        new GuiOptionSlider(lllllllllllllllIlIlIIIlIIIlIllIl.returnEnumOrdinal(), width / lIlIIIIlIlll[3] - lIlIIIIlIlll[5] + lllllllllllllllIlIlIIIlIIIlIlllI % lIlIIIIlIlll[3] * lIlIIIIlIlll[10], lIlIIIIlIlll[11] + lIlIIIIlIlll[12] * (lllllllllllllllIlIlIIIlIIIlIlllI >> lIlIIIIlIlll[2]), lllllllllllllllIlIlIIIlIIIlIllIl);
        "".length();
        "".length();
        if ("   ".length() >= "  ".length()) {}
      }
      else
      {
        new GuiOptionButton(lllllllllllllllIlIlIIIlIIIlIllIl.returnEnumOrdinal(), width / lIlIIIIlIlll[3] - lIlIIIIlIlll[5] + lllllllllllllllIlIlIIIlIIIlIlllI % lIlIIIIlIlll[3] * lIlIIIIlIlll[10], lIlIIIIlIlll[11] + lIlIIIIlIlll[12] * (lllllllllllllllIlIlIIIlIIIlIlllI >> lIlIIIIlIlll[2]), lllllllllllllllIlIlIIIlIIIlIllIl, options.getKeyBinding(lllllllllllllllIlIlIIIlIIIlIllIl));
        "".length();
      }
      lllllllllllllllIlIlIIIlIIIlIlllI++;
    }
  }
  
  private static boolean lllllIIllIlll(int ???)
  {
    double lllllllllllllllIlIlIIIIllIllIIII;
    return ??? == 0;
  }
  
  private static boolean lllllIIllIIll(int ???, int arg1)
  {
    int i;
    int lllllllllllllllIlIlIIIIllIlllIlI;
    return ??? >= i;
  }
  
  private static String lllllIIlIllIl(String lllllllllllllllIlIlIIIIlllIlIIlI, String lllllllllllllllIlIlIIIIlllIlIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIIIIlllIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIIIIlllIlIIIl.getBytes(StandardCharsets.UTF_8)), lIlIIIIlIlll[16]), "DES");
      Cipher lllllllllllllllIlIlIIIIlllIlIllI = Cipher.getInstance("DES");
      lllllllllllllllIlIlIIIIlllIlIllI.init(lIlIIIIlIlll[3], lllllllllllllllIlIlIIIIlllIlIlll);
      return new String(lllllllllllllllIlIlIIIIlllIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIIIIlllIlIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIIIIlllIlIlIl)
    {
      lllllllllllllllIlIlIIIIlllIlIlIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllllIIllIlIl(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIlIlIIIIllIllIllI;
    return ??? < i;
  }
  
  private static boolean lllllIIlllIIl(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIlIlIIIIllIlIlIlI;
    return ??? != i;
  }
  
  private static String lllllIIlIlIlI(String lllllllllllllllIlIlIIIIlllIIIlIl, String lllllllllllllllIlIlIIIIlllIIIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIIIIlllIIlIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIIIIlllIIIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlIlIIIIlllIIlIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlIlIIIIlllIIlIIl.init(lIlIIIIlIlll[3], lllllllllllllllIlIlIIIIlllIIlIlI);
      return new String(lllllllllllllllIlIlIIIIlllIIlIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIIIIlllIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIIIIlllIIlIII)
    {
      lllllllllllllllIlIlIIIIlllIIlIII.printStackTrace();
    }
    return null;
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllIlIlIIIlIIIIlllII)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllllIIllIlII(id, lIlIIIIlIlll[4]))
    {
      mc.displayGuiScreen(parentScreen);
      "".length();
      if (((0x38 ^ 0x15) & (0x84 ^ 0xA9 ^ 0xFFFFFFFF)) == 0) {}
    }
    else if (lllllIIllIlII(id, lIlIIIIlIlll[9]))
    {
      lllllllllllllllIlIlIIIlIIIIlIllI = (lllllllllllllllIlIlIIIlIIIIlIlIl = mc.gameSettings.keyBindings).length;
      lllllllllllllllIlIlIIIlIIIIlIlll = lIlIIIIlIlll[1];
      "".length();
      if (-"   ".length() >= 0) {
        return;
      }
      while (!lllllIIllIIll(lllllllllllllllIlIlIIIlIIIIlIlll, lllllllllllllllIlIlIIIlIIIIlIllI))
      {
        KeyBinding lllllllllllllllIlIlIIIlIIIIllIll = lllllllllllllllIlIlIIIlIIIIlIlIl[lllllllllllllllIlIlIIIlIIIIlIlll];
        lllllllllllllllIlIlIIIlIIIIllIll.setKeyCode(lllllllllllllllIlIlIIIlIIIIllIll.getKeyCodeDefault());
        lllllllllllllllIlIlIIIlIIIIlIlll++;
      }
      KeyBinding.resetKeyBindingArrayAndHash();
      "".length();
      if ("  ".length() >= " ".length()) {}
    }
    else if ((lllllIIllIlIl(id, lIlIIIIlIlll[13])) && (lllllIIllIIlI(lllllllllllllllIlIlIIIlIIIIlllII instanceof GuiOptionButton)))
    {
      options.setOptionValue(((GuiOptionButton)lllllllllllllllIlIlIIIlIIIIlllII).returnEnumOptions(), lIlIIIIlIlll[2]);
      displayString = options.getKeyBinding(GameSettings.Options.getEnumOptions(id));
    }
  }
  
  private static void lllllIIlIlllI()
  {
    lIlIIIIlIllI = new String[lIlIIIIlIlll[18]];
    lIlIIIIlIllI[lIlIIIIlIlll[1]] = lllllIIlIlIlI("bqQR+NHZVLtCTU+Wxu7WcA==", "FeoHj");
    lIlIIIIlIllI[lIlIIIIlIlll[2]] = lllllIIlIllIl("ldVhqqAV3XnhwK7CEPuXug==", "gLgku");
    lIlIIIIlIllI[lIlIIIIlIlll[3]] = lllllIIlIllIl("Wo1+DmaOMhDhq8VmFJdk+5YOb3zmCe/M", "KDVMH");
    lIlIIIIlIllI[lIlIIIIlIlll[0]] = lllllIIlIllIl("tkXqoB1eSBaBJsRywnRgxw==", "zdQfV");
  }
  
  static
  {
    lllllIIllIIIl();
    lllllIIlIlllI();
  }
  
  protected void mouseReleased(int lllllllllllllllIlIlIIIlIIIIIIIll, int lllllllllllllllIlIlIIIIllllllllI, int lllllllllllllllIlIlIIIIlllllllIl)
  {
    ;
    ;
    ;
    ;
    if ((!lllllIIllIlll(lllllllllllllllIlIlIIIIlllllllIl)) || (lllllIIllIlll(keyBindingList.mouseReleased(lllllllllllllllIlIlIIIlIIIIIIIll, lllllllllllllllIlIlIIIIllllllllI, lllllllllllllllIlIlIIIIlllllllIl)))) {
      lllllllllllllllIlIlIIIlIIIIIIlII.mouseReleased(lllllllllllllllIlIlIIIlIIIIIIIll, lllllllllllllllIlIlIIIIllllllllI, lllllllllllllllIlIlIIIIlllllllIl);
    }
  }
}

package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;

public class GuiListButton
  extends GuiButton
{
  private static String lIIIlIlIllllII(String lllllllllllllllIIllIlIIIIIIllIIl, String lllllllllllllllIIllIlIIIIIIlIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIllIlIIIIIIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIlIIIIIIlIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIllIlIIIIIIllIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIIllIlIIIIIIllIll.init(lIllIlIIIIll[4], lllllllllllllllIIllIlIIIIIIlllII);
      return new String(lllllllllllllllIIllIlIIIIIIllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIlIIIIIIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIllIlIIIIIIllIlI)
    {
      lllllllllllllllIIllIlIIIIIIllIlI.printStackTrace();
    }
    return null;
  }
  
  public void func_175212_b(boolean lllllllllllllllIIllIlIIIIIlIllll)
  {
    ;
    ;
    field_175216_o = lllllllllllllllIIllIlIIIIIlIllll;
    displayString = lllllllllllllllIIllIlIIIIIllIIII.buildDisplayString();
    guiResponder.func_175321_a(id, lllllllllllllllIIllIlIIIIIlIllll);
  }
  
  public boolean mousePressed(Minecraft lllllllllllllllIIllIlIIIIIlIIlll, int lllllllllllllllIIllIlIIIIIlIIIlI, int lllllllllllllllIIllIlIIIIIlIIlIl)
  {
    ;
    ;
    ;
    ;
    if (lIIIlIllIIIIII(lllllllllllllllIIllIlIIIIIlIIlII.mousePressed(lllllllllllllllIIllIlIIIIIlIIlll, lllllllllllllllIIllIlIIIIIlIIIlI, lllllllllllllllIIllIlIIIIIlIIlIl)))
    {
      if (lIIIlIllIIIIII(field_175216_o))
      {
        "".length();
        if (((0x5F ^ 0x56) & (0x15 ^ 0x1C ^ 0xFFFFFFFF)) >= -" ".length()) {
          break label76;
        }
        return (0x14 ^ 0x57) & (0x29 ^ 0x6A ^ 0xFFFFFFFF);
      }
      label76:
      lIllIlIIIIll2field_175216_o = lIllIlIIIIll[3];
      displayString = lllllllllllllllIIllIlIIIIIlIIlII.buildDisplayString();
      guiResponder.func_175321_a(id, field_175216_o);
      return lIllIlIIIIll[3];
    }
    return lIllIlIIIIll[2];
  }
  
  public GuiListButton(GuiPageButtonList.GuiResponder lllllllllllllllIIllIlIIIIlIIIIlI, int lllllllllllllllIIllIlIIIIlIIIIIl, int lllllllllllllllIIllIlIIIIlIIIIII, int lllllllllllllllIIllIlIIIIIlllIII, String lllllllllllllllIIllIlIIIIIlllllI, boolean lllllllllllllllIIllIlIIIIIllllIl)
  {
    lllllllllllllllIIllIlIIIIIllllII.<init>(lllllllllllllllIIllIlIIIIlIIIIIl, lllllllllllllllIIllIlIIIIIlllIIl, lllllllllllllllIIllIlIIIIIlllIII, lIllIlIIIIll[0], lIllIlIIIIll[1], lIllIlIIIIlI[lIllIlIIIIll[2]]);
    localizationStr = lllllllllllllllIIllIlIIIIIlllllI;
    field_175216_o = lllllllllllllllIIllIlIIIIIllllIl;
    displayString = lllllllllllllllIIllIlIIIIIllllII.buildDisplayString();
    guiResponder = lllllllllllllllIIllIlIIIIlIIIIlI;
  }
  
  private static boolean lIIIlIllIIIIIl(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIIllIIllllllllIII;
    return ??? < i;
  }
  
  private String buildDisplayString()
  {
    ;
    new StringBuilder(String.valueOf(I18n.format(localizationStr, new Object[lIllIlIIIIll[2]])));
    if (lIIIlIllIIIIII(field_175216_o))
    {
      "".length();
      if (-"   ".length() <= 0) {
        break label104;
      }
      return null;
    }
    label104:
    return String.valueOf(I18n.format(lIllIlIIIIlI[lIllIlIIIIll[4]], new Object[lIllIlIIIIll[2]]).append(I18n.format(lIllIlIIIIlI[lIllIlIIIIll[5]], new Object[lIllIlIIIIll[2]])));
  }
  
  private static String lIIIlIlIllllIl(String lllllllllllllllIIllIlIIIIIIIlIIl, String lllllllllllllllIIllIlIIIIIIIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIllIlIIIIIIIlIIl = new String(Base64.getDecoder().decode(lllllllllllllllIIllIlIIIIIIIlIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIllIlIIIIIIIIlll = new StringBuilder();
    char[] lllllllllllllllIIllIlIIIIIIIIllI = lllllllllllllllIIllIlIIIIIIIlIII.toCharArray();
    int lllllllllllllllIIllIlIIIIIIIIlIl = lIllIlIIIIll[2];
    Exception lllllllllllllllIIllIIlllllllllll = lllllllllllllllIIllIlIIIIIIIlIIl.toCharArray();
    short lllllllllllllllIIllIIllllllllllI = lllllllllllllllIIllIIlllllllllll.length;
    Exception lllllllllllllllIIllIIlllllllllIl = lIllIlIIIIll[2];
    while (lIIIlIllIIIIIl(lllllllllllllllIIllIIlllllllllIl, lllllllllllllllIIllIIllllllllllI))
    {
      char lllllllllllllllIIllIlIIIIIIIlIlI = lllllllllllllllIIllIIlllllllllll[lllllllllllllllIIllIIlllllllllIl];
      "".length();
      "".length();
      if ("   ".length() == 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIllIlIIIIIIIIlll);
  }
  
  static
  {
    lIIIlIlIllllll();
    lIIIlIlIlllllI();
  }
  
  private static void lIIIlIlIlllllI()
  {
    lIllIlIIIIlI = new String[lIllIlIIIIll[6]];
    lIllIlIIIIlI[lIllIlIIIIll[2]] = lIIIlIlIllllII("lGSnAXqgSA8=", "UtxcN");
    lIllIlIIIIlI[lIllIlIIIIll[3]] = lIIIlIlIllllII("nR5yCtVOESU=", "vKgDk");
    lIllIlIIIIlI[lIllIlIIIIll[4]] = lIIIlIlIllllIl("KhAkXwkoFg==", "MeMqp");
    lIllIlIIIIlI[lIllIlIIIIll[5]] = lIIIlIlIllllII("gD/6spJWC3M=", "HUtNw");
  }
  
  private static void lIIIlIlIllllll()
  {
    lIllIlIIIIll = new int[7];
    lIllIlIIIIll[0] = ('' + 117 - 258 + 149);
    lIllIlIIIIll[1] = (0xD6 ^ 0x8E ^ 0xE2 ^ 0xAE);
    lIllIlIIIIll[2] = (('µ' + 'Æ' - 150 + 15 ^ 30 + 49 - 2 + 74) & (0xE ^ 0x62 ^ 0x55 ^ 0x5A ^ -" ".length()));
    lIllIlIIIIll[3] = " ".length();
    lIllIlIIIIll[4] = "  ".length();
    lIllIlIIIIll[5] = "   ".length();
    lIllIlIIIIll[6] = (0xB4 ^ 0xB0);
  }
  
  private static boolean lIIIlIllIIIIII(int ???)
  {
    float lllllllllllllllIIllIIlllllllIllI;
    return ??? != 0;
  }
}

package net.minecraft.client.gui;

import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.network.LanServerDetector.LanServer;

public class ServerSelectionList
  extends GuiListExtended
{
  public int func_148193_k()
  {
    ;
    return selectedSlotIndex;
  }
  
  static {}
  
  public void func_148195_a(ServerList llllllllllllllIlIIIIIlIIlllIIIII)
  {
    ;
    ;
    ;
    field_148198_l.clear();
    int llllllllllllllIlIIIIIlIIlllIIIlI = lIIlIIlllIlIl[2];
    "".length();
    if (" ".length() != " ".length()) {
      return;
    }
    while (!lllIIIIlIlIIII(llllllllllllllIlIIIIIlIIlllIIIlI, llllllllllllllIlIIIIIlIIlllIIIII.countServers()))
    {
      new ServerListEntryNormal(owner, llllllllllllllIlIIIIIlIIlllIIIII.getServerData(llllllllllllllIlIIIIIlIIlllIIIlI));
      "".length();
    }
  }
  
  protected int getScrollBarX()
  {
    ;
    return llllllllllllllIlIIIIIlIIllIlIIIl.getScrollBarX() + lIIlIIlllIlIl[3];
  }
  
  private static boolean lllIIIIlIIlllI(int ???)
  {
    byte llllllllllllllIlIIIIIlIIllIIIIII;
    return ??? == 0;
  }
  
  protected boolean isSelected(int llllllllllllllIlIIIIIlIIlllIllIl)
  {
    ;
    ;
    if (lllIIIIlIIllll(llllllllllllllIlIIIIIlIIlllIllIl, selectedSlotIndex)) {
      return lIIlIIlllIlIl[1];
    }
    return lIIlIIlllIlIl[2];
  }
  
  private static boolean lllIIIIlIIllIl(int ???, int arg1)
  {
    int i;
    String llllllllllllllIlIIIIIlIIllIIIIlI;
    return ??? < i;
  }
  
  public GuiListExtended.IGuiListEntry getListEntry(int llllllllllllllIlIIIIIlIIllllllII)
  {
    ;
    ;
    if (lllIIIIlIIllIl(llllllllllllllIlIIIIIlIIllllllII, field_148198_l.size())) {
      return (GuiListExtended.IGuiListEntry)field_148198_l.get(llllllllllllllIlIIIIIlIIllllllII);
    }
    llllllllllllllIlIIIIIlIIllllllII -= field_148198_l.size();
    if (lllIIIIlIIlllI(llllllllllllllIlIIIIIlIIllllllII)) {
      return lanScanEntry;
    }
    llllllllllllllIlIIIIIlIIllllllII--;
    return (GuiListExtended.IGuiListEntry)field_148199_m.get(llllllllllllllIlIIIIIlIIllllllII);
  }
  
  public ServerSelectionList(GuiMultiplayer llllllllllllllIlIIIIIlIlIIIIlllI, Minecraft llllllllllllllIlIIIIIlIlIIIIIlIl, int llllllllllllllIlIIIIIlIlIIIIllII, int llllllllllllllIlIIIIIlIlIIIIlIll, int llllllllllllllIlIIIIIlIlIIIIIIlI, int llllllllllllllIlIIIIIlIlIIIIlIIl, int llllllllllllllIlIIIIIlIlIIIIlIII)
  {
    llllllllllllllIlIIIIIlIlIIIIIlll.<init>(llllllllllllllIlIIIIIlIlIIIIIlIl, llllllllllllllIlIIIIIlIlIIIIllII, llllllllllllllIlIIIIIlIlIIIIlIll, llllllllllllllIlIIIIIlIlIIIIIIlI, llllllllllllllIlIIIIIlIlIIIIlIIl, llllllllllllllIlIIIIIlIlIIIIlIII);
    owner = llllllllllllllIlIIIIIlIlIIIIlllI;
  }
  
  public void setSelectedSlotIndex(int llllllllllllllIlIIIIIlIIllllIIIl)
  {
    ;
    ;
    selectedSlotIndex = llllllllllllllIlIIIIIlIIllllIIIl;
  }
  
  protected int getSize()
  {
    ;
    return field_148198_l.size() + lIIlIIlllIlIl[1] + field_148199_m.size();
  }
  
  private static boolean lllIIIIlIlIIII(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlIIIIIlIIllIIIllI;
    return ??? >= i;
  }
  
  public int getListWidth()
  {
    ;
    return llllllllllllllIlIIIIIlIIllIIllll.getListWidth() + lIIlIIlllIlIl[4];
  }
  
  private static void lllIIIIlIIllII()
  {
    lIIlIIlllIlIl = new int[5];
    lIIlIIlllIlIl[0] = (-" ".length());
    lIIlIIlllIlIl[1] = " ".length();
    lIIlIIlllIlIl[2] = ((0x58 ^ 0x73 ^ 0x11 ^ 0x24) & (0x1E ^ 0x58 ^ 0xF5 ^ 0xAD ^ -" ".length()));
    lIIlIIlllIlIl[3] = (0xDB ^ 0xC5);
    lIIlIIlllIlIl[4] = (0x76 ^ 0x23);
  }
  
  private static boolean lllIIIIlIIllll(int ???, int arg1)
  {
    int i;
    short llllllllllllllIlIIIIIlIIllIIlIlI;
    return ??? == i;
  }
  
  public void func_148194_a(List<LanServerDetector.LanServer> llllllllllllllIlIIIIIlIIllIllIIl)
  {
    ;
    ;
    ;
    field_148199_m.clear();
    String llllllllllllllIlIIIIIlIIllIlIlII = llllllllllllllIlIIIIIlIIllIllIIl.iterator();
    "".length();
    if (" ".length() == "   ".length()) {
      return;
    }
    while (!lllIIIIlIIlllI(llllllllllllllIlIIIIIlIIllIlIlII.hasNext()))
    {
      LanServerDetector.LanServer llllllllllllllIlIIIIIlIIllIllIII = (LanServerDetector.LanServer)llllllllllllllIlIIIIIlIIllIlIlII.next();
      new ServerListEntryLanDetected(owner, llllllllllllllIlIIIIIlIIllIllIII);
      "".length();
    }
  }
}

package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.MathHelper;

public class ScaledResolution
{
  static {}
  
  public int getScaledHeight()
  {
    ;
    return scaledHeight;
  }
  
  public double getScaledHeight_double()
  {
    ;
    return scaledHeightD;
  }
  
  private static boolean llIIIIIlIIIlI(int ???, int arg1)
  {
    int i;
    float llllllllllllllllIIIlIIllIIllIlll;
    return ??? != i;
  }
  
  private static boolean llIIIIIIlllll(int ???, int arg1)
  {
    int i;
    double llllllllllllllllIIIlIIllIIllllll;
    return ??? < i;
  }
  
  public double getScaledWidth_double()
  {
    ;
    return scaledWidthD;
  }
  
  public int getScaleFactor()
  {
    ;
    return scaleFactor;
  }
  
  private static boolean llIIIIIIllllI(int ???)
  {
    String llllllllllllllllIIIlIIllIIlllIll;
    return ??? == 0;
  }
  
  private static boolean llIIIIIlIIIII(int ???, int arg1)
  {
    int i;
    byte llllllllllllllllIIIlIIllIlIIIIll;
    return ??? >= i;
  }
  
  public ScaledResolution(Minecraft llllllllllllllllIIIlIIllIlIllIIl)
  {
    scaledWidth = displayWidth;
    scaledHeight = displayHeight;
    scaleFactor = lllllIllIll[0];
    boolean llllllllllllllllIIIlIIllIlIllIII = llllllllllllllllIIIlIIllIlIllIIl.isUnicode();
    int llllllllllllllllIIIlIIllIlIlIlll = gameSettings.guiScale;
    if (llIIIIIIllllI(llllllllllllllllIIIlIIllIlIlIlll))
    {
      llllllllllllllllIIIlIIllIlIlIlll = lllllIllIll[1];
      "".length();
      if (-" ".length() > ((0x6D ^ 0x53) & (0x96 ^ 0xA8 ^ 0xFFFFFFFF))) {
        throw null;
      }
    }
    while ((llIIIIIIlllll(scaleFactor, llllllllllllllllIIIlIIllIlIlIlll)) && (llIIIIIlIIIII(scaledWidth / (scaleFactor + lllllIllIll[0]), lllllIllIll[2])) && (!llIIIIIIlllll(scaledHeight / (scaleFactor + lllllIllIll[0]), lllllIllIll[3]))) {
      scaleFactor += lllllIllIll[0];
    }
    if ((llIIIIIlIIIIl(llllllllllllllllIIIlIIllIlIllIII)) && (llIIIIIlIIIIl(scaleFactor % lllllIllIll[4])) && (llIIIIIlIIIlI(scaleFactor, lllllIllIll[0]))) {
      scaleFactor -= lllllIllIll[0];
    }
    scaledWidthD = (scaledWidth / scaleFactor);
    scaledHeightD = (scaledHeight / scaleFactor);
    scaledWidth = MathHelper.ceiling_double_int(scaledWidthD);
    scaledHeight = MathHelper.ceiling_double_int(scaledHeightD);
  }
  
  private static void llIIIIIIlllIl()
  {
    lllllIllIll = new int[5];
    lllllIllIll[0] = " ".length();
    lllllIllIll[1] = (0xE7FB & 0x1BEC);
    lllllIllIll[2] = (0x89CF & 0x7770);
    lllllIllIll[3] = ((0xA1 ^ 0x87) + ('' + '' - 244 + 125) - -(0x49 ^ 0x50) + (0x58 ^ 0x56));
    lllllIllIll[4] = "  ".length();
  }
  
  public static int getScaledWidth()
  {
    return scaledWidth;
  }
  
  private static boolean llIIIIIlIIIIl(int ???)
  {
    String llllllllllllllllIIIlIIllIIllllIl;
    return ??? != 0;
  }
}

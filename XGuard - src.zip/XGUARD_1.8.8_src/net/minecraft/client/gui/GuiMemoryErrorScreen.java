package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;

public class GuiMemoryErrorScreen
  extends GuiScreen
{
  private static void llIIIIIllIlll()
  {
    llllllIIIIl = new int[28];
    llllllIIIIl[0] = ((0xCF ^ 0x94 ^ 0x3F ^ 0x6A) & (122 + 50 - 75 + 56 ^ 0 + 120 - 110 + 141 ^ -" ".length()));
    llllllIIIIl[1] = "  ".length();
    llllllIIIIl[2] = (38 + 11 - 19 + 125);
    llllllIIIIl[3] = (0x53 ^ 0x57);
    llllllIIIIl[4] = (0x78 ^ 0x1 ^ " ".length());
    llllllIIIIl[5] = (0x31 ^ 0x3D);
    llllllIIIIl[6] = " ".length();
    llllllIIIIl[7] = (116 + 58 - 75 + 61);
    llllllIIIIl[8] = (0x6F ^ 0x53);
    llllllIIIIl[9] = (0xA2 ^ 0xB6);
    llllllIIIIl[10] = (0xFFFFFFFF & 0xFFFFFF);
    llllllIIIIl[11] = "   ".length();
    llllllIIIIl[12] = ((0x23 ^ 0x5B) + (0x2D ^ 0x24) - (0x49 ^ 0x6D) + (0x58 ^ 0x77));
    llllllIIIIl[13] = (0xA0AB & 0xA0FFF4);
    llllllIIIIl[14] = ('' + 31 - -39 + 9 ^ '' + '' - 130 + 55);
    llllllIIIIl[15] = (0xE8 ^ 0x95 ^ 0xD6 ^ 0xAE);
    llllllIIIIl[16] = (0x86 ^ 0x9D);
    llllllIIIIl[17] = (0x49 ^ 0x19 ^ 0xC3 ^ 0x95);
    llllllIIIIl[18] = (0xB1 ^ 0x95);
    llllllIIIIl[19] = (0x46 ^ 0x41);
    llllllIIIIl[20] = (0x53 ^ 0xE ^ 0x3E ^ 0x55);
    llllllIIIIl[21] = (0x26 ^ 0x2E);
    llllllIIIIl[22] = (0x47 ^ 0x78);
    llllllIIIIl[23] = (0x46 ^ 0x4F);
    llllllIIIIl[24] = (0xFE ^ 0x9F ^ 0xB ^ 0x22);
    llllllIIIIl[25] = (16 + 57 - -27 + 42 ^ 74 + 4 - -45 + 9);
    llllllIIIIl[26] = (0x66 ^ 0x37);
    llllllIIIIl[27] = (0x3C ^ 0x69 ^ 0xF2 ^ 0xAC);
  }
  
  private static String llIIIIIllIIll(String llllllllllllllllIIIlIIlIIIIlIllI, String llllllllllllllllIIIlIIlIIIIlIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIIlIIlIIIIlIllI = new String(Base64.getDecoder().decode(llllllllllllllllIIIlIIlIIIIlIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIIIlIIlIIIIlIlII = new StringBuilder();
    char[] llllllllllllllllIIIlIIlIIIIlIIll = llllllllllllllllIIIlIIlIIIIlIlIl.toCharArray();
    int llllllllllllllllIIIlIIlIIIIlIIlI = llllllIIIIl[0];
    int llllllllllllllllIIIlIIlIIIIIllII = llllllllllllllllIIIlIIlIIIIlIllI.toCharArray();
    Exception llllllllllllllllIIIlIIlIIIIIlIll = llllllllllllllllIIIlIIlIIIIIllII.length;
    float llllllllllllllllIIIlIIlIIIIIlIlI = llllllIIIIl[0];
    while (llIIIIIlllIlI(llllllllllllllllIIIlIIlIIIIIlIlI, llllllllllllllllIIIlIIlIIIIIlIll))
    {
      char llllllllllllllllIIIlIIlIIIIlIlll = llllllllllllllllIIIlIIlIIIIIllII[llllllllllllllllIIIlIIlIIIIIlIlI];
      "".length();
      "".length();
      if (" ".length() >= "   ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIIIlIIlIIIIlIlII);
  }
  
  private static void llIIIIIllIllI()
  {
    llllllIIIII = new String[llllllIIIIl[27]];
    llllllIIIII[llllllIIIIl[0]] = llIIIIIllIIll("MSYBXCw5BwEGNDM=", "VShrX");
    llllllIIIII[llllllIIIIl[6]] = llIIIIIllIlII("tWtBwyJbEFRiJmzi5LoU5A==", "MGEud");
    llllllIIIII[llllllIIIIl[1]] = llIIIIIllIlIl("rOgCEhBZHppXjU0PDHo79A==", "eaNUc");
    llllllIIIII[llllllIIIIl[11]] = llIIIIIllIlII("yBk1K1xVB6t6GOVzolU+41+T37ouOBeR5Sc36Mmsp/aF/zbMNCfnSw==", "vdnap");
    llllllIIIII[llllllIIIIl[3]] = llIIIIIllIlII("J7BFD1mdNUjGFhP7rxOBz4sGixWc/Jh5sCut5KLuzWAc/3qmYYxcK1FRA+H9s+fiDRmJWtOHRQY=", "bnJSF");
    llllllIIIII[llllllIIIIl[15]] = llIIIIIllIlII("RC0deSmnSGhqHvax/asteDI+1hNgPidpxSqzQmei4iw73Nk3JQe91KEvkomBoD3L", "aIdli");
    llllllIIIII[llllllIIIIl[17]] = llIIIIIllIIll("JRwbGyIxVw==", "HyvtP");
    llllllIIIII[llllllIIIIl[19]] = llIIIIIllIlIl("Fde8plbjd9zPaKOHfeaN0lULYRf1louSNMjV9jW2cvBwIyiZeNyyY0y9zBtbOLfZhYORG3WS0/E=", "kmaXm");
    llllllIIIII[llllllIIIIl[21]] = llIIIIIllIlII("7I4akElZh4Su8A/4OqrAJek4XR2LHH+gJcmnka7Ec14Bdrib0YyOB1VxdZxt5/wn40l8z8Kq4b+CDiSLlvnPQA==", "TCOQu");
    llllllIIIII[llllllIIIIl[23]] = llIIIIIllIlIl("IXRX+awlPqugPk0unoOS7lgCW8LDolKdDjXSGjKJN3CRzIoDYQQ7NcTB1/iRzyPdiup7bzDr/YOT89yD2W5+oX0Wd9wbDp0Y", "wMOGC");
    llllllIIIII[llllllIIIIl[25]] = llIIIIIllIlIl("jdYsExAnKo7ly+B+i8npwrZS9Ug7ER1xGXpFBRd/aaP+hbUjsBfPQzLhtJTeSHicUrvGIiRX8cs=", "mvsUf");
  }
  
  public void initGui()
  {
    ;
    buttonList.clear();
    new GuiOptionButton(llllllIIIIl[0], width / llllllIIIIl[1] - llllllIIIIl[2], height / llllllIIIIl[3] + llllllIIIIl[4] + llllllIIIIl[5], I18n.format(llllllIIIII[llllllIIIIl[0]], new Object[llllllIIIIl[0]]));
    "".length();
    new GuiOptionButton(llllllIIIIl[6], width / llllllIIIIl[1] - llllllIIIIl[2] + llllllIIIIl[7], height / llllllIIIIl[3] + llllllIIIIl[4] + llllllIIIIl[5], I18n.format(llllllIIIII[llllllIIIIl[6]], new Object[llllllIIIIl[0]]));
    "".length();
  }
  
  protected void keyTyped(char llllllllllllllllIIIlIIlIIIlllIll, int llllllllllllllllIIIlIIlIIIlllIlI)
    throws IOException
  {}
  
  static
  {
    llIIIIIllIlll();
    llIIIIIllIllI();
  }
  
  public void drawScreen(int llllllllllllllllIIIlIIlIIIllIIII, int llllllllllllllllIIIlIIlIIIlIllll, float llllllllllllllllIIIlIIlIIIlIlllI)
  {
    ;
    ;
    ;
    ;
    llllllllllllllllIIIlIIlIIIllIlIl.drawDefaultBackground();
    llllllllllllllllIIIlIIlIIIllIlIl.drawCenteredString(fontRendererObj, llllllIIIII[llllllIIIIl[1]], width / llllllIIIIl[1], height / llllllIIIIl[3] - llllllIIIIl[8] + llllllIIIIl[9], llllllIIIIl[10]);
    llllllllllllllllIIIlIIlIIIllIlIl.drawString(fontRendererObj, llllllIIIII[llllllIIIIl[11]], width / llllllIIIIl[1] - llllllIIIIl[12], height / llllllIIIIl[3] - llllllIIIIl[8] + llllllIIIIl[8] + llllllIIIIl[0], llllllIIIIl[13]);
    llllllllllllllllIIIlIIlIIIllIlIl.drawString(fontRendererObj, llllllIIIII[llllllIIIIl[3]], width / llllllIIIIl[1] - llllllIIIIl[12], height / llllllIIIIl[3] - llllllIIIIl[8] + llllllIIIIl[8] + llllllIIIIl[14], llllllIIIIl[13]);
    llllllllllllllllIIIlIIlIIIllIlIl.drawString(fontRendererObj, llllllIIIII[llllllIIIIl[15]], width / llllllIIIIl[1] - llllllIIIIl[12], height / llllllIIIIl[3] - llllllIIIIl[8] + llllllIIIIl[8] + llllllIIIIl[16], llllllIIIIl[13]);
    llllllllllllllllIIIlIIlIIIllIlIl.drawString(fontRendererObj, llllllIIIII[llllllIIIIl[17]], width / llllllIIIIl[1] - llllllIIIIl[12], height / llllllIIIIl[3] - llllllIIIIl[8] + llllllIIIIl[8] + llllllIIIIl[18], llllllIIIIl[13]);
    llllllllllllllllIIIlIIlIIIllIlIl.drawString(fontRendererObj, llllllIIIII[llllllIIIIl[19]], width / llllllIIIIl[1] - llllllIIIIl[12], height / llllllIIIIl[3] - llllllIIIIl[8] + llllllIIIIl[8] + llllllIIIIl[20], llllllIIIIl[13]);
    llllllllllllllllIIIlIIlIIIllIlIl.drawString(fontRendererObj, llllllIIIII[llllllIIIIl[21]], width / llllllIIIIl[1] - llllllIIIIl[12], height / llllllIIIIl[3] - llllllIIIIl[8] + llllllIIIIl[8] + llllllIIIIl[22], llllllIIIIl[13]);
    llllllllllllllllIIIlIIlIIIllIlIl.drawString(fontRendererObj, llllllIIIII[llllllIIIIl[23]], width / llllllIIIIl[1] - llllllIIIIl[12], height / llllllIIIIl[3] - llllllIIIIl[8] + llllllIIIIl[8] + llllllIIIIl[24], llllllIIIIl[13]);
    llllllllllllllllIIIlIIlIIIllIlIl.drawString(fontRendererObj, llllllIIIII[llllllIIIIl[25]], width / llllllIIIIl[1] - llllllIIIIl[12], height / llllllIIIIl[3] - llllllIIIIl[8] + llllllIIIIl[8] + llllllIIIIl[26], llllllIIIIl[13]);
    llllllllllllllllIIIlIIlIIIllIlIl.drawScreen(llllllllllllllllIIIlIIlIIIllIIII, llllllllllllllllIIIlIIlIIIlIllll, llllllllllllllllIIIlIIlIIIlIlllI);
  }
  
  private static boolean llIIIIIlllIII(int ???)
  {
    int llllllllllllllllIIIlIIIlllllIIlI;
    return ??? == 0;
  }
  
  private static boolean llIIIIIlllIIl(int ???, int arg1)
  {
    int i;
    double llllllllllllllllIIIlIIIllllllIII;
    return ??? == i;
  }
  
  private static String llIIIIIllIlII(String llllllllllllllllIIIlIIlIIIlIIlII, String llllllllllllllllIIIlIIlIIIlIIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIIlIIlIIIlIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIIlIIlIIIlIIlIl.getBytes(StandardCharsets.UTF_8)), llllllIIIIl[21]), "DES");
      Cipher llllllllllllllllIIIlIIlIIIlIlIII = Cipher.getInstance("DES");
      llllllllllllllllIIIlIIlIIIlIlIII.init(llllllIIIIl[1], llllllllllllllllIIIlIIlIIIlIlIIl);
      return new String(llllllllllllllllIIIlIIlIIIlIlIII.doFinal(Base64.getDecoder().decode(llllllllllllllllIIIlIIlIIIlIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIIlIIlIIIlIIlll)
    {
      llllllllllllllllIIIlIIlIIIlIIlll.printStackTrace();
    }
    return null;
  }
  
  public GuiMemoryErrorScreen() {}
  
  private static boolean llIIIIIlllIlI(int ???, int arg1)
  {
    int i;
    String llllllllllllllllIIIlIIIlllllIlII;
    return ??? < i;
  }
  
  protected void actionPerformed(GuiButton llllllllllllllllIIIlIIlIIIllllIl)
    throws IOException
  {
    ;
    ;
    if (llIIIIIlllIII(id))
    {
      mc.displayGuiScreen(new GuiMainMenu());
      "".length();
      if ((0x35 ^ 0x4E ^ 55 + 52 - 33 + 53) > 0) {}
    }
    else if (llIIIIIlllIIl(id, llllllIIIIl[6]))
    {
      mc.shutdown();
    }
  }
  
  private static String llIIIIIllIlIl(String llllllllllllllllIIIlIIIlllllllll, String llllllllllllllllIIIlIIIllllllllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIIlIIlIIIIIIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIIlIIIllllllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIIIlIIlIIIIIIIll = Cipher.getInstance("Blowfish");
      llllllllllllllllIIIlIIlIIIIIIIll.init(llllllIIIIl[1], llllllllllllllllIIIlIIlIIIIIIlII);
      return new String(llllllllllllllllIIIlIIlIIIIIIIll.doFinal(Base64.getDecoder().decode(llllllllllllllllIIIlIIIlllllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIIlIIlIIIIIIIlI)
    {
      llllllllllllllllIIIlIIlIIIIIIIlI.printStackTrace();
    }
    return null;
  }
}

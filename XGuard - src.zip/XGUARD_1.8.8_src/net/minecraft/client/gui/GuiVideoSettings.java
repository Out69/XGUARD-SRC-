package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.GameSettings.Options;
import optfine.GuiAnimationSettingsOF;
import optfine.GuiDetailSettingsOF;
import optfine.GuiOtherSettingsOF;
import optfine.GuiPerformanceSettingsOF;
import optfine.GuiQualitySettingsOF;

public class GuiVideoSettings
  extends GuiScreen
{
  private static boolean lIIIlIIIlIllII(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIIlllIIIIIIlllllI;
    return ??? > i;
  }
  
  private static int lIIIlIIIlIlIlI(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  public static int getButtonHeight(GuiButton lllllllllllllllIIlllIIIIlIIIlIlI)
  {
    ;
    return height;
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    screenTitle = I18n.format(lIlIllllllIl[lIllIIIIIlIl[3]], new Object[lIllIIIIIlIl[0]]);
    buttonList.clear();
    is64bit = lIllIIIIIlIl[0];
    String[] lllllllllllllllIIlllIIIlIIIIIlll = { lIlIllllllIl[lIllIIIIIlIl[4]], lIlIllllllIl[lIllIIIIIlIl[5]], lIlIllllllIl[lIllIIIIIlIl[6]] };
    byte lllllllllllllllIIlllIIIIllllIllI = (lllllllllllllllIIlllIIIIllllIlIl = lllllllllllllllIIlllIIIlIIIIIlll).length;
    int lllllllllllllllIIlllIIIIllllIlll = lIllIIIIIlIl[0];
    "".length();
    if (-" ".length() > (0x6B ^ 0x6F)) {
      return;
    }
    while (!lIIIlIIIlIIllI(lllllllllllllllIIlllIIIIllllIlll, lllllllllllllllIIlllIIIIllllIllI))
    {
      String lllllllllllllllIIlllIIIlIIIIIllI = lllllllllllllllIIlllIIIIllllIlIl[lllllllllllllllIIlllIIIIllllIlll];
      String lllllllllllllllIIlllIIIlIIIIIlIl = System.getProperty(lllllllllllllllIIlllIIIlIIIIIllI);
      if ((lIIIlIIIlIIlII(lllllllllllllllIIlllIIIlIIIIIlIl)) && (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIlIIIIIlIl.contains(lIlIllllllIl[lIllIIIIIlIl[7]]))))
      {
        is64bit = lIllIIIIIlIl[2];
        "".length();
        if (-" ".length() < "   ".length()) {
          break;
        }
        return;
      }
      lllllllllllllllIIlllIIIIllllIlll++;
    }
    int lllllllllllllllIIlllIIIlIIIIIlII = lIllIIIIIlIl[0];
    if (lIIIlIIIlIIlIl(is64bit))
    {
      "".length();
      if ((0xC5 ^ 0xC1) <= (0xAB ^ 0xAF)) {
        break label266;
      }
    }
    label266:
    boolean lllllllllllllllIIlllIIIlIIIIIIll = lIllIIIIIlIl[2];
    GameSettings.Options[] lllllllllllllllIIlllIIIlIIIIIIlI = videoOptions;
    int lllllllllllllllIIlllIIIlIIIIIIIl = lllllllllllllllIIlllIIIlIIIIIIlI.length;
    int lllllllllllllllIIlllIIIlIIIIIIII = lIllIIIIIlIl[0];
    lllllllllllllllIIlllIIIlIIIIIIII = lIllIIIIIlIl[0];
    "".length();
    if (-" ".length() >= " ".length()) {
      return;
    }
    while (!lIIIlIIIlIIllI(lllllllllllllllIIlllIIIlIIIIIIII, lllllllllllllllIIlllIIIlIIIIIIIl))
    {
      GameSettings.Options lllllllllllllllIIlllIIIIllllllll = lllllllllllllllIIlllIIIlIIIIIIlI[lllllllllllllllIIlllIIIlIIIIIIII];
      if (lIIIlIIIlIIlII(lllllllllllllllIIlllIIIIllllllll))
      {
        int lllllllllllllllIIlllIIIIlllllllI = width / lIllIIIIIlIl[3] - lIllIIIIIlIl[14] + lllllllllllllllIIlllIIIlIIIIIIII % lIllIIIIIlIl[3] * lIllIIIIIlIl[15];
        int lllllllllllllllIIlllIIIIllllllIl = height / lIllIIIIIlIl[7] + lIllIIIIIlIl[16] * (lllllllllllllllIIlllIIIlIIIIIIII / lIllIIIIIlIl[3]) - lIllIIIIIlIl[11];
        if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIllllllll.getEnumFloat()))
        {
          new GuiOptionSlider(lllllllllllllllIIlllIIIIllllllll.returnEnumOrdinal(), lllllllllllllllIIlllIIIIlllllllI, lllllllllllllllIIlllIIIIllllllIl, lllllllllllllllIIlllIIIIllllllll);
          "".length();
          "".length();
          if ((59 + '' - 122 + 100 ^ 29 + '' - 4 + 13) != 0) {}
        }
        else
        {
          new GuiOptionButton(lllllllllllllllIIlllIIIIllllllll.returnEnumOrdinal(), lllllllllllllllIIlllIIIIlllllllI, lllllllllllllllIIlllIIIIllllllIl, lllllllllllllllIIlllIIIIllllllll, guiGameSettings.getKeyBinding(lllllllllllllllIIlllIIIIllllllll));
          "".length();
        }
      }
      lllllllllllllllIIlllIIIlIIIIIIII++;
    }
    int lllllllllllllllIIlllIIIIllllllII = height / lIllIIIIIlIl[7] + lIllIIIIIlIl[16] * (lllllllllllllllIIlllIIIlIIIIIIII / lIllIIIIIlIl[3]) - lIllIIIIIlIl[11];
    int lllllllllllllllIIlllIIIIlllllIll = lIllIIIIIlIl[0];
    lllllllllllllllIIlllIIIIlllllIll = width / lIllIIIIIlIl[3] - lIllIIIIIlIl[14] + lIllIIIIIlIl[15];
    new GuiOptionButton(lIllIIIIIlIl[17], lllllllllllllllIIlllIIIIlllllIll, lllllllllllllllIIlllIIIIllllllII, lIlIllllllIl[lIllIIIIIlIl[8]]);
    "".length();
    lllllllllllllllIIlllIIIIllllllII += 21;
    lllllllllllllllIIlllIIIIlllllIll = width / lIllIIIIIlIl[3] - lIllIIIIIlIl[14] + lIllIIIIIlIl[0];
    new GuiOptionButton(lIllIIIIIlIl[18], lllllllllllllllIIlllIIIIlllllIll, lllllllllllllllIIlllIIIIllllllII, lIlIllllllIl[lIllIIIIIlIl[9]]);
    "".length();
    lllllllllllllllIIlllIIIIlllllIll = width / lIllIIIIIlIl[3] - lIllIIIIIlIl[14] + lIllIIIIIlIl[15];
    new GuiOptionButton(lIllIIIIIlIl[19], lllllllllllllllIIlllIIIIlllllIll, lllllllllllllllIIlllIIIIllllllII, lIlIllllllIl[lIllIIIIIlIl[10]]);
    "".length();
    lllllllllllllllIIlllIIIIllllllII += 21;
    lllllllllllllllIIlllIIIIlllllIll = width / lIllIIIIIlIl[3] - lIllIIIIIlIl[14] + lIllIIIIIlIl[0];
    new GuiOptionButton(lIllIIIIIlIl[20], lllllllllllllllIIlllIIIIlllllIll, lllllllllllllllIIlllIIIIllllllII, lIlIllllllIl[lIllIIIIIlIl[11]]);
    "".length();
    lllllllllllllllIIlllIIIIlllllIll = width / lIllIIIIIlIl[3] - lIllIIIIIlIl[14] + lIllIIIIIlIl[15];
    new GuiOptionButton(lIllIIIIIlIl[21], lllllllllllllllIIlllIIIIlllllIll, lllllllllllllllIIlllIIIIllllllII, lIlIllllllIl[lIllIIIIIlIl[12]]);
    "".length();
    new GuiButton(lIllIIIIIlIl[22], width / lIllIIIIIlIl[3] - lIllIIIIIlIl[23], height / lIllIIIIIlIl[7] + lIllIIIIIlIl[24] + lIllIIIIIlIl[12], I18n.format(lIlIllllllIl[lIllIIIIIlIl[13]], new Object[lIllIIIIIlIl[0]]));
    "".length();
  }
  
  private String[] getTooltipLines(String lllllllllllllllIIlllIIIIlIlIllIl)
  {
    ;
    if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllIl.equals(lIlIllllllIl[lIllIIIIIlIl[1]])))
    {
      "".length();
      if (-" ".length() >= 0) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[38]])))
    {
      "".length();
      if (" ".length() == -" ".length()) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[45]])))
    {
      "".length();
      if (null != null) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[50]])))
    {
      "".length();
      if ((0x1C ^ 0x58 ^ 0x51 ^ 0x11) < -" ".length()) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[55]])))
    {
      "".length();
      if (-" ".length() != -" ".length()) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[62]])))
    {
      "".length();
      if (null != null) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[65]])))
    {
      "".length();
      if ((0xDD ^ 0xA1 ^ 0x2E ^ 0x56) == "  ".length()) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[68]])))
    {
      "".length();
      if ("   ".length() <= (('¯' + '' - 252 + 151 ^ 68 + 109 - 100 + 68) & (0xAE ^ 0x9E ^ 0x2D ^ 0x55 ^ -" ".length()))) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[71]])))
    {
      "".length();
      if ((0x2F ^ 0x2B) == "   ".length()) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[78]])))
    {
      "".length();
      if (((0x97 ^ 0x9E ^ "   ".length()) & (127 + 12 - 17 + 19 ^ 63 + 124 - 153 + 101 ^ -" ".length())) != 0) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[85]])))
    {
      "".length();
      if (((0x25 ^ 0x4F ^ 0x48 ^ 0x7D) & (76 + '¶' - 108 + 93 ^ 101 + 36 - 68 + 103 ^ -" ".length())) > 0) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[90]])))
    {
      "".length();
      if (((0xBB ^ 0xB3) & (0x12 ^ 0x1A ^ 0xFFFFFFFF)) != 0) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[96]])))
    {
      "".length();
      if ((0x9B ^ 0x95 ^ 0x53 ^ 0x59) <= -" ".length()) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[104]])))
    {
      "".length();
      if (((0x48 ^ 0x51) & (0x56 ^ 0x4F ^ 0xFFFFFFFF)) != 0) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[108]])))
    {
      "".length();
      if ((0x6B ^ 0x6F) == 0) {
        return null;
      }
    }
    else if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIlIllII.equals(lIlIllllllIl[lIllIIIIIlIl[112]])))
    {
      "".length();
      if (-" ".length() <= "   ".length()) {
        break label2144;
      }
      return null;
    }
    label2144:
    return null;
  }
  
  private static boolean lIIIlIIIlIllIl(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIIlllIIIIIlIIIIlI;
    return ??? <= i;
  }
  
  private static boolean lIIIlIIIlIIlII(Object ???)
  {
    float lllllllllllllllIIlllIIIIIIllllII;
    return ??? != null;
  }
  
  private static boolean lIIIlIIIlIlIII(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIIlllIIIIIlIIlllI;
    return ??? == i;
  }
  
  private static boolean lIIIlIIIlIlllI(int ???)
  {
    short lllllllllllllllIIlllIIIIIIllIlII;
    return ??? >= 0;
  }
  
  private static boolean lIIIlIIIlIIllI(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIIlllIIIIIlIIlIlI;
    return ??? >= i;
  }
  
  private static boolean lIIIlIIIlIlIll(int ???)
  {
    long lllllllllllllllIIlllIIIIIIllIllI;
    return ??? == 0;
  }
  
  private static boolean lIIIlIIIlIlIIl(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIIlllIIIIIIlIlllI;
    return ??? != i;
  }
  
  static
  {
    lIIIlIIIlIIIll();
    lIIIlIIIIlllII();
  }
  
  private static boolean lIIIlIIIllIIlI(int ???)
  {
    byte lllllllllllllllIIlllIIIIIIllIIlI;
    return ??? < 0;
  }
  
  public static int getButtonWidth(GuiButton lllllllllllllllIIlllIIIIlIIIlllI)
  {
    ;
    return width;
  }
  
  private GuiButton getSelectedButton(int lllllllllllllllIIlllIIIIlIIlllIl, int lllllllllllllllIIlllIIIIlIIlIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIIlllIIIIlIIllIll = lIllIIIIIlIl[0];
    "".length();
    if (-" ".length() >= 0) {
      return null;
    }
    label182:
    while (!lIIIlIIIlIIllI(lllllllllllllllIIlllIIIIlIIllIll, buttonList.size()))
    {
      GuiButton lllllllllllllllIIlllIIIIlIIllIlI = (GuiButton)buttonList.get(lllllllllllllllIIlllIIIIlIIllIll);
      if ((lIIIlIIIlIIllI(lllllllllllllllIIlllIIIIlIIlIlll, xPosition)) && (lIIIlIIIlIIllI(lllllllllllllllIIlllIIIIlIIlIllI, yPosition)) && (lIIIlIIIlIIlll(lllllllllllllllIIlllIIIIlIIlIlll, xPosition + width)) && (lIIIlIIIlIIlll(lllllllllllllllIIlllIIIIlIIlIllI, yPosition + height)))
      {
        "".length();
        if (-" ".length() < ((66 + 54 - 5 + 33 ^ 123 + 79 - 142 + 80) & ('Ñ' + '' - 227 + 99 ^ 109 + 89 - 78 + 78 ^ -" ".length()))) {
          break label182;
        }
        return null;
      }
      boolean lllllllllllllllIIlllIIIIlIIllIIl = lIllIIIIIlIl[0];
      if (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlIIllIIl)) {
        return lllllllllllllllIIlllIIIIlIIllIlI;
      }
      lllllllllllllllIIlllIIIIlIIllIll++;
    }
    return null;
  }
  
  private static boolean lIIIlIIIlIIlll(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIIlllIIIIIlIIIllI;
    return ??? < i;
  }
  
  private static String lIIIlIIIIIlIll(String lllllllllllllllIIlllIIIIIllllIlI, String lllllllllllllllIIlllIIIIIllllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlllIIIIIlllllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlllIIIIIllllIll.getBytes(StandardCharsets.UTF_8)), lIllIIIIIlIl[9]), "DES");
      Cipher lllllllllllllllIIlllIIIIIllllllI = Cipher.getInstance("DES");
      lllllllllllllllIIlllIIIIIllllllI.init(lIllIIIIIlIl[3], lllllllllllllllIIlllIIIIIlllllll);
      return new String(lllllllllllllllIIlllIIIIIllllllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlllIIIIIllllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlllIIIIIlllllIl)
    {
      lllllllllllllllIIlllIIIIIlllllIl.printStackTrace();
    }
    return null;
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllIIlllIIIIlllIlIIl)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIlIIIlIIlIl(enabled))
    {
      int lllllllllllllllIIlllIIIIlllIlIII = guiGameSettings.guiScale;
      if ((lIIIlIIIlIIlll(id, lIllIIIIIlIl[22])) && (lIIIlIIIlIIlIl(lllllllllllllllIIlllIIIIlllIlIIl instanceof GuiOptionButton)))
      {
        guiGameSettings.setOptionValue(((GuiOptionButton)lllllllllllllllIIlllIIIIlllIlIIl).returnEnumOptions(), lIllIIIIIlIl[2]);
        displayString = guiGameSettings.getKeyBinding(GameSettings.Options.getEnumOptions(id));
      }
      if (lIIIlIIIlIlIII(id, lIllIIIIIlIl[22]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(parentGuiScreen);
      }
      if (lIIIlIIIlIlIIl(guiGameSettings.guiScale, lllllllllllllllIIlllIIIIlllIlIII))
      {
        ScaledResolution lllllllllllllllIIlllIIIIlllIIlll = new ScaledResolution(mc);
        int lllllllllllllllIIlllIIIIlllIIllI = ScaledResolution.getScaledWidth();
        int lllllllllllllllIIlllIIIIlllIIlIl = lllllllllllllllIIlllIIIIlllIIlll.getScaledHeight();
        lllllllllllllllIIlllIIIIllIlllll.setWorldAndResolution(mc, lllllllllllllllIIlllIIIIlllIIllI, lllllllllllllllIIlllIIIIlllIIlIl);
      }
      if (lIIIlIIIlIlIII(id, lIllIIIIIlIl[18]))
      {
        mc.gameSettings.saveOptions();
        GuiDetailSettingsOF lllllllllllllllIIlllIIIIlllIIlII = new GuiDetailSettingsOF(lllllllllllllllIIlllIIIIllIlllll, guiGameSettings);
        mc.displayGuiScreen(lllllllllllllllIIlllIIIIlllIIlII);
      }
      if (lIIIlIIIlIlIII(id, lIllIIIIIlIl[17]))
      {
        mc.gameSettings.saveOptions();
        GuiQualitySettingsOF lllllllllllllllIIlllIIIIlllIIIll = new GuiQualitySettingsOF(lllllllllllllllIIlllIIIIllIlllll, guiGameSettings);
        mc.displayGuiScreen(lllllllllllllllIIlllIIIIlllIIIll);
      }
      if (lIIIlIIIlIlIII(id, lIllIIIIIlIl[20]))
      {
        mc.gameSettings.saveOptions();
        GuiAnimationSettingsOF lllllllllllllllIIlllIIIIlllIIIlI = new GuiAnimationSettingsOF(lllllllllllllllIIlllIIIIllIlllll, guiGameSettings);
        mc.displayGuiScreen(lllllllllllllllIIlllIIIIlllIIIlI);
      }
      if (lIIIlIIIlIlIII(id, lIllIIIIIlIl[19]))
      {
        mc.gameSettings.saveOptions();
        GuiPerformanceSettingsOF lllllllllllllllIIlllIIIIlllIIIIl = new GuiPerformanceSettingsOF(lllllllllllllllIIlllIIIIllIlllll, guiGameSettings);
        mc.displayGuiScreen(lllllllllllllllIIlllIIIIlllIIIIl);
      }
      if (lIIIlIIIlIlIII(id, lIllIIIIIlIl[21]))
      {
        mc.gameSettings.saveOptions();
        GuiOtherSettingsOF lllllllllllllllIIlllIIIIlllIIIII = new GuiOtherSettingsOF(lllllllllllllllIIlllIIIIllIlllll, guiGameSettings);
        mc.displayGuiScreen(lllllllllllllllIIlllIIIIlllIIIII);
      }
      if (lIIIlIIIlIlIII(id, GameSettings.Options.AO_LEVEL.ordinal())) {}
    }
  }
  
  public void drawScreen(int lllllllllllllllIIlllIIIIlIllllII, int lllllllllllllllIIlllIIIIlIlllIll, float lllllllllllllllIIlllIIIIllIIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlllIIIIllIIlIll.drawDefaultBackground();
    if (lIIIlIIIlIIlIl(is64bit))
    {
      "".length();
      if ((0x9C ^ 0x98) >= " ".length()) {
        break label67;
      }
    }
    label67:
    fontRendererObj.drawCenteredString(screenTitle, width / lIllIIIIIlIl[3], lIllIIIIIlIl[25], lIllIIIIIlIl[6], lIllIIIIIlIl[26]);
    if ((lIIIlIIIlIlIll(is64bit)) && (lIIIlIIIlIllII(guiGameSettings.renderDistanceChunks, lIllIIIIIlIl[9]))) {}
    lllllllllllllllIIlllIIIIllIIlIll.drawScreen(lllllllllllllllIIlllIIIIlIllllII, lllllllllllllllIIlllIIIIlIlllIll, lllllllllllllllIIlllIIIIllIIlIII);
    if ((lIIIlIIIlIllIl(Math.abs(lllllllllllllllIIlllIIIIlIllllII - lastMouseX), lIllIIIIIlIl[6])) && (lIIIlIIIlIllIl(Math.abs(lllllllllllllllIIlllIIIIlIlllIll - lastMouseY), lIllIIIIIlIl[6])))
    {
      int lllllllllllllllIIlllIIIIllIIIlll = lIllIIIIIlIl[27];
      if (lIIIlIIIlIlllI(lIIIlIIIlIlIlI(System.currentTimeMillis(), mouseStillTime + lllllllllllllllIIlllIIIIllIIIlll)))
      {
        int lllllllllllllllIIlllIIIIllIIIllI = width / lIllIIIIIlIl[3] - lIllIIIIIlIl[28];
        int lllllllllllllllIIlllIIIIllIIIlIl = height / lIllIIIIIlIl[7] - lIllIIIIIlIl[6];
        if (lIIIlIIIlIllIl(lllllllllllllllIIlllIIIIlIlllIll, lllllllllllllllIIlllIIIIllIIIlIl + lIllIIIIIlIl[29])) {
          lllllllllllllllIIlllIIIIllIIIlIl += 105;
        }
        int lllllllllllllllIIlllIIIIllIIIlII = lllllllllllllllIIlllIIIIllIIIllI + lIllIIIIIlIl[28] + lIllIIIIIlIl[28];
        int lllllllllllllllIIlllIIIIllIIIIll = lllllllllllllllIIlllIIIIllIIIlIl + lIllIIIIIlIl[30] + lIllIIIIIlIl[11];
        GuiButton lllllllllllllllIIlllIIIIllIIIIlI = lllllllllllllllIIlllIIIIllIIlIll.getSelectedButton(lllllllllllllllIIlllIIIIlIllllII, lllllllllllllllIIlllIIIIlIlllIll);
        if (lIIIlIIIlIIlII(lllllllllllllllIIlllIIIIllIIIIlI))
        {
          String lllllllllllllllIIlllIIIIllIIIIIl = lllllllllllllllIIlllIIIIllIIlIll.getButtonName(displayString);
          String[] lllllllllllllllIIlllIIIIllIIIIII = lllllllllllllllIIlllIIIIllIIlIll.getTooltipLines(lllllllllllllllIIlllIIIIllIIIIIl);
          if (lIIIlIIIlIllll(lllllllllllllllIIlllIIIIllIIIIII)) {
            return;
          }
          lllllllllllllllIIlllIIIIllIIlIll.drawGradientRect(lllllllllllllllIIlllIIIIllIIIllI, lllllllllllllllIIlllIIIIllIIIlIl, lllllllllllllllIIlllIIIIllIIIlII, lllllllllllllllIIlllIIIIllIIIIll, lIllIIIIIlIl[31], lIllIIIIIlIl[31]);
          int lllllllllllllllIIlllIIIIlIllllll = lIllIIIIIlIl[0];
          "".length();
          if (-(0x4A ^ 0x4E) > 0) {
            return;
          }
          while (!lIIIlIIIlIIllI(lllllllllllllllIIlllIIIIlIllllll, lllllllllllllllIIlllIIIIllIIIIII.length))
          {
            String lllllllllllllllIIlllIIIIlIlllllI = lllllllllllllllIIlllIIIIllIIIIII[lllllllllllllllIIlllIIIIlIllllll];
            "".length();
          }
          "".length();
          if (((0x2D ^ 0x14 ^ 0x40 ^ 0x53) & (9 + 119 - 81 + 89 ^ 26 + '' - 91 + 72 ^ -" ".length())) <= 0) {}
        }
      }
    }
    else
    {
      lastMouseX = lllllllllllllllIIlllIIIIlIllllII;
      lastMouseY = lllllllllllllllIIlllIIIIlIlllIll;
      mouseStillTime = System.currentTimeMillis();
    }
  }
  
  private static void lIIIlIIIlIIIll()
  {
    lIllIIIIIlIl = new int[116];
    lIllIIIIIlIl[0] = ((0x1C ^ 0x49 ^ 0xA ^ 0x73) & (0x74 ^ 0x7D ^ 0x4F ^ 0x6A ^ -" ".length()));
    lIllIIIIIlIl[1] = (0x37 ^ 0x1 ^ 0x55 ^ 0x6E);
    lIllIIIIIlIl[2] = " ".length();
    lIllIIIIIlIl[3] = "  ".length();
    lIllIIIIIlIl[4] = "   ".length();
    lIllIIIIIlIl[5] = (0xEA ^ 0x8C ^ 0xDB ^ 0xB9);
    lIllIIIIIlIl[6] = (0xAC ^ 0xA9);
    lIllIIIIIlIl[7] = (0x33 ^ 0x36 ^ "   ".length());
    lIllIIIIIlIl[8] = (0x0 ^ 0x7);
    lIllIIIIIlIl[9] = (0xA8 ^ 0xA0);
    lIllIIIIIlIl[10] = (119 + 114 - 186 + 119 ^ 9 + 63 - -93 + 10);
    lIllIIIIIlIl[11] = (96 + 61 - 46 + 20 ^ '' + 22 - 19 + 2);
    lIllIIIIIlIl[12] = (0x7E ^ 0xC ^ 0x1 ^ 0x78);
    lIllIIIIIlIl[13] = (0x90 ^ 0x9C);
    lIllIIIIIlIl[14] = (24 + 126 - 44 + 49);
    lIllIIIIIlIl[15] = (103 + 19 - -18 + 20);
    lIllIIIIIlIl[16] = (0x5E ^ 0x4B);
    lIllIIIIIlIl[17] = (17 + 79 - 17 + 123);
    lIllIIIIIlIl[18] = (75 + 3 - -4 + 119);
    lIllIIIIIlIl[19] = (25 + '' - 38 + 80);
    lIllIIIIIlIl[20] = (107 + 79 - 145 + 170);
    lIllIIIIIlIl[21] = ('Ü' + 'Ë' - 221 + 20);
    lIllIIIIIlIl[22] = ((0x6C ^ 0x44) + (49 + 82 - 51 + 96) - (0x29 ^ 0x3F) + (0x79 ^ 0x7F));
    lIllIIIIIlIl[23] = (0x5E ^ 0x3A);
    lIllIIIIIlIl[24] = (81 + 83 - 92 + 96);
    lIllIIIIIlIl[25] = (20 + 59 - 10 + 67 ^ 4 + 112 - 14 + 54);
    lIllIIIIIlIl[26] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIllIIIIIlIl[27] = (0xD7BF & 0x2AFC);
    lIllIIIIIlIl[28] = ((0xF4 ^ 0x8D) + (0x8A ^ 0xAC) - (0x6F ^ 0x33) + (0x73 ^ 0x20));
    lIllIIIIIlIl[29] = (0xDB ^ 0xB9);
    lIllIIIIIlIl[30] = (0x2 ^ 0x56);
    lIllIIIIIlIl[31] = (-(0xAE5B & 0x200051A4));
    lIllIIIIIlIl[32] = (0xDDFD & 0xDDFFDF);
    lIllIIIIIlIl[33] = (0x82 ^ 0xAF ^ 0x0 ^ 0x23);
    lIllIIIIIlIl[34] = (0xB3 ^ 0xBC);
    lIllIIIIIlIl[35] = (59 + 58 - 82 + 95 ^ 92 + 65 - 62 + 51);
    lIllIIIIIlIl[36] = (0x7B ^ 0x6A);
    lIllIIIIIlIl[37] = (82 + 36 - -1 + 62 ^ '¤' + 86 - 222 + 139);
    lIllIIIIIlIl[38] = (0x7D ^ 0x2A ^ 0xC7 ^ 0x83);
    lIllIIIIIlIl[39] = (0x29 ^ 0x3F);
    lIllIIIIIlIl[40] = (85 + 71 - 54 + 41 ^ 19 + 16 - -8 + 109);
    lIllIIIIIlIl[41] = (0x60 ^ 0x78);
    lIllIIIIIlIl[42] = (70 + 58 - 49 + 75 ^ 118 + 41 - 87 + 59);
    lIllIIIIIlIl[43] = (0x26 ^ 0x3C);
    lIllIIIIIlIl[44] = (0x36 ^ 0x2D);
    lIllIIIIIlIl[45] = (0xB7 ^ 0xAB);
    lIllIIIIIlIl[46] = (0x34 ^ 0x21 ^ 0x2F ^ 0x27);
    lIllIIIIIlIl[47] = (0xC3 ^ 0x99 ^ 0xFA ^ 0xBE);
    lIllIIIIIlIl[48] = (0xB9 ^ 0xA6);
    lIllIIIIIlIl[49] = (0x4A ^ 0x6A);
    lIllIIIIIlIl[50] = (0xC8 ^ 0xB3 ^ 0xC3 ^ 0x99);
    lIllIIIIIlIl[51] = (0x7D ^ 0x5F);
    lIllIIIIIlIl[52] = (111 + 85 - 102 + 91 ^ 45 + 91 - 67 + 85);
    lIllIIIIIlIl[53] = (0x35 ^ 0x11);
    lIllIIIIIlIl[54] = (0x6A ^ 0x4F);
    lIllIIIIIlIl[55] = (0x2 ^ 0x24);
    lIllIIIIIlIl[56] = (0x8B ^ 0x80 ^ 0x22 ^ 0xE);
    lIllIIIIIlIl[57] = (0x7B ^ 0x53);
    lIllIIIIIlIl[58] = (0xB7 ^ 0x97 ^ 0x37 ^ 0x3E);
    lIllIIIIIlIl[59] = (0x68 ^ 0x42);
    lIllIIIIIlIl[60] = (0xF ^ 0x24);
    lIllIIIIIlIl[61] = (99 + 47 - -30 + 58 ^ 125 + '½' - 119 + 3);
    lIllIIIIIlIl[62] = (0x31 ^ 0x4F ^ 0x28 ^ 0x7B);
    lIllIIIIIlIl[63] = (0x9F ^ 0xB1);
    lIllIIIIIlIl[64] = (0x95 ^ 0xAD ^ 0xB7 ^ 0xA0);
    lIllIIIIIlIl[65] = (0x61 ^ 0x51);
    lIllIIIIIlIl[66] = (0x4F ^ 0x7E);
    lIllIIIIIlIl[67] = (0x9E ^ 0xAC);
    lIllIIIIIlIl[68] = (0x4B ^ 0x42 ^ 0x10 ^ 0x2A);
    lIllIIIIIlIl[69] = (0x4C ^ 0x2F ^ 0xD0 ^ 0x87);
    lIllIIIIIlIl[70] = (0x93 ^ 0xA6);
    lIllIIIIIlIl[71] = (81 + 70 - 112 + 108 ^ 101 + 55 - 19 + 28);
    lIllIIIIIlIl[72] = (0xDA ^ 0x87 ^ 0xC2 ^ 0xA8);
    lIllIIIIIlIl[73] = (66 + 66 - 49 + 86 ^ 68 + 82 - 23 + 18);
    lIllIIIIIlIl[74] = (0xFC ^ 0xC5);
    lIllIIIIIlIl[75] = (0xF7 ^ 0x82 ^ 0x7 ^ 0x48);
    lIllIIIIIlIl[76] = (0x8D ^ 0xB6);
    lIllIIIIIlIl[77] = (0x39 ^ 0x5);
    lIllIIIIIlIl[78] = (0x30 ^ 0x2B ^ 0xE5 ^ 0xC3);
    lIllIIIIIlIl[79] = ('' + 39 - 107 + 104 ^ 48 + 43 - -38 + 20);
    lIllIIIIIlIl[80] = (0xFC ^ 0xC3);
    lIllIIIIIlIl[81] = ('Ô' + 94 - 209 + 119 ^ 50 + 117 - 31 + 16);
    lIllIIIIIlIl[82] = (0xE9 ^ 0xA8);
    lIllIIIIIlIl[83] = ('²' + 75 - 76 + 63 ^ 52 + 117 - 56 + 65);
    lIllIIIIIlIl[84] = (0x29 ^ 0x6A);
    lIllIIIIIlIl[85] = (0xC8 ^ 0x8C);
    lIllIIIIIlIl[86] = (0xD8 ^ 0x9D);
    lIllIIIIIlIl[87] = (0x72 ^ 0x34);
    lIllIIIIIlIl[88] = ('½' + '' - 178 + 83 ^ '³' + '´' - 184 + 15);
    lIllIIIIIlIl[89] = (0xDF ^ 0x97);
    lIllIIIIIlIl[90] = (0x46 ^ 0x38 ^ 0xA6 ^ 0x91);
    lIllIIIIIlIl[91] = (0x43 ^ 0x9);
    lIllIIIIIlIl[92] = (60 + 96 - -83 + 12 ^ 16 + 27 - -25 + 108);
    lIllIIIIIlIl[93] = (52 + 42 - 72 + 172 ^ '' + 65 - 106 + 49);
    lIllIIIIIlIl[94] = (0x8B ^ 0xB4 ^ 0x6B ^ 0x19);
    lIllIIIIIlIl[95] = ('¹' + '' - 189 + 96 ^ 33 + 34 - 49 + 129);
    lIllIIIIIlIl[96] = (0x45 ^ 0xA);
    lIllIIIIIlIl[97] = (0x75 ^ 0x25);
    lIllIIIIIlIl[98] = (0x12 ^ 0x46 ^ 0x8D ^ 0x88);
    lIllIIIIIlIl[99] = (0xC8 ^ 0x9A);
    lIllIIIIIlIl[100] = (0xD6 ^ 0x85);
    lIllIIIIIlIl[101] = (0xF3 ^ 0xA6);
    lIllIIIIIlIl[102] = (0x2E ^ 0x6B ^ 0x9D ^ 0x8E);
    lIllIIIIIlIl[103] = (0x7B ^ 0x3E ^ 0x3C ^ 0x2E);
    lIllIIIIIlIl[104] = (0xBE ^ 0xA2 ^ 0x84 ^ 0xC0);
    lIllIIIIIlIl[105] = (0x60 ^ 0x39);
    lIllIIIIIlIl[106] = (0x78 ^ 0xE ^ 0x99 ^ 0xB5);
    lIllIIIIIlIl[107] = ('¬' + '¬' - 331 + 206 ^ 124 + 90 - 187 + 101);
    lIllIIIIIlIl[108] = (0xDC ^ 0xC7 ^ 0x75 ^ 0x32);
    lIllIIIIIlIl[109] = (0xC3 ^ 0x9E);
    lIllIIIIIlIl[110] = (0x30 ^ 0x64 ^ 0x77 ^ 0x7D);
    lIllIIIIIlIl[111] = (0x30 ^ 0x6F);
    lIllIIIIIlIl[112] = (0x37 ^ 0x57);
    lIllIIIIIlIl[113] = ("   ".length() ^ 0xA1 ^ 0xC3);
    lIllIIIIIlIl[114] = (0x3D ^ 0x5E);
    lIllIIIIIlIl[115] = (0x80 ^ 0xC7 ^ 0xB7 ^ 0x95);
  }
  
  private static String lIIIlIIIIIlIlI(String lllllllllllllllIIlllIIIIIlIlIlIl, String lllllllllllllllIIlllIIIIIlIlIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlllIIIIIlIllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlllIIIIIlIlIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIlllIIIIIlIllIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIIlllIIIIIlIllIIl.init(lIllIIIIIlIl[3], lllllllllllllllIIlllIIIIIlIllIlI);
      return new String(lllllllllllllllIIlllIIIIIlIllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlllIIIIIlIlIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlllIIIIIlIllIII)
    {
      lllllllllllllllIIlllIIIIIlIllIII.printStackTrace();
    }
    return null;
  }
  
  private static void lIIIlIIIIlllII()
  {
    lIlIllllllIl = new String[lIllIIIIIlIl[115]];
    lIlIllllllIl[lIllIIIIIlIl[0]] = lIIIlIIIIIlIlI("nB+qA2xOuzUnBMhrgzrfNw==", "LFcsR");
    lIlIllllllIl[lIllIIIIIlIl[2]] = lIIIlIIIIIlIll("OvA1ah+UiQCm+qxshKZ67g==", "VGkRA");
    lIlIllllllIl[lIllIIIIIlIl[3]] = lIIIlIIIIIlIll("+Zb+kie9s0KxZwLqrVA0O2bndxeH7zio", "grdHF");
    lIlIllllllIl[lIllIIIIIlIl[4]] = lIIIlIIIIIlIll("rvIZFjUieLo78d9N/lXltG2cpJbZtusC", "ykWLi");
    lIlIllllllIl[lIllIIIIIlIl[5]] = lIIIlIIIIIllII("BigMaDoHKk8wPkslCDI+CiME", "eGaFS");
    lIlIllllllIl[lIllIIIIIlIl[6]] = lIIIlIIIIIllII("JhFFFwsqCg==", "Ibkvy");
    lIlIllllllIl[lIllIIIIIlIl[7]] = lIIIlIIIIIlIlI("GIFwkfLjDKM=", "MUUpp");
    lIlIllllllIl[lIllIIIIIlIl[8]] = lIIIlIIIIIlIll("6fSLca64JmDAEO+sWiAZlg==", "nnxmj");
    lIlIllllllIl[lIllIIIIIlIl[9]] = lIIIlIIIIIlIlI("0E4BqOx2/RgqSwwvVgczng==", "FIGlA");
    lIlIllllllIl[lIllIIIIIlIl[10]] = lIIIlIIIIIlIlI("GDuBaA7PJniOS73JLGClSg==", "VkYCp");
    lIlIllllllIl[lIllIIIIIlIl[11]] = lIIIlIIIIIlIll("914DYcUUnXKLteBxlBKF7A==", "yVWqV");
    lIlIllllllIl[lIllIIIIIlIl[12]] = lIIIlIIIIIlIlI("RIk6yOR3oP3M/gK3ASDr3g==", "mxofL");
    lIlIllllllIl[lIllIIIIIlIl[13]] = lIIIlIIIIIlIlI("mxqXF2Jhwvow49DLO0nYkg==", "DZIBj");
    lIlIllllllIl[lIllIIIIIlIl[1]] = lIIIlIIIIIllII("FRQyFDo7BSA=", "RfSdR");
    lIlIllllllIl[lIllIIIIIlIl[33]] = lIIIlIIIIIlIlI("XfrzRmh3EpteTwA4doRC5A==", "EbzJE");
    lIlIllllllIl[lIllIIIIIlIl[34]] = lIIIlIIIIIlIlI("5GqzTXFgFA0ljuh/iMDiJ349tewknnDBIaDlmZkgVFE=", "JlWtX");
    lIlIllllllIl[lIllIIIIIlIl[35]] = lIIIlIIIIIlIll("XUtUMaDyFB0G5XolpN55MG6KpALIyqrt1P5QxRQ18srKesLELsbKlA==", "jHBJb");
    lIlIllllllIl[lIllIIIIIlIl[36]] = lIIIlIIIIIlIll("q6/Y+K5L/1EVe80r1tDB+rqgcFjcg4XOp7Nkz8iHgAfi/GIFJ8kOSskyXrfuWxMJgv070eyE/xU=", "YaygA");
    lIlIllllllIl[lIllIIIIIlIl[37]] = lIIIlIIIIIllII("EBs3CzgUAHYOOQdTMR02EAB2HD4HFiVB", "csVoW");
    lIlIllllllIl[lIllIIIIIlIl[38]] = lIIIlIIIIIlIll("zjaVeehbxnrCarlItyFzQw==", "gHpSZ");
    lIlIllllllIl[lIllIIIIIlIl[25]] = lIIIlIIIIIlIlI("iOKZ/VinDsEn0tFKMZtA++hkQqjv5trw", "nPFnc");
    lIlIllllllIl[lIllIIIIIlIl[16]] = lIIIlIIIIIllII("eUdeazcwCRVrTnlUXiZDcQENOBc8FBhi", "YglKc");
    lIlIllllllIl[lIllIIIIIlIl[39]] = lIIIlIIIIIllII("TnlxeBcGNjcsZEN5c2wpTnEjOTcaPDdx", "nYEXD");
    lIlIllllllIl[lIllIIIIIlIl[40]] = lIIIlIIIIIllII("ZGhvVDQrOjoVFmRld0VIfCU=", "DHWtz");
    lIlIllllllIl[lIllIIIIIlIl[41]] = lIIIlIIIIIllII("R0J3e3MhAzRtfkdQc3s+R0o1ITwQBzRk", "gbFMS");
    lIlIllllllIl[lIllIIIIIlIl[42]] = lIIIlIIIIIlIll("hOrUo5Nr8DQMtydIcmTOjM2yk8DwSO/bGd/AKJnkBCI=", "LIPam");
    lIlIllllllIl[lIllIIIIIlIl[43]] = lIIIlIIIIIlIlI("Bf+da98fkG0wkmLNJ1eu6RTsHIIU/tRTToT8Wp2BM+tSSOWOKH71xf3MAzJaKp0advkIz63OBCs=", "wceNP");
    lIlIllllllIl[lIllIIIIIlIl[44]] = lIIIlIIIIIlIll("8xnP2Tc//oAepLq/FEqclC/yHNK/cn34hMGE76ihe/oTOabA4iH85mJnpBDBIztLPaMBiC11F1g=", "FYWKk");
    lIlIllllllIl[lIllIIIIIlIl[45]] = lIIIlIIIIIlIlI("ikYk3mDCDkqshr4Ug9af8Q==", "jTEqg");
    lIlIllllllIl[lIllIIIIIlIl[46]] = lIIIlIIIIIllII("PQc4JBAGSjsiAwYePiUD", "njWKd");
    lIlIllllllIl[lIllIIIIIlIl[47]] = lIIIlIIIIIllII("cFEVLSRwXHoFDXACNwQNJBl6Bws3GS4CDDdRcg0DIwU/GUs=", "PqZkb");
    lIlIllllllIl[lIllIIIIIlIl[48]] = lIIIlIIIIIllII("T3AXLSAGPS8pbkJwKS0jHzw/ZD0CPzUwJk88MyMmGzk0I25HIzYrOQoicw==", "oPZDN");
    lIlIllllllIl[lIllIIIIIlIl[49]] = lIIIlIIIIIlIlI("ZxQfMpGA4EzWEY19+7/hXXYzmCH6oyN9zvcfS1Ay3z7b7cxcAvMWPSRyzVW7juj8", "NijFp");
    lIlIllllllIl[lIllIIIIIlIl[50]] = lIIIlIIIIIllII("Eh8tPgApUg44EykGKz8TYT4nJxEt", "ArBQt");
    lIlIllllllIl[lIllIIIIIlIl[51]] = lIIIlIIIIIlIll("LQ7ON5PPrU7H69lCAfojjLMYrbPqA2ns", "vEawH");
    lIlIllllllIl[lIllIIIIIlIl[52]] = lIIIlIIIIIllII("QUY5LAlBS1YEIEEVHgsrDhEF", "afvjO");
    lIlIllllllIl[lIllIIIIIlIl[53]] = lIIIlIIIIIlIll("OFjsnS5JjSKsDKOENXe/GNK/ZwtfC30e", "IpyiD");
    lIlIllllllIl[lIllIIIIIlIl[54]] = lIIIlIIIIIllII("U01hfWVWTX1tMRIfO20mGww0IiIA", "smPMU");
    lIlIllllllIl[lIllIIIIIlIl[55]] = lIIIlIIIIIllII("OCk7dS0HKS4wGRQ8Jg==", "uHCUk");
    lIlIllllllIl[lIllIIIIIlIl[56]] = lIIIlIIIIIlIlI("eTPuat+uTLoTq8SgCNOpbg==", "fhMqI");
    lIlIllllllIl[lIllIIIIIlIl[57]] = lIIIlIIIIIlIll("Rpmv8nnuEGDrUyeqRPu1KVRcJinwQW8X4MyuznRh43ueUhUiWWEm9JVMMr4neJLus9KeK4ZkfzA=", "BhHHx");
    lIlIllllllIl[lIllIIIIIlIl[58]] = lIIIlIIIIIlIll("Eq5kqBBGr5+gJ+goRYk0d03tOYC9ea2m", "VvOdG");
    lIlIllllllIl[lIllIIIIIlIl[59]] = lIIIlIIIIIlIlI("4QTi/HJc/2sX1XZoVyTy+i8G3XLLe1j8zIaELqga8JK6vyH+G8vHrw==", "JhOxK");
    lIlIllllllIl[lIllIIIIIlIl[60]] = lIIIlIIIIIlIlI("UWYx/hmniQRfayeY26F5bcbY2RlmvfPITToBg5XBw6kcShruW6brmCKOBB0pypCw", "nNIGB");
    lIlIllllllIl[lIllIIIIIlIl[61]] = lIIIlIIIIIlIlI("mcP1XPIa9SWz4QvP+LJ266MhkADZW6NdwykrvTV0bak=", "BHXFo");
    lIlIllllllIl[lIllIIIIIlIl[62]] = lIIIlIIIIIlIlI("tPsaZ92S7gdv/c1OkfRvAg==", "KBEls");
    lIlIllllllIl[lIllIIIIIlIl[63]] = lIIIlIIIIIlIlI("7rn9hSInD7TuSVfQm+tgx+D0BKNpM+LTxW8q4yAX238=", "cMspr");
    lIlIllllllIl[lIllIIIIIlIl[64]] = lIIIlIIIIIlIlI("JGDGiTlHAs+5oN1JskYMVs+rm8foVAb+wgvjZmU7A7cKWzesys98X8VNKpVPXyrK5j8K1nEcuyI=", "Mcoby");
    lIlIllllllIl[lIllIIIIIlIl[65]] = lIIIlIIIIIllII("DzwEbB8rCCEp", "HiMLL");
    lIlIllllllIl[lIllIIIIIlIl[66]] = lIIIlIIIIIlIlI("XZmXP+xTVlGeBs4PU9rkSg==", "XvNfN");
    lIlIllllllIl[lIllIIIIIlIl[67]] = lIIIlIIIIIlIll("f1R6xEmhJpUE9GB51qfImUW5KscxHEtCkXN2YzLhODg=", "MvOLZ");
    lIlIllllllIl[lIllIIIIIlIl[68]] = lIIIlIIIIIlIll("lXoG90RX+/sOVKhDiKUwhQ==", "XaDHA");
    lIlIllllllIl[lIllIIIIIlIl[69]] = lIIIlIIIIIlIlI("GEjwqW6nl154e7G6hRqvWw==", "Cqkvm");
    lIlIllllllIl[lIllIIIIIlIl[70]] = lIIIlIIIIIlIlI("pWtrcheY+GVznsC9gttzI7ajrt7nD3anykMWiOjZ4W6N7fhyvYIiEYWFGXJm9GPN", "urucn");
    lIlIllllllIl[lIllIIIIIlIl[71]] = lIIIlIIIIIllII("FzQzOQQ1NSF4JSY1Kx8m", "VPEXj");
    lIlIllllllIl[lIllIIIIIlIl[72]] = lIIIlIIIIIlIlI("3rrKC/hlUfqtq4ssM9fy6TWavEMWT/oRG264jbv26OQjo8r9CZ2qMQ==", "ySpkP");
    lIlIllllllIl[lIllIIIIIlIl[73]] = lIIIlIIIIIlIll("yjtXy0oVjN/adQkaHvPqut2gSFsEmPat8RVu0WpjoeaWOTfOz+306qY8PPNymqxj", "iJZhR");
    lIlIllllllIl[lIllIIIIIlIl[74]] = lIIIlIIIIIlIll("Y/Flf74GQqmpzcG4Xcr9TmhCXS311T4lmFCTrdmXo+ZNPb7LTBkfQtyRueUt1ZrR8xUsvmPPPEA=", "QAiDE");
    lIlIllllllIl[lIllIIIIIlIl[75]] = lIIIlIIIIIlIll("+4k1bCf1ptxjUTl0i5DxI+I1ZnMgK4qp/NJFbbDK9Gtt9h/mKGaoPEG2GCnlkLFakIKh+/WboZbsdChacZzkhg==", "GLfVM");
    lIlIllllllIl[lIllIIIIIlIl[76]] = lIIIlIIIIIlIlI("/0coIcNzLmx4kaHqAwgZO49ovjnNu1kuev7KoJeQ9I01+1oBOlBN9tsbwN4lT+vGRDhI1w9YF0c=", "ATmKB");
    lIlIllllllIl[lIllIIIIIlIl[77]] = lIIIlIIIIIllII("LSs1CQEjOnQaCDg9eg==", "JYTyi");
    lIlIllllllIl[lIllIIIIIlIl[78]] = lIIIlIIIIIlIll("wbhOr9X0D+Q=", "UEqeJ");
    lIlIllllllIl[lIllIIIIIlIl[79]] = lIIIlIIIIIlIll("pCQPmyZrV1bPcMMwggDDHw==", "wwKBN");
    lIlIllllllIl[lIllIIIIIlIl[80]] = lIIIlIIIIIlIlI("d3arAJLZgcziqb/u2qWDR9TStF8DSrqd", "TBQKD");
    lIlIllllllIl[lIllIIIIIlIl[81]] = lIIIlIIIIIlIll("e6mdRSI2L8l/fV2usZQSCU+yKhLePhQ0iuZtkA4S5FAlRDPwNHi4Vg==", "aUZFT");
    lIlIllllllIl[lIllIIIIIlIl[82]] = lIIIlIIIIIllII("Zk8hNAFmQk4cKGYJARVrZgkPATMjHBo=", "FonrG");
    lIlIllllllIl[lIllIIIIIlIl[83]] = lIIIlIIIIIllII("PgkSbwkLDxQ2TwwOEG8GGUEWOQ4DDRYtAw9BGCEDE0EeKU8DFVcmHEoSAj8fBRMDKgtKAw5vGwIEVw==", "jawOo");
    lIlIllllllIl[lIllIIIIIlIl[84]] = lIIIlIIIIIlIll("Es9Nh0CMAP8qQPTCbfyjGA==", "NLoPD");
    lIlIllllllIl[lIllIIIIIlIl[85]] = lIIIlIIIIIlIlI("1xk4qVubUyXD6wov0FznOA==", "ZsdqS");
    lIlIllllllIl[lIllIIIIIlIl[86]] = lIIIlIIIIIllII("BAc/RwM2CSoT", "BhXgp");
    lIlIllllllIl[lIllIIIIIlIl[87]] = lIIIlIIIIIlIlI("y/bB7Iw6wxffj42mFVcs6G76m2aDskQPwN6wowM+sG9W3qyc1rgbvw==", "GOzel");
    lIlIllllllIl[lIllIIIIIlIl[88]] = lIIIlIIIIIlIlI("NEY12GUj8YVLy7z6NQOH20JWptbWc7NvmIRbUPG/sjDzfqk3IkOP40BQJ0rsEWws", "FwQGR");
    lIlIllllllIl[lIllIIIIIlIl[89]] = lIIIlIIIIIllII("Hj0FAmklJRgYJiR1GQI8KzkACGkuOgkCaSQ6GFEoLDMJEj1qIQQUaTowHhcmODgNHyovew==", "JUlqI");
    lIlIllllllIl[lIllIIIIIlIl[90]] = lIIIlIIIIIllII("LzsREB4ZJx0EBQ==", "mIxwv");
    lIlIllllllIl[lIllIIIIIlIl[91]] = lIIIlIIIIIllII("CAktADIgFCsBdzUPK1I1Mw4pGiMvAj0Bdy4BbhY2MwwrAHcuBSQXNDUU", "AgNrW");
    lIlIllllllIl[lIllIIIIIlIl[92]] = lIIIlIIIIIlIll("qzcsK4BCpbDVPDH3SGXT0acLUCucjdIhHPjhL3RUdZ0=", "Jymfs");
    lIlIllllllIl[lIllIIIIIlIl[93]] = lIIIlIIIIIlIll("Fikoa5Y4dXSbO8jIcuXR4srAvFK4WiS63l6HRgMc5CpYCnyu7BIUPCRPMRL+Lwd7", "CHPuY");
    lIlIllllllIl[lIllIIIIIlIl[94]] = lIIIlIIIIIlIll("EY/wTHktp/AAxicYOfjfG8XS9HP2Rn9F+7lf6vZH7dZG6LIL56SgMyUDX22zZPXO", "IEohB");
    lIlIllllllIl[lIllIIIIIlIl[95]] = lIIIlIIIIIllII("BDYEJjxCIQQrJgljBygvByAcOQ==", "bChJE");
    lIlIllllllIl[lIllIIIIIlIl[96]] = lIIIlIIIIIllII("FSYEJj52Ah4pMT8gFg==", "VNqHU");
    lIlIllllllIl[lIllIIIIIlIl[97]] = lIIIlIIIIIlIlI("KWmapRCCB32EwCy/064u/g==", "UCamL");
    lIlIllllllIl[lIllIIIIIlIl[98]] = lIIIlIIIIIllII("Y040DxwiGxweWm5OBQQJNw8SBh9jKCA5WjQGFQRaLwERDhMtCVAJEjYAGxk=", "Cnpjz");
    lIlIllllllIl[lIllIIIIIlIl[99]] = lIIIlIIIIIlIlI("ZTPnAAApnIG6PYjj/7o7pijSL5fb8RCK", "kWfZi");
    lIlIllllllIl[lIllIIIIIlIl[100]] = lIIIlIIIIIllII("Zmk+NhUyIF4AFjQsU25ZNT0SIRUjaTUTKmppQDtZICgANxw0aQQsCyotUy8WJy0aLR4=", "FIsCy");
    lIlIllllllIl[lIllIIIIIlIl[30]] = lIIIlIIIIIlIlI("Ynv9g91BsnCaq/rkFbXBbPIBMWfCjzkRyt+K7nlCSRt871YSdjBEq41md3Q+C09FhiOzhXSUk7A=", "WDxur");
    lIlIllllllIl[lIllIIIIIlIl[101]] = lIIIlIIIIIlIlI("FG8Vy1bSMew3aEofAT2SFd/yvrhc5VUpN6Qsij34RQn4q4osOgaMhQ==", "rksbE");
    lIlIllllllIl[lIllIIIIIlIl[102]] = lIIIlIIIIIlIlI("eOJrKKs42hdG7Wn10LFnpnodk3/1W8PWzg1iPgK1LMkVV5xilU7Xzd06zSyy9Xu8tyuth5gYmsI=", "qLXoy");
    lIlIllllllIl[lIllIIIIIlIl[103]] = lIIIlIIIIIlIll("QzwVpI2PFG2NNSECknbOleOtcSlWgvHuTZvpwE+Wrj5Tzof5xYsPGbM26xBVq9rI", "JzEUe");
    lIlIllllllIl[lIllIIIIIlIl[104]] = lIIIlIIIIIllII("GCokByI3JyQHcBsqPwE7Kg==", "YFPbP");
    lIlIllllllIl[lIllIIIIIlIl[105]] = lIIIlIIIIIlIlI("SYSiMRpeeats1BmVEiwqR5t1jhyAUX6o", "wZGMl");
    lIlIllllllIl[lIllIIIIIlIl[106]] = lIIIlIIIIIlIlI("jBwHe12WmKBLaIFXkO8wON8pWaUPnl5jI/3R4jt7ScoaBEYxZuTmrxnZebGxeJYH", "EKObi");
    lIlIllllllIl[lIllIIIIIlIl[107]] = lIIIlIIIIIlIll("PjOz9TUdSmhkgfrQdoppzQBjAB27l7fPoQxlf8ww3EiF7vXGJvPlLA==", "xwIAm");
    lIlIllllllIl[lIllIIIIIlIl[108]] = lIIIlIIIIIlIll("DEqYZXYeXbjauDLssbw7Ww==", "aVzfy");
    lIlIllllllIl[lIllIIIIIlIl[109]] = lIIIlIIIIIlIll("2+qguVY0OJ8fpKYqKtB22Y03d0FWzHmd", "Rskuf");
    lIlIllllllIl[lIllIIIIIlIl[110]] = lIIIlIIIIIlIlI("UmDvI346hJMyaLenpmONZSqfcnT7terMnOlO7vG6Kw6HHyu3B7z0BkE2B/mt4lMaPf5Lw+/omN4=", "GcGKp");
    lIlIllllllIl[lIllIIIIIlIl[111]] = lIIIlIIIIIlIlI("NmNA/Imt+M7N2aMi9UmjdFPlkNfGPDPYp3EtCfUroclfAWDhW238aFPGsm2SGZzs", "YqwSN");
    lIlIllllllIl[lIllIIIIIlIl[112]] = lIIIlIIIIIlIlI("0YHpvftWysYg5ZxYB8QCiw==", "Crydb");
    lIlIllllllIl[lIllIIIIIlIl[113]] = lIIIlIIIIIllII("SxJoDAEZMSQ0HxA=", "xVHMo");
    lIlIllllllIl[lIllIIIIIlIl[29]] = lIIIlIIIIIlIlI("GZuaw5gfqvqVj1xDCYWGRz2SppShoXTibvt/0xyUVucfpMDjtnDYraV6/uK/dTXwvniDOvxetqg=", "RoRdc");
    lIlIllllllIl[lIllIIIIIlIl[114]] = lIIIlIIIIIllII("EyowThcUJipOFwwgbA==", "uEBnr");
    lIlIllllllIl[lIllIIIIIlIl[23]] = lIIIlIIIIIlIll("DAi89J7Ap3Yckjg0abhgAUNB56sK3Ma1gXxmzPu6h89zdtvaZqmwA4hWbUMQVK9t", "xVffw");
  }
  
  private static String lIIIlIIIIIllII(String lllllllllllllllIIlllIIIIIllIllII, String lllllllllllllllIIlllIIIIIllIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlllIIIIIllIllII = new String(Base64.getDecoder().decode(lllllllllllllllIIlllIIIIIllIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlllIIIIIllIlIlI = new StringBuilder();
    char[] lllllllllllllllIIlllIIIIIllIlIIl = lllllllllllllllIIlllIIIIIllIlIll.toCharArray();
    int lllllllllllllllIIlllIIIIIllIlIII = lIllIIIIIlIl[0];
    Exception lllllllllllllllIIlllIIIIIllIIIlI = lllllllllllllllIIlllIIIIIllIllII.toCharArray();
    Exception lllllllllllllllIIlllIIIIIllIIIIl = lllllllllllllllIIlllIIIIIllIIIlI.length;
    char lllllllllllllllIIlllIIIIIllIIIII = lIllIIIIIlIl[0];
    while (lIIIlIIIlIIlll(lllllllllllllllIIlllIIIIIllIIIII, lllllllllllllllIIlllIIIIIllIIIIl))
    {
      char lllllllllllllllIIlllIIIIIllIllIl = lllllllllllllllIIlllIIIIIllIIIlI[lllllllllllllllIIlllIIIIIllIIIII];
      "".length();
      "".length();
      if (((0xFE ^ 0xBC) & (0x7D ^ 0x3F ^ 0xFFFFFFFF)) != 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlllIIIIIllIlIlI);
  }
  
  private String getButtonName(String lllllllllllllllIIlllIIIIlIlIIllI)
  {
    ;
    ;
    int lllllllllllllllIIlllIIIIlIlIIlll = lllllllllllllllIIlllIIIIlIlIIllI.indexOf(lIllIIIIIlIl[75]);
    if (lIIIlIIIllIIlI(lllllllllllllllIIlllIIIIlIlIIlll))
    {
      "".length();
      if ((0x6D ^ 0x69) > "  ".length()) {
        break label50;
      }
      return null;
    }
    label50:
    return lllllllllllllllIIlllIIIIlIlIlIII.substring(lIllIIIIIlIl[0], lllllllllllllllIIlllIIIIlIlIIlll);
  }
  
  private static boolean lIIIlIIIlIIlIl(int ???)
  {
    boolean lllllllllllllllIIlllIIIIIIlllIII;
    return ??? != 0;
  }
  
  public GuiVideoSettings(GuiScreen lllllllllllllllIIlllIIIlIIIlIlll, GameSettings lllllllllllllllIIlllIIIlIIIlIIll)
  {
    parentGuiScreen = lllllllllllllllIIlllIIIlIIIlIlII;
    guiGameSettings = lllllllllllllllIIlllIIIlIIIlIIll;
  }
  
  private static boolean lIIIlIIIlIllll(Object ???)
  {
    Exception lllllllllllllllIIlllIIIIIIlllIlI;
    return ??? == null;
  }
}

package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;

public class Gui
{
  protected void drawVerticalLine(int llllllllllllllllIlllllIIlIllIlll, int llllllllllllllllIlllllIIlIllIllI, int llllllllllllllllIlllllIIlIllIlIl, int llllllllllllllllIlllllIIlIllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIIlIIlIllll(llllllllllllllllIlllllIIlIllIlIl, llllllllllllllllIlllllIIlIllIllI))
    {
      int llllllllllllllllIlllllIIlIllIIll = llllllllllllllllIlllllIIlIllIllI;
      llllllllllllllllIlllllIIlIllIllI = llllllllllllllllIlllllIIlIllIlIl;
      llllllllllllllllIlllllIIlIllIlIl = llllllllllllllllIlllllIIlIllIIll;
    }
    drawRect(llllllllllllllllIlllllIIlIllIlll, llllllllllllllllIlllllIIlIllIllI + lIllIIllIll[1], llllllllllllllllIlllllIIlIllIlll + lIllIIllIll[1], llllllllllllllllIlllllIIlIllIlIl, llllllllllllllllIlllllIIlIllIlII);
  }
  
  public Gui() {}
  
  public static void drawScaledCustomSizeModalRect(int llllllllllllllllIllllIlllIIlllIl, int llllllllllllllllIllllIlllIlIlIlI, float llllllllllllllllIllllIlllIlIlIIl, float llllllllllllllllIllllIlllIlIlIII, int llllllllllllllllIllllIlllIlIIlll, int llllllllllllllllIllllIlllIlIIllI, int llllllllllllllllIllllIlllIIlIlll, int llllllllllllllllIllllIlllIlIIlII, float llllllllllllllllIllllIlllIIlIlIl, float llllllllllllllllIllllIlllIlIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllllIllllIlllIlIIIIl = 1.0F / llllllllllllllllIllllIlllIIlIlIl;
    float llllllllllllllllIllllIlllIlIIIII = 1.0F / llllllllllllllllIllllIlllIlIIIlI;
    Tessellator llllllllllllllllIllllIlllIIlllll = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIllllIlllIIllllI = llllllllllllllllIllllIlllIIlllll.getWorldRenderer();
    llllllllllllllllIllllIlllIIllllI.begin(lIllIIllIll[9], DefaultVertexFormats.POSITION_TEX);
    llllllllllllllllIllllIlllIIllllI.pos(llllllllllllllllIllllIlllIIlllIl, llllllllllllllllIllllIlllIlIlIlI + llllllllllllllllIllllIlllIlIIlII, 0.0D).tex(llllllllllllllllIllllIlllIlIlIIl * llllllllllllllllIllllIlllIlIIIIl, (llllllllllllllllIllllIlllIlIlIII + llllllllllllllllIllllIlllIlIIllI) * llllllllllllllllIllllIlllIlIIIII).endVertex();
    llllllllllllllllIllllIlllIIllllI.pos(llllllllllllllllIllllIlllIIlllIl + llllllllllllllllIllllIlllIIlIlll, llllllllllllllllIllllIlllIlIlIlI + llllllllllllllllIllllIlllIlIIlII, 0.0D).tex((llllllllllllllllIllllIlllIlIlIIl + llllllllllllllllIllllIlllIlIIlll) * llllllllllllllllIllllIlllIlIIIIl, (llllllllllllllllIllllIlllIlIlIII + llllllllllllllllIllllIlllIlIIllI) * llllllllllllllllIllllIlllIlIIIII).endVertex();
    llllllllllllllllIllllIlllIIllllI.pos(llllllllllllllllIllllIlllIIlllIl + llllllllllllllllIllllIlllIIlIlll, llllllllllllllllIllllIlllIlIlIlI, 0.0D).tex((llllllllllllllllIllllIlllIlIlIIl + llllllllllllllllIllllIlllIlIIlll) * llllllllllllllllIllllIlllIlIIIIl, llllllllllllllllIllllIlllIlIlIII * llllllllllllllllIllllIlllIlIIIII).endVertex();
    llllllllllllllllIllllIlllIIllllI.pos(llllllllllllllllIllllIlllIIlllIl, llllllllllllllllIllllIlllIlIlIlI, 0.0D).tex(llllllllllllllllIllllIlllIlIlIIl * llllllllllllllllIllllIlllIlIIIIl, llllllllllllllllIllllIlllIlIlIII * llllllllllllllllIllllIlllIlIIIII).endVertex();
    llllllllllllllllIllllIlllIIlllll.draw();
  }
  
  public static void drawRect(int llllllllllllllllIlllllIIlIlIIIlI, int llllllllllllllllIlllllIIlIlIIIIl, int llllllllllllllllIlllllIIlIIlIIll, int llllllllllllllllIlllllIIlIIlIIlI, int llllllllllllllllIlllllIIlIIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIlIIlIllll(llllllllllllllllIlllllIIlIlIIIlI, llllllllllllllllIlllllIIlIlIIIII))
    {
      int llllllllllllllllIlllllIIlIIlllIl = llllllllllllllllIlllllIIlIlIIIlI;
      llllllllllllllllIlllllIIlIlIIIlI = llllllllllllllllIlllllIIlIlIIIII;
      llllllllllllllllIlllllIIlIlIIIII = llllllllllllllllIlllllIIlIIlllIl;
    }
    if (lIIIlIIlIllll(llllllllllllllllIlllllIIlIlIIIIl, llllllllllllllllIlllllIIlIIlIIlI))
    {
      int llllllllllllllllIlllllIIlIIlllII = llllllllllllllllIlllllIIlIlIIIIl;
      llllllllllllllllIlllllIIlIlIIIIl = llllllllllllllllIlllllIIlIIlIIlI;
      llllllllllllllllIlllllIIlIIlIIlI = llllllllllllllllIlllllIIlIIlllII;
    }
    float llllllllllllllllIlllllIIlIIllIll = (llllllllllllllllIlllllIIlIIlIIIl >> lIllIIllIll[3] & lIllIIllIll[4]) / 255.0F;
    float llllllllllllllllIlllllIIlIIllIlI = (llllllllllllllllIlllllIIlIIlIIIl >> lIllIIllIll[5] & lIllIIllIll[4]) / 255.0F;
    float llllllllllllllllIlllllIIlIIllIIl = (llllllllllllllllIlllllIIlIIlIIIl >> lIllIIllIll[6] & lIllIIllIll[4]) / 255.0F;
    float llllllllllllllllIlllllIIlIIllIII = (llllllllllllllllIlllllIIlIIlIIIl & lIllIIllIll[4]) / 255.0F;
    Tessellator llllllllllllllllIlllllIIlIIlIlll = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIlllllIIlIIlIllI = llllllllllllllllIlllllIIlIIlIlll.getWorldRenderer();
    GlStateManager.enableBlend();
    GlStateManager.disableTexture2D();
    GlStateManager.tryBlendFuncSeparate(lIllIIllIll[7], lIllIIllIll[8], lIllIIllIll[1], lIllIIllIll[0]);
    GlStateManager.color(llllllllllllllllIlllllIIlIIllIlI, llllllllllllllllIlllllIIlIIllIIl, llllllllllllllllIlllllIIlIIllIII, llllllllllllllllIlllllIIlIIllIll);
    llllllllllllllllIlllllIIlIIlIllI.begin(lIllIIllIll[9], DefaultVertexFormats.POSITION);
    llllllllllllllllIlllllIIlIIlIllI.pos(llllllllllllllllIlllllIIlIlIIIlI, llllllllllllllllIlllllIIlIIlIIlI, 0.0D).endVertex();
    llllllllllllllllIlllllIIlIIlIllI.pos(llllllllllllllllIlllllIIlIlIIIII, llllllllllllllllIlllllIIlIIlIIlI, 0.0D).endVertex();
    llllllllllllllllIlllllIIlIIlIllI.pos(llllllllllllllllIlllllIIlIlIIIII, llllllllllllllllIlllllIIlIlIIIIl, 0.0D).endVertex();
    llllllllllllllllIlllllIIlIIlIllI.pos(llllllllllllllllIlllllIIlIlIIIlI, llllllllllllllllIlllllIIlIlIIIIl, 0.0D).endVertex();
    llllllllllllllllIlllllIIlIIlIlll.draw();
    GlStateManager.enableTexture2D();
    GlStateManager.disableBlend();
  }
  
  public void drawTexturedModalRect(int llllllllllllllllIllllIlllllIllII, int llllllllllllllllIllllIlllllIIIll, TextureAtlasSprite llllllllllllllllIllllIlllllIIIlI, int llllllllllllllllIllllIlllllIlIIl, int llllllllllllllllIllllIlllllIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Tessellator llllllllllllllllIllllIlllllIIlll = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIllllIlllllIIllI = llllllllllllllllIllllIlllllIIlll.getWorldRenderer();
    llllllllllllllllIllllIlllllIIllI.begin(lIllIIllIll[9], DefaultVertexFormats.POSITION_TEX);
    llllllllllllllllIllllIlllllIIllI.pos(llllllllllllllllIllllIlllllIllII + lIllIIllIll[0], llllllllllllllllIllllIlllllIIIll + llllllllllllllllIllllIlllllIlIII, zLevel).tex(llllllllllllllllIllllIlllllIIIlI.getMinU(), llllllllllllllllIllllIlllllIIIlI.getMaxV()).endVertex();
    llllllllllllllllIllllIlllllIIllI.pos(llllllllllllllllIllllIlllllIllII + llllllllllllllllIllllIlllllIlIIl, llllllllllllllllIllllIlllllIIIll + llllllllllllllllIllllIlllllIlIII, zLevel).tex(llllllllllllllllIllllIlllllIIIlI.getMaxU(), llllllllllllllllIllllIlllllIIIlI.getMaxV()).endVertex();
    llllllllllllllllIllllIlllllIIllI.pos(llllllllllllllllIllllIlllllIllII + llllllllllllllllIllllIlllllIlIIl, llllllllllllllllIllllIlllllIIIll + lIllIIllIll[0], zLevel).tex(llllllllllllllllIllllIlllllIIIlI.getMaxU(), llllllllllllllllIllllIlllllIIIlI.getMinV()).endVertex();
    llllllllllllllllIllllIlllllIIllI.pos(llllllllllllllllIllllIlllllIllII + lIllIIllIll[0], llllllllllllllllIllllIlllllIIIll + lIllIIllIll[0], zLevel).tex(llllllllllllllllIllllIlllllIIIlI.getMinU(), llllllllllllllllIllllIlllllIIIlI.getMinV()).endVertex();
    llllllllllllllllIllllIlllllIIlll.draw();
  }
  
  public void drawString(FontRenderer llllllllllllllllIlllllIIIIllllII, String llllllllllllllllIlllllIIIIlllIll, int llllllllllllllllIlllllIIIIlllIlI, int llllllllllllllllIlllllIIIIlllllI, int llllllllllllllllIlllllIIIIllllIl)
  {
    ;
    ;
    ;
    ;
    ;
    "".length();
  }
  
  private static String lIIIlIIlIIIlI(String llllllllllllllllIllllIllIlIlllII, String llllllllllllllllIllllIllIlIlllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIllllIllIllIIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllllIllIlIlllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIllllIllIllIIIII = Cipher.getInstance("Blowfish");
      llllllllllllllllIllllIllIllIIIII.init(lIllIIllIll[2], llllllllllllllllIllllIllIllIIIIl);
      return new String(llllllllllllllllIllllIllIllIIIII.doFinal(Base64.getDecoder().decode(llllllllllllllllIllllIllIlIlllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIllllIllIlIlllll)
    {
      llllllllllllllllIllllIllIlIlllll.printStackTrace();
    }
    return null;
  }
  
  private static String lIIIlIIlIIlII(String llllllllllllllllIllllIllIlllIIll, String llllllllllllllllIllllIllIlllIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIllllIllIlllIIll = new String(Base64.getDecoder().decode(llllllllllllllllIllllIllIlllIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIllllIllIlllIIIl = new StringBuilder();
    char[] llllllllllllllllIllllIllIlllIIII = llllllllllllllllIllllIllIlllIIlI.toCharArray();
    int llllllllllllllllIllllIllIllIllll = lIllIIllIll[0];
    Exception llllllllllllllllIllllIllIllIlIIl = llllllllllllllllIllllIllIlllIIll.toCharArray();
    boolean llllllllllllllllIllllIllIllIlIII = llllllllllllllllIllllIllIllIlIIl.length;
    short llllllllllllllllIllllIllIllIIlll = lIllIIllIll[0];
    while (lIIIlIIlIllll(llllllllllllllllIllllIllIllIIlll, llllllllllllllllIllllIllIllIlIII))
    {
      char llllllllllllllllIllllIllIlllIlII = llllllllllllllllIllllIllIllIlIIl[llllllllllllllllIllllIllIllIIlll];
      "".length();
      "".length();
      if ("  ".length() == " ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIllllIllIlllIIIl);
  }
  
  public void drawTexturedModalRect(int llllllllllllllllIlllllIIIIlIlIll, int llllllllllllllllIlllllIIIIlIlIlI, int llllllllllllllllIlllllIIIIIllllI, int llllllllllllllllIlllllIIIIIlllIl, int llllllllllllllllIlllllIIIIIlllII, int llllllllllllllllIlllllIIIIlIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllllIlllllIIIIlIIlIl = 0.00390625F;
    float llllllllllllllllIlllllIIIIlIIlII = 0.00390625F;
    Tessellator llllllllllllllllIlllllIIIIlIIIll = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIlllllIIIIlIIIlI = llllllllllllllllIlllllIIIIlIIIll.getWorldRenderer();
    llllllllllllllllIlllllIIIIlIIIlI.begin(lIllIIllIll[9], DefaultVertexFormats.POSITION_TEX);
    llllllllllllllllIlllllIIIIlIIIlI.pos(llllllllllllllllIlllllIIIIlIlIll + lIllIIllIll[0], llllllllllllllllIlllllIIIIlIlIlI + llllllllllllllllIlllllIIIIlIIllI, zLevel).tex((llllllllllllllllIlllllIIIIlIlIIl + lIllIIllIll[0]) * llllllllllllllllIlllllIIIIlIIlIl, (llllllllllllllllIlllllIIIIIlllIl + llllllllllllllllIlllllIIIIlIIllI) * llllllllllllllllIlllllIIIIlIIlII).endVertex();
    llllllllllllllllIlllllIIIIlIIIlI.pos(llllllllllllllllIlllllIIIIlIlIll + llllllllllllllllIlllllIIIIIlllII, llllllllllllllllIlllllIIIIlIlIlI + llllllllllllllllIlllllIIIIlIIllI, zLevel).tex((llllllllllllllllIlllllIIIIlIlIIl + llllllllllllllllIlllllIIIIIlllII) * llllllllllllllllIlllllIIIIlIIlIl, (llllllllllllllllIlllllIIIIIlllIl + llllllllllllllllIlllllIIIIlIIllI) * llllllllllllllllIlllllIIIIlIIlII).endVertex();
    llllllllllllllllIlllllIIIIlIIIlI.pos(llllllllllllllllIlllllIIIIlIlIll + llllllllllllllllIlllllIIIIIlllII, llllllllllllllllIlllllIIIIlIlIlI + lIllIIllIll[0], zLevel).tex((llllllllllllllllIlllllIIIIlIlIIl + llllllllllllllllIlllllIIIIIlllII) * llllllllllllllllIlllllIIIIlIIlIl, (llllllllllllllllIlllllIIIIIlllIl + lIllIIllIll[0]) * llllllllllllllllIlllllIIIIlIIlII).endVertex();
    llllllllllllllllIlllllIIIIlIIIlI.pos(llllllllllllllllIlllllIIIIlIlIll + lIllIIllIll[0], llllllllllllllllIlllllIIIIlIlIlI + lIllIIllIll[0], zLevel).tex((llllllllllllllllIlllllIIIIlIlIIl + lIllIIllIll[0]) * llllllllllllllllIlllllIIIIlIIlIl, (llllllllllllllllIlllllIIIIIlllIl + lIllIIllIll[0]) * llllllllllllllllIlllllIIIIlIIlII).endVertex();
    llllllllllllllllIlllllIIIIlIIIll.draw();
  }
  
  private static void lIIIlIIlIIlIl()
  {
    lIllIIlIllI = new String[lIllIIllIll[12]];
    lIllIIlIllI[lIllIIllIll[0]] = lIIIlIIlIIIlI("IbwkwpVmHeBtdnI6PcZxHD1QT81x50ivEe7Vur1Fo0G+1ix0GvbRwg==", "FvEaj");
    lIllIIlIllI[lIllIIllIll[1]] = lIIIlIIlIIlII("OSkCJxo/KQl8CDglVTAAIzgbOgEoPlUgGyw4CQwGLiMUIEE9Ih0=", "MLzSo");
    lIllIIlIllI[lIllIIllIll[2]] = lIIIlIIlIIIlI("rqFT4WJbsLW8aV0/Oy8qIoFOAHAA5nAL", "rRFTi");
  }
  
  protected void drawHorizontalLine(int llllllllllllllllIlllllIIllIIIlll, int llllllllllllllllIlllllIIllIIIllI, int llllllllllllllllIlllllIIllIIIIII, int llllllllllllllllIlllllIIlIllllll)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIIlIIlIllll(llllllllllllllllIlllllIIllIIIllI, llllllllllllllllIlllllIIllIIIlll))
    {
      int llllllllllllllllIlllllIIllIIIIll = llllllllllllllllIlllllIIllIIIlll;
      llllllllllllllllIlllllIIllIIIlll = llllllllllllllllIlllllIIllIIIllI;
      llllllllllllllllIlllllIIllIIIllI = llllllllllllllllIlllllIIllIIIIll;
    }
    drawRect(llllllllllllllllIlllllIIllIIIlll, llllllllllllllllIlllllIIllIIIIII, llllllllllllllllIlllllIIllIIIllI + lIllIIllIll[1], llllllllllllllllIlllllIIllIIIIII + lIllIIllIll[1], llllllllllllllllIlllllIIlIllllll);
  }
  
  static
  {
    lIIIlIIlIlllI();
    lIIIlIIlIIlIl();
    optionsBackground = new ResourceLocation(lIllIIlIllI[lIllIIllIll[0]]);
    statIcons = new ResourceLocation(lIllIIlIllI[lIllIIllIll[1]]);
  }
  
  private static boolean lIIIlIIlIllll(int ???, int arg1)
  {
    int i;
    String llllllllllllllllIllllIllIlIlIlIl;
    return ??? < i;
  }
  
  protected void drawGradientRect(int llllllllllllllllIlllllIIIllllIII, int llllllllllllllllIlllllIIIlllIlll, int llllllllllllllllIlllllIIIllIIlIl, int llllllllllllllllIlllllIIIllIIlII, int llllllllllllllllIlllllIIIlllIlII, int llllllllllllllllIlllllIIIllIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllllIlllllIIIlllIIlI = (llllllllllllllllIlllllIIIlllIlII >> lIllIIllIll[3] & lIllIIllIll[4]) / 255.0F;
    float llllllllllllllllIlllllIIIlllIIIl = (llllllllllllllllIlllllIIIlllIlII >> lIllIIllIll[5] & lIllIIllIll[4]) / 255.0F;
    float llllllllllllllllIlllllIIIlllIIII = (llllllllllllllllIlllllIIIlllIlII >> lIllIIllIll[6] & lIllIIllIll[4]) / 255.0F;
    float llllllllllllllllIlllllIIIllIllll = (llllllllllllllllIlllllIIIlllIlII & lIllIIllIll[4]) / 255.0F;
    float llllllllllllllllIlllllIIIllIlllI = (llllllllllllllllIlllllIIIllIIIlI >> lIllIIllIll[3] & lIllIIllIll[4]) / 255.0F;
    float llllllllllllllllIlllllIIIllIllIl = (llllllllllllllllIlllllIIIllIIIlI >> lIllIIllIll[5] & lIllIIllIll[4]) / 255.0F;
    float llllllllllllllllIlllllIIIllIllII = (llllllllllllllllIlllllIIIllIIIlI >> lIllIIllIll[6] & lIllIIllIll[4]) / 255.0F;
    float llllllllllllllllIlllllIIIllIlIll = (llllllllllllllllIlllllIIIllIIIlI & lIllIIllIll[4]) / 255.0F;
    GlStateManager.disableTexture2D();
    GlStateManager.enableBlend();
    GlStateManager.disableAlpha();
    GlStateManager.tryBlendFuncSeparate(lIllIIllIll[7], lIllIIllIll[8], lIllIIllIll[1], lIllIIllIll[0]);
    GlStateManager.shadeModel(lIllIIllIll[10]);
    Tessellator llllllllllllllllIlllllIIIllIlIlI = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIlllllIIIllIlIIl = llllllllllllllllIlllllIIIllIlIlI.getWorldRenderer();
    llllllllllllllllIlllllIIIllIlIIl.begin(lIllIIllIll[9], DefaultVertexFormats.POSITION_COLOR);
    llllllllllllllllIlllllIIIllIlIIl.pos(llllllllllllllllIlllllIIIlllIllI, llllllllllllllllIlllllIIIlllIlll, zLevel).color(llllllllllllllllIlllllIIIlllIIIl, llllllllllllllllIlllllIIIlllIIII, llllllllllllllllIlllllIIIllIllll, llllllllllllllllIlllllIIIlllIIlI).endVertex();
    llllllllllllllllIlllllIIIllIlIIl.pos(llllllllllllllllIlllllIIIllllIII, llllllllllllllllIlllllIIIlllIlll, zLevel).color(llllllllllllllllIlllllIIIlllIIIl, llllllllllllllllIlllllIIIlllIIII, llllllllllllllllIlllllIIIllIllll, llllllllllllllllIlllllIIIlllIIlI).endVertex();
    llllllllllllllllIlllllIIIllIlIIl.pos(llllllllllllllllIlllllIIIllllIII, llllllllllllllllIlllllIIIllIIlII, zLevel).color(llllllllllllllllIlllllIIIllIllIl, llllllllllllllllIlllllIIIllIllII, llllllllllllllllIlllllIIIllIlIll, llllllllllllllllIlllllIIIllIlllI).endVertex();
    llllllllllllllllIlllllIIIllIlIIl.pos(llllllllllllllllIlllllIIIlllIllI, llllllllllllllllIlllllIIIllIIlII, zLevel).color(llllllllllllllllIlllllIIIllIllIl, llllllllllllllllIlllllIIIllIllII, llllllllllllllllIlllllIIIllIlIll, llllllllllllllllIlllllIIIllIlllI).endVertex();
    llllllllllllllllIlllllIIIllIlIlI.draw();
    GlStateManager.shadeModel(lIllIIllIll[11]);
    GlStateManager.disableBlend();
    GlStateManager.enableAlpha();
    GlStateManager.enableTexture2D();
  }
  
  public void drawTexturedModalRect(float llllllllllllllllIlllllIIIIIIlIlI, float llllllllllllllllIllllIlllllllllI, int llllllllllllllllIlllllIIIIIIlIII, int llllllllllllllllIlllllIIIIIIIlll, int llllllllllllllllIllllIlllllllIll, int llllllllllllllllIlllllIIIIIIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllllIlllllIIIIIIIlII = 0.00390625F;
    float llllllllllllllllIlllllIIIIIIIIll = 0.00390625F;
    Tessellator llllllllllllllllIlllllIIIIIIIIlI = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIlllllIIIIIIIIIl = llllllllllllllllIlllllIIIIIIIIlI.getWorldRenderer();
    llllllllllllllllIlllllIIIIIIIIIl.begin(lIllIIllIll[9], DefaultVertexFormats.POSITION_TEX);
    llllllllllllllllIlllllIIIIIIIIIl.pos(llllllllllllllllIlllllIIIIIIlIlI + 0.0F, llllllllllllllllIllllIlllllllllI + llllllllllllllllIlllllIIIIIIIlIl, zLevel).tex((llllllllllllllllIllllIllllllllIl + lIllIIllIll[0]) * llllllllllllllllIlllllIIIIIIIlII, (llllllllllllllllIlllllIIIIIIIlll + llllllllllllllllIlllllIIIIIIIlIl) * llllllllllllllllIlllllIIIIIIIIll).endVertex();
    llllllllllllllllIlllllIIIIIIIIIl.pos(llllllllllllllllIlllllIIIIIIlIlI + llllllllllllllllIllllIlllllllIll, llllllllllllllllIllllIlllllllllI + llllllllllllllllIlllllIIIIIIIlIl, zLevel).tex((llllllllllllllllIllllIllllllllIl + llllllllllllllllIllllIlllllllIll) * llllllllllllllllIlllllIIIIIIIlII, (llllllllllllllllIlllllIIIIIIIlll + llllllllllllllllIlllllIIIIIIIlIl) * llllllllllllllllIlllllIIIIIIIIll).endVertex();
    llllllllllllllllIlllllIIIIIIIIIl.pos(llllllllllllllllIlllllIIIIIIlIlI + llllllllllllllllIllllIlllllllIll, llllllllllllllllIllllIlllllllllI + 0.0F, zLevel).tex((llllllllllllllllIllllIllllllllIl + llllllllllllllllIllllIlllllllIll) * llllllllllllllllIlllllIIIIIIIlII, (llllllllllllllllIlllllIIIIIIIlll + lIllIIllIll[0]) * llllllllllllllllIlllllIIIIIIIIll).endVertex();
    llllllllllllllllIlllllIIIIIIIIIl.pos(llllllllllllllllIlllllIIIIIIlIlI + 0.0F, llllllllllllllllIllllIlllllllllI + 0.0F, zLevel).tex((llllllllllllllllIllllIllllllllIl + lIllIIllIll[0]) * llllllllllllllllIlllllIIIIIIIlII, (llllllllllllllllIlllllIIIIIIIlll + lIllIIllIll[0]) * llllllllllllllllIlllllIIIIIIIIll).endVertex();
    llllllllllllllllIlllllIIIIIIIIlI.draw();
  }
  
  public static void outlineRect(int llllllllllllllllIllllIlllIIIIIll, int llllllllllllllllIllllIlllIIIIIlI, int llllllllllllllllIllllIlllIIIIlll, int llllllllllllllllIllllIlllIIIIIII, int llllllllllllllllIllllIllIlllllll, int llllllllllllllllIllllIlllIIIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    drawRect(llllllllllllllllIllllIlllIIIIIll - llllllllllllllllIllllIlllIIIIlII, llllllllllllllllIllllIlllIIIIIlI, llllllllllllllllIllllIlllIIIIIll, llllllllllllllllIllllIlllIIIIIII, llllllllllllllllIllllIllIlllllll);
    drawRect(llllllllllllllllIllllIlllIIIIlll, llllllllllllllllIllllIlllIIIIIlI, llllllllllllllllIllllIlllIIIIlll + llllllllllllllllIllllIlllIIIIlII, llllllllllllllllIllllIlllIIIIIII, llllllllllllllllIllllIllIlllllll);
    drawRect(llllllllllllllllIllllIlllIIIIIll - llllllllllllllllIllllIlllIIIIlII, llllllllllllllllIllllIlllIIIIIlI - llllllllllllllllIllllIlllIIIIlII, llllllllllllllllIllllIlllIIIIlll + llllllllllllllllIllllIlllIIIIlII, llllllllllllllllIllllIlllIIIIIlI, llllllllllllllllIllllIllIlllllll);
    drawRect(llllllllllllllllIllllIlllIIIIIll - llllllllllllllllIllllIlllIIIIlII, llllllllllllllllIllllIlllIIIIIII, llllllllllllllllIllllIlllIIIIlll + llllllllllllllllIllllIlllIIIIlII, llllllllllllllllIllllIlllIIIIIII + llllllllllllllllIllllIlllIIIIlII, llllllllllllllllIllllIllIlllllll);
  }
  
  public void drawCenteredString(FontRenderer llllllllllllllllIlllllIIIlIlIIIl, String llllllllllllllllIlllllIIIlIlIIII, int llllllllllllllllIlllllIIIlIIlIlI, int llllllllllllllllIlllllIIIlIIlllI, int llllllllllllllllIlllllIIIlIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    "".length();
  }
  
  public static void drawModalRectWithCustomSizedTexture(int llllllllllllllllIllllIllllIlIIIl, int llllllllllllllllIllllIllllIIIlII, float llllllllllllllllIllllIllllIIIIll, float llllllllllllllllIllllIllllIIIIlI, int llllllllllllllllIllllIllllIIIIIl, int llllllllllllllllIllllIllllIIIIII, float llllllllllllllllIllllIllllIIlIll, float llllllllllllllllIllllIllllIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllllIllllIllllIIlIIl = 1.0F / llllllllllllllllIllllIllllIIlIll;
    float llllllllllllllllIllllIllllIIlIII = 1.0F / llllllllllllllllIllllIllllIIlIlI;
    Tessellator llllllllllllllllIllllIllllIIIlll = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIllllIllllIIIllI = llllllllllllllllIllllIllllIIIlll.getWorldRenderer();
    llllllllllllllllIllllIllllIIIllI.begin(lIllIIllIll[9], DefaultVertexFormats.POSITION_TEX);
    llllllllllllllllIllllIllllIIIllI.pos(llllllllllllllllIllllIllllIlIIIl, llllllllllllllllIllllIllllIIIlII + llllllllllllllllIllllIllllIIIIII, 0.0D).tex(llllllllllllllllIllllIllllIIIIll * llllllllllllllllIllllIllllIIlIIl, (llllllllllllllllIllllIllllIIIIlI + llllllllllllllllIllllIllllIIIIII) * llllllllllllllllIllllIllllIIlIII).endVertex();
    llllllllllllllllIllllIllllIIIllI.pos(llllllllllllllllIllllIllllIlIIIl + llllllllllllllllIllllIllllIIIIIl, llllllllllllllllIllllIllllIIIlII + llllllllllllllllIllllIllllIIIIII, 0.0D).tex((llllllllllllllllIllllIllllIIIIll + llllllllllllllllIllllIllllIIIIIl) * llllllllllllllllIllllIllllIIlIIl, (llllllllllllllllIllllIllllIIIIlI + llllllllllllllllIllllIllllIIIIII) * llllllllllllllllIllllIllllIIlIII).endVertex();
    llllllllllllllllIllllIllllIIIllI.pos(llllllllllllllllIllllIllllIlIIIl + llllllllllllllllIllllIllllIIIIIl, llllllllllllllllIllllIllllIIIlII, 0.0D).tex((llllllllllllllllIllllIllllIIIIll + llllllllllllllllIllllIllllIIIIIl) * llllllllllllllllIllllIllllIIlIIl, llllllllllllllllIllllIllllIIIIlI * llllllllllllllllIllllIllllIIlIII).endVertex();
    llllllllllllllllIllllIllllIIIllI.pos(llllllllllllllllIllllIllllIlIIIl, llllllllllllllllIllllIllllIIIlII, 0.0D).tex(llllllllllllllllIllllIllllIIIIll * llllllllllllllllIllllIllllIIlIIl, llllllllllllllllIllllIllllIIIIlI * llllllllllllllllIllllIllllIIlIII).endVertex();
    llllllllllllllllIllllIllllIIIlll.draw();
  }
  
  private static void lIIIlIIlIlllI()
  {
    lIllIIllIll = new int[13];
    lIllIIllIll[0] = ((0x67 ^ 0x28 ^ 0x74 ^ 0x19) & (0x1 ^ 0x70 ^ 0x73 ^ 0x20 ^ -" ".length()));
    lIllIIllIll[1] = " ".length();
    lIllIIllIll[2] = "  ".length();
    lIllIIllIll[3] = (0x76 ^ 0x6E);
    lIllIIllIll[4] = ('ú' + 'É' - 254 + 58);
    lIllIIllIll[5] = (88 + 105 - 49 + 5 ^ '' + 48 - 85 + 38);
    lIllIIllIll[6] = (0x54 ^ 0x76 ^ 0x19 ^ 0x33);
    lIllIIllIll[7] = (-(0xF8F2 & 0x77BF) & 0xF3FF & 0x7FB3);
    lIllIIllIll[8] = (-(0xEFB5 & 0x14FB) & 0xCFBB & 0x37F7);
    lIllIIllIll[9] = (0x76 ^ 0x2C ^ 0xC1 ^ 0x9C);
    lIllIIllIll[10] = (-(0xF45D & 0x6BB3) & 0xFD1B & 0x7FF5);
    lIllIIllIll[11] = (0x9F74 & 0x7D8B);
    lIllIIllIll[12] = "   ".length();
  }
}

package net.minecraft.client.gui;

import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Ordering;
import com.mojang.authlib.GameProfile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.network.NetworkManager;
import net.minecraft.scoreboard.IScoreObjectiveCriteria.EnumRenderType;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.world.WorldSettings.GameType;

public class GuiPlayerTabOverlay
  extends Gui
{
  private static void llIllIIIlIIlII()
  {
    lIIIlllIIlIll = new String[lIIIlllIIllIl[9]];
    lIIIlllIIlIll[lIIIlllIIllIl[0]] = llIllIIIlIIIIl("lP67t7YPlMk=", "albtu");
    lIIIlllIIlIll[lIIIlllIIllIl[2]] = llIllIIIlIIIIl("+/7DuR8BW0BdERKmYWhyDw==", "jVQYX");
    lIIIlllIIlIll[lIIIlllIIllIl[8]] = llIllIIIlIIIIl("O7TkiwTN1D4=", "coyKc");
    lIIIlllIIlIll[lIIIlllIIllIl[21]] = llIllIIIlIIIlI("JQk=", "MybGk");
    lIIIlllIIlIll[lIIIlllIIllIl[22]] = llIllIIIlIIIll("GZGDT+wPA7U=", "gluav");
  }
  
  public void renderPlayerlist(int llllllllllllllIlIIlIlIIIllIlllll, Scoreboard llllllllllllllIlIIlIlIIIllIllllI, ScoreObjective llllllllllllllIlIIlIlIIIlIllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    NetHandlerPlayClient llllllllllllllIlIIlIlIIIllIlllII = mc.thePlayer.sendQueue;
    List<NetworkPlayerInfo> llllllllllllllIlIIlIlIIIllIllIll = field_175252_a.sortedCopy(llllllllllllllIlIIlIlIIIllIlllII.getPlayerInfoMap());
    int llllllllllllllIlIIlIlIIIllIllIlI = lIIIlllIIllIl[0];
    int llllllllllllllIlIIlIlIIIllIllIIl = lIIIlllIIllIl[0];
    Exception llllllllllllllIlIIlIlIIIlIlIlIlI = llllllllllllllIlIIlIlIIIllIllIll.iterator();
    "".length();
    if (-"  ".length() >= 0) {
      return;
    }
    while (!llIllIIIlIlIlI(llllllllllllllIlIIlIlIIIlIlIlIlI.hasNext()))
    {
      NetworkPlayerInfo llllllllllllllIlIIlIlIIIllIllIII = (NetworkPlayerInfo)llllllllllllllIlIIlIlIIIlIlIlIlI.next();
      int llllllllllllllIlIIlIlIIIllIlIlll = Minecraft.fontRendererObj.getStringWidth(llllllllllllllIlIIlIlIIIlllIIIII.getPlayerName(llllllllllllllIlIIlIlIIIllIllIII));
      llllllllllllllIlIIlIlIIIllIllIlI = Math.max(llllllllllllllIlIIlIlIIIllIllIlI, llllllllllllllIlIIlIlIIIllIlIlll);
      if ((llIllIIIlIlIII(llllllllllllllIlIIlIlIIIlIllIIII)) && (llIllIIIlIlIll(llllllllllllllIlIIlIlIIIlIllIIII.getRenderType(), IScoreObjectiveCriteria.EnumRenderType.HEARTS)))
      {
        llllllllllllllIlIIlIlIIIllIlIlll = Minecraft.fontRendererObj.getStringWidth(String.valueOf(new StringBuilder(lIIIlllIIlIll[lIIIlllIIllIl[0]]).append(llllllllllllllIlIIlIlIIIllIllllI.getValueFromObjective(llllllllllllllIlIIlIlIIIllIllIII.getGameProfile().getName(), llllllllllllllIlIIlIlIIIlIllIIII).getScorePoints())));
        llllllllllllllIlIIlIlIIIllIllIIl = Math.max(llllllllllllllIlIIlIlIIIllIllIIl, llllllllllllllIlIIlIlIIIllIlIlll);
      }
    }
    llllllllllllllIlIIlIlIIIllIllIll = llllllllllllllIlIIlIlIIIllIllIll.subList(lIIIlllIIllIl[0], Math.min(llllllllllllllIlIIlIlIIIllIllIll.size(), lIIIlllIIllIl[1]));
    int llllllllllllllIlIIlIlIIIllIlIllI = llllllllllllllIlIIlIlIIIllIllIll.size();
    int llllllllllllllIlIIlIlIIIllIlIlIl = llllllllllllllIlIIlIlIIIllIlIllI;
    int llllllllllllllIlIIlIlIIIllIlIlII = lIIIlllIIllIl[2];
    "".length();
    if ("   ".length() > (107 + 72 - 93 + 99 ^ 104 + 55 - -2 + 28)) {
      return;
    }
    while (!llIllIIIlIllII(llllllllllllllIlIIlIlIIIllIlIlIl, lIIIlllIIllIl[3]))
    {
      llllllllllllllIlIIlIlIIIllIlIlII++;
      llllllllllllllIlIIlIlIIIllIlIlIl = (llllllllllllllIlIIlIlIIIllIlIllI + llllllllllllllIlIIlIlIIIllIlIlII - lIIIlllIIllIl[2]) / llllllllllllllIlIIlIlIIIllIlIlII;
    }
    if ((llIllIIIlIlIlI(mc.isIntegratedServerRunning())) && (llIllIIIlIlIlI(mc.getNetHandler().getNetworkManager().getIsencrypted())))
    {
      "".length();
      if (null == null) {
        break label359;
      }
    }
    label359:
    boolean llllllllllllllIlIIlIlIIIllIlIIll = lIIIlllIIllIl[2];
    int llllllllllllllIlIIlIlIIIllIlIIII;
    if (llIllIIIlIlIII(llllllllllllllIlIIlIlIIIlIllIIII))
    {
      if (llIllIIIlIllIl(llllllllllllllIlIIlIlIIIlIllIIII.getRenderType(), IScoreObjectiveCriteria.EnumRenderType.HEARTS))
      {
        int llllllllllllllIlIIlIlIIIllIlIIlI = lIIIlllIIllIl[4];
        "".length();
        if (-" ".length() <= 0) {}
      }
      else
      {
        int llllllllllllllIlIIlIlIIIllIlIIIl = llllllllllllllIlIIlIlIIIllIllIIl;
        "".length();
        if (-" ".length() < "   ".length()) {}
      }
    }
    else {
      llllllllllllllIlIIlIlIIIllIlIIII = lIIIlllIIllIl[0];
    }
    if (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIllIlIIll))
    {
      "".length();
      if ("  ".length() != " ".length()) {
        break label476;
      }
    }
    label476:
    int llllllllllllllIlIIlIlIIIllIIllll = Math.min(lIIIlllIIllIl[5] * (lIIIlllIIllIl[0] + llllllllllllllIlIIlIlIIIllIllIlI + llllllllllllllIlIIlIlIIIllIlIIII + lIIIlllIIllIl[6]), llllllllllllllIlIIlIlIIIllIlllll - lIIIlllIIllIl[7]) / llllllllllllllIlIIlIlIIIllIlIlII;
    int llllllllllllllIlIIlIlIIIllIIlllI = llllllllllllllIlIIlIlIIIllIlllll / lIIIlllIIllIl[8] - (llllllllllllllIlIIlIlIIIllIIllll * llllllllllllllIlIIlIlIIIllIlIlII + (llllllllllllllIlIIlIlIIIllIlIlII - lIIIlllIIllIl[2]) * lIIIlllIIllIl[9]) / lIIIlllIIllIl[8];
    int llllllllllllllIlIIlIlIIIllIIllIl = lIIIlllIIllIl[10];
    int llllllllllllllIlIIlIlIIIllIIllII = llllllllllllllIlIIlIlIIIllIIllll * llllllllllllllIlIIlIlIIIllIlIlII + (llllllllllllllIlIIlIlIIIllIlIlII - lIIIlllIIllIl[2]) * lIIIlllIIllIl[9];
    List<String> llllllllllllllIlIIlIlIIIllIIlIll = null;
    List<String> llllllllllllllIlIIlIlIIIllIIlIlI = null;
    if (llIllIIIlIlIII(header))
    {
      llllllllllllllIlIIlIlIIIllIIlIll = Minecraft.fontRendererObj.listFormattedStringToWidth(header.getFormattedText(), llllllllllllllIlIIlIlIIIllIlllll - lIIIlllIIllIl[7]);
      llllllllllllllIlIIlIlIIIlIIlllll = llllllllllllllIlIIlIlIIIllIIlIll.iterator();
      "".length();
      if (null != null) {
        return;
      }
      while (!llIllIIIlIlIlI(llllllllllllllIlIIlIlIIIlIIlllll.hasNext()))
      {
        String llllllllllllllIlIIlIlIIIllIIlIIl = (String)llllllllllllllIlIIlIlIIIlIIlllll.next();
        llllllllllllllIlIIlIlIIIllIIllII = Math.max(llllllllllllllIlIIlIlIIIllIIllII, Minecraft.fontRendererObj.getStringWidth(llllllllllllllIlIIlIlIIIllIIlIIl));
      }
    }
    if (llIllIIIlIlIII(footer))
    {
      llllllllllllllIlIIlIlIIIllIIlIlI = Minecraft.fontRendererObj.listFormattedStringToWidth(footer.getFormattedText(), llllllllllllllIlIIlIlIIIllIlllll - lIIIlllIIllIl[7]);
      llllllllllllllIlIIlIlIIIlIIlllll = llllllllllllllIlIIlIlIIIllIIlIlI.iterator();
      "".length();
      if (-"  ".length() > 0) {
        return;
      }
      while (!llIllIIIlIlIlI(llllllllllllllIlIIlIlIIIlIIlllll.hasNext()))
      {
        String llllllllllllllIlIIlIlIIIllIIlIII = (String)llllllllllllllIlIIlIlIIIlIIlllll.next();
        llllllllllllllIlIIlIlIIIllIIllII = Math.max(llllllllllllllIlIIlIlIIIllIIllII, Minecraft.fontRendererObj.getStringWidth(llllllllllllllIlIIlIlIIIllIIlIII));
      }
    }
    if (llIllIIIlIlIII(llllllllllllllIlIIlIlIIIllIIlIll))
    {
      drawRect(llllllllllllllIlIIlIlIIIllIlllll / lIIIlllIIllIl[8] - llllllllllllllIlIIlIlIIIllIIllII / lIIIlllIIllIl[8] - lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIllIIllIl - lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIllIlllll / lIIIlllIIllIl[8] + llllllllllllllIlIIlIlIIIllIIllII / lIIIlllIIllIl[8] + lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIllIIllIl + llllllllllllllIlIIlIlIIIllIIlIll.size() * fontRendererObjFONT_HEIGHT, Integer.MIN_VALUE);
      llllllllllllllIlIIlIlIIIlIIlllll = llllllllllllllIlIIlIlIIIllIIlIll.iterator();
      "".length();
      if (null != null) {
        return;
      }
      while (!llIllIIIlIlIlI(llllllllllllllIlIIlIlIIIlIIlllll.hasNext()))
      {
        String llllllllllllllIlIIlIlIIIllIIIlll = (String)llllllllllllllIlIIlIlIIIlIIlllll.next();
        int llllllllllllllIlIIlIlIIIllIIIllI = Minecraft.fontRendererObj.getStringWidth(llllllllllllllIlIIlIlIIIllIIIlll);
        "".length();
        llllllllllllllIlIIlIlIIIllIIllIl += fontRendererObjFONT_HEIGHT;
      }
    }
    drawRect(llllllllllllllIlIIlIlIIIllIlllll / lIIIlllIIllIl[8] - llllllllllllllIlIIlIlIIIllIIllII / lIIIlllIIllIl[8] - lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIllIIllIl - lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIllIlllll / lIIIlllIIllIl[8] + llllllllllllllIlIIlIlIIIllIIllII / lIIIlllIIllIl[8] + lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIllIIllIl + llllllllllllllIlIIlIlIIIllIlIlIl * lIIIlllIIllIl[5], Integer.MIN_VALUE);
    int llllllllllllllIlIIlIlIIIllIIIlIl = lIIIlllIIllIl[0];
    "".length();
    if (-"  ".length() >= 0)
    {
      ;;;
    }
    int llllllllllllllIlIIlIlIIIllIIIlII;
    label1351:
    label1454:
    label1503:
    label1607:
    label1646:
    label1901:
    while (!llIllIIIllIIII(llllllllllllllIlIIlIlIIIllIIIlIl, llllllllllllllIlIIlIlIIIllIlIllI))
    {
      int llllllllllllllIlIIlIlIIIllIIIIll = llllllllllllllIlIIlIlIIIllIIIlIl % llllllllllllllIlIIlIlIIIllIlIlIl;
      int llllllllllllllIlIIlIlIIIllIIIIlI = llllllllllllllIlIIlIlIIIllIIlllI + llllllllllllllIlIIlIlIIIllIIIlII * llllllllllllllIlIIlIlIIIllIIllll + llllllllllllllIlIIlIlIIIllIIIlII * lIIIlllIIllIl[9];
      int llllllllllllllIlIIlIlIIIllIIIIIl = llllllllllllllIlIIlIlIIIllIIllIl + llllllllllllllIlIIlIlIIIllIIIIll * lIIIlllIIllIl[5];
      drawRect(llllllllllllllIlIIlIlIIIllIIIIlI, llllllllllllllIlIIlIlIIIllIIIIIl, llllllllllllllIlIIlIlIIIllIIIIlI + llllllllllllllIlIIlIlIIIllIIllll, llllllllllllllIlIIlIlIIIllIIIIIl + lIIIlllIIllIl[12], lIIIlllIIllIl[13]);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.enableAlpha();
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(lIIIlllIIllIl[14], lIIIlllIIllIl[15], lIIIlllIIllIl[2], lIIIlllIIllIl[0]);
      if (llIllIIIlIlllI(llllllllllllllIlIIlIlIIIllIIIlIl, llllllllllllllIlIIlIlIIIllIllIll.size()))
      {
        NetworkPlayerInfo llllllllllllllIlIIlIlIIIllIIIIII = (NetworkPlayerInfo)llllllllllllllIlIIlIlIIIllIllIll.get(llllllllllllllIlIIlIlIIIllIIIlIl);
        String llllllllllllllIlIIlIlIIIlIllllll = llllllllllllllIlIIlIlIIIlllIIIII.getPlayerName(llllllllllllllIlIIlIlIIIllIIIIII);
        GameProfile llllllllllllllIlIIlIlIIIlIlllllI = llllllllllllllIlIIlIlIIIllIIIIII.getGameProfile();
        if (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIllIlIIll))
        {
          EntityPlayer llllllllllllllIlIIlIlIIIlIllllIl = mc.theWorld.getPlayerEntityByUUID(llllllllllllllIlIIlIlIIIlIlllllI.getId());
          if ((llIllIIIlIlIII(llllllllllllllIlIIlIlIIIlIllllIl)) && (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIlIllllIl.isWearing(EnumPlayerModelParts.CAPE))) && ((!llIllIIIlIlIlI(llllllllllllllIlIIlIlIIIlIlllllI.getName().equals(lIIIlllIIlIll[lIIIlllIIllIl[2]]))) || (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIlIlllllI.getName().equals(lIIIlllIIlIll[lIIIlllIIllIl[8]])))))
          {
            "".length();
            if ("  ".length() == "  ".length()) {
              break label1351;
            }
          }
          boolean llllllllllllllIlIIlIlIIIlIllllII = lIIIlllIIllIl[0];
          mc.getTextureManager().bindTexture(llllllllllllllIlIIlIlIIIllIIIIII.getLocationSkin());
          if (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIlIllllII))
          {
            "".length();
            if ("   ".length() > ((0xB3 ^ 0x9F ^ 0xA3 ^ 0x97) & (95 + 49 - 96 + 83 ^ 118 + 13 - 103 + 127 ^ -" ".length()))) {
              break label1454;
            }
          }
          int llllllllllllllIlIIlIlIIIlIlllIll = lIIIlllIIllIl[12] + lIIIlllIIllIl[0];
          if (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIlIllllII))
          {
            "".length();
            if (-" ".length() < "   ".length()) {
              break label1503;
            }
          }
          int llllllllllllllIlIIlIlIIIlIlllIlI = lIIIlllIIllIl[11] * lIIIlllIIllIl[2];
          Gui.drawScaledCustomSizeModalRect(llllllllllllllIlIIlIlIIIllIIIIlI, llllllllllllllIlIIlIlIIIllIIIIIl, 8.0F, llllllllllllllIlIIlIlIIIlIlllIll, lIIIlllIIllIl[12], llllllllllllllIlIIlIlIIIlIlllIlI, lIIIlllIIllIl[12], lIIIlllIIllIl[12], 64.0F, 64.0F);
          if ((llIllIIIlIlIII(llllllllllllllIlIIlIlIIIlIllllIl)) && (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIlIllllIl.isWearing(EnumPlayerModelParts.HAT))))
          {
            if (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIlIllllII))
            {
              "".length();
              if ("  ".length() != 0) {
                break label1607;
              }
            }
            int llllllllllllllIlIIlIlIIIlIlllIIl = lIIIlllIIllIl[12] + lIIIlllIIllIl[0];
            if (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIlIllllII))
            {
              "".length();
              if (null == null) {
                break label1646;
              }
            }
            int llllllllllllllIlIIlIlIIIlIlllIII = lIIIlllIIllIl[11] * lIIIlllIIllIl[2];
            Gui.drawScaledCustomSizeModalRect(llllllllllllllIlIIlIlIIIllIIIIlI, llllllllllllllIlIIlIlIIIllIIIIIl, 40.0F, llllllllllllllIlIIlIlIIIlIlllIIl, lIIIlllIIllIl[12], llllllllllllllIlIIlIlIIIlIlllIII, lIIIlllIIllIl[12], lIIIlllIIllIl[12], 64.0F, 64.0F);
          }
          llllllllllllllIlIIlIlIIIllIIIIlI += 9;
        }
        if (llIllIIIlIllIl(llllllllllllllIlIIlIlIIIllIIIIII.getGameType(), WorldSettings.GameType.SPECTATOR))
        {
          llllllllllllllIlIIlIlIIIlIllllll = String.valueOf(new StringBuilder().append(EnumChatFormatting.ITALIC).append(llllllllllllllIlIIlIlIIIlIllllll));
          "".length();
          "".length();
          if (null == null) {}
        }
        else
        {
          "".length();
        }
        if ((llIllIIIlIlIII(llllllllllllllIlIIlIlIIIlIllIIII)) && (llIllIIIlIlIll(llllllllllllllIlIIlIlIIIllIIIIII.getGameType(), WorldSettings.GameType.SPECTATOR)))
        {
          int llllllllllllllIlIIlIlIIIlIllIlll = llllllllllllllIlIIlIlIIIllIIIIlI + llllllllllllllIlIIlIlIIIllIllIlI + lIIIlllIIllIl[2];
          int llllllllllllllIlIIlIlIIIlIllIllI = llllllllllllllIlIIlIlIIIlIllIlll + llllllllllllllIlIIlIlIIIllIlIIII;
          if (llIllIIIlIllll(llllllllllllllIlIIlIlIIIlIllIllI - llllllllllllllIlIIlIlIIIlIllIlll, lIIIlllIIllIl[9])) {
            llllllllllllllIlIIlIlIIIlllIIIII.drawScoreboardValues(llllllllllllllIlIIlIlIIIlIllIIII, llllllllllllllIlIIlIlIIIllIIIIIl, llllllllllllllIlIIlIlIIIlIlllllI.getName(), llllllllllllllIlIIlIlIIIlIllIlll, llllllllllllllIlIIlIlIIIlIllIllI, llllllllllllllIlIIlIlIIIllIIIIII);
          }
        }
        if (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIllIlIIll))
        {
          "".length();
          if (null == null) {
            break label1901;
          }
        }
        llllllllllllllIlIIlIlIIIllIIllll.drawPing(llllllllllllllIlIIlIlIIIllIIIIlI, lIIIlllIIllIl[5] - lIIIlllIIllIl[0], llllllllllllllIlIIlIlIIIllIIIIIl, llllllllllllllIlIIlIlIIIllIIIIII);
      }
      llllllllllllllIlIIlIlIIIllIIIlIl++;
    }
    if (llIllIIIlIlIII(llllllllllllllIlIIlIlIIIllIIlIlI))
    {
      llllllllllllllIlIIlIlIIIllIIllIl = llllllllllllllIlIIlIlIIIllIIllIl + llllllllllllllIlIIlIlIIIllIlIlIl * lIIIlllIIllIl[5] + lIIIlllIIllIl[2];
      drawRect(llllllllllllllIlIIlIlIIIllIlllll / lIIIlllIIllIl[8] - llllllllllllllIlIIlIlIIIllIIllII / lIIIlllIIllIl[8] - lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIllIIllIl - lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIllIlllll / lIIIlllIIllIl[8] + llllllllllllllIlIIlIlIIIllIIllII / lIIIlllIIllIl[8] + lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIllIIllIl + llllllllllllllIlIIlIlIIIllIIlIlI.size() * fontRendererObjFONT_HEIGHT, Integer.MIN_VALUE);
      llllllllllllllIlIIlIlIIIllIIIlII = llllllllllllllIlIIlIlIIIllIIlIlI.iterator();
      "".length();
      if (null != null) {
        return;
      }
      while (!llIllIIIlIlIlI(llllllllllllllIlIIlIlIIIllIIIlII.hasNext()))
      {
        String llllllllllllllIlIIlIlIIIlIllIlIl = (String)llllllllllllllIlIIlIlIIIllIIIlII.next();
        int llllllllllllllIlIIlIlIIIlIllIlII = Minecraft.fontRendererObj.getStringWidth(llllllllllllllIlIIlIlIIIlIllIlIl);
        "".length();
        llllllllllllllIlIIlIlIIIllIIllIl += fontRendererObjFONT_HEIGHT;
      }
    }
  }
  
  private static boolean llIllIIIlIlIlI(int ???)
  {
    Exception llllllllllllllIlIIlIIllllllIlIll;
    return ??? == 0;
  }
  
  private static boolean llIllIIIllIIIl(int ???)
  {
    Exception llllllllllllllIlIIlIIllllllIlIIl;
    return ??? < 0;
  }
  
  public GuiPlayerTabOverlay(Minecraft llllllllllllllIlIIlIlIIlIIllIIIl, GuiIngame llllllllllllllIlIIlIlIIlIIllIIll)
  {
    mc = llllllllllllllIlIIlIlIIlIIllIlII;
    guiIngame = llllllllllllllIlIIlIlIIlIIllIIll;
  }
  
  private static boolean llIllIIIlIlIII(Object ???)
  {
    String llllllllllllllIlIIlIIlllllllIIll;
    return ??? != null;
  }
  
  public void setFooter(IChatComponent llllllllllllllIlIIlIlIIIIlIIlIlI)
  {
    ;
    ;
    footer = llllllllllllllIlIIlIlIIIIlIIlIlI;
  }
  
  private static String llIllIIIlIIIlI(String llllllllllllllIlIIlIlIIIIIlIIlll, String llllllllllllllIlIIlIlIIIIIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIlIlIIIIIlIIlll = new String(Base64.getDecoder().decode(llllllllllllllIlIIlIlIIIIIlIIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIIlIlIIIIIlIIlIl = new StringBuilder();
    char[] llllllllllllllIlIIlIlIIIIIlIIlII = llllllllllllllIlIIlIlIIIIIlIIIIl.toCharArray();
    int llllllllllllllIlIIlIlIIIIIlIIIll = lIIIlllIIllIl[0];
    boolean llllllllllllllIlIIlIlIIIIIIlllIl = llllllllllllllIlIIlIlIIIIIlIIlll.toCharArray();
    double llllllllllllllIlIIlIlIIIIIIlllII = llllllllllllllIlIIlIlIIIIIIlllIl.length;
    double llllllllllllllIlIIlIlIIIIIIllIll = lIIIlllIIllIl[0];
    while (llIllIIIlIlllI(llllllllllllllIlIIlIlIIIIIIllIll, llllllllllllllIlIIlIlIIIIIIlllII))
    {
      char llllllllllllllIlIIlIlIIIIIlIlIII = llllllllllllllIlIIlIlIIIIIIlllIl[llllllllllllllIlIIlIlIIIIIIllIll];
      "".length();
      "".length();
      if ("   ".length() > (0x71 ^ 0x7A ^ 0x10 ^ 0x1F)) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIIlIlIIIIIlIIlIl);
  }
  
  private void drawScoreboardValues(ScoreObjective llllllllllllllIlIIlIlIIIIlIllIll, int llllllllllllllIlIIlIlIIIIllIllII, String llllllllllllllIlIIlIlIIIIlIllIIl, int llllllllllllllIlIIlIlIIIIllIlIlI, int llllllllllllllIlIIlIlIIIIllIlIIl, NetworkPlayerInfo llllllllllllllIlIIlIlIIIIllIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIIlIlIIIIllIIlll = llllllllllllllIlIIlIlIIIIlIllIll.getScoreboard().getValueFromObjective(llllllllllllllIlIIlIlIIIIllIlIll, llllllllllllllIlIIlIlIIIIlIllIll).getScorePoints();
    if (llIllIIIlIllIl(llllllllllllllIlIIlIlIIIIlIllIll.getRenderType(), IScoreObjectiveCriteria.EnumRenderType.HEARTS))
    {
      mc.getTextureManager().bindTexture(icons);
      if (llIllIIIlIlIlI(llIllIIIllIIlI(lastTimeOpened, llllllllllllllIlIIlIlIIIIllIlIII.func_178855_p()))) {
        if (llIllIIIlIlllI(llllllllllllllIlIIlIlIIIIllIIlll, llllllllllllllIlIIlIlIIIIllIlIII.func_178835_l()))
        {
          llllllllllllllIlIIlIlIIIIllIlIII.func_178846_a(Minecraft.getSystemTime());
          llllllllllllllIlIIlIlIIIIllIlIII.func_178844_b(guiIngame.getUpdateCounter() + lIIIlllIIllIl[3]);
          "".length();
          if ("  ".length() == "  ".length()) {}
        }
        else if (llIllIIIlIllll(llllllllllllllIlIIlIlIIIIllIIlll, llllllllllllllIlIIlIlIIIIllIlIII.func_178835_l()))
        {
          llllllllllllllIlIIlIlIIIIllIlIII.func_178846_a(Minecraft.getSystemTime());
          llllllllllllllIlIIlIlIIIIllIlIII.func_178844_b(guiIngame.getUpdateCounter() + lIIIlllIIllIl[10]);
        }
      }
      if ((!llIllIIIllIlII(llIllIIIllIIlI(Minecraft.getSystemTime() - llllllllllllllIlIIlIlIIIIllIlIII.func_178847_n(), 1000L))) || (llIllIIIlIlIIl(llIllIIIllIIlI(lastTimeOpened, llllllllllllllIlIIlIlIIIIllIlIII.func_178855_p()))))
      {
        llllllllllllllIlIIlIlIIIIllIlIII.func_178836_b(llllllllllllllIlIIlIlIIIIllIIlll);
        llllllllllllllIlIIlIlIIIIllIlIII.func_178857_c(llllllllllllllIlIIlIlIIIIllIIlll);
        llllllllllllllIlIIlIlIIIIllIlIII.func_178846_a(Minecraft.getSystemTime());
      }
      llllllllllllllIlIIlIlIIIIllIlIII.func_178843_c(lastTimeOpened);
      llllllllllllllIlIIlIlIIIIllIlIII.func_178836_b(llllllllllllllIlIIlIlIIIIllIIlll);
      int llllllllllllllIlIIlIlIIIIllIIllI = MathHelper.ceiling_float_int(Math.max(llllllllllllllIlIIlIlIIIIllIIlll, llllllllllllllIlIIlIlIIIIllIlIII.func_178860_m()) / 2.0F);
      int llllllllllllllIlIIlIlIIIIllIIlIl = Math.max(MathHelper.ceiling_float_int(llllllllllllllIlIIlIlIIIIllIIlll / lIIIlllIIllIl[8]), Math.max(MathHelper.ceiling_float_int(llllllllllllllIlIIlIlIIIIllIlIII.func_178860_m() / lIIIlllIIllIl[8]), lIIIlllIIllIl[10]));
      if ((llIllIIIllIlIl(llIllIIIllIIlI(llllllllllllllIlIIlIlIIIIllIlIII.func_178858_o(), guiIngame.getUpdateCounter()))) && (llIllIIIlIlIlI(llIllIIIllIIlI((llllllllllllllIlIIlIlIIIIllIlIII.func_178858_o() - guiIngame.getUpdateCounter()) / 3L % 2L, 1L))))
      {
        "".length();
        if ((0x57 ^ 0x52) > 0) {
          break label376;
        }
      }
      label376:
      boolean llllllllllllllIlIIlIlIIIIllIIlII = lIIIlllIIllIl[0];
      if (llIllIIIllIlIl(llllllllllllllIlIIlIlIIIIllIIllI))
      {
        float llllllllllllllIlIIlIlIIIIllIIIll = Math.min((llllllllllllllIlIIlIlIIIIllIlIIl - llllllllllllllIlIIlIlIIIIllIlIlI - lIIIlllIIllIl[22]) / llllllllllllllIlIIlIlIIIIllIIlIl, 9.0F);
        if (llIllIIIllIlIl(llIllIIIllIIll(llllllllllllllIlIIlIlIIIIllIIIll, 3.0F)))
        {
          int llllllllllllllIlIIlIlIIIIllIIIlI = llllllllllllllIlIIlIlIIIIllIIllI;
          "".length();
          if (" ".length() > "  ".length()) {
            return;
          }
          label502:
          while (!llIllIIIllIIII(llllllllllllllIlIIlIlIIIIllIIIlI, llllllllllllllIlIIlIlIIIIllIIlIl))
          {
            if (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIIllIIlII))
            {
              "".length();
              if ("   ".length() < (0x66 ^ 0x62)) {
                break label502;
              }
            }
            (llllllllllllllIlIIlIlIIIIllIlIlI + llllllllllllllIlIIlIlIIIIllIIIlI * llllllllllllllIlIIlIlIIIIllIIIll).drawTexturedModalRect(llllllllllllllIlIIlIlIIIIllIllII, lIIIlllIIllIl[25], lIIIlllIIllIl[26], lIIIlllIIllIl[0], lIIIlllIIllIl[5], lIIIlllIIllIl[5]);
          }
          int llllllllllllllIlIIlIlIIIIllIIIIl = lIIIlllIIllIl[0];
          "".length();
          if ("  ".length() < 0) {
            return;
          }
          label609:
          label844:
          label944:
          while (!llIllIIIllIIII(llllllllllllllIlIIlIlIIIIllIIIIl, llllllllllllllIlIIlIlIIIIllIIllI))
          {
            if (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIIllIIlII))
            {
              "".length();
              if ("   ".length() != -" ".length()) {
                break label609;
              }
            }
            (llllllllllllllIlIIlIlIIIIllIlIlI + llllllllllllllIlIIlIlIIIIllIIIIl * llllllllllllllIlIIlIlIIIIllIIIll).drawTexturedModalRect(llllllllllllllIlIIlIlIIIIllIllII, lIIIlllIIllIl[25], lIIIlllIIllIl[26], lIIIlllIIllIl[0], lIIIlllIIllIl[5], lIIIlllIIllIl[5]);
            if (llIllIIIlIlIIl(llllllllllllllIlIIlIlIIIIllIIlII))
            {
              if (llIllIIIlIlllI(llllllllllllllIlIIlIlIIIIllIIIIl * lIIIlllIIllIl[8] + lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIIllIlIII.func_178860_m())) {
                llllllllllllllIlIIlIlIIIIllIlllI.drawTexturedModalRect(llllllllllllllIlIIlIlIIIIllIlIlI + llllllllllllllIlIIlIlIIIIllIIIIl * llllllllllllllIlIIlIlIIIIllIIIll, llllllllllllllIlIIlIlIIIIllIllII, lIIIlllIIllIl[27], lIIIlllIIllIl[0], lIIIlllIIllIl[5], lIIIlllIIllIl[5]);
              }
              if (llIllIIIllIllI(llllllllllllllIlIIlIlIIIIllIIIIl * lIIIlllIIllIl[8] + lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIIllIlIII.func_178860_m())) {
                llllllllllllllIlIIlIlIIIIllIlllI.drawTexturedModalRect(llllllllllllllIlIIlIlIIIIllIlIlI + llllllllllllllIlIIlIlIIIIllIIIIl * llllllllllllllIlIIlIlIIIIllIIIll, llllllllllllllIlIIlIlIIIIllIllII, lIIIlllIIllIl[28], lIIIlllIIllIl[0], lIIIlllIIllIl[5], lIIIlllIIllIl[5]);
              }
            }
            if (llIllIIIlIlllI(llllllllllllllIlIIlIlIIIIllIIIIl * lIIIlllIIllIl[8] + lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIIllIIlll))
            {
              if (llIllIIIllIIII(llllllllllllllIlIIlIlIIIIllIIIIl, lIIIlllIIllIl[10]))
              {
                "".length();
                if ("  ".length() != -" ".length()) {
                  break label844;
                }
              }
              (llllllllllllllIlIIlIlIIIIllIlIlI + llllllllllllllIlIIlIlIIIIllIIIIl * llllllllllllllIlIIlIlIIIIllIIIll).drawTexturedModalRect(llllllllllllllIlIIlIlIIIIllIllII, lIIIlllIIllIl[29], lIIIlllIIllIl[30], lIIIlllIIllIl[0], lIIIlllIIllIl[5], lIIIlllIIllIl[5]);
            }
            if (llIllIIIllIllI(llllllllllllllIlIIlIlIIIIllIIIIl * lIIIlllIIllIl[8] + lIIIlllIIllIl[2], llllllllllllllIlIIlIlIIIIllIIlll))
            {
              if (llIllIIIllIIII(llllllllllllllIlIIlIlIIIIllIIIIl, lIIIlllIIllIl[10]))
              {
                "".length();
                if (" ".length() <= "  ".length()) {
                  break label944;
                }
              }
              (llllllllllllllIlIIlIlIIIIllIlIlI + llllllllllllllIlIIlIlIIIIllIIIIl * llllllllllllllIlIIlIlIIIIllIIIll).drawTexturedModalRect(llllllllllllllIlIIlIlIIIIllIllII, lIIIlllIIllIl[31], lIIIlllIIllIl[32], lIIIlllIIllIl[0], lIIIlllIIllIl[5], lIIIlllIIllIl[5]);
            }
            llllllllllllllIlIIlIlIIIIllIIIIl++;
          }
          "".length();
          if (((0x1 ^ 0xB) & (0x88 ^ 0x82 ^ 0xFFFFFFFF)) == 0) {}
        }
        else
        {
          float llllllllllllllIlIIlIlIIIIllIIIII = MathHelper.clamp_float(llllllllllllllIlIIlIlIIIIllIIlll / 20.0F, 0.0F, 1.0F);
          int llllllllllllllIlIIlIlIIIIlIlllll = (int)((1.0F - llllllllllllllIlIIlIlIIIIllIIIII) * 255.0F) << lIIIlllIIllIl[26] | (int)(llllllllllllllIlIIlIlIIIIllIIIII * 255.0F) << lIIIlllIIllIl[12];
          String llllllllllllllIlIIlIlIIIIlIllllI = String.valueOf(new StringBuilder().append(llllllllllllllIlIIlIlIIIIllIIlll / 2.0F));
          if (llIllIIIllIIII(llllllllllllllIlIIlIlIIIIllIlIIl - Minecraft.fontRendererObj.getStringWidth(String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlIIlIlIIIIlIllllI)).append(lIIIlllIIlIll[lIIIlllIIllIl[21]]))), llllllllllllllIlIIlIlIIIIllIlIlI)) {
            llllllllllllllIlIIlIlIIIIlIllllI = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlIIlIlIIIIlIllllI)).append(lIIIlllIIlIll[lIIIlllIIllIl[22]]));
          }
          "".length();
          "".length();
          if (((0x77 ^ 0x3D) & (0x5 ^ 0x4F ^ 0xFFFFFFFF)) == 0) {}
        }
      }
    }
    else
    {
      String llllllllllllllIlIIlIlIIIIlIlllIl = String.valueOf(new StringBuilder().append(EnumChatFormatting.YELLOW).append(llllllllllllllIlIIlIlIIIIllIIlll));
      "".length();
    }
  }
  
  public void updatePlayerList(boolean llllllllllllllIlIIlIlIIlIIlIlIII)
  {
    ;
    ;
    if ((llIllIIIlIlIIl(llllllllllllllIlIIlIlIIlIIlIlIII)) && (llIllIIIlIlIlI(isBeingRendered))) {
      lastTimeOpened = Minecraft.getSystemTime();
    }
    isBeingRendered = llllllllllllllIlIIlIlIIlIIlIlIII;
  }
  
  private static boolean llIllIIIlIlIIl(int ???)
  {
    double llllllllllllllIlIIlIIllllllIllIl;
    return ??? != 0;
  }
  
  private static boolean llIllIIIlIllIl(Object ???, Object arg1)
  {
    Object localObject;
    float llllllllllllllIlIIlIIllllllIllll;
    return ??? == localObject;
  }
  
  public String getPlayerName(NetworkPlayerInfo llllllllllllllIlIIlIlIIlIIlIllII)
  {
    ;
    if (llIllIIIlIlIII(llllllllllllllIlIIlIlIIlIIlIllII.getDisplayName()))
    {
      "".length();
      if (null == null) {
        break label45;
      }
      return null;
    }
    label45:
    return ScorePlayerTeam.formatPlayerName(llllllllllllllIlIIlIlIIlIIlIllIl.getPlayerTeam(), llllllllllllllIlIIlIlIIlIIlIllIl.getGameProfile().getName());
  }
  
  private static boolean llIllIIIlIllII(int ???, int arg1)
  {
    int i;
    float llllllllllllllIlIIlIIlllllllllIl;
    return ??? <= i;
  }
  
  private static boolean llIllIIIlIlllI(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIlIIlIlIIIIIIIIIIl;
    return ??? < i;
  }
  
  public void func_181030_a()
  {
    ;
    header = null;
    footer = null;
  }
  
  private static boolean llIllIIIllIllI(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlIIlIlIIIIIIIlIIl;
    return ??? == i;
  }
  
  private static int llIllIIIllIIll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static String llIllIIIlIIIIl(String llllllllllllllIlIIlIlIIIIIllIlIl, String llllllllllllllIlIIlIlIIIIIllIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIlIlIIIIIlllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIlIlIIIIIllIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIIlIlIIIIIlllIIl = Cipher.getInstance("Blowfish");
      llllllllllllllIlIIlIlIIIIIlllIIl.init(lIIIlllIIllIl[8], llllllllllllllIlIIlIlIIIIIlllIlI);
      return new String(llllllllllllllIlIIlIlIIIIIlllIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIlIlIIIIIllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIlIlIIIIIlllIII)
    {
      llllllllllllllIlIIlIlIIIIIlllIII.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIllIIIllIlIl(int ???)
  {
    long llllllllllllllIlIIlIIllllllIIlIl;
    return ??? > 0;
  }
  
  private static boolean llIllIIIllIlII(int ???)
  {
    byte llllllllllllllIlIIlIIllllllIIlll;
    return ??? <= 0;
  }
  
  public void setHeader(IChatComponent llllllllllllllIlIIlIlIIIIlIIIIlI)
  {
    ;
    ;
    header = llllllllllllllIlIIlIlIIIIlIIIIlI;
  }
  
  static
  {
    llIllIIIlIIlll();
    llIllIIIlIIlII();
  }
  
  private static String llIllIIIlIIIll(String llllllllllllllIlIIlIlIIIIIIlIIlI, String llllllllllllllIlIIlIlIIIIIIlIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIlIlIIIIIIlIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIlIlIIIIIIlIIIl.getBytes(StandardCharsets.UTF_8)), lIIIlllIIllIl[12]), "DES");
      Cipher llllllllllllllIlIIlIlIIIIIIlIlII = Cipher.getInstance("DES");
      llllllllllllllIlIIlIlIIIIIIlIlII.init(lIIIlllIIllIl[8], llllllllllllllIlIIlIlIIIIIIlIlIl);
      return new String(llllllllllllllIlIIlIlIIIIIIlIlII.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIlIlIIIIIIlIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIlIlIIIIIIlIIll)
    {
      llllllllllllllIlIIlIlIIIIIIlIIll.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIllIIIllIIII(int ???, int arg1)
  {
    int i;
    String llllllllllllllIlIIlIlIIIIIIIIlIl;
    return ??? >= i;
  }
  
  private static int llIllIIIllIIlI(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  protected void drawPing(int llllllllllllllIlIIlIlIIIlIIIIIll, int llllllllllllllIlIIlIlIIIlIIIlIIl, int llllllllllllllIlIIlIlIIIlIIIIIIl, NetworkPlayerInfo llllllllllllllIlIIlIlIIIlIIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(icons);
    int llllllllllllllIlIIlIlIIIlIIIIllI = lIIIlllIIllIl[0];
    int llllllllllllllIlIIlIlIIIlIIIIlIl = lIIIlllIIllIl[0];
    if (llIllIIIllIIIl(llllllllllllllIlIIlIlIIIlIIIIlll.getResponseTime()))
    {
      llllllllllllllIlIIlIlIIIlIIIIlIl = lIIIlllIIllIl[9];
      "".length();
      if ((0x31 ^ 0x34) > 0) {}
    }
    else if (llIllIIIlIlllI(llllllllllllllIlIIlIlIIIlIIIIlll.getResponseTime(), lIIIlllIIllIl[17]))
    {
      llllllllllllllIlIIlIlIIIlIIIIlIl = lIIIlllIIllIl[0];
      "".length();
      if (((0x5A ^ 0x64) & (0x19 ^ 0x27 ^ 0xFFFFFFFF)) <= (0xC6 ^ 0xC2)) {}
    }
    else if (llIllIIIlIlllI(llllllllllllllIlIIlIlIIIlIIIIlll.getResponseTime(), lIIIlllIIllIl[18]))
    {
      llllllllllllllIlIIlIlIIIlIIIIlIl = lIIIlllIIllIl[2];
      "".length();
      if (((0x7D ^ 0x20) & (0x70 ^ 0x2D ^ 0xFFFFFFFF)) <= 0) {}
    }
    else if (llIllIIIlIlllI(llllllllllllllIlIIlIlIIIlIIIIlll.getResponseTime(), lIIIlllIIllIl[19]))
    {
      llllllllllllllIlIIlIlIIIlIIIIlIl = lIIIlllIIllIl[8];
      "".length();
      if (" ".length() >= " ".length()) {}
    }
    else if (llIllIIIlIlllI(llllllllllllllIlIIlIlIIIlIIIIlll.getResponseTime(), lIIIlllIIllIl[20]))
    {
      llllllllllllllIlIIlIlIIIlIIIIlIl = lIIIlllIIllIl[21];
      "".length();
      if (-" ".length() < " ".length()) {}
    }
    else
    {
      llllllllllllllIlIIlIlIIIlIIIIlIl = lIIIlllIIllIl[22];
    }
    zLevel += 100.0F;
    llllllllllllllIlIIlIlIIIlIIIlIll.drawTexturedModalRect(llllllllllllllIlIIlIlIIIlIIIIIlI + llllllllllllllIlIIlIlIIIlIIIIIll - lIIIlllIIllIl[23], llllllllllllllIlIIlIlIIIlIIIIIIl, lIIIlllIIllIl[0] + llllllllllllllIlIIlIlIIIlIIIIllI * lIIIlllIIllIl[10], lIIIlllIIllIl[24] + llllllllllllllIlIIlIlIIIlIIIIlIl * lIIIlllIIllIl[12], lIIIlllIIllIl[10], lIIIlllIIllIl[12]);
    zLevel -= 100.0F;
  }
  
  private static boolean llIllIIIlIllll(int ???, int arg1)
  {
    int i;
    char llllllllllllllIlIIlIIllllllllIIl;
    return ??? > i;
  }
  
  private static void llIllIIIlIIlll()
  {
    lIIIlllIIllIl = new int[34];
    lIIIlllIIllIl[0] = (('' + 3 - 64 + 65 ^ 51 + 65 - -19 + 0) & (118 + '' - 232 + 135 ^ 42 + '' - 141 + 107 ^ -" ".length()));
    lIIIlllIIllIl[1] = (0xF6 ^ 0xA6);
    lIIIlllIIllIl[2] = " ".length();
    lIIIlllIIllIl[3] = (' ' + 4 - 17 + 29 ^ 54 + 49 - -59 + 2);
    lIIIlllIIllIl[4] = (0xE3 ^ 0xB9);
    lIIIlllIIllIl[5] = (0x2E ^ 0x27);
    lIIIlllIIllIl[6] = (0xF ^ 0x8 ^ 0xAB ^ 0xA1);
    lIIIlllIIllIl[7] = (0xF3 ^ 0xC1);
    lIIIlllIIllIl[8] = "  ".length();
    lIIIlllIIllIl[9] = (0x6B ^ 0x34 ^ 0xCF ^ 0x95);
    lIIIlllIIllIl[10] = (0xE8 ^ 0x88 ^ 0x21 ^ 0x4B);
    lIIIlllIIllIl[11] = (-" ".length());
    lIIIlllIIllIl[12] = (25 + 52 - -52 + 25 ^ 39 + '' - 139 + 115);
    lIIIlllIIllIl[13] = (0xFFFFFFFF & 0x20FFFFFF);
    lIIIlllIIllIl[14] = (0xB30F & 0x4FF2);
    lIIIlllIIllIl[15] = (0x9FD3 & 0x632F);
    lIIIlllIIllIl[16] = (-(0xCDA9 & 0x6F003257));
    lIIIlllIIllIl[17] = ((0x7C ^ 0x69) + (0x55 ^ 0x52) - -(0x9A ^ 0x88) + (0x45 ^ 0x2D));
    lIIIlllIIllIl[18] = (0xD53E & 0x2BED);
    lIIIlllIIllIl[19] = (0x937E & 0x6ED9);
    lIIIlllIIllIl[20] = (0x9FFE & 0x63E9);
    lIIIlllIIllIl[21] = "   ".length();
    lIIIlllIIllIl[22] = (0xCE ^ 0x85 ^ 0x53 ^ 0x1C);
    lIIIlllIIllIl[23] = (0x6 ^ 0xD);
    lIIIlllIIllIl[24] = (103 + 58 - 97 + 112);
    lIIIlllIIllIl[25] = (0x6C ^ 0x78 ^ 0x9C ^ 0x91);
    lIIIlllIIllIl[26] = (63 + 9 - 29 + 129 ^ 19 + 98 - 33 + 104);
    lIIIlllIIllIl[27] = (96 + 127 - 207 + 195 ^ 39 + 0 - -98 + 12);
    lIIIlllIIllIl[28] = (0x82 ^ 0xA1 ^ 0xD9 ^ 0xB5);
    lIIIlllIIllIl[29] = (28 + 92 - -18 + 22);
    lIIIlllIIllIl[30] = (0x23 ^ 0x17);
    lIIIlllIIllIl[31] = ('' + 78 - 82 + 19 + (0x8D ^ 0x9C) - (0xD ^ 0x21) + (0x37 ^ 0x16));
    lIIIlllIIllIl[32] = (0x17 ^ 0x2A);
    lIIIlllIIllIl[33] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
  }
  
  private static boolean llIllIIIlIlIll(Object ???, Object arg1)
  {
    Object localObject;
    String llllllllllllllIlIIlIIlllllllIlIl;
    return ??? != localObject;
  }
  
  static class PlayerComparator
    implements Comparator<NetworkPlayerInfo>
  {
    private static void lIlIIIlllIIlIl()
    {
      llIlIlIlIIII = new String[llIlIlIlIIIl[2]];
      llIlIlIlIIII[llIlIlIlIIIl[1]] = lIlIIIlllIIIll("172BmMUxSm8=", "pbZQE");
      llIlIlIlIIII[llIlIlIlIIIl[0]] = lIlIIIlllIIlII("", "gXPwc");
    }
    
    private static boolean lIlIIIlllIlIIl(int ???, int arg1)
    {
      int i;
      double lllllllllllllllIIIIIIIlIlIlIIIll;
      return ??? < i;
    }
    
    private static boolean lIlIIIlllIIlll(Object ???, Object arg1)
    {
      Object localObject;
      float lllllllllllllllIIIIIIIlIlIIlllll;
      return ??? != localObject;
    }
    
    private static boolean lIlIIIlllIlIII(Object ???)
    {
      float lllllllllllllllIIIIIIIlIlIIlllIl;
      return ??? != null;
    }
    
    private static String lIlIIIlllIIIll(String lllllllllllllllIIIIIIIlIllIIIlII, String lllllllllllllllIIIIIIIlIllIIIIll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIIIIIIlIllIIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIIIIIlIllIIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIIIIIIIlIllIIIllI = Cipher.getInstance("Blowfish");
        lllllllllllllllIIIIIIIlIllIIIllI.init(llIlIlIlIIIl[2], lllllllllllllllIIIIIIIlIllIIIlll);
        return new String(lllllllllllllllIIIIIIIlIllIIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIIIIIlIllIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIIIIIIlIllIIIlIl)
      {
        lllllllllllllllIIIIIIIlIllIIIlIl.printStackTrace();
      }
      return null;
    }
    
    private PlayerComparator() {}
    
    static
    {
      lIlIIIlllIIllI();
      lIlIIIlllIIlIl();
    }
    
    public int compare(NetworkPlayerInfo lllllllllllllllIIIIIIIlIllIllIll, NetworkPlayerInfo lllllllllllllllIIIIIIIlIllIlIllI)
    {
      ;
      ;
      ;
      ;
      ScorePlayerTeam lllllllllllllllIIIIIIIlIllIllIIl = lllllllllllllllIIIIIIIlIllIllIll.getPlayerTeam();
      ScorePlayerTeam lllllllllllllllIIIIIIIlIllIllIII = lllllllllllllllIIIIIIIlIllIlIllI.getPlayerTeam();
      if (lIlIIIlllIIlll(lllllllllllllllIIIIIIIlIllIllIll.getGameType(), WorldSettings.GameType.SPECTATOR))
      {
        "".length();
        if (-" ".length() != " ".length()) {
          break label106;
        }
        return (0x19 ^ 0x1) & (0xA3 ^ 0xBB ^ 0xFFFFFFFF) & ((0x8 ^ 0x3F) & (0x84 ^ 0xB3 ^ 0xFFFFFFFF) & ((0x11 ^ 0x72) & (0x4D ^ 0x2E ^ 0xFFFFFFFF) ^ 0xFFFFFFFF) ^ 0xFFFFFFFF);
      }
      label106:
      if (lIlIIIlllIIlll(lllllllllllllllIIIIIIIlIllIlIllI.getGameType(), WorldSettings.GameType.SPECTATOR))
      {
        "".length();
        if ("   ".length() != 0) {
          break label176;
        }
        return (0x1C ^ 0x18 ^ " ".length()) & (0x1E ^ 0x29 ^ 0xA6 ^ 0x94 ^ -" ".length());
      }
      label176:
      if (lIlIIIlllIlIII(lllllllllllllllIIIIIIIlIllIllIIl))
      {
        "".length();
        if (" ".length() != 0) {
          break label229;
        }
        return (0xDF ^ 0x84) & (0x25 ^ 0x7E ^ 0xFFFFFFFF);
      }
      label229:
      if (lIlIIIlllIlIII(lllllllllllllllIIIIIIIlIllIllIII))
      {
        "".length();
        if ((0x69 ^ 0x22 ^ 0x5B ^ 0x15) != 0) {
          break label306;
        }
        return (0xAE ^ 0xC7 ^ 0x6F ^ 0x29) & (0x6 ^ 0x10 ^ 0xBA ^ 0x83 ^ -" ".length());
      }
      label306:
      return llIlIlIlIIII[llIlIlIlIIIl[1]].compare(lllllllllllllllIIIIIIIlIllIllIII.getRegisteredName(), llIlIlIlIIII[llIlIlIlIIIl[0]]).compare(lllllllllllllllIIIIIIIlIllIllIll.getGameProfile().getName(), lllllllllllllllIIIIIIIlIllIlIllI.getGameProfile().getName()).result();
    }
    
    private static String lIlIIIlllIIlII(String lllllllllllllllIIIIIIIlIlIlIllll, String lllllllllllllllIIIIIIIlIlIllIIll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIIIIIIIlIlIlIllll = new String(Base64.getDecoder().decode(lllllllllllllllIIIIIIIlIlIlIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIIIIIIIlIlIllIIlI = new StringBuilder();
      char[] lllllllllllllllIIIIIIIlIlIllIIIl = lllllllllllllllIIIIIIIlIlIllIIll.toCharArray();
      int lllllllllllllllIIIIIIIlIlIllIIII = llIlIlIlIIIl[1];
      String lllllllllllllllIIIIIIIlIlIlIlIlI = lllllllllllllllIIIIIIIlIlIlIllll.toCharArray();
      char lllllllllllllllIIIIIIIlIlIlIlIIl = lllllllllllllllIIIIIIIlIlIlIlIlI.length;
      boolean lllllllllllllllIIIIIIIlIlIlIlIII = llIlIlIlIIIl[1];
      while (lIlIIIlllIlIIl(lllllllllllllllIIIIIIIlIlIlIlIII, lllllllllllllllIIIIIIIlIlIlIlIIl))
      {
        char lllllllllllllllIIIIIIIlIlIllIlIl = lllllllllllllllIIIIIIIlIlIlIlIlI[lllllllllllllllIIIIIIIlIlIlIlIII];
        "".length();
        "".length();
        if (-(0x47 ^ 0x42) >= 0) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIIIIIIIlIlIllIIlI);
    }
    
    private static void lIlIIIlllIIllI()
    {
      llIlIlIlIIIl = new int[3];
      llIlIlIlIIIl[0] = " ".length();
      llIlIlIlIIIl[1] = ((0x3B ^ 0x3D ^ "   ".length()) & (0x49 ^ 0x41 ^ 0x3 ^ 0xE ^ -" ".length()));
      llIlIlIlIIIl[2] = "  ".length();
    }
  }
}

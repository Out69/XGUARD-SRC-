package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.util.IChatComponent;

public class GuiCustomizeSkin
  extends GuiScreen
{
  private static String llIIllIlIIllI(String lllllllllllllllIlllllIlIIlIIIlll, String lllllllllllllllIlllllIlIIlIIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlllllIlIIlIIIlll = new String(Base64.getDecoder().decode(lllllllllllllllIlllllIlIIlIIIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllllIlIIlIIlIlI = new StringBuilder();
    char[] lllllllllllllllIlllllIlIIlIIlIIl = lllllllllllllllIlllllIlIIlIIIllI.toCharArray();
    int lllllllllllllllIlllllIlIIlIIlIII = lIIIIlIlIlII[0];
    double lllllllllllllllIlllllIlIIlIIIIlI = lllllllllllllllIlllllIlIIlIIIlll.toCharArray();
    String lllllllllllllllIlllllIlIIlIIIIIl = lllllllllllllllIlllllIlIIlIIIIlI.length;
    byte lllllllllllllllIlllllIlIIlIIIIII = lIIIIlIlIlII[0];
    while (llIIllIllIIIl(lllllllllllllllIlllllIlIIlIIIIII, lllllllllllllllIlllllIlIIlIIIIIl))
    {
      char lllllllllllllllIlllllIlIIlIIllIl = lllllllllllllllIlllllIlIIlIIIIlI[lllllllllllllllIlllllIlIIlIIIIII];
      "".length();
      "".length();
      if (-"  ".length() > 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIlllllIlIIlIIlIlI);
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    int lllllllllllllllIlllllIlIlIIIIIIl = lIIIIlIlIlII[0];
    title = I18n.format(lIIIIlIlIIll[lIIIIlIlIlII[0]], new Object[lIIIIlIlIlII[0]]);
    byte lllllllllllllllIlllllIlIIllllIll = (lllllllllllllllIlllllIlIIllllIlI = EnumPlayerModelParts.values()).length;
    long lllllllllllllllIlllllIlIIlllllII = lIIIIlIlIlII[0];
    "".length();
    if ("   ".length() == 0) {
      return;
    }
    while (!llIIllIlIlllI(lllllllllllllllIlllllIlIIlllllII, lllllllllllllllIlllllIlIIllllIll))
    {
      EnumPlayerModelParts lllllllllllllllIlllllIlIlIIIIIII = lllllllllllllllIlllllIlIIllllIlI[lllllllllllllllIlllllIlIIlllllII];
      new ButtonPart(lllllllllllllllIlllllIlIlIIIIIII.getPartId(), width / lIIIIlIlIlII[1] - lIIIIlIlIlII[2] + lllllllllllllllIlllllIlIlIIIIIIl % lIIIIlIlIlII[1] * lIIIIlIlIlII[3], height / lIIIIlIlIlII[4] + lIIIIlIlIlII[5] * (lllllllllllllllIlllllIlIlIIIIIIl >> lIIIIlIlIlII[6]), lIIIIlIlIlII[7], lIIIIlIlIlII[8], lllllllllllllllIlllllIlIlIIIIIII, null);
      "".length();
    }
    lllllllllllllllIlllllIlIIlllllII++;
    if (llIIllIlIllll(lllllllllllllllIlllllIlIlIIIIIIl % lIIIIlIlIlII[1], lIIIIlIlIlII[6])) {}
    new GuiButton(lIIIIlIlIlII[9], width / lIIIIlIlIlII[1] - lIIIIlIlIlII[10], height / lIIIIlIlIlII[4] + lIIIIlIlIlII[5] * (lllllllllllllllIlllllIlIlIIIIIIl >> lIIIIlIlIlII[6]), I18n.format(lIIIIlIlIIll[lIIIIlIlIlII[6]], new Object[lIIIIlIlIlII[0]]));
    "".length();
  }
  
  public GuiCustomizeSkin(GuiScreen lllllllllllllllIlllllIlIlIIIlIll)
  {
    parentScreen = lllllllllllllllIlllllIlIlIIIlIll;
  }
  
  private static boolean llIIllIlIllll(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIlllllIlIIIlIIIIl;
    return ??? == i;
  }
  
  private static boolean llIIllIllIIIl(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIlllllIlIIIIllIIl;
    return ??? < i;
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllIlllllIlIIlllIIlI)
    throws IOException
  {
    ;
    ;
    ;
    if (llIIllIllIIII(enabled)) {
      if (llIIllIlIllll(id, lIIIIlIlIlII[9]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(parentScreen);
        "".length();
        if (((4 + '£' - -13 + 15 ^ 100 + 70 - 94 + 72) & (0x18 ^ 0x14 ^ 0xF5 ^ 0xAE ^ -" ".length())) == 0) {}
      }
      else if (llIIllIllIIII(lllllllllllllllIlllllIlIIlllIIlI instanceof ButtonPart))
      {
        EnumPlayerModelParts lllllllllllllllIlllllIlIIlllIlII = playerModelParts;
        mc.gameSettings.switchModelPartEnabled(lllllllllllllllIlllllIlIIlllIlII);
        displayString = lllllllllllllllIlllllIlIIlllIllI.func_175358_a(lllllllllllllllIlllllIlIIlllIlII);
      }
    }
  }
  
  private String func_175358_a(EnumPlayerModelParts lllllllllllllllIlllllIlIIlIlllII)
  {
    ;
    ;
    ;
    String lllllllllllllllIlllllIlIIlIllllI;
    if (llIIllIllIIII(mc.gameSettings.getModelParts().contains(lllllllllllllllIlllllIlIIlIlllII)))
    {
      String lllllllllllllllIlllllIlIIlIlllll = I18n.format(lIIIIlIlIIll[lIIIIlIlIlII[1]], new Object[lIIIIlIlIlII[0]]);
      "".length();
      if (null != null) {
        return null;
      }
    }
    else
    {
      lllllllllllllllIlllllIlIIlIllllI = I18n.format(lIIIIlIlIIll[lIIIIlIlIlII[12]], new Object[lIIIIlIlIlII[0]]);
    }
    return String.valueOf(new StringBuilder(String.valueOf(lllllllllllllllIlllllIlIIlIlllII.func_179326_d().getFormattedText())).append(lIIIIlIlIIll[lIIIIlIlIlII[13]]).append(lllllllllllllllIlllllIlIIlIllllI));
  }
  
  private static void llIIllIlIllII()
  {
    lIIIIlIlIIll = new String[lIIIIlIlIlII[14]];
    lIIIIlIlIIll[lIIIIlIlIlII[0]] = llIIllIlIIllI("HwoiPAIeCXgmBhkUFSAeBBU7PB4RDj86A14OPyEBFQ==", "pzVUm");
    lIIIIlIlIIll[lIIIIlIlIlII[6]] = llIIllIlIlIII("kkpAf2YbuYx04j2WJ9QWuA==", "IJrNZ");
    lIIIIlIlIIll[lIIIIlIlIlII[1]] = llIIllIlIIllI("CgQkMywLB341LQ==", "etPZC");
    lIIIIlIlIIll[lIIIIlIlIlII[12]] = llIIllIlIlIll("jz9BipbO1uHMBvP1qFYjCA==", "JMgiF");
    lIIIIlIlIIll[lIIIIlIlIlII[13]] = llIIllIlIIllI("Vks=", "lkdzG");
  }
  
  private static boolean llIIllIllIIII(int ???)
  {
    double lllllllllllllllIlllllIlIIIIlIlll;
    return ??? != 0;
  }
  
  private static boolean llIIllIlIlllI(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIlllllIlIIIIlllIl;
    return ??? >= i;
  }
  
  static
  {
    llIIllIlIllIl();
    llIIllIlIllII();
  }
  
  private static void llIIllIlIllIl()
  {
    lIIIIlIlIlII = new int[16];
    lIIIIlIlIlII[0] = ((57 + 122 - 169 + 119 ^ 43 + 95 - 11 + 15) & (0x31 ^ 0x9 ^ 0x77 ^ 0x40 ^ -" ".length()));
    lIIIIlIlIlII[1] = "  ".length();
    lIIIIlIlIlII[2] = (42 + '' - 76 + 45);
    lIIIIlIlIlII[3] = ((0x44 ^ 0x13) + (78 + 17 - 67 + 117) - (36 + 2 - -50 + 68) + (0x5 ^ 0x51));
    lIIIIlIlIlII[4] = (0x64 ^ 0x62);
    lIIIIlIlIlII[5] = (0x7 ^ 0x33 ^ 0x38 ^ 0x14);
    lIIIIlIlIlII[6] = " ".length();
    lIIIIlIlIlII[7] = ('' + 35 - 98 + 80);
    lIIIIlIlIlII[8] = (110 + 124 - 205 + 145 ^ 124 + '¥' - 185 + 82);
    lIIIIlIlIlII[9] = ('¡' + 118 - 264 + 183 + (0x28 ^ 0x48) - ('»' + 90 - 33 + 5) + (65 + 63 - 73 + 100));
    lIIIIlIlIlII[10] = (0x48 ^ 0x2C);
    lIIIIlIlIlII[11] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIIIIlIlIlII[12] = "   ".length();
    lIIIIlIlIlII[13] = (0x61 ^ 0x65);
    lIIIIlIlIlII[14] = (77 + 65 - 123 + 112 ^ 54 + 2 - 52 + 130);
    lIIIIlIlIlII[15] = (5 + 55 - -79 + 67 ^ '¢' + 25 - 162 + 173);
  }
  
  public void drawScreen(int lllllllllllllllIlllllIlIIllIIlll, int lllllllllllllllIlllllIlIIllIlIlI, float lllllllllllllllIlllllIlIIllIIlIl)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIlllllIlIIllIllII.drawDefaultBackground();
    lllllllllllllllIlllllIlIIllIllII.drawCenteredString(fontRendererObj, title, width / lIIIIlIlIlII[1], lIIIIlIlIlII[8], lIIIIlIlIlII[11]);
    lllllllllllllllIlllllIlIIllIllII.drawScreen(lllllllllllllllIlllllIlIIllIIlll, lllllllllllllllIlllllIlIIllIlIlI, lllllllllllllllIlllllIlIIllIIlIl);
  }
  
  private static String llIIllIlIlIll(String lllllllllllllllIlllllIlIIIlIlIII, String lllllllllllllllIlllllIlIIIlIIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlllllIlIIIlIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIlIIIlIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllllIlIIIlIllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllllIlIIIlIllII.init(lIIIIlIlIlII[1], lllllllllllllllIlllllIlIIIlIllIl);
      return new String(lllllllllllllllIlllllIlIIIlIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIlIIIlIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlllllIlIIIlIlIll)
    {
      lllllllllllllllIlllllIlIIIlIlIll.printStackTrace();
    }
    return null;
  }
  
  private static String llIIllIlIlIII(String lllllllllllllllIlllllIlIIIllIlIl, String lllllllllllllllIlllllIlIIIllIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlllllIlIIIlllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllIlIIIllIllI.getBytes(StandardCharsets.UTF_8)), lIIIIlIlIlII[15]), "DES");
      Cipher lllllllllllllllIlllllIlIIIlllIIl = Cipher.getInstance("DES");
      lllllllllllllllIlllllIlIIIlllIIl.init(lIIIIlIlIlII[1], lllllllllllllllIlllllIlIIIlllIlI);
      return new String(lllllllllllllllIlllllIlIIIlllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllIlIIIllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlllllIlIIIlllIII)
    {
      lllllllllllllllIlllllIlIIIlllIII.printStackTrace();
    }
    return null;
  }
  
  class ButtonPart
    extends GuiButton
  {
    private ButtonPart(int llllllllllllllIIllIllIllIlIllIll, int llllllllllllllIIllIllIllIlIlIIlI, int llllllllllllllIIllIllIllIlIllIIl, int llllllllllllllIIllIllIllIlIlIIII, int llllllllllllllIIllIllIllIlIlIlll, EnumPlayerModelParts llllllllllllllIIllIllIllIlIlIllI)
    {
      llllllllllllllIIllIllIllIlIlIlIl.<init>(llllllllllllllIIllIllIllIlIllIll, llllllllllllllIIllIllIllIlIlIIlI, llllllllllllllIIllIllIllIlIlIIIl, llllllllllllllIIllIllIllIlIlIIII, llllllllllllllIIllIllIllIlIlIlll, GuiCustomizeSkin.this.func_175358_a(llllllllllllllIIllIllIllIlIlIllI));
      playerModelParts = llllllllllllllIIllIllIllIlIlIllI;
    }
  }
}

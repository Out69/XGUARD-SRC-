package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.realms.RealmsSimpleScrolledSelectionList;
import net.minecraft.util.MathHelper;

public class GuiSimpleScrolledSelectionListProxy
  extends GuiSlot
{
  static {}
  
  private static boolean lllIllIIlIII(int ???)
  {
    String lllllllllllllllllIIllllIlIIIIlIl;
    return ??? > 0;
  }
  
  public int getWidth()
  {
    ;
    return width;
  }
  
  private static boolean lllIllIIIlll(int ???)
  {
    short lllllllllllllllllIIllllIlIIIlIll;
    return ??? != 0;
  }
  
  public GuiSimpleScrolledSelectionListProxy(RealmsSimpleScrolledSelectionList lllllllllllllllllIIlllllIIIlllIl, int lllllllllllllllllIIlllllIIIlIIII, int lllllllllllllllllIIlllllIIIIllll, int lllllllllllllllllIIlllllIIIllIII, int lllllllllllllllllIIlllllIIIlIllI, int lllllllllllllllllIIlllllIIIIlIll)
  {
    lllllllllllllllllIIlllllIIIlllll.<init>(Minecraft.getMinecraft(), lllllllllllllllllIIlllllIIIlIIII, lllllllllllllllllIIlllllIIIllIIl, lllllllllllllllllIIlllllIIIllIII, lllllllllllllllllIIlllllIIIlIllI, lllllllllllllllllIIlllllIIIIlIll);
    field_178050_u = lllllllllllllllllIIlllllIIIlllIl;
  }
  
  protected int getSize()
  {
    ;
    return field_178050_u.getItemCount();
  }
  
  protected void drawBackground()
  {
    ;
    field_178050_u.renderBackground();
  }
  
  public void handleMouseInput()
  {
    ;
    lllllllllllllllllIIllllIllIIIIII.handleMouseInput();
  }
  
  protected boolean isSelected(int lllllllllllllllllIIllllIlllIlIIl)
  {
    ;
    ;
    return field_178050_u.isSelectedItem(lllllllllllllllllIIllllIlllIlIIl);
  }
  
  public int getMouseX()
  {
    ;
    return mouseX;
  }
  
  protected int getScrollBarX()
  {
    ;
    return field_178050_u.getScrollbarPosition();
  }
  
  public int getMouseY()
  {
    ;
    return mouseY;
  }
  
  private static void lllIllIIIlIl()
  {
    lIIlIlIlIll = new int[15];
    lIIlIlIlIll[0] = (0x56 ^ 0x18 ^ 0x7A ^ 0x32);
    lIIlIlIlIll[1] = "  ".length();
    lIIlIlIlIll[2] = (0x80 ^ 0x84);
    lIIlIlIlIll[3] = ((0x2B ^ 0x68) & (0xF4 ^ 0xB7 ^ 0xFFFFFFFF));
    lIIlIlIlIll[4] = (126 + 55 - 65 + 139);
    lIIlIlIlIll[5] = (-(0xFDFE & 0x761B) & 0xF7BF & 0x7F5B);
    lIIlIlIlIll[6] = (-(0x967D & 0x6DDF) & 0xEFFF & 0x175F);
    lIIlIlIlIll[7] = " ".length();
    lIIlIlIlIll[8] = (-(0xD66B & 0x6BBF) & 0xFF3B & 0x5FEF);
    lIIlIlIlIll[9] = (0xAF ^ 0x8F);
    lIIlIlIlIll[10] = (0xCF ^ 0xC7);
    lIIlIlIlIll[11] = (14 + 38 - 48 + 137 ^ 85 + 44 - 127 + 136);
    lIIlIlIlIll[12] = (87 + 7 - 75 + 109);
    lIIlIlIlIll[13] = (8 + 45 - -5 + 85 + (5 + 109 - -11 + 3) - (106 + 'ü' - 264 + 159) + ('' + 18 - -4 + 14));
    lIIlIlIlIll[14] = (0xBF8F & 0x5D70);
  }
  
  protected void elementClicked(int lllllllllllllllllIIllllIllllIlll, boolean lllllllllllllllllIIllllIllllIllI, int lllllllllllllllllIIllllIllllIlIl, int lllllllllllllllllIIllllIllllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    field_178050_u.selectItem(lllllllllllllllllIIllllIllllIlll, lllllllllllllllllIIllllIllllIIIl, lllllllllllllllllIIllllIllllIlIl, lllllllllllllllllIIllllIllllIlII);
  }
  
  public void drawScreen(int lllllllllllllllllIIllllIlIllIIII, int lllllllllllllllllIIllllIlIlIIIIl, float lllllllllllllllllIIllllIlIlIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIllIIIlll(field_178041_q))
    {
      mouseX = lllllllllllllllllIIllllIlIllIIII;
      mouseY = lllllllllllllllllIIllllIlIlIIIIl;
      lllllllllllllllllIIllllIlIllIIIl.drawBackground();
      int lllllllllllllllllIIllllIlIlIllIl = lllllllllllllllllIIllllIlIllIIIl.getScrollBarX();
      int lllllllllllllllllIIllllIlIlIllII = lllllllllllllllllIIllllIlIlIllIl + lIIlIlIlIll[0];
      lllllllllllllllllIIllllIlIllIIIl.bindAmountScrolled();
      GlStateManager.disableLighting();
      GlStateManager.disableFog();
      Tessellator lllllllllllllllllIIllllIlIlIlIll = Tessellator.getInstance();
      WorldRenderer lllllllllllllllllIIllllIlIlIlIlI = lllllllllllllllllIIllllIlIlIlIll.getWorldRenderer();
      int lllllllllllllllllIIllllIlIlIlIIl = left + width / lIIlIlIlIll[1] - lllllllllllllllllIIllllIlIllIIIl.getListWidth() / lIIlIlIlIll[1] + lIIlIlIlIll[1];
      int lllllllllllllllllIIllllIlIlIlIII = top + lIIlIlIlIll[2] - (int)amountScrolled;
      if (lllIllIIIlll(hasListHeader)) {
        lllllllllllllllllIIllllIlIllIIIl.drawListHeader(lllllllllllllllllIIllllIlIlIlIIl, lllllllllllllllllIIllllIlIlIlIII, lllllllllllllllllIIllllIlIlIlIll);
      }
      lllllllllllllllllIIllllIlIllIIIl.drawSelectionBox(lllllllllllllllllIIllllIlIlIlIIl, lllllllllllllllllIIllllIlIlIlIII, lllllllllllllllllIIllllIlIllIIII, lllllllllllllllllIIllllIlIlIIIIl);
      GlStateManager.disableDepth();
      int lllllllllllllllllIIllllIlIlIIlll = lIIlIlIlIll[2];
      lllllllllllllllllIIllllIlIllIIIl.overlayBackground(lIIlIlIlIll[3], top, lIIlIlIlIll[4], lIIlIlIlIll[4]);
      lllllllllllllllllIIllllIlIllIIIl.overlayBackground(bottom, height, lIIlIlIlIll[4], lIIlIlIlIll[4]);
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(lIIlIlIlIll[5], lIIlIlIlIll[6], lIIlIlIlIll[3], lIIlIlIlIll[7]);
      GlStateManager.disableAlpha();
      GlStateManager.shadeModel(lIIlIlIlIll[8]);
      GlStateManager.disableTexture2D();
      int lllllllllllllllllIIllllIlIlIIllI = lllllllllllllllllIIllllIlIllIIIl.func_148135_f();
      if (lllIllIIlIII(lllllllllllllllllIIllllIlIlIIllI))
      {
        int lllllllllllllllllIIllllIlIlIIlIl = (bottom - top) * (bottom - top) / lllllllllllllllllIIllllIlIllIIIl.getContentHeight();
        lllllllllllllllllIIllllIlIlIIlIl = MathHelper.clamp_int(lllllllllllllllllIIllllIlIlIIlIl, lIIlIlIlIll[9], bottom - top - lIIlIlIlIll[10]);
        int lllllllllllllllllIIllllIlIlIIlII = (int)amountScrolled * (bottom - top - lllllllllllllllllIIllllIlIlIIlIl) / lllllllllllllllllIIllllIlIlIIllI + top;
        if (lllIllIIlIIl(lllllllllllllllllIIllllIlIlIIlII, top)) {
          lllllllllllllllllIIllllIlIlIIlII = top;
        }
        lllllllllllllllllIIllllIlIlIlIlI.begin(lIIlIlIlIll[11], DefaultVertexFormats.POSITION_TEX_COLOR);
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllIl, bottom, 0.0D).tex(0.0D, 1.0D).color(lIIlIlIlIll[3], lIIlIlIlIll[3], lIIlIlIlIll[3], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllII, bottom, 0.0D).tex(1.0D, 1.0D).color(lIIlIlIlIll[3], lIIlIlIlIll[3], lIIlIlIlIll[3], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllII, top, 0.0D).tex(1.0D, 0.0D).color(lIIlIlIlIll[3], lIIlIlIlIll[3], lIIlIlIlIll[3], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllIl, top, 0.0D).tex(0.0D, 0.0D).color(lIIlIlIlIll[3], lIIlIlIlIll[3], lIIlIlIlIll[3], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIll.draw();
        lllllllllllllllllIIllllIlIlIlIlI.begin(lIIlIlIlIll[11], DefaultVertexFormats.POSITION_TEX_COLOR);
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllIl, lllllllllllllllllIIllllIlIlIIlII + lllllllllllllllllIIllllIlIlIIlIl, 0.0D).tex(0.0D, 1.0D).color(lIIlIlIlIll[12], lIIlIlIlIll[12], lIIlIlIlIll[12], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllII, lllllllllllllllllIIllllIlIlIIlII + lllllllllllllllllIIllllIlIlIIlIl, 0.0D).tex(1.0D, 1.0D).color(lIIlIlIlIll[12], lIIlIlIlIll[12], lIIlIlIlIll[12], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllII, lllllllllllllllllIIllllIlIlIIlII, 0.0D).tex(1.0D, 0.0D).color(lIIlIlIlIll[12], lIIlIlIlIll[12], lIIlIlIlIll[12], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllIl, lllllllllllllllllIIllllIlIlIIlII, 0.0D).tex(0.0D, 0.0D).color(lIIlIlIlIll[12], lIIlIlIlIll[12], lIIlIlIlIll[12], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIll.draw();
        lllllllllllllllllIIllllIlIlIlIlI.begin(lIIlIlIlIll[11], DefaultVertexFormats.POSITION_TEX_COLOR);
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllIl, lllllllllllllllllIIllllIlIlIIlII + lllllllllllllllllIIllllIlIlIIlIl - lIIlIlIlIll[7], 0.0D).tex(0.0D, 1.0D).color(lIIlIlIlIll[13], lIIlIlIlIll[13], lIIlIlIlIll[13], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllII - lIIlIlIlIll[7], lllllllllllllllllIIllllIlIlIIlII + lllllllllllllllllIIllllIlIlIIlIl - lIIlIlIlIll[7], 0.0D).tex(1.0D, 1.0D).color(lIIlIlIlIll[13], lIIlIlIlIll[13], lIIlIlIlIll[13], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllII - lIIlIlIlIll[7], lllllllllllllllllIIllllIlIlIIlII, 0.0D).tex(1.0D, 0.0D).color(lIIlIlIlIll[13], lIIlIlIlIll[13], lIIlIlIlIll[13], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIlI.pos(lllllllllllllllllIIllllIlIlIllIl, lllllllllllllllllIIllllIlIlIIlII, 0.0D).tex(0.0D, 0.0D).color(lIIlIlIlIll[13], lIIlIlIlIll[13], lIIlIlIlIll[13], lIIlIlIlIll[4]).endVertex();
        lllllllllllllllllIIllllIlIlIlIll.draw();
      }
      lllllllllllllllllIIllllIlIllIIIl.func_148142_b(lllllllllllllllllIIllllIlIllIIII, lllllllllllllllllIIllllIlIlIIIIl);
      GlStateManager.enableTexture2D();
      GlStateManager.shadeModel(lIIlIlIlIll[14]);
      GlStateManager.enableAlpha();
      GlStateManager.disableBlend();
    }
  }
  
  protected void drawSlot(int lllllllllllllllllIIllllIllIlllIl, int lllllllllllllllllIIllllIllIlllII, int lllllllllllllllllIIllllIllIlIlII, int lllllllllllllllllIIllllIllIlIIll, int lllllllllllllllllIIllllIllIllIIl, int lllllllllllllllllIIllllIllIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    field_178050_u.renderItem(lllllllllllllllllIIllllIllIlllIl, lllllllllllllllllIIllllIllIlllII, lllllllllllllllllIIllllIllIllIll, lllllllllllllllllIIllllIllIlIIll, lllllllllllllllllIIllllIllIllIIl, lllllllllllllllllIIllllIllIllIII);
  }
  
  private static boolean lllIllIIlIIl(int ???, int arg1)
  {
    int i;
    String lllllllllllllllllIIllllIlIIIllll;
    return ??? < i;
  }
  
  protected int getContentHeight()
  {
    ;
    return field_178050_u.getMaxPosition();
  }
}

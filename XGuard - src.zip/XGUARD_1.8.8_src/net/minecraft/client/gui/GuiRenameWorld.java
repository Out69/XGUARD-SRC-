package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.WorldInfo;
import org.lwjgl.input.Keyboard;

public class GuiRenameWorld
  extends GuiScreen
{
  protected void mouseClicked(int llIIIIllIllIll, int llIIIIllIllIlI, int llIIIIllIllIIl)
    throws IOException
  {
    ;
    ;
    ;
    ;
    llIIIIllIllIII.mouseClicked(llIIIIllIllIll, llIIIIllIllIlI, llIIIIllIllIIl);
    field_146583_f.mouseClicked(llIIIIllIllIll, llIIIIllIllIlI, llIIIIllIllIIl);
  }
  
  public void onGuiClosed()
  {
    Keyboard.enableRepeatEvents(llIIIlIll[1]);
  }
  
  private static boolean lIlIIlIlllI(int ???, int arg1)
  {
    int i;
    short llIIIIlIIlllII;
    return ??? < i;
  }
  
  private static boolean lIlIIlIllIl(int ???, int arg1)
  {
    int i;
    short llIIIIlIIlIIlI;
    return ??? != i;
  }
  
  protected void keyTyped(char llIIIIlllIIIlI, int llIIIIlllIIlII)
    throws IOException
  {
    ;
    ;
    ;
    "".length();
    if (lIlIIlIllII(field_146583_f.getText().trim().length()))
    {
      "".length();
      if (null == null) {
        break label72;
      }
    }
    label72:
    llIIIlIll0enabled = llIIIlIll[1];
    if ((!lIlIIlIllIl(llIIIIlllIIlII, llIIIlIll[11])) || (lIlIIlIlIlI(llIIIIlllIIlII, llIIIlIll[12]))) {
      llIIIIlllIIIll.actionPerformed((GuiButton)buttonList.get(llIIIlIll[1]));
    }
  }
  
  private static String lIlIIlIIIll(String llIIIIlIlllllI, String llIIIIlIlllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llIIIIlIlllllI = new String(Base64.getDecoder().decode(llIIIIlIlllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llIIIIlIllllII = new StringBuilder();
    char[] llIIIIlIlllIll = llIIIIlIlllIII.toCharArray();
    int llIIIIlIlllIlI = llIIIlIll[1];
    float llIIIIlIllIlII = llIIIIlIlllllI.toCharArray();
    Exception llIIIIlIllIIll = llIIIIlIllIlII.length;
    double llIIIIlIllIIlI = llIIIlIll[1];
    while (lIlIIlIlllI(llIIIIlIllIIlI, llIIIIlIllIIll))
    {
      char llIIIIlIllllll = llIIIIlIllIlII[llIIIIlIllIIlI];
      "".length();
      "".length();
      if (-"   ".length() > 0) {
        return null;
      }
    }
    return String.valueOf(llIIIIlIllllII);
  }
  
  private static boolean lIlIIlIlIIl(int ???)
  {
    String llIIIIlIIllIlI;
    return ??? != 0;
  }
  
  private static void lIlIIlIlIII()
  {
    llIIIlIll = new int[17];
    llIIIlIll[0] = " ".length();
    llIIIlIll[1] = ((0xAD ^ 0xB2) & (0x73 ^ 0x6C ^ 0xFFFFFFFF));
    llIIIlIll[2] = "  ".length();
    llIIIlIll[3] = (0x45 ^ 0x21);
    llIIIlIll[4] = (0xA9 ^ 0xAD);
    llIIIlIll[5] = (0xF4 ^ 0x9F ^ 0x32 ^ 0x39);
    llIIIlIll[6] = (0x7F ^ 0x72 ^ " ".length());
    llIIIlIll[7] = (0x18 ^ 0x60);
    llIIIlIll[8] = ('§' + 20 - 162 + 147 ^ 76 + 59 - 91 + 100);
    llIIIlIll[9] = ((0x8F ^ 0xA6) + (0x56 ^ 0x70) - -(0xE5 ^ 0x86) + (0x15 ^ 0x3));
    llIIIlIll[10] = (0x8A ^ 0x9E);
    llIIIlIll[11] = (71 + 68 - 24 + 12 ^ 0x4F ^ 0x2C);
    llIIIlIll[12] = ((0x74 ^ 0xC) + (0x33 ^ 0x69) - ('' + ' ' - 97 + 4) + (29 + 9 - 15 + 122));
    llIIIlIll[13] = (0xFFFFFFFF & 0xFFFFFF);
    llIIIlIll[14] = "   ".length();
    llIIIlIll[15] = (0x31 ^ 0x1E);
    llIIIlIll[16] = (0xAEBB & 0xA0F1E4);
  }
  
  public void updateScreen()
  {
    ;
    field_146583_f.updateCursorCounter();
  }
  
  private static boolean lIlIIlIlIlI(int ???, int arg1)
  {
    int i;
    float llIIIIlIlIIIII;
    return ??? == i;
  }
  
  private static void lIlIIlIIlIl()
  {
    llIIIlIIl = new String[llIIIlIll[4]];
    llIIIlIIl[llIIIlIll[1]] = lIlIIlIIIll("OiYYCyY9FBscKS1tBgsrKC4RLDA9NxsA", "ICtnE");
    llIIIlIIl[llIIIlIll[0]] = lIlIIlIIlII("yHzJsMEyrDdeL58vZklGCw==", "ZRIuE");
    llIIIlIIl[llIIIlIll[2]] = lIlIIlIIIll("MQEOBzQ2Mw0QOyZKEAc5IwkHNj42CAc=", "BdbbW");
    llIIIlIIl[llIIIlIll[14]] = lIlIIlIIlII("uTAunQ1Ahmg498PFi2mtaFnk5kZRJRSb", "xslew");
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    Keyboard.enableRepeatEvents(llIIIlIll[0]);
    buttonList.clear();
    new GuiButton(llIIIlIll[1], width / llIIIlIll[2] - llIIIlIll[3], height / llIIIlIll[4] + llIIIlIll[5] + llIIIlIll[6], I18n.format(llIIIlIIl[llIIIlIll[1]], new Object[llIIIlIll[1]]));
    "".length();
    new GuiButton(llIIIlIll[0], width / llIIIlIll[2] - llIIIlIll[3], height / llIIIlIll[4] + llIIIlIll[7] + llIIIlIll[6], I18n.format(llIIIlIIl[llIIIlIll[0]], new Object[llIIIlIll[1]]));
    "".length();
    ISaveFormat llIIIIlllllIlI = mc.getSaveLoader();
    WorldInfo llIIIIlllllIIl = llIIIIlllllIlI.getWorldInfo(saveName);
    String llIIIIlllllIII = llIIIIlllllIIl.getWorldName();
    field_146583_f = new GuiTextField(llIIIlIll[2], fontRendererObj, width / llIIIlIll[2] - llIIIlIll[3], llIIIlIll[8], llIIIlIll[9], llIIIlIll[10]);
    field_146583_f.setFocused(llIIIlIll[0]);
    field_146583_f.setText(llIIIIlllllIII);
  }
  
  public void drawScreen(int llIIIIllIIlIll, int llIIIIllIIlIlI, float llIIIIllIIlIIl)
  {
    ;
    ;
    ;
    ;
    llIIIIllIlIIII.drawDefaultBackground();
    llIIIIllIlIIII.drawCenteredString(fontRendererObj, I18n.format(llIIIlIIl[llIIIlIll[2]], new Object[llIIIlIll[1]]), width / llIIIlIll[2], llIIIlIll[10], llIIIlIll[13]);
    llIIIIllIlIIII.drawString(fontRendererObj, I18n.format(llIIIlIIl[llIIIlIll[14]], new Object[llIIIlIll[1]]), width / llIIIlIll[2] - llIIIlIll[3], llIIIlIll[15], llIIIlIll[16]);
    field_146583_f.drawTextBox();
    llIIIIllIlIIII.drawScreen(llIIIIllIIlIll, llIIIIllIIlIlI, llIIIIllIIlIIl);
  }
  
  private static boolean lIlIIlIlIll(int ???)
  {
    boolean llIIIIlIIllIII;
    return ??? == 0;
  }
  
  private static String lIlIIlIIlII(String llIIIIlIlIIlll, String llIIIIlIlIIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIIIIlIlIllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llIIIIlIlIIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llIIIIlIlIlIll = Cipher.getInstance("Blowfish");
      llIIIIlIlIlIll.init(llIIIlIll[2], llIIIIlIlIllII);
      return new String(llIIIIlIlIlIll.doFinal(Base64.getDecoder().decode(llIIIIlIlIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIIIIlIlIlIlI)
    {
      llIIIIlIlIlIlI.printStackTrace();
    }
    return null;
  }
  
  protected void actionPerformed(GuiButton llIIIIlllIlIll)
    throws IOException
  {
    ;
    ;
    ;
    if (lIlIIlIlIIl(enabled)) {
      if (lIlIIlIlIlI(id, llIIIlIll[0]))
      {
        mc.displayGuiScreen(parentScreen);
        "".length();
        if ((0xB4 ^ 0xB1 ^ " ".length()) != -" ".length()) {}
      }
      else if (lIlIIlIlIll(id))
      {
        ISaveFormat llIIIIlllIllIl = mc.getSaveLoader();
        llIIIIlllIllIl.renameWorld(saveName, field_146583_f.getText().trim());
        mc.displayGuiScreen(parentScreen);
      }
    }
  }
  
  private static boolean lIlIIlIllII(int ???)
  {
    float llIIIIlIIlIllI;
    return ??? > 0;
  }
  
  public GuiRenameWorld(GuiScreen llIIIlIIIIIlII, String llIIIlIIIIIllI)
  {
    parentScreen = llIIIlIIIIIlll;
    saveName = llIIIlIIIIIllI;
  }
  
  static
  {
    lIlIIlIlIII();
    lIlIIlIIlIl();
  }
}

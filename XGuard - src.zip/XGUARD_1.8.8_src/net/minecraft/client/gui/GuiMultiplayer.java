package net.minecraft.client.gui;

import com.google.common.base.Splitter;
import com.google.common.collect.Lists;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.network.LanServerDetector.LanServer;
import net.minecraft.client.network.LanServerDetector.LanServerList;
import net.minecraft.client.network.LanServerDetector.ThreadLanServerFind;
import net.minecraft.client.network.OldServerPinger;
import net.minecraft.client.resources.I18n;
import org.apache.logging.log4j.Logger;
import org.lwjgl.input.Keyboard;

public class GuiMultiplayer
  extends GuiScreen
  implements GuiYesNoCallback
{
  public void drawScreen(int llllllllllllllIlIlIlIIllIlIIlllI, int llllllllllllllIlIlIlIIllIlIlIIIl, float llllllllllllllIlIlIlIIllIlIIllII)
  {
    ;
    ;
    ;
    ;
    hoveringText = null;
    llllllllllllllIlIlIlIIllIlIlIIll.drawDefaultBackground();
    serverListSelector.drawScreen(llllllllllllllIlIlIlIIllIlIIlllI, llllllllllllllIlIlIlIIllIlIlIIIl, llllllllllllllIlIlIlIIllIlIIllII);
    llllllllllllllIlIlIlIIllIlIlIIll.drawCenteredString(fontRendererObj, I18n.format(llllllllIllI[lIIIIllIIlIll[36]], new Object[lIIIIllIIlIll[1]]), width / lIIIIllIIlIll[6], lIIIIllIIlIll[10], lIIIIllIIlIll[37]);
    llllllllllllllIlIlIlIIllIlIlIIll.drawScreen(llllllllllllllIlIlIlIIllIlIIlllI, llllllllllllllIlIlIlIIllIlIlIIIl, llllllllllllllIlIlIlIIllIlIIllII);
    if (llIIllIllIIllI(hoveringText)) {
      llllllllllllllIlIlIlIIllIlIlIIll.drawHoveringText(Lists.newArrayList(Splitter.on(llllllllIllI[lIIIIllIIlIll[38]]).split(hoveringText)), llllllllllllllIlIlIlIIllIlIIlllI, llllllllllllllIlIlIlIIllIlIlIIIl);
    }
  }
  
  private void connectToServer(ServerData llllllllllllllIlIlIlIIllIIllllll)
  {
    ;
    ;
    mc.displayGuiScreen(new GuiConnecting(llllllllllllllIlIlIlIIllIlIIIIII, mc, llllllllllllllIlIlIlIIllIIllllll));
  }
  
  private static String llIIIIlllIlIlI(String llllllllllllllIlIlIlIIlIllIIlIlI, String llllllllllllllIlIlIlIIlIllIIlIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIlIlIIlIllIIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIlIIlIllIIlIIl.getBytes(StandardCharsets.UTF_8)), lIIIIllIIlIll[18]), "DES");
      Cipher llllllllllllllIlIlIlIIlIllIIllII = Cipher.getInstance("DES");
      llllllllllllllIlIlIlIIlIllIIllII.init(lIIIIllIIlIll[6], llllllllllllllIlIlIlIIlIllIIllIl);
      return new String(llllllllllllllIlIlIlIIlIllIIllII.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIlIIlIllIIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIlIlIIlIllIIlIll)
    {
      llllllllllllllIlIlIlIIlIllIIlIll.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIIllIllIlIlI(int ???)
  {
    double llllllllllllllIlIlIlIIlIlIlIlIII;
    return ??? >= 0;
  }
  
  public void func_175393_b(ServerListEntryNormal llllllllllllllIlIlIlIIlIllllIIIl, int llllllllllllllIlIlIlIIlIllllIIII, boolean llllllllllllllIlIlIlIIlIlllIllll)
  {
    ;
    ;
    ;
    ;
    if (llIIllIllIIlIl(llllllllllllllIlIlIlIIlIlllIllll))
    {
      "".length();
      if ("   ".length() <= "   ".length()) {
        break label49;
      }
    }
    label49:
    int llllllllllllllIlIlIlIIlIlllIlllI = llllllllllllllIlIlIlIIlIlllIllII + lIIIIllIIlIll[0];
    savedServerList.swapServers(llllllllllllllIlIlIlIIlIlllIllII, llllllllllllllIlIlIlIIlIlllIlllI);
    if (llIIllIllIlIII(serverListSelector.func_148193_k(), llllllllllllllIlIlIlIIlIlllIllII)) {
      llllllllllllllIlIlIlIIlIllllIIlI.selectServer(llllllllllllllIlIlIlIIlIlllIlllI);
    }
    serverListSelector.func_148195_a(savedServerList);
  }
  
  private void refreshServerList()
  {
    ;
    mc.displayGuiScreen(new GuiMultiplayer(parentScreen));
  }
  
  protected void keyTyped(char llllllllllllllIlIlIlIIllIlIllIll, int llllllllllllllIlIlIlIIllIlIlllll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIlIlIIllIlIllllI = serverListSelector.func_148193_k();
    if (llIIllIllIIlll(llllllllllllllIlIlIlIIllIlIllllI))
    {
      "".length();
      if ("   ".length() > "  ".length()) {
        break label46;
      }
    }
    label46:
    GuiListExtended.IGuiListEntry llllllllllllllIlIlIlIIllIlIlllIl = serverListSelector.getListEntry(llllllllllllllIlIlIlIIllIlIllllI);
    if (llIIllIllIlIII(llllllllllllllIlIlIlIIllIlIlllll, lIIIIllIIlIll[32]))
    {
      llllllllllllllIlIlIlIIllIllIIIIl.refreshServerList();
      "".length();
      if ((0x63 ^ 0x67) != -" ".length()) {}
    }
    else if (llIIllIllIlIlI(llllllllllllllIlIlIlIIllIlIllllI))
    {
      if (llIIllIllIlIII(llllllllllllllIlIlIlIIllIlIlllll, lIIIIllIIlIll[33]))
      {
        if (llIIllIllIIlIl(isShiftKeyDown()))
        {
          if ((llIIllIllIlIll(llllllllllllllIlIlIlIIllIlIllllI)) && (llIIllIllIIlIl(llllllllllllllIlIlIlIIllIlIlllIl instanceof ServerListEntryNormal)))
          {
            savedServerList.swapServers(llllllllllllllIlIlIlIIllIlIllllI, llllllllllllllIlIlIlIIllIlIllllI - lIIIIllIIlIll[0]);
            llllllllllllllIlIlIlIIllIllIIIIl.selectServer(serverListSelector.func_148193_k() - lIIIIllIIlIll[0]);
            serverListSelector.scrollBy(-serverListSelector.getSlotHeight());
            serverListSelector.func_148195_a(savedServerList);
            "".length();
            if (-"  ".length() < 0) {}
          }
        }
        else if (llIIllIllIlIll(llllllllllllllIlIlIlIIllIlIllllI))
        {
          llllllllllllllIlIlIlIIllIllIIIIl.selectServer(serverListSelector.func_148193_k() - lIIIIllIIlIll[0]);
          serverListSelector.scrollBy(-serverListSelector.getSlotHeight());
          if (llIIllIllIIlIl(serverListSelector.getListEntry(serverListSelector.func_148193_k()) instanceof ServerListEntryLanScan)) {
            if (llIIllIllIlIll(serverListSelector.func_148193_k()))
            {
              llllllllllllllIlIlIlIIllIllIIIIl.selectServer(serverListSelector.getSize() - lIIIIllIIlIll[0]);
              serverListSelector.scrollBy(-serverListSelector.getSlotHeight());
              "".length();
              if (-" ".length() < 0) {}
            }
            else
            {
              llllllllllllllIlIlIlIIllIllIIIIl.selectServer(lIIIIllIIlIll[31]);
              "".length();
              if (((0x67 ^ 0x7E ^ 0xE ^ 0x45) & (0xE2 ^ 0xA9 ^ 0x33 ^ 0x2A ^ -" ".length())) == 0) {}
            }
          }
        }
        else
        {
          llllllllllllllIlIlIlIIllIllIIIIl.selectServer(lIIIIllIIlIll[31]);
          "".length();
          if (((0x3C ^ 0x64 ^ 0x2D ^ 0x3C) & (0x27 ^ 0x17 ^ 0xB8 ^ 0xC1 ^ -" ".length())) < "  ".length()) {}
        }
      }
      else if (llIIllIllIlIII(llllllllllllllIlIlIlIIllIlIlllll, lIIIIllIIlIll[34]))
      {
        if (llIIllIllIIlIl(isShiftKeyDown()))
        {
          if (llIIllIllIllII(llllllllllllllIlIlIlIIllIlIllllI, savedServerList.countServers() - lIIIIllIIlIll[0]))
          {
            savedServerList.swapServers(llllllllllllllIlIlIlIIllIlIllllI, llllllllllllllIlIlIlIIllIlIllllI + lIIIIllIIlIll[0]);
            llllllllllllllIlIlIlIIllIllIIIIl.selectServer(llllllllllllllIlIlIlIIllIlIllllI + lIIIIllIIlIll[0]);
            serverListSelector.scrollBy(serverListSelector.getSlotHeight());
            serverListSelector.func_148195_a(savedServerList);
            "".length();
            if ("   ".length() == "   ".length()) {}
          }
        }
        else if (llIIllIllIllII(llllllllllllllIlIlIlIIllIlIllllI, serverListSelector.getSize()))
        {
          llllllllllllllIlIlIlIIllIllIIIIl.selectServer(serverListSelector.func_148193_k() + lIIIIllIIlIll[0]);
          serverListSelector.scrollBy(serverListSelector.getSlotHeight());
          if (llIIllIllIIlIl(serverListSelector.getListEntry(serverListSelector.func_148193_k()) instanceof ServerListEntryLanScan)) {
            if (llIIllIllIllII(serverListSelector.func_148193_k(), serverListSelector.getSize() - lIIIIllIIlIll[0]))
            {
              llllllllllllllIlIlIlIIllIllIIIIl.selectServer(serverListSelector.getSize() + lIIIIllIIlIll[0]);
              serverListSelector.scrollBy(serverListSelector.getSlotHeight());
              "".length();
              if ((0x2D ^ 0x28) != 0) {}
            }
            else
            {
              llllllllllllllIlIlIlIIllIllIIIIl.selectServer(lIIIIllIIlIll[31]);
              "".length();
              if ((('Ñ' + 113 - 247 + 176 ^ 117 + 34 - 126 + 136) & (0x30 ^ 0x3A ^ 0x56 ^ 0x6 ^ -" ".length())) == 0) {}
            }
          }
        }
        else
        {
          llllllllllllllIlIlIlIIllIllIIIIl.selectServer(lIIIIllIIlIll[31]);
          "".length();
          if (null == null) {}
        }
      }
      else if ((llIIllIllIllll(llllllllllllllIlIlIlIIllIlIlllll, lIIIIllIIlIll[8])) && (llIIllIllIllll(llllllllllllllIlIlIlIIllIlIlllll, lIIIIllIIlIll[35])))
      {
        llllllllllllllIlIlIlIIllIllIIIIl.keyTyped(llllllllllllllIlIlIlIIllIllIIIII, llllllllllllllIlIlIlIIllIlIlllll);
        "".length();
        if (" ".length() >= 0) {}
      }
      else
      {
        llllllllllllllIlIlIlIIllIllIIIIl.actionPerformed((GuiButton)buttonList.get(lIIIIllIIlIll[6]));
        "".length();
        if (null == null) {}
      }
    }
    else
    {
      llllllllllllllIlIlIlIIllIllIIIIl.keyTyped(llllllllllllllIlIlIlIIllIllIIIII, llllllllllllllIlIlIlIIllIlIlllll);
    }
  }
  
  public ServerList getServerList()
  {
    ;
    return savedServerList;
  }
  
  private static boolean llIIllIllIlIII(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlIlIlIIlIlIllIlII;
    return ??? == i;
  }
  
  public void confirmClicked(boolean llllllllllllllIlIlIlIIllIllIlIIl, int llllllllllllllIlIlIlIIllIllIllIl)
  {
    ;
    ;
    ;
    ;
    if (llIIllIllIIlll(serverListSelector.func_148193_k()))
    {
      "".length();
      if (-" ".length() <= 0) {
        break label45;
      }
    }
    label45:
    GuiListExtended.IGuiListEntry llllllllllllllIlIlIlIIllIllIllII = serverListSelector.getListEntry(serverListSelector.func_148193_k());
    if (llIIllIllIIlIl(deletingServer))
    {
      deletingServer = lIIIIllIIlIll[1];
      if ((llIIllIllIIlIl(llllllllllllllIlIlIlIIllIllIlllI)) && (llIIllIllIIlIl(llllllllllllllIlIlIlIIllIllIllII instanceof ServerListEntryNormal)))
      {
        savedServerList.removeServerData(serverListSelector.func_148193_k());
        savedServerList.saveServerList();
        serverListSelector.setSelectedSlotIndex(lIIIIllIIlIll[31]);
        serverListSelector.func_148195_a(savedServerList);
      }
      mc.displayGuiScreen(llllllllllllllIlIlIlIIllIllIllll);
      "".length();
      if ((0x9 ^ 0x33 ^ 0xA4 ^ 0x9B) > 0) {}
    }
    else if (llIIllIllIIlIl(directConnect))
    {
      directConnect = lIIIIllIIlIll[1];
      if (llIIllIllIIlIl(llllllllllllllIlIlIlIIllIllIlllI))
      {
        llllllllllllllIlIlIlIIllIllIllll.connectToServer(selectedServer);
        "".length();
        if (-(0xC0 ^ 0xC5) < 0) {}
      }
      else
      {
        mc.displayGuiScreen(llllllllllllllIlIlIlIIllIllIllll);
        "".length();
        if ((("   ".length() ^ 0x95 ^ 0x91) & (75 + 34 - 67 + 106 ^ 23 + 102 - 17 + 39 ^ -" ".length())) == 0) {}
      }
    }
    else if (llIIllIllIIlIl(addingServer))
    {
      addingServer = lIIIIllIIlIll[1];
      if (llIIllIllIIlIl(llllllllllllllIlIlIlIIllIllIlllI))
      {
        savedServerList.addServerData(selectedServer);
        savedServerList.saveServerList();
        serverListSelector.setSelectedSlotIndex(lIIIIllIIlIll[31]);
        serverListSelector.func_148195_a(savedServerList);
      }
      mc.displayGuiScreen(llllllllllllllIlIlIlIIllIllIllll);
      "".length();
      if ("  ".length() <= (0x69 ^ 0x23 ^ 0xE9 ^ 0xA7)) {}
    }
    else if (llIIllIllIIlIl(editingServer))
    {
      editingServer = lIIIIllIIlIll[1];
      if ((llIIllIllIIlIl(llllllllllllllIlIlIlIIllIllIlllI)) && (llIIllIllIIlIl(llllllllllllllIlIlIlIIllIllIllII instanceof ServerListEntryNormal)))
      {
        ServerData llllllllllllllIlIlIlIIllIllIlIll = ((ServerListEntryNormal)llllllllllllllIlIlIlIIllIllIllII).getServerData();
        serverName = selectedServer.serverName;
        serverIP = selectedServer.serverIP;
        llllllllllllllIlIlIlIIllIllIlIll.copyFrom(selectedServer);
        savedServerList.saveServerList();
        serverListSelector.func_148195_a(savedServerList);
      }
      mc.displayGuiScreen(llllllllllllllIlIlIlIIllIllIllll);
    }
  }
  
  private static boolean llIIllIllIllII(int ???, int arg1)
  {
    int i;
    char llllllllllllllIlIlIlIIlIlIllIIII;
    return ??? < i;
  }
  
  static
  {
    llIIllIllIIIIl();
    llIIllIlIlIIII();
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIlIlIlIIllIllllllI)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIllIllIIlIl(enabled))
    {
      if (llIIllIllIIlll(serverListSelector.func_148193_k()))
      {
        "".length();
        if (" ".length() != (0xA2 ^ 0xA6)) {
          break label61;
        }
      }
      label61:
      GuiListExtended.IGuiListEntry llllllllllllllIlIlIlIIlllIIIIlll = serverListSelector.getListEntry(serverListSelector.func_148193_k());
      if ((llIIllIllIlIII(id, lIIIIllIIlIll[6])) && (llIIllIllIIlIl(llllllllllllllIlIlIlIIlllIIIIlll instanceof ServerListEntryNormal)))
      {
        String llllllllllllllIlIlIlIIlllIIIIllI = getServerDataserverName;
        if (llIIllIllIIllI(llllllllllllllIlIlIlIIlllIIIIllI))
        {
          deletingServer = lIIIIllIIlIll[0];
          String llllllllllllllIlIlIlIIlllIIIIlIl = I18n.format(llllllllIllI[lIIIIllIIlIll[18]], new Object[lIIIIllIIlIll[1]]);
          String llllllllllllllIlIlIlIIlllIIIIlII = String.valueOf(new StringBuilder(llllllllIllI[lIIIIllIIlIll[22]]).append(llllllllllllllIlIlIlIIlllIIIIllI).append(llllllllIllI[lIIIIllIIlIll[23]]).append(I18n.format(llllllllIllI[lIIIIllIIlIll[24]], new Object[lIIIIllIIlIll[1]])));
          String llllllllllllllIlIlIlIIlllIIIIIll = I18n.format(llllllllIllI[lIIIIllIIlIll[25]], new Object[lIIIIllIIlIll[1]]);
          String llllllllllllllIlIlIlIIlllIIIIIlI = I18n.format(llllllllIllI[lIIIIllIIlIll[26]], new Object[lIIIIllIIlIll[1]]);
          GuiYesNo llllllllllllllIlIlIlIIlllIIIIIIl = new GuiYesNo(llllllllllllllIlIlIlIIllIlllllll, llllllllllllllIlIlIlIIlllIIIIlIl, llllllllllllllIlIlIlIIlllIIIIlII, llllllllllllllIlIlIlIIlllIIIIIll, llllllllllllllIlIlIlIIlllIIIIIlI, serverListSelector.func_148193_k());
          mc.displayGuiScreen(llllllllllllllIlIlIlIIlllIIIIIIl);
          "".length();
          if (" ".length() != 0) {}
        }
      }
      else if (llIIllIllIlIII(id, lIIIIllIIlIll[0]))
      {
        llllllllllllllIlIlIlIIllIlllllll.connectToSelected();
        "".length();
        if (-" ".length() < "   ".length()) {}
      }
      else if (llIIllIllIlIII(id, lIIIIllIIlIll[15]))
      {
        directConnect = lIIIIllIIlIll[0];
        mc.displayGuiScreen(new GuiScreenServerList(llllllllllllllIlIlIlIIllIlllllll, llllllllllllllIlIlIlIIllIlllllll.selectedServer = new ServerData(I18n.format(llllllllIllI[lIIIIllIIlIll[27]], new Object[lIIIIllIIlIll[1]]), llllllllIllI[lIIIIllIIlIll[28]], lIIIIllIIlIll[1])));
        "".length();
        if (null == null) {}
      }
      else if (llIIllIllIlIII(id, lIIIIllIIlIll[14]))
      {
        addingServer = lIIIIllIIlIll[0];
        mc.displayGuiScreen(new GuiScreenAddServer(llllllllllllllIlIlIlIIllIlllllll, llllllllllllllIlIlIlIIllIlllllll.selectedServer = new ServerData(I18n.format(llllllllIllI[lIIIIllIIlIll[29]], new Object[lIIIIllIIlIll[1]]), llllllllIllI[lIIIIllIIlIll[30]], lIIIIllIIlIll[1])));
        "".length();
        if (((0xF9 ^ 0xAB) & (0xE7 ^ 0xB5 ^ 0xFFFFFFFF)) != (0xC4 ^ 0xC0)) {}
      }
      else if ((llIIllIllIlIII(id, lIIIIllIIlIll[5])) && (llIIllIllIIlIl(llllllllllllllIlIlIlIIlllIIIIlll instanceof ServerListEntryNormal)))
      {
        editingServer = lIIIIllIIlIll[0];
        ServerData llllllllllllllIlIlIlIIlllIIIIIII = ((ServerListEntryNormal)llllllllllllllIlIlIlIIlllIIIIlll).getServerData();
        selectedServer = new ServerData(serverName, serverIP, lIIIIllIIlIll[1]);
        selectedServer.copyFrom(llllllllllllllIlIlIlIIlllIIIIIII);
        mc.displayGuiScreen(new GuiScreenAddServer(llllllllllllllIlIlIlIIllIlllllll, selectedServer));
        "".length();
        if ("   ".length() >= "  ".length()) {}
      }
      else if (llIIllIllIIIlI(id))
      {
        mc.displayGuiScreen(parentScreen);
        "".length();
        if ("  ".length() > " ".length()) {}
      }
      else if (llIIllIllIlIII(id, lIIIIllIIlIll[18]))
      {
        llllllllllllllIlIlIlIIllIlllllll.refreshServerList();
      }
    }
  }
  
  protected void mouseClicked(int llllllllllllllIlIlIlIIllIIlIIlIl, int llllllllllllllIlIlIlIIllIIlIIlII, int llllllllllllllIlIlIlIIllIIlIIIll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    llllllllllllllIlIlIlIIllIIlIIIlI.mouseClicked(llllllllllllllIlIlIlIIllIIlIIlIl, llllllllllllllIlIlIlIIllIIlIIlII, llllllllllllllIlIlIlIIllIIlIIIll);
    "".length();
  }
  
  public void onGuiClosed()
  {
    ;
    Keyboard.enableRepeatEvents(lIIIIllIIlIll[1]);
    if (llIIllIllIIllI(lanServerDetector))
    {
      lanServerDetector.interrupt();
      lanServerDetector = null;
    }
    oldServerPinger.clearPendingNetworks();
  }
  
  private static void llIIllIllIIIIl()
  {
    lIIIIllIIlIll = new int[39];
    lIIIIllIIlIll[0] = " ".length();
    lIIIIllIIlIll[1] = ((0x5B ^ 0x18 ^ 0x54 ^ 0x5B) & (52 + 14 - 17 + 88 ^ 119 + 81 - 151 + 148 ^ -" ".length()));
    lIIIIllIIlIll[2] = (0x29 ^ 0x9);
    lIIIIllIIlIll[3] = (31 + 7 - 65379 + 27 ^ 83 + 121 - 190 + 144);
    lIIIIllIIlIll[4] = (0x5A ^ 0x7E);
    lIIIIllIIlIll[5] = (0x8 ^ 0x37 ^ 0x79 ^ 0x41);
    lIIIIllIIlIll[6] = "  ".length();
    lIIIIllIIlIll[7] = (7 + 68 - 50 + 129);
    lIIIIllIIlIll[8] = (0x6E ^ 0x72);
    lIIIIllIIlIll[9] = (0x3F ^ 0x79);
    lIIIIllIIlIll[10] = (0x3D ^ 0x29);
    lIIIIllIIlIll[11] = (0x8F ^ 0xBC ^ 0x5D ^ 0x24);
    lIIIIllIIlIll[12] = (0xF2 ^ 0xC6);
    lIIIIllIIlIll[13] = (0x4 ^ 0x4D ^ 0x43 ^ 0x6E);
    lIIIIllIIlIll[14] = "   ".length();
    lIIIIllIIlIll[15] = (0x70 ^ 0x74);
    lIIIIllIIlIll[16] = (0x65 ^ 0x57);
    lIIIIllIIlIll[17] = (0xAF ^ 0xAA);
    lIIIIllIIlIll[18] = (0x6 ^ 0xE);
    lIIIIllIIlIll[19] = (0xA7 ^ 0xA1);
    lIIIIllIIlIll[20] = (96 + 114 - 83 + 0 ^ 0x32 ^ 0x1);
    lIIIIllIIlIll[21] = (0x31 ^ 0x27 ^ 0xD3 ^ 0x8E);
    lIIIIllIIlIll[22] = ('' + 108 - 115 + 37 ^ 49 + 2 - 32 + 141);
    lIIIIllIIlIll[23] = ('' + 12 - 114 + 120 ^ 40 + 9 - -96 + 3);
    lIIIIllIIlIll[24] = (34 + 117 - 52 + 57 ^ 4 + 126 - -21 + 0);
    lIIIIllIIlIll[25] = (75 + 67 - 31 + 33 ^ 11 + 14 - -85 + 46);
    lIIIIllIIlIll[26] = (118 + 82 - 183 + 124 ^ 51 + 14 - -4 + 59);
    lIIIIllIIlIll[27] = (0x5D ^ 0x53);
    lIIIIllIIlIll[28] = (0x4C ^ 0x43);
    lIIIIllIIlIll[29] = (0x35 ^ 0x25);
    lIIIIllIIlIll[30] = (35 + '¿' - 18 + 1 ^ 30 + 3 - 65394 + 17);
    lIIIIllIIlIll[31] = (-" ".length());
    lIIIIllIIlIll[32] = (0xC ^ 0x33);
    lIIIIllIIlIll[33] = (20 + 56 - 17 + 141);
    lIIIIllIIlIll[34] = ((0xCD ^ 0xA4) + (62 + 24 - 9 + 92) - (0xD30F & 0x2DFF) + (43 + 15 - -2 + 145));
    lIIIIllIIlIll[35] = (76 + 115 - 183 + 148);
    lIIIIllIIlIll[36] = (0x9D ^ 0xA7 ^ 0x37 ^ 0x1F);
    lIIIIllIIlIll[37] = (0xFFFFFFFF & 0xFFFFFF);
    lIIIIllIIlIll[38] = (0x8D ^ 0x9E);
  }
  
  public void connectToSelected()
  {
    ;
    ;
    ;
    if (llIIllIllIIlll(serverListSelector.func_148193_k()))
    {
      "".length();
      if (-(0x32 ^ 0x36) <= 0) {
        break label44;
      }
    }
    label44:
    GuiListExtended.IGuiListEntry llllllllllllllIlIlIlIIllIlIIIlll = serverListSelector.getListEntry(serverListSelector.func_148193_k());
    if (llIIllIllIIlIl(llllllllllllllIlIlIlIIllIlIIIlll instanceof ServerListEntryNormal))
    {
      llllllllllllllIlIlIlIIllIlIIlIII.connectToServer(((ServerListEntryNormal)llllllllllllllIlIlIlIIllIlIIIlll).getServerData());
      "".length();
      if ((0x29 ^ 0x2D) > 0) {}
    }
    else if (llIIllIllIIlIl(llllllllllllllIlIlIlIIllIlIIIlll instanceof ServerListEntryLanDetected))
    {
      LanServerDetector.LanServer llllllllllllllIlIlIlIIllIlIIIllI = ((ServerListEntryLanDetected)llllllllllllllIlIlIlIIllIlIIIlll).getLanServer();
      llllllllllllllIlIlIlIIllIlIIlIII.connectToServer(new ServerData(llllllllllllllIlIlIlIIllIlIIIllI.getServerMotd(), llllllllllllllIlIlIlIIllIlIIIllI.getServerIpPort(), lIIIIllIIlIll[0]));
    }
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    llllllllllllllIlIlIlIIlllIIlllll.handleMouseInput();
    serverListSelector.handleMouseInput();
  }
  
  private static boolean llIIllIllIIlIl(int ???)
  {
    boolean llllllllllllllIlIlIlIIlIlIlIllII;
    return ??? != 0;
  }
  
  private static boolean llIIllIllIIllI(Object ???)
  {
    Exception llllllllllllllIlIlIlIIlIlIlIlllI;
    return ??? != null;
  }
  
  public boolean func_175392_a(ServerListEntryNormal llllllllllllllIlIlIlIIllIIIIllIl, int llllllllllllllIlIlIlIIllIIIIllII)
  {
    ;
    if (llIIllIllIlIll(llllllllllllllIlIlIlIIllIIIIllII)) {
      return lIIIIllIIlIll[0];
    }
    return lIIIIllIIlIll[1];
  }
  
  public void selectServer(int llllllllllllllIlIlIlIIllIIlllIII)
  {
    ;
    ;
    ;
    serverListSelector.setSelectedSlotIndex(llllllllllllllIlIlIlIIllIIlllIII);
    if (llIIllIllIIlll(llllllllllllllIlIlIlIIllIIlllIII))
    {
      "".length();
      if ((55 + 0 - -4 + 71 ^ 87 + 31 - 2 + 18) == (0x1B ^ 0x6C ^ 0xE0 ^ 0x93)) {
        break label68;
      }
    }
    label68:
    GuiListExtended.IGuiListEntry llllllllllllllIlIlIlIIllIIllIlll = serverListSelector.getListEntry(llllllllllllllIlIlIlIIllIIlllIII);
    btnSelectServer.enabled = lIIIIllIIlIll[1];
    btnEditServer.enabled = lIIIIllIIlIll[1];
    btnDeleteServer.enabled = lIIIIllIIlIll[1];
    if ((llIIllIllIIllI(llllllllllllllIlIlIlIIllIIllIlll)) && (llIIllIllIIIlI(llllllllllllllIlIlIlIIllIIllIlll instanceof ServerListEntryLanScan)))
    {
      btnSelectServer.enabled = lIIIIllIIlIll[0];
      if (llIIllIllIIlIl(llllllllllllllIlIlIlIIllIIllIlll instanceof ServerListEntryNormal))
      {
        btnEditServer.enabled = lIIIIllIIlIll[0];
        btnDeleteServer.enabled = lIIIIllIIlIll[0];
      }
    }
  }
  
  public OldServerPinger getOldServerPinger()
  {
    ;
    return oldServerPinger;
  }
  
  private static boolean llIIllIllIIlll(int ???)
  {
    short llllllllllllllIlIlIlIIlIlIlIIllI;
    return ??? < 0;
  }
  
  public void func_175391_a(ServerListEntryNormal llllllllllllllIlIlIlIIlIlllllllI, int llllllllllllllIlIlIlIIlIllllllIl, boolean llllllllllllllIlIlIlIIlIllllllII)
  {
    ;
    ;
    ;
    ;
    if (llIIllIllIIlIl(llllllllllllllIlIlIlIIlIllllllII))
    {
      "".length();
      if (" ".length() >= 0) {
        break label35;
      }
    }
    label35:
    int llllllllllllllIlIlIlIIlIlllllIll = llllllllllllllIlIlIlIIlIlllllIIl - lIIIIllIIlIll[0];
    savedServerList.swapServers(llllllllllllllIlIlIlIIlIlllllIIl, llllllllllllllIlIlIlIIlIlllllIll);
    if (llIIllIllIlIII(serverListSelector.func_148193_k(), llllllllllllllIlIlIlIIlIlllllIIl)) {
      llllllllllllllIlIlIlIIlIlllllIlI.selectServer(llllllllllllllIlIlIlIIlIlllllIll);
    }
    serverListSelector.func_148195_a(savedServerList);
  }
  
  private static String llIIIIlllIllII(String llllllllllllllIlIlIlIIlIlIllllIl, String llllllllllllllIlIlIlIIlIlIllllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIlIlIIlIllIIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIlIIlIlIllllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIlIlIIlIlIllllll = Cipher.getInstance("Blowfish");
      llllllllllllllIlIlIlIIlIlIllllll.init(lIIIIllIIlIll[6], llllllllllllllIlIlIlIIlIllIIIIII);
      return new String(llllllllllllllIlIlIlIIlIlIllllll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIlIIlIlIllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIlIlIIlIlIlllllI)
    {
      llllllllllllllIlIlIlIIlIlIlllllI.printStackTrace();
    }
    return null;
  }
  
  private static void llIIllIlIlIIII()
  {
    llllllllIllI = new String[lIIIIllIIlIll[10]];
    llllllllIllI[lIIIIllIIlIll[1]] = llIIIIlllIlIlI("yHPpme54L62XcZi2pvxjY6VJW4AycbWjSw7cOVTbnvdqxN6JOtAUgQ==", "yHKHW");
    llllllllIllI[lIIIIllIIlIll[0]] = llIIIIlllIlIlI("f/AsDLU9fEufW2DtaWmK7kO32kewWZo5", "CskOt");
    llllllllIllI[lIIIIllIIlIll[6]] = llIIIIlllIllII("b2AvA3eNS+2G+FdNIUlTxIgMDHq753Ye", "ZfBXS");
    llllllllIllI[lIIIIllIIlIll[14]] = llIIIIlllIlIlI("8vJ0qwugaZKOpIP1tREm3rDmxiwl+zpP", "KnyVH");
    llllllllIllI[lIIIIllIIlIll[15]] = llIIIIlllIllII("UmdGkC9YPAmY+T8a19U4phwWmiuNdJiQ", "tWGaK");
    llllllllIllI[lIIIIllIIlIll[17]] = llIIIIlllIllII("gXA2H0PGM3aXl5xL0l+cWIB3M2+RYCit", "oGNdr");
    llllllllIllI[lIIIIllIIlIll[19]] = llIIIIlllIlllI("OQ4jHCE+OCoLNC8ZYQsnLBkqCio=", "JkOyB");
    llllllllIllI[lIIIIllIIlIll[5]] = llIIIIlllIlIlI("oR82dH8KfpxPpXJBdwsSfw==", "KkibO");
    llllllllIllI[lIIIIllIIlIll[18]] = llIIIIlllIlIlI("TQTJYBta+PfZQqcOPhRwZ+OO+VuQkO+pjzJGzsVDCTs=", "tEMsf");
    llllllllIllI[lIIIIllIIlIll[22]] = llIIIIlllIllII("I+pFYMmlMu0=", "rAwNI");
    llllllllIllI[lIIIIllIIlIll[23]] = llIIIIlllIlIlI("sGGRArUp3h0=", "qqXzc");
    llllllllIllI[lIIIIllIIlIll[24]] = llIIIIlllIllII("d06uHFbNT88fdrozTFsG8A6306CtdvfPZ1Hv61U8poI=", "lzDlN");
    llllllllIllI[lIIIIllIIlIll[25]] = llIIIIlllIlIlI("tQrAEz1kA1nT8eNSNhue+rBt3wS8ZxBzFCKM2vfFR6Q=", "irQwm");
    llllllllIllI[lIIIIllIIlIll[26]] = llIIIIlllIlIlI("rrxHZRj8jhV4MwzqDNGSPw==", "gHQGb");
    llllllllIllI[lIIIIllIIlIll[27]] = llIIIIlllIlIlI("pKind6CSH20ZgoURulKWhpmFaPDD3P1AUV/mGHPl/3Y=", "avTPe");
    llllllllIllI[lIIIIllIIlIll[28]] = llIIIIlllIllII("AbelBylgsLI=", "ZmADn");
    llllllllIllI[lIIIIllIIlIll[29]] = llIIIIlllIlllI("MRQiBjE2IisRJCcDYAc3JBA7DyYMECMG", "BqNcR");
    llllllllIllI[lIIIIllIIlIll[30]] = llIIIIlllIllII("jZe7A9mXbcA=", "quYmF");
    llllllllIllI[lIIIIllIIlIll[36]] = llIIIIlllIlllI("DjYrLQETLyYgDRFtMzAcDyY=", "cCGYh");
    llllllllIllI[lIIIIllIIlIll[38]] = llIIIIlllIlllI("WQ==", "SECsl");
  }
  
  public void setHoveringText(String llllllllllllllIlIlIlIIllIIlIllIl)
  {
    ;
    ;
    hoveringText = llllllllllllllIlIlIlIIllIIlIllIl;
  }
  
  private static boolean llIIllIllIllll(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlIlIlIIlIlIlIIIII;
    return ??? != i;
  }
  
  public void initGui()
  {
    ;
    ;
    Keyboard.enableRepeatEvents(lIIIIllIIlIll[0]);
    buttonList.clear();
    if (llIIllIllIIIlI(initialized))
    {
      initialized = lIIIIllIIlIll[0];
      savedServerList = new ServerList(mc);
      savedServerList.loadServerList();
      lanServerList = new LanServerDetector.LanServerList();
      try
      {
        lanServerDetector = new LanServerDetector.ThreadLanServerFind(lanServerList);
        lanServerDetector.start();
        "".length();
        if ((0xB2 ^ 0xB6) < (0x2C ^ 0x28)) {
          return;
        }
      }
      catch (Exception llllllllllllllIlIlIlIIlllIlIIlII)
      {
        logger.warn(String.valueOf(new StringBuilder(llllllllIllI[lIIIIllIIlIll[1]]).append(llllllllllllllIlIlIlIIlllIlIIlII.getMessage())));
        serverListSelector = new ServerSelectionList(llllllllllllllIlIlIlIIlllIlIIlIl, mc, width, height, lIIIIllIIlIll[2], height - lIIIIllIIlIll[3], lIIIIllIIlIll[4]);
        serverListSelector.func_148195_a(savedServerList);
        "".length();
        if (null == null) {
          break label244;
        }
      }
      return;
    }
    serverListSelector.setDimensions(width, height, lIIIIllIIlIll[2], height - lIIIIllIIlIll[3]);
    label244:
    llllllllllllllIlIlIlIIlllIlIIlIl.createButtons();
  }
  
  public boolean func_175394_b(ServerListEntryNormal llllllllllllllIlIlIlIIllIIIIIlll, int llllllllllllllIlIlIlIIllIIIIIllI)
  {
    ;
    ;
    if (llIIllIllIllII(llllllllllllllIlIlIlIIllIIIIIllI, savedServerList.countServers() - lIIIIllIIlIll[0])) {
      return lIIIIllIIlIll[0];
    }
    return lIIIIllIIlIll[1];
  }
  
  private static String llIIIIlllIlllI(String llllllllllllllIlIlIlIIlIllIlllll, String llllllllllllllIlIlIlIIlIllIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIlIlIIlIllIlllll = new String(Base64.getDecoder().decode(llllllllllllllIlIlIlIIlIllIlllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIlIlIIlIllIlllIl = new StringBuilder();
    char[] llllllllllllllIlIlIlIIlIllIlllII = llllllllllllllIlIlIlIIlIllIllIIl.toCharArray();
    int llllllllllllllIlIlIlIIlIllIllIll = lIIIIllIIlIll[1];
    short llllllllllllllIlIlIlIIlIllIlIlIl = llllllllllllllIlIlIlIIlIllIlllll.toCharArray();
    short llllllllllllllIlIlIlIIlIllIlIlII = llllllllllllllIlIlIlIIlIllIlIlIl.length;
    float llllllllllllllIlIlIlIIlIllIlIIll = lIIIIllIIlIll[1];
    while (llIIllIllIllII(llllllllllllllIlIlIlIIlIllIlIIll, llllllllllllllIlIlIlIIlIllIlIlII))
    {
      char llllllllllllllIlIlIlIIlIlllIIIII = llllllllllllllIlIlIlIIlIllIlIlIl[llllllllllllllIlIlIlIIlIllIlIIll];
      "".length();
      "".length();
      if ("  ".length() < 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIlIlIIlIllIlllIl);
  }
  
  protected void mouseReleased(int llllllllllllllIlIlIlIIllIIIllIIl, int llllllllllllllIlIlIlIIllIIIlIlII, int llllllllllllllIlIlIlIIllIIIlIlll)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIlIlIlIIllIIIlIllI.mouseReleased(llllllllllllllIlIlIlIIllIIIllIIl, llllllllllllllIlIlIlIIllIIIlIlII, llllllllllllllIlIlIlIIllIIIlIlll);
    "".length();
  }
  
  private static boolean llIIllIllIlIll(int ???)
  {
    short llllllllllllllIlIlIlIIlIlIlIIlII;
    return ??? > 0;
  }
  
  public GuiMultiplayer(GuiScreen llllllllllllllIlIlIlIIlllIlIlIlI)
  {
    parentScreen = llllllllllllllIlIlIlIIlllIlIlIlI;
  }
  
  public void createButtons()
  {
    ;
    btnEditServer = new GuiButton(lIIIIllIIlIll[5], width / lIIIIllIIlIll[6] - lIIIIllIIlIll[7], height - lIIIIllIIlIll[8], lIIIIllIIlIll[9], lIIIIllIIlIll[10], I18n.format(llllllllIllI[lIIIIllIIlIll[0]], new Object[lIIIIllIIlIll[1]]));
    "".length();
    btnDeleteServer = new GuiButton(lIIIIllIIlIll[6], width / lIIIIllIIlIll[6] - lIIIIllIIlIll[11], height - lIIIIllIIlIll[8], lIIIIllIIlIll[9], lIIIIllIIlIll[10], I18n.format(llllllllIllI[lIIIIllIIlIll[6]], new Object[lIIIIllIIlIll[1]]));
    "".length();
    btnSelectServer = new GuiButton(lIIIIllIIlIll[0], width / lIIIIllIIlIll[6] - lIIIIllIIlIll[7], height - lIIIIllIIlIll[12], lIIIIllIIlIll[13], lIIIIllIIlIll[10], I18n.format(llllllllIllI[lIIIIllIIlIll[14]], new Object[lIIIIllIIlIll[1]]));
    "".length();
    new GuiButton(lIIIIllIIlIll[15], width / lIIIIllIIlIll[6] - lIIIIllIIlIll[16], height - lIIIIllIIlIll[12], lIIIIllIIlIll[13], lIIIIllIIlIll[10], I18n.format(llllllllIllI[lIIIIllIIlIll[15]], new Object[lIIIIllIIlIll[1]]));
    "".length();
    new GuiButton(lIIIIllIIlIll[14], width / lIIIIllIIlIll[6] + lIIIIllIIlIll[15] + lIIIIllIIlIll[16], height - lIIIIllIIlIll[12], lIIIIllIIlIll[13], lIIIIllIIlIll[10], I18n.format(llllllllIllI[lIIIIllIIlIll[17]], new Object[lIIIIllIIlIll[1]]));
    "".length();
    new GuiButton(lIIIIllIIlIll[18], width / lIIIIllIIlIll[6] + lIIIIllIIlIll[15], height - lIIIIllIIlIll[8], lIIIIllIIlIll[9], lIIIIllIIlIll[10], I18n.format(llllllllIllI[lIIIIllIIlIll[19]], new Object[lIIIIllIIlIll[1]]));
    "".length();
    new GuiButton(lIIIIllIIlIll[1], width / lIIIIllIIlIll[6] + lIIIIllIIlIll[15] + lIIIIllIIlIll[20], height - lIIIIllIIlIll[8], lIIIIllIIlIll[21], lIIIIllIIlIll[10], I18n.format(llllllllIllI[lIIIIllIIlIll[5]], new Object[lIIIIllIIlIll[1]]));
    "".length();
    llllllllllllllIlIlIlIIlllIIlllIl.selectServer(serverListSelector.func_148193_k());
  }
  
  public void updateScreen()
  {
    ;
    ;
    llllllllllllllIlIlIlIIlllIIllIIl.updateScreen();
    if (llIIllIllIIlIl(lanServerList.getWasUpdated()))
    {
      List<LanServerDetector.LanServer> llllllllllllllIlIlIlIIlllIIllIII = lanServerList.getLanServers();
      lanServerList.setWasNotUpdated();
      serverListSelector.func_148194_a(llllllllllllllIlIlIlIIlllIIllIII);
    }
    oldServerPinger.pingPendingNetworks();
  }
  
  private static boolean llIIllIllIIIlI(int ???)
  {
    int llllllllllllllIlIlIlIIlIlIlIlIlI;
    return ??? == 0;
  }
}

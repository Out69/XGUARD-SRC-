package net.minecraft.client.gui;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.resources.ResourcePackListEntry;
import net.minecraft.util.EnumChatFormatting;

public abstract class GuiResourcePackList
  extends GuiListExtended
{
  public GuiResourcePackList(Minecraft lllllllllllllllIlIlllIlIllllIIII, int lllllllllllllllIlIlllIlIllllIlII, int lllllllllllllllIlIlllIlIllllIIll, List<ResourcePackListEntry> lllllllllllllllIlIlllIlIlllIllIl)
  {
    lllllllllllllllIlIlllIlIllllIIIl.<init>(lllllllllllllllIlIlllIlIllllIIII, lllllllllllllllIlIlllIlIlllIllll, lllllllllllllllIlIlllIlIllllIIll, lIIllIIllIlI[0], lllllllllllllllIlIlllIlIllllIIll - lIIllIIllIlI[1] + lIIllIIllIlI[2], lIIllIIllIlI[3]);
    mc = lllllllllllllllIlIlllIlIllllIIII;
    field_148204_l = lllllllllllllllIlIlllIlIlllIllIl;
    field_148163_i = lIIllIIllIlI[4];
    lllllllllllllllIlIlllIlIllllIIIl.setHasListHeader(lIIllIIllIlI[5], (int)(fontRendererObjFONT_HEIGHT * 1.5F));
  }
  
  public List<ResourcePackListEntry> getList()
  {
    ;
    return field_148204_l;
  }
  
  protected int getScrollBarX()
  {
    ;
    return right - lIIllIIllIlI[9];
  }
  
  protected int getSize()
  {
    ;
    return lllllllllllllllIlIlllIlIllIllIll.getList().size();
  }
  
  protected void drawListHeader(int lllllllllllllllIlIlllIlIlllIIlll, int lllllllllllllllIlIlllIlIlllIIllI, Tessellator lllllllllllllllIlIlllIlIlllIIlIl)
  {
    ;
    ;
    ;
    ;
    String lllllllllllllllIlIlllIlIlllIIlII = String.valueOf(new StringBuilder().append(EnumChatFormatting.UNDERLINE).append(EnumChatFormatting.BOLD).append(lllllllllllllllIlIlllIlIlllIlIII.getListHeader()));
    "".length();
  }
  
  public int getListWidth()
  {
    ;
    return width;
  }
  
  private static void lllIllIllIlIl()
  {
    lIIllIIllIlI = new int[10];
    lIIllIIllIlI[0] = (0x34 ^ 0x60 ^ 0xC2 ^ 0xB6);
    lIIllIIllIlI[1] = (0x4A ^ 0x7D);
    lIIllIIllIlI[2] = (0x70 ^ 0x57 ^ 0xAA ^ 0x89);
    lIIllIIllIlI[3] = (0xE2 ^ 0xC6);
    lIIllIIllIlI[4] = ((0x44 ^ 0x51) & (0x56 ^ 0x43 ^ 0xFFFFFFFF));
    lIIllIIllIlI[5] = " ".length();
    lIIllIIllIlI[6] = "  ".length();
    lIIllIIllIlI[7] = "   ".length();
    lIIllIIllIlI[8] = (0xFFFFFFFF & 0xFFFFFF);
    lIIllIIllIlI[9] = (0x74 ^ 0x72);
  }
  
  public ResourcePackListEntry getListEntry(int lllllllllllllllIlIlllIlIllIlIlII)
  {
    ;
    ;
    return (ResourcePackListEntry)lllllllllllllllIlIlllIlIllIlIlIl.getList().get(lllllllllllllllIlIlllIlIllIlIlII);
  }
  
  static {}
  
  protected abstract String getListHeader();
}

package net.minecraft.client.gui;

import com.google.common.base.Objects;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.util.IntHashMap;

public class GuiPageButtonList
  extends GuiListExtended
{
  public void func_181155_a(boolean llllllllllllllIllIlIIIIIIlIIIIIl)
  {
    ;
    ;
    ;
    Exception llllllllllllllIllIlIIIIIIIllllII = field_178074_u.iterator();
    "".length();
    if ((0xB1 ^ 0xB5) < " ".length()) {
      return;
    }
    while (!lIllllIIlIIIll(llllllllllllllIllIlIIIIIIIllllII.hasNext()))
    {
      GuiEntry llllllllllllllIllIlIIIIIIlIIIIII = (GuiEntry)llllllllllllllIllIlIIIIIIIllllII.next();
      if (lIllllIIIlllll(field_178029_b instanceof GuiButton)) {
        field_178029_b).enabled = llllllllllllllIllIlIIIIIIlIIIIIl;
      }
      if (lIllllIIIlllll(field_178030_c instanceof GuiButton)) {
        field_178030_c).enabled = llllllllllllllIllIlIIIIIIlIIIIIl;
      }
    }
  }
  
  protected int getScrollBarX()
  {
    ;
    return llllllllllllllIllIIllllllIllIlll.getScrollBarX() + llllIlllIllI[10];
  }
  
  private static void lIllllIIIllIlI()
  {
    llllIlllIlIl = new String[llllIlllIllI[1]];
    llllIlllIlIl[llllIlllIllI[0]] = lIllllIIIllIIl("tTJ+G0OrdBM=", "ICmYw");
  }
  
  public void func_178062_a(char llllllllllllllIllIIlllllllIIllIl, int llllllllllllllIllIIlllllllIIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllllIIIlllll(field_178075_A instanceof GuiTextField))
    {
      GuiTextField llllllllllllllIllIIlllllllIlIlll = (GuiTextField)field_178075_A;
      if (lIllllIIlIIIll(GuiScreen.isKeyComboCtrlV(llllllllllllllIllIIlllllllIIllII)))
      {
        if (lIllllIIlIIlll(llllllllllllllIllIIlllllllIIllII, llllIlllIllI[8]))
        {
          llllllllllllllIllIIlllllllIlIlll.setFocused(llllIlllIllI[0]);
          int llllllllllllllIllIIlllllllIlIllI = field_178072_w.indexOf(field_178075_A);
          if (lIllllIIIlllll(GuiScreen.isShiftKeyDown()))
          {
            if (lIllllIIlIIIll(llllllllllllllIllIIlllllllIlIllI))
            {
              llllllllllllllIllIIlllllllIlIllI = field_178072_w.size() - llllIlllIllI[1];
              "".length();
              if (null == null) {}
            }
            else
            {
              llllllllllllllIllIIlllllllIlIllI--;
              "".length();
              if (-(53 + 44 - 71 + 111 ^ '' + 92 - 223 + 139) < 0) {}
            }
          }
          else if (lIllllIIlIIlll(llllllllllllllIllIIlllllllIlIllI, field_178072_w.size() - llllIlllIllI[1]))
          {
            llllllllllllllIllIIlllllllIlIllI = llllIlllIllI[0];
            "".length();
            if (-" ".length() <= " ".length()) {}
          }
          else
          {
            llllllllllllllIllIIlllllllIlIllI++;
          }
          field_178075_A = ((Gui)field_178072_w.get(llllllllllllllIllIIlllllllIlIllI));
          llllllllllllllIllIIlllllllIlIlll = (GuiTextField)field_178075_A;
          llllllllllllllIllIIlllllllIlIlll.setFocused(llllIlllIllI[1]);
          int llllllllllllllIllIIlllllllIlIlIl = yPosition + slotHeight;
          int llllllllllllllIllIIlllllllIlIlII = yPosition;
          if (lIllllIIlIlIII(llllllllllllllIllIIlllllllIlIlIl, bottom))
          {
            amountScrolled += llllllllllllllIllIIlllllllIlIlIl - bottom;
            "".length();
            if (null == null) {}
          }
          else if (lIllllIIIlllII(llllllllllllllIllIIlllllllIlIlII, top))
          {
            amountScrolled = llllllllllllllIllIIlllllllIlIlII;
            "".length();
            if (-" ".length() < " ".length()) {}
          }
        }
        else
        {
          "".length();
          "".length();
          if ((0x40 ^ 0x44) == (0x4 ^ 0x0)) {}
        }
      }
      else
      {
        String llllllllllllllIllIIlllllllIlIIll = GuiScreen.getClipboardString();
        String[] llllllllllllllIllIIlllllllIlIIlI = llllllllllllllIllIIlllllllIlIIll.split(llllIlllIlIl[llllIlllIllI[0]]);
        int llllllllllllllIllIIlllllllIlIIIl = field_178072_w.indexOf(field_178075_A);
        int llllllllllllllIllIIlllllllIlIIII = llllllllllllllIllIIlllllllIlIIIl;
        llllllllllllllIllIIlllllllIIIlII = (llllllllllllllIllIIlllllllIIIIll = llllllllllllllIllIIlllllllIlIIlI).length;
        llllllllllllllIllIIlllllllIIIlIl = llllIlllIllI[0];
        "".length();
        if (" ".length() >= (0x4B ^ 0x4F)) {
          return;
        }
        while (!lIllllIIlIIIII(llllllllllllllIllIIlllllllIIIlIl, llllllllllllllIllIIlllllllIIIlII))
        {
          String llllllllllllllIllIIlllllllIIllll = llllllllllllllIllIIlllllllIIIIll[llllllllllllllIllIIlllllllIIIlIl];
          ((GuiTextField)field_178072_w.get(llllllllllllllIllIIlllllllIlIIII)).setText(llllllllllllllIllIIlllllllIIllll);
          if (lIllllIIlIIlll(llllllllllllllIllIIlllllllIlIIII, field_178072_w.size() - llllIlllIllI[1]))
          {
            llllllllllllllIllIIlllllllIlIIII = llllIlllIllI[0];
            "".length();
            if (" ".length() != 0) {}
          }
          else
          {
            llllllllllllllIllIIlllllllIlIIII++;
          }
          if (lIllllIIlIIlll(llllllllllllllIllIIlllllllIlIIII, llllllllllllllIllIIlllllllIlIIIl))
          {
            "".length();
            if (((113 + 'Â' - 108 + 45 ^ 91 + 80 - 160 + 139) & (104 + 76 - -26 + 25 ^ 0 + 117 - 101 + 117 ^ -" ".length())) == 0) {
              break;
            }
            return;
          }
          llllllllllllllIllIIlllllllIIIlIl++;
        }
      }
    }
  }
  
  private void func_178060_e(int llllllllllllllIllIlIIIIIIllIIlII, int llllllllllllllIllIlIIIIIIlIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    double llllllllllllllIllIlIIIIIIlIllIll = (llllllllllllllIllIlIIIIIIlIllIlI = field_178078_x[llllllllllllllIllIlIIIIIIlIlllll]).length;
    float llllllllllllllIllIlIIIIIIlIlllII = llllIlllIllI[0];
    "".length();
    if (((0xFE ^ 0xB5) & (0x7F ^ 0x34 ^ 0xFFFFFFFF)) != 0) {
      return;
    }
    while (!lIllllIIlIIIII(llllllllllllllIllIlIIIIIIlIlllII, llllllllllllllIllIlIIIIIIlIllIll))
    {
      GuiListEntry llllllllllllllIllIlIIIIIIllIIIlI = llllllllllllllIllIlIIIIIIlIllIlI[llllllllllllllIllIlIIIIIIlIlllII];
      if (lIllllIIIllllI(llllllllllllllIllIlIIIIIIllIIIlI)) {
        llllllllllllllIllIlIIIIIIllIIlIl.func_178066_a((Gui)field_178073_v.lookup(llllllllllllllIllIlIIIIIIllIIIlI.func_178935_b()), llllIlllIllI[0]);
      }
      llllllllllllllIllIlIIIIIIlIlllII++;
    }
    llllllllllllllIllIlIIIIIIlIllIll = (llllllllllllllIllIlIIIIIIlIllIlI = field_178078_x[llllllllllllllIllIlIIIIIIlIllllI]).length;
    llllllllllllllIllIlIIIIIIlIlllII = llllIlllIllI[0];
    "".length();
    if (((0x38 ^ 0xC) & (0xF ^ 0x3B ^ 0xFFFFFFFF)) >= "   ".length()) {
      return;
    }
    while (!lIllllIIlIIIII(llllllllllllllIllIlIIIIIIlIlllII, llllllllllllllIllIlIIIIIIlIllIll))
    {
      GuiListEntry llllllllllllllIllIlIIIIIIllIIIIl = llllllllllllllIllIlIIIIIIlIllIlI[llllllllllllllIllIlIIIIIIlIlllII];
      if (lIllllIIIllllI(llllllllllllllIllIlIIIIIIllIIIIl)) {
        llllllllllllllIllIlIIIIIIllIIlIl.func_178066_a((Gui)field_178073_v.lookup(llllllllllllllIllIlIIIIIIllIIIIl.func_178935_b()), llllIlllIllI[1]);
      }
      llllllllllllllIllIlIIIIIIlIlllII++;
    }
  }
  
  private static boolean lIllllIIIlllII(int ???, int arg1)
  {
    int i;
    int llllllllllllllIllIIllllllIIllIIl;
    return ??? < i;
  }
  
  public int getSize()
  {
    ;
    return field_178074_u.size();
  }
  
  private Gui func_178058_a(GuiListEntry llllllllllllllIllIlIIIIIIlIIlIIl, int llllllllllllllIllIlIIIIIIlIIllII, boolean llllllllllllllIllIlIIIIIIlIIlIll)
  {
    ;
    ;
    ;
    ;
    if (lIllllIIIlllll(llllllllllllllIllIlIIIIIIlIIlIIl instanceof GuiSlideEntry))
    {
      "".length();
      if (null != null) {
        return null;
      }
    }
    else if (lIllllIIIlllll(llllllllllllllIllIlIIIIIIlIIlIIl instanceof GuiButtonEntry))
    {
      "".length();
      if (" ".length() != " ".length()) {
        return null;
      }
    }
    else if (lIllllIIIlllll(llllllllllllllIllIlIIIIIIlIIlIIl instanceof EditBoxEntry))
    {
      "".length();
      if (" ".length() <= -" ".length()) {
        return null;
      }
    }
    else if (lIllllIIIlllll(llllllllllllllIllIlIIIIIIlIIlIIl instanceof GuiLabelEntry))
    {
      "".length();
      if ((88 + '' - 215 + 142 ^ 95 + '' - 135 + 52) > ((0x93 ^ 0xB2 ^ 0x23 ^ 0x5E) & (122 + 30 - 100 + 203 ^ 40 + 2 - 14 + 135 ^ -" ".length()))) {
        break label305;
      }
      return null;
    }
    label305:
    return null;
  }
  
  private void func_178055_t()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    field_178074_u.clear();
    int llllllllllllllIllIlIIIIIlIIlIlll = llllIlllIllI[0];
    "".length();
    if (" ".length() > " ".length()) {
      return;
    }
    label110:
    label171:
    while (!lIllllIIlIIIII(llllllllllllllIllIlIIIIIlIIlIlll, field_178078_x[field_178077_y].length))
    {
      GuiListEntry llllllllllllllIllIlIIIIIlIIlIllI = field_178078_x[field_178077_y][llllllllllllllIllIlIIIIIlIIlIlll];
      if (lIllllIIIlllII(llllllllllllllIllIlIIIIIlIIlIlll, field_178078_x[field_178077_y].length - llllIlllIllI[1]))
      {
        "".length();
        if (-" ".length() < "  ".length()) {
          break label110;
        }
      }
      GuiListEntry llllllllllllllIllIlIIIIIlIIlIlIl = null;
      Gui llllllllllllllIllIlIIIIIlIIlIlII = (Gui)field_178073_v.lookup(llllllllllllllIllIlIIIIIlIIlIllI.func_178935_b());
      if (lIllllIIIllllI(llllllllllllllIllIlIIIIIlIIlIlIl))
      {
        "".length();
        if ("  ".length() <= "  ".length()) {
          break label171;
        }
      }
      Gui llllllllllllllIllIlIIIIIlIIlIIll = null;
      GuiEntry llllllllllllllIllIlIIIIIlIIlIIlI = new GuiEntry(llllllllllllllIllIlIIIIIlIIlIlII, llllllllllllllIllIlIIIIIlIIlIIll);
      "".length();
      llllllllllllllIllIlIIIIIlIIlIlll += 2;
    }
  }
  
  public Gui func_178056_g()
  {
    ;
    return field_178075_A;
  }
  
  private void func_178066_a(Gui llllllllllllllIllIlIIIIIIlIlIlII, boolean llllllllllllllIllIlIIIIIIlIlIIll)
  {
    ;
    ;
    if (lIllllIIIlllll(llllllllllllllIllIlIIIIIIlIlIlII instanceof GuiButton))
    {
      visible = llllllllllllllIllIlIIIIIIlIlIIll;
      "".length();
      if (null == null) {}
    }
    else if (lIllllIIIlllll(llllllllllllllIllIlIIIIIIlIlIlII instanceof GuiTextField))
    {
      ((GuiTextField)llllllllllllllIllIlIIIIIIlIlIlII).setVisible(llllllllllllllIllIlIIIIIIlIlIIll);
      "".length();
      if (" ".length() < ('¨' + 36 - 35 + 30 ^ 96 + '' - 232 + 181)) {}
    }
    else if (lIllllIIIlllll(llllllllllllllIllIlIIIIIIlIlIlII instanceof GuiLabel))
    {
      visible = llllllllllllllIllIlIIIIIIlIlIIll;
    }
  }
  
  private static boolean lIllllIIIlllIl(Object ???)
  {
    float llllllllllllllIllIIllllllIIIllIl;
    return ??? == null;
  }
  
  private static void lIllllIIIllIll()
  {
    llllIlllIllI = new int[12];
    llllIlllIllI[0] = ((19 + 71 - 43 + 130 ^ 93 + 107 - 77 + 16) & (0x50 ^ 0x76 ^ 0xDA ^ 0xC6 ^ -" ".length()));
    llllIlllIllI[1] = " ".length();
    llllIlllIllI[2] = (52 + 89 - 25 + 44);
    llllIlllIllI[3] = "  ".length();
    llllIlllIllI[4] = (41 + 81 - -10 + 23);
    llllIlllIllI[5] = (42 + 30 - 26 + 104);
    llllIlllIllI[6] = (0x1F ^ 0x63 ^ 0x68 ^ 0x0);
    llllIlllIllI[7] = (-" ".length());
    llllIlllIllI[8] = (0xB9 ^ 0xB6);
    llllIlllIllI[9] = (-(0xBB79 & 0x54EF) & 0xB5F8 & 0x5BFF);
    llllIlllIllI[10] = (0x4 ^ 0x54 ^ 0x58 ^ 0x28);
    llllIlllIllI[11] = (0x78 ^ 0x70);
  }
  
  private static boolean lIllllIIlIIlll(int ???, int arg1)
  {
    int i;
    char llllllllllllllIllIIllllllIlIIIIl;
    return ??? == i;
  }
  
  private static String lIllllIIIllIIl(String llllllllllllllIllIIllllllIlIlIII, String llllllllllllllIllIIllllllIlIIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIllllllIlIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIllllllIlIIlll.getBytes(StandardCharsets.UTF_8)), llllIlllIllI[11]), "DES");
      Cipher llllllllllllllIllIIllllllIlIllII = Cipher.getInstance("DES");
      llllllllllllllIllIIllllllIlIllII.init(llllIlllIllI[3], llllllllllllllIllIIllllllIlIllIl);
      return new String(llllllllllllllIllIIllllllIlIllII.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIllllllIlIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIllllllIlIlIll)
    {
      llllllllllllllIllIIllllllIlIlIll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIllllIIlIIIll(int ???)
  {
    long llllllllllllllIllIIllllllIIIlIIl;
    return ??? == 0;
  }
  
  public void func_178064_i()
  {
    ;
    if (lIllllIIIlllII(field_178077_y, field_178078_x.length - llllIlllIllI[1])) {
      llllllllllllllIllIlIIIIIIlllIIll.func_181156_c(field_178077_y + llllIlllIllI[1]);
    }
  }
  
  private static boolean lIllllIIlIIlII(int ???)
  {
    String llllllllllllllIllIIllllllIIIIlll;
    return ??? >= 0;
  }
  
  private static boolean lIllllIIlIIlIl(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllIllIIllllllIIlIIIl;
    return ??? != localObject;
  }
  
  public void func_178071_h()
  {
    ;
    if (lIllllIIlIIIlI(field_178077_y)) {
      llllllllllllllIllIlIIIIIIlllIllI.func_181156_c(field_178077_y - llllIlllIllI[1]);
    }
  }
  
  private GuiSlider func_178067_a(int llllllllllllllIllIlIIIIIIIIllIll, int llllllllllllllIllIlIIIIIIIIlllll, GuiSlideEntry llllllllllllllIllIlIIIIIIIIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    GuiSlider llllllllllllllIllIlIIIIIIIIlllIl = new GuiSlider(field_178076_z, llllllllllllllIllIlIIIIIIIIllllI.func_178935_b(), llllllllllllllIllIlIIIIIIIIllIll, llllllllllllllIllIlIIIIIIIIlllll, llllllllllllllIllIlIIIIIIIIllllI.func_178936_c(), llllllllllllllIllIlIIIIIIIIllllI.func_178943_e(), llllllllllllllIllIlIIIIIIIIllllI.func_178944_f(), llllllllllllllIllIlIIIIIIIIllllI.func_178942_g(), llllllllllllllIllIlIIIIIIIIllllI.func_178945_a());
    visible = llllllllllllllIllIlIIIIIIIIllllI.func_178934_d();
    return llllllllllllllIllIlIIIIIIIIlllIl;
  }
  
  private static boolean lIllllIIlIlIII(int ???, int arg1)
  {
    int i;
    short llllllllllllllIllIIllllllIIlIlIl;
    return ??? > i;
  }
  
  public int func_178057_f()
  {
    ;
    return field_178078_x.length;
  }
  
  private void func_178069_s()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    short llllllllllllllIllIlIIIIIlIlIIlll = (llllllllllllllIllIlIIIIIlIlIIllI = field_178078_x).length;
    double llllllllllllllIllIlIIIIIlIlIlIII = llllIlllIllI[0];
    "".length();
    if ("   ".length() < 0) {
      return;
    }
    label111:
    label156:
    label204:
    while (!lIllllIIlIIIII(llllllllllllllIllIlIIIIIlIlIlIII, llllllllllllllIllIlIIIIIlIlIIlll))
    {
      GuiListEntry[] llllllllllllllIllIlIIIIIlIllIIIl = llllllllllllllIllIlIIIIIlIlIIllI[llllllllllllllIllIlIIIIIlIlIlIII];
      int llllllllllllllIllIlIIIIIlIllIIII = llllIlllIllI[0];
      "".length();
      if (null != null) {
        return;
      }
      while (!lIllllIIlIIIII(llllllllllllllIllIlIIIIIlIllIIII, llllllllllllllIllIlIIIIIlIllIIIl.length))
      {
        GuiListEntry llllllllllllllIllIlIIIIIlIlIllll = llllllllllllllIllIlIIIIIlIllIIIl[llllllllllllllIllIlIIIIIlIllIIII];
        if (lIllllIIIlllII(llllllllllllllIllIlIIIIIlIllIIII, llllllllllllllIllIlIIIIIlIllIIIl.length - llllIlllIllI[1]))
        {
          "".length();
          if (-(0x38 ^ 0x28 ^ 0x85 ^ 0x91) < 0) {
            break label111;
          }
        }
        GuiListEntry llllllllllllllIllIlIIIIIlIlIlllI = null;
        if (lIllllIIIlllIl(llllllllllllllIllIlIIIIIlIlIlllI))
        {
          "".length();
          if (-"  ".length() <= 0) {
            break label156;
          }
        }
        Gui llllllllllllllIllIlIIIIIlIlIllIl = llllllllllllllIllIlIIIIIlIlIllll.func_178058_a(llllIlllIllI[0], llllIlllIllI[1], llllIlllIllI[0]);
        if (lIllllIIIlllIl(llllllllllllllIllIlIIIIIlIlIllll))
        {
          "".length();
          if (-"  ".length() < 0) {
            break label204;
          }
        }
        Gui llllllllllllllIllIlIIIIIlIlIllII = llllllllllllllIllIlIIIIIlIlIlllI.func_178058_a(llllIlllIllI[2], llllIlllIllI[1], llllIlllIllI[0]);
        GuiEntry llllllllllllllIllIlIIIIIlIlIlIll = new GuiEntry(llllllllllllllIllIlIIIIIlIlIllIl, llllllllllllllIllIlIIIIIlIlIllII);
        "".length();
        if ((lIllllIIIllllI(llllllllllllllIllIlIIIIIlIlIllll)) && (lIllllIIIllllI(llllllllllllllIllIlIIIIIlIlIllIl)))
        {
          field_178073_v.addKey(llllllllllllllIllIlIIIIIlIlIllll.func_178935_b(), llllllllllllllIllIlIIIIIlIlIllIl);
          if (lIllllIIIlllll(llllllllllllllIllIlIIIIIlIlIllIl instanceof GuiTextField)) {
            "".length();
          }
        }
        if ((lIllllIIIllllI(llllllllllllllIllIlIIIIIlIlIlllI)) && (lIllllIIIllllI(llllllllllllllIllIlIIIIIlIlIllII)))
        {
          field_178073_v.addKey(llllllllllllllIllIlIIIIIlIlIlllI.func_178935_b(), llllllllllllllIllIlIIIIIlIlIllII);
          if (lIllllIIIlllll(llllllllllllllIllIlIIIIIlIlIllII instanceof GuiTextField)) {
            "".length();
          }
        }
        llllllllllllllIllIlIIIIIlIllIIII += 2;
      }
    }
  }
  
  public boolean mouseClicked(int llllllllllllllIllIlIIIIIIIllIIll, int llllllllllllllIllIlIIIIIIIlIlIll, int llllllllllllllIllIlIIIIIIIllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    boolean llllllllllllllIllIlIIIIIIIllIIII = llllllllllllllIllIlIIIIIIIlIllIl.mouseClicked(llllllllllllllIllIlIIIIIIIllIIll, llllllllllllllIllIlIIIIIIIlIlIll, llllllllllllllIllIlIIIIIIIllIIIl);
    int llllllllllllllIllIlIIIIIIIlIllll = llllllllllllllIllIlIIIIIIIlIllIl.getSlotIndexFromScreenCoords(llllllllllllllIllIlIIIIIIIllIIll, llllllllllllllIllIlIIIIIIIlIlIll);
    if (lIllllIIlIIlII(llllllllllllllIllIlIIIIIIIlIllll))
    {
      GuiEntry llllllllllllllIllIlIIIIIIIlIlllI = llllllllllllllIllIlIIIIIIIlIllIl.getListEntry(llllllllllllllIllIlIIIIIIIlIllll);
      if ((lIllllIIlIIlIl(field_178075_A, field_178028_d)) && (lIllllIIIllllI(field_178075_A)) && (lIllllIIIlllll(field_178075_A instanceof GuiTextField))) {
        ((GuiTextField)field_178075_A).setFocused(llllIlllIllI[0]);
      }
      field_178075_A = field_178028_d;
    }
    return llllllllllllllIllIlIIIIIIIllIIII;
  }
  
  public void func_181156_c(int llllllllllllllIllIlIIIIIlIIIIllI)
  {
    ;
    ;
    ;
    if (lIllllIIlIIIIl(llllllllllllllIllIlIIIIIlIIIIllI, field_178077_y))
    {
      int llllllllllllllIllIlIIIIIlIIIIlIl = field_178077_y;
      field_178077_y = llllllllllllllIllIlIIIIIlIIIIllI;
      llllllllllllllIllIlIIIIIlIIIIlll.func_178055_t();
      llllllllllllllIllIlIIIIIlIIIIlll.func_178060_e(llllllllllllllIllIlIIIIIlIIIIlIl, llllllllllllllIllIlIIIIIlIIIIllI);
      amountScrolled = 0.0F;
    }
  }
  
  public int getListWidth()
  {
    return llllIlllIllI[9];
  }
  
  public Gui func_178061_c(int llllllllllllllIllIlIIIIIIllIllll)
  {
    ;
    ;
    return (Gui)field_178073_v.lookup(llllllllllllllIllIlIIIIIIllIllll);
  }
  
  private GuiTextField func_178068_a(int llllllllllllllIllIIlllllllllllIl, int llllllllllllllIllIlIIIIIIIIIIIIl, EditBoxEntry llllllllllllllIllIlIIIIIIIIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    GuiTextField llllllllllllllIllIIlllllllllllll = new GuiTextField(llllllllllllllIllIlIIIIIIIIIIIII.func_178935_b(), Minecraft.fontRendererObj, llllllllllllllIllIIlllllllllllIl, llllllllllllllIllIlIIIIIIIIIIIIl, llllIlllIllI[5], llllIlllIllI[6]);
    llllllllllllllIllIIlllllllllllll.setText(llllllllllllllIllIlIIIIIIIIIIIII.func_178936_c());
    llllllllllllllIllIIlllllllllllll.func_175207_a(field_178076_z);
    llllllllllllllIllIIlllllllllllll.setVisible(llllllllllllllIllIlIIIIIIIIIIIII.func_178934_d());
    llllllllllllllIllIIlllllllllllll.func_175205_a(llllllllllllllIllIlIIIIIIIIIIIII.func_178950_a());
    return llllllllllllllIllIIlllllllllllll;
  }
  
  private GuiLabel func_178063_a(int llllllllllllllIllIIllllllllIlIll, int llllllllllllllIllIIlllllllllIIIl, GuiLabelEntry llllllllllllllIllIIllllllllIlIIl, boolean llllllllllllllIllIIllllllllIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    GuiLabel llllllllllllllIllIIllllllllIllIl;
    if (lIllllIIIlllll(llllllllllllllIllIIllllllllIlIII))
    {
      GuiLabel llllllllllllllIllIIllllllllIlllI = new GuiLabel(Minecraft.fontRendererObj, llllllllllllllIllIIllllllllIlIIl.func_178935_b(), llllllllllllllIllIIllllllllIlIll, llllllllllllllIllIIllllllllIlIlI, width - llllllllllllllIllIIllllllllIlIll * llllIlllIllI[3], llllIlllIllI[6], llllIlllIllI[7]);
      "".length();
      if (((0x3E ^ 0x32 ^ 0xBF ^ 0x93) & ('' + 22 - 54 + 60 ^ 56 + 106 - 86 + 55 ^ -" ".length())) < 0) {
        return null;
      }
    }
    else
    {
      llllllllllllllIllIIllllllllIllIl = new GuiLabel(Minecraft.fontRendererObj, llllllllllllllIllIIllllllllIlIIl.func_178935_b(), llllllllllllllIllIIllllllllIlIll, llllllllllllllIllIIllllllllIlIlI, llllIlllIllI[5], llllIlllIllI[6], llllIlllIllI[7]);
    }
    visible = llllllllllllllIllIIllllllllIlIIl.func_178934_d();
    llllllllllllllIllIIllllllllIllIl.func_175202_a(llllllllllllllIllIIllllllllIlIIl.func_178936_c());
    "".length();
    return llllllllllllllIllIIllllllllIllIl;
  }
  
  private static boolean lIllllIIIlllll(int ???)
  {
    short llllllllllllllIllIIllllllIIIlIll;
    return ??? != 0;
  }
  
  public int func_178059_e()
  {
    ;
    return field_178077_y;
  }
  
  private static boolean lIllllIIIllllI(Object ???)
  {
    char llllllllllllllIllIIllllllIIIllll;
    return ??? != null;
  }
  
  private static boolean lIllllIIlIIIlI(int ???)
  {
    long llllllllllllllIllIIllllllIIIIlIl;
    return ??? > 0;
  }
  
  public GuiEntry getListEntry(int llllllllllllllIllIIllllllIllllIl)
  {
    ;
    ;
    return (GuiEntry)field_178074_u.get(llllllllllllllIllIIllllllIllllIl);
  }
  
  private static boolean lIllllIIlIIIII(int ???, int arg1)
  {
    int i;
    float llllllllllllllIllIIllllllIIlllIl;
    return ??? >= i;
  }
  
  static
  {
    lIllllIIIllIll();
    lIllllIIIllIlI();
  }
  
  private GuiListButton func_178065_a(int llllllllllllllIllIlIIIIIIIIlIIIl, int llllllllllllllIllIlIIIIIIIIIlIll, GuiButtonEntry llllllllllllllIllIlIIIIIIIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    GuiListButton llllllllllllllIllIlIIIIIIIIIlllI = new GuiListButton(field_178076_z, llllllllllllllIllIlIIIIIIIIIllll.func_178935_b(), llllllllllllllIllIlIIIIIIIIlIIIl, llllllllllllllIllIlIIIIIIIIIlIll, llllllllllllllIllIlIIIIIIIIIllll.func_178936_c(), llllllllllllllIllIlIIIIIIIIIllll.func_178940_a());
    visible = llllllllllllllIllIlIIIIIIIIIllll.func_178934_d();
    return llllllllllllllIllIlIIIIIIIIIlllI;
  }
  
  public GuiPageButtonList(Minecraft llllllllllllllIllIlIIIIIllIIlllI, int llllllllllllllIllIlIIIIIllIIllIl, int llllllllllllllIllIlIIIIIllIIllII, int llllllllllllllIllIlIIIIIllIIlIll, int llllllllllllllIllIlIIIIIllIIlIlI, int llllllllllllllIllIlIIIIIllIIlIIl, GuiResponder llllllllllllllIllIlIIIIIllIIlIII, GuiListEntry[]... llllllllllllllIllIlIIIIIlIlllllI)
  {
    llllllllllllllIllIlIIIIIllIIIllI.<init>(llllllllllllllIllIlIIIIIllIIlllI, llllllllllllllIllIlIIIIIllIIllIl, llllllllllllllIllIlIIIIIllIIllII, llllllllllllllIllIlIIIIIllIIIIlI, llllllllllllllIllIlIIIIIllIIlIlI, llllllllllllllIllIlIIIIIllIIlIIl);
    field_178076_z = llllllllllllllIllIlIIIIIllIIlIII;
    field_178078_x = llllllllllllllIllIlIIIIIlIlllllI;
    field_148163_i = llllIlllIllI[0];
    llllllllllllllIllIlIIIIIllIIIllI.func_178069_s();
    llllllllllllllIllIlIIIIIllIIIllI.func_178055_t();
  }
  
  private static boolean lIllllIIlIIIIl(int ???, int arg1)
  {
    int i;
    long llllllllllllllIllIIllllllIIIIIIl;
    return ??? != i;
  }
  
  public static class GuiButtonEntry
    extends GuiPageButtonList.GuiListEntry
  {
    public GuiButtonEntry(int lllllllllllllllIllIlIIIIIIIIIIll, String lllllllllllllllIllIIllllllllllIl, boolean lllllllllllllllIllIIllllllllllII, boolean lllllllllllllllIllIlIIIIIIIIIIII)
    {
      lllllllllllllllIllIlIIIIIIIIIlII.<init>(lllllllllllllllIllIlIIIIIIIIIIll, lllllllllllllllIllIlIIIIIIIIIIlI, lllllllllllllllIllIIllllllllllII);
      field_178941_a = lllllllllllllllIllIlIIIIIIIIIIII;
    }
    
    public boolean func_178940_a()
    {
      ;
      return field_178941_a;
    }
  }
  
  public static class EditBoxEntry
    extends GuiPageButtonList.GuiListEntry
  {
    public Predicate<String> func_178950_a()
    {
      ;
      return field_178951_a;
    }
    
    public EditBoxEntry(int llllllllllllllIlIIIlIIIIllIIlIIl, String llllllllllllllIlIIIlIIIIllIIlIII, boolean llllllllllllllIlIIIlIIIIllIIIlll, Predicate<String> llllllllllllllIlIIIlIIIIllIIIIIl)
    {
      llllllllllllllIlIIIlIIIIllIIIlIl.<init>(llllllllllllllIlIIIlIIIIllIIlIIl, llllllllllllllIlIIIlIIIIllIIIIll, llllllllllllllIlIIIlIIIIllIIIlll);
      field_178951_a = ((Predicate)Objects.firstNonNull(llllllllllllllIlIIIlIIIIllIIIIIl, Predicates.alwaysTrue()));
    }
  }
  
  public static abstract interface GuiResponder
  {
    public abstract void func_175321_a(int paramInt, boolean paramBoolean);
    
    public abstract void onTick(int paramInt, float paramFloat);
    
    public abstract void func_175319_a(int paramInt, String paramString);
  }
  
  public static class GuiLabelEntry
    extends GuiPageButtonList.GuiListEntry
  {
    public GuiLabelEntry(int lllllllllllllllIlllIIIIIIlllIlII, String lllllllllllllllIlllIIIIIIlllIlll, boolean lllllllllllllllIlllIIIIIIlllIllI)
    {
      lllllllllllllllIlllIIIIIIlllIlIl.<init>(lllllllllllllllIlllIIIIIIlllIlII, lllllllllllllllIlllIIIIIIlllIlll, lllllllllllllllIlllIIIIIIlllIllI);
    }
  }
  
  public static class GuiListEntry
  {
    public String func_178936_c()
    {
      ;
      return field_178937_b;
    }
    
    public boolean func_178934_d()
    {
      ;
      return field_178938_c;
    }
    
    public GuiListEntry(int llllllllllllllIlIlllIIIIIIIlIlIl, String llllllllllllllIlIlllIIIIIIIlIlII, boolean llllllllllllllIlIlllIIIIIIIlIIll)
    {
      field_178939_a = llllllllllllllIlIlllIIIIIIIlIlIl;
      field_178937_b = llllllllllllllIlIlllIIIIIIIlIlII;
      field_178938_c = llllllllllllllIlIlllIIIIIIIlIIll;
    }
    
    public int func_178935_b()
    {
      ;
      return field_178939_a;
    }
  }
  
  public static class GuiEntry
    implements GuiListExtended.IGuiListEntry
  {
    private void func_178017_a(Gui llllllllllllllllIllIIIlllIllIIIl, int llllllllllllllllIllIIIlllIllIIII, int llllllllllllllllIllIIIlllIlIllll, int llllllllllllllllIllIIIlllIllIlII, boolean llllllllllllllllIllIIIlllIllIIll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      if (lIIlIllIlllIl(llllllllllllllllIllIIIlllIllIIIl)) {
        if (lIIlIllIllllI(llllllllllllllllIllIIIlllIllIIIl instanceof GuiButton))
        {
          llllllllllllllllIllIIIlllIllIIlI.func_178024_a((GuiButton)llllllllllllllllIllIIIlllIllIIIl, llllllllllllllllIllIIIlllIllIIII, llllllllllllllllIllIIIlllIlIllll, llllllllllllllllIllIIIlllIllIlII, llllllllllllllllIllIIIlllIllIIll);
          "".length();
          if (null == null) {}
        }
        else if (lIIlIllIllllI(llllllllllllllllIllIIIlllIllIIIl instanceof GuiTextField))
        {
          llllllllllllllllIllIIIlllIllIIlI.func_178027_a((GuiTextField)llllllllllllllllIllIIIlllIllIIIl, llllllllllllllllIllIIIlllIllIIII, llllllllllllllllIllIIIlllIllIIll);
          "".length();
          if (((23 + '½' - 141 + 136 ^ 68 + 14 - 2 + 74) & (69 + 18 - -99 + 43 ^ 62 + 24 - 27 + 117 ^ -" ".length())) < "   ".length()) {}
        }
        else if (lIIlIllIllllI(llllllllllllllllIllIIIlllIllIIIl instanceof GuiLabel))
        {
          llllllllllllllllIllIIIlllIllIIlI.func_178025_a((GuiLabel)llllllllllllllllIllIIIlllIllIIIl, llllllllllllllllIllIIIlllIllIIII, llllllllllllllllIllIIIlllIlIllll, llllllllllllllllIllIIIlllIllIlII, llllllllllllllllIllIIIlllIllIIll);
        }
      }
    }
    
    private void func_178018_a(GuiTextField llllllllllllllllIllIIIllIIllIlll, int llllllllllllllllIllIIIllIIllIllI, int llllllllllllllllIllIIIllIIllIlIl, int llllllllllllllllIllIIIllIIlllIIl)
    {
      ;
      ;
      ;
      ;
      ;
      llllllllllllllllIllIIIllIIllIlll.mouseClicked(llllllllllllllllIllIIIllIIlllIll, llllllllllllllllIllIIIllIIllIlIl, llllllllllllllllIllIIIllIIlllIIl);
      if (lIIlIllIllllI(llllllllllllllllIllIIIllIIllIlll.isFocused())) {
        field_178028_d = llllllllllllllllIllIIIllIIllIlll;
      }
    }
    
    private void func_178016_b(Gui llllllllllllllllIllIIIllIIIllllI, int llllllllllllllllIllIIIllIIIllIII, int llllllllllllllllIllIIIllIIIlIlll, int llllllllllllllllIllIIIllIIIllIll)
    {
      ;
      ;
      ;
      ;
      ;
      if ((lIIlIllIlllIl(llllllllllllllllIllIIIllIIIllllI)) && (lIIlIllIllllI(llllllllllllllllIllIIIllIIIllllI instanceof GuiButton))) {
        llllllllllllllllIllIIIllIIIlllll.func_178019_b((GuiButton)llllllllllllllllIllIIIllIIIllllI, llllllllllllllllIllIIIllIIIlllIl, llllllllllllllllIllIIIllIIIlIlll, llllllllllllllllIllIIIllIIIllIll);
      }
    }
    
    public void mouseReleased(int llllllllllllllllIllIIIllIIlIlllI, int llllllllllllllllIllIIIllIIlIIlll, int llllllllllllllllIllIIIllIIlIIllI, int llllllllllllllllIllIIIllIIlIlIll, int llllllllllllllllIllIIIllIIlIlIlI, int llllllllllllllllIllIIIllIIlIlIIl)
    {
      ;
      ;
      ;
      ;
      llllllllllllllllIllIIIllIIlIlIII.func_178016_b(field_178029_b, llllllllllllllllIllIIIllIIlIIlll, llllllllllllllllIllIIIllIIlIIllI, llllllllllllllllIllIIIllIIlIlIll);
      llllllllllllllllIllIIIllIIlIlIII.func_178016_b(field_178030_c, llllllllllllllllIllIIIllIIlIIlll, llllllllllllllllIllIIIllIIlIIllI, llllllllllllllllIllIIIllIIlIlIll);
    }
    
    private static void lIIlIllIlllII()
    {
      llIIIlIIlll = new int[2];
      llIIIlIIlll[0] = ((" ".length() ^ 0xF5 ^ 0xB4) & ('Á' + '' - 253 + 158 ^ 62 + '' - 79 + 47 ^ -" ".length()));
      llIIIlIIlll[1] = " ".length();
    }
    
    private static boolean lIIlIllIlllIl(Object ???)
    {
      byte llllllllllllllllIllIIIllIIIIIIll;
      return ??? != null;
    }
    
    public Gui func_178021_b()
    {
      ;
      return field_178030_c;
    }
    
    private void func_178025_a(GuiLabel llllllllllllllllIllIIIlllIIIlIIl, int llllllllllllllllIllIIIlllIIIIIlI, int llllllllllllllllIllIIIlllIIIIIIl, int llllllllllllllllIllIIIlllIIIIIII, boolean llllllllllllllllIllIIIlllIIIIlIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      field_146174_h = llllllllllllllllIllIIIlllIIIIIlI;
      if (lIIlIllIlllll(llllllllllllllllIllIIIlllIIIIlIl)) {
        llllllllllllllllIllIIIlllIIIlIIl.drawLabel(field_178031_a, llllllllllllllllIllIIIlllIIIIIIl, llllllllllllllllIllIIIlllIIIIIII);
      }
    }
    
    private boolean func_178023_a(GuiButton llllllllllllllllIllIIIllIlIIIllI, int llllllllllllllllIllIIIllIlIIIlIl, int llllllllllllllllIllIIIllIlIIIlII, int llllllllllllllllIllIIIllIlIIlIIl)
    {
      ;
      ;
      ;
      ;
      ;
      boolean llllllllllllllllIllIIIllIlIIlIII = llllllllllllllllIllIIIllIlIIIllI.mousePressed(field_178031_a, llllllllllllllllIllIIIllIlIIlIll, llllllllllllllllIllIIIllIlIIIlII);
      if (lIIlIllIllllI(llllllllllllllllIllIIIllIlIIlIII)) {
        field_178028_d = llllllllllllllllIllIIIllIlIIIllI;
      }
      return llllllllllllllllIllIIIllIlIIlIII;
    }
    
    public void setSelected(int llllllllllllllllIllIIIllIllllIll, int llllllllllllllllIllIIIllIllllIlI, int llllllllllllllllIllIIIllIllllIIl)
    {
      ;
      ;
      llllllllllllllllIllIIIllIlllllII.func_178017_a(field_178029_b, llllllllllllllllIllIIIllIllllIIl, llIIIlIIlll[0], llIIIlIIlll[0], llIIIlIIlll[1]);
      llllllllllllllllIllIIIllIlllllII.func_178017_a(field_178030_c, llllllllllllllllIllIIIllIllllIIl, llIIIlIIlll[0], llIIIlIIlll[0], llIIIlIIlll[1]);
    }
    
    static {}
    
    public boolean mousePressed(int llllllllllllllllIllIIIllIllIllll, int llllllllllllllllIllIIIllIllIlllI, int llllllllllllllllIllIIIllIllIIlIl, int llllllllllllllllIllIIIllIllIIlII, int llllllllllllllllIllIIIllIllIlIll, int llllllllllllllllIllIIIllIllIlIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      boolean llllllllllllllllIllIIIllIllIlIIl = llllllllllllllllIllIIIllIllIIlll.func_178026_a(field_178029_b, llllllllllllllllIllIIIllIllIlllI, llllllllllllllllIllIIIllIllIIlIl, llllllllllllllllIllIIIllIllIIlII);
      boolean llllllllllllllllIllIIIllIllIlIII = llllllllllllllllIllIIIllIllIIlll.func_178026_a(field_178030_c, llllllllllllllllIllIIIllIllIlllI, llllllllllllllllIllIIIllIllIIlIl, llllllllllllllllIllIIIllIllIIlII);
      if ((lIIlIllIlllll(llllllllllllllllIllIIIllIllIlIIl)) && (lIIlIllIlllll(llllllllllllllllIllIIIllIllIlIII))) {
        return llIIIlIIlll[0];
      }
      return llIIIlIIlll[1];
    }
    
    public GuiEntry(Gui llllllllllllllllIllIIIllllIlIlll, Gui llllllllllllllllIllIIIllllIllIIl)
    {
      field_178029_b = llllllllllllllllIllIIIllllIllIlI;
      field_178030_c = llllllllllllllllIllIIIllllIllIIl;
    }
    
    private static boolean lIIlIllIlllll(int ???)
    {
      char llllllllllllllllIllIIIlIllllllIl;
      return ??? == 0;
    }
    
    private void func_178019_b(GuiButton llllllllllllllllIllIIIllIIIlIIIl, int llllllllllllllllIllIIIllIIIlIIII, int llllllllllllllllIllIIIllIIIIllll, int llllllllllllllllIllIIIllIIIIlllI)
    {
      ;
      ;
      ;
      llllllllllllllllIllIIIllIIIlIIIl.mouseReleased(llllllllllllllllIllIIIllIIIlIIII, llllllllllllllllIllIIIllIIIIllll);
    }
    
    private void func_178024_a(GuiButton llllllllllllllllIllIIIlllIIlllll, int llllllllllllllllIllIIIlllIIllllI, int llllllllllllllllIllIIIlllIIlllIl, int llllllllllllllllIllIIIlllIIlllII, boolean llllllllllllllllIllIIIlllIIllIll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      yPosition = llllllllllllllllIllIIIlllIIllllI;
      if (lIIlIllIlllll(llllllllllllllllIllIIIlllIIllIll)) {
        llllllllllllllllIllIIIlllIIlllll.drawButton(field_178031_a, llllllllllllllllIllIIIlllIIlllIl, llllllllllllllllIllIIIlllIIlllII);
      }
    }
    
    private static boolean lIIlIllIllllI(int ???)
    {
      double llllllllllllllllIllIIIlIllllllll;
      return ??? != 0;
    }
    
    public Gui func_178022_a()
    {
      ;
      return field_178029_b;
    }
    
    public void drawEntry(int llllllllllllllllIllIIIllllIIlIlI, int llllllllllllllllIllIIIllllIIlIIl, int llllllllllllllllIllIIIllllIIIIIl, int llllllllllllllllIllIIIllllIIIlll, int llllllllllllllllIllIIIllllIIIllI, int llllllllllllllllIllIIIllllIIIlIl, int llllllllllllllllIllIIIllllIIIlII, boolean llllllllllllllllIllIIIllllIIIIll)
    {
      ;
      ;
      ;
      ;
      llllllllllllllllIllIIIllllIIIIlI.func_178017_a(field_178029_b, llllllllllllllllIllIIIllllIIIIIl, llllllllllllllllIllIIIllllIIIIII, llllllllllllllllIllIIIllllIIIlII, llIIIlIIlll[0]);
      llllllllllllllllIllIIIllllIIIIlI.func_178017_a(field_178030_c, llllllllllllllllIllIIIllllIIIIIl, llllllllllllllllIllIIIllllIIIIII, llllllllllllllllIllIIIllllIIIlII, llIIIlIIlll[0]);
    }
    
    private void func_178027_a(GuiTextField llllllllllllllllIllIIIlllIIlIllI, int llllllllllllllllIllIIIlllIIlIlIl, boolean llllllllllllllllIllIIIlllIIlIlII)
    {
      ;
      ;
      ;
      yPosition = llllllllllllllllIllIIIlllIIlIIlI;
      if (lIIlIllIlllll(llllllllllllllllIllIIIlllIIlIlII)) {
        llllllllllllllllIllIIIlllIIlIllI.drawTextBox();
      }
    }
    
    private static boolean lIIlIlllIIIII(Object ???)
    {
      double llllllllllllllllIllIIIllIIIIIIIl;
      return ??? == null;
    }
    
    private boolean func_178026_a(Gui llllllllllllllllIllIIIllIlIlIllI, int llllllllllllllllIllIIIllIlIllIlI, int llllllllllllllllIllIIIllIlIllIIl, int llllllllllllllllIllIIIllIlIlIIll)
    {
      ;
      ;
      ;
      ;
      ;
      if (lIIlIlllIIIII(llllllllllllllllIllIIIllIlIlIllI)) {
        return llIIIlIIlll[0];
      }
      if (lIIlIllIllllI(llllllllllllllllIllIIIllIlIlIllI instanceof GuiButton)) {
        return llllllllllllllllIllIIIllIlIlllII.func_178023_a((GuiButton)llllllllllllllllIllIIIllIlIlIllI, llllllllllllllllIllIIIllIlIlIlIl, llllllllllllllllIllIIIllIlIllIIl, llllllllllllllllIllIIIllIlIlIIll);
      }
      if (lIIlIllIllllI(llllllllllllllllIllIIIllIlIlIllI instanceof GuiTextField)) {
        llllllllllllllllIllIIIllIlIlllII.func_178018_a((GuiTextField)llllllllllllllllIllIIIllIlIlIllI, llllllllllllllllIllIIIllIlIlIlIl, llllllllllllllllIllIIIllIlIllIIl, llllllllllllllllIllIIIllIlIlIIll);
      }
      return llIIIlIIlll[0];
    }
  }
  
  public static class GuiSlideEntry
    extends GuiPageButtonList.GuiListEntry
  {
    public float func_178942_g()
    {
      ;
      return field_178946_d;
    }
    
    public GuiSlideEntry(int llllllllllllllIlIIlllIlllllIIIII, String llllllllllllllIlIIlllIllllIlllll, boolean llllllllllllllIlIIlllIllllIllllI, GuiSlider.FormatHelper llllllllllllllIlIIlllIllllIlllIl, float llllllllllllllIlIIlllIlllllIIlII, float llllllllllllllIlIIlllIllllIllIll, float llllllllllllllIlIIlllIllllIllIlI)
    {
      llllllllllllllIlIIlllIlllllIIIIl.<init>(llllllllllllllIlIIlllIlllllIIIII, llllllllllllllIlIIlllIllllIlllll, llllllllllllllIlIIlllIllllIllllI);
      field_178949_a = llllllllllllllIlIIlllIllllIlllIl;
      field_178947_b = llllllllllllllIlIIlllIlllllIIlII;
      field_178948_c = llllllllllllllIlIIlllIllllIllIll;
      field_178946_d = llllllllllllllIlIIlllIllllIllIlI;
    }
    
    public float func_178943_e()
    {
      ;
      return field_178947_b;
    }
    
    public float func_178944_f()
    {
      ;
      return field_178948_c;
    }
    
    public GuiSlider.FormatHelper func_178945_a()
    {
      ;
      return field_178949_a;
    }
  }
}

package net.minecraft.client.gui;

import com.google.common.base.Charsets;
import com.google.common.util.concurrent.ThreadFactoryBuilder;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufInputStream;
import io.netty.buffer.Unpooled;
import java.awt.image.BufferedImage;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.network.OldServerPinger;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.ResourceLocation;
import org.apache.commons.lang3.Validate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ServerListEntryNormal
  implements GuiListExtended.IGuiListEntry
{
  private static String lIlIIIlllIllI(String llllllllllllllllIlIIlIllIlIlIlIl, String llllllllllllllllIlIIlIllIlIlIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIlIIlIllIlIllIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlIIlIllIlIlIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIlIIlIllIlIlIlll = Cipher.getInstance("Blowfish");
      llllllllllllllllIlIIlIllIlIlIlll.init(llIlIllIlIl[3], llllllllllllllllIlIIlIllIlIllIII);
      return new String(llllllllllllllllIlIIlIllIlIlIlll.doFinal(java.util.Base64.getDecoder().decode(llllllllllllllllIlIIlIllIlIlIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIlIIlIllIlIlIllI)
    {
      llllllllllllllllIlIIlIllIlIlIllI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlIIlIIIIlIl(int ???, int arg1)
  {
    int i;
    char llllllllllllllllIlIIlIllIIlIIlll;
    return ??? == i;
  }
  
  public boolean mousePressed(int llllllllllllllllIlIIlIllIllllIII, int llllllllllllllllIlIIlIllIlllIlll, int llllllllllllllllIlIIlIllIlllIllI, int llllllllllllllllIlIIlIllIlllIlIl, int llllllllllllllllIlIIlIllIlllIIII, int llllllllllllllllIlIIlIllIlllIIll)
  {
    ;
    ;
    ;
    ;
    if (lIlIIlIIIIIlI(llllllllllllllllIlIIlIllIlllIIII, llIlIllIlIl[8]))
    {
      if ((lIlIIIlllllIl(llllllllllllllllIlIIlIllIlllIIII, llIlIllIlIl[8])) && (lIlIIIlllllII(llllllllllllllllIlIIlIllIlllIIII, llIlIllIlIl[20])) && (lIlIIIlllllll(llllllllllllllllIlIIlIllIlllIIlI.func_178013_b())))
      {
        field_148303_c.selectServer(llllllllllllllllIlIIlIllIllllIII);
        field_148303_c.connectToSelected();
        return llIlIllIlIl[2];
      }
      if ((lIlIIIlllllIl(llllllllllllllllIlIIlIllIlllIIII, llIlIllIlIl[20])) && (lIlIIIlllllIl(llllllllllllllllIlIIlIllIlllIIll, llIlIllIlIl[20])) && (lIlIIIlllllll(field_148303_c.func_175392_a(llllllllllllllllIlIIlIllIlllIIlI, llllllllllllllllIlIIlIllIllllIII))))
      {
        field_148303_c.func_175391_a(llllllllllllllllIlIIlIllIlllIIlI, llllllllllllllllIlIIlIllIllllIII, GuiScreen.isShiftKeyDown());
        return llIlIllIlIl[2];
      }
      if ((lIlIIIlllllIl(llllllllllllllllIlIIlIllIlllIIII, llIlIllIlIl[20])) && (lIlIIIlllllII(llllllllllllllllIlIIlIllIlllIIll, llIlIllIlIl[20])) && (lIlIIIlllllll(field_148303_c.func_175394_b(llllllllllllllllIlIIlIllIlllIIlI, llllllllllllllllIlIIlIllIllllIII))))
      {
        field_148303_c.func_175393_b(llllllllllllllllIlIIlIllIlllIIlI, llllllllllllllllIlIIlIllIllllIII, GuiScreen.isShiftKeyDown());
        return llIlIllIlIl[2];
      }
    }
    field_148303_c.selectServer(llllllllllllllllIlIIlIllIllllIII);
    if (lIlIIlIIIIIII(lIlIIlIIIIllI(Minecraft.getSystemTime() - field_148298_f, 250L))) {
      field_148303_c.connectToSelected();
    }
    field_148298_f = Minecraft.getSystemTime();
    return llIlIllIlIl[1];
  }
  
  private static boolean lIlIIlIIIIlII(Object ???)
  {
    byte llllllllllllllllIlIIlIllIIIlIIll;
    return ??? == null;
  }
  
  private static boolean lIlIIlIIIIIlI(int ???, int arg1)
  {
    int i;
    double llllllllllllllllIlIIlIllIIIllIll;
    return ??? <= i;
  }
  
  private static boolean lIlIIlIIIIIIl(Object ???)
  {
    Exception llllllllllllllllIlIIlIllIIIlIlIl;
    return ??? != null;
  }
  
  private static int lIlIIIllllIlI(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  private static String lIlIIIlllIlIl(String llllllllllllllllIlIIlIllIIlIlllI, String llllllllllllllllIlIIlIllIIlIllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIlIIlIllIIllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlIIlIllIIlIllll.getBytes(StandardCharsets.UTF_8)), llIlIllIlIl[14]), "DES");
      Cipher llllllllllllllllIlIIlIllIIllIIlI = Cipher.getInstance("DES");
      llllllllllllllllIlIIlIllIIllIIlI.init(llIlIllIlIl[3], llllllllllllllllIlIIlIllIIllIIll);
      return new String(llllllllllllllllIlIIlIllIIllIIlI.doFinal(java.util.Base64.getDecoder().decode(llllllllllllllllIlIIlIllIIlIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIlIIlIllIIllIIIl)
    {
      llllllllllllllllIlIIlIllIIllIIIl.printStackTrace();
    }
    return null;
  }
  
  public void mouseReleased(int llllllllllllllllIlIIlIllIllIlIIl, int llllllllllllllllIlIIlIllIllIlIII, int llllllllllllllllIlIIlIllIllIIlll, int llllllllllllllllIlIIlIllIllIIllI, int llllllllllllllllIlIIlIllIllIIlIl, int llllllllllllllllIlIIlIllIllIIlII) {}
  
  private static boolean lIlIIIlllllIl(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllIlIIlIllIIIlllll;
    return ??? < i;
  }
  
  private static void lIlIIIllllIII()
  {
    llIlIllIlII = new String[llIlIllIlIl[24]];
    llIlIllIlII[llIlIllIlIl[1]] = lIlIIIlllIlIl("oqwFACOAtHx0/hllbg2TJp8XBfUFM9hv", "iteJn");
    llIlIllIlII[llIlIllIlIl[2]] = lIlIIIlllIlIl("sG8e/9o3aaGOwDvEeUvWGYk0gcs5n0Qky8EU/O1ztoKoi3pL+rLIhw==", "UiyYp");
    llIlIllIlII[llIlIllIlIl[3]] = lIlIIIlllIlIl("9fsdxLmS5ReMxsBLqZRmjKoEBFQjPG1h3WTc3FwkBof8spiZ2gl4mA==", "vekiw");
    llIlIllIlII[llIlIllIlIl[4]] = lIlIIIlllIllI("Xbl8qfuRP81z3rGKfq2Qug==", "LpaMe");
    llIlIllIlII[llIlIllIlIl[5]] = lIlIIIlllIlIl("26XdkcHEco4=", "KlAZk");
    llIlIllIlII[llIlIllIlIl[0]] = lIlIIIlllIllI("Qedzk8kwBMU=", "EwDdE");
    llIlIllIlII[llIlIllIlIl[6]] = lIlIIIlllIlll("", "UTjJR");
    llIlIllIlII[llIlIllIlIl[13]] = lIlIIIlllIllI("M1PGXyxXRlvGpShfJWP0XXQFEX1cQcJU", "poIaX");
    llIlIllIlII[llIlIllIlIl[14]] = lIlIIIlllIllI("ny4gHAoE6O+H28vd2XPKydDQzL85AmU0", "TuUpf");
    llIlIllIlII[llIlIllIlIl[15]] = lIlIIIlllIlIl("mwSOQg7vMLe/BCd9HTZJYw==", "ewXyq");
    llIlIllIlII[llIlIllIlIl[16]] = lIlIIIlllIlll("BTo=", "hILyE");
    llIlIllIlII[llIlIllIlIl[17]] = lIlIIIlllIllI("O0+9bUDPwCpDpldd+F1i3g==", "blFsG");
    llIlIllIlII[llIlIllIlIl[10]] = lIlIIIlllIlIl("uJE4bCjJa36Dx2rLfgkfXs6E24Ah5zyA", "OSwgQ");
    llIlIllIlII[llIlIllIlIl[22]] = lIlIIIlllIlll("ADkHOHEvKVR6ZW08HTQ0IT9UJDgqJA==", "MLtLQ");
    llIlIllIlII[llIlIllIlIl[23]] = lIlIIIlllIlIl("kq32ATPlduDgRhJa1N11KFXVVgJ4PMmuOajgvWljI5c=", "JZLbd");
    llIlIllIlII[llIlIllIlIl[12]] = lIlIIIlllIllI("jlSfnrgodlc=", "vGoTd");
    llIlIllIlII[llIlIllIlIl[20]] = lIlIIIlllIlll("eg==", "SeZlG");
  }
  
  private static boolean lIlIIIllllIll(int ???)
  {
    Exception llllllllllllllllIlIIlIllIIIIllll;
    return ??? == 0;
  }
  
  public void setSelected(int llllllllllllllllIlIIlIllIllIllIl, int llllllllllllllllIlIIlIllIllIllII, int llllllllllllllllIlIIlIllIllIlIll) {}
  
  private static boolean lIlIIIlllllII(int ???, int arg1)
  {
    int i;
    char llllllllllllllllIlIIlIllIIIlIlll;
    return ??? > i;
  }
  
  private static boolean lIlIIIlllllll(int ???)
  {
    int llllllllllllllllIlIIlIllIIIlIIIl;
    return ??? != 0;
  }
  
  public void drawEntry(int llllllllllllllllIlIIlIllllIlIIll, int llllllllllllllllIlIIlIllllIlIIlI, int llllllllllllllllIlIIlIlllIlIllll, int llllllllllllllllIlIIlIllllIlIIII, int llllllllllllllllIlIIlIllllIIllll, int llllllllllllllllIlIIlIllllIIlllI, int llllllllllllllllIlIIlIlllIlIllII, boolean llllllllllllllllIlIIlIllllIIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIIIllllIll(field_148301_e.field_78841_f))
    {
      field_148301_e.field_78841_f = llIlIllIlIl[2];
      field_148301_e.pingToServer = -2L;
      field_148301_e.serverMOTD = llIlIllIlII[llIlIllIlIl[0]];
      field_148301_e.populationInfo = llIlIllIlII[llIlIllIlIl[6]];
      new Runnable();
      {
        public void run()
        {
          try
          {
            ;
            ;
            field_148303_c.getOldServerPinger().ping(field_148301_e);
            "".length();
            if ((0x27 ^ 0x72 ^ 0x7 ^ 0x57) <= 0) {}
          }
          catch (UnknownHostException llllllllllllllIllIIllIIlIIlIIllI)
          {
            field_148301_e.pingToServer = -1L;
            field_148301_e.serverMOTD = String.valueOf(new StringBuilder().append(EnumChatFormatting.DARK_RED).append(lllllIIlIlll[lllllIIllIIl[0]]));
            "".length();
            if (null != null) {}
          }
          catch (Exception llllllllllllllIllIIllIIlIIlIIlIl)
          {
            field_148301_e.pingToServer = -1L;
            field_148301_e.serverMOTD = String.valueOf(new StringBuilder().append(EnumChatFormatting.DARK_RED).append(lllllIIlIlll[lllllIIllIIl[1]]));
          }
        }
        
        private static void lIlllllIIIllIl()
        {
          lllllIIllIIl = new int[4];
          lllllIIllIIl[0] = ((0x5E ^ 0x28 ^ 0x79 ^ 0x1) & (115 + 60 - 65 + 81 ^ 100 + 103 - 143 + 117 ^ -" ".length()));
          lllllIIllIIl[1] = " ".length();
          lllllIIllIIl[2] = "  ".length();
          lllllIIllIIl[3] = (0x6D ^ 0x75 ^ 0x7D ^ 0x6D);
        }
        
        private static void lIlllllIIIlIll()
        {
          lllllIIlIlll = new String[lllllIIllIIl[2]];
          lllllIIlIlll[lllllIIllIIl[0]] = lIlllllIIIlIIl("E+MIBmAcTkvGJ4csKBRAY2Iulfe9Q3DQ", "qLPZv");
          lllllIIlIlll[lllllIIllIIl[1]] = lIlllllIIIlIIl("JyG+UF42cddeJ93VE2ZtGVj90cXfLZaSGcCfP2ytxds=", "UnJME");
        }
        
        private static String lIlllllIIIlIIl(String llllllllllllllIllIIllIIlIIIllIll, String llllllllllllllIllIIllIIlIIIllIII)
        {
          try
          {
            ;
            ;
            ;
            ;
            SecretKeySpec llllllllllllllIllIIllIIlIIIllllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIllIIlIIIllIII.getBytes(StandardCharsets.UTF_8)), lllllIIllIIl[3]), "DES");
            Cipher llllllllllllllIllIIllIIlIIIlllIl = Cipher.getInstance("DES");
            llllllllllllllIllIIllIIlIIIlllIl.init(lllllIIllIIl[2], llllllllllllllIllIIllIIlIIIllllI);
            return new String(llllllllllllllIllIIllIIlIIIlllIl.doFinal(java.util.Base64.getDecoder().decode(llllllllllllllIllIIllIIlIIIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
          }
          catch (Exception llllllllllllllIllIIllIIlIIIlllII)
          {
            llllllllllllllIllIIllIIlIIIlllII.printStackTrace();
          }
          return null;
        }
        
        static
        {
          lIlllllIIIllIl();
          lIlllllIIIlIll();
        }
      };
      "".length();
    }
    if (lIlIIIlllllII(field_148301_e.version, llIlIllIlIl[7]))
    {
      "".length();
      if (-" ".length() <= 0) {
        break label136;
      }
    }
    label136:
    boolean llllllllllllllllIlIIlIllllIIlIll = llIlIllIlIl[1];
    if (lIlIIIlllllIl(field_148301_e.version, llIlIllIlIl[7]))
    {
      "".length();
      if (" ".length() > -" ".length()) {
        break label191;
      }
    }
    label191:
    boolean llllllllllllllllIlIIlIllllIIlIlI = llIlIllIlIl[1];
    if ((lIlIIIllllIll(llllllllllllllllIlIIlIllllIIlIll)) && (lIlIIIllllIll(llllllllllllllllIlIIlIllllIIlIlI)))
    {
      "".length();
      if (-"   ".length() < 0) {
        break label237;
      }
    }
    label237:
    boolean llllllllllllllllIlIIlIllllIIlIIl = llIlIllIlIl[2];
    "".length();
    List<String> llllllllllllllllIlIIlIllllIIlIII = Minecraft.fontRendererObj.listFormattedStringToWidth(field_148301_e.serverMOTD, llllllllllllllllIlIIlIlllIlIlllI - llIlIllIlIl[8] - llIlIllIlIl[3]);
    int llllllllllllllllIlIIlIllllIIIlll = llIlIllIlIl[1];
    "".length();
    if ("   ".length() == 0) {
      return;
    }
    while (!lIlIIIllllllI(llllllllllllllllIlIIlIllllIIIlll, Math.min(llllllllllllllllIlIIlIllllIIlIII.size(), llIlIllIlIl[3]))) {
      "".length();
    }
    llllllllllllllllIlIIlIllllIIIlll++;
    if (lIlIIIlllllll(llllllllllllllllIlIIlIllllIIlIIl))
    {
      new StringBuilder();
      "".length();
      if ((0x64 ^ 0x60) > "  ".length()) {
        break label492;
      }
    }
    label492:
    String llllllllllllllllIlIIlIllllIIIllI = field_148301_e.populationInfo;
    int llllllllllllllllIlIIlIllllIIIlIl = Minecraft.fontRendererObj.getStringWidth(llllllllllllllllIlIIlIllllIIIllI);
    "".length();
    int llllllllllllllllIlIIlIllllIIIlII = llIlIllIlIl[1];
    String llllllllllllllllIlIIlIllllIIIIll = null;
    label617:
    int llllllllllllllllIlIIlIlllIlllIll;
    String llllllllllllllllIlIIlIlllIllIlll;
    if (lIlIIIlllllll(llllllllllllllllIlIIlIllllIIlIIl))
    {
      int llllllllllllllllIlIIlIllllIIIIlI = llIlIllIlIl[0];
      if (lIlIIIlllllll(llllllllllllllllIlIIlIllllIIlIll))
      {
        "".length();
        if (null == null) {
          break label617;
        }
      }
      String llllllllllllllllIlIIlIlllIlllIlI = llIlIllIlII[llIlIllIlIl[14]];
      llllllllllllllllIlIIlIllllIIIIll = field_148301_e.playerList;
      "".length();
      if (-" ".length() <= -" ".length()) {}
    }
    else if ((lIlIIIlllllll(field_148301_e.field_78841_f)) && (lIlIIIlllllll(lIlIIIllllIlI(field_148301_e.pingToServer, -2L))))
    {
      int llllllllllllllllIlIIlIlllIllllII;
      if (lIlIIlIIIIIII(lIlIIIllllIlI(field_148301_e.pingToServer, 0L)))
      {
        int llllllllllllllllIlIIlIllllIIIIIl = llIlIllIlIl[0];
        "".length();
        if ("  ".length() < "   ".length()) {}
      }
      else if (lIlIIlIIIIIII(lIlIIIllllIlI(field_148301_e.pingToServer, 150L)))
      {
        int llllllllllllllllIlIIlIllllIIIIII = llIlIllIlIl[1];
        "".length();
        if (null == null) {}
      }
      else if (lIlIIlIIIIIII(lIlIIIllllIlI(field_148301_e.pingToServer, 300L)))
      {
        int llllllllllllllllIlIIlIlllIllllll = llIlIllIlIl[2];
        "".length();
        if ("   ".length() >= " ".length()) {}
      }
      else if (lIlIIlIIIIIII(lIlIIIllllIlI(field_148301_e.pingToServer, 600L)))
      {
        int llllllllllllllllIlIIlIlllIlllllI = llIlIllIlIl[3];
        "".length();
        if (null == null) {}
      }
      else if (lIlIIlIIIIIII(lIlIIIllllIlI(field_148301_e.pingToServer, 1000L)))
      {
        int llllllllllllllllIlIIlIlllIllllIl = llIlIllIlIl[4];
        "".length();
        if (null == null) {}
      }
      else
      {
        llllllllllllllllIlIIlIlllIllllII = llIlIllIlIl[5];
      }
      if (lIlIIlIIIIIII(lIlIIIllllIlI(field_148301_e.pingToServer, 0L)))
      {
        String llllllllllllllllIlIIlIlllIlllIIl = llIlIllIlII[llIlIllIlIl[15]];
        "".length();
        if ("  ".length() <= "  ".length()) {}
      }
      else
      {
        String llllllllllllllllIlIIlIlllIlllIII = String.valueOf(new StringBuilder(String.valueOf(field_148301_e.pingToServer)).append(llIlIllIlII[llIlIllIlIl[16]]));
        llllllllllllllllIlIIlIllllIIIIll = field_148301_e.playerList;
        "".length();
        if (-(0x4C ^ 0x70 ^ 0x17 ^ 0x2F) <= 0) {}
      }
    }
    else
    {
      llllllllllllllllIlIIlIllllIIIlII = llIlIllIlIl[2];
      llllllllllllllllIlIIlIlllIlllIll = (int)(Minecraft.getSystemTime() / 100L + llllllllllllllllIlIIlIllllIlIIll * llIlIllIlIl[3] & 0x7);
      if (lIlIIIlllllII(llllllllllllllllIlIIlIlllIlllIll, llIlIllIlIl[5])) {
        llllllllllllllllIlIIlIlllIlllIll = llIlIllIlIl[14] - llllllllllllllllIlIIlIlllIlllIll;
      }
      llllllllllllllllIlIIlIlllIllIlll = llIlIllIlII[llIlIllIlIl[17]];
    }
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(Gui.icons);
    Gui.drawModalRectWithCustomSizedTexture(llllllllllllllllIlIIlIllllIlIIlI + llllllllllllllllIlIIlIlllIlIlllI - llIlIllIlIl[12], llllllllllllllllIlIIlIlllIlIllll, llllllllllllllllIlIIlIllllIIIlII * llIlIllIlIl[16], llIlIllIlIl[18] + llllllllllllllllIlIIlIlllIlllIll * llIlIllIlIl[14], llIlIllIlIl[16], llIlIllIlIl[14], 256.0F, 256.0F);
    if ((lIlIIlIIIIIIl(field_148301_e.getBase64EncodedIconData())) && (lIlIIIllllIll(field_148301_e.getBase64EncodedIconData().equals(field_148299_g))))
    {
      field_148299_g = field_148301_e.getBase64EncodedIconData();
      llllllllllllllllIlIIlIlllIllIIlI.prepareServerIcon();
      field_148303_c.getServerList().saveServerList();
    }
    if (lIlIIlIIIIIIl(field_148305_h))
    {
      llllllllllllllllIlIIlIlllIllIIlI.func_178012_a(llllllllllllllllIlIIlIllllIlIIlI, llllllllllllllllIlIIlIlllIlIllll, field_148306_i);
      "".length();
      if ((0x4F ^ 0x4A) != 0) {}
    }
    else
    {
      llllllllllllllllIlIIlIlllIllIIlI.func_178012_a(llllllllllllllllIlIIlIllllIlIIlI, llllllllllllllllIlIIlIlllIlIllll, UNKNOWN_SERVER);
    }
    int llllllllllllllllIlIIlIlllIllIllI = llllllllllllllllIlIIlIllllIIlllI - llllllllllllllllIlIIlIllllIlIIlI;
    int llllllllllllllllIlIIlIlllIllIlIl = llllllllllllllllIlIIlIlllIlIllII - llllllllllllllllIlIIlIlllIlIllll;
    if ((lIlIIIllllllI(llllllllllllllllIlIIlIlllIllIllI, llllllllllllllllIlIIlIlllIlIlllI - llIlIllIlIl[12])) && (lIlIIlIIIIIlI(llllllllllllllllIlIIlIlllIllIllI, llllllllllllllllIlIIlIlllIlIlllI - llIlIllIlIl[0])) && (lIlIIlIIIIIll(llllllllllllllllIlIIlIlllIllIlIl)) && (lIlIIlIIIIIlI(llllllllllllllllIlIIlIlllIllIlIl, llIlIllIlIl[14])))
    {
      field_148303_c.setHoveringText(llllllllllllllllIlIIlIlllIllIlll);
      "".length();
      if (null == null) {}
    }
    else if ((lIlIIIllllllI(llllllllllllllllIlIIlIlllIllIllI, llllllllllllllllIlIIlIlllIlIlllI - llllllllllllllllIlIIlIllllIIIlIl - llIlIllIlIl[12] - llIlIllIlIl[3])) && (lIlIIlIIIIIlI(llllllllllllllllIlIIlIlllIllIllI, llllllllllllllllIlIIlIlllIlIlllI - llIlIllIlIl[12] - llIlIllIlIl[3])) && (lIlIIlIIIIIll(llllllllllllllllIlIIlIlllIllIlIl)) && (lIlIIlIIIIIlI(llllllllllllllllIlIIlIlllIllIlIl, llIlIllIlIl[14])))
    {
      field_148303_c.setHoveringText(llllllllllllllllIlIIlIllllIIIIll);
    }
    if ((!lIlIIIllllIll(mc.gameSettings.touchscreen)) || (lIlIIIlllllll(llllllllllllllllIlIIlIllllIIllII)))
    {
      mc.getTextureManager().bindTexture(SERVER_SELECTION_BUTTONS);
      Gui.drawRect(llllllllllllllllIlIIlIllllIlIIlI, llllllllllllllllIlIIlIlllIlIllll, llllllllllllllllIlIIlIllllIlIIlI + llIlIllIlIl[8], llllllllllllllllIlIIlIlllIlIllll + llIlIllIlIl[8], llIlIllIlIl[19]);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      int llllllllllllllllIlIIlIlllIllIlII = llllllllllllllllIlIIlIllllIIlllI - llllllllllllllllIlIIlIllllIlIIlI;
      int llllllllllllllllIlIIlIlllIllIIll = llllllllllllllllIlIIlIlllIlIllII - llllllllllllllllIlIIlIlllIlIllll;
      if (lIlIIIlllllll(llllllllllllllllIlIIlIlllIllIIlI.func_178013_b())) {
        if ((lIlIIIlllllIl(llllllllllllllllIlIIlIlllIllIlII, llIlIllIlIl[8])) && (lIlIIIlllllII(llllllllllllllllIlIIlIlllIllIlII, llIlIllIlIl[20])))
        {
          Gui.drawModalRectWithCustomSizedTexture(llllllllllllllllIlIIlIllllIlIIlI, llllllllllllllllIlIIlIlllIlIllll, 0.0F, 32.0F, llIlIllIlIl[8], llIlIllIlIl[8], 256.0F, 256.0F);
          "".length();
          if (((104 + 79 - 150 + 115 ^ 121 + 109 - 159 + 85) & (0x24 ^ 0x73 ^ 0xD5 ^ 0x8A ^ -" ".length())) == 0) {}
        }
        else
        {
          Gui.drawModalRectWithCustomSizedTexture(llllllllllllllllIlIIlIllllIlIIlI, llllllllllllllllIlIIlIlllIlIllll, 0.0F, 0.0F, llIlIllIlIl[8], llIlIllIlIl[8], 256.0F, 256.0F);
        }
      }
      if (lIlIIIlllllll(field_148303_c.func_175392_a(llllllllllllllllIlIIlIlllIllIIlI, llllllllllllllllIlIIlIllllIlIIll))) {
        if ((lIlIIIlllllIl(llllllllllllllllIlIIlIlllIllIlII, llIlIllIlIl[20])) && (lIlIIIlllllIl(llllllllllllllllIlIIlIlllIllIIll, llIlIllIlIl[20])))
        {
          Gui.drawModalRectWithCustomSizedTexture(llllllllllllllllIlIIlIllllIlIIlI, llllllllllllllllIlIIlIlllIlIllll, 96.0F, 32.0F, llIlIllIlIl[8], llIlIllIlIl[8], 256.0F, 256.0F);
          "".length();
          if (null == null) {}
        }
        else
        {
          Gui.drawModalRectWithCustomSizedTexture(llllllllllllllllIlIIlIllllIlIIlI, llllllllllllllllIlIIlIlllIlIllll, 96.0F, 0.0F, llIlIllIlIl[8], llIlIllIlIl[8], 256.0F, 256.0F);
        }
      }
      if (lIlIIIlllllll(field_148303_c.func_175394_b(llllllllllllllllIlIIlIlllIllIIlI, llllllllllllllllIlIIlIllllIlIIll))) {
        if ((lIlIIIlllllIl(llllllllllllllllIlIIlIlllIllIlII, llIlIllIlIl[20])) && (lIlIIIlllllII(llllllllllllllllIlIIlIlllIllIIll, llIlIllIlIl[20])))
        {
          Gui.drawModalRectWithCustomSizedTexture(llllllllllllllllIlIIlIllllIlIIlI, llllllllllllllllIlIIlIlllIlIllll, 64.0F, 32.0F, llIlIllIlIl[8], llIlIllIlIl[8], 256.0F, 256.0F);
          "".length();
          if (((0xBA ^ 0xBD) & (0x9D ^ 0x9A ^ 0xFFFFFFFF)) == 0) {}
        }
        else
        {
          Gui.drawModalRectWithCustomSizedTexture(llllllllllllllllIlIIlIllllIlIIlI, llllllllllllllllIlIIlIlllIlIllll, 64.0F, 0.0F, llIlIllIlIl[8], llIlIllIlIl[8], 256.0F, 256.0F);
        }
      }
    }
  }
  
  static
  {
    lIlIIIllllIIl();
    lIlIIIllllIII();
    logger = LogManager.getLogger();
    field_148302_b = new ScheduledThreadPoolExecutor(llIlIllIlIl[0], new ThreadFactoryBuilder().setNameFormat(llIlIllIlII[llIlIllIlIl[1]]).setDaemon(llIlIllIlIl[2]).build());
    UNKNOWN_SERVER = new ResourceLocation(llIlIllIlII[llIlIllIlIl[2]]);
  }
  
  private boolean func_178013_b()
  {
    return llIlIllIlIl[2];
  }
  
  private static boolean lIlIIIllllllI(int ???, int arg1)
  {
    int i;
    long llllllllllllllllIlIIlIllIIlIIIll;
    return ??? >= i;
  }
  
  private static void lIlIIIllllIIl()
  {
    llIlIllIlIl = new int[25];
    llIlIllIlIl[0] = (0x17 ^ 0x3E ^ 0x82 ^ 0xAE);
    llIlIllIlIl[1] = ((12 + 65 - 51 + 102 ^ '' + 73 - 132 + 71) & (0x76 ^ 0x57 ^ 0x25 ^ 0x22 ^ -" ".length()));
    llIlIllIlIl[2] = " ".length();
    llIlIllIlIl[3] = "  ".length();
    llIlIllIlIl[4] = "   ".length();
    llIlIllIlIl[5] = (0x43 ^ 0x55 ^ 0xB4 ^ 0xA6);
    llIlIllIlIl[6] = (0xC ^ 0xA);
    llIlIllIlIl[7] = (0x3C ^ 0x5F ^ 0x4E ^ 0x2);
    llIlIllIlIl[8] = (0x3 ^ 0x44 ^ 0xFF ^ 0x98);
    llIlIllIlIl[9] = (0xFFFFFFFF & 0xFFFFFF);
    llIlIllIlIl[10] = (0xAE ^ 0xA2);
    llIlIllIlIl[11] = (-(0xE76C & 0x3997) & 0xE7A7 & 0x80B9DB);
    llIlIllIlIl[12] = (48 + 108 - 104 + 84 ^ 89 + 24 - 11 + 33);
    llIlIllIlIl[13] = (0xD1 ^ 0xB1 ^ 0xDC ^ 0xBB);
    llIlIllIlIl[14] = (0xD1 ^ 0x95 ^ 0xD3 ^ 0x9F);
    llIlIllIlIl[15] = (0x90 ^ 0x99);
    llIlIllIlIl[16] = (0x4D ^ 0x53 ^ 0x27 ^ 0x33);
    llIlIllIlIl[17] = (0x61 ^ 0x6A);
    llIlIllIlIl[18] = ((0x26 ^ 0x46) + (88 + 30 - 74 + 88) - (77 + '' - 69 + 6) + (0x6D ^ 0x33));
    llIlIllIlIl[19] = (-(0xEF79 & 0x5F6F7FF6));
    llIlIllIlIl[20] = (0x96 ^ 0x86);
    llIlIllIlIl[21] = (13 + 78 - 90 + 200 ^ '' + 37 - 154 + 122);
    llIlIllIlIl[22] = (0x9F ^ 0x92);
    llIlIllIlIl[23] = (0x23 ^ 0x2D);
    llIlIllIlIl[24] = (0xFA ^ 0xA6 ^ 0x1E ^ 0x53);
  }
  
  public ServerData getServerData()
  {
    ;
    return field_148301_e;
  }
  
  protected ServerListEntryNormal(GuiMultiplayer llllllllllllllllIlIIlIlllllIllll, ServerData llllllllllllllllIlIIlIlllllIlllI)
  {
    field_148303_c = llllllllllllllllIlIIlIlllllIllII;
    field_148301_e = llllllllllllllllIlIIlIlllllIlllI;
    mc = Minecraft.getMinecraft();
    field_148306_i = new ResourceLocation(String.valueOf(new StringBuilder(llIlIllIlII[llIlIllIlIl[4]]).append(serverIP).append(llIlIllIlII[llIlIllIlIl[5]])));
    field_148305_h = ((DynamicTexture)mc.getTextureManager().getTexture(field_148306_i));
  }
  
  private static String lIlIIIlllIlll(String llllllllllllllllIlIIlIllIlIIIIII, String llllllllllllllllIlIIlIllIlIIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIlIIlIllIlIIIIII = new String(java.util.Base64.getDecoder().decode(llllllllllllllllIlIIlIllIlIIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIlIIlIllIlIIIIll = new StringBuilder();
    char[] llllllllllllllllIlIIlIllIlIIIIlI = llllllllllllllllIlIIlIllIlIIIlII.toCharArray();
    int llllllllllllllllIlIIlIllIlIIIIIl = llIlIllIlIl[1];
    Exception llllllllllllllllIlIIlIllIIlllIll = llllllllllllllllIlIIlIllIlIIIIII.toCharArray();
    char llllllllllllllllIlIIlIllIIlllIlI = llllllllllllllllIlIIlIllIIlllIll.length;
    byte llllllllllllllllIlIIlIllIIlllIIl = llIlIllIlIl[1];
    while (lIlIIIlllllIl(llllllllllllllllIlIIlIllIIlllIIl, llllllllllllllllIlIIlIllIIlllIlI))
    {
      char llllllllllllllllIlIIlIllIlIIIllI = llllllllllllllllIlIIlIllIIlllIll[llllllllllllllllIlIIlIllIIlllIIl];
      "".length();
      "".length();
      if (((0xF ^ 0x3B) & (0xE ^ 0x3A ^ 0xFFFFFFFF)) == "   ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIlIIlIllIlIIIIll);
  }
  
  protected void func_178012_a(int llllllllllllllllIlIIlIlllIIlIlll, int llllllllllllllllIlIIlIlllIIlIIlI, ResourceLocation llllllllllllllllIlIIlIlllIIlIIIl)
  {
    ;
    ;
    ;
    ;
    mc.getTextureManager().bindTexture(llllllllllllllllIlIIlIlllIIlIIIl);
    GlStateManager.enableBlend();
    Gui.drawModalRectWithCustomSizedTexture(llllllllllllllllIlIIlIlllIIlIlll, llllllllllllllllIlIIlIlllIIlIIlI, 0.0F, 0.0F, llIlIllIlIl[8], llIlIllIlIl[8], 32.0F, 32.0F);
    GlStateManager.disableBlend();
  }
  
  private void prepareServerIcon()
  {
    ;
    ;
    ;
    ;
    ;
    if (lIlIIlIIIIlII(field_148301_e.getBase64EncodedIconData()))
    {
      mc.getTextureManager().deleteTexture(field_148306_i);
      field_148305_h = null;
      "".length();
      if ((("   ".length() ^ 0x21 ^ 0x1B) & (59 + 126 - 130 + 73 ^ 5 + '®' - 61 + 67 ^ -" ".length())) < (0x4C ^ 0x29 ^ 0x47 ^ 0x26)) {}
    }
    else
    {
      ByteBuf llllllllllllllllIlIIlIlllIIIlIII = Unpooled.copiedBuffer(field_148301_e.getBase64EncodedIconData(), Charsets.UTF_8);
      ByteBuf llllllllllllllllIlIIlIlllIIIIlll = io.netty.handler.codec.base64.Base64.decode(llllllllllllllllIlIIlIlllIIIlIII);
      try
      {
        BufferedImage llllllllllllllllIlIIlIlllIIIIllI = TextureUtil.readBufferedImage(new ByteBufInputStream(llllllllllllllllIlIIlIlllIIIIlll));
        if (lIlIIlIIIIlIl(llllllllllllllllIlIIlIlllIIIIllI.getWidth(), llIlIllIlIl[21]))
        {
          "".length();
          if ("  ".length() == "  ".length()) {
            break label179;
          }
        }
        label179:
        Validate.validState(llIlIllIlIl[1], llIlIllIlII[llIlIllIlIl[10]], new Object[llIlIllIlIl[1]]);
        if (lIlIIlIIIIlIl(llllllllllllllllIlIIlIlllIIIIllI.getHeight(), llIlIllIlIl[21]))
        {
          "".length();
          if ("  ".length() != 0) {
            break label243;
          }
        }
        label243:
        Validate.validState(llIlIllIlIl[1], llIlIllIlII[llIlIllIlIl[22]], new Object[llIlIllIlIl[1]]);
        "".length();
        "".length();
        "".length();
        if ((('¬' + '' - 203 + 111 ^ 20 + 101 - 60 + 96) & (0x9 ^ 0x4F ^ 0x96 ^ 0x9E ^ -" ".length())) <= 0) {
          break label493;
        }
        return;
      }
      catch (Throwable llllllllllllllllIlIIlIlllIIIIlII)
      {
        logger.error(String.valueOf(new StringBuilder(llIlIllIlII[llIlIllIlIl[23]]).append(field_148301_e.serverName).append(llIlIllIlII[llIlIllIlIl[12]]).append(field_148301_e.serverIP).append(llIlIllIlII[llIlIllIlIl[20]])), llllllllllllllllIlIIlIlllIIIIlII);
        field_148301_e.setBase64EncodedIconData(null);
        "".length();
        "".length();
        "".length();
        if (null != null) {
          return;
        }
      }
      finally
      {
        "".length();
        "".length();
      }
      return;
      label493:
      BufferedImage llllllllllllllllIlIIlIlllIIIIlIl;
      if (lIlIIlIIIIlII(field_148305_h))
      {
        field_148305_h = new DynamicTexture(llllllllllllllllIlIIlIlllIIIIlIl.getWidth(), llllllllllllllllIlIIlIlllIIIIlIl.getHeight());
        "".length();
      }
      "".length();
      field_148305_h.updateDynamicTexture();
    }
  }
  
  private static boolean lIlIIlIIIIIll(int ???)
  {
    byte llllllllllllllllIlIIlIllIIIIllIl;
    return ??? >= 0;
  }
  
  private static int lIlIIlIIIIllI(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  private static boolean lIlIIlIIIIIII(int ???)
  {
    String llllllllllllllllIlIIlIllIIIIlIll;
    return ??? < 0;
  }
}

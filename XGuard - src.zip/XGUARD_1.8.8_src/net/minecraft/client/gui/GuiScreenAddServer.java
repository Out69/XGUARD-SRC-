package net.minecraft.client.gui;

import com.google.common.base.Predicate;
import java.io.IOException;
import java.net.IDN;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerData.ServerResourceMode;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.IChatComponent;
import org.lwjgl.input.Keyboard;

public class GuiScreenAddServer
  extends GuiScreen
{
  private static void lIIIlIllIl()
  {
    lIlIlIlI = new String[lIlIllIl[29]];
    lIlIlIlI[lIlIllIl[1]] = lIIIlIlIlI("FigQKzAFOhEKexYoEA==", "wLtxU");
    lIlIlIlI[lIlIllIl[0]] = lIIIlIlIlI("ECUlZBcWPi8vGA==", "wPLJt");
    lIlIlIlI[lIlIllIl[2]] = lIIIlIlIll("vq8vo1eDWFB5dhXBYFMXcN9Wn9FdqC2V", "GDSQy");
    lIlIlIlI[lIlIllIl[9]] = lIIIlIlIlI("SXM=", "sSdJc");
    lIlIlIlI[lIlIllIl[4]] = lIIIlIlIlI("bg==", "TZvWU");
    lIlIlIlI[lIlIllIl[15]] = lIIIlIllII("Ux61HY1VIUvZErqipEZh8cg5FcytFeNb", "uLBVN");
    lIlIlIlI[lIlIllIl[16]] = lIIIlIlIll("m38zWcUx5pA=", "tleRQ");
    lIlIlIlI[lIlIllIl[20]] = lIIIlIllII("r9tx9kID7Vc=", "aIVEz");
    lIlIlIlI[lIlIllIl[21]] = lIIIlIlIlI("JTMXIjc2IRYDfDA+Bx03", "DWsqR");
    lIlIlIlI[lIlIllIl[24]] = lIIIlIlIlI("MRU8PDYiBz0dfTUfLAohHhA1Cg==", "PqXoS");
    lIlIlIlI[lIlIllIl[27]] = lIIIlIlIlI("AwUOOAAQFw8ZSwcPHg4XKxE=", "bajke");
  }
  
  private static boolean lIIIlllIlI(int ???, int arg1)
  {
    int i;
    short lIllllIIIlIIlll;
    return ??? < i;
  }
  
  public GuiScreenAddServer(GuiScreen lIllllIlIlllllI, ServerData lIllllIllIIIIII)
  {
    parentScreen = lIllllIllIIIIIl;
    serverData = lIllllIllIIIIII;
  }
  
  public void initGui()
  {
    ;
    Keyboard.enableRepeatEvents(lIlIllIl[0]);
    buttonList.clear();
    new GuiButton(lIlIllIl[1], width / lIlIllIl[2] - lIlIllIl[3], height / lIlIllIl[4] + lIlIllIl[5] + lIlIllIl[6], I18n.format(lIlIlIlI[lIlIllIl[1]], new Object[lIlIllIl[1]]));
    "".length();
    new GuiButton(lIlIllIl[0], width / lIlIllIl[2] - lIlIllIl[3], height / lIlIllIl[4] + lIlIllIl[7] + lIlIllIl[6], I18n.format(lIlIlIlI[lIlIllIl[0]], new Object[lIlIllIl[1]]));
    "".length();
    serverResourcePacks = new GuiButton(lIlIllIl[2], width / lIlIllIl[2] - lIlIllIl[3], height / lIlIllIl[4] + lIlIllIl[8], String.valueOf(new StringBuilder(String.valueOf(I18n.format(lIlIlIlI[lIlIllIl[2]], new Object[lIlIllIl[1]]))).append(lIlIlIlI[lIlIllIl[9]]).append(serverData.getResourceMode().getMotd().getFormattedText())));
    "".length();
    serverNameField = new GuiTextField(lIlIllIl[1], fontRendererObj, width / lIlIllIl[2] - lIlIllIl[3], lIlIllIl[10], lIlIllIl[11], lIlIllIl[12]);
    serverNameField.setFocused(lIlIllIl[0]);
    serverNameField.setText(serverData.serverName);
    serverIPField = new GuiTextField(lIlIllIl[0], fontRendererObj, width / lIlIllIl[2] - lIlIllIl[3], lIlIllIl[13], lIlIllIl[11], lIlIllIl[12]);
    serverIPField.setMaxStringLength(lIlIllIl[14]);
    serverIPField.setText(serverData.serverIP);
    serverIPField.func_175205_a(field_181032_r);
    if ((lIIIllIlIl(serverIPField.getText().length())) && (lIIIllIlIl(serverIPField.getText().split(lIlIlIlI[lIlIllIl[4]]).length)) && (lIIIllIlIl(serverNameField.getText().length())))
    {
      "".length();
      if (-(0xA2 ^ 0xAC ^ 0x8F ^ 0x85) <= 0) {
        break label602;
      }
    }
    label602:
    lIlIllIl0enabled = lIlIllIl[1];
  }
  
  private static String lIIIlIllII(String lIllllIIlllIlll, String lIllllIIlllIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIllllIIllllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIllllIIlllIlII.getBytes(StandardCharsets.UTF_8)), lIlIllIl[21]), "DES");
      Cipher lIllllIIllllIIl = Cipher.getInstance("DES");
      lIllllIIllllIIl.init(lIlIllIl[2], lIllllIIllllIlI);
      return new String(lIllllIIllllIIl.doFinal(Base64.getDecoder().decode(lIllllIIlllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIllllIIllllIII)
    {
      lIllllIIllllIII.printStackTrace();
    }
    return null;
  }
  
  public void drawScreen(int lIllllIlIIlIIIl, int lIllllIlIIlIlII, float lIllllIlIIIllll)
  {
    ;
    ;
    ;
    ;
    lIllllIlIIlIIlI.drawDefaultBackground();
    lIllllIlIIlIIlI.drawCenteredString(fontRendererObj, I18n.format(lIlIlIlI[lIlIllIl[21]], new Object[lIlIllIl[1]]), width / lIlIllIl[2], lIlIllIl[22], lIlIllIl[23]);
    lIllllIlIIlIIlI.drawString(fontRendererObj, I18n.format(lIlIlIlI[lIlIllIl[24]], new Object[lIlIllIl[1]]), width / lIlIllIl[2] - lIlIllIl[3], lIlIllIl[25], lIlIllIl[26]);
    lIllllIlIIlIIlI.drawString(fontRendererObj, I18n.format(lIlIlIlI[lIlIllIl[27]], new Object[lIlIllIl[1]]), width / lIlIllIl[2] - lIlIllIl[3], lIlIllIl[28], lIlIllIl[26]);
    serverNameField.drawTextBox();
    serverIPField.drawTextBox();
    lIllllIlIIlIIlI.drawScreen(lIllllIlIIlIIIl, lIllllIlIIlIlII, lIllllIlIIIllll);
  }
  
  private static boolean lIIIlllIIl(int ???, int arg1)
  {
    int i;
    char lIllllIIIIllIll;
    return ??? != i;
  }
  
  protected void keyTyped(char lIllllIlIlIlIII, int lIllllIlIlIlIlI)
    throws IOException
  {
    ;
    ;
    ;
    "".length();
    "".length();
    if (lIIIllIlll(lIllllIlIlIlIlI, lIlIllIl[17]))
    {
      if (lIIIllIllI(serverNameField.isFocused()))
      {
        "".length();
        if (null == null) {
          break label81;
        }
      }
      label81:
      lIlIllIl[1].setFocused(lIlIllIl[0]);
      if (lIIIllIllI(serverIPField.isFocused()))
      {
        "".length();
        if (((0x1A ^ 0x5E) & (0x2D ^ 0x69 ^ 0xFFFFFFFF)) <= 0) {
          break label134;
        }
      }
      label134:
      lIlIllIl[1].setFocused(lIlIllIl[0]);
    }
    if ((!lIIIlllIIl(lIllllIlIlIlIlI, lIlIllIl[18])) || (lIIIllIlll(lIllllIlIlIlIlI, lIlIllIl[19]))) {
      lIllllIlIlIlIIl.actionPerformed((GuiButton)buttonList.get(lIlIllIl[1]));
    }
    if ((lIIIllIlIl(serverIPField.getText().length())) && (lIIIllIlIl(serverIPField.getText().split(lIlIlIlI[lIlIllIl[20]]).length)) && (lIIIllIlIl(serverNameField.getText().length())))
    {
      "".length();
      if (((0x48 ^ 0x11 ^ 0x5 ^ 0xE) & (97 + 119 - 168 + 180 ^ 107 + 28 - 25 + 72 ^ -" ".length())) > -" ".length()) {
        break label331;
      }
    }
    label331:
    lIlIllIl0enabled = lIlIllIl[1];
  }
  
  protected void mouseClicked(int lIllllIlIIlllIl, int lIllllIlIIlllII, int lIllllIlIIlllll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    lIllllIlIlIIIlI.mouseClicked(lIllllIlIIlllIl, lIllllIlIIlllII, lIllllIlIIlllll);
    serverIPField.mouseClicked(lIllllIlIIlllIl, lIllllIlIIlllII, lIllllIlIIlllll);
    serverNameField.mouseClicked(lIllllIlIIlllIl, lIllllIlIIlllII, lIllllIlIIlllll);
  }
  
  public void updateScreen()
  {
    ;
    serverNameField.updateCursorCounter();
    serverIPField.updateCursorCounter();
  }
  
  private static String lIIIlIlIlI(String lIllllIIlIllIll, String lIllllIIlIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIllllIIlIllIll = new String(Base64.getDecoder().decode(lIllllIIlIllIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIllllIIlIllllI = new StringBuilder();
    char[] lIllllIIlIlllIl = lIllllIIlIllIlI.toCharArray();
    int lIllllIIlIlllII = lIlIllIl[1];
    short lIllllIIlIlIIll = lIllllIIlIllIll.toCharArray();
    double lIllllIIlIlIIIl = lIllllIIlIlIIll.length;
    long lIllllIIlIIllll = lIlIllIl[1];
    while (lIIIlllIlI(lIllllIIlIIllll, lIllllIIlIlIIIl))
    {
      char lIllllIIllIIIIl = lIllllIIlIlIIll[lIllllIIlIIllll];
      "".length();
      "".length();
      if (((0x6B ^ 0x38) & (0xF7 ^ 0xA4 ^ 0xFFFFFFFF)) != ((0xB ^ 0x4C) & (0x7D ^ 0x3A ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(lIllllIIlIllllI);
  }
  
  public void onGuiClosed()
  {
    Keyboard.enableRepeatEvents(lIlIllIl[1]);
  }
  
  private static boolean lIIIllIlIl(int ???)
  {
    short lIllllIIIIlllll;
    return ??? > 0;
  }
  
  private static void lIIIllIlII()
  {
    lIlIllIl = new int[30];
    lIlIllIl[0] = " ".length();
    lIlIllIl[1] = ((0x7D ^ 0xD ^ 0xB0 ^ 0xA2) & (0x71 ^ 0x74 ^ 0x4A ^ 0x2D ^ -" ".length()));
    lIlIllIl[2] = "  ".length();
    lIlIllIl[3] = (0x67 ^ 0x3);
    lIlIllIl[4] = (0x26 ^ 0x5F ^ 0x23 ^ 0x5E);
    lIlIllIl[5] = (0x6A ^ 0xA);
    lIlIllIl[6] = (0xA8 ^ 0xBA);
    lIlIllIl[7] = (0xE3 ^ 0x9B);
    lIlIllIl[8] = (0x1A ^ 0x52);
    lIlIllIl[9] = "   ".length();
    lIlIllIl[10] = (0x34 ^ 0x76);
    lIlIllIl[11] = ((0xF7 ^ 0x8B) + (19 + 47 - -30 + 48) - ('Ì' + 'Ï' - 380 + 196) + (11 + 10 - 4 + 142));
    lIlIllIl[12] = (0x5E ^ 0x20 ^ 0xC0 ^ 0xAA);
    lIlIllIl[13] = (0x7C ^ 0x16);
    lIlIllIl[14] = (120 + 97 - 191 + 102);
    lIlIllIl[15] = (0x8A ^ 0x8F);
    lIlIllIl[16] = (0x2D ^ 0x5 ^ 0xA2 ^ 0x8C);
    lIlIllIl[17] = (0x96 ^ 0xB6 ^ 0x36 ^ 0x19);
    lIlIllIl[18] = (0x4E ^ 0x3E ^ 0x76 ^ 0x1A);
    lIlIllIl[19] = ('' + '' - 233 + 103);
    lIlIllIl[20] = (0xA6 ^ 0xA1);
    lIlIllIl[21] = (0x1E ^ 0x4 ^ 0xE ^ 0x1C);
    lIlIllIl[22] = (0xAA ^ 0xBB);
    lIlIllIl[23] = (0xFFFFFFFF & 0xFFFFFF);
    lIlIllIl[24] = (0x53 ^ 0x5A);
    lIlIllIl[25] = (0x1A ^ 0x2F);
    lIlIllIl[26] = (0xB8FF & 0xA0E7A0);
    lIlIllIl[27] = (0x9B ^ 0xC1 ^ 0x72 ^ 0x22);
    lIlIllIl[28] = (0x66 ^ 0x38);
    lIlIllIl[29] = (0x19 ^ 0x12);
  }
  
  private static boolean lIIIllIllI(int ???)
  {
    short lIllllIIIlIIlIl;
    return ??? != 0;
  }
  
  protected void actionPerformed(GuiButton lIllllIlIllIIlI)
    throws IOException
  {
    ;
    ;
    if (lIIIllIllI(enabled)) {
      if (lIIIllIlll(id, lIlIllIl[2]))
      {
        serverData.setResourceMode(ServerData.ServerResourceMode.values()[((serverData.getResourceMode().ordinal() + lIlIllIl[0]) % ServerData.ServerResourceMode.values().length)]);
        serverResourcePacks.displayString = String.valueOf(new StringBuilder(String.valueOf(I18n.format(lIlIlIlI[lIlIllIl[15]], new Object[lIlIllIl[1]]))).append(lIlIlIlI[lIlIllIl[16]]).append(serverData.getResourceMode().getMotd().getFormattedText()));
        "".length();
        if ("   ".length() >= " ".length()) {}
      }
      else if (lIIIllIlll(id, lIlIllIl[0]))
      {
        parentScreen.confirmClicked(lIlIllIl[1], lIlIllIl[1]);
        "".length();
        if ("  ".length() > -" ".length()) {}
      }
      else if (lIIIlllIII(id))
      {
        serverData.serverName = serverNameField.getText();
        serverData.serverIP = serverIPField.getText();
        parentScreen.confirmClicked(lIlIllIl[0], lIlIllIl[1]);
      }
    }
  }
  
  private static boolean lIIIllIlll(int ???, int arg1)
  {
    int i;
    long lIllllIIIlIlIll;
    return ??? == i;
  }
  
  static
  {
    lIIIllIlII();
    lIIIlIllIl();
  }
  
  private static boolean lIIIlllIII(int ???)
  {
    byte lIllllIIIlIIIIl;
    return ??? == 0;
  }
  
  private static String lIIIlIlIll(String lIllllIlIIIIlll, String lIllllIlIIIIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIllllIlIIIlIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIllllIlIIIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIllllIlIIIlIIl = Cipher.getInstance("Blowfish");
      lIllllIlIIIlIIl.init(lIlIllIl[2], lIllllIlIIIlIlI);
      return new String(lIllllIlIIIlIIl.doFinal(Base64.getDecoder().decode(lIllllIlIIIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIllllIlIIIlIII)
    {
      lIllllIlIIIlIII.printStackTrace();
    }
    return null;
  }
}

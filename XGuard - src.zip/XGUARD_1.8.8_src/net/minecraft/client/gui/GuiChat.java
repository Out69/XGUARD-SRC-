package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.C14PacketTabComplete;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatStyle;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class GuiChat
  extends GuiScreen
{
  private static void lllIlIllIllIII()
  {
    lIIllIIllllIl = new int[19];
    lIIllIIllllIl[0] = ((0x1C ^ 0x39) & (0x1A ^ 0x3F ^ 0xFFFFFFFF));
    lIIllIIllllIl[1] = (-" ".length());
    lIIllIIllllIl[2] = " ".length();
    lIIllIIllllIl[3] = "  ".length();
    lIIllIIllllIl[4] = "   ".length();
    lIIllIIllllIl[5] = (0x8D ^ 0x89);
    lIIllIIllllIl[6] = (0x3 ^ 0x45 ^ 0xCC ^ 0x86);
    lIIllIIllllIl[7] = (0xEF ^ 0x8B);
    lIIllIIllllIl[8] = (0x79 ^ 0x5F ^ 0x9 ^ 0x20);
    lIIllIIllllIl[9] = (0x8 ^ 0x51 ^ 0x79 ^ 0x3C);
    lIIllIIllllIl[10] = (11 + 29 - -43 + 73);
    lIIllIIllllIl[11] = ((0xAC ^ 0xBA) + ('' + 10 - 84 + 117) - ('' + '' - 226 + 109) + (109 + 99 - 56 + 2));
    lIIllIIllllIl[12] = ('À' + '' - 314 + 181);
    lIIllIIllllIl[13] = ((0x1 ^ 0x71) + (0x99 ^ 0xA1) - (0xB ^ 0x31) + (0x78 ^ 0x23));
    lIIllIIllllIl[14] = (43 + 2 - -35 + 129);
    lIIllIIllllIl[15] = (0x6B ^ 0x6C);
    lIIllIIllllIl[16] = (0x36 ^ 0x13 ^ 0x74 ^ 0x5F);
    lIIllIIllllIl[17] = (0x73 ^ 0x42 ^ 0x7 ^ 0x33);
    lIIllIIllllIl[18] = (0x5C ^ 0x16 ^ 0x3C ^ 0x7E);
  }
  
  private static boolean lllIlIllIllIll(int ???)
  {
    byte llllllllllllllIIllIlIlllllIIIlIl;
    return ??? > 0;
  }
  
  private static void lllIlIllIlIIIl()
  {
    lIIllIIlllIIl = new String[lIIllIIllllIl[17]];
    lIIllIIlllIIl[lIIllIIllllIl[0]] = lllIlIllIIllII("", "goZvM");
    lIIllIIlllIIl[lIIllIIllllIl[2]] = lllIlIllIIllII("", "gsXlG");
    lIIllIIlllIIl[lIIllIIllllIl[3]] = lllIlIllIIllIl("vFLY9iX4Xck=", "OeBNR");
    lIIllIIlllIIl[lIIllIIllllIl[4]] = lllIlIllIlIIII("MxQJk5Q5TU4=", "ClNys");
    lIIllIIlllIIl[lIIllIIllllIl[5]] = lllIlIllIIllII("YUU=", "MeVRL");
  }
  
  private static boolean lllIlIlllIIIll(Object ???)
  {
    double llllllllllllllIIllIlIlllllIIllll;
    return ??? != null;
  }
  
  public void onGuiClosed()
  {
    ;
    Keyboard.enableRepeatEvents(lIIllIIllllIl[0]);
    mc.ingameGUI.getChatGUI().resetScroll();
  }
  
  private void sendAutocompleteRequest(String llllllllllllllIIllIllIIIIlIllIIl, String llllllllllllllIIllIllIIIIlIllIII)
  {
    ;
    ;
    ;
    if (lllIlIlllIIIIl(llllllllllllllIIllIllIIIIlIllIIl.length(), lIIllIIllllIl[2]))
    {
      BlockPos llllllllllllllIIllIllIIIIlIlIlll = null;
      if ((lllIlIlllIIIll(mc.objectMouseOver)) && (lllIlIlllIIlII(mc.objectMouseOver.typeOfHit, MovingObjectPosition.MovingObjectType.BLOCK))) {
        llllllllllllllIIllIllIIIIlIlIlll = mc.objectMouseOver.getBlockPos();
      }
      mc.thePlayer.sendQueue.addToSendQueue(new C14PacketTabComplete(llllllllllllllIIllIllIIIIlIlIlIl, llllllllllllllIIllIllIIIIlIlIlll));
      waitingOnAutocomplete = lIIllIIllllIl[2];
    }
  }
  
  protected void setText(String llllllllllllllIIllIllIIIIlllIIII, boolean llllllllllllllIIllIllIIIIllIllII)
  {
    ;
    ;
    ;
    if (lllIlIllIlllII(llllllllllllllIIllIllIIIIllIllII))
    {
      inputField.setText(llllllllllllllIIllIllIIIIllIllIl);
      "".length();
      if (-(0x3F ^ 0x45 ^ 0xD4 ^ 0xAA) < 0) {}
    }
    else
    {
      inputField.writeText(llllllllllllllIIllIllIIIIllIllIl);
    }
  }
  
  protected void mouseClicked(int llllllllllllllIIllIllIIIIllllIII, int llllllllllllllIIllIllIIIIlllllII, int llllllllllllllIIllIllIIIIlllIllI)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIlIlllIIIII(llllllllllllllIIllIllIIIIlllIllI))
    {
      IChatComponent llllllllllllllIIllIllIIIIllllIlI = mc.ingameGUI.getChatGUI().getChatComponent(Mouse.getX(), Mouse.getY());
      if (lllIlIllIlllII(llllllllllllllIIllIllIIIIllllIIl.handleComponentClick(llllllllllllllIIllIllIIIIllllIlI))) {
        return;
      }
    }
    inputField.mouseClicked(llllllllllllllIIllIllIIIIllllIII, llllllllllllllIIllIllIIIIlllllII, llllllllllllllIIllIllIIIIlllIllI);
    llllllllllllllIIllIllIIIIllllIIl.mouseClicked(llllllllllllllIIllIllIIIIllllIII, llllllllllllllIIllIllIIIIlllllII, llllllllllllllIIllIllIIIIlllIllI);
  }
  
  private static boolean lllIlIllIlllll(int ???, int arg1)
  {
    int i;
    float llllllllllllllIIllIlIlllllIlIlIl;
    return ??? < i;
  }
  
  private static boolean lllIlIllIllllI(int ???, int arg1)
  {
    int i;
    float llllllllllllllIIllIlIlllllIlIIIl;
    return ??? > i;
  }
  
  private static boolean lllIlIllIllIIl(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIIllIlIlllllIlllIl;
    return ??? == i;
  }
  
  private static String lllIlIllIIllIl(String llllllllllllllIIllIllIIIIIIlllll, String llllllllllllllIIllIllIIIIIIlllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllIllIIIIIlIIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllIllIIIIIIlllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIIllIllIIIIIlIIIIl = Cipher.getInstance("Blowfish");
      llllllllllllllIIllIllIIIIIlIIIIl.init(lIIllIIllllIl[3], llllllllllllllIIllIllIIIIIlIIIlI);
      return new String(llllllllllllllIIllIllIIIIIlIIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIIllIllIIIIIIlllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllIllIIIIIlIIIII)
    {
      llllllllllllllIIllIllIIIIIlIIIII.printStackTrace();
    }
    return null;
  }
  
  private static String lllIlIllIlIIII(String llllllllllllllIIllIlIlllllllIIIl, String llllllllllllllIIllIlIlllllllIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllIlIllllllllIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllIlIlllllllIIII.getBytes(StandardCharsets.UTF_8)), lIIllIIllllIl[18]), "DES");
      Cipher llllllllllllllIIllIlIlllllllIlll = Cipher.getInstance("DES");
      llllllllllllllIIllIlIlllllllIlll.init(lIIllIIllllIl[3], llllllllllllllIIllIlIllllllllIIl);
      return new String(llllllllllllllIIllIlIlllllllIlll.doFinal(Base64.getDecoder().decode(llllllllllllllIIllIlIlllllllIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllIlIlllllllIllI)
    {
      llllllllllllllIIllIlIlllllllIllI.printStackTrace();
    }
    return null;
  }
  
  public void onAutocompleteResponse(String[] llllllllllllllIIllIllIIIIIlIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIlIllIlllII(waitingOnAutocomplete))
    {
      playerNamesFound = lIIllIIllllIl[0];
      foundPlayerNames.clear();
      llllllllllllllIIllIllIIIIIlIlIIl = (llllllllllllllIIllIllIIIIIlIlIII = llllllllllllllIIllIllIIIIIlIllII).length;
      llllllllllllllIIllIllIIIIIlIlIlI = lIIllIIllllIl[0];
      "".length();
      if (-" ".length() >= " ".length()) {
        return;
      }
      while (!lllIlIlllIIIIl(llllllllllllllIIllIllIIIIIlIlIlI, llllllllllllllIIllIllIIIIIlIlIIl))
      {
        String llllllllllllllIIllIllIIIIIllIIII = llllllllllllllIIllIllIIIIIlIlIII[llllllllllllllIIllIllIIIIIlIlIlI];
        if (lllIlIllIllIll(llllllllllllllIIllIllIIIIIllIIII.length())) {
          "".length();
        }
        llllllllllllllIIllIllIIIIIlIlIlI++;
      }
      String llllllllllllllIIllIllIIIIIlIllll = inputField.getText().substring(inputField.func_146197_a(lIIllIIllllIl[1], inputField.getCursorPosition(), lIIllIIllllIl[0]));
      String llllllllllllllIIllIllIIIIIlIlllI = StringUtils.getCommonPrefix(llllllllllllllIIllIllIIIIIlIllII);
      if ((lllIlIllIllIll(llllllllllllllIIllIllIIIIIlIlllI.length())) && (lllIlIlllIIIII(llllllllllllllIIllIllIIIIIlIllll.equalsIgnoreCase(llllllllllllllIIllIllIIIIIlIlllI))))
      {
        inputField.deleteFromCursor(inputField.func_146197_a(lIIllIIllllIl[1], inputField.getCursorPosition(), lIIllIIllllIl[0]) - inputField.getCursorPosition());
        inputField.writeText(llllllllllllllIIllIllIIIIIlIlllI);
        "".length();
        if (-" ".length() <= 0) {}
      }
      else if (lllIlIllIllIll(foundPlayerNames.size()))
      {
        playerNamesFound = lIIllIIllllIl[2];
        llllllllllllllIIllIllIIIIIllIIlI.autocompletePlayerNames();
      }
    }
  }
  
  public void autocompletePlayerNames()
  {
    ;
    ;
    ;
    ;
    String llllllllllllllIIllIllIIIIllIIlII;
    if (lllIlIllIlllII(playerNamesFound))
    {
      inputField.deleteFromCursor(inputField.func_146197_a(lIIllIIllllIl[1], inputField.getCursorPosition(), lIIllIIllllIl[0]) - inputField.getCursorPosition());
      if (lllIlIlllIIIIl(autocompleteIndex, foundPlayerNames.size()))
      {
        autocompleteIndex = lIIllIIllllIl[0];
        "".length();
        if ((0x7 ^ 0x3) > 0) {}
      }
    }
    else
    {
      int llllllllllllllIIllIllIIIIllIIllI = inputField.func_146197_a(lIIllIIllllIl[1], inputField.getCursorPosition(), lIIllIIllllIl[0]);
      foundPlayerNames.clear();
      autocompleteIndex = lIIllIIllllIl[0];
      String llllllllllllllIIllIllIIIIllIIlIl = inputField.getText().substring(llllllllllllllIIllIllIIIIllIIllI).toLowerCase();
      llllllllllllllIIllIllIIIIllIIlII = inputField.getText().substring(lIIllIIllllIl[0], inputField.getCursorPosition());
      llllllllllllllIIllIllIIIIllIIIIl.sendAutocompleteRequest(llllllllllllllIIllIllIIIIllIIlII, llllllllllllllIIllIllIIIIllIIlIl);
      if (lllIlIllIlllII(foundPlayerNames.isEmpty())) {
        return;
      }
      playerNamesFound = lIIllIIllllIl[2];
      inputField.deleteFromCursor(llllllllllllllIIllIllIIIIllIIllI - inputField.getCursorPosition());
    }
    if (lllIlIllIllllI(foundPlayerNames.size(), lIIllIIllllIl[2]))
    {
      StringBuilder llllllllllllllIIllIllIIIIllIIIll = new StringBuilder();
      llllllllllllllIIllIllIIIIllIIlII = foundPlayerNames.iterator();
      "".length();
      if ("  ".length() == (("   ".length() ^ 0x28 ^ 0x6) & (0x4A ^ 0x61 ^ 0xA2 ^ 0xA4 ^ -" ".length()))) {
        return;
      }
      while (!lllIlIlllIIIII(llllllllllllllIIllIllIIIIllIIlII.hasNext()))
      {
        String llllllllllllllIIllIllIIIIllIIIlI = (String)llllllllllllllIIllIllIIIIllIIlII.next();
        if (lllIlIllIllIll(llllllllllllllIIllIllIIIIllIIIll.length())) {
          "".length();
        }
        "".length();
      }
      mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion(new ChatComponentText(String.valueOf(llllllllllllllIIllIllIIIIllIIIll)), lIIllIIllllIl[2]);
    }
    int tmp408_405 = autocompleteIndex;
    autocompleteIndex = (tmp408_405 + lIIllIIllllIl[2]);
    inputField.writeText((String)foundPlayerNames.get(tmp408_405));
  }
  
  public GuiChat(String llllllllllllllIIllIllIIIlIlIIIIl)
  {
    historyBuffer = lIIllIIlllIIl[lIIllIIllllIl[3]];
    sentHistoryCursor = lIIllIIllllIl[1];
    foundPlayerNames = Lists.newArrayList();
    defaultInputFieldText = lIIllIIlllIIl[lIIllIIllllIl[4]];
    defaultInputFieldText = llllllllllllllIIllIllIIIlIlIIIIl;
  }
  
  protected void keyTyped(char llllllllllllllIIllIllIIIlIIIllII, int llllllllllllllIIllIllIIIlIIIllll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    waitingOnAutocomplete = lIIllIIllllIl[0];
    if (lllIlIllIllIIl(llllllllllllllIIllIllIIIlIIIllll, lIIllIIllllIl[8]))
    {
      llllllllllllllIIllIllIIIlIIIllIl.autocompletePlayerNames();
      "".length();
      if (((0x72 ^ 0xA ^ 0x33 ^ 0x74) & (0x6D ^ 0x40 ^ 0x62 ^ 0x70 ^ -" ".length())) == 0) {}
    }
    else
    {
      playerNamesFound = lIIllIIllllIl[0];
    }
    if (lllIlIllIllIIl(llllllllllllllIIllIllIIIlIIIllll, lIIllIIllllIl[2]))
    {
      mc.displayGuiScreen(null);
      "".length();
      if (null == null) {}
    }
    else if ((lllIlIllIllIlI(llllllllllllllIIllIllIIIlIIIllll, lIIllIIllllIl[9])) && (lllIlIllIllIlI(llllllllllllllIIllIllIIIlIIIllll, lIIllIIllllIl[10])))
    {
      if (lllIlIllIllIIl(llllllllllllllIIllIllIIIlIIIllll, lIIllIIllllIl[11]))
      {
        llllllllllllllIIllIllIIIlIIIllIl.getSentHistory(lIIllIIllllIl[1]);
        "".length();
        if (((0xF8 ^ 0xAA ^ 0x24 ^ 0x68) & (117 + 37 - 107 + 101 ^ 94 + '' - 116 + 27 ^ -" ".length())) > -" ".length()) {}
      }
      else if (lllIlIllIllIIl(llllllllllllllIIllIllIIIlIIIllll, lIIllIIllllIl[12]))
      {
        llllllllllllllIIllIllIIIlIIIllIl.getSentHistory(lIIllIIllllIl[2]);
        "".length();
        if (null == null) {}
      }
      else if (lllIlIllIllIIl(llllllllllllllIIllIllIIIlIIIllll, lIIllIIllllIl[13]))
      {
        mc.ingameGUI.getChatGUI().scroll(mc.ingameGUI.getChatGUI().getLineCount() - lIIllIIllllIl[2]);
        "".length();
        if (-(0x36 ^ 0x32) <= 0) {}
      }
      else if (lllIlIllIllIIl(llllllllllllllIIllIllIIIlIIIllll, lIIllIIllllIl[14]))
      {
        mc.ingameGUI.getChatGUI().scroll(-mc.ingameGUI.getChatGUI().getLineCount() + lIIllIIllllIl[2]);
        "".length();
        if ((0x3A ^ 0x3E) != 0) {}
      }
      else
      {
        "".length();
        "".length();
        if ("  ".length() < "   ".length()) {}
      }
    }
    else
    {
      String llllllllllllllIIllIllIIIlIIIlllI = inputField.getText().trim();
      if (lllIlIllIllIll(llllllllllllllIIllIllIIIlIIIlllI.length())) {
        llllllllllllllIIllIllIIIlIIIllIl.sendChatMessage(llllllllllllllIIllIllIIIlIIIlllI);
      }
      mc.displayGuiScreen(null);
    }
  }
  
  public void getSentHistory(int llllllllllllllIIllIllIIIIlIIlllI)
  {
    ;
    ;
    ;
    ;
    int llllllllllllllIIllIllIIIIlIIllIl = sentHistoryCursor + llllllllllllllIIllIllIIIIlIIlllI;
    int llllllllllllllIIllIllIIIIlIIllII = mc.ingameGUI.getChatGUI().getSentMessages().size();
    llllllllllllllIIllIllIIIIlIIllIl = MathHelper.clamp_int(llllllllllllllIIllIllIIIIlIIllIl, lIIllIIllllIl[0], llllllllllllllIIllIllIIIIlIIllII);
    if (lllIlIllIllIlI(llllllllllllllIIllIllIIIIlIIllIl, sentHistoryCursor)) {
      if (lllIlIllIllIIl(llllllllllllllIIllIllIIIIlIIllIl, llllllllllllllIIllIllIIIIlIIllII))
      {
        sentHistoryCursor = llllllllllllllIIllIllIIIIlIIllII;
        inputField.setText(historyBuffer);
        "".length();
        if (null == null) {}
      }
      else
      {
        if (lllIlIllIllIIl(sentHistoryCursor, llllllllllllllIIllIllIIIIlIIllII)) {
          historyBuffer = inputField.getText();
        }
        inputField.setText((String)mc.ingameGUI.getChatGUI().getSentMessages().get(llllllllllllllIIllIllIIIIlIIllIl));
        sentHistoryCursor = llllllllllllllIIllIllIIIIlIIllIl;
      }
    }
  }
  
  public void initGui()
  {
    ;
    Keyboard.enableRepeatEvents(lIIllIIllllIl[2]);
    sentHistoryCursor = mc.ingameGUI.getChatGUI().getSentMessages().size();
    inputField = new GuiTextField(lIIllIIllllIl[0], fontRendererObj, lIIllIIllllIl[5], height - lIIllIIllllIl[6], width - lIIllIIllllIl[5], lIIllIIllllIl[6]);
    inputField.setMaxStringLength(lIIllIIllllIl[7]);
    inputField.setEnableBackgroundDrawing(lIIllIIllllIl[0]);
    inputField.setFocused(lIIllIIllllIl[2]);
    inputField.setText(defaultInputFieldText);
    inputField.setCanLoseFocus(lIIllIIllllIl[0]);
  }
  
  private static boolean lllIlIlllIIlII(Object ???, Object arg1)
  {
    Object localObject;
    boolean llllllllllllllIIllIlIlllllIIlIll;
    return ??? == localObject;
  }
  
  public boolean doesGuiPauseGame()
  {
    return lIIllIIllllIl[0];
  }
  
  private static boolean lllIlIllIllIlI(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIIllIlIlllllIIIIIl;
    return ??? != i;
  }
  
  private static boolean lllIlIlllIIIII(int ???)
  {
    float llllllllllllllIIllIlIlllllIIIlll;
    return ??? == 0;
  }
  
  static
  {
    lllIlIllIllIII();
    lllIlIllIlIIIl();
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    ;
    llllllllllllllIIllIllIIIlIIIIlll.handleMouseInput();
    int llllllllllllllIIllIllIIIlIIIIllI = Mouse.getEventDWheel();
    if (lllIlIllIlllII(llllllllllllllIIllIllIIIlIIIIllI))
    {
      if (lllIlIllIllllI(llllllllllllllIIllIllIIIlIIIIllI, lIIllIIllllIl[2])) {
        llllllllllllllIIllIllIIIlIIIIllI = lIIllIIllllIl[2];
      }
      if (lllIlIllIlllll(llllllllllllllIIllIllIIIlIIIIllI, lIIllIIllllIl[1])) {
        llllllllllllllIIllIllIIIlIIIIllI = lIIllIIllllIl[1];
      }
      if (lllIlIlllIIIII(isShiftKeyDown())) {
        llllllllllllllIIllIllIIIlIIIIllI *= lIIllIIllllIl[15];
      }
      mc.ingameGUI.getChatGUI().scroll(llllllllllllllIIllIllIIIlIIIIllI);
    }
  }
  
  private static boolean lllIlIlllIIIIl(int ???, int arg1)
  {
    int i;
    float llllllllllllllIIllIlIlllllIllIIl;
    return ??? >= i;
  }
  
  public void updateScreen()
  {
    ;
    inputField.updateCursorCounter();
  }
  
  private static String lllIlIllIIllII(String llllllllllllllIIllIllIIIIIIIllll, String llllllllllllllIIllIllIIIIIIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIllIIIIIIIllll = new String(Base64.getDecoder().decode(llllllllllllllIIllIllIIIIIIIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIllIllIIIIIIIllIl = new StringBuilder();
    char[] llllllllllllllIIllIllIIIIIIIllII = llllllllllllllIIllIllIIIIIIIlIIl.toCharArray();
    int llllllllllllllIIllIllIIIIIIIlIll = lIIllIIllllIl[0];
    short llllllllllllllIIllIllIIIIIIIIlIl = llllllllllllllIIllIllIIIIIIIllll.toCharArray();
    float llllllllllllllIIllIllIIIIIIIIlII = llllllllllllllIIllIllIIIIIIIIlIl.length;
    byte llllllllllllllIIllIllIIIIIIIIIll = lIIllIIllllIl[0];
    while (lllIlIllIlllll(llllllllllllllIIllIllIIIIIIIIIll, llllllllllllllIIllIllIIIIIIIIlII))
    {
      char llllllllllllllIIllIllIIIIIIlIIII = llllllllllllllIIllIllIIIIIIIIlIl[llllllllllllllIIllIllIIIIIIIIIll];
      "".length();
      "".length();
      if (-(0x5 ^ 0x0) >= 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIllIllIIIIIIIllIl);
  }
  
  public GuiChat()
  {
    historyBuffer = lIIllIIlllIIl[lIIllIIllllIl[0]];
    sentHistoryCursor = lIIllIIllllIl[1];
    foundPlayerNames = Lists.newArrayList();
    defaultInputFieldText = lIIllIIlllIIl[lIIllIIllllIl[2]];
  }
  
  private static boolean lllIlIllIlllII(int ???)
  {
    int llllllllllllllIIllIlIlllllIIlIIl;
    return ??? != 0;
  }
  
  public void drawScreen(int llllllllllllllIIllIllIIIIIllllII, int llllllllllllllIIllIllIIIIlIIIIII, float llllllllllllllIIllIllIIIIIllllll)
  {
    ;
    ;
    ;
    ;
    ;
    drawRect(lIIllIIllllIl[3], height - lIIllIIllllIl[16], width - lIIllIIllllIl[3], height - lIIllIIllllIl[3], Integer.MIN_VALUE);
    inputField.drawTextBox();
    IChatComponent llllllllllllllIIllIllIIIIIlllllI = mc.ingameGUI.getChatGUI().getChatComponent(Mouse.getX(), Mouse.getY());
    if ((lllIlIlllIIIll(llllllllllllllIIllIllIIIIIlllllI)) && (lllIlIlllIIIll(llllllllllllllIIllIllIIIIIlllllI.getChatStyle().getChatHoverEvent()))) {
      llllllllllllllIIllIllIIIIlIIIIlI.handleComponentHover(llllllllllllllIIllIllIIIIIlllllI, llllllllllllllIIllIllIIIIIllllII, llllllllllllllIIllIllIIIIlIIIIII);
    }
    llllllllllllllIIllIllIIIIlIIIIlI.drawScreen(llllllllllllllIIllIllIIIIIllllII, llllllllllllllIIllIllIIIIlIIIIII, llllllllllllllIIllIllIIIIIllllll);
  }
}

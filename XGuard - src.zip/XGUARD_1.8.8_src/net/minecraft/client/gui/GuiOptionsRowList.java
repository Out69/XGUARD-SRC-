package net.minecraft.client.gui;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.GameSettings.Options;

public class GuiOptionsRowList
  extends GuiListExtended
{
  static {}
  
  protected int getScrollBarX()
  {
    ;
    return llllllllllllllIllIlIIIlIIIIIlllI.getScrollBarX() + llllIlllIIII[6];
  }
  
  public Row getListEntry(int llllllllllllllIllIlIIIlIIIIlIlll)
  {
    ;
    ;
    return (Row)field_148184_k.get(llllllllllllllIllIlIIIlIIIIlIlll);
  }
  
  protected int getSize()
  {
    ;
    return field_148184_k.size();
  }
  
  private static boolean lIllllIIIIIIII(int ???, int arg1)
  {
    int i;
    String llllllllllllllIllIlIIIlIIIIIIIlI;
    return ??? < i;
  }
  
  private static boolean lIllllIIIIIIIl(int ???, int arg1)
  {
    int i;
    int llllllllllllllIllIlIIIlIIIIIIllI;
    return ??? >= i;
  }
  
  public GuiOptionsRowList(Minecraft llllllllllllllIllIlIIIlIIlIIIIll, int llllllllllllllIllIlIIIlIIIllIlIl, int llllllllllllllIllIlIIIlIIlIIIIIl, int llllllllllllllIllIlIIIlIIlIIIIII, int llllllllllllllIllIlIIIlIIIllllll, int llllllllllllllIllIlIIIlIIIlllllI, GameSettings.Options... llllllllllllllIllIlIIIlIIIllIIII)
  {
    llllllllllllllIllIlIIIlIIIllIlll.<init>(llllllllllllllIllIlIIIlIIlIIIIll, llllllllllllllIllIlIIIlIIIllIlIl, llllllllllllllIllIlIIIlIIlIIIIIl, llllllllllllllIllIlIIIlIIlIIIIII, llllllllllllllIllIlIIIlIIIllllll, llllllllllllllIllIlIIIlIIIlllllI);
    field_148163_i = llllIlllIIII[0];
    int llllllllllllllIllIlIIIlIIIllllII = llllIlllIIII[0];
    "".length();
    if ("  ".length() <= -" ".length()) {
      throw null;
    }
    label110:
    while (!lIllllIIIIIIIl(llllllllllllllIllIlIIIlIIIllllII, llllllllllllllIllIlIIIlIIIllIIII.length))
    {
      GameSettings.Options llllllllllllllIllIlIIIlIIIlllIll = llllllllllllllIllIlIIIlIIIllIIII[llllllllllllllIllIlIIIlIIIllllII];
      if (lIllllIIIIIIII(llllllllllllllIllIlIIIlIIIllllII, llllllllllllllIllIlIIIlIIIllIIII.length - llllIlllIIII[1]))
      {
        "".length();
        if (" ".length() >= 0) {
          break label110;
        }
        throw null;
      }
      GameSettings.Options llllllllllllllIllIlIIIlIIIlllIlI = null;
      GuiButton llllllllllllllIllIlIIIlIIIlllIIl = llllllllllllllIllIlIIIlIIIllIlll.func_148182_a(llllllllllllllIllIlIIIlIIlIIIIll, llllllllllllllIllIlIIIlIIIllIlIl / llllIlllIIII[2] - llllIlllIIII[3], llllIlllIIII[0], llllllllllllllIllIlIIIlIIIlllIll);
      GuiButton llllllllllllllIllIlIIIlIIIlllIII = llllllllllllllIllIlIIIlIIIllIlll.func_148182_a(llllllllllllllIllIlIIIlIIlIIIIll, llllllllllllllIllIlIIIlIIIllIlIl / llllIlllIIII[2] - llllIlllIIII[3] + llllIlllIIII[4], llllIlllIIII[0], llllllllllllllIllIlIIIlIIIlllIlI);
      new Row(llllllllllllllIllIlIIIlIIIlllIIl, llllllllllllllIllIlIIIlIIIlllIII);
      "".length();
      llllllllllllllIllIlIIIlIIIllllII += 2;
    }
  }
  
  private static void lIlllIllllllll()
  {
    llllIlllIIII = new int[7];
    llllIlllIIII[0] = ((0x3E ^ 0x30) & (0x3F ^ 0x31 ^ 0xFFFFFFFF));
    llllIlllIIII[1] = " ".length();
    llllIlllIIII[2] = "  ".length();
    llllIlllIIII[3] = ((0x79 ^ 0x22) + (0x3A ^ 0x14) - (0x5E ^ 0x76) + (0xBC ^ 0x86));
    llllIlllIIII[4] = ((0xFE ^ 0x86) + (73 + 127 - 135 + 68) - (25 + 42 - -47 + 64) + (0x3A ^ 0x6F));
    llllIlllIIII[5] = (0xA590 & 0x5BFF);
    llllIlllIIII[6] = (104 + 52 - 100 + 98 ^ 108 + 98 - 63 + 43);
  }
  
  private GuiButton func_148182_a(Minecraft llllllllllllllIllIlIIIlIIIIlllll, int llllllllllllllIllIlIIIlIIIlIIIll, int llllllllllllllIllIlIIIlIIIIlllIl, GameSettings.Options llllllllllllllIllIlIIIlIIIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIllllIIIIIIlI(llllllllllllllIllIlIIIlIIIlIIIIl)) {
      return null;
    }
    int llllllllllllllIllIlIIIlIIIlIIIII = llllllllllllllIllIlIIIlIIIlIIIIl.returnEnumOrdinal();
    if (lIllllIIIIIIll(llllllllllllllIllIlIIIlIIIlIIIIl.getEnumFloat()))
    {
      new GuiOptionSlider(llllllllllllllIllIlIIIlIIIlIIIII, llllllllllllllIllIlIIIlIIIlIIIll, llllllllllllllIllIlIIIlIIIIlllIl, llllllllllllllIllIlIIIlIIIlIIIIl);
      "".length();
      if (((0x67 ^ 0x11 ^ 0x1B ^ 0x72) & (0x61 ^ 0x71 ^ 0xC8 ^ 0xC7 ^ -" ".length())) < "   ".length()) {
        break label111;
      }
      return null;
    }
    label111:
    return new GuiOptionButton(llllllllllllllIllIlIIIlIIIlIIIII, llllllllllllllIllIlIIIlIIIlIIIll, llllllllllllllIllIlIIIlIIIIlllIl, llllllllllllllIllIlIIIlIIIlIIIIl, gameSettings.getKeyBinding(llllllllllllllIllIlIIIlIIIlIIIIl));
  }
  
  private static boolean lIllllIIIIIIll(int ???)
  {
    float llllllllllllllIllIlIIIIllllllllI;
    return ??? != 0;
  }
  
  private static boolean lIllllIIIIIIlI(Object ???)
  {
    int llllllllllllllIllIlIIIlIIIIIIIII;
    return ??? == null;
  }
  
  public int getListWidth()
  {
    return llllIlllIIII[5];
  }
  
  public static class Row
    implements GuiListExtended.IGuiListEntry
  {
    static {}
    
    public void setSelected(int lllllllllllllllIlIlllIlIlIIlIlII, int lllllllllllllllIlIlllIlIlIIlIIll, int lllllllllllllllIlIlllIlIlIIlIIlI) {}
    
    private static void lllIllIllllII()
    {
      lIIllIIllllI = new int[2];
      lIIllIIllllI[0] = " ".length();
      lIIllIIllllI[1] = ((0x3D ^ 0x63) & (0x5D ^ 0x3 ^ 0xFFFFFFFF));
    }
    
    public boolean mousePressed(int lllllllllllllllIlIlllIlIlIlIlIll, int lllllllllllllllIlIlllIlIlIlIIlII, int lllllllllllllllIlIlllIlIlIlIlIIl, int lllllllllllllllIlIlllIlIlIlIlIII, int lllllllllllllllIlIlllIlIlIlIIlll, int lllllllllllllllIlIlllIlIlIlIIllI)
    {
      ;
      ;
      ;
      if (lllIllIllllll(field_148323_b.mousePressed(field_148325_a, lllllllllllllllIlIlllIlIlIlIIlII, lllllllllllllllIlIlllIlIlIlIlIIl)))
      {
        if (lllIllIllllll(field_148323_b instanceof GuiOptionButton))
        {
          field_148325_a.gameSettings.setOptionValue(((GuiOptionButton)field_148323_b).returnEnumOptions(), lIIllIIllllI[0]);
          field_148323_b.displayString = field_148325_a.gameSettings.getKeyBinding(GameSettings.Options.getEnumOptions(field_148323_b.id));
        }
        return lIIllIIllllI[0];
      }
      if ((lllIllIlllllI(field_148324_c)) && (lllIllIllllll(field_148324_c.mousePressed(field_148325_a, lllllllllllllllIlIlllIlIlIlIIlII, lllllllllllllllIlIlllIlIlIlIlIIl))))
      {
        if (lllIllIllllll(field_148324_c instanceof GuiOptionButton))
        {
          field_148325_a.gameSettings.setOptionValue(((GuiOptionButton)field_148324_c).returnEnumOptions(), lIIllIIllllI[0]);
          field_148324_c.displayString = field_148325_a.gameSettings.getKeyBinding(GameSettings.Options.getEnumOptions(field_148324_c.id));
        }
        return lIIllIIllllI[0];
      }
      return lIIllIIllllI[1];
    }
    
    private static boolean lllIllIlllllI(Object ???)
    {
      int lllllllllllllllIlIlllIlIlIIlIIII;
      return ??? != null;
    }
    
    private static boolean lllIllIllllll(int ???)
    {
      float lllllllllllllllIlIlllIlIlIIIlllI;
      return ??? != 0;
    }
    
    public void drawEntry(int lllllllllllllllIlIlllIlIlIlllIll, int lllllllllllllllIlIlllIlIlIlllIlI, int lllllllllllllllIlIlllIlIlIlllIIl, int lllllllllllllllIlIlllIlIlIlllIII, int lllllllllllllllIlIlllIlIlIllIlll, int lllllllllllllllIlIlllIlIlIllIIIl, int lllllllllllllllIlIlllIlIlIllIlIl, boolean lllllllllllllllIlIlllIlIlIllIlII)
    {
      ;
      ;
      ;
      ;
      if (lllIllIlllllI(field_148323_b))
      {
        field_148323_b.yPosition = lllllllllllllllIlIlllIlIlIlllIIl;
        field_148323_b.drawButton(field_148325_a, lllllllllllllllIlIlllIlIlIllIllI, lllllllllllllllIlIlllIlIlIllIlIl);
      }
      if (lllIllIlllllI(field_148324_c))
      {
        field_148324_c.yPosition = lllllllllllllllIlIlllIlIlIlllIIl;
        field_148324_c.drawButton(field_148325_a, lllllllllllllllIlIlllIlIlIllIllI, lllllllllllllllIlIlllIlIlIllIlIl);
      }
    }
    
    public Row(GuiButton lllllllllllllllIlIlllIlIllIIIlIl, GuiButton lllllllllllllllIlIlllIlIllIIIlII)
    {
      field_148323_b = lllllllllllllllIlIlllIlIllIIIIlI;
      field_148324_c = lllllllllllllllIlIlllIlIllIIIlII;
    }
    
    public void mouseReleased(int lllllllllllllllIlIlllIlIlIIllllI, int lllllllllllllllIlIlllIlIlIIlllIl, int lllllllllllllllIlIlllIlIlIIlIllI, int lllllllllllllllIlIlllIlIlIIllIll, int lllllllllllllllIlIlllIlIlIIllIlI, int lllllllllllllllIlIlllIlIlIIllIIl)
    {
      ;
      ;
      ;
      if (lllIllIlllllI(field_148323_b)) {
        field_148323_b.mouseReleased(lllllllllllllllIlIlllIlIlIIlllIl, lllllllllllllllIlIlllIlIlIIlIllI);
      }
      if (lllIllIlllllI(field_148324_c)) {
        field_148324_c.mouseReleased(lllllllllllllllIlIlllIlIlIIlllIl, lllllllllllllllIlIlllIlIlIIlIllI);
      }
    }
  }
}

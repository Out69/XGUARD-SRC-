package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;

public class GuiButtonLanguage
  extends GuiButton
{
  public void drawButton(Minecraft lllllllllllllllIllllllIIIllllIlI, int lllllllllllllllIllllllIIIllllIIl, int lllllllllllllllIllllllIIIllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIllIIIlIIl(visible))
    {
      lllllllllllllllIllllllIIIllllIlI.getTextureManager().bindTexture(GuiButton.buttonTextures);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      if ((llIIllIIIlIlI(lllllllllllllllIllllllIIIllllIIl, xPosition)) && (llIIllIIIlIlI(lllllllllllllllIllllllIIIllllIII, yPosition)) && (llIIllIIIlIll(lllllllllllllllIllllllIIIllllIIl, xPosition + width)) && (llIIllIIIlIll(lllllllllllllllIllllllIIIllllIII, yPosition + height)))
      {
        "".length();
        if ("   ".length() > "  ".length()) {
          break label111;
        }
      }
      label111:
      boolean lllllllllllllllIllllllIIIlllllIl = lIIIIlIIlIlI[1];
      int lllllllllllllllIllllllIIIlllllII = lIIIIlIIlIlI[3];
      if (llIIllIIIlIIl(lllllllllllllllIllllllIIIlllllIl)) {
        lllllllllllllllIllllllIIIlllllII += height;
      }
      lllllllllllllllIllllllIIIllllIll.drawTexturedModalRect(xPosition, yPosition, lIIIIlIIlIlI[1], lllllllllllllllIllllllIIIlllllII, width, height);
    }
  }
  
  private static void llIIllIIIlIII()
  {
    lIIIIlIIlIlI = new int[5];
    lIIIIlIIlIlI[0] = (32 + '' - 42 + 23 ^ 4 + 32 - -32 + 113);
    lIIIIlIIlIlI[1] = ((0xB5 ^ 0x9E) & (0x7E ^ 0x55 ^ 0xFFFFFFFF));
    lIIIIlIIlIlI[2] = " ".length();
    lIIIIlIIlIlI[3] = (0xC1 ^ 0x87 ^ 0x26 ^ 0xA);
    lIIIIlIIlIlI[4] = "  ".length();
  }
  
  public GuiButtonLanguage(int lllllllllllllllIllllllIIlIIIlllI, int lllllllllllllllIllllllIIlIIIlIIl, int lllllllllllllllIllllllIIlIIIllII)
  {
    lllllllllllllllIllllllIIlIIIlIll.<init>(lllllllllllllllIllllllIIlIIIlllI, lllllllllllllllIllllllIIlIIIlIIl, lllllllllllllllIllllllIIlIIIllII, lIIIIlIIlIlI[0], lIIIIlIIlIlI[0], lIIIIlIIlIIl[lIIIIlIIlIlI[1]]);
  }
  
  private static boolean llIIllIIIlIlI(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllIllllllIIIllIIlIl;
    return ??? >= i;
  }
  
  private static boolean llIIllIIIlIIl(int ???)
  {
    String lllllllllllllllIllllllIIIlIlllll;
    return ??? != 0;
  }
  
  private static void llIIllIIIIlll()
  {
    lIIIIlIIlIIl = new String[lIIIIlIIlIlI[2]];
    lIIIIlIIlIIl[lIIIIlIIlIlI[1]] = llIIllIIIIllI("D4cD5VO42q4=", "EsCVB");
  }
  
  private static String llIIllIIIIllI(String lllllllllllllllIllllllIIIllIllII, String lllllllllllllllIllllllIIIllIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllllllIIIlllIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllllIIIllIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllllIIIlllIIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllllIIIlllIIII.init(lIIIIlIIlIlI[4], lllllllllllllllIllllllIIIlllIIIl);
      return new String(lllllllllllllllIllllllIIIlllIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllllIIIllIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllllllIIIllIllll)
    {
      lllllllllllllllIllllllIIIllIllll.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIIllIIIlIll(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIllllllIIIllIIIIl;
    return ??? < i;
  }
  
  static
  {
    llIIllIIIlIII();
    llIIllIIIIlll();
  }
}

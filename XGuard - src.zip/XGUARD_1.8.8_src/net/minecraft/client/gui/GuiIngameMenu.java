package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.achievement.GuiAchievements;
import net.minecraft.client.gui.achievement.GuiStats;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.resources.I18n;
import net.minecraft.realms.RealmsBridge;
import net.minecraft.server.integrated.IntegratedServer;
import pl.xguard.blacklist.BlacklistManage;

public class GuiIngameMenu
  extends GuiScreen
{
  private static void llllIIIIIll()
  {
    lIIlIIllIl = new String[lIIlIlIIII[18]];
    lIIlIIllIl[lIIlIlIIII[0]] = llllIIIIIII("2RaLkO8sDKLttWqxqbCacJatVlq54Axn", "NIFUH");
    lIIlIIllIl[lIIlIlIIII[3]] = llllIIIIIII("aZao0RpB5NkmTpqn3v4D4A==", "GHzsA");
    lIIlIIllIl[lIIlIlIIII[4]] = llllIIIIIIl("wQs4ufQhlUjnGt8y1ghDf2Y4GA5ZV/TS", "IvtCS");
    lIIlIIllIl[lIIlIlIIII[11]] = llllIIIIIlI("BSQLHmcHMRECJgYy", "hAekI");
    lIIlIIllIl[lIIlIlIIII[6]] = llllIIIIIIl("1DQLf71F28gUjphaJo8FGQ==", "jyxgC");
    lIIlIIllIl[lIIlIlIIII[13]] = llllIIIIIII("FVW7yjclYfDD3LKPAeAAlXJwLvg+eip6", "AhwtS");
    lIIlIIllIl[lIIlIlIIII[15]] = llllIIIIIIl("EkAFT+58kL8/xifjRpvTcw==", "MVQNS");
    lIIlIIllIl[lIIlIlIIII[12]] = llllIIIIIlI("BhAvBVQMFCwV", "kuApz");
  }
  
  private static boolean llllIIIllll(int ???, int arg1)
  {
    int i;
    byte llllllIIlIlI;
    return ??? < i;
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    field_146445_a = lIIlIlIIII[0];
    buttonList.clear();
    int lIIIIIIlIIlII = lIIlIlIIII[1];
    int lIIIIIIlIIIll = lIIlIlIIII[2];
    new GuiButton(lIIlIlIIII[3], width / lIIlIlIIII[4] - lIIlIlIIII[5], height / lIIlIlIIII[6] + lIIlIlIIII[7] + lIIIIIIlIIlII, I18n.format(lIIlIIllIl[lIIlIlIIII[0]], new Object[lIIlIlIIII[0]]));
    "".length();
    if (llllIIIllII(mc.isIntegratedServerRunning())) {
      buttonList.get(lIIlIlIIII[0])).displayString = I18n.format(lIIlIIllIl[lIIlIlIIII[3]], new Object[lIIlIlIIII[0]]);
    }
    new GuiButton(lIIlIlIIII[6], width / lIIlIlIIII[4] - lIIlIlIIII[5], height / lIIlIlIIII[6] + lIIlIlIIII[8] + lIIIIIIlIIlII, I18n.format(lIIlIIllIl[lIIlIlIIII[4]], new Object[lIIlIlIIII[0]]));
    "".length();
    new GuiButton(lIIlIlIIII[0], width / lIIlIlIIII[4] - lIIlIlIIII[5], height / lIIlIlIIII[6] + lIIlIlIIII[9] + lIIIIIIlIIlII, lIIlIlIIII[2], lIIlIlIIII[10], I18n.format(lIIlIIllIl[lIIlIlIIII[11]], new Object[lIIlIlIIII[0]]));
    "".length();
    BlacklistManage.check(mc);
    GuiButton lIIIIIIlIIIlI = new GuiButton(lIIlIlIIII[12], width / lIIlIlIIII[4] + lIIlIlIIII[4], height / lIIlIlIIII[6] + lIIlIlIIII[9] + lIIIIIIlIIlII, lIIlIlIIII[2], lIIlIlIIII[10], I18n.format(lIIlIIllIl[lIIlIlIIII[6]], new Object[lIIlIlIIII[0]]));
    "".length();
    new GuiButton(lIIlIlIIII[13], width / lIIlIlIIII[4] - lIIlIlIIII[5], height / lIIlIlIIII[6] + lIIlIlIIII[14] + lIIIIIIlIIlII, lIIlIlIIII[2], lIIlIlIIII[10], I18n.format(lIIlIIllIl[lIIlIlIIII[13]], new Object[lIIlIlIIII[0]]));
    "".length();
    new GuiButton(lIIlIlIIII[15], width / lIIlIlIIII[4] + lIIlIlIIII[4], height / lIIlIlIIII[6] + lIIlIlIIII[14] + lIIIIIIlIIlII, lIIlIlIIII[2], lIIlIlIIII[10], I18n.format(lIIlIIllIl[lIIlIlIIII[15]], new Object[lIIlIlIIII[0]]));
    "".length();
    if ((llllIIIllIl(mc.isSingleplayer())) && (llllIIIllII(mc.getIntegratedServer().getPublic())))
    {
      "".length();
      if (null == null) {
        break label693;
      }
    }
    label693:
    lIIlIlIIII3enabled = lIIlIlIIII[0];
  }
  
  private static String llllIIIIIII(String lllllllIIIII, String llllllIlllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllIlllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllIIIlI = Cipher.getInstance("Blowfish");
      lllllllIIIlI.init(lIIlIlIIII[4], lllllllIIIll);
      return new String(lllllllIIIlI.doFinal(Base64.getDecoder().decode(lllllllIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllIIIIl)
    {
      lllllllIIIIl.printStackTrace();
    }
    return null;
  }
  
  public void drawScreen(int lIIIIIIIIIllI, int lIIIIIIIIIlIl, float lIIIIIIIIIIII)
  {
    ;
    ;
    ;
    ;
    lIIIIIIIIIlll.drawDefaultBackground();
    lIIIIIIIIIlll.drawCenteredString(fontRendererObj, I18n.format(lIIlIIllIl[lIIlIlIIII[12]], new Object[lIIlIlIIII[0]]), width / lIIlIlIIII[4], lIIlIlIIII[16], lIIlIlIIII[17]);
    lIIIIIIIIIlll.drawScreen(lIIIIIIIIIllI, lIIIIIIIIIlIl, lIIIIIIIIIIII);
  }
  
  private static String llllIIIIIIl(String llllllIlIIIl, String llllllIlIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllIlIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllIlIIII.getBytes(StandardCharsets.UTF_8)), lIIlIlIIII[18]), "DES");
      Cipher llllllIlIlIl = Cipher.getInstance("DES");
      llllllIlIlIl.init(lIIlIlIIII[4], llllllIlIllI);
      return new String(llllllIlIlIl.doFinal(Base64.getDecoder().decode(llllllIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllIlIlII)
    {
      llllllIlIlII.printStackTrace();
    }
    return null;
  }
  
  private static String llllIIIIIlI(String llllllllIlIl, String llllllllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllIlIl = new String(Base64.getDecoder().decode(llllllllIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllIIll = new StringBuilder();
    char[] llllllllIIlI = llllllllIlII.toCharArray();
    int llllllllIIIl = lIIlIlIIII[0];
    double lllllllIlIll = llllllllIlIl.toCharArray();
    float lllllllIlIlI = lllllllIlIll.length;
    char lllllllIlIIl = lIIlIlIIII[0];
    while (llllIIIllll(lllllllIlIIl, lllllllIlIlI))
    {
      char llllllllIllI = lllllllIlIll[lllllllIlIIl];
      "".length();
      "".length();
      if ("   ".length() == 0) {
        return null;
      }
    }
    return String.valueOf(llllllllIIll);
  }
  
  protected void actionPerformed(GuiButton lIIIIIIIlIIlI)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    switch (id)
    {
    case 0: 
      mc.displayGuiScreen(new GuiOptions(lIIIIIIIlIIll, mc.gameSettings));
      "".length();
      if ("  ".length() <= 0) {}
      break;
    case 1: 
      boolean lIIIIIIIlIllI = mc.isIntegratedServerRunning();
      boolean lIIIIIIIlIlIl = mc.func_181540_al();
      enabled = lIIlIlIIII[0];
      mc.theWorld.sendQuittingDisconnectingPacket();
      mc.loadWorld(null);
      if (llllIIIllIl(lIIIIIIIlIllI))
      {
        mc.displayGuiScreen(new GuiMainMenu());
        "".length();
        if (-(0x66 ^ 0x59 ^ 0x3A ^ 0x1) <= 0) {
          break;
        }
      }
      else if (llllIIIllIl(lIIIIIIIlIlIl))
      {
        RealmsBridge lIIIIIIIlIlII = new RealmsBridge();
        lIIIIIIIlIlII.switchToRealms(new GuiMainMenu());
        "".length();
        if (-" ".length() != " ".length()) {
          break;
        }
      }
      else
      {
        mc.displayGuiScreen(new GuiMultiplayer(new GuiMainMenu()));
      }
      break;
    case 2: 
    case 3: 
    default: 
      "".length();
      if (((0x3D ^ 0x10) & (0xEC ^ 0xC1 ^ 0xFFFFFFFF)) < 0) {}
      break;
    case 4: 
      mc.displayGuiScreen(null);
      mc.setIngameFocus();
      "".length();
      if ("   ".length() > "   ".length()) {}
      break;
    case 5: 
      mc.displayGuiScreen(new GuiAchievements(lIIIIIIIlIIll, mc.thePlayer.getStatFileWriter()));
      "".length();
      if (((24 + 'Ö' - 29 + 44 ^ 66 + '' - 202 + 142) & ('Ì' + 48 - 134 + 117 ^ 43 + 101 - 134 + 126 ^ -" ".length())) != 0) {}
      break;
    case 6: 
      mc.displayGuiScreen(new GuiStats(lIIIIIIIlIIll, mc.thePlayer.getStatFileWriter()));
      "".length();
      if ("   ".length() < -" ".length()) {}
      break;
    case 7: 
      mc.displayGuiScreen(new GuiShareToLan(lIIIIIIIlIIll));
    }
  }
  
  private static void llllIIIlIll()
  {
    lIIlIlIIII = new int[19];
    lIIlIlIIII[0] = (('©' + 48 - 200 + 153 ^ '' + 2 - 70 + 78) & (0xEA ^ 0x8C ^ 0xF4 ^ 0xAC ^ -" ".length()));
    lIIlIlIIII[1] = (-(0x1E ^ 0xE));
    lIIlIlIIII[2] = (0xC7 ^ 0xAB ^ 0x56 ^ 0x58);
    lIIlIlIIII[3] = " ".length();
    lIIlIlIIII[4] = "  ".length();
    lIIlIlIIII[5] = (0x64 ^ 0x5 ^ 0x67 ^ 0x62);
    lIIlIlIIII[6] = (0x3F ^ 0x6 ^ 0x42 ^ 0x7F);
    lIIlIlIIII[7] = (0xF0 ^ 0x88);
    lIIlIlIIII[8] = (0x94 ^ 0x8C);
    lIIlIlIIII[9] = (0x44 ^ 0x33 ^ 0x58 ^ 0x4F);
    lIIlIlIIII[10] = (97 + 53 - 15 + 28 ^ '°' + 118 - 122 + 11);
    lIIlIlIIII[11] = "   ".length();
    lIIlIlIIII[12] = (34 + 42 - 15 + 79 ^ 28 + 127 - 54 + 38);
    lIIlIlIIII[13] = (0x1D ^ 0x18);
    lIIlIlIIII[14] = (0x6A ^ 0x5A);
    lIIlIlIIII[15] = (0x4F ^ 0x49);
    lIIlIlIIII[16] = (0xAE ^ 0x86);
    lIIlIlIIII[17] = (0xFFFFFFFF & 0xFFFFFF);
    lIIlIlIIII[18] = (0x3 ^ 0x65 ^ 0x3 ^ 0x6D);
  }
  
  private static boolean llllIIIllIl(int ???)
  {
    char llllllIIlIII;
    return ??? != 0;
  }
  
  public GuiIngameMenu() {}
  
  public void updateScreen()
  {
    ;
    lIIIIIIIIllII.updateScreen();
    field_146444_f += lIIlIlIIII[3];
  }
  
  private static boolean llllIIIllII(int ???)
  {
    String llllllIIIllI;
    return ??? == 0;
  }
  
  static
  {
    llllIIIlIll();
    llllIIIIIll();
  }
}

package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.IChatComponent;

public class GuiDisconnected
  extends GuiScreen
{
  static
  {
    llIlIIllllIlll();
    llIlIIllllIllI();
  }
  
  public void drawScreen(int llllllllllllllIlIIlllIIlllIlIIII, int llllllllllllllIlIIlllIIlllIIllll, float llllllllllllllIlIIlllIIlllIlIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIlllIIlllIlIIIl.drawDefaultBackground();
    llllllllllllllIlIIlllIIlllIlIIIl.drawCenteredString(fontRendererObj, reason, width / lIIIlIlIlllII[2], height / lIIIlIlIlllII[2] - field_175353_i / lIIIlIlIlllII[2] - fontRendererObj.FONT_HEIGHT * lIIIlIlIlllII[2], lIIIlIlIlllII[4]);
    int llllllllllllllIlIIlllIIlllIlIIll = height / lIIIlIlIlllII[2] - field_175353_i / lIIIlIlIlllII[2];
    if (llIlIIlllllIlI(multilineMessage))
    {
      llllllllllllllIlIIlllIIlllIIlIll = multilineMessage.iterator();
      "".length();
      if (" ".length() == 0) {
        return;
      }
      while (!llIlIIlllllIIl(llllllllllllllIlIIlllIIlllIIlIll.hasNext()))
      {
        String llllllllllllllIlIIlllIIlllIlIIlI = (String)llllllllllllllIlIIlllIIlllIIlIll.next();
        llllllllllllllIlIIlllIIlllIlIIIl.drawCenteredString(fontRendererObj, llllllllllllllIlIIlllIIlllIlIIlI, width / lIIIlIlIlllII[2], llllllllllllllIlIIlllIIlllIlIIll, lIIIlIlIlllII[5]);
        llllllllllllllIlIIlllIIlllIlIIll += fontRendererObj.FONT_HEIGHT;
      }
    }
    llllllllllllllIlIIlllIIlllIlIIIl.drawScreen(llllllllllllllIlIIlllIIlllIlIIII, llllllllllllllIlIIlllIIlllIIllll, llllllllllllllIlIIlllIIlllIlIlII);
  }
  
  protected void keyTyped(char llllllllllllllIlIIlllIIllllIlIIl, int llllllllllllllIlIIlllIIllllIlIII)
    throws IOException
  {}
  
  private static String llIlIIllllIlIl(String llllllllllllllIlIIlllIIllIlllIll, String llllllllllllllIlIIlllIIllIlllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIlllIIllIlllIll = new String(Base64.getDecoder().decode(llllllllllllllIlIIlllIIllIlllIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIIlllIIllIlllllI = new StringBuilder();
    char[] llllllllllllllIlIIlllIIllIllllIl = llllllllllllllIlIIlllIIllIlllIlI.toCharArray();
    int llllllllllllllIlIIlllIIllIllllII = lIIIlIlIlllII[0];
    double llllllllllllllIlIIlllIIllIllIllI = llllllllllllllIlIIlllIIllIlllIll.toCharArray();
    long llllllllllllllIlIIlllIIllIllIlIl = llllllllllllllIlIIlllIIllIllIllI.length;
    int llllllllllllllIlIIlllIIllIllIlII = lIIIlIlIlllII[0];
    while (llIlIIlllllIll(llllllllllllllIlIIlllIIllIllIlII, llllllllllllllIlIIlllIIllIllIlIl))
    {
      char llllllllllllllIlIIlllIIlllIIIIIl = llllllllllllllIlIIlllIIllIllIllI[llllllllllllllIlIIlllIIllIllIlII];
      "".length();
      "".length();
      if ((0x21 ^ 0x25) < 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIIlllIIllIlllllI);
  }
  
  public void initGui()
  {
    ;
    buttonList.clear();
    multilineMessage = fontRendererObj.listFormattedStringToWidth(message.getFormattedText(), width - lIIIlIlIlllII[1]);
    field_175353_i = (multilineMessage.size() * fontRendererObj.FONT_HEIGHT);
    new GuiButton(lIIIlIlIlllII[0], width / lIIIlIlIlllII[2] - lIIIlIlIlllII[3], height / lIIIlIlIlllII[2] + field_175353_i / lIIIlIlIlllII[2] + fontRendererObj.FONT_HEIGHT, I18n.format(lIIIlIlIllIll[lIIIlIlIlllII[0]], new Object[lIIIlIlIlllII[0]]));
    "".length();
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIlIIlllIIlllIlllll)
    throws IOException
  {
    ;
    ;
    if (llIlIIlllllIIl(id)) {
      mc.displayGuiScreen(parentScreen);
    }
  }
  
  private static boolean llIlIIlllllIIl(int ???)
  {
    short llllllllllllllIlIIlllIIllIlIlIll;
    return ??? == 0;
  }
  
  private static boolean llIlIIlllllIlI(Object ???)
  {
    String llllllllllllllIlIIlllIIllIlIllIl;
    return ??? != null;
  }
  
  private static void llIlIIllllIllI()
  {
    lIIIlIlIllIll = new String[lIIIlIlIlllII[6]];
    lIIIlIlIllIll[lIIIlIlIlllII[0]] = llIlIIllllIlIl("DDkReSIEAR05Iw==", "kLxWV");
  }
  
  private static void llIlIIllllIlll()
  {
    lIIIlIlIlllII = new int[7];
    lIIIlIlIlllII[0] = ((122 + 126 - 240 + 241 ^ '¯' + 57 - 220 + 182) & ("  ".length() ^ 0x35 ^ 0xC ^ -" ".length()));
    lIIIlIlIlllII[1] = (0x34 ^ 0x41 ^ 0x67 ^ 0x20);
    lIIIlIlIlllII[2] = "  ".length();
    lIIIlIlIlllII[3] = (0x96 ^ 0x8F ^ 0xDA ^ 0xA7);
    lIIIlIlIlllII[4] = (0xBFEF & 0xAAEABA);
    lIIIlIlIlllII[5] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIIIlIlIlllII[6] = " ".length();
  }
  
  private static boolean llIlIIlllllIll(int ???, int arg1)
  {
    int i;
    short llllllllllllllIlIIlllIIllIlIllll;
    return ??? < i;
  }
  
  public GuiDisconnected(GuiScreen llllllllllllllIlIIlllIIllllIllIl, String llllllllllllllIlIIlllIIlllllIIII, IChatComponent llllllllllllllIlIIlllIIllllIllll)
  {
    parentScreen = llllllllllllllIlIIlllIIllllIllIl;
    reason = I18n.format(llllllllllllllIlIIlllIIlllllIIII, new Object[lIIIlIlIlllII[0]]);
    message = llllllllllllllIlIIlllIIllllIllll;
  }
}

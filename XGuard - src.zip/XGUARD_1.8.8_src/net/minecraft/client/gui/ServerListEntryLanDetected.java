package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.LanServerDetector.LanServer;
import net.minecraft.client.settings.GameSettings;

public class ServerListEntryLanDetected
  implements GuiListExtended.IGuiListEntry
{
  public void setSelected(int llllllllllllllllIIlIIIlllIlIlIIl, int llllllllllllllllIIlIIIlllIlIlIII, int llllllllllllllllIIlIIIlllIlIIlll) {}
  
  private static void lIlllIIIlIIII()
  {
    lllIlllIlIl = new int[11];
    lllIlllIlIl[0] = ((32 + '' - 108 + 94 ^ 74 + 94 - 82 + 75) & (10 + 92 - 27 + 93 ^ '' + 89 - 213 + 132 ^ -" ".length()));
    lllIlllIlIl[1] = (0x63 ^ 0x43);
    lllIlllIlIl[2] = "   ".length();
    lllIlllIlIl[3] = " ".length();
    lllIlllIlIl[4] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lllIlllIlIl[5] = (0xCE ^ 0xC2);
    lllIlllIlIl[6] = (-(0xE6DE & 0x5D6B) & 0xFEC9 & 0x80C5FF);
    lllIlllIlIl[7] = (0 + '¤' - 102 + 127 ^ 4 + '' - 120 + 142);
    lllIlllIlIl[8] = (-(0xED7F & 0x5F87) & 0xFDBE & 0x307F77);
    lllIlllIlIl[9] = "  ".length();
    lllIlllIlIl[10] = (0x47 ^ 0x4F);
  }
  
  public LanServerDetector.LanServer getLanServer()
  {
    ;
    return field_148291_b;
  }
  
  private static void lIlllIIIIIllI()
  {
    lllIlllIIlI = new String[lllIlllIlIl[9]];
    lllIlllIIlI[lllIlllIlIl[0]] = lIlllIIIIIIll("XMKJortzqtRQhHVP+W8mOA==", "dhgyG");
    lllIlllIIlI[lllIlllIlIl[3]] = lIlllIIIIIIll("FZlHAi+2YK/HUgcQnmRKj853Q5epTX5FdLIifG1bnEo=", "WHvOC");
  }
  
  private static boolean lIlllIIIlIIIl(int ???)
  {
    Exception llllllllllllllllIIlIIIllIlllIlII;
    return ??? != 0;
  }
  
  private static int lIlllIIIlIIll(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  public void drawEntry(int llllllllllllllllIIlIIIllllIIIIII, int llllllllllllllllIIlIIIlllIllllll, int llllllllllllllllIIlIIIlllIlllllI, int llllllllllllllllIIlIIIlllIllllIl, int llllllllllllllllIIlIIIlllIllllII, int llllllllllllllllIIlIIIlllIlllIll, int llllllllllllllllIIlIIIlllIlllIlI, boolean llllllllllllllllIIlIIIlllIlllIIl)
  {
    ;
    ;
    ;
    "".length();
    "".length();
    if (lIlllIIIlIIIl(mc.gameSettings.hideServerAddress))
    {
      "".length();
      "".length();
      if ((("   ".length() ^ 0x95 ^ 0x88) & (0x32 ^ 0x17 ^ 0x4C ^ 0x77 ^ -" ".length())) == 0) {}
    }
    else
    {
      "".length();
    }
  }
  
  public void mouseReleased(int llllllllllllllllIIlIIIlllIlIIlIl, int llllllllllllllllIIlIIIlllIlIIlII, int llllllllllllllllIIlIIIlllIlIIIll, int llllllllllllllllIIlIIIlllIlIIIlI, int llllllllllllllllIIlIIIlllIlIIIIl, int llllllllllllllllIIlIIIlllIlIIIII) {}
  
  public boolean mousePressed(int llllllllllllllllIIlIIIlllIllIIlI, int llllllllllllllllIIlIIIlllIllIIIl, int llllllllllllllllIIlIIIlllIllIIII, int llllllllllllllllIIlIIIlllIlIllll, int llllllllllllllllIIlIIIlllIlIlllI, int llllllllllllllllIIlIIIlllIlIllIl)
  {
    ;
    ;
    field_148292_c.selectServer(llllllllllllllllIIlIIIlllIllIIlI);
    if (lIlllIIIlIlII(lIlllIIIlIIll(Minecraft.getSystemTime() - field_148290_d, 250L))) {
      field_148292_c.connectToSelected();
    }
    field_148290_d = Minecraft.getSystemTime();
    return lllIlllIlIl[0];
  }
  
  private static boolean lIlllIIIlIlII(int ???)
  {
    byte llllllllllllllllIIlIIIllIllIlllI;
    return ??? < 0;
  }
  
  protected ServerListEntryLanDetected(GuiMultiplayer llllllllllllllllIIlIIIllllIlllII, LanServerDetector.LanServer llllllllllllllllIIlIIIllllIlIlII)
  {
    field_148292_c = llllllllllllllllIIlIIIllllIlIllI;
    field_148291_b = llllllllllllllllIIlIIIllllIlIlII;
    mc = Minecraft.getMinecraft();
  }
  
  static
  {
    lIlllIIIlIIII();
    lIlllIIIIIllI();
  }
  
  private static String lIlllIIIIIIll(String llllllllllllllllIIlIIIlllIIIllII, String llllllllllllllllIIlIIIlllIIIIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIlIIIlllIIlIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIlIIIlllIIIIllI.getBytes(StandardCharsets.UTF_8)), lllIlllIlIl[10]), "DES");
      Cipher llllllllllllllllIIlIIIlllIIlIIII = Cipher.getInstance("DES");
      llllllllllllllllIIlIIIlllIIlIIII.init(lllIlllIlIl[9], llllllllllllllllIIlIIIlllIIlIIlI);
      return new String(llllllllllllllllIIlIIIlllIIlIIII.doFinal(Base64.getDecoder().decode(llllllllllllllllIIlIIIlllIIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIlIIIlllIIIlllI)
    {
      llllllllllllllllIIlIIIlllIIIlllI.printStackTrace();
    }
    return null;
  }
}

package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.DateFormat;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.AnvilConverterException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.ISaveHandler;
import net.minecraft.world.storage.SaveFormatComparator;
import net.minecraft.world.storage.WorldInfo;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;

public class GuiSelectWorld
  extends GuiScreen
  implements GuiYesNoCallback
{
  private static boolean lllIIIIllIllII(int ???, int arg1)
  {
    int i;
    int llllllllllllllIlIIIIIIlIlIllIlII;
    return ??? == i;
  }
  
  protected String func_146614_d(int llllllllllllllIlIIIIIIllIlIllIIl)
  {
    ;
    ;
    ;
    String llllllllllllllIlIIIIIIllIlIllIII = ((SaveFormatComparator)field_146639_s.get(llllllllllllllIlIIIIIIllIlIllIIl)).getDisplayName();
    if (lllIIIIllIlIll(StringUtils.isEmpty(llllllllllllllIlIIIIIIllIlIllIII))) {
      llllllllllllllIlIIIIIIllIlIllIII = String.valueOf(new StringBuilder(String.valueOf(I18n.format(lIIlIIlllIIll[lIIlIIllllIll[11]], new Object[lIIlIIllllIll[0]]))).append(lIIlIIlllIIll[lIIlIIllllIll[12]]).append(llllllllllllllIlIIIIIIllIlIllIIl + lIIlIIllllIll[2]));
    }
    return llllllllllllllIlIIIIIIllIlIllIII;
  }
  
  public void func_146618_g()
  {
    ;
    selectButton = new GuiButton(lIIlIIllllIll[2], width / lIIlIIllllIll[3] - lIIlIIllllIll[13], height - lIIlIIllllIll[14], lIIlIIllllIll[15], lIIlIIllllIll[16], I18n.format(lIIlIIlllIIll[lIIlIIllllIll[17]], new Object[lIIlIIllllIll[0]]));
    "".length();
    new GuiButton(lIIlIIllllIll[4], width / lIIlIIllllIll[3] + lIIlIIllllIll[1], height - lIIlIIllllIll[14], lIIlIIllllIll[15], lIIlIIllllIll[16], I18n.format(lIIlIIlllIIll[lIIlIIllllIll[18]], new Object[lIIlIIllllIll[0]]));
    "".length();
    renameButton = new GuiButton(lIIlIIllllIll[6], width / lIIlIIllllIll[3] - lIIlIIllllIll[13], height - lIIlIIllllIll[19], lIIlIIllllIll[20], lIIlIIllllIll[16], I18n.format(lIIlIIlllIIll[lIIlIIllllIll[21]], new Object[lIIlIIllllIll[0]]));
    "".length();
    deleteButton = new GuiButton(lIIlIIllllIll[3], width / lIIlIIllllIll[3] - lIIlIIllllIll[22], height - lIIlIIllllIll[19], lIIlIIllllIll[20], lIIlIIllllIll[16], I18n.format(lIIlIIlllIIll[lIIlIIllllIll[23]], new Object[lIIlIIllllIll[0]]));
    "".length();
    recreateButton = new GuiButton(lIIlIIllllIll[7], width / lIIlIIllllIll[3] + lIIlIIllllIll[1], height - lIIlIIllllIll[19], lIIlIIllllIll[20], lIIlIIllllIll[16], I18n.format(lIIlIIlllIIll[lIIlIIllllIll[24]], new Object[lIIlIIllllIll[0]]));
    "".length();
    new GuiButton(lIIlIIllllIll[0], width / lIIlIIllllIll[3] + lIIlIIllllIll[25], height - lIIlIIllllIll[19], lIIlIIllllIll[20], lIIlIIllllIll[16], I18n.format(lIIlIIlllIIll[lIIlIIllllIll[26]], new Object[lIIlIIllllIll[0]]));
    "".length();
    selectButton.enabled = lIIlIIllllIll[0];
    deleteButton.enabled = lIIlIIllllIll[0];
    renameButton.enabled = lIIlIIllllIll[0];
    recreateButton.enabled = lIIlIIllllIll[0];
  }
  
  public void drawScreen(int llllllllllllllIlIIIIIIllIIIlllII, int llllllllllllllIlIIIIIIllIIIlllll, float llllllllllllllIlIIIIIIllIIIllIlI)
  {
    ;
    ;
    ;
    ;
    field_146638_t.drawScreen(llllllllllllllIlIIIIIIllIIIlllII, llllllllllllllIlIIIIIIllIIIlllll, llllllllllllllIlIIIIIIllIIIllIlI);
    llllllllllllllIlIIIIIIllIIIlllIl.drawCenteredString(fontRendererObj, field_146628_f, width / lIIlIIllllIll[3], lIIlIIllllIll[16], lIIlIIllllIll[29]);
    llllllllllllllIlIIIIIIllIIIlllIl.drawScreen(llllllllllllllIlIIIIIIllIIIlllII, llllllllllllllIlIIIIIIllIIIlllll, llllllllllllllIlIIIIIIllIIIllIlI);
  }
  
  public void confirmClicked(boolean llllllllllllllIlIIIIIIllIIlIlllI, int llllllllllllllIlIIIIIIllIIlIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIIIIllIlIll(field_146643_x))
    {
      field_146643_x = lIIlIIllllIll[0];
      if (lllIIIIllIlIll(llllllllllllllIlIIIIIIllIIlIlIIl))
      {
        ISaveFormat llllllllllllllIlIIIIIIllIIlIllII = mc.getSaveLoader();
        llllllllllllllIlIIIIIIllIIlIllII.flushCache();
        "".length();
        try
        {
          llllllllllllllIlIIIIIIllIIlIlIlI.func_146627_h();
          "".length();
          if (null != null) {
            return;
          }
        }
        catch (AnvilConverterException llllllllllllllIlIIIIIIllIIlIlIll)
        {
          logger.error(lIIlIIlllIIll[lIIlIIllllIll[16]], llllllllllllllIlIIIIIIllIIlIlIll);
        }
      }
      mc.displayGuiScreen(llllllllllllllIlIIIIIIllIIlIlIlI);
    }
  }
  
  private static String lllIIIIlIIlIlI(String llllllllllllllIlIIIIIIlIlllIIIII, String llllllllllllllIlIIIIIIlIlllIIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIIIIIlIlllIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIIIIIlIlllIIIIl.getBytes(StandardCharsets.UTF_8)), lIIlIIllllIll[8]), "DES");
      Cipher llllllllllllllIlIIIIIIlIlllIIlII = Cipher.getInstance("DES");
      llllllllllllllIlIIIIIIlIlllIIlII.init(lIIlIIllllIll[3], llllllllllllllIlIIIIIIlIlllIIlIl);
      return new String(llllllllllllllIlIIIIIIlIlllIIlII.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIIIIIlIlllIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIIIIIlIlllIIIll)
    {
      llllllllllllllIlIIIIIIlIlllIIIll.printStackTrace();
    }
    return null;
  }
  
  public void initGui()
  {
    ;
    ;
    field_146628_f = I18n.format(lIIlIIlllIIll[lIIlIIllllIll[2]], new Object[lIIlIIllllIll[0]]);
    try
    {
      llllllllllllllIlIIIIIIllIlllIIII.func_146627_h();
      "".length();
      if ("  ".length() <= " ".length()) {
        return;
      }
    }
    catch (AnvilConverterException llllllllllllllIlIIIIIIllIllIllll)
    {
      logger.error(lIIlIIlllIIll[lIIlIIllllIll[3]], llllllllllllllIlIIIIIIllIllIllll);
      mc.displayGuiScreen(new GuiErrorScreen(lIIlIIlllIIll[lIIlIIllllIll[4]], llllllllllllllIlIIIIIIllIllIllll.getMessage()));
      return;
    }
    field_146637_u = I18n.format(lIIlIIlllIIll[lIIlIIllllIll[1]], new Object[lIIlIIllllIll[0]]);
    field_146636_v = I18n.format(lIIlIIlllIIll[lIIlIIllllIll[5]], new Object[lIIlIIllllIll[0]]);
    field_146635_w[net.minecraft.world.WorldSettings.GameType.SURVIVAL.getID()] = I18n.format(lIIlIIlllIIll[lIIlIIllllIll[6]], new Object[lIIlIIllllIll[0]]);
    field_146635_w[net.minecraft.world.WorldSettings.GameType.CREATIVE.getID()] = I18n.format(lIIlIIlllIIll[lIIlIIllllIll[7]], new Object[lIIlIIllllIll[0]]);
    field_146635_w[net.minecraft.world.WorldSettings.GameType.ADVENTURE.getID()] = I18n.format(lIIlIIlllIIll[lIIlIIllllIll[8]], new Object[lIIlIIllllIll[0]]);
    field_146635_w[net.minecraft.world.WorldSettings.GameType.SPECTATOR.getID()] = I18n.format(lIIlIIlllIIll[lIIlIIllllIll[9]], new Object[lIIlIIllllIll[0]]);
    field_146638_t = new List(mc);
    field_146638_t.registerScrollButtons(lIIlIIllllIll[1], lIIlIIllllIll[5]);
    llllllllllllllIlIIIIIIllIlllIIII.func_146618_g();
  }
  
  private static boolean lllIIIIlllIIII(int ???, int arg1)
  {
    int i;
    char llllllllllllllIlIIIIIIlIlIllIIII;
    return ??? < i;
  }
  
  public static GuiYesNo func_152129_a(GuiYesNoCallback llllllllllllllIlIIIIIIllIIIIlIIl, String llllllllllllllIlIIIIIIllIIIlIIII, int llllllllllllllIlIIIIIIllIIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    String llllllllllllllIlIIIIIIllIIIIlllI = I18n.format(lIIlIIlllIIll[lIIlIIllllIll[30]], new Object[lIIlIIllllIll[0]]);
    String llllllllllllllIlIIIIIIllIIIIllIl = String.valueOf(new StringBuilder(lIIlIIlllIIll[lIIlIIllllIll[31]]).append(llllllllllllllIlIIIIIIllIIIIlIII).append(lIIlIIlllIIll[lIIlIIllllIll[32]]).append(I18n.format(lIIlIIlllIIll[lIIlIIllllIll[33]], new Object[lIIlIIllllIll[0]])));
    String llllllllllllllIlIIIIIIllIIIIllII = I18n.format(lIIlIIlllIIll[lIIlIIllllIll[34]], new Object[lIIlIIllllIll[0]]);
    String llllllllllllllIlIIIIIIllIIIIlIll = I18n.format(lIIlIIlllIIll[lIIlIIllllIll[35]], new Object[lIIlIIllllIll[0]]);
    GuiYesNo llllllllllllllIlIIIIIIllIIIIlIlI = new GuiYesNo(llllllllllllllIlIIIIIIllIIIIlIIl, llllllllllllllIlIIIIIIllIIIIlllI, llllllllllllllIlIIIIIIllIIIIllIl, llllllllllllllIlIIIIIIllIIIIllII, llllllllllllllIlIIIIIIllIIIIlIll, llllllllllllllIlIIIIIIllIIIIllll);
    return llllllllllllllIlIIIIIIllIIIIlIlI;
  }
  
  private static boolean lllIIIIllIlllI(int ???)
  {
    boolean llllllllllllllIlIIIIIIlIlIlIlIII;
    return ??? == 0;
  }
  
  private static boolean lllIIIIllIllIl(Object ???)
  {
    double llllllllllllllIlIIIIIIlIlIlIlllI;
    return ??? != null;
  }
  
  private static String lllIIIIlIlIIIl(String llllllllllllllIlIIIIIIlIlIllllIl, String llllllllllllllIlIIIIIIlIlIlllIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIIIIIlIllIIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIIIIIlIlIlllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIIIIIIlIlIllllll = Cipher.getInstance("Blowfish");
      llllllllllllllIlIIIIIIlIlIllllll.init(lIIlIIllllIll[3], llllllllllllllIlIIIIIIlIllIIIIII);
      return new String(llllllllllllllIlIIIIIIlIlIllllll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIIIIIlIlIllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIIIIIlIlIlllllI)
    {
      llllllllllllllIlIIIIIIlIlIlllllI.printStackTrace();
    }
    return null;
  }
  
  public void func_146615_e(int llllllllllllllIlIIIIIIllIIlllIll)
  {
    ;
    ;
    ;
    ;
    mc.displayGuiScreen(null);
    if (lllIIIIllIlllI(field_146634_i))
    {
      field_146634_i = lIIlIIllllIll[2];
      String llllllllllllllIlIIIIIIllIIlllIlI = llllllllllllllIlIIIIIIllIIlllIII.func_146621_a(llllllllllllllIlIIIIIIllIIlllIll);
      if (lllIIIIllIllll(llllllllllllllIlIIIIIIllIIlllIlI)) {
        llllllllllllllIlIIIIIIllIIlllIlI = String.valueOf(new StringBuilder(lIIlIIlllIIll[lIIlIIllllIll[27]]).append(llllllllllllllIlIIIIIIllIIlllIll));
      }
      String llllllllllllllIlIIIIIIllIIlllIIl = llllllllllllllIlIIIIIIllIIlllIII.func_146614_d(llllllllllllllIlIIIIIIllIIlllIll);
      if (lllIIIIllIllll(llllllllllllllIlIIIIIIllIIlllIIl)) {
        llllllllllllllIlIIIIIIllIIlllIIl = String.valueOf(new StringBuilder(lIIlIIlllIIll[lIIlIIllllIll[28]]).append(llllllllllllllIlIIIIIIllIIlllIll));
      }
      if (lllIIIIllIlIll(mc.getSaveLoader().canLoadWorld(llllllllllllllIlIIIIIIllIIlllIlI))) {
        mc.launchIntegratedServer(llllllllllllllIlIIIIIIllIIlllIlI, llllllllllllllIlIIIIIIllIIlllIIl, null);
      }
    }
  }
  
  private static boolean lllIIIIllIlIll(int ???)
  {
    String llllllllllllllIlIIIIIIlIlIlIlIlI;
    return ??? != 0;
  }
  
  private static void lllIIIIlIlIllI()
  {
    lIIlIIlllIIll = new String[lIIlIIllllIll[36]];
    lIIlIIlllIIll[lIIlIIllllIll[0]] = lllIIIIlIIlIlI("2A7Dn0ycD/srYSuVbbyFrw==", "UvXMH");
    lIIlIIlllIIll[lIIlIIllllIll[2]] = lllIIIIlIIlIll("FjQbMgERBhglDgF/Az4WCTQ=", "eQwWb");
    lIIlIIlllIIll[lIIlIIllllIll[3]] = lllIIIIlIIlIll("FSclHz04byRTNTkpNFM1Mz41H3k6ISMH", "VHPsY");
    lIIlIIlllIIll[lIIlIIllllIll[4]] = lllIIIIlIIlIll("MTgKEDsBdh8ddwg5ChZ3EzkZHjMX", "dVkrW");
    lIIlIIlllIIll[lIIlIIllllIll[1]] = lllIIIIlIIlIlI("YH4q3Tmq3A2aZu5Za5ctiz61O1rkjATh", "GhiYX");
    lIIlIIlllIIll[lIIlIIllllIll[5]] = lllIIIIlIlIIIl("AdgCeByf/QVBs1tv7FR4y7eJaLGorSKF", "oGvlu");
    lIIlIIlllIIll[lIIlIIllllIll[6]] = lllIIIIlIIlIlI("uUo2IMbpuSze06SFldRJ1W3adQq/ICdy", "kqUhQ");
    lIIlIIlllIIll[lIIlIIllllIll[7]] = lllIIIIlIIlIll("LhUDLiEmEAtlDzsRDz8FPxE=", "ItnKl");
    lIIlIIlllIIll[lIIlIIllllIll[8]] = lllIIIIlIIlIll("ChM+FjsCFjZdFwkENh0CGAA2", "mrSsv");
    lIIlIIlllIIll[lIIlIIllllIll[9]] = lllIIIIlIIlIll("FSguCS8dLSZCEQIsIBgDBiYx", "rIClb");
    lIIlIIlllIIll[lIIlIIllllIll[11]] = lllIIIIlIIlIll("CSMNPCcOEQ4rKB5oFjY2FiI=", "zFaYD");
    lIIlIIlllIIll[lIIlIIllllIll[12]] = lllIIIIlIlIIIl("x6n9RCy0YuE=", "HAoyR");
    lIIlIIlllIIll[lIIlIIllllIll[17]] = lllIIIIlIIlIlI("xi+eYvCL+s3159KPrswRvq54lc/m0zwT", "GlgYt");
    lIIlIIlllIIll[lIIlIIllllIll[18]] = lllIIIIlIIlIlI("ZgyjTQl20CWxTmGgNS0Dn1fB2OI+UJIl", "lDTpW");
    lIIlIIlllIIll[lIIlIIllllIll[21]] = lllIIIIlIIlIll("MDEtNAY3Ay4jCSd6MzQLIjkk", "CTAQe");
    lIIlIIlllIIll[lIIlIIllllIll[23]] = lllIIIIlIIlIlI("twtzHUzMwOqmlWFcc0W0FH4JS+8vRSsV", "dcAfm");
    lIIlIIlllIIll[lIIlIIllllIll[24]] = lllIIIIlIIlIll("HAQJMyEbNgokLgtPFzMhHQQEIic=", "oaeVB");
    lIIlIIlllIIll[lIIlIIllllIll[26]] = lllIIIIlIIlIlI("8W12GXhFc+twAxIdzNOHlg==", "fkVfR");
    lIIlIIlllIIll[lIIlIIllllIll[27]] = lllIIIIlIlIIIl("zrGrh0fKPGg=", "fJoRc");
    lIIlIIlllIIll[lIIlIIllllIll[28]] = lllIIIIlIlIIIl("TduC+ur9lqo=", "riMkN");
    lIIlIIlllIIll[lIIlIIllllIll[16]] = lllIIIIlIIlIlI("RicQzBTlVSTn3X2l5rzrj+vnbT2nP0Bl5bkcnMnSjmA=", "NKsnL");
    lIIlIIlllIIll[lIIlIIllllIll[30]] = lllIIIIlIIlIlI("OYbSsRABZ0C6o2Dm3aEImsfmaBHc2zbLHWpNFgqBjKU=", "rhtTn");
    lIIlIIlllIIll[lIIlIIllllIll[31]] = lllIIIIlIIlIlI("RZeeea5TU80=", "qcNaZ");
    lIIlIIlllIIll[lIIlIIllllIll[32]] = lllIIIIlIIlIll("Xng=", "yXdsr");
    lIIlIIlllIIll[lIIlIIllllIll[33]] = lllIIIIlIIlIlI("fD88M9UmHTENQ5KFRd01MfR4xmBYLxZnCJrdXlCe4Us=", "KYMDN");
    lIIlIIlllIIll[lIIlIIllllIll[34]] = lllIIIIlIIlIlI("MabvEZKwXXvJ1Ff1VI4b+D6c4rlztCMRNBRhrlPCRbk=", "BNVgq");
    lIIlIIlllIIll[lIIlIIllllIll[35]] = lllIIIIlIlIIIl("WTR2t8K/9E81kGNy8GlVMw==", "gnjyC");
  }
  
  public GuiSelectWorld(GuiScreen llllllllllllllIlIIIIIIllIlllIlIl)
  {
    parentScreen = llllllllllllllIlIIIIIIllIlllIlIl;
  }
  
  private void func_146627_h()
    throws AnvilConverterException
  {
    ;
    ;
    ISaveFormat llllllllllllllIlIIIIIIllIllIIllI = mc.getSaveLoader();
    field_146639_s = llllllllllllllIlIIIIIIllIllIIllI.getSaveList();
    Collections.sort(field_146639_s);
    field_146640_r = lIIlIIllllIll[10];
  }
  
  private static void lllIIIIllIlIIl()
  {
    lIIlIIllllIll = new int[37];
    lIIlIIllllIll[0] = ((0x91 ^ 0xA7 ^ 0xE4 ^ 0x9C) & (0x46 ^ 0x37 ^ 0x6D ^ 0x52 ^ -" ".length()));
    lIIlIIllllIll[1] = (0x77 ^ 0x17 ^ 0x54 ^ 0x30);
    lIIlIIllllIll[2] = " ".length();
    lIIlIIllllIll[3] = "  ".length();
    lIIlIIllllIll[4] = "   ".length();
    lIIlIIllllIll[5] = (0xAE ^ 0x9E ^ 0x20 ^ 0x15);
    lIIlIIllllIll[6] = (0xB4 ^ 0x83 ^ 0x33 ^ 0x2);
    lIIlIIllllIll[7] = (0x19 ^ 0x1E);
    lIIlIIllllIll[8] = (109 + 53 - 26 + 34 ^ 17 + 63 - 19 + 101);
    lIIlIIllllIll[9] = (0x27 ^ 0x47 ^ 0xF7 ^ 0x9E);
    lIIlIIllllIll[10] = (-" ".length());
    lIIlIIllllIll[11] = (0xB6 ^ 0xBC);
    lIIlIIllllIll[12] = (0xA6 ^ 0x96 ^ 0x3A ^ 0x1);
    lIIlIIllllIll[13] = ('' + 27 - 70 + 46 + (0x85 ^ 0x92) - (0x8F ^ 0xB7) + (0x80 ^ 0xB2));
    lIIlIIllllIll[14] = (0x20 ^ 0x14);
    lIIlIIllllIll[15] = (16 + 1 - -47 + 86);
    lIIlIIllllIll[16] = (0xEA ^ 0xAF ^ 0x2F ^ 0x7E);
    lIIlIIllllIll[17] = (0x26 ^ 0x2A);
    lIIlIIllllIll[18] = (0x8E ^ 0x83);
    lIIlIIllllIll[19] = (0x53 ^ 0x4F);
    lIIlIIllllIll[20] = (47 + '' - -14 + 21 ^ 3 + 49 - -71 + 39);
    lIIlIIllllIll[21] = (0x90 ^ 0x9E);
    lIIlIIllllIll[22] = (0xB8 ^ 0xB7 ^ 0x26 ^ 0x65);
    lIIlIIllllIll[23] = (0x40 ^ 0x4F);
    lIIlIIllllIll[24] = (0x1B ^ 0xB);
    lIIlIIllllIll[25] = (0x3C ^ 0x3 ^ 0x19 ^ 0x74);
    lIIlIIllllIll[26] = (0x52 ^ 0x43);
    lIIlIIllllIll[27] = (0xB0 ^ 0xA2);
    lIIlIIllllIll[28] = (0x94 ^ 0x87);
    lIIlIIllllIll[29] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIIlIIllllIll[30] = (0x8A ^ 0x9F);
    lIIlIIllllIll[31] = (0x64 ^ 0x72);
    lIIlIIllllIll[32] = (0x4C ^ 0x5B);
    lIIlIIllllIll[33] = (0x61 ^ 0x79);
    lIIlIIllllIll[34] = (0x9D ^ 0xA3 ^ 0x1E ^ 0x39);
    lIIlIIllllIll[35] = (0x30 ^ 0x2A);
    lIIlIIllllIll[36] = (0xA1 ^ 0xBA);
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    llllllllllllllIlIIIIIIllIllIlIlI.handleMouseInput();
    field_146638_t.handleMouseInput();
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIlIIIIIIllIlIIIlII)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIIIIllIlIll(enabled)) {
      if (lllIIIIllIllII(id, lIIlIIllllIll[3]))
      {
        String llllllllllllllIlIIIIIIllIlIIlIlI = llllllllllllllIlIIIIIIllIlIIIlIl.func_146614_d(field_146640_r);
        if (lllIIIIllIllIl(llllllllllllllIlIIIIIIllIlIIlIlI))
        {
          field_146643_x = lIIlIIllllIll[2];
          GuiYesNo llllllllllllllIlIIIIIIllIlIIlIIl = func_152129_a(llllllllllllllIlIIIIIIllIlIIIlIl, llllllllllllllIlIIIIIIllIlIIlIlI, field_146640_r);
          mc.displayGuiScreen(llllllllllllllIlIIIIIIllIlIIlIIl);
          "".length();
          if (((0x52 ^ 0x1A) & (0xEB ^ 0xA3 ^ 0xFFFFFFFF)) >= ((0xC7 ^ 0x8B) & (0x30 ^ 0x7C ^ 0xFFFFFFFF))) {}
        }
      }
      else if (lllIIIIllIllII(id, lIIlIIllllIll[2]))
      {
        llllllllllllllIlIIIIIIllIlIIIlIl.func_146615_e(field_146640_r);
        "".length();
        if ((('' + 60 - -21 + 16 ^ 44 + 93 - 120 + 123) & (0xE5 ^ 0xB5 ^ 0x15 ^ 0x26 ^ -" ".length())) == 0) {}
      }
      else if (lllIIIIllIllII(id, lIIlIIllllIll[4]))
      {
        mc.displayGuiScreen(new GuiCreateWorld(llllllllllllllIlIIIIIIllIlIIIlIl));
        "".length();
        if (-" ".length() == -" ".length()) {}
      }
      else if (lllIIIIllIllII(id, lIIlIIllllIll[6]))
      {
        mc.displayGuiScreen(new GuiRenameWorld(llllllllllllllIlIIIIIIllIlIIIlIl, llllllllllllllIlIIIIIIllIlIIIlIl.func_146621_a(field_146640_r)));
        "".length();
        if (null == null) {}
      }
      else if (lllIIIIllIlllI(id))
      {
        mc.displayGuiScreen(parentScreen);
        "".length();
        if (((0xB9 ^ 0x99) & (0x6E ^ 0x4E ^ 0xFFFFFFFF)) >= 0) {}
      }
      else if (lllIIIIllIllII(id, lIIlIIllllIll[7]))
      {
        GuiCreateWorld llllllllllllllIlIIIIIIllIlIIlIII = new GuiCreateWorld(llllllllllllllIlIIIIIIllIlIIIlIl);
        ISaveHandler llllllllllllllIlIIIIIIllIlIIIlll = mc.getSaveLoader().getSaveLoader(llllllllllllllIlIIIIIIllIlIIIlIl.func_146621_a(field_146640_r), lIIlIIllllIll[0]);
        WorldInfo llllllllllllllIlIIIIIIllIlIIIllI = llllllllllllllIlIIIIIIllIlIIIlll.loadWorldInfo();
        llllllllllllllIlIIIIIIllIlIIIlll.flush();
        llllllllllllllIlIIIIIIllIlIIlIII.func_146318_a(llllllllllllllIlIIIIIIllIlIIIllI);
        mc.displayGuiScreen(llllllllllllllIlIIIIIIllIlIIlIII);
        "".length();
        if (-(0xEE ^ 0xC1 ^ 0xB5 ^ 0x9F) < 0) {}
      }
      else
      {
        field_146638_t.actionPerformed(llllllllllllllIlIIIIIIllIlIIIlII);
      }
    }
  }
  
  private static boolean lllIIIIllIllll(Object ???)
  {
    short llllllllllllllIlIIIIIIlIlIlIllII;
    return ??? == null;
  }
  
  static
  {
    lllIIIIllIlIIl();
    lllIIIIlIlIllI();
  }
  
  protected String func_146621_a(int llllllllllllllIlIIIIIIllIllIIIII)
  {
    ;
    ;
    return ((SaveFormatComparator)field_146639_s.get(llllllllllllllIlIIIIIIllIllIIIII)).getFileName();
  }
  
  private static String lllIIIIlIIlIll(String llllllllllllllIlIIIIIIlIllIlIIlI, String llllllllllllllIlIIIIIIlIllIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIIIIIlIllIlIIlI = new String(Base64.getDecoder().decode(llllllllllllllIlIIIIIIlIllIlIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIIIIIIlIllIlIIII = new StringBuilder();
    char[] llllllllllllllIlIIIIIIlIllIIllll = llllllllllllllIlIIIIIIlIllIlIIIl.toCharArray();
    int llllllllllllllIlIIIIIIlIllIIlllI = lIIlIIllllIll[0];
    float llllllllllllllIlIIIIIIlIllIIlIII = llllllllllllllIlIIIIIIlIllIlIIlI.toCharArray();
    byte llllllllllllllIlIIIIIIlIllIIIlll = llllllllllllllIlIIIIIIlIllIIlIII.length;
    byte llllllllllllllIlIIIIIIlIllIIIllI = lIIlIIllllIll[0];
    while (lllIIIIlllIIII(llllllllllllllIlIIIIIIlIllIIIllI, llllllllllllllIlIIIIIIlIllIIIlll))
    {
      char llllllllllllllIlIIIIIIlIllIlIIll = llllllllllllllIlIIIIIIlIllIIlIII[llllllllllllllIlIIIIIIlIllIIIllI];
      "".length();
      "".length();
      if (-" ".length() != -" ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIIIIIIlIllIlIIII);
  }
  
  class List
    extends GuiSlot
  {
    protected void drawBackground()
    {
      ;
      drawDefaultBackground();
    }
    
    private static boolean lIlIIllIIIIlIl(int ???)
    {
      String llllllllllllllIllllllIlIIlIllllI;
      return ??? >= 0;
    }
    
    protected void drawSlot(int llllllllllllllIllllllIlIlIIlIlIl, int llllllllllllllIllllllIlIlIIlIlII, int llllllllllllllIllllllIlIlIIlIIll, int llllllllllllllIllllllIlIlIIlllIl, int llllllllllllllIllllllIlIlIIlllII, int llllllllllllllIllllllIlIlIIllIll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      SaveFormatComparator llllllllllllllIllllllIlIlIIllIlI = (SaveFormatComparator)field_146639_s.get(llllllllllllllIllllllIlIlIIlIlIl);
      String llllllllllllllIllllllIlIlIIllIIl = llllllllllllllIllllllIlIlIIllIlI.getDisplayName();
      if (lIlIIllIIIIlll(StringUtils.isEmpty(llllllllllllllIllllllIlIlIIllIIl))) {
        llllllllllllllIllllllIlIlIIllIIl = String.valueOf(new StringBuilder(String.valueOf(field_146637_u)).append(llIllIIlIIll[llIllIIlIlIl[4]]).append(llllllllllllllIllllllIlIlIIlIlIl + llIllIIlIlIl[3]));
      }
      String llllllllllllllIllllllIlIlIIllIII = llllllllllllllIllllllIlIlIIllIlI.getFileName();
      llllllllllllllIllllllIlIlIIllIII = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIllllllIlIlIIllIII)).append(llIllIIlIIll[llIllIIlIlIl[3]]).append(field_146633_h.format(new Date(llllllllllllllIllllllIlIlIIllIlI.getLastTimePlayed()))));
      llllllllllllllIllllllIlIlIIllIII = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIllllllIlIlIIllIII)).append(llIllIIlIIll[llIllIIlIlIl[5]]));
      String llllllllllllllIllllllIlIlIIlIlll = llIllIIlIIll[llIllIIlIlIl[6]];
      if (lIlIIllIIIIlll(llllllllllllllIllllllIlIlIIllIlI.requiresConversion()))
      {
        llllllllllllllIllllllIlIlIIlIlll = String.valueOf(new StringBuilder(String.valueOf(field_146636_v)).append(llIllIIlIIll[llIllIIlIlIl[7]]).append(llllllllllllllIllllllIlIlIIlIlll));
        "".length();
        if (null == null) {}
      }
      else
      {
        llllllllllllllIllllllIlIlIIlIlll = field_146635_w[llllllllllllllIllllllIlIlIIllIlI.getEnumGameType().getID()];
        if (lIlIIllIIIIlll(llllllllllllllIllllllIlIlIIllIlI.isHardcoreModeEnabled())) {
          llllllllllllllIllllllIlIlIIlIlll = String.valueOf(new StringBuilder().append(EnumChatFormatting.DARK_RED).append(I18n.format(llIllIIlIIll[llIllIIlIlIl[8]], new Object[llIllIIlIlIl[4]])).append(EnumChatFormatting.RESET));
        }
        if (lIlIIllIIIIlll(llllllllllllllIllllllIlIlIIllIlI.getCheatsEnabled())) {
          llllllllllllllIllllllIlIlIIlIlll = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIllllllIlIlIIlIlll)).append(llIllIIlIIll[llIllIIlIlIl[9]]).append(I18n.format(llIllIIlIIll[llIllIIlIlIl[10]], new Object[llIllIIlIlIl[4]])));
        }
      }
      drawString(fontRendererObj, llllllllllllllIllllllIlIlIIllIIl, llllllllllllllIllllllIlIlIIlIlII + llIllIIlIlIl[5], llllllllllllllIllllllIlIlIIllllI + llIllIIlIlIl[3], llIllIIlIlIl[11]);
      drawString(fontRendererObj, llllllllllllllIllllllIlIlIIllIII, llllllllllllllIllllllIlIlIIlIlII + llIllIIlIlIl[5], llllllllllllllIllllllIlIlIIllllI + llIllIIlIlIl[12], llIllIIlIlIl[13]);
      drawString(fontRendererObj, llllllllllllllIllllllIlIlIIlIlll, llllllllllllllIllllllIlIlIIlIlII + llIllIIlIlIl[5], llllllllllllllIllllllIlIlIIllllI + llIllIIlIlIl[12] + llIllIIlIlIl[14], llIllIIlIlIl[13]);
    }
    
    private static boolean lIlIIllIIIIlll(int ???)
    {
      long llllllllllllllIllllllIlIIllIIIII;
      return ??? != 0;
    }
    
    protected void elementClicked(int llllllllllllllIllllllIlIlIlllIII, boolean llllllllllllllIllllllIlIlIllllIl, int llllllllllllllIllllllIlIlIllllII, int llllllllllllllIllllllIlIlIlllIll)
    {
      ;
      ;
      ;
      ;
      field_146640_r = llllllllllllllIllllllIlIlIlllIII;
      if ((lIlIIllIIIIlIl(field_146640_r)) && (lIlIIllIIIIllI(field_146640_r, llllllllllllllIllllllIlIlIllllll.getSize())))
      {
        "".length();
        if (" ".length() >= ((0x85 ^ 0x8A ^ 0x54 ^ 0x6F) & (0x8D ^ 0xC3 ^ 0xD ^ 0x77 ^ -" ".length()))) {
          break label97;
        }
      }
      label97:
      boolean llllllllllllllIllllllIlIlIlllIlI = llIllIIlIlIl[4];
      selectButton.enabled = llllllllllllllIllllllIlIlIlllIlI;
      deleteButton.enabled = llllllllllllllIllllllIlIlIlllIlI;
      renameButton.enabled = llllllllllllllIllllllIlIlIlllIlI;
      recreateButton.enabled = llllllllllllllIllllllIlIlIlllIlI;
      if ((lIlIIllIIIIlll(llllllllllllllIllllllIlIlIllIlll)) && (lIlIIllIIIIlll(llllllllllllllIllllllIlIlIlllIlI))) {
        func_146615_e(llllllllllllllIllllllIlIlIlllIII);
      }
    }
    
    protected int getContentHeight()
    {
      ;
      return field_146639_s.size() * llIllIIlIlIl[2];
    }
    
    static
    {
      lIlIIllIIIIlII();
      lIlIIllIIIIIIl();
    }
    
    private static boolean lIlIIllIIIIllI(int ???, int arg1)
    {
      int i;
      byte llllllllllllllIllllllIlIIllIIIlI;
      return ??? < i;
    }
    
    public List(Minecraft llllllllllllllIllllllIlIllIIIlll)
    {
      llllllllllllllIllllllIlIllIIlIll.<init>(llllllllllllllIllllllIlIllIIIlll, width, height, llIllIIlIlIl[0], height - llIllIIlIlIl[1], llIllIIlIlIl[2]);
    }
    
    protected boolean isSelected(int llllllllllllllIllllllIlIlIllIIlI)
    {
      ;
      ;
      if (lIlIIllIIIlIII(llllllllllllllIllllllIlIlIllIIlI, field_146640_r)) {
        return llIllIIlIlIl[3];
      }
      return llIllIIlIlIl[4];
    }
    
    private static boolean lIlIIllIIIlIII(int ???, int arg1)
    {
      int i;
      short llllllllllllllIllllllIlIIllIIllI;
      return ??? == i;
    }
    
    private static void lIlIIllIIIIlII()
    {
      llIllIIlIlIl = new int[16];
      llIllIIlIlIl[0] = (0x9B ^ 0xBB);
      llIllIIlIlIl[1] = ('¾' + '' - 114 + 45 ^ 111 + 110 - 87 + 51);
      llIllIIlIlIl[2] = (0x17 ^ 0x33);
      llIllIIlIlIl[3] = " ".length();
      llIllIIlIlIl[4] = ((0xD1 ^ 0xB7 ^ 0x97 ^ 0xBB) & ('' + 118 - 206 + 183 ^ '' + '·' - 186 + 38 ^ -" ".length()));
      llIllIIlIlIl[5] = "  ".length();
      llIllIIlIlIl[6] = "   ".length();
      llIllIIlIlIl[7] = (0x2F ^ 0x29 ^ "  ".length());
      llIllIIlIlIl[8] = (0x45 ^ 0x40);
      llIllIIlIlIl[9] = (70 + 7 - -1 + 112 ^ '' + 73 - 195 + 169);
      llIllIIlIlIl[10] = (0xB1 ^ 0xB6);
      llIllIIlIlIl[11] = (0xFFFFFFFF & 0xFFFFFF);
      llIllIIlIlIl[12] = (0x10 ^ 0x1C);
      llIllIIlIlIl[13] = (-(0xF37F & 0x4FF9) & 0xEBFB & 0x80D7FC);
      llIllIIlIlIl[14] = (0x6F ^ 0x65);
      llIllIIlIlIl[15] = (16 + 55 - 65 + 155 ^ 58 + 76 - 130 + 165);
    }
    
    private static String lIlIIllIIIIIII(String llllllllllllllIllllllIlIIlllllll, String llllllllllllllIllllllIlIlIIIIIll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIllllllIlIIlllllll = new String(Base64.getDecoder().decode(llllllllllllllIllllllIlIIlllllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIllllllIlIlIIIIIlI = new StringBuilder();
      char[] llllllllllllllIllllllIlIlIIIIIIl = llllllllllllllIllllllIlIlIIIIIll.toCharArray();
      int llllllllllllllIllllllIlIlIIIIIII = llIllIIlIlIl[4];
      boolean llllllllllllllIllllllIlIIllllIlI = llllllllllllllIllllllIlIIlllllll.toCharArray();
      char llllllllllllllIllllllIlIIllllIIl = llllllllllllllIllllllIlIIllllIlI.length;
      int llllllllllllllIllllllIlIIllllIII = llIllIIlIlIl[4];
      while (lIlIIllIIIIllI(llllllllllllllIllllllIlIIllllIII, llllllllllllllIllllllIlIIllllIIl))
      {
        char llllllllllllllIllllllIlIlIIIIlIl = llllllllllllllIllllllIlIIllllIlI[llllllllllllllIllllllIlIIllllIII];
        "".length();
        "".length();
        if ((('' + 10 - 55 + 57 ^ 15 + 57 - -34 + 69) & (0x6D ^ 0x3E ^ 0x17 ^ 0x4B ^ -" ".length())) != 0) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIllllllIlIlIIIIIlI);
    }
    
    private static void lIlIIllIIIIIIl()
    {
      llIllIIlIIll = new String[llIllIIlIlIl[15]];
      llIllIIlIIll[llIllIIlIlIl[4]] = lIlIIlIlllllII("sylQX8XP7N0=", "gPoVK");
      llIllIIlIIll[llIllIIlIlIl[3]] = lIlIIlIlllllII("qEwfzlfgTt0=", "AzSTw");
      llIllIIlIIll[llIllIIlIlIl[5]] = lIlIIlIlllllII("d7RufQoguoE=", "WMbhN");
      llIllIIlIIll[llIllIIlIlIl[6]] = lIlIIllIIIIIII("", "xReSp");
      llIllIIlIIll[llIllIIlIlIl[7]] = lIlIIllIIIIIII("WA==", "xbnqM");
      llIllIIlIIll[llIllIIlIlIl[8]] = lIlIIlIlllllII("TPG0q89w21lMUe68GUjXvfOFS3VR6kd1", "fEIgw");
      llIllIIlIIll[llIllIIlIlIl[9]] = lIlIIllIIIIIII("WEQ=", "tdcJR");
      llIllIIlIIll[llIllIIlIlIl[10]] = lIlIIlIlllllII("HTaSBWdDDHBDCEVGuRg1mNyKO+gjI+SX", "HlsJF");
    }
    
    private static String lIlIIlIlllllII(String llllllllllllllIllllllIlIIllIllll, String llllllllllllllIllllllIlIIllIllII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIllllllIlIIlllIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllllllIlIIllIllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIllllllIlIIlllIIIl = Cipher.getInstance("Blowfish");
        llllllllllllllIllllllIlIIlllIIIl.init(llIllIIlIlIl[5], llllllllllllllIllllllIlIIlllIIlI);
        return new String(llllllllllllllIllllllIlIIlllIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllllllIlIIllIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIllllllIlIIlllIIII)
      {
        llllllllllllllIllllllIlIIlllIIII.printStackTrace();
      }
      return null;
    }
    
    protected int getSize()
    {
      ;
      return field_146639_s.size();
    }
  }
}

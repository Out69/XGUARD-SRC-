package net.minecraft.client.gui;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Iterator;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.BlockPortal;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.BlockModelShapes;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.boss.BossStatus;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.profiler.Profiler;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.FoodStats;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.StringUtils;
import net.minecraft.world.World;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.storage.WorldInfo;
import optfine.Config;

public class GuiIngame
  extends Gui
{
  private static boolean lIlIlIlllIlI(int ???, int arg1)
  {
    int i;
    short llllllllllllllllllIlllIIllllllll;
    return ??? <= i;
  }
  
  public void updateTick()
  {
    ;
    ;
    if (lIlIlIlllIII(recordPlayingUpFor)) {
      recordPlayingUpFor -= llIlIllIlI[1];
    }
    if (lIlIlIlllIII(field_175195_w))
    {
      field_175195_w -= llIlIllIlI[1];
      if (lIlIllIIIlII(field_175195_w))
      {
        field_175201_x = llIlIlIlIl[llIlIllIlI[68]];
        field_175200_y = llIlIlIlIl[llIlIllIlI[63]];
      }
    }
    updateCounter += llIlIllIlI[1];
    streamIndicator.func_152439_a();
    if (lIlIlIllIllI(mc.thePlayer))
    {
      ItemStack llllllllllllllllllIlllIlIlllllIl = mc.thePlayer.inventory.getCurrentItem();
      if (lIlIlIllllII(llllllllllllllllllIlllIlIlllllIl))
      {
        remainingHighlightTicks = llIlIllIlI[0];
        "".length();
        if ("   ".length() != 0) {}
      }
      else if ((lIlIlIllIllI(highlightingItemStack)) && (lIlIlIllIlll(llllllllllllllllllIlllIlIlllllIl.getItem(), highlightingItemStack.getItem())) && (lIlIlIllIlII(ItemStack.areItemStackTagsEqual(llllllllllllllllllIlllIlIlllllIl, highlightingItemStack))) && ((!lIlIlIllIlIl(llllllllllllllllllIlllIlIlllllIl.isItemStackDamageable())) || (lIlIlIllllll(llllllllllllllllllIlllIlIlllllIl.getMetadata(), highlightingItemStack.getMetadata()))))
      {
        if (lIlIlIlllIII(remainingHighlightTicks))
        {
          remainingHighlightTicks -= llIlIllIlI[1];
          "".length();
          if (" ".length() < "  ".length()) {}
        }
      }
      else
      {
        remainingHighlightTicks = llIlIllIlI[69];
      }
      highlightingItemStack = llllllllllllllllllIlllIlIlllllIl;
    }
  }
  
  private static boolean lIlIlIllIlll(Object ???, Object arg1)
  {
    Object localObject;
    boolean llllllllllllllllllIlllIIllllIlIl;
    return ??? == localObject;
  }
  
  private static String lIlIlIIlIlll(String llllllllllllllllllIlllIlIIlIlIIl, String llllllllllllllllllIlllIlIIlIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllllIlllIlIIlIlIIl = new String(Base64.getDecoder().decode(llllllllllllllllllIlllIlIIlIlIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllIlllIlIIlIIlll = new StringBuilder();
    char[] llllllllllllllllllIlllIlIIlIIllI = llllllllllllllllllIlllIlIIlIlIII.toCharArray();
    int llllllllllllllllllIlllIlIIlIIlIl = llIlIllIlI[0];
    int llllllllllllllllllIlllIlIIIlllll = llllllllllllllllllIlllIlIIlIlIIl.toCharArray();
    byte llllllllllllllllllIlllIlIIIllllI = llllllllllllllllllIlllIlIIIlllll.length;
    String llllllllllllllllllIlllIlIIIlllIl = llIlIllIlI[0];
    while (lIlIllIIIIll(llllllllllllllllllIlllIlIIIlllIl, llllllllllllllllllIlllIlIIIllllI))
    {
      char llllllllllllllllllIlllIlIIlIlIlI = llllllllllllllllllIlllIlIIIlllll[llllllllllllllllllIlllIlIIIlllIl];
      "".length();
      "".length();
      if ((0xB0 ^ 0xB5) == 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllllIlllIlIIlIIlll);
  }
  
  private static int lIlIllIIlIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIlIlIllllll(int ???, int arg1)
  {
    int i;
    long llllllllllllllllllIlllIlIIIIlIll;
    return ??? == i;
  }
  
  private static String lIlIlIIllIII(String llllllllllllllllllIlllIlIIIlIlII, String llllllllllllllllllIlllIlIIIlIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIlllIlIIIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlllIlIIIlIIIl.getBytes(StandardCharsets.UTF_8)), llIlIllIlI[16]), "DES");
      Cipher llllllllllllllllllIlllIlIIIlIllI = Cipher.getInstance("DES");
      llllllllllllllllllIlllIlIIIlIllI.init(llIlIllIlI[2], llllllllllllllllllIlllIlIIIlIlll);
      return new String(llllllllllllllllllIlllIlIIIlIllI.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlllIlIIIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIlllIlIIIlIlIl)
    {
      llllllllllllllllllIlllIlIIIlIlIl.printStackTrace();
    }
    return null;
  }
  
  private void renderHotbarItem(int llllllllllllllllllIlllIllIIIlIII, int llllllllllllllllllIlllIllIIIIlll, int llllllllllllllllllIlllIllIIIllll, float llllllllllllllllllIlllIllIIIIlIl, EntityPlayer llllllllllllllllllIlllIllIIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ItemStack llllllllllllllllllIlllIllIIIllII = inventory.mainInventory[llllllllllllllllllIlllIllIIIlIII];
    if (lIlIlIllIllI(llllllllllllllllllIlllIllIIIllII))
    {
      float llllllllllllllllllIlllIllIIIlIll = animationsToGo - llllllllllllllllllIlllIllIIIIlIl;
      if (lIlIlIlllIII(lIlIllIIlIIl(llllllllllllllllllIlllIllIIIlIll, 0.0F)))
      {
        GlStateManager.pushMatrix();
        float llllllllllllllllllIlllIllIIIlIlI = 1.0F + llllllllllllllllllIlllIllIIIlIll / 5.0F;
        GlStateManager.translate(llllllllllllllllllIlllIllIIIIlll + llIlIllIlI[16], llllllllllllllllllIlllIllIIIllll + llIlIllIlI[32], 0.0F);
        GlStateManager.scale(1.0F / llllllllllllllllllIlllIllIIIlIlI, (llllllllllllllllllIlllIllIIIlIlI + 1.0F) / 2.0F, 1.0F);
        GlStateManager.translate(-(llllllllllllllllllIlllIllIIIIlll + llIlIllIlI[16]), -(llllllllllllllllllIlllIllIIIllll + llIlIllIlI[32]), 0.0F);
      }
      itemRenderer.renderItemAndEffectIntoGUI(llllllllllllllllllIlllIllIIIllII, llllllllllllllllllIlllIllIIIIlll, llllllllllllllllllIlllIllIIIllll);
      if (lIlIlIlllIII(lIlIllIIlIIl(llllllllllllllllllIlllIllIIIlIll, 0.0F))) {
        GlStateManager.popMatrix();
      }
      itemRenderer.renderItemOverlays(Minecraft.fontRendererObj, llllllllllllllllllIlllIllIIIllII, llllllllllllllllllIlllIllIIIIlll, llllllllllllllllllIlllIllIIIllll);
    }
  }
  
  public void setRecordPlaying(String llllllllllllllllllIlllIlIlllIIII, boolean llllllllllllllllllIlllIlIllIllll)
  {
    ;
    ;
    ;
    recordPlaying = llllllllllllllllllIlllIlIllIllIl;
    recordPlayingUpFor = llIlIllIlI[71];
    recordIsPlaying = llllllllllllllllllIlllIlIllIllll;
  }
  
  private static int lIlIllIIIllI(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public FontRenderer getFontRenderer()
  {
    return Minecraft.fontRendererObj;
  }
  
  public void renderDemo(ScaledResolution llllllllllllllllllIllllIllIIlIIl)
  {
    ;
    ;
    ;
    mc.mcProfiler.startSection(llIlIlIlIl[llIlIllIlI[15]]);
    String llllllllllllllllllIllllIllIIlIII = llIlIlIlIl[llIlIllIlI[44]];
    if (lIlIlIlllIll(lIlIlIlllllI(mc.theWorld.getTotalWorldTime(), 120500L)))
    {
      llllllllllllllllllIllllIllIIlIII = I18n.format(llIlIlIlIl[llIlIllIlI[45]], new Object[llIlIllIlI[0]]);
      "".length();
      if ((0x3E ^ 0x3A) != "  ".length()) {}
    }
    else
    {
      llllllllllllllllllIllllIllIIlIII = I18n.format(llIlIlIlIl[llIlIllIlI[46]], new Object[] { StringUtils.ticksToElapsedTime((int)(120500L - mc.theWorld.getTotalWorldTime())) });
    }
    int llllllllllllllllllIllllIllIIIlll = llllllllllllllllllIllllIllIIIllI.getFontRenderer().getStringWidth(llllllllllllllllllIllllIllIIlIII);
    "".length();
    mc.mcProfiler.endSection();
  }
  
  public void setRecordPlayingMessage(String llllllllllllllllllIlllIlIlllIlll)
  {
    ;
    ;
    llllllllllllllllllIlllIlIlllIllI.setRecordPlaying(I18n.format(llIlIlIlIl[llIlIllIlI[70]], new Object[] { llllllllllllllllllIlllIlIlllIlll }), llIlIllIlI[1]);
  }
  
  private static boolean lIlIllIIIIll(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllllIlllIlIIIIIIll;
    return ??? < i;
  }
  
  public void renderHorseJumpBar(ScaledResolution llllllllllllllllllIlllllIIIIlIlI, int llllllllllllllllllIlllllIIIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    mc.mcProfiler.startSection(llIlIlIlIl[llIlIllIlI[32]]);
    mc.getTextureManager().bindTexture(Gui.icons);
    float llllllllllllllllllIlllllIIIIlIII = mc.thePlayer.getHorseJumpPower();
    short llllllllllllllllllIlllllIIIIIlll = llIlIllIlI[30];
    int llllllllllllllllllIlllllIIIIIllI = (int)(llllllllllllllllllIlllllIIIIlIII * (llllllllllllllllllIlllllIIIIIlll + llIlIllIlI[1]));
    int llllllllllllllllllIlllllIIIIIlIl = llllllllllllllllllIlllllIIIIIIll.getScaledHeight() - llIlIllIlI[33] + llIlIllIlI[3];
    llllllllllllllllllIlllllIIIIIlII.drawTexturedModalRect(llllllllllllllllllIlllllIIIIIIlI, llllllllllllllllllIlllllIIIIIlIl, llIlIllIlI[0], llIlIllIlI[34], llllllllllllllllllIlllllIIIIIlll, llIlIllIlI[5]);
    if (lIlIlIlllIII(llllllllllllllllllIlllllIIIIIllI)) {
      llllllllllllllllllIlllllIIIIIlII.drawTexturedModalRect(llllllllllllllllllIlllllIIIIIIlI, llllllllllllllllllIlllllIIIIIlIl, llIlIllIlI[0], llIlIllIlI[35], llllllllllllllllllIlllllIIIIIllI, llIlIllIlI[5]);
    }
    mc.mcProfiler.endSection();
  }
  
  public GuiIngame(Minecraft llllllllllllllllllIlllllIllIIIII)
  {
    mc = llllllllllllllllllIlllllIllIIIII;
    itemRenderer = llllllllllllllllllIlllllIllIIIII.getRenderItem();
    overlayDebug = new GuiOverlayDebug(llllllllllllllllllIlllllIllIIIII);
    spectatorGui = new GuiSpectator(llllllllllllllllllIlllllIllIIIII);
    persistantChatGUI = new GuiNewChat(llllllllllllllllllIlllllIllIIIII);
    streamIndicator = new GuiStreamIndicator(llllllllllllllllllIlllllIllIIIII);
    overlayPlayerList = new GuiPlayerTabOverlay(llllllllllllllllllIlllllIllIIIII, llllllllllllllllllIlllllIlIlllll);
    llllllllllllllllllIlllllIlIlllll.func_175177_a();
  }
  
  private static int lIlIlIlllllI(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  public void renderGameOverlay(float llllllllllllllllllIlllllIIllIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ScaledResolution llllllllllllllllllIlllllIlIIllIl = new ScaledResolution(mc);
    int llllllllllllllllllIlllllIlIIllII = ScaledResolution.getScaledWidth();
    int llllllllllllllllllIlllllIlIIlIll = llllllllllllllllllIlllllIlIIllIl.getScaledHeight();
    mc.entityRenderer.setupOverlayRendering();
    GlStateManager.enableBlend();
    if (lIlIlIllIlII(Config.isVignetteEnabled()))
    {
      llllllllllllllllllIlllllIlIIllll.renderVignette(mc.thePlayer.getBrightness(llllllllllllllllllIlllllIIllIlll), llllllllllllllllllIlllllIlIIllIl);
      "".length();
      if (null == null) {}
    }
    else
    {
      GlStateManager.tryBlendFuncSeparate(llIlIllIlI[10], llIlIllIlI[11], llIlIllIlI[1], llIlIllIlI[0]);
    }
    ItemStack llllllllllllllllllIlllllIlIIlIlI = mc.thePlayer.inventory.armorItemInSlot(llIlIllIlI[3]);
    if ((lIlIlIllIlIl(mc.gameSettings.thirdPersonView)) && (lIlIlIllIllI(llllllllllllllllllIlllllIlIIlIlI)) && (lIlIlIllIlll(llllllllllllllllllIlllllIlIIlIlI.getItem(), Item.getItemFromBlock(Blocks.pumpkin)))) {
      llllllllllllllllllIlllllIlIIllll.renderPumpkinOverlay(llllllllllllllllllIlllllIlIIllIl);
    }
    if (lIlIlIllIlIl(mc.thePlayer.isPotionActive(Potion.confusion)))
    {
      float llllllllllllllllllIlllllIlIIlIIl = mc.thePlayer.prevTimeInPortal + (mc.thePlayer.timeInPortal - mc.thePlayer.prevTimeInPortal) * llllllllllllllllllIlllllIIllIlll;
      if (lIlIlIlllIII(lIlIlIllIIll(llllllllllllllllllIlllllIlIIlIIl, 0.0F))) {
        llllllllllllllllllIlllllIlIIllll.func_180474_b(llllllllllllllllllIlllllIlIIlIIl, llllllllllllllllllIlllllIlIIllIl);
      }
    }
    if (lIlIlIllIlII(mc.playerController.isSpectator()))
    {
      spectatorGui.renderTooltip(llllllllllllllllllIlllllIlIIllIl, llllllllllllllllllIlllllIIllIlll);
      "".length();
      if ((0x48 ^ 0x10 ^ 0xD8 ^ 0x84) != 0) {}
    }
    else
    {
      llllllllllllllllllIlllllIlIIllll.renderTooltip(llllllllllllllllllIlllllIlIIllIl, llllllllllllllllllIlllllIIllIlll);
    }
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(icons);
    GlStateManager.enableBlend();
    if (lIlIlIllIlII(llllllllllllllllllIlllllIlIIllll.showCrosshair()))
    {
      GlStateManager.tryBlendFuncSeparate(llIlIllIlI[12], llIlIllIlI[13], llIlIllIlI[1], llIlIllIlI[0]);
      GlStateManager.enableAlpha();
      llllllllllllllllllIlllllIlIIllll.drawTexturedModalRect(llllllllllllllllllIlllllIlIIllII / llIlIllIlI[2] - llIlIllIlI[14], llllllllllllllllllIlllllIlIIlIll / llIlIllIlI[2] - llIlIllIlI[14], llIlIllIlI[0], llIlIllIlI[0], llIlIllIlI[15], llIlIllIlI[15]);
    }
    GlStateManager.tryBlendFuncSeparate(llIlIllIlI[10], llIlIllIlI[11], llIlIllIlI[1], llIlIllIlI[0]);
    mc.mcProfiler.startSection(llIlIlIlIl[llIlIllIlI[14]]);
    llllllllllllllllllIlllllIlIIllll.renderBossHealth();
    mc.mcProfiler.endSection();
    if (lIlIlIllIlII(mc.playerController.shouldDrawHUD())) {
      llllllllllllllllllIlllllIlIIllll.renderPlayerStats(llllllllllllllllllIlllllIlIIllIl);
    }
    GlStateManager.disableBlend();
    if (lIlIlIlllIII(mc.thePlayer.getSleepTimer()))
    {
      mc.mcProfiler.startSection(llIlIlIlIl[llIlIllIlI[16]]);
      GlStateManager.disableDepth();
      GlStateManager.disableAlpha();
      int llllllllllllllllllIlllllIlIIlIII = mc.thePlayer.getSleepTimer();
      float llllllllllllllllllIlllllIlIIIlll = llllllllllllllllllIlllllIlIIlIII / 100.0F;
      if (lIlIlIlllIII(lIlIlIllIIll(llllllllllllllllllIlllllIlIIIlll, 1.0F))) {
        llllllllllllllllllIlllllIlIIIlll = 1.0F - (llllllllllllllllllIlllllIlIIlIII - llIlIllIlI[17]) / 10.0F;
      }
      int llllllllllllllllllIlllllIlIIIllI = (int)(220.0F * llllllllllllllllllIlllllIlIIIlll) << llIlIllIlI[18] | llIlIllIlI[19];
      drawRect(llIlIllIlI[0], llIlIllIlI[0], llllllllllllllllllIlllllIlIIllII, llllllllllllllllllIlllllIlIIlIll, llllllllllllllllllIlllllIlIIIllI);
      GlStateManager.enableAlpha();
      GlStateManager.enableDepth();
      mc.mcProfiler.endSection();
    }
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    int llllllllllllllllllIlllllIlIIIlIl = llllllllllllllllllIlllllIlIIllII / llIlIllIlI[2] - llIlIllIlI[20];
    if (lIlIlIllIlII(mc.thePlayer.isRidingHorse()))
    {
      llllllllllllllllllIlllllIlIIllll.renderHorseJumpBar(llllllllllllllllllIlllllIlIIllIl, llllllllllllllllllIlllllIlIIIlIl);
      "".length();
      if (((0x70 ^ 0x6D) & (0x5C ^ 0x41 ^ 0xFFFFFFFF)) == 0) {}
    }
    else if (lIlIlIllIlII(mc.playerController.gameIsSurvivalOrAdventure()))
    {
      llllllllllllllllllIlllllIlIIllll.renderExpBar(llllllllllllllllllIlllllIlIIllIl, llllllllllllllllllIlllllIlIIIlIl);
    }
    if ((lIlIlIllIlII(mc.gameSettings.heldItemTooltips)) && (lIlIlIllIlIl(mc.playerController.isSpectator())))
    {
      llllllllllllllllllIlllllIlIIllll.func_181551_a(llllllllllllllllllIlllllIlIIllIl);
      "".length();
      if ("   ".length() != 0) {}
    }
    else if (lIlIlIllIlII(mc.thePlayer.isSpectator()))
    {
      spectatorGui.func_175263_a(llllllllllllllllllIlllllIlIIllIl);
    }
    if (lIlIlIllIlII(mc.isDemo())) {
      llllllllllllllllllIlllllIlIIllll.renderDemo(llllllllllllllllllIlllllIlIIllIl);
    }
    if (lIlIlIllIlII(mc.gameSettings.showDebugInfo)) {
      overlayDebug.renderDebugInfo(llllllllllllllllllIlllllIlIIllIl);
    }
    if (lIlIlIlllIII(recordPlayingUpFor))
    {
      mc.mcProfiler.startSection(llIlIlIlIl[llIlIllIlI[21]]);
      float llllllllllllllllllIlllllIlIIIlII = recordPlayingUpFor - llllllllllllllllllIlllllIIllIlll;
      int llllllllllllllllllIlllllIlIIIIll = (int)(llllllllllllllllllIlllllIlIIIlII * 255.0F / 20.0F);
      if (lIlIlIlllIIl(llllllllllllllllllIlllllIlIIIIll, llIlIllIlI[22])) {
        llllllllllllllllllIlllllIlIIIIll = llIlIllIlI[22];
      }
      if (lIlIlIlllIIl(llllllllllllllllllIlllllIlIIIIll, llIlIllIlI[16]))
      {
        GlStateManager.pushMatrix();
        GlStateManager.translate(llllllllllllllllllIlllllIlIIllII / llIlIllIlI[2], llllllllllllllllllIlllllIlIIlIll - llIlIllIlI[23], 0.0F);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(llIlIllIlI[10], llIlIllIlI[11], llIlIllIlI[1], llIlIllIlI[0]);
        int llllllllllllllllllIlllllIlIIIIlI = llIlIllIlI[24];
        if (lIlIlIllIlII(recordIsPlaying)) {
          llllllllllllllllllIlllllIlIIIIlI = MathHelper.func_181758_c(llllllllllllllllllIlllllIlIIIlII / 50.0F, 0.7F, 0.6F) & llIlIllIlI[24];
        }
        "".length();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
      }
      mc.mcProfiler.endSection();
    }
    if (lIlIlIlllIII(field_175195_w))
    {
      mc.mcProfiler.startSection(llIlIlIlIl[llIlIllIlI[7]]);
      float llllllllllllllllllIlllllIlIIIIIl = field_175195_w - llllllllllllllllllIlllllIIllIlll;
      int llllllllllllllllllIlllllIlIIIIII = llIlIllIlI[22];
      if (lIlIlIlllIIl(field_175195_w, field_175193_B + field_175192_A))
      {
        float llllllllllllllllllIlllllIIllllll = field_175199_z + field_175192_A + field_175193_B - llllllllllllllllllIlllllIlIIIIIl;
        llllllllllllllllllIlllllIlIIIIII = (int)(llllllllllllllllllIlllllIIllllll * 255.0F / field_175199_z);
      }
      if (lIlIlIlllIlI(field_175195_w, field_175193_B)) {
        llllllllllllllllllIlllllIlIIIIII = (int)(llllllllllllllllllIlllllIlIIIIIl * 255.0F / field_175193_B);
      }
      llllllllllllllllllIlllllIlIIIIII = MathHelper.clamp_int(llllllllllllllllllIlllllIlIIIIII, llIlIllIlI[0], llIlIllIlI[22]);
      if (lIlIlIlllIIl(llllllllllllllllllIlllllIlIIIIII, llIlIllIlI[16]))
      {
        GlStateManager.pushMatrix();
        GlStateManager.translate(llllllllllllllllllIlllllIlIIllII / llIlIllIlI[2], llllllllllllllllllIlllllIlIIlIll / llIlIllIlI[2], 0.0F);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(llIlIllIlI[10], llIlIllIlI[11], llIlIllIlI[1], llIlIllIlI[0]);
        GlStateManager.pushMatrix();
        GlStateManager.scale(4.0F, 4.0F, 4.0F);
        int llllllllllllllllllIlllllIIlllllI = llllllllllllllllllIlllllIlIIIIII << llIlIllIlI[18] & llIlIllIlI[26];
        "".length();
        GlStateManager.popMatrix();
        GlStateManager.pushMatrix();
        GlStateManager.scale(2.0F, 2.0F, 2.0F);
        "".length();
        GlStateManager.popMatrix();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
      }
      mc.mcProfiler.endSection();
    }
    Scoreboard llllllllllllllllllIlllllIIllllIl = mc.theWorld.getScoreboard();
    ScoreObjective llllllllllllllllllIlllllIIllllII = null;
    ScorePlayerTeam llllllllllllllllllIlllllIIlllIll = llllllllllllllllllIlllllIIllllIl.getPlayersTeam(mc.thePlayer.getName());
    if (lIlIlIllIllI(llllllllllllllllllIlllllIIlllIll))
    {
      int llllllllllllllllllIlllllIIlllIlI = llllllllllllllllllIlllllIIlllIll.getChatFormat().getColorIndex();
      if (lIlIlIlllIll(llllllllllllllllllIlllllIIlllIlI)) {
        llllllllllllllllllIlllllIIllllII = llllllllllllllllllIlllllIIllllIl.getObjectiveInDisplaySlot(llIlIllIlI[3] + llllllllllllllllllIlllllIIlllIlI);
      }
    }
    if (lIlIlIllIllI(llllllllllllllllllIlllllIIllllII))
    {
      "".length();
      if (((20 + 45 - -91 + 53 ^ 37 + 20 - 28 + 148) & (0x39 ^ 0x51 ^ 0x4B ^ 0x43 ^ -" ".length())) >= -" ".length()) {
        break label1644;
      }
    }
    label1644:
    ScoreObjective llllllllllllllllllIlllllIIlllIIl = llllllllllllllllllIlllllIIllllIl.getObjectiveInDisplaySlot(llIlIllIlI[1]);
    if (lIlIlIllIllI(llllllllllllllllllIlllllIIlllIIl)) {
      llllllllllllllllllIlllllIlIIllll.renderScoreboard(llllllllllllllllllIlllllIIlllIIl, llllllllllllllllllIlllllIlIIllIl);
    }
    GlStateManager.enableBlend();
    GlStateManager.tryBlendFuncSeparate(llIlIllIlI[10], llIlIllIlI[11], llIlIllIlI[1], llIlIllIlI[0]);
    GlStateManager.disableAlpha();
    GlStateManager.pushMatrix();
    GlStateManager.translate(0.0F, llllllllllllllllllIlllllIlIIlIll - llIlIllIlI[27], 0.0F);
    mc.mcProfiler.startSection(llIlIlIlIl[llIlIllIlI[28]]);
    persistantChatGUI.drawChat(updateCounter);
    mc.mcProfiler.endSection();
    GlStateManager.popMatrix();
    llllllllllllllllllIlllllIIlllIIl = llllllllllllllllllIlllllIIllllIl.getObjectiveInDisplaySlot(llIlIllIlI[0]);
    if ((!lIlIlIllIlII(mc.gameSettings.keyBindPlayerList.isKeyDown())) || ((lIlIlIllIlII(mc.isIntegratedServerRunning())) && (lIlIlIlllIlI(mc.thePlayer.sendQueue.getPlayerInfoMap().size(), llIlIllIlI[1])) && (lIlIlIllllII(llllllllllllllllllIlllllIIlllIIl))))
    {
      overlayPlayerList.updatePlayerList(llIlIllIlI[0]);
      "".length();
      if (null == null) {}
    }
    else
    {
      overlayPlayerList.updatePlayerList(llIlIllIlI[1]);
      overlayPlayerList.renderPlayerlist(llllllllllllllllllIlllllIlIIllII, llllllllllllllllllIlllllIIllllIl, llllllllllllllllllIlllllIIlllIIl);
    }
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.disableLighting();
    GlStateManager.enableAlpha();
  }
  
  private void renderPumpkinOverlay(ScaledResolution llllllllllllllllllIlllIlllIllIll)
  {
    ;
    ;
    ;
    ;
    GlStateManager.disableDepth();
    GlStateManager.depthMask(llIlIllIlI[0]);
    GlStateManager.tryBlendFuncSeparate(llIlIllIlI[10], llIlIllIlI[11], llIlIllIlI[1], llIlIllIlI[0]);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.disableAlpha();
    mc.getTextureManager().bindTexture(pumpkinBlurTexPath);
    Tessellator llllllllllllllllllIlllIlllIllIlI = Tessellator.getInstance();
    WorldRenderer llllllllllllllllllIlllIlllIllIIl = llllllllllllllllllIlllIlllIllIlI.getWorldRenderer();
    llllllllllllllllllIlllIlllIllIIl.begin(llIlIllIlI[14], DefaultVertexFormats.POSITION_TEX);
    llllllllllllllllllIlllIlllIllIIl.pos(0.0D, llllllllllllllllllIlllIlllIllIll.getScaledHeight(), -90.0D).tex(0.0D, 1.0D).endVertex();
    llllllllllllllllllIlllIlllIllIIl.pos(ScaledResolution.getScaledWidth(), llllllllllllllllllIlllIlllIllIll.getScaledHeight(), -90.0D).tex(1.0D, 1.0D).endVertex();
    llllllllllllllllllIlllIlllIllIIl.pos(ScaledResolution.getScaledWidth(), 0.0D, -90.0D).tex(1.0D, 0.0D).endVertex();
    llllllllllllllllllIlllIlllIllIIl.pos(0.0D, 0.0D, -90.0D).tex(0.0D, 0.0D).endVertex();
    llllllllllllllllllIlllIlllIllIlI.draw();
    GlStateManager.depthMask(llIlIllIlI[1]);
    GlStateManager.enableDepth();
    GlStateManager.enableAlpha();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
  }
  
  public GuiNewChat getChatGUI()
  {
    ;
    return persistantChatGUI;
  }
  
  private static int lIlIllIIIIII(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  public void renderExpBar(ScaledResolution llllllllllllllllllIllllIllllIIll, int llllllllllllllllllIllllIllllIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    mc.mcProfiler.startSection(llIlIlIlIl[llIlIllIlI[36]]);
    mc.getTextureManager().bindTexture(Gui.icons);
    int llllllllllllllllllIllllIllllIIIl = mc.thePlayer.xpBarCap();
    if (lIlIlIlllIII(llllllllllllllllllIllllIllllIIIl))
    {
      short llllllllllllllllllIllllIllllIIII = llIlIllIlI[30];
      int llllllllllllllllllIllllIlllIllll = (int)(mc.thePlayer.experience * (llllllllllllllllllIllllIllllIIII + llIlIllIlI[1]));
      int llllllllllllllllllIllllIlllIlllI = llllllllllllllllllIllllIlllIIlll.getScaledHeight() - llIlIllIlI[33] + llIlIllIlI[3];
      llllllllllllllllllIllllIlllIlIII.drawTexturedModalRect(llllllllllllllllllIllllIllllIIlI, llllllllllllllllllIllllIlllIlllI, llIlIllIlI[0], llIlIllIlI[37], llllllllllllllllllIllllIllllIIII, llIlIllIlI[5]);
      if (lIlIlIlllIII(llllllllllllllllllIllllIlllIllll)) {
        llllllllllllllllllIllllIlllIlIII.drawTexturedModalRect(llllllllllllllllllIllllIllllIIlI, llllllllllllllllllIllllIlllIlllI, llIlIllIlI[0], llIlIllIlI[38], llllllllllllllllllIllllIlllIllll, llIlIllIlI[5]);
      }
    }
    mc.mcProfiler.endSection();
    if (lIlIlIlllIII(mc.thePlayer.experienceLevel))
    {
      mc.mcProfiler.startSection(llIlIlIlIl[llIlIllIlI[39]]);
      int llllllllllllllllllIllllIlllIllIl = llIlIllIlI[40];
      String llllllllllllllllllIllllIlllIllII = String.valueOf(new StringBuilder().append(mc.thePlayer.experienceLevel));
      int llllllllllllllllllIllllIlllIlIll = (ScaledResolution.getScaledWidth() - llllllllllllllllllIllllIlllIlIII.getFontRenderer().getStringWidth(llllllllllllllllllIllllIlllIllII)) / llIlIllIlI[2];
      int llllllllllllllllllIllllIlllIlIlI = llllllllllllllllllIllllIlllIIlll.getScaledHeight() - llIlIllIlI[41] - llIlIllIlI[4];
      boolean llllllllllllllllllIllllIlllIlIIl = llIlIllIlI[0];
      "".length();
      "".length();
      "".length();
      "".length();
      "".length();
      mc.mcProfiler.endSection();
    }
  }
  
  public int getUpdateCounter()
  {
    ;
    return updateCounter;
  }
  
  private static int lIlIlIllIIll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public GuiSpectator getSpectatorGui()
  {
    ;
    return spectatorGui;
  }
  
  private static void lIlIlIlIIIIl()
  {
    llIlIlIlIl = new String[llIlIllIlI[41]];
    llIlIlIlIl[llIlIllIlI[0]] = lIlIlIIlIllI("Lteq0XWgsVB3R2CfiMGclA==", "zqkxI");
    llIlIlIlIl[llIlIllIlI[1]] = lIlIlIIlIlll("HRIQAzsbEhtYIwAEC1g4ABAGEjodEkYHIA4=", "iwhwN");
    llIlIlIlIl[llIlIllIlI[2]] = lIlIlIIlIlll("HSYxJxMbJjp8ARwqZiQPDSQsJxVHMyc0", "iCISf");
    llIlIlIlIl[llIlIllIlI[3]] = lIlIlIIlIllI("aHwlGmijy5sR2D3ql50I4s/37nO00gSsp1lLQVQIV+o=", "ASPro");
    llIlIlIlIl[llIlIllIlI[4]] = lIlIlIIlIllI("htw4cToLj7g=", "lziCY");
    llIlIlIlIl[llIlIllIlI[5]] = lIlIlIIlIllI("Apv3sWHDOtY=", "BnkHG");
    llIlIlIlIl[llIlIllIlI[6]] = lIlIlIIlIlll("", "YVghh");
    llIlIlIlIl[llIlIllIlI[14]] = lIlIlIIlIllI("ZvySOY+iQlOALX/cWOfRPQ==", "tQbHd");
    llIlIlIlIl[llIlIllIlI[16]] = lIlIlIIllIII("+lYpAx2Xyac=", "dhfRJ");
    llIlIlIlIl[llIlIllIlI[21]] = lIlIlIIllIII("hZl0f9784Bi8TaCOrPfbyA==", "fHWhV");
    llIlIlIlIl[llIlIllIlI[7]] = lIlIlIIllIII("jTfRwQq8B9TL2JfokvqlmTadRR4E4yfm", "djUEs");
    llIlIlIlIl[llIlIllIlI[28]] = lIlIlIIlIlll("EysPLQ==", "pCnYq");
    llIlIlIlIl[llIlIllIlI[32]] = lIlIlIIlIlll("PDE6ESA3Ng==", "VDWab");
    llIlIlIlIl[llIlIllIlI[36]] = lIlIlIIlIlll("MwglJxEk", "VpUep");
    llIlIlIlIl[llIlIllIlI[39]] = lIlIlIIlIlll("IB8+CDIzAiI=", "EgNDW");
    llIlIlIlIl[llIlIllIlI[42]] = lIlIlIIllIII("/DV7clNtN3xGE7eguQ6gvzXK/TCX2C31", "PlCUI");
    llIlIlIlIl[llIlIllIlI[15]] = lIlIlIIllIII("HF304a6rBXY=", "FoxLy");
    llIlIlIlIl[llIlIllIlI[44]] = lIlIlIIllIII("/zSXh44B3gI=", "dTomd");
    llIlIlIlIl[llIlIllIlI[45]] = lIlIlIIlIlll("HScXC3YdJxcLHQEyExY9HQ==", "yBzdX");
    llIlIlIlIl[llIlIllIlI[46]] = lIlIlIIlIlll("BQEEK1oTAQQlHQ8NByMgCAkM", "adiDt");
    llIlIlIlIl[llIlIllIlI[9]] = lIlIlIIlIlll("Xlg=", "dxWFC");
    llIlIlIlIl[llIlIllIlI[53]] = lIlIlIIlIlll("EAAgFRE=", "qrMzc");
    llIlIlIlIl[llIlIllIlI[29]] = lIlIlIIllIII("hEg7FQtyJ4c=", "CKlzh");
    llIlIlIlIl[llIlIllIlI[62]] = lIlIlIIlIllI("ROM78avvbWg=", "WTpAk");
    llIlIlIlIl[llIlIllIlI[18]] = lIlIlIIlIlll("Dh0gIBUrFzQiFQs=", "crUNa");
    llIlIlIlIl[llIlIllIlI[55]] = lIlIlIIllIII("DdUyXbR+XiU=", "XLaNM");
    llIlIlIlIl[llIlIllIlI[68]] = lIlIlIIlIllI("3KyU9QLPXEo=", "GUGiv");
    llIlIlIlIl[llIlIllIlI[63]] = lIlIlIIllIII("A8yb2lsBEqM=", "xeQaw");
    llIlIlIlIl[llIlIllIlI[70]] = lIlIlIIlIlll("Ig4UPxg0RRk/HQAHFikDPgw=", "PkwPj");
    llIlIlIlIl[llIlIllIlI[72]] = lIlIlIIlIllI("cuNCoEFH/Ww=", "IwOkY");
    llIlIlIlIl[llIlIllIlI[64]] = lIlIlIIlIlll("", "KRYhl");
  }
  
  public void func_181551_a(ScaledResolution llllllllllllllllllIllllIllIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    mc.mcProfiler.startSection(llIlIlIlIl[llIlIllIlI[42]]);
    if ((lIlIlIlllIII(remainingHighlightTicks)) && (lIlIlIllIllI(highlightingItemStack)))
    {
      String llllllllllllllllllIllllIllIlIlll = highlightingItemStack.getDisplayName();
      if (lIlIlIllIlII(highlightingItemStack.hasDisplayName())) {
        llllllllllllllllllIllllIllIlIlll = String.valueOf(new StringBuilder().append(EnumChatFormatting.ITALIC).append(llllllllllllllllllIllllIllIlIlll));
      }
      int llllllllllllllllllIllllIllIlIllI = (ScaledResolution.getScaledWidth() - llllllllllllllllllIllllIllIlIIll.getFontRenderer().getStringWidth(llllllllllllllllllIllllIllIlIlll)) / llIlIllIlI[2];
      int llllllllllllllllllIllllIllIlIlIl = llllllllllllllllllIllllIllIllIII.getScaledHeight() - llIlIllIlI[43];
      if (lIlIlIllIlIl(mc.playerController.shouldDrawHUD())) {
        llllllllllllllllllIllllIllIlIlIl += 14;
      }
      int llllllllllllllllllIllllIllIlIlII = (int)(remainingHighlightTicks * 256.0F / 10.0F);
      if (lIlIlIlllIIl(llllllllllllllllllIllllIllIlIlII, llIlIllIlI[22])) {
        llllllllllllllllllIllllIllIlIlII = llIlIllIlI[22];
      }
      if (lIlIlIlllIII(llllllllllllllllllIllllIllIlIlII))
      {
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(llIlIllIlI[10], llIlIllIlI[11], llIlIllIlI[1], llIlIllIlI[0]);
        "".length();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
      }
    }
    mc.mcProfiler.endSection();
  }
  
  private static int lIlIllIIIlll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private void func_180474_b(float llllllllllllllllllIlllIllIlIlllI, ScaledResolution llllllllllllllllllIlllIllIlIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIllIIIlIl(lIlIllIIlIII(llllllllllllllllllIlllIllIlIlllI, 1.0F)))
    {
      llllllllllllllllllIlllIllIlIIlII *= llllllllllllllllllIlllIllIlIIlII;
      llllllllllllllllllIlllIllIlIIlII *= llllllllllllllllllIlllIllIlIIlII;
      llllllllllllllllllIlllIllIlIIlII = llllllllllllllllllIlllIllIlIIlII * 0.8F + 0.2F;
    }
    GlStateManager.disableAlpha();
    GlStateManager.disableDepth();
    GlStateManager.depthMask(llIlIllIlI[0]);
    GlStateManager.tryBlendFuncSeparate(llIlIllIlI[10], llIlIllIlI[11], llIlIllIlI[1], llIlIllIlI[0]);
    GlStateManager.color(1.0F, 1.0F, 1.0F, llllllllllllllllllIlllIllIlIIlII);
    mc.getTextureManager().bindTexture(TextureMap.locationBlocksTexture);
    TextureAtlasSprite llllllllllllllllllIlllIllIlIllII = mc.getBlockRendererDispatcher().getBlockModelShapes().getTexture(Blocks.portal.getDefaultState());
    float llllllllllllllllllIlllIllIlIlIll = llllllllllllllllllIlllIllIlIllII.getMinU();
    float llllllllllllllllllIlllIllIlIlIlI = llllllllllllllllllIlllIllIlIllII.getMinV();
    float llllllllllllllllllIlllIllIlIlIIl = llllllllllllllllllIlllIllIlIllII.getMaxU();
    float llllllllllllllllllIlllIllIlIlIII = llllllllllllllllllIlllIllIlIllII.getMaxV();
    Tessellator llllllllllllllllllIlllIllIlIIlll = Tessellator.getInstance();
    WorldRenderer llllllllllllllllllIlllIllIlIIllI = llllllllllllllllllIlllIllIlIIlll.getWorldRenderer();
    llllllllllllllllllIlllIllIlIIllI.begin(llIlIllIlI[14], DefaultVertexFormats.POSITION_TEX);
    llllllllllllllllllIlllIllIlIIllI.pos(0.0D, llllllllllllllllllIlllIllIlIllIl.getScaledHeight(), -90.0D).tex(llllllllllllllllllIlllIllIlIlIll, llllllllllllllllllIlllIllIlIlIII).endVertex();
    llllllllllllllllllIlllIllIlIIllI.pos(ScaledResolution.getScaledWidth(), llllllllllllllllllIlllIllIlIllIl.getScaledHeight(), -90.0D).tex(llllllllllllllllllIlllIllIlIlIIl, llllllllllllllllllIlllIllIlIlIII).endVertex();
    llllllllllllllllllIlllIllIlIIllI.pos(ScaledResolution.getScaledWidth(), 0.0D, -90.0D).tex(llllllllllllllllllIlllIllIlIlIIl, llllllllllllllllllIlllIllIlIlIlI).endVertex();
    llllllllllllllllllIlllIllIlIIllI.pos(0.0D, 0.0D, -90.0D).tex(llllllllllllllllllIlllIllIlIlIll, llllllllllllllllllIlllIllIlIlIlI).endVertex();
    llllllllllllllllllIlllIllIlIIlll.draw();
    GlStateManager.depthMask(llIlIllIlI[1]);
    GlStateManager.enableDepth();
    GlStateManager.enableAlpha();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
  }
  
  private static boolean lIlIlIllllII(Object ???)
  {
    char llllllllllllllllllIlllIIllllIIll;
    return ??? == null;
  }
  
  private static void lIlIlIllIIlI()
  {
    llIlIllIlI = new int[73];
    llIlIllIlI[0] = ((0xAA ^ 0xB0) & (0x37 ^ 0x2D ^ 0xFFFFFFFF));
    llIlIllIlI[1] = " ".length();
    llIlIllIlI[2] = "  ".length();
    llIlIllIlI[3] = "   ".length();
    llIlIllIlI[4] = (0x4F ^ 0x4B);
    llIlIllIlI[5] = (72 + 32 - 28 + 104 ^ 91 + '¯' - 245 + 156);
    llIlIllIlI[6] = (0x1E ^ 0x18);
    llIlIllIlI[7] = (0xEA ^ 0xBD ^ 0xF1 ^ 0xAC);
    llIlIllIlI[8] = ((0x5E ^ 0x6D) & (0xBE ^ 0x8D ^ 0xFFFFFFFF) ^ 0xC0 ^ 0x86);
    llIlIllIlI[9] = (0x8F ^ 0x9B);
    llIlIllIlI[10] = (0x8B56 & 0x77AB);
    llIlIllIlI[11] = (0xDB7F & 0x2783);
    llIlIllIlI[12] = (-(0xEBF9 & 0x3CCF) & 0xEFFF & 0x3BCF);
    llIlIllIlI[13] = (0x9FD1 & 0x632F);
    llIlIllIlI[14] = (7 + 117 - 118 + 152 ^ '' + 25 - 60 + 58);
    llIlIllIlI[15] = (0x2F ^ 0x3F);
    llIlIllIlI[16] = (0x5F ^ 0x57);
    llIlIllIlI[17] = (0x72 ^ 0x5A ^ 0xCE ^ 0x82);
    llIlIllIlI[18] = (0x65 ^ 0x6D ^ 0x5E ^ 0x4E);
    llIlIllIlI[19] = (0xD0F9 & 0x103F26);
    llIlIllIlI[20] = (0x1E ^ 0x45);
    llIlIllIlI[21] = (0x72 ^ 0x7B);
    llIlIllIlI[22] = ('Ö' + 95 - 217 + 163);
    llIlIllIlI[23] = (0xF5 ^ 0xB1);
    llIlIllIlI[24] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    llIlIllIlI[25] = (-(0xBB ^ 0x90 ^ 0x3E ^ 0x11));
    llIlIllIlI[26] = (-(-(0xB6E4 & 0x7F3F) & 0xB767 & 0x1007EBB));
    llIlIllIlI[27] = (0x73 ^ 0x33 ^ 0x1D ^ 0x6D);
    llIlIllIlI[28] = (0x36 ^ 0x1F ^ 0x97 ^ 0xB5);
    llIlIllIlI[29] = (0x9 ^ 0x1F);
    llIlIllIlI[30] = (96 + 73 - 159 + 172);
    llIlIllIlI[31] = (0x36 ^ 0x51 ^ 0xA8 ^ 0x95);
    llIlIllIlI[32] = (0x96 ^ 0x8F ^ 0x4A ^ 0x5F);
    llIlIllIlI[33] = (0xA ^ 0x2A);
    llIlIllIlI[34] = (0x76 ^ 0x1E ^ 0x5C ^ 0x60);
    llIlIllIlI[35] = (0x2E ^ 0xF ^ 0xEC ^ 0x94);
    llIlIllIlI[36] = (0x35 ^ 0x38);
    llIlIllIlI[37] = (0x39 ^ 0x79);
    llIlIllIlI[38] = (0x17 ^ 0x52);
    llIlIllIlI[39] = (0x5F ^ 0x51);
    llIlIllIlI[40] = (-"   ".length() & 0xFF26 & 0x80FFFB);
    llIlIllIlI[41] = (0x29 ^ 0x36);
    llIlIllIlI[42] = (0x7E ^ 0x3D ^ 0x35 ^ 0x79);
    llIlIllIlI[43] = (0x34 ^ 0x52 ^ 0x42 ^ 0x1F);
    llIlIllIlI[44] = (19 + 83 - 44 + 119 ^ 37 + 98 - 54 + 79);
    llIlIllIlI[45] = (42 + 77 - -24 + 43 ^ 114 + 8 - -38 + 8);
    llIlIllIlI[46] = (0xD0 ^ 0xC3);
    llIlIllIlI[47] = (0x83F8 & 0x50007C07);
    llIlIllIlI[48] = (0xFFFFFFFF & 0x20FFFFFF);
    llIlIllIlI[49] = (-(0xDDFF & 0x277B) & 0xCDFA & 0x6000377F);
    llIlIllIlI[50] = (0xC7FF & 0x4FE27);
    llIlIllIlI[51] = (63 + 16 - 18 + 76 ^ 102 + 18 - -39 + 15);
    llIlIllIlI[52] = (-" ".length());
    llIlIllIlI[53] = (0x21 ^ 0x57 ^ 0x6C ^ 0xF);
    llIlIllIlI[54] = (0x5D ^ 0x7F);
    llIlIllIlI[55] = (0xB3 ^ 0xAA);
    llIlIllIlI[56] = (0x29 ^ 0x1F);
    llIlIllIlI[57] = (0xA8 ^ 0x97);
    llIlIllIlI[58] = (0xA5 ^ 0x96 ^ 0x8D ^ 0x9A);
    llIlIllIlI[59] = (0xAE ^ 0x83);
    llIlIllIlI[60] = (25 + 35 - 25 + 118);
    llIlIllIlI[61] = (98 + 10 - 84 + 107 + (0xF7 ^ 0x85) - ('¶' + 3 - 149 + 154) + (0x57 ^ 0xE));
    llIlIllIlI[62] = (0x11 ^ 0x6);
    llIlIllIlI[63] = (0xB5 ^ 0xAE);
    llIlIllIlI[64] = (0x52 ^ 0x4C);
    llIlIllIlI[65] = (20 + 65 - 51 + 124 ^ 2 + 105 - 102 + 165);
    llIlIllIlI[66] = (0x27 ^ 0x6D);
    llIlIllIlI[67] = (0xFF ^ 0xB0);
    llIlIllIlI[68] = (0x8E ^ 0x94);
    llIlIllIlI[69] = (47 + 67 - -9 + 9 ^ '' + 73 - 74 + 44);
    llIlIllIlI[70] = (46 + 10 - 23 + 109 ^ 122 + 50 - 114 + 88);
    llIlIllIlI[71] = (27 + 42 - -32 + 78 ^ 50 + 68 - 51 + 76);
    llIlIllIlI[72] = (0x4 ^ 0x19);
  }
  
  private static boolean lIlIlIllIllI(Object ???)
  {
    Exception llllllllllllllllllIlllIIlllllIIl;
    return ??? != null;
  }
  
  private static int lIlIllIIlIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void setRecordPlaying(IChatComponent llllllllllllllllllIlllIlIlIlIlIl, boolean llllllllllllllllllIlllIlIlIlIIIl)
  {
    ;
    ;
    ;
    llllllllllllllllllIlllIlIlIlIllI.setRecordPlaying(llllllllllllllllllIlllIlIlIlIIlI.getUnformattedText(), llllllllllllllllllIlllIlIlIlIIIl);
  }
  
  private static boolean lIlIlIllIlIl(int ???)
  {
    short llllllllllllllllllIlllIIlllIllll;
    return ??? == 0;
  }
  
  private static boolean lIlIlIlllIII(int ???)
  {
    String llllllllllllllllllIlllIIlllIIlll;
    return ??? > 0;
  }
  
  public void displayTitle(String llllllllllllllllllIlllIlIllIIlII, String llllllllllllllllllIlllIlIlIlllIl, int llllllllllllllllllIlllIlIllIIIlI, int llllllllllllllllllIlllIlIlIllIll, int llllllllllllllllllIlllIlIllIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIlIlIllllII(llllllllllllllllllIlllIlIllIIlII)) && (lIlIlIllllII(llllllllllllllllllIlllIlIlIlllIl)) && (lIlIllIIIlIl(llllllllllllllllllIlllIlIllIIIlI)) && (lIlIllIIIlIl(llllllllllllllllllIlllIlIlIllIll)) && (lIlIllIIIlIl(llllllllllllllllllIlllIlIllIIIII)))
    {
      field_175201_x = llIlIlIlIl[llIlIllIlI[72]];
      field_175200_y = llIlIlIlIl[llIlIllIlI[64]];
      field_175195_w = llIlIllIlI[0];
      "".length();
      if (((0x3B ^ 0x6A) & (0x1F ^ 0x4E ^ 0xFFFFFFFF)) == 0) {}
    }
    else if (lIlIlIllIllI(llllllllllllllllllIlllIlIllIIlII))
    {
      field_175201_x = llllllllllllllllllIlllIlIllIIlII;
      field_175195_w = (field_175199_z + field_175192_A + field_175193_B);
      "".length();
      if (null == null) {}
    }
    else if (lIlIlIllIllI(llllllllllllllllllIlllIlIlIlllIl))
    {
      field_175200_y = llllllllllllllllllIlllIlIlIlllIl;
      "".length();
      if (null == null) {}
    }
    else
    {
      if (lIlIlIlllIll(llllllllllllllllllIlllIlIllIIIlI)) {
        field_175199_z = llllllllllllllllllIlllIlIllIIIlI;
      }
      if (lIlIlIlllIll(llllllllllllllllllIlllIlIlIllIll)) {
        field_175192_A = llllllllllllllllllIlllIlIlIllIll;
      }
      if (lIlIlIlllIll(llllllllllllllllllIlllIlIllIIIII)) {
        field_175193_B = llllllllllllllllllIlllIlIllIIIII;
      }
      if (lIlIlIlllIII(field_175195_w)) {
        field_175195_w = (field_175199_z + field_175192_A + field_175193_B);
      }
    }
  }
  
  private static boolean lIlIllIIIlII(int ???)
  {
    long llllllllllllllllllIlllIIlllIlIIl;
    return ??? <= 0;
  }
  
  private static boolean lIlIlIllIlII(int ???)
  {
    boolean llllllllllllllllllIlllIIllllIIIl;
    return ??? != 0;
  }
  
  public void renderStreamIndicator(ScaledResolution llllllllllllllllllIllllIlIlllIll)
  {
    ;
    streamIndicator.render(ScaledResolution.getScaledWidth() - llIlIllIlI[7], llIlIllIlI[7]);
  }
  
  protected boolean showCrosshair()
  {
    ;
    ;
    if ((lIlIlIllIlII(mc.gameSettings.showDebugInfo)) && (lIlIlIllIlIl(mc.thePlayer.hasReducedDebug())) && (lIlIlIllIlIl(mc.gameSettings.reducedDebugInfo))) {
      return llIlIllIlI[0];
    }
    if (lIlIlIllIlII(mc.playerController.isSpectator()))
    {
      if (lIlIlIllIllI(mc.pointedEntity)) {
        return llIlIllIlI[1];
      }
      if ((lIlIlIllIllI(mc.objectMouseOver)) && (lIlIlIllIlll(mc.objectMouseOver.typeOfHit, MovingObjectPosition.MovingObjectType.BLOCK)))
      {
        BlockPos llllllllllllllllllIllllIllIIIIII = mc.objectMouseOver.getBlockPos();
        if (lIlIlIllIlII(mc.theWorld.getTileEntity(llllllllllllllllllIllllIllIIIIII) instanceof IInventory)) {
          return llIlIllIlI[1];
        }
      }
      return llIlIllIlI[0];
    }
    return llIlIllIlI[1];
  }
  
  private static boolean lIlIlIlllIll(int ???)
  {
    int llllllllllllllllllIlllIIlllIllIl;
    return ??? >= 0;
  }
  
  protected void renderTooltip(ScaledResolution llllllllllllllllllIlllllIIlIIIll, float llllllllllllllllllIlllllIIIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIlIllIlII(mc.getRenderViewEntity() instanceof EntityPlayer))
    {
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      mc.getTextureManager().bindTexture(widgetsTexPath);
      EntityPlayer llllllllllllllllllIlllllIIlIIIIl = (EntityPlayer)mc.getRenderViewEntity();
      int llllllllllllllllllIlllllIIlIIIII = ScaledResolution.getScaledWidth() / llIlIllIlI[2];
      float llllllllllllllllllIlllllIIIlllll = zLevel;
      zLevel = -90.0F;
      llllllllllllllllllIlllllIIIllIll.drawTexturedModalRect(llllllllllllllllllIlllllIIlIIIII - llIlIllIlI[20], llllllllllllllllllIlllllIIIllIlI.getScaledHeight() - llIlIllIlI[29], llIlIllIlI[0], llIlIllIlI[0], llIlIllIlI[30], llIlIllIlI[29]);
      llllllllllllllllllIlllllIIIllIll.drawTexturedModalRect(llllllllllllllllllIlllllIIlIIIII - llIlIllIlI[20] - llIlIllIlI[1] + inventory.currentItem * llIlIllIlI[9], llllllllllllllllllIlllllIIIllIlI.getScaledHeight() - llIlIllIlI[29] - llIlIllIlI[1], llIlIllIlI[0], llIlIllIlI[29], llIlIllIlI[18], llIlIllIlI[29]);
      zLevel = llllllllllllllllllIlllllIIIlllll;
      GlStateManager.enableRescaleNormal();
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(llIlIllIlI[10], llIlIllIlI[11], llIlIllIlI[1], llIlIllIlI[0]);
      RenderHelper.enableGUIStandardItemLighting();
      int llllllllllllllllllIlllllIIIllllI = llIlIllIlI[0];
      "".length();
      if ((0xBA ^ 0xBE) < "   ".length()) {
        return;
      }
      while (!lIlIlIllllIl(llllllllllllllllllIlllllIIIllllI, llIlIllIlI[21]))
      {
        int llllllllllllllllllIlllllIIIlllIl = ScaledResolution.getScaledWidth() / llIlIllIlI[2] - llIlIllIlI[31] + llllllllllllllllllIlllllIIIllllI * llIlIllIlI[9] + llIlIllIlI[2];
        int llllllllllllllllllIlllllIIIlllII = llllllllllllllllllIlllllIIIllIlI.getScaledHeight() - llIlIllIlI[15] - llIlIllIlI[3];
        llllllllllllllllllIlllllIIIllIll.renderHotbarItem(llllllllllllllllllIlllllIIIllllI, llllllllllllllllllIlllllIIIlllIl, llllllllllllllllllIlllllIIIlllII, llllllllllllllllllIlllllIIIllIIl, llllllllllllllllllIlllllIIlIIIIl);
        llllllllllllllllllIlllllIIIllllI++;
      }
      RenderHelper.disableStandardItemLighting();
      GlStateManager.disableRescaleNormal();
      GlStateManager.disableBlend();
    }
  }
  
  private static boolean lIlIllIIIlIl(int ???)
  {
    double llllllllllllllllllIlllIIlllIlIll;
    return ??? < 0;
  }
  
  private void renderVignette(float llllllllllllllllllIlllIlllIIlIlI, ScaledResolution llllllllllllllllllIlllIlllIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIlIllIlII(Config.isVignetteEnabled()))
    {
      llllllllllllllllllIlllIlllIIIIIl = 1.0F - llllllllllllllllllIlllIlllIIIIIl;
      llllllllllllllllllIlllIlllIIIIIl = MathHelper.clamp_float(llllllllllllllllllIlllIlllIIIIIl, 0.0F, 1.0F);
      WorldBorder llllllllllllllllllIlllIlllIIlIII = mc.theWorld.getWorldBorder();
      float llllllllllllllllllIlllIlllIIIlll = (float)llllllllllllllllllIlllIlllIIlIII.getClosestDistance(mc.thePlayer);
      double llllllllllllllllllIlllIlllIIIllI = Math.min(llllllllllllllllllIlllIlllIIlIII.getResizeSpeed() * llllllllllllllllllIlllIlllIIlIII.getWarningTime() * 1000.0D, Math.abs(llllllllllllllllllIlllIlllIIlIII.getTargetSize() - llllllllllllllllllIlllIlllIIlIII.getDiameter()));
      double llllllllllllllllllIlllIlllIIIlIl = Math.max(llllllllllllllllllIlllIlllIIlIII.getWarningDistance(), llllllllllllllllllIlllIlllIIIllI);
      if (lIlIllIIIlIl(lIlIllIIIllI(llllllllllllllllllIlllIlllIIIlll, llllllllllllllllllIlllIlllIIIlIl)))
      {
        llllllllllllllllllIlllIlllIIIlll = 1.0F - (float)(llllllllllllllllllIlllIlllIIIlll / llllllllllllllllllIlllIlllIIIlIl);
        "".length();
        if (-" ".length() == -" ".length()) {}
      }
      else
      {
        llllllllllllllllllIlllIlllIIIlll = 0.0F;
      }
      prevVignetteBrightness = ((float)(prevVignetteBrightness + (llllllllllllllllllIlllIlllIIIIIl - prevVignetteBrightness) * 0.01D));
      GlStateManager.disableDepth();
      GlStateManager.depthMask(llIlIllIlI[0]);
      GlStateManager.tryBlendFuncSeparate(llIlIllIlI[0], llIlIllIlI[13], llIlIllIlI[1], llIlIllIlI[0]);
      if (lIlIlIlllIII(lIlIllIIIlll(llllllllllllllllllIlllIlllIIIlll, 0.0F)))
      {
        GlStateManager.color(0.0F, llllllllllllllllllIlllIlllIIIlll, llllllllllllllllllIlllIlllIIIlll, 1.0F);
        "".length();
        if (" ".length() != 0) {}
      }
      else
      {
        GlStateManager.color(prevVignetteBrightness, prevVignetteBrightness, prevVignetteBrightness, 1.0F);
      }
      mc.getTextureManager().bindTexture(vignetteTexPath);
      Tessellator llllllllllllllllllIlllIlllIIIlII = Tessellator.getInstance();
      WorldRenderer llllllllllllllllllIlllIlllIIIIll = llllllllllllllllllIlllIlllIIIlII.getWorldRenderer();
      llllllllllllllllllIlllIlllIIIIll.begin(llIlIllIlI[14], DefaultVertexFormats.POSITION_TEX);
      llllllllllllllllllIlllIlllIIIIll.pos(0.0D, llllllllllllllllllIlllIlllIIIIII.getScaledHeight(), -90.0D).tex(0.0D, 1.0D).endVertex();
      llllllllllllllllllIlllIlllIIIIll.pos(ScaledResolution.getScaledWidth(), llllllllllllllllllIlllIlllIIIIII.getScaledHeight(), -90.0D).tex(1.0D, 1.0D).endVertex();
      llllllllllllllllllIlllIlllIIIIll.pos(ScaledResolution.getScaledWidth(), 0.0D, -90.0D).tex(1.0D, 0.0D).endVertex();
      llllllllllllllllllIlllIlllIIIIll.pos(0.0D, 0.0D, -90.0D).tex(0.0D, 0.0D).endVertex();
      llllllllllllllllllIlllIlllIIIlII.draw();
      GlStateManager.depthMask(llIlIllIlI[1]);
      GlStateManager.enableDepth();
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.tryBlendFuncSeparate(llIlIllIlI[10], llIlIllIlI[11], llIlIllIlI[1], llIlIllIlI[0]);
    }
  }
  
  public void func_181029_i()
  {
    ;
    overlayPlayerList.func_181030_a();
  }
  
  private void renderBossHealth()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIlIlIllIllI(BossStatus.bossName)) && (lIlIlIlllIII(BossStatus.statusBarTime)))
    {
      BossStatus.statusBarTime -= llIlIllIlI[1];
      FontRenderer llllllllllllllllllIlllIlllllIIIl = Minecraft.fontRendererObj;
      ScaledResolution llllllllllllllllllIlllIlllllIIII = new ScaledResolution(mc);
      int llllllllllllllllllIlllIllllIllll = ScaledResolution.getScaledWidth();
      short llllllllllllllllllIlllIllllIlllI = llIlIllIlI[30];
      int llllllllllllllllllIlllIllllIllIl = llllllllllllllllllIlllIllllIllll / llIlIllIlI[2] - llllllllllllllllllIlllIllllIlllI / llIlIllIlI[2];
      int llllllllllllllllllIlllIllllIllII = (int)(BossStatus.healthScale * (llllllllllllllllllIlllIllllIlllI + llIlIllIlI[1]));
      byte llllllllllllllllllIlllIllllIlIll = llIlIllIlI[32];
      llllllllllllllllllIlllIlllllIIlI.drawTexturedModalRect(llllllllllllllllllIlllIllllIllIl, llllllllllllllllllIlllIllllIlIll, llIlIllIlI[0], llIlIllIlI[66], llllllllllllllllllIlllIllllIlllI, llIlIllIlI[5]);
      llllllllllllllllllIlllIlllllIIlI.drawTexturedModalRect(llllllllllllllllllIlllIllllIllIl, llllllllllllllllllIlllIllllIlIll, llIlIllIlI[0], llIlIllIlI[66], llllllllllllllllllIlllIllllIlllI, llIlIllIlI[5]);
      if (lIlIlIlllIII(llllllllllllllllllIlllIllllIllII)) {
        llllllllllllllllllIlllIlllllIIlI.drawTexturedModalRect(llllllllllllllllllIlllIllllIllIl, llllllllllllllllllIlllIllllIlIll, llIlIllIlI[0], llIlIllIlI[67], llllllllllllllllllIlllIllllIllII, llIlIllIlI[5]);
      }
      String llllllllllllllllllIlllIllllIlIlI = BossStatus.bossName;
      "".length();
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      mc.getTextureManager().bindTexture(icons);
    }
  }
  
  private static boolean lIlIlIllllIl(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllllIlllIlIIIIIlll;
    return ??? >= i;
  }
  
  private static boolean lIlIlIlllIIl(int ???, int arg1)
  {
    int i;
    short llllllllllllllllllIlllIIlllllIll;
    return ??? > i;
  }
  
  public void func_175177_a()
  {
    ;
    field_175199_z = llIlIllIlI[7];
    field_175192_A = llIlIllIlI[8];
    field_175193_B = llIlIllIlI[9];
  }
  
  private static String lIlIlIIlIllI(String llllllllllllllllllIlllIlIIllIlll, String llllllllllllllllllIlllIlIIlllIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIlllIlIIllllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlllIlIIlllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIlllIlIIlllIll = Cipher.getInstance("Blowfish");
      llllllllllllllllllIlllIlIIlllIll.init(llIlIllIlI[2], llllllllllllllllllIlllIlIIllllII);
      return new String(llllllllllllllllllIlllIlIIlllIll.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlllIlIIllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIlllIlIIlllIlI)
    {
      llllllllllllllllllIlllIlIIlllIlI.printStackTrace();
    }
    return null;
  }
  
  public GuiPlayerTabOverlay getTabList()
  {
    ;
    return overlayPlayerList;
  }
  
  private void renderPlayerStats(ScaledResolution llllllllllllllllllIllllIIIIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIlIllIlII(mc.getRenderViewEntity() instanceof EntityPlayer))
    {
      EntityPlayer llllllllllllllllllIllllIIlIIllll = (EntityPlayer)mc.getRenderViewEntity();
      int llllllllllllllllllIllllIIlIIlllI = MathHelper.ceiling_float_int(llllllllllllllllllIllllIIlIIllll.getHealth());
      if ((lIlIlIlllIII(lIlIllIIIIII(healthUpdateCounter, updateCounter))) && (lIlIlIllIlIl(lIlIllIIIIII((healthUpdateCounter - updateCounter) / 3L % 2L, 1L))))
      {
        "".length();
        if ("   ".length() > 0) {
          break label106;
        }
      }
      label106:
      boolean llllllllllllllllllIllllIIlIIllIl = llIlIllIlI[0];
      if ((lIlIllIIIIll(llllllllllllllllllIllllIIlIIlllI, playerHealth)) && (lIlIlIlllIII(hurtResistantTime)))
      {
        lastSystemTime = Minecraft.getSystemTime();
        healthUpdateCounter = (updateCounter + llIlIllIlI[9]);
        "".length();
        if ((0x6B ^ 0x6F) != "  ".length()) {}
      }
      else if ((lIlIlIlllIIl(llllllllllllllllllIllllIIlIIlllI, playerHealth)) && (lIlIlIlllIII(hurtResistantTime)))
      {
        lastSystemTime = Minecraft.getSystemTime();
        healthUpdateCounter = (updateCounter + llIlIllIlI[7]);
      }
      if (lIlIlIlllIII(lIlIllIIIIII(Minecraft.getSystemTime() - lastSystemTime, 1000L)))
      {
        playerHealth = llllllllllllllllllIllllIIlIIlllI;
        lastPlayerHealth = llllllllllllllllllIllllIIlIIlllI;
        lastSystemTime = Minecraft.getSystemTime();
      }
      playerHealth = llllllllllllllllllIllllIIlIIlllI;
      int llllllllllllllllllIllllIIlIIllII = lastPlayerHealth;
      rand.setSeed(updateCounter * llIlIllIlI[50]);
      boolean llllllllllllllllllIllllIIlIIlIll = llIlIllIlI[0];
      FoodStats llllllllllllllllllIllllIIlIIlIlI = llllllllllllllllllIllllIIlIIllll.getFoodStats();
      int llllllllllllllllllIllllIIlIIlIIl = llllllllllllllllllIllllIIlIIlIlI.getFoodLevel();
      int llllllllllllllllllIllllIIlIIlIII = llllllllllllllllllIllllIIlIIlIlI.getPrevFoodLevel();
      IAttributeInstance llllllllllllllllllIllllIIlIIIlll = llllllllllllllllllIllllIIlIIllll.getEntityAttribute(SharedMonsterAttributes.maxHealth);
      int llllllllllllllllllIllllIIlIIIllI = ScaledResolution.getScaledWidth() / llIlIllIlI[2] - llIlIllIlI[20];
      int llllllllllllllllllIllllIIlIIIlIl = ScaledResolution.getScaledWidth() / llIlIllIlI[2] + llIlIllIlI[20];
      int llllllllllllllllllIllllIIlIIIlII = llllllllllllllllllIllllIIIIlllII.getScaledHeight() - llIlIllIlI[51];
      float llllllllllllllllllIllllIIlIIIIll = (float)llllllllllllllllllIllllIIlIIIlll.getAttributeValue();
      float llllllllllllllllllIllllIIlIIIIlI = llllllllllllllllllIllllIIlIIllll.getAbsorptionAmount();
      int llllllllllllllllllIllllIIlIIIIIl = MathHelper.ceiling_float_int((llllllllllllllllllIllllIIlIIIIll + llllllllllllllllllIllllIIlIIIIlI) / 2.0F / 10.0F);
      int llllllllllllllllllIllllIIlIIIIII = Math.max(llIlIllIlI[7] - (llllllllllllllllllIllllIIlIIIIIl - llIlIllIlI[2]), llIlIllIlI[3]);
      int llllllllllllllllllIllllIIIllllll = llllllllllllllllllIllllIIlIIIlII - (llllllllllllllllllIllllIIlIIIIIl - llIlIllIlI[1]) * llllllllllllllllllIllllIIlIIIIII - llIlIllIlI[7];
      float llllllllllllllllllIllllIIIlllllI = llllllllllllllllllIllllIIlIIIIlI;
      int llllllllllllllllllIllllIIIllllIl = llllllllllllllllllIllllIIlIIllll.getTotalArmorValue();
      int llllllllllllllllllIllllIIIllllII = llIlIllIlI[52];
      if (lIlIlIllIlII(llllllllllllllllllIllllIIlIIllll.isPotionActive(Potion.regeneration))) {
        llllllllllllllllllIllllIIIllllII = updateCounter % MathHelper.ceiling_float_int(llllllllllllllllllIllllIIlIIIIll + 5.0F);
      }
      mc.mcProfiler.startSection(llIlIlIlIl[llIlIllIlI[53]]);
      int llllllllllllllllllIllllIIIlllIll = llIlIllIlI[0];
      "".length();
      if ((0x80 ^ 0x9F ^ 0xA4 ^ 0xBF) != (0x61 ^ 0x30 ^ 0xD4 ^ 0x81)) {
        return;
      }
      while (!lIlIlIllllIl(llllllllllllllllllIllllIIIlllIll, llIlIllIlI[7]))
      {
        if (lIlIlIlllIII(llllllllllllllllllIllllIIIllllIl))
        {
          int llllllllllllllllllIllllIIIlllIlI = llllllllllllllllllIllllIIlIIIllI + llllllllllllllllllIllllIIIlllIll * llIlIllIlI[16];
          if (lIlIllIIIIll(llllllllllllllllllIllllIIIlllIll * llIlIllIlI[2] + llIlIllIlI[1], llllllllllllllllllIllllIIIllllIl)) {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIlllIlI, llllllllllllllllllIllllIIIllllll, llIlIllIlI[54], llIlIllIlI[21], llIlIllIlI[21], llIlIllIlI[21]);
          }
          if (lIlIlIllllll(llllllllllllllllllIllllIIIlllIll * llIlIllIlI[2] + llIlIllIlI[1], llllllllllllllllllIllllIIIllllIl)) {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIlllIlI, llllllllllllllllllIllllIIIllllll, llIlIllIlI[55], llIlIllIlI[21], llIlIllIlI[21], llIlIllIlI[21]);
          }
          if (lIlIlIlllIIl(llllllllllllllllllIllllIIIlllIll * llIlIllIlI[2] + llIlIllIlI[1], llllllllllllllllllIllllIIIllllIl)) {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIlllIlI, llllllllllllllllllIllllIIIllllll, llIlIllIlI[15], llIlIllIlI[21], llIlIllIlI[21], llIlIllIlI[21]);
          }
        }
        llllllllllllllllllIllllIIIlllIll++;
      }
      mc.mcProfiler.endStartSection(llIlIlIlIl[llIlIllIlI[29]]);
      int llllllllllllllllllIllllIIIlllIIl = MathHelper.ceiling_float_int((llllllllllllllllllIllllIIlIIIIll + llllllllllllllllllIllllIIlIIIIlI) / 2.0F) - llIlIllIlI[1];
      "".length();
      if (-"  ".length() > 0) {
        return;
      }
      while (!lIlIllIIIlIl(llllllllllllllllllIllllIIIlllIIl))
      {
        int llllllllllllllllllIllllIIIlllIII = llIlIllIlI[15];
        if (lIlIlIllIlII(llllllllllllllllllIllllIIlIIllll.isPotionActive(Potion.poison)))
        {
          llllllllllllllllllIllllIIIlllIII += 36;
          "".length();
          if ("   ".length() >= 0) {}
        }
        else if (lIlIlIllIlII(llllllllllllllllllIllllIIlIIllll.isPotionActive(Potion.wither)))
        {
          llllllllllllllllllIllllIIIlllIII += 72;
        }
        byte llllllllllllllllllIllllIIIllIlll = llIlIllIlI[0];
        if (lIlIlIllIlII(llllllllllllllllllIllllIIlIIllIl)) {
          llllllllllllllllllIllllIIIllIlll = llIlIllIlI[1];
        }
        int llllllllllllllllllIllllIIIllIllI = MathHelper.ceiling_float_int((llllllllllllllllllIllllIIIlllIIl + llIlIllIlI[1]) / 10.0F) - llIlIllIlI[1];
        int llllllllllllllllllIllllIIIllIlIl = llllllllllllllllllIllllIIlIIIllI + llllllllllllllllllIllllIIIlllIIl % llIlIllIlI[7] * llIlIllIlI[16];
        int llllllllllllllllllIllllIIIllIlII = llllllllllllllllllIllllIIlIIIlII - llllllllllllllllllIllllIIIllIllI * llllllllllllllllllIllllIIlIIIIII;
        if (lIlIlIlllIlI(llllllllllllllllllIllllIIlIIlllI, llIlIllIlI[4])) {
          llllllllllllllllllIllllIIIllIlII += rand.nextInt(llIlIllIlI[2]);
        }
        if (lIlIlIllllll(llllllllllllllllllIllllIIIlllIIl, llllllllllllllllllIllllIIIllllII)) {
          llllllllllllllllllIllllIIIllIlII -= 2;
        }
        byte llllllllllllllllllIllllIIIllIIll = llIlIllIlI[0];
        if (lIlIlIllIlII(worldObj.getWorldInfo().isHardcoreModeEnabled())) {
          llllllllllllllllllIllllIIIllIIll = llIlIllIlI[5];
        }
        llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIllIlIl, llllllllllllllllllIllllIIIllIlII, llIlIllIlI[15] + llllllllllllllllllIllllIIIllIlll * llIlIllIlI[21], llIlIllIlI[21] * llllllllllllllllllIllllIIIllIIll, llIlIllIlI[21], llIlIllIlI[21]);
        if (lIlIlIllIlII(llllllllllllllllllIllllIIlIIllIl))
        {
          if (lIlIllIIIIll(llllllllllllllllllIllllIIIlllIIl * llIlIllIlI[2] + llIlIllIlI[1], llllllllllllllllllIllllIIlIIllII)) {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIllIlIl, llllllllllllllllllIllllIIIllIlII, llllllllllllllllllIllllIIIlllIII + llIlIllIlI[56], llIlIllIlI[21] * llllllllllllllllllIllllIIIllIIll, llIlIllIlI[21], llIlIllIlI[21]);
          }
          if (lIlIlIllllll(llllllllllllllllllIllllIIIlllIIl * llIlIllIlI[2] + llIlIllIlI[1], llllllllllllllllllIllllIIlIIllII)) {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIllIlIl, llllllllllllllllllIllllIIIllIlII, llllllllllllllllllIllllIIIlllIII + llIlIllIlI[57], llIlIllIlI[21] * llllllllllllllllllIllllIIIllIIll, llIlIllIlI[21], llIlIllIlI[21]);
          }
        }
        if (lIlIllIIIlII(lIlIllIIIIIl(llllllllllllllllllIllllIIIlllllI, 0.0F)))
        {
          if (lIlIllIIIIll(llllllllllllllllllIllllIIIlllIIl * llIlIllIlI[2] + llIlIllIlI[1], llllllllllllllllllIllllIIlIIlllI)) {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIllIlIl, llllllllllllllllllIllllIIIllIlII, llllllllllllllllllIllllIIIlllIII + llIlIllIlI[58], llIlIllIlI[21] * llllllllllllllllllIllllIIIllIIll, llIlIllIlI[21], llIlIllIlI[21]);
          }
          if (lIlIlIllllll(llllllllllllllllllIllllIIIlllIIl * llIlIllIlI[2] + llIlIllIlI[1], llllllllllllllllllIllllIIlIIlllI))
          {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIllIlIl, llllllllllllllllllIllllIIIllIlII, llllllllllllllllllIllllIIIlllIII + llIlIllIlI[59], llIlIllIlI[21] * llllllllllllllllllIllllIIIllIIll, llIlIllIlI[21], llIlIllIlI[21]);
            "".length();
            if ((0xB4 ^ 0xB0) > 0) {}
          }
        }
        else
        {
          if ((lIlIlIllIlIl(lIlIllIIIIlI(llllllllllllllllllIllllIIIlllllI, llllllllllllllllllIllllIIlIIIIlI))) && (lIlIlIllIlIl(lIlIllIIIIlI(llllllllllllllllllIllllIIlIIIIlI % 2.0F, 1.0F))))
          {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIllIlIl, llllllllllllllllllIllllIIIllIlII, llllllllllllllllllIllllIIIlllIII + llIlIllIlI[60], llIlIllIlI[21] * llllllllllllllllllIllllIIIllIIll, llIlIllIlI[21], llIlIllIlI[21]);
            "".length();
            if (" ".length() != -" ".length()) {}
          }
          else
          {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIllIlIl, llllllllllllllllllIllllIIIllIlII, llllllllllllllllllIllllIIIlllIII + llIlIllIlI[61], llIlIllIlI[21] * llllllllllllllllllIllllIIIllIIll, llIlIllIlI[21], llIlIllIlI[21]);
          }
          llllllllllllllllllIllllIIIlllllI -= 2.0F;
        }
        llllllllllllllllllIllllIIIlllIIl--;
      }
      Entity llllllllllllllllllIllllIIIllIIlI = ridingEntity;
      if (lIlIlIllllII(llllllllllllllllllIllllIIIllIIlI))
      {
        mc.mcProfiler.endStartSection(llIlIlIlIl[llIlIllIlI[62]]);
        int llllllllllllllllllIllllIIIllIIIl = llIlIllIlI[0];
        "".length();
        if (-" ".length() >= " ".length()) {
          return;
        }
        while (!lIlIlIllllIl(llllllllllllllllllIllllIIIllIIIl, llIlIllIlI[7]))
        {
          int llllllllllllllllllIllllIIIllIIII = llllllllllllllllllIllllIIlIIIlII;
          int llllllllllllllllllIllllIIIlIllll = llIlIllIlI[15];
          byte llllllllllllllllllIllllIIIlIlllI = llIlIllIlI[0];
          if (lIlIlIllIlII(llllllllllllllllllIllllIIlIIllll.isPotionActive(Potion.hunger)))
          {
            llllllllllllllllllIllllIIIlIllll += 36;
            llllllllllllllllllIllllIIIlIlllI = llIlIllIlI[36];
          }
          if ((lIlIllIIIlII(lIlIllIIIIIl(llllllllllllllllllIllllIIlIIllll.getFoodStats().getSaturationLevel(), 0.0F))) && (lIlIlIllIlIl(updateCounter % (llllllllllllllllllIllllIIlIIlIIl * llIlIllIlI[3] + llIlIllIlI[1])))) {
            llllllllllllllllllIllllIIIllIIII = llllllllllllllllllIllllIIlIIIlII + (rand.nextInt(llIlIllIlI[3]) - llIlIllIlI[1]);
          }
          if (lIlIlIllIlII(llllllllllllllllllIllllIIlIIlIll)) {
            llllllllllllllllllIllllIIIlIlllI = llIlIllIlI[1];
          }
          int llllllllllllllllllIllllIIIlIllIl = llllllllllllllllllIllllIIlIIIlIl - llllllllllllllllllIllllIIIllIIIl * llIlIllIlI[16] - llIlIllIlI[21];
          llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIlIllIl, llllllllllllllllllIllllIIIllIIII, llIlIllIlI[15] + llllllllllllllllllIllllIIIlIlllI * llIlIllIlI[21], llIlIllIlI[63], llIlIllIlI[21], llIlIllIlI[21]);
          if (lIlIlIllIlII(llllllllllllllllllIllllIIlIIlIll))
          {
            if (lIlIllIIIIll(llllllllllllllllllIllllIIIllIIIl * llIlIllIlI[2] + llIlIllIlI[1], llllllllllllllllllIllllIIlIIlIII)) {
              llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIlIllIl, llllllllllllllllllIllllIIIllIIII, llllllllllllllllllIllllIIIlIllll + llIlIllIlI[56], llIlIllIlI[63], llIlIllIlI[21], llIlIllIlI[21]);
            }
            if (lIlIlIllllll(llllllllllllllllllIllllIIIllIIIl * llIlIllIlI[2] + llIlIllIlI[1], llllllllllllllllllIllllIIlIIlIII)) {
              llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIlIllIl, llllllllllllllllllIllllIIIllIIII, llllllllllllllllllIllllIIIlIllll + llIlIllIlI[57], llIlIllIlI[63], llIlIllIlI[21], llIlIllIlI[21]);
            }
          }
          if (lIlIllIIIIll(llllllllllllllllllIllllIIIllIIIl * llIlIllIlI[2] + llIlIllIlI[1], llllllllllllllllllIllllIIlIIlIIl)) {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIlIllIl, llllllllllllllllllIllllIIIllIIII, llllllllllllllllllIllllIIIlIllll + llIlIllIlI[58], llIlIllIlI[63], llIlIllIlI[21], llIlIllIlI[21]);
          }
          if (lIlIlIllllll(llllllllllllllllllIllllIIIllIIIl * llIlIllIlI[2] + llIlIllIlI[1], llllllllllllllllllIllllIIlIIlIIl)) {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIlIllIl, llllllllllllllllllIllllIIIllIIII, llllllllllllllllllIllllIIIlIllll + llIlIllIlI[59], llIlIllIlI[63], llIlIllIlI[21], llIlIllIlI[21]);
          }
          llllllllllllllllllIllllIIIllIIIl++;
        }
        "".length();
        if (" ".length() <= (0x23 ^ 0x78 ^ 0xD2 ^ 0x8D)) {}
      }
      else if (lIlIlIllIlII(llllllllllllllllllIllllIIIllIIlI instanceof EntityLivingBase))
      {
        mc.mcProfiler.endStartSection(llIlIlIlIl[llIlIllIlI[18]]);
        EntityLivingBase llllllllllllllllllIllllIIIlIllII = (EntityLivingBase)llllllllllllllllllIllllIIIllIIlI;
        int llllllllllllllllllIllllIIIlIlIll = (int)Math.ceil(llllllllllllllllllIllllIIIlIllII.getHealth());
        float llllllllllllllllllIllllIIIlIlIlI = llllllllllllllllllIllllIIIlIllII.getMaxHealth();
        int llllllllllllllllllIllllIIIlIlIIl = (int)(llllllllllllllllllIllllIIIlIlIlI + 0.5F) / llIlIllIlI[2];
        if (lIlIlIlllIIl(llllllllllllllllllIllllIIIlIlIIl, llIlIllIlI[64])) {
          llllllllllllllllllIllllIIIlIlIIl = llIlIllIlI[64];
        }
        int llllllllllllllllllIllllIIIlIlIII = llllllllllllllllllIllllIIlIIIlII;
        int llllllllllllllllllIllllIIIlIIlll = llIlIllIlI[0];
        "".length();
        if (-" ".length() > 0) {
          return;
        }
        while (!lIlIllIIIlII(llllllllllllllllllIllllIIIlIlIIl))
        {
          int llllllllllllllllllIllllIIIlIIllI = Math.min(llllllllllllllllllIllllIIIlIlIIl, llIlIllIlI[7]);
          llllllllllllllllllIllllIIIlIlIIl -= llllllllllllllllllIllllIIIlIIllI;
          int llllllllllllllllllIllllIIIlIIlIl = llIlIllIlI[0];
          "".length();
          if (((65 + 'Î' - 265 + 201 ^ 92 + 48 - 107 + 103) & (0x24 ^ 0x22 ^ 0x28 ^ 0x69 ^ -" ".length())) != 0) {
            return;
          }
          while (!lIlIlIllllIl(llllllllllllllllllIllllIIIlIIlIl, llllllllllllllllllIllllIIIlIIllI))
          {
            byte llllllllllllllllllIllllIIIlIIlII = llIlIllIlI[65];
            byte llllllllllllllllllIllllIIIlIIIll = llIlIllIlI[0];
            if (lIlIlIllIlII(llllllllllllllllllIllllIIlIIlIll)) {
              llllllllllllllllllIllllIIIlIIIll = llIlIllIlI[1];
            }
            int llllllllllllllllllIllllIIIlIIIlI = llllllllllllllllllIllllIIlIIIlIl - llllllllllllllllllIllllIIIlIIlIl * llIlIllIlI[16] - llIlIllIlI[21];
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIlIIIlI, llllllllllllllllllIllllIIIlIlIII, llllllllllllllllllIllllIIIlIIlII + llllllllllllllllllIllllIIIlIIIll * llIlIllIlI[21], llIlIllIlI[21], llIlIllIlI[21], llIlIllIlI[21]);
            if (lIlIllIIIIll(llllllllllllllllllIllllIIIlIIlIl * llIlIllIlI[2] + llIlIllIlI[1] + llllllllllllllllllIllllIIIlIIlll, llllllllllllllllllIllllIIIlIlIll)) {
              llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIlIIIlI, llllllllllllllllllIllllIIIlIlIII, llllllllllllllllllIllllIIIlIIlII + llIlIllIlI[58], llIlIllIlI[21], llIlIllIlI[21], llIlIllIlI[21]);
            }
            if (lIlIlIllllll(llllllllllllllllllIllllIIIlIIlIl * llIlIllIlI[2] + llIlIllIlI[1] + llllllllllllllllllIllllIIIlIIlll, llllllllllllllllllIllllIIIlIlIll)) {
              llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIIlIIIlI, llllllllllllllllllIllllIIIlIlIII, llllllllllllllllllIllllIIIlIIlII + llIlIllIlI[59], llIlIllIlI[21], llIlIllIlI[21], llIlIllIlI[21]);
            }
            llllllllllllllllllIllllIIIlIIlIl++;
          }
          llllllllllllllllllIllllIIIlIlIII -= 10;
          llllllllllllllllllIllllIIIlIIlll += 20;
        }
      }
      mc.mcProfiler.endStartSection(llIlIlIlIl[llIlIllIlI[55]]);
      if (lIlIlIllIlII(llllllllllllllllllIllllIIlIIllll.isInsideOfMaterial(Material.water)))
      {
        int llllllllllllllllllIllllIIIlIIIIl = mc.thePlayer.getAir();
        int llllllllllllllllllIllllIIIlIIIII = MathHelper.ceiling_double_int((llllllllllllllllllIllllIIIlIIIIl - llIlIllIlI[2]) * 10.0D / 300.0D);
        int llllllllllllllllllIllllIIIIlllll = MathHelper.ceiling_double_int(llllllllllllllllllIllllIIIlIIIIl * 10.0D / 300.0D) - llllllllllllllllllIllllIIIlIIIII;
        int llllllllllllllllllIllllIIIIllllI = llIlIllIlI[0];
        "".length();
        if (-(46 + '' - 124 + 85 ^ 87 + '' - 141 + 78) > 0) {
          return;
        }
        while (!lIlIlIllllIl(llllllllllllllllllIllllIIIIllllI, llllllllllllllllllIllllIIIlIIIII + llllllllllllllllllIllllIIIIlllll))
        {
          if (lIlIllIIIIll(llllllllllllllllllIllllIIIIllllI, llllllllllllllllllIllllIIIlIIIII))
          {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIlIIIlIl - llllllllllllllllllIllllIIIIllllI * llIlIllIlI[16] - llIlIllIlI[21], llllllllllllllllllIllllIIIllllll, llIlIllIlI[15], llIlIllIlI[45], llIlIllIlI[21], llIlIllIlI[21]);
            "".length();
            if (null == null) {}
          }
          else
          {
            llllllllllllllllllIllllIIIIlllIl.drawTexturedModalRect(llllllllllllllllllIllllIIlIIIlIl - llllllllllllllllllIllllIIIIllllI * llIlIllIlI[16] - llIlIllIlI[21], llllllllllllllllllIllllIIIllllll, llIlIllIlI[55], llIlIllIlI[45], llIlIllIlI[21], llIlIllIlI[21]);
          }
          llllllllllllllllllIllllIIIIllllI++;
        }
      }
      mc.mcProfiler.endSection();
    }
  }
  
  private static int lIlIllIIIIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  static
  {
    lIlIlIllIIlI();
    lIlIlIlIIIIl();
    __OBFID = llIlIlIlIl[llIlIllIlI[0]];
    vignetteTexPath = new ResourceLocation(llIlIlIlIl[llIlIllIlI[1]]);
  }
  
  private void renderScoreboard(ScoreObjective llllllllllllllllllIllllIlIIIlIII, ScaledResolution llllllllllllllllllIllllIlIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Scoreboard llllllllllllllllllIllllIlIlIIIII = llllllllllllllllllIllllIlIIIlIII.getScoreboard();
    Collection llllllllllllllllllIllllIlIIlllll = llllllllllllllllllIllllIlIlIIIII.getSortedScores(llllllllllllllllllIllllIlIlIIIlI);
    ArrayList llllllllllllllllllIllllIlIIllllI = Lists.newArrayList(Iterables.filter(llllllllllllllllllIllllIlIIlllll, new Predicate()
    {
      private static boolean lllIIlllIlIlII(Object ???)
      {
        int llllllllllllllIIlllIlIIlllIIIIII;
        return ??? != null;
      }
      
      public boolean apply(Score llllllllllllllIIlllIlIlllIIIllll)
      {
        ;
        if ((lllIIlllIlIlII(llllllllllllllIIlllIlIlllIIIllll.getPlayerName())) && (lllIIlllIlIlIl(llllllllllllllIIlllIlIlllIIIlllI.getPlayerName().startsWith(lIIlIllIlllII[lIIlIllIllllI[0]])))) {
          return lIIlIllIllllI[1];
        }
        return lIIlIllIllllI[0];
      }
      
      private static boolean lllIIlllIlIlIl(int ???)
      {
        byte llllllllllllllIIlllIlIIllIlllllI;
        return ??? == 0;
      }
      
      private static String lllIIlllIlIIII(String llllllllllllllIIlllIlIIlllIIIlll, String llllllllllllllIIlllIlIIlllIIIlII)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllIIlllIlIIlllIIlIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIIlllIlIIlllIIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher llllllllllllllIIlllIlIIlllIIlIIl = Cipher.getInstance("Blowfish");
          llllllllllllllIIlllIlIIlllIIlIIl.init(lIIlIllIllllI[2], llllllllllllllIIlllIlIIlllIIlIlI);
          return new String(llllllllllllllIIlllIlIIlllIIlIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIIlllIlIIlllIIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllIIlllIlIIlllIIlIII)
        {
          llllllllllllllIIlllIlIIlllIIlIII.printStackTrace();
        }
        return null;
      }
      
      public boolean apply(Object llllllllllllllIIlllIlIIlllIIllll)
      {
        ;
        ;
        return llllllllllllllIIlllIlIIlllIlIIII.apply((Score)llllllllllllllIIlllIlIIlllIIllll);
      }
      
      private static void lllIIlllIlIIlI()
      {
        lIIlIllIllllI = new int[3];
        lIIlIllIllllI[0] = ((0x3A ^ 0x2B) & (0x3A ^ 0x2B ^ 0xFFFFFFFF));
        lIIlIllIllllI[1] = " ".length();
        lIIlIllIllllI[2] = "  ".length();
      }
      
      static
      {
        lllIIlllIlIIlI();
        lllIIlllIlIIIl();
      }
      
      private static void lllIIlllIlIIIl()
      {
        lIIlIllIlllII = new String[lIIlIllIllllI[2]];
        lIIlIllIlllII[lIIlIllIllllI[0]] = lllIIlllIlIIII("VQpJR7PlIOU=", "cmrXz");
        lIIlIllIlllII[lIIlIllIllllI[1]] = lllIIlllIlIIII("GueT7lI6b28jPzluIMQL7w==", "iOVIL");
      }
    }));
    ArrayList llllllllllllllllllIllllIlIIlllII;
    if (lIlIlIlllIIl(llllllllllllllllllIllllIlIIllllI.size(), llIlIllIlI[42]))
    {
      ArrayList llllllllllllllllllIllllIlIIlllIl = Lists.newArrayList(Iterables.skip(llllllllllllllllllIllllIlIIllllI, llllllllllllllllllIllllIlIIlllll.size() - llIlIllIlI[42]));
      "".length();
      if (((0x3A ^ 0x1F) & (0x1C ^ 0x39 ^ 0xFFFFFFFF)) == 0) {}
    }
    else
    {
      llllllllllllllllllIllllIlIIlllII = llllllllllllllllllIllllIlIIllllI;
    }
    int llllllllllllllllllIllllIlIIllIll = llllllllllllllllllIllllIlIlIIIll.getFontRenderer().getStringWidth(llllllllllllllllllIllllIlIlIIIlI.getDisplayName());
    Exception llllllllllllllllllIllllIlIIIIIII = llllllllllllllllllIllllIlIIlllII.iterator();
    "".length();
    if (null != null) {
      return;
    }
    while (!lIlIlIllIlIl(llllllllllllllllllIllllIlIIIIIII.hasNext()))
    {
      Object llllllllllllllllllIllllIlIIllIlI = llllllllllllllllllIllllIlIIIIIII.next();
      Score llllllllllllllllllIllllIlIIllIIl = (Score)llllllllllllllllllIllllIlIIllIlI;
      ScorePlayerTeam llllllllllllllllllIllllIlIIllIII = llllllllllllllllllIllllIlIlIIIII.getPlayersTeam(llllllllllllllllllIllllIlIIllIIl.getPlayerName());
      String llllllllllllllllllIllllIlIIlIlll = String.valueOf(new StringBuilder(String.valueOf(ScorePlayerTeam.formatPlayerName(llllllllllllllllllIllllIlIIllIII, llllllllllllllllllIllllIlIIllIIl.getPlayerName()))).append(llIlIlIlIl[llIlIllIlI[9]]).append(EnumChatFormatting.RED).append(llllllllllllllllllIllllIlIIllIIl.getScorePoints()));
      llllllllllllllllllIllllIlIIllIll = Math.max(llllllllllllllllllIllllIlIIllIll, llllllllllllllllllIllllIlIlIIIll.getFontRenderer().getStringWidth(llllllllllllllllllIllllIlIIlIlll));
    }
    int llllllllllllllllllIllllIlIIlIllI = llllllllllllllllllIllllIlIIlllII.size() * getFontRendererFONT_HEIGHT;
    int llllllllllllllllllIllllIlIIlIlIl = llllllllllllllllllIllllIlIlIIIIl.getScaledHeight() / llIlIllIlI[2] + llllllllllllllllllIllllIlIIlIllI / llIlIllIlI[3];
    byte llllllllllllllllllIllllIlIIlIlII = llIlIllIlI[3];
    int llllllllllllllllllIllllIlIIlIIll = ScaledResolution.getScaledWidth() - llllllllllllllllllIllllIlIIllIll - llllllllllllllllllIllllIlIIlIlII;
    int llllllllllllllllllIllllIlIIlIIlI = llIlIllIlI[0];
    byte llllllllllllllllllIllllIIllllIll = llllllllllllllllllIllllIlIIlllII.iterator();
    "".length();
    if (((0xD1 ^ 0x8E) & (0x0 ^ 0x5F ^ 0xFFFFFFFF)) < ((0x92 ^ 0xBD) & (0x9D ^ 0xB2 ^ 0xFFFFFFFF))) {
      return;
    }
    while (!lIlIlIllIlIl(llllllllllllllllllIllllIIllllIll.hasNext()))
    {
      Object llllllllllllllllllIllllIlIIlIIIl = llllllllllllllllllIllllIIllllIll.next();
      Score llllllllllllllllllIllllIlIIlIIII = (Score)llllllllllllllllllIllllIlIIlIIIl;
      llllllllllllllllllIllllIlIIlIIlI++;
      ScorePlayerTeam llllllllllllllllllIllllIlIIIllll = llllllllllllllllllIllllIlIlIIIII.getPlayersTeam(llllllllllllllllllIllllIlIIlIIII.getPlayerName());
      String llllllllllllllllllIllllIlIIIlllI = ScorePlayerTeam.formatPlayerName(llllllllllllllllllIllllIlIIIllll, llllllllllllllllllIllllIlIIlIIII.getPlayerName());
      String llllllllllllllllllIllllIlIIIllIl = String.valueOf(new StringBuilder().append(EnumChatFormatting.RED).append(llllllllllllllllllIllllIlIIlIIII.getScorePoints()));
      int llllllllllllllllllIllllIlIIIllII = llllllllllllllllllIllllIlIIlIlIl - llllllllllllllllllIllllIlIIlIIlI * getFontRendererFONT_HEIGHT;
      int llllllllllllllllllIllllIlIIIlIll = ScaledResolution.getScaledWidth() - llllllllllllllllllIllllIlIIlIlII + llIlIllIlI[2];
      drawRect(llllllllllllllllllIllllIlIIlIIll - llIlIllIlI[2], llllllllllllllllllIllllIlIIIllII, llllllllllllllllllIllllIlIIIlIll, llllllllllllllllllIllllIlIIIllII + getFontRendererFONT_HEIGHT, llIlIllIlI[47]);
      "".length();
      "".length();
      if (lIlIlIllllll(llllllllllllllllllIllllIlIIlIIlI, llllllllllllllllllIllllIlIIlllII.size()))
      {
        String llllllllllllllllllIllllIlIIIlIlI = llllllllllllllllllIllllIlIlIIIlI.getDisplayName();
        drawRect(llllllllllllllllllIllllIlIIlIIll - llIlIllIlI[2], llllllllllllllllllIllllIlIIIllII - getFontRendererFONT_HEIGHT - llIlIllIlI[1], llllllllllllllllllIllllIlIIIlIll, llllllllllllllllllIllllIlIIIllII - llIlIllIlI[1], llIlIllIlI[49]);
        drawRect(llllllllllllllllllIllllIlIIlIIll - llIlIllIlI[2], llllllllllllllllllIllllIlIIIllII - llIlIllIlI[1], llllllllllllllllllIllllIlIIIlIll, llllllllllllllllllIllllIlIIIllII, llIlIllIlI[47]);
        "".length();
      }
    }
  }
  
  private static int lIlIllIIIIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
}

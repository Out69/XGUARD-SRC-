package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundCategory;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class GuiScreenOptionsSounds
  extends GuiScreen
{
  public GuiScreenOptionsSounds(GuiScreen lllllllllllllllIIllIllIlIlIIllII, GameSettings lllllllllllllllIIllIllIlIlIIlIll)
  {
    field_146505_f = lllllllllllllllIIllIllIlIlIIlIIl;
    game_settings_4 = lllllllllllllllIIllIllIlIlIIlIll;
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllIIllIllIlIIllIlIl)
    throws IOException
  {
    ;
    ;
    if ((lIIIlIIllIllII(enabled)) && (lIIIlIIllIllIl(id, lIllIIlIIlll[8])))
    {
      mc.gameSettings.saveOptions();
      mc.displayGuiScreen(field_146505_f);
    }
  }
  
  private static boolean lIIIlIIllIllII(int ???)
  {
    short lllllllllllllllIIllIllIIllIllIII;
    return ??? != 0;
  }
  
  private static int lIIIlIIllIlllI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    int lllllllllllllllIIllIllIlIlIIIIII = lIllIIlIIlll[0];
    field_146507_a = I18n.format(lIllIIlIIlIl[lIllIIlIIlll[1]], new Object[lIllIIlIIlll[0]]);
    field_146508_h = I18n.format(lIllIIlIIlIl[lIllIIlIIlll[2]], new Object[lIllIIlIIlll[0]]);
    new Button(SoundCategory.MASTER.getCategoryId(), width / lIllIIlIIlll[2] - lIllIIlIIlll[3] + lllllllllllllllIIllIllIlIlIIIIII % lIllIIlIIlll[2] * lIllIIlIIlll[4], height / lIllIIlIIlll[5] - lIllIIlIIlll[6] + lIllIIlIIlll[7] * (lllllllllllllllIIllIllIlIlIIIIII >> lIllIIlIIlll[1]), SoundCategory.MASTER, lIllIIlIIlll[1]);
    "".length();
    lllllllllllllllIIllIllIlIlIIIIII += 2;
    char lllllllllllllllIIllIllIlIIlllIlI = (lllllllllllllllIIllIllIlIIlllIIl = SoundCategory.values()).length;
    char lllllllllllllllIIllIllIlIIlllIll = lIllIIlIIlll[0];
    "".length();
    if (((0x8C ^ 0x94) & (0x88 ^ 0x90 ^ 0xFFFFFFFF)) != 0) {
      return;
    }
    while (!lIIIlIIllIlIll(lllllllllllllllIIllIllIlIIlllIll, lllllllllllllllIIllIllIlIIlllIlI))
    {
      SoundCategory lllllllllllllllIIllIllIlIIllllll = lllllllllllllllIIllIllIlIIlllIIl[lllllllllllllllIIllIllIlIIlllIll];
      if (lIIIlIIllIlIlI(lllllllllllllllIIllIllIlIIllllll, SoundCategory.MASTER))
      {
        new Button(lllllllllllllllIIllIllIlIIllllll.getCategoryId(), width / lIllIIlIIlll[2] - lIllIIlIIlll[3] + lllllllllllllllIIllIllIlIlIIIIII % lIllIIlIIlll[2] * lIllIIlIIlll[4], height / lIllIIlIIlll[5] - lIllIIlIIlll[6] + lIllIIlIIlll[7] * (lllllllllllllllIIllIllIlIlIIIIII >> lIllIIlIIlll[1]), lllllllllllllllIIllIllIlIIllllll, lIllIIlIIlll[0]);
        "".length();
      }
      lllllllllllllllIIllIllIlIIlllIll++;
    }
    new GuiButton(lIllIIlIIlll[8], width / lIllIIlIIlll[2] - lIllIIlIIlll[9], height / lIllIIlIIlll[5] + lIllIIlIIlll[10], I18n.format(lIllIIlIIlIl[lIllIIlIIlll[11]], new Object[lIllIIlIIlll[0]]));
    "".length();
  }
  
  static
  {
    lIIIlIIllIlIIl();
    lIIIlIIllIlIII();
  }
  
  private static boolean lIIIlIIllIllIl(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIIllIllIIlllIIllI;
    return ??? == i;
  }
  
  private static void lIIIlIIllIlIIl()
  {
    lIllIIlIIlll = new int[17];
    lIllIIlIIlll[0] = ((95 + 125 - 85 + 42 ^ 3 + 127 - -24 + 34) & (0xDC ^ 0xBA ^ 0x62 ^ 0x9 ^ -" ".length()));
    lIllIIlIIlll[1] = " ".length();
    lIllIIlIIlll[2] = "  ".length();
    lIllIIlIIlll[3] = (107 + 87 - 86 + 38 + (0x2E ^ 0x7B) - (0xD3 ^ 0xBB) + (0xB5 ^ 0xA9));
    lIllIIlIIlll[4] = (67 + '' - 199 + 133);
    lIllIIlIIlll[5] = (0xFE ^ 0x93 ^ 0x6B ^ 0x0);
    lIllIIlIIlll[6] = (91 + 97 - 177 + 189 ^ 33 + 47 - -15 + 101);
    lIllIIlIIlll[7] = (0x99 ^ 0x8B ^ 0x41 ^ 0x4B);
    lIllIIlIIlll[8] = ('Ã' + '¦' - 324 + 163);
    lIllIIlIIlll[9] = (0x23 ^ 0x47);
    lIllIIlIIlll[10] = (97 + 55 - 115 + 131);
    lIllIIlIIlll[11] = "   ".length();
    lIllIIlIIlll[12] = (0xA4 ^ 0xB4 ^ 0x54 ^ 0x4B);
    lIllIIlIIlll[13] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIllIIlIIlll[14] = (0x50 ^ 0x54);
    lIllIIlIIlll[15] = (50 + 14 - 34 + 128 ^ '' + 29 - 32 + 20);
    lIllIIlIIlll[16] = (0x3D ^ 0x35);
  }
  
  private static boolean lIIIlIIllIlIlI(Object ???, Object arg1)
  {
    Object localObject;
    double lllllllllllllllIIllIllIIllIllIlI;
    return ??? != localObject;
  }
  
  protected String getSoundVolume(SoundCategory lllllllllllllllIIllIllIlIIlIIIlI)
  {
    ;
    ;
    ;
    float lllllllllllllllIIllIllIlIIlIIIIl = game_settings_4.getSoundLevel(lllllllllllllllIIllIllIlIIlIIIlI);
    if (lIIIlIIllIllll(lIIIlIIllIlllI(lllllllllllllllIIllIllIlIIlIIIIl, 0.0F)))
    {
      "".length();
      if (" ".length() == " ".length()) {
        break label76;
      }
      return null;
    }
    label76:
    return String.valueOf(new StringBuilder(String.valueOf((int)(lllllllllllllllIIllIllIlIIlIIIIl * 100.0F))).append(lIllIIlIIlIl[lIllIIlIIlll[14]]));
  }
  
  private static boolean lIIIlIIllIllll(int ???)
  {
    float lllllllllllllllIIllIllIIllIlIllI;
    return ??? == 0;
  }
  
  private static void lIIIlIIllIlIII()
  {
    lIllIIlIIlIl = new String[lIllIIlIIlll[15]];
    lIllIIlIIlIl[lIllIIlIIlll[0]] = lIIIlIIllIIIll("PjMcMR4fMA==", "qChXq");
    lIllIIlIIlIl[lIllIIlIIlll[1]] = lIIIlIIllIIlII("UUZRIS3rcNjKIVKASYQmAYTjeQpAmGpO", "dbyfn");
    lIllIIlIIlIl[lIllIIlIIlll[2]] = lIIIlIIllIIlII("a7NXZgH+mWSXirbD0dYyJg==", "heMmz");
    lIllIIlIIlIl[lIllIIlIIlll[11]] = lIIIlIIllIIlIl("3f1IZpmKHfvWJtT6EEuEyA==", "qJobQ");
    lIllIIlIIlIl[lIllIIlIIlll[14]] = lIIIlIIllIIlII("7ymYv5ddrfU=", "LOdaH");
  }
  
  private static String lIIIlIIllIIlII(String lllllllllllllllIIllIllIIlllIllIl, String lllllllllllllllIIllIllIIlllIlllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIllIllIIllllIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIllIIlllIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIllIllIIllllIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIIllIllIIllllIIIl.init(lIllIIlIIlll[2], lllllllllllllllIIllIllIIllllIIlI);
      return new String(lllllllllllllllIIllIllIIllllIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIllIIlllIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIllIllIIllllIIII)
    {
      lllllllllllllllIIllIllIIllllIIII.printStackTrace();
    }
    return null;
  }
  
  private static String lIIIlIIllIIIll(String lllllllllllllllIIllIllIlIIIIIlII, String lllllllllllllllIIllIllIlIIIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIllIllIlIIIIIlII = new String(Base64.getDecoder().decode(lllllllllllllllIIllIllIlIIIIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIllIllIlIIIIIIlI = new StringBuilder();
    char[] lllllllllllllllIIllIllIlIIIIIIIl = lllllllllllllllIIllIllIlIIIIIIll.toCharArray();
    int lllllllllllllllIIllIllIlIIIIIIII = lIllIIlIIlll[0];
    short lllllllllllllllIIllIllIIlllllIlI = lllllllllllllllIIllIllIlIIIIIlII.toCharArray();
    float lllllllllllllllIIllIllIIlllllIIl = lllllllllllllllIIllIllIIlllllIlI.length;
    double lllllllllllllllIIllIllIIlllllIII = lIllIIlIIlll[0];
    while (lIIIlIIlllIIII(lllllllllllllllIIllIllIIlllllIII, lllllllllllllllIIllIllIIlllllIIl))
    {
      char lllllllllllllllIIllIllIlIIIIIlIl = lllllllllllllllIIllIllIIlllllIlI[lllllllllllllllIIllIllIIlllllIII];
      "".length();
      "".length();
      if (" ".length() < 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIllIllIlIIIIIIlI);
  }
  
  private static boolean lIIIlIIllIlIll(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIIllIllIIlllIIIlI;
    return ??? >= i;
  }
  
  private static boolean lIIIlIIlllIIII(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIIllIllIIllIllllI;
    return ??? < i;
  }
  
  private static String lIIIlIIllIIlIl(String lllllllllllllllIIllIllIlIIIlIlII, String lllllllllllllllIIllIllIlIIIlIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIllIllIlIIIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIllIlIIIlIIll.getBytes(StandardCharsets.UTF_8)), lIllIIlIIlll[16]), "DES");
      Cipher lllllllllllllllIIllIllIlIIIlIllI = Cipher.getInstance("DES");
      lllllllllllllllIIllIllIlIIIlIllI.init(lIllIIlIIlll[2], lllllllllllllllIIllIllIlIIIlIlll);
      return new String(lllllllllllllllIIllIllIlIIIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIllIlIIIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIllIllIlIIIlIlIl)
    {
      lllllllllllllllIIllIllIlIIIlIlIl.printStackTrace();
    }
    return null;
  }
  
  public void drawScreen(int lllllllllllllllIIllIllIlIIlIlIIl, int lllllllllllllllIIllIllIlIIlIlIII, float lllllllllllllllIIllIllIlIIlIIlll)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIIllIllIlIIlIlllI.drawDefaultBackground();
    lllllllllllllllIIllIllIlIIlIlllI.drawCenteredString(fontRendererObj, field_146507_a, width / lIllIIlIIlll[2], lIllIIlIIlll[12], lIllIIlIIlll[13]);
    lllllllllllllllIIllIllIlIIlIlllI.drawScreen(lllllllllllllllIIllIllIlIIlIlIIl, lllllllllllllllIIllIllIlIIlIlIII, lllllllllllllllIIllIllIlIIlIIlll);
  }
  
  class Button
    extends GuiButton
  {
    public boolean mousePressed(Minecraft lllllllllllllllIlIlIIIlllIllIIlI, int lllllllllllllllIlIlIIIlllIllIlIl, int lllllllllllllllIlIlIIIlllIllIlII)
    {
      ;
      ;
      ;
      ;
      if (lllllIIlIIllI(lllllllllllllllIlIlIIIlllIllIlll.mousePressed(lllllllllllllllIlIlIIIlllIllIIlI, lllllllllllllllIlIlIIIlllIllIlIl, lllllllllllllllIlIlIIIlllIllIlII)))
      {
        field_146156_o = ((lllllllllllllllIlIlIIIlllIllIlIl - (xPosition + lIlIIIIlIlIl[6])) / (width - lIlIIIIlIlIl[7]));
        field_146156_o = MathHelper.clamp_float(field_146156_o, 0.0F, 1.0F);
        gameSettings.setSoundLevel(field_146153_r, field_146156_o);
        gameSettings.saveOptions();
        displayString = String.valueOf(new StringBuilder(String.valueOf(field_146152_s)).append(lIlIIIIlIIII[lIlIIIIlIlIl[6]]).append(getSoundVolume(field_146153_r)));
        field_146155_p = lIlIIIIlIlIl[4];
        return lIlIIIIlIlIl[4];
      }
      return lIlIIIIlIlIl[3];
    }
    
    protected int getHoverState(boolean lllllllllllllllIlIlIIIllllIIIllI)
    {
      return lIlIIIIlIlIl[3];
    }
    
    public Button(int lllllllllllllllIlIlIIIllllIlIIll, int lllllllllllllllIlIlIIIllllIIlIll, int lllllllllllllllIlIlIIIllllIIlIlI, SoundCategory lllllllllllllllIlIlIIIllllIIlIIl, boolean lllllllllllllllIlIlIIIllllIIlIII) {}
    
    protected void mouseDragged(Minecraft lllllllllllllllIlIlIIIlllIllllIl, int lllllllllllllllIlIlIIIlllIllllII, int lllllllllllllllIlIlIIIlllIllllll)
    {
      ;
      ;
      ;
      if (lllllIIlIIllI(visible))
      {
        if (lllllIIlIIllI(field_146155_p))
        {
          field_146156_o = ((lllllllllllllllIlIlIIIlllIllllII - (xPosition + lIlIIIIlIlIl[6])) / (width - lIlIIIIlIlIl[7]));
          field_146156_o = MathHelper.clamp_float(field_146156_o, 0.0F, 1.0F);
          gameSettings.setSoundLevel(field_146153_r, field_146156_o);
          gameSettings.saveOptions();
          displayString = String.valueOf(new StringBuilder(String.valueOf(field_146152_s)).append(lIlIIIIlIIII[lIlIIIIlIlIl[8]]).append(getSoundVolume(field_146153_r)));
        }
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        lllllllllllllllIlIlIIIllllIIIIlI.drawTexturedModalRect(xPosition + (int)(field_146156_o * (width - lIlIIIIlIlIl[7])), yPosition, lIlIIIIlIlIl[3], lIlIIIIlIlIl[9], lIlIIIIlIlIl[6], lIlIIIIlIlIl[2]);
        lllllllllllllllIlIlIIIllllIIIIlI.drawTexturedModalRect(xPosition + (int)(field_146156_o * (width - lIlIIIIlIlIl[7])) + lIlIIIIlIlIl[6], yPosition, lIlIIIIlIlIl[10], lIlIIIIlIlIl[9], lIlIIIIlIlIl[6], lIlIIIIlIlIl[2]);
      }
    }
    
    private static void lllllIIIlIlIl()
    {
      lIlIIIIlIIII = new String[lIlIIIIlIlIl[12]];
      lIlIIIIlIIII[lIlIIIIlIlIl[3]] = lllllIIIlIIIl("tIMvW2bPxt8=", "xhUBf");
      lIlIIIIlIIII[lIlIIIIlIlIl[4]] = lllllIIIlIIll("MxBBdOv4HS4508On4bhYcA==", "kOWCC");
      lIlIIIIlIIII[lIlIIIIlIlIl[5]] = lllllIIIlIlII("Y0Q=", "YdEVe");
      lIlIIIIlIIII[lIlIIIIlIlIl[8]] = lllllIIIlIlII("aHE=", "RQOzm");
      lIlIIIIlIIII[lIlIIIIlIlIl[6]] = lllllIIIlIlII("Q0E=", "yaLvs");
      lIlIIIIlIIII[lIlIIIIlIlIl[11]] = lllllIIIlIIll("7k09KqaJVGsb6xeL5gK+bzM5On2dBvhT", "vVXyM");
    }
    
    static
    {
      lllllIIlIIlIl();
      lllllIIIlIlIl();
    }
    
    public void mouseReleased(int lllllllllllllllIlIlIIIlllIlIlIlI, int lllllllllllllllIlIlIIIlllIlIlIIl)
    {
      ;
      ;
      if (lllllIIlIIllI(field_146155_p))
      {
        if (lllllIIlIlIIl(field_146153_r, SoundCategory.MASTER))
        {
          lllllllllllllllIlIlIIIlllIlIIlll = 1.0F;
          "".length();
          if (" ".length() > 0) {}
        }
        else
        {
          "".length();
        }
        mc.getSoundHandler().playSound(PositionedSoundRecord.create(new ResourceLocation(lIlIIIIlIIII[lIlIIIIlIlIl[11]]), 1.0F));
      }
      field_146155_p = lIlIIIIlIlIl[3];
    }
    
    private static String lllllIIIlIIIl(String lllllllllllllllIlIlIIIllIlIlIIll, String lllllllllllllllIlIlIIIllIlIlIlIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIlIlIIIllIlIlllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIIIllIlIlIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIlIlIIIllIlIllIll = Cipher.getInstance("Blowfish");
        lllllllllllllllIlIlIIIllIlIllIll.init(lIlIIIIlIlIl[5], lllllllllllllllIlIlIIIllIlIlllIl);
        return new String(lllllllllllllllIlIlIIIllIlIllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIIIllIlIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIlIlIIIllIlIllIIl)
      {
        lllllllllllllllIlIlIIIllIlIllIIl.printStackTrace();
      }
      return null;
    }
    
    private static String lllllIIIlIIll(String lllllllllllllllIlIlIIIlllIIllIlI, String lllllllllllllllIlIlIIIlllIIlIllI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIlIlIIIlllIIlllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIIIlllIIlIllI.getBytes(StandardCharsets.UTF_8)), lIlIIIIlIlIl[7]), "DES");
        Cipher lllllllllllllllIlIlIIIlllIIlllIl = Cipher.getInstance("DES");
        lllllllllllllllIlIlIIIlllIIlllIl.init(lIlIIIIlIlIl[5], lllllllllllllllIlIlIIIlllIIlllll);
        return new String(lllllllllllllllIlIlIIIlllIIlllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIIIlllIIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIlIlIIIlllIIllIll)
      {
        lllllllllllllllIlIlIIIlllIIllIll.printStackTrace();
      }
      return null;
    }
    
    private static boolean lllllIIlIlIll(int ???, int arg1)
    {
      int i;
      float lllllllllllllllIlIlIIIllIIlllllI;
      return ??? < i;
    }
    
    private static boolean lllllIIlIIllI(int ???)
    {
      byte lllllllllllllllIlIlIIIllIIllIlll;
      return ??? != 0;
    }
    
    private static String lllllIIIlIlII(String lllllllllllllllIlIlIIIllIlllIIlI, String lllllllllllllllIlIlIIIllIlllIllI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIlIlIIIllIlllIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlIlIIIllIlllIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIlIlIIIllIlllIlIl = new StringBuilder();
      char[] lllllllllllllllIlIlIIIllIlllIlII = lllllllllllllllIlIlIIIllIlllIllI.toCharArray();
      int lllllllllllllllIlIlIIIllIlllIIll = lIlIIIIlIlIl[3];
      Exception lllllllllllllllIlIlIIIllIllIllIl = lllllllllllllllIlIlIIIllIlllIIlI.toCharArray();
      boolean lllllllllllllllIlIlIIIllIllIllII = lllllllllllllllIlIlIIIllIllIllIl.length;
      short lllllllllllllllIlIlIIIllIllIlIll = lIlIIIIlIlIl[3];
      while (lllllIIlIlIll(lllllllllllllllIlIlIIIllIllIlIll, lllllllllllllllIlIlIIIllIllIllII))
      {
        char lllllllllllllllIlIlIIIllIllllIlI = lllllllllllllllIlIlIIIllIllIllIl[lllllllllllllllIlIlIIIllIllIlIll];
        "".length();
        "".length();
        if (((0xAB ^ 0xB4) & (0x89 ^ 0x96 ^ 0xFFFFFFFF)) != 0) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIlIlIIIllIlllIlIl);
    }
    
    public void playPressSound(SoundHandler lllllllllllllllIlIlIIIlllIlIlllI) {}
    
    private static boolean lllllIIlIlIIl(Object ???, Object arg1)
    {
      Object localObject;
      int lllllllllllllllIlIlIIIllIIlllIlI;
      return ??? == localObject;
    }
    
    private static void lllllIIlIIlIl()
    {
      lIlIIIIlIlIl = new int[13];
      lIlIIIIlIlIl[0] = (-(0xEC47 & 0x37F9) & 0xEDFF & 0x3776);
      lIlIIIIlIlIl[1] = (46 + 38 - 8 + 74);
      lIlIIIIlIlIl[2] = (122 + 31 - 135 + 119 ^ 89 + 12 - 70 + 126);
      lIlIIIIlIlIl[3] = ((0xFD ^ 0x96 ^ 0x50 ^ 0x1F) & (14 + 91 - 27 + 147 ^ 109 + '' - 166 + 111 ^ -" ".length()));
      lIlIIIIlIlIl[4] = " ".length();
      lIlIIIIlIlIl[5] = "  ".length();
      lIlIIIIlIlIl[6] = (33 + 27 - 30 + 168 ^ 80 + 51 - -31 + 32);
      lIlIIIIlIlIl[7] = (0x13 ^ 0x1B);
      lIlIIIIlIlIl[8] = "   ".length();
      lIlIIIIlIlIl[9] = (0x52 ^ 0x10);
      lIlIIIIlIlIl[10] = (71 + 31 - 88 + 182);
      lIlIIIIlIlIl[11] = (0x6B ^ 0x6E);
      lIlIIIIlIlIl[12] = (0x6E ^ 0x68);
    }
  }
}

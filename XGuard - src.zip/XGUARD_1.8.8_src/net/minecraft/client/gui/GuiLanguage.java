package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.Language;
import net.minecraft.client.resources.LanguageManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.GameSettings.Options;

public class GuiLanguage
  extends GuiScreen
{
  static
  {
    llIlIlIIlllIlI();
    llIlIlIIlIlllI();
  }
  
  private static boolean llIlIlIIllllII(int ???, int arg1)
  {
    int i;
    short llllllllllllllIlIIllIllIIllIllII;
    return ??? < i;
  }
  
  private static String llIlIlIIlIllII(String llllllllllllllIlIIllIllIIlllIIll, String llllllllllllllIlIIllIllIIlllIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIllIllIIllllIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIllIllIIlllIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIIllIllIIlllIlll = Cipher.getInstance("Blowfish");
      llllllllllllllIlIIllIllIIlllIlll.init(lIIIlIlllIlll[1], llllllllllllllIlIIllIllIIllllIII);
      return new String(llllllllllllllIlIIllIllIIlllIlll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIllIllIIlllIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIllIllIIlllIllI)
    {
      llllllllllllllIlIIllIllIIlllIllI.printStackTrace();
    }
    return null;
  }
  
  private static String llIlIlIIlIlIll(String llllllllllllllIlIIllIllIlIIllIlI, String llllllllllllllIlIIllIllIlIIlIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIllIllIlIIlllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIllIllIlIIlIlll.getBytes(StandardCharsets.UTF_8)), lIIIlIlllIlll[8]), "DES");
      Cipher llllllllllllllIlIIllIllIlIIlllII = Cipher.getInstance("DES");
      llllllllllllllIlIIllIllIlIIlllII.init(lIIIlIlllIlll[1], llllllllllllllIlIIllIllIlIIlllIl);
      return new String(llllllllllllllIlIIllIllIlIIlllII.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIllIllIlIIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIllIllIlIIllIll)
    {
      llllllllllllllIlIIllIllIlIIllIll.printStackTrace();
    }
    return null;
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIlIIllIllIlIlllIIl)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    if (llIlIlIIlllIll(enabled)) {
      switch (id)
      {
      case 5: 
        "".length();
        if (-(10 + 33 - 30 + 186 ^ '²' + '°' - 339 + 180) > 0) {}
        break;
      case 6: 
        mc.displayGuiScreen(parentScreen);
        "".length();
        if (null != null) {}
        break;
      case 100: 
        if (llIlIlIIlllIll(llllllllllllllIlIIllIllIlIlllIIl instanceof GuiOptionButton))
        {
          game_settings_3.setOptionValue(((GuiOptionButton)llllllllllllllIlIIllIllIlIlllIIl).returnEnumOptions(), lIIIlIlllIlll[9]);
          displayString = game_settings_3.getKeyBinding(GameSettings.Options.FORCE_UNICODE_FONT);
          ScaledResolution llllllllllllllIlIIllIllIlIllllIl = new ScaledResolution(mc);
          int llllllllllllllIlIIllIllIlIllllII = ScaledResolution.getScaledWidth();
          int llllllllllllllIlIIllIllIlIlllIll = llllllllllllllIlIIllIllIlIllllIl.getScaledHeight();
          llllllllllllllIlIIllIllIlIllllll.setWorldAndResolution(mc, llllllllllllllIlIIllIllIlIllllII, llllllllllllllIlIIllIllIlIlllIll);
          "".length();
          if ((0xE3 ^ 0xAF ^ 0x53 ^ 0x1A) <= 0) {}
        }
        break;
      default: 
        list.actionPerformed(llllllllllllllIlIIllIllIlIlllIIl);
      }
    }
  }
  
  private static String llIlIlIIlIllIl(String llllllllllllllIlIIllIllIlIIIlIlI, String llllllllllllllIlIIllIllIlIIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIllIllIlIIIlIlI = new String(Base64.getDecoder().decode(llllllllllllllIlIIllIllIlIIIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIIllIllIlIIIlIII = new StringBuilder();
    char[] llllllllllllllIlIIllIllIlIIIIlll = llllllllllllllIlIIllIllIlIIIlIIl.toCharArray();
    int llllllllllllllIlIIllIllIlIIIIllI = lIIIlIlllIlll[6];
    short llllllllllllllIlIIllIllIlIIIIIII = llllllllllllllIlIIllIllIlIIIlIlI.toCharArray();
    byte llllllllllllllIlIIllIllIIlllllll = llllllllllllllIlIIllIllIlIIIIIII.length;
    double llllllllllllllIlIIllIllIIllllllI = lIIIlIlllIlll[6];
    while (llIlIlIIllllII(llllllllllllllIlIIllIllIIllllllI, llllllllllllllIlIIllIllIIlllllll))
    {
      char llllllllllllllIlIIllIllIlIIIlIll = llllllllllllllIlIIllIllIlIIIIIII[llllllllllllllIlIIllIllIIllllllI];
      "".length();
      "".length();
      if (" ".length() != " ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIIllIllIlIIIlIII);
  }
  
  private static void llIlIlIIlllIlI()
  {
    lIIIlIlllIlll = new int[17];
    lIIIlIlllIlll[0] = (0xC7 ^ 0xA4 ^ 0x58 ^ 0x5F);
    lIIIlIlllIlll[1] = "  ".length();
    lIIIlIlllIlll[2] = (92 + 31 - 109 + 141);
    lIIIlIlllIlll[3] = (78 + 46 - 90 + 114 ^ 37 + 49 - -56 + 36);
    lIIIlIlllIlll[4] = (0x2 ^ 0x6E ^ 0x2A ^ 0x40);
    lIIIlIlllIlll[5] = ((0x3D ^ 0xC) + (0x10 ^ 0x1) - (0x36 ^ 0x21) + (0xF1 ^ 0x84));
    lIIIlIlllIlll[6] = ((0x88 ^ 0x99 ^ 0x91 ^ 0x99) & (5 + 97 - -10 + 20 ^ '' + 32 - 44 + 22 ^ -" ".length()));
    lIIIlIlllIlll[7] = (0xAC ^ 0xA0 ^ 0x96 ^ 0x9D);
    lIIIlIlllIlll[8] = (16 + 47 - -34 + 70 ^ 3 + 36 - -95 + 41);
    lIIIlIlllIlll[9] = " ".length();
    lIIIlIlllIlll[10] = (0x3 ^ 0x21 ^ 0x92 ^ 0xA0);
    lIIIlIlllIlll[11] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIIIlIlllIlll[12] = "   ".length();
    lIIIlIlllIlll[13] = (20 + 65 - 75 + 175 ^ '' + 38 - 103 + 102);
    lIIIlIlllIlll[14] = (36 + 93 - 34 + 54 ^ 111 + '¥' - 150 + 47);
    lIIIlIlllIlll[15] = (-(0xBC77 & 0x53AB) & 0xB8EF & 0x80D7B2);
    lIIIlIlllIlll[16] = (0x16 ^ 0x13);
  }
  
  public void drawScreen(int llllllllllllllIlIIllIllIlIllIIII, int llllllllllllllIlIIllIllIlIlIllll, float llllllllllllllIlIIllIllIlIlIlIlI)
  {
    ;
    ;
    ;
    ;
    list.drawScreen(llllllllllllllIlIIllIllIlIllIIII, llllllllllllllIlIIllIllIlIlIllll, llllllllllllllIlIIllIllIlIlIlIlI);
    llllllllllllllIlIIllIllIlIlIllIl.drawCenteredString(fontRendererObj, I18n.format(lIIIlIlllIIIl[lIIIlIlllIlll[9]], new Object[lIIIlIlllIlll[6]]), width / lIIIlIlllIlll[1], lIIIlIlllIlll[10], lIIIlIlllIlll[11]);
    llllllllllllllIlIIllIllIlIlIllIl.drawCenteredString(fontRendererObj, String.valueOf(new StringBuilder(lIIIlIlllIIIl[lIIIlIlllIlll[1]]).append(I18n.format(lIIIlIlllIIIl[lIIIlIlllIlll[12]], new Object[lIIIlIlllIlll[6]])).append(lIIIlIlllIIIl[lIIIlIlllIlll[13]])), width / lIIIlIlllIlll[1], height - lIIIlIlllIlll[14], lIIIlIlllIlll[15]);
    llllllllllllllIlIIllIllIlIlIllIl.drawScreen(llllllllllllllIlIIllIllIlIllIIII, llllllllllllllIlIIllIllIlIlIllll, llllllllllllllIlIIllIllIlIlIlIlI);
  }
  
  public void initGui()
  {
    ;
    forceUnicodeFontBtn = new GuiOptionButton(lIIIlIlllIlll[0], width / lIIIlIlllIlll[1] - lIIIlIlllIlll[2], height - lIIIlIlllIlll[3], GameSettings.Options.FORCE_UNICODE_FONT, game_settings_3.getKeyBinding(GameSettings.Options.FORCE_UNICODE_FONT));
    "".length();
    confirmSettingsBtn = new GuiOptionButton(lIIIlIlllIlll[4], width / lIIIlIlllIlll[1] - lIIIlIlllIlll[2] + lIIIlIlllIlll[5], height - lIIIlIlllIlll[3], I18n.format(lIIIlIlllIIIl[lIIIlIlllIlll[6]], new Object[lIIIlIlllIlll[6]]));
    "".length();
    list = new List(mc);
    list.registerScrollButtons(lIIIlIlllIlll[7], lIIIlIlllIlll[8]);
  }
  
  private static boolean llIlIlIIlllIll(int ???)
  {
    char llllllllllllllIlIIllIllIIllIlIlI;
    return ??? != 0;
  }
  
  private static void llIlIlIIlIlllI()
  {
    lIIIlIlllIIIl = new String[lIIIlIlllIlll[16]];
    lIIIlIlllIIIl[lIIIlIlllIlll[6]] = llIlIlIIlIlIll("AZG2ia1rfXvQL7gs6p0k6g==", "JeGti");
    lIIIlIlllIIIl[lIIIlIlllIlll[9]] = llIlIlIIlIllII("9uzpSyrVlHa81W4ARX7ThGRsVODi7iNb", "RZijf");
    lIIIlIlllIIIl[lIIIlIlllIlll[1]] = llIlIlIIlIllIl("cg==", "ZglEr");
    lIIIlIlllIIIl[lIIIlIlllIlll[12]] = llIlIlIIlIllII("1loLCeB6Pquil9yhu82x1qPEHFFm802I", "ifuZw");
    lIIIlIlllIIIl[lIIIlIlllIlll[13]] = llIlIlIIlIllIl("Tw==", "fqVOJ");
  }
  
  public GuiLanguage(GuiScreen llllllllllllllIlIIllIllIllIIllIl, GameSettings llllllllllllllIlIIllIllIllIIllII, LanguageManager llllllllllllllIlIIllIllIllIIlIll)
  {
    parentScreen = llllllllllllllIlIIllIllIllIIllIl;
    game_settings_3 = llllllllllllllIlIIllIllIllIIllII;
    languageManager = llllllllllllllIlIIllIllIllIIlIll;
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    llllllllllllllIlIIllIllIllIIIlIl.handleMouseInput();
    list.handleMouseInput();
  }
  
  class List
    extends GuiSlot
  {
    private static String llIllIIllIllIl(String llllllllllllllIlIIlIIlIIlIIlIlII, String llllllllllllllIlIIlIIlIIlIIlIIIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIIlIIlIIlIIlIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIlIIlIIlIIlIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIlIIlIIlIIlIIlIllI = Cipher.getInstance("Blowfish");
        llllllllllllllIlIIlIIlIIlIIlIllI.init(lIIIlllllIIII[6], llllllllllllllIlIIlIIlIIlIIlIlll);
        return new String(llllllllllllllIlIIlIIlIIlIIlIllI.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIlIIlIIlIIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIIlIIlIIlIIlIlIl)
      {
        llllllllllllllIlIIlIIlIIlIIlIlIl.printStackTrace();
      }
      return null;
    }
    
    private static boolean llIllIIllllIlI(int ???)
    {
      boolean llllllllllllllIlIIlIIlIIlIIIllIl;
      return ??? == 0;
    }
    
    private static void llIllIIllIlllI()
    {
      lIIIllllIllIl = new String[lIIIlllllIIII[5]];
      lIIIllllIllIl[lIIIlllllIIII[4]] = llIllIIllIllIl("fyyYnkcDAJD3YLfZMBVXiw==", "MvKMt");
    }
    
    protected int getContentHeight()
    {
      ;
      return llllllllllllllIlIIlIIlIIlIlIllIl.getSize() * lIIIlllllIIII[3];
    }
    
    protected void drawSlot(int llllllllllllllIlIIlIIlIIlIIlllIl, int llllllllllllllIlIIlIIlIIlIlIIIll, int llllllllllllllIlIIlIIlIIlIIlllII, int llllllllllllllIlIIlIIlIIlIlIIIIl, int llllllllllllllIlIIlIIlIIlIlIIIII, int llllllllllllllIlIIlIIlIIlIIlllll)
    {
      ;
      ;
      ;
      fontRendererObj.setBidiFlag(lIIIlllllIIII[5]);
      drawCenteredString(fontRendererObj, ((Language)languageMap.get(langCodeList.get(llllllllllllllIlIIlIIlIIlIIlllIl))).toString(), width / lIIIlllllIIII[6], llllllllllllllIlIIlIIlIIlIIlllII + lIIIlllllIIII[5], lIIIlllllIIII[7]);
      fontRendererObj.setBidiFlag(languageManager.getCurrentLanguage().isBidirectional());
    }
    
    static
    {
      llIllIIllllIIl();
      llIllIIllIlllI();
    }
    
    protected void drawBackground()
    {
      ;
      drawDefaultBackground();
    }
    
    protected int getSize()
    {
      ;
      return langCodeList.size();
    }
    
    public List(Minecraft llllllllllllllIlIIlIIlIIllIIlIlI)
    {
      llllllllllllllIlIIlIIlIIllIIlIII.<init>(llllllllllllllIlIIlIIlIIllIIlIlI, width, height, lIIIlllllIIII[0], height - lIIIlllllIIII[1] + lIIIlllllIIII[2], lIIIlllllIIII[3]);
      char llllllllllllllIlIIlIIlIIllIIIlII = languageManager.getLanguages().iterator();
      "".length();
      if (-" ".length() > (0xB5 ^ 0xB1)) {
        throw null;
      }
      while (!llIllIIllllIlI(llllllllllllllIlIIlIIlIIllIIIlII.hasNext()))
      {
        Language llllllllllllllIlIIlIIlIIllIIlIIl = (Language)llllllllllllllIlIIlIIlIIllIIIlII.next();
        "".length();
        "".length();
      }
    }
    
    private static void llIllIIllllIIl()
    {
      lIIIlllllIIII = new int[8];
      lIIIlllllIIII[0] = (4 + 35 - 31 + 143 ^ 103 + '' - 123 + 63);
      lIIIlllllIIII[1] = ('' + 'É' - 299 + 161 ^ 59 + 62 - 61 + 92);
      lIIIlllllIIII[2] = (0x15 ^ 0xB ^ 0x6C ^ 0x76);
      lIIIlllllIIII[3] = (0x23 ^ 0x31);
      lIIIlllllIIII[4] = ((0x38 ^ 0x19 ^ 0x49 ^ 0x7D) & (0x75 ^ 0x5E ^ 0x89 ^ 0xB7 ^ -" ".length()));
      lIIIlllllIIII[5] = " ".length();
      lIIIlllllIIII[6] = "  ".length();
      lIIIlllllIIII[7] = (0xFFFFFFFF & 0xFFFFFF);
    }
    
    protected boolean isSelected(int llllllllllllllIlIIlIIlIIlIlIllll)
    {
      ;
      ;
      return ((String)langCodeList.get(llllllllllllllIlIIlIIlIIlIlIllll)).equals(languageManager.getCurrentLanguage().getLanguageCode());
    }
    
    protected void elementClicked(int llllllllllllllIlIIlIIlIIlIllllII, boolean llllllllllllllIlIIlIIlIIlIlllIll, int llllllllllllllIlIIlIIlIIlIlllIlI, int llllllllllllllIlIIlIIlIIlIlllIIl)
    {
      ;
      ;
      ;
      Language llllllllllllllIlIIlIIlIIlIlllIII = (Language)languageMap.get(langCodeList.get(llllllllllllllIlIIlIIlIIlIllllII));
      languageManager.setCurrentLanguage(llllllllllllllIlIIlIIlIIlIlllIII);
      game_settings_3.language = llllllllllllllIlIIlIIlIIlIlllIII.getLanguageCode();
      mc.refreshResources();
      if ((llIllIIllllIlI(languageManager.isCurrentLocaleUnicode())) && (llIllIIllllIlI(game_settings_3.forceUnicodeFont)))
      {
        "".length();
        if (null == null) {
          break label118;
        }
      }
      label118:
      lIIIlllllIIII[4].setUnicodeFlag(lIIIlllllIIII[5]);
      fontRendererObj.setBidiFlag(languageManager.isCurrentLanguageBidirectional());
      confirmSettingsBtn.displayString = I18n.format(lIIIllllIllIl[lIIIlllllIIII[4]], new Object[lIIIlllllIIII[4]]);
      forceUnicodeFontBtn.displayString = game_settings_3.getKeyBinding(GameSettings.Options.FORCE_UNICODE_FONT);
      game_settings_3.saveOptions();
    }
  }
}

package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.GameSettings.Options;
import net.minecraft.util.MathHelper;

public class GuiOptionSlider
  extends GuiButton
{
  public GuiOptionSlider(int llllllllllllllIllllIIIIlllllIIll, int llllllllllllllIllllIIIIllllIlIlI, int llllllllllllllIllllIIIIlllllIIIl, GameSettings.Options llllllllllllllIllllIIIIlllllIIII, float llllllllllllllIllllIIIIllllIIlll, float llllllllllllllIllllIIIIllllIlllI)
  {
    llllllllllllllIllllIIIIlllllIlII.<init>(llllllllllllllIllllIIIIlllllIIll, llllllllllllllIllllIIIIllllIlIlI, llllllllllllllIllllIIIIllllIlIIl, lllIIIIIlIll[0], lllIIIIIlIll[1], lllIIIIIlIlI[lllIIIIIlIll[2]]);
    options = llllllllllllllIllllIIIIlllllIIII;
    field_146132_r = llllllllllllllIllllIIIIllllIIlll;
    field_146131_s = llllllllllllllIllllIIIIllllIlllI;
    Minecraft llllllllllllllIllllIIIIllllIllIl = Minecraft.getMinecraft();
    sliderValue = llllllllllllllIllllIIIIlllllIIII.normalizeValue(gameSettings.getOptionFloatValue(llllllllllllllIllllIIIIlllllIIII));
    displayString = gameSettings.getKeyBinding(llllllllllllllIllllIIIIlllllIIII);
  }
  
  public GuiOptionSlider(int llllllllllllllIllllIIIlIIIIIIlIl, int llllllllllllllIllllIIIlIIIIIIlII, int llllllllllllllIllllIIIIllllllllI, GameSettings.Options llllllllllllllIllllIIIIlllllllIl)
  {
    llllllllllllllIllllIIIlIIIIIIIIl.<init>(llllllllllllllIllllIIIlIIIIIIlIl, llllllllllllllIllllIIIIlllllllll, llllllllllllllIllllIIIIllllllllI, llllllllllllllIllllIIIIlllllllIl, 0.0F, 1.0F);
  }
  
  private static boolean lIlIlIllIlllIl(int ???)
  {
    double llllllllllllllIllllIIIIllIllIllI;
    return ??? != 0;
  }
  
  private static void lIlIlIllIllIll()
  {
    lllIIIIIlIlI = new String[lllIIIIIlIll[7]];
    lllIIIIIlIlI[lllIIIIIlIll[2]] = lIlIlIllIllIlI("TeoU5mt9IlE=", "zrvwI");
  }
  
  protected int getHoverState(boolean llllllllllllllIllllIIIIllllIIIll)
  {
    return lllIIIIIlIll[2];
  }
  
  static
  {
    lIlIlIllIlllII();
    lIlIlIllIllIll();
  }
  
  private static String lIlIlIllIllIlI(String llllllllllllllIllllIIIIllIllllIl, String llllllllllllllIllllIIIIllIllllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllllIIIIlllIIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllllIIIIllIllllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllllIIIIllIllllll = Cipher.getInstance("Blowfish");
      llllllllllllllIllllIIIIllIllllll.init(lllIIIIIlIll[8], llllllllllllllIllllIIIIlllIIIIII);
      return new String(llllllllllllllIllllIIIIllIllllll.doFinal(Base64.getDecoder().decode(llllllllllllllIllllIIIIllIllllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllllIIIIllIlllllI)
    {
      llllllllllllllIllllIIIIllIlllllI.printStackTrace();
    }
    return null;
  }
  
  private static void lIlIlIllIlllII()
  {
    lllIIIIIlIll = new int[9];
    lllIIIIIlIll[0] = (96 + '' - 207 + 128);
    lllIIIIIlIll[1] = (0x22 ^ 0x36);
    lllIIIIIlIll[2] = ((0x4E ^ 0x11) & (0x2A ^ 0x75 ^ 0xFFFFFFFF));
    lllIIIIIlIll[3] = (0 + '' - 82 + 89 ^ 38 + 12 - 21 + 121);
    lllIIIIIlIll[4] = (66 + 4 - -86 + 8 ^ 74 + 89 - 8 + 17);
    lllIIIIIlIll[5] = (0x94 ^ 0x86 ^ 0x5B ^ 0xB);
    lllIIIIIlIll[6] = ((0x22 ^ 0x4A) + (23 + 127 - 63 + 76) - (61 + 37 - 16 + 160) + (39 + 29 - -5 + 98));
    lllIIIIIlIll[7] = " ".length();
    lllIIIIIlIll[8] = "  ".length();
  }
  
  public void mouseReleased(int llllllllllllllIllllIIIIlllIIIlll, int llllllllllllllIllllIIIIlllIIIllI)
  {
    ;
    dragging = lllIIIIIlIll[2];
  }
  
  public boolean mousePressed(Minecraft llllllllllllllIllllIIIIlllIIllII, int llllllllllllllIllllIIIIlllIIllll, int llllllllllllllIllllIIIIlllIIlIlI)
  {
    ;
    ;
    ;
    ;
    if (lIlIlIllIlllIl(llllllllllllllIllllIIIIlllIlIIIl.mousePressed(llllllllllllllIllllIIIIlllIIllII, llllllllllllllIllllIIIIlllIIllll, llllllllllllllIllllIIIIlllIIlIlI)))
    {
      sliderValue = ((llllllllllllllIllllIIIIlllIIllll - (xPosition + lllIIIIIlIll[3])) / (width - lllIIIIIlIll[4]));
      sliderValue = MathHelper.clamp_float(sliderValue, 0.0F, 1.0F);
      gameSettings.setOptionFloatValue(options, options.denormalizeValue(sliderValue));
      displayString = gameSettings.getKeyBinding(options);
      dragging = lllIIIIIlIll[7];
      return lllIIIIIlIll[7];
    }
    return lllIIIIIlIll[2];
  }
  
  protected void mouseDragged(Minecraft llllllllllllllIllllIIIIlllIllIII, int llllllllllllllIllllIIIIlllIlIlll, int llllllllllllllIllllIIIIlllIllIll)
  {
    ;
    ;
    ;
    ;
    if (lIlIlIllIlllIl(visible))
    {
      if (lIlIlIllIlllIl(dragging))
      {
        sliderValue = ((llllllllllllllIllllIIIIlllIlIlll - (xPosition + lllIIIIIlIll[3])) / (width - lllIIIIIlIll[4]));
        sliderValue = MathHelper.clamp_float(sliderValue, 0.0F, 1.0F);
        float llllllllllllllIllllIIIIlllIllIlI = options.denormalizeValue(sliderValue);
        gameSettings.setOptionFloatValue(options, llllllllllllllIllllIIIIlllIllIlI);
        sliderValue = options.normalizeValue(llllllllllllllIllllIIIIlllIllIlI);
        displayString = gameSettings.getKeyBinding(options);
      }
      llllllllllllllIllllIIIIlllIllIII.getTextureManager().bindTexture(buttonTextures);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      llllllllllllllIllllIIIIlllIllllI.drawTexturedModalRect(xPosition + (int)(sliderValue * (width - lllIIIIIlIll[4])), yPosition, lllIIIIIlIll[2], lllIIIIIlIll[5], lllIIIIIlIll[3], lllIIIIIlIll[1]);
      llllllllllllllIllllIIIIlllIllllI.drawTexturedModalRect(xPosition + (int)(sliderValue * (width - lllIIIIIlIll[4])) + lllIIIIIlIll[3], yPosition, lllIIIIIlIll[6], lllIIIIIlIll[5], lllIIIIIlIll[3], lllIIIIIlIll[1]);
    }
  }
}

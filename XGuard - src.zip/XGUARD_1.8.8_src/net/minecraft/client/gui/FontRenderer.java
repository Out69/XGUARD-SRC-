package net.minecraft.client.gui;

import com.ibm.icu.text.ArabicShaping;
import com.ibm.icu.text.ArabicShapingException;
import com.ibm.icu.text.Bidi;
import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.IResource;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourceManagerReloadListener;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.ResourceLocation;
import optfine.Config;
import org.apache.commons.io.IOUtils;
import org.lwjgl.opengl.GL11;

public class FontRenderer
  implements IResourceManagerReloadListener
{
  private void readCustomCharWidths()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    String lllIIIIlIIIlIlI = locationFontTexture.getResourcePath();
    String lllIIIIlIIIlIIl = llllll[lIIIIII[16]];
    if (lllIlIII(lllIIIIlIIIlIlI.endsWith(lllIIIIlIIIlIIl)))
    {
      String lllIIIIlIIIlIII = String.valueOf(new StringBuilder(String.valueOf(lllIIIIlIIIlIlI.substring(lIIIIII[0], lllIIIIlIIIlIlI.length() - lllIIIIlIIIlIIl.length()))).append(llllll[lIIIIII[27]]));
      try
      {
        ResourceLocation lllIIIIlIIIIlll = new ResourceLocation(locationFontTexture.getResourceDomain(), lllIIIIlIIIlIII);
        InputStream lllIIIIlIIIIllI = Config.getResourceStream(Config.getResourceManager(), lllIIIIlIIIIlll);
        if (llllIlII(lllIIIIlIIIIllI)) {
          return;
        }
        Config.log(String.valueOf(new StringBuilder(llllll[lIIIIII[28]]).append(lllIIIIlIIIlIII)));
        Properties lllIIIIlIIIIlIl = new Properties();
        lllIIIIlIIIIlIl.load(lllIIIIlIIIIllI);
        lllIIIIIlllIlII = lllIIIIlIIIIlIl.keySet().iterator();
        "".length();
        if ((0x6C ^ 0x5A ^ 0x2F ^ 0x1D) != (2 + 40 - -91 + 3 ^ 96 + 7 - -16 + 21)) {
          return;
        }
        while (!lllIllII(lllIIIIIlllIlII.hasNext()))
        {
          Object lllIIIIlIIIIlII = lllIIIIIlllIlII.next();
          String lllIIIIlIIIIIll = (String)lllIIIIlIIIIlII;
          String lllIIIIlIIIIIlI = llllll[lIIIIII[29]];
          if (lllIlIII(lllIIIIlIIIIIll.startsWith(lllIIIIlIIIIIlI)))
          {
            String lllIIIIlIIIIIIl = lllIIIIlIIIIIll.substring(lllIIIIlIIIIIlI.length());
            int lllIIIIlIIIIIII = Config.parseInt(lllIIIIlIIIIIIl, lIIIIII[22]);
            if ((llllIlIl(lllIIIIlIIIIIII)) && (lllIlIll(lllIIIIlIIIIIII, charWidth.length)))
            {
              String lllIIIIIlllllll = lllIIIIlIIIIlIl.getProperty(lllIIIIlIIIIIll);
              float lllIIIIIllllllI = Config.parseFloat(lllIIIIIlllllll, -1.0F);
              if (llllIlIl(llllllIl(lllIIIIIllllllI, 0.0F))) {
                charWidth[lllIIIIlIIIIIII] = lllIIIIIllllllI;
              }
            }
          }
        }
        "".length();
        if (null != null) {}
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
        "".length();
        if (((0x2 ^ 0x1D) & (0xBD ^ 0xA2 ^ 0xFFFFFFFF)) < 0) {}
      }
      catch (IOException lllIIIIIlllllIl)
      {
        lllIIIIIlllllIl.printStackTrace();
      }
    }
  }
  
  private static boolean llllIlII(Object ???)
  {
    String lllIIIIIIIlIlIl;
    return ??? == null;
  }
  
  private static boolean lllIllII(int ???)
  {
    double lllIIIIIIIlIIIl;
    return ??? == 0;
  }
  
  private static int llllllII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public int splitStringWidth(String lllIIIlIIIIlllI, int lllIIIlIIIIllIl)
  {
    ;
    ;
    ;
    return FONT_HEIGHT * lllIIIlIIIIllII.listFormattedStringToWidth(lllIIIlIIIIlIll, lllIIIlIIIIllIl).size();
  }
  
  private static boolean lllllIII(int ???)
  {
    boolean lllIIIIIIIIlIll;
    return ??? > 0;
  }
  
  private static void lllIIlIl()
  {
    llllll = new String[lIIIIII[53]];
    llllll[lIIIIII[0]] = lllIIIlI("auyrjeiB1lmehftr6SLJEg==", "OpjEQ");
    llllll[lIIIIII[5]] = lllIIIlI("7MEfWW6znKGPTMyx5Tbdoj5L17wVloEY", "oPjDQ");
    llllll[lIIIIII[8]] = lllIIIll("eV4WIMIUmqPP+YQNytnx3fv9YXgyKQNAjUigscQzVh3lB2NCnH0O44/owcl0+BD04JjfNzwuT6PgIfdfyT9cw+Prqn0uZ+yaDhy22hEIdlF3Uv4Ffm3tV0Am1Ofx/FJti6CZW6tc4kIedg/l7dg8RIfmau/S5v9Ghg+qEeDZc6P4GLD1iAlzR2sYWOLCCjz4L2rwZjEStsbz4O/GYph5DgbiV/qV9pbPN7wEE+wDdSBRPGIbc+9iXEJSI+AR3dF1jYflqUhNysR9gVNbtHoTLopMalbIaMvekZFnGKqwl4q4vHmel6Qm+OUfjX0/E6+hD+at3cxbSslW4ydhWjgEZuneyJ42kQKDgkhcRcSXqKIunSlllBuAnI3VdM06H3AMpZF8mSY/NgnzGA5GDYuZbXkb3gZZrUa3mo0ykTrPUFRDHA7FWkaqwn27/htq8J+ZMrP6kwgLUZvH23n+TiMbnvFyjDKDdGnrEZi624Q4NpDeoEeCe/t2qllcBHmW7JOfBt2KH3/OefgRE03nxbPPdXjCxOqg0HhWAiPVfTLXj/sXIolW301YPNghO7++NZz5j1Oae7CxyWRamJmeOMrIOhbJ51zQvPOd+YZpdm6LnNjfRpptsoEWTQ==", "zcjfq");
    llllll[lIIIIII[6]] = lllIIIll("Q+/0Ab4oMbLUBZ8GRIEzRkyAc0pwFSRoPw9da5yGPoMF5uJDCjlOGw==", "AgjWu");
    llllll[lIIIIII[17]] = lllIIlII("YkNzdU5nRHZ+QzMQIiIfNBktKxQ9AA==", "RrAFz");
    llllll[lIIIIII[23]] = lllIIlII("wqjCosKWwo3ChcKjwq7Ch8KRwprCssK8wrfCsMWQxZjFksSGxJbEkcS3xJfEocS7yYhoY1RFT2hjdGRtS0dxY2hASn5uY0VNe3V+WlBgcHlfW21/dFReanoPKSEXAQouJBwMBSMvGQsAODIGFhs9NQMdFjI4CBgRNwM1JywMBjIiJwEJPykiBgwkND0bFyEzOBAaLj4zFR1UwoLCs8KBwoHCsMKlwqrCj8KJwr/CrcKgwobCj8KQwoDChsKOwqXCoMKzwr3Ck8KawqvCk8KTwpDDgMKMwpLHncKJwo7Cp8K/wr7CucOJw67DusOhw4TDnsOow6TDpMOT4pey4peG4peW4pWN4pWM4pSC4pS24pST4pSa4pSL4pSy4pSD4pSY4pST4pSz4pWz4pWA4pWx4pWj4pW04pWj4pWo4pSb4pSQ4pSy4pS34pS94pSj4pSv4pS44pSP4pSz4pSt4pSr4pSN4pS64pSM4pSX4pSc4pSD4pSJ4pWM4pWJ4peH4pes4pev4peE4peFz77Pms+wzpTPps6Mz5TOp8+yz53Pps+c4om94omR4omN4omm4oiJw5LiiLHiiKHija/ijYnClOKInMO14omWw5/iibnigKvDt+KXr2g=", "hcTEO");
    llllll[lIIIIII[10]] = lllIIIll("biH34wjoXmfo5pCbfUe3SkyO+fbwIHYjiQf2zrzCLVN6LUYtXgnLyiCknsGsFv3A1SXcAnl6A330RfU35+LoXb1lsKkeDUVUZn2lq5CS0quRUQGYuUA/q/MgXZbDTA0C28rDTG4sc7gE3xEJDwB6nHndJ32XQs60yrz3mQpGdrct/Suy0Banl3hOzbS76mlcSr3t/iyov/HsjKpgLKLoS+mjm2VCZDuv/NKS/6fgYqlhTq4/AdqlO2fRYiSmWjwCiXAs6nZ+ByxD1KWluceyoNXPr3WnMkrS7OTAbMDf7j9+d9gBj3/yBqc18Elx6vR/vPX02XbNBW83PAvD+LmHF6u5cH0ByXYTv3cvwqCmynwrtQJgHjXMV3CiIIJdF7JBh+ucyzbY7K2hXhDkQFet/1i0DG4Q08RvM4LAKglkz44Ulyf7EdSI/DHgO3w2UjE82q0pMoic3wTj9v3y1WWKwxLdvrWRvVI3x+GnZaF89euxnwvOoqAh5aDgxHCFxUkOjF3/Ca1/hCktPUvTCIZgoi2N3ISHGJPY5yDMoLOnzjtscu+pJXjogIRFYbgsoUtnqIx6Zgd+4XE0T5O9Kerj8HMhmVjzJSHLxzj2cYbfCNrKTT7x3jQJEA==", "RorGP");
    llllll[lIIIIII[32]] = lllIIIlI("hYrLiRR/jRAvAt9Cq5ehO2/enT5m+jN6jHxY/3GzLgzQbhRBJ230dRRw30ZyD3f3TBWJ6C+kIjZ35MC+DTDuw1+lY5iKwvOGhFaKIVFoWkwViqExGR3/UkjkWSJn6MjOVjKqPqW0BvjWAwz8Ex/bgwKsbesKpoc1kIABbfiWYdJ6Cbg/LTxbDhBvOB5nxshaXcS6c2FXWy9kFKKAjh3CdwOay3hnubeqZ4iLOdQ5sKTYNPUbumbP/jaPRnPH+rGI1NZOzGXGVrOoRLL3pkWQiFYftg6EkJrUklng6DGedVK89Pf5wLna2YIbBx6qpkr3TSvfBx2IrpjvKFvSDBv4yXoz8TJWt78s+aUXaaZJkNSzYh+APTyaMOwy/wOYqxyz06QR2CC0yTamdgq4q9aHWyiE3nQkxcqJ60tL81CGUWs3pm1RbfTaOUUr8CzZzq65XVc9SRY0YPosVYTBTM/ndh+SfUDr8RzXClb48T5ZLuGgOaFcBkEk/9ECkTYTdHvcRoL3/KOrC5+Cdyw/pDzv3PyzhZy4M4klKTjVR5JRF4tKTl9OwN0oPRAICxKW6NTuRGDig5X2DneqU1vpFKpORHUi/u0n/uUCQcBMleEJHxRpdjAOfOoe9w==", "mYKyx");
    llllll[lIIIIII[19]] = lllIIlII("wpbCqsKnwrLCpcKdwqbCtsKuwrrCjMK0wobCj8WwxabFmsS3xKnEscSJxJ/EkMSEyahWa2V6b1ZrRVtNdU9AXEh+Qk9RQ3tFSkpeZFhRT1lhU1xAVGpWW0UvFykmPioQLC0zJR0nKDQgBjo3KTsDPTIiNgwwOScxCQsEGAwyDgMdBz8BDhYCOAQVCx0lHxAMGC4SHwETKxVlwr3Ck8K/wonCgcKaworCscKBwo7CksKAwrjCh8Khwr/CpsKwwq3CkcKMwp3CrcKSwprCrMKzwq7DiMK9wq3HvcK3wobClsKAwp7Ch8OBw5/DhcOBw7rDlsOZw5vDhMOt4pe64pe34pep4pWt4pWy4pSK4pSH4pSs4pS64pS14pS64pSy4pSn4pSz4pSN4pW74pWx4pWO4pWD4pWK4pWr4pWZ4pSk4pSw4pSM4pS/4pSM4pSc4pSP4pSG4pSH4pSC4pSS4pSL4pSz4pSy4pS94pSo4pS84pS94pSB4pW94pW24pen4peS4pen4pe14pe6z57PpM+4zqXPmc6sz6rOr8+Dz6LPhs+i4om14omg4omy4omG4oi3w5riiIDiiJ7ijY/ijbfCnOKIrcOK4om2w6HiibHigJrDiOKXj1Y=", "Vkezo");
    llllll[lIIIIII[2]] = lllIIIlI("wNsqYpLboV4=", "molqM");
    llllll[lIIIIII[40]] = lllIIlII("eg==", "pimkT");
    llllll[lIIIIII[13]] = lllIIlII("TQ==", "GGIqS");
    llllll[lIIIIII[49]] = lllIIIlI("X139XrRVI/U=", "KDAXO");
    llllll[lIIIIII[50]] = lllIIIll("EwsICKcA7yg=", "UMMKk");
    llllll[lIIIIII[51]] = lllIIIlI("I4r3QCEe2GI=", "WRqyo");
    llllll[lIIIIII[24]] = lllIIIlI("0SsWFXp9I8oNDeCJQgJ7MVAsYo2zMhvZ", "uxahO");
    llllll[lIIIIII[16]] = lllIIIll("3S1em2Ee2OI=", "bkGqL");
    llllll[lIIIIII[27]] = lllIIlII("dzM+KDc8MTguIio=", "YCLGG");
    llllll[lIIIIII[28]] = lllIIIll("obflCC7+gWVEf42q/UypaA==", "MfqTE");
    llllll[lIIIIII[29]] = lllIIIlI("BjO5uY2aFOY=", "enDLp");
    llllll[lIIIIII[30]] = lllIIlII("Agw5FxsEDDJM", "viAcn");
    llllll[lIIIIII[31]] = lllIIlII("GxEZGQYVGgwKXQ==", "vrixr");
  }
  
  private void loadGlyphTexture(int lllIIlIIlIlIIIl)
  {
    ;
    ;
    renderEngine.bindTexture(lllIIlIIlIlIIlI.getUnicodePageLocation(lllIIlIIlIlIIIl));
  }
  
  public int drawString(String lllIIlIIIIIIllI, float lllIIIlllllllIl, float lllIIlIIIIIIlII, int lllIIlIIIIIIIll, boolean lllIIIllllllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.enableAlpha();
    lllIIIlllllllll.resetStyles();
    int lllIIlIIIIIIIII;
    if (lllIlIII(lllIIIllllllIlI))
    {
      int lllIIlIIIIIIIIl = lllIIIlllllllll.renderString(lllIIlIIIIIIllI, lllIIIlllllllIl + 1.0F, lllIIlIIIIIIlII + 1.0F, lllIIlIIIIIIIll, lIIIIII[5]);
      lllIIlIIIIIIIIl = Math.max(lllIIlIIIIIIIIl, lllIIIlllllllll.renderString(lllIIlIIIIIIllI, lllIIIlllllllIl, lllIIlIIIIIIlII, lllIIlIIIIIIIll, lIIIIII[0]));
      "".length();
      if (null != null) {
        return (33 + 15 - 16 + 110 ^ 38 + 117 - 31 + 15) & (75 + '' - 154 + 117 ^ '' + 33 - 152 + 164 ^ -" ".length());
      }
    }
    else
    {
      lllIIlIIIIIIIII = lllIIIlllllllll.renderString(lllIIlIIIIIIllI, lllIIIlllllllIl, lllIIlIIIIIIlII, lllIIlIIIIIIIll, lIIIIII[0]);
    }
    return lllIIlIIIIIIIII;
  }
  
  public boolean getBidiFlag()
  {
    ;
    return bidiFlag;
  }
  
  private int renderStringAligned(String lllIIIllIllIIlI, int lllIIIllIllIIIl, int lllIIIllIlllIII, int lllIIIllIllIlll, int lllIIIllIlIlllI, boolean lllIIIllIlIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIlIII(bidiFlag))
    {
      int lllIIIllIllIlII = lllIIIllIllIIll.getStringWidth(lllIIIllIllIIll.bidiReorder(lllIIIllIllIIlI));
      lllIIIllIllIIIl = lllIIIllIllIIIl + lllIIIllIllIlll - lllIIIllIllIlII;
    }
    return lllIIIllIllIIll.renderString(lllIIIllIllIIlI, lllIIIllIllIIIl, lllIIIllIllIIII, lllIIIllIlIlllI, lllIIIllIlIllIl);
  }
  
  private static String lllIIlII(String lllIIIIIlIIllll, String lllIIIIIlIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllIIIIIlIIllll = new String(Base64.getDecoder().decode(lllIIIIIlIIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllIIIIIlIlIIlI = new StringBuilder();
    char[] lllIIIIIlIlIIIl = lllIIIIIlIIlllI.toCharArray();
    int lllIIIIIlIlIIII = lIIIIII[0];
    double lllIIIIIlIIlIlI = lllIIIIIlIIllll.toCharArray();
    float lllIIIIIlIIlIIl = lllIIIIIlIIlIlI.length;
    String lllIIIIIlIIlIII = lIIIIII[0];
    while (lllIlIll(lllIIIIIlIIlIII, lllIIIIIlIIlIIl))
    {
      char lllIIIIIlIlIlIl = lllIIIIIlIIlIlI[lllIIIIIlIIlIII];
      "".length();
      "".length();
      if (" ".length() != " ".length()) {
        return null;
      }
    }
    return String.valueOf(lllIIIIIlIlIIlI);
  }
  
  private float renderUnicodeChar(char lllIIlIIlIIIIll, boolean lllIIlIIIllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIllII(glyphWidth[lllIIlIIIllIlll])) {
      return 0.0F;
    }
    int lllIIlIIlIIIIIl = lllIIlIIIllIlll / lIIIIII[1];
    lllIIlIIlIIIlII.loadGlyphTexture(lllIIlIIlIIIIIl);
    int lllIIlIIlIIIIII = glyphWidth[lllIIlIIIllIlll] >>> lIIIIII[17];
    int lllIIlIIIllllll = glyphWidth[lllIIlIIIllIlll] & lIIIIII[24];
    float lllIIlIIIlllllI = lllIIlIIlIIIIII;
    float lllIIlIIIllllIl = lllIIlIIIllllll + lIIIIII[5];
    float lllIIlIIIllllII = lllIIlIIIllIlll % lIIIIII[16] * lIIIIII[16] + lllIIlIIIlllllI;
    float lllIIlIIIlllIll = (lllIIlIIIllIlll & lIIIIII[18]) / lIIIIII[16] * lIIIIII[16];
    float lllIIlIIIlllIlI = lllIIlIIIllllIl - lllIIlIIIlllllI - 0.02F;
    if (lllIlIII(lllIIlIIIllIllI))
    {
      "".length();
      if (-" ".length() < " ".length()) {
        break label163;
      }
      return 0.0F;
    }
    label163:
    float lllIIlIIIlllIIl = 0.0F;
    GL11.glBegin(lIIIIII[23]);
    GL11.glTexCoord2f(lllIIlIIIllllII / 256.0F, lllIIlIIIlllIll / 256.0F);
    GL11.glVertex3f(posX + lllIIlIIIlllIIl, posY, 0.0F);
    GL11.glTexCoord2f(lllIIlIIIllllII / 256.0F, (lllIIlIIIlllIll + 15.98F) / 256.0F);
    GL11.glVertex3f(posX - lllIIlIIIlllIIl, posY + 7.99F, 0.0F);
    GL11.glTexCoord2f((lllIIlIIIllllII + lllIIlIIIlllIlI) / 256.0F, lllIIlIIIlllIll / 256.0F);
    GL11.glVertex3f(posX + lllIIlIIIlllIlI / 2.0F + lllIIlIIIlllIIl, posY, 0.0F);
    GL11.glTexCoord2f((lllIIlIIIllllII + lllIIlIIIlllIlI) / 256.0F, (lllIIlIIIlllIll + 15.98F) / 256.0F);
    GL11.glVertex3f(posX + lllIIlIIIlllIlI / 2.0F - lllIIlIIIlllIIl, posY + 7.99F, 0.0F);
    GL11.glEnd();
    return (lllIIlIIIllllIl - lllIIlIIIlllllI) / 2.0F + 1.0F;
  }
  
  public int getCharWidth(char lllIIIlIlllllll)
  {
    ;
    ;
    return Math.round(lllIIIllIIIIIII.getCharWidthFloat(lllIIIlIlllllll));
  }
  
  private static boolean lllIlIll(int ???, int arg1)
  {
    int i;
    char lllIIIIIIlIIIIl;
    return ??? < i;
  }
  
  public void setBidiFlag(boolean lllIIIIlllllIll)
  {
    ;
    ;
    bidiFlag = lllIIIIlllllIll;
  }
  
  public List listFormattedStringToWidth(String lllIIIIllllIllI, int lllIIIIllllIIlI)
  {
    ;
    ;
    ;
    return Arrays.asList(lllIIIIllllIlll.wrapFormattedStringToWidth(lllIIIIllllIIll, lllIIIIllllIIlI).split(llllll[lIIIIII[40]]));
  }
  
  public static String getFormatFromString(String lllIIIIlIllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    String lllIIIIlIlIllll = llllll[lIIIIII[49]];
    int lllIIIIlIlIlllI = lIIIIII[22];
    int lllIIIIlIlIllIl = lllIIIIlIlIlIll.length();
    "".length();
    if (((0x69 ^ 0x23) & (0x5 ^ 0x4F ^ 0xFFFFFFFF)) < ((0x33 ^ 0x6C) & (0x7B ^ 0x24 ^ 0xFFFFFFFF))) {
      return null;
    }
    while (!lllIIlll(lllIIIIlIlIlllI = lllIIIIlIlIlIll.indexOf(lIIIIII[26], lllIIIIlIlIlllI + lIIIIII[5]), lIIIIII[22])) {
      if (lllIlIll(lllIIIIlIlIlllI, lllIIIIlIlIllIl - lIIIIII[5]))
      {
        char lllIIIIlIlIllII = lllIIIIlIlIlIll.charAt(lllIIIIlIlIlllI + lIIIIII[5]);
        if (lllIlIII(isFormatColor(lllIIIIlIlIllII)))
        {
          lllIIIIlIlIllll = String.valueOf(new StringBuilder(llllll[lIIIIII[50]]).append(lllIIIIlIlIllII));
          "".length();
          if ((0x39 ^ 0x44 ^ 0x69 ^ 0x10) < ((0x46 ^ 0x7D ^ 0x10 ^ 0x7C) & (0xFF ^ 0xA5 ^ 0x13 ^ 0x1E ^ -" ".length()))) {
            return null;
          }
        }
        else if (lllIlIII(isFormatSpecial(lllIIIIlIlIllII)))
        {
          lllIIIIlIlIllll = String.valueOf(new StringBuilder(String.valueOf(lllIIIIlIlIllll)).append(llllll[lIIIIII[51]]).append(lllIIIIlIlIllII));
        }
      }
    }
    return lllIIIIlIlIllll;
  }
  
  public void setUnicodeFlag(boolean lllIIIlIIIIIlII)
  {
    ;
    ;
    unicodeFlag = lllIIIlIIIIIlII;
  }
  
  private static String lllIIIll(String lllIIIIIIllllll, String lllIIIIIIllllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllIIIIIlIIIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllIIIIIIllllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllIIIIIlIIIIIl = Cipher.getInstance("Blowfish");
      lllIIIIIlIIIIIl.init(lIIIIII[8], lllIIIIIlIIIIlI);
      return new String(lllIIIIIlIIIIIl.doFinal(Base64.getDecoder().decode(lllIIIIIIllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllIIIIIlIIIIII)
    {
      lllIIIIIlIIIIII.printStackTrace();
    }
    return null;
  }
  
  private static ResourceLocation getHdFontLocation(ResourceLocation lllIIIIIllIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIllII(Config.isCustomFonts())) {
      return lllIIIIIllIIIll;
    }
    if (llllIlII(lllIIIIIllIIIll)) {
      return lllIIIIIllIIIll;
    }
    String lllIIIIIllIIlll = lllIIIIIllIIIll.getResourcePath();
    String lllIIIIIllIIllI = llllll[lIIIIII[30]];
    String lllIIIIIllIIlIl = llllll[lIIIIII[31]];
    if (lllIllII(lllIIIIIllIIlll.startsWith(lllIIIIIllIIllI))) {
      return lllIIIIIllIIIll;
    }
    lllIIIIIllIIlll = lllIIIIIllIIlll.substring(lllIIIIIllIIllI.length());
    lllIIIIIllIIlll = String.valueOf(new StringBuilder(String.valueOf(lllIIIIIllIIlIl)).append(lllIIIIIllIIlll));
    ResourceLocation lllIIIIIllIIlII = new ResourceLocation(lllIIIIIllIIIll.getResourceDomain(), lllIIIIIllIIlll);
    if (lllIlIII(Config.hasResource(Config.getResourceManager(), lllIIIIIllIIlII)))
    {
      "".length();
      if ("   ".length() > 0) {
        break label136;
      }
      return null;
    }
    label136:
    return lllIIIIIllIIIll;
  }
  
  private static boolean lllIllll(int ???, int arg1)
  {
    int i;
    int lllIIIIIIIIIlll;
    return ??? != i;
  }
  
  private void resetStyles()
  {
    ;
    randomStyle = lIIIIII[0];
    boldStyle = lIIIIII[0];
    italicStyle = lIIIIII[0];
    underlineStyle = lIIIIII[0];
    strikethroughStyle = lIIIIII[0];
  }
  
  private static boolean llllIlIl(int ???)
  {
    Exception lllIIIIIIIIllll;
    return ??? >= 0;
  }
  
  private String trimStringNewline(String lllIIIlIIllllII)
  {
    ;
    "".length();
    if (-(6 + 18 - -91 + 12 ^ 0xFC ^ 0x87) >= 0) {
      return null;
    }
    while ((lllllIll(lllIIIlIIllllIl)) && (!lllIllII(lllIIIlIIllllIl.endsWith(llllll[lIIIIII[2]])))) {
      lllIIIlIIllllIl = lllIIIlIIllllIl.substring(lIIIIII[0], lllIIIlIIllllIl.length() - lIIIIII[5]);
    }
    return lllIIIlIIllllIl;
  }
  
  public void onResourceManagerReload(IResourceManager lllIIlIllIIIlIl)
  {
    ;
    ;
    locationFontTexture = getHdFontLocation(locationFontTextureBase);
    int lllIIlIllIIIlII = lIIIIII[0];
    "".length();
    if ((31 + 123 - 12 + 32 ^ 65 + 59 - 61 + 107) != (0x6D ^ 0x7B ^ 0x70 ^ 0x62)) {
      return;
    }
    while (!lllIlIIl(lllIIlIllIIIlII, unicodePageLocations.length))
    {
      unicodePageLocations[lllIIlIllIIIlII] = null;
      lllIIlIllIIIlII++;
    }
    lllIIlIllIIIIll.readFontTexture();
  }
  
  private static boolean lllIlllI(int ???, int arg1)
  {
    int i;
    char lllIIIIIIIlllIl;
    return ??? <= i;
  }
  
  private static boolean lllIlIII(int ???)
  {
    short lllIIIIIIIlIIll;
    return ??? != 0;
  }
  
  private void readGlyphSizes()
  {
    ;
    ;
    ;
    InputStream lllIIlIlIIIIlII = null;
    try
    {
      lllIIlIlIIIIlII = Minecraft.getMinecraft().getResourceManager().getResource(new ResourceLocation(llllll[lIIIIII[5]])).getInputStream();
      "".length();
      "".length();
      if (-"  ".length() >= 0) {
        return;
      }
    }
    catch (IOException lllIIlIlIIIIIll)
    {
      lllIIlIlIIIIIll = lllIIlIlIIIIIll;
      throw new RuntimeException(lllIIlIlIIIIIll);
    }
    finally
    {
      lllIIlIIlllllll = finally;
      IOUtils.closeQuietly(lllIIlIlIIIIlII);
      throw lllIIlIIlllllll;
    }
    IOUtils.closeQuietly(lllIIlIlIIIIlII);
  }
  
  public int drawString(String lllIIlIIIIlIlll, int lllIIlIIIIlIllI, int lllIIlIIIIlIIII, int lllIIlIIIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIllII(enabled))
    {
      "".length();
      if (((1 + 126 - 72 + 82 ^ 106 + 53 - 3 + 2) & (0x92 ^ 0xB7 ^ 0x12 ^ 0x20 ^ -" ".length())) == 0) {
        break label118;
      }
      return (0xBD ^ 0x84 ^ 0x3B ^ 0x12) & (0x78 ^ 0x8 ^ 0xA7 ^ 0xC7 ^ -" ".length());
    }
    label118:
    return lllIIlIIIIllIII.drawString(lllIIlIIIIlIlll, lllIIlIIIIlIIIl, lllIIlIIIIlIIII, lllIIlIIIIIllll, lIIIIII[0]);
  }
  
  private static boolean lllIlIlI(int ???, int arg1)
  {
    int i;
    long lllIIIIIIIllIIl;
    return ??? > i;
  }
  
  private static boolean isFormatSpecial(char lllIIIIlIllIlll)
  {
    ;
    if (((!lllIlIIl(lllIIIIlIllIlll, lIIIIII[45])) || (lllIlIlI(lllIIIIlIllIllI, lIIIIII[46]))) && ((!lllIlIIl(lllIIIIlIllIllI, lIIIIII[47])) || (lllIlIlI(lllIIIIlIllIllI, lIIIIII[48]))) && (lllIllll(lllIIIIlIllIllI, lIIIIII[38])) && (lllIllll(lllIIIIlIllIllI, lIIIIII[39]))) {
      return lIIIIII[0];
    }
    return lIIIIII[5];
  }
  
  private int renderString(String lllIIIllIlIIlII, float lllIIIllIIlllIl, float lllIIIllIlIIIlI, int lllIIIllIlIIIIl, boolean lllIIIllIIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (llllIlII(lllIIIllIlIIlII)) {
      return lIIIIII[0];
    }
    if (lllIlIII(bidiFlag)) {
      lllIIIllIlIIlII = lllIIIllIIlllll.bidiReorder(lllIIIllIlIIlII);
    }
    if (lllIllII(lllIIIllIlIIIIl & lIIIIII[33])) {
      lllIIIllIlIIIIl |= lIIIIII[34];
    }
    if (lllIlIII(lllIIIllIIllIlI)) {
      lllIIIllIlIIIIl = (lllIIIllIlIIIIl & lIIIIII[35]) >> lIIIIII[8] | lllIIIllIlIIIIl & lIIIIII[34];
    }
    red = ((lllIIIllIlIIIIl >> lIIIIII[16] & lIIIIII[18]) / 255.0F);
    blue = ((lllIIIllIlIIIIl >> lIIIIII[19] & lIIIIII[18]) / 255.0F);
    green = ((lllIIIllIlIIIIl & lIIIIII[18]) / 255.0F);
    alpha = ((lllIIIllIlIIIIl >> lIIIIII[20] & lIIIIII[18]) / 255.0F);
    GlStateManager.color(red, blue, green, alpha);
    posX = lllIIIllIIlllIl;
    posY = lllIIIllIlIIIlI;
    lllIIIllIIlllll.renderStringAtPos(lllIIIllIlIIlII, lllIIIllIIllIlI);
    return (int)posX;
  }
  
  private static void lllIIllI()
  {
    lIIIIII = new int[54];
    lIIIIII[0] = ("  ".length() & ("  ".length() ^ -" ".length()));
    lIIIIII[1] = (0xA386 & 0x5D79);
    lIIIIII[2] = (0x40 ^ 0x49);
    lIIIIII[3] = (0x9B76 & 0x16489);
    lIIIIII[4] = (0x2A ^ 0xA);
    lIIIIII[5] = " ".length();
    lIIIIII[6] = "   ".length();
    lIIIIII[7] = (0xC5 ^ 0xBD ^ 0x5F ^ 0x72);
    lIIIIII[8] = "  ".length();
    lIIIIII[9] = (54 + 57 - 29 + 59 + (0x7F ^ 0x31) - (0xAA ^ 0x90) + (0x4 ^ 0xD));
    lIIIIII[10] = (0x5E ^ 0x30 ^ 0x69 ^ 0x1);
    lIIIIII[11] = (0x1D ^ 0x3);
    lIIIIII[12] = (0x4C ^ 0x38 ^ 0xD7 ^ 0x98);
    lIIIIII[13] = (0x8E ^ 0x85);
    lIIIIII[14] = (0x7 ^ 0x68 ^ 0x57 ^ 0x5C);
    lIIIIII[15] = (0x3A ^ 0x7C);
    lIIIIII[16] = (0x51 ^ 0x41);
    lIIIIII[17] = (90 + 41 - -34 + 5 ^ 6 + 127 - -31 + 10);
    lIIIIII[18] = ('Ë' + 74 - 161 + 139);
    lIIIIII[19] = (0xD ^ 0x5);
    lIIIIII[20] = (0x7E ^ 0x78 ^ 0x6B ^ 0x75);
    lIIIIII[21] = (0x35 ^ 0x74);
    lIIIIII[22] = (-" ".length());
    lIIIIII[23] = (0xDA ^ 0x86 ^ 0x44 ^ 0x1D);
    lIIIIII[24] = (0x28 ^ 0x27);
    lIIIIII[25] = (16 + 35 - -12 + 64);
    lIIIIII[26] = ((0x10 ^ 0x41) + (0xF8 ^ 0xAB) - (0x15 ^ 0x38) + (0xAA ^ 0x9A));
    lIIIIII[27] = (0x3B ^ 0x2A);
    lIIIIII[28] = (0x55 ^ 0x47);
    lIIIIII[29] = (0x9B ^ 0x88);
    lIIIIII[30] = (0x88 ^ 0x9C);
    lIIIIII[31] = (0xB7 ^ 0xA2);
    lIIIIII[32] = (0x42 ^ 0x45);
    lIIIIII[33] = (-(0xBD58 & 0x40042A7));
    lIIIIII[34] = (-(-(0xBF59 & 0x7CA7) & 0xFCAA & 0x1003F55));
    lIIIIII[35] = (-(0xF687 & 0xB7C) & 0xFEFF & 0xFCFFFF);
    lIIIIII[36] = (0x2F ^ 0x3D ^ 0xD6 ^ 0xA8);
    lIIIIII[37] = (14 + 'Ô' - 154 + 149 ^ 72 + 97 - 137 + 113);
    lIIIIII[38] = (0x7C ^ 0xE);
    lIIIIII[39] = (0x72 ^ 0x3A ^ 0x2D ^ 0x37);
    lIIIIII[40] = (0x77 ^ 0x7D);
    lIIIIII[41] = (0x77 ^ 0x47);
    lIIIIII[42] = (0x14 ^ 0x2D);
    lIIIIII[43] = (0x4 ^ 0x34 ^ 0x3A ^ 0x6B);
    lIIIIII[44] = (58 + 29 - -76 + 54 ^ '' + '¼' - 292 + 158);
    lIIIIII[45] = (0xF ^ 0x64);
    lIIIIII[46] = (0x6A ^ 0x5);
    lIIIIII[47] = (0x38 ^ 0x73);
    lIIIIII[48] = (0x4A ^ 0x5);
    lIIIIII[49] = (0xB4 ^ 0xB8);
    lIIIIII[50] = (0x13 ^ 0x1E);
    lIIIIII[51] = (0x4F ^ 0x2C ^ 0x3D ^ 0x50);
    lIIIIII[52] = (0xFFFFFFFF & 0xFFFFFF);
    lIIIIII[53] = ('Æ' + 'Ë' - 309 + 118 ^ 19 + 110 - 48 + 115);
  }
  
  private static boolean lllIlIIl(int ???, int arg1)
  {
    int i;
    long lllIIIIIIlIIlIl;
    return ??? >= i;
  }
  
  private static int lllllIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static String lllIIIlI(String lllIIIIIIllIIlI, String lllIIIIIIlIllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllIIIIIIllIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllIIIIIIlIllll.getBytes(StandardCharsets.UTF_8)), lIIIIII[19]), "DES");
      Cipher lllIIIIIIllIlII = Cipher.getInstance("DES");
      lllIIIIIIllIlII.init(lIIIIII[8], lllIIIIIIllIlIl);
      return new String(lllIIIIIIllIlII.doFinal(Base64.getDecoder().decode(lllIIIIIIllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllIIIIIIllIIll)
    {
      lllIIIIIIllIIll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIlll(int ???, int arg1)
  {
    int i;
    byte lllIIIIIIlIlIIl;
    return ??? == i;
  }
  
  private static int lllllIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public int getStringWidth(String lllIIIllIIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llllIlII(lllIIIllIIlIIIl)) {
      return lIIIIII[0];
    }
    float lllIIIllIIlIIII = 0.0F;
    boolean lllIIIllIIIllll = lIIIIII[0];
    int lllIIIllIIIlllI = lIIIIII[0];
    "".length();
    if (null != null) {
      return (0x16 ^ 0xB) & (0x59 ^ 0x44 ^ 0xFFFFFFFF);
    }
    while (!lllIlIIl(lllIIIllIIIlllI, lllIIIllIIlIIIl.length()))
    {
      char lllIIIllIIIllIl = lllIIIllIIlIIIl.charAt(lllIIIllIIIlllI);
      float lllIIIllIIIllII = lllIIIllIIIlIll.getCharWidthFloat(lllIIIllIIIllIl);
      if ((lllIllIl(llllIllI(lllIIIllIIIllII, 0.0F))) && (lllIlIll(lllIIIllIIIlllI, lllIIIllIIlIIIl.length() - lIIIIII[5])))
      {
        lllIIIllIIIlllI++;
        lllIIIllIIIllIl = lllIIIllIIlIIIl.charAt(lllIIIllIIIlllI);
        if ((lllIllll(lllIIIllIIIllIl, lIIIIII[36])) && (lllIllll(lllIIIllIIIllIl, lIIIIII[37])))
        {
          if ((!lllIllll(lllIIIllIIIllIl, lIIIIII[38])) || (lllIIlll(lllIIIllIIIllIl, lIIIIII[39])))
          {
            lllIIIllIIIllll = lIIIIII[0];
            "".length();
            if ((0x51 ^ 0x55) == "   ".length()) {
              return (0x38 ^ 0x59) & (0x34 ^ 0x55 ^ 0xFFFFFFFF);
            }
          }
        }
        else {
          lllIIIllIIIllll = lIIIIII[5];
        }
        lllIIIllIIIllII = 0.0F;
      }
      lllIIIllIIlIIII += lllIIIllIIIllII;
      if ((lllIlIII(lllIIIllIIIllll)) && (lllllIII(llllIlll(lllIIIllIIIllII, 0.0F)))) {
        lllIIIllIIlIIII += 1.0F;
      }
      lllIIIllIIIlllI++;
    }
    return (int)lllIIIllIIlIIII;
  }
  
  public FontRenderer(GameSettings lllIIlIllIlIlII, ResourceLocation lllIIlIlllIIIII, TextureManager lllIIlIllIlllll, boolean lllIIlIllIlIIIl)
  {
    gameSettings = lllIIlIllIlIlII;
    locationFontTextureBase = lllIIlIllIlIIll;
    locationFontTexture = lllIIlIllIlIIll;
    renderEngine = lllIIlIllIlllll;
    unicodeFlag = lllIIlIllIlIIIl;
    locationFontTexture = getHdFontLocation(locationFontTextureBase);
    lllIIlIllIlllll.bindTexture(locationFontTexture);
    int lllIIlIllIlllIl = lIIIIII[0];
    "".length();
    if (-(0x2B ^ 0x25 ^ 0x1E ^ 0x14) >= 0) {
      throw null;
    }
    while (!lllIlIIl(lllIIlIllIlllIl, lIIIIII[4]))
    {
      int lllIIlIllIlllII = (lllIIlIllIlllIl >> lIIIIII[6] & lIIIIII[5]) * lIIIIII[7];
      int lllIIlIllIllIll = (lllIIlIllIlllIl >> lIIIIII[8] & lIIIIII[5]) * lIIIIII[9] + lllIIlIllIlllII;
      int lllIIlIllIllIlI = (lllIIlIllIlllIl >> lIIIIII[5] & lIIIIII[5]) * lIIIIII[9] + lllIIlIllIlllII;
      int lllIIlIllIllIIl = (lllIIlIllIlllIl >> lIIIIII[0] & lIIIIII[5]) * lIIIIII[9] + lllIIlIllIlllII;
      if (lllIIlll(lllIIlIllIlllIl, lIIIIII[10])) {
        lllIIlIllIllIll += 85;
      }
      if (lllIlIII(anaglyph))
      {
        int lllIIlIllIllIII = (lllIIlIllIllIll * lIIIIII[11] + lllIIlIllIllIlI * lIIIIII[12] + lllIIlIllIllIIl * lIIIIII[13]) / lIIIIII[14];
        int lllIIlIllIlIlll = (lllIIlIllIllIll * lIIIIII[11] + lllIIlIllIllIlI * lIIIIII[15]) / lIIIIII[14];
        int lllIIlIllIlIllI = (lllIIlIllIllIll * lIIIIII[11] + lllIIlIllIllIIl * lIIIIII[15]) / lIIIIII[14];
        lllIIlIllIllIll = lllIIlIllIllIII;
        lllIIlIllIllIlI = lllIIlIllIlIlll;
        lllIIlIllIllIIl = lllIIlIllIlIllI;
      }
      if (lllIlIIl(lllIIlIllIlllIl, lIIIIII[16]))
      {
        lllIIlIllIllIll /= lIIIIII[17];
        lllIIlIllIllIlI /= lIIIIII[17];
        lllIIlIllIllIIl /= lIIIIII[17];
      }
      colorCode[lllIIlIllIlllIl] = ((lllIIlIllIllIll & lIIIIII[18]) << lIIIIII[16] | (lllIIlIllIllIlI & lIIIIII[18]) << lIIIIII[19] | lllIIlIllIllIIl & lIIIIII[18]);
      lllIIlIllIlllIl++;
    }
    lllIIlIlllIIIlI.readGlyphSizes();
  }
  
  public String trimStringToWidth(String lllIIIlIlIllIII, int lllIIIlIlIlIlll, boolean lllIIIlIlIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    StringBuilder lllIIIlIlIlIlIl = new StringBuilder();
    float lllIIIlIlIlIlII = 0.0F;
    if (lllIlIII(lllIIIlIlIIlIIl))
    {
      "".length();
      if (((0xFC ^ 0xBD) & (0x7 ^ 0x46 ^ 0xFFFFFFFF)) >= 0) {
        break label60;
      }
      return null;
    }
    label60:
    int lllIIIlIlIlIIll = lIIIIII[0];
    if (lllIlIII(lllIIIlIlIIlIIl))
    {
      "".length();
      if (" ".length() <= "   ".length()) {
        break label103;
      }
      return null;
    }
    label103:
    int lllIIIlIlIlIIlI = lIIIIII[5];
    boolean lllIIIlIlIlIIIl = lIIIIII[0];
    boolean lllIIIlIlIlIIII = lIIIIII[0];
    int lllIIIlIlIIllll = lllIIIlIlIlIIll;
    "".length();
    if ("   ".length() == 0) {
      return null;
    }
    while ((llllIlIl(lllIIIlIlIIllll)) && (lllIlIll(lllIIIlIlIIllll, lllIIIlIlIllIII.length())) && (!llllIlIl(lllllIIl(lllIIIlIlIlIlII, lllIIIlIlIlIlll))))
    {
      char lllIIIlIlIIlllI = lllIIIlIlIllIII.charAt(lllIIIlIlIIllll);
      float lllIIIlIlIIllIl = lllIIIlIlIllIIl.getCharWidthFloat(lllIIIlIlIIlllI);
      if (lllIlIII(lllIIIlIlIlIIIl))
      {
        lllIIIlIlIlIIIl = lIIIIII[0];
        if ((lllIllll(lllIIIlIlIIlllI, lIIIIII[36])) && (lllIllll(lllIIIlIlIIlllI, lIIIIII[37])))
        {
          if ((!lllIllll(lllIIIlIlIIlllI, lIIIIII[38])) || (lllIIlll(lllIIIlIlIIlllI, lIIIIII[39])))
          {
            lllIIIlIlIlIIII = lIIIIII[0];
            "".length();
            if (-"  ".length() > 0) {
              return null;
            }
          }
        }
        else
        {
          lllIIIlIlIlIIII = lIIIIII[5];
          "".length();
          if (null != null) {
            return null;
          }
        }
      }
      else if (lllIllIl(lllllIIl(lllIIIlIlIIllIl, 0.0F)))
      {
        lllIIIlIlIlIIIl = lIIIIII[5];
        "".length();
        if (-('£' + 102 - 168 + 100 ^ '¼' + 116 - 234 + 122) >= 0) {
          return null;
        }
      }
      else
      {
        lllIIIlIlIlIlII += lllIIIlIlIIllIl;
        if (lllIlIII(lllIIIlIlIlIIII)) {
          lllIIIlIlIlIlII += 1.0F;
        }
      }
      if (lllllIII(lllllIlI(lllIIIlIlIlIlII, lllIIIlIlIlIlll)))
      {
        "".length();
        if (" ".length() == " ".length()) {
          break;
        }
        return null;
      }
      if (lllIlIII(lllIIIlIlIIlIIl))
      {
        "".length();
        "".length();
        if ("   ".length() >= (69 + '' - 142 + 80 ^ '' + 36 - 65 + 31)) {
          return null;
        }
      }
      else
      {
        "".length();
      }
      lllIIIlIlIIllll += lllIIIlIlIlIIlI;
    }
    return String.valueOf(lllIIIlIlIlIlIl);
  }
  
  public String trimStringToWidth(String lllIIIlIllIlIII, int lllIIIlIllIIlll)
  {
    ;
    ;
    ;
    return lllIIIlIllIlIIl.trimStringToWidth(lllIIIlIllIlIll, lllIIIlIllIIlll, lIIIIII[0]);
  }
  
  public boolean getUnicodeFlag()
  {
    ;
    return unicodeFlag;
  }
  
  static
  {
    lllIIllI();
    lllIIlIl();
  }
  
  private float renderDefaultChar(int lllIIlIIllIlIIl, boolean lllIIlIIllIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllIIlIIllIIlll = lllIIlIIllIlIIl % lIIIIII[16] * lIIIIII[19];
    int lllIIlIIllIIllI = lllIIlIIllIIIIl / lIIIIII[16] * lIIIIII[19];
    if (lllIlIII(lllIIlIIllIIIII))
    {
      "".length();
      if (null == null) {
        break label62;
      }
      return 0.0F;
    }
    label62:
    int lllIIlIIllIIlIl = lIIIIII[0];
    renderEngine.bindTexture(locationFontTexture);
    float lllIIlIIllIIlII = charWidth[lllIIlIIllIIIIl];
    float lllIIlIIllIIIll = 7.99F;
    GL11.glBegin(lIIIIII[23]);
    GL11.glTexCoord2f(lllIIlIIllIIlll / 128.0F, lllIIlIIllIIllI / 128.0F);
    GL11.glVertex3f(posX + lllIIlIIllIIlIl, posY, 0.0F);
    GL11.glTexCoord2f(lllIIlIIllIIlll / 128.0F, (lllIIlIIllIIllI + 7.99F) / 128.0F);
    GL11.glVertex3f(posX - lllIIlIIllIIlIl, posY + 7.99F, 0.0F);
    GL11.glTexCoord2f((lllIIlIIllIIlll + lllIIlIIllIIIll - 1.0F) / 128.0F, lllIIlIIllIIllI / 128.0F);
    GL11.glVertex3f(posX + lllIIlIIllIIIll - 1.0F + lllIIlIIllIIlIl, posY, 0.0F);
    GL11.glTexCoord2f((lllIIlIIllIIlll + lllIIlIIllIIIll - 1.0F) / 128.0F, (lllIIlIIllIIllI + 7.99F) / 128.0F);
    GL11.glVertex3f(posX + lllIIlIIllIIIll - 1.0F - lllIIlIIllIIlIl, posY + 7.99F, 0.0F);
    GL11.glEnd();
    return lllIIlIIllIIlII;
  }
  
  String wrapFormattedStringToWidth(String lllIIIIlllIlIII, int lllIIIIlllIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllIIIIlllIIllI = lllIIIIlllIIIIl.sizeStringToWidth(lllIIIIlllIIIII, lllIIIIlllIIlll);
    if (lllIlllI(lllIIIIlllIIIII.length(), lllIIIIlllIIllI)) {
      return lllIIIIlllIIIII;
    }
    String lllIIIIlllIIlIl = lllIIIIlllIIIII.substring(lIIIIII[0], lllIIIIlllIIllI);
    char lllIIIIlllIIlII = lllIIIIlllIIIII.charAt(lllIIIIlllIIllI);
    if ((lllIllll(lllIIIIlllIIlII, lIIIIII[4])) && (lllIllll(lllIIIIlllIIlII, lIIIIII[40])))
    {
      "".length();
      if (-" ".length() <= 0) {
        break label94;
      }
      return null;
    }
    label94:
    boolean lllIIIIlllIIIll = lIIIIII[5];
    new StringBuilder(String.valueOf(getFormatFromString(lllIIIIlllIIlIl)));
    if (lllIlIII(lllIIIIlllIIIll))
    {
      "".length();
      if (((0x1 ^ 0x45) & (0xF1 ^ 0xB5 ^ 0xFFFFFFFF)) == 0) {
        break label156;
      }
      return null;
    }
    label156:
    String lllIIIIlllIIIlI = String.valueOf(lllIIIIlllIIIII.append(lllIIIIlllIIllI.substring(lIIIIII[5] + lIIIIII[0])));
    return String.valueOf(new StringBuilder(String.valueOf(lllIIIIlllIIlIl)).append(llllll[lIIIIII[13]]).append(lllIIIIlllIIIIl.wrapFormattedStringToWidth(lllIIIIlllIIIlI, lllIIIIlllIIlll)));
  }
  
  private float func_181559_a(char lllIIlIIllllIIl, boolean lllIIlIIllllIII)
  {
    ;
    ;
    ;
    ;
    if (lllIIlll(lllIIlIIllllIIl, lIIIIII[4])) {
      return charWidth[lllIIlIIlllIlIl];
    }
    int lllIIlIIlllIlll = llllll[lIIIIII[8]].indexOf(lllIIlIIlllIlIl);
    if ((lllIllll(lllIIlIIlllIlll, lIIIIII[22])) && (lllIllII(unicodeFlag)))
    {
      "".length();
      if (-(0xB2 ^ 0x8C ^ 0xA7 ^ 0x9C) < 0) {
        break label96;
      }
      return 0.0F;
    }
    label96:
    return lllIIlIIlllIllI.renderUnicodeChar(lllIIlIIlllIlIl, lllIIlIIllllIII);
  }
  
  private static int llllllIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private float getCharWidthFloat(char lllIIIlIlllIIll)
  {
    ;
    ;
    ;
    ;
    ;
    if (lllIIlll(lllIIIlIlllIIll, lIIIIII[26])) {
      return -1.0F;
    }
    if (lllIIlll(lllIIIlIlllIIll, lIIIIII[4])) {
      return charWidth[lIIIIII[4]];
    }
    int lllIIIlIlllIlll = llllll[lIIIIII[19]].indexOf(lllIIIlIlllIIll);
    if ((lllllIII(lllIIIlIlllIIll)) && (lllIllll(lllIIIlIlllIlll, lIIIIII[22])) && (lllIllII(unicodeFlag))) {
      return charWidth[lllIIIlIlllIlll];
    }
    if (lllIlIII(glyphWidth[lllIIIlIlllIIll]))
    {
      int lllIIIlIlllIllI = glyphWidth[lllIIIlIlllIIll] >>> lIIIIII[17];
      int lllIIIlIlllIlIl = glyphWidth[lllIIIlIlllIIll] & lIIIIII[24];
      if (lllIlIlI(lllIIIlIlllIlIl, lIIIIII[32]))
      {
        lllIIIlIlllIlIl = lIIIIII[24];
        lllIIIlIlllIllI = lIIIIII[0];
      }
      lllIIIlIlllIlIl++;
      return (lllIIIlIlllIlIl - lllIIIlIlllIllI) / lIIIIII[8] + lIIIIII[5];
    }
    return 0.0F;
  }
  
  private void renderStringAtPos(String lllIIIllllIIIII, boolean lllIIIlllIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllIIIlllIllllI = lIIIIII[0];
    "".length();
    if ("  ".length() < 0) {
      return;
    }
    label764:
    label837:
    label1293:
    while (!lllIlIIl(lllIIIlllIllllI, lllIIIlllIIlllI.length()))
    {
      char lllIIIlllIlllIl = lllIIIlllIIlllI.charAt(lllIIIlllIllllI);
      if ((lllIIlll(lllIIIlllIlllIl, lIIIIII[26])) && (lllIlIll(lllIIIlllIllllI + lIIIIII[5], lllIIIlllIIlllI.length())))
      {
        int lllIIIlllIlllII = llllll[lIIIIII[17]].indexOf(lllIIIlllIIlllI.toLowerCase().charAt(lllIIIlllIllllI + lIIIIII[5]));
        if (lllIlIll(lllIIIlllIlllII, lIIIIII[16]))
        {
          randomStyle = lIIIIII[0];
          boldStyle = lIIIIII[0];
          strikethroughStyle = lIIIIII[0];
          underlineStyle = lIIIIII[0];
          italicStyle = lIIIIII[0];
          if ((!llllIlIl(lllIIIlllIlllII)) || (lllIlIlI(lllIIIlllIlllII, lIIIIII[24]))) {
            lllIIIlllIlllII = lIIIIII[24];
          }
          if (lllIlIII(lllIIIlllIlllll)) {
            lllIIIlllIlllII += 16;
          }
          int lllIIIlllIllIll = colorCode[lllIIIlllIlllII];
          textColor = lllIIIlllIllIll;
          GlStateManager.color((lllIIIlllIllIll >> lIIIIII[16]) / 255.0F, (lllIIIlllIllIll >> lIIIIII[19] & lIIIIII[18]) / 255.0F, (lllIIIlllIllIll & lIIIIII[18]) / 255.0F, alpha);
          "".length();
          if (null == null) {}
        }
        else if (lllIIlll(lllIIIlllIlllII, lIIIIII[16]))
        {
          randomStyle = lIIIIII[5];
          "".length();
          if ("   ".length() >= 0) {}
        }
        else if (lllIIlll(lllIIIlllIlllII, lIIIIII[27]))
        {
          boldStyle = lIIIIII[5];
          "".length();
          if (-" ".length() <= (0x59 ^ 0x32 ^ 0x6E ^ 0x1)) {}
        }
        else if (lllIIlll(lllIIIlllIlllII, lIIIIII[28]))
        {
          strikethroughStyle = lIIIIII[5];
          "".length();
          if ("   ".length() != 0) {}
        }
        else if (lllIIlll(lllIIIlllIlllII, lIIIIII[29]))
        {
          underlineStyle = lIIIIII[5];
          "".length();
          if ("   ".length() > " ".length()) {}
        }
        else if (lllIIlll(lllIIIlllIlllII, lIIIIII[30]))
        {
          italicStyle = lIIIIII[5];
          "".length();
          if (" ".length() > ((72 + 20 - 35 + 81 ^ 93 + 46 - 8 + 12) & (0x89 ^ 0x92 ^ 0x1D ^ 0x3 ^ -" ".length()))) {}
        }
        else if (lllIIlll(lllIIIlllIlllII, lIIIIII[31]))
        {
          randomStyle = lIIIIII[0];
          boldStyle = lIIIIII[0];
          strikethroughStyle = lIIIIII[0];
          underlineStyle = lIIIIII[0];
          italicStyle = lIIIIII[0];
          GlStateManager.color(red, blue, green, alpha);
        }
        lllIIIlllIllllI++;
        "".length();
        if ((0x11 ^ 0x79 ^ 0x4D ^ 0x20) != 0) {}
      }
      else
      {
        int lllIIIlllIllIlI = llllll[lIIIIII[23]].indexOf(lllIIIlllIlllIl);
        if ((lllIlIII(randomStyle)) && (lllIllll(lllIIIlllIllIlI, lIIIIII[22])))
        {
          int lllIIIlllIllIIl = lllIIIlllIIllll.getCharWidth(lllIIIlllIlllIl);
          char lllIIIlllIllIII;
          do
          {
            lllIIIlllIllIlI = fontRandom.nextInt(llllll[lIIIIII[10]].length());
            lllIIIlllIllIII = llllll[lIIIIII[32]].charAt(lllIIIlllIllIlI);
          } while (!lllIIlll(lllIIIlllIllIIl, lllIIIlllIIllll.getCharWidth(lllIIIlllIllIII)));
          lllIIIlllIlllIl = lllIIIlllIllIII;
        }
        if (lllIlIII(unicodeFlag))
        {
          "".length();
          if (null == null) {
            break label764;
          }
        }
        float lllIIIlllIlIlll = 1.0F / scaleFactor;
        if (((!lllIlIII(lllIIIlllIlllIl)) || (!lllIllll(lllIIIlllIllIlI, lIIIIII[22])) || (lllIlIII(unicodeFlag))) && (lllIlIII(lllIIIlllIlllll)))
        {
          "".length();
          if ("   ".length() >= "   ".length()) {
            break label837;
          }
        }
        boolean lllIIIlllIlIllI = lIIIIII[0];
        if (lllIlIII(lllIIIlllIlIllI))
        {
          posX -= lllIIIlllIlIlll;
          posY -= lllIIIlllIlIlll;
        }
        float lllIIIlllIlIlIl = lllIIIlllIIllll.func_181559_a(lllIIIlllIlllIl, italicStyle);
        if (lllIlIII(lllIIIlllIlIllI))
        {
          posX += lllIIIlllIlIlll;
          posY += lllIIIlllIlIlll;
        }
        if (lllIlIII(boldStyle))
        {
          posX += lllIIIlllIlIlll;
          if (lllIlIII(lllIIIlllIlIllI))
          {
            posX -= lllIIIlllIlIlll;
            posY -= lllIIIlllIlIlll;
          }
          "".length();
          posX -= lllIIIlllIlIlll;
          if (lllIlIII(lllIIIlllIlIllI))
          {
            posX += lllIIIlllIlIlll;
            posY += lllIIIlllIlIlll;
          }
          lllIIIlllIlIlIl += lllIIIlllIlIlll;
        }
        if (lllIlIII(strikethroughStyle))
        {
          Tessellator lllIIIlllIlIlII = Tessellator.getInstance();
          WorldRenderer lllIIIlllIlIIll = lllIIIlllIlIlII.getWorldRenderer();
          GlStateManager.disableTexture2D();
          lllIIIlllIlIIll.begin(lIIIIII[32], DefaultVertexFormats.POSITION);
          lllIIIlllIlIIll.pos(posX, posY + FONT_HEIGHT / lIIIIII[8], 0.0D).endVertex();
          lllIIIlllIlIIll.pos(posX + lllIIIlllIlIlIl, posY + FONT_HEIGHT / lIIIIII[8], 0.0D).endVertex();
          lllIIIlllIlIIll.pos(posX + lllIIIlllIlIlIl, posY + FONT_HEIGHT / lIIIIII[8] - 1.0F, 0.0D).endVertex();
          lllIIIlllIlIIll.pos(posX, posY + FONT_HEIGHT / lIIIIII[8] - 1.0F, 0.0D).endVertex();
          lllIIIlllIlIlII.draw();
          GlStateManager.enableTexture2D();
        }
        if (lllIlIII(underlineStyle))
        {
          Tessellator lllIIIlllIlIIlI = Tessellator.getInstance();
          WorldRenderer lllIIIlllIlIIIl = lllIIIlllIlIIlI.getWorldRenderer();
          GlStateManager.disableTexture2D();
          lllIIIlllIlIIIl.begin(lIIIIII[32], DefaultVertexFormats.POSITION);
          if (lllIlIII(underlineStyle))
          {
            "".length();
            if ("   ".length() > "  ".length()) {
              break label1293;
            }
          }
          int lllIIIlllIlIIII = lIIIIII[0];
          lllIIIlllIlIIIl.pos(posX + lllIIIlllIlIIII, posY + FONT_HEIGHT, 0.0D).endVertex();
          lllIIIlllIlIIIl.pos(posX + lllIIIlllIlIlIl, posY + FONT_HEIGHT, 0.0D).endVertex();
          lllIIIlllIlIIIl.pos(posX + lllIIIlllIlIlIl, posY + FONT_HEIGHT - 1.0F, 0.0D).endVertex();
          lllIIIlllIlIIIl.pos(posX + lllIIIlllIlIIII, posY + FONT_HEIGHT - 1.0F, 0.0D).endVertex();
          lllIIIlllIlIIlI.draw();
          GlStateManager.enableTexture2D();
        }
        posX += lllIIIlllIlIlIl;
      }
      lllIIIlllIllllI++;
    }
  }
  
  private static boolean lllIllIl(int ???)
  {
    byte lllIIIIIIIIllIl;
    return ??? < 0;
  }
  
  private static boolean isFormatColor(char lllIIIIlIlllIIl)
  {
    ;
    if (((!lllIlIIl(lllIIIIlIlllIIl, lIIIIII[41])) || (lllIlIlI(lllIIIIlIlllIlI, lIIIIII[42]))) && ((!lllIlIIl(lllIIIIlIlllIlI, lIIIIII[43])) || (lllIlIlI(lllIIIIlIlllIlI, lIIIIII[44]))) && ((!lllIlIIl(lllIIIIlIlllIlI, lIIIIII[21])) || (lllIlIlI(lllIIIIlIlllIlI, lIIIIII[15])))) {
      return lIIIIII[0];
    }
    return lIIIIII[5];
  }
  
  private static int llllIllI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private String bidiReorder(String lllIIIlllllIlIl)
  {
    try
    {
      ;
      ;
      Bidi lllIIIlllllIlII = new Bidi(new ArabicShaping(lIIIIII[19]).shape(lllIIIlllllIIlI), lIIIIII[25]);
      lllIIIlllllIlII.setReorderingMode(lIIIIII[0]);
      return lllIIIlllllIlII.writeReordered(lIIIIII[8]);
    }
    catch (ArabicShapingException lllIIIlllllIIll) {}
    return lllIIIlllllIIlI;
  }
  
  private static int llllIlll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private ResourceLocation getUnicodePageLocation(int lllIIlIIlIlIlll)
  {
    ;
    if (llllIlII(unicodePageLocations[lllIIlIIlIllIII]))
    {
      unicodePageLocations[lllIIlIIlIllIII] = new ResourceLocation(String.format(llllll[lIIIIII[6]], new Object[] { Integer.valueOf(lllIIlIIlIllIII) }));
      unicodePageLocations[lllIIlIIlIllIII] = getHdFontLocation(unicodePageLocations[lllIIlIIlIllIII]);
    }
    return unicodePageLocations[lllIIlIIlIllIII];
  }
  
  private void readFontTexture()
  {
    try
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      BufferedImage lllIIlIlIlIlllI = TextureUtil.readBufferedImage(Minecraft.getMinecraft().getResourceManager().getResource(locationFontTexture).getInputStream());
      "".length();
      if ("   ".length() <= "  ".length()) {
        return;
      }
    }
    catch (IOException lllIIlIlIlIllII)
    {
      throw new RuntimeException(lllIIlIlIlIllII);
    }
    BufferedImage lllIIlIlIlIllIl;
    int lllIIlIlIlIlIll = lllIIlIlIlIllIl.getWidth();
    int lllIIlIlIlIlIlI = lllIIlIlIlIllIl.getHeight();
    int lllIIlIlIlIlIIl = lllIIlIlIlIlIll / lIIIIII[16];
    int lllIIlIlIlIlIII = lllIIlIlIlIlIlI / lIIIIII[16];
    float lllIIlIlIlIIlll = lllIIlIlIlIlIll / 128.0F;
    scaleFactor = lllIIlIlIlIIlll;
    int[] lllIIlIlIlIIllI = new int[lllIIlIlIlIlIll * lllIIlIlIlIlIlI];
    "".length();
    int lllIIlIlIlIIlIl = lIIIIII[0];
    "".length();
    if ("   ".length() < 0) {
      return;
    }
    while (!lllIlIIl(lllIIlIlIlIIlIl, lIIIIII[1]))
    {
      int lllIIlIlIlIIlII = lllIIlIlIlIIlIl % lIIIIII[16];
      int lllIIlIlIlIIIll = lllIIlIlIlIIlIl / lIIIIII[16];
      int lllIIlIlIlIIIlI = lIIIIII[0];
      lllIIlIlIlIIIlI = lllIIlIlIlIlIIl - lIIIIII[5];
      "".length();
      if ("   ".length() != "   ".length()) {
        return;
      }
      while (!lllIllIl(lllIIlIlIlIIIlI))
      {
        int lllIIlIlIlIIIIl = lllIIlIlIlIIlII * lllIIlIlIlIlIIl + lllIIlIlIlIIIlI;
        boolean lllIIlIlIlIIIII = lIIIIII[5];
        int lllIIlIlIIlllll = lIIIIII[0];
        "".length();
        if (-" ".length() >= "   ".length()) {
          return;
        }
        while ((lllIlIll(lllIIlIlIIlllll, lllIIlIlIlIlIII)) && (!lllIllII(lllIIlIlIlIIIII)))
        {
          int lllIIlIlIIllllI = (lllIIlIlIlIIIll * lllIIlIlIlIlIII + lllIIlIlIIlllll) * lllIIlIlIlIlIll;
          int lllIIlIlIIlllIl = lllIIlIlIlIIllI[(lllIIlIlIlIIIIl + lllIIlIlIIllllI)];
          int lllIIlIlIIlllII = lllIIlIlIIlllIl >> lIIIIII[20] & lIIIIII[18];
          if (lllIlIlI(lllIIlIlIIlllII, lIIIIII[16])) {
            lllIIlIlIlIIIII = lIIIIII[0];
          }
          lllIIlIlIIlllll++;
        }
        if (lllIllII(lllIIlIlIlIIIII))
        {
          "".length();
          if (((0xC ^ 0x50 ^ 0x77 ^ 0x60) & (0x55 ^ 0x37 ^ 0x68 ^ 0x41 ^ -" ".length())) == 0) {
            break;
          }
          return;
        }
        lllIIlIlIlIIIlI--;
      }
      if (lllIIlll(lllIIlIlIlIIlIl, lIIIIII[21])) {
        lllIIlIlIlIIlIl = lllIIlIlIlIIlIl;
      }
      if (lllIIlll(lllIIlIlIlIIlIl, lIIIIII[4])) {
        if (lllIlllI(lllIIlIlIlIlIIl, lIIIIII[19]))
        {
          lllIIlIlIlIIIlI = (int)(2.0F * lllIIlIlIlIIlll);
          "".length();
          if (" ".length() != 0) {}
        }
        else
        {
          lllIIlIlIlIIIlI = (int)(1.5F * lllIIlIlIlIIlll);
        }
      }
      charWidth[lllIIlIlIlIIlIl] = ((lllIIlIlIlIIIlI + lIIIIII[5]) / lllIIlIlIlIIlll + 1.0F);
    }
    lllIIlIlIIllIll.readCustomCharWidths();
  }
  
  private void renderSplitString(String lllIIIlIIlIIIII, int lllIIIlIIIllIII, int lllIIIlIIIlIlll, int lllIIIlIIIlIllI, boolean lllIIIlIIIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    char lllIIIlIIIlIIll = lllIIIlIIlIIIIl.listFormattedStringToWidth(lllIIIlIIlIIIII, lllIIIlIIIlIllI).iterator();
    "".length();
    if (((0x4C ^ 0xB) & (0x50 ^ 0x17 ^ 0xFFFFFFFF)) >= (0x55 ^ 0x51)) {
      return;
    }
    while (!lllIllII(lllIIIlIIIlIIll.hasNext()))
    {
      Object lllIIIlIIIllIll = lllIIIlIIIlIIll.next();
      "".length();
      lllIIIlIIIlIlll += FONT_HEIGHT;
    }
  }
  
  public int drawStringWithShadow(String lllIIlIIIlIIIIl, float lllIIlIIIlIIIII, float lllIIlIIIlIIlII, int lllIIlIIIlIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    return lllIIlIIIlIIIlI.drawString(lllIIlIIIlIIIIl, lllIIlIIIlIIlIl, lllIIlIIIlIIlII, lllIIlIIIlIIIll, lIIIIII[5]);
  }
  
  public int getColorCode(char lllIIIIlIIlllll)
  {
    ;
    ;
    ;
    int lllIIIIlIIllllI = llllll[lIIIIII[24]].indexOf(lllIIIIlIIlllll);
    if ((llllIlIl(lllIIIIlIIllllI)) && (lllIlIll(lllIIIIlIIllllI, colorCode.length)))
    {
      "".length();
      if ("   ".length() <= "   ".length()) {
        break label105;
      }
      return (0xC7 ^ 0xAB ^ 0x4B ^ 0xB) & (0xB7 ^ 0xC1 ^ 0xD1 ^ 0x8B ^ -" ".length());
    }
    label105:
    return lIIIIII[52];
  }
  
  private int sizeStringToWidth(String lllIIIIllIIIlII, int lllIIIIllIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllIIIIllIIllII = lllIIIIllIIIlII.length();
    float lllIIIIllIIlIll = 0.0F;
    int lllIIIIllIIlIlI = lIIIIII[0];
    int lllIIIIllIIlIIl = lIIIIII[22];
    boolean lllIIIIllIIlIII = lIIIIII[0];
    "".length();
    if ("   ".length() < "   ".length()) {
      return (0xAF ^ 0x94 ^ 0x30 ^ 0x0) & (0xBC ^ 0x8E ^ 0x8 ^ 0x31 ^ -" ".length());
    }
    while (!lllIlIIl(lllIIIIllIIlIlI, lllIIIIllIIllII))
    {
      char lllIIIIllIIIlll = lllIIIIllIIlllI.charAt(lllIIIIllIIlIlI);
      switch (lllIIIIllIIIlll)
      {
      case '\n': 
        lllIIIIllIIlIlI--;
        "".length();
        if (" ".length() == "   ".length()) {
          return (0x86 ^ 0xC7) & (0x17 ^ 0x56 ^ 0xFFFFFFFF);
        }
        break;
      case ' ': 
        lllIIIIllIIlIIl = lllIIIIllIIlIlI;
      default: 
        lllIIIIllIIlIll += lllIIIIllIIIlIl.getCharWidthFloat(lllIIIIllIIIlll);
        if (lllIlIII(lllIIIIllIIlIII))
        {
          lllIIIIllIIlIll += 1.0F;
          "".length();
          if (null != null) {
            return (0x2A ^ 0x1B) & (0x8D ^ 0xBC ^ 0xFFFFFFFF);
          }
        }
        break;
      case '§': 
        if (lllIlIll(lllIIIIllIIlIlI, lllIIIIllIIllII - lIIIIII[5]))
        {
          lllIIIIllIIlIlI++;
          char lllIIIIllIIIllI = lllIIIIllIIlllI.charAt(lllIIIIllIIlIlI);
          if ((lllIllll(lllIIIIllIIIllI, lIIIIII[36])) && (lllIllll(lllIIIIllIIIllI, lIIIIII[37])))
          {
            if ((!lllIllll(lllIIIIllIIIllI, lIIIIII[38])) || (!lllIllll(lllIIIIllIIIllI, lIIIIII[39])) || (lllIlIII(isFormatColor(lllIIIIllIIIllI))))
            {
              lllIIIIllIIlIII = lIIIIII[0];
              "".length();
              if (null != null) {
                return (0x9E ^ 0xB5) & (0x88 ^ 0xA3 ^ 0xFFFFFFFF);
              }
            }
          }
          else {
            lllIIIIllIIlIII = lIIIIII[5];
          }
        }
        break;
      }
      if (lllIIlll(lllIIIIllIIIlll, lIIIIII[40]))
      {
        lllIIIIllIIlIlI++;
        lllIIIIllIIlIIl = lllIIIIllIIlIlI;
        "".length();
        if ((94 + 117 - 185 + 115 ^ 47 + 72 - 83 + 101) != "  ".length()) {
          break;
        }
        return (0xD1 ^ 0xAA ^ 0xF5 ^ 0xAA) & (0xF0 ^ 0x83 ^ 0x59 ^ 0xE ^ -" ".length());
      }
      if (lllllIII(llllllII(lllIIIIllIIlIll, lllIIIIllIIllIl)))
      {
        "".length();
        if (((112 + 43 - 115 + 88 ^ 121 + 3 - 15 + 64) & (0xE4 ^ 0xBC ^ 0x3A ^ 0x4F ^ -" ".length())) <= "   ".length()) {
          break;
        }
        return (0x20 ^ 0x15 ^ 0x2 ^ 0x79) & (13 + 72 - 47 + 102 ^ '' + 50 - 147 + 133 ^ -" ".length());
      }
      lllIIIIllIIlIlI++;
    }
    if ((lllIllll(lllIIIIllIIlIlI, lllIIIIllIIllII)) && (lllIllll(lllIIIIllIIlIIl, lIIIIII[22])) && (lllIlIll(lllIIIIllIIlIIl, lllIIIIllIIlIlI)))
    {
      "".length();
      if (-" ".length() == -" ".length()) {
        break label666;
      }
      return (0xF9 ^ 0xA7) & (0x36 ^ 0x68 ^ 0xFFFFFFFF);
    }
    label666:
    return lllIIIIllIIlIlI;
  }
  
  private static boolean lllllIll(Object ???)
  {
    byte lllIIIIIIIlIlll;
    return ??? != null;
  }
  
  public void drawSplitString(String lllIIIlIIllIlII, int lllIIIlIIlIllIl, int lllIIIlIIllIIlI, int lllIIIlIIlIlIll, int lllIIIlIIllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllIIIlIIllIlIl.resetStyles();
    textColor = lllIIIlIIllIIII;
    lllIIIlIIllIlII = lllIIIlIIllIlIl.trimStringNewline(lllIIIlIIllIlII);
    lllIIIlIIllIlIl.renderSplitString(lllIIIlIIllIlII, lllIIIlIIlIllIl, lllIIIlIIllIIlI, lllIIIlIIlIlIll, lIIIIII[0]);
  }
}

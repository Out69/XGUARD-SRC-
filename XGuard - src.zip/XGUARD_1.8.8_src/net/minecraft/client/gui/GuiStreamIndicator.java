package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.stream.IStream;

public class GuiStreamIndicator
{
  private int func_152440_b()
  {
    ;
    if (lllIIlIlllII(mc.getTwitchStream().isPaused()))
    {
      "".length();
      if ((0x36 ^ 0x32) >= "   ".length()) {
        break label61;
      }
      return (0x7F ^ 0x3E) & (0x42 ^ 0x3 ^ 0xFFFFFFFF);
    }
    label61:
    return lIIlIIIlIII[0];
  }
  
  private static int lllIIlIllllI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lllIIlIlllIl(int ???)
  {
    short lllllllllllllllllIlIIlIlIllIlIll;
    return ??? > 0;
  }
  
  static
  {
    lllIIlIllIll();
    lllIIlIllIII();
  }
  
  private void render(int lllllllllllllllllIlIIlIllIIlllIl, int lllllllllllllllllIlIIlIllIIlIIII, int lllllllllllllllllIlIIlIllIIIllll, int lllllllllllllllllIlIIlIllIIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 0.65F + 0.35000002F * field_152443_c);
    mc.getTextureManager().bindTexture(locationStreamIndicator);
    float lllllllllllllllllIlIIlIllIIllIIl = 150.0F;
    float lllllllllllllllllIlIIlIllIIllIII = 0.0F;
    float lllllllllllllllllIlIIlIllIIlIlll = lllllllllllllllllIlIIlIllIIIllll * 0.015625F;
    float lllllllllllllllllIlIIlIllIIlIllI = 1.0F;
    float lllllllllllllllllIlIIlIllIIlIlIl = (lllllllllllllllllIlIIlIllIIIllll + lIIlIIIlIII[6]) * 0.015625F;
    Tessellator lllllllllllllllllIlIIlIllIIlIlII = Tessellator.getInstance();
    WorldRenderer lllllllllllllllllIlIIlIllIIlIIll = lllllllllllllllllIlIIlIllIIlIlII.getWorldRenderer();
    lllllllllllllllllIlIIlIllIIlIIll.begin(lIIlIIIlIII[3], DefaultVertexFormats.POSITION_TEX);
    lllllllllllllllllIlIIlIllIIlIIll.pos(lllllllllllllllllIlIIlIllIIlllIl - lIIlIIIlIII[6] - lllllllllllllllllIlIIlIllIIllIlI, lllllllllllllllllIlIIlIllIIlllII + lIIlIIIlIII[6], lllllllllllllllllIlIIlIllIIllIIl).tex(lllllllllllllllllIlIIlIllIIllIII, lllllllllllllllllIlIIlIllIIlIlIl).endVertex();
    lllllllllllllllllIlIIlIllIIlIIll.pos(lllllllllllllllllIlIIlIllIIlllIl - lllllllllllllllllIlIIlIllIIllIlI, lllllllllllllllllIlIIlIllIIlllII + lIIlIIIlIII[6], lllllllllllllllllIlIIlIllIIllIIl).tex(lllllllllllllllllIlIIlIllIIlIllI, lllllllllllllllllIlIIlIllIIlIlIl).endVertex();
    lllllllllllllllllIlIIlIllIIlIIll.pos(lllllllllllllllllIlIIlIllIIlllIl - lllllllllllllllllIlIIlIllIIllIlI, lllllllllllllllllIlIIlIllIIlllII + lIIlIIIlIII[0], lllllllllllllllllIlIIlIllIIllIIl).tex(lllllllllllllllllIlIIlIllIIlIllI, lllllllllllllllllIlIIlIllIIlIlll).endVertex();
    lllllllllllllllllIlIIlIllIIlIIll.pos(lllllllllllllllllIlIIlIllIIlllIl - lIIlIIIlIII[6] - lllllllllllllllllIlIIlIllIIllIlI, lllllllllllllllllIlIIlIllIIlllII + lIIlIIIlIII[0], lllllllllllllllllIlIIlIllIIllIIl).tex(lllllllllllllllllIlIIlIllIIllIII, lllllllllllllllllIlIIlIllIIlIlll).endVertex();
    lllllllllllllllllIlIIlIllIIlIlII.draw();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
  }
  
  private static String lllIIlIlIlll(String lllllllllllllllllIlIIlIlIlllIlII, String lllllllllllllllllIlIIlIlIlllIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIlIIlIlIllllIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIIlIlIlllIIll.getBytes(StandardCharsets.UTF_8)), lIIlIIIlIII[10]), "DES");
      Cipher lllllllllllllllllIlIIlIlIllllIII = Cipher.getInstance("DES");
      lllllllllllllllllIlIIlIlIllllIII.init(lIIlIIIlIII[11], lllllllllllllllllIlIIlIlIllllIIl);
      return new String(lllllllllllllllllIlIIlIlIllllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIIlIlIlllIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIlIIlIlIlllIlll)
    {
      lllllllllllllllllIlIIlIlIlllIlll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIllIIIII(int ???)
  {
    double lllllllllllllllllIlIIlIlIllIllIl;
    return ??? < 0;
  }
  
  private int func_152438_c()
  {
    ;
    if (lllIIlIlllII(mc.getTwitchStream().func_152929_G()))
    {
      "".length();
      if (-"   ".length() < 0) {
        break label90;
      }
      return (32 + 89 - 0 + 26 ^ 99 + 104 - 151 + 91) & (0x9C ^ 0x94 ^ 0x7 ^ 0x13 ^ -" ".length());
    }
    label90:
    return lIIlIIIlIII[8];
  }
  
  private static void lllIIlIllIll()
  {
    lIIlIIIlIII = new int[12];
    lIIlIIIlIII[0] = ((0x8F ^ 0xB7) & (0x79 ^ 0x41 ^ 0xFFFFFFFF));
    lIIlIIIlIII[1] = " ".length();
    lIIlIIIlIII[2] = (0x5C ^ 0x70 ^ 0x97 ^ 0xAF);
    lIIlIIIlIII[3] = (15 + 22 - -121 + 20 ^ '' + 114 - 211 + 140);
    lIIlIIIlIII[4] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIIlIIIlIII[5] = (0x19 ^ 0x8);
    lIIlIIIlIII[6] = (0x10 ^ 0x7A ^ 0x40 ^ 0x3A);
    lIIlIIIlIII[7] = (92 + 116 - 139 + 92 ^ 66 + 0 - 39 + 118);
    lIIlIIIlIII[8] = (0x63 ^ 0x43);
    lIIlIIIlIII[9] = (-" ".length());
    lIIlIIIlIII[10] = (0x1F ^ 0x17);
    lIIlIIIlIII[11] = "  ".length();
  }
  
  public void func_152439_a()
  {
    ;
    if (lllIIlIlllII(mc.getTwitchStream().isBroadcasting()))
    {
      field_152443_c += 0.025F * field_152444_d;
      if (lllIIllIIIII(lllIIlIllllI(field_152443_c, 0.0F)))
      {
        field_152444_d *= lIIlIIIlIII[9];
        field_152443_c = 0.0F;
        "".length();
        if (null == null) {}
      }
      else if (lllIIlIlllIl(lllIIlIlllll(field_152443_c, 1.0F)))
      {
        field_152444_d *= lIIlIIIlIII[9];
        field_152443_c = 1.0F;
        "".length();
        if (null == null) {}
      }
    }
    else
    {
      field_152443_c = 1.0F;
      field_152444_d = lIIlIIIlIII[1];
    }
  }
  
  public void render(int lllllllllllllllllIlIIlIllIllIlIl, int lllllllllllllllllIlIIlIlllIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIlIlllII(mc.getTwitchStream().isBroadcasting()))
    {
      GlStateManager.enableBlend();
      int lllllllllllllllllIlIIlIllIllllll = mc.getTwitchStream().func_152920_A();
      if (lllIIlIlllIl(lllllllllllllllllIlIIlIllIllllll))
      {
        String lllllllllllllllllIlIIlIllIlllllI = String.valueOf(new StringBuilder().append(lllllllllllllllllIlIIlIllIllllll));
        int lllllllllllllllllIlIIlIllIllllIl = Minecraft.fontRendererObj.getStringWidth(lllllllllllllllllIlIIlIllIlllllI);
        int lllllllllllllllllIlIIlIllIllllII = lIIlIIIlIII[2];
        int lllllllllllllllllIlIIlIllIlllIll = lllllllllllllllllIlIIlIlllIIIIIl - lllllllllllllllllIlIIlIllIllllIl - lIIlIIIlIII[1];
        int lllllllllllllllllIlIIlIllIlllIlI = lllllllllllllllllIlIIlIlllIIIIII + lIIlIIIlIII[2] - lIIlIIIlIII[1];
        int lllllllllllllllllIlIIlIllIlllIIl = lllllllllllllllllIlIIlIlllIIIIII + lIIlIIIlIII[2] + fontRendererObjFONT_HEIGHT - lIIlIIIlIII[1];
        GlStateManager.disableTexture2D();
        Tessellator lllllllllllllllllIlIIlIllIlllIII = Tessellator.getInstance();
        WorldRenderer lllllllllllllllllIlIIlIllIllIlll = lllllllllllllllllIlIIlIllIlllIII.getWorldRenderer();
        GlStateManager.color(0.0F, 0.0F, 0.0F, (0.65F + 0.35000002F * field_152443_c) / 2.0F);
        lllllllllllllllllIlIIlIllIllIlll.begin(lIIlIIIlIII[3], DefaultVertexFormats.POSITION);
        lllllllllllllllllIlIIlIllIllIlll.pos(lllllllllllllllllIlIIlIllIlllIll, lllllllllllllllllIlIIlIllIlllIIl, 0.0D).endVertex();
        lllllllllllllllllIlIIlIllIllIlll.pos(lllllllllllllllllIlIIlIlllIIIIIl, lllllllllllllllllIlIIlIllIlllIIl, 0.0D).endVertex();
        lllllllllllllllllIlIIlIllIllIlll.pos(lllllllllllllllllIlIIlIlllIIIIIl, lllllllllllllllllIlIIlIllIlllIlI, 0.0D).endVertex();
        lllllllllllllllllIlIIlIllIllIlll.pos(lllllllllllllllllIlIIlIllIlllIll, lllllllllllllllllIlIIlIllIlllIlI, 0.0D).endVertex();
        lllllllllllllllllIlIIlIllIlllIII.draw();
        GlStateManager.enableTexture2D();
        "".length();
      }
      lllllllllllllllllIlIIlIllIllIllI.render(lllllllllllllllllIlIIlIlllIIIIIl, lllllllllllllllllIlIIlIlllIIIIII, lllllllllllllllllIlIIlIllIllIllI.func_152440_b(), lIIlIIIlIII[0]);
      lllllllllllllllllIlIIlIllIllIllI.render(lllllllllllllllllIlIIlIlllIIIIIl, lllllllllllllllllIlIIlIlllIIIIII, lllllllllllllllllIlIIlIllIllIllI.func_152438_c(), lIIlIIIlIII[5]);
    }
  }
  
  private static boolean lllIIlIlllII(int ???)
  {
    float lllllllllllllllllIlIIlIlIllIllll;
    return ??? != 0;
  }
  
  private static void lllIIlIllIII()
  {
    lIIlIIIIlll = new String[lIIlIIIlIII[1]];
    lIIlIIIIlll[lIIlIIIlIII[0]] = lllIIlIlIlll("rNH5WjIj9fIhsRuLPu56q6bGSKQ5aUgx/dXsn1KNXOe5Nq6CLDrPXQ==", "ljIRq");
  }
  
  private static int lllIIlIlllll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public GuiStreamIndicator(Minecraft lllllllllllllllllIlIIlIlllIIllll)
  {
    mc = lllllllllllllllllIlIIlIlllIIllll;
  }
}

package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.BlockTallGrass.EnumType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.gen.FlatGeneratorInfo;
import net.minecraft.world.gen.FlatLayerInfo;
import org.lwjgl.input.Keyboard;

public class GuiFlatPresets
  extends GuiScreen
{
  protected void keyTyped(char llIIllIIIllIlIl, int llIIllIIIllIlII)
    throws IOException
  {
    ;
    ;
    ;
    if (llIllIlII(field_146433_u.textboxKeyTyped(llIIllIIIllIIlI, llIIllIIIllIlII))) {
      llIIllIIIllIIll.keyTyped(llIIllIIIllIIlI, llIIllIIIllIlII);
    }
  }
  
  static
  {
    llIllIIll();
    llIllIIlI();
    FLAT_WORLD_PRESETS = Lists.newArrayList();
    func_146421_a(lIIIlIIl[lIIIlIlI[0]], Item.getItemFromBlock(Blocks.grass), BiomeGenBase.plains, Arrays.asList(new String[] { lIIIlIIl[lIIIlIlI[1]] }), new FlatLayerInfo[] { new FlatLayerInfo(lIIIlIlI[1], Blocks.grass), new FlatLayerInfo(lIIIlIlI[3], Blocks.dirt), new FlatLayerInfo(lIIIlIlI[1], Blocks.bedrock) });
    func_146421_a(lIIIlIIl[lIIIlIlI[3]], Item.getItemFromBlock(Blocks.stone), BiomeGenBase.extremeHills, Arrays.asList(new String[] { lIIIlIIl[lIIIlIlI[2]], lIIIlIIl[lIIIlIlI[5]], lIIIlIIl[lIIIlIlI[4]], lIIIlIIl[lIIIlIlI[6]], lIIIlIIl[lIIIlIlI[7]] }), new FlatLayerInfo[] { new FlatLayerInfo(lIIIlIlI[1], Blocks.grass), new FlatLayerInfo(lIIIlIlI[4], Blocks.dirt), new FlatLayerInfo(lIIIlIlI[8], Blocks.stone), new FlatLayerInfo(lIIIlIlI[1], Blocks.bedrock) });
    func_146421_a(lIIIlIIl[lIIIlIlI[9]], Items.water_bucket, BiomeGenBase.deepOcean, Arrays.asList(new String[] { lIIIlIIl[lIIIlIlI[10]], lIIIlIIl[lIIIlIlI[11]] }), new FlatLayerInfo[] { new FlatLayerInfo(lIIIlIlI[12], Blocks.water), new FlatLayerInfo(lIIIlIlI[4], Blocks.sand), new FlatLayerInfo(lIIIlIlI[4], Blocks.dirt), new FlatLayerInfo(lIIIlIlI[4], Blocks.stone), new FlatLayerInfo(lIIIlIlI[1], Blocks.bedrock) });
    func_175354_a(lIIIlIIl[lIIIlIlI[13]], Item.getItemFromBlock(Blocks.tallgrass), BlockTallGrass.EnumType.GRASS.getMeta(), BiomeGenBase.plains, Arrays.asList(new String[] { lIIIlIIl[lIIIlIlI[14]], lIIIlIIl[lIIIlIlI[15]], lIIIlIIl[lIIIlIlI[16]], lIIIlIIl[lIIIlIlI[17]], lIIIlIIl[lIIIlIlI[18]], lIIIlIIl[lIIIlIlI[19]], lIIIlIIl[lIIIlIlI[20]], lIIIlIIl[lIIIlIlI[21]] }), new FlatLayerInfo[] { new FlatLayerInfo(lIIIlIlI[1], Blocks.grass), new FlatLayerInfo(lIIIlIlI[2], Blocks.dirt), new FlatLayerInfo(lIIIlIlI[22], Blocks.stone), new FlatLayerInfo(lIIIlIlI[1], Blocks.bedrock) });
    func_146421_a(lIIIlIIl[lIIIlIlI[23]], Item.getItemFromBlock(Blocks.snow_layer), BiomeGenBase.icePlains, Arrays.asList(new String[] { lIIIlIIl[lIIIlIlI[24]], lIIIlIIl[lIIIlIlI[25]] }), new FlatLayerInfo[] { new FlatLayerInfo(lIIIlIlI[1], Blocks.snow_layer), new FlatLayerInfo(lIIIlIlI[1], Blocks.grass), new FlatLayerInfo(lIIIlIlI[2], Blocks.dirt), new FlatLayerInfo(lIIIlIlI[22], Blocks.stone), new FlatLayerInfo(lIIIlIlI[1], Blocks.bedrock) });
    func_146421_a(lIIIlIIl[lIIIlIlI[26]], Items.feather, BiomeGenBase.plains, Arrays.asList(new String[] { lIIIlIIl[lIIIlIlI[27]], lIIIlIIl[lIIIlIlI[28]] }), new FlatLayerInfo[] { new FlatLayerInfo(lIIIlIlI[1], Blocks.grass), new FlatLayerInfo(lIIIlIlI[2], Blocks.dirt), new FlatLayerInfo(lIIIlIlI[3], Blocks.cobblestone) });
    func_146421_a(lIIIlIIl[lIIIlIlI[29]], Item.getItemFromBlock(Blocks.sand), BiomeGenBase.desert, Arrays.asList(new String[] { lIIIlIIl[lIIIlIlI[30]], lIIIlIIl[lIIIlIlI[31]], lIIIlIIl[lIIIlIlI[32]], lIIIlIIl[lIIIlIlI[33]], lIIIlIIl[lIIIlIlI[34]], lIIIlIIl[lIIIlIlI[35]] }), new FlatLayerInfo[] { new FlatLayerInfo(lIIIlIlI[9], Blocks.sand), new FlatLayerInfo(lIIIlIlI[36], Blocks.sandstone), new FlatLayerInfo(lIIIlIlI[2], Blocks.stone), new FlatLayerInfo(lIIIlIlI[1], Blocks.bedrock) });
    func_146425_a(lIIIlIIl[lIIIlIlI[37]], Items.redstone, BiomeGenBase.desert, new FlatLayerInfo[] { new FlatLayerInfo(lIIIlIlI[36], Blocks.sandstone), new FlatLayerInfo(lIIIlIlI[2], Blocks.stone), new FlatLayerInfo(lIIIlIlI[1], Blocks.bedrock) });
  }
  
  private static boolean llIllIllI(int ???, int arg1)
  {
    int i;
    short llIIlIllIlIIIll;
    return ??? == i;
  }
  
  private static String llIllIIIl(String llIIlIlllIIIIIl, String llIIlIllIlllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llIIlIlllIIIIIl = new String(Base64.getDecoder().decode(llIIlIlllIIIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llIIlIllIllllll = new StringBuilder();
    char[] llIIlIllIlllllI = llIIlIllIlllIll.toCharArray();
    int llIIlIllIllllIl = lIIIlIlI[0];
    char llIIlIllIllIlll = llIIlIlllIIIIIl.toCharArray();
    long llIIlIllIllIllI = llIIlIllIllIlll.length;
    float llIIlIllIllIlIl = lIIIlIlI[0];
    while (llIllllII(llIIlIllIllIlIl, llIIlIllIllIllI))
    {
      char llIIlIlllIIIIlI = llIIlIllIllIlll[llIIlIllIllIlIl];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(llIIlIllIllllll);
  }
  
  private boolean func_146430_p()
  {
    ;
    if (((!llIllIlll(field_146435_s.field_148175_k, lIIIlIlI[52])) || (llIlllIII(field_146435_s.field_148175_k, FLAT_WORLD_PRESETS.size()))) && (llIlllIIl(field_146433_u.getText().length(), lIIIlIlI[1]))) {
      return lIIIlIlI[0];
    }
    return lIIIlIlI[1];
  }
  
  public void updateScreen()
  {
    ;
    field_146433_u.updateCursorCounter();
    llIIllIIIIlllII.updateScreen();
  }
  
  private static void func_146425_a(String llIIllIIIIIlIlI, Item llIIllIIIIIlIIl, BiomeGenBase llIIllIIIIIllII, FlatLayerInfo... llIIllIIIIIIlll)
  {
    ;
    ;
    ;
    ;
    func_175354_a(llIIllIIIIIlIlI, llIIllIIIIIlIIl, lIIIlIlI[0], llIIllIIIIIllII, null, llIIllIIIIIIlll);
  }
  
  private static void func_146421_a(String llIIllIIIIIIIIl, Item llIIlIllllllIll, BiomeGenBase llIIlIlllllllll, List<String> llIIlIllllllIIl, FlatLayerInfo... llIIlIllllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    func_175354_a(llIIllIIIIIIIIl, llIIlIllllllIll, lIIIlIlI[0], llIIlIllllllIlI, llIIlIllllllIIl, llIIlIllllllIII);
  }
  
  private static String llIlIllll(String llIIlIllIlIlIlI, String llIIlIllIlIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIIlIllIlIllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llIIlIllIlIlIll.getBytes(StandardCharsets.UTF_8)), lIIIlIlI[9]), "DES");
      Cipher llIIlIllIlIlllI = Cipher.getInstance("DES");
      llIIlIllIlIlllI.init(lIIIlIlI[3], llIIlIllIlIllll);
      return new String(llIIlIllIlIlllI.doFinal(Base64.getDecoder().decode(llIIlIllIlIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIIlIllIlIllIl)
    {
      llIIlIllIlIllIl.printStackTrace();
    }
    return null;
  }
  
  public GuiFlatPresets(GuiCreateFlatWorld llIIllIIlIIllll)
  {
    parentScreen = llIIllIIlIIllll;
  }
  
  private static void llIllIIlI()
  {
    lIIIlIIl = new String[lIIIlIlI[53]];
    lIIIlIIl[lIIIlIlI[0]] = llIlIllll("gsJcJauKtkjhXn2TWaPUvA==", "VcPlV");
    lIIIlIIl[lIIIlIlI[1]] = llIllIIII("3dyxvDkyQh8=", "NWgzw");
    lIIIlIIl[lIIIlIlI[3]] = llIllIIIl("ICMdHj8YMwEDfVQSARU7GQ==", "tVspZ");
    lIIIlIIl[lIIIlIlI[2]] = llIllIIIl("GhEYORInSQ==", "xxwTw");
    lIIIlIIl[lIIIlIlI[5]] = llIlIllll("fGtDKcbhWD8=", "jLACa");
    lIIIlIIl[lIIIlIlI[4]] = llIllIIII("BfZjkum5blNK93Mdd6OZLA==", "UqxgG");
    lIIIlIIl[lIIIlIlI[6]] = llIllIIII("ljmni/h/VLA3tw9poqEvng==", "OZDoR");
    lIIIlIIl[lIIIlIlI[7]] = llIlIllll("zCzN89eT/HxnDLRwk3jpwQ==", "lVofT");
    lIIIlIIl[lIIIlIlI[9]] = llIllIIIl("PCcBNStLERoiNQ8=", "kFuPY");
    lIIIlIIl[lIIIlIlI[10]] = llIlIllll("p52dEi+uZtg=", "EZPaG");
    lIIIlIIl[lIIIlIlI[11]] = llIllIIII("WZBFxALdVO7t/SNr+SofCA==", "jkRIl");
    lIIIlIIl[lIIIlIlI[13]] = llIllIIII("R7be1nboYhE6zpH3TTjGQA==", "raKZB");
    lIIIlIIl[lIIIlIlI[14]] = llIlIllll("3/ZhRKjIck8=", "XsnBb");
    lIIIlIIl[lIIIlIlI[15]] = llIllIIIl("BwoVGCY6Ug==", "eczuC");
    lIIIlIIl[lIIIlIlI[16]] = llIllIIIl("JgsJAxEjGgMDDQ==", "Bnjlc");
    lIIIlIIl[lIIIlIlI[17]] = llIlIllll("fTXD7Hv4R5cQCRxv1qwMLA==", "oUabJ");
    lIIIlIIl[lIIIlIlI[18]] = llIlIllll("H3RKIwOwjmiLdp2mtUcHJA==", "diPwi");
    lIIIlIIl[lIIIlIlI[19]] = llIllIIII("fSkCo3N3bJA=", "TXwxQ");
    lIIIlIIl[lIIIlIlI[20]] = llIllIIII("2SWN7iPRMBc=", "hjHsz");
    lIIIlIIl[lIIIlIlI[21]] = llIllIIII("TjJvBph2YvhZ9b475N5fTg==", "zMsQi");
    lIIIlIIl[lIIIlIlI[23]] = llIllIIII("w0I+YaP7BxNaUNpKXnztDA==", "iOwzT");
    lIIIlIIl[lIIIlIlI[24]] = llIllIIIl("MygtIDAiJA==", "EAALQ");
    lIIIlIIl[lIIIlIlI[25]] = llIllIIIl("GycaGhcmfw==", "yNuwr");
    lIIIlIIl[lIIIlIlI[26]] = llIllIIII("9pjUVDKAoZQPZm41yO5HyQ==", "yZRcx");
    lIIIlIIl[lIIIlIlI[27]] = llIlIllll("gzTlXw1DHCc=", "iNCLM");
    lIIIlIIl[lIIIlIlI[28]] = llIlIllll("VTxpTO5hzJY=", "kOfcX");
    lIIIlIIl[lIIIlIlI[29]] = llIlIllll("TXtdNQiHctY=", "VtSXu");
    lIIIlIIl[lIIIlIlI[30]] = llIllIIIl("HRomOi4MFg==", "ksJVO");
    lIIIlIIl[lIIIlIlI[31]] = llIllIIIl("Dw0rLwMyVQ==", "mdDBf");
    lIIIlIIl[lIIIlIlI[32]] = llIlIllll("vAoOPh1sI88hRvAhPfptYA==", "hYrOX");
    lIIIlIIl[lIIIlIlI[33]] = llIlIllll("jR7CMl+cwSbfWmAzd0Yb+g==", "TOsIn");
    lIIIlIIl[lIIIlIlI[34]] = llIlIllll("FpXLDFebEeiMkxq/2Rxx6w==", "AbBCe");
    lIIIlIIl[lIIIlIlI[35]] = llIllIIII("pDbZuaohItE=", "BxUQl");
    lIIIlIIl[lIIIlIlI[37]] = llIllIIII("sgzBE61NWRMtkdTb+0+Nfg==", "VnWlR");
    lIIIlIIl[lIIIlIlI[38]] = llIllIIII("ACR2aAotOh/GMBtkM0TUz5epuB5g+ZLDxg86X7PwNAbwqEuK8E90jQ==", "fHKnI");
    lIIIlIIl[lIIIlIlI[39]] = llIlIllll("iw8QnoDU+xm9Awooc8Lbf4xp5NxUx7bzE1dmACp/b5Mnonm+WOX0iQ==", "lMlAw");
    lIIIlIIl[lIIIlIlI[40]] = llIllIIII("8y8yX2OiV+ZLebbKkNE6Y2gGj654Fc0CZyyXTVWzfrJEK1R2Cjcptw==", "OZsLO");
    lIIIlIIl[lIIIlIlI[47]] = llIllIIII("T1mnLGgSUwLh6PbpZ2osgkooDIyyQDi7MikemteYcQ/FXXgrsgr7tg==", "bkmrq");
    lIIIlIIl[lIIIlIlI[48]] = llIllIIIl("JDEwSxYiKjoAGQ==", "CDYeu");
  }
  
  private static void func_175354_a(String llIIlIllllIlllI, Item llIIlIllllIllIl, int llIIlIllllIllII, BiomeGenBase llIIlIllllIlIll, List<String> llIIlIllllIIIIl, FlatLayerInfo... llIIlIllllIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    FlatGeneratorInfo llIIlIllllIlIII = new FlatGeneratorInfo();
    int llIIlIllllIIlll = llIIlIllllIlIIl.length - lIIIlIlI[1];
    "".length();
    if (((0x19 ^ 0x39) & (0x71 ^ 0x51 ^ 0xFFFFFFFF)) != 0) {
      return;
    }
    while (!llIlllIlI(llIIlIllllIIlll)) {
      "".length();
    }
    llIIlIllllIlIII.setBiome(biomeID);
    llIIlIllllIlIII.func_82645_d();
    if (llIlllIll(llIIlIllllIIIIl))
    {
      llIIlIlllIlllIl = llIIlIllllIIIIl.iterator();
      "".length();
      if (null != null) {
        return;
      }
      while (!llIllIlII(llIIlIlllIlllIl.hasNext()))
      {
        String llIIlIllllIIllI = (String)llIIlIlllIlllIl.next();
        "".length();
      }
    }
    new LayerItem(llIIlIllllIllIl, llIIlIllllIllII, llIIlIllllIlllI, llIIlIllllIlIII.toString());
    "".length();
  }
  
  protected void actionPerformed(GuiButton llIIllIIIlIllIl)
    throws IOException
  {
    ;
    ;
    if ((llIllIlII(id)) && (llIllIlIl(llIIllIIIlIllII.func_146430_p())))
    {
      parentScreen.func_146383_a(field_146433_u.getText());
      mc.displayGuiScreen(parentScreen);
      "".length();
      if (null == null) {}
    }
    else if (llIllIllI(id, lIIIlIlI[1]))
    {
      mc.displayGuiScreen(parentScreen);
    }
  }
  
  private static void llIllIIll()
  {
    lIIIlIlI = new int[54];
    lIIIlIlI[0] = ((0x5A ^ 0x7F) & (0x48 ^ 0x6D ^ 0xFFFFFFFF));
    lIIIlIlI[1] = " ".length();
    lIIIlIlI[2] = "   ".length();
    lIIIlIlI[3] = "  ".length();
    lIIIlIlI[4] = (0xB6 ^ 0xB3);
    lIIIlIlI[5] = (0xE0 ^ 0x83 ^ 0x40 ^ 0x27);
    lIIIlIlI[6] = (0x2E ^ 0x28);
    lIIIlIlI[7] = (0x58 ^ 0x61 ^ 0xBA ^ 0x84);
    lIIIlIlI[8] = (78 + 111 - 115 + 63 + ('' + 'Ë' - 234 + 101) - (101 + 'Ä' - 245 + 165) + (0x7 ^ 0x6D));
    lIIIlIlI[9] = (42 + 64 - 94 + 130 ^ 15 + 105 - 48 + 62);
    lIIIlIlI[10] = (0x41 ^ 0x48);
    lIIIlIlI[11] = (0xE7 ^ 0xC0 ^ 0x97 ^ 0xBA);
    lIIIlIlI[12] = (85 + 34 - 45 + 161 ^ 58 + 14 - -42 + 63);
    lIIIlIlI[13] = (0x2B ^ 0xA ^ 0x7E ^ 0x54);
    lIIIlIlI[14] = (0xBE ^ 0xB2);
    lIIIlIlI[15] = (0xBD ^ 0xB0);
    lIIIlIlI[16] = (106 + 86 - 96 + 46 ^ 98 + 77 - 140 + 93);
    lIIIlIlI[17] = (0x7A ^ 0x13 ^ 0x51 ^ 0x37);
    lIIIlIlI[18] = (0x4 ^ 0x1A ^ 0x61 ^ 0x6F);
    lIIIlIlI[19] = (67 + 96 - -27 + 18 ^ 20 + 84 - 29 + 118);
    lIIIlIlI[20] = (0xDE ^ 0x8B ^ 0x43 ^ 0x4);
    lIIIlIlI[21] = (0x6B ^ 0x78);
    lIIIlIlI[22] = (0x41 ^ 0x7A);
    lIIIlIlI[23] = (0xBD ^ 0xB3 ^ 0x23 ^ 0x39);
    lIIIlIlI[24] = (0xA5 ^ 0x9B ^ 0x5D ^ 0x76);
    lIIIlIlI[25] = (0xA ^ 0x1C);
    lIIIlIlI[26] = (122 + 29 - 147 + 157 ^ 123 + '¥' - 214 + 108);
    lIIIlIlI[27] = (8 + 120 - -43 + 9 ^ 88 + 108 - 87 + 63);
    lIIIlIlI[28] = (50 + 16 - 33 + 101 ^ 82 + 125 - 181 + 133);
    lIIIlIlI[29] = (0xE ^ 0x14);
    lIIIlIlI[30] = (0xA4 ^ 0xBF);
    lIIIlIlI[31] = (0xA1 ^ 0xBD);
    lIIIlIlI[32] = (0xDE ^ 0xC3);
    lIIIlIlI[33] = (0x8C ^ 0x92);
    lIIIlIlI[34] = (0xD ^ 0x12);
    lIIIlIlI[35] = (0x2B ^ 0x18 ^ 0xB1 ^ 0xA2);
    lIIIlIlI[36] = (0x4F ^ 0x7B);
    lIIIlIlI[37] = (0x12 ^ 0x33);
    lIIIlIlI[38] = (0xF6 ^ 0xA2 ^ 0xDC ^ 0xAA);
    lIIIlIlI[39] = (0x40 ^ 0x3A ^ 0xC ^ 0x55);
    lIIIlIlI[40] = (0xB9 ^ 0x8B ^ 0x98 ^ 0x8E);
    lIIIlIlI[41] = (0x38 ^ 0x29 ^ 0xA5 ^ 0x86);
    lIIIlIlI[42] = (0xC8 ^ 0xB6 ^ 0x39 ^ 0x6F);
    lIIIlIlI[43] = (0xCB ^ 0xAF);
    lIIIlIlI[44] = (-(0xDB36 & 0x3EFB) & 0xFFFFFFFF & 0x1EFF);
    lIIIlIlI[45] = ((0x56 ^ 0x3B) + (0x23 ^ 0x5E) - ('' + 54 - 139 + 93) + (0xDB ^ 0x90));
    lIIIlIlI[46] = ((0x6B ^ 0x2D) + (0x25 ^ 0x28) - (0x5D ^ 0x63) + (57 + 9 - -55 + 8));
    lIIIlIlI[47] = (0xE7 ^ 0xC2);
    lIIIlIlI[48] = (0x0 ^ 0x26);
    lIIIlIlI[49] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIIIlIlI[50] = (0xEBB1 & 0xA0B4EE);
    lIIIlIlI[51] = (0x1D ^ 0x7C ^ 0x40 ^ 0x67);
    lIIIlIlI[52] = (-" ".length());
    lIIIlIlI[53] = (0x29 ^ 0xE);
  }
  
  public void onGuiClosed()
  {
    Keyboard.enableRepeatEvents(lIIIlIlI[0]);
  }
  
  private static boolean llIlllIII(int ???, int arg1)
  {
    int i;
    boolean llIIlIllIIlllll;
    return ??? >= i;
  }
  
  private static boolean llIllllII(int ???, int arg1)
  {
    int i;
    Exception llIIlIllIIllIll;
    return ??? < i;
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    llIIllIIlIIlIII.handleMouseInput();
    field_146435_s.handleMouseInput();
  }
  
  private static boolean llIllIlII(int ???)
  {
    long llIIlIllIIIllIl;
    return ??? == 0;
  }
  
  private static boolean llIlllIlI(int ???)
  {
    long llIIlIllIIIlIll;
    return ??? < 0;
  }
  
  public void func_146426_g()
  {
    ;
    ;
    boolean llIIllIIIIllIII = llIIllIIIIllIIl.func_146430_p();
    field_146434_t.enabled = llIIllIIIIllIII;
  }
  
  public void drawScreen(int llIIllIIIlIIlIl, int llIIllIIIlIIIII, float llIIllIIIIlllll)
  {
    ;
    ;
    ;
    ;
    llIIllIIIlIIllI.drawDefaultBackground();
    field_146435_s.drawScreen(llIIllIIIlIIlIl, llIIllIIIlIIIII, llIIllIIIIlllll);
    llIIllIIIlIIllI.drawCenteredString(fontRendererObj, presetsTitle, width / lIIIlIlI[3], lIIIlIlI[9], lIIIlIlI[49]);
    llIIllIIIlIIllI.drawString(fontRendererObj, presetsShare, lIIIlIlI[41], lIIIlIlI[33], lIIIlIlI[50]);
    llIIllIIIlIIllI.drawString(fontRendererObj, field_146436_r, lIIIlIlI[41], lIIIlIlI[51], lIIIlIlI[50]);
    field_146433_u.drawTextBox();
    llIIllIIIlIIllI.drawScreen(llIIllIIIlIIlIl, llIIllIIIlIIIII, llIIllIIIIlllll);
  }
  
  private static boolean llIlllIIl(int ???, int arg1)
  {
    int i;
    boolean llIIlIllIIlIlll;
    return ??? <= i;
  }
  
  private static boolean llIllIlIl(int ???)
  {
    char llIIlIllIIIllll;
    return ??? != 0;
  }
  
  public void initGui()
  {
    ;
    buttonList.clear();
    Keyboard.enableRepeatEvents(lIIIlIlI[1]);
    presetsTitle = I18n.format(lIIIlIIl[lIIIlIlI[38]], new Object[lIIIlIlI[0]]);
    presetsShare = I18n.format(lIIIlIIl[lIIIlIlI[39]], new Object[lIIIlIlI[0]]);
    field_146436_r = I18n.format(lIIIlIIl[lIIIlIlI[40]], new Object[lIIIlIlI[0]]);
    field_146433_u = new GuiTextField(lIIIlIlI[3], fontRendererObj, lIIIlIlI[41], lIIIlIlI[42], width - lIIIlIlI[43], lIIIlIlI[23]);
    field_146435_s = new ListSlot();
    field_146433_u.setMaxStringLength(lIIIlIlI[44]);
    field_146433_u.setText(parentScreen.func_146384_e());
    field_146434_t = new GuiButton(lIIIlIlI[0], width / lIIIlIlI[3] - lIIIlIlI[45], height - lIIIlIlI[31], lIIIlIlI[46], lIIIlIlI[23], I18n.format(lIIIlIIl[lIIIlIlI[47]], new Object[lIIIlIlI[0]]));
    "".length();
    new GuiButton(lIIIlIlI[1], width / lIIIlIlI[3] + lIIIlIlI[4], height - lIIIlIlI[31], lIIIlIlI[46], lIIIlIlI[23], I18n.format(lIIIlIIl[lIIIlIlI[48]], new Object[lIIIlIlI[0]]));
    "".length();
    llIIllIIlIIlIll.func_146426_g();
  }
  
  private static String llIllIIII(String llIIlIlllIlIIIl, String llIIlIlllIlIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIIlIlllIlIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llIIlIlllIlIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llIIlIlllIlIIll = Cipher.getInstance("Blowfish");
      llIIlIlllIlIIll.init(lIIIlIlI[3], llIIlIlllIlIlII);
      return new String(llIIlIlllIlIIll.doFinal(Base64.getDecoder().decode(llIIlIlllIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIIlIlllIlIIlI)
    {
      llIIlIlllIlIIlI.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIllIlll(int ???, int arg1)
  {
    int i;
    Exception llIIlIllIIlIIll;
    return ??? > i;
  }
  
  private static boolean llIlllIll(Object ???)
  {
    long llIIlIllIIlIIIl;
    return ??? != null;
  }
  
  protected void mouseClicked(int llIIllIIlIIIIII, int llIIllIIIllllll, int llIIllIIIlllIlI)
    throws IOException
  {
    ;
    ;
    ;
    ;
    field_146433_u.mouseClicked(llIIllIIlIIIIII, llIIllIIIllllll, llIIllIIIlllIlI);
    llIIllIIIllllIl.mouseClicked(llIIllIIlIIIIII, llIIllIIIllllll, llIIllIIIlllIlI);
  }
  
  class ListSlot
    extends GuiSlot
  {
    public ListSlot()
    {
      llllllllllllllllllllIIIIlIlIlIll.<init>(mc, width, height, lIllllIIII[0], height - lIllllIIII[1], lIllllIIII[2]);
    }
    
    protected void drawBackground() {}
    
    protected void drawSlot(int llllllllllllllllllllIIIIIlIlIIII, int llllllllllllllllllllIIIIIlIIllll, int llllllllllllllllllllIIIIIlIIlllI, int llllllllllllllllllllIIIIIlIlIlIl, int llllllllllllllllllllIIIIIlIlIlII, int llllllllllllllllllllIIIIIlIlIIll)
    {
      ;
      ;
      ;
      ;
      ;
      GuiFlatPresets.LayerItem llllllllllllllllllllIIIIIlIlIIlI = (GuiFlatPresets.LayerItem)GuiFlatPresets.FLAT_WORLD_PRESETS.get(llllllllllllllllllllIIIIIlIlIIII);
      llllllllllllllllllllIIIIIlIlIIIl.func_178054_a(llllllllllllllllllllIIIIIlIIllll, llllllllllllllllllllIIIIIlIlIllI, field_148234_a, field_179037_b);
      "".length();
    }
    
    private void func_148173_e(int llllllllllllllllllllIIIIlIIlIlIl, int llllllllllllllllllllIIIIlIIlIlII)
    {
      ;
      ;
      ;
      llllllllllllllllllllIIIIlIIlIIll.func_148171_c(llllllllllllllllllllIIIIlIIlIIlI, llllllllllllllllllllIIIIlIIlIlII, lIllllIIII[6], lIllllIIII[6]);
    }
    
    private static boolean lIIlIlllIIII(int ???, int arg1)
    {
      int i;
      Exception llllllllllllllllllllIIIIIlIIlIIl;
      return ??? == i;
    }
    
    private void func_148171_c(int llllllllllllllllllllIIIIIllllIIl, int llllllllllllllllllllIIIIlIIIIIll, int llllllllllllllllllllIIIIIlllIlll, int llllllllllllllllllllIIIIIlllIllI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      mc.getTextureManager().bindTexture(Gui.statIcons);
      float llllllllllllllllllllIIIIlIIIIIII = 0.0078125F;
      float llllllllllllllllllllIIIIIlllllll = 0.0078125F;
      int llllllllllllllllllllIIIIIllllllI = lIllllIIII[7];
      int llllllllllllllllllllIIIIIlllllIl = lIllllIIII[7];
      Tessellator llllllllllllllllllllIIIIIlllllII = Tessellator.getInstance();
      WorldRenderer llllllllllllllllllllIIIIIllllIll = llllllllllllllllllllIIIIIlllllII.getWorldRenderer();
      llllllllllllllllllllIIIIIllllIll.begin(lIllllIIII[8], DefaultVertexFormats.POSITION_TEX);
      llllllllllllllllllllIIIIIllllIll.pos(llllllllllllllllllllIIIIIllllIIl + lIllllIIII[6], llllllllllllllllllllIIIIIllllIII + lIllllIIII[7], zLevel).tex((llllllllllllllllllllIIIIIlllIlll + lIllllIIII[6]) * 0.0078125F, (llllllllllllllllllllIIIIIlllIllI + lIllllIIII[7]) * 0.0078125F).endVertex();
      llllllllllllllllllllIIIIIllllIll.pos(llllllllllllllllllllIIIIIllllIIl + lIllllIIII[7], llllllllllllllllllllIIIIIllllIII + lIllllIIII[7], zLevel).tex((llllllllllllllllllllIIIIIlllIlll + lIllllIIII[7]) * 0.0078125F, (llllllllllllllllllllIIIIIlllIllI + lIllllIIII[7]) * 0.0078125F).endVertex();
      llllllllllllllllllllIIIIIllllIll.pos(llllllllllllllllllllIIIIIllllIIl + lIllllIIII[7], llllllllllllllllllllIIIIIllllIII + lIllllIIII[6], zLevel).tex((llllllllllllllllllllIIIIIlllIlll + lIllllIIII[7]) * 0.0078125F, (llllllllllllllllllllIIIIIlllIllI + lIllllIIII[6]) * 0.0078125F).endVertex();
      llllllllllllllllllllIIIIIllllIll.pos(llllllllllllllllllllIIIIIllllIIl + lIllllIIII[6], llllllllllllllllllllIIIIIllllIII + lIllllIIII[6], zLevel).tex((llllllllllllllllllllIIIIIlllIlll + lIllllIIII[6]) * 0.0078125F, (llllllllllllllllllllIIIIIlllIllI + lIllllIIII[6]) * 0.0078125F).endVertex();
      llllllllllllllllllllIIIIIlllllII.draw();
    }
    
    protected int getSize()
    {
      return GuiFlatPresets.FLAT_WORLD_PRESETS.size();
    }
    
    private static void lIIlIllIllll()
    {
      lIllllIIII = new int[12];
      lIllllIIII[0] = (0x75 ^ 0x25);
      lIllllIIII[1] = (0x8B ^ 0xAE);
      lIllllIIII[2] = (0xA ^ 0x12);
      lIllllIIII[3] = (-" ".length());
      lIllllIIII[4] = " ".length();
      lIllllIIII[5] = "  ".length();
      lIllllIIII[6] = ((0x4D ^ 0x6C) & (0x43 ^ 0x62 ^ 0xFFFFFFFF));
      lIllllIIII[7] = ('' + 81 - 157 + 97 ^ 103 + 80 - 84 + 37);
      lIllllIIII[8] = (0x8 ^ 0xF);
      lIllllIIII[9] = (0x12 ^ 0x17);
      lIllllIIII[10] = (111 + 109 - 152 + 98 ^ 5 + 14 - -81 + 60);
      lIllllIIII[11] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    }
    
    static {}
    
    protected void elementClicked(int llllllllllllllllllllIIIIIllIIllI, boolean llllllllllllllllllllIIIIIllIlIlI, int llllllllllllllllllllIIIIIllIlIIl, int llllllllllllllllllllIIIIIllIlIII)
    {
      ;
      ;
      field_148175_k = llllllllllllllllllllIIIIIllIIllI;
      func_146426_g();
      field_146433_u.setText(FLAT_WORLD_PRESETSgetfield_146435_s.field_148175_k)).field_148233_c);
    }
    
    protected boolean isSelected(int llllllllllllllllllllIIIIIllIIIII)
    {
      ;
      ;
      if (lIIlIlllIIII(llllllllllllllllllllIIIIIllIIIII, field_148175_k)) {
        return lIllllIIII[4];
      }
      return lIllllIIII[6];
    }
    
    private void func_178054_a(int llllllllllllllllllllIIIIlIlIIIlI, int llllllllllllllllllllIIIIlIIlllII, Item llllllllllllllllllllIIIIlIlIIIII, int llllllllllllllllllllIIIIlIIlllll)
    {
      ;
      ;
      ;
      ;
      ;
      llllllllllllllllllllIIIIlIlIIIll.func_148173_e(llllllllllllllllllllIIIIlIlIIIlI + lIllllIIII[4], llllllllllllllllllllIIIIlIlIIIIl + lIllllIIII[4]);
      GlStateManager.enableRescaleNormal();
      RenderHelper.enableGUIStandardItemLighting();
      itemRender.renderItemIntoGUI(new ItemStack(llllllllllllllllllllIIIIlIlIIIII, lIllllIIII[4], llllllllllllllllllllIIIIlIIlllll), llllllllllllllllllllIIIIlIlIIIlI + lIllllIIII[5], llllllllllllllllllllIIIIlIlIIIIl + lIllllIIII[5]);
      RenderHelper.disableStandardItemLighting();
      GlStateManager.disableRescaleNormal();
    }
  }
  
  static class LayerItem
  {
    public LayerItem(Item llllllllllllllllIllIlIlIllIIlIll, int llllllllllllllllIllIlIlIllIIIlIl, String llllllllllllllllIllIlIlIllIIIlII, String llllllllllllllllIllIlIlIllIIIIll)
    {
      field_148234_a = llllllllllllllllIllIlIlIllIIlIll;
      field_179037_b = llllllllllllllllIllIlIlIllIIlIlI;
      field_148232_b = llllllllllllllllIllIlIlIllIIIlII;
      field_148233_c = llllllllllllllllIllIlIlIllIIIIll;
    }
  }
}

package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class GuiConfirmOpenLink
  extends GuiYesNo
{
  private static void lllIIllIIIIIlI()
  {
    lIIlIllIIIllI = new int[16];
    lIIlIllIIIllI[0] = ((0xB0 ^ 0x93) & (0x43 ^ 0x60 ^ 0xFFFFFFFF));
    lIIlIllIIIllI[1] = " ".length();
    lIIlIllIIIllI[2] = "  ".length();
    lIIlIllIIIllI[3] = "   ".length();
    lIIlIllIIIllI[4] = (0x8C ^ 0x88);
    lIIlIllIIIllI[5] = (0x4F ^ 0xC ^ 0xC5 ^ 0x83);
    lIIlIllIIIllI[6] = (41 + '·' - 165 + 140 ^ 12 + 31 - 16 + 166);
    lIIlIllIIIllI[7] = (0x28 ^ 0x2F);
    lIIlIllIIIllI[8] = (0x49 ^ 0x7B);
    lIIlIllIIIllI[9] = (0x50 ^ 0x39);
    lIIlIllIIIllI[10] = (0x91 ^ 0xC1 ^ 0x8F ^ 0xBF);
    lIIlIllIIIllI[11] = (0xA6 ^ 0xC2);
    lIIlIllIIIllI[12] = (0x5C ^ 0x18 ^ 0xF5 ^ 0xA5);
    lIIlIllIIIllI[13] = (0x7B ^ 0x15);
    lIIlIllIIIllI[14] = (-(0xE27E & 0x1FA3) & 0xFEEF & 0xFFCFFD);
    lIIlIllIIIllI[15] = (0x7C ^ 0x74);
  }
  
  private static boolean lllIIllIIIIlIl(int ???)
  {
    String llllllllllllllIIlllIllllIIIlllII;
    return ??? == 0;
  }
  
  public GuiConfirmOpenLink(GuiYesNoCallback llllllllllllllIIlllIllllIllllIII, String llllllllllllllIIlllIllllIlllIlll, int llllllllllllllIIlllIllllIllllIll, boolean llllllllllllllIIlllIllllIlllIlIl) {}
  
  public void drawScreen(int llllllllllllllIIlllIllllIlIlllll, int llllllllllllllIIlllIllllIlIllllI, float llllllllllllllIIlllIllllIllIIIIl)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIIlllIllllIllIIlII.drawScreen(llllllllllllllIIlllIllllIlIlllll, llllllllllllllIIlllIllllIlIllllI, llllllllllllllIIlllIllllIllIIIIl);
    if (lllIIllIIIIIll(showSecurityWarning)) {
      llllllllllllllIIlllIllllIllIIlII.drawCenteredString(fontRendererObj, openLinkWarning, width / lIIlIllIIIllI[2], lIIlIllIIIllI[13], lIIlIllIIIllI[14]);
    }
  }
  
  static
  {
    lllIIllIIIIIlI();
    lllIIllIIIIIIl();
  }
  
  public void copyLinkToClipboard()
  {
    ;
    setClipboardString(linkText);
  }
  
  public void initGui()
  {
    ;
    llllllllllllllIIlllIllllIlllIIlI.initGui();
    buttonList.clear();
    new GuiButton(lIIlIllIIIllI[0], width / lIIlIllIIIllI[2] - lIIlIllIIIllI[8] - lIIlIllIIIllI[9], height / lIIlIllIIIllI[6] + lIIlIllIIIllI[10], lIIlIllIIIllI[11], lIIlIllIIIllI[12], confirmButtonText);
    "".length();
    new GuiButton(lIIlIllIIIllI[2], width / lIIlIllIIIllI[2] - lIIlIllIIIllI[8], height / lIIlIllIIIllI[6] + lIIlIllIIIllI[10], lIIlIllIIIllI[11], lIIlIllIIIllI[12], copyLinkButtonText);
    "".length();
    new GuiButton(lIIlIllIIIllI[1], width / lIIlIllIIIllI[2] - lIIlIllIIIllI[8] + lIIlIllIIIllI[9], height / lIIlIllIIIllI[6] + lIIlIllIIIllI[10], lIIlIllIIIllI[11], lIIlIllIIIllI[12], cancelButtonText);
    "".length();
  }
  
  private static boolean lllIIllIIIIlII(int ???, int arg1)
  {
    int i;
    float llllllllllllllIIlllIllllIIlIIlII;
    return ??? == i;
  }
  
  private static String lllIIlIlllllll(String llllllllllllllIIlllIllllIlIIlIlI, String llllllllllllllIIlllIllllIlIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIlllIllllIlIIlIlI = new String(Base64.getDecoder().decode(llllllllllllllIIlllIllllIlIIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIlllIllllIlIIllIl = new StringBuilder();
    char[] llllllllllllllIIlllIllllIlIIllII = llllllllllllllIIlllIllllIlIIlllI.toCharArray();
    int llllllllllllllIIlllIllllIlIIlIll = lIIlIllIIIllI[0];
    float llllllllllllllIIlllIllllIlIIIlIl = llllllllllllllIIlllIllllIlIIlIlI.toCharArray();
    byte llllllllllllllIIlllIllllIlIIIlII = llllllllllllllIIlllIllllIlIIIlIl.length;
    byte llllllllllllllIIlllIllllIlIIIIll = lIIlIllIIIllI[0];
    while (lllIIllIIIIllI(llllllllllllllIIlllIllllIlIIIIll, llllllllllllllIIlllIllllIlIIIlII))
    {
      char llllllllllllllIIlllIllllIlIlIIII = llllllllllllllIIlllIllllIlIIIlIl[llllllllllllllIIlllIllllIlIIIIll];
      "".length();
      "".length();
      if ("   ".length() != "   ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIlllIllllIlIIllIl);
  }
  
  public void disableSecurityWarning()
  {
    ;
    showSecurityWarning = lIIlIllIIIllI[0];
  }
  
  private static void lllIIllIIIIIIl()
  {
    lIIlIllIIIlIl = new String[lIIlIllIIIllI[15]];
    lIIlIllIIIlIl[lIIlIllIIIllI[0]] = lllIIlIllllllI("zrVT9p9PVd+Q0YknyYHvvOIxRFaCCpJBGOmj/XReTo8=", "IFZuU");
    lIIlIllIIIlIl[lIIlIllIIIllI[1]] = lllIIlIlllllll("BictBlwJJiIZXAYgIhQbFyI=", "eOLrr");
    lIIlIllIIIlIl[lIIlIllIIIllI[2]] = lllIIlIllllllI("RqGjEkcmkCaaVp4hlvV4zg==", "VZVbt");
    lIIlIllIIIlIl[lIIlIllIIIllI[3]] = lllIIlIllllllI("5gWzR+uf9/0=", "oqfSY");
    lIIlIllIIIlIl[lIIlIllIIIllI[4]] = lllIIlIlllllll("AxsRaTAFABsiPw==", "dnxGS");
    lIIlIllIIIlIl[lIIlIllIIIllI[5]] = lllIIllIIIIIII("EZ9THE0pI4M=", "bOBfe");
    lIIlIllIIIlIl[lIIlIllIIIllI[6]] = lllIIlIllllllI("SBpNSNTCiKtUmzg1F4EcoQ==", "NUZXi");
    lIIlIllIIIlIl[lIIlIllIIIllI[7]] = lllIIllIIIIIII("D30XbnuZVPjCddLWyrB0Y5ScAh6pitWO", "IJMgw");
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIIlllIllllIllIlllI)
    throws IOException
  {
    ;
    ;
    if (lllIIllIIIIlII(id, lIIlIllIIIllI[2])) {
      llllllllllllllIIlllIllllIllIllIl.copyLinkToClipboard();
    }
    if (lllIIllIIIIlIl(id))
    {
      "".length();
      if (-"   ".length() <= 0) {
        break label59;
      }
    }
    label59:
    lIIlIllIIIllI[1].confirmClicked(lIIlIllIIIllI[0], parentButtonClickedId);
  }
  
  private static String lllIIllIIIIIII(String llllllllllllllIIlllIllllIIlllIlI, String llllllllllllllIIlllIllllIIlllIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIlllIllllIIllllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIIlllIllllIIlllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIIlllIllllIIllllII = Cipher.getInstance("Blowfish");
      llllllllllllllIIlllIllllIIllllII.init(lIIlIllIIIllI[2], llllllllllllllIIlllIllllIIllllIl);
      return new String(llllllllllllllIIlllIllllIIllllII.doFinal(Base64.getDecoder().decode(llllllllllllllIIlllIllllIIlllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIlllIllllIIlllIll)
    {
      llllllllllllllIIlllIllllIIlllIll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIllIIIIIll(int ???)
  {
    char llllllllllllllIIlllIllllIIIllllI;
    return ??? != 0;
  }
  
  private static boolean lllIIllIIIIllI(int ???, int arg1)
  {
    int i;
    char llllllllllllllIIlllIllllIIlIIIII;
    return ??? < i;
  }
  
  private static String lllIIlIllllllI(String llllllllllllllIIlllIllllIIlIlIll, String llllllllllllllIIlllIllllIIlIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIlllIllllIIllIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIlllIllllIIlIllII.getBytes(StandardCharsets.UTF_8)), lIIlIllIIIllI[15]), "DES");
      Cipher llllllllllllllIIlllIllllIIlIllll = Cipher.getInstance("DES");
      llllllllllllllIIlllIllllIIlIllll.init(lIIlIllIIIllI[2], llllllllllllllIIlllIllllIIllIIII);
      return new String(llllllllllllllIIlllIllllIIlIllll.doFinal(Base64.getDecoder().decode(llllllllllllllIIlllIllllIIlIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIlllIllllIIlIlllI)
    {
      llllllllllllllIIlllIllllIIlIlllI.printStackTrace();
    }
    return null;
  }
}

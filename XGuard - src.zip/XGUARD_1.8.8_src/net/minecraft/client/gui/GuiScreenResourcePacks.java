package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.ResourcePackListEntry;
import net.minecraft.client.resources.ResourcePackListEntryDefault;
import net.minecraft.client.resources.ResourcePackListEntryFound;
import net.minecraft.client.resources.ResourcePackRepository;
import net.minecraft.client.resources.ResourcePackRepository.Entry;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.Util;
import net.minecraft.util.Util.EnumOS;
import org.apache.logging.log4j.Logger;

public class GuiScreenResourcePacks
  extends GuiScreen
{
  private static boolean llIlIIIlllIll(int ???, int arg1)
  {
    int i;
    int lllllllllllllllIllllIIIIlIIIlIIl;
    return ??? < i;
  }
  
  private static void llIlIIIlIllIl()
  {
    lIIIIlllIIIl = new String[lIIIIlllIlIl[22]];
    lIIIIlllIIIl[lIIIIlllIlIl[0]] = llIlIIIlIIllI("LasDGy5iW9fWQWI4MihLfWBB/lWfolue", "YNfkd");
    lIIIIlllIIIl[lIIIIlllIlIl[4]] = llIlIIIlIlIII("vQIfVYpmNR4qrFuu+T543g==", "ZunwO");
    lIIIIlllIIIl[lIIIIlllIlIl[1]] = llIlIIIlIlIII("ubJBC1lTuGBG6tlh7SHuaw==", "XsfzU");
    lIIIIlllIIIl[lIIIIlllIlIl[9]] = llIlIIIlIIllI("SLjR+yM6a0UQfTC8KSAFzNee54Je2yEo", "dNyGk");
    lIIIIlllIIIl[lIIIIlllIlIl[5]] = llIlIIIlIlIII("vTigWCdmSO4BZFH5Cs0GpEahGSzu3HBwJpVhVWdVDkEjJptW7tNi0Q==", "LWnNP");
    lIIIIlllIIIl[lIIIIlllIlIl[10]] = llIlIIIlIlIII("MVy6AID7eqdqTnduxjnFvUAF4vfj4/jj", "RJljh");
    lIIIIlllIIIl[lIIIIlllIlIl[11]] = llIlIIIlIIllI("2mIkSKxsBRorCWhZk+5OZvQIju4tlkkJ", "MfRss");
    lIIIIlllIIIl[lIIIIlllIlIl[7]] = llIlIIIlIllII("NwMAFR0jDQA+CA==", "PftQx");
    lIIIIlllIIIl[lIIIIlllIlIl[8]] = llIlIIIlIllII("DB4fJiQL", "nlpQW");
    lIIIIlllIIIl[lIIIIlllIlIl[12]] = llIlIIIlIIllI("JZSj8iVXQyuzHvzV/F4GT/bTJrlJUsP7", "NoeZo");
    lIIIIlllIIIl[lIIIIlllIlIl[13]] = llIlIIIlIllII("JCkIIhAFPk06EAp5HjUKHzwAbBoHOB4/WA==", "kYmLy");
    lIIIIlllIIIl[lIIIIlllIlIl[14]] = llIlIIIlIIllI("H/0+gcTuTCk=", "sxcnG");
    lIIIIlllIIIl[lIIIIlllIlIl[15]] = llIlIIIlIllII("Oic/OxI6ISkEBispYiAOPC4p", "HBLTg");
    lIIIIlllIIIl[lIIIIlllIlIl[18]] = llIlIIIlIllII("NhI3FxM2FCEoByccah4JKBMhCi8qESs=", "DwDxf");
  }
  
  public void markChanged()
  {
    ;
    changed = lIIIIlllIlIl[4];
  }
  
  static
  {
    llIlIIIllIlIl();
    llIlIIIlIllIl();
  }
  
  private static boolean llIlIIIlllIIl(Object ???, Object arg1)
  {
    Object localObject;
    byte lllllllllllllllIllllIIIIlIIIIlIl;
    return ??? == localObject;
  }
  
  private static String llIlIIIlIllII(String lllllllllllllllIllllIIIIlIlIIllI, String lllllllllllllllIllllIIIIlIlIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllllIIIIlIlIIllI = new String(Base64.getDecoder().decode(lllllllllllllllIllllIIIIlIlIIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllllIIIIlIlIlIIl = new StringBuilder();
    char[] lllllllllllllllIllllIIIIlIlIlIII = lllllllllllllllIllllIIIIlIlIlIlI.toCharArray();
    int lllllllllllllllIllllIIIIlIlIIlll = lIIIIlllIlIl[0];
    float lllllllllllllllIllllIIIIlIlIIIIl = lllllllllllllllIllllIIIIlIlIIllI.toCharArray();
    String lllllllllllllllIllllIIIIlIlIIIII = lllllllllllllllIllllIIIIlIlIIIIl.length;
    Exception lllllllllllllllIllllIIIIlIIlllll = lIIIIlllIlIl[0];
    while (llIlIIIlllIll(lllllllllllllllIllllIIIIlIIlllll, lllllllllllllllIllllIIIIlIlIIIII))
    {
      char lllllllllllllllIllllIIIIlIlIllII = lllllllllllllllIllllIIIIlIlIIIIl[lllllllllllllllIllllIIIIlIIlllll];
      "".length();
      "".length();
      if ((0x73 ^ 0x19 ^ 0xFF ^ 0x91) < -" ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIllllIIIIlIlIlIIl);
  }
  
  private static void llIlIIIllIlIl()
  {
    lIIIIlllIlIl = new int[23];
    lIIIIlllIlIl[0] = ((0x39 ^ 0xA) & (0x0 ^ 0x33 ^ 0xFFFFFFFF));
    lIIIIlllIlIl[1] = "  ".length();
    lIIIIlllIlIl[2] = ((0x61 ^ 0x71) + (0x37 ^ 0x33) - -(0x8 ^ 0x27) + (0x7D ^ 0x2A));
    lIIIIlllIlIl[3] = (0x2 ^ 0x32);
    lIIIIlllIlIl[4] = " ".length();
    lIIIIlllIlIl[5] = (0x2F ^ 0x2B);
    lIIIIlllIlIl[6] = (72 + 36 - 11 + 68 + ('' + 60 - 148 + 136) - (7 + 'é' - 203 + 214) + (0xAD ^ 0xC1));
    lIIIIlllIlIl[7] = (0x1A ^ 0x1D);
    lIIIIlllIlIl[8] = (0x1C ^ 0x14);
    lIIIIlllIlIl[9] = "   ".length();
    lIIIIlllIlIl[10] = (0x77 ^ 0x7A ^ 0xCC ^ 0xC4);
    lIIIIlllIlIl[11] = (41 + 53 - -99 + 3 ^ 30 + '' - 61 + 70);
    lIIIIlllIlIl[12] = (0x2A ^ 0x23);
    lIIIIlllIlIl[13] = ('£' + '­' - 138 + 7 ^ 109 + '' - 93 + 27);
    lIIIIlllIlIl[14] = (0x3C ^ 0x41 ^ 0xF7 ^ 0x81);
    lIIIIlllIlIl[15] = (96 + 78 - 171 + 138 ^ 85 + 89 - 53 + 8);
    lIIIIlllIlIl[16] = (0x2E ^ 0x3E);
    lIIIIlllIlIl[17] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIIIIlllIlIl[18] = (0x6D ^ 0x60);
    lIIIIlllIlIl[19] = ('Å' + '¨' - 205 + 83 ^ '¡' + '' - 135 + 22);
    lIIIIlllIlIl[20] = (0xBD ^ 0xA7);
    lIIIIlllIlIl[21] = (-(0xFCF9 & 0x3B76) & 0xBFEF & 0x80F8FF);
    lIIIIlllIlIl[22] = (0x28 ^ 0x26);
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    lllllllllllllllIllllIIIlIIIllIIl.handleMouseInput();
    selectedResourcePacksList.handleMouseInput();
    availableResourcePacksList.handleMouseInput();
  }
  
  public List<ResourcePackListEntry> getListContaining(ResourcePackListEntry lllllllllllllllIllllIIIlIIIIllII)
  {
    ;
    ;
    if (llIlIIIllIlll(lllllllllllllllIllllIIIlIIIIllll.hasResourcePackEntry(lllllllllllllllIllllIIIlIIIIllII)))
    {
      "".length();
      if (-"  ".length() < 0) {
        break label36;
      }
      return null;
    }
    label36:
    return availableResourcePacks;
  }
  
  protected void mouseClicked(int lllllllllllllllIllllIIIIlllIIlII, int lllllllllllllllIllllIIIIlllIIIll, int lllllllllllllllIllllIIIIllIllllI)
    throws IOException
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIllllIIIIlllIIIIl.mouseClicked(lllllllllllllllIllllIIIIlllIIlII, lllllllllllllllIllllIIIIlllIIIll, lllllllllllllllIllllIIIIllIllllI);
    "".length();
    "".length();
  }
  
  private static boolean llIlIIIllIlll(int ???)
  {
    float lllllllllllllllIllllIIIIlIIIIIll;
    return ??? != 0;
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    ;
    new GuiOptionButton(lIIIIlllIlIl[1], width / lIIIIlllIlIl[1] - lIIIIlllIlIl[2], height - lIIIIlllIlIl[3], I18n.format(lIIIIlllIIIl[lIIIIlllIlIl[0]], new Object[lIIIIlllIlIl[0]]));
    "".length();
    new GuiOptionButton(lIIIIlllIlIl[4], width / lIIIIlllIlIl[1] + lIIIIlllIlIl[5], height - lIIIIlllIlIl[3], I18n.format(lIIIIlllIIIl[lIIIIlllIlIl[4]], new Object[lIIIIlllIlIl[0]]));
    "".length();
    if (llIlIIIllIllI(changed))
    {
      availableResourcePacks = Lists.newArrayList();
      selectedResourcePacks = Lists.newArrayList();
      ResourcePackRepository lllllllllllllllIllllIIIlIIlIlIlI = mc.getResourcePackRepository();
      lllllllllllllllIllllIIIlIIlIlIlI.updateRepositoryEntriesAll();
      List<ResourcePackRepository.Entry> lllllllllllllllIllllIIIlIIlIlIII = Lists.newArrayList(lllllllllllllllIllllIIIlIIlIlIlI.getRepositoryEntriesAll());
      "".length();
      lllllllllllllllIllllIIIlIIIllIll = lllllllllllllllIllllIIIlIIlIlIII.iterator();
      "".length();
      if (((0x5 ^ 0x4F) & (0xFB ^ 0xB1 ^ 0xFFFFFFFF)) == (0x29 ^ 0x2D)) {
        return;
      }
      while (!llIlIIIllIllI(lllllllllllllllIllllIIIlIIIllIll.hasNext()))
      {
        ResourcePackRepository.Entry lllllllllllllllIllllIIIlIIlIIllI = (ResourcePackRepository.Entry)lllllllllllllllIllllIIIlIIIllIll.next();
        new ResourcePackListEntryFound(lllllllllllllllIllllIIIlIIlIllII, lllllllllllllllIllllIIIlIIlIIllI);
        "".length();
      }
      lllllllllllllllIllllIIIlIIIllIll = Lists.reverse(lllllllllllllllIllllIIIlIIlIlIlI.getRepositoryEntries()).iterator();
      "".length();
      if ((0xB6 ^ 0xB2) < "   ".length()) {
        return;
      }
      while (!llIlIIIllIllI(lllllllllllllllIllllIIIlIIIllIll.hasNext()))
      {
        ResourcePackRepository.Entry lllllllllllllllIllllIIIlIIlIIlII = (ResourcePackRepository.Entry)lllllllllllllllIllllIIIlIIIllIll.next();
        new ResourcePackListEntryFound(lllllllllllllllIllllIIIlIIlIllII, lllllllllllllllIllllIIIlIIlIIlII);
        "".length();
      }
      new ResourcePackListEntryDefault(lllllllllllllllIllllIIIlIIlIllII);
      "".length();
    }
    availableResourcePacksList = new GuiResourcePackAvailable(mc, lIIIIlllIlIl[6], height, availableResourcePacks);
    availableResourcePacksList.setSlotXBoundsFromLeft(width / lIIIIlllIlIl[1] - lIIIIlllIlIl[5] - lIIIIlllIlIl[6]);
    availableResourcePacksList.registerScrollButtons(lIIIIlllIlIl[7], lIIIIlllIlIl[8]);
    selectedResourcePacksList = new GuiResourcePackSelected(mc, lIIIIlllIlIl[6], height, selectedResourcePacks);
    selectedResourcePacksList.setSlotXBoundsFromLeft(width / lIIIIlllIlIl[1] + lIIIIlllIlIl[5]);
    selectedResourcePacksList.registerScrollButtons(lIIIIlllIlIl[7], lIIIIlllIlIl[8]);
  }
  
  private static String llIlIIIlIIllI(String lllllllllllllllIllllIIIIlIIlIlII, String lllllllllllllllIllllIIIIlIIlIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllllIIIIlIIllIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIIlIIlIIll.getBytes(StandardCharsets.UTF_8)), lIIIIlllIlIl[8]), "DES");
      Cipher lllllllllllllllIllllIIIIlIIllIII = Cipher.getInstance("DES");
      lllllllllllllllIllllIIIIlIIllIII.init(lIIIIlllIlIl[1], lllllllllllllllIllllIIIIlIIllIIl);
      return new String(lllllllllllllllIllllIIIIlIIllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIIlIIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllllIIIIlIIlIlll)
    {
      lllllllllllllllIllllIIIIlIIlIlll.printStackTrace();
    }
    return null;
  }
  
  protected void mouseReleased(int lllllllllllllllIllllIIIIllIlIlII, int lllllllllllllllIllllIIIIllIlIIll, int lllllllllllllllIllllIIIIllIlIllI)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIllllIIIIllIlIlIl.mouseReleased(lllllllllllllllIllllIIIIllIlIlII, lllllllllllllllIllllIIIIllIlIIll, lllllllllllllllIllllIIIIllIlIllI);
  }
  
  private static boolean llIlIIIlllIlI(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIllllIIIIIlllllIl;
    return ??? != i;
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllIllllIIIIlllIllll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIlIIIllIlll(enabled))
    {
      label223:
      boolean lllllllllllllllIllllIIIIllllIlll;
      if (llIlIIIlllIII(id, lIIIIlllIlIl[1]))
      {
        File lllllllllllllllIllllIIIIllllllII = mc.getResourcePackRepository().getDirResourcepacks();
        String lllllllllllllllIllllIIIIlllllIll = lllllllllllllllIllllIIIIllllllII.getAbsolutePath();
        if (llIlIIIlllIIl(Util.getOSType(), Util.EnumOS.OSX))
        {
          try
          {
            logger.info(lllllllllllllllIllllIIIIlllllIll);
            "".length();
            return;
          }
          catch (IOException lllllllllllllllIllllIIIIlllllIlI)
          {
            logger.error(lIIIIlllIIIl[lIIIIlllIlIl[9]], lllllllllllllllIllllIIIIlllllIlI);
            "".length();
            if ("  ".length() != 0) {
              break label223;
            }
          }
        }
        else if (llIlIIIlllIIl(Util.getOSType(), Util.EnumOS.WINDOWS))
        {
          String lllllllllllllllIllllIIIIlllllIIl = String.format(lIIIIlllIIIl[lIIIIlllIlIl[5]], new Object[] { lllllllllllllllIllllIIIIlllllIll });
          try
          {
            "".length();
            return;
          }
          catch (IOException lllllllllllllllIllllIIIIlllllIII)
          {
            logger.error(lIIIIlllIIIl[lIIIIlllIlIl[10]], lllllllllllllllIllllIIIIlllllIII);
          }
        }
        lllllllllllllllIllllIIIIllllIlll = lIIIIlllIlIl[0];
        try
        {
          Class<?> lllllllllllllllIllllIIIIllllIllI = Class.forName(lIIIIlllIIIl[lIIIIlllIlIl[11]]);
          Object lllllllllllllllIllllIIIIllllIlIl = lllllllllllllllIllllIIIIllllIllI.getMethod(lIIIIlllIIIl[lIIIIlllIlIl[7]], new Class[lIIIIlllIlIl[0]]).invoke(null, new Object[lIIIIlllIlIl[0]]);
          "".length();
          "".length();
          if ("   ".length() <= -" ".length()) {
            return;
          }
        }
        catch (Throwable lllllllllllllllIllllIIIIllllIlII)
        {
          logger.error(lIIIIlllIIIl[lIIIIlllIlIl[12]], lllllllllllllllIllllIIIIllllIlII);
          lllllllllllllllIllllIIIIllllIlll = lIIIIlllIlIl[4];
        }
        if (llIlIIIllIlll(lllllllllllllllIllllIIIIllllIlll))
        {
          logger.info(lIIIIlllIIIl[lIIIIlllIlIl[13]]);
          new StringBuilder(lIIIIlllIIIl[lIIIIlllIlIl[14]]);
          "".length();
          "".length();
          if (" ".length() >= 0) {}
        }
      }
      else if (llIlIIIlllIII(id, lIIIIlllIlIl[4]))
      {
        if (llIlIIIllIlll(changed))
        {
          List<ResourcePackRepository.Entry> lllllllllllllllIllllIIIIllllIIll = Lists.newArrayList();
          lllllllllllllllIllllIIIIllllIlll = selectedResourcePacks.iterator();
          "".length();
          if (null != null) {
            return;
          }
          while (!llIlIIIllIllI(lllllllllllllllIllllIIIIllllIlll.hasNext()))
          {
            ResourcePackListEntry lllllllllllllllIllllIIIIllllIIlI = (ResourcePackListEntry)lllllllllllllllIllllIIIIllllIlll.next();
            if (llIlIIIllIlll(lllllllllllllllIllllIIIIllllIIlI instanceof ResourcePackListEntryFound)) {
              "".length();
            }
          }
          Collections.reverse(lllllllllllllllIllllIIIIllllIIll);
          mc.getResourcePackRepository().setRepositories(lllllllllllllllIllllIIIIllllIIll);
          mc.gameSettings.resourcePacks.clear();
          mc.gameSettings.field_183018_l.clear();
          lllllllllllllllIllllIIIIllllIlll = lllllllllllllllIllllIIIIllllIIll.iterator();
          "".length();
          if (((0xE9 ^ 0xAC) & (0x59 ^ 0x1C ^ 0xFFFFFFFF)) > 0) {
            return;
          }
          while (!llIlIIIllIllI(lllllllllllllllIllllIIIIllllIlll.hasNext()))
          {
            ResourcePackRepository.Entry lllllllllllllllIllllIIIIllllIIIl = (ResourcePackRepository.Entry)lllllllllllllllIllllIIIIllllIlll.next();
            "".length();
            if (llIlIIIlllIlI(lllllllllllllllIllllIIIIllllIIIl.func_183027_f(), lIIIIlllIlIl[4])) {
              "".length();
            }
          }
          mc.gameSettings.saveOptions();
          mc.refreshResources();
        }
        mc.displayGuiScreen(parentScreen);
      }
    }
  }
  
  public List<ResourcePackListEntry> getSelectedResourcePacks()
  {
    ;
    return selectedResourcePacks;
  }
  
  public boolean hasResourcePackEntry(ResourcePackListEntry lllllllllllllllIllllIIIlIIIlIlII)
  {
    ;
    ;
    return selectedResourcePacks.contains(lllllllllllllllIllllIIIlIIIlIlII);
  }
  
  public List<ResourcePackListEntry> getAvailableResourcePacks()
  {
    ;
    return availableResourcePacks;
  }
  
  public void drawScreen(int lllllllllllllllIllllIIIIllIIllII, int lllllllllllllllIllllIIIIllIIlIll, float lllllllllllllllIllllIIIIllIIlIlI)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIllllIIIIllIIllIl.drawBackground(lIIIIlllIlIl[0]);
    availableResourcePacksList.drawScreen(lllllllllllllllIllllIIIIllIIllII, lllllllllllllllIllllIIIIllIIlIll, lllllllllllllllIllllIIIIllIIlIlI);
    selectedResourcePacksList.drawScreen(lllllllllllllllIllllIIIIllIIllII, lllllllllllllllIllllIIIIllIIlIll, lllllllllllllllIllllIIIIllIIlIlI);
    lllllllllllllllIllllIIIIllIIllIl.drawCenteredString(fontRendererObj, I18n.format(lIIIIlllIIIl[lIIIIlllIlIl[15]], new Object[lIIIIlllIlIl[0]]), width / lIIIIlllIlIl[1], lIIIIlllIlIl[16], lIIIIlllIlIl[17]);
    lllllllllllllllIllllIIIIllIIllIl.drawCenteredString(fontRendererObj, I18n.format(lIIIIlllIIIl[lIIIIlllIlIl[18]], new Object[lIIIIlllIlIl[0]]), width / lIIIIlllIlIl[1] - lIIIIlllIlIl[19], height - lIIIIlllIlIl[20], lIIIIlllIlIl[21]);
    lllllllllllllllIllllIIIIllIIllIl.drawScreen(lllllllllllllllIllllIIIIllIIllII, lllllllllllllllIllllIIIIllIIlIll, lllllllllllllllIllllIIIIllIIlIlI);
  }
  
  private static boolean llIlIIIllIllI(int ???)
  {
    double lllllllllllllllIllllIIIIlIIIIIIl;
    return ??? == 0;
  }
  
  private static boolean llIlIIIlllIII(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIllllIIIIlIIIllIl;
    return ??? == i;
  }
  
  public GuiScreenResourcePacks(GuiScreen lllllllllllllllIllllIIIlIlIIlIlI)
  {
    parentScreen = lllllllllllllllIllllIIIlIlIIlIlI;
  }
  
  private static String llIlIIIlIlIII(String lllllllllllllllIllllIIIIlIlllIll, String lllllllllllllllIllllIIIIlIlllIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllllIIIIlIlllllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllIIIIlIlllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllIIIIlIllllIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllIIIIlIllllIl.init(lIIIIlllIlIl[1], lllllllllllllllIllllIIIIlIlllllI);
      return new String(lllllllllllllllIllllIIIIlIllllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllIIIIlIlllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllllIIIIlIllllII)
    {
      lllllllllllllllIllllIIIIlIllllII.printStackTrace();
    }
    return null;
  }
}

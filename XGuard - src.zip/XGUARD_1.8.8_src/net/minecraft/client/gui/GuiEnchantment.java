package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.model.ModelBook;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerEnchantment;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnchantmentNameParts;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.IWorldNameable;
import net.minecraft.world.World;
import org.lwjgl.util.glu.Project;

public class GuiEnchantment
  extends GuiContainer
{
  private static boolean llllIllllllll(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIlIlIIlIllIlllIII;
    return ??? == i;
  }
  
  private static String llllIlllIIIll(String lllllllllllllllIlIlIIlIllllIIllI, String lllllllllllllllIlIlIIlIllllIIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIIlIllllIlIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIIlIllllIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlIlIIlIllllIlIII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlIlIIlIllllIlIII.init(lIlIIIIIlIll[7], lllllllllllllllIlIlIIlIllllIlIIl);
      return new String(lllllllllllllllIlIlIIlIllllIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIIlIllllIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIIlIllllIIlll)
    {
      lllllllllllllllIlIlIIlIllllIIlll.printStackTrace();
    }
    return null;
  }
  
  private static boolean llllIllllIllI(int ???)
  {
    double lllllllllllllllIlIlIIlIllIlIllII;
    return ??? != 0;
  }
  
  private static int llllIlllllIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llllIllllIlIl(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllIlIlIIlIllIllIIII;
    return ??? < i;
  }
  
  private static boolean llllIllllIlll(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIlIlIIlIllIllIlII;
    return ??? >= i;
  }
  
  private static boolean llllIllllllIl(int ???)
  {
    boolean lllllllllllllllIlIlIIlIllIlIlIlI;
    return ??? == 0;
  }
  
  private static int lllllIIIIIIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void drawScreen(int lllllllllllllllIlIlIIllIIIIlIlIl, int lllllllllllllllIlIlIIllIIIIlIlII, float lllllllllllllllIlIlIIllIIIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIIllIIIIIlIIl.drawScreen(lllllllllllllllIlIlIIllIIIIlIlIl, lllllllllllllllIlIlIIllIIIIlIlII, lllllllllllllllIlIlIIllIIIIlIIll);
    boolean lllllllllllllllIlIlIIllIIIIlIIlI = mc.thePlayer.capabilities.isCreativeMode;
    int lllllllllllllllIlIlIIllIIIIlIIIl = container.getLapisAmount();
    int lllllllllllllllIlIlIIllIIIIlIIII = lIlIIIIIlIll[0];
    "".length();
    if ("   ".length() >= (0x16 ^ 0x27 ^ 0x7 ^ 0x32)) {
      return;
    }
    while (!llllIllllIlll(lllllllllllllllIlIlIIllIIIIlIIII, lIlIIIIIlIll[12]))
    {
      int lllllllllllllllIlIlIIllIIIIIllll = container.enchantLevels[lllllllllllllllIlIlIIllIIIIlIIII];
      int lllllllllllllllIlIlIIllIIIIIlllI = container.field_178151_h[lllllllllllllllIlIlIIllIIIIlIIII];
      int lllllllllllllllIlIlIIllIIIIIllIl = lllllllllllllllIlIlIIllIIIIlIIII + lIlIIIIIlIll[1];
      if ((llllIllllIllI(lllllllllllllllIlIlIIllIIIIIlIIl.isPointInRegion(lIlIIIIIlIll[8], lIlIIIIIlIll[9] + lIlIIIIIlIll[10] * lllllllllllllllIlIlIIllIIIIlIIII, lIlIIIIIlIll[11], lIlIIIIIlIll[32], lllllllllllllllIlIlIIllIIIIlIlIl, lllllllllllllllIlIlIIllIIIIlIlII))) && (llllIllllllII(lllllllllllllllIlIlIIllIIIIIllll)) && (llllIllllIlII(lllllllllllllllIlIlIIllIIIIIlllI)))
      {
        List<String> lllllllllllllllIlIlIIllIIIIIllII = Lists.newArrayList();
        if ((llllIllllIlII(lllllllllllllllIlIlIIllIIIIIlllI)) && (llllIlllllllI(Enchantment.getEnchantmentById(lllllllllllllllIlIlIIllIIIIIlllI & lIlIIIIIlIll[33]))))
        {
          String lllllllllllllllIlIlIIllIIIIIlIll = Enchantment.getEnchantmentById(lllllllllllllllIlIlIIllIIIIIlllI & lIlIIIIIlIll[33]).getTranslatedName((lllllllllllllllIlIlIIllIIIIIlllI & lIlIIIIIlIll[34]) >> lIlIIIIIlIll[5]);
          new StringBuilder(String.valueOf(EnumChatFormatting.WHITE.toString()));
          "".length();
        }
        if (llllIllllllIl(lllllllllllllllIlIlIIllIIIIlIIlI))
        {
          if (llllIllllIlII(lllllllllllllllIlIlIIllIIIIIlllI)) {
            "".length();
          }
          if (llllIllllIlIl(mc.thePlayer.experienceLevel, lllllllllllllllIlIlIIllIIIIIllll))
          {
            new StringBuilder(String.valueOf(EnumChatFormatting.RED.toString()));
            "".length();
            "".length();
            if (" ".length() < "  ".length()) {}
          }
          else
          {
            String lllllllllllllllIlIlIIllIIIIIlIlI = lIlIIIIIlIII[lIlIIIIIlIll[3]];
            if (llllIllllllll(lllllllllllllllIlIlIIllIIIIIllIl, lIlIIIIIlIll[1]))
            {
              lllllllllllllllIlIlIIllIIIIIlIlI = I18n.format(lIlIIIIIlIII[lIlIIIIIlIll[36]], new Object[lIlIIIIIlIll[0]]);
              "".length();
              if (-"   ".length() <= 0) {}
            }
            else
            {
              lllllllllllllllIlIlIIllIIIIIlIlI = I18n.format(lIlIIIIIlIII[lIlIIIIIlIll[31]], new Object[] { Integer.valueOf(lllllllllllllllIlIlIIllIIIIIllIl) });
            }
            if (llllIllllIlll(lllllllllllllllIlIlIIllIIIIlIIIl, lllllllllllllllIlIlIIllIIIIIllIl))
            {
              new StringBuilder(String.valueOf(EnumChatFormatting.GRAY.toString()));
              "".length();
              "".length();
              if ("   ".length() >= " ".length()) {}
            }
            else
            {
              new StringBuilder(String.valueOf(EnumChatFormatting.RED.toString()));
              "".length();
            }
            if (llllIllllllll(lllllllllllllllIlIlIIllIIIIIllIl, lIlIIIIIlIll[1]))
            {
              lllllllllllllllIlIlIIllIIIIIlIlI = I18n.format(lIlIIIIIlIII[lIlIIIIIlIll[5]], new Object[lIlIIIIIlIll[0]]);
              "".length();
              if (-"  ".length() <= 0) {}
            }
            else
            {
              lllllllllllllllIlIlIIllIIIIIlIlI = I18n.format(lIlIIIIIlIII[lIlIIIIIlIll[37]], new Object[] { Integer.valueOf(lllllllllllllllIlIlIIllIIIIIllIl) });
            }
            new StringBuilder(String.valueOf(EnumChatFormatting.GRAY.toString()));
            "".length();
          }
        }
        lllllllllllllllIlIlIIllIIIIIlIIl.drawHoveringText(lllllllllllllllIlIlIIllIIIIIllII, lllllllllllllllIlIlIIllIIIIlIlIl, lllllllllllllllIlIlIIllIIIIlIlII);
        "".length();
        if ("  ".length() != 0) {
          break;
        }
        return;
      }
      lllllllllllllllIlIlIIllIIIIlIIII++;
    }
  }
  
  private static void llllIlllIlIlI()
  {
    lIlIIIIIlIII = new String[lIlIIIIIlIll[38]];
    lIlIIIIIlIII[lIlIIIIIlIll[0]] = llllIlllIIIlI("Egs7Ex8UCzBIDRMHbAQFCBoiDgQDHGwCBAUGIgkeDwAkOB4HDC8CRBYAJA==", "fnCgj");
    lIlIIIIIlIII[lIlIIIIIlIll[1]] = llllIlllIIIll("nFJg/0BssM+kSTw6jg0NbDKuW8Vn8kn9STP3dLSIymoHULvZaIPixU8cyU1+nij2", "eRdDc");
    lIlIIIIIlIII[lIlIIIIIlIll[7]] = llllIlllIIIll("0PMnbAa6svt75sclHbKbeV2RJwZzwXU8", "QZIko");
    lIlIIIIIlIII[lIlIIIIIlIll[12]] = llllIlllIIlII("9uuB4+gPRA4=", "dJzqV");
    lIlIIIIIlIII[lIlIIIIIlIll[35]] = llllIlllIIIlI("AzQBIghvAxI2ESYjEioBISVNZw==", "OQwGd");
    lIlIIIIIlIII[lIlIIIIIlIll[3]] = llllIlllIIIlI("", "cHAwk");
    lIlIIIIIlIII[lIlIIIIIlIll[36]] = llllIlllIIIlI("EDoMDhMaOwcIXBY7ARITHSFMFhMDPBFUHR0w", "sUbzr");
    lIlIIIIIlIII[lIlIIIIIlIll[31]] = llllIlllIIIlI("NysDNTk9KggzdjEqDik5OjBDLTkkLR5vNTUqFA==", "TDmAX");
    lIlIIIIIlIII[lIlIIIIIlIll[5]] = llllIlllIIIll("/rPmxD1g5rvCWwFJpAXBAcptnYThcDCYvvr0ANpALUM=", "fcWsT");
    lIlIIIIIlIII[lIlIIIIIlIll[37]] = llllIlllIIIlI("CQsPPAcDCgQ6SA8KAiAHBBBPJAMcAQ1mCwsKGA==", "jdaHf");
  }
  
  private static boolean llllIllllIlII(int ???)
  {
    char lllllllllllllllIlIlIIlIllIlIlIII;
    return ??? >= 0;
  }
  
  static
  {
    llllIllllIIlI();
    llllIlllIlIlI();
    ENCHANTMENT_TABLE_GUI_TEXTURE = new ResourceLocation(lIlIIIIIlIII[lIlIIIIIlIll[0]]);
  }
  
  private static String llllIlllIIIlI(String lllllllllllllllIlIlIIlIlllIlIIIl, String lllllllllllllllIlIlIIlIlllIlIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIIlIlllIlIIIl = new String(Base64.getDecoder().decode(lllllllllllllllIlIlIIlIlllIlIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlIlIIlIlllIlIlII = new StringBuilder();
    char[] lllllllllllllllIlIlIIlIlllIlIIll = lllllllllllllllIlIlIIlIlllIlIlIl.toCharArray();
    int lllllllllllllllIlIlIIlIlllIlIIlI = lIlIIIIIlIll[0];
    Exception lllllllllllllllIlIlIIlIlllIIllII = lllllllllllllllIlIlIIlIlllIlIIIl.toCharArray();
    String lllllllllllllllIlIlIIlIlllIIlIll = lllllllllllllllIlIlIIlIlllIIllII.length;
    short lllllllllllllllIlIlIIlIlllIIlIlI = lIlIIIIIlIll[0];
    while (llllIllllIlIl(lllllllllllllllIlIlIIlIlllIIlIlI, lllllllllllllllIlIlIIlIlllIIlIll))
    {
      char lllllllllllllllIlIlIIlIlllIlIlll = lllllllllllllllIlIlIIlIlllIIllII[lllllllllllllllIlIlIIlIlllIIlIlI];
      "".length();
      "".length();
      if ((0xA7 ^ 0xA3) <= "   ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIlIlIIlIlllIlIlII);
  }
  
  private static boolean llllIlllllllI(Object ???)
  {
    double lllllllllllllllIlIlIIlIllIlIlllI;
    return ??? != null;
  }
  
  protected void mouseClicked(int lllllllllllllllIlIlIIllIIllllIll, int lllllllllllllllIlIlIIllIIlllIIIl, int lllllllllllllllIlIlIIllIIlllIIII)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIIllIIlllllII.mouseClicked(lllllllllllllllIlIlIIllIIllllIll, lllllllllllllllIlIlIIllIIlllIIIl, lllllllllllllllIlIlIIllIIlllIIII);
    int lllllllllllllllIlIlIIllIIllllIII = (width - xSize) / lIlIIIIIlIll[7];
    int lllllllllllllllIlIlIIllIIlllIlll = (height - ySize) / lIlIIIIIlIll[7];
    int lllllllllllllllIlIlIIllIIlllIllI = lIlIIIIIlIll[0];
    "".length();
    if (-" ".length() >= ((0x3A ^ 0x1D ^ 0x3F ^ 0x5C) & (115 + '«' - 278 + 217 ^ 10 + 127 - 108 + 136 ^ -" ".length()))) {
      return;
    }
    while (!llllIllllIlll(lllllllllllllllIlIlIIllIIlllIllI, lIlIIIIIlIll[12]))
    {
      int lllllllllllllllIlIlIIllIIlllIlIl = lllllllllllllllIlIlIIllIIllllIll - (lllllllllllllllIlIlIIllIIllllIII + lIlIIIIIlIll[8]);
      int lllllllllllllllIlIlIIllIIlllIlII = lllllllllllllllIlIlIIllIIlllIIIl - (lllllllllllllllIlIlIIllIIlllIlll + lIlIIIIIlIll[9] + lIlIIIIIlIll[10] * lllllllllllllllIlIlIIllIIlllIllI);
      if ((llllIllllIlII(lllllllllllllllIlIlIIllIIlllIlIl)) && (llllIllllIlII(lllllllllllllllIlIlIIllIIlllIlII)) && (llllIllllIlIl(lllllllllllllllIlIlIIllIIlllIlIl, lIlIIIIIlIll[11])) && (llllIllllIlIl(lllllllllllllllIlIlIIllIIlllIlII, lIlIIIIIlIll[10])) && (llllIllllIllI(container.enchantItem(mc.thePlayer, lllllllllllllllIlIlIIllIIlllIllI)))) {
        mc.playerController.sendEnchantPacket(container.windowId, lllllllllllllllIlIlIIllIIlllIllI);
      }
      lllllllllllllllIlIlIIllIIlllIllI++;
    }
  }
  
  private static boolean llllIlllllIll(int ???)
  {
    byte lllllllllllllllIlIlIIlIllIlIIllI;
    return ??? < 0;
  }
  
  protected void drawGuiContainerBackgroundLayer(float lllllllllllllllIlIlIIllIIlIlIIIl, int lllllllllllllllIlIlIIllIIlIlIIII, int lllllllllllllllIlIlIIllIIIllIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(ENCHANTMENT_TABLE_GUI_TEXTURE);
    int lllllllllllllllIlIlIIllIIlIIlllI = (width - xSize) / lIlIIIIIlIll[7];
    int lllllllllllllllIlIlIIllIIlIIllIl = (height - ySize) / lIlIIIIIlIll[7];
    lllllllllllllllIlIlIIllIIlIlIIlI.drawTexturedModalRect(lllllllllllllllIlIlIIllIIlIIlllI, lllllllllllllllIlIlIIllIIlIIllIl, lIlIIIIIlIll[0], lIlIIIIIlIll[0], xSize, ySize);
    GlStateManager.pushMatrix();
    GlStateManager.matrixMode(lIlIIIIIlIll[13]);
    GlStateManager.pushMatrix();
    GlStateManager.loadIdentity();
    ScaledResolution lllllllllllllllIlIlIIllIIlIIllII = new ScaledResolution(mc);
    GlStateManager.viewport((ScaledResolution.getScaledWidth() - lIlIIIIIlIll[14]) / lIlIIIIIlIll[7] * lllllllllllllllIlIlIIllIIlIIllII.getScaleFactor(), (lllllllllllllllIlIlIIllIIlIIllII.getScaledHeight() - lIlIIIIIlIll[15]) / lIlIIIIIlIll[7] * lllllllllllllllIlIlIIllIIlIIllII.getScaleFactor(), lIlIIIIIlIll[14] * lllllllllllllllIlIlIIllIIlIIllII.getScaleFactor(), lIlIIIIIlIll[15] * lllllllllllllllIlIlIIllIIlIIllII.getScaleFactor());
    GlStateManager.translate(-0.34F, 0.23F, 0.0F);
    Project.gluPerspective(90.0F, 1.3333334F, 9.0F, 80.0F);
    float lllllllllllllllIlIlIIllIIlIIlIll = 1.0F;
    GlStateManager.matrixMode(lIlIIIIIlIll[16]);
    GlStateManager.loadIdentity();
    RenderHelper.enableStandardItemLighting();
    GlStateManager.translate(0.0F, 3.3F, -16.0F);
    GlStateManager.scale(lllllllllllllllIlIlIIllIIlIIlIll, lllllllllllllllIlIlIIllIIlIIlIll, lllllllllllllllIlIlIIllIIlIIlIll);
    float lllllllllllllllIlIlIIllIIlIIlIlI = 5.0F;
    GlStateManager.scale(lllllllllllllllIlIlIIllIIlIIlIlI, lllllllllllllllIlIlIIllIIlIIlIlI, lllllllllllllllIlIlIIllIIlIIlIlI);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    mc.getTextureManager().bindTexture(ENCHANTMENT_TABLE_BOOK_TEXTURE);
    GlStateManager.rotate(20.0F, 1.0F, 0.0F, 0.0F);
    float lllllllllllllllIlIlIIllIIlIIlIIl = field_147076_A + (field_147080_z - field_147076_A) * lllllllllllllllIlIlIIllIIlIlIIIl;
    GlStateManager.translate((1.0F - lllllllllllllllIlIlIIllIIlIIlIIl) * 0.2F, (1.0F - lllllllllllllllIlIlIIllIIlIIlIIl) * 0.1F, (1.0F - lllllllllllllllIlIlIIllIIlIIlIIl) * 0.25F);
    GlStateManager.rotate(-(1.0F - lllllllllllllllIlIlIIllIIlIIlIIl) * 90.0F - 90.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(180.0F, 1.0F, 0.0F, 0.0F);
    float lllllllllllllllIlIlIIllIIlIIlIII = field_147069_w + (field_147071_v - field_147069_w) * lllllllllllllllIlIlIIllIIlIlIIIl + 0.25F;
    float lllllllllllllllIlIlIIllIIlIIIlll = field_147069_w + (field_147071_v - field_147069_w) * lllllllllllllllIlIlIIllIIlIlIIIl + 0.75F;
    lllllllllllllllIlIlIIllIIlIIlIII = (lllllllllllllllIlIlIIllIIlIIlIII - MathHelper.truncateDoubleToInt(lllllllllllllllIlIlIIllIIlIIlIII)) * 1.6F - 0.3F;
    lllllllllllllllIlIlIIllIIlIIIlll = (lllllllllllllllIlIlIIllIIlIIIlll - MathHelper.truncateDoubleToInt(lllllllllllllllIlIlIIllIIlIIIlll)) * 1.6F - 0.3F;
    if (llllIlllllIll(llllIlllllIII(lllllllllllllllIlIlIIllIIlIIlIII, 0.0F))) {
      lllllllllllllllIlIlIIllIIlIIlIII = 0.0F;
    }
    if (llllIlllllIll(llllIlllllIII(lllllllllllllllIlIlIIllIIlIIIlll, 0.0F))) {
      lllllllllllllllIlIlIIllIIlIIIlll = 0.0F;
    }
    if (llllIllllllII(llllIlllllIIl(lllllllllllllllIlIlIIllIIlIIlIII, 1.0F))) {
      lllllllllllllllIlIlIIllIIlIIlIII = 1.0F;
    }
    if (llllIllllllII(llllIlllllIIl(lllllllllllllllIlIlIIllIIlIIIlll, 1.0F))) {
      lllllllllllllllIlIlIIllIIlIIIlll = 1.0F;
    }
    GlStateManager.enableRescaleNormal();
    MODEL_BOOK.render(null, 0.0F, lllllllllllllllIlIlIIllIIlIIlIII, lllllllllllllllIlIlIIllIIlIIIlll, lllllllllllllllIlIlIIllIIlIIlIIl, 0.0F, 0.0625F);
    GlStateManager.disableRescaleNormal();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.matrixMode(lIlIIIIIlIll[13]);
    GlStateManager.viewport(lIlIIIIIlIll[0], lIlIIIIIlIll[0], mc.displayWidth, mc.displayHeight);
    GlStateManager.popMatrix();
    GlStateManager.matrixMode(lIlIIIIIlIll[16]);
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    EnchantmentNameParts.getInstance().reseedRandomGenerator(container.xpSeed);
    int lllllllllllllllIlIlIIllIIlIIIllI = container.getLapisAmount();
    int lllllllllllllllIlIlIIllIIlIIIlIl = lIlIIIIIlIll[0];
    "".length();
    if (" ".length() < 0) {
      return;
    }
    while (!llllIllllIlll(lllllllllllllllIlIlIIllIIlIIIlIl, lIlIIIIIlIll[12]))
    {
      int lllllllllllllllIlIlIIllIIlIIIlII = lllllllllllllllIlIlIIllIIlIIlllI + lIlIIIIIlIll[8];
      int lllllllllllllllIlIlIIllIIlIIIIll = lllllllllllllllIlIlIIllIIlIIIlII + lIlIIIIIlIll[17];
      int lllllllllllllllIlIlIIllIIlIIIIlI = lIlIIIIIlIll[18];
      String lllllllllllllllIlIlIIllIIlIIIIIl = EnchantmentNameParts.getInstance().generateNewRandomName();
      zLevel = 0.0F;
      mc.getTextureManager().bindTexture(ENCHANTMENT_TABLE_GUI_TEXTURE);
      int lllllllllllllllIlIlIIllIIlIIIIII = container.enchantLevels[lllllllllllllllIlIlIIllIIlIIIlIl];
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      if (llllIllllllIl(lllllllllllllllIlIlIIllIIlIIIIII))
      {
        lllllllllllllllIlIlIIllIIlIlIIlI.drawTexturedModalRect(lllllllllllllllIlIlIIllIIlIIIlII, lllllllllllllllIlIlIIllIIlIIllIl + lIlIIIIIlIll[9] + lIlIIIIIlIll[10] * lllllllllllllllIlIlIIllIIlIIIlIl, lIlIIIIIlIll[0], lIlIIIIIlIll[19], lIlIIIIIlIll[11], lIlIIIIIlIll[10]);
        "".length();
        if (-(0x61 ^ 0x65) <= 0) {}
      }
      else
      {
        String lllllllllllllllIlIlIIllIIIllllll = String.valueOf(new StringBuilder().append(lllllllllllllllIlIlIIllIIlIIIIII));
        FontRenderer lllllllllllllllIlIlIIllIIIlllllI = mc.standardGalacticFontRenderer;
        int lllllllllllllllIlIlIIllIIIllllIl = lIlIIIIIlIll[20];
        if (((!llllIllllIlll(lllllllllllllllIlIlIIllIIlIIIllI, lllllllllllllllIlIlIIllIIlIIIlIl + lIlIIIIIlIll[1])) || (llllIllllIlIl(mc.thePlayer.experienceLevel, lllllllllllllllIlIlIIllIIlIIIIII))) && (llllIllllllIl(mc.thePlayer.capabilities.isCreativeMode)))
        {
          lllllllllllllllIlIlIIllIIlIlIIlI.drawTexturedModalRect(lllllllllllllllIlIlIIllIIlIIIlII, lllllllllllllllIlIlIIllIIlIIllIl + lIlIIIIIlIll[9] + lIlIIIIIlIll[10] * lllllllllllllllIlIlIIllIIlIIIlIl, lIlIIIIIlIll[0], lIlIIIIIlIll[19], lIlIIIIIlIll[11], lIlIIIIIlIll[10]);
          lllllllllllllllIlIlIIllIIlIlIIlI.drawTexturedModalRect(lllllllllllllllIlIlIIllIIlIIIlII + lIlIIIIIlIll[1], lllllllllllllllIlIlIIllIIlIIllIl + lIlIIIIIlIll[21] + lIlIIIIIlIll[10] * lllllllllllllllIlIlIIllIIlIIIlIl, lIlIIIIIlIll[22] * lllllllllllllllIlIlIIllIIlIIIlIl, lIlIIIIIlIll[23], lIlIIIIIlIll[22], lIlIIIIIlIll[22]);
          lllllllllllllllIlIlIIllIIIlllllI.drawSplitString(lllllllllllllllIlIlIIllIIlIIIIIl, lllllllllllllllIlIlIIllIIlIIIIll, lllllllllllllllIlIlIIllIIlIIllIl + lIlIIIIIlIll[22] + lIlIIIIIlIll[10] * lllllllllllllllIlIlIIllIIlIIIlIl, lllllllllllllllIlIlIIllIIlIIIIlI, (lllllllllllllllIlIlIIllIIIllllIl & lIlIIIIIlIll[24]) >> lIlIIIIIlIll[1]);
          lllllllllllllllIlIlIIllIIIllllIl = lIlIIIIIlIll[25];
          "".length();
          if (null == null) {}
        }
        else
        {
          int lllllllllllllllIlIlIIllIIIllllII = lllllllllllllllIlIlIIllIIlIlIIII - (lllllllllllllllIlIlIIllIIlIIlllI + lIlIIIIIlIll[8]);
          int lllllllllllllllIlIlIIllIIIlllIll = lllllllllllllllIlIlIIllIIIllIlll - (lllllllllllllllIlIlIIllIIlIIllIl + lIlIIIIIlIll[9] + lIlIIIIIlIll[10] * lllllllllllllllIlIlIIllIIlIIIlIl);
          if ((llllIllllIlII(lllllllllllllllIlIlIIllIIIllllII)) && (llllIllllIlII(lllllllllllllllIlIlIIllIIIlllIll)) && (llllIllllIlIl(lllllllllllllllIlIlIIllIIIllllII, lIlIIIIIlIll[11])) && (llllIllllIlIl(lllllllllllllllIlIlIIllIIIlllIll, lIlIIIIIlIll[10])))
          {
            lllllllllllllllIlIlIIllIIlIlIIlI.drawTexturedModalRect(lllllllllllllllIlIlIIllIIlIIIlII, lllllllllllllllIlIlIIllIIlIIllIl + lIlIIIIIlIll[9] + lIlIIIIIlIll[10] * lllllllllllllllIlIlIIllIIlIIIlIl, lIlIIIIIlIll[0], lIlIIIIIlIll[26], lIlIIIIIlIll[11], lIlIIIIIlIll[10]);
            lllllllllllllllIlIlIIllIIIllllIl = lIlIIIIIlIll[27];
            "".length();
            if ("   ".length() <= "   ".length()) {}
          }
          else
          {
            lllllllllllllllIlIlIIllIIlIlIIlI.drawTexturedModalRect(lllllllllllllllIlIlIIllIIlIIIlII, lllllllllllllllIlIlIIllIIlIIllIl + lIlIIIIIlIll[9] + lIlIIIIIlIll[10] * lllllllllllllllIlIlIIllIIlIIIlIl, lIlIIIIIlIll[0], lIlIIIIIlIll[28], lIlIIIIIlIll[11], lIlIIIIIlIll[10]);
          }
          lllllllllllllllIlIlIIllIIlIlIIlI.drawTexturedModalRect(lllllllllllllllIlIlIIllIIlIIIlII + lIlIIIIIlIll[1], lllllllllllllllIlIlIIllIIlIIllIl + lIlIIIIIlIll[21] + lIlIIIIIlIll[10] * lllllllllllllllIlIlIIllIIlIIIlIl, lIlIIIIIlIll[22] * lllllllllllllllIlIlIIllIIlIIIlIl, lIlIIIIIlIll[29], lIlIIIIIlIll[22], lIlIIIIIlIll[22]);
          lllllllllllllllIlIlIIllIIIlllllI.drawSplitString(lllllllllllllllIlIlIIllIIlIIIIIl, lllllllllllllllIlIlIIllIIlIIIIll, lllllllllllllllIlIlIIllIIlIIllIl + lIlIIIIIlIll[22] + lIlIIIIIlIll[10] * lllllllllllllllIlIlIIllIIlIIIlIl, lllllllllllllllIlIlIIllIIlIIIIlI, lllllllllllllllIlIlIIllIIIllllIl);
          lllllllllllllllIlIlIIllIIIllllIl = lIlIIIIIlIll[30];
        }
        lllllllllllllllIlIlIIllIIIlllllI = Minecraft.fontRendererObj;
        "".length();
      }
      lllllllllllllllIlIlIIllIIlIIIlIl++;
    }
  }
  
  private static boolean llllIllllllII(int ???)
  {
    Exception lllllllllllllllIlIlIIlIllIlIIIlI;
    return ??? > 0;
  }
  
  public void updateScreen()
  {
    ;
    lllllllllllllllIlIlIIllIlIIIIlll.updateScreen();
    lllllllllllllllIlIlIIllIlIIIIllI.func_147068_g();
  }
  
  private static String llllIlllIIlII(String lllllllllllllllIlIlIIlIllIllllll, String lllllllllllllllIlIlIIlIllIlllllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIIlIlllIIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIIlIllIlllllI.getBytes(StandardCharsets.UTF_8)), lIlIIIIIlIll[5]), "DES");
      Cipher lllllllllllllllIlIlIIlIlllIIIIll = Cipher.getInstance("DES");
      lllllllllllllllIlIlIIlIlllIIIIll.init(lIlIIIIIlIll[7], lllllllllllllllIlIlIIlIlllIIIlII);
      return new String(lllllllllllllllIlIlIIlIlllIIIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIIlIllIllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIIlIlllIIIIlI)
    {
      lllllllllllllllIlIlIIlIlllIIIIlI.printStackTrace();
    }
    return null;
  }
  
  private static void llllIllllIIlI()
  {
    lIlIIIIIlIll = new int[39];
    lIlIIIIIlIll[0] = ((0x7F ^ 0x65) & (0x38 ^ 0x22 ^ 0xFFFFFFFF));
    lIlIIIIIlIll[1] = " ".length();
    lIlIIIIIlIll[2] = (0xA0 ^ 0xAC);
    lIlIIIIIlIll[3] = (0x6F ^ 0x1F ^ 0x13 ^ 0x66);
    lIlIIIIIlIll[4] = (-(0xFFFFFFED & 0x123E) & 0xDE6B & 0x4073FF);
    lIlIIIIIlIll[5] = (0xA0 ^ 0xA8);
    lIlIIIIIlIll[6] = (0xA2 ^ 0xC2);
    lIlIIIIIlIll[7] = "  ".length();
    lIlIIIIIlIll[8] = (0xD8 ^ 0xA3 ^ 0x4F ^ 0x8);
    lIlIIIIIlIll[9] = (0x79 ^ 0x77);
    lIlIIIIIlIll[10] = (0xE ^ 0x1D);
    lIlIIIIIlIll[11] = (0x99 ^ 0xBF ^ 0x1D ^ 0x57);
    lIlIIIIIlIll[12] = "   ".length();
    lIlIIIIIlIll[13] = (-(0xFB5F & 0x44E1) & 0xD753 & 0x7FED);
    lIlIIIIIlIll[14] = (-(0x9EBF & 0x7DF7) & 0xBFF6 & 0x5DFF);
    lIlIIIIIlIll[15] = ('è' + 120 - 148 + 36);
    lIlIIIIIlIll[16] = (0xDF07 & 0x37F8);
    lIlIIIIIlIll[17] = (0x7 ^ 0x48 ^ 0x24 ^ 0x7F);
    lIlIIIIIlIll[18] = (110 + '' - 194 + 135 ^ '' + 77 - 100 + 40);
    lIlIIIIIlIll[19] = (41 + 67 - 103 + 180);
    lIlIIIIIlIll[20] = (-(15 + '' - 94 + 91) & 0xDEDA & 0x687FFF);
    lIlIIIIIlIll[21] = (0xCE ^ 0x8F ^ 0xA ^ 0x44);
    lIlIIIIIlIll[22] = (0xA1 ^ 0xB1);
    lIlIIIIIlIll[23] = ((0x13 ^ 0x21) + (0x49 ^ 0x30) - (0x62 ^ 0x6A) + (0x6D ^ 0x21));
    lIlIIIIIlIll[24] = (-"  ".length() & 0xFFFFFFFF & 0xFEFEFF);
    lIlIIIIIlIll[25] = (-(106 + 37 - 78 + 97) & 0xFFFFFFF5 & 0x407FBB);
    lIlIIIIIlIll[26] = ((0x55 ^ 0xA) + (0x59 ^ 0x6E) - (0xB0 ^ 0xBC) + (0x2B ^ 0x69));
    lIlIIIIIlIll[27] = (-(0x96 ^ 0xAF) & 0xFFFFFFFD & 0xFFFFBA);
    lIlIIIIIlIll[28] = ((0x55 ^ 0x67) + (0x1C ^ 0x73) - ('' + 125 - 191 + 69) + ('' + '' - 171 + 45));
    lIlIIIIIlIll[29] = ((0x9E ^ 0x88) + (49 + 86 - -7 + 62) - (0x3A ^ 0x2B) + (0x71 ^ 0x7F));
    lIlIIIIIlIll[30] = (-(57 + '¿' - 178 + 135) & 0xFFFFFFFE & 0x80FFED);
    lIlIIIIIlIll[31] = (0x39 ^ 0x3E);
    lIlIIIIIlIll[32] = (0xD6 ^ 0xC7);
    lIlIIIIIlIll[33] = (72 + 61 - -49 + 0 + (94 + 35 - 91 + 112) - (6 + 121 - -37 + 10) + (0x53 ^ 0x32));
    lIlIIIIIlIll[34] = (0xFFFFFFF6 & 0xFF09);
    lIlIIIIIlIll[35] = (0x5A ^ 0x6 ^ 0x1D ^ 0x45);
    lIlIIIIIlIll[36] = (0x2D ^ 0x2B);
    lIlIIIIIlIll[37] = (0xA1 ^ 0xA8);
    lIlIIIIIlIll[38] = (0x70 ^ 0x5F ^ 0x9A ^ 0xBF);
  }
  
  private static int llllIlllllIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  protected void drawGuiContainerForegroundLayer(int lllllllllllllllIlIlIIllIlIIIlIll, int lllllllllllllllIlIlIIllIlIIIlIlI)
  {
    ;
    "".length();
    "".length();
  }
  
  private static int lllllIIIIIIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lllllIIIIIIlI(int ???)
  {
    short lllllllllllllllIlIlIIlIllIlIIlII;
    return ??? <= 0;
  }
  
  public void func_147068_g()
  {
    ;
    ;
    ;
    ;
    ;
    ItemStack lllllllllllllllIlIlIIlIlllllIlll = inventorySlots.getSlot(lIlIIIIIlIll[0]).getStack();
    if (llllIllllllIl(ItemStack.areItemStacksEqual(lllllllllllllllIlIlIIlIlllllIlll, field_147077_B)))
    {
      field_147077_B = lllllllllllllllIlIlIIlIlllllIlll;
      do
      {
        field_147082_x += random.nextInt(lIlIIIIIlIll[35]) - random.nextInt(lIlIIIIIlIll[35]);
      } while ((lllllIIIIIIlI(lllllIIIIIIII(field_147071_v, field_147082_x + 1.0F))) && (!llllIlllllIll(lllllIIIIIIIl(field_147071_v, field_147082_x - 1.0F))));
    }
    field_147073_u += lIlIIIIIlIll[1];
    field_147069_w = field_147071_v;
    field_147076_A = field_147080_z;
    boolean lllllllllllllllIlIlIIlIlllllIllI = lIlIIIIIlIll[0];
    int lllllllllllllllIlIlIIlIlllllIlIl = lIlIIIIIlIll[0];
    "".length();
    if (null != null) {
      return;
    }
    while (!llllIllllIlll(lllllllllllllllIlIlIIlIlllllIlIl, lIlIIIIIlIll[12]))
    {
      if (llllIllllIllI(container.enchantLevels[lllllllllllllllIlIlIIlIlllllIlIl])) {
        lllllllllllllllIlIlIIlIlllllIllI = lIlIIIIIlIll[1];
      }
      lllllllllllllllIlIlIIlIlllllIlIl++;
    }
    if (llllIllllIllI(lllllllllllllllIlIlIIlIlllllIllI))
    {
      field_147080_z += 0.2F;
      "".length();
      if (-"  ".length() < 0) {}
    }
    else
    {
      field_147080_z -= 0.2F;
    }
    field_147080_z = MathHelper.clamp_float(field_147080_z, 0.0F, 1.0F);
    float lllllllllllllllIlIlIIlIlllllIlII = (field_147082_x - field_147071_v) * 0.4F;
    float lllllllllllllllIlIlIIlIlllllIIll = 0.2F;
    lllllllllllllllIlIlIIlIlllllIlII = MathHelper.clamp_float(lllllllllllllllIlIlIIlIlllllIlII, -lllllllllllllllIlIlIIlIlllllIIll, lllllllllllllllIlIlIIlIlllllIIll);
    field_147081_y += (lllllllllllllllIlIlIIlIlllllIlII - field_147081_y) * 0.9F;
    field_147071_v += field_147081_y;
  }
  
  public GuiEnchantment(InventoryPlayer lllllllllllllllIlIlIIllIlIIlIlII, World lllllllllllllllIlIlIIllIlIIIllll, IWorldNameable lllllllllllllllIlIlIIllIlIIlIIlI)
  {
    lllllllllllllllIlIlIIllIlIIlIlIl.<init>(new ContainerEnchantment(lllllllllllllllIlIlIIllIlIIlIlII, lllllllllllllllIlIlIIllIlIIIllll));
    playerInventory = lllllllllllllllIlIlIIllIlIIlIlII;
    container = ((ContainerEnchantment)inventorySlots);
    field_175380_I = lllllllllllllllIlIlIIllIlIIlIIlI;
  }
}

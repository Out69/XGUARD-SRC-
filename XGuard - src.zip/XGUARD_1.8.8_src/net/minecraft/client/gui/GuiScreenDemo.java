package net.minecraft.client.gui;

import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import org.apache.logging.log4j.Logger;

public class GuiScreenDemo
  extends GuiScreen
{
  private static String lllIlIlIIlllll(String llllllllllllllIIllIlIllIllIllIlI, String llllllllllllllIIllIlIllIllIllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllIlIllIllIlllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllIlIllIllIllIll.getBytes(StandardCharsets.UTF_8)), lIIllIlIIlIIl[16]), "DES");
      Cipher llllllllllllllIIllIlIllIllIllllI = Cipher.getInstance("DES");
      llllllllllllllIIllIlIllIllIllllI.init(lIIllIlIIlIIl[3], llllllllllllllIIllIlIllIllIlllll);
      return new String(llllllllllllllIIllIlIllIllIllllI.doFinal(Base64.getDecoder().decode(llllllllllllllIIllIlIllIllIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllIlIllIllIlllIl)
    {
      llllllllllllllIIllIlIllIllIlllIl.printStackTrace();
    }
    return null;
  }
  
  private static String lllIlIlIIllllI(String llllllllllllllIIllIlIllIlllIllII, String llllllllllllllIIllIlIllIllllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIlIllIlllIllII = new String(Base64.getDecoder().decode(llllllllllllllIIllIlIllIlllIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIllIlIllIlllIllll = new StringBuilder();
    char[] llllllllllllllIIllIlIllIlllIlllI = llllllllllllllIIllIlIllIllllIIII.toCharArray();
    int llllllllllllllIIllIlIllIlllIllIl = lIIllIlIIlIIl[0];
    int llllllllllllllIIllIlIllIlllIIlll = llllllllllllllIIllIlIllIlllIllII.toCharArray();
    short llllllllllllllIIllIlIllIlllIIllI = llllllllllllllIIllIlIllIlllIIlll.length;
    byte llllllllllllllIIllIlIllIlllIIlIl = lIIllIlIIlIIl[0];
    while (lllIlIlllIlIll(llllllllllllllIIllIlIllIlllIIlIl, llllllllllllllIIllIlIllIlllIIllI))
    {
      char llllllllllllllIIllIlIllIllllIIlI = llllllllllllllIIllIlIllIlllIIlll[llllllllllllllIIllIlIllIlllIIlIl];
      "".length();
      "".length();
      if (" ".length() <= ((0xA8 ^ 0x95) & (0x64 ^ 0x59 ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIllIlIllIlllIllll);
  }
  
  private static String lllIlIlIlIIIII(String llllllllllllllIIllIlIllIllIIllIl, String llllllllllllllIIllIlIllIllIIlllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllIlIllIllIlIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllIlIllIllIIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIIllIlIllIllIlIIIl = Cipher.getInstance("Blowfish");
      llllllllllllllIIllIlIllIllIlIIIl.init(lIIllIlIIlIIl[3], llllllllllllllIIllIlIllIllIlIIlI);
      return new String(llllllllllllllIIllIlIllIllIlIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIIllIlIllIllIIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllIlIllIllIlIIII)
    {
      llllllllllllllIIllIlIllIllIlIIII.printStackTrace();
    }
    return null;
  }
  
  private static void lllIlIlIlIIIIl()
  {
    lIIllIIIllllI = new String[lIIllIlIIlIIl[27]];
    lIIllIIIllllI[lIIllIlIIlIIl[0]] = lllIlIlIIllllI("EAAfHTMWABRGIREMSA0jCQo4CycHDgAbKRELA0c2CgI=", "degiF");
    lIIllIIIllllI[lIIllIlIIlIIl[2]] = lllIlIlIIlllll("o0KdD6btBSaQj9iNosW7Iw==", "ANBTp");
    lIIllIIIllllI[lIIllIlIIlIIl[3]] = lllIlIlIIlllll("R0v1D6RHm5+LmBd+FEUvCg==", "eEuUz");
    lIIllIIIllllI[lIIllIlIIlIIl[8]] = lllIlIlIIllllI("Gw4aImIQGBhtCBQcBzcjAQ==", "qolCL");
    lIIllIIIllllI[lIIllIlIIlIIl[9]] = lllIlIlIIlllll("/xbnXRW29yQaJwQAU/huKQ==", "IoQRf");
    lIIllIIIllllI[lIIllIlIIlIIl[10]] = lllIlIlIlIIIII("jnkDfrpSHM8=", "Goeje");
    lIIllIIIllllI[lIIllIlIIlIIl[11]] = lllIlIlIIlllll("8OGyAPvCA6g1eGUBB/SKWzKCVphbzEqiANMD1vwsaAi+76rTXo1K9qfRFaKFdZbC", "vajyc");
    lIIllIIIllllI[lIIllIlIIlIIl[12]] = lllIlIlIIlllll("LAwedGxLYUvojQxbTT50XZzr+F8Ex//I", "yXhun");
    lIIllIIIllllI[lIIllIlIIlIIl[16]] = lllIlIlIIllllI("NyMVKUw7IxQ2TCcvDCoH", "SFxFb");
    lIIllIIIllllI[lIIllIlIIlIIl[18]] = lllIlIlIlIIIII("pJfADy/5pEi6sUWHD06+88fKBk/bNa8g", "SyTPF");
    lIIllIIIllllI[lIIllIlIIlIIl[15]] = lllIlIlIIllllI("EzQDFWsfNAIKaxo+GB8oEj8aNyoCIgs=", "wQnzE");
    lIIllIIIllllI[lIIllIlIIlIIl[21]] = lllIlIlIlIIIII("nTjScRRVopLaq4j2hHEo/Q==", "ZtSMJ");
    lIIllIIIllllI[lIIllIlIIlIIl[20]] = lllIlIlIIllllI("PCIKAkwwIgsdTDEpEQgMLCgVFA==", "XGgmb");
    lIIllIIIllllI[lIIllIlIIlIIl[24]] = lllIlIlIIllllI("KwEVKEMnARQ3QykRFCs6PQUINwgr", "OdxGm");
  }
  
  private static void lllIlIlllIlIlI()
  {
    lIIllIlIIlIIl = new int[28];
    lIIllIlIIlIIl[0] = ((7 + 'ã' - 64 + 58 ^ '¯' + '' - 210 + 75) & ('Ä' + '¯' - 246 + 82 ^ 88 + 28 - -26 + 4 ^ -" ".length()));
    lIIllIlIIlIIl[1] = (-(0x51 ^ 0x7D ^ 0x88 ^ 0xB4));
    lIIllIlIIlIIl[2] = " ".length();
    lIIllIlIIlIIl[3] = "  ".length();
    lIIllIlIIlIIl[4] = (0x7 ^ 0x73);
    lIIllIlIIlIIl[5] = ('¥' + '«' - 229 + 67 ^ '' + 100 - 131 + 45);
    lIIllIlIIlIIl[6] = (0x3F ^ 0x4D);
    lIIllIlIIlIIl[7] = (0x2A ^ 0x3E);
    lIIllIlIIlIIl[8] = "   ".length();
    lIIllIlIIlIIl[9] = (0xC9 ^ 0x87 ^ 0x26 ^ 0x6C);
    lIIllIlIIlIIl[10] = (91 + 28 - 28 + 89 ^ 74 + 123 - 75 + 55);
    lIIllIlIIlIIl[11] = (0x9B ^ 0xB8 ^ 0x9 ^ 0x2C);
    lIIllIlIIlIIl[12] = (0xB ^ 0xC);
    lIIllIlIIlIIl[13] = ((0x67 ^ 0x3C) + ('ä' + 'Ö' - 319 + 118) - (0xDF ^ 0x84) + (0xAD ^ 0xAA));
    lIIllIlIIlIIl[14] = (33 + '' - 34 + 31);
    lIIllIlIIlIIl[15] = (0x2A ^ 0x20);
    lIIllIlIIlIIl[16] = (0xB6 ^ 0xBE);
    lIIllIlIIlIIl[17] = (-(0xDDCD & 0x6273) & 0xDFFF & 0x1F7F5F);
    lIIllIlIIlIIl[18] = (102 + '' - 107 + 44 ^ 27 + '£' - 173 + 161);
    lIIllIlIIlIIl[19] = (0xCF7F & 0x4F7FCF);
    lIIllIlIIlIIl[20] = (0x36 ^ 0x3A);
    lIIllIlIIlIIl[21] = (0x60 ^ 0x6B);
    lIIllIlIIlIIl[22] = (0x53 ^ 0x4B);
    lIIllIlIIlIIl[23] = (0x3C ^ 0x79 ^ 0x78 ^ 0x19);
    lIIllIlIIlIIl[24] = (0x7F ^ 0x72);
    lIIllIlIIlIIl[25] = (0x6 ^ 0x42);
    lIIllIlIIlIIl[26] = (59 + 'Å' - 60 + 22);
    lIIllIlIIlIIl[27] = (0x99 ^ 0x97);
  }
  
  static
  {
    lllIlIlllIlIlI();
    lllIlIlIlIIIIl();
  }
  
  public GuiScreenDemo() {}
  
  public void updateScreen()
  {
    ;
    llllllllllllllIIllIlIlllIIIllIlI.updateScreen();
  }
  
  private static boolean lllIlIlllIlIll(int ???, int arg1)
  {
    int i;
    char llllllllllllllIIllIlIllIllIIIllI;
    return ??? < i;
  }
  
  public void initGui()
  {
    ;
    ;
    buttonList.clear();
    int llllllllllllllIIllIlIlllIIlIllII = lIIllIlIIlIIl[1];
    new GuiButton(lIIllIlIIlIIl[2], width / lIIllIlIIlIIl[3] - lIIllIlIIlIIl[4], height / lIIllIlIIlIIl[3] + lIIllIlIIlIIl[5] + llllllllllllllIIllIlIlllIIlIllII, lIIllIlIIlIIl[6], lIIllIlIIlIIl[7], I18n.format(lIIllIIIllllI[lIIllIlIIlIIl[2]], new Object[lIIllIlIIlIIl[0]]));
    "".length();
    new GuiButton(lIIllIlIIlIIl[3], width / lIIllIlIIlIIl[3] + lIIllIlIIlIIl[3], height / lIIllIlIIlIIl[3] + lIIllIlIIlIIl[5] + llllllllllllllIIllIlIlllIIlIllII, lIIllIlIIlIIl[6], lIIllIlIIlIIl[7], I18n.format(lIIllIIIllllI[lIIllIlIIlIIl[3]], new Object[lIIllIlIIlIIl[0]]));
    "".length();
  }
  
  public void drawDefaultBackground()
  {
    ;
    ;
    ;
    llllllllllllllIIllIlIlllIIIlIIll.drawDefaultBackground();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(field_146348_f);
    int llllllllllllllIIllIlIlllIIIlIlIl = (width - lIIllIlIIlIIl[13]) / lIIllIlIIlIIl[3];
    int llllllllllllllIIllIlIlllIIIlIlII = (height - lIIllIlIIlIIl[14]) / lIIllIlIIlIIl[3];
    llllllllllllllIIllIlIlllIIIlIllI.drawTexturedModalRect(llllllllllllllIIllIlIlllIIIlIlIl, llllllllllllllIIllIlIlllIIIlIlII, lIIllIlIIlIIl[0], lIIllIlIIlIIl[0], lIIllIlIIlIIl[13], lIIllIlIIlIIl[14]);
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIIllIlIlllIIlIIlII)
    throws IOException
  {
    ;
    ;
    ;
    ;
    switch (id)
    {
    case 1: 
      enabled = lIIllIlIIlIIl[0];
      try
      {
        Class<?> llllllllllllllIIllIlIlllIIlIIIll = Class.forName(lIIllIIIllllI[lIIllIlIIlIIl[8]]);
        Object llllllllllllllIIllIlIlllIIlIIIlI = llllllllllllllIIllIlIlllIIlIIIll.getMethod(lIIllIIIllllI[lIIllIlIIlIIl[9]], new Class[lIIllIlIIlIIl[0]]).invoke(null, new Object[lIIllIlIIlIIl[0]]);
        "".length();
        "".length();
        if (" ".length() != "   ".length()) {
          break;
        }
        return;
      }
      catch (Throwable llllllllllllllIIllIlIlllIIlIIIIl)
      {
        logger.error(lIIllIIIllllI[lIIllIlIIlIIl[12]], llllllllllllllIIllIlIlllIIlIIIIl);
        "".length();
        if (((0x59 ^ 0x5) & (0x24 ^ 0x78 ^ 0xFFFFFFFF)) == 0) {
          break;
        }
      }
      return;
    case 2: 
      mc.displayGuiScreen(null);
      mc.setIngameFocus();
    }
  }
  
  public void drawScreen(int llllllllllllllIIllIlIlllIIIIIIIl, int llllllllllllllIIllIlIlllIIIIIlll, float llllllllllllllIIllIlIllIllllllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIlIlllIIIIIIlI.drawDefaultBackground();
    int llllllllllllllIIllIlIlllIIIIIlIl = (width - lIIllIlIIlIIl[13]) / lIIllIlIIlIIl[3] + lIIllIlIIlIIl[15];
    int llllllllllllllIIllIlIlllIIIIIlII = (height - lIIllIlIIlIIl[14]) / lIIllIlIIlIIl[3] + lIIllIlIIlIIl[16];
    "".length();
    llllllllllllllIIllIlIlllIIIIIlII += 12;
    GameSettings llllllllllllllIIllIlIlllIIIIIIll = mc.gameSettings;
    "".length();
    "".length();
    "".length();
    "".length();
    fontRendererObj.drawSplitString(I18n.format(lIIllIIIllllI[lIIllIlIIlIIl[24]], new Object[lIIllIlIIlIIl[0]]), llllllllllllllIIllIlIlllIIIIIlIl, llllllllllllllIIllIlIlllIIIIIlII + lIIllIlIIlIIl[25], lIIllIlIIlIIl[26], lIIllIlIIlIIl[17]);
    llllllllllllllIIllIlIlllIIIIIIlI.drawScreen(llllllllllllllIIllIlIlllIIIIIIIl, llllllllllllllIIllIlIlllIIIIIlll, llllllllllllllIIllIlIllIllllllll);
  }
}

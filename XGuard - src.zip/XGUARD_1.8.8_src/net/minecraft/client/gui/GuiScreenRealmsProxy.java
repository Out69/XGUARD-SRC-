package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import net.minecraft.item.ItemStack;
import net.minecraft.realms.RealmsButton;
import net.minecraft.realms.RealmsScreen;

public class GuiScreenRealmsProxy
  extends GuiScreen
{
  public void handleKeyboardInput()
    throws IOException
  {
    ;
    field_154330_a.keyboardEvent();
    lllllllllllllllIIIlllIIllIllIIll.handleKeyboardInput();
  }
  
  public void func_154319_c(String lllllllllllllllIIIlllIIlllllIIII, int lllllllllllllllIIIlllIIllllIllll, int lllllllllllllllIIIlllIIlllllIIll, int lllllllllllllllIIIlllIIlllllIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    "".length();
  }
  
  public void func_154327_a(RealmsButton lllllllllllllllIIIlllIIlllIlIlll)
  {
    ;
    ;
    "".length();
  }
  
  public void func_154324_i()
  {
    ;
    buttonList.clear();
  }
  
  public int func_154326_c(String lllllllllllllllIIIlllIIllllllllI)
  {
    ;
    ;
    return fontRendererObj.getStringWidth(lllllllllllllllIIIlllIIllllllllI);
  }
  
  public List<String> func_154323_a(String lllllllllllllllIIIlllIIllllIIlIl, int lllllllllllllllIIIlllIIllllIIlll)
  {
    ;
    ;
    ;
    return fontRendererObj.listFormattedStringToWidth(lllllllllllllllIIIlllIIllllIlIII, lllllllllllllllIIIlllIIllllIIlll);
  }
  
  public void updateScreen()
  {
    ;
    field_154330_a.tick();
    lllllllllllllllIIIlllIlIIIIIIlIl.updateScreen();
  }
  
  public void drawScreen(int lllllllllllllllIIIlllIlIIIllIIlI, int lllllllllllllllIIIlllIlIIIlIllIl, float lllllllllllllllIIIlllIlIIIlIllII)
  {
    ;
    ;
    ;
    ;
    field_154330_a.render(lllllllllllllllIIIlllIlIIIllIIlI, lllllllllllllllIIIlllIlIIIlIllIl, lllllllllllllllIIIlllIlIIIlIllII);
  }
  
  public void func_154328_b(RealmsButton lllllllllllllllIIIlllIIlllIIIlII)
  {
    ;
    ;
    "".length();
  }
  
  public List<RealmsButton> func_154320_j()
  {
    ;
    ;
    ;
    List<RealmsButton> lllllllllllllllIIIlllIIlllIIllll = Lists.newArrayListWithExpectedSize(buttonList.size());
    char lllllllllllllllIIIlllIIlllIIlIlI = buttonList.iterator();
    "".length();
    if ("   ".length() < 0) {
      return null;
    }
    while (!lIIlIllIlIllll(lllllllllllllllIIIlllIIlllIIlIlI.hasNext()))
    {
      GuiButton lllllllllllllllIIIlllIIlllIIlllI = (GuiButton)lllllllllllllllIIIlllIIlllIIlIlI.next();
      "".length();
    }
    return lllllllllllllllIIIlllIIlllIIllll;
  }
  
  public int func_154329_h()
  {
    ;
    return fontRendererObj.FONT_HEIGHT;
  }
  
  public void renderToolTip(ItemStack lllllllllllllllIIIlllIlIIIlIIllI, int lllllllllllllllIIIlllIlIIIlIIIIl, int lllllllllllllllIIIlllIlIIIlIIlII)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIIIlllIlIIIlIIlll.renderToolTip(lllllllllllllllIIIlllIlIIIlIIllI, lllllllllllllllIIIlllIlIIIlIIIIl, lllllllllllllllIIIlllIlIIIlIIlII);
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    field_154330_a.mouseEvent();
    lllllllllllllllIIIlllIIllIllIlIl.handleMouseInput();
  }
  
  public boolean doesGuiPauseGame()
  {
    ;
    return lllllllllllllllIIIlllIlIIIllllll.doesGuiPauseGame();
  }
  
  public void onGuiClosed()
  {
    ;
    field_154330_a.removed();
    lllllllllllllllIIIlllIIllIIIIIll.onGuiClosed();
  }
  
  public void drawCreativeTabHoveringText(String lllllllllllllllIIIlllIlIIIIllIlI, int lllllllllllllllIIIlllIlIIIIlIlIl, int lllllllllllllllIIIlllIlIIIIllIII)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIIIlllIlIIIIllIll.drawCreativeTabHoveringText(lllllllllllllllIIIlllIlIIIIllIlI, lllllllllllllllIIIlllIlIIIIlIlIl, lllllllllllllllIIIlllIlIIIIllIII);
  }
  
  public void initGui()
  {
    ;
    field_154330_a.init();
    lllllllllllllllIIIlllIlIlIIIllII.initGui();
  }
  
  public void mouseClicked(int lllllllllllllllIIIlllIIllIlllIlI, int lllllllllllllllIIIlllIIllIllllIl, int lllllllllllllllIIIlllIIllIlllIII)
    throws IOException
  {
    ;
    ;
    ;
    ;
    field_154330_a.mouseClicked(lllllllllllllllIIIlllIIllIlllIlI, lllllllllllllllIIIlllIIllIllllIl, lllllllllllllllIIIlllIIllIlllIII);
    lllllllllllllllIIIlllIIllIllllll.mouseClicked(lllllllllllllllIIIlllIIllIlllIlI, lllllllllllllllIIIlllIIllIllllIl, lllllllllllllllIIIlllIIllIlllIII);
  }
  
  public void keyTyped(char lllllllllllllllIIIlllIIllIIIllll, int lllllllllllllllIIIlllIIllIIIlllI)
    throws IOException
  {
    ;
    ;
    ;
    field_154330_a.keyPressed(lllllllllllllllIIIlllIIllIIlIIlI, lllllllllllllllIIIlllIIllIIIlllI);
  }
  
  public RealmsScreen func_154321_a()
  {
    ;
    return field_154330_a;
  }
  
  public final void actionPerformed(GuiButton lllllllllllllllIIIlllIIllllIIIII)
    throws IOException
  {
    ;
    ;
    field_154330_a.buttonClicked(((GuiButtonRealmsProxy)lllllllllllllllIIIlllIIllllIIIII).getRealmsButton());
  }
  
  private static boolean lIIlIllIlIllll(int ???)
  {
    float lllllllllllllllIIIlllIIllIIIIIII;
    return ??? == 0;
  }
  
  public void mouseClickMove(int lllllllllllllllIIIlllIIllIIllIlI, int lllllllllllllllIIIlllIIllIIllIIl, int lllllllllllllllIIIlllIIllIIlllIl, long lllllllllllllllIIIlllIIllIIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    field_154330_a.mouseDragged(lllllllllllllllIIIlllIIllIIllIlI, lllllllllllllllIIIlllIIllIIllllI, lllllllllllllllIIIlllIIllIIlllIl, lllllllllllllllIIIlllIIllIIlllII);
  }
  
  public void drawHoveringText(List<String> lllllllllllllllIIIlllIlIIIIIlIlI, int lllllllllllllllIIIlllIlIIIIIllIl, int lllllllllllllllIIIlllIlIIIIIllII)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllIIIlllIlIIIIIllll.drawHoveringText(lllllllllllllllIIIlllIlIIIIIlIlI, lllllllllllllllIIIlllIlIIIIIllIl, lllllllllllllllIIIlllIlIIIIIllII);
  }
  
  public void drawWorldBackground(int lllllllllllllllIIIlllIlIIIlllIII)
  {
    ;
    ;
    lllllllllllllllIIIlllIlIIIlllIIl.drawWorldBackground(lllllllllllllllIIIlllIlIIIlllIII);
  }
  
  public void func_154325_a(String lllllllllllllllIIIlllIlIlIIIIlIl, int lllllllllllllllIIIlllIlIlIIIIlII, int lllllllllllllllIIIlllIlIIllllllI, int lllllllllllllllIIIlllIlIlIIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIlllIlIlIIIIllI.drawCenteredString(fontRendererObj, lllllllllllllllIIIlllIlIlIIIIlIl, lllllllllllllllIIIlllIlIIlllllll, lllllllllllllllIIIlllIlIIllllllI, lllllllllllllllIIIlllIlIlIIIIIlI);
  }
  
  public void func_154322_b(String lllllllllllllllIIIlllIlIIlllIIIl, int lllllllllllllllIIIlllIlIIlllIlIl, int lllllllllllllllIIIlllIlIIlllIlII, int lllllllllllllllIIIlllIlIIllIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIlllIlIIlllIlll.drawString(fontRendererObj, lllllllllllllllIIIlllIlIIlllIIIl, lllllllllllllllIIIlllIlIIlllIIII, lllllllllllllllIIIlllIlIIlllIlII, lllllllllllllllIIIlllIlIIllIlllI);
  }
  
  public void confirmClicked(boolean lllllllllllllllIIIlllIIllIIIIllI, int lllllllllllllllIIIlllIIllIIIIlIl)
  {
    ;
    ;
    ;
    field_154330_a.confirmResult(lllllllllllllllIIIlllIIllIIIlIIl, lllllllllllllllIIIlllIIllIIIIlIl);
  }
  
  public void drawGradientRect(int lllllllllllllllIIIlllIlIIlIlIIII, int lllllllllllllllIIIlllIlIIlIIlIII, int lllllllllllllllIIIlllIlIIlIIIlll, int lllllllllllllllIIIlllIlIIlIIllIl, int lllllllllllllllIIIlllIlIIlIIIlIl, int lllllllllllllllIIIlllIlIIlIIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIlllIlIIlIIlIlI.drawGradientRect(lllllllllllllllIIIlllIlIIlIlIIII, lllllllllllllllIIIlllIlIIlIIlIII, lllllllllllllllIIIlllIlIIlIIlllI, lllllllllllllllIIIlllIlIIlIIllIl, lllllllllllllllIIIlllIlIIlIIIlIl, lllllllllllllllIIIlllIlIIlIIIlII);
  }
  
  public void drawDefaultBackground()
  {
    ;
    lllllllllllllllIIIlllIlIIlIIIIlI.drawDefaultBackground();
  }
  
  public void mouseReleased(int lllllllllllllllIIIlllIIllIlIllII, int lllllllllllllllIIIlllIIllIlIlIll, int lllllllllllllllIIIlllIIllIlIlIlI)
  {
    ;
    ;
    ;
    ;
    field_154330_a.mouseReleased(lllllllllllllllIIIlllIIllIlIllII, lllllllllllllllIIIlllIIllIlIlIll, lllllllllllllllIIIlllIIllIlIlIlI);
  }
  
  public void drawTexturedModalRect(int lllllllllllllllIIIlllIlIIllIIlIl, int lllllllllllllllIIIlllIlIIllIIlII, int lllllllllllllllIIIlllIlIIlIlllII, int lllllllllllllllIIIlllIlIIlIllIll, int lllllllllllllllIIIlllIlIIlIllIlI, int lllllllllllllllIIIlllIlIIllIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    field_154330_a.blit(lllllllllllllllIIIlllIlIIllIIlIl, lllllllllllllllIIIlllIlIIllIIlII, lllllllllllllllIIIlllIlIIllIIIll, lllllllllllllllIIIlllIlIIlIllIll, lllllllllllllllIIIlllIlIIlIllIlI, lllllllllllllllIIIlllIlIIllIIIII);
    lllllllllllllllIIIlllIlIIlIlllll.drawTexturedModalRect(lllllllllllllllIIIlllIlIIllIIlIl, lllllllllllllllIIIlllIlIIllIIlII, lllllllllllllllIIIlllIlIIllIIIll, lllllllllllllllIIIlllIlIIlIllIll, lllllllllllllllIIIlllIlIIlIllIlI, lllllllllllllllIIIlllIlIIllIIIII);
  }
  
  public GuiScreenRealmsProxy(RealmsScreen lllllllllllllllIIIlllIlIlIIlIlII)
  {
    field_154330_a = lllllllllllllllIIIlllIlIlIIlIlII;
    buttonList = Collections.synchronizedList(Lists.newArrayList());
  }
}

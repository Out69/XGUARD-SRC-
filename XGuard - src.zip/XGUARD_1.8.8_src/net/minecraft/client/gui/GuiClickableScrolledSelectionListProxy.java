package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.realms.RealmsClickableScrolledSelectionList;
import net.minecraft.realms.Tezzelator;
import org.lwjgl.input.Mouse;

public class GuiClickableScrolledSelectionListProxy
  extends GuiSlot
{
  static {}
  
  private static boolean lIlIllllllI(int ???, int arg1)
  {
    int i;
    long lIllIIlIIIIlll;
    return ??? >= i;
  }
  
  protected int getContentHeight()
  {
    ;
    return field_178046_u.getMaxPosition();
  }
  
  protected int getSize()
  {
    ;
    return field_178046_u.getItemCount();
  }
  
  protected void elementClicked(int lIllIIlllIllIl, boolean lIllIIlllIIlll, int lIllIIlllIlIll, int lIllIIlllIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    field_178046_u.selectItem(lIllIIlllIllIl, lIllIIlllIllII, lIllIIlllIlIll, lIllIIlllIlIlI);
  }
  
  public GuiClickableScrolledSelectionListProxy(RealmsClickableScrolledSelectionList lIllIlIIIIIIll, int lIllIlIIIIIIlI, int lIllIIlllllIlI, int lIllIlIIIIIIII, int lIllIIllllllll, int lIllIIlllllllI)
  {
    lIllIlIIIIIlII.<init>(Minecraft.getMinecraft(), lIllIlIIIIIIlI, lIllIlIIIIIIIl, lIllIlIIIIIIII, lIllIIllllllll, lIllIIlllllllI);
    field_178046_u = lIllIlIIIIIIll;
  }
  
  public void func_178043_a(int lIllIIlIlIlIIl, int lIllIIlIlIlIII, int lIllIIlIlIllII, Tezzelator lIllIIlIlIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    field_178046_u.renderSelected(lIllIIlIlIlIIl, lIllIIlIlIllIl, lIllIIlIlIllII, lIllIIlIlIIllI);
  }
  
  private static boolean lIlIlllllIl(int ???, int arg1)
  {
    int i;
    double lIllIIlIIIIIll;
    return ??? < i;
  }
  
  private static boolean lIlIllllIll(int ???)
  {
    char lIllIIIlllllIl;
    return ??? != 0;
  }
  
  private static boolean lIlIllllIlI(int ???)
  {
    short lIllIIIllllIll;
    return ??? > 0;
  }
  
  public void handleMouseInput()
  {
    ;
    lIllIIlIllIllI.handleMouseInput();
    if ((lIlIllllIlI(lIlIllllIIl(scrollMultiplier, 0.0F))) && (lIlIllllIll(Mouse.getEventButtonState()))) {
      field_178046_u.customMouseEvent(top, bottom, headerPadding, amountScrolled, slotHeight);
    }
  }
  
  public int func_178044_e()
  {
    ;
    return width;
  }
  
  protected int getScrollBarX()
  {
    ;
    return field_178046_u.getScrollbarPosition();
  }
  
  protected void drawSelectionBox(int lIllIIlIIllIll, int lIllIIlIIlIIIl, int lIllIIlIIlIIII, int lIllIIlIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lIllIIlIIlIlll = lIllIIlIIlllII.getSize();
    int lIllIIlIIlIllI = llIlIlIll[0];
    "".length();
    if (null != null) {
      return;
    }
    while (!lIlIllllllI(lIllIIlIIlIllI, lIllIIlIIlIlll))
    {
      int lIllIIlIIlIlIl = lIllIIlIIllIlI + lIllIIlIIlIllI * slotHeight + headerPadding;
      int lIllIIlIIlIlII = slotHeight - llIlIlIll[1];
      if ((!lIlIlllllII(lIllIIlIIlIlIl, bottom)) || (lIlIlllllIl(lIllIIlIIlIlIl + lIllIIlIIlIlII, top))) {
        lIllIIlIIlllII.func_178040_a(lIllIIlIIlIllI, lIllIIlIIllIll, lIllIIlIIlIlIl);
      }
      if ((lIlIllllIll(showSelectionBox)) && (lIlIllllIll(lIllIIlIIlllII.isSelected(lIllIIlIIlIllI)))) {
        lIllIIlIIlllII.func_178043_a(width, lIllIIlIIlIlIl, lIllIIlIIlIlII, Tezzelator.instance);
      }
      lIllIIlIIlllII.drawSlot(lIllIIlIIlIllI, lIllIIlIIllIll, lIllIIlIIlIlIl, lIllIIlIIlIlII, lIllIIlIIlIIII, lIllIIlIIIllll);
      lIllIIlIIlIllI++;
    }
  }
  
  protected void drawSlot(int lIllIIllIIllII, int lIllIIllIIlIll, int lIllIIllIlIIIl, int lIllIIllIIlIIl, int lIllIIllIIlIII, int lIllIIllIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    field_178046_u.renderItem(lIllIIllIIllII, lIllIIllIIlIll, lIllIIllIIlIlI, lIllIIllIIlIIl, lIllIIllIIlIII, lIllIIllIIlllI);
  }
  
  private static void lIlIllllIII()
  {
    llIlIlIll = new int[2];
    llIlIlIll[0] = ((0x91 ^ 0x84) & (0x8B ^ 0x9E ^ 0xFFFFFFFF));
    llIlIlIll[1] = (0xF4 ^ 0xB9 ^ 0xC6 ^ 0x8F);
  }
  
  private static boolean lIlIlllllII(int ???, int arg1)
  {
    int i;
    boolean lIllIIIlllllll;
    return ??? <= i;
  }
  
  protected void drawBackground()
  {
    ;
    field_178046_u.renderBackground();
  }
  
  public int func_178042_f()
  {
    ;
    return mouseY;
  }
  
  private static int lIlIllllIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  protected boolean isSelected(int lIllIIlllIIIIl)
  {
    ;
    ;
    return field_178046_u.isSelectedItem(lIllIIlllIIIIl);
  }
  
  public int func_178045_g()
  {
    ;
    return mouseX;
  }
}

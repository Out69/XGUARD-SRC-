package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.gen.ChunkProviderSettings.Factory;
import org.lwjgl.input.Keyboard;

public class GuiScreenCustomizePresets
  extends GuiScreen
{
  private static void lIIIllIIlIIIl()
  {
    lIllIlIlllI = new String[lIllIllllll[21]];
    lIllIlIlllI[lIllIllllll[0]] = lIIIlIllIllIl("JTUVHSQjNR5GNiQ5QhkjNCMIHSJ+JwwdNCN+HQc2", "QPmiQ");
    lIllIlIlllI[lIllIllllll[1]] = lIIIlIllIllIl("MBoGCTg2PwwaIDdGAB0/JwcOATY2RgAdPycHDkY8IQ0QDTh9HwIcKSE/DBogNw==", "ShchL");
    lIllIlIlllI[lIllIllllll[2]] = lIIIlIllIlllI("57RhVnCYXbRntUhxQX7JElz+T5UUM2X6H8gB2iTccoU=", "DJnEs");
    lIllIlIlllI[lIllIllllll[3]] = lIIIlIllIllll("vH0OoG8UDlE2be2FNMAPdlLllAEyPyM/JS0iqV2H4qzo2WlHaILZb67S4TJ+inw5", "cZvdz");
    lIllIlIlllI[lIllIllllll[4]] = lIIIlIllIllll("+s24GC4rC1jnlIdEjlcNHjSHE5ntw1aq8bLeO0Z5UVCEpx7JP6i1cw==", "dWnCn");
    lIllIlIlllI[lIllIllllll[5]] = lIIIlIllIllll("Rp2d5fF4SQg4kgxrGkafZeWwpY8VRN3+WRT5Y2gxz11Hy+sWhXKRaf5++w1F4+1h", "CgvlF");
    lIllIlIlllI[lIllIllllll[6]] = lIIIlIllIlllI("CfPyvnGHN2D1ZQH+o6oJ5vSa4vkn5SJ+i/85vIogUlprvJtbVC0ZSQ==", "HSdub");
    lIllIlIlllI[lIllIllllll[7]] = lIIIlIllIlllI("MZ9nfTJWY8iqoduwBdffKYQFEdk9qWccZoDNdorg5Nd/1RkynZ6gjdxnOwdOSRn4", "SLQXP");
    lIllIlIlllI[lIllIllllll[8]] = lIIIlIllIllll("CZsFdqT1DaRdmBRLv1Ob0cudO+sGO4nGJ+aFtlXqQDKr08NQwhLMsw==", "rYwyn");
    lIllIlIlllI[lIllIllllll[9]] = lIIIlIllIllIl("DisUAA4IDh4TFgl3EhQJGTYcCAAIdxIUCRk2HE8KHzwCBA5DPQMODwoxBQ==", "mYqaz");
    lIllIlIlllI[lIllIllllll[10]] = lIIIlIllIllIl("IBEoJTMmESN+ISEdfyE0MQc1JTV7FzgwKSdaID8h", "TtPQF");
    lIllIlIlllI[lIllIllllll[11]] = lIIIlIllIlllI("NE/yip/P9Nag8bxOyURVrFP0UvTrARgqJg9/L2xVHk5/RnR21NPvgWeuvVpiparH", "AJmWo");
    lIllIlIlllI[lIllIllllll[12]] = lIIIlIllIllIl("Fw0VMzIRDR5oIBYBQjc1BhsIMzRMBBgkLE0YAyA=", "chmGG");
    lIllIlIlllI[lIllIllllll[13]] = lIIIlIllIlllI("O7flm3IQ4BXG7PhFpjSk0vdC42DWfVkHsPHIcGtX1F6VWbCLiGcz36YNznGk3VX/", "DuWOw");
    lIllIlIlllI[lIllIllllll[14]] = lIIIlIllIllIl("FTwXLQQ7IB48SwEmFjUPdhkWPBgzPRc=", "VIdYk");
    lIllIlIlllI[lIllIllllll[15]] = lIIIlIllIllll("8QlGvuPr6xnyEQ3bHCXtIgncjgi7CT0vZAyVWtYyM+ORf10k7wgT5UIGnppcwOXu", "YjusF");
    lIllIlIlllI[lIllIllllll[16]] = lIIIlIllIllll("VeCzlG8rCWC5U+1t790GTMaQ73Ie739I0fcbqz64qZ04R9wEQ98rmw==", "QZpZH");
    lIllIlIlllI[lIllIllllll[17]] = lIIIlIllIlllI("w/0Pe8qVO6a8xUlQPAsWkRmn9UXVPsj3bg/R30biAGNYB2l7LmLSeg==", "SHhda");
    lIllIlIlllI[lIllIllllll[25]] = lIIIlIllIllIl("JB03NiUiOD0lPSNBMSIiMwA/PisiQSIlNDQKJiR/NAo+MjIz", "GoRWQ");
    lIllIlIlllI[lIllIllllll[26]] = lIIIlIllIllIl("ITMxbTUnKDsmOg==", "FFXCV");
  }
  
  private static boolean lIIlIIIIIlIII(int ???, int arg1)
  {
    int i;
    byte llllllllllllllllIllIlllIIllIlIll;
    return ??? <= i;
  }
  
  private static String lIIIlIllIllll(String llllllllllllllllIllIlllIIllllIlI, String llllllllllllllllIllIlllIIllllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIllIlllIIlllllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllIlllIIllllIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIllIlllIIllllllI = Cipher.getInstance("Blowfish");
      llllllllllllllllIllIlllIIllllllI.init(lIllIllllll[2], llllllllllllllllIllIlllIIlllllll);
      return new String(llllllllllllllllIllIlllIIllllllI.doFinal(Base64.getDecoder().decode(llllllllllllllllIllIlllIIllllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIllIlllIIlllllIl)
    {
      llllllllllllllllIllIlllIIlllllIl.printStackTrace();
    }
    return null;
  }
  
  private static String lIIIlIllIlllI(String llllllllllllllllIllIlllIlIIlllll, String llllllllllllllllIllIlllIlIlIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIllIlllIlIlIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllIlllIlIlIIIII.getBytes(StandardCharsets.UTF_8)), lIllIllllll[8]), "DES");
      Cipher llllllllllllllllIllIlllIlIlIIIll = Cipher.getInstance("DES");
      llllllllllllllllIllIlllIlIlIIIll.init(lIllIllllll[2], llllllllllllllllIllIlllIlIlIIlII);
      return new String(llllllllllllllllIllIlllIlIlIIIll.doFinal(Base64.getDecoder().decode(llllllllllllllllIllIlllIlIIlllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIllIlllIlIlIIIlI)
    {
      llllllllllllllllIllIlllIlIlIIIlI.printStackTrace();
    }
    return null;
  }
  
  public void initGui()
  {
    ;
    buttonList.clear();
    Keyboard.enableRepeatEvents(lIllIllllll[1]);
    field_175315_a = I18n.format(lIllIlIlllI[lIllIllllll[15]], new Object[lIllIllllll[0]]);
    field_175313_s = I18n.format(lIllIlIlllI[lIllIllllll[16]], new Object[lIllIllllll[0]]);
    field_175312_t = I18n.format(lIllIlIlllI[lIllIllllll[17]], new Object[lIllIllllll[0]]);
    field_175317_i = new GuiTextField(lIllIllllll[2], fontRendererObj, lIllIllllll[18], lIllIllllll[19], width - lIllIllllll[20], lIllIllllll[21]);
    field_175311_g = new ListPreset();
    field_175317_i.setMaxStringLength(lIllIllllll[22]);
    field_175317_i.setText(field_175314_r.func_175323_a());
    field_175316_h = new GuiButton(lIllIllllll[0], width / lIllIllllll[2] - lIllIllllll[23], height - lIllIllllll[24], lIllIllllll[20], lIllIllllll[21], I18n.format(lIllIlIlllI[lIllIllllll[25]], new Object[lIllIllllll[0]]));
    "".length();
    new GuiButton(lIllIllllll[1], width / lIllIllllll[2] + lIllIllllll[3], height - lIllIllllll[24], lIllIllllll[20], lIllIllllll[21], I18n.format(lIllIlIlllI[lIllIllllll[26]], new Object[lIllIllllll[0]]));
    "".length();
    llllllllllllllllIllIlllIlllIIIIl.func_175304_a();
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    llllllllllllllllIllIlllIllIlllll.handleMouseInput();
    field_175311_g.handleMouseInput();
  }
  
  public void onGuiClosed()
  {
    Keyboard.enableRepeatEvents(lIllIllllll[0]);
  }
  
  public void func_175304_a()
  {
    ;
    field_175316_h.enabled = llllllllllllllllIllIlllIlIllIIII.func_175305_g();
  }
  
  protected void mouseClicked(int llllllllllllllllIllIlllIllIlIIll, int llllllllllllllllIllIlllIllIlIIlI, int llllllllllllllllIllIlllIllIlIlIl)
    throws IOException
  {
    ;
    ;
    ;
    ;
    field_175317_i.mouseClicked(llllllllllllllllIllIlllIllIlIIll, llllllllllllllllIllIlllIllIlIIlI, llllllllllllllllIllIlllIllIlIlIl);
    llllllllllllllllIllIlllIllIlIlII.mouseClicked(llllllllllllllllIllIlllIllIlIIll, llllllllllllllllIllIlllIllIlIIlI, llllllllllllllllIllIlllIllIlIlIl);
  }
  
  private static boolean lIIlIIIIIIllI(int ???, int arg1)
  {
    int i;
    int llllllllllllllllIllIlllIIllIIlll;
    return ??? > i;
  }
  
  private static boolean lIIlIIIIIIlll(int ???, int arg1)
  {
    int i;
    double llllllllllllllllIllIlllIIlllIIll;
    return ??? >= i;
  }
  
  public void updateScreen()
  {
    ;
    field_175317_i.updateCursorCounter();
    llllllllllllllllIllIlllIlIllIlII.updateScreen();
  }
  
  protected void actionPerformed(GuiButton llllllllllllllllIllIlllIllIIIIlI)
    throws IOException
  {
    ;
    ;
    switch (id)
    {
    case 0: 
      field_175314_r.func_175324_a(field_175317_i.getText());
      mc.displayGuiScreen(field_175314_r);
      "".length();
      if (null != null) {}
      break;
    case 1: 
      mc.displayGuiScreen(field_175314_r);
    }
  }
  
  private static boolean lIIlIIIIIlIIl(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllIllIlllIIllIllll;
    return ??? < i;
  }
  
  private static boolean lIIlIIIIIIlIl(int ???)
  {
    double llllllllllllllllIllIlllIIllIIlIl;
    return ??? == 0;
  }
  
  public GuiScreenCustomizePresets(GuiCustomizeWorldScreen llllllllllllllllIllIlllIlllIIlII)
  {
    field_175314_r = llllllllllllllllIllIlllIlllIIlII;
  }
  
  private boolean func_175305_g()
  {
    ;
    if (((!lIIlIIIIIIllI(field_175311_g.field_178053_u, lIllIllllll[31])) || (lIIlIIIIIIlll(field_175311_g.field_178053_u, field_175310_f.size()))) && (lIIlIIIIIlIII(field_175317_i.getText().length(), lIllIllllll[1]))) {
      return lIllIllllll[0];
    }
    return lIllIllllll[1];
  }
  
  public void drawScreen(int llllllllllllllllIllIlllIlIlllIII, int llllllllllllllllIllIlllIlIllIlll, float llllllllllllllllIllIlllIlIlllIlI)
  {
    ;
    ;
    ;
    ;
    llllllllllllllllIllIlllIlIllllIl.drawDefaultBackground();
    field_175311_g.drawScreen(llllllllllllllllIllIlllIlIlllIII, llllllllllllllllIllIlllIlIllIlll, llllllllllllllllIllIlllIlIlllIlI);
    llllllllllllllllIllIlllIlIllllIl.drawCenteredString(fontRendererObj, field_175315_a, width / lIllIllllll[2], lIllIllllll[8], lIllIllllll[27]);
    llllllllllllllllIllIlllIlIllllIl.drawString(fontRendererObj, field_175313_s, lIllIllllll[18], lIllIllllll[28], lIllIllllll[29]);
    llllllllllllllllIllIlllIlIllllIl.drawString(fontRendererObj, field_175312_t, lIllIllllll[18], lIllIllllll[30], lIllIllllll[29]);
    field_175317_i.drawTextBox();
    llllllllllllllllIllIlllIlIllllIl.drawScreen(llllllllllllllllIllIlllIlIlllIII, llllllllllllllllIllIlllIlIllIlll, llllllllllllllllIllIlllIlIlllIlI);
  }
  
  static
  {
    lIIIllIllIIll();
    lIIIllIIlIIIl();
    float llllllllllllllllIllIlllIlllIlIlI;
    float llllllllllllllllIllIlllIlllIlIll;
    field_175310_f = Lists.newArrayList();
    ChunkProviderSettings.Factory llllllllllllllllIllIlllIlllIllIl = ChunkProviderSettings.Factory.jsonToFactory("{ \"coordinateScale\":684.412, \"heightScale\":684.412, \"upperLimitScale\":512.0, \"lowerLimitScale\":512.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":5000.0, \"mainNoiseScaleY\":1000.0, \"mainNoiseScaleZ\":5000.0, \"baseSize\":8.5, \"stretchY\":8.0, \"biomeDepthWeight\":2.0, \"biomeDepthOffset\":0.5, \"biomeScaleWeight\":2.0, \"biomeScaleOffset\":0.375, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":255 }");
    ResourceLocation llllllllllllllllIllIlllIlllIllII = new ResourceLocation(lIllIlIlllI[lIllIllllll[0]]);
    new Info(I18n.format(lIllIlIlllI[lIllIllllll[1]], new Object[lIllIllllll[0]]), llllllllllllllllIllIlllIlllIllII, llllllllllllllllIllIlllIlllIllIl);
    "".length();
    llllllllllllllllIllIlllIlllIllIl = ChunkProviderSettings.Factory.jsonToFactory("{\"coordinateScale\":3000.0, \"heightScale\":6000.0, \"upperLimitScale\":250.0, \"lowerLimitScale\":512.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":80.0, \"mainNoiseScaleY\":160.0, \"mainNoiseScaleZ\":80.0, \"baseSize\":8.5, \"stretchY\":10.0, \"biomeDepthWeight\":1.0, \"biomeDepthOffset\":0.0, \"biomeScaleWeight\":1.0, \"biomeScaleOffset\":0.0, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":63 }");
    llllllllllllllllIllIlllIlllIllII = new ResourceLocation(lIllIlIlllI[lIllIllllll[2]]);
    new Info(I18n.format(lIllIlIlllI[lIllIllllll[3]], new Object[lIllIllllll[0]]), llllllllllllllllIllIlllIlllIllII, llllllllllllllllIllIlllIlllIllIl);
    "".length();
    llllllllllllllllIllIlllIlllIllIl = ChunkProviderSettings.Factory.jsonToFactory("{\"coordinateScale\":684.412, \"heightScale\":684.412, \"upperLimitScale\":512.0, \"lowerLimitScale\":512.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":5000.0, \"mainNoiseScaleY\":1000.0, \"mainNoiseScaleZ\":5000.0, \"baseSize\":8.5, \"stretchY\":5.0, \"biomeDepthWeight\":2.0, \"biomeDepthOffset\":1.0, \"biomeScaleWeight\":4.0, \"biomeScaleOffset\":1.0, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":63 }");
    llllllllllllllllIllIlllIlllIllII = new ResourceLocation(lIllIlIlllI[lIllIllllll[4]]);
    new Info(I18n.format(lIllIlIlllI[lIllIllllll[5]], new Object[lIllIllllll[0]]), llllllllllllllllIllIlllIlllIllII, llllllllllllllllIllIlllIlllIllIl);
    "".length();
    llllllllllllllllIllIlllIlllIllIl = ChunkProviderSettings.Factory.jsonToFactory("{\"coordinateScale\":738.41864, \"heightScale\":157.69133, \"upperLimitScale\":801.4267, \"lowerLimitScale\":1254.1643, \"depthNoiseScaleX\":374.93652, \"depthNoiseScaleZ\":288.65228, \"depthNoiseScaleExponent\":1.2092624, \"mainNoiseScaleX\":1355.9908, \"mainNoiseScaleY\":745.5343, \"mainNoiseScaleZ\":1183.464, \"baseSize\":1.8758626, \"stretchY\":1.7137525, \"biomeDepthWeight\":1.7553768, \"biomeDepthOffset\":3.4701107, \"biomeScaleWeight\":1.0, \"biomeScaleOffset\":2.535211, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":63 }");
    llllllllllllllllIllIlllIlllIllII = new ResourceLocation(lIllIlIlllI[lIllIllllll[6]]);
    new Info(I18n.format(lIllIlIlllI[lIllIllllll[7]], new Object[lIllIllllll[0]]), llllllllllllllllIllIlllIlllIllII, llllllllllllllllIllIlllIlllIllIl);
    "".length();
    llllllllllllllllIllIlllIlllIllIl = ChunkProviderSettings.Factory.jsonToFactory("{\"coordinateScale\":684.412, \"heightScale\":684.412, \"upperLimitScale\":512.0, \"lowerLimitScale\":512.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":1000.0, \"mainNoiseScaleY\":3000.0, \"mainNoiseScaleZ\":1000.0, \"baseSize\":8.5, \"stretchY\":10.0, \"biomeDepthWeight\":1.0, \"biomeDepthOffset\":0.0, \"biomeScaleWeight\":1.0, \"biomeScaleOffset\":0.0, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":20 }");
    llllllllllllllllIllIlllIlllIllII = new ResourceLocation(lIllIlIlllI[lIllIllllll[8]]);
    new Info(I18n.format(lIllIlIlllI[lIllIllllll[9]], new Object[lIllIllllll[0]]), llllllllllllllllIllIlllIlllIllII, llllllllllllllllIllIlllIlllIllIl);
    "".length();
    llllllllllllllllIllIlllIlllIllIl = ChunkProviderSettings.Factory.jsonToFactory("{\"coordinateScale\":684.412, \"heightScale\":684.412, \"upperLimitScale\":2.0, \"lowerLimitScale\":64.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":80.0, \"mainNoiseScaleY\":160.0, \"mainNoiseScaleZ\":80.0, \"baseSize\":8.5, \"stretchY\":12.0, \"biomeDepthWeight\":1.0, \"biomeDepthOffset\":0.0, \"biomeScaleWeight\":1.0, \"biomeScaleOffset\":0.0, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":false, \"seaLevel\":6 }");
    llllllllllllllllIllIlllIlllIllII = new ResourceLocation(lIllIlIlllI[lIllIllllll[10]]);
    new Info(I18n.format(lIllIlIlllI[lIllIllllll[11]], new Object[lIllIllllll[0]]), llllllllllllllllIllIlllIlllIllII, llllllllllllllllIllIlllIlllIllIl);
    "".length();
    llllllllllllllllIllIlllIlllIllIl = ChunkProviderSettings.Factory.jsonToFactory("{\"coordinateScale\":684.412, \"heightScale\":684.412, \"upperLimitScale\":512.0, \"lowerLimitScale\":512.0, \"depthNoiseScaleX\":200.0, \"depthNoiseScaleZ\":200.0, \"depthNoiseScaleExponent\":0.5, \"mainNoiseScaleX\":80.0, \"mainNoiseScaleY\":160.0, \"mainNoiseScaleZ\":80.0, \"baseSize\":8.5, \"stretchY\":12.0, \"biomeDepthWeight\":1.0, \"biomeDepthOffset\":0.0, \"biomeScaleWeight\":1.0, \"biomeScaleOffset\":0.0, \"useCaves\":true, \"useDungeons\":true, \"dungeonChance\":8, \"useStrongholds\":true, \"useVillages\":true, \"useMineShafts\":true, \"useTemples\":true, \"useRavines\":true, \"useWaterLakes\":true, \"waterLakeChance\":4, \"useLavaLakes\":true, \"lavaLakeChance\":80, \"useLavaOceans\":true, \"seaLevel\":40 }");
    llllllllllllllllIllIlllIlllIllII = new ResourceLocation(lIllIlIlllI[lIllIllllll[12]]);
    new Info(I18n.format(lIllIlIlllI[lIllIllllll[13]], new Object[lIllIllllll[0]]), llllllllllllllllIllIlllIlllIllII, llllllllllllllllIllIlllIlllIllIl);
    "".length();
  }
  
  private static String lIIIlIllIllIl(String llllllllllllllllIllIlllIlIIlIIIl, String llllllllllllllllIllIlllIlIIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIllIlllIlIIlIIIl = new String(Base64.getDecoder().decode(llllllllllllllllIllIlllIlIIlIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIllIlllIlIIIllll = new StringBuilder();
    char[] llllllllllllllllIllIlllIlIIIlllI = llllllllllllllllIllIlllIlIIlIIII.toCharArray();
    int llllllllllllllllIllIlllIlIIIllIl = lIllIllllll[0];
    Exception llllllllllllllllIllIlllIlIIIIlll = llllllllllllllllIllIlllIlIIlIIIl.toCharArray();
    long llllllllllllllllIllIlllIlIIIIllI = llllllllllllllllIllIlllIlIIIIlll.length;
    double llllllllllllllllIllIlllIlIIIIlIl = lIllIllllll[0];
    while (lIIlIIIIIlIIl(llllllllllllllllIllIlllIlIIIIlIl, llllllllllllllllIllIlllIlIIIIllI))
    {
      char llllllllllllllllIllIlllIlIIlIIlI = llllllllllllllllIllIlllIlIIIIlll[llllllllllllllllIllIlllIlIIIIlIl];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIllIlllIlIIIllll);
  }
  
  protected void keyTyped(char llllllllllllllllIllIlllIllIIlIIl, int llllllllllllllllIllIlllIllIIlIII)
    throws IOException
  {
    ;
    ;
    ;
    if (lIIlIIIIIIlIl(field_175317_i.textboxKeyTyped(llllllllllllllllIllIlllIllIIllII, llllllllllllllllIllIlllIllIIlIII))) {
      llllllllllllllllIllIlllIllIIlIlI.keyTyped(llllllllllllllllIllIlllIllIIllII, llllllllllllllllIllIlllIllIIlIII);
    }
  }
  
  private static void lIIIllIllIIll()
  {
    lIllIllllll = new int[32];
    lIllIllllll[0] = ((0x7D ^ 0x3F) & (0x2A ^ 0x68 ^ 0xFFFFFFFF));
    lIllIllllll[1] = " ".length();
    lIllIllllll[2] = "  ".length();
    lIllIllllll[3] = "   ".length();
    lIllIllllll[4] = (0xBA ^ 0xB2 ^ 0x86 ^ 0x8A);
    lIllIllllll[5] = (71 + 66 - 121 + 155 ^ 36 + 105 - 8 + 41);
    lIllIllllll[6] = (40 + 82 - 43 + 55 ^ 90 + 34 - 111 + 115);
    lIllIllllll[7] = (79 + 117 - 165 + 105 ^ 91 + 62 - 134 + 124);
    lIllIllllll[8] = (0x67 ^ 0x4E ^ 0x1F ^ 0x3E);
    lIllIllllll[9] = (0xB3 ^ 0xBA);
    lIllIllllll[10] = (0x8A ^ 0x80);
    lIllIllllll[11] = (0x76 ^ 0x5A ^ 0xA7 ^ 0x80);
    lIllIllllll[12] = (0xB6 ^ 0x8D ^ 0x39 ^ 0xE);
    lIllIllllll[13] = (0x5C ^ 0x51);
    lIllIllllll[14] = (0x80 ^ 0x8E);
    lIllIllllll[15] = (0xC4 ^ 0x86 ^ 0x8F ^ 0xC2);
    lIllIllllll[16] = (0x20 ^ 0x56 ^ 0x5A ^ 0x3C);
    lIllIllllll[17] = ("  ".length() ^ 0x80 ^ 0x93);
    lIllIllllll[18] = (0x10 ^ 0x2E ^ 0xD ^ 0x1);
    lIllIllllll[19] = (0xB7 ^ 0x9F);
    lIllIllllll[20] = (0x4A ^ 0x2E);
    lIllIllllll[21] = (0xB6 ^ 0xA2);
    lIllIllllll[22] = (-(0xB656 & 0x69B9) & 0xBFDF & 0x67FF);
    lIllIllllll[23] = (0x3B ^ 0x5D);
    lIllIllllll[24] = (31 + '' - 165 + 158 ^ '' + 20 - 68 + 96);
    lIllIllllll[25] = (0x3B ^ 0x29);
    lIllIllllll[26] = (0x2F ^ 0x4A ^ 0xCE ^ 0xB8);
    lIllIllllll[27] = (0xFFFFFFFF & 0xFFFFFF);
    lIllIllllll[28] = (0xF ^ 0x28 ^ 0x2A ^ 0x13);
    lIllIllllll[29] = (-(0x9CDF & 0x7F3D) & 0xFFFFFFBF & 0xA0BCFC);
    lIllIllllll[30] = (0xA1 ^ 0x87 ^ 0xF8 ^ 0x98);
    lIllIllllll[31] = (-" ".length());
  }
  
  static class Info
  {
    public Info(String lllllllllllllllIlIlIlIlIIIIlIIlI, ResourceLocation lllllllllllllllIlIlIlIlIIIIIllIl, ChunkProviderSettings.Factory lllllllllllllllIlIlIlIlIIIIlIIII)
    {
      field_178955_a = lllllllllllllllIlIlIlIlIIIIlIIlI;
      field_178953_b = lllllllllllllllIlIlIlIlIIIIIllIl;
      field_178954_c = lllllllllllllllIlIlIlIlIIIIlIIII;
    }
  }
  
  class ListPreset
    extends GuiSlot
  {
    protected int getSize()
    {
      return GuiScreenCustomizePresets.field_175310_f.size();
    }
    
    private static boolean lllllIIllIIII(int ???, int arg1)
    {
      int i;
      char lllllllllllllllIlIlIIIlIIIllllll;
      return ??? == i;
    }
    
    public ListPreset()
    {
      lllllllllllllllIlIlIIIlIlIIIIIlI.<init>(mc, width, height, lIlIIIIllIIl[0], height - lIlIIIIllIIl[1], lIlIIIIllIIl[2]);
    }
    
    protected void drawSlot(int lllllllllllllllIlIlIIIlIIlIIlllI, int lllllllllllllllIlIlIIIlIIlIIllIl, int lllllllllllllllIlIlIIIlIIlIIIlII, int lllllllllllllllIlIlIIIlIIlIIlIll, int lllllllllllllllIlIlIIIlIIlIIlIlI, int lllllllllllllllIlIlIIIlIIlIIlIIl)
    {
      ;
      ;
      ;
      ;
      ;
      GuiScreenCustomizePresets.Info lllllllllllllllIlIlIIIlIIlIIlIII = (GuiScreenCustomizePresets.Info)GuiScreenCustomizePresets.field_175310_f.get(lllllllllllllllIlIlIIIlIIlIIlllI);
      lllllllllllllllIlIlIIIlIIlIIIlll.func_178051_a(lllllllllllllllIlIlIIIlIIlIIllIl, lllllllllllllllIlIlIIIlIIlIIllII, field_178953_b);
      "".length();
    }
    
    protected void drawBackground() {}
    
    static {}
    
    private static void lllllIIlIllll()
    {
      lIlIIIIllIIl = new int[13];
      lIlIIIIllIIl[0] = (0xF1 ^ 0xA1);
      lIlIIIIllIIl[1] = (0x48 ^ 0x3F ^ 0xC ^ 0x5B);
      lIlIIIIllIIl[2] = (0x30 ^ 0x76 ^ 0x3D ^ 0x5D);
      lIlIIIIllIIl[3] = (-" ".length());
      lIlIIIIllIIl[4] = " ".length();
      lIlIIIIllIIl[5] = ((0x8 ^ 0x1A ^ 0x74 ^ 0x43) & (0x66 ^ 0x61 ^ 0x62 ^ 0x40 ^ -" ".length()));
      lIlIIIIllIIl[6] = (0x14 ^ 0x7 ^ 0x9 ^ 0x1F);
      lIlIIIIllIIl[7] = (-(-(0xC95F & 0x76FD) & 0xDFFC & 0x1F7F7F));
      lIlIIIIllIIl[8] = (-(-(66 + 114 - 132 + 91) & 0xDFFF & 0x5F7FEA));
      lIlIIIIllIIl[9] = (0xA7 ^ 0x95 ^ 0x12 ^ 0x27);
      lIlIIIIllIIl[10] = (121 + 86 - 157 + 130 ^ 25 + '' - 91 + 104);
      lIlIIIIllIIl[11] = (0xF8 ^ 0x8C ^ 0x8 ^ 0x72);
      lIlIIIIllIIl[12] = (0xFFFFFFFF & 0xFFFFFF);
    }
    
    protected void elementClicked(int lllllllllllllllIlIlIIIlIIlllIlll, boolean lllllllllllllllIlIlIIIlIIllllIll, int lllllllllllllllIlIlIIIlIIllllIlI, int lllllllllllllllIlIlIIIlIIllllIIl)
    {
      ;
      ;
      field_178053_u = lllllllllllllllIlIlIIIlIIlllIlll;
      func_175304_a();
      field_175317_i.setText(field_175310_fgetfield_175311_g.field_178053_u)).field_178954_c.toString());
    }
    
    protected boolean isSelected(int lllllllllllllllIlIlIIIlIIlllIIll)
    {
      ;
      ;
      if (lllllIIllIIII(lllllllllllllllIlIlIIIlIIlllIIll, field_178053_u)) {
        return lIlIIIIllIIl[4];
      }
      return lIlIIIIllIIl[5];
    }
    
    private void func_178051_a(int lllllllllllllllIlIlIIIlIIllIIlIl, int lllllllllllllllIlIlIIIlIIlIllIll, ResourceLocation lllllllllllllllIlIlIIIlIIlIllIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      int lllllllllllllllIlIlIIIlIIllIIIlI = lllllllllllllllIlIlIIIlIIllIIlIl + lIlIIIIllIIl[6];
      drawHorizontalLine(lllllllllllllllIlIlIIIlIIllIIIlI - lIlIIIIllIIl[4], lllllllllllllllIlIlIIIlIIllIIIlI + lIlIIIIllIIl[1], lllllllllllllllIlIlIIIlIIlIllIll - lIlIIIIllIIl[4], lIlIIIIllIIl[7]);
      drawHorizontalLine(lllllllllllllllIlIlIIIlIIllIIIlI - lIlIIIIllIIl[4], lllllllllllllllIlIlIIIlIIllIIIlI + lIlIIIIllIIl[1], lllllllllllllllIlIlIIIlIIlIllIll + lIlIIIIllIIl[1], lIlIIIIllIIl[8]);
      drawVerticalLine(lllllllllllllllIlIlIIIlIIllIIIlI - lIlIIIIllIIl[4], lllllllllllllllIlIlIIIlIIlIllIll - lIlIIIIllIIl[4], lllllllllllllllIlIlIIIlIIlIllIll + lIlIIIIllIIl[1], lIlIIIIllIIl[7]);
      drawVerticalLine(lllllllllllllllIlIlIIIlIIllIIIlI + lIlIIIIllIIl[1], lllllllllllllllIlIlIIIlIIlIllIll - lIlIIIIllIIl[4], lllllllllllllllIlIlIIIlIIlIllIll + lIlIIIIllIIl[1], lIlIIIIllIIl[8]);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      mc.getTextureManager().bindTexture(lllllllllllllllIlIlIIIlIIlIllIlI);
      int lllllllllllllllIlIlIIIlIIllIIIIl = lIlIIIIllIIl[1];
      int lllllllllllllllIlIlIIIlIIllIIIII = lIlIIIIllIIl[1];
      Tessellator lllllllllllllllIlIlIIIlIIlIlllll = Tessellator.getInstance();
      WorldRenderer lllllllllllllllIlIlIIIlIIlIllllI = lllllllllllllllIlIlIIIlIIlIlllll.getWorldRenderer();
      lllllllllllllllIlIlIIIlIIlIllllI.begin(lIlIIIIllIIl[9], DefaultVertexFormats.POSITION_TEX);
      lllllllllllllllIlIlIIIlIIlIllllI.pos(lllllllllllllllIlIlIIIlIIllIIIlI + lIlIIIIllIIl[5], lllllllllllllllIlIlIIIlIIlIllIll + lIlIIIIllIIl[1], 0.0D).tex(0.0D, 1.0D).endVertex();
      lllllllllllllllIlIlIIIlIIlIllllI.pos(lllllllllllllllIlIlIIIlIIllIIIlI + lIlIIIIllIIl[1], lllllllllllllllIlIlIIIlIIlIllIll + lIlIIIIllIIl[1], 0.0D).tex(1.0D, 1.0D).endVertex();
      lllllllllllllllIlIlIIIlIIlIllllI.pos(lllllllllllllllIlIlIIIlIIllIIIlI + lIlIIIIllIIl[1], lllllllllllllllIlIlIIIlIIlIllIll + lIlIIIIllIIl[5], 0.0D).tex(1.0D, 0.0D).endVertex();
      lllllllllllllllIlIlIIIlIIlIllllI.pos(lllllllllllllllIlIlIIIlIIllIIIlI + lIlIIIIllIIl[5], lllllllllllllllIlIlIIIlIIlIllIll + lIlIIIIllIIl[5], 0.0D).tex(0.0D, 0.0D).endVertex();
      lllllllllllllllIlIlIIIlIIlIlllll.draw();
    }
  }
}

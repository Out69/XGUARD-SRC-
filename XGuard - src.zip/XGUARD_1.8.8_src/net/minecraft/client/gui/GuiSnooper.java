package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.GameSettings.Options;
import net.minecraft.profiler.PlayerUsageSnooper;
import net.minecraft.server.integrated.IntegratedServer;

public class GuiSnooper
  extends GuiScreen
{
  private static boolean lIlIIlIIIIIl(int ???)
  {
    char lllllllllllllllllllIIlIllIIlllll;
    return ??? == 0;
  }
  
  private static boolean lIlIIlIIIIll(int ???)
  {
    int lllllllllllllllllllIIlIllIlIIIIl;
    return ??? != 0;
  }
  
  static
  {
    lIlIIlIIIIII();
    lIlIIIllIIII();
  }
  
  private static boolean lIlIIlIIIlII(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllllllIIlIllIlIllIl;
    return ??? == i;
  }
  
  private static String lIlIIIlIllII(String lllllllllllllllllllIIlIllIllIllI, String lllllllllllllllllllIIlIllIllIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllllIIlIllIlllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIIlIllIllIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllllIIlIllIlllIII = Cipher.getInstance("Blowfish");
      lllllllllllllllllllIIlIllIlllIII.init(llIIllIlll[3], lllllllllllllllllllIIlIllIlllIIl);
      return new String(lllllllllllllllllllIIlIllIlllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIIlIllIllIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllllIIlIllIllIlll)
    {
      lllllllllllllllllllIIlIllIllIlll.printStackTrace();
    }
    return null;
  }
  
  private static String lIlIIIlIllIl(String lllllllllllllllllllIIlIlllIllIIl, String lllllllllllllllllllIIlIlllIllIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllllIIlIlllIllllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIIlIlllIllIII.getBytes(StandardCharsets.UTF_8)), llIIllIlll[11]), "DES");
      Cipher lllllllllllllllllllIIlIlllIlllIl = Cipher.getInstance("DES");
      lllllllllllllllllllIIlIlllIlllIl.init(llIIllIlll[3], lllllllllllllllllllIIlIlllIllllI);
      return new String(lllllllllllllllllllIIlIlllIlllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIIlIlllIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllllIIlIlllIlllII)
    {
      lllllllllllllllllllIIlIlllIlllII.printStackTrace();
    }
    return null;
  }
  
  public GuiSnooper(GuiScreen lllllllllllllllllllIIllIIIIlllll, GameSettings lllllllllllllllllllIIllIIIIllllI)
  {
    field_146608_a = lllllllllllllllllllIIllIIIIlllII;
    game_settings_2 = lllllllllllllllllllIIllIIIIllllI;
  }
  
  private static boolean lIlIIlIIIllI(int ???, int arg1)
  {
    int i;
    double lllllllllllllllllllIIlIllIlIIlIl;
    return ??? < i;
  }
  
  private static void lIlIIIllIIII()
  {
    llIIllIIIl = new String[llIIllIlll[15]];
    llIIllIIIl[llIIllIlll[0]] = lIlIIIlIllII("FyXADQ8xM8oQJcKUPitCZUvTDwqGG15/", "jqZYM");
    llIIllIIIl[llIIllIlll[1]] = lIlIIIlIllIl("4m5qvMpzYDCWbn1bATRQdIv2oscaZD2O", "hLSlm");
    llIIllIIIl[llIIllIlll[3]] = lIlIIIlIllll("AAQZQQoIHxU=", "gqpon");
    llIIllIIIl[llIIllIlll[7]] = lIlIIIlIllIl("PJtRVaPGoTk=", "Mghtk");
    llIIllIIIl[llIIllIlll[8]] = lIlIIIlIllll("", "mUhJD");
    llIIllIIIl[llIIllIlll[10]] = lIlIIIlIllll("NUs=", "fkcUI");
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    field_146610_i = I18n.format(llIIllIIIl[llIIllIlll[0]], new Object[llIIllIlll[0]]);
    String lllllllllllllllllllIIllIIIIlIIll = I18n.format(llIIllIIIl[llIIllIlll[1]], new Object[llIIllIlll[0]]);
    List<String> lllllllllllllllllllIIllIIIIlIIlI = Lists.newArrayList();
    char lllllllllllllllllllIIllIIIIIlIIl = fontRendererObj.listFormattedStringToWidth(lllllllllllllllllllIIllIIIIlIIll, width - llIIllIlll[2]).iterator();
    "".length();
    if (" ".length() < 0) {
      return;
    }
    while (!lIlIIlIIIIIl(lllllllllllllllllllIIllIIIIIlIIl.hasNext()))
    {
      Object lllllllllllllllllllIIllIIIIlIIIl = lllllllllllllllllllIIllIIIIIlIIl.next();
      "".length();
    }
    field_146607_r = ((String[])lllllllllllllllllllIIllIIIIlIIlI.toArray(new String[lllllllllllllllllllIIllIIIIlIIlI.size()]));
    field_146604_g.clear();
    field_146609_h.clear();
    field_146605_t = new GuiButton(llIIllIlll[1], width / llIIllIlll[3] - llIIllIlll[4], height - llIIllIlll[2], llIIllIlll[5], llIIllIlll[6], game_settings_2.getKeyBinding(GameSettings.Options.SNOOPER_ENABLED));
    "".length();
    new GuiButton(llIIllIlll[3], width / llIIllIlll[3] + llIIllIlll[3], height - llIIllIlll[2], llIIllIlll[5], llIIllIlll[6], I18n.format(llIIllIIIl[llIIllIlll[3]], new Object[llIIllIlll[0]]));
    "".length();
    if ((lIlIIlIIIIlI(mc.getIntegratedServer())) && (lIlIIlIIIIlI(mc.getIntegratedServer().getPlayerUsageSnooper())))
    {
      "".length();
      if (" ".length() < "  ".length()) {
        break label391;
      }
    }
    label391:
    boolean lllllllllllllllllllIIllIIIIlIIII = llIIllIlll[0];
    short lllllllllllllllllllIIllIIIIIlIII = new TreeMap(mc.getPlayerUsageSnooper().getCurrentStats()).entrySet().iterator();
    "".length();
    if (null != null) {
      return;
    }
    label493:
    while (!lIlIIlIIIIIl(lllllllllllllllllllIIllIIIIIlIII.hasNext()))
    {
      Map.Entry<String, String> lllllllllllllllllllIIllIIIIIllll = (Map.Entry)lllllllllllllllllllIIllIIIIIlIII.next();
      if (lIlIIlIIIIll(lllllllllllllllllllIIllIIIIlIIII))
      {
        "".length();
        if (" ".length() > 0) {
          break label493;
        }
      }
      llIIllIIIl[llIIllIlll[7]].<init>(String.valueOf(llIIllIIIl[llIIllIlll[8]]));
      "".length();
      "".length();
    }
    if (lIlIIlIIIIll(lllllllllllllllllllIIllIIIIlIIII))
    {
      lllllllllllllllllllIIllIIIIIlIII = new TreeMap(mc.getIntegratedServer().getPlayerUsageSnooper().getCurrentStats()).entrySet().iterator();
      "".length();
      if ((0x5B ^ 0x13 ^ 0x51 ^ 0x1D) < 0) {
        return;
      }
      while (!lIlIIlIIIIIl(lllllllllllllllllllIIllIIIIIlIII.hasNext()))
      {
        Map.Entry<String, String> lllllllllllllllllllIIllIIIIIlllI = (Map.Entry)lllllllllllllllllllIIllIIIIIlIII.next();
        new StringBuilder(llIIllIIIl[llIIllIlll[10]]);
        "".length();
        "".length();
      }
    }
    field_146606_s = new List();
  }
  
  private static String lIlIIIlIllll(String lllllllllllllllllllIIlIlllIIIllI, String lllllllllllllllllllIIlIlllIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIIlIlllIIIllI = new String(Base64.getDecoder().decode(lllllllllllllllllllIIlIlllIIIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllllIIlIlllIIlIIl = new StringBuilder();
    char[] lllllllllllllllllllIIlIlllIIlIII = lllllllllllllllllllIIlIlllIIlIlI.toCharArray();
    int lllllllllllllllllllIIlIlllIIIlll = llIIllIlll[0];
    float lllllllllllllllllllIIlIlllIIIIIl = lllllllllllllllllllIIlIlllIIIllI.toCharArray();
    Exception lllllllllllllllllllIIlIlllIIIIII = lllllllllllllllllllIIlIlllIIIIIl.length;
    long lllllllllllllllllllIIlIllIllllll = llIIllIlll[0];
    while (lIlIIlIIIllI(lllllllllllllllllllIIlIllIllllll, lllllllllllllllllllIIlIlllIIIIII))
    {
      char lllllllllllllllllllIIlIlllIIllII = lllllllllllllllllllIIlIlllIIIIIl[lllllllllllllllllllIIlIllIllllll];
      "".length();
      "".length();
      if (((0x83 ^ 0xBD) & (0xAD ^ 0x93 ^ 0xFFFFFFFF)) != 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllllIIlIlllIIlIIl);
  }
  
  private static boolean lIlIIlIIIIlI(Object ???)
  {
    char lllllllllllllllllllIIlIllIlIIIll;
    return ??? != null;
  }
  
  private static void lIlIIlIIIIII()
  {
    llIIllIlll = new int[16];
    llIIllIlll[0] = ((0xDD ^ 0x81) & (0x21 ^ 0x7D ^ 0xFFFFFFFF));
    llIIllIlll[1] = " ".length();
    llIIllIlll[2] = ('' + 48 - 91 + 88 ^ '' + '' - 199 + 73);
    llIIllIlll[3] = "  ".length();
    llIIllIlll[4] = (97 + 54 - 77 + 73 + (0xD5 ^ 0x92) - ('¥' + 85 - 168 + 88) + (0xCF ^ 0xA7));
    llIIllIlll[5] = ((0x7E ^ 0x36) + "   ".length() - (0x5E ^ 0x48) + (0x2 ^ 0x63));
    llIIllIlll[6] = (0x60 ^ 0x4B ^ 0x1D ^ 0x22);
    llIIllIlll[7] = "   ".length();
    llIIllIlll[8] = ('' + 18 - 0 + 12 ^ 35 + 90 - 115 + 167);
    llIIllIlll[9] = ('¬' + 'Ï' - 210 + 51);
    llIIllIlll[10] = (0x53 ^ 0x56);
    llIIllIlll[11] = (0x45 ^ 0x15 ^ 0xF0 ^ 0xA8);
    llIIllIlll[12] = (0xFFFFFFFF & 0xFFFFFF);
    llIIllIlll[13] = (0x2D ^ 0x3B);
    llIIllIlll[14] = (-(0xDF35 & 0x3FFF) & 0xBFF5 & 0x80DFBE);
    llIIllIlll[15] = ("  ".length() ^ 0x81 ^ 0x85);
  }
  
  private static boolean lIlIIlIIIlIl(int ???, int arg1)
  {
    int i;
    char lllllllllllllllllllIIlIllIlIlIIl;
    return ??? >= i;
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllllllIIllIIIIIIIIl)
    throws IOException
  {
    ;
    ;
    if (lIlIIlIIIIll(enabled))
    {
      if (lIlIIlIIIlII(id, llIIllIlll[3]))
      {
        game_settings_2.saveOptions();
        game_settings_2.saveOptions();
        mc.displayGuiScreen(field_146608_a);
      }
      if (lIlIIlIIIlII(id, llIIllIlll[1]))
      {
        game_settings_2.setOptionValue(GameSettings.Options.SNOOPER_ENABLED, llIIllIlll[1]);
        field_146605_t.displayString = game_settings_2.getKeyBinding(GameSettings.Options.SNOOPER_ENABLED);
      }
    }
  }
  
  public void drawScreen(int lllllllllllllllllllIIlIllllIlllI, int lllllllllllllllllllIIlIllllIllIl, float lllllllllllllllllllIIlIlllllIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIIlIlllllIlIl.drawDefaultBackground();
    field_146606_s.drawScreen(lllllllllllllllllllIIlIllllIlllI, lllllllllllllllllllIIlIllllIllIl, lllllllllllllllllllIIlIlllllIIlI);
    lllllllllllllllllllIIlIlllllIlIl.drawCenteredString(fontRendererObj, field_146610_i, width / llIIllIlll[3], llIIllIlll[11], llIIllIlll[12]);
    int lllllllllllllllllllIIlIlllllIIIl = llIIllIlll[13];
    Exception lllllllllllllllllllIIlIllllIlIII = (lllllllllllllllllllIIlIllllIIlll = field_146607_r).length;
    Exception lllllllllllllllllllIIlIllllIlIIl = llIIllIlll[0];
    "".length();
    if (" ".length() == 0) {
      return;
    }
    while (!lIlIIlIIIlIl(lllllllllllllllllllIIlIllllIlIIl, lllllllllllllllllllIIlIllllIlIII))
    {
      String lllllllllllllllllllIIlIlllllIIII = lllllllllllllllllllIIlIllllIIlll[lllllllllllllllllllIIlIllllIlIIl];
      lllllllllllllllllllIIlIlllllIlIl.drawCenteredString(fontRendererObj, lllllllllllllllllllIIlIlllllIIII, width / llIIllIlll[3], lllllllllllllllllllIIlIlllllIIIl, llIIllIlll[14]);
      lllllllllllllllllllIIlIlllllIIIl += fontRendererObj.FONT_HEIGHT;
      lllllllllllllllllllIIlIllllIlIIl++;
    }
    lllllllllllllllllllIIlIlllllIlIl.drawScreen(lllllllllllllllllllIIlIllllIlllI, lllllllllllllllllllIIlIllllIllIl, lllllllllllllllllllIIlIlllllIIlI);
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    lllllllllllllllllllIIllIIIIIIllI.handleMouseInput();
    field_146606_s.handleMouseInput();
  }
  
  class List
    extends GuiSlot
  {
    protected void elementClicked(int lllllllllllllllIlIllIlIIlIlIIlII, boolean lllllllllllllllIlIllIlIIlIlIIIll, int lllllllllllllllIlIllIlIIlIlIIIlI, int lllllllllllllllIlIllIlIIlIlIIIIl) {}
    
    protected boolean isSelected(int lllllllllllllllIlIllIlIIlIIlllll)
    {
      return lIIlllIIIlII[3];
    }
    
    private static void llllIIIIllIII()
    {
      lIIlllIIIlII = new int[7];
      lIIlllIIIlII[0] = (0x2A ^ 0x1D ^ 0x3A ^ 0x5D);
      lIIlllIIIlII[1] = (0x20 ^ 0x8);
      lIIlllIIIlII[2] = " ".length();
      lIIlllIIIlII[3] = ((0x7B ^ 0x1 ^ 0xDF ^ 0x93) & (0xB2 ^ 0xA5 ^ 0xE ^ 0x2F ^ -" ".length()));
      lIIlllIIIlII[4] = (0x8B ^ 0x81);
      lIIlllIIIlII[5] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
      lIIlllIIIlII[6] = ((0x57 ^ 0x69) + (124 + 85 - 141 + 88) - "   ".length() + (0x64 ^ 0x6B));
    }
    
    protected void drawBackground() {}
    
    protected void drawSlot(int lllllllllllllllIlIllIlIIlIIllIIl, int lllllllllllllllIlIllIlIIlIIllIII, int lllllllllllllllIlIllIlIIlIIlIlll, int lllllllllllllllIlIllIlIIlIIlIllI, int lllllllllllllllIlIllIlIIlIIlIlIl, int lllllllllllllllIlIllIlIIlIIlIlII)
    {
      ;
      ;
      ;
      "".length();
      "".length();
    }
    
    protected int getScrollBarX()
    {
      ;
      return width - lIIlllIIIlII[4];
    }
    
    static {}
    
    protected int getSize()
    {
      ;
      return field_146604_g.size();
    }
    
    public List()
    {
      lllllllllllllllIlIllIlIIlIlIlIlI.<init>(mc, width, height, lIIlllIIIlII[0], height - lIIlllIIIlII[1], fontRendererObj.FONT_HEIGHT + lIIlllIIIlII[2]);
    }
  }
}

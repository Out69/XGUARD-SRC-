package net.minecraft.client.gui;

import net.minecraft.util.IChatComponent;

public class ChatLine
{
  public int getChatLineID()
  {
    ;
    return chatLineID;
  }
  
  public IChatComponent getChatComponent()
  {
    ;
    return lineString;
  }
  
  public ChatLine(int lllllllllllllllIllIIIlIllIIllIIl, IChatComponent lllllllllllllllIllIIIlIllIIllIII, int lllllllllllllllIllIIIlIllIIlIIll)
  {
    lineString = lllllllllllllllIllIIIlIllIIllIII;
    updateCounterCreated = lllllllllllllllIllIIIlIllIIllIIl;
    chatLineID = lllllllllllllllIllIIIlIllIIlIIll;
  }
  
  public int getUpdatedCounter()
  {
    ;
    return updateCounterCreated;
  }
}

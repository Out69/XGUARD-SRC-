package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;

public class GuiSlider
  extends GuiButton
{
  public float func_175220_c()
  {
    ;
    return min + (max - min) * sliderPosition;
  }
  
  private static int lIllllIlll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public boolean mousePressed(Minecraft lIlIIllIIIlIlIl, int lIlIIllIIIlIlII, int lIlIIllIIIlIIll)
  {
    ;
    ;
    ;
    ;
    if (lIllllIIIl(lIlIIllIIIlIllI.mousePressed(lIlIIllIIIlIlIl, lIlIIllIIIlIlII, lIlIIllIIIlIIll)))
    {
      sliderPosition = ((lIlIIllIIIlIlII - (xPosition + lllIlIll[4])) / (width - lllIlIll[5]));
      if (lIllllIlIl(lIllllIlll(sliderPosition, 0.0F))) {
        sliderPosition = 0.0F;
      }
      if (lIllllIllI(lIlllllIII(sliderPosition, 1.0F))) {
        sliderPosition = 1.0F;
      }
      displayString = lIlIIllIIIlIllI.getDisplayString();
      responder.onTick(id, lIlIIllIIIlIllI.func_175220_c());
      isMouseDown = lllIlIll[3];
      return lllIlIll[3];
    }
    return lllIlIll[2];
  }
  
  private static String lIlllIlllI(String lIlIIlIllllIlll, String lIlIIlIllllIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIlIIlIllllllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIlIIlIllllIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIlIIlIlllllIll = Cipher.getInstance("Blowfish");
      lIlIIlIlllllIll.init(lllIlIll[8], lIlIIlIllllllII);
      return new String(lIlIIlIlllllIll.doFinal(Base64.getDecoder().decode(lIlIIlIllllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIlIIlIlllllIlI)
    {
      lIlIIlIlllllIlI.printStackTrace();
    }
    return null;
  }
  
  public void mouseReleased(int lIlIIllIIIlIIII, int lIlIIllIIIIllll)
  {
    ;
    isMouseDown = lllIlIll[2];
  }
  
  protected void mouseDragged(Minecraft lIlIIllIIlIlIIl, int lIlIIllIIlIIlIl, int lIlIIllIIlIIlll)
  {
    ;
    ;
    if (lIllllIIIl(visible))
    {
      if (lIllllIIIl(isMouseDown))
      {
        sliderPosition = ((lIlIIllIIlIlIII - (xPosition + lllIlIll[4])) / (width - lllIlIll[5]));
        if (lIllllIlIl(lIllllIIll(sliderPosition, 0.0F))) {
          sliderPosition = 0.0F;
        }
        if (lIllllIllI(lIllllIlII(sliderPosition, 1.0F))) {
          sliderPosition = 1.0F;
        }
        displayString = lIlIIllIIlIIllI.getDisplayString();
        responder.onTick(id, lIlIIllIIlIIllI.func_175220_c());
      }
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      lIlIIllIIlIIllI.drawTexturedModalRect(xPosition + (int)(sliderPosition * (width - lllIlIll[5])), yPosition, lllIlIll[2], lllIlIll[6], lllIlIll[4], lllIlIll[1]);
      lIlIIllIIlIIllI.drawTexturedModalRect(xPosition + (int)(sliderPosition * (width - lllIlIll[5])) + lllIlIll[4], yPosition, lllIlIll[7], lllIlIll[6], lllIlIll[4], lllIlIll[1]);
    }
  }
  
  public void func_175218_a(float lIlIIllIIllIllI, boolean lIlIIllIIlllIII)
  {
    ;
    ;
    ;
    sliderPosition = ((lIlIIllIIlllIIl - min) / (max - min));
    displayString = lIlIIllIIlllIlI.getDisplayString();
    if (lIllllIIIl(lIlIIllIIlllIII)) {
      responder.onTick(id, lIlIIllIIlllIlI.func_175220_c());
    }
  }
  
  public float func_175217_d()
  {
    ;
    return sliderPosition;
  }
  
  protected int getHoverState(boolean lIlIIllIIlIllIl)
  {
    return lllIlIll[2];
  }
  
  private String getDisplayString()
  {
    ;
    if (lIllllIIlI(formatHelper))
    {
      new StringBuilder(String.valueOf(I18n.format(name, new Object[lllIlIll[2]])));
      "".length();
      if (((0x7E ^ 0x3A) & (0xE4 ^ 0xA0 ^ 0xFFFFFFFF)) != "   ".length()) {
        break label122;
      }
      return null;
    }
    label122:
    return formatHelper.getText(id, I18n.format(name, new Object[lllIlIll[2]]), lIlIIllIIlIllll.func_175220_c());
  }
  
  private static boolean lIllllIIlI(Object ???)
  {
    String lIlIIlIllllIIlI;
    return ??? == null;
  }
  
  public void func_175219_a(float lIlIIllIIlIIIIl)
  {
    ;
    ;
    sliderPosition = lIlIIllIIlIIIIl;
    displayString = lIlIIllIIlIIIlI.getDisplayString();
    responder.onTick(id, lIlIIllIIlIIIlI.func_175220_c());
  }
  
  private static boolean lIllllIIIl(int ???)
  {
    int lIlIIlIllllIIII;
    return ??? != 0;
  }
  
  private static int lIllllIlII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static void lIlllIllll()
  {
    lllIlIlI = new String[lllIlIll[8]];
    lllIlIlI[lllIlIll[2]] = lIlllIllIl("E2oKiFhM00k=", "WSwVd");
    lllIlIlI[lllIlIll[3]] = lIlllIlllI("jD88weV8a54=", "bqNOu");
  }
  
  private static boolean lIllllIlIl(int ???)
  {
    int lIlIIlIlllIlllI;
    return ??? < 0;
  }
  
  private static void lIllllIIII()
  {
    lllIlIll = new int[9];
    lllIlIll[0] = (5 + 110 - 80 + 115);
    lllIlIll[1] = (0x2C ^ 0x52 ^ 0xD5 ^ 0xBF);
    lllIlIll[2] = ((0x4 ^ 0x36) & (0xB0 ^ 0x82 ^ 0xFFFFFFFF));
    lllIlIll[3] = " ".length();
    lllIlIll[4] = (0x49 ^ 0x23 ^ 0x57 ^ 0x39);
    lllIlIll[5] = (0xE3 ^ 0xA3 ^ 0x48 ^ 0x0);
    lllIlIll[6] = ('ß' + 5 - 35 + 35 ^ 61 + 117 - 108 + 96);
    lllIlIll[7] = (81 + 111 - 184 + 127 + (0x15 ^ 0x5F) - (0x8B ^ 0xAF) + (0x2D ^ 0x3A));
    lllIlIll[8] = "  ".length();
  }
  
  private static int lIlllllIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIllllIllI(int ???)
  {
    Exception lIlIIlIlllIllII;
    return ??? > 0;
  }
  
  private static int lIllllIIll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public GuiSlider(GuiPageButtonList.GuiResponder lIlIIllIlIlIIll, int lIlIIllIlIlIIlI, int lIlIIllIlIlIIIl, int lIlIIllIlIlIIII, String lIlIIllIlIIIlIl, float lIlIIllIlIIlllI, float lIlIIllIlIIIIll, float lIlIIllIlIIIIlI, FormatHelper lIlIIllIlIIIIIl)
  {
    lIlIIllIlIIlIlI.<init>(lIlIIllIlIlIIlI, lIlIIllIlIlIIIl, lIlIIllIlIlIIII, lllIlIll[0], lllIlIll[1], lllIlIlI[lllIlIll[2]]);
    name = lIlIIllIlIIIlIl;
    min = lIlIIllIlIIlllI;
    max = lIlIIllIlIIIIll;
    sliderPosition = ((lIlIIllIlIIIIlI - lIlIIllIlIIlllI) / (lIlIIllIlIIIIll - lIlIIllIlIIlllI));
    formatHelper = lIlIIllIlIIIIIl;
    responder = lIlIIllIlIlIIll;
    displayString = lIlIIllIlIIlIlI.getDisplayString();
  }
  
  static
  {
    lIllllIIII();
    lIlllIllll();
  }
  
  private static String lIlllIllIl(String lIlIIllIIIIIlII, String lIlIIllIIIIIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIlIIllIIIIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIlIIllIIIIIlIl.getBytes(StandardCharsets.UTF_8)), lllIlIll[5]), "DES");
      Cipher lIlIIllIIIIlIII = Cipher.getInstance("DES");
      lIlIIllIIIIlIII.init(lllIlIll[8], lIlIIllIIIIlIIl);
      return new String(lIlIIllIIIIlIII.doFinal(Base64.getDecoder().decode(lIlIIllIIIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIlIIllIIIIIlll)
    {
      lIlIIllIIIIIlll.printStackTrace();
    }
    return null;
  }
  
  public static abstract interface FormatHelper
  {
    public abstract String getText(int paramInt, String paramString, float paramFloat);
  }
}

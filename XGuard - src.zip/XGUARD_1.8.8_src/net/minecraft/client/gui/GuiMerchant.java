package net.minecraft.client.gui;

import io.netty.buffer.Unpooled;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ContainerMerchant;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.util.IChatComponent;
import net.minecraft.village.MerchantRecipe;
import net.minecraft.village.MerchantRecipeList;
import net.minecraft.world.World;

public class GuiMerchant
  extends GuiContainer
{
  private static boolean llIIIIllIlllll(int ???)
  {
    boolean llllllllllllllIllIIIIIllllIIlIIl;
    return ??? < 0;
  }
  
  private static void llIIIIllIllIII()
  {
    lllllllIllll = new int[21];
    lllllllIllll[0] = ((0x6 ^ 0x8) & (0x0 ^ 0xE ^ 0xFFFFFFFF));
    lllllllIllll[1] = "  ".length();
    lllllllIllll[2] = " ".length();
    lllllllIllll[3] = (0xDB ^ 0xA3);
    lllllllIllll[4] = (108 + 17 - -45 + 7 ^ '' + 84 - 93 + 43);
    lllllllIllll[5] = (0x62 ^ 0x7A);
    lllllllIllll[6] = ('¡' + '¤' - 256 + 120 ^ 127 + 5 - -13 + 8);
    lllllllIllll[7] = (0x22 ^ 0x31);
    lllllllIllll[8] = (65 + '¼' - 125 + 62 ^ '¡' + 72 - 220 + 171);
    lllllllIllll[9] = (0xC6E5 & 0x40795A);
    lllllllIllll[10] = (0x5 ^ 0xD);
    lllllllIllll[11] = (0xFC ^ 0x91 ^ 0x83 ^ 0x8E);
    lllllllIllll[12] = (0xFE ^ 0xAD);
    lllllllIllll[13] = ("   ".length() ^ 0x54 ^ 0x42);
    lllllllIllll[14] = (110 + '¶' - 226 + 146);
    lllllllIllll[15] = (0xA7 ^ 0x9E ^ 0x97 ^ 0xB2);
    lllllllIllll[16] = (0x1A ^ 0x5E ^ 0xE4 ^ 0x93);
    lllllllIllll[17] = (0x40 ^ 0x7E);
    lllllllIllll[18] = (0xC2 ^ 0x98 ^ 0x5F ^ 0x15);
    lllllllIllll[19] = "   ".length();
    lllllllIllll[20] = (53 + 91 - 41 + 29 ^ 121 + 58 - 63 + 12);
  }
  
  static
  {
    llIIIIllIllIII();
    llIIIIllIlIIll();
  }
  
  public void updateScreen()
  {
    ;
    ;
    llllllllllllllIllIIIIlIIIlIlllIl.updateScreen();
    MerchantRecipeList llllllllllllllIllIIIIlIIIlIlllII = merchant.getRecipes(mc.thePlayer);
    if (llIIIIllIllIlI(llllllllllllllIllIIIIlIIIlIlllII))
    {
      if (llIIIIllIllIll(selectedMerchantRecipe, llllllllllllllIllIIIIlIIIlIlllII.size() - lllllllIllll[2]))
      {
        "".length();
        if ("  ".length() != " ".length()) {
          break label82;
        }
      }
      label82:
      lllllllIllll2enabled = lllllllIllll[0];
      if (llIIIIllIlllII(selectedMerchantRecipe))
      {
        "".length();
        if (null == null) {
          break label120;
        }
      }
      label120:
      lllllllIllll2enabled = lllllllIllll[0];
    }
  }
  
  private static String llIIIIllIlIIlI(String llllllllllllllIllIIIIIlllllIllll, String llllllllllllllIllIIIIIllllllIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIIIIllllllIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIIIIllllllIIII.getBytes(StandardCharsets.UTF_8)), lllllllIllll[10]), "DES");
      Cipher llllllllllllllIllIIIIIllllllIIll = Cipher.getInstance("DES");
      llllllllllllllIllIIIIIllllllIIll.init(lllllllIllll[1], llllllllllllllIllIIIIIllllllIlII);
      return new String(llllllllllllllIllIIIIIllllllIIll.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIIIIlllllIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIIIIllllllIIlI)
    {
      llllllllllllllIllIIIIIllllllIIlI.printStackTrace();
    }
    return null;
  }
  
  private static String llIIIIllIIllII(String llllllllllllllIllIIIIIlllllIIIlI, String llllllllllllllIllIIIIIlllllIIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIIIIlllllIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIIIIlllllIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIIIIIlllllIIllI = Cipher.getInstance("Blowfish");
      llllllllllllllIllIIIIIlllllIIllI.init(lllllllIllll[1], llllllllllllllIllIIIIIlllllIIlll);
      return new String(llllllllllllllIllIIIIIlllllIIllI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIIIIlllllIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIIIIlllllIIlIl)
    {
      llllllllllllllIllIIIIIlllllIIlIl.printStackTrace();
    }
    return null;
  }
  
  public GuiMerchant(InventoryPlayer llllllllllllllIllIIIIlIIIlllIlll, IMerchant llllllllllllllIllIIIIlIIIlllIllI, World llllllllllllllIllIIIIlIIIlllIlIl)
  {
    llllllllllllllIllIIIIlIIIllllIII.<init>(new ContainerMerchant(llllllllllllllIllIIIIlIIIlllIlll, llllllllllllllIllIIIIlIIIlllIllI, llllllllllllllIllIIIIlIIIlllIlIl));
    merchant = llllllllllllllIllIIIIlIIIlllIllI;
    chatComponent = llllllllllllllIllIIIIlIIIlllIllI.getDisplayName();
  }
  
  private static void llIIIIllIlIIll()
  {
    lllllllIlIlI = new String[lllllllIllll[20]];
    lllllllIlIlI[lllllllIllll[0]] = llIIIIllIIllII("g3jeuWmA4evavSK9x/6wnzkkYez5X0rCD2LznOafC6S2em03InxxJA==", "YdHdv");
    lllllllIlIlI[lllllllIllll[2]] = llIIIIllIIllII("ghyS8ngn3jZlaN42+x+RAr4Ie2eWH8Mq", "GfART");
    lllllllIlIlI[lllllllIllll[1]] = llIIIIllIlIIIl("BBIvBCAaND8=", "IQSPR");
    lllllllIlIlI[lllllllIllll[19]] = llIIIIllIlIIlI("aJG9gKMEaUlqSy6ZXSsLJTap+STk4hs7", "kUprJ");
  }
  
  private static boolean llIIIIllIllIlI(Object ???)
  {
    String llllllllllllllIllIIIIIllllIlIlIl;
    return ??? != null;
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    llllllllllllllIllIIIIlIIIllIlIlI.initGui();
    int llllllllllllllIllIIIIlIIIllIllII = (width - xSize) / lllllllIllll[1];
    int llllllllllllllIllIIIIlIIIllIlIll = (height - ySize) / lllllllIllll[1];
    nextButton = new MerchantButton(lllllllIllll[2], llllllllllllllIllIIIIlIIIllIllII + lllllllIllll[3] + lllllllIllll[4], llllllllllllllIllIIIIlIIIllIlIll + lllllllIllll[5] - lllllllIllll[2], lllllllIllll[2]);
    "".length();
    previousButton = new MerchantButton(lllllllIllll[1], llllllllllllllIllIIIIlIIIllIllII + lllllllIllll[6] - lllllllIllll[7], llllllllllllllIllIIIIlIIIllIlIll + lllllllIllll[5] - lllllllIllll[2], lllllllIllll[0]);
    "".length();
    nextButton.enabled = lllllllIllll[0];
    previousButton.enabled = lllllllIllll[0];
  }
  
  private static boolean llIIIIlllIIIII(int ???)
  {
    byte llllllllllllllIllIIIIIllllIIllll;
    return ??? != 0;
  }
  
  private static boolean llIIIIlllIIIlI(int ???)
  {
    String llllllllllllllIllIIIIIllllIIlIll;
    return ??? >= 0;
  }
  
  protected void drawGuiContainerForegroundLayer(int llllllllllllllIllIIIIlIIIllIIlII, int llllllllllllllIllIIIIlIIIllIIIll)
  {
    ;
    ;
    String llllllllllllllIllIIIIlIIIllIIIlI = chatComponent.getUnformattedText();
    "".length();
    "".length();
  }
  
  public void drawScreen(int llllllllllllllIllIIIIlIIIIlIlIlI, int llllllllllllllIllIIIIlIIIIlIlIIl, float llllllllllllllIllIIIIlIIIIlIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIIIlIIIIIlllll.drawScreen(llllllllllllllIllIIIIlIIIIlIlIlI, llllllllllllllIllIIIIlIIIIlIlIIl, llllllllllllllIllIIIIlIIIIlIlIII);
    MerchantRecipeList llllllllllllllIllIIIIlIIIIlIIlll = merchant.getRecipes(mc.thePlayer);
    if ((llIIIIllIllIlI(llllllllllllllIllIIIIlIIIIlIIlll)) && (llIIIIlllIIIIl(llllllllllllllIllIIIIlIIIIlIIlll.isEmpty())))
    {
      int llllllllllllllIllIIIIlIIIIlIIllI = (width - xSize) / lllllllIllll[1];
      int llllllllllllllIllIIIIlIIIIlIIlIl = (height - ySize) / lllllllIllll[1];
      int llllllllllllllIllIIIIlIIIIlIIlII = selectedMerchantRecipe;
      MerchantRecipe llllllllllllllIllIIIIlIIIIlIIIll = (MerchantRecipe)llllllllllllllIllIIIIlIIIIlIIlll.get(llllllllllllllIllIIIIlIIIIlIIlII);
      ItemStack llllllllllllllIllIIIIlIIIIlIIIlI = llllllllllllllIllIIIIlIIIIlIIIll.getItemToBuy();
      ItemStack llllllllllllllIllIIIIlIIIIlIIIIl = llllllllllllllIllIIIIlIIIIlIIIll.getSecondItemToBuy();
      ItemStack llllllllllllllIllIIIIlIIIIlIIIII = llllllllllllllIllIIIIlIIIIlIIIll.getItemToSell();
      GlStateManager.pushMatrix();
      RenderHelper.enableGUIStandardItemLighting();
      GlStateManager.disableLighting();
      GlStateManager.enableRescaleNormal();
      GlStateManager.enableColorMaterial();
      GlStateManager.enableLighting();
      itemRender.zLevel = 100.0F;
      itemRender.renderItemAndEffectIntoGUI(llllllllllllllIllIIIIlIIIIlIIIlI, llllllllllllllIllIIIIlIIIIlIIllI + lllllllIllll[6], llllllllllllllIllIIIIlIIIIlIIlIl + lllllllIllll[5]);
      itemRender.renderItemOverlays(fontRendererObj, llllllllllllllIllIIIIlIIIIlIIIlI, llllllllllllllIllIIIIlIIIIlIIllI + lllllllIllll[6], llllllllllllllIllIIIIlIIIIlIIlIl + lllllllIllll[5]);
      if (llIIIIllIllIlI(llllllllllllllIllIIIIlIIIIlIIIIl))
      {
        itemRender.renderItemAndEffectIntoGUI(llllllllllllllIllIIIIlIIIIlIIIIl, llllllllllllllIllIIIIlIIIIlIIllI + lllllllIllll[17], llllllllllllllIllIIIIlIIIIlIIlIl + lllllllIllll[5]);
        itemRender.renderItemOverlays(fontRendererObj, llllllllllllllIllIIIIlIIIIlIIIIl, llllllllllllllIllIIIIlIIIIlIIllI + lllllllIllll[17], llllllllllllllIllIIIIlIIIIlIIlIl + lllllllIllll[5]);
      }
      itemRender.renderItemAndEffectIntoGUI(llllllllllllllIllIIIIlIIIIlIIIII, llllllllllllllIllIIIIlIIIIlIIllI + lllllllIllll[3], llllllllllllllIllIIIIlIIIIlIIlIl + lllllllIllll[5]);
      itemRender.renderItemOverlays(fontRendererObj, llllllllllllllIllIIIIlIIIIlIIIII, llllllllllllllIllIIIIlIIIIlIIllI + lllllllIllll[3], llllllllllllllIllIIIIlIIIIlIIlIl + lllllllIllll[5]);
      itemRender.zLevel = 0.0F;
      GlStateManager.disableLighting();
      if ((llIIIIlllIIIII(llllllllllllllIllIIIIlIIIIIlllll.isPointInRegion(lllllllIllll[6], lllllllIllll[5], lllllllIllll[18], lllllllIllll[18], llllllllllllllIllIIIIlIIIIlIlIlI, llllllllllllllIllIIIIlIIIIlIlIIl))) && (llIIIIllIllIlI(llllllllllllllIllIIIIlIIIIlIIIlI)))
      {
        llllllllllllllIllIIIIlIIIIIlllll.renderToolTip(llllllllllllllIllIIIIlIIIIlIIIlI, llllllllllllllIllIIIIlIIIIlIlIlI, llllllllllllllIllIIIIlIIIIlIlIIl);
        "".length();
        if (-"   ".length() <= 0) {}
      }
      else if ((llIIIIllIllIlI(llllllllllllllIllIIIIlIIIIlIIIIl)) && (llIIIIlllIIIII(llllllllllllllIllIIIIlIIIIIlllll.isPointInRegion(lllllllIllll[17], lllllllIllll[5], lllllllIllll[18], lllllllIllll[18], llllllllllllllIllIIIIlIIIIlIlIlI, llllllllllllllIllIIIIlIIIIlIlIIl))) && (llIIIIllIllIlI(llllllllllllllIllIIIIlIIIIlIIIIl)))
      {
        llllllllllllllIllIIIIlIIIIIlllll.renderToolTip(llllllllllllllIllIIIIlIIIIlIIIIl, llllllllllllllIllIIIIlIIIIlIlIlI, llllllllllllllIllIIIIlIIIIlIlIIl);
        "".length();
        if (((0x3C ^ 0x2B) & (0xB1 ^ 0xA6 ^ 0xFFFFFFFF)) == 0) {}
      }
      else if ((llIIIIllIllIlI(llllllllllllllIllIIIIlIIIIlIIIII)) && (llIIIIlllIIIII(llllllllllllllIllIIIIlIIIIIlllll.isPointInRegion(lllllllIllll[3], lllllllIllll[5], lllllllIllll[18], lllllllIllll[18], llllllllllllllIllIIIIlIIIIlIlIlI, llllllllllllllIllIIIIlIIIIlIlIIl))) && (llIIIIllIllIlI(llllllllllllllIllIIIIlIIIIlIIIII)))
      {
        llllllllllllllIllIIIIlIIIIIlllll.renderToolTip(llllllllllllllIllIIIIlIIIIlIIIII, llllllllllllllIllIIIIlIIIIlIlIlI, llllllllllllllIllIIIIlIIIIlIlIIl);
        "".length();
        if (null == null) {}
      }
      else if ((llIIIIlllIIIII(llllllllllllllIllIIIIlIIIIlIIIll.isRecipeDisabled())) && ((!llIIIIlllIIIIl(llllllllllllllIllIIIIlIIIIIlllll.isPointInRegion(lllllllIllll[12], lllllllIllll[13], lllllllIllll[15], lllllllIllll[13], llllllllllllllIllIIIIlIIIIlIlIlI, llllllllllllllIllIIIIlIIIIlIlIIl))) || (llIIIIlllIIIII(llllllllllllllIllIIIIlIIIIIlllll.isPointInRegion(lllllllIllll[12], lllllllIllll[16], lllllllIllll[15], lllllllIllll[13], llllllllllllllIllIIIIlIIIIlIlIlI, llllllllllllllIllIIIIlIIIIlIlIIl)))))
      {
        llllllllllllllIllIIIIlIIIIIlllll.drawCreativeTabHoveringText(I18n.format(lllllllIlIlI[lllllllIllll[19]], new Object[lllllllIllll[0]]), llllllllllllllIllIIIIlIIIIlIlIlI, llllllllllllllIllIIIIlIIIIlIlIIl);
      }
      GlStateManager.popMatrix();
      GlStateManager.enableLighting();
      GlStateManager.enableDepth();
      RenderHelper.enableStandardItemLighting();
    }
  }
  
  protected void drawGuiContainerBackgroundLayer(float llllllllllllllIllIIIIlIIIlIIIlIl, int llllllllllllllIllIIIIlIIIlIIIlII, int llllllllllllllIllIIIIlIIIlIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(MERCHANT_GUI_TEXTURE);
    int llllllllllllllIllIIIIlIIIlIIIIlI = (width - xSize) / lllllllIllll[1];
    int llllllllllllllIllIIIIlIIIlIIIIIl = (height - ySize) / lllllllIllll[1];
    llllllllllllllIllIIIIlIIIlIIIllI.drawTexturedModalRect(llllllllllllllIllIIIIlIIIlIIIIlI, llllllllllllllIllIIIIlIIIlIIIIIl, lllllllIllll[0], lllllllIllll[0], xSize, ySize);
    MerchantRecipeList llllllllllllllIllIIIIlIIIlIIIIII = merchant.getRecipes(mc.thePlayer);
    if ((llIIIIllIllIlI(llllllllllllllIllIIIIlIIIlIIIIII)) && (llIIIIlllIIIIl(llllllllllllllIllIIIIlIIIlIIIIII.isEmpty())))
    {
      int llllllllllllllIllIIIIlIIIIllllll = selectedMerchantRecipe;
      if ((!llIIIIlllIIIlI(llllllllllllllIllIIIIlIIIIllllll)) || (llIIIIllIllllI(llllllllllllllIllIIIIlIIIIllllll, llllllllllllllIllIIIIlIIIlIIIIII.size()))) {
        return;
      }
      MerchantRecipe llllllllllllllIllIIIIlIIIIlllllI = (MerchantRecipe)llllllllllllllIllIIIIlIIIlIIIIII.get(llllllllllllllIllIIIIlIIIIllllll);
      if (llIIIIlllIIIII(llllllllllllllIllIIIIlIIIIlllllI.isRecipeDisabled()))
      {
        mc.getTextureManager().bindTexture(MERCHANT_GUI_TEXTURE);
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.disableLighting();
        llllllllllllllIllIIIIlIIIlIIIllI.drawTexturedModalRect(guiLeft + lllllllIllll[12], guiTop + lllllllIllll[13], lllllllIllll[14], lllllllIllll[0], lllllllIllll[15], lllllllIllll[13]);
        llllllllllllllIllIIIIlIIIlIIIllI.drawTexturedModalRect(guiLeft + lllllllIllll[12], guiTop + lllllllIllll[16], lllllllIllll[14], lllllllIllll[0], lllllllIllll[15], lllllllIllll[13]);
      }
    }
  }
  
  public IMerchant getMerchant()
  {
    ;
    return merchant;
  }
  
  private static boolean llIIIIllIllllI(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIllIIIIIllllIllIll;
    return ??? >= i;
  }
  
  private static String llIIIIllIlIIIl(String llllllllllllllIllIIIIlIIIIIIIllI, String llllllllllllllIllIIIIlIIIIIIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIIIlIIIIIIIllI = new String(Base64.getDecoder().decode(llllllllllllllIllIIIIlIIIIIIIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIIIIlIIIIIIIlII = new StringBuilder();
    char[] llllllllllllllIllIIIIlIIIIIIIIll = llllllllllllllIllIIIIlIIIIIIIlIl.toCharArray();
    int llllllllllllllIllIIIIlIIIIIIIIlI = lllllllIllll[0];
    Exception llllllllllllllIllIIIIIllllllllII = llllllllllllllIllIIIIlIIIIIIIllI.toCharArray();
    byte llllllllllllllIllIIIIIlllllllIll = llllllllllllllIllIIIIIllllllllII.length;
    short llllllllllllllIllIIIIIlllllllIlI = lllllllIllll[0];
    while (llIIIIllIllIll(llllllllllllllIllIIIIIlllllllIlI, llllllllllllllIllIIIIIlllllllIll))
    {
      char llllllllllllllIllIIIIlIIIIIIIlll = llllllllllllllIllIIIIIllllllllII[llllllllllllllIllIIIIIlllllllIlI];
      "".length();
      "".length();
      if (-" ".length() > ((0x7E ^ 0x59) & (0x67 ^ 0x40 ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIIIIlIIIIIIIlII);
  }
  
  private static boolean llIIIIllIlllIl(Object ???, Object arg1)
  {
    Object localObject;
    String llllllllllllllIllIIIIIllllIlIIIl;
    return ??? == localObject;
  }
  
  private static boolean llIIIIlllIIIIl(int ???)
  {
    double llllllllllllllIllIIIIIllllIIllIl;
    return ??? == 0;
  }
  
  private static boolean llIIIIllIlllII(int ???)
  {
    double llllllllllllllIllIIIIIllllIIIlll;
    return ??? > 0;
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIllIIIIlIIIlIIllll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    boolean llllllllllllllIllIIIIlIIIlIlIIll = lllllllIllll[0];
    if (llIIIIllIlllIl(llllllllllllllIllIIIIlIIIlIIllll, nextButton))
    {
      selectedMerchantRecipe += lllllllIllll[2];
      MerchantRecipeList llllllllllllllIllIIIIlIIIlIlIIlI = merchant.getRecipes(mc.thePlayer);
      if ((llIIIIllIllIlI(llllllllllllllIllIIIIlIIIlIlIIlI)) && (llIIIIllIllllI(selectedMerchantRecipe, llllllllllllllIllIIIIlIIIlIlIIlI.size()))) {
        selectedMerchantRecipe = (llllllllllllllIllIIIIlIIIlIlIIlI.size() - lllllllIllll[2]);
      }
      llllllllllllllIllIIIIlIIIlIlIIll = lllllllIllll[2];
      "".length();
      if (-" ".length() <= 0) {}
    }
    else if (llIIIIllIlllIl(llllllllllllllIllIIIIlIIIlIIllll, previousButton))
    {
      selectedMerchantRecipe -= lllllllIllll[2];
      if (llIIIIllIlllll(selectedMerchantRecipe)) {
        selectedMerchantRecipe = lllllllIllll[0];
      }
      llllllllllllllIllIIIIlIIIlIlIIll = lllllllIllll[2];
    }
    if (llIIIIlllIIIII(llllllllllllllIllIIIIlIIIlIlIIll))
    {
      ((ContainerMerchant)inventorySlots).setCurrentRecipeIndex(selectedMerchantRecipe);
      PacketBuffer llllllllllllllIllIIIIlIIIlIlIIIl = new PacketBuffer(Unpooled.buffer());
      "".length();
      mc.getNetHandler().addToSendQueue(new C17PacketCustomPayload(lllllllIlIlI[lllllllIllll[1]], llllllllllllllIllIIIIlIIIlIlIIIl));
    }
  }
  
  private static boolean llIIIIllIllIll(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIllIIIIIllllIlIlll;
    return ??? < i;
  }
  
  static class MerchantButton
    extends GuiButton
  {
    private static boolean llIIIlIIIllI(int ???, int arg1)
    {
      int i;
      int llllllllllllllllllIIlIIIIIlIllII;
      return ??? < i;
    }
    
    public MerchantButton(int llllllllllllllllllIIlIIIIllIIlll, int llllllllllllllllllIIlIIIIllIIIIl, int llllllllllllllllllIIlIIIIllIIIII, boolean llllllllllllllllllIIlIIIIllIIlII)
    {
      llllllllllllllllllIIlIIIIllIIIll.<init>(llllllllllllllllllIIlIIIIllIIlll, llllllllllllllllllIIlIIIIllIIllI, llllllllllllllllllIIlIIIIllIIIII, llllIllIlI[0], llllIllIlI[1], llllIllIIl[llllIllIlI[2]]);
      field_146157_o = llllllllllllllllllIIlIIIIllIIlII;
    }
    
    static
    {
      llIIIlIIIIll();
      llIIIlIIIIlI();
    }
    
    private static String llIIIlIIIIII(String llllllllllllllllllIIlIIIIIllllII, String llllllllllllllllllIIlIIIIIlllIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllllllIIlIIIIlIIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIIlIIIIIlllIlI.getBytes(StandardCharsets.UTF_8)), llllIllIlI[6]), "DES");
        Cipher llllllllllllllllllIIlIIIIlIIIIII = Cipher.getInstance("DES");
        llllllllllllllllllIIlIIIIlIIIIII.init(llllIllIlI[5], llllllllllllllllllIIlIIIIlIIIIIl);
        return new String(llllllllllllllllllIIlIIIIlIIIIII.doFinal(Base64.getDecoder().decode(llllllllllllllllllIIlIIIIIllllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllllllIIlIIIIIlllllI)
      {
        llllllllllllllllllIIlIIIIIlllllI.printStackTrace();
      }
      return null;
    }
    
    private static void llIIIlIIIIll()
    {
      llllIllIlI = new int[7];
      llllIllIlI[0] = (0x90 ^ 0x9C);
      llllIllIlI[1] = (0x78 ^ 0x45 ^ 0x75 ^ 0x5B);
      llllIllIlI[2] = ((0x5C ^ 0x41) & (0x46 ^ 0x5B ^ 0xFFFFFFFF));
      llllIllIlI[3] = " ".length();
      llllIllIlI[4] = (67 + 117 - 19 + 11);
      llllIllIlI[5] = "  ".length();
      llllIllIlI[6] = (0x4B ^ 0x43 ^ (0xB4 ^ 0xBA) & (0xB5 ^ 0xBB ^ 0xFFFFFFFF));
    }
    
    private static boolean llIIIlIIIlIl(int ???, int arg1)
    {
      int i;
      long llllllllllllllllllIIlIIIIIllIIII;
      return ??? >= i;
    }
    
    public void drawButton(Minecraft llllllllllllllllllIIlIIIIlIIllll, int llllllllllllllllllIIlIIIIlIlIlIl, int llllllllllllllllllIIlIIIIlIIllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      if (llIIIlIIIlII(visible))
      {
        llllllllllllllllllIIlIIIIlIIllll.getTextureManager().bindTexture(GuiMerchant.MERCHANT_GUI_TEXTURE);
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        if ((llIIIlIIIlIl(llllllllllllllllllIIlIIIIlIlIlIl, xPosition)) && (llIIIlIIIlIl(llllllllllllllllllIIlIIIIlIIllIl, yPosition)) && (llIIIlIIIllI(llllllllllllllllllIIlIIIIlIlIlIl, xPosition + width)) && (llIIIlIIIllI(llllllllllllllllllIIlIIIIlIIllIl, yPosition + height)))
        {
          "".length();
          if (null == null) {
            break label102;
          }
        }
        label102:
        boolean llllllllllllllllllIIlIIIIlIlIIll = llllIllIlI[2];
        int llllllllllllllllllIIlIIIIlIlIIlI = llllIllIlI[2];
        int llllllllllllllllllIIlIIIIlIlIIIl = llllIllIlI[4];
        if (llIIIlIIIlll(enabled))
        {
          llllllllllllllllllIIlIIIIlIlIIIl += width * llllIllIlI[5];
          "".length();
          if ((0xA0 ^ 0x87 ^ 0x1F ^ 0x3D) > 0) {}
        }
        else if (llIIIlIIIlII(llllllllllllllllllIIlIIIIlIlIIll))
        {
          llllllllllllllllllIIlIIIIlIlIIIl += width;
        }
        if (llIIIlIIIlll(field_146157_o)) {
          llllllllllllllllllIIlIIIIlIlIIlI += height;
        }
        llllllllllllllllllIIlIIIIlIlIIII.drawTexturedModalRect(xPosition, yPosition, llllllllllllllllllIIlIIIIlIlIIIl, llllllllllllllllllIIlIIIIlIlIIlI, width, height);
      }
    }
    
    private static void llIIIlIIIIlI()
    {
      llllIllIIl = new String[llllIllIlI[3]];
      llllIllIIl[llllIllIlI[2]] = llIIIlIIIIII("0TZnuwM83Hk=", "kfyoh");
    }
    
    private static boolean llIIIlIIIlll(int ???)
    {
      int llllllllllllllllllIIlIIIIIlIlIII;
      return ??? == 0;
    }
    
    private static boolean llIIIlIIIlII(int ???)
    {
      int llllllllllllllllllIIlIIIIIlIlIlI;
      return ??? != 0;
    }
  }
}

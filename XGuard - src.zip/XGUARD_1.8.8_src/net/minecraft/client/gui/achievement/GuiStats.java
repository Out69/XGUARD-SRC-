package net.minecraft.client.gui.achievement;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSlot;
import net.minecraft.client.gui.IProgressMeter;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityList.EntityEggInfo;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.network.play.client.C16PacketClientStatus.EnumState;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatCrafting;
import net.minecraft.stats.StatFileWriter;
import net.minecraft.stats.StatList;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;

public class GuiStats
  extends GuiScreen
  implements IProgressMeter
{
  private static boolean lIlllIIlIIlIll(Object ???)
  {
    String llllllllllllllIllIlIlIllllIlIlll;
    return ??? != null;
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIllIlIllIIIlllllll)
    throws IOException
  {
    ;
    ;
    if (lIlllIIlIIlllI(enabled)) {
      if (lIlllIIlIIllIl(id))
      {
        mc.displayGuiScreen(parentScreen);
        "".length();
        if (((104 + 93 - 96 + 50 ^ 97 + 65 - 30 + 3) & (42 + 94 - 118 + 118 ^ 34 + '' - 137 + 111 ^ -" ".length())) >= 0) {}
      }
      else if (lIlllIIlIlIIII(id, llllIIllIIll[1]))
      {
        displaySlot = generalStats;
        "".length();
        if ((0x46 ^ 0x42) > 0) {}
      }
      else if (lIlllIIlIlIIII(id, llllIIllIIll[10]))
      {
        displaySlot = itemStats;
        "".length();
        if ("   ".length() >= 0) {}
      }
      else if (lIlllIIlIlIIII(id, llllIIllIIll[2]))
      {
        displaySlot = blockStats;
        "".length();
        if (-" ".length() < 0) {}
      }
      else if (lIlllIIlIlIIII(id, llllIIllIIll[3]))
      {
        displaySlot = mobStats;
        "".length();
        if (-(0x94 ^ 0xC2 ^ 0x7B ^ 0x29) < 0) {}
      }
      else
      {
        displaySlot.actionPerformed(llllllllllllllIllIlIllIIIlllllll);
      }
    }
  }
  
  public void func_175366_f()
  {
    ;
    generalStats = new StatsGeneral(mc);
    generalStats.registerScrollButtons(llllIIllIIll[1], llllIIllIIll[1]);
    itemStats = new StatsItem(mc);
    itemStats.registerScrollButtons(llllIIllIIll[1], llllIIllIIll[1]);
    blockStats = new StatsBlock(mc);
    blockStats.registerScrollButtons(llllIIllIIll[1], llllIIllIIll[1]);
    mobStats = new StatsMobsList(mc);
    mobStats.registerScrollButtons(llllIIllIIll[1], llllIIllIIll[1]);
  }
  
  private void drawStatsScreen(int llllllllllllllIllIlIllIIIllIIIll, int llllllllllllllIllIlIllIIIllIIIlI, Item llllllllllllllIllIlIllIIIllIIIIl)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIllIlIllIIIllIIlII.drawButtonBackground(llllllllllllllIllIlIllIIIllIIIll + llllIIllIIll[1], llllllllllllllIllIlIllIIIllIIIlI + llllIIllIIll[1]);
    GlStateManager.enableRescaleNormal();
    RenderHelper.enableGUIStandardItemLighting();
    itemRender.renderItemIntoGUI(new ItemStack(llllllllllllllIllIlIllIIIllIIIIl, llllIIllIIll[1], llllIIllIIll[0]), llllllllllllllIllIlIllIIIllIIIll + llllIIllIIll[2], llllllllllllllIllIlIllIIIllIIIlI + llllIIllIIll[2]);
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
  }
  
  public boolean doesGuiPauseGame()
  {
    ;
    if (lIlllIIlIIlllI(doesGuiPauseGame))
    {
      "".length();
      if (null == null) {
        break label75;
      }
      return (0xDF ^ 0x88 ^ 0x4 ^ 0x46) & (61 + 102 - 160 + 126 ^ 124 + 11 - 22 + 35 ^ -" ".length());
    }
    label75:
    return llllIIllIIll[1];
  }
  
  private static void lIlllIIlIIIlIl()
  {
    llllIIlIllll = new String[llllIIllIIll[16]];
    llllIIlIllll[llllIIllIIll[0]] = lIlllIIlIIIIlI("szlUTd8AIBSDzdV9iOhSMg==", "RAhQh");
    llllIIlIllll[llllIIllIIll[1]] = lIlllIIlIIIIll("MKHCtBMZhmfEXkHIc9bAgQ==", "lTFMk");
    llllIIlIllll[llllIIllIIll[2]] = lIlllIIlIIIIll("z6LkXd/5FIK8mmzHpF//qw==", "kzkBL");
    llllIIlIllll[llllIIllIIll[10]] = lIlllIIlIIIlII("CSANImodMQIzNhs4LiMwDjsC", "zTlVD");
    llllIIlIllll[llllIIllIIll[3]] = lIlllIIlIIIIlI("ZRdoYhW9/dTz2L+h06kSjI1wK0tFcGzQ", "ZNgJm");
    llllIIlIllll[llllIIllIIll[11]] = lIlllIIlIIIIlI("GqNep602zr0gXDNoFzK0UF7/XaMefd52", "QPcXf");
    llllIIlIllll[llllIIllIIll[12]] = lIlllIIlIIIlII("ARo4GHsfATsfFwcaLQM7", "rnYlU");
    llllIIlIllll[llllIIllIIll[13]] = lIlllIIlIIIIll("tEZYXlK67tA17t9IRTZDy8tqG/VhUtlUMLRDN+nlgBo=", "NxuKI");
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    llllllllllllllIllIlIllIIlIIlIlII.handleMouseInput();
    if (lIlllIIlIIlIll(displaySlot)) {
      displaySlot.handleMouseInput();
    }
  }
  
  private void drawSprite(int llllllllllllllIllIlIllIIIlIIIIII, int llllllllllllllIllIlIllIIIlIIlIlI, int llllllllllllllIllIlIllIIIlIIlIIl, int llllllllllllllIllIlIllIIIIllllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(statIcons);
    float llllllllllllllIllIlIllIIIlIIIlll = 0.0078125F;
    float llllllllllllllIllIlIllIIIlIIIllI = 0.0078125F;
    int llllllllllllllIllIlIllIIIlIIIlIl = llllIIllIIll[15];
    int llllllllllllllIllIlIllIIIlIIIlII = llllIIllIIll[15];
    Tessellator llllllllllllllIllIlIllIIIlIIIIll = Tessellator.getInstance();
    WorldRenderer llllllllllllllIllIlIllIIIlIIIIlI = llllllllllllllIllIlIllIIIlIIIIll.getWorldRenderer();
    llllllllllllllIllIlIllIIIlIIIIlI.begin(llllIIllIIll[13], DefaultVertexFormats.POSITION_TEX);
    llllllllllllllIllIlIllIIIlIIIIlI.pos(llllllllllllllIllIlIllIIIlIIIIII + llllIIllIIll[0], llllllllllllllIllIlIllIIIIllllll + llllIIllIIll[15], zLevel).tex((llllllllllllllIllIlIllIIIlIIlIIl + llllIIllIIll[0]) * 0.0078125F, (llllllllllllllIllIlIllIIIIllllIl + llllIIllIIll[15]) * 0.0078125F).endVertex();
    llllllllllllllIllIlIllIIIlIIIIlI.pos(llllllllllllllIllIlIllIIIlIIIIII + llllIIllIIll[15], llllllllllllllIllIlIllIIIIllllll + llllIIllIIll[15], zLevel).tex((llllllllllllllIllIlIllIIIlIIlIIl + llllIIllIIll[15]) * 0.0078125F, (llllllllllllllIllIlIllIIIIllllIl + llllIIllIIll[15]) * 0.0078125F).endVertex();
    llllllllllllllIllIlIllIIIlIIIIlI.pos(llllllllllllllIllIlIllIIIlIIIIII + llllIIllIIll[15], llllllllllllllIllIlIllIIIIllllll + llllIIllIIll[0], zLevel).tex((llllllllllllllIllIlIllIIIlIIlIIl + llllIIllIIll[15]) * 0.0078125F, (llllllllllllllIllIlIllIIIIllllIl + llllIIllIIll[0]) * 0.0078125F).endVertex();
    llllllllllllllIllIlIllIIIlIIIIlI.pos(llllllllllllllIllIlIllIIIlIIIIII + llllIIllIIll[0], llllllllllllllIllIlIllIIIIllllll + llllIIllIIll[0], zLevel).tex((llllllllllllllIllIlIllIIIlIIlIIl + llllIIllIIll[0]) * 0.0078125F, (llllllllllllllIllIlIllIIIIllllIl + llllIIllIIll[0]) * 0.0078125F).endVertex();
    llllllllllllllIllIlIllIIIlIIIIll.draw();
  }
  
  private static void lIlllIIlIIlIlI()
  {
    llllIIllIIll = new int[17];
    llllIIllIIll[0] = ((0xE ^ 0x26) & (0xAA ^ 0x82 ^ 0xFFFFFFFF));
    llllIIllIIll[1] = " ".length();
    llllIIllIIll[2] = "  ".length();
    llllIIllIIll[3] = ('' + 1 - 30 + 74 ^ 82 + '' - 78 + 49);
    llllIIllIIll[4] = (0xB0 ^ 0xAC);
    llllIIllIIll[5] = (93 + 63 - 90 + 84);
    llllIIllIIll[6] = (0x6F ^ 0x7B);
    llllIIllIIll[7] = ('' + 57 - 196 + 140);
    llllIIllIIll[8] = (0x8B ^ 0xBF);
    llllIIllIIll[9] = (0xDC ^ 0x94 ^ 0x80 ^ 0x98);
    llllIIllIIll[10] = "   ".length();
    llllIIllIIll[11] = (0x6A ^ 0x59 ^ 0x2A ^ 0x1C);
    llllIIllIIll[12] = (0x7B ^ 0x30 ^ 0x72 ^ 0x3F);
    llllIIllIIll[13] = (0xAF ^ 0xA8 ^ (0xA0 ^ 0xAD) & (0xBB ^ 0xB6 ^ 0xFFFFFFFF));
    llllIIllIIll[14] = (0xFFFFFFFF & 0xFFFFFF);
    llllIIllIIll[15] = (0x1C ^ 0xE);
    llllIIllIIll[16] = (0x1A ^ 0x12);
  }
  
  private static boolean lIlllIIlIlIIIl(int ???, int arg1)
  {
    int i;
    float llllllllllllllIllIlIlIllllIllIIl;
    return ??? < i;
  }
  
  public GuiStats(GuiScreen llllllllllllllIllIlIllIIlIIllllI, StatFileWriter llllllllllllllIllIlIllIIlIIlllIl)
  {
    parentScreen = llllllllllllllIllIlIllIIlIIllIll;
    field_146546_t = llllllllllllllIllIlIllIIlIIlllIl;
  }
  
  private static boolean lIlllIIlIIllIl(int ???)
  {
    long llllllllllllllIllIlIlIllllIlIIll;
    return ??? == 0;
  }
  
  private static String lIlllIIlIIIIlI(String llllllllllllllIllIlIlIlllllIIllI, String llllllllllllllIllIlIlIlllllIIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIlIlIlllllIlIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIlIlllllIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIlIlIlllllIlIII = Cipher.getInstance("Blowfish");
      llllllllllllllIllIlIlIlllllIlIII.init(llllIIllIIll[2], llllllllllllllIllIlIlIlllllIlIIl);
      return new String(llllllllllllllIllIlIlIlllllIlIII.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIlIlllllIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIlIlIlllllIIlll)
    {
      llllllllllllllIllIlIlIlllllIIlll.printStackTrace();
    }
    return null;
  }
  
  public void drawScreen(int llllllllllllllIllIlIllIIIlllIlIl, int llllllllllllllIllIlIllIIIlllIlII, float llllllllllllllIllIlIllIIIlllIIll)
  {
    ;
    ;
    ;
    ;
    if (lIlllIIlIIlllI(doesGuiPauseGame))
    {
      llllllllllllllIllIlIllIIIlllIllI.drawDefaultBackground();
      llllllllllllllIllIlIllIIIlllIllI.drawCenteredString(fontRendererObj, I18n.format(llllIIlIllll[llllIIllIIll[13]], new Object[llllIIllIIll[0]]), width / llllIIllIIll[2], height / llllIIllIIll[2], llllIIllIIll[14]);
      llllllllllllllIllIlIllIIIlllIllI.drawCenteredString(fontRendererObj, lanSearchStates[((int)(Minecraft.getSystemTime() / 150L % lanSearchStates.length))], width / llllIIllIIll[2], height / llllIIllIIll[2] + fontRendererObj.FONT_HEIGHT * llllIIllIIll[2], llllIIllIIll[14]);
      "".length();
      if (-" ".length() < " ".length()) {}
    }
    else
    {
      displaySlot.drawScreen(llllllllllllllIllIlIllIIIlllIlIl, llllllllllllllIllIlIllIIIlllIlII, llllllllllllllIllIlIllIIIlllIIll);
      llllllllllllllIllIlIllIIIlllIllI.drawCenteredString(fontRendererObj, screenTitle, width / llllIIllIIll[2], llllIIllIIll[6], llllIIllIIll[14]);
      llllllllllllllIllIlIllIIIlllIllI.drawScreen(llllllllllllllIllIlIllIIIlllIlIl, llllllllllllllIllIlIllIIIlllIlII, llllllllllllllIllIlIllIIIlllIIll);
    }
  }
  
  public void createButtons()
  {
    ;
    ;
    ;
    ;
    new GuiButton(llllIIllIIll[0], width / llllIIllIIll[2] + llllIIllIIll[3], height - llllIIllIIll[4], llllIIllIIll[5], llllIIllIIll[6], I18n.format(llllIIlIllll[llllIIllIIll[2]], new Object[llllIIllIIll[0]]));
    "".length();
    new GuiButton(llllIIllIIll[1], width / llllIIllIIll[2] - llllIIllIIll[7], height - llllIIllIIll[8], llllIIllIIll[9], llllIIllIIll[6], I18n.format(llllIIlIllll[llllIIllIIll[10]], new Object[llllIIllIIll[0]]));
    "".length();
    GuiButton llllllllllllllIllIlIllIIlIIIlIll = new GuiButton(llllIIllIIll[2], width / llllIIllIIll[2] - llllIIllIIll[9], height - llllIIllIIll[8], llllIIllIIll[9], llllIIllIIll[6], I18n.format(llllIIlIllll[llllIIllIIll[3]], new Object[llllIIllIIll[0]]));
    "".length();
    GuiButton llllllllllllllIllIlIllIIlIIIlIlI = new GuiButton(llllIIllIIll[10], width / llllIIllIIll[2], height - llllIIllIIll[8], llllIIllIIll[9], llllIIllIIll[6], I18n.format(llllIIlIllll[llllIIllIIll[11]], new Object[llllIIllIIll[0]]));
    "".length();
    GuiButton llllllllllllllIllIlIllIIlIIIlIIl = new GuiButton(llllIIllIIll[3], width / llllIIllIIll[2] + llllIIllIIll[9], height - llllIIllIIll[8], llllIIllIIll[9], llllIIllIIll[6], I18n.format(llllIIlIllll[llllIIllIIll[12]], new Object[llllIIllIIll[0]]));
    "".length();
    if (lIlllIIlIIllIl(blockStats.getSize())) {
      enabled = llllIIllIIll[0];
    }
    if (lIlllIIlIIllIl(itemStats.getSize())) {
      enabled = llllIIllIIll[0];
    }
    if (lIlllIIlIIllIl(mobStats.getSize())) {
      enabled = llllIIllIIll[0];
    }
  }
  
  private static boolean lIlllIIlIIlllI(int ???)
  {
    String llllllllllllllIllIlIlIllllIlIlIl;
    return ??? != 0;
  }
  
  private static String lIlllIIlIIIIll(String llllllllllllllIllIlIlIllllllIIIl, String llllllllllllllIllIlIlIllllllIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIlIlIllllllIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIlIllllllIIII.getBytes(StandardCharsets.UTF_8)), llllIIllIIll[16]), "DES");
      Cipher llllllllllllllIllIlIlIllllllIlIl = Cipher.getInstance("DES");
      llllllllllllllIllIlIlIllllllIlIl.init(llllIIllIIll[2], llllllllllllllIllIlIlIllllllIllI);
      return new String(llllllllllllllIllIlIlIllllllIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIlIllllllIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIlIlIllllllIlII)
    {
      llllllllllllllIllIlIlIllllllIlII.printStackTrace();
    }
    return null;
  }
  
  private static String lIlllIIlIIIlII(String llllllllllllllIllIlIllIIIIIIIIll, String llllllllllllllIllIlIllIIIIIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIlIllIIIIIIIIll = new String(Base64.getDecoder().decode(llllllllllllllIllIlIllIIIIIIIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIlIllIIIIIIIllI = new StringBuilder();
    char[] llllllllllllllIllIlIllIIIIIIIlIl = llllllllllllllIllIlIllIIIIIIIIlI.toCharArray();
    int llllllllllllllIllIlIllIIIIIIIlII = llllIIllIIll[0];
    double llllllllllllllIllIlIlIlllllllllI = llllllllllllllIllIlIllIIIIIIIIll.toCharArray();
    long llllllllllllllIllIlIlIllllllllIl = llllllllllllllIllIlIlIlllllllllI.length;
    char llllllllllllllIllIlIlIllllllllII = llllIIllIIll[0];
    while (lIlllIIlIlIIIl(llllllllllllllIllIlIlIllllllllII, llllllllllllllIllIlIlIllllllllIl))
    {
      char llllllllllllllIllIlIllIIIIIIlIIl = llllllllllllllIllIlIlIlllllllllI[llllllllllllllIllIlIlIllllllllII];
      "".length();
      "".length();
      if ((18 + 17 - -69 + 38 ^ '' + 33 - 92 + 61) <= 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIlIllIIIIIIIllI);
  }
  
  static
  {
    lIlllIIlIIlIlI();
    lIlllIIlIIIlIl();
  }
  
  private void drawButtonBackground(int llllllllllllllIllIlIllIIIlIllIIl, int llllllllllllllIllIlIllIIIlIllIll)
  {
    ;
    ;
    ;
    llllllllllllllIllIlIllIIIlIlllIl.drawSprite(llllllllllllllIllIlIllIIIlIlllII, llllllllllllllIllIlIllIIIlIllIll, llllIIllIIll[0], llllIIllIIll[0]);
  }
  
  public void doneLoading()
  {
    ;
    if (lIlllIIlIIlllI(doesGuiPauseGame))
    {
      llllllllllllllIllIlIllIIIlllIIII.func_175366_f();
      llllllllllllllIllIlIllIIIlllIIII.createButtons();
      displaySlot = generalStats;
      doesGuiPauseGame = llllIIllIIll[0];
    }
  }
  
  public void initGui()
  {
    ;
    screenTitle = I18n.format(llllIIlIllll[llllIIllIIll[1]], new Object[llllIIllIIll[0]]);
    doesGuiPauseGame = llllIIllIIll[1];
    mc.getNetHandler().addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.REQUEST_STATS));
  }
  
  private static boolean lIlllIIlIlIIII(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIllIlIlIllllIlllIl;
    return ??? == i;
  }
  
  class StatsBlock
    extends GuiStats.Stats
  {
    protected void drawListHeader(int llllllllllllllIllIlllllllllIlllI, int llllllllllllllIllIlllllllllIllIl, Tessellator llllllllllllllIllIlllllllllIlIII)
    {
      ;
      ;
      ;
      ;
      llllllllllllllIllIlllllllllIllll.drawListHeader(llllllllllllllIllIlllllllllIlllI, llllllllllllllIllIlllllllllIllIl, llllllllllllllIllIlllllllllIlIII);
      if (lIllIIllllIlll(field_148218_l))
      {
        GuiStats.this.drawSprite(llllllllllllllIllIlllllllllIlllI + lllIlIllIIll[2] - lllIlIllIIll[3] + lllIlIllIIll[1], llllllllllllllIllIlllllllllIllIl + lllIlIllIIll[1] + lllIlIllIIll[1], lllIlIllIIll[3], lllIlIllIIll[3]);
        "".length();
        if (null == null) {}
      }
      else
      {
        GuiStats.this.drawSprite(llllllllllllllIllIlllllllllIlllI + lllIlIllIIll[2] - lllIlIllIIll[3], llllllllllllllIllIlllllllllIllIl + lllIlIllIIll[1], lllIlIllIIll[3], lllIlIllIIll[3]);
      }
      if (lIllIIlllllIII(field_148218_l, lllIlIllIIll[1]))
      {
        GuiStats.this.drawSprite(llllllllllllllIllIlllllllllIlllI + lllIlIllIIll[4] - lllIlIllIIll[3] + lllIlIllIIll[1], llllllllllllllIllIlllllllllIllIl + lllIlIllIIll[1] + lllIlIllIIll[1], lllIlIllIIll[5], lllIlIllIIll[3]);
        "".length();
        if (" ".length() >= " ".length()) {}
      }
      else
      {
        GuiStats.this.drawSprite(llllllllllllllIllIlllllllllIlllI + lllIlIllIIll[4] - lllIlIllIIll[3], llllllllllllllIllIlllllllllIllIl + lllIlIllIIll[1], lllIlIllIIll[5], lllIlIllIIll[3]);
      }
      if (lIllIIlllllIII(field_148218_l, lllIlIllIIll[6]))
      {
        GuiStats.this.drawSprite(llllllllllllllIllIlllllllllIlllI + lllIlIllIIll[7] - lllIlIllIIll[3] + lllIlIllIIll[1], llllllllllllllIllIlllllllllIllIl + lllIlIllIIll[1] + lllIlIllIIll[1], lllIlIllIIll[8], lllIlIllIIll[3]);
        "".length();
        if (-" ".length() <= 0) {}
      }
      else
      {
        GuiStats.this.drawSprite(llllllllllllllIllIlllllllllIlllI + lllIlIllIIll[7] - lllIlIllIIll[3], llllllllllllllIllIlllllllllIllIl + lllIlIllIIll[1], lllIlIllIIll[8], lllIlIllIIll[3]);
      }
    }
    
    private static boolean lIllIIllllIllI(int ???)
    {
      Exception llllllllllllllIllIlllllllIlIlIII;
      return ??? != 0;
    }
    
    private static void lIllIIllllIIll()
    {
      lllIlIllIIll = new int[12];
      lllIlIllIIll[0] = ((0x54 ^ 0x70 ^ 0xBC ^ 0xB2) & (0xAB ^ 0x96 ^ 0x10 ^ 0x7 ^ -" ".length()));
      lllIlIllIIll[1] = " ".length();
      lllIlIllIIll[2] = (0x8 ^ 0x7B);
      lllIlIllIIll[3] = (0xE6 ^ 0xB3 ^ 0x55 ^ 0x12);
      lllIlIllIIll[4] = (66 + '' - 160 + 120);
      lllIlIllIIll[5] = (0x42 ^ 0x66);
      lllIlIllIIll[6] = "  ".length();
      lllIlIllIIll[7] = ((0x69 ^ 0x19) + (0x63 ^ 0x6B) - (0x75 ^ 0x2D) + (45 + '¢' - 79 + 55));
      lllIlIllIIll[8] = (26 + '' - 71 + 48 ^ 37 + 108 - 140 + 159);
      lllIlIllIIll[9] = (0x7F ^ 0x57);
      lllIlIllIIll[10] = "   ".length();
      lllIlIllIIll[11] = (0x54 ^ 0x5C);
    }
    
    private static boolean lIllIIlllllIII(int ???, int arg1)
    {
      int i;
      Exception llllllllllllllIllIlllllllIlIllII;
      return ??? == i;
    }
    
    private static boolean lIllIIllllIlll(int ???)
    {
      boolean llllllllllllllIllIlllllllIlIIllI;
      return ??? == 0;
    }
    
    protected void drawSlot(int llllllllllllllIllIllllllllIlllll, int llllllllllllllIllIllllllllIllllI, int llllllllllllllIllIllllllllIlIIll, int llllllllllllllIllIllllllllIlllII, int llllllllllllllIllIllllllllIllIll, int llllllllllllllIllIllllllllIllIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      StatCrafting llllllllllllllIllIllllllllIllIIl = llllllllllllllIllIlllllllllIIIII.func_148211_c(llllllllllllllIllIllllllllIlllll);
      Item llllllllllllllIllIllllllllIllIII = llllllllllllllIllIllllllllIllIIl.func_150959_a();
      GuiStats.this.drawStatsScreen(llllllllllllllIllIllllllllIllllI + lllIlIllIIll[9], llllllllllllllIllIllllllllIlllIl, llllllllllllllIllIllllllllIllIII);
      int llllllllllllllIllIllllllllIlIlll = Item.getIdFromItem(llllllllllllllIllIllllllllIllIII);
      if (lIllIIllllIlll(llllllllllllllIllIllllllllIlllll % lllIlIllIIll[6]))
      {
        "".length();
        if (-(106 + 110 - 120 + 36 ^ 44 + 60 - 86 + 110) <= 0) {
          break label112;
        }
      }
      label112:
      StatList.objectCraftStats[llllllllllllllIllIllllllllIlIlll].func_148209_a(llllllllllllllIllIllllllllIllllI + lllIlIllIIll[2], llllllllllllllIllIllllllllIlllIl, lllIlIllIIll[1], lllIlIllIIll[0]);
      if (lIllIIllllIlll(llllllllllllllIllIllllllllIlllll % lllIlIllIIll[6]))
      {
        "".length();
        if (-" ".length() >= -" ".length()) {
          break label176;
        }
      }
      label176:
      StatList.objectUseStats[llllllllllllllIllIllllllllIlIlll].func_148209_a(llllllllllllllIllIllllllllIllllI + lllIlIllIIll[4], llllllllllllllIllIllllllllIlllIl, lllIlIllIIll[1], lllIlIllIIll[0]);
      if (lIllIIllllIlll(llllllllllllllIllIllllllllIlllll % lllIlIllIIll[6]))
      {
        "".length();
        if ("  ".length() != (0x68 ^ 0x26 ^ 0xE7 ^ 0xAD)) {
          break label243;
        }
      }
      label243:
      llllllllllllllIllIllllllllIllIIl.func_148209_a(llllllllllllllIllIllllllllIllllI + lllIlIllIIll[7], llllllllllllllIllIllllllllIlllIl, lllIlIllIIll[1], lllIlIllIIll[0]);
    }
    
    private static boolean lIllIIllllIlIl(Object ???)
    {
      byte llllllllllllllIllIlllllllIlIlIlI;
      return ??? != null;
    }
    
    private static String lIllIIlllIlllI(String llllllllllllllIllIllllllllIIIIlI, String llllllllllllllIllIlllllllIllllll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIllIllllllllIIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlllllllIllllll.getBytes(StandardCharsets.UTF_8)), lllIlIllIIll[11]), "DES");
        Cipher llllllllllllllIllIllllllllIIIlII = Cipher.getInstance("DES");
        llllllllllllllIllIllllllllIIIlII.init(lllIlIllIIll[6], llllllllllllllIllIllllllllIIIlIl);
        return new String(llllllllllllllIllIllllllllIIIlII.doFinal(Base64.getDecoder().decode(llllllllllllllIllIllllllllIIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIllIllllllllIIIIll)
      {
        llllllllllllllIllIllllllllIIIIll.printStackTrace();
      }
      return null;
    }
    
    public StatsBlock(Minecraft llllllllllllllIllIlllllllllllIII)
    {
      llllllllllllllIllIllllllllllllll.<init>(GuiStats.this, llllllllllllllIllIlllllllllllIII);
      statsHolder = Lists.newArrayList();
      byte llllllllllllllIllIllllllllllIllI = StatList.objectMineStats.iterator();
      "".length();
      if ("  ".length() < 0) {
        throw null;
      }
      while (!lIllIIllllIlll(llllllllllllllIllIllllllllllIllI.hasNext()))
      {
        StatCrafting llllllllllllllIllIllllllllllllIl = (StatCrafting)llllllllllllllIllIllllllllllIllI.next();
        boolean llllllllllllllIllIllllllllllllII = lllIlIllIIll[0];
        int llllllllllllllIllIlllllllllllIll = Item.getIdFromItem(llllllllllllllIllIllllllllllllIl.func_150959_a());
        if (lIllIIllllIlII(field_146546_t.readStat(llllllllllllllIllIllllllllllllIl)))
        {
          llllllllllllllIllIllllllllllllII = lllIlIllIIll[1];
          "".length();
          if ("  ".length() >= "   ".length()) {
            throw null;
          }
        }
        else if ((lIllIIllllIlIl(StatList.objectUseStats[llllllllllllllIllIlllllllllllIll])) && (lIllIIllllIlII(field_146546_t.readStat(StatList.objectUseStats[llllllllllllllIllIlllllllllllIll]))))
        {
          llllllllllllllIllIllllllllllllII = lllIlIllIIll[1];
          "".length();
          if ((0x30 ^ 0x34) < 0) {
            throw null;
          }
        }
        else if ((lIllIIllllIlIl(StatList.objectCraftStats[llllllllllllllIllIlllllllllllIll])) && (lIllIIllllIlII(field_146546_t.readStat(StatList.objectCraftStats[llllllllllllllIllIlllllllllllIll]))))
        {
          llllllllllllllIllIllllllllllllII = lllIlIllIIll[1];
        }
        if (lIllIIllllIllI(llllllllllllllIllIllllllllllllII)) {
          "".length();
        }
      }
      statSorter = new Comparator()
      {
        public int compare(StatCrafting llllllllllllllIIllIIlIllllIlllIl, StatCrafting llllllllllllllIIllIIlIllllIlIIll)
        {
          ;
          ;
          ;
          ;
          ;
          ;
          ;
          ;
          ;
          int llllllllllllllIIllIIlIllllIllIll = Item.getIdFromItem(llllllllllllllIIllIIlIllllIlllIl.func_150959_a());
          int llllllllllllllIIllIIlIllllIllIlI = Item.getIdFromItem(llllllllllllllIIllIIlIllllIlIIll.func_150959_a());
          StatBase llllllllllllllIIllIIlIllllIllIIl = null;
          StatBase llllllllllllllIIllIIlIllllIllIII = null;
          if (lllIlllIlIlIIl(field_148217_o, lIIlllIlIIllI[0]))
          {
            llllllllllllllIIllIIlIllllIllIIl = StatList.mineBlockStatArray[llllllllllllllIIllIIlIllllIllIll];
            llllllllllllllIIllIIlIllllIllIII = StatList.mineBlockStatArray[llllllllllllllIIllIIlIllllIllIlI];
            "".length();
            if ((0x85 ^ 0x81) != (0x40 ^ 0x44)) {
              return (0xBF ^ 0xB9) & (0xBE ^ 0xB8 ^ 0xFFFFFFFF);
            }
          }
          else if (lllIlllIlIlIlI(field_148217_o))
          {
            llllllllllllllIIllIIlIllllIllIIl = StatList.objectCraftStats[llllllllllllllIIllIIlIllllIllIll];
            llllllllllllllIIllIIlIllllIllIII = StatList.objectCraftStats[llllllllllllllIIllIIlIllllIllIlI];
            "".length();
            if (null != null) {
              return (0xF9 ^ 0xB2) & (0x8D ^ 0xC6 ^ 0xFFFFFFFF);
            }
          }
          else if (lllIlllIlIlIIl(field_148217_o, lIIlllIlIIllI[1]))
          {
            llllllllllllllIIllIIlIllllIllIIl = StatList.objectUseStats[llllllllllllllIIllIIlIllllIllIll];
            llllllllllllllIIllIIlIllllIllIII = StatList.objectUseStats[llllllllllllllIIllIIlIllllIllIlI];
          }
          if ((!lllIlllIlIllII(llllllllllllllIIllIIlIllllIllIIl)) || (lllIlllIlIllIl(llllllllllllllIIllIIlIllllIllIII)))
          {
            if (lllIlllIlIllII(llllllllllllllIIllIIlIllllIllIIl)) {
              return lIIlllIlIIllI[1];
            }
            if (lllIlllIlIllII(llllllllllllllIIllIIlIllllIllIII)) {
              return lIIlllIlIIllI[2];
            }
            int llllllllllllllIIllIIlIllllIlIlll = field_146546_t.readStat(llllllllllllllIIllIIlIllllIllIIl);
            int llllllllllllllIIllIIlIllllIlIllI = field_146546_t.readStat(llllllllllllllIIllIIlIllllIllIII);
            if (lllIlllIlIlllI(llllllllllllllIIllIIlIllllIlIlll, llllllllllllllIIllIIlIllllIlIllI)) {
              return (llllllllllllllIIllIIlIllllIlIlll - llllllllllllllIIllIIlIllllIlIllI) * field_148215_p;
            }
          }
          return llllllllllllllIIllIIlIllllIllIll - llllllllllllllIIllIIlIllllIllIlI;
        }
        
        private static boolean lllIlllIlIllII(Object ???)
        {
          float llllllllllllllIIllIIlIlllIllllll;
          return ??? == null;
        }
        
        private static boolean lllIlllIlIlllI(int ???, int arg1)
        {
          int i;
          long llllllllllllllIIllIIlIlllIlllIIl;
          return ??? != i;
        }
        
        private static boolean lllIlllIlIlIIl(int ???, int arg1)
        {
          int i;
          double llllllllllllllIIllIIlIllllIIIIll;
          return ??? == i;
        }
        
        private static boolean lllIlllIlIllIl(Object ???)
        {
          float llllllllllllllIIllIIlIllllIIIIIl;
          return ??? != null;
        }
        
        private static void lllIlllIlIlIII()
        {
          lIIlllIlIIllI = new int[3];
          lIIlllIlIIllI[0] = "  ".length();
          lIIlllIlIIllI[1] = " ".length();
          lIIlllIlIIllI[2] = (-" ".length());
        }
        
        private static boolean lllIlllIlIlIlI(int ???)
        {
          float llllllllllllllIIllIIlIlllIllllIl;
          return ??? == 0;
        }
        
        static {}
      };
    }
    
    protected String func_148210_b(int llllllllllllllIllIllllllllIIllII)
    {
      ;
      if (lIllIIllllIlll(llllllllllllllIllIllllllllIIllII))
      {
        "".length();
        if (null != null) {
          return null;
        }
      }
      else if (lIllIIlllllIII(llllllllllllllIllIllllllllIIllIl, lllIlIllIIll[1]))
      {
        "".length();
        if ("  ".length() == "  ".length()) {
          break label80;
        }
        return null;
      }
      label80:
      return lllIlIlIllll[lllIlIllIIll[6]];
    }
    
    private static String lIllIIlllIlIII(String llllllllllllllIllIlllllllIllIlIl, String llllllllllllllIllIlllllllIllIIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIllIlllllllIlllIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlllllllIllIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIllIlllllllIllIlll = Cipher.getInstance("Blowfish");
        llllllllllllllIllIlllllllIllIlll.init(lllIlIllIIll[6], llllllllllllllIllIlllllllIlllIII);
        return new String(llllllllllllllIllIlllllllIllIlll.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlllllllIllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIllIlllllllIllIllI)
      {
        llllllllllllllIllIlllllllIllIllI.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIllIIllllIlII(int ???)
    {
      Exception llllllllllllllIllIlllllllIlIIlII;
      return ??? > 0;
    }
    
    static
    {
      lIllIIllllIIll();
      lIllIIlllIllll();
    }
    
    private static void lIllIIlllIllll()
    {
      lllIlIlIllll = new String[lllIlIllIIll[10]];
      lllIlIlIllll[lllIlIllIIll[0]] = lIllIIlllIlIII("kA8ESlmqHZPCst4hQymdDQ==", "WNzgA");
      lllIlIlIllll[lllIlIllIIll[1]] = lIllIIlllIlIII("RtkA7TV1iOJOWfHzBMPYPg==", "PeRxe");
      lllIlIlIllll[lllIlIllIIll[6]] = lIllIIlllIlllI("qet6mVO66/la7H6hvdd3UQ==", "UuADm");
    }
  }
  
  class StatsMobsList
    extends GuiSlot
  {
    protected void drawBackground()
    {
      ;
      drawDefaultBackground();
    }
    
    public StatsMobsList(Minecraft llllllllllllllIlIllIlIIIlIIlllll)
    {
      llllllllllllllIlIllIlIIIlIlIIIIl.<init>(llllllllllllllIlIllIlIIIlIIlllll, width, height, lIIIIIllIIIll[0], height - lIIIIIllIIIll[1], fontRendererObj.FONT_HEIGHT * lIIIIIllIIIll[2]);
      llllllllllllllIlIllIlIIIlIlIIIIl.setShowSelectionBox(lIIIIIllIIIll[3]);
      String llllllllllllllIlIllIlIIIlIIlllIl = EntityList.entityEggs.values().iterator();
      "".length();
      if (-"  ".length() > 0) {
        throw null;
      }
      while (!llIIlIIIlIlIII(llllllllllllllIlIllIlIIIlIIlllIl.hasNext()))
      {
        EntityList.EntityEggInfo llllllllllllllIlIllIlIIIlIlIIIlI = (EntityList.EntityEggInfo)llllllllllllllIlIllIlIIIlIIlllIl.next();
        if ((!llIIlIIIlIIllI(field_146546_t.readStat(field_151512_d))) || (llIIlIIIlIIlll(field_146546_t.readStat(field_151513_e)))) {
          "".length();
        }
      }
    }
    
    private static void llIIlIIIIllllI()
    {
      lIIIIIlIlllII = new String[lIIIIIllIIIll[12]];
      lIIIIIlIlllII[lIIIIIllIIIll[3]] = llIIlIIIIllIll("V02bJjq0N/o=", "rBpjn");
      lIIIIIlIlllII[lIIIIIllIIIll[4]] = llIIlIIIIlllII("7QKxiUCiP5c=", "xgYXD");
      lIIIIIlIlllII[lIIIIIllIIIll[5]] = llIIlIIIIlllIl("Nhs7LmYgAS4zPDwkMzYkNg==", "EoZZH");
      lIIIIIlIlllII[lIIIIIllIIIll[6]] = llIIlIIIIlllIl("IwIGNXQ1GBMoLik9Di02NRIlOA==", "PvgAZ");
      lIIIIIlIlllII[lIIIIIllIIIll[2]] = llIIlIIIIlllIl("KwY0E0w9HCEOFiE5PAsOK1w7CAw9", "XrUgb");
      lIIIIIlIlllII[lIIIIIllIIIll[7]] = llIIlIIIIlllIl("Ixc1FnY1DSALLCkoPQ40NQcWG3Y+DDoH", "PcTbX");
    }
    
    private static boolean llIIlIIIlIIllI(int ???)
    {
      long llllllllllllllIlIllIlIIIIIllIIlI;
      return ??? <= 0;
    }
    
    private static String llIIlIIIIlllIl(String llllllllllllllIlIllIlIIIIlIIIIlI, String llllllllllllllIlIllIlIIIIlIIIllI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIlIllIlIIIIlIIIIlI = new String(Base64.getDecoder().decode(llllllllllllllIlIllIlIIIIlIIIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIlIllIlIIIIlIIIlIl = new StringBuilder();
      char[] llllllllllllllIlIllIlIIIIlIIIlII = llllllllllllllIlIllIlIIIIlIIIllI.toCharArray();
      int llllllllllllllIlIllIlIIIIlIIIIll = lIIIIIllIIIll[3];
      long llllllllllllllIlIllIlIIIIIllllIl = llllllllllllllIlIllIlIIIIlIIIIlI.toCharArray();
      short llllllllllllllIlIllIlIIIIIllllII = llllllllllllllIlIllIlIIIIIllllIl.length;
      Exception llllllllllllllIlIllIlIIIIIlllIll = lIIIIIllIIIll[3];
      while (llIIlIIIlIlIIl(llllllllllllllIlIllIlIIIIIlllIll, llllllllllllllIlIllIlIIIIIllllII))
      {
        char llllllllllllllIlIllIlIIIIlIIlIII = llllllllllllllIlIllIlIIIIIllllIl[llllllllllllllIlIllIlIIIIIlllIll];
        "".length();
        "".length();
        if ((0xA1 ^ 0xA7 ^ "  ".length()) <= " ".length()) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIlIllIlIIIIlIIIlIl);
    }
    
    protected void elementClicked(int llllllllllllllIlIllIlIIIlIIllIII, boolean llllllllllllllIlIllIlIIIlIIlIlll, int llllllllllllllIlIllIlIIIlIIlIllI, int llllllllllllllIlIllIlIIIlIIlIlIl) {}
    
    protected boolean isSelected(int llllllllllllllIlIllIlIIIlIIlIIll)
    {
      return lIIIIIllIIIll[3];
    }
    
    private static String llIIlIIIIlllII(String llllllllllllllIlIllIlIIIIllIIIlI, String llllllllllllllIlIllIlIIIIllIIIIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIllIlIIIIllIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIllIlIIIIllIIIIl.getBytes(StandardCharsets.UTF_8)), lIIIIIllIIIll[13]), "DES");
        Cipher llllllllllllllIlIllIlIIIIllIIllI = Cipher.getInstance("DES");
        llllllllllllllIlIllIlIIIIllIIllI.init(lIIIIIllIIIll[5], llllllllllllllIlIllIlIIIIllIIlll);
        return new String(llllllllllllllIlIllIlIIIIllIIllI.doFinal(Base64.getDecoder().decode(llllllllllllllIlIllIlIIIIllIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIllIlIIIIllIIlIl)
      {
        llllllllllllllIlIllIlIIIIllIIlIl.printStackTrace();
      }
      return null;
    }
    
    protected void drawSlot(int llllllllllllllIlIllIlIIIlIIIIIIl, int llllllllllllllIlIllIlIIIIlllIIll, int llllllllllllllIlIllIlIIIIlllllll, int llllllllllllllIlIllIlIIIIllllllI, int llllllllllllllIlIllIlIIIIlllllIl, int llllllllllllllIlIllIlIIIIlllllII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      EntityList.EntityEggInfo llllllllllllllIlIllIlIIIIllllIll = (EntityList.EntityEggInfo)field_148222_l.get(llllllllllllllIlIllIlIIIlIIIIIIl);
      String llllllllllllllIlIllIlIIIIllllIlI = I18n.format(String.valueOf(new StringBuilder(lIIIIIlIlllII[lIIIIIllIIIll[3]]).append(EntityList.getStringFromID(spawnedID)).append(lIIIIIlIlllII[lIIIIIllIIIll[4]])), new Object[lIIIIIllIIIll[3]]);
      int llllllllllllllIlIllIlIIIIllllIIl = field_146546_t.readStat(field_151512_d);
      int llllllllllllllIlIllIlIIIIllllIII = field_146546_t.readStat(field_151513_e);
      String llllllllllllllIlIllIlIIIIlllIlll = I18n.format(lIIIIIlIlllII[lIIIIIllIIIll[5]], new Object[] { Integer.valueOf(llllllllllllllIlIllIlIIIIllllIIl), llllllllllllllIlIllIlIIIIllllIlI });
      String llllllllllllllIlIllIlIIIIlllIllI = I18n.format(lIIIIIlIlllII[lIIIIIllIIIll[6]], new Object[] { llllllllllllllIlIllIlIIIIllllIlI, Integer.valueOf(llllllllllllllIlIllIlIIIIllllIII) });
      if (llIIlIIIlIlIII(llllllllllllllIlIllIlIIIIllllIIl)) {
        llllllllllllllIlIllIlIIIIlllIlll = I18n.format(lIIIIIlIlllII[lIIIIIllIIIll[2]], new Object[] { llllllllllllllIlIllIlIIIIllllIlI });
      }
      if (llIIlIIIlIlIII(llllllllllllllIlIllIlIIIIllllIII)) {
        llllllllllllllIlIllIlIIIIlllIllI = I18n.format(lIIIIIlIlllII[lIIIIIllIIIll[7]], new Object[] { llllllllllllllIlIllIlIIIIllllIlI });
      }
      drawString(fontRendererObj, llllllllllllllIlIllIlIIIIllllIlI, llllllllllllllIlIllIlIIIIlllIIll + lIIIIIllIIIll[5] - lIIIIIllIIIll[8], llllllllllllllIlIllIlIIIIlllIIlI + lIIIIIllIIIll[4], lIIIIIllIIIll[9]);
      if (llIIlIIIlIlIII(llllllllllllllIlIllIlIIIIllllIIl))
      {
        "".length();
        if (((0x6D ^ 0x1A ^ 0xF9 ^ 0xA7) & (0x35 ^ 0x52 ^ 0xFE ^ 0xB0 ^ -" ".length())) == 0) {
          break label415;
        }
      }
      label415:
      fontRendererObj.drawString(llllllllllllllIlIllIlIIIIlllIlll, llllllllllllllIlIllIlIIIIlllIIll + lIIIIIllIIIll[5], llllllllllllllIlIllIlIIIIlllIIlI + lIIIIIllIIIll[4] + fontRendererObj.FONT_HEIGHT, lIIIIIllIIIll[10], lIIIIIllIIIll[11]);
      if (llIIlIIIlIlIII(llllllllllllllIlIllIlIIIIllllIII))
      {
        "".length();
        if ("  ".length() > ((0x53 ^ 0x9 ^ 0x57 ^ 0x50) & (96 + 98 - 108 + 111 ^ 84 + 48 - 91 + 111 ^ -" ".length()))) {
          break label539;
        }
      }
      label539:
      fontRendererObj.drawString(llllllllllllllIlIllIlIIIIlllIllI, llllllllllllllIlIllIlIIIIlllIIll + lIIIIIllIIIll[5], llllllllllllllIlIllIlIIIIlllIIlI + lIIIIIllIIIll[4] + fontRendererObj.FONT_HEIGHT * lIIIIIllIIIll[5], lIIIIIllIIIll[10], lIIIIIllIIIll[11]);
    }
    
    protected int getSize()
    {
      ;
      return field_148222_l.size();
    }
    
    private static void llIIlIIIlIIlIl()
    {
      lIIIIIllIIIll = new int[14];
      lIIIIIllIIIll[0] = (0x6 ^ 0x66 ^ 0x53 ^ 0x13);
      lIIIIIllIIIll[1] = (0xA7 ^ 0xBA ^ 0xF ^ 0x52);
      lIIIIIllIIIll[2] = (0xB1 ^ 0x97 ^ 0x35 ^ 0x17);
      lIIIIIllIIIll[3] = ((0xF3 ^ 0xBB ^ 0x23 ^ 0x3B) & (0x40 ^ 0x1E ^ 0xBC ^ 0xB2 ^ -" ".length()));
      lIIIIIllIIIll[4] = " ".length();
      lIIIIIllIIIll[5] = "  ".length();
      lIIIIIllIIIll[6] = "   ".length();
      lIIIIIllIIIll[7] = (0x45 ^ 0x9 ^ 0x23 ^ 0x6A);
      lIIIIIllIIIll[8] = (0x7A ^ 0x70 ^ (0xF9 ^ 0xC4) & (0x88 ^ 0xB5 ^ 0xFFFFFFFF));
      lIIIIIllIIIll[9] = (0xFFFFFFFF & 0xFFFFFF);
      lIIIIIllIIIll[10] = (0xFCE4 & 0x60637B);
      lIIIIIllIIIll[11] = (0xFABB & 0x9095D4);
      lIIIIIllIIIll[12] = ('' + 'Ã' - 219 + 80 ^ '' + 77 - 99 + 66);
      lIIIIIllIIIll[13] = (0x3E ^ 0x36);
    }
    
    private static String llIIlIIIIllIll(String llllllllllllllIlIllIlIIIIlIlIlIl, String llllllllllllllIlIllIlIIIIlIlIlII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIllIlIIIIlIllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIllIlIIIIlIlIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIlIllIlIIIIlIllIIl = Cipher.getInstance("Blowfish");
        llllllllllllllIlIllIlIIIIlIllIIl.init(lIIIIIllIIIll[5], llllllllllllllIlIllIlIIIIlIllIlI);
        return new String(llllllllllllllIlIllIlIIIIlIllIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlIllIlIIIIlIlIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIllIlIIIIlIllIII)
      {
        llllllllllllllIlIllIlIIIIlIllIII.printStackTrace();
      }
      return null;
    }
    
    static
    {
      llIIlIIIlIIlIl();
      llIIlIIIIllllI();
    }
    
    private static boolean llIIlIIIlIIlll(int ???)
    {
      char llllllllllllllIlIllIlIIIIIllIIII;
      return ??? > 0;
    }
    
    private static boolean llIIlIIIlIlIIl(int ???, int arg1)
    {
      int i;
      byte llllllllllllllIlIllIlIIIIIllIllI;
      return ??? < i;
    }
    
    private static boolean llIIlIIIlIlIII(int ???)
    {
      byte llllllllllllllIlIllIlIIIIIllIlII;
      return ??? == 0;
    }
    
    protected int getContentHeight()
    {
      ;
      return llllllllllllllIlIllIlIIIlIIlIIIl.getSize() * fontRendererObj.FONT_HEIGHT * lIIIIIllIIIll[2];
    }
  }
  
  abstract class Stats
    extends GuiSlot
  {
    private static boolean lIlIIIIIlIlI(int ???, int arg1)
    {
      int i;
      short lllllllllllllllllllIlIIIlllIlllI;
      return ??? < i;
    }
    
    protected abstract String func_148210_b(int paramInt);
    
    protected final StatCrafting func_148211_c(int lllllllllllllllllllIlIIllIIIIIlI)
    {
      ;
      ;
      return (StatCrafting)statsHolder.get(lllllllllllllllllllIlIIllIIIIIlI);
    }
    
    private static boolean lIlIIIIIlIll(int ???)
    {
      float lllllllllllllllllllIlIIIllIllllI;
      return ??? >= 0;
    }
    
    static
    {
      lIlIIIIIIlIl();
      lIIlllIIIllI();
    }
    
    private static void lIlIIIIIIlIl()
    {
      llIIlIlIlI = new int[26];
      llIIlIlIlI[0] = (0x95 ^ 0xA8 ^ 0x69 ^ 0x74);
      llIIlIlIlI[1] = (0xF ^ 0xA ^ 0xFF ^ 0xBA);
      llIIlIlIlI[2] = (0x90 ^ 0x84);
      llIIlIlIlI[3] = (-" ".length());
      llIIlIlIlI[4] = ((0x90 ^ 0xA2 ^ 0x67 ^ 0x7F) & ('' + '' - 212 + 141 ^ 3 + 39 - -86 + 65 ^ -" ".length()));
      llIIlIlIlI[5] = " ".length();
      llIIlIlIlI[6] = (0xB5 ^ 0x99 ^ 0xEA ^ 0xB5);
      llIIlIlIlI[7] = (83 + '' - 117 + 65 ^ '' + 54 - 120 + 94);
      llIIlIlIlI[8] = (91 + 1 - 2 + 75);
      llIIlIlIlI[9] = "  ".length();
      llIIlIlIlI[10] = ((0x93 ^ 0xB6) + (0x19 ^ 0x58) - -(0x74 ^ 0x26) + (0x80 ^ 0x9F));
      llIIlIlIlI[11] = (0x4C ^ 0x3);
      llIIlIlIlI[12] = ((0x85 ^ 0x93) + (0x3F ^ 0x78) - (0xFA ^ 0xB2) + (0x5F ^ 0x33));
      llIIlIlIlI[13] = ((0x3C ^ 0x73) + (0xF6 ^ 0x8C) - (54 + 114 - 133 + 114) + (91 + 115 - 118 + 39));
      llIIlIlIlI[14] = (0x53 ^ 0x77);
      llIIlIlIlI[15] = (0x28 ^ 0x2D);
      llIIlIlIlI[16] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
      llIIlIlIlI[17] = (0xF1BD & 0x909ED2);
      llIIlIlIlI[18] = (0xB4 ^ 0x9A ^ 0x50 ^ 0x22);
      llIIlIlIlI[19] = (0x0 ^ 0x10);
      llIIlIlIlI[20] = (0x37 ^ 0x1F);
      llIIlIlIlI[21] = (0x76 ^ 0x4A ^ 0x9F ^ 0xAF);
      llIIlIlIlI[22] = "   ".length();
      llIIlIlIlI[23] = (39 + '' - 183 + 169 ^ 127 + 68 - 144 + 114);
      llIIlIlIlI[24] = (-(0xD2E8 & 0x40002D17));
      llIIlIlIlI[25] = (0xFF ^ 0xB7 ^ 0x2F ^ 0x63);
    }
    
    protected void func_148212_h(int lllllllllllllllllllIlIIlIIlIllII)
    {
      ;
      ;
      if (lIlIIIIIlIII(lllllllllllllllllllIlIIlIIlIllII, field_148217_o))
      {
        field_148217_o = lllllllllllllllllllIlIIlIIlIllII;
        field_148215_p = llIIlIlIlI[3];
        "".length();
        if ((0x1C ^ 0x18) != 0) {}
      }
      else if (lIlIIIIIIlll(field_148215_p, llIIlIlIlI[3]))
      {
        field_148215_p = llIIlIlIlI[5];
        "".length();
        if ("  ".length() >= 0) {}
      }
      else
      {
        field_148217_o = llIIlIlIlI[3];
        field_148215_p = llIIlIlIlI[4];
      }
      Collections.sort(statsHolder, statSorter);
    }
    
    private static boolean lIlIIIIIllll(int ???, int arg1)
    {
      int i;
      char lllllllllllllllllllIlIIIlllIIllI;
      return ??? > i;
    }
    
    protected void elementClicked(int lllllllllllllllllllIlIIllIlIlIlI, boolean lllllllllllllllllllIlIIllIlIlIIl, int lllllllllllllllllllIlIIllIlIlIII, int lllllllllllllllllllIlIIllIlIIlll) {}
    
    private static boolean lIlIIIIIllII(Object ???)
    {
      boolean lllllllllllllllllllIlIIIlllIIlII;
      return ??? != null;
    }
    
    private static boolean lIlIIIIlIIII(int ???)
    {
      Exception lllllllllllllllllllIlIIIllIlllII;
      return ??? > 0;
    }
    
    private static boolean lIlIIIIIIlll(int ???, int arg1)
    {
      int i;
      float lllllllllllllllllllIlIIIllllIllI;
      return ??? == i;
    }
    
    private static String lIIlllIIIlII(String lllllllllllllllllllIlIIlIIlIIIlI, String lllllllllllllllllllIlIIlIIlIIIIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllllllIlIIlIIlIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIlIIlIIlIIIIl.getBytes(StandardCharsets.UTF_8)), llIIlIlIlI[23]), "DES");
        Cipher lllllllllllllllllllIlIIlIIlIIllI = Cipher.getInstance("DES");
        lllllllllllllllllllIlIIlIIlIIllI.init(llIIlIlIlI[9], lllllllllllllllllllIlIIlIIlIIlll);
        return new String(lllllllllllllllllllIlIIlIIlIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIlIIlIIlIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllllllIlIIlIIlIIlIl)
      {
        lllllllllllllllllllIlIIlIIlIIlIl.printStackTrace();
      }
      return null;
    }
    
    protected boolean isSelected(int lllllllllllllllllllIlIIllIlIIlIl)
    {
      return llIIlIlIlI[4];
    }
    
    protected void func_148213_a(StatCrafting lllllllllllllllllllIlIIlIlIIIllI, int lllllllllllllllllllIlIIlIlIIIlIl, int lllllllllllllllllllIlIIlIIlllIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      if (lIlIIIIIllII(lllllllllllllllllllIlIIlIlIIIllI))
      {
        Item lllllllllllllllllllIlIIlIlIIIIll = lllllllllllllllllllIlIIlIlIIIllI.func_150959_a();
        ItemStack lllllllllllllllllllIlIIlIlIIIIlI = new ItemStack(lllllllllllllllllllIlIIlIlIIIIll);
        String lllllllllllllllllllIlIIlIlIIIIIl = lllllllllllllllllllIlIIlIlIIIIlI.getUnlocalizedName();
        String lllllllllllllllllllIlIIlIlIIIIII = String.valueOf(new StringBuilder().append(I18n.format(String.valueOf(new StringBuilder(String.valueOf(lllllllllllllllllllIlIIlIlIIIIIl)).append(llIIIIllIl[llIIlIlIlI[22]])), new Object[llIIlIlIlI[4]]))).trim();
        if (lIlIIIIlIIII(lllllllllllllllllllIlIIlIlIIIIII.length()))
        {
          int lllllllllllllllllllIlIIlIIllllll = lllllllllllllllllllIlIIlIlIIIlIl + llIIlIlIlI[21];
          int lllllllllllllllllllIlIIlIIlllllI = lllllllllllllllllllIlIIlIIlllIIl - llIIlIlIlI[21];
          int lllllllllllllllllllIlIIlIIllllIl = fontRendererObj.getStringWidth(lllllllllllllllllllIlIIlIlIIIIII);
          drawGradientRect(lllllllllllllllllllIlIIlIIllllll - llIIlIlIlI[22], lllllllllllllllllllIlIIlIIlllllI - llIIlIlIlI[22], lllllllllllllllllllIlIIlIIllllll + lllllllllllllllllllIlIIlIIllllIl + llIIlIlIlI[22], lllllllllllllllllllIlIIlIIlllllI + llIIlIlIlI[23] + llIIlIlIlI[22], llIIlIlIlI[24], llIIlIlIlI[24]);
          "".length();
        }
      }
    }
    
    private static String lIIlllIIIIll(String lllllllllllllllllllIlIIlIIIlIlIl, String lllllllllllllllllllIlIIlIIIlIlII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllllllIlIIlIIIllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIlIIlIIIlIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllllllIlIIlIIIllIIl = Cipher.getInstance("Blowfish");
        lllllllllllllllllllIlIIlIIIllIIl.init(llIIlIlIlI[9], lllllllllllllllllllIlIIlIIIllIlI);
        return new String(lllllllllllllllllllIlIIlIIIllIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIlIIlIIIlIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllllllIlIIlIIIllIII)
      {
        lllllllllllllllllllIlIIlIIIllIII.printStackTrace();
      }
      return null;
    }
    
    private static String lIIlllIIIlIl(String lllllllllllllllllllIlIIlIIIIIlll, String lllllllllllllllllllIlIIlIIIIIIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllllllIlIIlIIIIIlll = new String(Base64.getDecoder().decode(lllllllllllllllllllIlIIlIIIIIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllllllIlIIlIIIIIlIl = new StringBuilder();
      char[] lllllllllllllllllllIlIIlIIIIIlII = lllllllllllllllllllIlIIlIIIIIIIl.toCharArray();
      int lllllllllllllllllllIlIIlIIIIIIll = llIIlIlIlI[4];
      char lllllllllllllllllllIlIIIllllllIl = lllllllllllllllllllIlIIlIIIIIlll.toCharArray();
      double lllllllllllllllllllIlIIIllllllII = lllllllllllllllllllIlIIIllllllIl.length;
      boolean lllllllllllllllllllIlIIIlllllIll = llIIlIlIlI[4];
      while (lIlIIIIIlIlI(lllllllllllllllllllIlIIIlllllIll, lllllllllllllllllllIlIIIllllllII))
      {
        char lllllllllllllllllllIlIIlIIIIlIII = lllllllllllllllllllIlIIIllllllIl[lllllllllllllllllllIlIIIlllllIll];
        "".length();
        "".length();
        if (-"   ".length() > 0) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllllllIlIIlIIIIIlIl);
    }
    
    private static boolean lIlIIIIIlllI(int ???, int arg1)
    {
      int i;
      double lllllllllllllllllllIlIIIlllIlIlI;
      return ??? <= i;
    }
    
    private static boolean lIlIIIIIIllI(int ???)
    {
      float lllllllllllllllllllIlIIIlllIIIII;
      return ??? == 0;
    }
    
    private static boolean lIlIIIIIlIIl(int ???, int arg1)
    {
      int i;
      long lllllllllllllllllllIlIIIllllIIlI;
      return ??? >= i;
    }
    
    protected Stats(Minecraft lllllllllllllllllllIlIIllIlIllII)
    {
      lllllllllllllllllllIlIIllIllIIII.<init>(lllllllllllllllllllIlIIllIlIllII, width, height, llIIlIlIlI[0], height - llIIlIlIlI[1], llIIlIlIlI[2]);
      lllllllllllllllllllIlIIllIllIIII.setShowSelectionBox(llIIlIlIlI[4]);
      lllllllllllllllllllIlIIllIllIIII.setHasListHeader(llIIlIlIlI[5], llIIlIlIlI[2]);
    }
    
    private static boolean lIlIIIIIlIII(int ???, int arg1)
    {
      int i;
      char lllllllllllllllllllIlIIIllIllIII;
      return ??? != i;
    }
    
    protected void drawBackground()
    {
      ;
      drawDefaultBackground();
    }
    
    private static void lIIlllIIIllI()
    {
      llIIIIllIl = new String[llIIlIlIlI[25]];
      llIIIIllIl[llIIlIlIlI[4]] = lIIlllIIIIll("EDfoY8nS/qmO4LFMU6IrHcpNBU6iSlU2", "nxAUf");
      llIIIIllIl[llIIlIlIlI[5]] = lIIlllIIIlII("7rx/HVPbZkE=", "CACxU");
      llIIIIllIl[llIIlIlIlI[9]] = lIIlllIIIIll("m5FnZdXKBk8=", "imyzy");
      llIIIIllIl[llIIlIlIlI[22]] = lIIlllIIIlIl("SAM1NSs=", "fmTXN");
    }
    
    protected void drawListHeader(int lllllllllllllllllllIlIIllIIllIll, int lllllllllllllllllllIlIIllIIllIlI, Tessellator lllllllllllllllllllIlIIllIIllIIl)
    {
      ;
      ;
      ;
      ;
      ;
      if (lIlIIIIIIllI(Mouse.isButtonDown(llIIlIlIlI[4]))) {
        field_148218_l = llIIlIlIlI[3];
      }
      if (lIlIIIIIIllI(field_148218_l))
      {
        GuiStats.this.drawSprite(lllllllllllllllllllIlIIllIIllIll + llIIlIlIlI[6] - llIIlIlIlI[7], lllllllllllllllllllIlIIllIIllIlI + llIIlIlIlI[5], llIIlIlIlI[4], llIIlIlIlI[4]);
        "".length();
        if ((0x67 ^ 0x63) == (0x8B ^ 0x8F)) {}
      }
      else
      {
        GuiStats.this.drawSprite(lllllllllllllllllllIlIIllIIllIll + llIIlIlIlI[6] - llIIlIlIlI[7], lllllllllllllllllllIlIIllIIllIlI + llIIlIlIlI[5], llIIlIlIlI[4], llIIlIlIlI[7]);
      }
      if (lIlIIIIIIlll(field_148218_l, llIIlIlIlI[5]))
      {
        GuiStats.this.drawSprite(lllllllllllllllllllIlIIllIIllIll + llIIlIlIlI[8] - llIIlIlIlI[7], lllllllllllllllllllIlIIllIIllIlI + llIIlIlIlI[5], llIIlIlIlI[4], llIIlIlIlI[4]);
        "".length();
        if (-('±' + 30 - 159 + 144 ^ 40 + '' - 47 + 74) <= 0) {}
      }
      else
      {
        GuiStats.this.drawSprite(lllllllllllllllllllIlIIllIIllIll + llIIlIlIlI[8] - llIIlIlIlI[7], lllllllllllllllllllIlIIllIIllIlI + llIIlIlIlI[5], llIIlIlIlI[4], llIIlIlIlI[7]);
      }
      if (lIlIIIIIIlll(field_148218_l, llIIlIlIlI[9]))
      {
        GuiStats.this.drawSprite(lllllllllllllllllllIlIIllIIllIll + llIIlIlIlI[10] - llIIlIlIlI[7], lllllllllllllllllllIlIIllIIllIlI + llIIlIlIlI[5], llIIlIlIlI[4], llIIlIlIlI[4]);
        "".length();
        if ((0x45 ^ 0x63 ^ 0x40 ^ 0x62) >= " ".length()) {}
      }
      else
      {
        GuiStats.this.drawSprite(lllllllllllllllllllIlIIllIIllIll + llIIlIlIlI[10] - llIIlIlIlI[7], lllllllllllllllllllIlIIllIIllIlI + llIIlIlIlI[5], llIIlIlIlI[4], llIIlIlIlI[7]);
      }
      if (lIlIIIIIlIII(field_148217_o, llIIlIlIlI[3]))
      {
        int lllllllllllllllllllIlIIllIIllIII = llIIlIlIlI[11];
        int lllllllllllllllllllIlIIllIIlIlll = llIIlIlIlI[7];
        if (lIlIIIIIIlll(field_148217_o, llIIlIlIlI[5]))
        {
          lllllllllllllllllllIlIIllIIllIII = llIIlIlIlI[12];
          "".length();
          if ("  ".length() != -" ".length()) {}
        }
        else if (lIlIIIIIIlll(field_148217_o, llIIlIlIlI[9]))
        {
          lllllllllllllllllllIlIIllIIllIII = llIIlIlIlI[13];
        }
        if (lIlIIIIIIlll(field_148215_p, llIIlIlIlI[5])) {
          lllllllllllllllllllIlIIllIIlIlll = llIIlIlIlI[14];
        }
        GuiStats.this.drawSprite(lllllllllllllllllllIlIIllIIllIll + lllllllllllllllllllIlIIllIIllIII, lllllllllllllllllllIlIIllIIllIlI + llIIlIlIlI[5], lllllllllllllllllllIlIIllIIlIlll, llIIlIlIlI[4]);
      }
    }
    
    protected void func_148209_a(StatBase lllllllllllllllllllIlIIlIlllIIll, int lllllllllllllllllllIlIIlIllllIIl, int lllllllllllllllllllIlIIlIllllIII, boolean lllllllllllllllllllIlIIlIlllIlll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      if (lIlIIIIIllII(lllllllllllllllllllIlIIlIlllIIll))
      {
        String lllllllllllllllllllIlIIlIlllIllI = lllllllllllllllllllIlIIlIlllIIll.format(field_146546_t.readStat(lllllllllllllllllllIlIIlIlllIIll));
        if (lIlIIIIIllIl(lllllllllllllllllllIlIIlIlllIlll))
        {
          "".length();
          if ("   ".length() <= "   ".length()) {
            break label99;
          }
        }
        label99:
        fontRendererObj.drawString(lllllllllllllllllllIlIIlIlllIllI, lllllllllllllllllllIlIIlIlllIIlI - fontRendererObj.getStringWidth(lllllllllllllllllllIlIIlIlllIllI), lllllllllllllllllllIlIIlIllllIII + llIIlIlIlI[15], llIIlIlIlI[16], llIIlIlIlI[17]);
        "".length();
        if ("  ".length() > 0) {}
      }
      else
      {
        String lllllllllllllllllllIlIIlIlllIlIl = llIIIIllIl[llIIlIlIlI[5]];
        if (lIlIIIIIllIl(lllllllllllllllllllIlIIlIlllIlll))
        {
          "".length();
          if (-"   ".length() <= 0) {
            break label199;
          }
        }
        label199:
        fontRendererObj.drawString(lllllllllllllllllllIlIIlIlllIlIl, lllllllllllllllllllIlIIlIlllIIlI - fontRendererObj.getStringWidth(lllllllllllllllllllIlIIlIlllIlIl), lllllllllllllllllllIlIIlIllllIII + llIIlIlIlI[15], llIIlIlIlI[16], llIIlIlIlI[17]);
      }
    }
    
    protected void func_148132_a(int lllllllllllllllllllIlIIllIIIlIll, int lllllllllllllllllllIlIIllIIIllIl)
    {
      ;
      ;
      field_148218_l = llIIlIlIlI[3];
      if ((lIlIIIIIlIIl(lllllllllllllllllllIlIIllIIIlllI, llIIlIlIlI[11])) && (lIlIIIIIlIlI(lllllllllllllllllllIlIIllIIIlllI, llIIlIlIlI[6])))
      {
        field_148218_l = llIIlIlIlI[4];
        "".length();
        if ("   ".length() > -" ".length()) {}
      }
      else if ((lIlIIIIIlIIl(lllllllllllllllllllIlIIllIIIlllI, llIIlIlIlI[12])) && (lIlIIIIIlIlI(lllllllllllllllllllIlIIllIIIlllI, llIIlIlIlI[8])))
      {
        field_148218_l = llIIlIlIlI[5];
        "".length();
        if ("  ".length() > -" ".length()) {}
      }
      else if ((lIlIIIIIlIIl(lllllllllllllllllllIlIIllIIIlllI, llIIlIlIlI[13])) && (lIlIIIIIlIlI(lllllllllllllllllllIlIIllIIIlllI, llIIlIlIlI[10])))
      {
        field_148218_l = llIIlIlIlI[9];
      }
      if (lIlIIIIIlIll(field_148218_l))
      {
        lllllllllllllllllllIlIIllIIIllll.func_148212_h(field_148218_l);
        mc.getSoundHandler().playSound(PositionedSoundRecord.create(new ResourceLocation(llIIIIllIl[llIIlIlIlI[4]]), 1.0F));
      }
    }
    
    protected void func_148142_b(int lllllllllllllllllllIlIIlIlIllIlI, int lllllllllllllllllllIlIIlIlIllIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      if ((lIlIIIIIlIIl(lllllllllllllllllllIlIIlIlIllIIl, top)) && (lIlIIIIIlllI(lllllllllllllllllllIlIIlIlIllIIl, bottom)))
      {
        int lllllllllllllllllllIlIIlIllIIIlI = lllllllllllllllllllIlIIlIlIllIll.getSlotIndexFromScreenCoords(lllllllllllllllllllIlIIlIllIIlII, lllllllllllllllllllIlIIlIlIllIIl);
        int lllllllllllllllllllIlIIlIllIIIIl = width / llIIlIlIlI[9] - llIIlIlIlI[18] - llIIlIlIlI[19];
        if (lIlIIIIIlIll(lllllllllllllllllllIlIIlIllIIIlI))
        {
          if ((!lIlIIIIIlIIl(lllllllllllllllllllIlIIlIllIIlII, lllllllllllllllllllIlIIlIllIIIIl + llIIlIlIlI[20])) || (lIlIIIIIllll(lllllllllllllllllllIlIIlIllIIlII, lllllllllllllllllllIlIIlIllIIIIl + llIIlIlIlI[20] + llIIlIlIlI[2]))) {
            return;
          }
          StatCrafting lllllllllllllllllllIlIIlIllIIIII = lllllllllllllllllllIlIIlIlIllIll.func_148211_c(lllllllllllllllllllIlIIlIllIIIlI);
          lllllllllllllllllllIlIIlIlIllIll.func_148213_a(lllllllllllllllllllIlIIlIllIIIII, lllllllllllllllllllIlIIlIllIIlII, lllllllllllllllllllIlIIlIlIllIIl);
          "".length();
          if (-" ".length() <= "   ".length()) {}
        }
        else
        {
          String lllllllllllllllllllIlIIlIlIlllll = llIIIIllIl[llIIlIlIlI[9]];
          if ((lIlIIIIIlIIl(lllllllllllllllllllIlIIlIllIIlII, lllllllllllllllllllIlIIlIllIIIIl + llIIlIlIlI[6] - llIIlIlIlI[7])) && (lIlIIIIIlllI(lllllllllllllllllllIlIIlIllIIlII, lllllllllllllllllllIlIIlIllIIIIl + llIIlIlIlI[6])))
          {
            lllllllllllllllllllIlIIlIlIlllll = lllllllllllllllllllIlIIlIlIllIll.func_148210_b(llIIlIlIlI[4]);
            "".length();
            if (null == null) {}
          }
          else if ((lIlIIIIIlIIl(lllllllllllllllllllIlIIlIllIIlII, lllllllllllllllllllIlIIlIllIIIIl + llIIlIlIlI[8] - llIIlIlIlI[7])) && (lIlIIIIIlllI(lllllllllllllllllllIlIIlIllIIlII, lllllllllllllllllllIlIIlIllIIIIl + llIIlIlIlI[8])))
          {
            lllllllllllllllllllIlIIlIlIlllll = lllllllllllllllllllIlIIlIlIllIll.func_148210_b(llIIlIlIlI[5]);
            "".length();
            if (null == null) {}
          }
          else
          {
            if ((!lIlIIIIIlIIl(lllllllllllllllllllIlIIlIllIIlII, lllllllllllllllllllIlIIlIllIIIIl + llIIlIlIlI[10] - llIIlIlIlI[7])) || (lIlIIIIIllll(lllllllllllllllllllIlIIlIllIIlII, lllllllllllllllllllIlIIlIllIIIIl + llIIlIlIlI[10]))) {
              return;
            }
            lllllllllllllllllllIlIIlIlIlllll = lllllllllllllllllllIlIIlIlIllIll.func_148210_b(llIIlIlIlI[9]);
          }
          lllllllllllllllllllIlIIlIlIlllll = String.valueOf(new StringBuilder().append(I18n.format(lllllllllllllllllllIlIIlIlIlllll, new Object[llIIlIlIlI[4]]))).trim();
          if (lIlIIIIlIIII(lllllllllllllllllllIlIIlIlIlllll.length()))
          {
            int lllllllllllllllllllIlIIlIlIllllI = lllllllllllllllllllIlIIlIllIIlII + llIIlIlIlI[21];
            int lllllllllllllllllllIlIIlIlIlllIl = lllllllllllllllllllIlIIlIlIllIIl - llIIlIlIlI[21];
            int lllllllllllllllllllIlIIlIlIlllII = fontRendererObj.getStringWidth(lllllllllllllllllllIlIIlIlIlllll);
            drawGradientRect(lllllllllllllllllllIlIIlIlIllllI - llIIlIlIlI[22], lllllllllllllllllllIlIIlIlIlllIl - llIIlIlIlI[22], lllllllllllllllllllIlIIlIlIllllI + lllllllllllllllllllIlIIlIlIlllII + llIIlIlIlI[22], lllllllllllllllllllIlIIlIlIlllIl + llIIlIlIlI[23] + llIIlIlIlI[22], llIIlIlIlI[24], llIIlIlIlI[24]);
            "".length();
          }
        }
      }
    }
    
    private static boolean lIlIIIIIllIl(int ???)
    {
      short lllllllllllllllllllIlIIIlllIIIlI;
      return ??? != 0;
    }
    
    protected final int getSize()
    {
      ;
      return statsHolder.size();
    }
  }
  
  class StatsGeneral
    extends GuiSlot
  {
    protected void elementClicked(int llllIllIlIlIl, boolean llllIllIlIlII, int llllIllIlIIll, int llllIllIlIIlI) {}
    
    protected int getSize()
    {
      return StatList.generalStats.size();
    }
    
    protected void drawBackground()
    {
      ;
      drawDefaultBackground();
    }
    
    protected boolean isSelected(int llllIllIlIIII)
    {
      return lIIIIIIIIl[3];
    }
    
    private static void llIIlllIIll()
    {
      lIIIIIIIIl = new int[9];
      lIIIIIIIIl[0] = (24 + '¨' - 148 + 181 ^ 13 + 10 - 65386 + 20);
      lIIIIIIIIl[1] = (0xDD ^ 0x9D);
      lIIIIIIIIl[2] = (0x40 ^ 0x4A);
      lIIIIIIIIl[3] = ((0xA9 ^ 0xBD) & (0x3 ^ 0x17 ^ 0xFFFFFFFF));
      lIIIIIIIIl[4] = "  ".length();
      lIIIIIIIIl[5] = " ".length();
      lIIIIIIIIl[6] = (0xFFFFFFFF & 0xFFFFFF);
      lIIIIIIIIl[7] = (-(0xEF7F & 0x7FAF) & 0xFFFFFFFF & 0x90FFBE);
      lIIIIIIIIl[8] = (116 + '' - 139 + 105);
    }
    
    protected void drawSlot(int llllIlIlllIIl, int llllIllIIIIIl, int llllIlIllIlll, int llllIlIllllll, int llllIlIlllllI, int llllIlIllllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      StatBase llllIlIllllII = (StatBase)StatList.generalStats.get(llllIlIlllIIl);
      if (llIIlllIlII(llllIlIlllIIl % lIIIIIIIIl[4]))
      {
        "".length();
        if (" ".length() > -" ".length()) {
          break label95;
        }
      }
      label95:
      fontRendererObj.drawString(llllIlIllllII.getStatName().getUnformattedText(), llllIllIIIIIl + lIIIIIIIIl[4], llllIllIIIIII + lIIIIIIIIl[5], lIIIIIIIIl[6], lIIIIIIIIl[7]);
      String llllIlIlllIll = llllIlIllllII.format(field_146546_t.readStat(llllIlIllllII));
      if (llIIlllIlII(llllIlIlllIIl % lIIIIIIIIl[4]))
      {
        "".length();
        if (((122 + '' - 136 + 39 ^ 24 + 23 - -95 + 3) & (0x22 ^ 0x65 ^ 0xD0 ^ 0xA5 ^ -" ".length())) <= 0) {
          break label244;
        }
      }
      label244:
      fontRendererObj.drawString(llllIlIlllIll, llllIllIIIIIl + lIIIIIIIIl[4] + lIIIIIIIIl[8] - fontRendererObj.getStringWidth(llllIlIlllIll), llllIllIIIIII + lIIIIIIIIl[5], lIIIIIIIIl[6], lIIIIIIIIl[7]);
    }
    
    static {}
    
    public StatsGeneral(Minecraft llllIllIllIll)
    {
      llllIllIlllII.<init>(llllIllIllIll, width, height, lIIIIIIIIl[0], height - lIIIIIIIIl[1], lIIIIIIIIl[2]);
      llllIllIlllII.setShowSelectionBox(lIIIIIIIIl[3]);
    }
    
    private static boolean llIIlllIlII(int ???)
    {
      char llllIlIllIIll;
      return ??? == 0;
    }
    
    protected int getContentHeight()
    {
      ;
      return llllIllIIlllI.getSize() * lIIIIIIIIl[2];
    }
  }
  
  class StatsItem
    extends GuiStats.Stats
  {
    protected void drawSlot(int llllllllllllllIlIIIIlIlllllIlllI, int llllllllllllllIlIIIIlIlllllIIIll, int llllllllllllllIlIIIIlIlllllIIIlI, int llllllllllllllIlIIIIlIlllllIlIll, int llllllllllllllIlIIIIlIlllllIlIlI, int llllllllllllllIlIIIIlIlllllIlIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      StatCrafting llllllllllllllIlIIIIlIlllllIlIII = llllllllllllllIlIIIIlIlllllIIlIl.func_148211_c(llllllllllllllIlIIIIlIlllllIlllI);
      Item llllllllllllllIlIIIIlIlllllIIlll = llllllllllllllIlIIIIlIlllllIlIII.func_150959_a();
      GuiStats.this.drawStatsScreen(llllllllllllllIlIIIIlIlllllIIIll + lIIlIIlIlIllI[9], llllllllllllllIlIIIIlIlllllIllII, llllllllllllllIlIIIIlIlllllIIlll);
      int llllllllllllllIlIIIIlIlllllIIllI = Item.getIdFromItem(llllllllllllllIlIIIIlIlllllIIlll);
      if (llIlllllllIIII(llllllllllllllIlIIIIlIlllllIlllI % lIIlIIlIlIllI[6]))
      {
        "".length();
        if ("  ".length() != "   ".length()) {
          break label98;
        }
      }
      label98:
      StatList.objectBreakStats[llllllllllllllIlIIIIlIlllllIIllI].func_148209_a(llllllllllllllIlIIIIlIlllllIIIll + lIIlIIlIlIllI[2], llllllllllllllIlIIIIlIlllllIllII, lIIlIIlIlIllI[1], lIIlIIlIlIllI[0]);
      if (llIlllllllIIII(llllllllllllllIlIIIIlIlllllIlllI % lIIlIIlIlIllI[6]))
      {
        "".length();
        if ("   ".length() <= (0x3D ^ 0x39)) {
          break label160;
        }
      }
      label160:
      StatList.objectCraftStats[llllllllllllllIlIIIIlIlllllIIllI].func_148209_a(llllllllllllllIlIIIIlIlllllIIIll + lIIlIIlIlIllI[5], llllllllllllllIlIIIIlIlllllIllII, lIIlIIlIlIllI[1], lIIlIIlIlIllI[0]);
      if (llIlllllllIIII(llllllllllllllIlIIIIlIlllllIlllI % lIIlIIlIlIllI[6]))
      {
        "".length();
        if (((0x73 ^ 0x5F) & (0x59 ^ 0x75 ^ 0xFFFFFFFF)) < " ".length()) {
          break label227;
        }
      }
      label227:
      llllllllllllllIlIIIIlIlllllIlIII.func_148209_a(llllllllllllllIlIIIIlIlllllIIIll + lIIlIIlIlIllI[7], llllllllllllllIlIIIIlIlllllIllII, lIIlIIlIlIllI[1], lIIlIIlIlIllI[0]);
    }
    
    private static String llIllllllIlIII(String llllllllllllllIlIIIIlIllllIIIlII, String llllllllllllllIlIIIIlIllllIIIIll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIIIIlIllllIIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIIIlIllllIIIIll.getBytes(StandardCharsets.UTF_8)), lIIlIIlIlIllI[11]), "DES");
        Cipher llllllllllllllIlIIIIlIllllIIIllI = Cipher.getInstance("DES");
        llllllllllllllIlIIIIlIllllIIIllI.init(lIIlIIlIlIllI[6], llllllllllllllIlIIIIlIllllIIIlll);
        return new String(llllllllllllllIlIIIIlIllllIIIllI.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIIIlIllllIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIIIIlIllllIIIlIl)
      {
        llllllllllllllIlIIIIlIllllIIIlIl.printStackTrace();
      }
      return null;
    }
    
    public StatsItem(Minecraft llllllllllllllIlIIIIllIIIIIIllIl)
    {
      llllllllllllllIlIIIIllIIIIIIlllI.<init>(GuiStats.this, llllllllllllllIlIIIIllIIIIIIllIl);
      statsHolder = Lists.newArrayList();
      byte llllllllllllllIlIIIIllIIIIIIIlIl = StatList.itemStats.iterator();
      "".length();
      if (null != null) {
        throw null;
      }
      while (!llIlllllllIIII(llllllllllllllIlIIIIllIIIIIIIlIl.hasNext()))
      {
        StatCrafting llllllllllllllIlIIIIllIIIIIIllII = (StatCrafting)llllllllllllllIlIIIIllIIIIIIIlIl.next();
        boolean llllllllllllllIlIIIIllIIIIIIlIll = lIIlIIlIlIllI[0];
        int llllllllllllllIlIIIIllIIIIIIlIlI = Item.getIdFromItem(llllllllllllllIlIIIIllIIIIIIllII.func_150959_a());
        if (llIllllllIllIl(field_146546_t.readStat(llllllllllllllIlIIIIllIIIIIIllII)))
        {
          llllllllllllllIlIIIIllIIIIIIlIll = lIIlIIlIlIllI[1];
          "".length();
          if (null != null) {
            throw null;
          }
        }
        else if ((llIllllllIlllI(StatList.objectBreakStats[llllllllllllllIlIIIIllIIIIIIlIlI])) && (llIllllllIllIl(field_146546_t.readStat(StatList.objectBreakStats[llllllllllllllIlIIIIllIIIIIIlIlI]))))
        {
          llllllllllllllIlIIIIllIIIIIIlIll = lIIlIIlIlIllI[1];
          "".length();
          if (-(0xF ^ 0xB) >= 0) {
            throw null;
          }
        }
        else if ((llIllllllIlllI(StatList.objectCraftStats[llllllllllllllIlIIIIllIIIIIIlIlI])) && (llIllllllIllIl(field_146546_t.readStat(StatList.objectCraftStats[llllllllllllllIlIIIIllIIIIIIlIlI]))))
        {
          llllllllllllllIlIIIIllIIIIIIlIll = lIIlIIlIlIllI[1];
        }
        if (llIllllllIllll(llllllllllllllIlIIIIllIIIIIIlIll)) {
          "".length();
        }
      }
      statSorter = new Comparator()
      {
        private static void llIIIIIlIllIl()
        {
          lllllIlllll = new int[3];
          lllllIlllll[0] = " ".length();
          lllllIlllll[1] = "  ".length();
          lllllIlllll[2] = (-" ".length());
        }
        
        static {}
        
        private static boolean llIIIIIllIIII(Object ???)
        {
          long llllllllllllllllIIIlIIlIIlIIllll;
          return ??? == null;
        }
        
        public int compare(StatCrafting llllllllllllllllIIIlIIlIIllIIlII, StatCrafting llllllllllllllllIIIlIIlIIllIllII)
        {
          ;
          ;
          ;
          ;
          ;
          ;
          ;
          ;
          ;
          int llllllllllllllllIIIlIIlIIllIlIll = Item.getIdFromItem(llllllllllllllllIIIlIIlIIllIIlII.func_150959_a());
          int llllllllllllllllIIIlIIlIIllIlIlI = Item.getIdFromItem(llllllllllllllllIIIlIIlIIllIllII.func_150959_a());
          StatBase llllllllllllllllIIIlIIlIIllIlIIl = null;
          StatBase llllllllllllllllIIIlIIlIIllIlIII = null;
          if (llIIIIIlIlllI(field_148217_o))
          {
            llllllllllllllllIIIlIIlIIllIlIIl = StatList.objectBreakStats[llllllllllllllllIIIlIIlIIllIlIll];
            llllllllllllllllIIIlIIlIIllIlIII = StatList.objectBreakStats[llllllllllllllllIIIlIIlIIllIlIlI];
            "".length();
            if ("   ".length() < " ".length()) {
              return (0x1E ^ 0xB ^ 0xCF ^ 0x8D) & (0x81 ^ 0x90 ^ 0x2E ^ 0x68 ^ -" ".length());
            }
          }
          else if (llIIIIIlIllll(field_148217_o, lllllIlllll[0]))
          {
            llllllllllllllllIIIlIIlIIllIlIIl = StatList.objectCraftStats[llllllllllllllllIIIlIIlIIllIlIll];
            llllllllllllllllIIIlIIlIIllIlIII = StatList.objectCraftStats[llllllllllllllllIIIlIIlIIllIlIlI];
            "".length();
            if ("  ".length() < 0) {
              return (91 + '' - 99 + 54 ^ 98 + 20 - -10 + 25) & (0xEF ^ 0x9D ^ 0xCF ^ 0x9A ^ -" ".length());
            }
          }
          else if (llIIIIIlIllll(field_148217_o, lllllIlllll[1]))
          {
            llllllllllllllllIIIlIIlIIllIlIIl = StatList.objectUseStats[llllllllllllllllIIIlIIlIIllIlIll];
            llllllllllllllllIIIlIIlIIllIlIII = StatList.objectUseStats[llllllllllllllllIIIlIIlIIllIlIlI];
          }
          if ((!llIIIIIllIIII(llllllllllllllllIIIlIIlIIllIlIIl)) || (llIIIIIllIIIl(llllllllllllllllIIIlIIlIIllIlIII)))
          {
            if (llIIIIIllIIII(llllllllllllllllIIIlIIlIIllIlIIl)) {
              return lllllIlllll[0];
            }
            if (llIIIIIllIIII(llllllllllllllllIIIlIIlIIllIlIII)) {
              return lllllIlllll[2];
            }
            int llllllllllllllllIIIlIIlIIllIIlll = field_146546_t.readStat(llllllllllllllllIIIlIIlIIllIlIIl);
            int llllllllllllllllIIIlIIlIIllIIllI = field_146546_t.readStat(llllllllllllllllIIIlIIlIIllIlIII);
            if (llIIIIIllIIlI(llllllllllllllllIIIlIIlIIllIIlll, llllllllllllllllIIIlIIlIIllIIllI)) {
              return (llllllllllllllllIIIlIIlIIllIIlll - llllllllllllllllIIIlIIlIIllIIllI) * field_148215_p;
            }
          }
          return llllllllllllllllIIIlIIlIIllIlIll - llllllllllllllllIIIlIIlIIllIlIlI;
        }
        
        private static boolean llIIIIIlIlllI(int ???)
        {
          long llllllllllllllllIIIlIIlIIlIIllIl;
          return ??? == 0;
        }
        
        private static boolean llIIIIIllIIIl(Object ???)
        {
          char llllllllllllllllIIIlIIlIIlIlIIIl;
          return ??? != null;
        }
        
        private static boolean llIIIIIlIllll(int ???, int arg1)
        {
          int i;
          byte llllllllllllllllIIIlIIlIIlIlIIll;
          return ??? == i;
        }
        
        private static boolean llIIIIIllIIlI(int ???, int arg1)
        {
          int i;
          long llllllllllllllllIIIlIIlIIlIIlIIl;
          return ??? != i;
        }
      };
    }
    
    private static String llIllllllIlIIl(String llllllllllllllIlIIIIlIlllIlIllll, String llllllllllllllIlIIIIlIlllIlIlllI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIlIIIIlIlllIlIllll = new String(Base64.getDecoder().decode(llllllllllllllIlIIIIlIlllIlIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIlIIIIlIlllIllIIlI = new StringBuilder();
      char[] llllllllllllllIlIIIIlIlllIllIIIl = llllllllllllllIlIIIIlIlllIlIlllI.toCharArray();
      int llllllllllllllIlIIIIlIlllIllIIII = lIIlIIlIlIllI[0];
      byte llllllllllllllIlIIIIlIlllIlIlIlI = llllllllllllllIlIIIIlIlllIlIllll.toCharArray();
      long llllllllllllllIlIIIIlIlllIlIlIIl = llllllllllllllIlIIIIlIlllIlIlIlI.length;
      byte llllllllllllllIlIIIIlIlllIlIlIII = lIIlIIlIlIllI[0];
      while (llIlllllllIIlI(llllllllllllllIlIIIIlIlllIlIlIII, llllllllllllllIlIIIIlIlllIlIlIIl))
      {
        char llllllllllllllIlIIIIlIlllIllIlIl = llllllllllllllIlIIIIlIlllIlIlIlI[llllllllllllllIlIIIIlIlllIlIlIII];
        "".length();
        "".length();
        if (null != null) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIlIIIIlIlllIllIIlI);
    }
    
    protected void drawListHeader(int llllllllllllllIlIIIIlIllllllllIl, int llllllllllllllIlIIIIlIllllllllII, Tessellator llllllllllllllIlIIIIlIllllllIlll)
    {
      ;
      ;
      ;
      ;
      llllllllllllllIlIIIIlIlllllllIlI.drawListHeader(llllllllllllllIlIIIIlIllllllllIl, llllllllllllllIlIIIIlIllllllllII, llllllllllllllIlIIIIlIllllllIlll);
      if (llIlllllllIIII(field_148218_l))
      {
        GuiStats.this.drawSprite(llllllllllllllIlIIIIlIllllllllIl + lIIlIIlIlIllI[2] - lIIlIIlIlIllI[3] + lIIlIIlIlIllI[1], llllllllllllllIlIIIIlIllllllllII + lIIlIIlIlIllI[1] + lIIlIIlIlIllI[1], lIIlIIlIlIllI[4], lIIlIIlIlIllI[3]);
        "".length();
        if (((0x56 ^ 0x16) & (0x73 ^ 0x33 ^ 0xFFFFFFFF)) <= ((0x82 ^ 0xAC) & (0x6F ^ 0x41 ^ 0xFFFFFFFF))) {}
      }
      else
      {
        GuiStats.this.drawSprite(llllllllllllllIlIIIIlIllllllllIl + lIIlIIlIlIllI[2] - lIIlIIlIlIllI[3], llllllllllllllIlIIIIlIllllllllII + lIIlIIlIlIllI[1], lIIlIIlIlIllI[4], lIIlIIlIlIllI[3]);
      }
      if (llIlllllllIIIl(field_148218_l, lIIlIIlIlIllI[1]))
      {
        GuiStats.this.drawSprite(llllllllllllllIlIIIIlIllllllllIl + lIIlIIlIlIllI[5] - lIIlIIlIlIllI[3] + lIIlIIlIlIllI[1], llllllllllllllIlIIIIlIllllllllII + lIIlIIlIlIllI[1] + lIIlIIlIlIllI[1], lIIlIIlIlIllI[3], lIIlIIlIlIllI[3]);
        "".length();
        if ("  ".length() != 0) {}
      }
      else
      {
        GuiStats.this.drawSprite(llllllllllllllIlIIIIlIllllllllIl + lIIlIIlIlIllI[5] - lIIlIIlIlIllI[3], llllllllllllllIlIIIIlIllllllllII + lIIlIIlIlIllI[1], lIIlIIlIlIllI[3], lIIlIIlIlIllI[3]);
      }
      if (llIlllllllIIIl(field_148218_l, lIIlIIlIlIllI[6]))
      {
        GuiStats.this.drawSprite(llllllllllllllIlIIIIlIllllllllIl + lIIlIIlIlIllI[7] - lIIlIIlIlIllI[3] + lIIlIIlIlIllI[1], llllllllllllllIlIIIIlIllllllllII + lIIlIIlIlIllI[1] + lIIlIIlIlIllI[1], lIIlIIlIlIllI[8], lIIlIIlIlIllI[3]);
        "".length();
        if (null == null) {}
      }
      else
      {
        GuiStats.this.drawSprite(llllllllllllllIlIIIIlIllllllllIl + lIIlIIlIlIllI[7] - lIIlIIlIlIllI[3], llllllllllllllIlIIIIlIllllllllII + lIIlIIlIlIllI[1], lIIlIIlIlIllI[8], lIIlIIlIlIllI[3]);
      }
    }
    
    private static boolean llIlllllllIIlI(int ???, int arg1)
    {
      int i;
      boolean llllllllllllllIlIIIIlIlllIIlllll;
      return ??? < i;
    }
    
    private static boolean llIlllllllIIII(int ???)
    {
      boolean llllllllllllllIlIIIIlIlllIIllIIl;
      return ??? == 0;
    }
    
    private static void llIllllllIllII()
    {
      lIIlIIlIlIllI = new int[12];
      lIIlIIlIlIllI[0] = ((0x7E ^ 0x53 ^ 0x84 ^ 0x82) & (120 + 102 - 192 + 114 ^ 127 + 104 - 72 + 28 ^ -" ".length()));
      lIIlIIlIlIllI[1] = " ".length();
      lIIlIIlIlIllI[2] = (0xE2 ^ 0xB9 ^ 0x8E ^ 0xA6);
      lIIlIIlIlIllI[3] = (0xCE ^ 0x82 ^ 0x2 ^ 0x5C);
      lIIlIIlIlIllI[4] = (0x8A ^ 0xC2);
      lIIlIIlIlIllI[5] = (55 + 42 - 19 + 59 + (0x36 ^ 0x3E) - -(0x8A ^ 0x9A) + (0x99 ^ 0x9D));
      lIIlIIlIlIllI[6] = "  ".length();
      lIIlIIlIlIllI[7] = ((0x27 ^ 0x7A) + (45 + '' - 26 + 25) - ('' + 34 - -33 + 32) + (93 + '' - 108 + 52));
      lIIlIIlIlIllI[8] = (0x2E ^ 0x26 ^ 0x32 ^ 0x1E);
      lIIlIIlIlIllI[9] = (55 + 21 - 9 + 118 ^ 24 + '' - 79 + 60);
      lIIlIIlIlIllI[10] = "   ".length();
      lIIlIIlIlIllI[11] = (0x94 ^ 0xB7 ^ 0x4E ^ 0x65);
    }
    
    private static boolean llIllllllIllIl(int ???)
    {
      Exception llllllllllllllIlIIIIlIlllIIlIlll;
      return ??? > 0;
    }
    
    protected String func_148210_b(int llllllllllllllIlIIIIlIllllIllIll)
    {
      ;
      if (llIlllllllIIIl(llllllllllllllIlIIIIlIllllIllIll, lIIlIIlIlIllI[1]))
      {
        "".length();
        if (null != null) {
          return null;
        }
      }
      else if (llIlllllllIIIl(llllllllllllllIlIIIIlIllllIlllII, lIIlIIlIlIllI[6]))
      {
        "".length();
        if (((0x6B ^ 0x49) & (0xE6 ^ 0xC4 ^ 0xFFFFFFFF)) < " ".length()) {
          break label96;
        }
        return null;
      }
      label96:
      return lIIlIIlIlIlIl[lIIlIIlIlIllI[6]];
    }
    
    static
    {
      llIllllllIllII();
      llIllllllIlIll();
    }
    
    private static boolean llIllllllIlllI(Object ???)
    {
      long llllllllllllllIlIIIIlIlllIIlllIl;
      return ??? != null;
    }
    
    private static void llIllllllIlIll()
    {
      lIIlIIlIlIlIl = new String[lIIlIIlIlIllI[10]];
      lIIlIIlIlIlIl[lIIlIIlIlIllI[0]] = llIllllllIlIII("MWEjpx9vQS567XOV5eJCPA==", "fPoJa");
      lIIlIIlIlIlIl[lIIlIIlIlIllI[1]] = llIllllllIlIIl("PBYSBVY6ERYV", "Obsqx");
      lIIlIIlIlIlIl[lIIlIIlIlIllI[6]] = llIllllllIlIlI("zi+tUqk0T8X6MgSNe+vpJA==", "HcDYT");
    }
    
    private static boolean llIllllllIllll(int ???)
    {
      float llllllllllllllIlIIIIlIlllIIllIll;
      return ??? != 0;
    }
    
    private static boolean llIlllllllIIIl(int ???, int arg1)
    {
      int i;
      char llllllllllllllIlIIIIlIlllIlIIIll;
      return ??? == i;
    }
    
    private static String llIllllllIlIlI(String llllllllllllllIlIIIIlIllllIlIIIl, String llllllllllllllIlIIIIlIllllIIlllI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIIIIlIllllIlIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIIIlIllllIIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIlIIIIlIllllIlIIll = Cipher.getInstance("Blowfish");
        llllllllllllllIlIIIIlIllllIlIIll.init(lIIlIIlIlIllI[6], llllllllllllllIlIIIIlIllllIlIlII);
        return new String(llllllllllllllIlIIIIlIllllIlIIll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIIIlIllllIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIIIIlIllllIlIIlI)
      {
        llllllllllllllIlIIIIlIllllIlIIlI.printStackTrace();
      }
      return null;
    }
  }
}

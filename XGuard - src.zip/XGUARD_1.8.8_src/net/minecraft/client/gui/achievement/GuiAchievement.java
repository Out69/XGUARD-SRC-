package net.minecraft.client.gui.achievement;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.stats.Achievement;
import net.minecraft.util.IChatComponent;

public class GuiAchievement
  extends Gui
{
  private static boolean lIlIIIllllII(int ???)
  {
    int lllllllllllllllllllIIllIIIlIlIlI;
    return ??? == 0;
  }
  
  private static int lIlIIIlllIII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public void updateAchievementWindow()
  {
    ;
    ;
    ;
    ;
    ;
    if ((lIlIIIlllIlI(theAchievement)) && (lIlIIIlllIll(lIlIIIllIlll(notificationTime, 0L))) && (lIlIIIlllIlI(getMinecraftthePlayer)))
    {
      double lllllllllllllllllllIIllIIlIIlIII = (Minecraft.getSystemTime() - notificationTime) / 3000.0D;
      if (lIlIIIllllII(permanentNotification))
      {
        if ((!lIlIIIllllIl(lIlIIIlllIII(lllllllllllllllllllIIllIIlIIlIII, 0.0D))) || (lIlIIIlllllI(lIlIIIlllIIl(lllllllllllllllllllIIllIIlIIlIII, 1.0D)))) {
          notificationTime = 0L;
        }
      }
      else if (lIlIIIlllllI(lIlIIIlllIIl(lllllllllllllllllllIIllIIlIIlIII, 0.5D))) {
        lllllllllllllllllllIIllIIlIIlIII = 0.5D;
      }
      lllllllllllllllllllIIllIIlIIlIIl.updateAchievementWindowScale();
      GlStateManager.disableDepth();
      GlStateManager.depthMask(llIIllIllI[0]);
      double lllllllllllllllllllIIllIIlIIIlll = lllllllllllllllllllIIllIIlIIlIII * 2.0D;
      if (lIlIIIlllllI(lIlIIIlllIIl(lllllllllllllllllllIIllIIlIIIlll, 1.0D))) {
        lllllllllllllllllllIIllIIlIIIlll = 2.0D - lllllllllllllllllllIIllIIlIIIlll;
      }
      lllllllllllllllllllIIllIIlIIIlll *= 4.0D;
      lllllllllllllllllllIIllIIlIIIlll = 1.0D - lllllllllllllllllllIIllIIlIIIlll;
      if (lIlIIIllllll(lIlIIIlllIII(lllllllllllllllllllIIllIIlIIIlll, 0.0D))) {
        lllllllllllllllllllIIllIIlIIIlll = 0.0D;
      }
      lllllllllllllllllllIIllIIlIIIlll *= lllllllllllllllllllIIllIIlIIIlll;
      lllllllllllllllllllIIllIIlIIIlll *= lllllllllllllllllllIIllIIlIIIlll;
      int lllllllllllllllllllIIllIIlIIIllI = width - llIIllIllI[5];
      int lllllllllllllllllllIIllIIlIIIlIl = llIIllIllI[0] - (int)(lllllllllllllllllllIIllIIlIIIlll * 36.0D);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.enableTexture2D();
      mc.getTextureManager().bindTexture(achievementBg);
      GlStateManager.disableLighting();
      lllllllllllllllllllIIllIIlIIlIIl.drawTexturedModalRect(lllllllllllllllllllIIllIIlIIIllI, lllllllllllllllllllIIllIIlIIIlIl, llIIllIllI[6], llIIllIllI[7], llIIllIllI[5], llIIllIllI[8]);
      if (lIlIIIlllIll(permanentNotification))
      {
        Minecraft.fontRendererObj.drawSplitString(achievementDescription, lllllllllllllllllllIIllIIlIIIllI + llIIllIllI[9], lllllllllllllllllllIIllIIlIIIlIl + llIIllIllI[10], llIIllIllI[11], llIIllIllI[12]);
        "".length();
        if (null == null) {}
      }
      else
      {
        "".length();
        "".length();
      }
      RenderHelper.enableGUIStandardItemLighting();
      GlStateManager.disableLighting();
      GlStateManager.enableRescaleNormal();
      GlStateManager.enableColorMaterial();
      GlStateManager.enableLighting();
      renderItem.renderItemAndEffectIntoGUI(theAchievement.theItemStack, lllllllllllllllllllIIllIIlIIIllI + llIIllIllI[15], lllllllllllllllllllIIllIIlIIIlIl + llIIllIllI[15]);
      GlStateManager.disableLighting();
      GlStateManager.depthMask(llIIllIllI[1]);
      GlStateManager.enableDepth();
    }
  }
  
  private static boolean lIlIIIlllIll(int ???)
  {
    float lllllllllllllllllllIIllIIIlIllII;
    return ??? != 0;
  }
  
  public GuiAchievement(Minecraft lllllllllllllllllllIIllIIllIIIll)
  {
    mc = lllllllllllllllllllIIllIIllIIIll;
    renderItem = lllllllllllllllllllIIllIIllIIIll.getRenderItem();
  }
  
  public void displayUnformattedAchievement(Achievement lllllllllllllllllllIIllIIlIlIlIl)
  {
    ;
    ;
    achievementTitle = lllllllllllllllllllIIllIIlIlIlIl.getStatName().getUnformattedText();
    achievementDescription = lllllllllllllllllllIIllIIlIlIlIl.getDescription();
    notificationTime = (Minecraft.getSystemTime() + 2500L);
    theAchievement = lllllllllllllllllllIIllIIlIlIlIl;
    permanentNotification = llIIllIllI[1];
  }
  
  private static boolean lIlIIIllllIl(int ???)
  {
    int lllllllllllllllllllIIllIIIlIlIII;
    return ??? >= 0;
  }
  
  private static void lIlIIIllIlIl()
  {
    llIIllIlIl = new String[llIIllIllI[16]];
    llIIllIlIl[llIIllIllI[0]] = lIlIIIllIlII("/G+jvNbJF7aG/ai2NXWfDUNHMM+iG3wxxJXSxnZyz9BRxdwlYuHP56FN5f8AMOPAJbxkB92G4Gg=", "cWRRU");
    llIIllIlIl[llIIllIllI[1]] = lIlIIIllIlII("qwW/sP8vayiPADOkezZlcA==", "QlMTz");
  }
  
  private static int lIlIIIllIlll(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  private void updateAchievementWindowScale()
  {
    ;
    ;
    GlStateManager.viewport(llIIllIllI[0], llIIllIllI[0], mc.displayWidth, mc.displayHeight);
    GlStateManager.matrixMode(llIIllIllI[2]);
    GlStateManager.loadIdentity();
    GlStateManager.matrixMode(llIIllIllI[3]);
    GlStateManager.loadIdentity();
    width = mc.displayWidth;
    height = mc.displayHeight;
    ScaledResolution lllllllllllllllllllIIllIIlIlIIIl = new ScaledResolution(mc);
    width = ScaledResolution.getScaledWidth();
    height = lllllllllllllllllllIIllIIlIlIIIl.getScaledHeight();
    GlStateManager.clear(llIIllIllI[4]);
    GlStateManager.matrixMode(llIIllIllI[2]);
    GlStateManager.loadIdentity();
    GlStateManager.ortho(0.0D, width, height, 0.0D, 1000.0D, 3000.0D);
    GlStateManager.matrixMode(llIIllIllI[3]);
    GlStateManager.loadIdentity();
    GlStateManager.translate(0.0F, 0.0F, -2000.0F);
  }
  
  public void displayAchievement(Achievement lllllllllllllllllllIIllIIlIllIll)
  {
    ;
    ;
    achievementTitle = I18n.format(llIIllIlIl[llIIllIllI[1]], new Object[llIIllIllI[0]]);
    achievementDescription = lllllllllllllllllllIIllIIlIllIll.getStatName().getUnformattedText();
    notificationTime = Minecraft.getSystemTime();
    theAchievement = lllllllllllllllllllIIllIIlIllIll;
    permanentNotification = llIIllIllI[0];
  }
  
  private static void lIlIIIllIllI()
  {
    llIIllIllI = new int[17];
    llIIllIllI[0] = (('' + '«' - 222 + 126 ^ '«' + '' - 215 + 92) & (0xAE ^ 0xB6 ^ 0x60 ^ 0x19 ^ -" ".length()));
    llIIllIllI[1] = " ".length();
    llIIllIllI[2] = (0xB721 & 0x5FDF);
    llIIllIllI[3] = (0xD781 & 0x3F7E);
    llIIllIllI[4] = (0xAD59 & 0x53A6);
    llIIllIllI[5] = (118 + '' - 229 + 129);
    llIIllIllI[6] = (0x76 ^ 0x16);
    llIIllIllI[7] = (21 + 7 - -101 + 11 + (91 + 127 - 136 + 67) - ('×' + 69 - 87 + 20) + (54 + 57 - 33 + 52));
    llIIllIllI[8] = (0x51 ^ 0x39 ^ 0xD5 ^ 0x9D);
    llIIllIllI[9] = (0x60 ^ 0x4B ^ 0x1B ^ 0x2E);
    llIIllIllI[10] = (0xA ^ 0xD);
    llIIllIllI[11] = (0x78 ^ 0x0);
    llIIllIllI[12] = (-" ".length());
    llIIllIllI[13] = (-(0xB9A1 & 0x475E));
    llIIllIllI[14] = (0x13 ^ 0x1);
    llIIllIllI[15] = (0x82 ^ 0xB1 ^ 0xD ^ 0x36);
    llIIllIllI[16] = "  ".length();
  }
  
  private static boolean lIlIIIllllll(int ???)
  {
    String lllllllllllllllllllIIllIIIlIIllI;
    return ??? < 0;
  }
  
  private static boolean lIlIIIlllllI(int ???)
  {
    double lllllllllllllllllllIIllIIIlIIlII;
    return ??? > 0;
  }
  
  private static String lIlIIIllIlII(String lllllllllllllllllllIIllIIIllIlIl, String lllllllllllllllllllIIllIIIllIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllllIIllIIIlllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIIllIIIllIIlI.getBytes(StandardCharsets.UTF_8)), llIIllIllI[15]), "DES");
      Cipher lllllllllllllllllllIIllIIIllIlll = Cipher.getInstance("DES");
      lllllllllllllllllllIIllIIIllIlll.init(llIIllIllI[16], lllllllllllllllllllIIllIIIlllIII);
      return new String(lllllllllllllllllllIIllIIIllIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIIllIIIllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllllIIllIIIllIllI)
    {
      lllllllllllllllllllIIllIIIllIllI.printStackTrace();
    }
    return null;
  }
  
  public void clearAchievements()
  {
    ;
    theAchievement = null;
    notificationTime = 0L;
  }
  
  private static int lIlIIIlllIIl(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  static
  {
    lIlIIIllIllI();
    lIlIIIllIlIl();
  }
  
  private static boolean lIlIIIlllIlI(Object ???)
  {
    char lllllllllllllllllllIIllIIIlIlllI;
    return ??? != null;
  }
}

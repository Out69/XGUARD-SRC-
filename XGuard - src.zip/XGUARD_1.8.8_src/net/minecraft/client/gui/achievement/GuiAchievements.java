package net.minecraft.client.gui.achievement;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiOptionButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.IProgressMeter;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.BlockModelShapes;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.network.play.client.C16PacketClientStatus.EnumState;
import net.minecraft.stats.Achievement;
import net.minecraft.stats.AchievementList;
import net.minecraft.stats.StatFileWriter;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Session;
import org.lwjgl.input.Mouse;

public class GuiAchievements
  extends GuiScreen
  implements IProgressMeter
{
  private static boolean llIIIllIlII(int ???, int arg1)
  {
    int i;
    boolean lIIIIlIlIllIIl;
    return ??? < i;
  }
  
  protected void drawTitle()
  {
    ;
    ;
    ;
    int lIIIlIIIllIlII = (width - field_146555_f) / llllIlIII[8];
    int lIIIlIIIllIIll = (height - field_146557_g) / llllIlIII[8];
    "".length();
  }
  
  public void doneLoading()
  {
    ;
    if (llIIIllIIlI(loadingAchievements)) {
      loadingAchievements = llllIlIII[3];
    }
  }
  
  protected void keyTyped(char lIIIlIIllIlIll, int lIIIlIIllIlIlI)
    throws IOException
  {
    ;
    ;
    ;
    if (llIIIlIlllI(lIIIlIIllIlIlI, mc.gameSettings.keyBindInventory.getKeyCode()))
    {
      mc.displayGuiScreen(null);
      mc.setIngameFocus();
      "".length();
      if ("   ".length() == "   ".length()) {}
    }
    else
    {
      lIIIlIIllIllII.keyTyped(lIIIlIIllIlllI, lIIIlIIllIlIlI);
    }
  }
  
  private static int llIIIllIIII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static String llIIIlIlIlI(String lIIIIlIllllIlI, String lIIIIlIllllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIIIIlIllllIlI = new String(Base64.getDecoder().decode(lIIIIlIllllIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIIIIlIlllllIl = new StringBuilder();
    char[] lIIIIlIlllllII = lIIIIlIllllIIl.toCharArray();
    int lIIIIlIllllIll = llllIlIII[3];
    float lIIIIlIlllIlIl = lIIIIlIllllIlI.toCharArray();
    byte lIIIIlIlllIlII = lIIIIlIlllIlIl.length;
    byte lIIIIlIlllIIll = llllIlIII[3];
    while (llIIIllIlII(lIIIIlIlllIIll, lIIIIlIlllIlII))
    {
      char lIIIIllIIIIIII = lIIIIlIlllIlIl[lIIIIlIlllIIll];
      "".length();
      "".length();
      if (-" ".length() >= ((0xAE ^ 0x8F) & (0x48 ^ 0x69 ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(lIIIIlIlllllIl);
  }
  
  protected void drawAchievementScreen(int lIIIIllllllllI, int lIIIIlllllllIl, float lIIIIlllllllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lIIIIllllllIll = MathHelper.floor_double(field_146569_s + (field_146567_u - field_146569_s) * lIIIIlllllllII);
    int lIIIIllllllIlI = MathHelper.floor_double(field_146568_t + (field_146566_v - field_146568_t) * lIIIIlllllllII);
    if (llIIIllIlII(lIIIIllllllIll, field_146572_y)) {
      lIIIIllllllIll = field_146572_y;
    }
    if (llIIIllIlII(lIIIIllllllIlI, field_146571_z)) {
      lIIIIllllllIlI = field_146571_z;
    }
    if (llIIIllIIll(lIIIIllllllIll, field_146559_A)) {
      lIIIIllllllIll = field_146559_A - llllIlIII[6];
    }
    if (llIIIllIIll(lIIIIllllllIlI, field_146560_B)) {
      lIIIIllllllIlI = field_146560_B - llllIlIII[6];
    }
    int lIIIIllllllIIl = (width - field_146555_f) / llllIlIII[8];
    int lIIIIllllllIII = (height - field_146557_g) / llllIlIII[8];
    int lIIIIlllllIlll = lIIIIllllllIIl + llllIlIII[22];
    int lIIIIlllllIllI = lIIIIllllllIII + llllIlIII[15];
    zLevel = 0.0F;
    GlStateManager.depthFunc(llllIlIII[23]);
    GlStateManager.pushMatrix();
    GlStateManager.translate(lIIIIlllllIlll, lIIIIlllllIllI, -200.0F);
    GlStateManager.scale(1.0F / field_146570_r, 1.0F / field_146570_r, 0.0F);
    GlStateManager.enableTexture2D();
    GlStateManager.disableLighting();
    GlStateManager.enableRescaleNormal();
    GlStateManager.enableColorMaterial();
    int lIIIIlllllIlIl = lIIIIllllllIll + llllIlIII[24] >> llllIlIII[25];
    int lIIIIlllllIlII = lIIIIllllllIlI + llllIlIII[24] >> llllIlIII[25];
    int lIIIIlllllIIll = (lIIIIllllllIll + llllIlIII[24]) % llllIlIII[22];
    int lIIIIlllllIIlI = (lIIIIllllllIlI + llllIlIII[24]) % llllIlIII[22];
    int lIIIIlllllIIIl = llllIlIII[25];
    int lIIIIlllllIIII = llllIlIII[14];
    int lIIIIllllIllll = llllIlIII[26];
    int lIIIIllllIlllI = llllIlIII[27];
    int lIIIIllllIllIl = llllIlIII[28];
    Random lIIIIllllIllII = new Random();
    float lIIIIllllIlIll = 16.0F / field_146570_r;
    float lIIIIllllIlIlI = 16.0F / field_146570_r;
    int lIIIIllllIlIIl = llllIlIII[3];
    "".length();
    if ((0x5C ^ 0x58) < "  ".length()) {
      return;
    }
    while (!llIIIllIlll(llIIIlllIIl(lIIIIllllIlIIl * lIIIIllllIlIll - lIIIIlllllIIlI, 155.0F)))
    {
      float lIIIIllllIlIII = 0.6F - (lIIIIlllllIlII + lIIIIllllIlIIl) / 25.0F * 0.3F;
      GlStateManager.color(lIIIIllllIlIII, lIIIIllllIlIII, lIIIIllllIlIII, 1.0F);
      int lIIIIllllIIlll = llllIlIII[3];
      "".length();
      if (" ".length() != " ".length()) {
        return;
      }
      while (!llIIIllIlll(llIIIlllIIl(lIIIIllllIIlll * lIIIIllllIlIlI - lIIIIlllllIIll, 224.0F)))
      {
        lIIIIllllIllII.setSeed(mc.getSession().getPlayerID().hashCode() + lIIIIlllllIlIl + lIIIIllllIIlll + (lIIIIlllllIlII + lIIIIllllIlIIl) * llllIlIII[22]);
        int lIIIIllllIIllI = lIIIIllllIllII.nextInt(llllIlIII[6] + lIIIIlllllIlII + lIIIIllllIlIIl) + (lIIIIlllllIlII + lIIIIllllIlIIl) / llllIlIII[8];
        TextureAtlasSprite lIIIIllllIIlIl = lIIIIlllllllll.func_175371_a(Blocks.sand);
        if ((llIIIlllIll(lIIIIllllIIllI, llllIlIII[28])) && (llIIIllllII(lIIIIlllllIlII + lIIIIllllIlIIl, llllIlIII[29])))
        {
          if (llIIIlIlllI(lIIIIllllIIllI, llllIlIII[27]))
          {
            if (llIIIlIllIl(lIIIIllllIllII.nextInt(llllIlIII[8])))
            {
              lIIIIllllIIlIl = lIIIIlllllllll.func_175371_a(Blocks.diamond_ore);
              "".length();
              if (null == null) {}
            }
            else
            {
              lIIIIllllIIlIl = lIIIIlllllllll.func_175371_a(Blocks.redstone_ore);
              "".length();
              if (-" ".length() < (('' + 124 - 163 + 50 ^ 65 + 'º' - 103 + 40) & (17 + '' - 1 + 23 ^ 8 + 87 - 75 + 110 ^ -" ".length()))) {}
            }
          }
          else if (llIIIlIlllI(lIIIIllllIIllI, llllIlIII[26]))
          {
            lIIIIllllIIlIl = lIIIIlllllllll.func_175371_a(Blocks.iron_ore);
            "".length();
            if (-" ".length() == -" ".length()) {}
          }
          else if (llIIIlIlllI(lIIIIllllIIllI, llllIlIII[14]))
          {
            lIIIIllllIIlIl = lIIIIlllllllll.func_175371_a(Blocks.coal_ore);
            "".length();
            if ("   ".length() >= 0) {}
          }
          else if (llIIIllllIl(lIIIIllllIIllI, llllIlIII[25]))
          {
            lIIIIllllIIlIl = lIIIIlllllllll.func_175371_a(Blocks.stone);
            "".length();
            if (((0x7F ^ 0x40) & (0x35 ^ 0xA ^ 0xFFFFFFFF)) > -" ".length()) {}
          }
          else if (llIIIllIllI(lIIIIllllIIllI))
          {
            lIIIIllllIIlIl = lIIIIlllllllll.func_175371_a(Blocks.dirt);
            "".length();
            if (((0x48 ^ 0x2B ^ 0x3E ^ 0x6D) & (0x2F ^ 0x49 ^ 0x95 ^ 0xC3 ^ -" ".length())) >= 0) {}
          }
        }
        else
        {
          Block lIIIIllllIIlII = Blocks.bedrock;
          lIIIIllllIIlIl = lIIIIlllllllll.func_175371_a(lIIIIllllIIlII);
        }
        mc.getTextureManager().bindTexture(TextureMap.locationBlocksTexture);
        lIIIIlllllllll.drawTexturedModalRect(lIIIIllllIIlll * llllIlIII[22] - lIIIIlllllIIll, lIIIIllllIlIIl * llllIlIII[22] - lIIIIlllllIIlI, lIIIIllllIIlIl, llllIlIII[22], llllIlIII[22]);
        lIIIIllllIIlll++;
      }
      lIIIIllllIlIIl++;
    }
    GlStateManager.enableDepth();
    GlStateManager.depthFunc(llllIlIII[30]);
    mc.getTextureManager().bindTexture(ACHIEVEMENT_BACKGROUND);
    int lIIIIllllIIIll = llllIlIII[3];
    "".length();
    if (null != null) {
      return;
    }
    while (!llIIIllIIll(lIIIIllllIIIll, AchievementList.achievementList.size()))
    {
      Achievement lIIIIllllIIIlI = (Achievement)AchievementList.achievementList.get(lIIIIllllIIIll);
      if (llIIIlllllI(parentAchievement))
      {
        int lIIIIllllIIIIl = displayColumn * llllIlIII[0] - lIIIIllllllIll + llllIlIII[31];
        int lIIIIllllIIIII = displayRow * llllIlIII[0] - lIIIIllllllIlI + llllIlIII[31];
        int lIIIIlllIlllll = parentAchievement.displayColumn * llllIlIII[0] - lIIIIllllllIll + llllIlIII[31];
        int lIIIIlllIllllI = parentAchievement.displayRow * llllIlIII[0] - lIIIIllllllIlI + llllIlIII[31];
        boolean lIIIIlllIlllIl = statFileWriter.hasAchievementUnlocked(lIIIIllllIIIlI);
        boolean lIIIIlllIlllII = statFileWriter.canUnlockAchievement(lIIIIllllIIIlI);
        int lIIIIlllIllIll = statFileWriter.func_150874_c(lIIIIllllIIIlI);
        if (llIIIlllIll(lIIIIlllIllIll, llllIlIII[25]))
        {
          int lIIIIlllIllIlI = llllIlIII[32];
          if (llIIIllIIlI(lIIIIlllIlllIl))
          {
            lIIIIlllIllIlI = llllIlIII[33];
            "".length();
            if (-" ".length() < 0) {}
          }
          else if (llIIIllIIlI(lIIIIlllIlllII))
          {
            lIIIIlllIllIlI = llllIlIII[34];
          }
          lIIIIlllllllll.drawHorizontalLine(lIIIIllllIIIIl, lIIIIlllIlllll, lIIIIllllIIIII, lIIIIlllIllIlI);
          lIIIIlllllllll.drawVerticalLine(lIIIIlllIlllll, lIIIIllllIIIII, lIIIIlllIllllI, lIIIIlllIllIlI);
          if (llIIIllllIl(lIIIIllllIIIIl, lIIIIlllIlllll))
          {
            lIIIIlllllllll.drawTexturedModalRect(lIIIIllllIIIIl - llllIlIII[31] - llllIlIII[35], lIIIIllllIIIII - llllIlIII[20], llllIlIII[36], llllIlIII[37], llllIlIII[35], llllIlIII[31]);
            "".length();
            if ("   ".length() <= "   ".length()) {}
          }
          else if (llIIIllIlII(lIIIIllllIIIIl, lIIIIlllIlllll))
          {
            lIIIIlllllllll.drawTexturedModalRect(lIIIIllllIIIIl + llllIlIII[31], lIIIIllllIIIII - llllIlIII[20], llllIlIII[38], llllIlIII[37], llllIlIII[35], llllIlIII[31]);
            "".length();
            if (null == null) {}
          }
          else if (llIIIllllIl(lIIIIllllIIIII, lIIIIlllIllllI))
          {
            lIIIIlllllllll.drawTexturedModalRect(lIIIIllllIIIIl - llllIlIII[20], lIIIIllllIIIII - llllIlIII[31] - llllIlIII[35], llllIlIII[39], llllIlIII[37], llllIlIII[31], llllIlIII[35]);
            "".length();
            if ((" ".length() & (" ".length() ^ -" ".length())) == 0) {}
          }
          else if (llIIIllIlII(lIIIIllllIIIII, lIIIIlllIllllI))
          {
            lIIIIlllllllll.drawTexturedModalRect(lIIIIllllIIIIl - llllIlIII[20], lIIIIllllIIIII + llllIlIII[31], llllIlIII[39], llllIlIII[40], llllIlIII[31], llllIlIII[35]);
          }
        }
      }
      lIIIIllllIIIll++;
    }
    Achievement lIIIIlllIllIIl = null;
    float lIIIIlllIllIII = (lIIIIllllllllI - lIIIIlllllIlll) * field_146570_r;
    float lIIIIlllIlIlll = (lIIIIlllllllIl - lIIIIlllllIllI) * field_146570_r;
    RenderHelper.enableGUIStandardItemLighting();
    GlStateManager.disableLighting();
    GlStateManager.enableRescaleNormal();
    GlStateManager.enableColorMaterial();
    int lIIIIlllIlIllI = llllIlIII[3];
    "".length();
    if ("  ".length() <= 0) {
      return;
    }
    label2462:
    while (!llIIIllIIll(lIIIIlllIlIllI, AchievementList.achievementList.size()))
    {
      Achievement lIIIIlllIlIlIl = (Achievement)AchievementList.achievementList.get(lIIIIlllIlIllI);
      int lIIIIlllIlIlII = displayColumn * llllIlIII[0] - lIIIIllllllIll;
      int lIIIIlllIlIIll = displayRow * llllIlIII[0] - lIIIIllllllIlI;
      if ((llIIIllIIll(lIIIIlllIlIlII, llllIlIII[41])) && (llIIIllIIll(lIIIIlllIlIIll, llllIlIII[41])) && (llIIIllllll(llIIIlllIIl(lIIIIlllIlIlII, 224.0F * field_146570_r))) && (llIIIllllll(llIIIlllIIl(lIIIIlllIlIIll, 155.0F * field_146570_r))))
      {
        int lIIIIlllIlIIlI = statFileWriter.func_150874_c(lIIIIlllIlIlIl);
        if (llIIIllIIlI(statFileWriter.hasAchievementUnlocked(lIIIIlllIlIlIl)))
        {
          float lIIIIlllIlIIIl = 0.75F;
          GlStateManager.color(lIIIIlllIlIIIl, lIIIIlllIlIIIl, lIIIIlllIlIIIl, 1.0F);
          "".length();
          if (((6 + 18 - -3 + 105 ^ '¦' + 98 - 100 + 13) & (0x9C ^ 0x87 ^ 0x9C ^ 0xB2 ^ -" ".length())) == 0) {}
        }
        else if (llIIIllIIlI(statFileWriter.canUnlockAchievement(lIIIIlllIlIlIl)))
        {
          float lIIIIlllIlIIII = 1.0F;
          GlStateManager.color(lIIIIlllIlIIII, lIIIIlllIlIIII, lIIIIlllIlIIII, 1.0F);
          "".length();
          if (" ".length() < "   ".length()) {}
        }
        else if (llIIIllIlII(lIIIIlllIlIIlI, llllIlIII[18]))
        {
          float lIIIIlllIIllll = 0.3F;
          GlStateManager.color(lIIIIlllIIllll, lIIIIlllIIllll, lIIIIlllIIllll, 1.0F);
          "".length();
          if (((0xDE ^ 0x86) & (0x5E ^ 0x6 ^ 0xFFFFFFFF)) < "   ".length()) {}
        }
        else if (llIIIlIlllI(lIIIIlllIlIIlI, llllIlIII[18]))
        {
          float lIIIIlllIIlllI = 0.2F;
          GlStateManager.color(lIIIIlllIIlllI, lIIIIlllIIlllI, lIIIIlllIIlllI, 1.0F);
          "".length();
          if (-" ".length() == -" ".length()) {}
        }
        else
        {
          if (llIIIllllII(lIIIIlllIlIIlI, llllIlIII[25]))
          {
            "".length();
            if ((55 + 71 - -9 + 51 ^ 6 + '' - 13 + 57) > 0) {
              break label2462;
            }
            return;
          }
          float lIIIIlllIIllIl = 0.1F;
          GlStateManager.color(lIIIIlllIIllIl, lIIIIlllIIllIl, lIIIIlllIIllIl, 1.0F);
        }
        mc.getTextureManager().bindTexture(ACHIEVEMENT_BACKGROUND);
        if (llIIIllIIlI(lIIIIlllIlIlIl.getSpecial()))
        {
          lIIIIlllllllll.drawTexturedModalRect(lIIIIlllIlIlII - llllIlIII[8], lIIIIlllIlIIll - llllIlIII[8], llllIlIII[42], llllIlIII[5], llllIlIII[42], llllIlIII[42]);
          "".length();
          if ("   ".length() >= "   ".length()) {}
        }
        else
        {
          lIIIIlllllllll.drawTexturedModalRect(lIIIIlllIlIlII - llllIlIII[8], lIIIIlllIlIIll - llllIlIII[8], llllIlIII[3], llllIlIII[5], llllIlIII[42], llllIlIII[42]);
        }
        if (llIIIlIllIl(statFileWriter.canUnlockAchievement(lIIIIlllIlIlIl)))
        {
          float lIIIIlllIIllII = 0.1F;
          GlStateManager.color(lIIIIlllIIllII, lIIIIlllIIllII, lIIIIlllIIllII, 1.0F);
          itemRender.func_175039_a(llllIlIII[3]);
        }
        GlStateManager.enableLighting();
        GlStateManager.enableCull();
        itemRender.renderItemAndEffectIntoGUI(theItemStack, lIIIIlllIlIlII + llllIlIII[18], lIIIIlllIlIIll + llllIlIII[18]);
        GlStateManager.blendFunc(llllIlIII[43], llllIlIII[44]);
        GlStateManager.disableLighting();
        if (llIIIlIllIl(statFileWriter.canUnlockAchievement(lIIIIlllIlIlIl))) {
          itemRender.func_175039_a(llllIlIII[6]);
        }
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        if ((llIIIllIlll(llIIIlllIlI(lIIIIlllIllIII, lIIIIlllIlIlII))) && (llIIIllllll(llIIIlllIIl(lIIIIlllIllIII, lIIIIlllIlIlII + llllIlIII[27]))) && (llIIIllIlll(llIIIlllIlI(lIIIIlllIlIlll, lIIIIlllIlIIll))) && (llIIIllllll(llIIIlllIIl(lIIIIlllIlIlll, lIIIIlllIlIIll + llllIlIII[27])))) {
          lIIIIlllIllIIl = lIIIIlllIlIlIl;
        }
      }
      lIIIIlllIlIllI++;
    }
    GlStateManager.disableDepth();
    GlStateManager.enableBlend();
    GlStateManager.popMatrix();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(ACHIEVEMENT_BACKGROUND);
    lIIIIlllllllll.drawTexturedModalRect(lIIIIllllllIIl, lIIIIllllllIII, llllIlIII[3], llllIlIII[3], field_146555_f, field_146557_g);
    zLevel = 0.0F;
    GlStateManager.depthFunc(llllIlIII[30]);
    GlStateManager.disableDepth();
    GlStateManager.enableTexture2D();
    lIIIIlllllllll.drawScreen(lIIIIllllllllI, lIIIIlllllllIl, lIIIIlllllllII);
    if (llIIIlllllI(lIIIIlllIllIIl))
    {
      String lIIIIlllIIlIll = lIIIIlllIllIIl.getStatName().getUnformattedText();
      String lIIIIlllIIlIlI = lIIIIlllIllIIl.getDescription();
      int lIIIIlllIIlIIl = lIIIIllllllllI + llllIlIII[9];
      int lIIIIlllIIlIII = lIIIIlllllllIl - llllIlIII[25];
      int lIIIIlllIIIlll = statFileWriter.func_150874_c(lIIIIlllIllIIl);
      if (llIIIllIIlI(statFileWriter.canUnlockAchievement(lIIIIlllIllIIl)))
      {
        int lIIIIlllIIIllI = Math.max(fontRendererObj.getStringWidth(lIIIIlllIIlIll), llllIlIII[45]);
        int lIIIIlllIIIlIl = fontRendererObj.splitStringWidth(lIIIIlllIIlIlI, lIIIIlllIIIllI);
        if (llIIIllIIlI(statFileWriter.hasAchievementUnlocked(lIIIIlllIllIIl))) {
          lIIIIlllIIIlIl += 12;
        }
        lIIIIlllllllll.drawGradientRect(lIIIIlllIIlIIl - llllIlIII[18], lIIIIlllIIlIII - llllIlIII[18], lIIIIlllIIlIIl + lIIIIlllIIIllI + llllIlIII[18], lIIIIlllIIlIII + lIIIIlllIIIlIl + llllIlIII[18] + llllIlIII[9], llllIlIII[46], llllIlIII[46]);
        fontRendererObj.drawSplitString(lIIIIlllIIlIlI, lIIIIlllIIlIIl, lIIIIlllIIlIII + llllIlIII[9], lIIIIlllIIIllI, llllIlIII[33]);
        if (llIIIllIIlI(statFileWriter.hasAchievementUnlocked(lIIIIlllIllIIl)))
        {
          "".length();
          "".length();
          if ((0x12 ^ 0x79 ^ 0x4F ^ 0x21) > 0) {}
        }
      }
      else if (llIIIlIlllI(lIIIIlllIIIlll, llllIlIII[18]))
      {
        lIIIIlllIIlIll = I18n.format(llllIIlll[llllIlIII[20]], new Object[llllIlIII[3]]);
        int lIIIIlllIIIlII = Math.max(fontRendererObj.getStringWidth(lIIIIlllIIlIll), llllIlIII[45]);
        String lIIIIlllIIIIll = new ChatComponentTranslation(llllIIlll[llllIlIII[48]], new Object[] { parentAchievement.getStatName() }).getUnformattedText();
        int lIIIIlllIIIIlI = fontRendererObj.splitStringWidth(lIIIIlllIIIIll, lIIIIlllIIIlII);
        lIIIIlllllllll.drawGradientRect(lIIIIlllIIlIIl - llllIlIII[18], lIIIIlllIIlIII - llllIlIII[18], lIIIIlllIIlIIl + lIIIIlllIIIlII + llllIlIII[18], lIIIIlllIIlIII + lIIIIlllIIIIlI + llllIlIII[9] + llllIlIII[18], llllIlIII[46], llllIlIII[46]);
        fontRendererObj.drawSplitString(lIIIIlllIIIIll, lIIIIlllIIlIIl, lIIIIlllIIlIII + llllIlIII[9], lIIIIlllIIIlII, llllIlIII[49]);
        "".length();
        if (-"   ".length() < 0) {}
      }
      else if (llIIIllIlII(lIIIIlllIIIlll, llllIlIII[18]))
      {
        int lIIIIlllIIIIIl = Math.max(fontRendererObj.getStringWidth(lIIIIlllIIlIll), llllIlIII[45]);
        String lIIIIlllIIIIII = new ChatComponentTranslation(llllIIlll[llllIlIII[35]], new Object[] { parentAchievement.getStatName() }).getUnformattedText();
        int lIIIIllIllllll = fontRendererObj.splitStringWidth(lIIIIlllIIIIII, lIIIIlllIIIIIl);
        lIIIIlllllllll.drawGradientRect(lIIIIlllIIlIIl - llllIlIII[18], lIIIIlllIIlIII - llllIlIII[18], lIIIIlllIIlIIl + lIIIIlllIIIIIl + llllIlIII[18], lIIIIlllIIlIII + lIIIIllIllllll + llllIlIII[9] + llllIlIII[18], llllIlIII[46], llllIlIII[46]);
        fontRendererObj.drawSplitString(lIIIIlllIIIIII, lIIIIlllIIlIIl, lIIIIlllIIlIII + llllIlIII[9], lIIIIlllIIIIIl, llllIlIII[49]);
        "".length();
        if ("   ".length() >= ((0x6A ^ 0xD ^ 0x40 ^ 0x31) & (0xEC ^ 0xAD ^ 0x51 ^ 0x6 ^ -" ".length()))) {}
      }
      else
      {
        lIIIIlllIIlIll = null;
      }
      if (llIIIlllllI(lIIIIlllIIlIll))
      {
        if (llIIIllIIlI(statFileWriter.canUnlockAchievement(lIIIIlllIllIIl)))
        {
          if (llIIIllIIlI(lIIIIlllIllIIl.getSpecial()))
          {
            "".length();
            if (-" ".length() == -" ".length()) {}
          }
          else
          {
            "".length();
            if ((0xEB ^ 0x8C ^ 0xD2 ^ 0xB1) > 0) {}
          }
        }
        else if (llIIIllIIlI(lIIIIlllIllIIl.getSpecial()))
        {
          "".length();
          if (((0xB7 ^ 0x91) & (0x13 ^ 0x35 ^ 0xFFFFFFFF)) <= "  ".length()) {
            break label3492;
          }
        }
        label3492:
        "".length();
      }
    }
    GlStateManager.enableDepth();
    GlStateManager.enableLighting();
    RenderHelper.disableStandardItemLighting();
  }
  
  public boolean doesGuiPauseGame()
  {
    ;
    if (llIIIllIIlI(loadingAchievements))
    {
      "".length();
      if ((0x13 ^ 0x3 ^ 0xB7 ^ 0xA3) > " ".length()) {
        break label100;
      }
      return (0x90 ^ 0xC0 ^ (0x50 ^ 0x1B) & (0xC0 ^ 0x8B ^ 0xFFFFFFFF)) & (0xA ^ 0x5A ^ (0x51 ^ 0x4D) & (0xBD ^ 0xA1 ^ 0xFFFFFFFF) ^ -" ".length());
    }
    label100:
    return llllIlIII[6];
  }
  
  public GuiAchievements(GuiScreen lIIIlIIlllllll, StatFileWriter lIIIlIlIIIIIll)
  {
    parentScreen = lIIIlIlIIIIlII;
    statFileWriter = lIIIlIlIIIIIll;
    int lIIIlIlIIIIIlI = llllIlIII[7];
    int lIIIlIlIIIIIIl = llllIlIII[7];
    field_146569_s = (lIIIlIlIIIIIII.field_146567_u = lIIIlIlIIIIIII.field_146565_w = openInventorydisplayColumn * llllIlIII[0] - lIIIlIlIIIIIlI / llllIlIII[8] - llllIlIII[9]);
    field_146568_t = (lIIIlIlIIIIIII.field_146566_v = lIIIlIlIIIIIII.field_146573_x = openInventorydisplayRow * llllIlIII[0] - lIIIlIlIIIIIIl / llllIlIII[8]);
  }
  
  private static void llIIIlIllII()
  {
    llllIlIII = new int[54];
    llllIlIII[0] = (0 + 95 - -8 + 29 ^ 109 + '' - 195 + 113);
    llllIlIII[1] = (104 + 112 - 8 + 11 ^ 83 + 16 - 28 + 100);
    llllIlIII[2] = (0xE5 ^ 0xA8);
    llllIlIII[3] = (('°' + '' - 266 + 185 ^ 105 + 115 - 164 + 114) & (0x62 ^ 0x12 ^ 0x18 ^ 0x22 ^ -" ".length()));
    llllIlIII[4] = (-(0xFFFFFFAB & 0x7AD7) & 0xFBB7 & 0x7FCA);
    llllIlIII[5] = ((0x67 ^ 0x76) + (0x29 ^ 0x14) - -(0x6A ^ 0x7D) + (0xD9 ^ 0xBC));
    llllIlIII[6] = " ".length();
    llllIlIII[7] = (34 + 64 - 65 + 108);
    llllIlIII[8] = "  ".length();
    llllIlIII[9] = (0x3D ^ 0x31);
    llllIlIII[10] = (76 + '­' - 72 + 42 ^ 113 + 61 - 100 + 71);
    llllIlIII[11] = (0x4D ^ 0x1D);
    llllIlIII[12] = (0xF3 ^ 0xC5 ^ 0x6E ^ 0x4C);
    llllIlIII[13] = (0xFFFFFFFF & 0xFFFFFF);
    llllIlIII[14] = (0xC4 ^ 0x82 ^ 0xE1 ^ 0xAF);
    llllIlIII[15] = (0x12 ^ 0x3);
    llllIlIII[16] = (120 + 63 - 181 + 222);
    llllIlIII[17] = (15 + 46 - 27 + 121);
    llllIlIII[18] = "   ".length();
    llllIlIII[19] = ("   ".length() ^ 0x84 ^ 0x88);
    llllIlIII[20] = (0xD9 ^ 0x9B ^ 0x49 ^ 0xE);
    llllIlIII[21] = (0xE6F1 & 0x40594E);
    llllIlIII[22] = (0x9D ^ 0x8D);
    llllIlIII[23] = (-(0xBFFB & 0x7435) & 0xB77E & 0x7EB7);
    llllIlIII[24] = (0xAFEB & 0x5134);
    llllIlIII[25] = (0x29 ^ 0x16 ^ 0x11 ^ 0x2A);
    llllIlIII[26] = (0x0 ^ 0x76 ^ 0x45 ^ 0x39);
    llllIlIII[27] = (0xA1 ^ 0xB7);
    llllIlIII[28] = (0xB8 ^ 0xBF ^ 0xB3 ^ 0x91);
    llllIlIII[29] = (0x9F ^ 0x95 ^ 0x95 ^ 0xBC);
    llllIlIII[30] = (0xE75B & 0x1AA7);
    llllIlIII[31] = (0x4C ^ 0x47);
    llllIlIII[32] = (-(-(0xFFFFFFFF & 0x35E5) & 0xBDE6 & 0x10077FD));
    llllIlIII[33] = (-(0xDF71 & 0x5F7FEE));
    llllIlIII[34] = (-(0x8B7D & 0xFF7582));
    llllIlIII[35] = (0xA7 ^ 0xA0);
    llllIlIII[36] = (0x77 ^ 0x72 ^ 0x5B ^ 0x2C);
    llllIlIII[37] = (30 + 112 - -79 + 13);
    llllIlIII[38] = (0x15 ^ 0xE ^ 0x1F ^ 0x6F);
    llllIlIII[39] = (0x78 ^ 0x18);
    llllIlIII[40] = (51 + '' - 178 + 220);
    llllIlIII[41] = (-(0x23 ^ 0x3B));
    llllIlIII[42] = ('¨' + 39 - 50 + 13 ^ 48 + 118 - 37 + 47);
    llllIlIII[43] = (-(0xF963 & 0x76FE) & 0xFFFFFFF3 & 0x736F);
    llllIlIII[44] = (0x874B & 0x7BB7);
    llllIlIII[45] = (0x3F ^ 0x47);
    llllIlIII[46] = (-(0xA1DD & 0x40005E22));
    llllIlIII[47] = (-(-(0x44 ^ 0x5D) & 0xFFFFFFDB & 0x6F6F3D));
    llllIlIII[48] = (0xC1 ^ 0xC7);
    llllIlIII[49] = (-(-(0xFFFFFFCC & 0x407F) & 0xFFFFFFFF & 0x8FEFFB));
    llllIlIII[50] = (-(37 + 50 - 25 + 66));
    llllIlIII[51] = (-" ".length());
    llllIlIII[52] = (-(-(0x76 ^ 0x40) & 0xFFFFFFF5 & 0x7F7FFF));
    llllIlIII[53] = (-(0xFFFFFF9C & 0x7F7FE3));
  }
  
  public void drawScreen(int lIIIlIIlIIlllI, int lIIIlIIlIlllII, float lIIIlIIlIIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIIllIIlI(loadingAchievements))
    {
      lIIIlIIlIllllI.drawDefaultBackground();
      lIIIlIIlIllllI.drawCenteredString(fontRendererObj, I18n.format(llllIIlll[llllIlIII[8]], new Object[llllIlIII[3]]), width / llllIlIII[8], height / llllIlIII[8], llllIlIII[13]);
      lIIIlIIlIllllI.drawCenteredString(fontRendererObj, lanSearchStates[((int)(Minecraft.getSystemTime() / 150L % lanSearchStates.length))], width / llllIlIII[8], height / llllIlIII[8] + fontRendererObj.FONT_HEIGHT * llllIlIII[8], llllIlIII[13]);
      "".length();
      if (-"  ".length() < 0) {}
    }
    else
    {
      if (llIIIllIIlI(Mouse.isButtonDown(llllIlIII[3])))
      {
        int lIIIlIIlIllIlI = (width - field_146555_f) / llllIlIII[8];
        int lIIIlIIlIllIIl = (height - field_146557_g) / llllIlIII[8];
        int lIIIlIIlIllIII = lIIIlIIlIllIlI + llllIlIII[14];
        int lIIIlIIlIlIlll = lIIIlIIlIllIIl + llllIlIII[15];
        if (((!llIIIllIIlI(field_146554_D)) || (llIIIlIlllI(field_146554_D, llllIlIII[6]))) && (llIIIllIIll(lIIIlIIlIIlllI, lIIIlIIlIllIII)) && (llIIIllIlII(lIIIlIIlIIlllI, lIIIlIIlIllIII + llllIlIII[16])) && (llIIIllIIll(lIIIlIIlIlllII, lIIIlIIlIlIlll)) && (llIIIllIlII(lIIIlIIlIlllII, lIIIlIIlIlIlll + llllIlIII[17])))
        {
          if (llIIIlIllIl(field_146554_D))
          {
            field_146554_D = llllIlIII[6];
            "".length();
            if (" ".length() > -" ".length()) {}
          }
          else
          {
            field_146567_u -= (lIIIlIIlIIlllI - field_146563_h) * field_146570_r;
            field_146566_v -= (lIIIlIIlIlllII - field_146564_i) * field_146570_r;
            field_146565_w = (lIIIlIIlIllllI.field_146569_s = field_146567_u);
            field_146573_x = (lIIIlIIlIllllI.field_146568_t = field_146566_v);
          }
          field_146563_h = lIIIlIIlIIlllI;
          field_146564_i = lIIIlIIlIlllII;
          "".length();
          if (-" ".length() <= " ".length()) {}
        }
      }
      else
      {
        field_146554_D = llllIlIII[3];
      }
      int lIIIlIIlIlIllI = Mouse.getDWheel();
      float lIIIlIIlIlIlIl = field_146570_r;
      if (llIIIllIlIl(lIIIlIIlIlIllI))
      {
        field_146570_r += 0.25F;
        "".length();
        if (-" ".length() <= " ".length()) {}
      }
      else if (llIIIllIllI(lIIIlIIlIlIllI))
      {
        field_146570_r -= 0.25F;
      }
      field_146570_r = MathHelper.clamp_float(field_146570_r, 1.0F, 2.0F);
      if (llIIIllIIlI(llIIIlIllll(field_146570_r, lIIIlIIlIlIlIl)))
      {
        float lIIIlIIlIlIlII = lIIIlIIlIlIlIl - field_146570_r;
        float lIIIlIIlIlIIll = lIIIlIIlIlIlIl * field_146555_f;
        float lIIIlIIlIlIIlI = lIIIlIIlIlIlIl * field_146557_g;
        float lIIIlIIlIlIIIl = field_146570_r * field_146555_f;
        float lIIIlIIlIlIIII = field_146570_r * field_146557_g;
        field_146567_u -= (lIIIlIIlIlIIIl - lIIIlIIlIlIIll) * 0.5F;
        field_146566_v -= (lIIIlIIlIlIIII - lIIIlIIlIlIIlI) * 0.5F;
        field_146565_w = (lIIIlIIlIllllI.field_146569_s = field_146567_u);
        field_146573_x = (lIIIlIIlIllllI.field_146568_t = field_146566_v);
      }
      if (llIIIllIlIl(llIIIllIIII(field_146565_w, field_146572_y))) {
        field_146565_w = field_146572_y;
      }
      if (llIIIllIlIl(llIIIllIIII(field_146573_x, field_146571_z))) {
        field_146573_x = field_146571_z;
      }
      if (llIIIllIlll(llIIIllIIIl(field_146565_w, field_146559_A))) {
        field_146565_w = (field_146559_A - llllIlIII[6]);
      }
      if (llIIIllIlll(llIIIllIIIl(field_146573_x, field_146560_B))) {
        field_146573_x = (field_146560_B - llllIlIII[6]);
      }
      lIIIlIIlIllllI.drawDefaultBackground();
      lIIIlIIlIllllI.drawAchievementScreen(lIIIlIIlIIlllI, lIIIlIIlIlllII, lIIIlIIlIIllII);
      GlStateManager.disableLighting();
      GlStateManager.disableDepth();
      lIIIlIIlIllllI.drawTitle();
      GlStateManager.enableLighting();
      GlStateManager.enableDepth();
    }
  }
  
  private static boolean llIIIlllIll(int ???, int arg1)
  {
    int i;
    String lIIIIlIlIlIlIl;
    return ??? <= i;
  }
  
  private static boolean llIIIllllII(int ???, int arg1)
  {
    int i;
    Exception lIIIIlIIllllll;
    return ??? != i;
  }
  
  private static boolean llIIIlIllIl(int ???)
  {
    Exception lIIIIlIlIIlIll;
    return ??? == 0;
  }
  
  protected void actionPerformed(GuiButton lIIIlIIlllIIll)
    throws IOException
  {
    ;
    ;
    if ((llIIIlIllIl(loadingAchievements)) && (llIIIlIlllI(id, llllIlIII[6]))) {
      mc.displayGuiScreen(parentScreen);
    }
  }
  
  private static boolean llIIIllIIlI(int ???)
  {
    float lIIIIlIlIIllIl;
    return ??? != 0;
  }
  
  private static boolean llIIIllIlll(int ???)
  {
    boolean lIIIIlIlIIlIIl;
    return ??? >= 0;
  }
  
  private static int llIIIlllIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static int llIIIllIIIl(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static void llIIIlIlIll()
  {
    llllIIlll = new String[llllIlIII[14]];
    llllIIlll[llllIlIII[3]] = llIIIlIlIII("8je2lbPMrkWkskM4WZB4+s0o/Ys9WqsECKgyjV/tfHuwRYdGHT9Zj1ImMhgjvhU6XKknuufjhy0=", "LdPOb");
    llllIIlll[llllIlIII[6]] = llIIIlIlIIl("15NNF0hp7s/GAQnAdeoZUg==", "wbEPV");
    llllIIlll[llllIlIII[8]] = llIIIlIlIII("JlkfXPCcwuf69eDPlpSXGO7xSN1JI2YnYbCV3+ogZ7E=", "esUYS");
    llllIIlll[llllIlIII[18]] = llIIIlIlIIl("AEXqbHXpJItKq28f9/WJfuetsTeh3+9G", "GSkPJ");
    llllIIlll[llllIlIII[25]] = llIIIlIlIIl("2hv9Nu8LeMtyOb2wbj4P+7i7+8t7gE6p", "vbPLa");
    llllIIlll[llllIlIII[20]] = llIIIlIlIlI("GAwlAj0PCiAONg1BOAUzFwA6BQ==", "yoMkX");
    llllIIlll[llllIlIII[48]] = llIIIlIlIIl("zUI4TN6dMAJb74AKFz+up+4lEE4AegSo", "yMENQ");
    llllIIlll[llllIlIII[35]] = llIIIlIlIIl("vp3MuTMi7abOzNxIalUevvF0rQG0vNtp", "jzJts");
  }
  
  private TextureAtlasSprite func_175371_a(Block lIIIIllIIllIlI)
  {
    ;
    return Minecraft.getMinecraft().getBlockRendererDispatcher().getBlockModelShapes().getTexture(lIIIIllIIllIll.getDefaultState());
  }
  
  private static boolean llIIIllIlIl(int ???)
  {
    short lIIIIlIlIIIlll;
    return ??? < 0;
  }
  
  private static String llIIIlIlIII(String lIIIIlIllIlIII, String lIIIIlIllIIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIIIlIllIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIIIIlIllIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIIIIlIllIllII = Cipher.getInstance("Blowfish");
      lIIIIlIllIllII.init(llllIlIII[8], lIIIIlIllIllIl);
      return new String(lIIIIlIllIllII.doFinal(Base64.getDecoder().decode(lIIIIlIllIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIIIlIllIlIll)
    {
      lIIIIlIllIlIll.printStackTrace();
    }
    return null;
  }
  
  public void updateScreen()
  {
    ;
    ;
    ;
    if (llIIIlIllIl(loadingAchievements))
    {
      field_146569_s = field_146567_u;
      field_146568_t = field_146566_v;
      double lIIIlIIIllllIl = field_146565_w - field_146567_u;
      double lIIIlIIIllllII = field_146573_x - field_146566_v;
      if (llIIIllIlIl(llIIIlllIII(lIIIlIIIllllIl * lIIIlIIIllllIl + lIIIlIIIllllII * lIIIlIIIllllII, 4.0D)))
      {
        field_146567_u += lIIIlIIIllllIl;
        field_146566_v += lIIIlIIIllllII;
        "".length();
        if ((0x34 ^ 0x43 ^ 0x37 ^ 0x45) != 0) {}
      }
      else
      {
        field_146567_u += lIIIlIIIllllIl * 0.85D;
        field_146566_v += lIIIlIIIllllII * 0.85D;
      }
    }
  }
  
  public void initGui()
  {
    ;
    mc.getNetHandler().addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.REQUEST_STATS));
    buttonList.clear();
    new GuiOptionButton(llllIlIII[6], width / llllIlIII[8] + llllIlIII[0], height / llllIlIII[8] + llllIlIII[10], llllIlIII[11], llllIlIII[12], I18n.format(llllIIlll[llllIlIII[6]], new Object[llllIlIII[3]]));
    "".length();
  }
  
  private static int llIIIlIllll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  static
  {
    llIIIlIllII();
    llIIIlIlIll();
    field_146572_y = AchievementList.minDisplayColumn * llllIlIII[0] - llllIlIII[1];
    field_146571_z = AchievementList.minDisplayRow * llllIlIII[0] - llllIlIII[1];
    field_146559_A = AchievementList.maxDisplayColumn * llllIlIII[0] - llllIlIII[2];
  }
  
  private static boolean llIIIllllll(int ???)
  {
    boolean lIIIIlIlIIIlIl;
    return ??? <= 0;
  }
  
  private static boolean llIIIllIllI(int ???)
  {
    Exception lIIIIlIlIIIIll;
    return ??? > 0;
  }
  
  private static int llIIIlllIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static String llIIIlIlIIl(String lIIIIllIIIllIl, String lIIIIllIIIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIIIllIIlIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIIIIllIIIllII.getBytes(StandardCharsets.UTF_8)), llllIlIII[14]), "DES");
      Cipher lIIIIllIIlIIIl = Cipher.getInstance("DES");
      lIIIIllIIlIIIl.init(llllIlIII[8], lIIIIllIIlIIlI);
      return new String(lIIIIllIIlIIIl.doFinal(Base64.getDecoder().decode(lIIIIllIIIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIIIllIIlIIII)
    {
      lIIIIllIIlIIII.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIIIllllIl(int ???, int arg1)
  {
    int i;
    float lIIIIlIlIlIIIl;
    return ??? > i;
  }
  
  private static boolean llIIIllIIll(int ???, int arg1)
  {
    int i;
    long lIIIIlIlIlllIl;
    return ??? >= i;
  }
  
  private static boolean llIIIlIlllI(int ???, int arg1)
  {
    int i;
    byte lIIIIlIllIIIIl;
    return ??? == i;
  }
  
  private static int llIIIlllIII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean llIIIlllllI(Object ???)
  {
    float lIIIIlIlIIllll;
    return ??? != null;
  }
}

package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import org.lwjgl.input.Keyboard;

public class GuiScreenServerList
  extends GuiScreen
{
  private static boolean lllIIIlIlIlllI(int ???, int arg1)
  {
    int i;
    long llllllllllllllIIllllllIllIIlllll;
    return ??? != i;
  }
  
  public void updateScreen()
  {
    ;
    field_146302_g.updateCursorCounter();
  }
  
  protected void keyTyped(char llllllllllllllIIllllllIlllllllll, int llllllllllllllIIllllllIllllllIll)
    throws IOException
  {
    ;
    ;
    ;
    if (lllIIIlIlIlIll(field_146302_g.textboxKeyTyped(llllllllllllllIIllllllIlllllllII, llllllllllllllIIllllllIllllllIll)))
    {
      if ((lllIIIlIlIlIlI(field_146302_g.getText().length())) && (lllIIIlIlIlIlI(field_146302_g.getText().split(lIIlIlIIlIIlI[lIIlIlIIlllII[12]]).length)))
      {
        "".length();
        if (-"  ".length() <= 0) {
          break label101;
        }
      }
      label101:
      lIIlIlIIlllII0enabled = lIIlIlIIlllII[1];
      "".length();
      if (null == null) {}
    }
    else if ((!lllIIIlIlIlllI(llllllllllllllIIllllllIllllllIll, lIIlIlIIlllII[13])) || (lllIIIlIlIllII(llllllllllllllIIllllllIllllllIll, lIIlIlIIlllII[14])))
    {
      llllllllllllllIIlllllllIIIIIIIII.actionPerformed((GuiButton)buttonList.get(lIIlIlIIlllII[1]));
    }
  }
  
  private static boolean lllIIIlIlIllll(int ???, int arg1)
  {
    int i;
    short llllllllllllllIIllllllIllIlIlIIl;
    return ??? < i;
  }
  
  private static void lllIIIlIlIIIIl()
  {
    lIIlIlIIlIIlI = new String[lIIlIlIIlllII[18]];
    lIIlIlIIlIIlI[lIIlIlIIlllII[1]] = lllIIIlIIlIIlI("7aDuKMrHcK+RM3r7haKVlvHquj/MiOpk", "vEvCh");
    lIIlIlIIlIIlI[lIIlIlIIlllII[0]] = lllIIIlIIlIIll("4YogxaKMq+ZxYzAxSzEmMA==", "zwrWK");
    lIIlIlIIlIIlI[lIIlIlIIlllII[2]] = lllIIIlIIlIIlI("6Pw9OngdUs8=", "lMIfh");
    lIIlIlIIlIIlI[lIIlIlIIlllII[12]] = lllIIIlIIlIIll("TfL+zrUFkkY=", "vjYfl");
    lIIlIlIIlIIlI[lIIlIlIIlllII[4]] = lllIIIlIIlllll("OSgKEQI+HgMGFy8/SBAIOCgFAA==", "JMfta");
    lIIlIlIIlIIlI[lIIlIlIIlllII[16]] = lllIIIlIIlIIlI("xbenpEPO5Mh4FlQdt23yP27HGj+D0hhr", "EfuGU");
  }
  
  public void onGuiClosed()
  {
    ;
    Keyboard.enableRepeatEvents(lIIlIlIIlllII[1]);
    mc.gameSettings.lastServer = field_146302_g.getText();
    mc.gameSettings.saveOptions();
  }
  
  static
  {
    lllIIIlIlIlIIl();
    lllIIIlIlIIIIl();
  }
  
  public GuiScreenServerList(GuiScreen llllllllllllllIIlllllllIIIIlIlII, ServerData llllllllllllllIIlllllllIIIIlIIll)
  {
    field_146303_a = llllllllllllllIIlllllllIIIIlIlll;
    field_146301_f = llllllllllllllIIlllllllIIIIlIIll;
  }
  
  public void drawScreen(int llllllllllllllIIllllllIllllIIlIl, int llllllllllllllIIllllllIllllIIlII, float llllllllllllllIIllllllIllllIIlll)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIIllllllIllllIIllI.drawDefaultBackground();
    llllllllllllllIIllllllIllllIIllI.drawCenteredString(fontRendererObj, I18n.format(lIIlIlIIlIIlI[lIIlIlIIlllII[4]], new Object[lIIlIlIIlllII[1]]), width / lIIlIlIIlllII[2], lIIlIlIIlllII[10], lIIlIlIIlllII[15]);
    llllllllllllllIIllllllIllllIIllI.drawString(fontRendererObj, I18n.format(lIIlIlIIlIIlI[lIIlIlIIlllII[16]], new Object[lIIlIlIIlllII[1]]), width / lIIlIlIIlllII[2] - lIIlIlIIlllII[3], lIIlIlIIlllII[3], lIIlIlIIlllII[17]);
    field_146302_g.drawTextBox();
    llllllllllllllIIllllllIllllIIllI.drawScreen(llllllllllllllIIllllllIllllIIlIl, llllllllllllllIIllllllIllllIIlII, llllllllllllllIIllllllIllllIIlll);
  }
  
  private static boolean lllIIIlIlIlIlI(int ???)
  {
    short llllllllllllllIIllllllIllIlIIIll;
    return ??? > 0;
  }
  
  private static boolean lllIIIlIlIlIll(int ???)
  {
    short llllllllllllllIIllllllIllIlIIlll;
    return ??? != 0;
  }
  
  private static String lllIIIlIIlIIll(String llllllllllllllIIllllllIlllIllIll, String llllllllllllllIIllllllIlllIllIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllllllIlllIllllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllllllIlllIllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIIllllllIlllIlllIl = Cipher.getInstance("Blowfish");
      llllllllllllllIIllllllIlllIlllIl.init(lIIlIlIIlllII[2], llllllllllllllIIllllllIlllIllllI);
      return new String(llllllllllllllIIllllllIlllIlllIl.doFinal(Base64.getDecoder().decode(llllllllllllllIIllllllIlllIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllllllIlllIlllII)
    {
      llllllllllllllIIllllllIlllIlllII.printStackTrace();
    }
    return null;
  }
  
  private static String lllIIIlIIlllll(String llllllllllllllIIllllllIllIlllIIl, String llllllllllllllIIllllllIllIlllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllllllIllIlllIIl = new String(Base64.getDecoder().decode(llllllllllllllIIllllllIllIlllIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIllllllIllIllllII = new StringBuilder();
    char[] llllllllllllllIIllllllIllIlllIll = llllllllllllllIIllllllIllIlllIII.toCharArray();
    int llllllllllllllIIllllllIllIlllIlI = lIIlIlIIlllII[1];
    int llllllllllllllIIllllllIllIllIlII = llllllllllllllIIllllllIllIlllIIl.toCharArray();
    byte llllllllllllllIIllllllIllIllIIll = llllllllllllllIIllllllIllIllIlII.length;
    boolean llllllllllllllIIllllllIllIllIIlI = lIIlIlIIlllII[1];
    while (lllIIIlIlIllll(llllllllllllllIIllllllIllIllIIlI, llllllllllllllIIllllllIllIllIIll))
    {
      char llllllllllllllIIllllllIllIllllll = llllllllllllllIIllllllIllIllIlII[llllllllllllllIIllllllIllIllIIlI];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIllllllIllIllllII);
  }
  
  protected void mouseClicked(int llllllllllllllIIllllllIlllllIlIl, int llllllllllllllIIllllllIlllllIlII, int llllllllllllllIIllllllIlllllIIll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    llllllllllllllIIllllllIlllllIIlI.mouseClicked(llllllllllllllIIllllllIlllllIlIl, llllllllllllllIIllllllIlllllIlII, llllllllllllllIIllllllIlllllIIll);
    field_146302_g.mouseClicked(llllllllllllllIIllllllIlllllIlIl, llllllllllllllIIllllllIlllllIlII, llllllllllllllIIllllllIlllllIIll);
  }
  
  private static String lllIIIlIIlIIlI(String llllllllllllllIIllllllIlllIIllII, String llllllllllllllIIllllllIlllIIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllllllIlllIlIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllllllIlllIIlIll.getBytes(StandardCharsets.UTF_8)), lIIlIlIIlllII[19]), "DES");
      Cipher llllllllllllllIIllllllIlllIlIIII = Cipher.getInstance("DES");
      llllllllllllllIIllllllIlllIlIIII.init(lIIlIlIIlllII[2], llllllllllllllIIllllllIlllIlIIIl);
      return new String(llllllllllllllIIllllllIlllIlIIII.doFinal(Base64.getDecoder().decode(llllllllllllllIIllllllIlllIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllllllIlllIIllll)
    {
      llllllllllllllIIllllllIlllIIllll.printStackTrace();
    }
    return null;
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIIlllllllIIIIIIllI)
    throws IOException
  {
    ;
    ;
    if (lllIIIlIlIlIll(enabled)) {
      if (lllIIIlIlIllII(id, lIIlIlIIlllII[0]))
      {
        field_146303_a.confirmClicked(lIIlIlIIlllII[1], lIIlIlIIlllII[1]);
        "".length();
        if ((0x27 ^ 0x6E ^ 0x89 ^ 0xC4) > 0) {}
      }
      else if (lllIIIlIlIllIl(id))
      {
        field_146301_f.serverIP = field_146302_g.getText();
        field_146303_a.confirmClicked(lIIlIlIIlllII[0], lIIlIlIIlllII[1]);
      }
    }
  }
  
  public void initGui()
  {
    ;
    Keyboard.enableRepeatEvents(lIIlIlIIlllII[0]);
    buttonList.clear();
    new GuiButton(lIIlIlIIlllII[1], width / lIIlIlIIlllII[2] - lIIlIlIIlllII[3], height / lIIlIlIIlllII[4] + lIIlIlIIlllII[5] + lIIlIlIIlllII[6], I18n.format(lIIlIlIIlIIlI[lIIlIlIIlllII[1]], new Object[lIIlIlIIlllII[1]]));
    "".length();
    new GuiButton(lIIlIlIIlllII[0], width / lIIlIlIIlllII[2] - lIIlIlIIlllII[3], height / lIIlIlIIlllII[4] + lIIlIlIIlllII[7] + lIIlIlIIlllII[6], I18n.format(lIIlIlIIlIIlI[lIIlIlIIlllII[0]], new Object[lIIlIlIIlllII[1]]));
    "".length();
    field_146302_g = new GuiTextField(lIIlIlIIlllII[2], fontRendererObj, width / lIIlIlIIlllII[2] - lIIlIlIIlllII[3], lIIlIlIIlllII[8], lIIlIlIIlllII[9], lIIlIlIIlllII[10]);
    field_146302_g.setMaxStringLength(lIIlIlIIlllII[11]);
    field_146302_g.setFocused(lIIlIlIIlllII[0]);
    field_146302_g.setText(mc.gameSettings.lastServer);
    if ((lllIIIlIlIlIlI(field_146302_g.getText().length())) && (lllIIIlIlIlIlI(field_146302_g.getText().split(lIIlIlIIlIIlI[lIIlIlIIlllII[2]]).length)))
    {
      "".length();
      if ("   ".length() == "   ".length()) {
        break label377;
      }
    }
    label377:
    lIIlIlIIlllII0enabled = lIIlIlIIlllII[1];
  }
  
  private static boolean lllIIIlIlIllII(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIIllllllIllIlIllIl;
    return ??? == i;
  }
  
  private static boolean lllIIIlIlIllIl(int ???)
  {
    char llllllllllllllIIllllllIllIlIIlIl;
    return ??? == 0;
  }
  
  private static void lllIIIlIlIlIIl()
  {
    lIIlIlIIlllII = new int[20];
    lIIlIlIIlllII[0] = " ".length();
    lIIlIlIIlllII[1] = ((0x93 ^ 0x9D ^ 0x4F ^ 0x78) & (0x35 ^ 0x23 ^ 0x5 ^ 0x2A ^ -" ".length()));
    lIIlIlIIlllII[2] = "  ".length();
    lIIlIlIIlllII[3] = (0x41 ^ 0x25);
    lIIlIlIIlllII[4] = (0x1E ^ 0x1A);
    lIIlIlIIlllII[5] = (0xEE ^ 0x8E);
    lIIlIlIIlllII[6] = (105 + '£' - 254 + 165 ^ 94 + 126 - 131 + 102);
    lIIlIlIIlllII[7] = (0x5D ^ 0x25);
    lIIlIlIIlllII[8] = (0x44 ^ 0xD ^ 0x14 ^ 0x29);
    lIIlIlIIlllII[9] = (85 + 13 - -14 + 88);
    lIIlIlIIlllII[10] = (0xBF ^ 0xAB);
    lIIlIlIIlllII[11] = ((0xF ^ 0x5F) + (98 + 101 - 74 + 2) - (45 + '' - 38 + 37) + (0x2E ^ 0x71));
    lIIlIlIIlllII[12] = "   ".length();
    lIIlIlIIlllII[13] = (0x7E ^ 0x62);
    lIIlIlIIlllII[14] = (64 + 6 - -57 + 29);
    lIIlIlIIlllII[15] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIIlIlIIlllII[16] = (47 + 46 - 50 + 103 ^ 31 + 29 - 2 + 93);
    lIIlIlIIlllII[17] = (-(0xEBDF & 0x1D76) & 0xEDF7 & 0xA0BBFD);
    lIIlIlIIlllII[18] = (0x30 ^ 0x36);
    lIIlIlIIlllII[19] = (0x3 ^ 0xB);
  }
}

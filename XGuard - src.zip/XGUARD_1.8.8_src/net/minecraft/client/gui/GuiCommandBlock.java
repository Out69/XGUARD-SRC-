package net.minecraft.client.gui;

import io.netty.buffer.Unpooled;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.resources.I18n;
import net.minecraft.command.server.CommandBlockLogic;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.util.IChatComponent;
import org.lwjgl.input.Keyboard;

public class GuiCommandBlock
  extends GuiScreen
{
  private static boolean lIIlIlIIlIlIl(int ???, int arg1)
  {
    int i;
    String llllllllllllllllIllIIllllIIIlIIl;
    return ??? < i;
  }
  
  private static boolean lIIlIlIIlIIII(int ???)
  {
    float llllllllllllllllIllIIllllIIIIlIl;
    return ??? != 0;
  }
  
  protected void mouseClicked(int llllllllllllllllIllIIlllllIllllI, int llllllllllllllllIllIIlllllIlllIl, int llllllllllllllllIllIIlllllIllIII)
    throws IOException
  {
    ;
    ;
    ;
    ;
    llllllllllllllllIllIIlllllIlllll.mouseClicked(llllllllllllllllIllIIlllllIllllI, llllllllllllllllIllIIlllllIlllIl, llllllllllllllllIllIIlllllIllIII);
    commandTextField.mouseClicked(llllllllllllllllIllIIlllllIllllI, llllllllllllllllIllIIlllllIlllIl, llllllllllllllllIllIIlllllIllIII);
    previousOutputTextField.mouseClicked(llllllllllllllllIllIIlllllIllllI, llllllllllllllllIllIIlllllIlllIl, llllllllllllllllIllIIlllllIllIII);
  }
  
  protected void actionPerformed(GuiButton llllllllllllllllIllIIllllllIlllI)
    throws IOException
  {
    ;
    ;
    ;
    if (lIIlIlIIlIIII(enabled)) {
      if (lIIlIlIIlIIIl(id, llIIIIIIllI[0]))
      {
        localCommandBlock.setTrackOutput(field_175389_t);
        mc.displayGuiScreen(null);
        "".length();
        if (-(0x8D ^ 0x89) < 0) {}
      }
      else if (lIIlIlIIlIIlI(id))
      {
        PacketBuffer llllllllllllllllIllIIlllllllIIII = new PacketBuffer(Unpooled.buffer());
        "".length();
        localCommandBlock.func_145757_a(llllllllllllllllIllIIlllllllIIII);
        "".length();
        "".length();
        mc.getNetHandler().addToSendQueue(new C17PacketCustomPayload(llIIIIIIIIl[llIIIIIIllI[3]], llllllllllllllllIllIIlllllllIIII));
        if (lIIlIlIIlIIlI(localCommandBlock.shouldTrackOutput())) {
          localCommandBlock.setLastOutput(null);
        }
        mc.displayGuiScreen(null);
        "".length();
        if (" ".length() == " ".length()) {}
      }
      else if (lIIlIlIIlIIIl(id, llIIIIIIllI[3]))
      {
        if (lIIlIlIIlIIII(localCommandBlock.shouldTrackOutput()))
        {
          "".length();
          if (" ".length() == " ".length()) {
            break label280;
          }
        }
        label280:
        llIIIIIIllI[1].setTrackOutput(llIIIIIIllI[0]);
        llllllllllllllllIllIIlllllllIIlI.func_175388_a();
      }
    }
  }
  
  private static boolean lIIlIlIIlIIlI(int ???)
  {
    char llllllllllllllllIllIIllllIIIIIll;
    return ??? == 0;
  }
  
  private static boolean lIIlIlIIlIIIl(int ???, int arg1)
  {
    int i;
    String llllllllllllllllIllIIllllIIIllIl;
    return ??? == i;
  }
  
  static
  {
    lIIlIlIIIlllI();
    lIIlIlIIIIIII();
  }
  
  private static String lIIlIIlllllII(String llllllllllllllllIllIIllllIIlIllI, String llllllllllllllllIllIIllllIIlIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIllIIllllIIllIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllIIllllIIlIIll.getBytes(StandardCharsets.UTF_8)), llIIIIIIllI[22]), "DES");
      Cipher llllllllllllllllIllIIllllIIllIII = Cipher.getInstance("DES");
      llllllllllllllllIllIIllllIIllIII.init(llIIIIIIllI[2], llllllllllllllllIllIIllllIIllIIl);
      return new String(llllllllllllllllIllIIllllIIllIII.doFinal(Base64.getDecoder().decode(llllllllllllllllIllIIllllIIlIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIllIIllllIIlIlll)
    {
      llllllllllllllllIllIIllllIIlIlll.printStackTrace();
    }
    return null;
  }
  
  public void updateScreen()
  {
    ;
    commandTextField.updateCursorCounter();
  }
  
  private static String lIIlIIllllllI(String llllllllllllllllIllIIllllIlllIll, String llllllllllllllllIllIIllllIlllIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIllIIllllIlllllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllIIllllIlllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIllIIllllIllllIl = Cipher.getInstance("Blowfish");
      llllllllllllllllIllIIllllIllllIl.init(llIIIIIIllI[2], llllllllllllllllIllIIllllIlllllI);
      return new String(llllllllllllllllIllIIllllIllllIl.doFinal(Base64.getDecoder().decode(llllllllllllllllIllIIllllIlllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIllIIllllIllllII)
    {
      llllllllllllllllIllIIllllIllllII.printStackTrace();
    }
    return null;
  }
  
  protected void keyTyped(char llllllllllllllllIllIIllllllIlIII, int llllllllllllllllIllIIllllllIIlll)
    throws IOException
  {
    ;
    ;
    ;
    "".length();
    "".length();
    if (lIIlIlIIIllll(commandTextField.getText().trim().length()))
    {
      "".length();
      if (" ".length() != 0) {
        break label78;
      }
    }
    label78:
    llIIIIIIllI0enabled = llIIIIIIllI[1];
    if ((lIIlIlIIlIIll(llllllllllllllllIllIIllllllIIlll, llIIIIIIllI[13])) && (lIIlIlIIlIIll(llllllllllllllllIllIIllllllIIlll, llIIIIIIllI[14])))
    {
      if (lIIlIlIIlIIIl(llllllllllllllllIllIIllllllIIlll, llIIIIIIllI[0]))
      {
        llllllllllllllllIllIIllllllIlIIl.actionPerformed(cancelBtn);
        "".length();
        if (" ".length() > 0) {}
      }
    }
    else {
      llllllllllllllllIllIIllllllIlIIl.actionPerformed(doneBtn);
    }
  }
  
  private static boolean lIIlIlIIlIIll(int ???, int arg1)
  {
    int i;
    char llllllllllllllllIllIIlllIlllllIl;
    return ??? != i;
  }
  
  private static String lIIlIIlllllll(String llllllllllllllllIllIIllllIlIlIll, String llllllllllllllllIllIIllllIlIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIllIIllllIlIlIll = new String(Base64.getDecoder().decode(llllllllllllllllIllIIllllIlIlIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIllIIllllIlIlIIl = new StringBuilder();
    char[] llllllllllllllllIllIIllllIlIlIII = llllllllllllllllIllIIllllIlIIlIl.toCharArray();
    int llllllllllllllllIllIIllllIlIIlll = llIIIIIIllI[1];
    double llllllllllllllllIllIIllllIlIIIIl = llllllllllllllllIllIIllllIlIlIll.toCharArray();
    long llllllllllllllllIllIIllllIlIIIII = llllllllllllllllIllIIllllIlIIIIl.length;
    String llllllllllllllllIllIIllllIIlllll = llIIIIIIllI[1];
    while (lIIlIlIIlIlIl(llllllllllllllllIllIIllllIIlllll, llllllllllllllllIllIIllllIlIIIII))
    {
      char llllllllllllllllIllIIllllIlIllII = llllllllllllllllIllIIllllIlIIIIl[llllllllllllllllIllIIllllIIlllll];
      "".length();
      "".length();
      if (" ".length() <= 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIllIIllllIlIlIIl);
  }
  
  public void initGui()
  {
    ;
    Keyboard.enableRepeatEvents(llIIIIIIllI[0]);
    buttonList.clear();
    doneBtn = new GuiButton(llIIIIIIllI[1], width / llIIIIIIllI[2] - llIIIIIIllI[3] - llIIIIIIllI[4], height / llIIIIIIllI[3] + llIIIIIIllI[5] + llIIIIIIllI[6], llIIIIIIllI[4], llIIIIIIllI[7], I18n.format(llIIIIIIIIl[llIIIIIIllI[1]], new Object[llIIIIIIllI[1]]));
    "".length();
    cancelBtn = new GuiButton(llIIIIIIllI[0], width / llIIIIIIllI[2] + llIIIIIIllI[3], height / llIIIIIIllI[3] + llIIIIIIllI[5] + llIIIIIIllI[6], llIIIIIIllI[4], llIIIIIIllI[7], I18n.format(llIIIIIIIIl[llIIIIIIllI[0]], new Object[llIIIIIIllI[1]]));
    "".length();
    field_175390_s = new GuiButton(llIIIIIIllI[3], width / llIIIIIIllI[2] + llIIIIIIllI[4] - llIIIIIIllI[7], llIIIIIIllI[4], llIIIIIIllI[7], llIIIIIIllI[7], llIIIIIIIIl[llIIIIIIllI[2]]);
    "".length();
    commandTextField = new GuiTextField(llIIIIIIllI[2], fontRendererObj, width / llIIIIIIllI[2] - llIIIIIIllI[4], llIIIIIIllI[8], llIIIIIIllI[9], llIIIIIIllI[7]);
    commandTextField.setMaxStringLength(llIIIIIIllI[10]);
    commandTextField.setFocused(llIIIIIIllI[0]);
    commandTextField.setText(localCommandBlock.getCommand());
    previousOutputTextField = new GuiTextField(llIIIIIIllI[11], fontRendererObj, width / llIIIIIIllI[2] - llIIIIIIllI[4], llIIIIIIllI[4], llIIIIIIllI[12], llIIIIIIllI[7]);
    previousOutputTextField.setMaxStringLength(llIIIIIIllI[10]);
    previousOutputTextField.setEnabled(llIIIIIIllI[1]);
    previousOutputTextField.setText(llIIIIIIIIl[llIIIIIIllI[11]]);
    field_175389_t = localCommandBlock.shouldTrackOutput();
    llllllllllllllllIllIIllllllllIII.func_175388_a();
    if (lIIlIlIIIllll(commandTextField.getText().trim().length()))
    {
      "".length();
      if ((0x36 ^ 0x32) != 0) {
        break label560;
      }
    }
    label560:
    llIIIIIIllI0enabled = llIIIIIIllI[1];
  }
  
  public GuiCommandBlock(CommandBlockLogic llllllllllllllllIllIIlllllllllll)
  {
    localCommandBlock = llllllllllllllllIllIIlllllllllll;
  }
  
  public void onGuiClosed()
  {
    Keyboard.enableRepeatEvents(llIIIIIIllI[1]);
  }
  
  private static void lIIlIlIIIlllI()
  {
    llIIIIIIllI = new int[30];
    llIIIIIIllI[0] = " ".length();
    llIIIIIIllI[1] = ((0x5F ^ 0x1C) & (0xC8 ^ 0x8B ^ 0xFFFFFFFF));
    llIIIIIIllI[2] = "  ".length();
    llIIIIIIllI[3] = (0x70 ^ 0x44 ^ 0x20 ^ 0x10);
    llIIIIIIllI[4] = ((0xC3 ^ 0x9B) + (66 + 69 - 126 + 119) - (43 + 115 - 40 + 27) + (0x3A ^ 0x75));
    llIIIIIIllI[5] = ('ë' + 'Ó' - 407 + 207 ^ 122 + 68 - 107 + 59);
    llIIIIIIllI[6] = (0x6D ^ 0x61);
    llIIIIIIllI[7] = ('' + '' - 143 + 44 ^ 13 + 94 - -3 + 83);
    llIIIIIIllI[8] = (0x24 ^ 0x0 ^ 0x9 ^ 0x1F);
    llIIIIIIllI[9] = (-(0x8ED6 & 0x7D7D) & 0x8D7F & 0x7FFF);
    llIIIIIIllI[10] = (0xFFFFFFFF & 0x7FFF);
    llIIIIIIllI[11] = "   ".length();
    llIIIIIIllI[12] = (-(0xDFEB & 0x7695) & 0xDFBE & 0x77D5);
    llIIIIIIllI[13] = (0x80 ^ 0x9C);
    llIIIIIIllI[14] = ((0x3A ^ 0x55) + (0x9F ^ 0x86) - -"   ".length() + (0xB8 ^ 0xA9));
    llIIIIIIllI[15] = (0xA3 ^ 0x81 ^ 0x61 ^ 0x46);
    llIIIIIIllI[16] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    llIIIIIIllI[17] = (0x45 ^ 0x43);
    llIIIIIIllI[18] = (0xA6 ^ 0x83);
    llIIIIIIllI[19] = (0xBDF8 & 0xA0E2A7);
    llIIIIIIllI[20] = (15 + 96 - -30 + 2 ^ 56 + 44 - 94 + 190);
    llIIIIIIllI[21] = (0x9A ^ 0x9D);
    llIIIIIIllI[22] = (0x87 ^ 0x8B ^ 0x83 ^ 0x87);
    llIIIIIIllI[23] = (0xA4 ^ 0xAD);
    llIIIIIIllI[24] = (33 + 4 - 29 + 154 ^ '' + 110 - 228 + 137);
    llIIIIIIllI[25] = (0xDA ^ 0x96 ^ 0xC5 ^ 0x82);
    llIIIIIIllI[26] = (0x99 ^ 0x89);
    llIIIIIIllI[27] = (0x7C ^ 0x71);
    llIIIIIIllI[28] = (0xB4 ^ 0xBA);
    llIIIIIIllI[29] = (0xB4 ^ 0xB9 ^ "  ".length());
  }
  
  public void drawScreen(int llllllllllllllllIllIIlllllIlIIII, int llllllllllllllllIllIIlllllIIlIIl, float llllllllllllllllIllIIlllllIIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIllIIlllllIIlIll.drawDefaultBackground();
    llllllllllllllllIllIIlllllIIlIll.drawCenteredString(fontRendererObj, I18n.format(llIIIIIIIIl[llIIIIIIllI[15]], new Object[llIIIIIIllI[1]]), width / llIIIIIIllI[2], llIIIIIIllI[7], llIIIIIIllI[16]);
    llllllllllllllllIllIIlllllIIlIll.drawString(fontRendererObj, I18n.format(llIIIIIIIIl[llIIIIIIllI[17]], new Object[llIIIIIIllI[1]]), width / llIIIIIIllI[2] - llIIIIIIllI[4], llIIIIIIllI[18], llIIIIIIllI[19]);
    commandTextField.drawTextBox();
    int llllllllllllllllIllIIlllllIIllIl = llIIIIIIllI[20];
    int llllllllllllllllIllIIlllllIIllII = llIIIIIIllI[1];
    llllllllllllllllIllIIlllllIIlIll.drawString(fontRendererObj, I18n.format(llIIIIIIIIl[llIIIIIIllI[21]], new Object[llIIIIIIllI[1]]), width / llIIIIIIllI[2] - llIIIIIIllI[4], llllllllllllllllIllIIlllllIIllIl + llllllllllllllllIllIIlllllIIllII++ * fontRendererObj.FONT_HEIGHT, llIIIIIIllI[19]);
    llllllllllllllllIllIIlllllIIlIll.drawString(fontRendererObj, I18n.format(llIIIIIIIIl[llIIIIIIllI[22]], new Object[llIIIIIIllI[1]]), width / llIIIIIIllI[2] - llIIIIIIllI[4], llllllllllllllllIllIIlllllIIllIl + llllllllllllllllIllIIlllllIIllII++ * fontRendererObj.FONT_HEIGHT, llIIIIIIllI[19]);
    llllllllllllllllIllIIlllllIIlIll.drawString(fontRendererObj, I18n.format(llIIIIIIIIl[llIIIIIIllI[23]], new Object[llIIIIIIllI[1]]), width / llIIIIIIllI[2] - llIIIIIIllI[4], llllllllllllllllIllIIlllllIIllIl + llllllllllllllllIllIIlllllIIllII++ * fontRendererObj.FONT_HEIGHT, llIIIIIIllI[19]);
    llllllllllllllllIllIIlllllIIlIll.drawString(fontRendererObj, I18n.format(llIIIIIIIIl[llIIIIIIllI[24]], new Object[llIIIIIIllI[1]]), width / llIIIIIIllI[2] - llIIIIIIllI[4], llllllllllllllllIllIIlllllIIllIl + llllllllllllllllIllIIlllllIIllII++ * fontRendererObj.FONT_HEIGHT, llIIIIIIllI[19]);
    llllllllllllllllIllIIlllllIIlIll.drawString(fontRendererObj, llIIIIIIIIl[llIIIIIIllI[25]], width / llIIIIIIllI[2] - llIIIIIIllI[4], llllllllllllllllIllIIlllllIIllIl + llllllllllllllllIllIIlllllIIllII++ * fontRendererObj.FONT_HEIGHT, llIIIIIIllI[19]);
    if (lIIlIlIIIllll(previousOutputTextField.getText().length()))
    {
      llllllllllllllllIllIIlllllIIllIl = llllllllllllllllIllIIlllllIIllIl + llllllllllllllllIllIIlllllIIllII * fontRendererObj.FONT_HEIGHT + llIIIIIIllI[26];
      llllllllllllllllIllIIlllllIIlIll.drawString(fontRendererObj, I18n.format(llIIIIIIIIl[llIIIIIIllI[6]], new Object[llIIIIIIllI[1]]), width / llIIIIIIllI[2] - llIIIIIIllI[4], llllllllllllllllIllIIlllllIIllIl, llIIIIIIllI[19]);
      previousOutputTextField.drawTextBox();
    }
    llllllllllllllllIllIIlllllIIlIll.drawScreen(llllllllllllllllIllIIlllllIlIIII, llllllllllllllllIllIIlllllIIlIIl, llllllllllllllllIllIIlllllIIlIII);
  }
  
  private static void lIIlIlIIIIIII()
  {
    llIIIIIIIIl = new String[llIIIIIIllI[26]];
    llIIIIIIIIl[llIIIIIIllI[1]] = lIIlIIlllllII("Zbm5ZgCaCwGlm1NLpgJv1w==", "KjYhF");
    llIIIIIIIIl[llIIIIIIllI[0]] = lIIlIIlllllII("XkdxaMtWGBK1pjj/eBmKmA==", "rLvkD");
    llIIIIIIIIl[llIIIIIIllI[2]] = lIIlIIllllllI("Gw/H0yIaFEM=", "haVfD");
    llIIIIIIIIl[llIIIIIIllI[11]] = lIIlIIlllllII("8nuLkCkzE/w=", "uvgJg");
    llIIIIIIIIl[llIIIIIIllI[3]] = lIIlIIlllllII("52L06XpUcJBJPSA06rGMYQ==", "SqIFN");
    llIIIIIIIIl[llIIIIIIllI[15]] = lIIlIIllllllI("slgwjrkCNqOSlbjQ2wbcOcePU29OZCHK", "aAjyR");
    llIIIIIIIIl[llIIIIIIllI[17]] = lIIlIIlllllII("0kL54Ow6gK5UTuQnS8iElw==", "AgYiD");
    llIIIIIIIIl[llIIIIIIllI[21]] = lIIlIIllllllI("9LMx/wM13OygyCQ72qfNfncq8U5wf/aX", "CgZvn");
    llIIIIIIIIl[llIIIIIIllI[22]] = lIIlIIlllllII("QREZF8f9kA/FSi9iCu3LvRMcLhW8ArMo", "aJips");
    llIIIIIIIIl[llIIIIIIllI[23]] = lIIlIIllllllI("gYukPyvz0CnRCCufGWNe0H7d3T/fxEBX", "tFGNA");
    llIIIIIIIIl[llIIIIIIllI[24]] = lIIlIIllllllI("lL7viTUP1B+0tTx7e7CrCpB3n+Jpv2oL", "eyUvG");
    llIIIIIIIIl[llIIIIIIllI[25]] = lIIlIIlllllII("/fdC8Y9cRx0=", "GQXTe");
    llIIIIIIIIl[llIIIIIIllI[6]] = lIIlIIlllllll("NAMnLAQxAn8RGTAROA4eJigkFRsgEw==", "UgQak");
    llIIIIIIIIl[llIIIIIIllI[27]] = lIIlIIllllllI("8Xby10IOmuM=", "IzPat");
    llIIIIIIIIl[llIIIIIIllI[28]] = lIIlIIlllllII("PuAl5auApw0=", "slDvU");
    llIIIIIIIIl[llIIIIIIllI[29]] = lIIlIIlllllll("aA==", "ETeVs");
  }
  
  private static boolean lIIlIlIIIllll(int ???)
  {
    Exception llllllllllllllllIllIIllllIIIIIIl;
    return ??? > 0;
  }
  
  private static boolean lIIlIlIIlIlII(Object ???)
  {
    int llllllllllllllllIllIIllllIIIIlll;
    return ??? != null;
  }
  
  private void func_175388_a()
  {
    ;
    if (lIIlIlIIlIIII(localCommandBlock.shouldTrackOutput()))
    {
      field_175390_s.displayString = llIIIIIIIIl[llIIIIIIllI[27]];
      if (lIIlIlIIlIlII(localCommandBlock.getLastOutput()))
      {
        previousOutputTextField.setText(localCommandBlock.getLastOutput().getUnformattedText());
        "".length();
        if (((0xE8 ^ 0xA0) & (0xD ^ 0x45 ^ 0xFFFFFFFF)) == 0) {}
      }
    }
    else
    {
      field_175390_s.displayString = llIIIIIIIIl[llIIIIIIllI[28]];
      previousOutputTextField.setText(llIIIIIIIIl[llIIIIIIllI[29]]);
    }
  }
}

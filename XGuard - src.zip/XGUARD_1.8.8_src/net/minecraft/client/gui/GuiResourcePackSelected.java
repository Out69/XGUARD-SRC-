package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.ResourcePackListEntry;

public class GuiResourcePackSelected
  extends GuiResourcePackList
{
  public GuiResourcePackSelected(Minecraft llllllllllllllllIlllllIlIlIlllIl, int llllllllllllllllIlllllIlIlIlllII, int llllllllllllllllIlllllIlIlIllIll, List<ResourcePackListEntry> llllllllllllllllIlllllIlIlIllIlI)
  {
    llllllllllllllllIlllllIlIlIllllI.<init>(llllllllllllllllIlllllIlIlIlllIl, llllllllllllllllIlllllIlIlIlIlll, llllllllllllllllIlllllIlIlIllIll, llllllllllllllllIlllllIlIlIllIlI);
  }
  
  private static void lIIIlIIlIIIll()
  {
    lIllIIlIlll = new int[3];
    lIllIIlIlll[0] = ((0x4 ^ 0x57) & (0xD2 ^ 0x81 ^ 0xFFFFFFFF));
    lIllIIlIlll[1] = " ".length();
    lIllIIlIlll[2] = "  ".length();
  }
  
  protected String getListHeader()
  {
    return I18n.format(lIllIIlIIll[lIllIIlIlll[0]], new Object[lIllIIlIlll[0]]);
  }
  
  static
  {
    lIIIlIIlIIIll();
    lIIIlIIlIIIIl();
  }
  
  private static String lIIIlIIIlllll(String llllllllllllllllIlllllIlIlIIllII, String llllllllllllllllIlllllIlIlIIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIlllllIlIlIIllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlllllIlIlIIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIlllllIlIlIIlllI = Cipher.getInstance("Blowfish");
      llllllllllllllllIlllllIlIlIIlllI.init(lIllIIlIlll[2], llllllllllllllllIlllllIlIlIIllll);
      return new String(llllllllllllllllIlllllIlIlIIlllI.doFinal(Base64.getDecoder().decode(llllllllllllllllIlllllIlIlIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIlllllIlIlIIllIl)
    {
      llllllllllllllllIlllllIlIlIIllIl.printStackTrace();
    }
    return null;
  }
  
  private static void lIIIlIIlIIIIl()
  {
    lIllIIlIIll = new String[lIllIIlIlll[1]];
    lIllIIlIIll[lIllIIlIlll[0]] = lIIIlIIIlllll("Mg1ums8yrqUGNgVLtOfwRoZrmjYES+kJWI3Nfi9bXnQ=", "fQIDk");
  }
}

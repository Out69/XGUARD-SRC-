package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;

public abstract class GuiListExtended
  extends GuiSlot
{
  public boolean mouseReleased(int llllllllllllllIlIIIIIIlIIlIIIIIl, int llllllllllllllIlIIIIIIlIIlIIIIII, int llllllllllllllIlIIIIIIlIIIllllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIIIIIIlIIIlllllI = lIIlIIllllllI[0];
    "".length();
    if (null != null) {
      return (0x73 ^ 0x59) & (0xBD ^ 0x97 ^ 0xFFFFFFFF);
    }
    while (!lllIIIIlllIlIl(llllllllllllllIlIIIIIIlIIIlllllI, llllllllllllllIlIIIIIIlIIlIIIIlI.getSize()))
    {
      int llllllllllllllIlIIIIIIlIIIllllIl = left + width / lIIlIIllllllI[2] - llllllllllllllIlIIIIIIlIIlIIIIlI.getListWidth() / lIIlIIllllllI[2] + lIIlIIllllllI[2];
      int llllllllllllllIlIIIIIIlIIIllllII = top + lIIlIIllllllI[3] - llllllllllllllIlIIIIIIlIIlIIIIlI.getAmountScrolled() + llllllllllllllIlIIIIIIlIIIlllllI * slotHeight + headerPadding;
      int llllllllllllllIlIIIIIIlIIIlllIll = llllllllllllllIlIIIIIIlIIlIIIIIl - llllllllllllllIlIIIIIIlIIIllllIl;
      int llllllllllllllIlIIIIIIlIIIlllIlI = llllllllllllllIlIIIIIIlIIlIIIIII - llllllllllllllIlIIIIIIlIIIllllII;
      llllllllllllllIlIIIIIIlIIlIIIIlI.getListEntry(llllllllllllllIlIIIIIIlIIIlllllI).mouseReleased(llllllllllllllIlIIIIIIlIIIlllllI, llllllllllllllIlIIIIIIlIIlIIIIIl, llllllllllllllIlIIIIIIlIIlIIIIII, llllllllllllllIlIIIIIIlIIIllllll, llllllllllllllIlIIIIIIlIIIlllIll, llllllllllllllIlIIIIIIlIIIlllIlI);
      llllllllllllllIlIIIIIIlIIIlllllI++;
    }
    llllllllllllllIlIIIIIIlIIlIIIIlI.setEnabled(lIIlIIllllllI[1]);
    return lIIlIIllllllI[0];
  }
  
  protected void func_178040_a(int llllllllllllllIlIIIIIIlIIllIllII, int llllllllllllllIlIIIIIIlIIllIlIll, int llllllllllllllIlIIIIIIlIIllIlIlI)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIlIIIIIIlIIlllIIIl.getListEntry(llllllllllllllIlIIIIIIlIIllIllII).setSelected(llllllllllllllIlIIIIIIlIIllIllII, llllllllllllllIlIIIIIIlIIllIlIll, llllllllllllllIlIIIIIIlIIllIlIlI);
  }
  
  static {}
  
  private static boolean lllIIIIlllIlII(int ???)
  {
    int llllllllllllllIlIIIIIIlIIIlIIlIl;
    return ??? >= 0;
  }
  
  private static boolean lllIIIIlllIIlI(int ???, int arg1)
  {
    int i;
    long llllllllllllllIlIIIIIIlIIIlIllIl;
    return ??? == i;
  }
  
  private static boolean lllIIIIlllIlIl(int ???, int arg1)
  {
    int i;
    short llllllllllllllIlIIIIIIlIIIlIlIIl;
    return ??? >= i;
  }
  
  public abstract IGuiListEntry getListEntry(int paramInt);
  
  protected boolean isSelected(int llllllllllllllIlIIIIIIlIlIIIllII)
  {
    return lIIlIIllllllI[0];
  }
  
  private static boolean lllIIIIlllIIll(int ???)
  {
    long llllllllllllllIlIIIIIIlIIIlIIlll;
    return ??? != 0;
  }
  
  private static void lllIIIIlllIIIl()
  {
    lIIlIIllllllI = new int[4];
    lIIlIIllllllI[0] = ((0x0 ^ 0x30) & (0x12 ^ 0x22 ^ 0xFFFFFFFF));
    lIIlIIllllllI[1] = " ".length();
    lIIlIIllllllI[2] = "  ".length();
    lIIlIIllllllI[3] = (107 + '©' - 273 + 168 ^ 100 + '' - 161 + 100);
  }
  
  public GuiListExtended(Minecraft llllllllllllllIlIIIIIIlIlIIlllll, int llllllllllllllIlIIIIIIlIlIIlIlll, int llllllllllllllIlIIIIIIlIlIIlllIl, int llllllllllllllIlIIIIIIlIlIIlIlIl, int llllllllllllllIlIIIIIIlIlIIllIll, int llllllllllllllIlIIIIIIlIlIIlIIll)
  {
    llllllllllllllIlIIIIIIlIlIIllIIl.<init>(llllllllllllllIlIIIIIIlIlIIlllll, llllllllllllllIlIIIIIIlIlIIlIlll, llllllllllllllIlIIIIIIlIlIIlIllI, llllllllllllllIlIIIIIIlIlIIlIlIl, llllllllllllllIlIIIIIIlIlIIllIll, llllllllllllllIlIIIIIIlIlIIlIIll);
  }
  
  protected void drawSlot(int llllllllllllllIlIIIIIIlIlIIIIIlI, int llllllllllllllIlIIIIIIlIlIIIIIIl, int llllllllllllllIlIIIIIIlIlIIIIIII, int llllllllllllllIlIIIIIIlIIlllllll, int llllllllllllllIlIIIIIIlIIlllIlll, int llllllllllllllIlIIIIIIlIIlllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIIIlllIIlI(llllllllllllllIlIIIIIIlIIlllllII.getSlotIndexFromScreenCoords(llllllllllllllIlIIIIIIlIIlllIlll, llllllllllllllIlIIIIIIlIIlllIllI), llllllllllllllIlIIIIIIlIlIIIIIlI))
    {
      "".length();
      if ("   ".length() > ((0x9E ^ 0xB4) & (0xAE ^ 0x84 ^ 0xFFFFFFFF))) {
        break label75;
      }
    }
    label75:
    llllllllllllllIlIIIIIIlIlIIIIIlI.drawEntry(llllllllllllllIlIIIIIIlIlIIIIIIl, llllllllllllllIlIIIIIIlIIllllIIl, llllllllllllllIlIIIIIIlIIlllllII.getListWidth(), llllllllllllllIlIIIIIIlIIlllllll, llllllllllllllIlIIIIIIlIIlllIlll, llllllllllllllIlIIIIIIlIIlllIllI, lIIlIIllllllI[1], lIIlIIllllllI[0]);
  }
  
  protected void drawBackground() {}
  
  public boolean mouseClicked(int llllllllllllllIlIIIIIIlIIlIlIIll, int llllllllllllllIlIIIIIIlIIlIllllI, int llllllllllllllIlIIIIIIlIIlIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIIIlllIIll(llllllllllllllIlIIIIIIlIIlIlIlII.isMouseYWithinSlotBounds(llllllllllllllIlIIIIIIlIIlIllllI)))
    {
      int llllllllllllllIlIIIIIIlIIlIllIll = llllllllllllllIlIIIIIIlIIlIlIlII.getSlotIndexFromScreenCoords(llllllllllllllIlIIIIIIlIIlIlIIll, llllllllllllllIlIIIIIIlIIlIllllI);
      if (lllIIIIlllIlII(llllllllllllllIlIIIIIIlIIlIllIll))
      {
        int llllllllllllllIlIIIIIIlIIlIllIlI = left + width / lIIlIIllllllI[2] - llllllllllllllIlIIIIIIlIIlIlIlII.getListWidth() / lIIlIIllllllI[2] + lIIlIIllllllI[2];
        int llllllllllllllIlIIIIIIlIIlIllIII = top + lIIlIIllllllI[3] - llllllllllllllIlIIIIIIlIIlIlIlII.getAmountScrolled() + llllllllllllllIlIIIIIIlIIlIllIll * slotHeight + headerPadding;
        int llllllllllllllIlIIIIIIlIIlIlIllI = llllllllllllllIlIIIIIIlIIlIlIIll - llllllllllllllIlIIIIIIlIIlIllIlI;
        int llllllllllllllIlIIIIIIlIIlIlIlIl = llllllllllllllIlIIIIIIlIIlIllllI - llllllllllllllIlIIIIIIlIIlIllIII;
        if (lllIIIIlllIIll(llllllllllllllIlIIIIIIlIIlIlIlII.getListEntry(llllllllllllllIlIIIIIIlIIlIllIll).mousePressed(llllllllllllllIlIIIIIIlIIlIllIll, llllllllllllllIlIIIIIIlIIlIlIIll, llllllllllllllIlIIIIIIlIIlIllllI, llllllllllllllIlIIIIIIlIIlIlIIIl, llllllllllllllIlIIIIIIlIIlIlIllI, llllllllllllllIlIIIIIIlIIlIlIlIl)))
        {
          llllllllllllllIlIIIIIIlIIlIlIlII.setEnabled(lIIlIIllllllI[0]);
          return lIIlIIllllllI[1];
        }
      }
    }
    return lIIlIIllllllI[0];
  }
  
  protected void elementClicked(int llllllllllllllIlIIIIIIlIlIIlIIIl, boolean llllllllllllllIlIIIIIIlIlIIlIIII, int llllllllllllllIlIIIIIIlIlIIIllll, int llllllllllllllIlIIIIIIlIlIIIlllI) {}
  
  public static abstract interface IGuiListEntry
  {
    public abstract void drawEntry(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean);
    
    public abstract void setSelected(int paramInt1, int paramInt2, int paramInt3);
    
    public abstract void mouseReleased(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
    
    public abstract boolean mousePressed(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  }
}

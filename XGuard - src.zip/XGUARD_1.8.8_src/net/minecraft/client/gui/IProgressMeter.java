package net.minecraft.client.gui;

public abstract interface IProgressMeter
{
  public abstract void doneLoading();
}

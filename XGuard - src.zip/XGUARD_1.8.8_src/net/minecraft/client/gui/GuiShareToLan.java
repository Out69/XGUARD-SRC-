package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.WorldSettings.GameType;

public class GuiShareToLan
  extends GuiScreen
{
  private static boolean lIIIIIllIllIl(int ???, int arg1)
  {
    int i;
    long lllllllllllllllllIIIlIIIIIlIllll;
    return ??? < i;
  }
  
  private static boolean lIIIIIllIlIlI(int ???, int arg1)
  {
    int i;
    int lllllllllllllllllIIIlIIIIIllIIll;
    return ??? == i;
  }
  
  private static String lIIIIIlIlIllI(String lllllllllllllllllIIIlIIIIIlllIlI, String lllllllllllllllllIIIlIIIIIlllIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIIlIIIIIllllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIlIIIIIlllIIl.getBytes(StandardCharsets.UTF_8)), lIlIlIlIlII[17]), "DES");
      Cipher lllllllllllllllllIIIlIIIIIlllllI = Cipher.getInstance("DES");
      lllllllllllllllllIIIlIIIIIlllllI.init(lIlIlIlIlII[2], lllllllllllllllllIIIlIIIIIllllll);
      return new String(lllllllllllllllllIIIlIIIIIlllllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIlIIIIIlllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIIlIIIIIllllIl)
    {
      lllllllllllllllllIIIlIIIIIllllIl.printStackTrace();
    }
    return null;
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllllIIIlIIIIlllllII)
    throws IOException
  {
    ;
    ;
    ;
    ;
    if (lIIIIIllIlIlI(id, lIlIlIlIlII[8]))
    {
      mc.displayGuiScreen(field_146598_a);
      "".length();
      if (null == null) {}
    }
    else if (lIIIIIllIlIlI(id, lIlIlIlIlII[10]))
    {
      if (lIIIIIllIlIII(field_146599_h.equals(lIlIlIlIIII[lIlIlIlIlII[21]])))
      {
        field_146599_h = lIlIlIlIIII[lIlIlIlIlII[22]];
        "".length();
        if ("   ".length() > ((0x5D ^ 0x47) & (0x1F ^ 0x5 ^ 0xFFFFFFFF))) {}
      }
      else if (lIIIIIllIlIII(field_146599_h.equals(lIlIlIlIIII[lIlIlIlIlII[23]])))
      {
        field_146599_h = lIlIlIlIIII[lIlIlIlIlII[24]];
        "".length();
        if (-(0x10 ^ 0x14) < 0) {}
      }
      else if (lIIIIIllIlIII(field_146599_h.equals(lIlIlIlIIII[lIlIlIlIlII[25]])))
      {
        field_146599_h = lIlIlIlIIII[lIlIlIlIlII[26]];
        "".length();
        if (-"   ".length() < 0) {}
      }
      else
      {
        field_146599_h = lIlIlIlIIII[lIlIlIlIlII[27]];
      }
      lllllllllllllllllIIIlIIIIllllIII.func_146595_g();
      "".length();
      if (null == null) {}
    }
    else if (lIIIIIllIlIlI(id, lIlIlIlIlII[13]))
    {
      if (lIIIIIllIlIII(field_146600_i))
      {
        "".length();
        if ("   ".length() <= "   ".length()) {
          break label311;
        }
      }
      label311:
      lIlIlIlIlII0field_146600_i = lIlIlIlIlII[7];
      lllllllllllllllllIIIlIIIIllllIII.func_146595_g();
      "".length();
      if ("   ".length() > -" ".length()) {}
    }
    else if (lIIIIIllIlIlI(id, lIlIlIlIlII[1]))
    {
      mc.displayGuiScreen(null);
      String lllllllllllllllllIIIlIIIIllllIll = mc.getIntegratedServer().shareToLAN(WorldSettings.GameType.getByName(field_146599_h), field_146600_i);
      IChatComponent lllllllllllllllllIIIlIIIIllllIIl;
      if (lIIIIIllIllII(lllllllllllllllllIIIlIIIIllllIll))
      {
        IChatComponent lllllllllllllllllIIIlIIIIllllIlI = new ChatComponentTranslation(lIlIlIlIIII[lIlIlIlIlII[28]], new Object[] { lllllllllllllllllIIIlIIIIllllIll });
        "".length();
        if (" ".length() != 0) {}
      }
      else
      {
        lllllllllllllllllIIIlIIIIllllIIl = new ChatComponentText(lIlIlIlIIII[lIlIlIlIlII[6]]);
      }
      mc.ingameGUI.getChatGUI().printChatMessage(lllllllllllllllllIIIlIIIIllllIIl);
    }
  }
  
  private static void lIIIIIllIIlIl()
  {
    lIlIlIlIIII = new String[lIlIlIlIlII[34]];
    lIlIlIlIIII[lIlIlIlIlII[0]] = lIIIIIlIlIllI("oMHB2c/FftaECFvZqy89tQ==", "DODFK");
    lIlIlIlIIII[lIlIlIlIlII[7]] = lIIIIIlIlIllI("Ksi5MaWRYSlmDdyyv/BrPg==", "VeCRm");
    lIlIlIlIIII[lIlIlIlIlII[2]] = lIIIIIlIlIlll("ewY+HYB7FaDCOADplONfrw==", "PKZPr");
    lIlIlIlIIII[lIlIlIlIlII[12]] = lIIIIIlIllIlI("HAIdPywbMB4oIwtJFjsiCioePio=", "ogqZO");
    lIlIlIlIIII[lIlIlIlIlII[14]] = lIIIIIlIlIllI("/GQJKhpSXFU2WTtLyBEij95/8R4tdwwSPqIHziuUrZ4=", "zpvLX");
    lIlIlIlIIII[lIlIlIlIlII[9]] = lIIIIIlIllIlI("OCM8FyU/ET8AKi9oNxMrLgs/FiM=", "KFPrF");
    lIlIlIlIIII[lIlIlIlIlII[15]] = lIIIIIlIlIllI("DqAL/QYvAZw=", "OXiZH");
    lIlIlIlIIII[lIlIlIlIlII[16]] = lIIIIIlIlIllI("J/f9CscS9PyrWbjiLyKnexbu8Ex3ec+u", "tsnVE");
    lIlIlIlIIII[lIlIlIlIlII[17]] = lIIIIIlIlIllI("Ge5Lxa/6ZJYIi7wbMC3i/CoT1mJSJVBMKNczZ4pVUcQ=", "rIAqR");
    lIlIlIlIIII[lIlIlIlIlII[18]] = lIIIIIlIlIllI("Gn28zUwis9g=", "eNxBK");
    lIlIlIlIIII[lIlIlIlIlII[19]] = lIIIIIlIlIllI("cTzpAyMwUmHbWK7R9Y/Eug==", "ATKNl");
    lIlIlIlIIII[lIlIlIlIlII[20]] = lIIIIIlIlIllI("uiXEaRUoCQyVaRx9GHkMTg==", "cXVOq");
    lIlIlIlIIII[lIlIlIlIlII[21]] = lIIIIIlIlIllI("I47vkqDSROtnDjeqYehgCQ==", "uRflI");
    lIlIlIlIIII[lIlIlIlIlII[22]] = lIIIIIlIlIllI("08UMrIFWbIx95Su8hK2b7w==", "qRxhO");
    lIlIlIlIIII[lIlIlIlIlII[23]] = lIIIIIlIlIlll("aP7b3Y+RFxKrZUaiT/rNnA==", "RFdLA");
    lIlIlIlIIII[lIlIlIlIlII[24]] = lIIIIIlIllIlI("Mic9NCwnNjk0", "SCKQB");
    lIlIlIlIIII[lIlIlIlIlII[25]] = lIIIIIlIllIlI("JiElMikzMCEy", "GESWG");
    lIlIlIlIIII[lIlIlIlIlII[26]] = lIIIIIlIlIlll("SGg30B8VpWBC7dElbXyo/Q==", "CoGRc");
    lIlIlIlIIII[lIlIlIlIlII[27]] = lIIIIIlIlIllI("htRCMKtpRP8ttiyIZjNTKA==", "jAapB");
    lIlIlIlIIII[lIlIlIlIlII[28]] = lIIIIIlIllIlI("LhcgOCgjHD57OTgaITw6JVY+ISg/DCgx", "MxMUI");
    lIlIlIlIIII[lIlIlIlIlII[6]] = lIIIIIlIlIllI("/DYGyczS8lxPslosTMpn+0Sv0Ggk/E4U", "gWXxX");
    lIlIlIlIIII[lIlIlIlIlII[29]] = lIIIIIlIllIlI("LRcfOQwzABQYRzUfBQYM", "Avqji");
    lIlIlIlIIII[lIlIlIlIlII[32]] = lIIIIIlIlIlll("Wp6YT3yYLDdOx4vS7o26Tc4cPLPPSimI", "eMMSQ");
  }
  
  public GuiShareToLan(GuiScreen lllllllllllllllllIIIlIIIlIIIlIII)
  {
    field_146598_a = lllllllllllllllllIIIlIIIlIIIlIII;
  }
  
  private static void lIIIIIllIIlll()
  {
    lIlIlIlIlII = new int[35];
    lIlIlIlIlII[0] = ((0x3A ^ 0x1B) & (0x3D ^ 0x1C ^ 0xFFFFFFFF));
    lIlIlIlIlII[1] = (0xE2 ^ 0x87);
    lIlIlIlIlII[2] = "  ".length();
    lIlIlIlIlII[3] = ((0x2F ^ 0x41) + (0xC7 ^ 0x83) - (0xFC ^ 0x92) + (0xF0 ^ 0xA7));
    lIlIlIlIlII[4] = (77 + 15 - 19 + 56 ^ 120 + '' - 173 + 74);
    lIlIlIlIlII[5] = ('' + 63 - 140 + 93);
    lIlIlIlIlII[6] = (0xD2 ^ 0xC6);
    lIlIlIlIlII[7] = " ".length();
    lIlIlIlIlII[8] = (0xEF ^ 0x89);
    lIlIlIlIlII[9] = (0x1B ^ 0x1E);
    lIlIlIlIlII[10] = (0x75 ^ 0x1D);
    lIlIlIlIlII[11] = (0x69 ^ 0x19 ^ 0xD4 ^ 0xC0);
    lIlIlIlIlII[12] = "   ".length();
    lIlIlIlIlII[13] = (0x62 ^ 0x5);
    lIlIlIlIlII[14] = (0xBF ^ 0xBB);
    lIlIlIlIlII[15] = (0x6D ^ 0x7E ^ 0x1 ^ 0x14);
    lIlIlIlIlII[16] = (38 + 53 - -4 + 40 ^ 96 + 125 - 183 + 90);
    lIlIlIlIlII[17] = (0x9B ^ 0xBF ^ 0x68 ^ 0x44);
    lIlIlIlIlII[18] = (0x64 ^ 0x6D);
    lIlIlIlIlII[19] = (0xD0 ^ 0xC3 ^ 0x16 ^ 0xF);
    lIlIlIlIlII[20] = (0x56 ^ 0x46 ^ 0x9D ^ 0x86);
    lIlIlIlIlII[21] = (0x54 ^ 0x58);
    lIlIlIlIlII[22] = (0xA7 ^ 0xAA);
    lIlIlIlIlII[23] = (0xB2 ^ 0xBC);
    lIlIlIlIlII[24] = (0x16 ^ 0x19);
    lIlIlIlIlII[25] = (0x1C ^ 0x6E ^ 0x32 ^ 0x50);
    lIlIlIlIlII[26] = (0xD3 ^ 0xBD ^ 89 + 23 - 36 + 51);
    lIlIlIlIlII[27] = (0x67 ^ 0xB ^ 0x62 ^ 0x1C);
    lIlIlIlIlII[28] = (0xD8 ^ 0xC4 ^ 0x8E ^ 0x81);
    lIlIlIlIlII[29] = (0x15 ^ 0x53 ^ 0xC2 ^ 0x91);
    lIlIlIlIlII[30] = (0x3 ^ 0x31);
    lIlIlIlIlII[31] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIlIlIlIlII[32] = (0x95 ^ 0x83);
    lIlIlIlIlII[33] = (0xF6 ^ 0xA4);
    lIlIlIlIlII[34] = (0x65 ^ 0x72);
  }
  
  public void initGui()
  {
    ;
    buttonList.clear();
    new GuiButton(lIlIlIlIlII[1], width / lIlIlIlIlII[2] - lIlIlIlIlII[3], height - lIlIlIlIlII[4], lIlIlIlIlII[5], lIlIlIlIlII[6], I18n.format(lIlIlIlIIII[lIlIlIlIlII[7]], new Object[lIlIlIlIlII[0]]));
    "".length();
    new GuiButton(lIlIlIlIlII[8], width / lIlIlIlIlII[2] + lIlIlIlIlII[9], height - lIlIlIlIlII[4], lIlIlIlIlII[5], lIlIlIlIlII[6], I18n.format(lIlIlIlIIII[lIlIlIlIlII[2]], new Object[lIlIlIlIlII[0]]));
    "".length();
    field_146597_g = new GuiButton(lIlIlIlIlII[10], width / lIlIlIlIlII[2] - lIlIlIlIlII[3], lIlIlIlIlII[11], lIlIlIlIlII[5], lIlIlIlIlII[6], I18n.format(lIlIlIlIIII[lIlIlIlIlII[12]], new Object[lIlIlIlIlII[0]]));
    "".length();
    field_146596_f = new GuiButton(lIlIlIlIlII[13], width / lIlIlIlIlII[2] + lIlIlIlIlII[9], lIlIlIlIlII[11], lIlIlIlIlII[5], lIlIlIlIlII[6], I18n.format(lIlIlIlIIII[lIlIlIlIlII[14]], new Object[lIlIlIlIlII[0]]));
    "".length();
    lllllllllllllllllIIIlIIIlIIIIllI.func_146595_g();
  }
  
  public void drawScreen(int lllllllllllllllllIIIlIIIIllIlIll, int lllllllllllllllllIIIlIIIIllIlIlI, float lllllllllllllllllIIIlIIIIllIlIIl)
  {
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIlIIIIllIllII.drawDefaultBackground();
    lllllllllllllllllIIIlIIIIllIllII.drawCenteredString(fontRendererObj, I18n.format(lIlIlIlIIII[lIlIlIlIlII[29]], new Object[lIlIlIlIlII[0]]), width / lIlIlIlIlII[2], lIlIlIlIlII[30], lIlIlIlIlII[31]);
    lllllllllllllllllIIIlIIIIllIllII.drawCenteredString(fontRendererObj, I18n.format(lIlIlIlIIII[lIlIlIlIlII[32]], new Object[lIlIlIlIlII[0]]), width / lIlIlIlIlII[2], lIlIlIlIlII[33], lIlIlIlIlII[31]);
    lllllllllllllllllIIIlIIIIllIllII.drawScreen(lllllllllllllllllIIIlIIIIllIlIll, lllllllllllllllllIIIlIIIIllIlIlI, lllllllllllllllllIIIlIIIIllIlIIl);
  }
  
  private static String lIIIIIlIlIlll(String lllllllllllllllllIIIlIIIIlIlllll, String lllllllllllllllllIIIlIIIIlIllllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIIlIIIIllIIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIlIIIIlIllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIIIlIIIIllIIIll = Cipher.getInstance("Blowfish");
      lllllllllllllllllIIIlIIIIllIIIll.init(lIlIlIlIlII[2], lllllllllllllllllIIIlIIIIllIIlII);
      return new String(lllllllllllllllllIIIlIIIIllIIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIlIIIIlIlllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIIlIIIIllIIIlI)
    {
      lllllllllllllllllIIIlIIIIllIIIlI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIIIllIlIII(int ???)
  {
    double lllllllllllllllllIIIlIIIIIlIlIll;
    return ??? != 0;
  }
  
  private static String lIIIIIlIllIlI(String lllllllllllllllllIIIlIIIIlIlIIIl, String lllllllllllllllllIIIlIIIIlIIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIlIIIIlIlIIIl = new String(Base64.getDecoder().decode(lllllllllllllllllIIIlIIIIlIlIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIIlIIIIlIIllll = new StringBuilder();
    char[] lllllllllllllllllIIIlIIIIlIIlllI = lllllllllllllllllIIIlIIIIlIIlIll.toCharArray();
    int lllllllllllllllllIIIlIIIIlIIllIl = lIlIlIlIlII[0];
    double lllllllllllllllllIIIlIIIIlIIIlll = lllllllllllllllllIIIlIIIIlIlIIIl.toCharArray();
    String lllllllllllllllllIIIlIIIIlIIIllI = lllllllllllllllllIIIlIIIIlIIIlll.length;
    String lllllllllllllllllIIIlIIIIlIIIlIl = lIlIlIlIlII[0];
    while (lIIIIIllIllIl(lllllllllllllllllIIIlIIIIlIIIlIl, lllllllllllllllllIIIlIIIIlIIIllI))
    {
      char lllllllllllllllllIIIlIIIIlIlIIlI = lllllllllllllllllIIIlIIIIlIIIlll[lllllllllllllllllIIIlIIIIlIIIlIl];
      "".length();
      "".length();
      if ("   ".length() > (0x87 ^ 0x83)) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIIIlIIIIlIIllll);
  }
  
  private static boolean lIIIIIllIllII(Object ???)
  {
    Exception lllllllllllllllllIIIlIIIIIlIllIl;
    return ??? != null;
  }
  
  private void func_146595_g()
  {
    ;
    field_146597_g.displayString = String.valueOf(new StringBuilder(String.valueOf(I18n.format(lIlIlIlIIII[lIlIlIlIlII[9]], new Object[lIlIlIlIlII[0]]))).append(lIlIlIlIIII[lIlIlIlIlII[15]]).append(I18n.format(String.valueOf(new StringBuilder(lIlIlIlIIII[lIlIlIlIlII[16]]).append(field_146599_h)), new Object[lIlIlIlIlII[0]])));
    field_146596_f.displayString = String.valueOf(new StringBuilder(String.valueOf(I18n.format(lIlIlIlIIII[lIlIlIlIlII[17]], new Object[lIlIlIlIlII[0]]))).append(lIlIlIlIIII[lIlIlIlIlII[18]]));
    if (lIIIIIllIlIII(field_146600_i))
    {
      field_146596_f.displayString = String.valueOf(new StringBuilder(String.valueOf(field_146596_f.displayString)).append(I18n.format(lIlIlIlIIII[lIlIlIlIlII[19]], new Object[lIlIlIlIlII[0]])));
      "".length();
      if ("   ".length() >= 0) {}
    }
    else
    {
      field_146596_f.displayString = String.valueOf(new StringBuilder(String.valueOf(field_146596_f.displayString)).append(I18n.format(lIlIlIlIIII[lIlIlIlIlII[20]], new Object[lIlIlIlIlII[0]])));
    }
  }
  
  static
  {
    lIIIIIllIIlll();
    lIIIIIllIIlIl();
  }
}

package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.MusicTicker;
import net.minecraft.client.audio.MusicTicker.MusicType;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.IResource;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.network.play.client.C16PacketClientStatus.EnumState;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import org.apache.commons.io.Charsets;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class GuiWinGame
  extends GuiScreen
{
  private static String lllIIIllIlIIIl(String llllllllllllllIIlllllIIlIlllIIlI, String llllllllllllllIIlllllIIlIlllIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIlllllIIlIlllIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIlllllIIlIlllIIll.getBytes(StandardCharsets.UTF_8)), lIIlIlIlIIllI[10]), "DES");
      Cipher llllllllllllllIIlllllIIlIlllIllI = Cipher.getInstance("DES");
      llllllllllllllIIlllllIIlIlllIllI.init(lIIlIlIlIIllI[3], llllllllllllllIIlllllIIlIlllIlll);
      return new String(llllllllllllllIIlllllIIlIlllIllI.doFinal(Base64.getDecoder().decode(llllllllllllllIIlllllIIlIlllIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIlllllIIlIlllIlIl)
    {
      llllllllllllllIIlllllIIlIlllIlIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIIlllIlIIl(int ???)
  {
    char llllllllllllllIIlllllIIlIlIIIlll;
    return ??? != 0;
  }
  
  private static boolean lllIIIllIlllIl(int ???)
  {
    byte llllllllllllllIIlllllIIlIlIIIIIl;
    return ??? > 0;
  }
  
  public GuiWinGame() {}
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIIllIlllll(field_146582_i))
    {
      field_146582_i = Lists.newArrayList();
      try
      {
        String llllllllllllllIIlllllIIllllIlIlI = lIIlIlIlIIlII[lIIlIlIlIIllI[3]];
        String llllllllllllllIIlllllIIllllIlIIl = String.valueOf(new StringBuilder().append(EnumChatFormatting.WHITE).append(EnumChatFormatting.OBFUSCATED).append(EnumChatFormatting.GREEN).append(EnumChatFormatting.AQUA));
        int llllllllllllllIIlllllIIllllIlIII = lIIlIlIlIIllI[4];
        InputStream llllllllllllllIIlllllIIllllIIlll = mc.getResourceManager().getResource(new ResourceLocation(lIIlIlIlIIlII[lIIlIlIlIIllI[5]])).getInputStream();
        BufferedReader llllllllllllllIIlllllIIllllIIllI = new BufferedReader(new InputStreamReader(llllllllllllllIIlllllIIllllIIlll, Charsets.UTF_8));
        Random llllllllllllllIIlllllIIllllIIlIl = new Random(8124371L);
        "".length();
        if ("   ".length() < " ".length()) {
          return;
        }
        while (!lllIIIllIlllll(llllllllllllllIIlllllIIllllIlIlI = llllllllllllllIIlllllIIllllIIllI.readLine()))
        {
          llllllllllllllIIlllllIIllllIlIlI = llllllllllllllIIlllllIIllllIlIlI.replaceAll(lIIlIlIlIIlII[lIIlIlIlIIllI[6]], mc.getSession().getUsername());
          "".length();
          if (((0xFB ^ 0xA8) & (0xCF ^ 0x9C ^ 0xFFFFFFFF) ^ 0xC1 ^ 0xC5) < 0) {
            return;
          }
          while (!lllIIIllIllIll(llllllllllllllIIlllllIIllllIlIlI.contains(llllllllllllllIIlllllIIllllIlIIl)))
          {
            int llllllllllllllIIlllllIIllllIIIlI = llllllllllllllIIlllllIIllllIlIlI.indexOf(llllllllllllllIIlllllIIllllIlIIl);
            String llllllllllllllIIlllllIIllllIIlII = llllllllllllllIIlllllIIllllIlIlI.substring(lIIlIlIlIIllI[0], llllllllllllllIIlllllIIllllIIIlI);
            String llllllllllllllIIlllllIIllllIIIll = llllllllllllllIIlllllIIllllIlIlI.substring(llllllllllllllIIlllllIIllllIIIlI + llllllllllllllIIlllllIIllllIlIIl.length());
            llllllllllllllIIlllllIIllllIlIlI = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIIlllllIIllllIIlII)).append(EnumChatFormatting.WHITE).append(EnumChatFormatting.OBFUSCATED).append(lIIlIlIlIIlII[lIIlIlIlIIllI[7]].substring(lIIlIlIlIIllI[0], llllllllllllllIIlllllIIllllIIlIl.nextInt(lIIlIlIlIIllI[6]) + lIIlIlIlIIllI[5])).append(llllllllllllllIIlllllIIllllIIIll));
          }
          "".length();
          "".length();
        }
        llllllllllllllIIlllllIIllllIIlll.close();
        int llllllllllllllIIlllllIIllllIIIIl = lIIlIlIlIIllI[0];
        "".length();
        if (-(0x14 ^ 0x75 ^ 0x12 ^ 0x77) >= 0) {
          return;
        }
        while (!lllIIIlllIIIIl(llllllllllllllIIlllllIIllllIIIIl, lIIlIlIlIIllI[10])) {
          "".length();
        }
        llllllllllllllIIlllllIIllllIIlll = mc.getResourceManager().getResource(new ResourceLocation(lIIlIlIlIIlII[lIIlIlIlIIllI[10]])).getInputStream();
        llllllllllllllIIlllllIIllllIIllI = new BufferedReader(new InputStreamReader(llllllllllllllIIlllllIIllllIIlll, Charsets.UTF_8));
        "".length();
        if (-"  ".length() >= 0) {
          return;
        }
        while (!lllIIIllIlllll(llllllllllllllIIlllllIIllllIlIlI = llllllllllllllIIlllllIIllllIIllI.readLine()))
        {
          llllllllllllllIIlllllIIllllIlIlI = llllllllllllllIIlllllIIllllIlIlI.replaceAll(lIIlIlIlIIlII[lIIlIlIlIIllI[11]], mc.getSession().getUsername());
          llllllllllllllIIlllllIIllllIlIlI = llllllllllllllIIlllllIIllllIlIlI.replaceAll(lIIlIlIlIIlII[lIIlIlIlIIllI[12]], lIIlIlIlIIlII[lIIlIlIlIIllI[13]]);
          "".length();
          "".length();
        }
        llllllllllllllIIlllllIIllllIIlll.close();
        field_146579_r = (field_146582_i.size() * lIIlIlIlIIllI[14]);
        "".length();
        if (-" ".length() < -" ".length()) {}
      }
      catch (Exception llllllllllllllIIlllllIIllllIIIII)
      {
        logger.error(lIIlIlIlIIlII[lIIlIlIlIIllI[15]], llllllllllllllIIlllllIIllllIIIII);
      }
    }
  }
  
  private void drawWinGameScreen(int llllllllllllllIIlllllIIlllIIlIIl, int llllllllllllllIIlllllIIlllIIlIII, float llllllllllllllIIlllllIIlllIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Tessellator llllllllllllllIIlllllIIlllIIIllI = Tessellator.getInstance();
    WorldRenderer llllllllllllllIIlllllIIlllIIIlIl = llllllllllllllIIlllllIIlllIIIllI.getWorldRenderer();
    mc.getTextureManager().bindTexture(Gui.optionsBackground);
    llllllllllllllIIlllllIIlllIIIlIl.begin(lIIlIlIlIIllI[9], DefaultVertexFormats.POSITION_TEX_COLOR);
    int llllllllllllllIIlllllIIlllIIIlII = width;
    float llllllllllllllIIlllllIIlllIIIIll = 0.0F - (field_146581_h + llllllllllllllIIlllllIIlllIIIlll) * 0.5F * field_146578_s;
    float llllllllllllllIIlllllIIlllIIIIlI = height - (field_146581_h + llllllllllllllIIlllllIIlllIIIlll) * 0.5F * field_146578_s;
    float llllllllllllllIIlllllIIlllIIIIIl = 0.015625F;
    float llllllllllllllIIlllllIIlllIIIIII = (field_146581_h + llllllllllllllIIlllllIIlllIIIlll - 0.0F) * 0.02F;
    float llllllllllllllIIlllllIIllIllllll = (field_146579_r + height + height + lIIlIlIlIIllI[2]) / field_146578_s;
    float llllllllllllllIIlllllIIllIlllllI = (llllllllllllllIIlllllIIllIllllll - 20.0F - (field_146581_h + llllllllllllllIIlllllIIlllIIIlll)) * 0.005F;
    if (lllIIIlllIIlIl(lllIIIlllIIIlI(llllllllllllllIIlllllIIllIlllllI, llllllllllllllIIlllllIIlllIIIIII))) {
      llllllllllllllIIlllllIIlllIIIIII = llllllllllllllIIlllllIIllIlllllI;
    }
    if (lllIIIllIlllIl(lllIIIlllIIIll(llllllllllllllIIlllllIIlllIIIIII, 1.0F))) {
      llllllllllllllIIlllllIIlllIIIIII = 1.0F;
    }
    llllllllllllllIIlllllIIlllIIIIII *= llllllllllllllIIlllllIIlllIIIIII;
    llllllllllllllIIlllllIIlllIIIIII = llllllllllllllIIlllllIIlllIIIIII * 96.0F / 255.0F;
    llllllllllllllIIlllllIIlllIIIlIl.pos(0.0D, height, zLevel).tex(0.0D, llllllllllllllIIlllllIIlllIIIIll * llllllllllllllIIlllllIIlllIIIIIl).color(llllllllllllllIIlllllIIlllIIIIII, llllllllllllllIIlllllIIlllIIIIII, llllllllllllllIIlllllIIlllIIIIII, 1.0F).endVertex();
    llllllllllllllIIlllllIIlllIIIlIl.pos(llllllllllllllIIlllllIIlllIIIlII, height, zLevel).tex(llllllllllllllIIlllllIIlllIIIlII * llllllllllllllIIlllllIIlllIIIIIl, llllllllllllllIIlllllIIlllIIIIll * llllllllllllllIIlllllIIlllIIIIIl).color(llllllllllllllIIlllllIIlllIIIIII, llllllllllllllIIlllllIIlllIIIIII, llllllllllllllIIlllllIIlllIIIIII, 1.0F).endVertex();
    llllllllllllllIIlllllIIlllIIIlIl.pos(llllllllllllllIIlllllIIlllIIIlII, 0.0D, zLevel).tex(llllllllllllllIIlllllIIlllIIIlII * llllllllllllllIIlllllIIlllIIIIIl, llllllllllllllIIlllllIIlllIIIIlI * llllllllllllllIIlllllIIlllIIIIIl).color(llllllllllllllIIlllllIIlllIIIIII, llllllllllllllIIlllllIIlllIIIIII, llllllllllllllIIlllllIIlllIIIIII, 1.0F).endVertex();
    llllllllllllllIIlllllIIlllIIIlIl.pos(0.0D, 0.0D, zLevel).tex(0.0D, llllllllllllllIIlllllIIlllIIIIlI * llllllllllllllIIlllllIIlllIIIIIl).color(llllllllllllllIIlllllIIlllIIIIII, llllllllllllllIIlllllIIlllIIIIII, llllllllllllllIIlllllIIlllIIIIII, 1.0F).endVertex();
    llllllllllllllIIlllllIIlllIIIllI.draw();
  }
  
  private static int lllIIIllIllIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lllIIIlllIllIl(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIIlllllIIlIlIIlIll;
    return ??? < i;
  }
  
  private static boolean lllIIIlllIIIIl(int ???, int arg1)
  {
    int i;
    char llllllllllllllIIlllllIIlIlIIllll;
    return ??? >= i;
  }
  
  private static boolean lllIIIlllIIlIl(int ???)
  {
    Exception llllllllllllllIIlllllIIlIlIIIIll;
    return ??? < 0;
  }
  
  private static String lllIIIllIlIIlI(String llllllllllllllIIlllllIIlIllIIlII, String llllllllllllllIIlllllIIlIllIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIlllllIIlIllIIlII = new String(Base64.getDecoder().decode(llllllllllllllIIlllllIIlIllIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIlllllIIlIllIIIlI = new StringBuilder();
    char[] llllllllllllllIIlllllIIlIllIIIIl = llllllllllllllIIlllllIIlIllIIIll.toCharArray();
    int llllllllllllllIIlllllIIlIllIIIII = lIIlIlIlIIllI[0];
    short llllllllllllllIIlllllIIlIlIllIlI = llllllllllllllIIlllllIIlIllIIlII.toCharArray();
    boolean llllllllllllllIIlllllIIlIlIllIIl = llllllllllllllIIlllllIIlIlIllIlI.length;
    double llllllllllllllIIlllllIIlIlIllIII = lIIlIlIlIIllI[0];
    while (lllIIIlllIllIl(llllllllllllllIIlllllIIlIlIllIII, llllllllllllllIIlllllIIlIlIllIIl))
    {
      char llllllllllllllIIlllllIIlIllIIlIl = llllllllllllllIIlllllIIlIlIllIlI[llllllllllllllIIlllllIIlIlIllIII];
      "".length();
      "".length();
      if (((0xB5 ^ 0xA1) & (0x8D ^ 0x99 ^ 0xFFFFFFFF)) > " ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIlllllIIlIllIIIlI);
  }
  
  private static int lllIIIlllIIIll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private void sendRespawnPacket()
  {
    ;
    mc.thePlayer.sendQueue.addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.PERFORM_RESPAWN));
    mc.displayGuiScreen(null);
  }
  
  private static String lllIIIllIlIIII(String llllllllllllllIIlllllIIllIIIIIIl, String llllllllllllllIIlllllIIlIllllllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIlllllIIllIIIIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIIlllllIIlIllllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIIlllllIIllIIIIIll = Cipher.getInstance("Blowfish");
      llllllllllllllIIlllllIIllIIIIIll.init(lIIlIlIlIIllI[3], llllllllllllllIIlllllIIllIIIIlII);
      return new String(llllllllllllllIIlllllIIllIIIIIll.doFinal(Base64.getDecoder().decode(llllllllllllllIIlllllIIllIIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIlllllIIllIIIIIlI)
    {
      llllllllllllllIIlllllIIllIIIIIlI.printStackTrace();
    }
    return null;
  }
  
  private static int lllIIIlllIIIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lllIIIllIlllll(Object ???)
  {
    float llllllllllllllIIlllllIIlIlIIlIIl;
    return ??? == null;
  }
  
  private static void lllIIIllIlIIll()
  {
    lIIlIlIlIIlII = new String[lIIlIlIlIIllI[24]];
    lIIlIlIlIIlII[lIIlIlIlIIllI[0]] = lllIIIllIlIIII("Zt27l+UVjK9UoRwt6JyE0Mn5CZk9VEJkYbSxGEboq0nfIESQoQP+TQ==", "DdEom");
    lIIlIlIlIIlII[lIIlIlIlIIllI[1]] = lllIIIllIlIIII("Xb2eWXmXVhds/e+jXAQlPeGMYZ3KSpYEYVyc3GON30A=", "MSaqp");
    lIIlIlIlIIlII[lIIlIlIlIIllI[3]] = lllIIIllIlIIIl("5UQjRgdH0cw=", "zsXUn");
    lIIlIlIlIIlII[lIIlIlIlIIllI[5]] = lllIIIllIlIIlI("MDIQEDVrMgYAaDAvHA==", "DWhdF");
    lIIlIlIlIIlII[lIIlIlIlIIllI[6]] = lllIIIllIlIIIl("Ba3AmErI80fHgaGHmdSXbQ==", "exspT");
    lIIlIlIlIIlII[lIIlIlIlIIllI[7]] = lllIIIllIlIIIl("VdAnHeFsPYx9utmmkimO3w==", "IwCcI");
    lIIlIlIlIIlII[lIIlIlIlIIllI[8]] = lllIIIllIlIIIl("l5Iy0fveKMw=", "NGQdT");
    lIIlIlIlIIlII[lIIlIlIlIIllI[9]] = lllIIIllIlIIIl("TDQ9nCcU6zM=", "vBicG");
    lIIlIlIlIIlII[lIIlIlIlIIllI[10]] = lllIIIllIlIIIl("7xVhZtTHcMOMV2ftxcnyNb27/q+eM2qw", "GRrpI");
    lIIlIlIlIIlII[lIIlIlIlIIllI[11]] = lllIIIllIlIIlI("BRokLgEHGCQ6AQ==", "UVewD");
    lIIlIlIlIIlII[lIIlIlIlIIllI[12]] = lllIIIllIlIIlI("RQ==", "LzXSU");
    lIIlIlIlIIlII[lIIlIlIlIIllI[13]] = lllIIIllIlIIIl("dwKGQC1279Q=", "xjmRx");
    lIIlIlIlIIlII[lIIlIlIlIIllI[14]] = lllIIIllIlIIIl("fLEfgWux0YQ=", "tYzag");
    lIIlIlIlIIlII[lIIlIlIlIIllI[15]] = lllIIIllIlIIlI("OiU8IxIXbT1vGhYrLW8VCy8tJgIK", "yJIOv");
    lIIlIlIlIIlII[lIIlIlIlIIllI[21]] = lllIIIllIlIIlI("IQca", "zDGfa");
  }
  
  private static int lllIIIlllIIlll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lllIIIllIllIll(int ???)
  {
    int llllllllllllllIIlllllIIlIlIIIlIl;
    return ??? == 0;
  }
  
  private static int lllIIIlllIIllI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static void lllIIIllIlIllI()
  {
    lIIlIlIlIIllI = new int[25];
    lIIlIlIlIIllI[0] = ((0xCE ^ 0xB9 ^ 0x63 ^ 0x18) & (0x96 ^ 0xC7 ^ 0x66 ^ 0x3B ^ -" ".length()));
    lIIlIlIlIIllI[1] = " ".length();
    lIIlIlIlIIllI[2] = (0x46 ^ 0x5E);
    lIIlIlIlIIllI[3] = "  ".length();
    lIIlIlIlIIllI[4] = (-(0xFFFFFFEF & 0x64D9) & 0xEDDA & 0x77FF);
    lIIlIlIlIIllI[5] = "   ".length();
    lIIlIlIlIIllI[6] = (127 + 57 - 142 + 90 ^ 74 + 62 - 128 + 120);
    lIIlIlIlIIllI[7] = (0x53 ^ 0x56);
    lIIlIlIlIIllI[8] = (0x81 ^ 0xAC ^ 0x77 ^ 0x5C);
    lIIlIlIlIIllI[9] = (0x49 ^ 0x4E);
    lIIlIlIlIIllI[10] = (0x17 ^ 0x1F);
    lIIlIlIlIIllI[11] = (0x8F ^ 0x86);
    lIIlIlIlIIllI[12] = (0x85 ^ 0x8F);
    lIIlIlIlIIllI[13] = (78 + 61 - 128 + 141 ^ '' + 0 - 17 + 33);
    lIIlIlIlIIllI[14] = (0x4B ^ 0x47);
    lIIlIlIlIIllI[15] = (0x37 ^ 0x3A);
    lIIlIlIlIIllI[16] = (0x4F ^ 0x20 ^ 0x26 ^ 0x7B);
    lIIlIlIlIIllI[17] = ((0x18 ^ 0x13) + (0xD ^ 0x7D) - (0xA8 ^ 0xC6) + (126 + 1 - 28 + 43));
    lIIlIlIlIIllI[18] = (70 + 121 - 96 + 53 ^ 72 + 108 - 31 + 35);
    lIIlIlIlIIllI[19] = (0x44 ^ 0x69);
    lIIlIlIlIIllI[20] = ((0x2A ^ 0x1B) + (0x8E ^ 0x9D) - (0x3E ^ 0x33) + (85 + 2 - 24 + 82));
    lIIlIlIlIIllI[21] = (0xA3 ^ 0xAD);
    lIIlIlIlIIllI[22] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIIlIlIlIIllI[23] = (-(0xCCBD & 0x3FFB) & 0x8FFD & 0x7FBB);
    lIIlIlIlIIllI[24] = (0x5 ^ 0xA);
  }
  
  public boolean doesGuiPauseGame()
  {
    return lIIlIlIlIIllI[1];
  }
  
  public void updateScreen()
  {
    ;
    ;
    ;
    ;
    MusicTicker llllllllllllllIIlllllIlIIIIIIlll = mc.func_181535_r();
    SoundHandler llllllllllllllIIlllllIlIIIIIIllI = mc.getSoundHandler();
    if (lllIIIllIllIll(field_146581_h))
    {
      llllllllllllllIIlllllIlIIIIIIlll.func_181557_a();
      llllllllllllllIIlllllIlIIIIIIlll.func_181558_a(MusicTicker.MusicType.CREDITS);
      llllllllllllllIIlllllIlIIIIIIllI.resumeSounds();
    }
    llllllllllllllIIlllllIlIIIIIIllI.update();
    field_146581_h += lIIlIlIlIIllI[1];
    float llllllllllllllIIlllllIlIIIIIIlIl = (field_146579_r + height + height + lIIlIlIlIIllI[2]) / field_146578_s;
    if (lllIIIllIlllIl(lllIIIllIllIIl(field_146581_h, llllllllllllllIIlllllIlIIIIIIlIl))) {
      llllllllllllllIIlllllIlIIIIIlIII.sendRespawnPacket();
    }
  }
  
  public void drawScreen(int llllllllllllllIIlllllIIllIlIIlII, int llllllllllllllIIlllllIIllIlIIIll, float llllllllllllllIIlllllIIllIlIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIlllllIIllIlIIlIl.drawWinGameScreen(llllllllllllllIIlllllIIllIlIIlII, llllllllllllllIIlllllIIllIlIIIll, llllllllllllllIIlllllIIllIlIIIlI);
    Tessellator llllllllllllllIIlllllIIllIlIIIIl = Tessellator.getInstance();
    WorldRenderer llllllllllllllIIlllllIIllIlIIIII = llllllllllllllIIlllllIIllIlIIIIl.getWorldRenderer();
    int llllllllllllllIIlllllIIllIIlllll = lIIlIlIlIIllI[4];
    int llllllllllllllIIlllllIIllIIllllI = width / lIIlIlIlIIllI[3] - llllllllllllllIIlllllIIllIIlllll / lIIlIlIlIIllI[3];
    int llllllllllllllIIlllllIIllIIlllIl = height + lIIlIlIlIIllI[16];
    float llllllllllllllIIlllllIIllIIlllII = -(field_146581_h + llllllllllllllIIlllllIIllIlIIIlI) * field_146578_s;
    GlStateManager.pushMatrix();
    GlStateManager.translate(0.0F, llllllllllllllIIlllllIIllIIlllII, 0.0F);
    mc.getTextureManager().bindTexture(MINECRAFT_LOGO);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    llllllllllllllIIlllllIIllIlIIlIl.drawTexturedModalRect(llllllllllllllIIlllllIIllIIllllI, llllllllllllllIIlllllIIllIIlllIl, lIIlIlIlIIllI[0], lIIlIlIlIIllI[0], lIIlIlIlIIllI[17], lIIlIlIlIIllI[18]);
    llllllllllllllIIlllllIIllIlIIlIl.drawTexturedModalRect(llllllllllllllIIlllllIIllIIllllI + lIIlIlIlIIllI[17], llllllllllllllIIlllllIIllIIlllIl, lIIlIlIlIIllI[0], lIIlIlIlIIllI[19], lIIlIlIlIIllI[17], lIIlIlIlIIllI[18]);
    int llllllllllllllIIlllllIIllIIllIll = llllllllllllllIIlllllIIllIIlllIl + lIIlIlIlIIllI[20];
    int llllllllllllllIIlllllIIllIIllIlI = lIIlIlIlIIllI[0];
    "".length();
    if ("   ".length() <= 0) {
      return;
    }
    while (!lllIIIlllIIIIl(llllllllllllllIIlllllIIllIIllIlI, field_146582_i.size()))
    {
      if (lllIIIllIllllI(llllllllllllllIIlllllIIllIIllIlI, field_146582_i.size() - lIIlIlIlIIllI[1]))
      {
        float llllllllllllllIIlllllIIllIIllIIl = llllllllllllllIIlllllIIllIIllIll + llllllllllllllIIlllllIIllIIlllII - (height / lIIlIlIlIIllI[3] - lIIlIlIlIIllI[8]);
        if (lllIIIlllIIlIl(lllIIIlllIIllI(llllllllllllllIIlllllIIllIIllIIl, 0.0F))) {
          GlStateManager.translate(0.0F, -llllllllllllllIIlllllIIllIIllIIl, 0.0F);
        }
      }
      if ((lllIIIllIlllIl(lllIIIlllIIlll(llllllllllllllIIlllllIIllIIllIll + llllllllllllllIIlllllIIllIIlllII + 12.0F + 8.0F, 0.0F))) && (lllIIIlllIIlIl(lllIIIlllIIllI(llllllllllllllIIlllllIIllIIllIll + llllllllllllllIIlllllIIllIIlllII, height))))
      {
        String llllllllllllllIIlllllIIllIIllIII = (String)field_146582_i.get(llllllllllllllIIlllllIIllIIllIlI);
        if (lllIIIlllIlIIl(llllllllllllllIIlllllIIllIIllIII.startsWith(lIIlIlIlIIlII[lIIlIlIlIIllI[21]])))
        {
          "".length();
          "".length();
          if (" ".length() > -" ".length()) {}
        }
        else
        {
          fontRendererObj.fontRandom.setSeed(llllllllllllllIIlllllIIllIIllIlI * 4238972211L + field_146581_h / lIIlIlIlIIllI[6]);
          "".length();
        }
      }
      llllllllllllllIIlllllIIllIIllIll += 12;
    }
    GlStateManager.popMatrix();
    mc.getTextureManager().bindTexture(VIGNETTE_TEXTURE);
    GlStateManager.enableBlend();
    GlStateManager.blendFunc(lIIlIlIlIIllI[0], lIIlIlIlIIllI[23]);
    int llllllllllllllIIlllllIIllIIlIlll = width;
    int llllllllllllllIIlllllIIllIIlIllI = height;
    llllllllllllllIIlllllIIllIlIIIII.begin(lIIlIlIlIIllI[9], DefaultVertexFormats.POSITION_TEX_COLOR);
    llllllllllllllIIlllllIIllIlIIIII.pos(0.0D, llllllllllllllIIlllllIIllIIlIllI, zLevel).tex(0.0D, 1.0D).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
    llllllllllllllIIlllllIIllIlIIIII.pos(llllllllllllllIIlllllIIllIIlIlll, llllllllllllllIIlllllIIllIIlIllI, zLevel).tex(1.0D, 1.0D).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
    llllllllllllllIIlllllIIllIlIIIII.pos(llllllllllllllIIlllllIIllIIlIlll, 0.0D, zLevel).tex(1.0D, 0.0D).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
    llllllllllllllIIlllllIIllIlIIIII.pos(0.0D, 0.0D, zLevel).tex(0.0D, 0.0D).color(1.0F, 1.0F, 1.0F, 1.0F).endVertex();
    llllllllllllllIIlllllIIllIlIIIIl.draw();
    GlStateManager.disableBlend();
    llllllllllllllIIlllllIIllIlIIlIl.drawScreen(llllllllllllllIIlllllIIllIlIIlII, llllllllllllllIIlllllIIllIlIIIll, llllllllllllllIIlllllIIllIlIIIlI);
  }
  
  static
  {
    lllIIIllIlIllI();
    lllIIIllIlIIll();
    logger = LogManager.getLogger();
    MINECRAFT_LOGO = new ResourceLocation(lIIlIlIlIIlII[lIIlIlIlIIllI[0]]);
  }
  
  protected void keyTyped(char llllllllllllllIIlllllIIlllllllIl, int llllllllllllllIIlllllIIlllllllII)
    throws IOException
  {
    ;
    ;
    if (lllIIIllIllllI(llllllllllllllIIlllllIIlllllllII, lIIlIlIlIIllI[1])) {
      llllllllllllllIIlllllIIllllllIll.sendRespawnPacket();
    }
  }
  
  private static boolean lllIIIllIllllI(int ???, int arg1)
  {
    int i;
    double llllllllllllllIIlllllIIlIlIlIIll;
    return ??? == i;
  }
}

package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import com.google.gson.JsonParseException;
import io.netty.buffer.Unpooled;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.event.ClickEvent;
import net.minecraft.event.ClickEvent.Action;
import net.minecraft.init.Items;
import net.minecraft.item.ItemEditableBook;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatStyle;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.IChatComponent.Serializer;
import org.apache.logging.log4j.LogManager;
import org.lwjgl.input.Keyboard;

public class GuiScreenBook
  extends GuiScreen
{
  private static boolean lIIllllIIII(int ???)
  {
    byte llIIlllIIIlIIl;
    return ??? >= 0;
  }
  
  private static String lIIllIlIlII(String llIIlllIlIlllI, String llIIlllIlIllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIIlllIllIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llIIlllIlIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llIIlllIllIIlI = Cipher.getInstance("Blowfish");
      llIIlllIllIIlI.init(lIllllIll[4], llIIlllIllIIll);
      return new String(llIIlllIllIIlI.doFinal(Base64.getDecoder().decode(llIIlllIlIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIIlllIllIIIl)
    {
      llIIlllIllIIIl.printStackTrace();
    }
    return null;
  }
  
  protected void actionPerformed(GuiButton llIlIIlIIIlIII)
    throws IOException
  {
    ;
    ;
    if (lIIlllIIlll(enabled))
    {
      if (lIIlllIlIll(id))
      {
        mc.displayGuiScreen(null);
        llIlIIlIIIlIIl.sendBookToServer(lIllllIll[0]);
        "".length();
        if (null == null) {}
      }
      else if ((lIIlllIllll(id, lIllllIll[6])) && (lIIlllIIlll(bookIsUnsigned)))
      {
        bookGettingSigned = lIllllIll[2];
        "".length();
        if (" ".length() >= " ".length()) {}
      }
      else if (lIIlllIllll(id, lIllllIll[2]))
      {
        if (lIIlllIlIIl(currPage, bookTotalPages - lIllllIll[2]))
        {
          currPage += lIllllIll[2];
          "".length();
          if (-" ".length() <= -" ".length()) {}
        }
        else if (lIIlllIIlll(bookIsUnsigned))
        {
          llIlIIlIIIlIIl.addNewPage();
          if (lIIlllIlIIl(currPage, bookTotalPages - lIllllIll[2]))
          {
            currPage += lIllllIll[2];
            "".length();
            if (-" ".length() != " ".length()) {}
          }
        }
      }
      else if (lIIlllIllll(id, lIllllIll[4]))
      {
        if (lIIlllIllIl(currPage))
        {
          currPage -= lIllllIll[2];
          "".length();
          if (" ".length() >= 0) {}
        }
      }
      else if ((lIIlllIllll(id, lIllllIll[11])) && (lIIlllIIlll(bookGettingSigned)))
      {
        llIlIIlIIIlIIl.sendBookToServer(lIllllIll[2]);
        mc.displayGuiScreen(null);
        "".length();
        if ("   ".length() != 0) {}
      }
      else if ((lIIlllIllll(id, lIllllIll[8])) && (lIIlllIIlll(bookGettingSigned)))
      {
        bookGettingSigned = lIllllIll[0];
      }
      llIlIIlIIIlIIl.updateButtons();
    }
  }
  
  public IChatComponent func_175385_b(int llIIllllllIIII, int llIIlllllIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIlllIlIlI(field_175386_A)) {
      return null;
    }
    int llIIlllllIlllI = llIIlllllIIllI - (width - bookImageWidth) / lIllllIll[4] - lIllllIll[34];
    int llIIlllllIllIl = llIIlllllIllll - lIllllIll[4] - lIllllIll[26] - lIllllIll[26];
    if ((lIIllllIIII(llIIlllllIlllI)) && (lIIllllIIII(llIIlllllIllIl)))
    {
      int llIIlllllIllII = Math.min(lIllllIll[30] / fontRendererObj.FONT_HEIGHT, field_175386_A.size());
      if ((lIIlllIlllI(llIIlllllIlllI, lIllllIll[35])) && (lIIlllIlIIl(llIIlllllIllIl, fontRendererObjFONT_HEIGHT * llIIlllllIllII + llIIlllllIllII)))
      {
        int llIIlllllIlIll = llIIlllllIllIl / fontRendererObjFONT_HEIGHT;
        if ((lIIllllIIII(llIIlllllIlIll)) && (lIIlllIlIIl(llIIlllllIlIll, field_175386_A.size())))
        {
          IChatComponent llIIlllllIlIlI = (IChatComponent)field_175386_A.get(llIIlllllIlIll);
          int llIIlllllIlIIl = lIllllIll[0];
          llIIllllIlllIl = llIIlllllIlIlI.iterator();
          "".length();
          if (-" ".length() == ((0x3D ^ 0x43 ^ 0xD5 ^ 0x87) & (0x23 ^ 0x47 ^ 0x68 ^ 0x20 ^ -" ".length()))) {
            return null;
          }
          while (!lIIlllIlIll(llIIllllIlllIl.hasNext()))
          {
            IChatComponent llIIlllllIlIII = (IChatComponent)llIIllllIlllIl.next();
            if (lIIlllIIlll(llIIlllllIlIII instanceof ChatComponentText))
            {
              llIIlllllIlIIl += Minecraft.fontRendererObj.getStringWidth(((ChatComponentText)llIIlllllIlIII).getChatComponentText_TextValue());
              if (lIIllllIIll(llIIlllllIlIIl, llIIlllllIlllI)) {
                return llIIlllllIlIII;
              }
            }
          }
        }
        return null;
      }
      return null;
    }
    return null;
  }
  
  private static String lIIllIlIIll(String llIIllllIIIlIl, String llIIllllIIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llIIllllIIIlIl = new String(Base64.getDecoder().decode(llIIllllIIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llIIllllIIIIll = new StringBuilder();
    char[] llIIllllIIIIlI = llIIllllIIIlII.toCharArray();
    int llIIllllIIIIIl = lIllllIll[0];
    float llIIlllIlllIll = llIIllllIIIlIl.toCharArray();
    double llIIlllIlllIlI = llIIlllIlllIll.length;
    boolean llIIlllIlllIIl = lIllllIll[0];
    while (lIIlllIlIIl(llIIlllIlllIIl, llIIlllIlllIlI))
    {
      char llIIllllIIIllI = llIIlllIlllIll[llIIlllIlllIIl];
      "".length();
      "".length();
      if (-(95 + 126 - 151 + 71 ^ 64 + 16 - -2 + 55) > 0) {
        return null;
      }
    }
    return String.valueOf(llIIllllIIIIll);
  }
  
  private static boolean lIIlllIllll(int ???, int arg1)
  {
    int i;
    int llIIlllIlIIlll;
    return ??? == i;
  }
  
  private static void lIIllIlllII()
  {
    lIllllIII = new String[lIllllIll[47]];
    lIllllIII[lIllllIll[0]] = lIIllIlIIIl("MPlfeTfMteso4BtkSOm/ERYhgIKgcFuM", "xMalf");
    lIllllIII[lIllllIll[2]] = lIIllIlIIll("", "Vlaag");
    lIllllIII[lIllllIll[4]] = lIIllIlIIIl("QjmlAmJWWMU=", "FVwvJ");
    lIllllIII[lIllllIll[6]] = lIIllIlIIll("", "IeOSt");
    lIllllIII[lIllllIll[8]] = lIIllIlIlII("yedtB03zi14OWQ3lTH5vYQ==", "ryUVx");
    lIllllIII[lIllllIll[11]] = lIIllIlIIll("Dzo+RAMHITI=", "hOWjg");
    lIllllIII[lIllllIll[12]] = lIIllIlIlII("l5hmngRGFUk6bxeUyD/T2qV/TC2umsKo", "SYBLp");
    lIllllIII[lIllllIll[13]] = lIIllIlIIll("KAYcfQsuHRY2BA==", "OsuSh");
    lIllllIII[lIllllIll[5]] = lIIllIlIIll("KyYvfwwjPSM=", "LSFQh");
    lIllllIII[lIllllIll[18]] = lIIllIlIlII("KNbsR6aYXiI=", "jsDfW");
    lIllllIII[lIllllIll[19]] = lIIllIlIlII("vV52FZEgCE8=", "fkhcA");
    lIllllIII[lIllllIll[20]] = lIIllIlIIll("FRUQESw8Pxg=", "XVlSi");
    lIllllIII[lIllllIll[21]] = lIIllIlIlII("3CrEwhbJ67hIoad0VSwVHw==", "hTpGQ");
    lIllllIII[lIllllIll[22]] = lIIllIlIIIl("G53mOzpgXdc=", "wLwIH");
    lIllllIII[lIllllIll[23]] = lIIllIlIlII("kZ4qv4TEgMI=", "FEbLc");
    lIllllIII[lIllllIll[25]] = lIIllIlIlII("ft44C55pa2g=", "fRtjF");
    lIllllIII[lIllllIll[26]] = lIIllIlIIIl("1tR2hDRvCU8=", "ePfVV");
    lIllllIII[lIllllIll[27]] = lIIllIlIlII("6rAkV/pT9cU=", "rymIv");
    lIllllIII[lIllllIll[28]] = lIIllIlIIll("Mw==", "lQHYx");
    lIllllIII[lIllllIll[32]] = lIIllIlIlII("aQbZYg3w6tk=", "gsiZB");
    lIllllIII[lIllllIll[10]] = lIIllIlIIll("Lg==", "qiPXL");
    lIllllIII[lIllllIll[33]] = lIIllIlIlII("lMuEk1VBGFaAYOO3L6gZJQ==", "nYWuO");
    lIllllIII[lIllllIll[37]] = lIIllIlIIll("EyoGH0ITPCgBGBkqGw==", "qEitl");
    lIllllIII[lIllllIll[38]] = lIIllIlIIll("KwgJGmUvDggQJyAdAyYqOwkPHyw=", "IgfqK");
    lIllllIII[lIllllIll[40]] = lIIllIlIIIl("L4+CYBhcwEVrV1rj3oIddWrOYfI2vqP/", "FOkdd");
    lIllllIII[lIllllIll[41]] = lIIllIlIIIl("gK3hs7FmpqM=", "zIpIj");
    lIllllIII[lIllllIll[42]] = lIIllIlIIIl("nFwIu2YS1zw=", "sugoY");
    lIllllIII[lIllllIll[43]] = lIIllIlIIll("Ng==", "iOaTh");
    lIllllIII[lIllllIll[44]] = lIIllIlIlII("zhRHDCSjPEY=", "iIVfm");
    lIllllIII[lIllllIll[45]] = lIIllIlIIIl("64XFS1pVIaAtTZMUDxyiV/Ytn+z4nUf5", "TqYOM");
  }
  
  private static void lIIlllIIllI()
  {
    lIllllIll = new int[48];
    lIllllIll[0] = ((0xEE ^ 0xA1) & (0xC ^ 0x43 ^ 0xFFFFFFFF));
    lIllllIll[1] = ((0x5B ^ 0x1D) + "  ".length() - -(0x2A ^ 0x5C) + "  ".length());
    lIllllIll[2] = " ".length();
    lIllllIll[3] = (-" ".length());
    lIllllIll[4] = "  ".length();
    lIllllIll[5] = (0x96 ^ 0x9A ^ 0x3E ^ 0x3A);
    lIllllIll[6] = "   ".length();
    lIllllIll[7] = (0xCF ^ 0xAB);
    lIllllIll[8] = (0xC8 ^ 0x98 ^ 0xFE ^ 0xAA);
    lIllllIll[9] = (0xBC ^ 0x8F ^ 0x4A ^ 0x1B);
    lIllllIll[10] = (0xA6 ^ 0xB2);
    lIllllIll[11] = (0x63 ^ 0x25 ^ 0x67 ^ 0x24);
    lIllllIll[12] = (0x87 ^ 0x8D ^ 0x8B ^ 0x87);
    lIllllIll[13] = (0xDA ^ 0xBA ^ 0x7B ^ 0x1C);
    lIllllIll[14] = (127 + 65 - 93 + 33 + (0x1B ^ 0x38) - (0x68 ^ 0x19) + ('' + 38 - 155 + 131));
    lIllllIll[15] = (0xD7 ^ 0x8A ^ 0x81 ^ 0xA4);
    lIllllIll[16] = ((0x1 ^ 0x5C) + (0x59 ^ 0x0) - (0x12 ^ 0x40) + (0x4D ^ 0x7B));
    lIllllIll[17] = (0x5E ^ 0x78);
    lIllllIll[18] = (24 + 45 - -67 + 67 ^ 119 + '¶' - 230 + 123);
    lIllllIll[19] = (0xB5 ^ 0xBF);
    lIllllIll[20] = (0x33 ^ 0x25 ^ 0x21 ^ 0x3C);
    lIllllIll[21] = (97 + 90 - 135 + 85 ^ 31 + 38 - 58 + 122);
    lIllllIll[22] = (0x93 ^ 0x9E);
    lIllllIll[23] = (0x5C ^ 0x51 ^ "   ".length());
    lIllllIll[24] = (0xE7 ^ 0x94 ^ 0xC1 ^ 0x80);
    lIllllIll[25] = (0x73 ^ 0x7C);
    lIllllIll[26] = (0x45 ^ 0x55);
    lIllllIll[27] = (0x96 ^ 0x87);
    lIllllIll[28] = (0xB9 ^ 0xAB);
    lIllllIll[29] = (0x60 ^ 0x33 ^ 0x97 ^ 0xB2);
    lIllllIll[30] = ((0x34 ^ 0x5B) + (0xBB ^ 0x8C) - (30 + 100 - 71 + 97) + (0x71 ^ 0x7));
    lIllllIll[31] = (0xEFD7 & 0x1128);
    lIllllIll[32] = (0xA0 ^ 0x95 ^ 0x5E ^ 0x78);
    lIllllIll[33] = (0xD0 ^ 0xC5);
    lIllllIll[34] = (0x23 ^ 0x3C ^ 0x29 ^ 0x12);
    lIllllIll[35] = (0x7B ^ 0x50 ^ 0x59 ^ 0x6);
    lIllllIll[36] = (0xCB ^ 0xB9 ^ 0x3 ^ 0x41);
    lIllllIll[37] = (0x8C ^ 0x9A);
    lIllllIll[38] = (0x8E ^ 0x99);
    lIllllIll[39] = (0x50 ^ 0x3D ^ 0x1A ^ 0x27);
    lIllllIll[40] = (0x4 ^ 0x1C);
    lIllllIll[41] = ('' + 18 - -40 + 19 ^ '' + '¶' - 204 + 77);
    lIllllIll[42] = (0x55 ^ 0x4F);
    lIllllIll[43] = (0x2C ^ 0x37);
    lIllllIll[44] = (0x89 ^ 0x95);
    lIllllIll[45] = (0x89 ^ 0x94);
    lIllllIll[46] = (0x81 ^ 0xA4 ^ 0x27 ^ 0x2E);
    lIllllIll[47] = ('£' + '¤' - 247 + 105 ^ 126 + 42 - 49 + 48);
  }
  
  private static String lIIllIlIIIl(String llIIllllIlIIll, String llIIllllIlIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIIllllIllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llIIllllIlIIlI.getBytes(StandardCharsets.UTF_8)), lIllllIll[5]), "DES");
      Cipher llIIllllIlIlll = Cipher.getInstance("DES");
      llIIllllIlIlll.init(lIllllIll[4], llIIllllIllIII);
      return new String(llIIllllIlIlll.doFinal(Base64.getDecoder().decode(llIIllllIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIIllllIlIllI)
    {
      llIIllllIlIllI.printStackTrace();
    }
    return null;
  }
  
  private void updateButtons()
  {
    ;
    if ((lIIlllIlIll(bookGettingSigned)) && ((!lIIlllIllII(currPage, bookTotalPages - lIllllIll[2])) || (lIIlllIIlll(bookIsUnsigned))))
    {
      "".length();
      if ("  ".length() > -" ".length()) {
        break label76;
      }
    }
    label76:
    lIllllIll2visible = lIllllIll[0];
    if ((lIIlllIlIll(bookGettingSigned)) && (lIIlllIllIl(currPage)))
    {
      "".length();
      if (-" ".length() < ((0x7B ^ 0x4A) & (0xAC ^ 0x9D ^ 0xFFFFFFFF))) {
        break label144;
      }
    }
    label144:
    lIllllIll2visible = lIllllIll[0];
    if ((lIIlllIIlll(bookIsUnsigned)) && (lIIlllIIlll(bookGettingSigned)))
    {
      "".length();
      if ((("  ".length() ^ 0xE2 ^ 0xBD) & (0x5F ^ 0x45 ^ 0xDD ^ 0x9A ^ -" ".length())) == 0) {
        break label226;
      }
    }
    label226:
    lIllllIll0visible = lIllllIll[2];
    if (lIIlllIIlll(bookIsUnsigned))
    {
      if (lIIlllIIlll(bookGettingSigned))
      {
        "".length();
        if (((0x38 ^ 0xE ^ 0xB4 ^ 0x92) & (2 + 104 - -39 + 15 ^ '' + 32 - 112 + 100 ^ -" ".length())) >= 0) {
          break label317;
        }
      }
      label317:
      lIllllIll0visible = lIllllIll[2];
      buttonCancel.visible = bookGettingSigned;
      buttonFinalize.visible = bookGettingSigned;
      if (lIIlllIllIl(bookTitle.trim().length()))
      {
        "".length();
        if (-" ".length() <= ((0x29 ^ 0x6B) & (0xDC ^ 0x9E ^ 0xFFFFFFFF))) {
          break label403;
        }
      }
      label403:
      lIllllIll2enabled = lIllllIll[0];
    }
  }
  
  private static boolean lIIllllIIll(int ???, int arg1)
  {
    int i;
    Exception llIIlllIIlIlll;
    return ??? > i;
  }
  
  private static boolean lIIlllIlIII(Object ???)
  {
    byte llIIlllIIlIlIl;
    return ??? != null;
  }
  
  private void pageSetCurrent(String llIlIIIlIllllI)
  {
    ;
    ;
    if ((lIIlllIlIII(bookPages)) && (lIIllllIIII(currPage)) && (lIIlllIlIIl(currPage, bookPages.tagCount())))
    {
      bookPages.set(currPage, new NBTTagString(llIlIIIlIllllI));
      bookIsModified = lIllllIll[2];
    }
  }
  
  public void updateScreen()
  {
    ;
    llIlIIlIlIllll.updateScreen();
    updateCount += lIllllIll[2];
  }
  
  public GuiScreenBook(EntityPlayer llIlIIlIllIlII, ItemStack llIlIIlIlllIII, boolean llIlIIlIllIIlI)
  {
    editingPlayer = llIlIIlIllIlII;
    bookObj = llIlIIlIlllIII;
    bookIsUnsigned = llIlIIlIllIIlI;
    if (lIIlllIIlll(llIlIIlIlllIII.hasTagCompound()))
    {
      NBTTagCompound llIlIIlIllIllI = llIlIIlIlllIII.getTagCompound();
      bookPages = llIlIIlIllIllI.getTagList(lIllllIII[lIllllIll[4]], lIllllIll[5]);
      if (lIIlllIlIII(bookPages))
      {
        bookPages = ((NBTTagList)bookPages.copy());
        bookTotalPages = bookPages.tagCount();
        if (lIIlllIlIIl(bookTotalPages, lIllllIll[2])) {
          bookTotalPages = lIllllIll[2];
        }
      }
    }
    if ((lIIlllIlIlI(bookPages)) && (lIIlllIIlll(llIlIIlIllIIlI)))
    {
      bookPages = new NBTTagList();
      bookPages.appendTag(new NBTTagString(lIllllIII[lIllllIll[6]]));
      bookTotalPages = lIllllIll[2];
    }
  }
  
  public void drawScreen(int llIlIIIIlllllI, int llIlIIIIlIIllI, float llIlIIIIllllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(bookGuiTextures);
    int llIlIIIIlllIll = (width - bookImageWidth) / lIllllIll[4];
    int llIlIIIIlllIlI = lIllllIll[4];
    llIlIIIIlIlIII.drawTexturedModalRect(llIlIIIIlllIll, llIlIIIIlllIlI, lIllllIll[0], lIllllIll[0], bookImageWidth, bookImageHeight);
    if (lIIlllIIlll(bookGettingSigned))
    {
      String llIlIIIIlllIIl = bookTitle;
      if (lIIlllIIlll(bookIsUnsigned)) {
        if (lIIlllIlIll(updateCount / lIllllIll[12] % lIllllIll[4]))
        {
          llIlIIIIlllIIl = String.valueOf(new StringBuilder(String.valueOf(llIlIIIIlllIIl)).append(EnumChatFormatting.BLACK).append(lIllllIII[lIllllIll[32]]));
          "".length();
          if ("  ".length() >= 0) {}
        }
        else
        {
          llIlIIIIlllIIl = String.valueOf(new StringBuilder(String.valueOf(llIlIIIIlllIIl)).append(EnumChatFormatting.GRAY).append(lIllllIII[lIllllIll[10]]));
        }
      }
      String llIlIIIIlllIII = I18n.format(lIllllIII[lIllllIll[33]], new Object[lIllllIll[0]]);
      int llIlIIIIllIlll = fontRendererObj.getStringWidth(llIlIIIIlllIII);
      "".length();
      int llIlIIIIllIllI = fontRendererObj.getStringWidth(llIlIIIIlllIIl);
      "".length();
      String llIlIIIIllIlIl = I18n.format(lIllllIII[lIllllIll[37]], new Object[] { editingPlayer.getName() });
      int llIlIIIIllIlII = fontRendererObj.getStringWidth(llIlIIIIllIlIl);
      new StringBuilder();
      "".length();
      String llIlIIIIllIIll = I18n.format(lIllllIII[lIllllIll[38]], new Object[lIllllIll[0]]);
      fontRendererObj.drawSplitString(llIlIIIIllIIll, llIlIIIIlllIll + lIllllIll[34], llIlIIIIlllIlI + lIllllIll[39], lIllllIll[35], lIllllIll[0]);
      "".length();
      if (" ".length() > 0) {}
    }
    else
    {
      String llIlIIIIllIIlI = I18n.format(lIllllIII[lIllllIll[40]], new Object[] { Integer.valueOf(currPage + lIllllIll[2]), Integer.valueOf(bookTotalPages) });
      String llIlIIIIllIIIl = lIllllIII[lIllllIll[41]];
      if ((lIIlllIlIII(bookPages)) && (lIIllllIIII(currPage)) && (lIIlllIlIIl(currPage, bookPages.tagCount()))) {
        llIlIIIIllIIIl = bookPages.getStringTagAt(currPage);
      }
      if (lIIlllIIlll(bookIsUnsigned))
      {
        if (lIIlllIIlll(fontRendererObj.getBidiFlag()))
        {
          llIlIIIIllIIIl = String.valueOf(new StringBuilder(String.valueOf(llIlIIIIllIIIl)).append(lIllllIII[lIllllIll[42]]));
          "".length();
          if (((0xC9 ^ 0x82) & (0xCD ^ 0x86 ^ 0xFFFFFFFF)) == 0) {}
        }
        else if (lIIlllIlIll(updateCount / lIllllIll[12] % lIllllIll[4]))
        {
          llIlIIIIllIIIl = String.valueOf(new StringBuilder(String.valueOf(llIlIIIIllIIIl)).append(EnumChatFormatting.BLACK).append(lIllllIII[lIllllIll[43]]));
          "".length();
          if (-" ".length() <= 0) {}
        }
        else
        {
          llIlIIIIllIIIl = String.valueOf(new StringBuilder(String.valueOf(llIlIIIIllIIIl)).append(EnumChatFormatting.GRAY).append(lIllllIII[lIllllIll[44]]));
          "".length();
          if (-"  ".length() <= 0) {}
        }
      }
      else if (lIIllllIIIl(field_175387_B, currPage))
      {
        if (lIIlllIIlll(ItemEditableBook.validBookTagContents(bookObj.getTagCompound())))
        {
          try
          {
            IChatComponent llIlIIIIllIIII = IChatComponent.Serializer.jsonToComponent(llIlIIIIllIIIl);
            if (lIIlllIlIII(llIlIIIIllIIII))
            {
              "".length();
              if (((0x2B ^ 0x3F) & (0x2B ^ 0x3F ^ 0xFFFFFFFF)) == 0) {
                break label993;
              }
            }
            label993:
            func_178908_alIllllIll35fontRendererObj, lIllllIll[2], lIllllIll[2]).field_175386_A = null;
            "".length();
            if ("   ".length() == "   ".length()) {
              break label1094;
            }
            return;
          }
          catch (JsonParseException llIlIIIIlIllll)
          {
            field_175386_A = null;
            "".length();
            if ("   ".length() >= -" ".length()) {
              break label1094;
            }
          }
        }
        else
        {
          ChatComponentText llIlIIIIlIlllI = new ChatComponentText(String.valueOf(new StringBuilder(String.valueOf(EnumChatFormatting.DARK_RED.toString())).append(lIllllIII[lIllllIll[45]])));
          field_175386_A = Lists.newArrayList(llIlIIIIlIlllI);
        }
        label1094:
        field_175387_B = currPage;
      }
      int llIlIIIIlIllIl = fontRendererObj.getStringWidth(llIlIIIIllIIlI);
      "".length();
      if (lIIlllIlIlI(field_175386_A))
      {
        fontRendererObj.drawSplitString(llIlIIIIllIIIl, llIlIIIIlllIll + lIllllIll[34], llIlIIIIlllIlI + lIllllIll[26] + lIllllIll[26], lIllllIll[35], lIllllIll[0]);
        "".length();
        if (-"   ".length() < 0) {}
      }
      else
      {
        int llIlIIIIlIllII = Math.min(lIllllIll[30] / fontRendererObj.FONT_HEIGHT, field_175386_A.size());
        int llIlIIIIlIlIll = lIllllIll[0];
        "".length();
        if ("   ".length() <= 0) {
          return;
        }
        while (!lIIlllIllII(llIlIIIIlIlIll, llIlIIIIlIllII))
        {
          IChatComponent llIlIIIIlIlIlI = (IChatComponent)field_175386_A.get(llIlIIIIlIlIll);
          "".length();
        }
        IChatComponent llIlIIIIlIlIIl = llIlIIIIlIlIII.func_175385_b(llIlIIIIlllllI, llIlIIIIlIIllI);
        if (lIIlllIlIII(llIlIIIIlIlIIl)) {
          llIlIIIIlIlIII.handleComponentHover(llIlIIIIlIlIIl, llIlIIIIlllllI, llIlIIIIlIIllI);
        }
      }
    }
    llIlIIIIlIlIII.drawScreen(llIlIIIIlllllI, llIlIIIIlIIllI, llIlIIIIllllII);
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    buttonList.clear();
    Keyboard.enableRepeatEvents(lIllllIll[2]);
    if (lIIlllIIlll(bookIsUnsigned))
    {
      buttonSign = new GuiButton(lIllllIll[6], width / lIllllIll[4] - lIllllIll[7], lIllllIll[8] + bookImageHeight, lIllllIll[9], lIllllIll[10], I18n.format(lIllllIII[lIllllIll[8]], new Object[lIllllIll[0]]));
      "".length();
      buttonDone = new GuiButton(lIllllIll[0], width / lIllllIll[4] + lIllllIll[4], lIllllIll[8] + bookImageHeight, lIllllIll[9], lIllllIll[10], I18n.format(lIllllIII[lIllllIll[11]], new Object[lIllllIll[0]]));
      "".length();
      buttonFinalize = new GuiButton(lIllllIll[11], width / lIllllIll[4] - lIllllIll[7], lIllllIll[8] + bookImageHeight, lIllllIll[9], lIllllIll[10], I18n.format(lIllllIII[lIllllIll[12]], new Object[lIllllIll[0]]));
      "".length();
      buttonCancel = new GuiButton(lIllllIll[8], width / lIllllIll[4] + lIllllIll[4], lIllllIll[8] + bookImageHeight, lIllllIll[9], lIllllIll[10], I18n.format(lIllllIII[lIllllIll[13]], new Object[lIllllIll[0]]));
      "".length();
      "".length();
      if (((0x52 ^ 0x18) & (0x0 ^ 0x4A ^ 0xFFFFFFFF)) < (0x17 ^ 0x13)) {}
    }
    else
    {
      buttonDone = new GuiButton(lIllllIll[0], width / lIllllIll[4] - lIllllIll[7], lIllllIll[8] + bookImageHeight, lIllllIll[14], lIllllIll[10], I18n.format(lIllllIII[lIllllIll[5]], new Object[lIllllIll[0]]));
      "".length();
    }
    int llIlIIlIlIlIIl = (width - bookImageWidth) / lIllllIll[4];
    int llIlIIlIlIlIII = lIllllIll[4];
    buttonNextPage = new NextPageButton(lIllllIll[2], llIlIIlIlIlIIl + lIllllIll[15], llIlIIlIlIlIII + lIllllIll[16], lIllllIll[2]);
    "".length();
    buttonPreviousPage = new NextPageButton(lIllllIll[4], llIlIIlIlIlIIl + lIllllIll[17], llIlIIlIlIlIII + lIllllIll[16], lIllllIll[0]);
    "".length();
    llIlIIlIlIlIlI.updateButtons();
  }
  
  protected void keyTyped(char llIlIIIllllIll, int llIlIIIllllIlI)
    throws IOException
  {
    ;
    ;
    ;
    llIlIIIlllllII.keyTyped(llIlIIIllllllI, llIlIIIllllIlI);
    if (lIIlllIIlll(bookIsUnsigned)) {
      if (lIIlllIIlll(bookGettingSigned))
      {
        llIlIIIlllllII.keyTypedInTitle(llIlIIIllllllI, llIlIIIllllIlI);
        "".length();
        if ((0x3 ^ 0x67 ^ 0x45 ^ 0x25) >= 0) {}
      }
      else
      {
        llIlIIIlllllII.keyTypedInBook(llIlIIIllllllI, llIlIIIllllIlI);
      }
    }
  }
  
  private static boolean lIIlllIlllI(int ???, int arg1)
  {
    int i;
    Exception llIIlllIIllIll;
    return ??? <= i;
  }
  
  private void addNewPage()
  {
    ;
    if ((lIIlllIlIII(bookPages)) && (lIIlllIlIIl(bookPages.tagCount(), lIllllIll[24])))
    {
      bookPages.appendTag(new NBTTagString(lIllllIII[lIllllIll[25]]));
      bookTotalPages += lIllllIll[2];
      bookIsModified = lIllllIll[2];
    }
  }
  
  protected void mouseClicked(int llIlIIIIIlIlIl, int llIlIIIIIlIlII, int llIlIIIIIlIIll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIlllIlIll(llIlIIIIIlIIll))
    {
      IChatComponent llIlIIIIIlIIlI = llIlIIIIIlIIIl.func_175385_b(llIlIIIIIlIlIl, llIlIIIIIlIlII);
      if (lIIlllIIlll(llIlIIIIIlIIIl.handleComponentClick(llIlIIIIIlIIlI))) {
        return;
      }
    }
    llIlIIIIIlIIIl.mouseClicked(llIlIIIIIlIlIl, llIlIIIIIlIlII, llIlIIIIIlIIll);
  }
  
  private static boolean lIIlllIlIll(int ???)
  {
    short llIIlllIIIlIll;
    return ??? == 0;
  }
  
  private static boolean lIIlllIlIlI(Object ???)
  {
    float llIIlllIIIllll;
    return ??? == null;
  }
  
  private void pageInsertIntoCurrent(String llIlIIIlIlIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    String llIlIIIlIlIlII = llIlIIIlIlIIIl.pageGetCurrent();
    String llIlIIIlIlIIll = String.valueOf(new StringBuilder(String.valueOf(llIlIIIlIlIlII)).append(llIlIIIlIlIlIl));
    int llIlIIIlIlIIlI = fontRendererObj.splitStringWidth(String.valueOf(new StringBuilder(String.valueOf(llIlIIIlIlIIll)).append(EnumChatFormatting.BLACK).append(lIllllIII[lIllllIll[28]])), lIllllIll[29]);
    if ((lIIlllIlllI(llIlIIIlIlIIlI, lIllllIll[30])) && (lIIlllIlIIl(llIlIIIlIlIIll.length(), lIllllIll[31]))) {
      llIlIIIlIlIIIl.pageSetCurrent(llIlIIIlIlIIll);
    }
  }
  
  private void sendBookToServer(boolean llIlIIlIIllIIl)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIIlllIIlll(bookIsUnsigned)) && (lIIlllIIlll(bookIsModified)) && (lIIlllIlIII(bookPages)))
    {
      "".length();
      if (null != null) {
        return;
      }
      while (!lIIlllIlllI(bookPages.tagCount(), lIllllIll[2]))
      {
        String llIlIIlIIllIII = bookPages.getStringTagAt(bookPages.tagCount() - lIllllIll[2]);
        if (lIIlllIIlll(llIlIIlIIllIII.length()))
        {
          "".length();
          if (null == null) {
            break;
          }
          return;
        }
        "".length();
      }
      if (lIIlllIIlll(bookObj.hasTagCompound()))
      {
        NBTTagCompound llIlIIlIIlIlll = bookObj.getTagCompound();
        llIlIIlIIlIlll.setTag(lIllllIII[lIllllIll[18]], bookPages);
        "".length();
        if ((0x69 ^ 0x6D) > -" ".length()) {}
      }
      else
      {
        bookObj.setTagInfo(lIllllIII[lIllllIll[19]], bookPages);
      }
      String llIlIIlIIlIllI = lIllllIII[lIllllIll[20]];
      if (lIIlllIIlll(llIlIIlIIllIIl))
      {
        llIlIIlIIlIllI = lIllllIII[lIllllIll[21]];
        bookObj.setTagInfo(lIllllIII[lIllllIll[22]], new NBTTagString(editingPlayer.getName()));
        bookObj.setTagInfo(lIllllIII[lIllllIll[23]], new NBTTagString(bookTitle.trim()));
        int llIlIIlIIlIlIl = lIllllIll[0];
        "".length();
        if (null != null) {
          return;
        }
        while (!lIIlllIllII(llIlIIlIIlIlIl, bookPages.tagCount()))
        {
          String llIlIIlIIlIlII = bookPages.getStringTagAt(llIlIIlIIlIlIl);
          IChatComponent llIlIIlIIlIIll = new ChatComponentText(llIlIIlIIlIlII);
          llIlIIlIIlIlII = IChatComponent.Serializer.componentToJson(llIlIIlIIlIIll);
          bookPages.set(llIlIIlIIlIlIl, new NBTTagString(llIlIIlIIlIlII));
        }
        bookObj.setItem(Items.written_book);
      }
      PacketBuffer llIlIIlIIlIIlI = new PacketBuffer(Unpooled.buffer());
      llIlIIlIIlIIlI.writeItemStackToBuffer(bookObj);
      mc.getNetHandler().addToSendQueue(new C17PacketCustomPayload(llIlIIlIIlIllI, llIlIIlIIlIIlI));
    }
  }
  
  static
  {
    lIIlllIIllI();
    lIIllIlllII();
    logger = LogManager.getLogger();
  }
  
  private static boolean lIIlllIIlll(int ???)
  {
    int llIIlllIIIllIl;
    return ??? != 0;
  }
  
  private static boolean lIIllllIIIl(int ???, int arg1)
  {
    int i;
    double llIIlllIIIIIll;
    return ??? != i;
  }
  
  private static boolean lIIlllIllIl(int ???)
  {
    double llIIlllIIIIlll;
    return ??? > 0;
  }
  
  private void keyTypedInTitle(char llIlIIIllIlIIl, int llIlIIIllIIlIl)
    throws IOException
  {
    ;
    ;
    ;
    switch (llIlIIIllIIlIl)
    {
    case 14: 
      if (lIIlllIlIll(bookTitle.isEmpty()))
      {
        bookTitle = bookTitle.substring(lIllllIll[0], bookTitle.length() - lIllllIll[2]);
        llIlIIIllIlIlI.updateButtons();
      }
      return;
    case 28: 
    case 156: 
      if (lIIlllIlIll(bookTitle.isEmpty()))
      {
        llIlIIIllIlIlI.sendBookToServer(lIllllIll[2]);
        mc.displayGuiScreen(null);
      }
      return;
    }
    if ((lIIlllIlIIl(bookTitle.length(), lIllllIll[26])) && (lIIlllIIlll(ChatAllowedCharacters.isAllowedCharacter(llIlIIIllIIllI))))
    {
      bookTitle = String.valueOf(new StringBuilder(String.valueOf(bookTitle)).append(Character.toString(llIlIIIllIIllI)));
      llIlIIIllIlIlI.updateButtons();
      bookIsModified = lIllllIll[2];
    }
  }
  
  private static boolean lIIlllIllII(int ???, int arg1)
  {
    int i;
    byte llIIlllIlIIIll;
    return ??? >= i;
  }
  
  private static boolean lIIllllIIlI(Object ???, Object arg1)
  {
    Object localObject;
    long llIIlllIIlIIIl;
    return ??? == localObject;
  }
  
  private void keyTypedInBook(char llIlIIIlllIIII, int llIlIIIlllIIll)
  {
    ;
    ;
    ;
    ;
    if (lIIlllIIlll(GuiScreen.isKeyComboCtrlV(llIlIIIlllIIll)))
    {
      llIlIIIlllIIIl.pageInsertIntoCurrent(GuiScreen.getClipboardString());
      "".length();
      if (-" ".length() <= " ".length()) {}
    }
    else
    {
      switch (llIlIIIlllIIll)
      {
      case 14: 
        String llIlIIIlllIIlI = llIlIIIlllIIIl.pageGetCurrent();
        if (lIIlllIllIl(llIlIIIlllIIlI.length())) {
          llIlIIIlllIIIl.pageSetCurrent(llIlIIIlllIIlI.substring(lIllllIll[0], llIlIIIlllIIlI.length() - lIllllIll[2]));
        }
        return;
      case 28: 
      case 156: 
        llIlIIIlllIIIl.pageInsertIntoCurrent(lIllllIII[lIllllIll[26]]);
        return;
      }
      if (lIIlllIIlll(ChatAllowedCharacters.isAllowedCharacter(llIlIIIlllIlII))) {
        llIlIIIlllIIIl.pageInsertIntoCurrent(Character.toString(llIlIIIlllIlII));
      }
    }
  }
  
  protected boolean handleComponentClick(IChatComponent llIlIIIIIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIlllIlIlI(llIlIIIIIIIIII))
    {
      "".length();
      if (((0x1F ^ 0x5D) & (0xDE ^ 0x9C ^ 0xFFFFFFFF)) <= 0) {
        break label59;
      }
      return (0x9C ^ 0x92) & (0xA1 ^ 0xAF ^ 0xFFFFFFFF);
    }
    label59:
    ClickEvent llIlIIIIIIIlIl = llIlIIIIIIIIII.getChatStyle().getChatClickEvent();
    if (lIIlllIlIlI(llIlIIIIIIIlIl)) {
      return lIllllIll[0];
    }
    if (lIIllllIIlI(llIlIIIIIIIlIl.getAction(), ClickEvent.Action.CHANGE_PAGE))
    {
      String llIlIIIIIIIlII = llIlIIIIIIIlIl.getValue();
      try
      {
        int llIlIIIIIIIIll = Integer.parseInt(llIlIIIIIIIlII) - lIllllIll[2];
        if ((lIIllllIIII(llIlIIIIIIIIll)) && (lIIlllIlIIl(llIlIIIIIIIIll, bookTotalPages)) && (lIIllllIIIl(llIlIIIIIIIIll, currPage)))
        {
          currPage = llIlIIIIIIIIll;
          llIlIIIIIIIlll.updateButtons();
          return lIllllIll[2];
        }
      }
      catch (Throwable localThrowable) {}
      return lIllllIll[0];
    }
    boolean llIlIIIIIIIIlI = llIlIIIIIIIlll.handleComponentClick(llIlIIIIIIIIII);
    if ((lIIlllIIlll(llIlIIIIIIIIlI)) && (lIIllllIIlI(llIlIIIIIIIlIl.getAction(), ClickEvent.Action.RUN_COMMAND))) {
      mc.displayGuiScreen(null);
    }
    return llIlIIIIIIIIlI;
  }
  
  private String pageGetCurrent()
  {
    ;
    if ((lIIlllIlIII(bookPages)) && (lIIllllIIII(currPage)) && (lIIlllIlIIl(currPage, bookPages.tagCount())))
    {
      "".length();
      if (((0xA0 ^ 0x9C) & (0x61 ^ 0x5D ^ 0xFFFFFFFF)) == 0) {
        break label84;
      }
      return null;
    }
    label84:
    return lIllllIII[lIllllIll[27]];
  }
  
  private static boolean lIIlllIlIIl(int ???, int arg1)
  {
    int i;
    int llIIlllIIlllll;
    return ??? < i;
  }
  
  public void onGuiClosed()
  {
    Keyboard.enableRepeatEvents(lIllllIll[0]);
  }
  
  static class NextPageButton
    extends GuiButton
  {
    static
    {
      llllIIIIIlII();
      llllIIIIIIII();
    }
    
    public NextPageButton(int lllllllllllllllllIIlllIIIIIIIIIl, int lllllllllllllllllIIlllIIIIIIIIII, int lllllllllllllllllIIlllIIIIIIIlII, boolean lllllllllllllllllIIllIlllllllllI)
    {
      lllllllllllllllllIIlllIIIIIIIlll.<init>(lllllllllllllllllIIlllIIIIIIIIIl, lllllllllllllllllIIlllIIIIIIIlIl, lllllllllllllllllIIlllIIIIIIIlII, lIIllIIIIIl[0], lIIllIIIIIl[1], lIIlIllllll[lIIllIIIIIl[2]]);
      field_146151_o = lllllllllllllllllIIllIlllllllllI;
    }
    
    private static boolean llllIIIIIllI(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllllIIllIllllIIllIl;
      return ??? >= i;
    }
    
    private static void llllIIIIIIII()
    {
      lIIlIllllll = new String[lIIllIIIIIl[3]];
      lIIlIllllll[lIIllIIIIIl[2]] = lllIllllllll("", "xLRHe");
    }
    
    public void drawButton(Minecraft lllllllllllllllllIIllIlllllIlllI, int lllllllllllllllllIIllIllllllIlII, int lllllllllllllllllIIllIlllllIllII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      if (llllIIIIIlIl(visible))
      {
        if ((llllIIIIIllI(lllllllllllllllllIIllIllllllIlII, xPosition)) && (llllIIIIIllI(lllllllllllllllllIIllIlllllIllII, yPosition)) && (llllIIIIIlll(lllllllllllllllllIIllIllllllIlII, xPosition + width)) && (llllIIIIIlll(lllllllllllllllllIIllIlllllIllII, yPosition + height)))
        {
          "".length();
          if ((0xEC ^ 0xAE ^ 0x66 ^ 0x20) > " ".length()) {
            break label102;
          }
        }
        label102:
        boolean lllllllllllllllllIIllIllllllIIlI = lIIllIIIIIl[2];
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        lllllllllllllllllIIllIlllllIlllI.getTextureManager().bindTexture(GuiScreenBook.bookGuiTextures);
        int lllllllllllllllllIIllIllllllIIIl = lIIllIIIIIl[2];
        int lllllllllllllllllIIllIllllllIIII = lIIllIIIIIl[4];
        if (llllIIIIIlIl(lllllllllllllllllIIllIllllllIIlI)) {
          lllllllllllllllllIIllIllllllIIIl += 23;
        }
        if (llllIIIIlIII(field_146151_o)) {
          lllllllllllllllllIIllIllllllIIII += 13;
        }
        lllllllllllllllllIIllIllllllIllI.drawTexturedModalRect(xPosition, yPosition, lllllllllllllllllIIllIllllllIIIl, lllllllllllllllllIIllIllllllIIII, lIIllIIIIIl[0], lIIllIIIIIl[1]);
      }
    }
    
    private static String lllIllllllll(String lllllllllllllllllIIllIllllIllllI, String lllllllllllllllllIIllIllllIlllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllllIIllIllllIllllI = new String(Base64.getDecoder().decode(lllllllllllllllllIIllIllllIllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllllIIllIllllIlllII = new StringBuilder();
      char[] lllllllllllllllllIIllIllllIllIll = lllllllllllllllllIIllIllllIlllIl.toCharArray();
      int lllllllllllllllllIIllIllllIllIlI = lIIllIIIIIl[2];
      char lllllllllllllllllIIllIllllIlIlII = lllllllllllllllllIIllIllllIllllI.toCharArray();
      char lllllllllllllllllIIllIllllIlIIll = lllllllllllllllllIIllIllllIlIlII.length;
      long lllllllllllllllllIIllIllllIlIIlI = lIIllIIIIIl[2];
      while (llllIIIIIlll(lllllllllllllllllIIllIllllIlIIlI, lllllllllllllllllIIllIllllIlIIll))
      {
        char lllllllllllllllllIIllIllllIlllll = lllllllllllllllllIIllIllllIlIlII[lllllllllllllllllIIllIllllIlIIlI];
        "".length();
        "".length();
        if ("  ".length() == (0x57 ^ 0x53)) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllllIIllIllllIlllII);
    }
    
    private static boolean llllIIIIlIII(int ???)
    {
      float lllllllllllllllllIIllIllllIIIlIl;
      return ??? == 0;
    }
    
    private static boolean llllIIIIIlll(int ???, int arg1)
    {
      int i;
      short lllllllllllllllllIIllIllllIIlIIl;
      return ??? < i;
    }
    
    private static void llllIIIIIlII()
    {
      lIIllIIIIIl = new int[5];
      lIIllIIIIIl[0] = (0xBD ^ 0xAA);
      lIIllIIIIIl[1] = (54 + 85 - 69 + 57 ^ 0x42 ^ 0x30);
      lIIllIIIIIl[2] = ((0x9B ^ 0xBC ^ 0x3A ^ 0x11) & (0x5A ^ 0x1D ^ 0x64 ^ 0x2F ^ -" ".length()));
      lIIllIIIIIl[3] = " ".length();
      lIIllIIIIIl[4] = (109 + 58 - 157 + 182);
    }
    
    private static boolean llllIIIIIlIl(int ???)
    {
      double lllllllllllllllllIIllIllllIIIlll;
      return ??? != 0;
    }
  }
}

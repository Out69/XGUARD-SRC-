package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.realms.RealmsButton;

public class GuiButtonRealmsProxy
  extends GuiButton
{
  public GuiButtonRealmsProxy(RealmsButton llllllllllllllIlllIlIIIllIIllllI, int llllllllllllllIlllIlIIIllIIlllIl, int llllllllllllllIlllIlIIIllIlIIlII, int llllllllllllllIlllIlIIIllIIllIll, String llllllllllllllIlllIlIIIllIIllIlI, int llllllllllllllIlllIlIIIllIIllIIl, int llllllllllllllIlllIlIIIllIIllIII)
  {
    llllllllllllllIlllIlIIIllIlIIlll.<init>(llllllllllllllIlllIlIIIllIIlllIl, llllllllllllllIlllIlIIIllIlIIlII, llllllllllllllIlllIlIIIllIIllIll, llllllllllllllIlllIlIIIllIIllIIl, llllllllllllllIlllIlIIIllIIllIII, llllllllllllllIlllIlIIIllIIllIlI);
    realmsButton = llllllllllllllIlllIlIIIllIIllllI;
  }
  
  public int getButtonWidth()
  {
    ;
    return llllllllllllllIlllIlIIIllIIIIlII.getButtonWidth();
  }
  
  public void mouseDragged(Minecraft llllllllllllllIlllIlIIIlIllIIllI, int llllllllllllllIlllIlIIIlIllIIIlI, int llllllllllllllIlllIlIIIlIllIIlII)
  {
    ;
    ;
    ;
    realmsButton.renderBg(llllllllllllllIlllIlIIIlIllIIlIl, llllllllllllllIlllIlIIIlIllIIlII);
  }
  
  public int getId()
  {
    ;
    return id;
  }
  
  public void setEnabled(boolean llllllllllllllIlllIlIIIllIIIlllI)
  {
    ;
    ;
    enabled = llllllllllllllIlllIlIIIllIIIlllI;
  }
  
  public RealmsButton getRealmsButton()
  {
    ;
    return realmsButton;
  }
  
  public int func_154312_c(boolean llllllllllllllIlllIlIIIlIlIlIIlI)
  {
    ;
    ;
    return llllllllllllllIlllIlIIIlIlIlIIll.getHoverState(llllllllllllllIlllIlIIIlIlIlIIlI);
  }
  
  public int func_175232_g()
  {
    ;
    return height;
  }
  
  public void mouseReleased(int llllllllllllllIlllIlIIIlIllIllII, int llllllllllllllIlllIlIIIlIllIlIll)
  {
    ;
    ;
    ;
    realmsButton.released(llllllllllllllIlllIlIIIlIllIllll, llllllllllllllIlllIlIIIlIllIlIll);
  }
  
  public int getPositionY()
  {
    ;
    return yPosition;
  }
  
  public void setText(String llllllllllllllIlllIlIIIllIIIlIII)
  {
    ;
    ;
    displayString = llllllllllllllIlllIlIIIllIIIlIII;
  }
  
  private static boolean lIlIlllllIllll(int ???)
  {
    byte llllllllllllllIlllIlIIIlIlIIllIl;
    return ??? != 0;
  }
  
  public int getHoverState(boolean llllllllllllllIlllIlIIIlIlIllIII)
  {
    ;
    ;
    return realmsButton.getYImage(llllllllllllllIlllIlIIIlIlIllIII);
  }
  
  public GuiButtonRealmsProxy(RealmsButton llllllllllllllIlllIlIIIllIlllIlI, int llllllllllllllIlllIlIIIllIllIIll, int llllllllllllllIlllIlIIIllIlllIII, int llllllllllllllIlllIlIIIllIllIlll, String llllllllllllllIlllIlIIIllIllIIII)
  {
    llllllllllllllIlllIlIIIllIlllIll.<init>(llllllllllllllIlllIlIIIllIllIIll, llllllllllllllIlllIlIIIllIlllIII, llllllllllllllIlllIlIIIllIllIlll, llllllllllllllIlllIlIIIllIllIIII);
    realmsButton = llllllllllllllIlllIlIIIllIlllIlI;
  }
  
  public boolean mousePressed(Minecraft llllllllllllllIlllIlIIIlIllllIlI, int llllllllllllllIlllIlIIIlIllllIIl, int llllllllllllllIlllIlIIIlIlllIlII)
  {
    ;
    ;
    ;
    ;
    if (lIlIlllllIllll(llllllllllllllIlllIlIIIlIllllIll.mousePressed(llllllllllllllIlllIlIIIlIllllIlI, llllllllllllllIlllIlIIIlIllllIIl, llllllllllllllIlllIlIIIlIlllIlII))) {
      realmsButton.clicked(llllllllllllllIlllIlIIIlIllllIIl, llllllllllllllIlllIlIIIlIlllIlII);
    }
    return llllllllllllllIlllIlIIIlIllllIll.mousePressed(llllllllllllllIlllIlIIIlIllllIlI, llllllllllllllIlllIlIIIlIllllIIl, llllllllllllllIlllIlIIIlIlllIlII);
  }
  
  public boolean getEnabled()
  {
    ;
    return enabled;
  }
}

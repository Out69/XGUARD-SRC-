package net.minecraft.client.gui;

import net.minecraft.client.settings.GameSettings.Options;

public class GuiOptionButton
  extends GuiButton
{
  public GuiOptionButton(int llllllllllllllIlIllIIlllllIlIIII, int llllllllllllllIlIllIIlllllIIllll, int llllllllllllllIlIllIIlllllIlIlIl, int llllllllllllllIlIllIIlllllIIllIl, int llllllllllllllIlIllIIlllllIIllII, String llllllllllllllIlIllIIlllllIIlIll)
  {
    llllllllllllllIlIllIIlllllIllIII.<init>(llllllllllllllIlIllIIlllllIlIIII, llllllllllllllIlIllIIlllllIIllll, llllllllllllllIlIllIIlllllIIlllI, llllllllllllllIlIllIIlllllIIllIl, llllllllllllllIlIllIIlllllIIllII, llllllllllllllIlIllIIlllllIIlIll);
    enumOptions = null;
  }
  
  public GuiOptionButton(int llllllllllllllIlIllIIllllllIlIII, int llllllllllllllIlIllIIllllllIIIlI, int llllllllllllllIlIllIIllllllIIIIl, String llllllllllllllIlIllIIllllllIIlIl)
  {
    llllllllllllllIlIllIIllllllIlIIl.<init>(llllllllllllllIlIllIIllllllIlIII, llllllllllllllIlIllIIllllllIIlll, llllllllllllllIlIllIIllllllIIIIl, null, llllllllllllllIlIllIIllllllIIlIl);
  }
  
  public GuiOptionButton(int llllllllllllllIlIllIIllllIllllIl, int llllllllllllllIlIllIIllllIllllII, int llllllllllllllIlIllIIllllIlllIll, GameSettings.Options llllllllllllllIlIllIIlllllIIIIII, String llllllllllllllIlIllIIllllIlllIIl)
  {
    llllllllllllllIlIllIIllllIlllllI.<init>(llllllllllllllIlIllIIllllIllllIl, llllllllllllllIlIllIIllllIllllII, llllllllllllllIlIllIIllllIlllIll, lIIIIIllIlIll[0], lIIIIIllIlIll[1], llllllllllllllIlIllIIllllIlllIIl);
    enumOptions = llllllllllllllIlIllIIlllllIIIIII;
  }
  
  static {}
  
  public GameSettings.Options returnEnumOptions()
  {
    ;
    return enumOptions;
  }
  
  private static void llIIlIIIllIIIl()
  {
    lIIIIIllIlIll = new int[2];
    lIIIIIllIlIll[0] = ('' + 26 - 131 + 124);
    lIIIIIllIlIll[1] = (0xD7 ^ 0xC3);
  }
}

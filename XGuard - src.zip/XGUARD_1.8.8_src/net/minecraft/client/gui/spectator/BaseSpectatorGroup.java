package net.minecraft.client.gui.spectator;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.gui.spectator.categories.TeleportToPlayer;
import net.minecraft.client.gui.spectator.categories.TeleportToTeam;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

public class BaseSpectatorGroup
  implements ISpectatorMenuView
{
  static
  {
    lIIlIIlIlIlIII();
    lIIlIIlIlIIlll();
  }
  
  public BaseSpectatorGroup()
  {
    new TeleportToPlayer();
    "".length();
    new TeleportToTeam();
    "".length();
  }
  
  public IChatComponent func_178670_b()
  {
    return new ChatComponentText(llIIIIIIIlIl[llIIIIIIIllI[0]]);
  }
  
  private static void lIIlIIlIlIIlll()
  {
    llIIIIIIIlIl = new String[llIIIIIIIllI[1]];
    llIIIIIIIlIl[llIIIIIIIllI[0]] = lIIlIIlIlIIllI("a3HH7kqQC9MFn/upSvDkf8Io8ysAj6SI7oKlGCxs52lxNMNWcucb5tn5cNePGituND5/1Gr1YVU=", "TfMoo");
  }
  
  private static String lIIlIIlIlIIllI(String lllllllllllllllIIlIIllIIlIlIIlII, String lllllllllllllllIIlIIllIIlIlIIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlIIllIIlIlIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlIIllIIlIlIIIll.getBytes(StandardCharsets.UTF_8)), llIIIIIIIllI[2]), "DES");
      Cipher lllllllllllllllIIlIIllIIlIlIIllI = Cipher.getInstance("DES");
      lllllllllllllllIIlIIllIIlIlIIllI.init(llIIIIIIIllI[3], lllllllllllllllIIlIIllIIlIlIIlll);
      return new String(lllllllllllllllIIlIIllIIlIlIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlIIllIIlIlIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlIIllIIlIlIIlIl)
    {
      lllllllllllllllIIlIIllIIlIlIIlIl.printStackTrace();
    }
    return null;
  }
  
  private static void lIIlIIlIlIlIII()
  {
    llIIIIIIIllI = new int[4];
    llIIIIIIIllI[0] = ((0xBB ^ 0xBF) & (0x9F ^ 0x9B ^ 0xFFFFFFFF));
    llIIIIIIIllI[1] = " ".length();
    llIIIIIIIllI[2] = (0x14 ^ 0x1C);
    llIIIIIIIllI[3] = "  ".length();
  }
  
  public List<ISpectatorMenuObject> func_178669_a()
  {
    ;
    return field_178671_a;
  }
}

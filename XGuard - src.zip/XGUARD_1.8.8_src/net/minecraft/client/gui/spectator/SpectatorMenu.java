package net.minecraft.client.gui.spectator;

import com.google.common.collect.Lists;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiSpectator;
import net.minecraft.client.gui.spectator.categories.SpectatorDetails;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

public class SpectatorMenu
{
  private static boolean lIIlIlIIlllIl(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllllIllIIlllIIllIIll;
    return ??? != localObject;
  }
  
  private static boolean lIIlIlIIllIII(int ???)
  {
    boolean llllllllllllllllIllIIlllIIlIllll;
    return ??? == 0;
  }
  
  private static boolean lIIlIlIIlIlll(int ???)
  {
    String llllllllllllllllIllIIlllIIlIlIll;
    return ??? > 0;
  }
  
  private static boolean lIIlIlIIllIIl(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllIllIIlllIIllllll;
    return ??? == i;
  }
  
  public int func_178648_e()
  {
    ;
    return field_178660_i;
  }
  
  public void func_178647_a(ISpectatorMenuView llllllllllllllllIllIIlllIlIIlIlI)
  {
    ;
    ;
    "".length();
    field_178659_h = llllllllllllllllIllIIlllIlIIlIlI;
    field_178660_i = llIIIIIlIII[0];
    field_178658_j = llIIIIIlIII[2];
  }
  
  private static boolean lIIlIlIIlllII(int ???, int arg1)
  {
    int i;
    int llllllllllllllllIllIIlllIIllIlll;
    return ??? > i;
  }
  
  public List<ISpectatorMenuObject> func_178642_a()
  {
    ;
    ;
    ;
    List<ISpectatorMenuObject> llllllllllllllllIllIIlllIllIlIIl = Lists.newArrayList();
    int llllllllllllllllIllIIlllIllIlIII = llIIIIIlIII[2];
    "".length();
    if (null != null) {
      return null;
    }
    while (!lIIlIlIIlllII(llllllllllllllllIllIIlllIllIlIII, llIIIIIlIII[5])) {
      "".length();
    }
    return llllllllllllllllIllIIlllIllIlIIl;
  }
  
  private static void lIIlIlIIlIllI()
  {
    llIIIIIlIII = new int[6];
    llIIIIIlIII[0] = (-" ".length());
    llIIIIIlIII[1] = " ".length();
    llIIIIIlIII[2] = ((0xAC ^ 0xB6) & (0x41 ^ 0x5B ^ 0xFFFFFFFF));
    llIIIIIlIII[3] = (28 + '¯' - 190 + 168 ^ 70 + 103 - 125 + 131);
    llIIIIIlIII[4] = (0x3 ^ 0x4);
    llIIIIIlIII[5] = (45 + ' ' - 112 + 96 ^ 44 + 16 - -24 + 97);
  }
  
  public ISpectatorMenuView func_178650_c()
  {
    ;
    return field_178659_h;
  }
  
  public void func_178644_b(int llllllllllllllllIllIIlllIlIllIlI)
  {
    ;
    ;
    ;
    ISpectatorMenuObject llllllllllllllllIllIIlllIlIllIIl = llllllllllllllllIllIIlllIlIllIII.func_178643_a(llllllllllllllllIllIIlllIlIllIlI);
    if (lIIlIlIIlllIl(llllllllllllllllIllIIlllIlIllIIl, field_178657_a)) {
      if ((lIIlIlIIllIIl(field_178660_i, llllllllllllllllIllIIlllIlIllIlI)) && (lIIlIlIIllllI(llllllllllllllllIllIIlllIlIllIIl.func_178662_A_())))
      {
        llllllllllllllllIllIIlllIlIllIIl.func_178661_a(llllllllllllllllIllIIlllIlIllIII);
        "".length();
        if (" ".length() >= 0) {}
      }
      else
      {
        field_178660_i = llllllllllllllllIllIIlllIlIllIlI;
      }
    }
  }
  
  public ISpectatorMenuObject func_178645_b()
  {
    ;
    return llllllllllllllllIllIIlllIllIIIll.func_178643_a(field_178660_i);
  }
  
  public SpectatorDetails func_178646_f()
  {
    ;
    return new SpectatorDetails(field_178659_h, llllllllllllllllIllIIlllIlIIlIII.func_178642_a(), field_178660_i);
  }
  
  static
  {
    lIIlIlIIlIllI();
    field_178655_b = new EndSpectatorObject(null);
    field_178656_c = new MoveMenuObject(llIIIIIlIII[0], llIIIIIlIII[1]);
    field_178653_d = new MoveMenuObject(llIIIIIlIII[1], llIIIIIlIII[1]);
    field_178654_e = new MoveMenuObject(llIIIIIlIII[1], llIIIIIlIII[2]);
  }
  
  private static boolean lIIlIlIIllIll(int ???)
  {
    int llllllllllllllllIllIIlllIIlIllIl;
    return ??? >= 0;
  }
  
  private static boolean lIIlIlIIllIlI(int ???, int arg1)
  {
    int i;
    double llllllllllllllllIllIIlllIIlllIll;
    return ??? < i;
  }
  
  private static boolean lIIlIlIIllllI(int ???)
  {
    double llllllllllllllllIllIIlllIIllIIIl;
    return ??? != 0;
  }
  
  public SpectatorMenu(ISpectatorMenuRecipient llllllllllllllllIllIIlllIllllIIl)
  {
    field_178651_f = llllllllllllllllIllIIlllIllllIIl;
  }
  
  public void func_178641_d()
  {
    ;
    field_178651_f.func_175257_a(llllllllllllllllIllIIlllIlIlIlII);
  }
  
  public ISpectatorMenuObject func_178643_a(int llllllllllllllllIllIIlllIlllIIlI)
  {
    ;
    ;
    ;
    int llllllllllllllllIllIIlllIlllIIIl = llllllllllllllllIllIIlllIlllIIlI + field_178658_j * llIIIIIlIII[3];
    if ((lIIlIlIIlIlll(field_178658_j)) && (lIIlIlIIllIII(llllllllllllllllIllIIlllIlllIIlI)))
    {
      "".length();
      if (" ".length() > " ".length()) {
        return null;
      }
    }
    else if (lIIlIlIIllIIl(llllllllllllllllIllIIlllIlllIIlI, llIIIIIlIII[4]))
    {
      if (lIIlIlIIllIlI(llllllllllllllllIllIIlllIlllIIIl, field_178659_h.func_178669_a().size()))
      {
        "".length();
        if (null != null) {
          return null;
        }
      }
      else
      {
        "".length();
        if (-(0xD ^ 0x9) >= 0) {
          return null;
        }
      }
    }
    else if (lIIlIlIIllIIl(llllllllllllllllIllIIlllIlllIIlI, llIIIIIlIII[5]))
    {
      "".length();
      if (-" ".length() < -" ".length()) {
        return null;
      }
    }
    else if ((lIIlIlIIllIll(llllllllllllllllIllIIlllIlllIIIl)) && (lIIlIlIIllIlI(llllllllllllllllIllIIlllIlllIIIl, field_178659_h.func_178669_a().size())))
    {
      "".length();
      if ((0xA8 ^ 0xAC) > "   ".length()) {
        break label241;
      }
      return null;
    }
    label241:
    return field_178657_a;
  }
  
  static class MoveMenuObject
    implements ISpectatorMenuObject
  {
    private static boolean llIIIlllIlIl(int ???)
    {
      String llllllllllllllllllIIIlIIllIlllIl;
      return ??? < 0;
    }
    
    static
    {
      llIIIlllIlII();
      llIIIlllIIll();
    }
    
    private static void llIIIlllIIll()
    {
      lllllIlIll = new String[lllllIllII[3]];
      lllllIlIll[lllllIllII[0]] = llIIIlllIIIl("OB0fDiUHGglYHAkIHw==", "hozxL");
      lllllIlIll[lllllIllII[1]] = llIIIlllIIlI("fFg5FT5I36SRbDxdqMrEBg==", "EpLkv");
    }
    
    private static void llIIIlllIlII()
    {
      lllllIllII = new int[5];
      lllllIllII[0] = ((0x6A ^ 0x6F) & (0x9C ^ 0x99 ^ 0xFFFFFFFF));
      lllllIllII[1] = " ".length();
      lllllIllII[2] = (0x7F ^ 0x71 ^ 0x14 ^ 0xA);
      lllllIllII[3] = "  ".length();
      lllllIllII[4] = (0x9E ^ 0x94 ^ "  ".length());
    }
    
    private static String llIIIlllIIlI(String llllllllllllllllllIIIlIIlllIlIII, String llllllllllllllllllIIIlIIlllIIlIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllllllIIIlIIlllIlIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIIIlIIlllIIlIl.getBytes(StandardCharsets.UTF_8)), lllllIllII[4]), "DES");
        Cipher llllllllllllllllllIIIlIIlllIlIlI = Cipher.getInstance("DES");
        llllllllllllllllllIIIlIIlllIlIlI.init(lllllIllII[3], llllllllllllllllllIIIlIIlllIlIll);
        return new String(llllllllllllllllllIIIlIIlllIlIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllllIIIlIIlllIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllllllIIIlIIlllIlIIl)
      {
        llllllllllllllllllIIIlIIlllIlIIl.printStackTrace();
      }
      return null;
    }
    
    public boolean func_178662_A_()
    {
      ;
      return field_178665_b;
    }
    
    private static String llIIIlllIIIl(String llllllllllllllllllIIIlIIllllllIl, String llllllllllllllllllIIIlIIllllllII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllllllIIIlIIllllllIl = new String(Base64.getDecoder().decode(llllllllllllllllllIIIlIIllllllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllllllIIIlIIlllllIll = new StringBuilder();
      char[] llllllllllllllllllIIIlIIlllllIlI = llllllllllllllllllIIIlIIllllllII.toCharArray();
      int llllllllllllllllllIIIlIIlllllIIl = lllllIllII[0];
      char llllllllllllllllllIIIlIIllllIIll = llllllllllllllllllIIIlIIllllllIl.toCharArray();
      byte llllllllllllllllllIIIlIIllllIIlI = llllllllllllllllllIIIlIIllllIIll.length;
      short llllllllllllllllllIIIlIIllllIIIl = lllllIllII[0];
      while (llIIIlllIllI(llllllllllllllllllIIIlIIllllIIIl, llllllllllllllllllIIIlIIllllIIlI))
      {
        char llllllllllllllllllIIIlIIlllllllI = llllllllllllllllllIIIlIIllllIIll[llllllllllllllllllIIIlIIllllIIIl];
        "".length();
        "".length();
        if ("  ".length() <= ((0x26 ^ 0x46 ^ 0xE7 ^ 0x82) & (0x86 ^ 0x90 ^ 0x27 ^ 0x34 ^ -" ".length()))) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllllllIIIlIIlllllIll);
    }
    
    private static boolean llIIIlllIllI(int ???, int arg1)
    {
      int i;
      byte llllllllllllllllllIIIlIIllIlllll;
      return ??? < i;
    }
    
    public void func_178661_a(SpectatorMenu llllllllllllllllllIIIlIlIIIlIIll)
    {
      ;
      ;
      field_178658_j = field_178666_a;
    }
    
    public IChatComponent getSpectatorName()
    {
      ;
      if (llIIIlllIlIl(field_178666_a))
      {
        new ChatComponentText(lllllIlIll[lllllIllII[0]]);
        "".length();
        if ("   ".length() != 0) {
          break label58;
        }
        return null;
      }
      label58:
      return new ChatComponentText(lllllIlIll[lllllIllII[1]]);
    }
    
    public void func_178663_a(float llllllllllllllllllIIIlIlIIIIllIl, int llllllllllllllllllIIIlIlIIIIllII)
    {
      ;
      Minecraft.getMinecraft().getTextureManager().bindTexture(GuiSpectator.field_175269_a);
      if (llIIIlllIlIl(field_178666_a))
      {
        Gui.drawModalRectWithCustomSizedTexture(lllllIllII[0], lllllIllII[0], 144.0F, 0.0F, lllllIllII[2], lllllIllII[2], 256.0F, 256.0F);
        "".length();
        if (((0x4F ^ 0x1B ^ 0x33 ^ 0x56) & (0x7B ^ 0x27 ^ 0x2D ^ 0x40 ^ -" ".length())) == 0) {}
      }
      else
      {
        Gui.drawModalRectWithCustomSizedTexture(lllllIllII[0], lllllIllII[0], 160.0F, 0.0F, lllllIllII[2], lllllIllII[2], 256.0F, 256.0F);
      }
    }
    
    public MoveMenuObject(int llllllllllllllllllIIIlIlIIIlllIl, boolean llllllllllllllllllIIIlIlIIIllIIl)
    {
      field_178666_a = llllllllllllllllllIIIlIlIIIllIlI;
      field_178665_b = llllllllllllllllllIIIlIlIIIllIIl;
    }
  }
  
  static class EndSpectatorObject
    implements ISpectatorMenuObject
  {
    static
    {
      lIIIIlllIIll();
      lIIIIlllIIlI();
    }
    
    public void func_178663_a(float llIIIlllIl, int llIIIlllII)
    {
      Minecraft.getMinecraft().getTextureManager().bindTexture(GuiSpectator.field_175269_a);
      Gui.drawModalRectWithCustomSizedTexture(lIlIIllIII[0], lIlIIllIII[0], 128.0F, 0.0F, lIlIIllIII[1], lIlIIllIII[1], 256.0F, 256.0F);
    }
    
    public boolean func_178662_A_()
    {
      return lIlIIllIII[2];
    }
    
    private static void lIIIIlllIIll()
    {
      lIlIIllIII = new int[5];
      lIlIIllIII[0] = ((0x5 ^ 0x4E) & (0x30 ^ 0x7B ^ 0xFFFFFFFF));
      lIlIIllIII[1] = (0x3F ^ 0x2F);
      lIlIIllIII[2] = " ".length();
      lIlIIllIII[3] = (0x9A ^ 0x92);
      lIlIIllIII[4] = "  ".length();
    }
    
    private static void lIIIIlllIIlI()
    {
      lIlIIlIlll = new String[lIlIIllIII[2]];
      lIlIIlIlll[lIlIIllIII[0]] = lIIIIlllIIIl("6Eu6lYDeHr9kj09G5ip6jA==", "baJup");
    }
    
    private EndSpectatorObject() {}
    
    public IChatComponent getSpectatorName()
    {
      return new ChatComponentText(lIlIIlIlll[lIlIIllIII[0]]);
    }
    
    private static String lIIIIlllIIIl(String llIIIIllll, String llIIIlIIII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llIIIlIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llIIIlIIII.getBytes(StandardCharsets.UTF_8)), lIlIIllIII[3]), "DES");
        Cipher llIIIlIIll = Cipher.getInstance("DES");
        llIIIlIIll.init(lIlIIllIII[4], llIIIlIlII);
        return new String(llIIIlIIll.doFinal(Base64.getDecoder().decode(llIIIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llIIIlIIlI)
      {
        llIIIlIIlI.printStackTrace();
      }
      return null;
    }
    
    public void func_178661_a(SpectatorMenu llIIlIIIII)
    {
      ;
      llIIlIIIII.func_178641_d();
    }
  }
}

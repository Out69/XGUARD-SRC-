package net.minecraft.client.gui.spectator.categories;

import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Ordering;
import com.mojang.authlib.GameProfile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiSpectator;
import net.minecraft.client.gui.spectator.ISpectatorMenuObject;
import net.minecraft.client.gui.spectator.ISpectatorMenuView;
import net.minecraft.client.gui.spectator.PlayerMenuObject;
import net.minecraft.client.gui.spectator.SpectatorMenu;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.WorldSettings.GameType;

public class TeleportToPlayer
  implements ISpectatorMenuObject, ISpectatorMenuView
{
  public void func_178663_a(float llllllllllllllllllIllIllIIIIIIIl, int llllllllllllllllllIllIllIIIIIIII)
  {
    Minecraft.getMinecraft().getTextureManager().bindTexture(GuiSpectator.field_175269_a);
    Gui.drawModalRectWithCustomSizedTexture(llIllIlIlI[0], llIllIlIlI[0], 0.0F, 0.0F, llIllIlIlI[2], llIllIlIlI[2], 256.0F, 256.0F);
  }
  
  private static void lIlIlllIIIII()
  {
    llIllIIlII = new String[llIllIlIlI[3]];
    llIllIIlII[llIllIlIlI[0]] = lIlIllIllllI("vzXa5+Zknrfjy61Kwf4JbUjboHYbsx52kObOryLf/uA=", "XfBbX");
    llIllIIlII[llIllIlIlI[1]] = lIlIllIlllll("8M91VEWHyjPEvncsI0fh1Ltwll7Lj/SH", "zZsqw");
  }
  
  public List<ISpectatorMenuObject> func_178669_a()
  {
    ;
    return field_178673_b;
  }
  
  private static boolean lIlIlllIIlll(int ???)
  {
    long llllllllllllllllllIllIlIllIlllIl;
    return ??? != 0;
  }
  
  public boolean func_178662_A_()
  {
    ;
    if (lIlIlllIIlll(field_178673_b.isEmpty()))
    {
      "".length();
      if (" ".length() > -" ".length()) {
        break label59;
      }
      return (0xF ^ 0x7) & (0x6C ^ 0x64 ^ 0xFFFFFFFF);
    }
    label59:
    return llIllIlIlI[1];
  }
  
  private static void lIlIlllIIlII()
  {
    llIllIlIlI = new int[5];
    llIllIlIlI[0] = ((0x50 ^ 0x60) & (0x49 ^ 0x79 ^ 0xFFFFFFFF));
    llIllIlIlI[1] = " ".length();
    llIllIlIlI[2] = (0xA9 ^ 0xB9);
    llIllIlIlI[3] = "  ".length();
    llIllIlIlI[4] = (0x2 ^ 0xA);
  }
  
  public IChatComponent getSpectatorName()
  {
    return new ChatComponentText(llIllIIlII[llIllIlIlI[1]]);
  }
  
  private static String lIlIllIllllI(String llllllllllllllllllIllIlIllllIIll, String llllllllllllllllllIllIlIllllIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIllIlIlllllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIllIlIllllIlII.getBytes(StandardCharsets.UTF_8)), llIllIlIlI[4]), "DES");
      Cipher llllllllllllllllllIllIlIllllIlll = Cipher.getInstance("DES");
      llllllllllllllllllIllIlIllllIlll.init(llIllIlIlI[3], llllllllllllllllllIllIlIlllllIII);
      return new String(llllllllllllllllllIllIlIllllIlll.doFinal(Base64.getDecoder().decode(llllllllllllllllllIllIlIllllIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIllIlIllllIllI)
    {
      llllllllllllllllllIllIlIllllIllI.printStackTrace();
    }
    return null;
  }
  
  public IChatComponent func_178670_b()
  {
    return new ChatComponentText(llIllIIlII[llIllIlIlI[0]]);
  }
  
  public TeleportToPlayer()
  {
    llllllllllllllllllIllIllIIIllIlI.<init>(field_178674_a.sortedCopy(Minecraft.getMinecraft().getNetHandler().getPlayerInfoMap()));
  }
  
  public TeleportToPlayer(Collection<NetworkPlayerInfo> llllllllllllllllllIllIllIIIlIIll)
  {
    boolean llllllllllllllllllIllIllIIIIlllI = field_178674_a.sortedCopy(llllllllllllllllllIllIllIIIlIIll).iterator();
    "".length();
    if (" ".length() == "  ".length()) {
      throw null;
    }
    while (!lIlIlllIIllI(llllllllllllllllllIllIllIIIIlllI.hasNext()))
    {
      NetworkPlayerInfo llllllllllllllllllIllIllIIIlIIlI = (NetworkPlayerInfo)llllllllllllllllllIllIllIIIIlllI.next();
      if (lIlIlllIIlIl(llllllllllllllllllIllIllIIIlIIlI.getGameType(), WorldSettings.GameType.SPECTATOR))
      {
        new PlayerMenuObject(llllllllllllllllllIllIllIIIlIIlI.getGameProfile());
        "".length();
      }
    }
  }
  
  private static boolean lIlIlllIIllI(int ???)
  {
    int llllllllllllllllllIllIlIllIllIll;
    return ??? == 0;
  }
  
  static
  {
    lIlIlllIIlII();
    lIlIlllIIIII();
  }
  
  private static String lIlIllIlllll(String llllllllllllllllllIllIlIlllIIllI, String llllllllllllllllllIllIlIlllIIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIllIlIlllIlIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIllIlIlllIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIllIlIlllIlIlI = Cipher.getInstance("Blowfish");
      llllllllllllllllllIllIlIlllIlIlI.init(llIllIlIlI[3], llllllllllllllllllIllIlIlllIlIll);
      return new String(llllllllllllllllllIllIlIlllIlIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllllIllIlIlllIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIllIlIlllIlIIl)
    {
      llllllllllllllllllIllIlIlllIlIIl.printStackTrace();
    }
    return null;
  }
  
  public void func_178661_a(SpectatorMenu llllllllllllllllllIllIllIIIIIllI)
  {
    ;
    ;
    llllllllllllllllllIllIllIIIIIllI.func_178647_a(llllllllllllllllllIllIllIIIIIlll);
  }
  
  private static boolean lIlIlllIIlIl(Object ???, Object arg1)
  {
    Object localObject;
    char llllllllllllllllllIllIlIllIlllll;
    return ??? != localObject;
  }
}

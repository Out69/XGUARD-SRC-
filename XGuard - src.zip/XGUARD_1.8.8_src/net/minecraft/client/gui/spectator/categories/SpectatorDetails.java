package net.minecraft.client.gui.spectator.categories;

import java.util.List;
import net.minecraft.client.gui.spectator.ISpectatorMenuObject;
import net.minecraft.client.gui.spectator.ISpectatorMenuView;
import net.minecraft.client.gui.spectator.SpectatorMenu;

public class SpectatorDetails
{
  public int func_178681_b()
  {
    ;
    return field_178683_c;
  }
  
  private static boolean lIllIlllIll(int ???)
  {
    long lIlIIlIlllIllI;
    return ??? >= 0;
  }
  
  public ISpectatorMenuObject func_178680_a(int lIlIIllIIIIIIl)
  {
    ;
    ;
    if ((lIllIlllIll(lIlIIllIIIIIIl)) && (lIllIllllII(lIlIIllIIIIIIl, field_178682_b.size())))
    {
      "".length();
      if (((0x9F ^ 0xBB) & (0xA9 ^ 0x8D ^ 0xFFFFFFFF)) != -" ".length()) {
        break label82;
      }
      return null;
    }
    label82:
    return SpectatorMenu.field_178657_a;
  }
  
  public SpectatorDetails(ISpectatorMenuView lIlIIllIIIIlll, List<ISpectatorMenuObject> lIlIIllIIIIllI, int lIlIIllIIIIlIl)
  {
    field_178684_a = lIlIIllIIIIlll;
    field_178682_b = lIlIIllIIIIllI;
    field_178683_c = lIlIIllIIIIlIl;
  }
  
  private static boolean lIllIllllII(int ???, int arg1)
  {
    int i;
    boolean lIlIIlIllllIII;
    return ??? < i;
  }
}

package net.minecraft.client.gui.spectator.categories;

import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiSpectator;
import net.minecraft.client.gui.spectator.ISpectatorMenuObject;
import net.minecraft.client.gui.spectator.ISpectatorMenuView;
import net.minecraft.client.gui.spectator.SpectatorMenu;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;

public class TeleportToTeam
  implements ISpectatorMenuView, ISpectatorMenuObject
{
  private static boolean llIlllIlIlllIl(int ???)
  {
    double llllllllllllllIlIIIlIIllIllIIIll;
    return ??? != 0;
  }
  
  private static boolean llIlllIlIlllII(int ???)
  {
    double llllllllllllllIlIIIlIIllIllIIIIl;
    return ??? == 0;
  }
  
  public List<ISpectatorMenuObject> func_178669_a()
  {
    ;
    return field_178672_a;
  }
  
  private static void llIlIIIlllllII()
  {
    lIIIIlIlIIlIl = new String[lIIlIIIlIlIIl[3]];
    lIIIIlIlIIlIl[lIIlIIIlIlIIl[0]] = llIIlIlllllIII("PCkfNhkbbBJzDgotHnMOAGwHNhYKPBwhDk84HA==", "oLsSz");
    lIIIIlIlIIlIl[lIIlIIIlIlIIl[1]] = llIIlIlllllIIl("N0TEyd7O+QXvWrLlO/seHkME0pSzUXBa", "JsjXq");
  }
  
  public TeleportToTeam()
  {
    Minecraft llllllllllllllIlIIIlIIlllIlIlIIl = Minecraft.getMinecraft();
    boolean llllllllllllllIlIIIlIIlllIlIIlII = theWorld.getScoreboard().getTeams().iterator();
    "".length();
    if (" ".length() <= ((0x9E ^ 0xA1) & (0x78 ^ 0x47 ^ 0xFFFFFFFF))) {
      throw null;
    }
    while (!llIlllIlIlllII(llllllllllllllIlIIIlIIlllIlIIlII.hasNext()))
    {
      ScorePlayerTeam llllllllllllllIlIIIlIIlllIlIlIII = (ScorePlayerTeam)llllllllllllllIlIIIlIIlllIlIIlII.next();
      new TeamSelectionObject(llllllllllllllIlIIIlIIlllIlIlIII);
      "".length();
    }
  }
  
  private static String llIIlIlllllIII(String llllllllllllllIlIIIlIIllIlllIllI, String llllllllllllllIlIIIlIIllIlllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIIlIIllIlllIllI = new String(Base64.getDecoder().decode(llllllllllllllIlIIIlIIllIlllIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlIIIlIIllIlllIlII = new StringBuilder();
    char[] llllllllllllllIlIIIlIIllIlllIIll = llllllllllllllIlIIIlIIllIlllIIII.toCharArray();
    int llllllllllllllIlIIIlIIllIlllIIlI = lIIlIIIlIlIIl[0];
    float llllllllllllllIlIIIlIIllIllIllII = llllllllllllllIlIIIlIIllIlllIllI.toCharArray();
    long llllllllllllllIlIIIlIIllIllIlIll = llllllllllllllIlIIIlIIllIllIllII.length;
    char llllllllllllllIlIIIlIIllIllIlIlI = lIIlIIIlIlIIl[0];
    while (llIlllIlIllllI(llllllllllllllIlIIIlIIllIllIlIlI, llllllllllllllIlIIIlIIllIllIlIll))
    {
      char llllllllllllllIlIIIlIIllIlllIlll = llllllllllllllIlIIIlIIllIllIllII[llllllllllllllIlIIIlIIllIllIlIlI];
      "".length();
      "".length();
      if ("  ".length() != "  ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlIIIlIIllIlllIlII);
  }
  
  private static String llIIlIlllllIIl(String llllllllllllllIlIIIlIIlllIIIIllI, String llllllllllllllIlIIIlIIlllIIIIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIIIlIIlllIIIlIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIIlIIlllIIIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIIIlIIlllIIIlIII = Cipher.getInstance("Blowfish");
      llllllllllllllIlIIIlIIlllIIIlIII.init(lIIlIIIlIlIIl[3], llllllllllllllIlIIIlIIlllIIIlIIl);
      return new String(llllllllllllllIlIIIlIIlllIIIlIII.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIIlIIlllIIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIIIlIIlllIIIIlll)
    {
      llllllllllllllIlIIIlIIlllIIIIlll.printStackTrace();
    }
    return null;
  }
  
  public void func_178663_a(float llllllllllllllIlIIIlIIlllIIlIlll, int llllllllllllllIlIIIlIIlllIIlIllI)
  {
    Minecraft.getMinecraft().getTextureManager().bindTexture(GuiSpectator.field_175269_a);
    Gui.drawModalRectWithCustomSizedTexture(lIIlIIIlIlIIl[0], lIIlIIIlIlIIl[0], 16.0F, 0.0F, lIIlIIIlIlIIl[2], lIIlIIIlIlIIl[2], 256.0F, 256.0F);
  }
  
  static
  {
    llIlllIlIllIll();
    llIlIIIlllllII();
  }
  
  public IChatComponent getSpectatorName()
  {
    return new ChatComponentText(lIIIIlIlIIlIl[lIIlIIIlIlIIl[1]]);
  }
  
  private static boolean llIlllIlIllllI(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlIIIlIIllIllIIlIl;
    return ??? < i;
  }
  
  public boolean func_178662_A_()
  {
    ;
    ;
    Exception llllllllllllllIlIIIlIIlllIIIlllI = field_178672_a.iterator();
    "".length();
    if (-"   ".length() >= 0) {
      return (0x42 ^ 0x79) & (0x28 ^ 0x13 ^ 0xFFFFFFFF);
    }
    while (!llIlllIlIlllII(llllllllllllllIlIIIlIIlllIIIlllI.hasNext()))
    {
      ISpectatorMenuObject llllllllllllllIlIIIlIIlllIIlIIIl = (ISpectatorMenuObject)llllllllllllllIlIIIlIIlllIIIlllI.next();
      if (llIlllIlIlllIl(llllllllllllllIlIIIlIIlllIIlIIIl.func_178662_A_())) {
        return lIIlIIIlIlIIl[1];
      }
    }
    return lIIlIIIlIlIIl[0];
  }
  
  public void func_178661_a(SpectatorMenu llllllllllllllIlIIIlIIlllIIllIlI)
  {
    ;
    ;
    llllllllllllllIlIIIlIIlllIIllIlI.func_178647_a(llllllllllllllIlIIIlIIlllIIllIll);
  }
  
  public IChatComponent func_178670_b()
  {
    return new ChatComponentText(lIIIIlIlIIlIl[lIIlIIIlIlIIl[0]]);
  }
  
  private static void llIlllIlIllIll()
  {
    lIIlIIIlIlIIl = new int[4];
    lIIlIIIlIlIIl[0] = (('' + '' - 215 + 97 ^ 120 + 26 - -44 + 3) & (24 + 28 - -77 + 109 ^ '' + '²' - 180 + 34 ^ -" ".length()));
    lIIlIIIlIlIIl[1] = " ".length();
    lIIlIIIlIlIIl[2] = (24 + 38 - 24 + 99 ^ 105 + 62 - 50 + 36);
    lIIlIIIlIlIIl[3] = "  ".length();
  }
  
  class TeamSelectionObject
    implements ISpectatorMenuObject
  {
    private static boolean llIllIIlIIIIIl(int ???, int arg1)
    {
      int i;
      long llllllllllllllIlIIlIIllllIIIlIII;
      return ??? >= i;
    }
    
    public TeamSelectionObject(ScorePlayerTeam llllllllllllllIlIIlIIllllIllIIll)
    {
      field_178676_b = llllllllllllllIlIIlIIllllIllIIll;
      field_178675_d = Lists.newArrayList();
      float llllllllllllllIlIIlIIllllIllIIIl = llllllllllllllIlIIlIIllllIllIIll.getMembershipCollection().iterator();
      "".length();
      if (((0x31 ^ 0x3D ^ 0xB2 ^ 0xAA) & ("  ".length() ^ 0xAA ^ 0xBC ^ -" ".length())) != 0) {
        throw null;
      }
      while (!llIllIIlIIIIII(llllllllllllllIlIIlIIllllIllIIIl.hasNext()))
      {
        String llllllllllllllIlIIlIIllllIlllIII = (String)llllllllllllllIlIIlIIllllIllIIIl.next();
        NetworkPlayerInfo llllllllllllllIlIIlIIllllIllIlll = Minecraft.getMinecraft().getNetHandler().getPlayerInfo(llllllllllllllIlIIlIIllllIlllIII);
        if (llIllIIIllllll(llllllllllllllIlIIlIIllllIllIlll)) {
          "".length();
        }
      }
      if (llIllIIlIIIIII(field_178675_d.isEmpty()))
      {
        String llllllllllllllIlIIlIIllllIllIllI = ((NetworkPlayerInfo)field_178675_d.get(new Random().nextInt(field_178675_d.size()))).getGameProfile().getName();
        field_178677_c = AbstractClientPlayer.getLocationSkin(llllllllllllllIlIIlIIllllIllIllI);
        "".length();
        "".length();
        if ("  ".length() < "  ".length()) {
          throw null;
        }
      }
      else
      {
        field_178677_c = DefaultPlayerSkin.getDefaultSkinLegacy();
      }
    }
    
    private static boolean llIllIIIllllll(Object ???)
    {
      short llllllllllllllIlIIlIIllllIIIIllI;
      return ??? != null;
    }
    
    private static boolean llIllIIlIIIIll(int ???)
    {
      float llllllllllllllIlIIlIIllllIIIIlII;
      return ??? != 0;
    }
    
    public IChatComponent getSpectatorName()
    {
      ;
      return new ChatComponentText(field_178676_b.getTeamName());
    }
    
    public void func_178663_a(float llllllllllllllIlIIlIIllllIIlllIl, int llllllllllllllIlIIlIIllllIIlIlII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      int llllllllllllllIlIIlIIllllIIllIll = lIIIlllIlIIll[0];
      String llllllllllllllIlIIlIIllllIIllIlI = FontRenderer.getFormatFromString(field_178676_b.getColorPrefix());
      if (llIllIIlIIIIIl(llllllllllllllIlIIlIIllllIIllIlI.length(), lIIIlllIlIIll[1]))
      {
        "".length();
        llllllllllllllIlIIlIIllllIIllIll = Minecraft.fontRendererObj.getColorCode(llllllllllllllIlIIlIIllllIIllIlI.charAt(lIIIlllIlIIll[2]));
      }
      if (llIllIIlIIIIlI(llllllllllllllIlIIlIIllllIIllIll))
      {
        float llllllllllllllIlIIlIIllllIIllIIl = (llllllllllllllIlIIlIIllllIIllIll >> lIIIlllIlIIll[3] & lIIIlllIlIIll[4]) / 255.0F;
        float llllllllllllllIlIIlIIllllIIllIII = (llllllllllllllIlIIlIIllllIIllIll >> lIIIlllIlIIll[5] & lIIIlllIlIIll[4]) / 255.0F;
        float llllllllllllllIlIIlIIllllIIlIlll = (llllllllllllllIlIIlIIllllIIllIll & lIIIlllIlIIll[4]) / 255.0F;
        Gui.drawRect(lIIIlllIlIIll[2], lIIIlllIlIIll[2], lIIIlllIlIIll[6], lIIIlllIlIIll[6], MathHelper.func_180183_b(llllllllllllllIlIIlIIllllIIllIIl * llllllllllllllIlIIlIIllllIIlIlIl, llllllllllllllIlIIlIIllllIIllIII * llllllllllllllIlIIlIIllllIIlIlIl, llllllllllllllIlIIlIIllllIIlIlll * llllllllllllllIlIIlIIllllIIlIlIl) | llllllllllllllIlIIlIIllllIIlIlII << lIIIlllIlIIll[7]);
      }
      Minecraft.getMinecraft().getTextureManager().bindTexture(field_178677_c);
      GlStateManager.color(llllllllllllllIlIIlIIllllIIlIlIl, llllllllllllllIlIIlIIllllIIlIlIl, llllllllllllllIlIIlIIllllIIlIlIl, llllllllllllllIlIIlIIllllIIlIlII / 255.0F);
      Gui.drawScaledCustomSizeModalRect(lIIIlllIlIIll[1], lIIIlllIlIIll[1], 8.0F, 8.0F, lIIIlllIlIIll[5], lIIIlllIlIIll[5], lIIIlllIlIIll[8], lIIIlllIlIIll[8], 64.0F, 64.0F);
      Gui.drawScaledCustomSizeModalRect(lIIIlllIlIIll[1], lIIIlllIlIIll[1], 40.0F, 8.0F, lIIIlllIlIIll[5], lIIIlllIlIIll[5], lIIIlllIlIIll[8], lIIIlllIlIIll[8], 64.0F, 64.0F);
    }
    
    static {}
    
    private static boolean llIllIIlIIIIII(int ???)
    {
      short llllllllllllllIlIIlIIllllIIIIIlI;
      return ??? == 0;
    }
    
    private static void llIllIIIlllllI()
    {
      lIIIlllIlIIll = new int[10];
      lIIIlllIlIIll[0] = (-" ".length());
      lIIIlllIlIIll[1] = "  ".length();
      lIIIlllIlIIll[2] = " ".length();
      lIIIlllIlIIll[3] = (0x88 ^ 0x98);
      lIIIlllIlIIll[4] = ((0xA ^ 0x7D) + (5 + 40 - 0 + 173) - (74 + 93 - 106 + 95) + (0xDD ^ 0x97));
      lIIIlllIlIIll[5] = (0xA4 ^ 0xAC);
      lIIIlllIlIIll[6] = (0x9D ^ 0x92);
      lIIIlllIlIIll[7] = (0x42 ^ 0x38 ^ 0xED ^ 0x8F);
      lIIIlllIlIIll[8] = (127 + 79 - 180 + 104 ^ 76 + 82 - 34 + 18);
      lIIIlllIlIIll[9] = ((0x39 ^ 0x6D) & (0x7B ^ 0x2F ^ 0xFFFFFFFF));
    }
    
    private static boolean llIllIIlIIIIlI(int ???)
    {
      char llllllllllllllIlIIlIIllllIIIIIII;
      return ??? >= 0;
    }
    
    public boolean func_178662_A_()
    {
      ;
      if (llIllIIlIIIIll(field_178675_d.isEmpty()))
      {
        "".length();
        if ((0xBA ^ 0xBE) <= (0x7E ^ 0x7A)) {
          break label63;
        }
        return (0x30 ^ 0x9) & (0xFE ^ 0xC7 ^ 0xFFFFFFFF);
      }
      label63:
      return lIIIlllIlIIll[2];
    }
    
    public void func_178661_a(SpectatorMenu llllllllllllllIlIIlIIllllIlIlIlI)
    {
      ;
      ;
      llllllllllllllIlIIlIIllllIlIlIlI.func_178647_a(new TeleportToPlayer(field_178675_d));
    }
  }
}

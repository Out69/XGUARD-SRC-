package net.minecraft.client.gui.spectator;

public abstract interface ISpectatorMenuRecipient
{
  public abstract void func_175257_a(SpectatorMenu paramSpectatorMenu);
}

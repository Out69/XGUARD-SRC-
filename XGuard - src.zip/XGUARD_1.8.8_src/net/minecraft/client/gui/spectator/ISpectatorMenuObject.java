package net.minecraft.client.gui.spectator;

import net.minecraft.util.IChatComponent;

public abstract interface ISpectatorMenuObject
{
  public abstract boolean func_178662_A_();
  
  public abstract void func_178663_a(float paramFloat, int paramInt);
  
  public abstract void func_178661_a(SpectatorMenu paramSpectatorMenu);
  
  public abstract IChatComponent getSpectatorName();
}

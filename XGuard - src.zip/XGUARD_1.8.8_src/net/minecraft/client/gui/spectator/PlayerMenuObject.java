package net.minecraft.client.gui.spectator;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.network.play.client.C18PacketSpectate;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

public class PlayerMenuObject
  implements ISpectatorMenuObject
{
  public void func_178661_a(SpectatorMenu llllllllllllllllIlIIlllIllllIlIl)
  {
    ;
    Minecraft.getMinecraft().getNetHandler().addToSendQueue(new C18PacketSpectate(profile.getId()));
  }
  
  static {}
  
  private static void lIlIIIIllllll()
  {
    llIlIlIIlII = new int[4];
    llIlIlIIlII[0] = "  ".length();
    llIlIlIIlII[1] = (0xBE ^ 0xB3 ^ 0x5 ^ 0x0);
    llIlIlIIlII[2] = (0x2F ^ 0x23);
    llIlIlIIlII[3] = " ".length();
  }
  
  public PlayerMenuObject(GameProfile llllllllllllllllIlIIlllIlllllIII)
  {
    profile = llllllllllllllllIlIIlllIlllllIII;
    resourceLocation = AbstractClientPlayer.getLocationSkin(llllllllllllllllIlIIlllIlllllIII.getName());
    "".length();
  }
  
  public void func_178663_a(float llllllllllllllllIlIIlllIlllIllIl, int llllllllllllllllIlIIlllIlllIlIlI)
  {
    ;
    ;
    Minecraft.getMinecraft().getTextureManager().bindTexture(resourceLocation);
    GlStateManager.color(1.0F, 1.0F, 1.0F, llllllllllllllllIlIIlllIlllIlIlI / 255.0F);
    Gui.drawScaledCustomSizeModalRect(llIlIlIIlII[0], llIlIlIIlII[0], 8.0F, 8.0F, llIlIlIIlII[1], llIlIlIIlII[1], llIlIlIIlII[2], llIlIlIIlII[2], 64.0F, 64.0F);
    Gui.drawScaledCustomSizeModalRect(llIlIlIIlII[0], llIlIlIIlII[0], 40.0F, 8.0F, llIlIlIIlII[1], llIlIlIIlII[1], llIlIlIIlII[2], llIlIlIIlII[2], 64.0F, 64.0F);
  }
  
  public boolean func_178662_A_()
  {
    return llIlIlIIlII[3];
  }
  
  public IChatComponent getSpectatorName()
  {
    ;
    return new ChatComponentText(profile.getName());
  }
}

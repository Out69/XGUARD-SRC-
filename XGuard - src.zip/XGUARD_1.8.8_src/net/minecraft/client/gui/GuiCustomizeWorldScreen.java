package net.minecraft.client.gui;

import com.google.common.base.Predicate;
import com.google.common.primitives.Floats;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.MathHelper;
import net.minecraft.world.biome.BiomeGenBase;
import net.minecraft.world.gen.ChunkProviderSettings.Factory;

public class GuiCustomizeWorldScreen
  extends GuiScreen
  implements GuiPageButtonList.GuiResponder, GuiSlider.FormatHelper
{
  private static void llIlIIllIll()
  {
    lIIIIIlIll = new int['ø'];
    lIIIIIlIll[0] = (('' + '¬' - 251 + 137 ^ 36 + 106 - 48 + 44) & (126 + 'Ð' - 183 + 83 ^ '¡' + '' - 192 + 61 ^ -" ".length()));
    lIIIIIlIll[1] = " ".length();
    lIIIIIlIll[2] = "  ".length();
    lIIIIIlIll[3] = (0x34 ^ 0x30);
    lIIIIIlIll[4] = "   ".length();
    lIIIIIlIll[5] = (-(0xE341 & 0x3EFF) & 0xBB6F & 0x67FE);
    lIIIIIlIll[6] = (54 + 66 - 24 + 93 ^ 109 + 86 - 46 + 20);
    lIIIIIlIll[7] = (0x1E ^ 0x78 ^ 0x66 ^ 0x5);
    lIIIIIlIll[8] = (0xB5 ^ 0x9B ^ 0x4F ^ 0x31);
    lIIIIIlIll[9] = (-(0xDDEB & 0x2695) & 0x9DEF & 0x67BF);
    lIIIIIlIll[10] = (0xDA ^ 0xBE);
    lIIIIIlIll[11] = (-(0xDFEB & 0x3255) & 0xB7F4 & 0x5B7B);
    lIIIIIlIll[12] = ((0x66 ^ 0xA) + (0x2A ^ 0x44) - (0x5D ^ 0x6B) + (0x96 ^ 0x81));
    lIIIIIlIll[13] = (0xF ^ 0x12 ^ 0xA0 ^ 0xA6);
    lIIIIIlIll[14] = (0x27 ^ 0x7D);
    lIIIIIlIll[15] = (0x50 ^ 0x6C ^ 0x51 ^ 0x6B);
    lIIIIIlIll[16] = (-(0xBF8B & 0x74F7) & 0xBDFF & 0x77AF);
    lIIIIIlIll[17] = (0x1A ^ 0x46);
    lIIIIIlIll[18] = (0x7B ^ 0x2F ^ 0x90 ^ 0xC3);
    lIIIIIlIll[19] = (-(0xBFCB & 0x7AF7) & 0xBBFB & 0x7FF7);
    lIIIIIlIll[20] = ('Ê' + 44 - 54 + 12 ^ 76 + 19 - 34 + 135);
    lIIIIIlIll[21] = (-(0xFFFFFFD3 & 0x566D) & 0xFF7D & 0x57EE);
    lIIIIIlIll[22] = (0x3 ^ 0x61);
    lIIIIIlIll[23] = (0x32 ^ 0x3B);
    lIIIIIlIll[24] = (-(0xFDC2 & 0x767F) & 0xF7FB & 0x7D77);
    lIIIIIlIll[25] = (98 + '' - 103 + 9 ^ 71 + 90 - -11 + 2);
    lIIIIIlIll[26] = (42 + '' - 100 + 68);
    lIIIIIlIll[27] = (0xE6 ^ 0x9A ^ 0x5D ^ 0x13);
    lIIIIIlIll[28] = (0x58 ^ 0x52);
    lIIIIIlIll[29] = (0x89FF & 0x7733);
    lIIIIIlIll[30] = (0x13 ^ 0x18);
    lIIIIIlIll[31] = (79 + 29 - 16 + 78 ^ 65 + '®' - 219 + 164);
    lIIIIIlIll[32] = (0xA6 ^ 0xAA);
    lIIIIIlIll[33] = ((0x5D ^ 0x53) + (66 + 68 - 131 + 126) - (112 + 126 - 167 + 71) + ('' + 116 - 124 + 18));
    lIIIIIlIll[34] = ('' + 1 - 64 + 104 ^ 119 + '' - 201 + 84);
    lIIIIIlIll[35] = ((0x6F ^ 0x57) + (0x9E ^ 0xA1) - (0xD ^ 0x14) + (0x80 ^ 0xB8));
    lIIIIIlIll[36] = (0x2A ^ 0x24);
    lIIIIIlIll[37] = (46 + 85 - 15 + 35);
    lIIIIIlIll[38] = (0x12 ^ 0x26 ^ 0x60 ^ 0x5B);
    lIIIIIlIll[39] = ((0xAB ^ 0xB7) + (35 + 101 - 48 + 57) - (0xD2 ^ 0xAC) + (0xF0 ^ 0x99));
    lIIIIIlIll[40] = (25 + 121 - -24 + 1 ^ 6 + '¥' - 80 + 96);
    lIIIIIlIll[41] = (8 + 19 - -118 + 8);
    lIIIIIlIll[42] = (0xB7 ^ 0xB8 ^ 0x5B ^ 0x45);
    lIIIIIlIll[43] = ((0x32 ^ 0x3D) + (101 + 22 - 5 + 30) - -(0xE8 ^ 0xC1) + (0xA7 ^ 0xA1));
    lIIIIIlIll[44] = ((0xE2 ^ 0xC2) + (0x27 ^ 0x72) - (0xC3 ^ 0xA3) + (10 + 26 - -83 + 14));
    lIIIIIlIll[45] = (0xB8 ^ 0xAB);
    lIIIIIlIll[46] = ('' + 28 - 113 + 90);
    lIIIIIlIll[47] = (93 + '' - 184 + 98);
    lIIIIIlIll[48] = (0xAE ^ 0xBB);
    lIIIIIlIll[49] = ('' + 66 - 146 + 106);
    lIIIIIlIll[50] = (0x66 ^ 0x70);
    lIIIIIlIll[51] = (54 + 6 - 18 + 116);
    lIIIIIlIll[52] = (0x12 ^ 0x5);
    lIIIIIlIll[53] = ((0xA2 ^ 0x87) + (0x20 ^ 0x6B) - (0x56 ^ 0x10) + (0x6C ^ 0x1E));
    lIIIIIlIll[54] = (0xEA ^ 0xC0 ^ 0xF6 ^ 0xC4);
    lIIIIIlIll[55] = (29 + 42 - -4 + 84);
    lIIIIIlIll[56] = (0x6B ^ 0x72);
    lIIIIIlIll[57] = (98 + 28 - 7 + 42);
    lIIIIIlIll[58] = (0x42 ^ 0x58);
    lIIIIIlIll[59] = (10 + 96 - 70 + 126);
    lIIIIIlIll[60] = (119 + 59 - 125 + 110);
    lIIIIIlIll[61] = (0x48 ^ 0x6F ^ 0x7 ^ 0x3C);
    lIIIIIlIll[62] = (76 + '' - 116 + 57);
    lIIIIIlIll[63] = (0x7C ^ 0x61);
    lIIIIIlIll[64] = (0xD2 ^ 0x90);
    lIIIIIlIll[65] = (-(0xFFFFFFFE & 0x7259) & 0xF7F7 & 0x7BFF);
    lIIIIIlIll[66] = (0x13 ^ 0xD);
    lIIIIIlIll[67] = ((0x4F ^ 0x7D) + ((0x32 ^ 0x6E) & (0x5E ^ 0x2 ^ 0xFFFFFFFF)) - (0x2D ^ 0x1C) + (43 + 43 - -68 + 10));
    lIIIIIlIll[68] = (30 + 103 - 73 + 106 ^ 34 + 43 - 20 + 128);
    lIIIIIlIll[69] = ((0x5F ^ 0x29) + (0x2C ^ 0x27) - (0x79 ^ 0x59) + (0x58 ^ 0x1D));
    lIIIIIlIll[70] = (0x6 ^ 0x26);
    lIIIIIlIll[71] = (105 + 33 - 68 + 97);
    lIIIIIlIll[72] = (0x83 ^ 0xA2);
    lIIIIIlIll[73] = (110 + 87 - 174 + 145);
    lIIIIIlIll[74] = (" ".length() ^ 0x7F ^ 0x5C);
    lIIIIIlIll[75] = (-(0xEF7F & 0x56D9) & 0xF7FB & 0x4FFD);
    lIIIIIlIll[76] = (0x2B ^ 0x8);
    lIIIIIlIll[77] = (55 + '' - 42 + 4);
    lIIIIIlIll[78] = (0xAF ^ 0x8B);
    lIIIIIlIll[79] = ((0x39 ^ 0x4B) + (0x4 ^ 0x7E) - (0x4 ^ 0x40) + "  ".length());
    lIIIIIlIll[80] = (0x1B ^ 0x3E);
    lIIIIIlIll[81] = ((0x93 ^ 0xBC) + (0xE9 ^ 0xA0) - (0x8 ^ 0x36) + (0x28 ^ 0x59));
    lIIIIIlIll[82] = (0x1E ^ 0x49 ^ 0xE6 ^ 0x97);
    lIIIIIlIll[83] = ((0x26 ^ 0x31) + (0xBF ^ 0x80) - (0x1E ^ 0x25) + (5 + 44 - -34 + 62));
    lIIIIIlIll[84] = (0xE0 ^ 0xC7);
    lIIIIIlIll[85] = (0xD7E3 & 0x29BE);
    lIIIIIlIll[86] = (0x9F ^ 0xB7);
    lIIIIIlIll[87] = ((0x67 ^ 0x6E) + (0x34 ^ 0x4E) - (0x36 ^ 0xD) + (0x78 ^ 0x1D));
    lIIIIIlIll[88] = (0xB1 ^ 0x98);
    lIIIIIlIll[89] = (44 + 4 - -122 + 4);
    lIIIIIlIll[90] = (13 + '' - 58 + 51 ^ 55 + 120 - 138 + 140);
    lIIIIIlIll[91] = (59 + 93 - 128 + 151);
    lIIIIIlIll[92] = ('' + '£' - 250 + 116 ^ 48 + 42 - -2 + 38);
    lIIIIIlIll[93] = ('' + 5 - 80 + 115);
    lIIIIIlIll[94] = (0xB ^ 0x60 ^ 0xDB ^ 0x9C);
    lIIIIIlIll[95] = (0xC5B3 & 0x3BEF);
    lIIIIIlIll[96] = (0x5 ^ 0x11 ^ 0xB7 ^ 0x8E);
    lIIIIIlIll[97] = (83 + 127 - 135 + 102);
    lIIIIIlIll[98] = (0x2D ^ 0x5D ^ 0x5B ^ 0x5);
    lIIIIIlIll[99] = (124 + 124 - 211 + 141);
    lIIIIIlIll[100] = (0x51 ^ 0x7E);
    lIIIIIlIll[101] = ((0xF8 ^ 0x8C) + (0xF4 ^ 0x83) - (0x2F ^ 0x65) + (0x6D ^ 0x7F));
    lIIIIIlIll[102] = (33 + 64 - 56 + 114 ^ '' + 97 - 135 + 76);
    lIIIIIlIll[103] = ((0x1E ^ 0x55) + (120 + 70 - 175 + 148) - (0x28 ^ 0x61) + (0xBD ^ 0xB2));
    lIIIIIlIll[104] = (0xFB ^ 0xBD ^ 0x69 ^ 0x1E);
    lIIIIIlIll[105] = (-(0xACFD & 0x5B1E) & 0xEBBF & 0x1DFF);
    lIIIIIlIll[106] = (78 + 105 - 59 + 57);
    lIIIIIlIll[107] = (0x43 ^ 0x70);
    lIIIIIlIll[108] = ('' + '' - 171 + 55);
    lIIIIIlIll[109] = ((0x68 ^ 0x6E) & (0x70 ^ 0x76 ^ 0xFFFFFFFF) ^ 0x20 ^ 0x14);
    lIIIIIlIll[110] = (114 + 70 - 19 + 18);
    lIIIIIlIll[111] = (0x77 ^ 0x7 ^ 0xCD ^ 0x88);
    lIIIIIlIll[112] = (5 + 111 - 11 + 79);
    lIIIIIlIll[113] = (0xAF ^ 0x99);
    lIIIIIlIll[114] = (-(0xB64B & 0x6FBF) & 0xAFFF & 0x77AF);
    lIIIIIlIll[115] = (109 + 113 - 114 + 77);
    lIIIIIlIll[116] = (0x2C ^ 0x14);
    lIIIIIlIll[117] = (83 + 30 - -44 + 29);
    lIIIIIlIll[118] = (0x0 ^ 0x66 ^ 0x6A ^ 0x35);
    lIIIIIlIll[119] = (0x9F ^ 0xA5);
    lIIIIIlIll[120] = (75 + 42 - -25 + 26 + (124 + 75 - 181 + 126) - (0xFB5F & 0x5AE) + (67 + 42 - -10 + 28));
    lIIIIIlIll[121] = (0x25 ^ 0x1E);
    lIIIIIlIll[122] = (0xA3B7 & 0x5DEE);
    lIIIIIlIll[123] = (0x44 ^ 0x78);
    lIIIIIlIll[124] = (52 + 20 - 16 + 134);
    lIIIIIlIll[125] = (0x11 ^ 0x24 ^ 0x79 ^ 0x71);
    lIIIIIlIll[126] = ((0x5 ^ 0x43) + (0x5B ^ 0x4) - (0xFD ^ 0xA4) + (0x45 ^ 0x36));
    lIIIIIlIll[127] = (0x6E ^ 0x1D ^ 0x3D ^ 0x70);
    lIIIIIlIll[''] = ('' + '' - 82 + 11);
    lIIIIIlIll[''] = (38 + 49 - -17 + 69 ^ 85 + 0 - 67 + 128);
    lIIIIIlIll[''] = (66 + 72 - 117 + 172);
    lIIIIIlIll[''] = (0x58 ^ 0x18);
    lIIIIIlIll[''] = (-(0xD5AF & 0x6E51) & 0xCDE7 & 0x77BF);
    lIIIIIlIll[''] = (0xE3 ^ 0xA2);
    lIIIIIlIll[''] = ('¦' + 'º' - 186 + 28);
    lIIIIIlIll[''] = ("   ".length() + (38 + '' - 180 + 145) - (29 + '' - 113 + 86) + ('' + 20 - 11 + 13));
    lIIIIIlIll[''] = (0x60 ^ 0x69 ^ 0x20 ^ 0x6A);
    lIIIIIlIll[''] = (45 + 96 - 43 + 98);
    lIIIIIlIll[''] = (0x39 ^ 0x52 ^ 0xE8 ^ 0xC7);
    lIIIIIlIll[''] = ((0x74 ^ 0x39) + (0x16 ^ 0x40) - (0xD9 ^ 0xA8) + ('' + 117 - 234 + 123));
    lIIIIIlIll[''] = (0xB5 ^ 0x99 ^ 0x59 ^ 0x30);
    lIIIIIlIll[''] = (-(0xDA77 & 0x659B) & 0xD9FB & 0x67BE);
    lIIIIIlIll[''] = (0x2A ^ 0x41 ^ 0xB9 ^ 0x94);
    lIIIIIlIll[''] = (95 + '' - 97 + 55);
    lIIIIIlIll[''] = (91 + 'Þ' - 163 + 85 ^ 76 + 103 - 154 + 147);
    lIIIIIlIll[''] = ('Ã' + 'º' - 364 + 182);
    lIIIIIlIll[''] = (0xC8 ^ 0x93 ^ 0x2F ^ 0x3C);
    lIIIIIlIll[''] = (72 + 53 - 121 + 196);
    lIIIIIlIll[''] = (0xD7 ^ 0x9E);
    lIIIIIlIll[''] = (67 + 67 - 38 + 105);
    lIIIIIlIll[''] = (0x2E ^ 0x64);
    lIIIIIlIll[''] = (-(0xD9FF & 0x7E05) & 0xDDFD & 0x7BAF);
    lIIIIIlIll[''] = (0x1A ^ 0x2F ^ 0xF4 ^ 0x8A);
    lIIIIIlIll[''] = (95 + '' - 48 + 9);
    lIIIIIlIll[''] = (0xB2 ^ 0xC7 ^ 0x79 ^ 0x40);
    lIIIIIlIll[''] = (40 + 52 - -5 + 106);
    lIIIIIlIll[''] = (0x17 ^ 0x7C ^ 0x4F ^ 0x69);
    lIIIIIlIll[''] = ('' + '' - 151 + 53 + (98 + 13 - -44 + 6) - ('' + 76 - 105 + 65) + (0x50 ^ 0x79));
    lIIIIIlIll[''] = (0x13 ^ 0xD ^ 0x27 ^ 0x77);
    lIIIIIlIll[''] = ((0x96 ^ 0x9F) + ('' + 94 - 235 + 159) - (119 + 60 - 46 + 2) + (69 + 58 - 40 + 70));
    lIIIIIlIll[' '] = (0x63 ^ 0x7B ^ 0xD3 ^ 0x84);
    lIIIIIlIll['¡'] = (-(0xE6F6 & 0x5B0B) & 0xCFFB & 0x73AF);
    lIIIIIlIll['¢'] = (108 + 57 - 54 + 39 + (0x40 ^ 0x14) - (0x41 ^ 0x64) + (0x1D ^ 0x14));
    lIIIIIlIll['£'] = (0xC ^ 0x4 ^ 0xDB ^ 0x82);
    lIIIIIlIll['¤'] = ('¸' + '«' - 183 + 35);
    lIIIIIlIll['¥'] = (0x15 ^ 0x47);
    lIIIIIlIll['¦'] = (111 + '' - 175 + 139);
    lIIIIIlIll['§'] = ('Î' + 'Ð' - 209 + 23 ^ 28 + 81 - 24 + 98);
    lIIIIIlIll['¨'] = ((0x6B ^ 0x47) + (23 + 8 - 20 + 124) - -"  ".length() + (0x3C ^ 0x20));
    lIIIIIlIll['©'] = (0xD8 ^ 0x8C);
    lIIIIIlIll['ª'] = (0xCD ^ 0x98);
    lIIIIIlIll['«'] = (0x20 ^ 0x45);
    lIIIIIlIll['¬'] = (0x45 ^ 0x40 ^ 0xCD ^ 0x9E);
    lIIIIIlIll['­'] = (0x40 ^ 0x32 ^ 0x92 ^ 0x86);
    lIIIIIlIll['®'] = ('µ' + 75 - 80 + 60 ^ 15 + 59 - 11 + 124);
    lIIIIIlIll['¯'] = (0x21 ^ 0x46);
    lIIIIIlIll['°'] = ('' + '' - 86 + 8 ^ '' + 63 - 157 + 133);
    lIIIIIlIll['±'] = (0x7D ^ 0x15);
    lIIIIIlIll['²'] = (0x6E ^ 0x1B ^ 0x0 ^ 0x2C);
    lIIIIIlIll['³'] = (0x63 ^ 0xA);
    lIIIIIlIll['´'] = (0xF2 ^ 0xC6 ^ 0x1 ^ 0x5F);
    lIIIIIlIll['µ'] = (0x24 ^ 0x5D ^ 0x3 ^ 0x21);
    lIIIIIlIll['¶'] = (0x39 ^ 0x52);
    lIIIIIlIll['·'] = (0xE4 ^ 0x88);
    lIIIIIlIll['¸'] = (0x4B ^ 0x16);
    lIIIIIlIll['¹'] = (0xAD ^ 0xC0);
    lIIIIIlIll['º'] = (0xD1 ^ 0x8F);
    lIIIIIlIll['»'] = (0xAD ^ 0xC3);
    lIIIIIlIll['¼'] = (0x5 ^ 0x5A);
    lIIIIIlIll['½'] = (0x23 ^ 0x64 ^ 0xE ^ 0x26);
    lIIIIIlIll['¾'] = (0xA4 ^ 0xC4);
    lIIIIIlIll['¿'] = (6 + 103 - -60 + 83 ^ 71 + 117 - 179 + 131);
    lIIIIIlIll['À'] = (0x24 ^ 0x45);
    lIIIIIlIll['Á'] = (0xEE ^ 0xB9 ^ 0x14 ^ 0x32);
    lIIIIIlIll['Â'] = (0xE0 ^ 0x92);
    lIIIIIlIll['Ã'] = (0xDC ^ 0xBF);
    lIIIIIlIll['Ä'] = (0xED ^ 0x9E);
    lIIIIIlIll['Å'] = (-(0xF5FF & 0x5E2D) & 0xF5BD & 0x5FFE);
    lIIIIIlIll['Æ'] = ((0x3A ^ 0x26) + (0x65 ^ 0x23) - (0x4D ^ 0x7F) + (0xD8 ^ 0x8C));
    lIIIIIlIll['Ç'] = (0xDFD9 & 0x21B7);
    lIIIIIlIll['È'] = (40 + 65 - -24 + 4);
    lIIIIIlIll['É'] = (-(0xBB3D & 0x66EF) & 0xF7FF & 0x2BBE);
    lIIIIIlIll['Ê'] = (65 + 91 - 41 + 15 + (0xF5 ^ 0x90) - (59 + ' ' - 95 + 73) + (0xDB ^ 0xBF));
    lIIIIIlIll['Ë'] = (-(0xFF7F & 0x5EA9) & 0xDFFF & 0x7FBB);
    lIIIIIlIll['Ì'] = (120 + 57 - 52 + 4 + (0xB0 ^ 0x9C) - (26 + 69 - 57 + 105) + (0xDA ^ 0xB3));
    lIIIIIlIll['Í'] = (-(0xFCFF & 0x7F64) & 0xFDF7 & 0x7FFF);
    lIIIIIlIll['Î'] = (94 + 49 - 23 + 16);
    lIIIIIlIll['Ï'] = (0xCB97 & 0x35FD);
    lIIIIIlIll['Ð'] = (0x32 ^ 0x46);
    lIIIIIlIll['Ñ'] = (0x5A ^ 0x2F);
    lIIIIIlIll['Ò'] = (120 + 122 - 108 + 3);
    lIIIIIlIll['Ó'] = (0xFA ^ 0x8C);
    lIIIIIlIll['Ô'] = (0xF3F7 & 0xD9E);
    lIIIIIlIll['Õ'] = ('­' + 99 - 90 + 18 ^ 37 + 35 - -85 + 34);
    lIIIIIlIll['Ö'] = (0xE6 ^ 0x9E);
    lIIIIIlIll['×'] = (43 + 114 - 137 + 118);
    lIIIIIlIll['Ø'] = (0xF8 ^ 0x81);
    lIIIIIlIll['Ù'] = (-(0xBDF1 & 0x622F) & 0xABB7 & 0x75FF);
    lIIIIIlIll['Ú'] = (' ' + 85 - 32 + 28 ^ 112 + 120 - 220 + 127);
    lIIIIIlIll['Û'] = (0xD ^ 0x1C ^ 0x1B ^ 0x71);
    lIIIIIlIll['Ü'] = ((0x87 ^ 0x82) + (0x43 ^ 0x64) - -(0x72 ^ 0x67) + (0x22 ^ 0x68));
    lIIIIIlIll['Ý'] = (0xB ^ 0x19 ^ 0xF2 ^ 0x9C);
    lIIIIIlIll['Þ'] = (0xEB9D & 0x15FA);
    lIIIIIlIll['ß'] = (0x71 ^ 0xC);
    lIIIIIlIll['à'] = ('¢' + '' - 293 + 197 ^ '' + '§' - 258 + 110);
    lIIIIIlIll['á'] = (88 + 77 - 105 + 80);
    lIIIIIlIll['â'] = (75 + 2 - 25 + 75);
    lIIIIIlIll['ã'] = (-(0xCEA5 & 0x3F5B) & 0xBF9F & 0x4FF9);
    lIIIIIlIll['ä'] = (48 + 11 - 34 + 103);
    lIIIIIlIll['å'] = (19 + 76 - -12 + 22);
    lIIIIIlIll['æ'] = ((0xF8 ^ 0x98) + (0xCB ^ 0xA1) - (113 + 65 - 107 + 60) + (0xE1 ^ 0xA7));
    lIIIIIlIll['ç'] = ((0x47 ^ 0x1F) + (0xF2 ^ 0xC2) - (0xB7 ^ 0x8B) + (0xF3 ^ 0xC5));
    lIIIIIlIll['è'] = (-(0xFF61 & 0x5EBF) & 0xDFBB & 0x7FFE);
    lIIIIIlIll['é'] = (85 + 22 - 5 + 29);
    lIIIIIlIll['ê'] = ((0x77 ^ 0x3E) + (0x60 ^ 0x16) - (90 + 56 - 99 + 113) + (0x48 ^ 0x27));
    lIIIIIlIll['ë'] = (0xF5DF & 0xBBB);
    lIIIIIlIll['ì'] = (100 + 86 - 171 + 128);
    lIIIIIlIll['í'] = (-(0xF8F4 & 0x7F4F) & 0xFDDF & 0x7BFF);
    lIIIIIlIll['î'] = (32 + 95 - 106 + 123);
    lIIIIIlIll['ï'] = (-(0xFDCF & 0x7A71) & 0xFDDD & 0x7BFF);
    lIIIIIlIll['ð'] = (22 + 11 - -51 + 61);
    lIIIIIlIll['ñ'] = (-(0x9DFF & 0x7261) & 0xFBFE & 0x15FF);
    lIIIIIlIll['ò'] = (115 + 20 - 116 + 127);
    lIIIIIlIll['ó'] = (-(0xFEFB & 0x7745) & 0xFFFFFFFF & 0x77DF);
    lIIIIIlIll['ô'] = ((0x33 ^ 0x2) + (0x61 ^ 0x5B) - " ".length() + (0x5C ^ 0x75));
    lIIIIIlIll['õ'] = (0xFFFFFFFF & 0xFFFFFF);
    lIIIIIlIll['ö'] = (-(0xBFE3 & 0x1F5F3C));
    lIIIIIlIll['÷'] = (-(-(71 + 121 - 148 + 86) & 0xFFFFFFF3 & 0x5F5FED));
  }
  
  private static String lIlIlllIlII(String lllIIlIIIIIIl, String lllIIlIIIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllIIlIIIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllIIlIIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllIIlIIIIlIl = Cipher.getInstance("Blowfish");
      lllIIlIIIIlIl.init(lIIIIIlIll[2], lllIIlIIIIllI);
      return new String(lllIIlIIIIlIl.doFinal(Base64.getDecoder().decode(lllIIlIIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllIIlIIIIlII)
    {
      lllIIlIIIIlII.printStackTrace();
    }
    return null;
  }
  
  private void func_181031_a(boolean lllIlIIllllII)
  {
    ;
    ;
    field_175338_A = lllIlIIllllII;
    field_175346_u.enabled = lllIlIIllllII;
  }
  
  public String getText(int lllIlIIllIIII, String lllIlIIlIllll, float lllIlIIlIlllI)
  {
    ;
    ;
    ;
    ;
    return String.valueOf(new StringBuilder(String.valueOf(lllIlIIlIllll)).append(llIlIIllI[lIIIIIlIll[39]]).append(lllIlIIllIlIl.func_175330_b(lllIlIIllIIII, lllIlIIlIlllI)));
  }
  
  static
  {
    llIlIIllIll();
    lIllllIIIll();
  }
  
  private void func_175328_i()
  {
    ;
    if (llIlIIlllIl(field_175349_r.func_178059_e()))
    {
      "".length();
      if (null == null) {
        break label38;
      }
    }
    label38:
    lIIIIIlIll1enabled = lIIIIIlIll[0];
    if (llIlIlIIlII(field_175349_r.func_178059_e(), field_175349_r.func_178057_f() - lIIIIIlIll[1]))
    {
      "".length();
      if ("  ".length() == "  ".length()) {
        break label101;
      }
    }
    label101:
    lIIIIIlIll1enabled = lIIIIIlIll[0];
    field_175333_f = I18n.format(llIlIIllI[lIIIIIlIll[55]], new Object[] { Integer.valueOf(field_175349_r.func_178059_e() + lIIIIIlIll[1]), Integer.valueOf(field_175349_r.func_178057_f()) });
    field_175335_g = field_175342_h[field_175349_r.func_178059_e()];
    if (llIlIlIIlII(field_175349_r.func_178059_e(), field_175349_r.func_178057_f() - lIIIIIlIll[1]))
    {
      "".length();
      if (" ".length() != 0) {
        break label240;
      }
    }
    label240:
    lIIIIIlIll1enabled = lIIIIIlIll[0];
  }
  
  public void func_175324_a(String lllIlIlIlIIIl)
  {
    ;
    ;
    if ((llIlIIlllII(lllIlIlIlIIIl)) && (llIlIIlllIl(lllIlIlIlIIIl.length())))
    {
      field_175336_F = ChunkProviderSettings.Factory.jsonToFactory(lllIlIlIlIIIl);
      "".length();
      if (((0x2D ^ 0x15) & (0xA7 ^ 0x9F ^ 0xFFFFFFFF)) == 0) {}
    }
    else
    {
      field_175336_F = new ChunkProviderSettings.Factory();
    }
  }
  
  protected void mouseClicked(int lllIIlIlllIII, int lllIIlIllIIll, int lllIIlIllIIlI)
    throws IOException
  {
    ;
    ;
    ;
    ;
    lllIIlIllIlIl.mouseClicked(lllIIlIlllIII, lllIIlIllIIll, lllIIlIllIIlI);
    if ((llIlIlIIIII(field_175339_B)) && (llIlIlIIIII(field_175340_C))) {
      "".length();
    }
  }
  
  private void func_175322_b(int lllIIlllIlIll)
  {
    ;
    ;
    field_175339_B = lllIIlllIlIll;
    lllIIlllIlllI.func_175329_a(lIIIIIlIll[1]);
  }
  
  protected void keyTyped(char lllIIllIlIlll, int lllIIllIllIIl)
    throws IOException
  {
    ;
    ;
    ;
    lllIIllIllIll.keyTyped(lllIIllIllIlI, lllIIllIllIIl);
    if (llIlIlIIIII(field_175339_B)) {
      switch (lllIIllIllIIl)
      {
      case 200: 
        lllIIllIllIll.func_175327_a(1.0F);
        "".length();
        if (null != null) {}
        break;
      case 208: 
        lllIIllIllIll.func_175327_a(-1.0F);
        "".length();
        if (" ".length() != " ".length()) {}
        break;
      default: 
        field_175349_r.func_178062_a(lllIIllIllIlI, lllIIllIllIIl);
      }
    }
  }
  
  protected void actionPerformed(GuiButton lllIIlllllIlI)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIlIIlllIl(enabled)) {
      switch (id)
      {
      case 300: 
        field_175343_i.chunkProviderSettingsJson = field_175336_F.toString();
        mc.displayGuiScreen(field_175343_i);
        "".length();
        if (("   ".length() & ("   ".length() ^ 0xFFFFFFFF)) != 0) {}
        break;
      case 301: 
        int lllIlIIIIIIll = lIIIIIlIll[0];
        "".length();
        if (-"   ".length() > 0) {
          return;
        }
        while (!llIlIIllllI(lllIlIIIIIIll, field_175349_r.getSize()))
        {
          GuiPageButtonList.GuiEntry lllIlIIIIIIlI = field_175349_r.getListEntry(lllIlIIIIIIll);
          Gui lllIlIIIIIIIl = lllIlIIIIIIlI.func_178022_a();
          if (llIlIIlllIl(lllIlIIIIIIIl instanceof GuiButton))
          {
            GuiButton lllIlIIIIIIII = (GuiButton)lllIlIIIIIIIl;
            if (llIlIIlllIl(lllIlIIIIIIII instanceof GuiSlider))
            {
              float lllIIllllllll = ((GuiSlider)lllIlIIIIIIII).func_175217_d() * (0.75F + random.nextFloat() * 0.5F) + (random.nextFloat() * 0.1F - 0.05F);
              ((GuiSlider)lllIlIIIIIIII).func_175219_a(MathHelper.clamp_float(lllIIllllllll, 0.0F, 1.0F));
              "".length();
              if ((0xDE ^ 0x9B ^ 0xA ^ 0x4B) >= (120 + 112 - 108 + 47 ^ 75 + 57 - 110 + 153)) {}
            }
            else if (llIlIIlllIl(lllIlIIIIIIII instanceof GuiListButton))
            {
              ((GuiListButton)lllIlIIIIIIII).func_175212_b(random.nextBoolean());
            }
          }
          Gui lllIIlllllllI = lllIlIIIIIIlI.func_178021_b();
          if (llIlIIlllIl(lllIIlllllllI instanceof GuiButton))
          {
            GuiButton lllIIllllllIl = (GuiButton)lllIIlllllllI;
            if (llIlIIlllIl(lllIIllllllIl instanceof GuiSlider))
            {
              float lllIIllllllII = ((GuiSlider)lllIIllllllIl).func_175217_d() * (0.75F + random.nextFloat() * 0.5F) + (random.nextFloat() * 0.1F - 0.05F);
              ((GuiSlider)lllIIllllllIl).func_175219_a(MathHelper.clamp_float(lllIIllllllII, 0.0F, 1.0F));
              "".length();
              if ("   ".length() >= ((0x3A ^ 0x6F) & (0x6E ^ 0x3B ^ 0xFFFFFFFF))) {}
            }
            else if (llIlIIlllIl(lllIIllllllIl instanceof GuiListButton))
            {
              ((GuiListButton)lllIIllllllIl).func_175212_b(random.nextBoolean());
            }
          }
          lllIlIIIIIIll++;
        }
        return;
      case 302: 
        field_175349_r.func_178071_h();
        lllIIlllllIll.func_175328_i();
        "".length();
        if (-"   ".length() >= 0) {}
        break;
      case 303: 
        field_175349_r.func_178064_i();
        lllIIlllllIll.func_175328_i();
        "".length();
        if ("   ".length() != "   ".length()) {}
        break;
      case 304: 
        if (llIlIIlllIl(field_175338_A))
        {
          lllIIlllllIll.func_175322_b(lIIIIIlIll[11]);
          "".length();
          if (null != null) {}
        }
        break;
      case 305: 
        mc.displayGuiScreen(new GuiScreenCustomizePresets(lllIIlllllIll));
        "".length();
        if (('' + 122 - 212 + 115 ^ 116 + '' - 249 + 156) <= "   ".length()) {}
        break;
      case 306: 
        lllIIlllllIll.func_175331_h();
        "".length();
        if (-" ".length() >= 0) {}
        break;
      case 307: 
        field_175339_B = lIIIIIlIll[0];
        lllIIlllllIll.func_175331_h();
      }
    }
  }
  
  private static boolean llIlIIlllIl(int ???)
  {
    short lllIIIlIIllIl;
    return ??? != 0;
  }
  
  private static boolean llIlIlIIlII(int ???, int arg1)
  {
    int i;
    long lllIIIlIIIlIl;
    return ??? != i;
  }
  
  public void func_175321_a(int lllIlIIIllllI, boolean lllIlIIIllIlI)
  {
    ;
    ;
    ;
    switch (lllIlIIIllllI)
    {
    case 148: 
      field_175336_F.useCaves = lllIlIIIllIlI;
      "".length();
      if (-(41 + 16 - -59 + 64 ^ 4 + 127 - -19 + 26) >= 0) {
        return;
      }
      break;
    case 149: 
      field_175336_F.useDungeons = lllIlIIIllIlI;
      "".length();
      if (-(0xC2 ^ 0xC7) >= 0) {
        return;
      }
      break;
    case 150: 
      field_175336_F.useStrongholds = lllIlIIIllIlI;
      "".length();
      if (" ".length() >= "   ".length()) {
        return;
      }
      break;
    case 151: 
      field_175336_F.useVillages = lllIlIIIllIlI;
      "".length();
      if (((42 + 3 - -116 + 16 ^ 1 + 29 - -57 + 56) & (16 + 54 - 38 + 96 ^ '' + '®' - 286 + 151 ^ -" ".length())) >= " ".length()) {
        return;
      }
      break;
    case 152: 
      field_175336_F.useMineShafts = lllIlIIIllIlI;
      "".length();
      if (((0xC8 ^ 0xA6 ^ 0xFC ^ 0x8B) & (0x1 ^ 0x26 ^ 0x3F ^ 0x1 ^ -" ".length())) < 0) {
        return;
      }
      break;
    case 153: 
      field_175336_F.useTemples = lllIlIIIllIlI;
      "".length();
      if ((0x93 ^ 0x97) < -" ".length()) {
        return;
      }
      break;
    case 154: 
      field_175336_F.useRavines = lllIlIIIllIlI;
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 155: 
      field_175336_F.useWaterLakes = lllIlIIIllIlI;
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 156: 
      field_175336_F.useLavaLakes = lllIlIIIllIlI;
      "".length();
      if ("  ".length() != "  ".length()) {
        return;
      }
      break;
    case 161: 
      field_175336_F.useLavaOceans = lllIlIIIllIlI;
      "".length();
      if ((0x2B ^ 0x66 ^ 0x51 ^ 0x18) < ((0x12 ^ 0x42 ^ 0x17 ^ 0x1) & (0xE5 ^ 0x89 ^ 0xED ^ 0xC7 ^ -" ".length()))) {
        return;
      }
      break;
    case 210: 
      field_175336_F.useMonuments = lllIlIIIllIlI;
    }
    if (llIlIlIIIII(field_175336_F.equals(field_175334_E))) {
      lllIlIIIlllll.func_181031_a(lIIIIIlIll[1]);
    }
  }
  
  private static boolean llIlIIlllII(Object ???)
  {
    String lllIIIlIIllll;
    return ??? != null;
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    lllIlIllIlIlI.handleMouseInput();
    field_175349_r.handleMouseInput();
  }
  
  private static boolean llIlIlIIIll(int ???, int arg1)
  {
    int i;
    byte lllIIIlIlIIIl;
    return ??? < i;
  }
  
  private static String lIlIlllIIIl(String lllIIIllIlllI, String lllIIIllIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllIIIllIlllI = new String(Base64.getDecoder().decode(lllIIIllIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllIIIlllIIIl = new StringBuilder();
    char[] lllIIIlllIIII = lllIIIllIllIl.toCharArray();
    int lllIIIllIllll = lIIIIIlIll[0];
    boolean lllIIIllIlIIl = lllIIIllIlllI.toCharArray();
    char lllIIIllIlIII = lllIIIllIlIIl.length;
    Exception lllIIIllIIlll = lIIIIIlIll[0];
    while (llIlIlIIIll(lllIIIllIIlll, lllIIIllIlIII))
    {
      char lllIIIlllIlII = lllIIIllIlIIl[lllIIIllIIlll];
      "".length();
      "".length();
      if (" ".length() > "   ".length()) {
        return null;
      }
    }
    return String.valueOf(lllIIIlllIIIl);
  }
  
  public void func_175319_a(int lllIlIlIIIIll, String lllIlIlIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    float lllIlIlIIIllI = 0.0F;
    try
    {
      lllIlIlIIIllI = Float.parseFloat(lllIlIlIIIIlI);
      "".length();
      if ((0x5C ^ 0x58) < "   ".length()) {
        return;
      }
    }
    catch (NumberFormatException localNumberFormatException)
    {
      float lllIlIlIIIlIl = 0.0F;
      switch (lllIlIlIIlIII)
      {
      case 132: 
        lllIlIlIIIlIl = field_175336_F.mainNoiseScaleX = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 5000.0F);
        "".length();
        if (null != null) {
          return;
        }
        break;
      case 133: 
        lllIlIlIIIlIl = field_175336_F.mainNoiseScaleY = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 5000.0F);
        "".length();
        if ("   ".length() >= (0x62 ^ 0x3A ^ 0xF ^ 0x53)) {
          return;
        }
        break;
      case 134: 
        lllIlIlIIIlIl = field_175336_F.mainNoiseScaleZ = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 5000.0F);
        "".length();
        if (((0x29 ^ 0x6C) & (0x19 ^ 0x5C ^ 0xFFFFFFFF)) == -" ".length()) {
          return;
        }
        break;
      case 135: 
        lllIlIlIIIlIl = field_175336_F.depthNoiseScaleX = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 2000.0F);
        "".length();
        if ("  ".length() <= ((0x86 ^ 0xB7) & (0x88 ^ 0xB9 ^ 0xFFFFFFFF))) {
          return;
        }
        break;
      case 136: 
        lllIlIlIIIlIl = field_175336_F.depthNoiseScaleZ = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 2000.0F);
        "".length();
        if (" ".length() <= ((0x71 ^ 0x21 ^ 0xA8 ^ 0xB1) & (0x31 ^ 0x76 ^ 0x82 ^ 0x8C ^ -" ".length()))) {
          return;
        }
        break;
      case 137: 
        lllIlIlIIIlIl = field_175336_F.depthNoiseScaleExponent = MathHelper.clamp_float(lllIlIlIIIllI, 0.01F, 20.0F);
        "".length();
        if (" ".length() <= 0) {
          return;
        }
        break;
      case 138: 
        lllIlIlIIIlIl = field_175336_F.baseSize = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 25.0F);
        "".length();
        if ("  ".length() <= " ".length()) {
          return;
        }
        break;
      case 139: 
        lllIlIlIIIlIl = field_175336_F.coordinateScale = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 6000.0F);
        "".length();
        if (null != null) {
          return;
        }
        break;
      case 140: 
        lllIlIlIIIlIl = field_175336_F.heightScale = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 6000.0F);
        "".length();
        if (null != null) {
          return;
        }
        break;
      case 141: 
        lllIlIlIIIlIl = field_175336_F.stretchY = MathHelper.clamp_float(lllIlIlIIIllI, 0.01F, 50.0F);
        "".length();
        if (-" ".length() >= "   ".length()) {
          return;
        }
        break;
      case 142: 
        lllIlIlIIIlIl = field_175336_F.upperLimitScale = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 5000.0F);
        "".length();
        if ((0x59 ^ 0x5D) == -" ".length()) {
          return;
        }
        break;
      case 143: 
        lllIlIlIIIlIl = field_175336_F.lowerLimitScale = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 5000.0F);
        "".length();
        if (" ".length() == 0) {
          return;
        }
        break;
      case 144: 
        lllIlIlIIIlIl = field_175336_F.biomeDepthWeight = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 20.0F);
        "".length();
        if ("  ".length() < 0) {
          return;
        }
        break;
      case 145: 
        lllIlIlIIIlIl = field_175336_F.biomeDepthOffset = MathHelper.clamp_float(lllIlIlIIIllI, 0.0F, 20.0F);
        "".length();
        if ("  ".length() >= (0xBB ^ 0xBF)) {
          return;
        }
        break;
      case 146: 
        lllIlIlIIIlIl = field_175336_F.biomeScaleWeight = MathHelper.clamp_float(lllIlIlIIIllI, 1.0F, 20.0F);
        "".length();
        if (" ".length() == 0) {
          return;
        }
        break;
      case 147: 
        lllIlIlIIIlIl = field_175336_F.biomeScaleOffset = MathHelper.clamp_float(lllIlIlIIIllI, 0.0F, 20.0F);
      }
      if ((llIlIIlllIl(llIlIIlllll(lllIlIlIIIlIl, lllIlIlIIIllI))) && (llIlIIlllIl(llIlIIlllll(lllIlIlIIIllI, 0.0F)))) {
        ((GuiTextField)field_175349_r.func_178061_c(lllIlIlIIlIII)).setText(lllIlIlIIlIIl.func_175330_b(lllIlIlIIlIII, lllIlIlIIIlIl));
      }
      ((GuiSlider)field_175349_r.func_178061_c(lllIlIlIIlIII - lIIIIIlIll['Æ'] + lIIIIIlIll[10])).func_175218_a(lllIlIlIIIlIl, lIIIIIlIll[0]);
      if (llIlIlIIIII(field_175336_F.equals(field_175334_E))) {
        lllIlIlIIlIIl.func_181031_a(lIIIIIlIll[1]);
      }
    }
  }
  
  private void func_175329_a(boolean lllIIlllIIIlI)
  {
    ;
    ;
    field_175352_x.visible = lllIIlllIIIlI;
    field_175351_y.visible = lllIIlllIIIlI;
    if (llIlIIlllIl(lllIIlllIIIlI))
    {
      "".length();
      if (-" ".length() != ((0xD7 ^ 0x87 ^ 0x5A ^ 0x27) & (44 + 99 - 112 + 154 ^ 57 + '' - 189 + 136 ^ -" ".length()))) {
        break label101;
      }
    }
    label101:
    lIIIIIlIll0enabled = lIIIIIlIll[1];
    if (llIlIIlllIl(lllIIlllIIIlI))
    {
      "".length();
      if ("  ".length() < "   ".length()) {
        break label145;
      }
    }
    label145:
    lIIIIIlIll0enabled = lIIIIIlIll[1];
    if (llIlIIlllIl(lllIIlllIIIlI))
    {
      "".length();
      if (((0x40 ^ 0x66) & (0xBE ^ 0x98 ^ 0xFFFFFFFF)) < " ".length()) {
        break label199;
      }
    }
    label199:
    lIIIIIlIll0enabled = lIIIIIlIll[1];
    if (llIlIIlllIl(lllIIlllIIIlI))
    {
      "".length();
      if (" ".length() > -" ".length()) {
        break label244;
      }
    }
    label244:
    lIIIIIlIll0enabled = lIIIIIlIll[1];
    if ((llIlIIlllIl(field_175338_A)) && (llIlIlIIIII(lllIIlllIIIlI)))
    {
      "".length();
      if ((26 + 21 - -18 + 80 ^ 114 + 34 - 111 + 111) > 0) {
        break label311;
      }
    }
    label311:
    lIIIIIlIll1enabled = lIIIIIlIll[0];
    if (llIlIIlllIl(lllIIlllIIIlI))
    {
      "".length();
      if (((0xEC ^ 0xC0) & (0xB6 ^ 0x9A ^ 0xFFFFFFFF)) == 0) {
        break label362;
      }
    }
    label362:
    lIIIIIlIll0enabled = lIIIIIlIll[1];
    if (llIlIIlllIl(lllIIlllIIIlI))
    {
      "".length();
      if (null == null) {
        break label397;
      }
    }
    label397:
    lIIIIIlIll[0].func_181155_a(lIIIIIlIll[1]);
  }
  
  private void func_175327_a(float lllIIllIIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Gui lllIIllIIlIll = field_175349_r.func_178056_g();
    if (llIlIIlllIl(lllIIllIIlIll instanceof GuiTextField))
    {
      float lllIIllIIlIlI = lllIIllIIIlII;
      if (llIlIIlllIl(GuiScreen.isShiftKeyDown()))
      {
        lllIIllIIlIlI = lllIIllIIIlII * 0.1F;
        if (llIlIIlllIl(GuiScreen.isCtrlKeyDown()))
        {
          lllIIllIIlIlI *= 0.1F;
          "".length();
          if ("   ".length() >= -" ".length()) {}
        }
      }
      else if (llIlIIlllIl(GuiScreen.isCtrlKeyDown()))
      {
        lllIIllIIlIlI = lllIIllIIIlII * 10.0F;
        if (llIlIIlllIl(GuiScreen.isAltKeyDown())) {
          lllIIllIIlIlI *= 10.0F;
        }
      }
      GuiTextField lllIIllIIlIIl = (GuiTextField)lllIIllIIlIll;
      Float lllIIllIIlIII = Floats.tryParse(lllIIllIIlIIl.getText());
      if (llIlIIlllII(lllIIllIIlIII))
      {
        lllIIllIIlIII = Float.valueOf(lllIIllIIlIII.floatValue() + lllIIllIIlIlI);
        int lllIIllIIIlll = lllIIllIIlIIl.getId();
        String lllIIllIIIllI = lllIIllIIllIl.func_175330_b(lllIIllIIlIIl.getId(), lllIIllIIlIII.floatValue());
        lllIIllIIlIIl.setText(lllIIllIIIllI);
        lllIIllIIllIl.func_175319_a(lllIIllIIIlll, lllIIllIIIllI);
      }
    }
  }
  
  public String func_175323_a()
  {
    ;
    return field_175336_F.toString().replace(llIlIIllI[lIIIIIlIll[35]], llIlIIllI[lIIIIIlIll[37]]);
  }
  
  private static int llIlIIlllll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llIlIlIIIlI(int ???)
  {
    short lllIIIlIIlIIl;
    return ??? < 0;
  }
  
  private static boolean llIlIlIIIII(int ???)
  {
    String lllIIIlIIlIll;
    return ??? == 0;
  }
  
  private static void lIllllIIIll()
  {
    llIlIIllI = new String[lIIIIIlIll[60]];
    llIlIIllI[lIIIIIlIll[0]] = lIlIlllIIIl("CAUbDC0mGRIdYhwfGhQmayMNDDYiHg8L", "KphxB");
    llIlIIllI[lIIIIIlIll[1]] = lIlIlllIIlI("ddB2Ih2QIXV0iYcM37csaQ==", "XWVYS");
    llIlIIllI[lIIIIIlIll[2]] = lIlIlllIIIl("LgY4Ay1MNC4eOgUJLBk=", "lgKjN");
    llIlIIllI[lIIIIIlIll[4]] = lIlIlllIIIl("DhMNODkPEFcyIxIXFjw/GwYtOCINBg==", "acyQV");
    llIlIIllI[lIIIIIlIll[3]] = lIlIlllIlII("wBKsz5XA2OQQFCaohzKgWYgCUbLTlRd8f4heleDxWKXaHitihjbNuQ==", "sTFKV");
    llIlIIllI[lIIIIIlIll[7]] = lIlIlllIlII("k+rXh9paCOGnwLtnlH9NQjULkGHwl0tbk5HZ+JQA/VB3wfnb8Y47ow==", "VJkkl");
    llIlIIllI[lIIIIIlIll[15]] = lIlIlllIlII("cIIR9uUoxLkDjpK+BHHT1nTrjRR/aVVsgvKOpUTorKsphrAq+3bfQw==", "IyxSf");
    llIlIIllI[lIIIIIlIll[18]] = lIlIlllIIlI("MwjxBcV8vqtHmIMTbCXH0jekxn5q/BPDONICPDG16eRkVw9HEaeGpg==", "BzKgY");
    llIlIIllI[lIIIIIlIll[20]] = lIlIlllIlII("xmJEgnC6JLlqYEln0FhQ6QjxOSVzOu9BJCvzYlTdHaGbel1B7P1gLQ==", "Amifk");
    llIlIIllI[lIIIIIlIll[23]] = lIlIlllIlII("GFdWEx2LDr8Ql9oetmKSug==", "zqsdf");
    llIlIIllI[lIIIIIlIll[28]] = lIlIlllIIlI("SvlpcrzwyF4=", "DgymW");
    llIlIIllI[lIIIIIlIll[30]] = lIlIlllIIIl("CRgFRz4B", "nmliP");
    llIlIIllI[lIIIIIlIll[32]] = lIlIlllIIIl("NSUSByIzABgUOjJ5FBMlIjgaDywzeRQTJSI4GkglMzY7AyAzOw==", "VWwfV");
    llIlIIllI[lIIIIIlIll[34]] = lIlIlllIIlI("OiMTceAXu5homct5IV3NLHLXKd7fSFZMXtjBtRj5jnt46uTvB79ZPQ==", "gflNn");
    llIlIIllI[lIIIIIlIll[36]] = lIlIlllIIIl("ET8HIA4XGg0zFhZjATQJBiIPKAAXYwE0CQYiD28PASgxNQgdIwUpFR4pEQ==", "rMbAz");
    llIlIIllI[lIIIIIlIll[38]] = lIlIlllIIIl("BDAdMz0CFRcgJQNsGyc6Ey0VOzMCbBsnOhMtFXw8FCcuOyULIx83Og==", "gBxRI");
    llIlIIllI[lIIIIIlIll[40]] = lIlIlllIIIl("NzoIIh4xHwIxBjBmDjYZICcAKhAxZg42GSAnAG0fJy0gKgQxGwUiDCA7", "THmCj");
    llIlIIllI[lIIIIIlIll[42]] = lIlIlllIIlI("0tHI1sQ6kJwx60xI2zWFWQLRke+lfn8o1uI/R79PTF2pId15uVIoEg==", "xknBq");
    llIlIIllI[lIIIIIlIll[31]] = lIlIlllIlII("YzulQ6UXXYPhmjqSn3h/oCnQmBsU9cDQbk9OcGwxXs9xP+Ws7Ep65j44DxKIHK7q", "ceywE");
    llIlIIllI[lIIIIIlIll[45]] = lIlIlllIIlI("Vc59L2f1EkTi3yQ4ES12qq8AYb4OadDKHbTEMdL/Hsn/sz60S+JURQ==", "fpcKG");
    llIlIIllI[lIIIIIlIll[6]] = lIlIlllIIIl("FzUpLzwRECM8JBBpLzs7ACghJzIRaS87OwAoIWA9ByIIOyYTIiMgOw==", "tGLNH");
    llIlIIllI[lIIIIIlIll[48]] = lIlIlllIIlI("XXbNLCK/0pPA0IVO60P9dmvjEBgV3l+YsfGlGxa8rJnpNT1qp085A/rb7qBMXpfe", "Iojvj");
    llIlIIllI[lIIIIIlIll[50]] = lIlIlllIIIl("Oxc3MTc9Mj0iLzxLMSUwLAo/OTk9SzElMCwKP342KwAFMTc9Fx4xKD0W", "XeRPC");
    llIlIIllI[lIIIIIlIll[52]] = lIlIlllIIlI("3jcdrjLW9+L5O0XaM1t8Q8C0KC5Dr4doolQVr9U+eOj4/HhrQi/qlypSVutS7vXI", "znpsv");
    llIlIIllI[lIIIIIlIll[54]] = lIlIlllIIlI("zd1nWEvLA/9ZOWeAM2sCrANDDsmI9YoM3OrGdQ4q03bHPr65F9qEjXFCwuF/2nMF", "OLgyj");
    llIlIIllI[lIIIIIlIll[56]] = lIlIlllIlII("QGh6JpGLaj1sRW4nN5lKD/ggP1Q8cYxapDvUB8dnQv0GcKPSgFCbzigx3G2tGdjA", "TZkrt");
    llIlIIllI[lIIIIIlIll[58]] = lIlIlllIIIl("CAQICwwOIQIYFA9YDh8LHxkAAwIOWA4fCx8ZAEQNGBMhCw4KOQ4PGQUF", "kvmjx");
    llIlIIllI[lIIIIIlIll[13]] = lIlIlllIIlI("Mf+g73HjwY5z8LzzBv+87tki8C8+D7hC2sBINXM5oXox/PNQTC0qWw==", "oecxP");
    llIlIIllI[lIIIIIlIll[61]] = lIlIlllIlII("xC2sbSybhcceZhhsuQ/hS3Sc2BWJZOPEfOLDgYFS72AD9gFiyNlHKw==", "AMHCM");
    llIlIIllI[lIIIIIlIll[63]] = lIlIlllIIIl("CiotCBcMDycbDw12KxwQHTclABkMdiscEB03JUcRAC4tGzAAIi0=", "iXHic");
    llIlIIllI[lIIIIIlIll[66]] = lIlIlllIIIl("NTslJ2olOzs2ai8zJCc=", "ARIBD");
    llIlIIllI[lIIIIIlIll[68]] = lIlIlllIIlI("pAsJSlVoKkfSNkHZJfe0MDv1fKG3VcA4QdMLsSP2aFhjvQ5F0/nFIg==", "kUXFd");
    llIlIIllI[lIIIIIlIll[70]] = lIlIlllIlII("PNGucES06uGGiQAPYmizl8pf7i8UDKaevC+oe8jZQi/6kE0p7cevmg==", "QYdmJ");
    llIlIIllI[lIIIIIlIll[72]] = lIlIlllIIlI("yuBOyFpu/ZG3rTEatCFfSTD/R5nF+qDC8eKXtnV1vjs2nNnqasfKWQ==", "CAwQp");
    llIlIIllI[lIIIIIlIll[74]] = lIlIlllIlII("iTMZDVLww1E1I4+/QMjuYm4XJAswFGbIZmJBRW6FwiijJnxWV5rM4g==", "htysa");
    llIlIIllI[lIIIIIlIll[76]] = lIlIlllIIlI("dO95X+Ht9wcAbUswlC8gDae908W2NsFk", "xIhsN");
    llIlIIllI[lIIIIIlIll[78]] = lIlIlllIlII("fy4KkWoLreABcEAZ2ij9QO1q1A54lYGwi0/EqL6El5VOH8zwzhEzOg==", "IgTHg");
    llIlIIllI[lIIIIIlIll[80]] = lIlIlllIIlI("ecqgYg0jkjaVhhQG3dxpZIUlJxaz9+Ux7ttRkle+fu5Ze6pJldGlTQ==", "oznlE");
    llIlIIllI[lIIIIIlIll[82]] = lIlIlllIIIl("CQsHFiUPLg0FPQ5XAQIiHhYPHisPVwECIh4WD1k8AxcqEjgNERY=", "jybwQ");
    llIlIIllI[lIIIIIlIll[84]] = lIlIlllIIIl("ByMEEjIBBg4BKgB/AgY1ED4MGjwBfwIGNRA+DF0rBSkpFi8DORU=", "dQasF");
    llIlIIllI[lIIIIIlIll[86]] = lIlIlllIlII("Fae2rf26fRcVTq95gmMhRgImLoracsCZ", "OZuVL");
    llIlIIllI[lIIIIIlIll[88]] = lIlIlllIlII("q0AwqNca3EPlVQQ5x3K7yOY91Rfxom3Ot53GLez5Q8wL6RJaqGzdbg==", "YreQQ");
    llIlIIllI[lIIIIIlIll[90]] = lIlIlllIIIl("BTkIFycDHAIEPwJlDgMgEiQAHykDZQ4DIBIkAFgwCT4DAg==", "fKmvS");
    llIlIIllI[lIIIIIlIll[92]] = lIlIlllIlII("t5u39yIec7U76eGB9gFEnRt+l0UtOARMh205vTlOPZxyFB4fmC+1bA==", "AWPdF");
    llIlIIllI[lIIIIIlIll[94]] = lIlIlllIlII("1dW2JEyWov2zT5Gl2SAn7hlq54a/Hnk7YIOxMrLeSSiwozGxJk/Y5Q==", "vOcQV");
    llIlIIllI[lIIIIIlIll[96]] = lIlIlllIIlI("RBnzlAqjQ5sBIwf7lMscJvmvast7UZum", "sRhkZ");
    llIlIIllI[lIIIIIlIll[98]] = lIlIlllIIIl("KDUUMgAuEB4hGC9pEiYHPygcOg4uaRImBz8oHH0HIj0U", "KGqSt");
    llIlIIllI[lIIIIIlIll[100]] = lIlIlllIIIl("NjkKOS0wHAAqNTFlDC0qISQCMSMwZQwtKiEkAnY6Oj4BLA==", "UKoXY");
    llIlIIllI[lIIIIIlIll[102]] = lIlIlllIIlI("oPxb/4V1PTEyhpMhwgwJXj8letaUjFkdT1aIbzs7XgWPt0PExQuy8w==", "bddnV");
    llIlIIllI[lIIIIIlIll[104]] = lIlIlllIIlI("5UqVJh0gTmTetUDEv7O6FfGt1AagNqgNU8VVVroEdvv2qCGMmPDtuw==", "OCQhu");
    llIlIIllI[lIIIIIlIll[27]] = lIlIlllIIIl("Nw4lIW0wEyYqJm0GJyAmMA49IW0tBiQh", "CgIDC");
    llIlIIllI[lIIIIIlIll[107]] = lIlIlllIIlI("vwKrKQ/Xyb0MPj9nks4/674dvEo35u6d2IbnWTzLc2QeVx7yiKVsWw==", "NjPvY");
    llIlIIllI[lIIIIIlIll[109]] = lIlIlllIIIl("LgEPMjkoJAUhISldCSY+ORwHOjcoXQkmPjkcB30uIgYEJw==", "MsjSM");
    llIlIIllI[lIIIIIlIll[111]] = lIlIlllIlII("YLppOrRM6NJrbjyZectIM9yVWL47sTRP8UOl4Mm6YvDUapxEAFIg5A==", "gHrpD");
    llIlIIllI[lIIIIIlIll[113]] = lIlIlllIlII("tgTASWNoSSpsVN+W1awGmm/e8FbbHab3vQ1cBWdloxGy02FDlehDjg==", "KhPLf");
    llIlIIllI[lIIIIIlIll[25]] = lIlIlllIIIl("DiAdEk8VOxQ0DhslXxkAFyw=", "zIqwa");
    llIlIIllI[lIIIIIlIll[116]] = lIlIlllIlII("sTm++ji3XDJe+j3CbGae4XXmkQkaSovVWOLZ1WyBpOPqQafxyon3xA==", "cAjND");
    llIlIIllI[lIIIIIlIll[118]] = lIlIlllIIlI("yd3UBcTEl1YcR9OOZwKHeS6CEhq9zHkoM6d4hF1Tiwpf2ETw8r0j4w==", "suBWM");
    llIlIIllI[lIIIIIlIll[119]] = lIlIlllIIlI("NxDLqJ8cRj5B3Ysi9DlhEFPKFx5DszzAVRSpMtrljJGn0b9IapoUzA==", "hzaNb");
    llIlIIllI[lIIIIIlIll[121]] = lIlIlllIIIl("NBYcFwYyMxYEHjNKGgMBIwsUHwgyShoDASMLFFgfNhwxExswDA0=", "Wdyvr");
    llIlIIllI[lIIIIIlIll[123]] = lIlIlllIIlI("Fadmj5VlIqA5kkgjiAutwOQguDhUeKKO", "hmWkn");
    llIlIIllI[lIIIIIlIll[125]] = lIlIlllIlII("cXwncmcoX0N8w0Fjlk5HB5+rkYSl1eIuAHDR13ZIfmtzm1JpI+s7fQ==", "Nodxu");
    llIlIIllI[lIIIIIlIll[127]] = lIlIlllIIlI("bqjI2Z1TAqbbz4ANLFWO6cfeevuMGN/PHM1xbVOsLb3O++baLMqCsA==", "vRlnn");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIIIl("DDkmJQYKHCw2HgtlIDEBGyQuLQgKZSAxARskLmofBiULIRsIIzc=", "oKCDr");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIIIl("CAUVBCUOIB8XPQ9ZExAiHxgdDCsOWRMQIh8YHUs8Cg84ADgMHwQ=", "kwpeQ");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIlII("50pgOr/E8JlPmCEx1umlkd0oGuPaCA1D", "iqaWb");
    llIlIIllI[lIIIIIlIll[64]] = lIlIlllIIlI("lh5jgPufqm1x8X2danRoOlJIP4KdjW7NXPc4gjgS6cxltzLzLrXInA==", "VfYhG");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIIIl("BAUPFzYCIAUELgNZCQMxExgHHzgCWQkDMRMYB1ghCAIEAg==", "gwjvB");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIIlI("UKKdum5+pO5qBISjyAbqnsMcO4bYUgXRD4+UjlAtaR3NstA12PBVcw==", "FcPDa");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIlII("qrXZklqpnppElKVNAYcFEE1gD0dvhsz4MB6nLZYn/1xTOrZsmsN4Dw==", "DvmBG");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIlII("+FKQAfiH7EWAQSQuQZDsuaRVbbIpt97Z", "bREGZ");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIIIl("FAAjKx0SJSk4BRNcJT8aAx0rIxMSXCU/GgMdK2QaHggj", "wrFJi");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIIlI("IvWei6xzssxO6hEEctuvOptFWuhAmL95ipGOtMwtY1Su6/zPLDFlWA==", "WPZrY");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIIIl("MwAkKx01JS44BTRcIj8aJB0sIxM1XCI/GiQdLGQEORwJLwA3GjU=", "PrAJi");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIIlI("L1kosXtjH5WksUJp/30TArMURNYXioNEi3ZWcRqIimgSVCcdx2udLw==", "NjwGx");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIlII("6UB6fUmVgIm3iyg4hzaPL2ezu0kyuGXP", "aewzK");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIlII("tdCFRrdBtu6s168gqoxncF+Uc5X2bapfGPLofrVaeYRiI6hO77LAyA==", "Ikkub");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIlII("0vJu9pZ4eIt71EAM5PVESKg5bHdC/VdeLzIKWgW0d1exDpvSGi/aTQ==", "PuGfb");
    llIlIIllI[lIIIIIlIll['']] = lIlIlllIIIl("JD0dKQUiGBc6HSNhGz0CMyAVIQsiYRs9AjMgFWYcLiEwLRggJww=", "GOxHq");
    llIlIIllI[lIIIIIlIll[' ']] = lIlIlllIIlI("TPh64Tx2h/IlV9EY48JrOsFYZVTixK0YDs/PdE95uH4z3rhglilfOA==", "EqVLS");
    llIlIIllI[lIIIIIlIll[8]] = lIlIlllIIIl("NzMZI08sKBAKADMzBmgPIjcQ", "CZuFa");
    llIlIIllI[lIIIIIlIll['£']] = lIlIlllIIIl("DjQAKBMIEQo7CwloBjwUGSkIIB0IaAY8FBkpCGcUBDwA", "mFeIg");
    llIlIIllI[lIIIIIlIll['¥']] = lIlIlllIIIl("KTczExovEjkAAi5rNQcdPio7GxQvazUHHT4qO1wNJTA4Bg==", "JEVrn");
    llIlIIllI[lIIIIIlIll['§']] = lIlIlllIIIl("Lj4pMh8oGyMhByliLyYYOSMhOhEoYi8mGDkjIX0IKCI4Nhk=", "MLLSk");
    llIlIIllI[lIIIIIlIll['©']] = lIlIlllIIlI("rOi+LPizYRaXgkuJYgzhO16oCSA4SZgi4zVPVJrf7cmOQhmlNdXuKw==", "mMSGj");
    llIlIIllI[lIIIIIlIll['ª']] = lIlIlllIIlI("4q9HvdmN0NhPXtxzr1nLsKKrsO7stL1gCf9ATIq2hCZ18vTKk2SBM+5Bmh3FSdo1", "zNYEd");
    llIlIIllI[lIIIIIlIll['¬']] = lIlIlllIIlI("hV7OkbC6zlyWkMmk9OrNkpQHLyhbj3YoAtjX0O40k5uu4hXoY4lN3Laol4gd/A0Y", "aDULX");
    llIlIIllI[lIIIIIlIll['®']] = lIlIlllIlII("1FGj8VDtI9Tbvp2fVCMjCZ5RxALPRt8mRA3jnyBALt0zdL5ls0C3vGZCf0C8fgFN", "ArBvl");
    llIlIIllI[lIIIIIlIll['°']] = lIlIlllIIlI("gs2mPv4UKcChynZAXBxszqRgvAhFsJeV9tOdDGSIBA4O1MXoaHrWy1gHj4frLRru", "VHoUa");
    llIlIIllI[lIIIIIlIll['²']] = lIlIlllIIIl("Bzo3NTsBHz0mIwBmMSE8ECc/PTUBZjEhPBAnP3orATgmPAELISExHAcpPjEV", "dHRTO");
    llIlIIllI[lIIIIIlIll[14]] = lIlIlllIIIl("CQsWLwMPLhw8Gw5XEDsEHhYeJw0PVxA7BB4WHmATDwkHJjkFEAArJAkYHysyEgkcIBIEDQ==", "jysNw");
    llIlIIllI[lIIIIIlIll['µ']] = lIlIlllIIIl("KSAsIA0vBSYzFS58KjQKPj0kKAMvfCo0Cj49JG8bKyEsEhAwNw==", "JRIAy");
    llIlIIllI[lIIIIIlIll[17]] = lIlIlllIlII("Wa50kD4gMuDzksODizwBHKl0SWZNO3YtoXpXe0SJZufQ8Ukkx4YHpu9YqNgNcEAN", "AvYKJ");
    llIlIIllI[lIIIIIlIll['¸']] = lIlIlllIIIl("ECQCLBsWAQg/Axd4BDgcBzkKJBUWeAQ4HAc5CmMHFj8AJRsgNQYhCg==", "sVgMo");
    llIlIIllI[lIIIIIlIll['º']] = lIlIlllIIIl("ESsCDxEXDggcCRZ3BBsWBjYKBx8XdwQbFgY2CkAWBisCGgYaAA==", "rYgne");
    llIlIIllI[lIIIIIlIll['¼']] = lIlIlllIlII("OgYVX8+Nq6tvR0tReL7mFOI+CxPKnYFyKg2oVyx8SRK2+ybTZp7BqIaFteZK9ZKl", "ixEPw");
    llIlIIllI[lIIIIIlIll['¾']] = lIlIlllIIIl("JTwxIBwjGTszBCJgNzQbMiE5KBIjYDc0GzIhOW8EKTkxMyQvIz01OyUvOCQ=", "FNTAh");
    llIlIIllI[lIIIIIlIll['À']] = lIlIlllIIIl("DiYBEz4IAwsAJgl6Bwc5GTsJGzAIegcHORk7CVwoBDsJFw4IJBAaHQg9Axo+", "mTdrJ");
    llIlIIllI[lIIIIIlIll[22]] = lIlIlllIIlI("PqPQ7kp4ypyafFboQBmqpJZ/qsMD3FO/07+fSLrf6wQIMXSssLLSS7NdBajQC/Eb", "BFHPX");
    llIlIIllI[lIIIIIlIll['Ã']] = lIlIlllIlII("tIgtkzNstdPXBde3HsivKZJNmxVfQ7GDb8JNa4rVbdZKKuofmGKvlnET/bqEI2kC", "hqiMB");
    llIlIIllI[lIIIIIlIll[10]] = lIlIlllIIlI("q2U1ngyk2y2vq0G7CaJz21St6sRV/dXHt9WMSWuvgzOiwGMTJx7yhU7L73fg2rfh", "niVyV");
    llIlIIllI[lIIIIIlIll['«']] = lIlIlllIIIl("CyoQNTgNDxomIAx2FiE/HDcYPTYNdhYhPxw3GHohCTEbGiMBKxAHLwk0EAw=", "hXuTL");
    llIlIIllI[lIIIIIlIll['­']] = lIlIlllIIIl("XA==", "fPGDz");
    llIlIIllI[lIIIIIlIll['¯']] = lIlIlllIIlI("po2EOeSA9yo=", "pWCKW");
    llIlIIllI[lIIIIIlIll['±']] = lIlIlllIIlI("sgJojfR+AjXufwLQ0Z0iQxkeR0AvBVGoSANl1lVf58bd3jdRGdvKh3j8UYPRQ7QQ", "YqLEk");
    llIlIIllI[lIIIIIlIll['³']] = lIlIlllIlII("PYX1YU1Rid4=", "GwaAl");
    llIlIIllI[lIIIIIlIll['´']] = lIlIlllIIlI("0uKUfesKV9c=", "KTPIW");
    llIlIIllI[lIIIIIlIll['¶']] = lIlIlllIIlI("rac/Dejr08WkqN0pdeqNn0G/aMI8YLAojYn2ojwteu+2FFydqri/AF/ngPcQKX6r", "wsqOp");
    llIlIIllI[lIIIIIlIll['·']] = lIlIlllIIIl("XA==", "fbCou");
    llIlIIllI[lIIIIIlIll['¹']] = lIlIlllIlII("9x4PL0L/tYI=", "tPtGP");
    llIlIIllI[lIIIIIlIll['»']] = lIlIlllIlII("Iw4vdbD+xQVahagDYvvjOt6nfOBFgKCIHMXz5F0u0dxewqep3qy996WxjZRtYbbd", "eulji");
    llIlIIllI[lIIIIIlIll['½']] = lIlIlllIIlI("eIuouuJNqec=", "LUUHv");
    llIlIIllI[lIIIIIlIll['¿']] = lIlIlllIIIl("SGNHXQE=", "mVing");
    llIlIIllI[lIIIIIlIll['Á']] = lIlIlllIlII("xR/qxeGYFNrxcN0a67VaL8OQWWPwzxzgsIFpfcBstN9ejC/OaA9WJbOEYJb9JqIB", "uFnUB");
    llIlIIllI[lIIIIIlIll['Â']] = lIlIlllIIIl("eA==", "BmpwF");
    llIlIIllI[lIIIIIlIll['Ä']] = lIlIlllIlII("1+17Ik6a4aM=", "RVJHx");
    llIlIIllI[lIIIIIlIll['Ð']] = lIlIlllIIIl("Dwc2ODcJIjwrLwhbMCwwGBo+MDkJWzAsMBgaPncnCQUnMQ0DHCA8EA8UPzwGFAU8NyYCAQ==", "luSYC");
    llIlIIllI[lIIIIIlIll['Ñ']] = lIlIlllIIIl("TQ==", "wqLxx");
    llIlIIllI[lIIIIIlIll['Ó']] = lIlIlllIIIl("U3lpSTc=", "vKGzQ");
    llIlIIllI[lIIIIIlIll['Õ']] = lIlIlllIlII("7VqSQaPmFM1TyoavJwqP70X3uBEEhBFMnyVcPe8H+8EeFy9z6K+uqQ==", "wyjrl");
    llIlIIllI[lIIIIIlIll['Ö']] = lIlIlllIlII("S2otq5ahPh0=", "nxTNl");
    llIlIIllI[lIIIIIlIll['Ø']] = lIlIlllIIlI("rTr1xDDYBOk=", "lXAul");
    llIlIIllI[lIIIIIlIll['Ú']] = lIlIlllIlII("jaxr1svwgAm6mxxgGrTGtBrjuEStMVebK51uDSY74vAXIhVlv0A/npwiW3s3iw08", "Lhjnb");
    llIlIIllI[lIIIIIlIll['Û']] = lIlIlllIIIl("fQ==", "GQAYq");
    llIlIIllI[lIIIIIlIll['Ý']] = lIlIlllIlII("FjSzQJKEf18=", "JviWU");
    llIlIIllI[lIIIIIlIll['ß']] = lIlIlllIIIl("CQgPERIPLQUCCg5UCQUVHhUHGRwPVAkFFR4VB14ODxMNGBI5GQscAw==", "jzjpf");
    llIlIIllI[lIIIIIlIll['à']] = lIlIlllIIIl("Tw==", "uDgzh");
    llIlIIllI[lIIIIIlIll['â']] = lIlIlllIlII("3y4pq3zHhLc=", "tYdrA");
    llIlIIllI[lIIIIIlIll['ä']] = lIlIlllIIIl("FwgBNzMRLQskKxBUByM0ABUJPz0RVAcjNAAVCXg0AAgBIiQcIw==", "tzdVG");
    llIlIIllI[lIIIIIlIll['å']] = lIlIlllIIIl("ag==", "PlPhZ");
    llIlIIllI[lIIIIIlIll['ç']] = lIlIlllIlII("Mheodi5RTJ4=", "mwQYe");
    llIlIIllI[lIIIIIlIll['é']] = lIlIlllIIIl("EiczGREUAjkKCRV7NQ0WBTo7ER8UezUNFgU6O1YQASUzCikYOD8MNhI0Oh0=", "qUVxe");
    llIlIIllI[lIIIIIlIll['Æ']] = lIlIlllIIlI("SIdTY9HnQxU=", "dnVdB");
    llIlIIllI[lIIIIIlIll['È']] = lIlIlllIlII("VbYiqxwEkbI=", "wVvYn");
    llIlIIllI[lIIIIIlIll['Ê']] = lIlIlllIIIl("JAUhOQYiICsqHiNZJy0BMxgpMQgiWSctATMYKXYeKAAhKj4uGi0sISQWKD0=", "GwDXr");
    llIlIIllI[lIIIIIlIll['Ì']] = lIlIlllIIlI("xO7CoR+6jhE=", "oywPb");
    llIlIIllI[lIIIIIlIll['Î']] = lIlIlllIlII("+l8QP0xk/0U=", "vCVGM");
    llIlIIllI[lIIIIIlIll['Ò']] = lIlIlllIlII("iwOtA4M2lHXKF88UKM+PKShgZc9HevFE3QkX2uQkgFeG/DAjTiMJVMV/57DODVty", "covek");
    llIlIIllI[lIIIIIlIll['×']] = lIlIlllIIlI("33X5qEAe2hs=", "hJBaL");
    llIlIIllI[lIIIIIlIll['Ü']] = lIlIlllIlII("ndwXCfsZMMs=", "Bghpc");
    llIlIIllI[lIIIIIlIll['á']] = lIlIlllIIlI("7zrFsW670xK0CHUFrHmItxPcX9tDOf/PlkFd+TVt3fiMJQ0dLdddu1HBP2bkHvNp", "mLCpM");
    llIlIIllI[lIIIIIlIll['æ']] = lIlIlllIIlI("CxBDPcl3XF8=", "GGvdL");
    llIlIIllI[lIIIIIlIll['ê']] = lIlIlllIIlI("8hs6GxWvp+s=", "ZEdYT");
    llIlIIllI[lIIIIIlIll['ì']] = lIlIlllIIlI("SNUOmXWX5LXhFgrsCMTstQoSv1YsyzLlGdI1rRXddymRccrH29VCnlP77ZcHgzbi", "mWzfP");
    llIlIIllI[lIIIIIlIll['î']] = lIlIlllIlII("oZE32CkBLsU=", "CJYAu");
    llIlIIllI[lIIIIIlIll['ð']] = lIlIlllIlII("y8CvDKrdDvc=", "NyCjZ");
    llIlIIllI[lIIIIIlIll['ò']] = lIlIlllIIIl("GxEwLRkdNDo+ARxNNjkeDAw4JRcdTTY5HgwMOGIPEQw4KT4bAjkpIh4FJikZ", "xcULm");
    llIlIIllI[lIIIIIlIll['ô']] = lIlIlllIIlI("oYETymGvbd0=", "JcBLX");
    llIlIIllI[lIIIIIlIll[33]] = lIlIlllIlII("IiyCgs61wxw=", "mToSz");
    llIlIIllI[lIIIIIlIll[46]] = lIlIlllIIlI("vtISf49VhDZ/GdPTimtb/gVtJiBLUmdjPy5XaFfEiRcS3BTcwRvOnw==", "DDrLX");
    llIlIIllI[lIIIIIlIll[35]] = lIlIlllIlII("zFXF6GtU7kI=", "ctYvM");
    llIlIIllI[lIIIIIlIll[37]] = lIlIlllIIlI("NGNg8QqnMqs=", "BIegu");
    llIlIIllI[lIIIIIlIll[39]] = lIlIlllIIlI("miBf/n+8ddY=", "BfXnY");
    llIlIIllI[lIIIIIlIll[41]] = lIlIlllIIlI("qY57GpTTi5g=", "xEKsP");
    llIlIIllI[lIIIIIlIll[44]] = lIlIlllIIlI("cSqEzImDT7Q=", "lfdbS");
    llIlIIllI[lIIIIIlIll[49]] = lIlIlllIIlI("uqaHcmhGL30=", "FqJmG");
    llIlIIllI[lIIIIIlIll[53]] = lIlIlllIIIl("KzQBfBMgLQ==", "LAhRr");
    llIlIIllI[lIIIIIlIll[47]] = lIlIlllIlII("elfgXDA8ZyU=", "CDxVN");
    llIlIIllI[lIIIIIlIll[51]] = lIlIlllIlII("IdGdGdPZmOw=", "MJejN");
    llIlIIllI[lIIIIIlIll[55]] = lIlIlllIlII("Rjx2OabwwJ8T4wCNEE4CAFAwNoiajyTm", "iJmKa");
    llIlIIllI[lIIIIIlIll[26]] = lIlIlllIIIl("NxY2ExUxMzwADTBKMAcSIAs+GxsxSjAHEiALPlwCOwo1GxM5MDoGDTE=", "TdSra");
    llIlIIllI[lIIIIIlIll[57]] = lIlIlllIIIl("LCA/KxMqBTU4Cyt8OT8UOz03Ix0qfDk/FDs9N2QEIDw8IxUiYw==", "ORZJg");
    llIlIIllI[lIIIIIlIll[59]] = lIlIlllIIIl("AB8/Jh8GOjU1BwdDOTIYFwI3LhEGQzkyGBcCN2kIDAM8LhkOXw==", "cmZGk");
  }
  
  private String func_175330_b(int lllIlIIlIIlIl, float lllIlIIlIlIII)
  {
    ;
    ;
    ;
    switch (lllIlIIlIIlIl)
    {
    case 100: 
    case 101: 
    case 102: 
    case 103: 
    case 104: 
    case 107: 
    case 108: 
    case 110: 
    case 111: 
    case 132: 
    case 133: 
    case 134: 
    case 135: 
    case 136: 
    case 139: 
    case 140: 
    case 142: 
    case 143: 
      return String.format(llIlIIllI[lIIIIIlIll[41]], new Object[] { Float.valueOf(lllIlIIlIlIII) });
    case 105: 
    case 106: 
    case 109: 
    case 112: 
    case 113: 
    case 114: 
    case 115: 
    case 137: 
    case 138: 
    case 141: 
    case 144: 
    case 145: 
    case 146: 
    case 147: 
      return String.format(llIlIIllI[lIIIIIlIll[44]], new Object[] { Float.valueOf(lllIlIIlIlIII) });
    case 116: 
    case 117: 
    case 118: 
    case 119: 
    case 120: 
    case 121: 
    case 122: 
    case 123: 
    case 124: 
    case 125: 
    case 126: 
    case 127: 
    case 128: 
    case 129: 
    case 130: 
    case 131: 
    case 148: 
    case 149: 
    case 150: 
    case 151: 
    case 152: 
    case 153: 
    case 154: 
    case 155: 
    case 156: 
    case 157: 
    case 158: 
    case 159: 
    case 160: 
    case 161: 
    default: 
      return String.format(llIlIIllI[lIIIIIlIll[49]], new Object[] { Integer.valueOf((int)lllIlIIlIlIII) });
    }
    if (llIlIlIIIlI(llIlIlIIIIl(lllIlIIlIlIII, 0.0F))) {
      return I18n.format(llIlIIllI[lIIIIIlIll[53]], new Object[lIIIIIlIll[0]]);
    }
    if (llIlIIllllI((int)lllIlIIlIlIII, hellbiomeID))
    {
      BiomeGenBase lllIlIIlIIlll = BiomeGenBase.getBiomeGenArray()[((int)lllIlIIlIlIII + lIIIIIlIll[2])];
      if (llIlIIlllII(lllIlIIlIIlll))
      {
        "".length();
        if (((0x73 ^ 0x2A) & (0xCA ^ 0x93 ^ 0xFFFFFFFF)) == 0) {
          break label475;
        }
        return null;
      }
      label475:
      return llIlIIllI[lIIIIIlIll[47]];
    }
    BiomeGenBase lllIlIIlIIllI = BiomeGenBase.getBiomeGenArray()[((int)lllIlIIlIlIII)];
    if (llIlIIlllII(lllIlIIlIIllI))
    {
      "".length();
      if ((0x31 ^ 0x35) >= (0x45 ^ 0x41)) {
        break label525;
      }
      return null;
    }
    label525:
    return llIlIIllI[lIIIIIlIll[51]];
  }
  
  private static String lIlIlllIIlI(String lllIIIlIlllII, String lllIIIlIlllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllIIIllIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllIIIlIlllIl.getBytes(StandardCharsets.UTF_8)), lIIIIIlIll[20]), "DES");
      Cipher lllIIIllIIIII = Cipher.getInstance("DES");
      lllIIIllIIIII.init(lIIIIIlIll[2], lllIIIllIIIIl);
      return new String(lllIIIllIIIII.doFinal(Base64.getDecoder().decode(lllIIIlIlllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllIIIlIlllll)
    {
      lllIIIlIlllll.printStackTrace();
    }
    return null;
  }
  
  public void drawScreen(int lllIIlIIlIIlI, int lllIIlIIlIIIl, float lllIIlIIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllIIlIIlIIll.drawDefaultBackground();
    field_175349_r.drawScreen(lllIIlIIlIIlI, lllIIlIIlIIIl, lllIIlIIllIIl);
    lllIIlIIlIIll.drawCenteredString(fontRendererObj, field_175341_a, width / lIIIIIlIll[2], lIIIIIlIll[2], lIIIIIlIll['õ']);
    lllIIlIIlIIll.drawCenteredString(fontRendererObj, field_175333_f, width / lIIIIIlIll[2], lIIIIIlIll[32], lIIIIIlIll['õ']);
    lllIIlIIlIIll.drawCenteredString(fontRendererObj, field_175335_g, width / lIIIIIlIll[2], lIIIIIlIll[50], lIIIIIlIll['õ']);
    lllIIlIIlIIll.drawScreen(lllIIlIIlIIlI, lllIIlIIlIIIl, lllIIlIIllIIl);
    if (llIlIIlllIl(field_175339_B))
    {
      drawRect(lIIIIIlIll[0], lIIIIIlIll[0], width, height, Integer.MIN_VALUE);
      lllIIlIIlIIll.drawHorizontalLine(width / lIIIIIlIll[2] - lIIIIIlIll['µ'], width / lIIIIIlIll[2] + lIIIIIlIll[14], lIIIIIlIll['Ã'], lIIIIIlIll['ö']);
      lllIIlIIlIIll.drawHorizontalLine(width / lIIIIIlIll[2] - lIIIIIlIll['µ'], width / lIIIIIlIll[2] + lIIIIIlIll[14], lIIIIIlIll[115], lIIIIIlIll['÷']);
      lllIIlIIlIIll.drawVerticalLine(width / lIIIIIlIll[2] - lIIIIIlIll['µ'], lIIIIIlIll['Ã'], lIIIIIlIll[115], lIIIIIlIll['ö']);
      lllIIlIIlIIll.drawVerticalLine(width / lIIIIIlIll[2] + lIIIIIlIll[14], lIIIIIlIll['Ã'], lIIIIIlIll[115], lIIIIIlIll['÷']);
      float lllIIlIIllIII = 85.0F;
      float lllIIlIIlIlll = 180.0F;
      GlStateManager.disableLighting();
      GlStateManager.disableFog();
      Tessellator lllIIlIIlIllI = Tessellator.getInstance();
      WorldRenderer lllIIlIIlIlIl = lllIIlIIlIllI.getWorldRenderer();
      mc.getTextureManager().bindTexture(optionsBackground);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      float lllIIlIIlIlII = 32.0F;
      lllIIlIIlIlIl.begin(lIIIIIlIll[18], DefaultVertexFormats.POSITION_TEX_COLOR);
      lllIIlIIlIlIl.pos(width / lIIIIIlIll[2] - lIIIIIlIll[14], 185.0D, 0.0D).tex(0.0D, 2.65625D).color(lIIIIIlIll[''], lIIIIIlIll[''], lIIIIIlIll[''], lIIIIIlIll['']).endVertex();
      lllIIlIIlIlIl.pos(width / lIIIIIlIll[2] + lIIIIIlIll[14], 185.0D, 0.0D).tex(5.625D, 2.65625D).color(lIIIIIlIll[''], lIIIIIlIll[''], lIIIIIlIll[''], lIIIIIlIll['']).endVertex();
      lllIIlIIlIlIl.pos(width / lIIIIIlIll[2] + lIIIIIlIll[14], 100.0D, 0.0D).tex(5.625D, 0.0D).color(lIIIIIlIll[''], lIIIIIlIll[''], lIIIIIlIll[''], lIIIIIlIll['']).endVertex();
      lllIIlIIlIlIl.pos(width / lIIIIIlIll[2] - lIIIIIlIll[14], 100.0D, 0.0D).tex(0.0D, 0.0D).color(lIIIIIlIll[''], lIIIIIlIll[''], lIIIIIlIll[''], lIIIIIlIll['']).endVertex();
      lllIIlIIlIllI.draw();
      lllIIlIIlIIll.drawCenteredString(fontRendererObj, I18n.format(llIlIIllI[lIIIIIlIll[26]], new Object[lIIIIIlIll[0]]), width / lIIIIIlIll[2], lIIIIIlIll['³'], lIIIIIlIll['õ']);
      lllIIlIIlIIll.drawCenteredString(fontRendererObj, I18n.format(llIlIIllI[lIIIIIlIll[57]], new Object[lIIIIIlIll[0]]), width / lIIIIIlIll[2], lIIIIIlIll['ß'], lIIIIIlIll['õ']);
      lllIIlIIlIIll.drawCenteredString(fontRendererObj, I18n.format(llIlIIllI[lIIIIIlIll[59]], new Object[lIIIIIlIll[0]]), width / lIIIIIlIll[2], lIIIIIlIll['Ì'], lIIIIIlIll['õ']);
      field_175352_x.drawButton(mc, lllIIlIIlIIlI, lllIIlIIlIIIl);
      field_175351_y.drawButton(mc, lllIIlIIlIIlI, lllIIlIIlIIIl);
    }
  }
  
  private void func_175325_f()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    GuiPageButtonList.GuiListEntry[] lllIlIllIIIlI = { new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[26], I18n.format(llIlIIllI[lIIIIIlIll[32]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], lllIlIlIlllIl, 1.0F, 255.0F, field_175336_F.seaLevel), new GuiPageButtonList.GuiButtonEntry(lIIIIIlIll[33], I18n.format(llIlIIllI[lIIIIIlIll[34]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], field_175336_F.useCaves), new GuiPageButtonList.GuiButtonEntry(lIIIIIlIll[35], I18n.format(llIlIIllI[lIIIIIlIll[36]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], field_175336_F.useStrongholds), new GuiPageButtonList.GuiButtonEntry(lIIIIIlIll[37], I18n.format(llIlIIllI[lIIIIIlIll[38]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], field_175336_F.useVillages), new GuiPageButtonList.GuiButtonEntry(lIIIIIlIll[39], I18n.format(llIlIIllI[lIIIIIlIll[40]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], field_175336_F.useMineShafts), new GuiPageButtonList.GuiButtonEntry(lIIIIIlIll[41], I18n.format(llIlIIllI[lIIIIIlIll[42]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], field_175336_F.useTemples), new GuiPageButtonList.GuiButtonEntry(lIIIIIlIll[43], I18n.format(llIlIIllI[lIIIIIlIll[31]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], field_175336_F.useMonuments), new GuiPageButtonList.GuiButtonEntry(lIIIIIlIll[44], I18n.format(llIlIIllI[lIIIIIlIll[45]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], field_175336_F.useRavines), new GuiPageButtonList.GuiButtonEntry(lIIIIIlIll[46], I18n.format(llIlIIllI[lIIIIIlIll[6]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], field_175336_F.useDungeons), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[47], I18n.format(llIlIIllI[lIIIIIlIll[48]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], lllIlIlIlllIl, 1.0F, 100.0F, field_175336_F.dungeonChance), new GuiPageButtonList.GuiButtonEntry(lIIIIIlIll[49], I18n.format(llIlIIllI[lIIIIIlIll[50]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], field_175336_F.useWaterLakes), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[51], I18n.format(llIlIIllI[lIIIIIlIll[52]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], lllIlIlIlllIl, 1.0F, 100.0F, field_175336_F.waterLakeChance), new GuiPageButtonList.GuiButtonEntry(lIIIIIlIll[53], I18n.format(llIlIIllI[lIIIIIlIll[54]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], field_175336_F.useLavaLakes), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[55], I18n.format(llIlIIllI[lIIIIIlIll[56]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], lllIlIlIlllIl, 10.0F, 100.0F, field_175336_F.lavaLakeChance), new GuiPageButtonList.GuiButtonEntry(lIIIIIlIll[57], I18n.format(llIlIIllI[lIIIIIlIll[58]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], field_175336_F.useLavaOceans), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[59], I18n.format(llIlIIllI[lIIIIIlIll[13]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], lllIlIlIlllIl, -1.0F, 37.0F, field_175336_F.fixedBiome), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[60], I18n.format(llIlIIllI[lIIIIIlIll[61]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], lllIlIlIlllIl, 1.0F, 8.0F, field_175336_F.biomeSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[62], I18n.format(llIlIIllI[lIIIIIlIll[63]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[1], lllIlIlIlllIl, 1.0F, 5.0F, field_175336_F.riverSize) };
    GuiPageButtonList.GuiListEntry[] lllIlIllIIIIl = { new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll[65], I18n.format(llIlIIllI[lIIIIIlIll[66]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0]), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[67], I18n.format(llIlIIllI[lIIIIIlIll[68]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 50.0F, field_175336_F.dirtSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[69], I18n.format(llIlIIllI[lIIIIIlIll[70]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 40.0F, field_175336_F.dirtCount), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[71], I18n.format(llIlIIllI[lIIIIIlIll[72]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.dirtMinHeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[73], I18n.format(llIlIIllI[lIIIIIlIll[74]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.dirtMaxHeight), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll[75], I18n.format(llIlIIllI[lIIIIIlIll[76]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0]), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[77], I18n.format(llIlIIllI[lIIIIIlIll[78]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 50.0F, field_175336_F.gravelSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[79], I18n.format(llIlIIllI[lIIIIIlIll[80]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 40.0F, field_175336_F.gravelCount), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[81], I18n.format(llIlIIllI[lIIIIIlIll[82]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.gravelMinHeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[83], I18n.format(llIlIIllI[lIIIIIlIll[84]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.gravelMaxHeight), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll[85], I18n.format(llIlIIllI[lIIIIIlIll[86]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0]), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[87], I18n.format(llIlIIllI[lIIIIIlIll[88]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 50.0F, field_175336_F.graniteSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[89], I18n.format(llIlIIllI[lIIIIIlIll[90]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 40.0F, field_175336_F.graniteCount), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[91], I18n.format(llIlIIllI[lIIIIIlIll[92]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.graniteMinHeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[93], I18n.format(llIlIIllI[lIIIIIlIll[94]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.graniteMaxHeight), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll[95], I18n.format(llIlIIllI[lIIIIIlIll[96]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0]), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[97], I18n.format(llIlIIllI[lIIIIIlIll[98]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 50.0F, field_175336_F.dioriteSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[99], I18n.format(llIlIIllI[lIIIIIlIll[100]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 40.0F, field_175336_F.dioriteCount), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[101], I18n.format(llIlIIllI[lIIIIIlIll[102]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.dioriteMinHeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[103], I18n.format(llIlIIllI[lIIIIIlIll[104]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.dioriteMaxHeight), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll[105], I18n.format(llIlIIllI[lIIIIIlIll[27]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0]), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[106], I18n.format(llIlIIllI[lIIIIIlIll[107]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 50.0F, field_175336_F.andesiteSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[108], I18n.format(llIlIIllI[lIIIIIlIll[109]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 40.0F, field_175336_F.andesiteCount), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[110], I18n.format(llIlIIllI[lIIIIIlIll[111]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.andesiteMinHeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[112], I18n.format(llIlIIllI[lIIIIIlIll[113]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.andesiteMaxHeight), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll[114], I18n.format(llIlIIllI[lIIIIIlIll[25]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0]), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[115], I18n.format(llIlIIllI[lIIIIIlIll[116]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 50.0F, field_175336_F.coalSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[117], I18n.format(llIlIIllI[lIIIIIlIll[118]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 40.0F, field_175336_F.coalCount), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[12], I18n.format(llIlIIllI[lIIIIIlIll[119]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.coalMinHeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[120], I18n.format(llIlIIllI[lIIIIIlIll[121]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.coalMaxHeight), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll[122], I18n.format(llIlIIllI[lIIIIIlIll[123]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0]), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[124], I18n.format(llIlIIllI[lIIIIIlIll[125]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 50.0F, field_175336_F.ironSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[126], I18n.format(llIlIIllI[lIIIIIlIll[127]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 40.0F, field_175336_F.ironCount), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.ironMinHeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.ironMaxHeight), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0]), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll[64]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 50.0F, field_175336_F.goldSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 40.0F, field_175336_F.goldCount), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.goldMinHeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.goldMaxHeight), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0]), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 50.0F, field_175336_F.redstoneSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 40.0F, field_175336_F.redstoneCount), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.redstoneMinHeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.redstoneMaxHeight), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0]), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 50.0F, field_175336_F.diamondSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 40.0F, field_175336_F.diamondCount), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll['']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.diamondMinHeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[''], I18n.format(llIlIIllI[lIIIIIlIll[' ']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.diamondMaxHeight), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['¡'], I18n.format(llIlIIllI[lIIIIIlIll[8]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0]), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['¢'], I18n.format(llIlIIllI[lIIIIIlIll['£']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 50.0F, field_175336_F.lapisSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['¤'], I18n.format(llIlIIllI[lIIIIIlIll['¥']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 40.0F, field_175336_F.lapisCount), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['¦'], I18n.format(llIlIIllI[lIIIIIlIll['§']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.lapisCenterHeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['¨'], I18n.format(llIlIIllI[lIIIIIlIll['©']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 255.0F, field_175336_F.lapisSpread) };
    GuiPageButtonList.GuiListEntry[] lllIlIllIIIII = { new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll[10], I18n.format(llIlIIllI[lIIIIIlIll['ª']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 5000.0F, field_175336_F.mainNoiseScaleX), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['«'], I18n.format(llIlIIllI[lIIIIIlIll['¬']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 5000.0F, field_175336_F.mainNoiseScaleY), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['­'], I18n.format(llIlIIllI[lIIIIIlIll['®']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 5000.0F, field_175336_F.mainNoiseScaleZ), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['¯'], I18n.format(llIlIIllI[lIIIIIlIll['°']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 2000.0F, field_175336_F.depthNoiseScaleX), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['±'], I18n.format(llIlIIllI[lIIIIIlIll['²']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 2000.0F, field_175336_F.depthNoiseScaleZ), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['³'], I18n.format(llIlIIllI[lIIIIIlIll[14]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.01F, 20.0F, field_175336_F.depthNoiseScaleExponent), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['´'], I18n.format(llIlIIllI[lIIIIIlIll['µ']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 25.0F, field_175336_F.baseSize), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['¶'], I18n.format(llIlIIllI[lIIIIIlIll[17]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 6000.0F, field_175336_F.coordinateScale), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['·'], I18n.format(llIlIIllI[lIIIIIlIll['¸']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 6000.0F, field_175336_F.heightScale), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['¹'], I18n.format(llIlIIllI[lIIIIIlIll['º']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.01F, 50.0F, field_175336_F.stretchY), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['»'], I18n.format(llIlIIllI[lIIIIIlIll['¼']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 5000.0F, field_175336_F.upperLimitScale), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['½'], I18n.format(llIlIIllI[lIIIIIlIll['¾']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 5000.0F, field_175336_F.lowerLimitScale), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['¿'], I18n.format(llIlIIllI[lIIIIIlIll['À']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 20.0F, field_175336_F.biomeDepthWeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['Á'], I18n.format(llIlIIllI[lIIIIIlIll[22]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 20.0F, field_175336_F.biomeDepthOffset), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['Â'], I18n.format(llIlIIllI[lIIIIIlIll['Ã']], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 1.0F, 20.0F, field_175336_F.biomeScaleWeight), new GuiPageButtonList.GuiSlideEntry(lIIIIIlIll['Ä'], I18n.format(llIlIIllI[lIIIIIlIll[10]], new Object[lIIIIIlIll[0]]), lIIIIIlIll[0], lllIlIlIlllIl, 0.0F, 20.0F, field_175336_F.biomeScaleOffset) };
    GuiPageButtonList.GuiListEntry[] lllIlIlIlllll = { new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['Å'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['«']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['­']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['Æ'], String.format(llIlIIllI[lIIIIIlIll['¯']], new Object[] { Float.valueOf(field_175336_F.mainNoiseScaleX) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['Ç'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['±']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['³']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['È'], String.format(llIlIIllI[lIIIIIlIll['´']], new Object[] { Float.valueOf(field_175336_F.mainNoiseScaleY) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['É'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['¶']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['·']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['Ê'], String.format(llIlIIllI[lIIIIIlIll['¹']], new Object[] { Float.valueOf(field_175336_F.mainNoiseScaleZ) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['Ë'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['»']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['½']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['Ì'], String.format(llIlIIllI[lIIIIIlIll['¿']], new Object[] { Float.valueOf(field_175336_F.depthNoiseScaleX) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['Í'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['Á']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['Â']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['Î'], String.format(llIlIIllI[lIIIIIlIll['Ä']], new Object[] { Float.valueOf(field_175336_F.depthNoiseScaleZ) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['Ï'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['Ð']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['Ñ']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['Ò'], String.format(llIlIIllI[lIIIIIlIll['Ó']], new Object[] { Float.valueOf(field_175336_F.depthNoiseScaleExponent) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['Ô'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['Õ']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['Ö']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['×'], String.format(llIlIIllI[lIIIIIlIll['Ø']], new Object[] { Float.valueOf(field_175336_F.baseSize) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['Ù'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['Ú']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['Û']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['Ü'], String.format(llIlIIllI[lIIIIIlIll['Ý']], new Object[] { Float.valueOf(field_175336_F.coordinateScale) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['Þ'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['ß']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['à']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['á'], String.format(llIlIIllI[lIIIIIlIll['â']], new Object[] { Float.valueOf(field_175336_F.heightScale) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['ã'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['ä']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['å']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['æ'], String.format(llIlIIllI[lIIIIIlIll['ç']], new Object[] { Float.valueOf(field_175336_F.stretchY) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['è'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['é']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['Æ']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['ê'], String.format(llIlIIllI[lIIIIIlIll['È']], new Object[] { Float.valueOf(field_175336_F.upperLimitScale) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['ë'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['Ê']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['Ì']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['ì'], String.format(llIlIIllI[lIIIIIlIll['Î']], new Object[] { Float.valueOf(field_175336_F.lowerLimitScale) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['í'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['Ò']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['×']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['î'], String.format(llIlIIllI[lIIIIIlIll['Ü']], new Object[] { Float.valueOf(field_175336_F.biomeDepthWeight) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['ï'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['á']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['æ']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['ð'], String.format(llIlIIllI[lIIIIIlIll['ê']], new Object[] { Float.valueOf(field_175336_F.biomeDepthOffset) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['ñ'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['ì']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['î']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['ò'], String.format(llIlIIllI[lIIIIIlIll['ð']], new Object[] { Float.valueOf(field_175336_F.biomeScaleWeight) }), lIIIIIlIll[0], field_175332_D), new GuiPageButtonList.GuiLabelEntry(lIIIIIlIll['ó'], String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIIllI[lIIIIIlIll['ò']], new Object[lIIIIIlIll[0]]))).append(llIlIIllI[lIIIIIlIll['ô']])), lIIIIIlIll[0]), new GuiPageButtonList.EditBoxEntry(lIIIIIlIll['ô'], String.format(llIlIIllI[lIIIIIlIll[33]], new Object[] { Float.valueOf(field_175336_F.biomeScaleOffset) }), lIIIIIlIll[0], field_175332_D) };
    field_175349_r = new GuiPageButtonList(mc, width, height, lIIIIIlIll[70], height - lIIIIIlIll[70], lIIIIIlIll[56], lllIlIlIlllIl, new GuiPageButtonList.GuiListEntry[][] { lllIlIllIIIlI, lllIlIllIIIIl, lllIlIllIIIII, lllIlIlIlllll });
    int lllIlIlIllllI = lIIIIIlIll[0];
    "".length();
    if (-"  ".length() > 0) {
      return;
    }
    while (!llIlIIllllI(lllIlIlIllllI, lIIIIIlIll[3]))
    {
      field_175342_h[lllIlIlIllllI] = I18n.format(String.valueOf(new StringBuilder(llIlIIllI[lIIIIIlIll[46]]).append(lllIlIlIllllI)), new Object[lIIIIIlIll[0]]);
      lllIlIlIllllI++;
    }
    lllIlIlIlllIl.func_175328_i();
  }
  
  protected void mouseReleased(int lllIIlIlIllII, int lllIIlIlIlIll, int lllIIlIlIIllI)
  {
    ;
    ;
    ;
    ;
    lllIIlIlIllIl.mouseReleased(lllIIlIlIllII, lllIIlIlIlIll, lllIIlIlIIllI);
    if (llIlIIlllIl(field_175340_C))
    {
      field_175340_C = lIIIIIlIll[0];
      "".length();
      if ((0x22 ^ 0x53 ^ 0x54 ^ 0x21) != "   ".length()) {}
    }
    else if (llIlIlIIIII(field_175339_B))
    {
      "".length();
    }
  }
  
  private void func_175326_g()
  {
    ;
    field_175336_F.func_177863_a();
    lllIIllllIIIl.func_175325_f();
    lllIIllllIIIl.func_181031_a(lIIIIIlIll[0]);
  }
  
  private static boolean llIlIIllllI(int ???, int arg1)
  {
    int i;
    double lllIIIlIlIlIl;
    return ??? >= i;
  }
  
  private static int llIlIlIIIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void onTick(int lllIlIIIlIIII, float lllIlIIIlIIll)
  {
    ;
    ;
    ;
    ;
    switch (lllIlIIIlIIII)
    {
    case 100: 
      field_175336_F.mainNoiseScaleX = lllIlIIIlIIll;
      "".length();
      if ("   ".length() <= ((0xB ^ 0x2 ^ 0x75 ^ 0x65) & (0x8D ^ 0xB2 ^ 0x5E ^ 0x78 ^ -" ".length()))) {
        return;
      }
      break;
    case 101: 
      field_175336_F.mainNoiseScaleY = lllIlIIIlIIll;
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 102: 
      field_175336_F.mainNoiseScaleZ = lllIlIIIlIIll;
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 103: 
      field_175336_F.depthNoiseScaleX = lllIlIIIlIIll;
      "".length();
      if ("   ".length() != "   ".length()) {
        return;
      }
      break;
    case 104: 
      field_175336_F.depthNoiseScaleZ = lllIlIIIlIIll;
      "".length();
      if (((0x65 ^ 0x77) & (0x74 ^ 0x66 ^ 0xFFFFFFFF)) < 0) {
        return;
      }
      break;
    case 105: 
      field_175336_F.depthNoiseScaleExponent = lllIlIIIlIIll;
      "".length();
      if (-" ".length() == (0xAD ^ 0xA9)) {
        return;
      }
      break;
    case 106: 
      field_175336_F.baseSize = lllIlIIIlIIll;
      "".length();
      if ((0xA4 ^ 0xA0) <= 0) {
        return;
      }
      break;
    case 107: 
      field_175336_F.coordinateScale = lllIlIIIlIIll;
      "".length();
      if (-" ".length() > "   ".length()) {
        return;
      }
      break;
    case 108: 
      field_175336_F.heightScale = lllIlIIIlIIll;
      "".length();
      if ((0x3F ^ 0x67 ^ 0x3 ^ 0x5F) != (0x70 ^ 0x14 ^ 0x64 ^ 0x4)) {
        return;
      }
      break;
    case 109: 
      field_175336_F.stretchY = lllIlIIIlIIll;
      "".length();
      if ("  ".length() <= 0) {
        return;
      }
      break;
    case 110: 
      field_175336_F.upperLimitScale = lllIlIIIlIIll;
      "".length();
      if ("   ".length() < " ".length()) {
        return;
      }
      break;
    case 111: 
      field_175336_F.lowerLimitScale = lllIlIIIlIIll;
      "".length();
      if (((0x71 ^ 0x50) & (0xBB ^ 0x9A ^ 0xFFFFFFFF)) >= (0x9A ^ 0x9E)) {
        return;
      }
      break;
    case 112: 
      field_175336_F.biomeDepthWeight = lllIlIIIlIIll;
      "".length();
      if (-(111 + 52 - 88 + 52 ^ 0x70 ^ 0xB) > 0) {
        return;
      }
      break;
    case 113: 
      field_175336_F.biomeDepthOffset = lllIlIIIlIIll;
      "".length();
      if (-"  ".length() > 0) {
        return;
      }
      break;
    case 114: 
      field_175336_F.biomeScaleWeight = lllIlIIIlIIll;
      "".length();
      if ("  ".length() != "  ".length()) {
        return;
      }
      break;
    case 115: 
      field_175336_F.biomeScaleOffset = lllIlIIIlIIll;
    case 116: 
    case 117: 
    case 118: 
    case 119: 
    case 120: 
    case 121: 
    case 122: 
    case 123: 
    case 124: 
    case 125: 
    case 126: 
    case 127: 
    case 128: 
    case 129: 
    case 130: 
    case 131: 
    case 132: 
    case 133: 
    case 134: 
    case 135: 
    case 136: 
    case 137: 
    case 138: 
    case 139: 
    case 140: 
    case 141: 
    case 142: 
    case 143: 
    case 144: 
    case 145: 
    case 146: 
    case 147: 
    case 148: 
    case 149: 
    case 150: 
    case 151: 
    case 152: 
    case 153: 
    case 154: 
    case 155: 
    case 156: 
    case 161: 
    case 188: 
    default: 
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 157: 
      field_175336_F.dungeonChance = ((int)lllIlIIIlIIll);
      "".length();
      if ("   ".length() > "   ".length()) {
        return;
      }
      break;
    case 158: 
      field_175336_F.waterLakeChance = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() > 0) {
        return;
      }
      break;
    case 159: 
      field_175336_F.lavaLakeChance = ((int)lllIlIIIlIIll);
      "".length();
      if ("  ".length() != "  ".length()) {
        return;
      }
      break;
    case 160: 
      field_175336_F.seaLevel = ((int)lllIlIIIlIIll);
      "".length();
      if (((0x62 ^ 0x2D) & (0x2 ^ 0x4D ^ 0xFFFFFFFF)) != 0) {
        return;
      }
      break;
    case 162: 
      field_175336_F.fixedBiome = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() > 0) {
        return;
      }
      break;
    case 163: 
      field_175336_F.biomeSize = ((int)lllIlIIIlIIll);
      "".length();
      if (" ".length() == 0) {
        return;
      }
      break;
    case 164: 
      field_175336_F.riverSize = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() > ((0x75 ^ 0x6B) & (0x1E ^ 0x0 ^ 0xFFFFFFFF))) {
        return;
      }
      break;
    case 165: 
      field_175336_F.dirtSize = ((int)lllIlIIIlIIll);
      "".length();
      if (((115 + '' - 231 + 118 ^ '§' + 20 - 98 + 101) & (83 + 31 - 52 + 102 ^ 81 + 50 - -25 + 0 ^ -" ".length())) != 0) {
        return;
      }
      break;
    case 166: 
      field_175336_F.dirtCount = ((int)lllIlIIIlIIll);
      "".length();
      if ("   ".length() < "  ".length()) {
        return;
      }
      break;
    case 167: 
      field_175336_F.dirtMinHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() >= 0) {
        return;
      }
      break;
    case 168: 
      field_175336_F.dirtMaxHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (" ".length() < 0) {
        return;
      }
      break;
    case 169: 
      field_175336_F.gravelSize = ((int)lllIlIIIlIIll);
      "".length();
      if ("  ".length() < "  ".length()) {
        return;
      }
      break;
    case 170: 
      field_175336_F.gravelCount = ((int)lllIlIIIlIIll);
      "".length();
      if (((3 + 105 - 105 + 125 ^ 16 + '¸' - 142 + 141) & (0x5B ^ 0x3D ^ 0xE1 ^ 0xC0 ^ -" ".length())) < 0) {
        return;
      }
      break;
    case 171: 
      field_175336_F.gravelMinHeight = ((int)lllIlIIIlIIll);
      "".length();
      if ("  ".length() > "  ".length()) {
        return;
      }
      break;
    case 172: 
      field_175336_F.gravelMaxHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 173: 
      field_175336_F.graniteSize = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() > "  ".length()) {
        return;
      }
      break;
    case 174: 
      field_175336_F.graniteCount = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() > ((44 + 90 - 4 + 14 ^ 90 + 47 - 78 + 73) & (0xA2 ^ 0x9A ^ 0xAE ^ 0x82 ^ -" ".length()))) {
        return;
      }
      break;
    case 175: 
      field_175336_F.graniteMinHeight = ((int)lllIlIIIlIIll);
      "".length();
      if ((0x22 ^ 0x44 ^ 0x57 ^ 0x34) <= 0) {
        return;
      }
      break;
    case 176: 
      field_175336_F.graniteMaxHeight = ((int)lllIlIIIlIIll);
      "".length();
      if ("   ".length() < "   ".length()) {
        return;
      }
      break;
    case 177: 
      field_175336_F.dioriteSize = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() >= (15 + 55 - 45 + 123 ^ 22 + '' - 22 + 14)) {
        return;
      }
      break;
    case 178: 
      field_175336_F.dioriteCount = ((int)lllIlIIIlIIll);
      "".length();
      if (-"   ".length() >= 0) {
        return;
      }
      break;
    case 179: 
      field_175336_F.dioriteMinHeight = ((int)lllIlIIIlIIll);
      "".length();
      if ("   ".length() <= 0) {
        return;
      }
      break;
    case 180: 
      field_175336_F.dioriteMaxHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (((0x98 ^ 0xBA) & (0xB6 ^ 0x94 ^ 0xFFFFFFFF)) != 0) {
        return;
      }
      break;
    case 181: 
      field_175336_F.andesiteSize = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() == "   ".length()) {
        return;
      }
      break;
    case 182: 
      field_175336_F.andesiteCount = ((int)lllIlIIIlIIll);
      "".length();
      if ("  ".length() < 0) {
        return;
      }
      break;
    case 183: 
      field_175336_F.andesiteMinHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 184: 
      field_175336_F.andesiteMaxHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (((0x2E ^ 0x53 ^ 0x2 ^ 0x5F) & ("  ".length() ^ 0x5F ^ 0x7D ^ -" ".length())) != 0) {
        return;
      }
      break;
    case 185: 
      field_175336_F.coalSize = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() >= 0) {
        return;
      }
      break;
    case 186: 
      field_175336_F.coalCount = ((int)lllIlIIIlIIll);
      "".length();
      if ("   ".length() <= 0) {
        return;
      }
      break;
    case 187: 
      field_175336_F.coalMinHeight = ((int)lllIlIIIlIIll);
      "".length();
      if ("   ".length() == 0) {
        return;
      }
      break;
    case 189: 
      field_175336_F.coalMaxHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() < -" ".length()) {
        return;
      }
      break;
    case 190: 
      field_175336_F.ironSize = ((int)lllIlIIIlIIll);
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 191: 
      field_175336_F.ironCount = ((int)lllIlIIIlIIll);
      "".length();
      if (((0xE3 ^ 0x80) & (0xF ^ 0x6C ^ 0xFFFFFFFF)) > "  ".length()) {
        return;
      }
      break;
    case 192: 
      field_175336_F.ironMinHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 193: 
      field_175336_F.ironMaxHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (((0x56 ^ 0x60) & (0x63 ^ 0x55 ^ 0xFFFFFFFF)) != ((0x5F ^ 0x1B) & (0xDF ^ 0x9B ^ 0xFFFFFFFF))) {
        return;
      }
      break;
    case 194: 
      field_175336_F.goldSize = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() >= "  ".length()) {
        return;
      }
      break;
    case 195: 
      field_175336_F.goldCount = ((int)lllIlIIIlIIll);
      "".length();
      if (-(0x35 ^ 0x31) > 0) {
        return;
      }
      break;
    case 196: 
      field_175336_F.goldMinHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 197: 
      field_175336_F.goldMaxHeight = ((int)lllIlIIIlIIll);
      "".length();
      if ("   ".length() < 0) {
        return;
      }
      break;
    case 198: 
      field_175336_F.redstoneSize = ((int)lllIlIIIlIIll);
      "".length();
      if (" ".length() <= (('À' + 30 - 211 + 229 ^ '' + 99 - 112 + 65) & (49 + 27 - -111 + 37 ^ 37 + '' - 101 + 85 ^ -" ".length()))) {
        return;
      }
      break;
    case 199: 
      field_175336_F.redstoneCount = ((int)lllIlIIIlIIll);
      "".length();
      if ((0x2D ^ 0x29) == 0) {
        return;
      }
      break;
    case 200: 
      field_175336_F.redstoneMinHeight = ((int)lllIlIIIlIIll);
      "".length();
      if ("  ".length() <= " ".length()) {
        return;
      }
      break;
    case 201: 
      field_175336_F.redstoneMaxHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (null != null) {
        return;
      }
      break;
    case 202: 
      field_175336_F.diamondSize = ((int)lllIlIIIlIIll);
      "".length();
      if (-" ".length() > 0) {
        return;
      }
      break;
    case 203: 
      field_175336_F.diamondCount = ((int)lllIlIIIlIIll);
      "".length();
      if (((0x2D ^ 0x3F) & (0x35 ^ 0x27 ^ 0xFFFFFFFF)) != 0) {
        return;
      }
      break;
    case 204: 
      field_175336_F.diamondMinHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (" ".length() == 0) {
        return;
      }
      break;
    case 205: 
      field_175336_F.diamondMaxHeight = ((int)lllIlIIIlIIll);
      "".length();
      if ((('à' + '­' - 217 + 46 ^ 125 + '' - 245 + 148) & (0x32 ^ 0x61 ^ 0x65 ^ 0x62 ^ -" ".length())) > 0) {
        return;
      }
      break;
    case 206: 
      field_175336_F.lapisSize = ((int)lllIlIIIlIIll);
      "".length();
      if (" ".length() < ((0xFA ^ 0xAB ^ 0x86 ^ 0xC5) & (99 + '' - 169 + 124 ^ 47 + 16 - -16 + 96 ^ -" ".length()))) {
        return;
      }
      break;
    case 207: 
      field_175336_F.lapisCount = ((int)lllIlIIIlIIll);
      "".length();
      if (-(0x45 ^ 0x41) >= 0) {
        return;
      }
      break;
    case 208: 
      field_175336_F.lapisCenterHeight = ((int)lllIlIIIlIIll);
      "".length();
      if (('º' + 118 - 129 + 16 ^ 23 + '' - 15 + 32) == 0) {
        return;
      }
      break;
    case 209: 
      field_175336_F.lapisSpread = ((int)lllIlIIIlIIll);
    }
    if ((llIlIIllllI(lllIlIIIlIlII, lIIIIIlIll[10])) && (llIlIlIIIll(lllIlIIIlIlII, lIIIIIlIll['Ð'])))
    {
      Gui lllIlIIIlIIlI = field_175349_r.func_178061_c(lllIlIIIlIlII - lIIIIIlIll[10] + lIIIIIlIll['Æ']);
      if (llIlIIlllII(lllIlIIIlIIlI)) {
        ((GuiTextField)lllIlIIIlIIlI).setText(lllIlIIIlIlIl.func_175330_b(lllIlIIIlIlII, lllIlIIIlIIll));
      }
    }
    if (llIlIlIIIII(field_175336_F.equals(field_175334_E))) {
      lllIlIIIlIlIl.func_181031_a(lIIIIIlIll[1]);
    }
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    int lllIlIlllIIIl = lIIIIIlIll[0];
    int lllIlIlllIIII = lIIIIIlIll[0];
    if (llIlIIlllII(field_175349_r))
    {
      lllIlIlllIIIl = field_175349_r.func_178059_e();
      lllIlIlllIIII = field_175349_r.getAmountScrolled();
    }
    field_175341_a = I18n.format(llIlIIllI[lIIIIIlIll[4]], new Object[lIIIIIlIll[0]]);
    buttonList.clear();
    field_175345_v = new GuiButton(lIIIIIlIll[5], lIIIIIlIll[6], lIIIIIlIll[7], lIIIIIlIll[8], lIIIIIlIll[6], I18n.format(llIlIIllI[lIIIIIlIll[3]], new Object[lIIIIIlIll[0]]));
    "".length();
    field_175344_w = new GuiButton(lIIIIIlIll[9], width - lIIIIIlIll[10], lIIIIIlIll[7], lIIIIIlIll[8], lIIIIIlIll[6], I18n.format(llIlIIllI[lIIIIIlIll[7]], new Object[lIIIIIlIll[0]]));
    "".length();
    field_175346_u = new GuiButton(lIIIIIlIll[11], width / lIIIIIlIll[2] - lIIIIIlIll[12], height - lIIIIIlIll[13], lIIIIIlIll[14], lIIIIIlIll[6], I18n.format(llIlIIllI[lIIIIIlIll[15]], new Object[lIIIIIlIll[0]]));
    "".length();
    field_175347_t = new GuiButton(lIIIIIlIll[16], width / lIIIIIlIll[2] - lIIIIIlIll[17], height - lIIIIIlIll[13], lIIIIIlIll[14], lIIIIIlIll[6], I18n.format(llIlIIllI[lIIIIIlIll[18]], new Object[lIIIIIlIll[0]]));
    "".length();
    field_175350_z = new GuiButton(lIIIIIlIll[19], width / lIIIIIlIll[2] + lIIIIIlIll[4], height - lIIIIIlIll[13], lIIIIIlIll[14], lIIIIIlIll[6], I18n.format(llIlIIllI[lIIIIIlIll[20]], new Object[lIIIIIlIll[0]]));
    "".length();
    field_175348_s = new GuiButton(lIIIIIlIll[21], width / lIIIIIlIll[2] + lIIIIIlIll[22], height - lIIIIIlIll[13], lIIIIIlIll[14], lIIIIIlIll[6], I18n.format(llIlIIllI[lIIIIIlIll[23]], new Object[lIIIIIlIll[0]]));
    "".length();
    field_175346_u.enabled = field_175338_A;
    field_175352_x = new GuiButton(lIIIIIlIll[24], width / lIIIIIlIll[2] - lIIIIIlIll[25], lIIIIIlIll[26], lIIIIIlIll[27], lIIIIIlIll[6], I18n.format(llIlIIllI[lIIIIIlIll[28]], new Object[lIIIIIlIll[0]]));
    field_175352_x.visible = lIIIIIlIll[0];
    "".length();
    field_175351_y = new GuiButton(lIIIIIlIll[29], width / lIIIIIlIll[2] + lIIIIIlIll[7], lIIIIIlIll[26], lIIIIIlIll[27], lIIIIIlIll[6], I18n.format(llIlIIllI[lIIIIIlIll[30]], new Object[lIIIIIlIll[0]]));
    field_175351_y.visible = lIIIIIlIll[0];
    "".length();
    if (llIlIIlllIl(field_175339_B))
    {
      field_175352_x.visible = lIIIIIlIll[1];
      field_175351_y.visible = lIIIIIlIll[1];
    }
    lllIlIllIllll.func_175325_f();
    if (llIlIIlllIl(lllIlIlllIIIl))
    {
      field_175349_r.func_181156_c(lllIlIlllIIIl);
      field_175349_r.scrollBy(lllIlIlllIIII);
      lllIlIllIllll.func_175328_i();
    }
  }
  
  private void func_175331_h()
    throws IOException
  {
    ;
    switch (field_175339_B)
    {
    case 300: 
      lllIIlllIlIIl.actionPerformed((GuiListButton)field_175349_r.func_178061_c(lIIIIIlIll[21]));
      "".length();
      if (('' + 26 - 59 + 59 ^ '' + 43 - 60 + 27) == 0) {
        return;
      }
      break;
    case 304: 
      lllIIlllIlIIl.func_175326_g();
    }
    field_175339_B = lIIIIIlIll[0];
    field_175340_C = lIIIIIlIll[1];
    lllIIlllIlIIl.func_175329_a(lIIIIIlIll[0]);
  }
  
  public GuiCustomizeWorldScreen(GuiScreen lllIlIlllIlll, String lllIlIlllIllI)
  {
    field_175343_i = ((GuiCreateWorld)lllIlIllllIlI);
    lllIlIllllIII.func_175324_a(lllIlIlllIllI);
  }
}

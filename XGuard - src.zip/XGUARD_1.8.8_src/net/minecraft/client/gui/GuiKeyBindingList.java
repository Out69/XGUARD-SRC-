package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.EnumChatFormatting;
import org.apache.commons.lang3.ArrayUtils;

public class GuiKeyBindingList
  extends GuiListExtended
{
  public GuiListExtended.IGuiListEntry getListEntry(int lllllllllllllllIllllIIIllIlllIll)
  {
    ;
    ;
    return listEntries[lllllllllllllllIllllIIIllIlllIll];
  }
  
  protected int getSize()
  {
    ;
    return listEntries.length;
  }
  
  private static boolean llIlIIIlIIIlI(int ???)
  {
    int lllllllllllllllIllllIIIllIIllIll;
    return ??? == 0;
  }
  
  protected int getScrollBarX()
  {
    ;
    return lllllllllllllllIllllIIIllIllIIlI.getScrollBarX() + lIIIIllIllll[4];
  }
  
  public int getListWidth()
  {
    ;
    return lllllllllllllllIllllIIIllIllIIII.getListWidth() + lIIIIllIllll[1];
  }
  
  private static void llIlIIIlIIIII()
  {
    lIIIIllIllll = new int[5];
    lIIIIllIllll[0] = (0xA ^ 0x35);
    lIIIIllIllll[1] = (0xAB ^ 0x8B);
    lIIIIllIllll[2] = (0x81 ^ 0x95);
    lIIIIllIllll[3] = ((72 + 1 - -62 + 58 ^ 98 + 28 - 28 + 39) & (84 + '' - 88 + 112 ^ '' + 109 - 89 + 18 ^ -" ".length()));
    lIIIIllIllll[4] = (0x0 ^ 0x1C ^ 0x81 ^ 0x92);
  }
  
  static {}
  
  private static boolean llIlIIIlIIIll(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIllllIIIllIIlllIl;
    return ??? > i;
  }
  
  private static boolean llIlIIIlIIlII(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllIllllIIIllIlIIIIl;
    return ??? >= i;
  }
  
  public GuiKeyBindingList(GuiControls lllllllllllllllIllllIIIlllIlllll, Minecraft lllllllllllllllIllllIIIlllIllllI)
  {
    lllllllllllllllIllllIIIllllIlIlI.<init>(lllllllllllllllIllllIIIlllIllllI, width, height, lIIIIllIllll[0], height - lIIIIllIllll[1], lIIIIllIllll[2]);
    field_148191_k = lllllllllllllllIllllIIIllllIlIIl;
    mc = lllllllllllllllIllllIIIlllIllllI;
    KeyBinding[] lllllllllllllllIllllIIIllllIIlll = (KeyBinding[])ArrayUtils.clone(gameSettings.keyBindings);
    listEntries = new GuiListExtended.IGuiListEntry[lllllllllllllllIllllIIIllllIIlll.length + KeyBinding.getKeybinds().size()];
    Arrays.sort(lllllllllllllllIllllIIIllllIIlll);
    int lllllllllllllllIllllIIIllllIIllI = lIIIIllIllll[3];
    String lllllllllllllllIllllIIIllllIIlIl = null;
    int lllllllllllllllIllllIIIlllIlIlIl = (lllllllllllllllIllllIIIlllIlIIll = lllllllllllllllIllllIIIllllIIlll).length;
    double lllllllllllllllIllllIIIlllIlIlll = lIIIIllIllll[3];
    "".length();
    if ("   ".length() <= "  ".length()) {
      throw null;
    }
    while (!llIlIIIlIIlII(lllllllllllllllIllllIIIlllIlIlll, lllllllllllllllIllllIIIlllIlIlIl))
    {
      KeyBinding lllllllllllllllIllllIIIllllIIlII = lllllllllllllllIllllIIIlllIlIIll[lllllllllllllllIllllIIIlllIlIlll];
      String lllllllllllllllIllllIIIllllIIIll = lllllllllllllllIllllIIIllllIIlII.getKeyCategory();
      if (llIlIIIlIIIlI(lllllllllllllllIllllIIIllllIIIll.equals(lllllllllllllllIllllIIIllllIIlIl)))
      {
        lllllllllllllllIllllIIIllllIIlIl = lllllllllllllllIllllIIIllllIIIll;
        listEntries[(lllllllllllllllIllllIIIllllIIllI++)] = new CategoryEntry(lllllllllllllllIllllIIIllllIIIll);
      }
      int lllllllllllllllIllllIIIllllIIIlI = Minecraft.fontRendererObj.getStringWidth(I18n.format(lllllllllllllllIllllIIIllllIIlII.getKeyDescription(), new Object[lIIIIllIllll[3]]));
      if (llIlIIIlIIIll(lllllllllllllllIllllIIIllllIIIlI, maxListLabelWidth)) {
        maxListLabelWidth = lllllllllllllllIllllIIIllllIIIlI;
      }
      listEntries[(lllllllllllllllIllllIIIllllIIllI++)] = new KeyEntry(lllllllllllllllIllllIIIllllIIlII, null);
      lllllllllllllllIllllIIIlllIlIlll++;
    }
  }
  
  public class CategoryEntry
    implements GuiListExtended.IGuiListEntry
  {
    public boolean mousePressed(int llllllllllllllllIIlllIlIIIlIIIIl, int llllllllllllllllIIlllIlIIIlIIIII, int llllllllllllllllIIlllIlIIIIlllll, int llllllllllllllllIIlllIlIIIIllllI, int llllllllllllllllIIlllIlIIIIlllIl, int llllllllllllllllIIlllIlIIIIlllII)
    {
      return lllIIIIlllI[0];
    }
    
    static {}
    
    public void setSelected(int llllllllllllllllIIlllIlIIIIlIIll, int llllllllllllllllIIlllIlIIIIlIIlI, int llllllllllllllllIIlllIlIIIIlIIIl) {}
    
    private static void lIlIllIIlIIlI()
    {
      lllIIIIlllI = new int[4];
      lllIIIIlllI[0] = ((0x3B ^ 0x7C) & (0x7 ^ 0x40 ^ 0xFFFFFFFF));
      lllIIIIlllI[1] = "  ".length();
      lllIIIIlllI[2] = " ".length();
      lllIIIIlllI[3] = (0xFFFFFFFF & 0xFFFFFF);
    }
    
    public void drawEntry(int llllllllllllllllIIlllIlIIIlIllIl, int llllllllllllllllIIlllIlIIIlIllII, int llllllllllllllllIIlllIlIIIlIlIll, int llllllllllllllllIIlllIlIIIlIlIlI, int llllllllllllllllIIlllIlIIIlIlIIl, int llllllllllllllllIIlllIlIIIlIlIII, int llllllllllllllllIIlllIlIIIlIIlll, boolean llllllllllllllllIIlllIlIIIlIIllI)
    {
      ;
      ;
      ;
      "".length();
    }
    
    public CategoryEntry(String llllllllllllllllIIlllIlIIIllIIlI)
    {
      labelText = I18n.format(llllllllllllllllIIlllIlIIIllIIlI, new Object[lllIIIIlllI[0]]);
      labelWidth = Minecraft.fontRendererObj.getStringWidth(labelText);
    }
    
    public void mouseReleased(int llllllllllllllllIIlllIlIIIIllIlI, int llllllllllllllllIIlllIlIIIIllIIl, int llllllllllllllllIIlllIlIIIIllIII, int llllllllllllllllIIlllIlIIIIlIlll, int llllllllllllllllIIlllIlIIIIlIllI, int llllllllllllllllIIlllIlIIIIlIlIl) {}
  }
  
  public class KeyEntry
    implements GuiListExtended.IGuiListEntry
  {
    private static String lIIIlIIlIIlIIl(String lllllllllllllllIIllIlllIIIllIIII, String lllllllllllllllIIllIlllIIIlIllll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIllIlllIIIllIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIlllIIIlIllll.getBytes(StandardCharsets.UTF_8)), lIllIIIllllI[11]), "DES");
        Cipher lllllllllllllllIIllIlllIIIllIlII = Cipher.getInstance("DES");
        lllllllllllllllIIllIlllIIIllIlII.init(lIllIIIllllI[6], lllllllllllllllIIllIlllIIIllIlIl);
        return new String(lllllllllllllllIIllIlllIIIllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIlllIIIllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIllIlllIIIllIIll)
      {
        lllllllllllllllIIllIlllIIIllIIll.printStackTrace();
      }
      return null;
    }
    
    private KeyEntry(KeyBinding lllllllllllllllIIllIlllIlIIIIlIl)
    {
      keybinding = lllllllllllllllIIllIlllIlIIIIlIl;
      keyDesc = I18n.format(lllllllllllllllIIllIlllIlIIIIlIl.getKeyDescription(), new Object[lIllIIIllllI[0]]);
      btnChangeKeyBinding = new GuiButton(lIllIIIllllI[0], lIllIIIllllI[0], lIllIIIllllI[0], lIllIIIllllI[1], lIllIIIllllI[2], I18n.format(lllllllllllllllIIllIlllIlIIIIlIl.getKeyDescription(), new Object[lIllIIIllllI[0]]));
      btnReset = new GuiButton(lIllIIIllllI[0], lIllIIIllllI[0], lIllIIIllllI[0], lIllIIIllllI[3], lIllIIIllllI[2], I18n.format(lIllIIIlIlll[lIllIIIllllI[0]], new Object[lIllIIIllllI[0]]));
    }
    
    public boolean mousePressed(int lllllllllllllllIIllIlllIIlIllIIl, int lllllllllllllllIIllIlllIIlIllIII, int lllllllllllllllIIllIlllIIlIlIlll, int lllllllllllllllIIllIlllIIlIlIllI, int lllllllllllllllIIllIlllIIlIlIlIl, int lllllllllllllllIIllIlllIIlIlIlII)
    {
      ;
      ;
      ;
      if (lIIIlIIlIlIIlI(btnChangeKeyBinding.mousePressed(mc, lllllllllllllllIIllIlllIIlIllIII, lllllllllllllllIIllIlllIIlIlIlll)))
      {
        field_148191_k.buttonId = keybinding;
        return lIllIIIllllI[4];
      }
      if (lIIIlIIlIlIIlI(btnReset.mousePressed(mc, lllllllllllllllIIllIlllIIlIllIII, lllllllllllllllIIllIlllIIlIlIlll)))
      {
        mc.gameSettings.setOptionKeyBinding(keybinding, keybinding.getKeyCodeDefault());
        KeyBinding.resetKeyBindingArrayAndHash();
        return lIllIIIllllI[4];
      }
      return lIllIIIllllI[0];
    }
    
    private static boolean lIIIlIIlIlIlII(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllIIllIlllIIIIlIIIl;
      return ??? == i;
    }
    
    private static boolean lIIIlIIlIlIlIl(int ???, int arg1)
    {
      int i;
      float lllllllllllllllIIllIlllIIIIIllIl;
      return ??? >= i;
    }
    
    private static boolean lIIIlIIlIlIIIl(int ???, int arg1)
    {
      int i;
      short lllllllllllllllIIllIllIllllllIll;
      return ??? != i;
    }
    
    private static boolean lIIIlIIlIlIIll(Object ???, Object arg1)
    {
      Object localObject;
      String lllllllllllllllIIllIlllIIIIIIlIl;
      return ??? != localObject;
    }
    
    public void mouseReleased(int lllllllllllllllIIllIlllIIlIIllII, int lllllllllllllllIIllIlllIIlIIIlIl, int lllllllllllllllIIllIlllIIlIIIlII, int lllllllllllllllIIllIlllIIlIIlIIl, int lllllllllllllllIIllIlllIIlIIlIII, int lllllllllllllllIIllIlllIIlIIIlll)
    {
      ;
      ;
      ;
      btnChangeKeyBinding.mouseReleased(lllllllllllllllIIllIlllIIlIIIlIl, lllllllllllllllIIllIlllIIlIIIlII);
      btnReset.mouseReleased(lllllllllllllllIIllIlllIIlIIIlIl, lllllllllllllllIIllIlllIIlIIIlII);
    }
    
    private static String lIIIlIIlIIlIII(String lllllllllllllllIIllIlllIIIIlllIl, String lllllllllllllllIIllIlllIIIIlllII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIIllIlllIIIIlllIl = new String(Base64.getDecoder().decode(lllllllllllllllIIllIlllIIIIlllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIIllIlllIIIlIIIII = new StringBuilder();
      char[] lllllllllllllllIIllIlllIIIIlllll = lllllllllllllllIIllIlllIIIIlllII.toCharArray();
      int lllllllllllllllIIllIlllIIIIllllI = lIllIIIllllI[0];
      boolean lllllllllllllllIIllIlllIIIIllIII = lllllllllllllllIIllIlllIIIIlllIl.toCharArray();
      long lllllllllllllllIIllIlllIIIIlIlll = lllllllllllllllIIllIlllIIIIllIII.length;
      String lllllllllllllllIIllIlllIIIIlIllI = lIllIIIllllI[0];
      while (lIIIlIIlIlIllI(lllllllllllllllIIllIlllIIIIlIllI, lllllllllllllllIIllIlllIIIIlIlll))
      {
        char lllllllllllllllIIllIlllIIIlIIIll = lllllllllllllllIIllIlllIIIIllIII[lllllllllllllllIIllIlllIIIIlIllI];
        "".length();
        "".length();
        if (" ".length() < 0) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIIllIlllIIIlIIIII);
    }
    
    private static boolean lIIIlIIlIlIllI(int ???, int arg1)
    {
      int i;
      int lllllllllllllllIIllIlllIIIIIlIIl;
      return ??? < i;
    }
    
    public void drawEntry(int lllllllllllllllIIllIlllIIlllIlII, int lllllllllllllllIIllIlllIIlllIIll, int lllllllllllllllIIllIlllIIlllIIlI, int lllllllllllllllIIllIlllIIlllIIIl, int lllllllllllllllIIllIlllIIlllIIII, int lllllllllllllllIIllIlllIIllIllll, int lllllllllllllllIIllIlllIIllIlllI, boolean lllllllllllllllIIllIlllIIllIllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      if (lIIIlIIlIlIIII(field_148191_k.buttonId, keybinding))
      {
        "".length();
        if (-" ".length() <= ((64 + 84 - 19 + 39 ^ 112 + 54 - 157 + 155) & (0x99 ^ 0xB2 ^ 0x3D ^ 0x1A ^ -" ".length()))) {
          break label94;
        }
      }
      label94:
      boolean lllllllllllllllIIllIlllIIllIllII = lIllIIIllllI[0];
      "".length();
      btnReset.xPosition = (lllllllllllllllIIllIlllIIlllIIll + lIllIIIllllI[8]);
      btnReset.yPosition = lllllllllllllllIIllIlllIIlllIIlI;
      if (lIIIlIIlIlIIIl(keybinding.getKeyCode(), keybinding.getKeyCodeDefault()))
      {
        "".length();
        if (-" ".length() <= "   ".length()) {
          break label238;
        }
      }
      label238:
      lIllIIIllllI4enabled = lIllIIIllllI[0];
      btnReset.drawButton(mc, lllllllllllllllIIllIlllIIllIllll, lllllllllllllllIIllIlllIIllIlllI);
      btnChangeKeyBinding.xPosition = (lllllllllllllllIIllIlllIIlllIIll + lIllIIIllllI[9]);
      btnChangeKeyBinding.yPosition = lllllllllllllllIIllIlllIIlllIIlI;
      btnChangeKeyBinding.displayString = GameSettings.getKeyDisplayString(keybinding.getKeyCode());
      boolean lllllllllllllllIIllIlllIIllIlIll = lIllIIIllllI[0];
      if (lIIIlIIlIlIIlI(keybinding.getKeyCode()))
      {
        lllllllllllllllIIllIlllIIlIlllll = (lllllllllllllllIIllIlllIIlIllllI = mc.gameSettings.keyBindings).length;
        lllllllllllllllIIllIlllIIllIIIII = lIllIIIllllI[0];
        "".length();
        if (" ".length() == (0x82 ^ 0x86)) {
          return;
        }
        while (!lIIIlIIlIlIlIl(lllllllllllllllIIllIlllIIllIIIII, lllllllllllllllIIllIlllIIlIlllll))
        {
          KeyBinding lllllllllllllllIIllIlllIIllIlIlI = lllllllllllllllIIllIlllIIlIllllI[lllllllllllllllIIllIlllIIllIIIII];
          if ((lIIIlIIlIlIIll(lllllllllllllllIIllIlllIIllIlIlI, keybinding)) && (lIIIlIIlIlIlII(lllllllllllllllIIllIlllIIllIlIlI.getKeyCode(), keybinding.getKeyCode())))
          {
            lllllllllllllllIIllIlllIIllIlIll = lIllIIIllllI[4];
            "".length();
            if (" ".length() > 0) {
              break;
            }
            return;
          }
          lllllllllllllllIIllIlllIIllIIIII++;
        }
      }
      if (lIIIlIIlIlIIlI(lllllllllllllllIIllIlllIIllIllII))
      {
        btnChangeKeyBinding.displayString = String.valueOf(new StringBuilder().append(EnumChatFormatting.WHITE).append(lIllIIIlIlll[lIllIIIllllI[4]]).append(EnumChatFormatting.YELLOW).append(btnChangeKeyBinding.displayString).append(EnumChatFormatting.WHITE).append(lIllIIIlIlll[lIllIIIllllI[6]]));
        "".length();
        if (-"   ".length() <= 0) {}
      }
      else if (lIIIlIIlIlIIlI(lllllllllllllllIIllIlllIIllIlIll))
      {
        btnChangeKeyBinding.displayString = String.valueOf(new StringBuilder().append(EnumChatFormatting.RED).append(btnChangeKeyBinding.displayString));
      }
      btnChangeKeyBinding.drawButton(mc, lllllllllllllllIIllIlllIIllIllll, lllllllllllllllIIllIlllIIllIlllI);
    }
    
    private static boolean lIIIlIIlIlIIII(Object ???, Object arg1)
    {
      Object localObject;
      float lllllllllllllllIIllIlllIIIIIIIIl;
      return ??? == localObject;
    }
    
    static
    {
      lIIIlIIlIIllll();
      lIIIlIIlIIlIlI();
    }
    
    public void setSelected(int lllllllllllllllIIllIlllIIlIIIIlI, int lllllllllllllllIIllIlllIIlIIIIIl, int lllllllllllllllIIllIlllIIlIIIIII) {}
    
    private static boolean lIIIlIIlIlIIlI(int ???)
    {
      String lllllllllllllllIIllIllIlllllllll;
      return ??? != 0;
    }
    
    private static void lIIIlIIlIIllll()
    {
      lIllIIIllllI = new int[12];
      lIllIIIllllI[0] = ((0xA8 ^ 0x81) & (0xEB ^ 0xC2 ^ 0xFFFFFFFF));
      lIllIIIllllI[1] = (0x46 ^ 0x6A ^ 0xE9 ^ 0x8E);
      lIllIIIllllI[2] = ('' + 30 - 53 + 24 ^ 93 + 23 - -24 + 0);
      lIllIIIllllI[3] = (0xD1 ^ 0xBE ^ 0xE2 ^ 0xBF);
      lIllIIIllllI[4] = " ".length();
      lIllIIIllllI[5] = (0xB ^ 0x51);
      lIllIIIllllI[6] = "  ".length();
      lIllIIIllllI[7] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
      lIllIIIllllI[8] = (122 + 49 - 85 + 104);
      lIllIIIllllI[9] = (0xAD ^ 0xC4);
      lIllIIIllllI[10] = "   ".length();
      lIllIIIllllI[11] = (0x49 ^ 0x41);
    }
    
    private static void lIIIlIIlIIlIlI()
    {
      lIllIIIlIlll = new String[lIllIIIllllI[10]];
      lIllIIIlIlll[lIllIIIllllI[0]] = lIIIlIIlIIlIII("AQwJAAYNDxRaBgcQAgA=", "bcgtt");
      lIllIIIlIlll[lIllIIIllllI[4]] = lIIIlIIlIIlIIl("BeRC2XPLnLI=", "ZFrSO");
      lIllIIIlIlll[lIllIIIllllI[6]] = lIIIlIIlIIlIII("amo=", "JVWhT");
    }
  }
}

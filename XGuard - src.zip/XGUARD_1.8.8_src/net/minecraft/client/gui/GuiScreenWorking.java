package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.util.IProgressUpdate;

public class GuiScreenWorking
  extends GuiScreen
  implements IProgressUpdate
{
  public void setDoneWorking()
  {
    ;
    doneWorking = lIlIlllllI[1];
  }
  
  public void resetProgressAndMessage(String lllllllllllllllllllllIlllIIlllll)
  {
    ;
    ;
    field_146591_a = lllllllllllllllllllllIlllIIlllll;
    lllllllllllllllllllllIlllIlIIIII.displayLoadingString(lIlIllIlIl[lIlIlllllI[2]]);
  }
  
  private static void lIIIllIlIIII()
  {
    lIlIlllllI = new int[10];
    lIlIlllllI[0] = ((0x7C ^ 0x2A) & (0xEC ^ 0xBA ^ 0xFFFFFFFF));
    lIlIlllllI[1] = " ".length();
    lIlIlllllI[2] = "  ".length();
    lIlIlllllI[3] = (0x19 ^ 0x47 ^ 0x25 ^ 0x3D);
    lIlIlllllI[4] = (0xFFFFFFFF & 0xFFFFFF);
    lIlIlllllI[5] = "   ".length();
    lIlIlllllI[6] = (0x36 ^ 0x32);
    lIlIlllllI[7] = (0x66 ^ 0x3C);
    lIlIlllllI[8] = (0x5E ^ 0x23 ^ 0x63 ^ 0x1B);
    lIlIlllllI[9] = (61 + '¶' - 194 + 136 ^ 109 + 30 - 8 + 46);
  }
  
  private static String lIIIlIllIIII(String lllllllllllllllllllllIllIllIllIl, String lllllllllllllllllllllIllIllIlllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllllllIllIlllIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllllIllIllIlllI.getBytes(StandardCharsets.UTF_8)), lIlIlllllI[9]), "DES");
      Cipher lllllllllllllllllllllIllIlllIIIl = Cipher.getInstance("DES");
      lllllllllllllllllllllIllIlllIIIl.init(lIlIlllllI[2], lllllllllllllllllllllIllIlllIIlI);
      return new String(lllllllllllllllllllllIllIlllIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllllllllIllIllIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllllllIllIlllIIII)
    {
      lllllllllllllllllllllIllIlllIIII.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIIIllIlIIII();
    lIIIlIllIIlI();
  }
  
  private static boolean lIIIllIlIIIl(int ???)
  {
    float lllllllllllllllllllllIllIllIlIII;
    return ??? != 0;
  }
  
  private static String lIIIlIllIIIl(String lllllllllllllllllllllIllIllllIlI, String lllllllllllllllllllllIllIllllIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllllllIllIlllllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllllIllIllllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllllllIllIllllllI = Cipher.getInstance("Blowfish");
      lllllllllllllllllllllIllIllllllI.init(lIlIlllllI[2], lllllllllllllllllllllIllIlllllll);
      return new String(lllllllllllllllllllllIllIllllllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllllllIllIllllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllllllIllIlllllIl)
    {
      lllllllllllllllllllllIllIlllllIl.printStackTrace();
    }
    return null;
  }
  
  public void drawScreen(int lllllllllllllllllllllIlllIIIIllI, int lllllllllllllllllllllIlllIIIIlIl, float lllllllllllllllllllllIlllIIIlIII)
  {
    ;
    ;
    ;
    ;
    if (lIIIllIlIIIl(doneWorking))
    {
      if (lIIIllIlIIlI(mc.func_181540_al()))
      {
        mc.displayGuiScreen(null);
        "".length();
        if ("  ".length() < (0x28 ^ 0x2C)) {}
      }
    }
    else
    {
      lllllllllllllllllllllIlllIIIIlll.drawDefaultBackground();
      lllllllllllllllllllllIlllIIIIlll.drawCenteredString(fontRendererObj, field_146591_a, width / lIlIlllllI[2], lIlIlllllI[3], lIlIlllllI[4]);
      lllllllllllllllllllllIlllIIIIlll.drawCenteredString(fontRendererObj, String.valueOf(new StringBuilder(String.valueOf(field_146589_f)).append(lIlIllIlIl[lIlIlllllI[5]]).append(progress).append(lIlIllIlIl[lIlIlllllI[6]])), width / lIlIlllllI[2], lIlIlllllI[7], lIlIlllllI[4]);
      lllllllllllllllllllllIlllIIIIlll.drawScreen(lllllllllllllllllllllIlllIIIIllI, lllllllllllllllllllllIlllIIIIlIl, lllllllllllllllllllllIlllIIIlIII);
    }
  }
  
  public void displaySavingString(String lllllllllllllllllllllIlllIlIIlll)
  {
    ;
    ;
    lllllllllllllllllllllIlllIlIIllI.resetProgressAndMessage(lllllllllllllllllllllIlllIlIIlll);
  }
  
  private static void lIIIlIllIIlI()
  {
    lIlIllIlIl = new String[lIlIlllllI[8]];
    lIlIllIlIl[lIlIlllllI[0]] = lIIIlIllIIII("GGfy7gml2nc=", "SaKwr");
    lIlIllIlIl[lIlIlllllI[1]] = lIIIlIllIIII("xPACh01QfEU=", "Mpszm");
    lIlIllIlIl[lIlIlllllI[2]] = lIIIlIllIIII("3UmBGU7vZ9POEXGjT73uJQ==", "ipwjK");
    lIlIllIlIl[lIlIlllllI[5]] = lIIIlIllIIIl("qGPSTlDo/kk=", "DvDJS");
    lIlIllIlIl[lIlIlllllI[6]] = lIIIlIllIIIl("k6x7QpJ0maA=", "WaJDf");
  }
  
  public GuiScreenWorking() {}
  
  public void displayLoadingString(String lllllllllllllllllllllIlllIIllIIl)
  {
    ;
    ;
    field_146589_f = lllllllllllllllllllllIlllIIllIIl;
    lllllllllllllllllllllIlllIIlllII.setLoadingProgress(lIlIlllllI[0]);
  }
  
  private static boolean lIIIllIlIIlI(int ???)
  {
    boolean lllllllllllllllllllllIllIllIIllI;
    return ??? == 0;
  }
  
  public void setLoadingProgress(int lllllllllllllllllllllIlllIIlIIll)
  {
    ;
    ;
    progress = lllllllllllllllllllllIlllIIlIIll;
  }
}

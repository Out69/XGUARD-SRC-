package net.minecraft.client.gui.stream;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.stream.IStream;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;
import tv.twitch.chat.ChatUserInfo;
import tv.twitch.chat.ChatUserMode;
import tv.twitch.chat.ChatUserSubscription;

public class GuiTwitchUserMode
  extends GuiScreen
{
  static
  {
    lIllIIllllllIl();
    lIllIIlllllIIl();
    field_152331_a = EnumChatFormatting.DARK_GREEN;
  }
  
  private static void lIllIIlllllIIl()
  {
    lllIlIllIIlI = new String[lllIlIllIlIl[33]];
    lllIlIllIIlI[lllIlIllIlIl[1]] = lIllIIllllIIII("5Gt5iZAwMWw=", "ysiHQ");
    lllIlIllIIlI[lllIlIllIlIl[0]] = lIllIIllllIIII("aK86Pav0xdM=", "Roqhp");
    lllIlIllIIlI[lllIlIllIlIl[2]] = lIllIIllllIIIl("NRILFxMrSAwBFzRICgcQNQULGwIyDxYcXDUTGwERNA8bFwA=", "Ffyrr");
    lllIlIllIIlI[lllIlIllIlIl[3]] = lIllIIllllIIII("hqceZWbpCa6m5mnjLc16WxSoY7ykGFvn7TDEfMlXOU7DEP/PwrUkmrsh4UtThDmW", "xmYoz");
    lllIlIllIIlI[lllIlIllIlIl[4]] = lIllIIllllIIlI("MGGg2wAdJGUnrkyItDnsAFoDm5zpJw5KY9WPZAmlhqPz1TN/Az57eN4EyVv8eV1b", "WinxC");
    lllIlIllIIlI[lllIlIllIlIl[5]] = lIllIIllllIIII("AEhzipJjZSzkwCiArf7xtuoYUBWhCcPIjT/yznfVh70=", "iGGIl");
    lllIlIllIIlI[lllIlIllIlIl[6]] = lIllIIllllIIIl("Jj0mCww4ZyEdCCdnOQEJMGc1CgA8Jz0dGScoIAEf", "UITnm");
    lllIlIllIIlI[lllIlIllIlIl[7]] = lIllIIllllIIIl("HCMKJysCeQ0xLx15FS0uCnkaIyQBMhw=", "oWxBJ");
    lllIlIllIIlI[lllIlIllIlIl[8]] = lIllIIllllIIII("bnrdhGC8hQLXN9qnEmfZYyw8id6Rf6U8ZxvGVlf/3L8=", "ISbET");
    lllIlIllIIlI[lllIlIllIlIl[9]] = lIllIIllllIIIl("OhYfCTMkTBgfNztMAAM2LEwPDTwnBwlCPT0KCB4=", "IbmlR");
    lllIlIllIIlI[lllIlIllIlIl[10]] = lIllIIllllIIIl("Ow0AFQslVwcDDzpXHx8OLVcQAgUpHRERGTwcAA==", "Hyrpj");
    lllIlIllIIlI[lllIlIllIlIl[11]] = lIllIIllllIIlI("mE3k275ou1C9tSx2F4mk1s4Zvz+96WKlyWkkXg+p48nhuRmYg37DcA==", "ZTjrk");
    lllIlIllIIlI[lllIlIllIlIl[12]] = lIllIIllllIIIl("Gh8QAAkERRcWDRtFDwoMDEUAFwcIDwEEGx0OEEsHHQMHFw==", "ikbeh");
    lllIlIllIIlI[lllIlIllIlIl[13]] = lIllIIllllIIlI("2hDk2/IaxLU9sxMTEM2XOwU2wr6fgEzHr/C5TeqkkVU=", "clvUQ");
    lllIlIllIIlI[lllIlIllIlIl[14]] = lIllIIllllIIlI("oyfITkPEPKSvmFmfCQiNYmwwbMvJkrpyrUEp7IrZEdw=", "VsbAw");
    lllIlIllIIlI[lllIlIllIlIl[15]] = lIllIIllllIIIl("ACA+CA0eejkeCQF6IQIIFnohAggWJi0ZAwF6IxkEFiY=", "sTLml");
    lllIlIllIIlI[lllIlIllIlIl[16]] = lIllIIllllIIlI("H7SDnyW53VFtxxFRK6jGU9GTKA7i0Uif", "LRppw");
    lllIlIllIIlI[lllIlIllIlIl[20]] = lIllIIllllIIlI("S/HiZ9W52JIY6n/6iY6oV6g2Y16bc1wC", "CPonU");
    lllIlIllIIlI[lllIlIllIlIl[21]] = lIllIIllllIIlI("rSvZITXnEsM1noz4qLdtP/NzFwIkpMcy", "JjMfM");
    lllIlIllIIlI[lllIlIllIlIl[22]] = lIllIIllllIIlI("Izy+82/lBoPTpfitM3y9WDe+GCo6cszY", "OIVJz");
    lllIlIllIIlI[lllIlIllIlIl[19]] = lIllIIllllIIII("eyQCCuknMIC8m64WLyJB9w==", "gbvjt");
    lllIlIllIIlI[lllIlIllIlIl[24]] = lIllIIllllIIlI("staz12VutT2NXIiiPn2Sw+pzO8pKvHVy", "NsndW");
    lllIlIllIIlI[lllIlIllIlIl[25]] = lIllIIllllIIIl("Azk3NzQdYzAhMAIkKzQ6XjgrPzoU", "pMERU");
    lllIlIllIIlI[lllIlIllIlIl[26]] = lIllIIllllIIlI("xEehp5zuuKI=", "bEgVg");
    lllIlIllIIlI[lllIlIllIlIl[27]] = lIllIIllllIIII("MbH88xQRw/E=", "LmJmK");
    lllIlIllIIlI[lllIlIllIlIl[28]] = lIllIIllllIIIl("XAgtKEo=", "seBLj");
    lllIlIllIIlI[lllIlIllIlIl[29]] = lIllIIllllIIlI("e028kpdjn+k=", "ncpuk");
    lllIlIllIIlI[lllIlIllIlIl[30]] = lIllIIllllIIIl("QgwCLBYCDR9h", "mxkAs");
  }
  
  private static boolean lIllIlIIIIIIll(int ???, int arg1)
  {
    int i;
    long llllllllllllllIllIllllllIIIIIIlI;
    return ??? == i;
  }
  
  public static List<IChatComponent> func_152328_a(Set<ChatUserMode> llllllllllllllIllIlllllllIIlIIII, Set<ChatUserSubscription> llllllllllllllIllIlllllllIIIIIll, IStream llllllllllllllIllIlllllllIIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllIIlllllllI(llllllllllllllIllIlllllllIIIIIlI))
    {
      "".length();
      if ("  ".length() > -" ".length()) {
        break label36;
      }
      return null;
    }
    label36:
    String llllllllllllllIllIlllllllIIIllIl = llllllllllllllIllIlllllllIIIIIlI.func_152921_C();
    if ((lIllIIllllllll(llllllllllllllIllIlllllllIIIIIlI)) && (lIllIlIIIIIIII(llllllllllllllIllIlllllllIIIIIlI.func_152927_B())))
    {
      "".length();
      if ("   ".length() == "   ".length()) {
        break label87;
      }
      return null;
    }
    label87:
    boolean llllllllllllllIllIlllllllIIIllII = lllIlIllIlIl[1];
    List<IChatComponent> llllllllllllllIllIlllllllIIIlIll = Lists.newArrayList();
    long llllllllllllllIllIllllllIlllllIl = llllllllllllllIllIlllllllIIlIIII.iterator();
    "".length();
    if (-" ".length() >= "  ".length()) {
      return null;
    }
    while (!lIllIlIIIIIIIl(llllllllllllllIllIllllllIlllllIl.hasNext()))
    {
      ChatUserMode llllllllllllllIllIlllllllIIIlIlI = (ChatUserMode)llllllllllllllIllIllllllIlllllIl.next();
      IChatComponent llllllllllllllIllIlllllllIIIlIIl = func_152329_a(llllllllllllllIllIlllllllIIIlIlI, llllllllllllllIllIlllllllIIIllIl, llllllllllllllIllIlllllllIIIllII);
      if (lIllIIllllllll(llllllllllllllIllIlllllllIIIlIIl))
      {
        IChatComponent llllllllllllllIllIlllllllIIIlIII = new ChatComponentText(lllIlIllIIlI[lllIlIllIlIl[1]]);
        "".length();
        "".length();
      }
    }
    llllllllllllllIllIllllllIlllllIl = llllllllllllllIllIlllllllIIIllll.iterator();
    "".length();
    if (" ".length() == "   ".length()) {
      return null;
    }
    while (!lIllIlIIIIIIIl(llllllllllllllIllIllllllIlllllIl.hasNext()))
    {
      ChatUserSubscription llllllllllllllIllIlllllllIIIIlll = (ChatUserSubscription)llllllllllllllIllIllllllIlllllIl.next();
      IChatComponent llllllllllllllIllIlllllllIIIIllI = func_152330_a(llllllllllllllIllIlllllllIIIIlll, llllllllllllllIllIlllllllIIIllIl, llllllllllllllIllIlllllllIIIllII);
      if (lIllIIllllllll(llllllllllllllIllIlllllllIIIIllI))
      {
        IChatComponent llllllllllllllIllIlllllllIIIIlIl = new ChatComponentText(lllIlIllIIlI[lllIlIllIlIl[0]]);
        "".length();
        "".length();
      }
    }
    return llllllllllllllIllIlllllllIIIlIll;
  }
  
  private static boolean lIllIlIIIIIlII(int ???, int arg1)
  {
    int i;
    float llllllllllllllIllIlllllIlllllllI;
    return ??? < i;
  }
  
  public static IChatComponent func_152329_a(ChatUserMode llllllllllllllIllIllllllIllIlIlI, String llllllllllllllIllIllllllIllIIlIl, boolean llllllllllllllIllIllllllIllIIlII)
  {
    ;
    ;
    ;
    ;
    IChatComponent llllllllllllllIllIllllllIllIIlll = null;
    if (lIllIlIIIIIIlI(llllllllllllllIllIllllllIllIlIlI, ChatUserMode.TTV_CHAT_USERMODE_ADMINSTRATOR))
    {
      llllllllllllllIllIllllllIllIIlll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[6]], new Object[lllIlIllIlIl[1]]);
      "".length();
      "".length();
      if ((0x28 ^ 0x49 ^ 0x47 ^ 0x22) != (0x38 ^ 0x52 ^ 0xE9 ^ 0x87)) {
        return null;
      }
    }
    else if (lIllIlIIIIIIlI(llllllllllllllIllIllllllIllIlIlI, ChatUserMode.TTV_CHAT_USERMODE_BANNED))
    {
      if (lIllIIlllllllI(llllllllllllllIllIllllllIllIlIIl))
      {
        llllllllllllllIllIllllllIllIIlll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[7]], new Object[lllIlIllIlIl[1]]);
        "".length();
        if (" ".length() >= (35 + 89 - 12 + 79 ^ 8 + '´' - 167 + 166)) {
          return null;
        }
      }
      else if (lIllIlIIIIIIII(llllllllllllllIllIllllllIllIIlII))
      {
        llllllllllllllIllIllllllIllIIlll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[8]], new Object[lllIlIllIlIl[1]]);
        "".length();
        if (" ".length() == 0) {
          return null;
        }
      }
      else
      {
        llllllllllllllIllIllllllIllIIlll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[9]], new Object[] { llllllllllllllIllIllllllIllIlIIl });
      }
      "".length();
      "".length();
      if ((47 + 2 - -89 + 13 ^ 35 + 105 - 97 + 103) <= 0) {
        return null;
      }
    }
    else if (lIllIlIIIIIIlI(llllllllllllllIllIllllllIllIlIlI, ChatUserMode.TTV_CHAT_USERMODE_BROADCASTER))
    {
      if (lIllIIlllllllI(llllllllllllllIllIllllllIllIlIIl))
      {
        llllllllllllllIllIllllllIllIIlll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[10]], new Object[lllIlIllIlIl[1]]);
        "".length();
        if (((0x69 ^ 0x52) & (0x25 ^ 0x1E ^ 0xFFFFFFFF)) < 0) {
          return null;
        }
      }
      else if (lIllIlIIIIIIII(llllllllllllllIllIllllllIllIIlII))
      {
        llllllllllllllIllIllllllIllIIlll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[11]], new Object[lllIlIllIlIl[1]]);
        "".length();
        if ((0x40 ^ 0x44) != (0x77 ^ 0x73)) {
          return null;
        }
      }
      else
      {
        llllllllllllllIllIllllllIllIIlll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[12]], new Object[lllIlIllIlIl[1]]);
      }
      "".length();
      "".length();
      if (((0xD4 ^ 0xC2) & (0x64 ^ 0x72 ^ 0xFFFFFFFF)) == "   ".length()) {
        return null;
      }
    }
    else if (lIllIlIIIIIIlI(llllllllllllllIllIllllllIllIlIlI, ChatUserMode.TTV_CHAT_USERMODE_MODERATOR))
    {
      if (lIllIIlllllllI(llllllllllllllIllIllllllIllIlIIl))
      {
        llllllllllllllIllIllllllIllIIlll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[13]], new Object[lllIlIllIlIl[1]]);
        "".length();
        if (-" ".length() == "   ".length()) {
          return null;
        }
      }
      else if (lIllIlIIIIIIII(llllllllllllllIllIllllllIllIIlII))
      {
        llllllllllllllIllIllllllIllIIlll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[14]], new Object[lllIlIllIlIl[1]]);
        "".length();
        if (-" ".length() > 0) {
          return null;
        }
      }
      else
      {
        llllllllllllllIllIllllllIllIIlll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[15]], new Object[] { llllllllllllllIllIllllllIllIlIIl });
      }
      "".length();
      "".length();
      if (" ".length() >= "   ".length()) {
        return null;
      }
    }
    else if (lIllIlIIIIIIlI(llllllllllllllIllIllllllIllIlIlI, ChatUserMode.TTV_CHAT_USERMODE_STAFF))
    {
      llllllllllllllIllIllllllIllIIlll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[16]], new Object[lllIlIllIlIl[1]]);
      "".length();
    }
    return llllllllllllllIllIllllllIllIIlll;
  }
  
  private static String lIllIIllllIIII(String llllllllllllllIllIllllllIIlIIIll, String llllllllllllllIllIllllllIIlIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIllllllIIlIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIllllllIIlIIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIllllllIIlIIlIl = Cipher.getInstance("Blowfish");
      llllllllllllllIllIllllllIIlIIlIl.init(lllIlIllIlIl[2], llllllllllllllIllIllllllIIlIIllI);
      return new String(llllllllllllllIllIllllllIIlIIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIllllllIIlIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIllllllIIlIIlII)
    {
      llllllllllllllIllIllllllIIlIIlII.printStackTrace();
    }
    return null;
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIllIllllllIlIllIll = width / lllIlIllIlIl[3];
    int llllllllllllllIllIllllllIlIllIlI = llllllllllllllIllIllllllIlIllIll - lllIlIllIlIl[17];
    new GuiButton(lllIlIllIlIl[0], llllllllllllllIllIllllllIlIllIll * lllIlIllIlIl[1] + llllllllllllllIllIllllllIlIllIlI / lllIlIllIlIl[2], height - lllIlIllIlIl[18], lllIlIllIlIl[17], lllIlIllIlIl[19], I18n.format(lllIlIllIIlI[lllIlIllIlIl[20]], new Object[lllIlIllIlIl[1]]));
    "".length();
    new GuiButton(lllIlIllIlIl[1], llllllllllllllIllIllllllIlIllIll * lllIlIllIlIl[0] + llllllllllllllIllIllllllIlIllIlI / lllIlIllIlIl[2], height - lllIlIllIlIl[18], lllIlIllIlIl[17], lllIlIllIlIl[19], I18n.format(lllIlIllIIlI[lllIlIllIlIl[21]], new Object[lllIlIllIlIl[1]]));
    "".length();
    new GuiButton(lllIlIllIlIl[2], llllllllllllllIllIllllllIlIllIll * lllIlIllIlIl[2] + llllllllllllllIllIllllllIlIllIlI / lllIlIllIlIl[2], height - lllIlIllIlIl[18], lllIlIllIlIl[17], lllIlIllIlIl[19], I18n.format(lllIlIllIIlI[lllIlIllIlIl[22]], new Object[lllIlIllIlIl[1]]));
    "".length();
    new GuiButton(lllIlIllIlIl[5], llllllllllllllIllIllllllIlIllIll * lllIlIllIlIl[1] + llllllllllllllIllIllllllIlIllIlI / lllIlIllIlIl[2], height - lllIlIllIlIl[23], lllIlIllIlIl[17], lllIlIllIlIl[19], I18n.format(lllIlIllIIlI[lllIlIllIlIl[19]], new Object[lllIlIllIlIl[1]]));
    "".length();
    new GuiButton(lllIlIllIlIl[3], llllllllllllllIllIllllllIlIllIll * lllIlIllIlIl[0] + llllllllllllllIllIllllllIlIllIlI / lllIlIllIlIl[2], height - lllIlIllIlIl[23], lllIlIllIlIl[17], lllIlIllIlIl[19], I18n.format(lllIlIllIIlI[lllIlIllIlIl[24]], new Object[lllIlIllIlIl[1]]));
    "".length();
    new GuiButton(lllIlIllIlIl[4], llllllllllllllIllIllllllIlIllIll * lllIlIllIlIl[2] + llllllllllllllIllIllllllIlIllIlI / lllIlIllIlIl[2], height - lllIlIllIlIl[23], lllIlIllIlIl[17], lllIlIllIlIl[19], I18n.format(lllIlIllIIlI[lllIlIllIlIl[25]], new Object[lllIlIllIlIl[1]]));
    "".length();
    int llllllllllllllIllIllllllIlIllIIl = lllIlIllIlIl[1];
    long llllllllllllllIllIllllllIlIlIIlI = field_152332_r.iterator();
    "".length();
    if ((0x8E ^ 0x8B) == 0) {
      return;
    }
    while (!lIllIlIIIIIIIl(llllllllllllllIllIllllllIlIlIIlI.hasNext()))
    {
      IChatComponent llllllllllllllIllIllllllIlIllIII = (IChatComponent)llllllllllllllIllIllllllIlIlIIlI.next();
      llllllllllllllIllIllllllIlIllIIl = Math.max(llllllllllllllIllIllllllIlIllIIl, fontRendererObj.getStringWidth(llllllllllllllIllIllllllIlIllIII.getFormattedText()));
    }
    field_152334_t = (width / lllIlIllIlIl[2] - llllllllllllllIllIllllllIlIllIIl / lllIlIllIlIl[2]);
  }
  
  private static String lIllIIllllIIlI(String llllllllllllllIllIllllllIIlIlllI, String llllllllllllllIllIllllllIIlIllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIllllllIIllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIllllllIIlIllIl.getBytes(StandardCharsets.UTF_8)), lllIlIllIlIl[8]), "DES");
      Cipher llllllllllllllIllIllllllIIllIIlI = Cipher.getInstance("DES");
      llllllllllllllIllIllllllIIllIIlI.init(lllIlIllIlIl[2], llllllllllllllIllIllllllIIllIIll);
      return new String(llllllllllllllIllIllllllIIllIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIllllllIIlIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIllllllIIllIIIl)
    {
      llllllllllllllIllIllllllIIllIIIl.printStackTrace();
    }
    return null;
  }
  
  private static String lIllIIllllIIIl(String llllllllllllllIllIllllllIIIlIIll, String llllllllllllllIllIllllllIIIlIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIllllllIIIlIIll = new String(Base64.getDecoder().decode(llllllllllllllIllIllllllIIIlIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIllllllIIIlIIIl = new StringBuilder();
    char[] llllllllllllllIllIllllllIIIlIIII = llllllllllllllIllIllllllIIIlIIlI.toCharArray();
    int llllllllllllllIllIllllllIIIIllll = lllIlIllIlIl[1];
    Exception llllllllllllllIllIllllllIIIIlIIl = llllllllllllllIllIllllllIIIlIIll.toCharArray();
    double llllllllllllllIllIllllllIIIIlIII = llllllllllllllIllIllllllIIIIlIIl.length;
    long llllllllllllllIllIllllllIIIIIlll = lllIlIllIlIl[1];
    while (lIllIlIIIIIlII(llllllllllllllIllIllllllIIIIIlll, llllllllllllllIllIllllllIIIIlIII))
    {
      char llllllllllllllIllIllllllIIIlIlII = llllllllllllllIllIllllllIIIIlIIl[llllllllllllllIllIllllllIIIIIlll];
      "".length();
      "".length();
      if (-"  ".length() >= 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIllllllIIIlIIIl);
  }
  
  private static boolean lIllIlIIIIIIIl(int ???)
  {
    double llllllllllllllIllIlllllIllllIIlI;
    return ??? == 0;
  }
  
  public GuiTwitchUserMode(IStream llllllllllllllIllIlllllllIIlllII, ChatUserInfo llllllllllllllIllIlllllllIIllllI)
  {
    stream = llllllllllllllIllIlllllllIIlllll;
    field_152337_h = llllllllllllllIllIlllllllIIllllI;
    field_152338_i = new ChatComponentText(displayName);
    "".length();
  }
  
  public void drawScreen(int llllllllllllllIllIllllllIlIIIIll, int llllllllllllllIllIllllllIIllllII, float llllllllllllllIllIllllllIIlllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIllllllIIlllllI.drawDefaultBackground();
    llllllllllllllIllIllllllIIlllllI.drawCenteredString(fontRendererObj, field_152338_i.getUnformattedText(), width / lllIlIllIlIl[2], lllIlIllIlIl[18], lllIlIllIlIl[31]);
    int llllllllllllllIllIllllllIlIIIIII = lllIlIllIlIl[32];
    float llllllllllllllIllIllllllIIlllIII = field_152332_r.iterator();
    "".length();
    if ((0x74 ^ 0x70) == 0) {
      return;
    }
    while (!lIllIlIIIIIIIl(llllllllllllllIllIllllllIIlllIII.hasNext()))
    {
      IChatComponent llllllllllllllIllIllllllIIllllll = (IChatComponent)llllllllllllllIllIllllllIIlllIII.next();
      llllllllllllllIllIllllllIIlllllI.drawString(fontRendererObj, llllllllllllllIllIllllllIIllllll.getFormattedText(), field_152334_t, llllllllllllllIllIllllllIlIIIIII, lllIlIllIlIl[31]);
      llllllllllllllIllIllllllIlIIIIII += fontRendererObj.FONT_HEIGHT;
    }
    llllllllllllllIllIllllllIIlllllI.drawScreen(llllllllllllllIllIllllllIlIIIIll, llllllllllllllIllIllllllIIllllII, llllllllllllllIllIllllllIIlllIll);
  }
  
  public static IChatComponent func_152330_a(ChatUserSubscription llllllllllllllIllIllllllIlllIllI, String llllllllllllllIllIllllllIlllIlIl, boolean llllllllllllllIllIllllllIlllIlII)
  {
    ;
    ;
    ;
    ;
    IChatComponent llllllllllllllIllIllllllIlllIIll = null;
    if (lIllIlIIIIIIlI(llllllllllllllIllIllllllIlllIllI, ChatUserSubscription.TTV_CHAT_USERSUB_SUBSCRIBER))
    {
      if (lIllIIlllllllI(llllllllllllllIllIllllllIlllIIIl))
      {
        llllllllllllllIllIllllllIlllIIll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[2]], new Object[lllIlIllIlIl[1]]);
        "".length();
        if ((0x25 ^ 0x53 ^ 0xDC ^ 0xAE) <= 0) {
          return null;
        }
      }
      else if (lIllIlIIIIIIII(llllllllllllllIllIllllllIlllIlII))
      {
        llllllllllllllIllIllllllIlllIIll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[3]], new Object[lllIlIllIlIl[1]]);
        "".length();
        if ("   ".length() <= 0) {
          return null;
        }
      }
      else
      {
        llllllllllllllIllIllllllIlllIIll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[4]], new Object[] { llllllllllllllIllIllllllIlllIIIl });
      }
      "".length();
      "".length();
      if (-"  ".length() > 0) {
        return null;
      }
    }
    else if (lIllIlIIIIIIlI(llllllllllllllIllIllllllIlllIllI, ChatUserSubscription.TTV_CHAT_USERSUB_TURBO))
    {
      llllllllllllllIllIllllllIlllIIll = new ChatComponentTranslation(lllIlIllIIlI[lllIlIllIlIl[5]], new Object[lllIlIllIlIl[1]]);
      "".length();
    }
    return llllllllllllllIllIllllllIlllIIll;
  }
  
  private static boolean lIllIlIIIIIIlI(Object ???, Object arg1)
  {
    Object localObject;
    float llllllllllllllIllIlllllIlllllIII;
    return ??? == localObject;
  }
  
  private static boolean lIllIIlllllllI(Object ???)
  {
    byte llllllllllllllIllIlllllIllllIllI;
    return ??? == null;
  }
  
  private static boolean lIllIIllllllll(Object ???)
  {
    boolean llllllllllllllIllIlllllIllllllII;
    return ??? != null;
  }
  
  private static boolean lIllIlIIIIIIII(int ???)
  {
    String llllllllllllllIllIlllllIllllIlII;
    return ??? != 0;
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIllIllllllIlIIllII)
    throws IOException
  {
    ;
    ;
    if (lIllIlIIIIIIII(enabled))
    {
      if (lIllIlIIIIIIIl(id))
      {
        stream.func_152917_b(String.valueOf(new StringBuilder(lllIlIllIIlI[lllIlIllIlIl[26]]).append(field_152337_h.displayName)));
        "".length();
        if (" ".length() == " ".length()) {}
      }
      else if (lIllIlIIIIIIll(id, lllIlIllIlIl[3]))
      {
        stream.func_152917_b(String.valueOf(new StringBuilder(lllIlIllIIlI[lllIlIllIlIl[27]]).append(field_152337_h.displayName)));
        "".length();
        if (-(0x32 ^ 0x37) < 0) {}
      }
      else if (lIllIlIIIIIIll(id, lllIlIllIlIl[2]))
      {
        stream.func_152917_b(String.valueOf(new StringBuilder(lllIlIllIIlI[lllIlIllIlIl[28]]).append(field_152337_h.displayName)));
        "".length();
        if ("   ".length() >= " ".length()) {}
      }
      else if (lIllIlIIIIIIll(id, lllIlIllIlIl[4]))
      {
        stream.func_152917_b(String.valueOf(new StringBuilder(lllIlIllIIlI[lllIlIllIlIl[29]]).append(field_152337_h.displayName)));
        "".length();
        if (((0xC0 ^ 0xC7) & (0x13 ^ 0x14 ^ 0xFFFFFFFF)) == 0) {}
      }
      else if (lIllIlIIIIIIll(id, lllIlIllIlIl[0]))
      {
        stream.func_152917_b(String.valueOf(new StringBuilder(lllIlIllIIlI[lllIlIllIlIl[30]]).append(field_152337_h.displayName)));
      }
      mc.displayGuiScreen(null);
    }
  }
  
  private static void lIllIIllllllIl()
  {
    lllIlIllIlIl = new int[34];
    lllIlIllIlIl[0] = " ".length();
    lllIlIllIlIl[1] = ((59 + 46 - 67 + 139 ^ 18 + 59 - -38 + 17) & (115 + 93 - 117 + 150 ^ '¢' + 36 - 107 + 105 ^ -" ".length()));
    lllIlIllIlIl[2] = "  ".length();
    lllIlIllIlIl[3] = "   ".length();
    lllIlIllIlIl[4] = (0x4B ^ 0x4F);
    lllIlIllIlIl[5] = (0xB8 ^ 0xBD);
    lllIlIllIlIl[6] = ('' + 94 - 124 + 31 ^ 38 + 32 - 54 + 116);
    lllIlIllIlIl[7] = (0x65 ^ 0x62);
    lllIlIllIlIl[8] = (0xAE ^ 0xA6);
    lllIlIllIlIl[9] = (0x43 ^ 0x68 ^ 0x88 ^ 0xAA);
    lllIlIllIlIl[10] = (0x12 ^ 0x18);
    lllIlIllIlIl[11] = (0xB2 ^ 0xB9);
    lllIlIllIlIl[12] = (84 + '' - 79 + 6 ^ 81 + 121 - 181 + 114);
    lllIlIllIlIl[13] = (0x5F ^ 0x52);
    lllIlIllIlIl[14] = (38 + 99 - 118 + 126 ^ 115 + 16 - -5 + 23);
    lllIlIllIlIl[15] = (0x7F ^ 0x48 ^ 0x58 ^ 0x60);
    lllIlIllIlIl[16] = (0x7A ^ 0x6A);
    lllIlIllIlIl[17] = (125 + 40 - 159 + 124);
    lllIlIllIlIl[18] = (0x57 ^ 0x11);
    lllIlIllIlIl[19] = (39 + '' - 172 + 175 ^ 74 + 96 - 102 + 100);
    lllIlIllIlIl[20] = (0x2C ^ 0x3D);
    lllIlIllIlIl[21] = (0x38 ^ 0x2A);
    lllIlIllIlIl[22] = (0x12 ^ 0x1);
    lllIlIllIlIl[23] = (0x90 ^ 0x9D ^ 0x2A ^ 0xA);
    lllIlIllIlIl[24] = (0x93 ^ 0x86);
    lllIlIllIlIl[25] = (0x3D ^ 0x6E ^ 0xC6 ^ 0x83);
    lllIlIllIlIl[26] = (0x7 ^ 0xB ^ 0x70 ^ 0x6B);
    lllIlIllIlIl[27] = (31 + 82 - -19 + 28 ^ 93 + 74 - -11 + 6);
    lllIlIllIlIl[28] = (0x28 ^ 0x31);
    lllIlIllIlIl[29] = (117 + 28 - 117 + 127 ^ 117 + 105 - 106 + 13);
    lllIlIllIlIl[30] = (0x75 ^ 0x6E);
    lllIlIllIlIl[31] = (0xFFFFFFFF & 0xFFFFFF);
    lllIlIllIlIl[32] = ("   ".length() ^ 0xF9 ^ 0xAA);
    lllIlIllIlIl[33] = (0x5E ^ 0x42);
  }
}

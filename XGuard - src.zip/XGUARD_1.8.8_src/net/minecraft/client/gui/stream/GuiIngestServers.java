package net.minecraft.client.gui.stream;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiSlot;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.stream.IStream;
import net.minecraft.client.stream.IngestServerTester;
import net.minecraft.util.EnumChatFormatting;
import tv.twitch.broadcast.IngestServer;

public class GuiIngestServers
  extends GuiScreen
{
  public GuiIngestServers(GuiScreen llllllllllllllllIlIIIlllIIllllll)
  {
    field_152309_a = llllllllllllllllIlIIIlllIIllllll;
  }
  
  public void onGuiClosed()
  {
    ;
    if (lIlIIllIlIlll(mc.getTwitchStream().func_152908_z())) {
      mc.getTwitchStream().func_152932_y().func_153039_l();
    }
  }
  
  private static void lIlIIllIlIlIl()
  {
    llIllIIlIll = new int[13];
    llIllIIlIll[0] = ((0x36 ^ 0x29) & (0x1A ^ 0x5 ^ 0xFFFFFFFF));
    llIllIIlIll[1] = " ".length();
    llIllIIlIll[2] = "  ".length();
    llIllIIlIll[3] = (58 + 40 - 6 + 63);
    llIllIIlIll[4] = (0x6B ^ 0x35 ^ 0x1B ^ 0x5D);
    llIllIIlIll[5] = (0x17 ^ 0x3E ^ 0x19 ^ 0x36);
    llIllIIlIll[6] = ((0xBC ^ 0x96) + (0xC7 ^ 0x87) - (0xD ^ 0x6D) + (53 + 94 - 87 + 80));
    llIllIIlIll[7] = (0x46 ^ 0x52);
    llIllIIlIll[8] = (0x5D ^ 0xA ^ 0x90 ^ 0xC2);
    llIllIIlIll[9] = "   ".length();
    llIllIIlIll[10] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    llIllIIlIll[11] = (0x82 ^ 0xB4 ^ 0x33 ^ 0x1);
    llIllIIlIll[12] = (0x31 ^ 0x39);
  }
  
  private static boolean lIlIIllIllIIl(int ???, int arg1)
  {
    int i;
    char llllllllllllllllIlIIIllIllllIIll;
    return ??? < i;
  }
  
  private static String lIlIIllIIlllI(String llllllllllllllllIlIIIlllIIIllIII, String llllllllllllllllIlIIIlllIIIlIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIlIIIlllIIIllIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlIIIlllIIIlIlll.getBytes(StandardCharsets.UTF_8)), llIllIIlIll[12]), "DES");
      Cipher llllllllllllllllIlIIIlllIIIllIlI = Cipher.getInstance("DES");
      llllllllllllllllIlIIIlllIIIllIlI.init(llIllIIlIll[2], llllllllllllllllIlIIIlllIIIllIll);
      return new String(llllllllllllllllIlIIIlllIIIllIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllIlIIIlllIIIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIlIIIlllIIIllIIl)
    {
      llllllllllllllllIlIIIlllIIIllIIl.printStackTrace();
    }
    return null;
  }
  
  protected void actionPerformed(GuiButton llllllllllllllllIlIIIlllIIllIIII)
    throws IOException
  {
    ;
    ;
    if (lIlIIllIlIlll(enabled)) {
      if (lIlIIllIllIII(id, llIllIIlIll[1]))
      {
        mc.displayGuiScreen(field_152309_a);
        "".length();
        if (((0x57 ^ 0x7B ^ " ".length()) & (0x6E ^ 0x34 ^ 0xB6 ^ 0xC1 ^ -" ".length())) == 0) {}
      }
      else
      {
        mc.gameSettings.streamPreferredServer = llIllIIlIII[llIllIIlIll[9]];
        mc.gameSettings.saveOptions();
      }
    }
  }
  
  public void initGui()
  {
    ;
    field_152310_f = I18n.format(llIllIIlIII[llIllIIlIll[0]], new Object[llIllIIlIll[0]]);
    field_152311_g = new ServerList(mc);
    if (lIlIIllIlIllI(mc.getTwitchStream().func_152908_z())) {
      mc.getTwitchStream().func_152909_x();
    }
    new GuiButton(llIllIIlIll[1], width / llIllIIlIll[2] - llIllIIlIll[3], height - llIllIIlIll[4] - llIllIIlIll[5], llIllIIlIll[6], llIllIIlIll[7], I18n.format(llIllIIlIII[llIllIIlIll[1]], new Object[llIllIIlIll[0]]));
    "".length();
    new GuiButton(llIllIIlIll[2], width / llIllIIlIll[2] + llIllIIlIll[8], height - llIllIIlIll[4] - llIllIIlIll[5], llIllIIlIll[6], llIllIIlIll[7], I18n.format(llIllIIlIII[llIllIIlIll[2]], new Object[llIllIIlIll[0]]));
    "".length();
  }
  
  private static boolean lIlIIllIlIllI(int ???)
  {
    int llllllllllllllllIlIIIllIlllIllll;
    return ??? == 0;
  }
  
  private static boolean lIlIIllIllIII(int ???, int arg1)
  {
    int i;
    double llllllllllllllllIlIIIllIllllIlll;
    return ??? == i;
  }
  
  private static boolean lIlIIllIlIlll(int ???)
  {
    Exception llllllllllllllllIlIIIllIllllIIIl;
    return ??? != 0;
  }
  
  private static void lIlIIllIlIIII()
  {
    llIllIIlIII = new String[llIllIIlIll[11]];
    llIllIIlIII[llIllIIlIll[0]] = lIlIIllIIlllI("6BhUEHG8ADu/d2oaS+B8a0QJdIuIQiVLvtlTJgPpl1M=", "jwMhC");
    llIllIIlIII[llIllIIlIll[1]] = lIlIIllIIlllI("dAK2Ceoy9+AeWzp2+Lo4Qw==", "myaYK");
    llIllIIlIII[llIllIIlIll[2]] = lIlIIllIIlllI("G6lEF3T6vEo80eolBbljgciAKfU9br5P8D8hP1g1GDE=", "xNhke");
    llIllIIlIII[llIllIIlIll[9]] = lIlIIllIIllll("", "EuCXx");
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    llllllllllllllllIlIIIlllIIllIlll.handleMouseInput();
    field_152311_g.handleMouseInput();
  }
  
  static
  {
    lIlIIllIlIlIl();
    lIlIIllIlIIII();
  }
  
  private static String lIlIIllIIllll(String llllllllllllllllIlIIIlllIIIIlIII, String llllllllllllllllIlIIIlllIIIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIlIIIlllIIIIlIII = new String(Base64.getDecoder().decode(llllllllllllllllIlIIIlllIIIIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIlIIIlllIIIIIllI = new StringBuilder();
    char[] llllllllllllllllIlIIIlllIIIIIlIl = llllllllllllllllIlIIIlllIIIIIIlI.toCharArray();
    int llllllllllllllllIlIIIlllIIIIIlII = llIllIIlIll[0];
    float llllllllllllllllIlIIIllIlllllllI = llllllllllllllllIlIIIlllIIIIlIII.toCharArray();
    short llllllllllllllllIlIIIllIllllllIl = llllllllllllllllIlIIIllIlllllllI.length;
    float llllllllllllllllIlIIIllIllllllII = llIllIIlIll[0];
    while (lIlIIllIllIIl(llllllllllllllllIlIIIllIllllllII, llllllllllllllllIlIIIllIllllllIl))
    {
      char llllllllllllllllIlIIIlllIIIIlIIl = llllllllllllllllIlIIIllIlllllllI[llllllllllllllllIlIIIllIllllllII];
      "".length();
      "".length();
      if ((0xCC ^ 0x96 ^ 0x30 ^ 0x6E) == 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIlIIIlllIIIIIllI);
  }
  
  public void drawScreen(int llllllllllllllllIlIIIlllIIlIIlII, int llllllllllllllllIlIIIlllIIlIIlll, float llllllllllllllllIlIIIlllIIlIIIlI)
  {
    ;
    ;
    ;
    ;
    llllllllllllllllIlIIIlllIIlIlIIl.drawDefaultBackground();
    field_152311_g.drawScreen(llllllllllllllllIlIIIlllIIlIIlII, llllllllllllllllIlIIIlllIIlIIlll, llllllllllllllllIlIIIlllIIlIIIlI);
    llllllllllllllllIlIIIlllIIlIlIIl.drawCenteredString(fontRendererObj, field_152310_f, width / llIllIIlIll[2], llIllIIlIll[7], llIllIIlIll[10]);
    llllllllllllllllIlIIIlllIIlIlIIl.drawScreen(llllllllllllllllIlIIIlllIIlIIlII, llllllllllllllllIlIIIlllIIlIIlll, llllllllllllllllIlIIIlllIIlIIIlI);
  }
  
  class ServerList
    extends GuiSlot
  {
    protected void elementClicked(int lllllllllllllllIIllIIIllIllIIIII, boolean lllllllllllllllIIllIIIllIlIlllll, int lllllllllllllllIIllIIIllIlIllllI, int lllllllllllllllIIllIIIllIlIlllIl)
    {
      ;
      ;
      mc.gameSettings.streamPreferredServer = mc.getTwitchStream().func_152925_v()[lllllllllllllllIIllIIIllIllIIIII].serverUrl;
      mc.gameSettings.saveOptions();
    }
    
    protected void drawBackground() {}
    
    private static boolean lIIIllIIIlIlII(int ???)
    {
      double lllllllllllllllIIllIIIlIllllIIll;
      return ??? == 0;
    }
    
    protected int getScrollBarX()
    {
      ;
      return lllllllllllllllIIllIIIllIIllIlII.getScrollBarX() + lIllIlIllIlI[15];
    }
    
    private static boolean lIIIllIIIlIIIl(Object ???)
    {
      short lllllllllllllllIIllIIIlIlllllIll;
      return ??? != null;
    }
    
    private static String lIIIllIIIIIllI(String lllllllllllllllIIllIIIllIIIlIIIl, String lllllllllllllllIIllIIIllIIIlIIII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIllIIIllIIIlIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIIIllIIIlIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIIllIIIllIIIlIlIl = Cipher.getInstance("Blowfish");
        lllllllllllllllIIllIIIllIIIlIlIl.init(lIllIlIllIlI[4], lllllllllllllllIIllIIIllIIIlIllI);
        return new String(lllllllllllllllIIllIIIllIIIlIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIIIllIIIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIllIIIllIIIlIlII)
      {
        lllllllllllllllIIllIIIllIIIlIlII.printStackTrace();
      }
      return null;
    }
    
    protected boolean isSelected(int lllllllllllllllIIllIIIllIlIlIlll)
    {
      ;
      ;
      return mc.getTwitchStream().func_152925_v()[lllllllllllllllIIllIIIllIlIlIlll].serverUrl.equals(mc.gameSettings.streamPreferredServer);
    }
    
    private static void lIIIllIIIIllll()
    {
      lIllIlIllIlI = new int[17];
      lIllIlIllIlI[0] = (0x40 ^ 0x60);
      lIllIlIllIlI[1] = (0x48 ^ 0x6B);
      lIllIlIllIlI[2] = ((0x8C ^ 0x9E) & (0x8B ^ 0x99 ^ 0xFFFFFFFF));
      lIllIlIllIlI[3] = " ".length();
      lIllIlIllIlI[4] = "  ".length();
      lIllIlIllIlI[5] = "   ".length();
      lIllIlIllIlI[6] = (0x41 ^ 0x3B ^ 0xF1 ^ 0x8F);
      lIllIlIllIlI[7] = (0x13 ^ 0x16);
      lIllIlIllIlI[8] = (38 + 37 - -36 + 73 ^ 99 + '°' - 183 + 98);
      lIllIlIllIlI[9] = (0x7A ^ 0x7D);
      lIllIlIllIlI[10] = (0x57 ^ 0x5F);
      lIllIlIllIlI[11] = (0x1E ^ 0x17);
      lIllIlIllIlI[12] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
      lIllIlIllIlI[13] = (0xB336 & 0x307CF9);
      lIllIlIllIlI[14] = (-(0xEFDB & 0x7D7F) & 0xFDDB & 0x80EFFE);
      lIllIlIllIlI[15] = ("  ".length() ^ 0x5E ^ 0x53);
      lIllIlIllIlI[16] = (14 + 35 - -34 + 72 ^ 51 + 99 - 5 + 0);
    }
    
    private static boolean lIIIllIIIlIIll(int ???, int arg1)
    {
      int i;
      long lllllllllllllllIIllIIIlIllllllIl;
      return ??? < i;
    }
    
    public ServerList(Minecraft lllllllllllllllIIllIIIllIllIlIlI)
    {
      lllllllllllllllIIllIIIllIllIlIll.<init>(lllllllllllllllIIllIIIllIllIlIlI, width, height, lIllIlIllIlI[0], height - lIllIlIllIlI[1], (int)(fontRendererObjFONT_HEIGHT * 3.5D));
      lllllllllllllllIIllIIIllIllIlIll.setShowSelectionBox(lIllIlIllIlI[2]);
    }
    
    static
    {
      lIIIllIIIIllll();
      lIIIllIIIIlIlI();
    }
    
    private static String lIIIllIIIIIIlI(String lllllllllllllllIIllIIIllIIIIIllI, String lllllllllllllllIIllIIIllIIIIIlIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIllIIIllIIIIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIIIllIIIIIlIl.getBytes(StandardCharsets.UTF_8)), lIllIlIllIlI[10]), "DES");
        Cipher lllllllllllllllIIllIIIllIIIIlIII = Cipher.getInstance("DES");
        lllllllllllllllIIllIIIllIIIIlIII.init(lIllIlIllIlI[4], lllllllllllllllIIllIIIllIIIIlIIl);
        return new String(lllllllllllllllIIllIIIllIIIIlIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIIIllIIIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIllIIIllIIIIIlll)
      {
        lllllllllllllllIIllIIIllIIIIIlll.printStackTrace();
      }
      return null;
    }
    
    protected int getSize()
    {
      ;
      return mc.getTwitchStream().func_152925_v().length;
    }
    
    private static String lIIIllIIIIIIIl(String lllllllllllllllIIllIIIllIIlIIIll, String lllllllllllllllIIllIIIllIIlIIlll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIIllIIIllIIlIIIll = new String(Base64.getDecoder().decode(lllllllllllllllIIllIIIllIIlIIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIIllIIIllIIlIIllI = new StringBuilder();
      char[] lllllllllllllllIIllIIIllIIlIIlIl = lllllllllllllllIIllIIIllIIlIIlll.toCharArray();
      int lllllllllllllllIIllIIIllIIlIIlII = lIllIlIllIlI[2];
      byte lllllllllllllllIIllIIIllIIIllllI = lllllllllllllllIIllIIIllIIlIIIll.toCharArray();
      byte lllllllllllllllIIllIIIllIIIlllIl = lllllllllllllllIIllIIIllIIIllllI.length;
      byte lllllllllllllllIIllIIIllIIIlllII = lIllIlIllIlI[2];
      while (lIIIllIIIlIIll(lllllllllllllllIIllIIIllIIIlllII, lllllllllllllllIIllIIIllIIIlllIl))
      {
        char lllllllllllllllIIllIIIllIIlIlIIl = lllllllllllllllIIllIIIllIIIllllI[lllllllllllllllIIllIIIllIIIlllII];
        "".length();
        "".length();
        if (((0xC9 ^ 0xC4) & (0xA2 ^ 0xAF ^ 0xFFFFFFFF)) != 0) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIIllIIIllIIlIIllI);
    }
    
    private static boolean lIIIllIIIlIlIl(int ???)
    {
      byte lllllllllllllllIIllIIIlIllllIlIl;
      return ??? != 0;
    }
    
    private static void lIIIllIIIIlIlI()
    {
      lIllIlIlIlll = new String[lIllIlIllIlI[16]];
      lIllIlIlIlll[lIllIlIllIlI[2]] = lIIIllIIIIIIIl("PTkhEgYEIz85HwQ7Dhs=", "aBRft");
      lIllIlIlIlll[lIllIlIllIlI[3]] = lIIIllIIIIIIIl("", "BEbSk");
      lIllIlIlIlll[lIllIlIllIlI[4]] = lIIIllIIIIIIlI("RkDF+8FiuRI=", "WNJVA");
      lIllIlIlIlll[lIllIlIllIlI[5]] = lIIIllIIIIIllI("RkQSbE6PMUc=", "OdIGr");
      lIllIlIlIlll[lIllIlIllIlI[6]] = lIIIllIIIIIIIl("KSQ/NEA=", "mKHZa");
      lIllIlIlIlll[lIllIlIllIlI[7]] = lIIIllIIIIIllI("a4EdOGnIbqw=", "mhYUg");
      lIllIlIlIlll[lIllIlIllIlI[8]] = lIIIllIIIIIllI("6JLuXbBCCJQ=", "KjNJC");
      lIllIlIlIlll[lIllIlIllIlI[9]] = lIIIllIIIIIIlI("ghEkVwx7ysw=", "zsquW");
      lIllIlIlIlll[lIllIlIllIlI[10]] = lIIIllIIIIIIlI("s+AkdDuI4qFXltoKuf4qFw==", "YVttN");
      lIllIlIlIlll[lIllIlIllIlI[11]] = lIIIllIIIIIIIl("eDwEHBQlFBVT", "Pxazu");
    }
    
    private static int lIIIllIIIlIIII(float paramFloat1, float paramFloat2)
    {
      return paramFloat1 < paramFloat2;
    }
    
    protected void drawSlot(int lllllllllllllllIIllIIIllIlIIlIIl, int lllllllllllllllIIllIIIllIIllllII, int lllllllllllllllIIllIIIllIIlllIll, int lllllllllllllllIIllIIIllIlIIIllI, int lllllllllllllllIIllIIIllIlIIIlIl, int lllllllllllllllIIllIIIllIlIIIlII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      IngestServer lllllllllllllllIIllIIIllIlIIIIll = mc.getTwitchStream().func_152925_v()[lllllllllllllllIIllIIIllIlIIlIIl];
      String lllllllllllllllIIllIIIllIlIIIIlI = serverUrl.replaceAll(lIllIlIlIlll[lIllIlIllIlI[2]], lIllIlIlIlll[lIllIlIllIlI[3]]);
      String lllllllllllllllIIllIIIllIlIIIIIl = String.valueOf(new StringBuilder(String.valueOf((int)bitrateKbps)).append(lIllIlIlIlll[lIllIlIllIlI[4]]));
      String lllllllllllllllIIllIIIllIlIIIIII = null;
      IngestServerTester lllllllllllllllIIllIIIllIIllllll = mc.getTwitchStream().func_152932_y();
      if (lIIIllIIIlIIIl(lllllllllllllllIIllIIIllIIllllll))
      {
        if (lIIIllIIIlIIlI(lllllllllllllllIIllIIIllIlIIIIll, lllllllllllllllIIllIIIllIIllllll.func_153040_c()))
        {
          lllllllllllllllIIllIIIllIlIIIIlI = String.valueOf(new StringBuilder().append(EnumChatFormatting.GREEN).append(lllllllllllllllIIllIIIllIlIIIIlI));
          lllllllllllllllIIllIIIllIlIIIIIl = String.valueOf(new StringBuilder(String.valueOf((int)(lllllllllllllllIIllIIIllIIllllll.func_153030_h() * 100.0F))).append(lIllIlIlIlll[lIllIlIllIlI[5]]));
          "".length();
          if ("  ".length() > 0) {}
        }
        else if (lIIIllIIIlIIll(lllllllllllllllIIllIIIllIlIIlIIl, lllllllllllllllIIllIIIllIIllllll.func_153028_p()))
        {
          if (lIIIllIIIlIlII(lIIIllIIIlIIII(bitrateKbps, 0.0F)))
          {
            lllllllllllllllIIllIIIllIlIIIIIl = String.valueOf(new StringBuilder().append(EnumChatFormatting.RED).append(lIllIlIlIlll[lIllIlIllIlI[6]]));
            "".length();
            if (((42 + '¡' - 120 + 101 ^ 27 + '¨' - 188 + 176) & (0xE2 ^ 0xA0 ^ 0x5E ^ 0x13 ^ -" ".length())) == 0) {}
          }
        }
        else
        {
          lllllllllllllllIIllIIIllIlIIIIIl = String.valueOf(new StringBuilder().append(EnumChatFormatting.OBFUSCATED).append(lIllIlIlIlll[lIllIlIllIlI[7]]).append(EnumChatFormatting.RESET).append(lIllIlIlIlll[lIllIlIllIlI[8]]));
          "".length();
          if (((0x72 ^ 0x5E ^ 0xCC ^ 0xB8) & (0x46 ^ 0xD ^ 0x72 ^ 0x61 ^ -" ".length())) >= ((0x4 ^ 0x2E ^ 0x5B ^ 0x30) & (61 + '' - 150 + 209 ^ 31 + '' - 20 + 23 ^ -" ".length()))) {}
        }
      }
      else if (lIIIllIIIlIlII(lIIIllIIIlIIII(bitrateKbps, 0.0F))) {
        lllllllllllllllIIllIIIllIlIIIIIl = String.valueOf(new StringBuilder().append(EnumChatFormatting.RED).append(lIllIlIlIlll[lIllIlIllIlI[9]]));
      }
      lllllllllllllllIIllIIIllIIllllII -= 15;
      if (lIIIllIIIlIlIl(lllllllllllllllIIllIIIllIlIIlIlI.isSelected(lllllllllllllllIIllIIIllIlIIlIIl)))
      {
        lllllllllllllllIIllIIIllIlIIIIII = String.valueOf(new StringBuilder().append(EnumChatFormatting.BLUE).append(lIllIlIlIlll[lIllIlIllIlI[10]]));
        "".length();
        if (('' + '' - 138 + 8 ^ 44 + 29 - -48 + 61) > 0) {}
      }
      else if (lIIIllIIIlIlIl(defaultServer))
      {
        lllllllllllllllIIllIIIllIlIIIIII = String.valueOf(new StringBuilder().append(EnumChatFormatting.GREEN).append(lIllIlIlIlll[lIllIlIllIlI[11]]));
      }
      drawString(fontRendererObj, serverName, lllllllllllllllIIllIIIllIIllllII + lIllIlIllIlI[4], lllllllllllllllIIllIIIllIlIIIlll + lIllIlIllIlI[7], lIllIlIllIlI[12]);
      drawString(fontRendererObj, lllllllllllllllIIllIIIllIlIIIIlI, lllllllllllllllIIllIIIllIIllllII + lIllIlIllIlI[4], lllllllllllllllIIllIIIllIlIIIlll + fontRendererObj.FONT_HEIGHT + lIllIlIllIlI[7] + lIllIlIllIlI[5], lIllIlIllIlI[13]);
      drawString(fontRendererObj, lllllllllllllllIIllIIIllIlIIIIIl, lllllllllllllllIIllIIIllIlIIlIlI.getScrollBarX() - lIllIlIllIlI[7] - fontRendererObj.getStringWidth(lllllllllllllllIIllIIIllIlIIIIIl), lllllllllllllllIIllIIIllIlIIIlll + lIllIlIllIlI[7], lIllIlIllIlI[14]);
      if (lIIIllIIIlIIIl(lllllllllllllllIIllIIIllIlIIIIII)) {
        drawString(fontRendererObj, lllllllllllllllIIllIIIllIlIIIIII, lllllllllllllllIIllIIIllIlIIlIlI.getScrollBarX() - lIllIlIllIlI[7] - fontRendererObj.getStringWidth(lllllllllllllllIIllIIIllIlIIIIII), lllllllllllllllIIllIIIllIlIIIlll + lIllIlIllIlI[7] + lIllIlIllIlI[5] + fontRendererObj.FONT_HEIGHT, lIllIlIllIlI[14]);
      }
    }
    
    private static boolean lIIIllIIIlIIlI(Object ???, Object arg1)
    {
      Object localObject;
      String lllllllllllllllIIllIIIlIllllIlll;
      return ??? == localObject;
    }
  }
}

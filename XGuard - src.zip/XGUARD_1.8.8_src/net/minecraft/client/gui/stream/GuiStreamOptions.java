package net.minecraft.client.gui.stream;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiOptionButton;
import net.minecraft.client.gui.GuiOptionSlider;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.GameSettings.Options;
import net.minecraft.client.stream.IStream;
import net.minecraft.util.EnumChatFormatting;

public class GuiStreamOptions
  extends GuiScreen
{
  private static boolean lIIllIlIllIIl(int ???)
  {
    float llllllllllllllllIlIllIlIlllIllll;
    return ??? != 0;
  }
  
  private static boolean lIIllIlIlllII(int ???)
  {
    int llllllllllllllllIlIllIlIlllIlIll;
    return ??? <= 0;
  }
  
  private static String lIIllIlIlIlIl(String llllllllllllllllIlIllIllIIIIlIIl, String llllllllllllllllIlIllIllIIIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIlIllIllIIIIlIIl = new String(Base64.getDecoder().decode(llllllllllllllllIlIllIllIIIIlIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIlIllIllIIIIllII = new StringBuilder();
    char[] llllllllllllllllIlIllIllIIIIlIll = llllllllllllllllIlIllIllIIIIllIl.toCharArray();
    int llllllllllllllllIlIllIllIIIIlIlI = llIIlIlllII[1];
    int llllllllllllllllIlIllIllIIIIIlII = llllllllllllllllIlIllIllIIIIlIIl.toCharArray();
    byte llllllllllllllllIlIllIllIIIIIIll = llllllllllllllllIlIllIllIIIIIlII.length;
    String llllllllllllllllIlIllIllIIIIIIlI = llIIlIlllII[1];
    while (lIIllIlIllllI(llllllllllllllllIlIllIllIIIIIIlI, llllllllllllllllIlIllIllIIIIIIll))
    {
      char llllllllllllllllIlIllIllIIIIllll = llllllllllllllllIlIllIllIIIIIlII[llllllllllllllllIlIllIllIIIIIIlI];
      "".length();
      "".length();
      if ("   ".length() <= -" ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIlIllIllIIIIllII);
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    ;
    int llllllllllllllllIlIllIllIlIIIlII = llIIlIlllII[1];
    field_152319_i = I18n.format(llIIlIllIll[llIIlIlllII[1]], new Object[llIIlIlllII[1]]);
    field_152313_r = I18n.format(llIIlIllIll[llIIlIlllII[2]], new Object[llIIlIlllII[1]]);
    float llllllllllllllllIlIllIllIIllllII = (llllllllllllllllIlIllIllIIlllIll = field_152312_a).length;
    Exception llllllllllllllllIlIllIllIIllllIl = llIIlIlllII[1];
    "".length();
    if (("   ".length() & ("   ".length() ^ 0xFFFFFFFF)) == " ".length()) {
      return;
    }
    while (!lIIllIlIllIlI(llllllllllllllllIlIllIllIIllllIl, llllllllllllllllIlIllIllIIllllII))
    {
      GameSettings.Options llllllllllllllllIlIllIllIlIIIIll = llllllllllllllllIlIllIllIIlllIll[llllllllllllllllIlIllIllIIllllIl];
      if (lIIllIlIllIIl(llllllllllllllllIlIllIllIlIIIIll.getEnumFloat()))
      {
        new GuiOptionSlider(llllllllllllllllIlIllIllIlIIIIll.returnEnumOrdinal(), width / llIIlIlllII[3] - llIIlIlllII[9] + llllllllllllllllIlIllIllIlIIIlII % llIIlIlllII[3] * llIIlIlllII[10], height / llIIlIlllII[7] + llIIlIlllII[11] * (llllllllllllllllIlIllIllIlIIIlII >> llIIlIlllII[2]), llllllllllllllllIlIllIllIlIIIIll);
        "".length();
        "".length();
        if (" ".length() != 0) {}
      }
      else
      {
        new GuiOptionButton(llllllllllllllllIlIllIllIlIIIIll.returnEnumOrdinal(), width / llIIlIlllII[3] - llIIlIlllII[9] + llllllllllllllllIlIllIllIlIIIlII % llIIlIlllII[3] * llIIlIlllII[10], height / llIIlIlllII[7] + llIIlIlllII[11] * (llllllllllllllllIlIllIllIlIIIlII >> llIIlIlllII[2]), llllllllllllllllIlIllIllIlIIIIll, field_152318_h.getKeyBinding(llllllllllllllllIlIllIllIlIIIIll));
        "".length();
      }
      llllllllllllllllIlIllIllIlIIIlII++;
    }
    llllllllllllllllIlIllIllIIllllIl++;
    if (lIIllIlIllIll(llllllllllllllllIlIllIllIlIIIlII % llIIlIlllII[3], llIIlIlllII[2])) {}
    field_152314_s = (height / llIIlIlllII[7] + llIIlIlllII[11] * (llllllllllllllllIlIllIllIlIIIlII >> llIIlIlllII[2]) + llIIlIlllII[7]);
    llllllllllllllllIlIllIllIlIIIlII += 2;
    llllllllllllllllIlIllIllIIllllII = (llllllllllllllllIlIllIllIIlllIll = field_152316_f).length;
    llllllllllllllllIlIllIllIIllllIl = llIIlIlllII[1];
    "".length();
    if ("  ".length() > "  ".length()) {
      return;
    }
    while (!lIIllIlIllIlI(llllllllllllllllIlIllIllIIllllIl, llllllllllllllllIlIllIllIIllllII))
    {
      GameSettings.Options llllllllllllllllIlIllIllIlIIIIlI = llllllllllllllllIlIllIllIIlllIll[llllllllllllllllIlIllIllIIllllIl];
      if (lIIllIlIllIIl(llllllllllllllllIlIllIllIlIIIIlI.getEnumFloat()))
      {
        new GuiOptionSlider(llllllllllllllllIlIllIllIlIIIIlI.returnEnumOrdinal(), width / llIIlIlllII[3] - llIIlIlllII[9] + llllllllllllllllIlIllIllIlIIIlII % llIIlIlllII[3] * llIIlIlllII[10], height / llIIlIlllII[7] + llIIlIlllII[11] * (llllllllllllllllIlIllIllIlIIIlII >> llIIlIlllII[2]), llllllllllllllllIlIllIllIlIIIIlI);
        "".length();
        "".length();
        if ((99 + 111 - 174 + 101 ^ 19 + '' - 86 + 74) > 0) {}
      }
      else
      {
        new GuiOptionButton(llllllllllllllllIlIllIllIlIIIIlI.returnEnumOrdinal(), width / llIIlIlllII[3] - llIIlIlllII[9] + llllllllllllllllIlIllIllIlIIIlII % llIIlIlllII[3] * llIIlIlllII[10], height / llIIlIlllII[7] + llIIlIlllII[11] * (llllllllllllllllIlIllIllIlIIIlII >> llIIlIlllII[2]), llllllllllllllllIlIllIllIlIIIIlI, field_152318_h.getKeyBinding(llllllllllllllllIlIllIllIlIIIIlI));
        "".length();
      }
      llllllllllllllllIlIllIllIlIIIlII++;
    }
    new GuiButton(llIIlIlllII[12], width / llIIlIlllII[3] - llIIlIlllII[9], height / llIIlIlllII[7] + llIIlIlllII[13], llIIlIlllII[14], llIIlIlllII[15], I18n.format(llIIlIllIll[llIIlIlllII[3]], new Object[llIIlIlllII[1]]));
    "".length();
    GuiButton llllllllllllllllIlIllIllIlIIIIIl = new GuiButton(llIIlIlllII[16], width / llIIlIlllII[3] + llIIlIlllII[6], height / llIIlIlllII[7] + llIIlIlllII[13], llIIlIlllII[14], llIIlIlllII[15], I18n.format(llIIlIllIll[llIIlIlllII[4]], new Object[llIIlIlllII[1]]));
    if (((!lIIllIlIllIIl(mc.getTwitchStream().isReadyToBroadcast())) || (lIIllIlIlllII(mc.getTwitchStream().func_152925_v().length))) && (lIIllIlIlllIl(mc.getTwitchStream().func_152908_z())))
    {
      "".length();
      if ((0x4E ^ 0x4A) >= 0) {
        break label916;
      }
    }
    label916:
    llIIlIlllII1enabled = llIIlIlllII[2];
    "".length();
  }
  
  static
  {
    lIIllIlIllIII();
    lIIllIlIlIlll();
    field_152312_a = new GameSettings.Options[] { GameSettings.Options.STREAM_BYTES_PER_PIXEL, GameSettings.Options.STREAM_FPS, GameSettings.Options.STREAM_KBPS, GameSettings.Options.STREAM_SEND_METADATA, GameSettings.Options.STREAM_VOLUME_MIC, GameSettings.Options.STREAM_VOLUME_SYSTEM, GameSettings.Options.STREAM_MIC_TOGGLE_BEHAVIOR, GameSettings.Options.STREAM_COMPRESSION };
  }
  
  private static String lIIllIlIlIllI(String llllllllllllllllIlIllIllIIIllllI, String llllllllllllllllIlIllIllIIIllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIlIllIllIIlIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlIllIllIIIllIll.getBytes(StandardCharsets.UTF_8)), llIIlIlllII[0]), "DES");
      Cipher llllllllllllllllIlIllIllIIlIIIII = Cipher.getInstance("DES");
      llllllllllllllllIlIllIllIIlIIIII.init(llIIlIlllII[3], llllllllllllllllIlIllIllIIlIIIIl);
      return new String(llllllllllllllllIlIllIllIIlIIIII.doFinal(Base64.getDecoder().decode(llllllllllllllllIlIllIllIIIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIlIllIllIIIlllll)
    {
      llllllllllllllllIlIllIllIIIlllll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIllIlIllIll(int ???, int arg1)
  {
    int i;
    short llllllllllllllllIlIllIlIllllllIl;
    return ??? == i;
  }
  
  protected void actionPerformed(GuiButton llllllllllllllllIlIllIllIIllIllI)
    throws IOException
  {
    ;
    ;
    ;
    if (lIIllIlIllIIl(enabled))
    {
      if ((lIIllIlIllllI(id, llIIlIlllII[17])) && (lIIllIlIllIIl(llllllllllllllllIlIllIllIIllIllI instanceof GuiOptionButton)))
      {
        GameSettings.Options llllllllllllllllIlIllIllIIllIlIl = ((GuiOptionButton)llllllllllllllllIlIllIllIIllIllI).returnEnumOptions();
        field_152318_h.setOptionValue(llllllllllllllllIlIllIllIIllIlIl, llIIlIlllII[2]);
        displayString = field_152318_h.getKeyBinding(GameSettings.Options.getEnumOptions(id));
        if ((lIIllIlIllIIl(mc.getTwitchStream().isBroadcasting())) && (lIIllIlIlllll(llllllllllllllllIlIllIllIIllIlIl, GameSettings.Options.STREAM_CHAT_ENABLED)) && (lIIllIlIlllll(llllllllllllllllIlIllIllIIllIlIl, GameSettings.Options.STREAM_CHAT_USER_FILTER)))
        {
          field_152315_t = llIIlIlllII[2];
          "".length();
          if (" ".length() > 0) {}
        }
      }
      else if (lIIllIlIllIIl(llllllllllllllllIlIllIllIIllIllI instanceof GuiOptionSlider))
      {
        if (lIIllIlIllIll(id, GameSettings.Options.STREAM_VOLUME_MIC.returnEnumOrdinal()))
        {
          mc.getTwitchStream().updateStreamVolume();
          "".length();
          if (null == null) {}
        }
        else if (lIIllIlIllIll(id, GameSettings.Options.STREAM_VOLUME_SYSTEM.returnEnumOrdinal()))
        {
          mc.getTwitchStream().updateStreamVolume();
          "".length();
          if (-" ".length() < 0) {}
        }
        else if (lIIllIlIllIIl(mc.getTwitchStream().isBroadcasting()))
        {
          field_152315_t = llIIlIlllII[2];
        }
      }
      if (lIIllIlIllIll(id, llIIlIlllII[12]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(parentScreen);
        "".length();
        if ("   ".length() > "  ".length()) {}
      }
      else if (lIIllIlIllIll(id, llIIlIlllII[16]))
      {
        mc.gameSettings.saveOptions();
        mc.displayGuiScreen(new GuiIngestServers(llllllllllllllllIlIllIllIIllIlII));
      }
    }
  }
  
  private static boolean lIIllIlIllllI(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllIlIllIlIllllIlIl;
    return ??? < i;
  }
  
  public GuiStreamOptions(GuiScreen llllllllllllllllIlIllIllIlIlIIII, GameSettings llllllllllllllllIlIllIllIlIIllII)
  {
    parentScreen = llllllllllllllllIlIllIllIlIIllIl;
    field_152318_h = llllllllllllllllIlIllIllIlIIllII;
  }
  
  private static boolean lIIllIlIlllll(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllllIlIllIlIllllIIIl;
    return ??? != localObject;
  }
  
  public void drawScreen(int llllllllllllllllIlIllIllIIlIllII, int llllllllllllllllIlIllIllIIlIIlll, float llllllllllllllllIlIllIllIIlIlIlI)
  {
    ;
    ;
    ;
    ;
    llllllllllllllllIlIllIllIIlIlIIl.drawDefaultBackground();
    llllllllllllllllIlIllIllIIlIlIIl.drawCenteredString(fontRendererObj, field_152319_i, width / llIIlIlllII[3], llIIlIlllII[15], llIIlIlllII[18]);
    llllllllllllllllIlIllIllIIlIlIIl.drawCenteredString(fontRendererObj, field_152313_r, width / llIIlIlllII[3], field_152314_s, llIIlIlllII[18]);
    if (lIIllIlIllIIl(field_152315_t)) {
      llllllllllllllllIlIllIllIIlIlIIl.drawCenteredString(fontRendererObj, String.valueOf(new StringBuilder().append(EnumChatFormatting.RED).append(I18n.format(llIIlIllIll[llIIlIlllII[5]], new Object[llIIlIlllII[1]]))), width / llIIlIlllII[3], llIIlIlllII[15] + fontRendererObj.FONT_HEIGHT, llIIlIlllII[18]);
    }
    llllllllllllllllIlIllIllIIlIlIIl.drawScreen(llllllllllllllllIlIllIllIIlIllII, llllllllllllllllIlIllIllIIlIIlll, llllllllllllllllIlIllIllIIlIlIlI);
  }
  
  private static void lIIllIlIllIII()
  {
    llIIlIlllII = new int[19];
    llIIlIlllII[0] = (0x83 ^ 0x8B);
    llIIlIlllII[1] = ((0x3C ^ 0xD) & (0x28 ^ 0x19 ^ 0xFFFFFFFF));
    llIIlIlllII[2] = " ".length();
    llIIlIlllII[3] = "  ".length();
    llIIlIlllII[4] = "   ".length();
    llIIlIlllII[5] = (0xA5 ^ 0x8C ^ 0xA6 ^ 0x8B);
    llIIlIlllII[6] = (123 + 85 - 102 + 37 ^ '' + 56 - 94 + 41);
    llIIlIlllII[7] = (0xB0 ^ 0xB6);
    llIIlIlllII[8] = ('£' + '§' - 266 + 116 ^ 9 + 94 - -6 + 70);
    llIIlIlllII[9] = (116 + 104 - 121 + 56);
    llIIlIlllII[10] = ((0x67 ^ 0x3) + (0x64 ^ 0x2A) - (0x4F ^ 0x3F) + (0xF3 ^ 0xAD));
    llIIlIlllII[11] = (0xAB ^ 0xB3);
    llIIlIlllII[12] = ((0xA3 ^ 0xB4) + (0x44 ^ 0x1D) - -(0xA5 ^ 0xA2) + (0x75 ^ 0x24));
    llIIlIlllII[13] = ('¦' + 71 - 200 + 131);
    llIIlIlllII[14] = (31 + 50 - -63 + 6);
    llIIlIlllII[15] = (0x1D ^ 0x17 ^ 0x4 ^ 0x1A);
    llIIlIlllII[16] = ((0xD6 ^ 0xB6) + (0x70 ^ 0x5F) - -(0x96 ^ 0xB7) + (0x62 ^ 0x7B));
    llIIlIlllII[17] = (0x71 ^ 0x15);
    llIIlIlllII[18] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
  }
  
  private static boolean lIIllIlIlllIl(int ???)
  {
    char llllllllllllllllIlIllIlIlllIllIl;
    return ??? == 0;
  }
  
  private static boolean lIIllIlIllIlI(int ???, int arg1)
  {
    int i;
    byte llllllllllllllllIlIllIlIlllllIIl;
    return ??? >= i;
  }
  
  private static void lIIllIlIlIlll()
  {
    llIIlIllIll = new String[llIIlIlllII[6]];
    llIIlIllIll[llIIlIlllII[1]] = lIIllIlIlIlIl("HBMlCxwdEH8RBwEGMA9dBwolDhY=", "scQbs");
    llIIlIllIll[llIIlIlllII[2]] = lIIllIlIlIllI("PRAhqSahY0P/7UlHwUwlgeJqkpJ21iyI2JR6XHGUQnA=", "MjksK");
    llIIlIllIll[llIIlIlllII[3]] = lIIllIlIlIlIl("JDkYQT0sIhQ=", "CLqoY");
    llIIlIllIll[llIIlIlllII[4]] = lIIllIlIlIllI("qbJStgJgUmJ2QuQSZh+vw8YcRcm6EcZIB8xSsiEHYR8=", "vCyXo");
    llIIlIllIll[llIIlIlllII[5]] = lIIllIlIlIllI("+1A9v5S788B8l7VhESDHOeVfZ3EfP9zi", "YeDCZ");
  }
}

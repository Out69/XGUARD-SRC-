package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.spectator.ISpectatorMenuObject;
import net.minecraft.client.gui.spectator.ISpectatorMenuRecipient;
import net.minecraft.client.gui.spectator.ISpectatorMenuView;
import net.minecraft.client.gui.spectator.SpectatorMenu;
import net.minecraft.client.gui.spectator.categories.SpectatorDetails;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;

public class GuiSpectator
  extends Gui
  implements ISpectatorMenuRecipient
{
  private static String lIlIlIlllllIII(String llllllllllllllIlllIlllIllIlIlIII, String llllllllllllllIlllIlllIllIlIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlllIlllIllIlIlIII = new String(Base64.getDecoder().decode(llllllllllllllIlllIlllIllIlIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlllIlllIllIlIIllI = new StringBuilder();
    char[] llllllllllllllIlllIlllIllIlIIlIl = llllllllllllllIlllIlllIllIlIIIlI.toCharArray();
    int llllllllllllllIlllIlllIllIlIIlII = lllIIIIlIlII[0];
    Exception llllllllllllllIlllIlllIllIIllllI = llllllllllllllIlllIlllIllIlIlIII.toCharArray();
    short llllllllllllllIlllIlllIllIIlllIl = llllllllllllllIlllIlllIllIIllllI.length;
    Exception llllllllllllllIlllIlllIllIIlllII = lllIIIIlIlII[0];
    while (lIlIllIIIIIlIl(llllllllllllllIlllIlllIllIIlllII, llllllllllllllIlllIlllIllIIlllIl))
    {
      char llllllllllllllIlllIlllIllIlIlIIl = llllllllllllllIlllIlllIllIIllllI[llllllllllllllIlllIlllIllIIlllII];
      "".length();
      "".length();
      if (-"   ".length() >= 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlllIlllIllIlIIllI);
  }
  
  public void func_175260_a(int llllllllllllllIlllIllllIIIlIlIlI)
  {
    ;
    ;
    field_175270_h = Minecraft.getSystemTime();
    if (lIlIlIlllllIll(field_175271_i))
    {
      field_175271_i.func_178644_b(llllllllllllllIlllIllllIIIlIlIlI);
      "".length();
      if ((0x95 ^ 0x91) != " ".length()) {}
    }
    else
    {
      field_175271_i = new SpectatorMenu(llllllllllllllIlllIllllIIIlIlIIl);
    }
  }
  
  private static boolean lIlIllIIIIIlII(int ???, int arg1)
  {
    int i;
    short llllllllllllllIlllIlllIlIllllIll;
    return ??? != i;
  }
  
  static
  {
    lIlIlIlllllIlI();
    lIlIlIlllllIIl();
  }
  
  public void func_175257_a(SpectatorMenu llllllllllllllIlllIlllIlllIIIllI)
  {
    ;
    field_175271_i = null;
    field_175270_h = 0L;
  }
  
  protected void func_175258_a(ScaledResolution llllllllllllllIlllIllllIIIIIIlII, float llllllllllllllIlllIllllIIIIIIIll, int llllllllllllllIlllIllllIIIIIIIlI, float llllllllllllllIlllIllllIIIIIIIIl, SpectatorDetails llllllllllllllIlllIllllIIIIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.enableRescaleNormal();
    GlStateManager.enableBlend();
    GlStateManager.tryBlendFuncSeparate(lllIIIIlIlII[3], lllIIIIlIlII[4], lllIIIIlIlII[1], lllIIIIlIlII[0]);
    GlStateManager.color(1.0F, 1.0F, 1.0F, llllllllllllllIlllIllllIIIIIIIll);
    field_175268_g.getTextureManager().bindTexture(field_175267_f);
    llllllllllllllIlllIllllIIIIIIlIl.drawTexturedModalRect(llllllllllllllIlllIlllIlllllllII - lllIIIIlIlII[5], llllllllllllllIlllIllllIIIIIIIIl, lllIIIIlIlII[0], lllIIIIlIlII[0], lllIIIIlIlII[6], lllIIIIlIlII[7]);
    if (lIlIlIlllllllI(llllllllllllllIlllIllllIIIIIIIII.func_178681_b())) {
      llllllllllllllIlllIllllIIIIIIlIl.drawTexturedModalRect(llllllllllllllIlllIlllIlllllllII - lllIIIIlIlII[5] - lllIIIIlIlII[1] + llllllllllllllIlllIllllIIIIIIIII.func_178681_b() * lllIIIIlIlII[8], llllllllllllllIlllIllllIIIIIIIIl - 1.0F, lllIIIIlIlII[0], lllIIIIlIlII[7], lllIIIIlIlII[9], lllIIIIlIlII[7]);
    }
    RenderHelper.enableGUIStandardItemLighting();
    int llllllllllllllIlllIlllIlllllllll = lllIIIIlIlII[0];
    "".length();
    if ("   ".length() <= "  ".length()) {
      return;
    }
    while (!lIlIlIllllllll(llllllllllllllIlllIlllIlllllllll, lllIIIIlIlII[11]))
    {
      llllllllllllllIlllIllllIIIIIIlIl.func_175266_a(llllllllllllllIlllIlllIlllllllll, ScaledResolution.getScaledWidth() / lllIIIIlIlII[2] - lllIIIIlIlII[10] + llllllllllllllIlllIlllIlllllllll * lllIIIIlIlII[8] + lllIIIIlIlII[2], llllllllllllllIlllIllllIIIIIIIIl + 3.0F, llllllllllllllIlllIllllIIIIIIIll, llllllllllllllIlllIllllIIIIIIIII.func_178680_a(llllllllllllllIlllIlllIlllllllll));
      llllllllllllllIlllIlllIlllllllll++;
    }
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.disableBlend();
  }
  
  private static boolean lIlIllIIIIIIll(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlllIlllIllIIIllll;
    return ??? <= i;
  }
  
  public void func_175261_b()
  {
    ;
    ;
    field_175270_h = Minecraft.getSystemTime();
    if (lIlIllIIIIIIIl(llllllllllllllIlllIlllIllIllIlII.func_175262_a()))
    {
      int llllllllllllllIlllIlllIllIllIlIl = field_175271_i.func_178648_e();
      if (lIlIllIIIIIlII(llllllllllllllIlllIlllIllIllIlIl, lllIIIIlIlII[17]))
      {
        field_175271_i.func_178644_b(llllllllllllllIlllIlllIllIllIlIl);
        "".length();
        if (" ".length() > ((0x4C ^ 0x71) & (0x8 ^ 0x35 ^ 0xFFFFFFFF))) {}
      }
    }
    else
    {
      field_175271_i = new SpectatorMenu(llllllllllllllIlllIlllIllIllIlII);
    }
  }
  
  private static boolean lIlIllIIIIIIII(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllIlllIlllIllIIIIlll;
    return ??? != localObject;
  }
  
  private static int lIlIlIllllllII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIlIlIlllllIll(Object ???)
  {
    long llllllllllllllIlllIlllIllIIIIlIl;
    return ??? != null;
  }
  
  private static boolean lIlIllIIIIIIlI(int ???, int arg1)
  {
    int i;
    double llllllllllllllIlllIlllIllIIIlIll;
    return ??? > i;
  }
  
  private static boolean lIlIlIllllllIl(int ???)
  {
    double llllllllllllllIlllIlllIlIlllllll;
    return ??? <= 0;
  }
  
  public void renderTooltip(ScaledResolution llllllllllllllIlllIllllIIIIllIIl, float llllllllllllllIlllIllllIIIIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIlIlllllIll(field_175271_i))
    {
      float llllllllllllllIlllIllllIIIIlIlll = llllllllllllllIlllIllllIIIIllIlI.func_175265_c();
      if (lIlIlIllllllIl(lIlIlIllllllII(llllllllllllllIlllIllllIIIIlIlll, 0.0F)))
      {
        field_175271_i.func_178641_d();
        "".length();
        if ("   ".length() <= (0x4C ^ 0x48)) {}
      }
      else
      {
        int llllllllllllllIlllIllllIIIIlIllI = ScaledResolution.getScaledWidth() / lllIIIIlIlII[2];
        float llllllllllllllIlllIllllIIIIlIlIl = zLevel;
        zLevel = -90.0F;
        float llllllllllllllIlllIllllIIIIlIlII = llllllllllllllIlllIllllIIIIlIIIl.getScaledHeight() - 22.0F * llllllllllllllIlllIllllIIIIlIlll;
        SpectatorDetails llllllllllllllIlllIllllIIIIlIIll = field_175271_i.func_178646_f();
        llllllllllllllIlllIllllIIIIllIlI.func_175258_a(llllllllllllllIlllIllllIIIIlIIIl, llllllllllllllIlllIllllIIIIlIlll, llllllllllllllIlllIllllIIIIlIllI, llllllllllllllIlllIllllIIIIlIlII, llllllllllllllIlllIllllIIIIlIIll);
        zLevel = llllllllllllllIlllIllllIIIIlIlIl;
      }
    }
  }
  
  private void func_175266_a(int llllllllllllllIlllIlllIllllIIlIl, int llllllllllllllIlllIlllIllllIIlII, float llllllllllllllIlllIlllIllllIllII, float llllllllllllllIlllIlllIllllIlIll, ISpectatorMenuObject llllllllllllllIlllIlllIllllIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    field_175268_g.getTextureManager().bindTexture(field_175269_a);
    if (lIlIllIIIIIIII(llllllllllllllIlllIlllIllllIIIIl, SpectatorMenu.field_178657_a))
    {
      int llllllllllllllIlllIlllIllllIlIIl = (int)(llllllllllllllIlllIlllIllllIlIll * 255.0F);
      GlStateManager.pushMatrix();
      GlStateManager.translate(llllllllllllllIlllIlllIllllIIlII, llllllllllllllIlllIlllIllllIllII, 0.0F);
      if (lIlIllIIIIIIIl(llllllllllllllIlllIlllIllllIIIIl.func_178662_A_()))
      {
        "".length();
        if (-(36 + 41 - 38 + 105 ^ 89 + 9 - 73 + 123) <= 0) {
          break label94;
        }
      }
      label94:
      float llllllllllllllIlllIlllIllllIlIII = 0.25F;
      GlStateManager.color(llllllllllllllIlllIlllIllllIlIII, llllllllllllllIlllIlllIllllIlIII, llllllllllllllIlllIlllIllllIlIII, llllllllllllllIlllIlllIllllIlIll);
      llllllllllllllIlllIlllIllllIIIIl.func_178663_a(llllllllllllllIlllIlllIllllIlIII, llllllllllllllIlllIlllIllllIlIIl);
      GlStateManager.popMatrix();
      String llllllllllllllIlllIlllIllllIIlll = String.valueOf(GameSettings.getKeyDisplayString(field_175268_g.gameSettings.keyBindsHotbar[llllllllllllllIlllIlllIllllIIlIl].getKeyCode()));
      if ((lIlIllIIIIIIlI(llllllllllllllIlllIlllIllllIlIIl, lllIIIIlIlII[12])) && (lIlIllIIIIIIIl(llllllllllllllIlllIlllIllllIIIIl.func_178662_A_()))) {
        "".length();
      }
    }
  }
  
  private static boolean lIlIlIlllllllI(int ???)
  {
    byte llllllllllllllIlllIlllIllIIIIIIl;
    return ??? >= 0;
  }
  
  private static boolean lIlIllIIIIIIIl(int ???)
  {
    short llllllllllllllIlllIlllIllIIIIIll;
    return ??? != 0;
  }
  
  private static boolean lIlIlIllllllll(int ???, int arg1)
  {
    int i;
    int llllllllllllllIlllIlllIllIIlIlll;
    return ??? >= i;
  }
  
  public void func_175259_b(int llllllllllllllIlllIlllIllIllllIl)
  {
    ;
    ;
    ;
    int llllllllllllllIlllIlllIllIllllII = field_175271_i.func_178648_e() + llllllllllllllIlllIlllIllIllllIl;
    "".length();
    if (-"  ".length() >= 0) {
      return;
    }
    while ((lIlIlIlllllllI(llllllllllllllIlllIlllIllIllllII)) && (lIlIllIIIIIIll(llllllllllllllIlllIlllIllIllllII, lllIIIIlIlII[16])) && ((!lIlIllIIIIIIII(field_175271_i.func_178643_a(llllllllllllllIlllIlllIllIllllII), SpectatorMenu.field_178657_a)) || (!lIlIllIIIIIIIl(field_175271_i.func_178643_a(llllllllllllllIlllIlllIllIllllII).func_178662_A_())))) {
      llllllllllllllIlllIlllIllIllllII += llllllllllllllIlllIlllIllIllllIl;
    }
    if ((lIlIlIlllllllI(llllllllllllllIlllIlllIllIllllII)) && (lIlIllIIIIIIll(llllllllllllllIlllIlllIllIllllII, lllIIIIlIlII[16])))
    {
      field_175271_i.func_178644_b(llllllllllllllIlllIlllIllIllllII);
      field_175270_h = Minecraft.getSystemTime();
    }
  }
  
  private static boolean lIlIllIIIIIlIl(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIlllIlllIllIIlIIll;
    return ??? < i;
  }
  
  private float func_175265_c()
  {
    ;
    ;
    long llllllllllllllIlllIllllIIIlIIlII = field_175270_h - Minecraft.getSystemTime() + 5000L;
    return MathHelper.clamp_float((float)llllllllllllllIlllIllllIIIlIIlII / 2000.0F, 0.0F, 1.0F);
  }
  
  public GuiSpectator(Minecraft llllllllllllllIlllIllllIIIlIlllI)
  {
    field_175268_g = llllllllllllllIlllIllllIIIlIlllI;
  }
  
  public boolean func_175262_a()
  {
    ;
    if (lIlIlIlllllIll(field_175271_i)) {
      return lllIIIIlIlII[1];
    }
    return lllIIIIlIlII[0];
  }
  
  public void func_175263_a(ScaledResolution llllllllllllllIlllIlllIlllIlIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlllIlllIlllIlIlII = (int)(llllllllllllllIlllIlllIlllIIllll.func_175265_c() * 255.0F);
    if ((lIlIllIIIIIIlI(llllllllllllllIlllIlllIlllIlIlII, lllIIIIlIlII[12])) && (lIlIlIlllllIll(field_175271_i)))
    {
      ISpectatorMenuObject llllllllllllllIlllIlllIlllIlIIll = field_175271_i.func_178645_b();
      if (lIlIllIIIIIIII(llllllllllllllIlllIlllIlllIlIIll, SpectatorMenu.field_178657_a))
      {
        "".length();
        if ((0x1F ^ 0x47 ^ 0x4F ^ 0x13) != " ".length()) {
          break label105;
        }
      }
      label105:
      String llllllllllllllIlllIlllIlllIlIIlI = field_175271_i.func_178650_c().func_178670_b().getFormattedText();
      if (lIlIlIlllllIll(llllllllllllllIlllIlllIlllIlIIlI))
      {
        int llllllllllllllIlllIlllIlllIlIIIl = (ScaledResolution.getScaledWidth() - Minecraft.fontRendererObj.getStringWidth(llllllllllllllIlllIlllIlllIlIIlI)) / lllIIIIlIlII[2];
        int llllllllllllllIlllIlllIlllIlIIII = llllllllllllllIlllIlllIlllIlIlIl.getScaledHeight() - lllIIIIlIlII[15];
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(lllIIIIlIlII[3], lllIIIIlIlII[4], lllIIIIlIlII[1], lllIIIIlIlII[0]);
        "".length();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
      }
    }
  }
  
  private static void lIlIlIlllllIlI()
  {
    lllIIIIlIlII = new int[18];
    lllIIIIlIlII[0] = (('' + '¬' - 218 + 88 ^ 27 + 21 - -55 + 66) & (27 + 13 - -85 + 13 ^ 108 + '' - 195 + 94 ^ -" ".length()));
    lllIIIIlIlII[1] = " ".length();
    lllIIIIlIlII[2] = "  ".length();
    lllIIIIlIlII[3] = (0xCFD6 & 0x332B);
    lllIIIIlIlII[4] = (0xBF47 & 0x43BB);
    lllIIIIlIlII[5] = (73 + 69 - -10 + 66 ^ 122 + '' - 140 + 19);
    lllIIIIlIlII[6] = (25 + '' - 148 + 151);
    lllIIIIlIlII[7] = (0x72 ^ 0x65 ^ " ".length());
    lllIIIIlIlII[8] = (0x7F ^ 0x6B);
    lllIIIIlIlII[9] = (45 + 37 - -52 + 21 ^ 75 + 115 - 95 + 36);
    lllIIIIlIlII[10] = (0xE ^ 0x54);
    lllIIIIlIlII[11] = (0x60 ^ 0x69);
    lllIIIIlIlII[12] = "   ".length();
    lllIIIIlIlII[13] = (0x25 ^ 0x36);
    lllIIIIlIlII[14] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lllIIIIlIlII[15] = (0x29 ^ 0xA);
    lllIIIIlIlII[16] = (123 + '' - 159 + 65 ^ '' + ' ' - 270 + 135);
    lllIIIIlIlII[17] = (-" ".length());
  }
  
  private static void lIlIlIlllllIIl()
  {
    lllIIIIlIIll = new String[lllIIIIlIlII[2]];
    lllIIIIlIIll[lllIIIIlIlII[0]] = lIlIlIlllllIII("DScgPRMLJytmAQwrdz4PHSU9PRVXMjYu", "yBXIf");
    lllIIIIlIIll[lllIIIIlIlII[1]] = lIlIlIlllllIII("FygPHRwRKARGDhYkWBoZBi4DCB0MPygeAAcqEh0aTT0ZDg==", "cMwii");
  }
}

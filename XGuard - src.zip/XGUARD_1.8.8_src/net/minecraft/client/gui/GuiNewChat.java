package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EntityPlayer.EnumChatVisibility;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import org.apache.logging.log4j.Logger;
import pl.xguard.modules.BackgroundChatModule;

public class GuiNewChat
  extends Gui
{
  public static int calculateChatboxWidth(float llllllllllllllIllIIlIIIIllIIIIIl)
  {
    ;
    ;
    ;
    int llllllllllllllIllIIlIIIIllIIIIII = lllllIllllII[18];
    int llllllllllllllIllIIlIIIIlIllllll = lllllIllllII[19];
    return MathHelper.floor_float(llllllllllllllIllIIlIIIIlIlllllI * (llllllllllllllIllIIlIIIIllIIIIII - llllllllllllllIllIIlIIIIlIllllll) + llllllllllllllIllIIlIIIIlIllllll);
  }
  
  private static void lIllllllllllIl()
  {
    lllllIllllII = new int[22];
    lllllIllllII[0] = (("  ".length() ^ 0x62 ^ 0x5C) & (' ' + 127 - 271 + 146 ^ 54 + 105 - 41 + 40 ^ -" ".length()));
    lllllIllllII[1] = " ".length();
    lllllIllllII[2] = ((0x80 ^ 0xA9) + (0x31 ^ 0x1E) - -(0x4 ^ 0xB) + (0xDD ^ 0xBC));
    lllllIllllII[3] = (99 + 66 - 59 + 123 + (0xD0 ^ 0xA5) - (0x85BD & 0x7B46) + (118 + 39 - 92 + 104));
    lllllIllllII[4] = "   ".length();
    lllllIllllII[5] = (0xC5 ^ 0x9B ^ 0xF4 ^ 0xA3);
    lllllIllllII[6] = (0x28 ^ 0x2C);
    lllllIllllII[7] = "  ".length();
    lllllIllllII[8] = (80 + '±' - 45 + 4 ^ 67 + '' - 201 + 171);
    lllllIllllII[9] = (0xCF ^ 0xC7);
    lllllIllllII[10] = (0xFFFFFFFF & 0xFFFFFF);
    lllllIllllII[11] = ((0xEA ^ 0x81) + (0x34 ^ 0x0) - (0x5B ^ 0x36) + (0x25 ^ 0x5D));
    lllllIllllII[12] = ('' + 66 - 21 + 36 ^ 15 + 111 - 34 + 36);
    lllllIllllII[13] = (0xBB3B & 0xCC77F7);
    lllllIllllII[14] = (-(0xED1F & 0x5AF1) & 0xFBBA & 0x337FFF);
    lllllIllllII[15] = (-(0x91F7 & 0x7F39) & 0xFFFFFFFE & 0xCCDDFD);
    lllllIllllII[16] = (0x51 ^ 0x35);
    lllllIllllII[17] = ('' + 91 - 91 + 25 ^ 50 + 1 - -85 + 51);
    lllllIllllII[18] = (0xC753 & 0x39EC);
    lllllIllllII[19] = (0x26 ^ 0xE);
    lllllIllllII[20] = (((0x7E ^ 0x65) & (0x92 ^ 0x89 ^ 0xFFFFFFFF)) + (0xFF ^ 0xA3) - (0xF0 ^ 0xC4) + (114 + 46 - 148 + 128));
    lllllIllllII[21] = (0x17 ^ 0x3);
  }
  
  public boolean getChatOpen()
  {
    ;
    return mc.currentScreen instanceof GuiChat;
  }
  
  private static boolean llIIIIIIIIIIII(int ???)
  {
    double llllllllllllllIllIIlIIIIIlllllII;
    return ??? != 0;
  }
  
  public int getChatHeight()
  {
    ;
    if (llIIIIIIIIIIII(llllllllllllllIllIIlIIIIllIIlIII.getChatOpen()))
    {
      "".length();
      if ("  ".length() != 0) {
        break label58;
      }
      return (0x41 ^ 0x12) & (0x67 ^ 0x34 ^ 0xFFFFFFFF);
    }
    label58:
    return calculateChatboxHeight(mc.gameSettings.chatHeightUnfocused);
  }
  
  private static void lIllllllllllII()
  {
    lllllIlllIll = new String[lllllIllllII[1]];
    lllllIlllIll[lllllIllllII[0]] = lIlllllllllIll("MhoiIww0eQ==", "iYjbX");
  }
  
  private static boolean llIIIIIIIIlIII(int ???, int arg1)
  {
    int i;
    short llllllllllllllIllIIlIIIIlIIIlIII;
    return ??? <= i;
  }
  
  public int getLineCount()
  {
    ;
    return llllllllllllllIllIIlIIIIlIllIIIl.getChatHeight() / lllllIllllII[5];
  }
  
  public void scroll(int llllllllllllllIllIIlIIIlIIIIlIll)
  {
    ;
    ;
    ;
    scrollPos += llllllllllllllIllIIlIIIlIIIIlIll;
    int llllllllllllllIllIIlIIIlIIIIlIlI = field_146253_i.size();
    if (llIIIIIIIIIIll(scrollPos, llllllllllllllIllIIlIIIlIIIIlIlI - llllllllllllllIllIIlIIIlIIIIllII.getLineCount())) {
      scrollPos = (llllllllllllllIllIIlIIIlIIIIlIlI - llllllllllllllIllIIlIIIlIIIIllII.getLineCount());
    }
    if (llIIIIIIIIlIlI(scrollPos))
    {
      scrollPos = lllllIllllII[0];
      isScrolled = lllllIllllII[0];
    }
  }
  
  public void printChatMessage(IChatComponent llllllllllllllIllIIlIIIlIlIIlIll)
  {
    ;
    ;
    llllllllllllllIllIIlIIIlIlIIlllI.printChatMessageWithOptionalDeletion(llllllllllllllIllIIlIIIlIlIIlIll, lllllIllllII[0]);
  }
  
  public void drawChat(int llllllllllllllIllIIlIIIlIlllllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlllllllllllI(mc.gameSettings.chatVisibility, EntityPlayer.EnumChatVisibility.HIDDEN))
    {
      int llllllllllllllIllIIlIIIlIllllIll = llllllllllllllIllIIlIIIlIlllllIl.getLineCount();
      boolean llllllllllllllIllIIlIIIlIllllIlI = lllllIllllII[0];
      int llllllllllllllIllIIlIIIlIllllIIl = lllllIllllII[0];
      int llllllllllllllIllIIlIIIlIllllIII = field_146253_i.size();
      float llllllllllllllIllIIlIIIlIlllIlll = mc.gameSettings.chatOpacity * 0.9F + 0.1F;
      if (lIllllllllllll(llllllllllllllIllIIlIIIlIllllIII))
      {
        if (llIIIIIIIIIIII(llllllllllllllIllIIlIIIlIlllllIl.getChatOpen())) {
          llllllllllllllIllIIlIIIlIllllIlI = lllllIllllII[1];
        }
        float llllllllllllllIllIIlIIIlIlllIllI = llllllllllllllIllIIlIIIlIlllllIl.getChatScale();
        int llllllllllllllIllIIlIIIlIlllIlIl = MathHelper.ceiling_float_int(llllllllllllllIllIIlIIIlIlllllIl.getChatWidth() / llllllllllllllIllIIlIIIlIlllIllI);
        GlStateManager.pushMatrix();
        GlStateManager.translate(2.0F, 20.0F, 0.0F);
        GlStateManager.scale(llllllllllllllIllIIlIIIlIlllIllI, llllllllllllllIllIIlIIIlIlllIllI, 1.0F);
        int llllllllllllllIllIIlIIIlIlllIlII = lllllIllllII[0];
        "".length();
        if (((0x75 ^ 0x4B) & (0xA1 ^ 0x9F ^ 0xFFFFFFFF)) > "  ".length()) {
          return;
        }
        while ((llIIIIIIIIIlII(llllllllllllllIllIIlIIIlIlllIlII + scrollPos, field_146253_i.size())) && (!llIIIIIIIIIIlI(llllllllllllllIllIIlIIIlIlllIlII, llllllllllllllIllIIlIIIlIllllIll)))
        {
          ChatLine llllllllllllllIllIIlIIIlIlllIIll = (ChatLine)field_146253_i.get(llllllllllllllIllIIlIIIlIlllIlII + scrollPos);
          if (llIIIIIIIIIIIl(llllllllllllllIllIIlIIIlIlllIIll))
          {
            int llllllllllllllIllIIlIIIlIlllIIlI = llllllllllllllIllIIlIIIlIlllllII - llllllllllllllIllIIlIIIlIlllIIll.getUpdatedCounter();
            if ((!llIIIIIIIIIIlI(llllllllllllllIllIIlIIIlIlllIIlI, lllllIllllII[2])) || (llIIIIIIIIIIII(llllllllllllllIllIIlIIIlIllllIlI)))
            {
              double llllllllllllllIllIIlIIIlIlllIIIl = llllllllllllllIllIIlIIIlIlllIIlI / 200.0D;
              llllllllllllllIllIIlIIIlIlllIIIl = 1.0D - llllllllllllllIllIIlIIIlIlllIIIl;
              llllllllllllllIllIIlIIIlIlllIIIl *= 10.0D;
              llllllllllllllIllIIlIIIlIlllIIIl = MathHelper.clamp_double(llllllllllllllIllIIlIIIlIlllIIIl, 0.0D, 1.0D);
              llllllllllllllIllIIlIIIlIlllIIIl *= llllllllllllllIllIIlIIIlIlllIIIl;
              int llllllllllllllIllIIlIIIlIlllIIII = (int)(255.0D * llllllllllllllIllIIlIIIlIlllIIIl);
              if (llIIIIIIIIIIII(llllllllllllllIllIIlIIIlIllllIlI)) {
                llllllllllllllIllIIlIIIlIlllIIII = lllllIllllII[3];
              }
              llllllllllllllIllIIlIIIlIlllIIII = (int)(llllllllllllllIllIIlIIIlIlllIIII * llllllllllllllIllIIlIIIlIlllIlll);
              llllllllllllllIllIIlIIIlIllllIIl++;
              if (llIIIIIIIIIIll(llllllllllllllIllIIlIIIlIlllIIII, lllllIllllII[4]))
              {
                int llllllllllllllIllIIlIIIlIllIllll = lllllIllllII[0];
                int llllllllllllllIllIIlIIIlIllIlllI = -llllllllllllllIllIIlIIIlIlllIlII * lllllIllllII[5];
                if (llIIIIIIIIIIII(BackgroundChatModule.isEnabled())) {
                  drawRect(llllllllllllllIllIIlIIIlIllIllll, llllllllllllllIllIIlIIIlIllIlllI - lllllIllllII[5], llllllllllllllIllIIlIIIlIllIllll + llllllllllllllIllIIlIIIlIlllIlIl + lllllIllllII[6], llllllllllllllIllIIlIIIlIllIlllI, llllllllllllllIllIIlIIIlIlllIIII / lllllIllllII[7] << lllllIllllII[8]);
                }
                String llllllllllllllIllIIlIIIlIllIllIl = llllllllllllllIllIIlIIIlIlllIIll.getChatComponent().getFormattedText();
                GlStateManager.enableBlend();
                "".length();
                GlStateManager.disableAlpha();
                GlStateManager.disableBlend();
              }
            }
          }
          llllllllllllllIllIIlIIIlIlllIlII++;
        }
        if (llIIIIIIIIIIII(llllllllllllllIllIIlIIIlIllllIlI))
        {
          int llllllllllllllIllIIlIIIlIllIllII = fontRendererObjFONT_HEIGHT;
          GlStateManager.translate(-3.0F, 0.0F, 0.0F);
          int llllllllllllllIllIIlIIIlIllIlIll = llllllllllllllIllIIlIIIlIllllIII * llllllllllllllIllIIlIIIlIllIllII + llllllllllllllIllIIlIIIlIllllIII;
          int llllllllllllllIllIIlIIIlIllIlIlI = llllllllllllllIllIIlIIIlIllllIIl * llllllllllllllIllIIlIIIlIllIllII + llllllllllllllIllIIlIIIlIllllIIl;
          int llllllllllllllIllIIlIIIlIllIlIIl = scrollPos * llllllllllllllIllIIlIIIlIllIlIlI / llllllllllllllIllIIlIIIlIllllIII;
          int llllllllllllllIllIIlIIIlIllIlIII = llllllllllllllIllIIlIIIlIllIlIlI * llllllllllllllIllIIlIIIlIllIlIlI / llllllllllllllIllIIlIIIlIllIlIll;
          if (llIIIIIIIIIlIl(llllllllllllllIllIIlIIIlIllIlIll, llllllllllllllIllIIlIIIlIllIlIlI))
          {
            if (lIllllllllllll(llllllllllllllIllIIlIIIlIllIlIIl))
            {
              "".length();
              if (" ".length() < "  ".length()) {
                break label592;
              }
            }
            label592:
            int llllllllllllllIllIIlIIIlIllIIlll = lllllIllllII[12];
            if (llIIIIIIIIIIII(isScrolled))
            {
              "".length();
              if (" ".length() == " ".length()) {
                break label636;
              }
            }
            label636:
            int llllllllllllllIllIIlIIIlIllIIllI = lllllIllllII[14];
            drawRect(lllllIllllII[0], -llllllllllllllIllIIlIIIlIllIlIIl, lllllIllllII[7], -llllllllllllllIllIIlIIIlIllIlIIl - llllllllllllllIllIIlIIIlIllIlIII, llllllllllllllIllIIlIIIlIllIIllI + (llllllllllllllIllIIlIIIlIllIIlll << lllllIllllII[8]));
            drawRect(lllllIllllII[7], -llllllllllllllIllIIlIIIlIllIlIIl, lllllIllllII[1], -llllllllllllllIllIIlIIIlIllIlIIl - llllllllllllllIllIIlIIIlIllIlIII, lllllIllllII[15] + (llllllllllllllIllIIlIIIlIllIIlll << lllllIllllII[8]));
          }
        }
        GlStateManager.popMatrix();
      }
    }
  }
  
  public float getChatScale()
  {
    ;
    return mc.gameSettings.chatScale;
  }
  
  private static boolean llIIIIIIIIIIIl(Object ???)
  {
    short llllllllllllllIllIIlIIIIIllllllI;
    return ??? != null;
  }
  
  public static int calculateChatboxHeight(float llllllllllllllIllIIlIIIIlIllIlIl)
  {
    ;
    ;
    ;
    int llllllllllllllIllIIlIIIIlIllIlll = lllllIllllII[20];
    int llllllllllllllIllIIlIIIIlIllIllI = lllllIllllII[21];
    return MathHelper.floor_float(llllllllllllllIllIIlIIIIlIlllIII * (llllllllllllllIllIIlIIIIlIllIlll - llllllllllllllIllIIlIIIIlIllIllI) + llllllllllllllIllIIlIIIIlIllIllI);
  }
  
  public void refreshChat()
  {
    ;
    ;
    ;
    field_146253_i.clear();
    llllllllllllllIllIIlIIIlIIlIIIIl.resetScroll();
    int llllllllllllllIllIIlIIIlIIlIIIII = chatLines.size() - lllllIllllII[1];
    "".length();
    if (-" ".length() > 0) {
      return;
    }
    while (!llIIIIIIIIlIIl(llllllllllllllIllIIlIIIlIIlIIIII))
    {
      ChatLine llllllllllllllIllIIlIIIlIIIlllll = (ChatLine)chatLines.get(llllllllllllllIllIIlIIIlIIlIIIII);
      llllllllllllllIllIIlIIIlIIlIIIIl.setChatLine(llllllllllllllIllIIlIIIlIIIlllll.getChatComponent(), llllllllllllllIllIIlIIIlIIIlllll.getChatLineID(), llllllllllllllIllIIlIIIlIIIlllll.getUpdatedCounter(), lllllIllllII[1]);
      llllllllllllllIllIIlIIIlIIlIIIII--;
    }
  }
  
  public List<String> getSentMessages()
  {
    ;
    return sentMessages;
  }
  
  private static boolean lIllllllllllll(int ???)
  {
    double llllllllllllllIllIIlIIIIIlllIIlI;
    return ??? > 0;
  }
  
  private static boolean llIIIIIIIIIIll(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIllIIlIIIIlIIIIlII;
    return ??? > i;
  }
  
  public IChatComponent getChatComponent(int llllllllllllllIllIIlIIIIlllIlIlI, int llllllllllllllIllIIlIIIIlllIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIIIIIIIIlll(llllllllllllllIllIIlIIIIlllIlIll.getChatOpen())) {
      return null;
    }
    ScaledResolution llllllllllllllIllIIlIIIIllllIlIl = new ScaledResolution(mc);
    int llllllllllllllIllIIlIIIIllllIlII = llllllllllllllIllIIlIIIIllllIlIl.getScaleFactor();
    float llllllllllllllIllIIlIIIIllllIIll = llllllllllllllIllIIlIIIIlllIlIll.getChatScale();
    int llllllllllllllIllIIlIIIIllllIIlI = llllllllllllllIllIIlIIIIllllIlll / llllllllllllllIllIIlIIIIllllIlII - lllllIllllII[4];
    int llllllllllllllIllIIlIIIIllllIIIl = llllllllllllllIllIIlIIIIlllIlIIl / llllllllllllllIllIIlIIIIllllIlII - lllllIllllII[17];
    llllllllllllllIllIIlIIIIllllIIlI = MathHelper.floor_float(llllllllllllllIllIIlIIIIllllIIlI / llllllllllllllIllIIlIIIIllllIIll);
    llllllllllllllIllIIlIIIIllllIIIl = MathHelper.floor_float(llllllllllllllIllIIlIIIIllllIIIl / llllllllllllllIllIIlIIIIllllIIll);
    if ((llIIIIIIIIlIll(llllllllllllllIllIIlIIIIllllIIlI)) && (llIIIIIIIIlIll(llllllllllllllIllIIlIIIIllllIIIl)))
    {
      int llllllllllllllIllIIlIIIIllllIIII = Math.min(llllllllllllllIllIIlIIIIlllIlIll.getLineCount(), field_146253_i.size());
      if ((llIIIIIIIIlIII(llllllllllllllIllIIlIIIIllllIIlI, MathHelper.floor_float(llllllllllllllIllIIlIIIIlllIlIll.getChatWidth() / llllllllllllllIllIIlIIIIlllIlIll.getChatScale()))) && (llIIIIIIIIIlII(llllllllllllllIllIIlIIIIllllIIIl, fontRendererObjFONT_HEIGHT * llllllllllllllIllIIlIIIIllllIIII + llllllllllllllIllIIlIIIIllllIIII)))
      {
        int llllllllllllllIllIIlIIIIlllIllll = llllllllllllllIllIIlIIIIllllIIIl / fontRendererObjFONT_HEIGHT + scrollPos;
        if ((llIIIIIIIIlIll(llllllllllllllIllIIlIIIIlllIllll)) && (llIIIIIIIIIlII(llllllllllllllIllIIlIIIIlllIllll, field_146253_i.size())))
        {
          ChatLine llllllllllllllIllIIlIIIIlllIlllI = (ChatLine)field_146253_i.get(llllllllllllllIllIIlIIIIlllIllll);
          int llllllllllllllIllIIlIIIIlllIllIl = lllllIllllII[0];
          llllllllllllllIllIIlIIIIllIllllI = llllllllllllllIllIIlIIIIlllIlllI.getChatComponent().iterator();
          "".length();
          if ((0xAD ^ 0xA9) < 0) {
            return null;
          }
          while (!llIIIIIIIIIlll(llllllllllllllIllIIlIIIIllIllllI.hasNext()))
          {
            IChatComponent llllllllllllllIllIIlIIIIlllIllII = (IChatComponent)llllllllllllllIllIIlIIIIllIllllI.next();
            if (llIIIIIIIIIIII(llllllllllllllIllIIlIIIIlllIllII instanceof ChatComponentText))
            {
              llllllllllllllIllIIlIIIIlllIllIl += Minecraft.fontRendererObj.getStringWidth(GuiUtilRenderComponents.func_178909_a(((ChatComponentText)llllllllllllllIllIIlIIIIlllIllII).getChatComponentText_TextValue(), lllllIllllII[0]));
              if (llIIIIIIIIIIll(llllllllllllllIllIIlIIIIlllIllIl, llllllllllllllIllIIlIIIIllllIIlI)) {
                return llllllllllllllIllIIlIIIIlllIllII;
              }
            }
          }
        }
        return null;
      }
      return null;
    }
    return null;
  }
  
  public void addToSentMessages(String llllllllllllllIllIIlIIIlIIIlIIll)
  {
    ;
    ;
    if ((!llIIIIIIIIIlll(sentMessages.isEmpty())) || (llIIIIIIIIIlll(((String)sentMessages.get(sentMessages.size() - lllllIllllII[1])).equals(llllllllllllllIllIIlIIIlIIIlIIll)))) {
      "".length();
    }
  }
  
  private static boolean llIIIIIIIIlIIl(int ???)
  {
    double llllllllllllllIllIIlIIIIIlllIllI;
    return ??? < 0;
  }
  
  public int getChatWidth()
  {
    ;
    return calculateChatboxWidth(mc.gameSettings.chatWidth);
  }
  
  public void clearChatMessages()
  {
    ;
    field_146253_i.clear();
    chatLines.clear();
    sentMessages.clear();
  }
  
  public void resetScroll()
  {
    ;
    scrollPos = lllllIllllII[0];
    isScrolled = lllllIllllII[0];
  }
  
  public GuiNewChat(Minecraft llllllllllllllIllIIlIIIllIIlIIlI)
  {
    mc = llllllllllllllIllIIlIIIllIIlIIlI;
  }
  
  private static boolean llIIIIIIIIIIlI(int ???, int arg1)
  {
    int i;
    double llllllllllllllIllIIlIIIIlIIlIIII;
    return ??? >= i;
  }
  
  private void setChatLine(IChatComponent llllllllllllllIllIIlIIIlIIllIllI, int llllllllllllllIllIIlIIIlIIllIlIl, int llllllllllllllIllIIlIIIlIIllIlII, boolean llllllllllllllIllIIlIIIlIIlIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIIIIIIIIIII(llllllllllllllIllIIlIIIlIIllIlIl)) {
      llllllllllllllIllIIlIIIlIIllIlll.deleteChatLine(llllllllllllllIllIIlIIIlIIlIllII);
    }
    int llllllllllllllIllIIlIIIlIIllIIlI = MathHelper.floor_float(llllllllllllllIllIIlIIIlIIllIlll.getChatWidth() / llllllllllllllIllIIlIIIlIIllIlll.getChatScale());
    List<IChatComponent> llllllllllllllIllIIlIIIlIIllIIIl = GuiUtilRenderComponents.func_178908_a(llllllllllllllIllIIlIIIlIIllIllI, llllllllllllllIllIIlIIIlIIllIIlI, Minecraft.fontRendererObj, lllllIllllII[0], lllllIllllII[0]);
    boolean llllllllllllllIllIIlIIIlIIllIIII = llllllllllllllIllIIlIIIlIIllIlll.getChatOpen();
    char llllllllllllllIllIIlIIIlIIlIIlIl = llllllllllllllIllIIlIIIlIIllIIIl.iterator();
    "".length();
    if (((0x5F ^ 0x63) & (0x4D ^ 0x71 ^ 0xFFFFFFFF)) <= -" ".length()) {
      return;
    }
    while (!llIIIIIIIIIlll(llllllllllllllIllIIlIIIlIIlIIlIl.hasNext()))
    {
      IChatComponent llllllllllllllIllIIlIIIlIIlIllll = (IChatComponent)llllllllllllllIllIIlIIIlIIlIIlIl.next();
      if ((llIIIIIIIIIIII(llllllllllllllIllIIlIIIlIIllIIII)) && (lIllllllllllll(scrollPos)))
      {
        isScrolled = lllllIllllII[1];
        llllllllllllllIllIIlIIIlIIllIlll.scroll(lllllIllllII[1]);
      }
      field_146253_i.add(lllllIllllII[0], new ChatLine(llllllllllllllIllIIlIIIlIIllIlII, llllllllllllllIllIIlIIIlIIlIllll, llllllllllllllIllIIlIIIlIIlIllII));
    }
    "".length();
    if (('' + 126 - 225 + 141 ^ 98 + 23 - 62 + 138) == 0) {
      return;
    }
    while (!llIIIIIIIIlIII(field_146253_i.size(), lllllIllllII[16])) {
      "".length();
    }
    if (llIIIIIIIIIlll(llllllllllllllIllIIlIIIlIIlIlIlI))
    {
      chatLines.add(lllllIllllII[0], new ChatLine(llllllllllllllIllIIlIIIlIIllIlII, llllllllllllllIllIIlIIIlIIllIllI, llllllllllllllIllIIlIIIlIIlIllII));
      "".length();
      if (-" ".length() >= ((0xF3 ^ 0xB6) & (0x44 ^ 0x1 ^ 0xFFFFFFFF))) {
        return;
      }
      while (!llIIIIIIIIlIII(chatLines.size(), lllllIllllII[16])) {
        "".length();
      }
    }
  }
  
  private static boolean llIIIIIIIIlIll(int ???)
  {
    byte llllllllllllllIllIIlIIIIIllllIII;
    return ??? >= 0;
  }
  
  private static boolean llIIIIIIIIIlIl(int ???, int arg1)
  {
    int i;
    double llllllllllllllIllIIlIIIIIllIlllI;
    return ??? != i;
  }
  
  private static boolean llIIIIIIIIlIlI(int ???)
  {
    int llllllllllllllIllIIlIIIIIlllIlII;
    return ??? <= 0;
  }
  
  private static boolean llIIIIIIIIIlII(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIllIIlIIIIlIIIllII;
    return ??? < i;
  }
  
  public void printChatMessageWithOptionalDeletion(IChatComponent llllllllllllllIllIIlIIIlIlIIIIll, int llllllllllllllIllIIlIIIlIlIIIlIl)
  {
    ;
    ;
    ;
    llllllllllllllIllIIlIIIlIlIIIlll.setChatLine(llllllllllllllIllIIlIIIlIlIIIllI, llllllllllllllIllIIlIIIlIlIIIlIl, mc.ingameGUI.getUpdateCounter(), lllllIllllII[0]);
    logger.info(String.valueOf(new StringBuilder(lllllIlllIll[lllllIllllII[0]]).append(llllllllllllllIllIIlIIIlIlIIIllI.getUnformattedText())));
  }
  
  public void deleteChatLine(int llllllllllllllIllIIlIIIIllIlIlIl)
  {
    ;
    ;
    ;
    ;
    Iterator<ChatLine> llllllllllllllIllIIlIIIIllIlIlII = field_146253_i.iterator();
    "".length();
    if (-"  ".length() >= 0) {
      return;
    }
    while (!llIIIIIIIIIlll(llllllllllllllIllIIlIIIIllIlIlII.hasNext()))
    {
      ChatLine llllllllllllllIllIIlIIIIllIlIIll = (ChatLine)llllllllllllllIllIIlIIIIllIlIlII.next();
      if (llIIIIIIIIllIl(llllllllllllllIllIIlIIIIllIlIIll.getChatLineID(), llllllllllllllIllIIlIIIIllIlIlIl)) {
        llllllllllllllIllIIlIIIIllIlIlII.remove();
      }
    }
    llllllllllllllIllIIlIIIIllIlIlII = chatLines.iterator();
    "".length();
    if (" ".length() == 0) {
      return;
    }
    while (!llIIIIIIIIIlll(llllllllllllllIllIIlIIIIllIlIlII.hasNext()))
    {
      ChatLine llllllllllllllIllIIlIIIIllIlIIlI = (ChatLine)llllllllllllllIllIIlIIIIllIlIlII.next();
      if (llIIIIIIIIllIl(llllllllllllllIllIIlIIIIllIlIIlI.getChatLineID(), llllllllllllllIllIIlIIIIllIlIlIl))
      {
        llllllllllllllIllIIlIIIIllIlIlII.remove();
        "".length();
        if ("  ".length() > -" ".length()) {
          break;
        }
        return;
      }
    }
  }
  
  static
  {
    lIllllllllllIl();
    lIllllllllllII();
  }
  
  private static boolean lIlllllllllllI(Object ???, Object arg1)
  {
    Object localObject;
    double llllllllllllllIllIIlIIIIlIIIIIII;
    return ??? != localObject;
  }
  
  private static String lIlllllllllIll(String llllllllllllllIllIIlIIIIlIlIIIII, String llllllllllllllIllIIlIIIIlIIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIlIIIIlIlIIIII = new String(Base64.getDecoder().decode(llllllllllllllIllIIlIIIIlIlIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIIlIIIIlIlIIIll = new StringBuilder();
    char[] llllllllllllllIllIIlIIIIlIlIIIlI = llllllllllllllIllIIlIIIIlIIlllll.toCharArray();
    int llllllllllllllIllIIlIIIIlIlIIIIl = lllllIllllII[0];
    double llllllllllllllIllIIlIIIIlIIllIll = llllllllllllllIllIIlIIIIlIlIIIII.toCharArray();
    Exception llllllllllllllIllIIlIIIIlIIllIlI = llllllllllllllIllIIlIIIIlIIllIll.length;
    boolean llllllllllllllIllIIlIIIIlIIllIIl = lllllIllllII[0];
    while (llIIIIIIIIIlII(llllllllllllllIllIIlIIIIlIIllIIl, llllllllllllllIllIIlIIIIlIIllIlI))
    {
      char llllllllllllllIllIIlIIIIlIlIIllI = llllllllllllllIllIIlIIIIlIIllIll[llllllllllllllIllIIlIIIIlIIllIIl];
      "".length();
      "".length();
      if (-"  ".length() > 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIIlIIIIlIlIIIll);
  }
  
  private static boolean llIIIIIIIIIlll(int ???)
  {
    byte llllllllllllllIllIIlIIIIIllllIlI;
    return ??? == 0;
  }
  
  private static boolean llIIIIIIIIllIl(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIllIIlIIIIlIIlIlII;
    return ??? == i;
  }
}

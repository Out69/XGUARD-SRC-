package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ContainerHopper;
import net.minecraft.inventory.IInventory;

public class GuiHopper
  extends GuiContainer
{
  private static void lIIIIllIIIlI()
  {
    lIlIIlIIlI = new String[lIlIIlIlII[7]];
    lIlIIlIIlI[lIlIIlIlII[0]] = lIIIIllIIIIl("z4tblEnW0trQPJKtTZ6noFjeW3eoQwT+qyK2psXwacHnD1Ze83RRfw==", "pZVKm");
  }
  
  private static String lIIIIllIIIIl(String lllllllllI, String llllllllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIIIIIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIIIIIIIIlI = Cipher.getInstance("Blowfish");
      lIIIIIIIIlI.init(lIlIIlIlII[6], lIIIIIIIIll);
      return new String(lIIIIIIIIlI.doFinal(Base64.getDecoder().decode(lllllllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIIIIIIIIl)
    {
      lIIIIIIIIIl.printStackTrace();
    }
    return null;
  }
  
  private static void lIIIIllIIllI()
  {
    lIlIIlIlII = new int[8];
    lIlIIlIlII[0] = ((0x92 ^ 0xC4) & (0x0 ^ 0x56 ^ 0xFFFFFFFF));
    lIlIIlIlII[1] = ((0xC6 ^ 0x90) + (0xEE ^ 0xB2) - (24 + 9 - -29 + 95) + (0xD7 ^ 0xA7));
    lIlIIlIlII[2] = (123 + '' - 146 + 74 ^ 72 + 96 - 41 + 56);
    lIlIIlIlII[3] = (0x13 ^ 0x46 ^ 0xE9 ^ 0xBA);
    lIlIIlIlII[4] = (-(0x853F & 0x7FFE) & 0xE7FD & 0x405D7F);
    lIlIIlIlII[5] = (0xC0 ^ 0xBA ^ 0x2D ^ 0x37);
    lIlIIlIlII[6] = "  ".length();
    lIlIIlIlII[7] = " ".length();
  }
  
  protected void drawGuiContainerForegroundLayer(int lIIIIIlIllI, int lIIIIIlIlIl)
  {
    ;
    "".length();
    "".length();
  }
  
  protected void drawGuiContainerBackgroundLayer(float lIIIIIIllll, int lIIIIIIlllI, int lIIIIIIllIl)
  {
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(HOPPER_GUI_TEXTURE);
    int lIIIIIIllII = (width - xSize) / lIlIIlIlII[6];
    int lIIIIIIlIll = (height - ySize) / lIlIIlIlII[6];
    lIIIIIlIIII.drawTexturedModalRect(lIIIIIIllII, lIIIIIIlIll, lIlIIlIlII[0], lIlIIlIlII[0], xSize, ySize);
  }
  
  public GuiHopper(InventoryPlayer lIIIIIlllIl, IInventory lIIIIIlllII)
  {
    lIIIIIllIll.<init>(new ContainerHopper(lIIIIIllIlI, lIIIIIlllII, getMinecraftthePlayer));
    playerInventory = lIIIIIllIlI;
    hopperInventory = lIIIIIlllII;
    allowUserInput = lIlIIlIlII[0];
    ySize = lIlIIlIlII[1];
  }
  
  static
  {
    lIIIIllIIllI();
    lIIIIllIIIlI();
  }
}

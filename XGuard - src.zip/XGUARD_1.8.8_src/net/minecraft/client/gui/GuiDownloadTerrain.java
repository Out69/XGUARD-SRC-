package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.resources.I18n;
import net.minecraft.network.play.client.C00PacketKeepAlive;

public class GuiDownloadTerrain
  extends GuiScreen
{
  public void initGui()
  {
    ;
    buttonList.clear();
  }
  
  protected void keyTyped(char llllllllllllllIllIIllIlIlIllIIlI, int llllllllllllllIllIIllIlIlIllIIIl)
    throws IOException
  {}
  
  public void drawScreen(int llllllllllllllIllIIllIlIlIlIIIIl, int llllllllllllllIllIIllIlIlIlIIlII, float llllllllllllllIllIIllIlIlIlIIIll)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIllIIllIlIlIlIIIlI.drawBackground(lllllIIIllII[2]);
    llllllllllllllIllIIllIlIlIlIIIlI.drawCenteredString(fontRendererObj, I18n.format(lllllIIIlIIl[lllllIIIllII[2]], new Object[lllllIIIllII[2]]), width / lllllIIIllII[3], height / lllllIIIllII[3] - lllllIIIllII[4], lllllIIIllII[5]);
    llllllllllllllIllIIllIlIlIlIIIlI.drawScreen(llllllllllllllIllIIllIlIlIlIIIIl, llllllllllllllIllIIllIlIlIlIIlII, llllllllllllllIllIIllIlIlIlIIIll);
  }
  
  public GuiDownloadTerrain(NetHandlerPlayClient llllllllllllllIllIIllIlIlIllIlII)
  {
    netHandlerPlayClient = llllllllllllllIllIIllIlIlIllIlII;
  }
  
  private static void lIllllIllIIlll()
  {
    lllllIIIllII = new int[7];
    lllllIIIllII[0] = " ".length();
    lllllIIIllII[1] = (91 + 5 - -32 + 3 ^ 56 + 67 - 68 + 96);
    lllllIIIllII[2] = ((0xE3 ^ 0xC4) & (0xC ^ 0x2B ^ 0xFFFFFFFF));
    lllllIIIllII[3] = "  ".length();
    lllllIIIllII[4] = (0x56 ^ 0x64);
    lllllIIIllII[5] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lllllIIIllII[6] = ('' + 90 - 114 + 81 ^ 110 + '' - 90 + 23);
  }
  
  private static void lIllllIllIIIll()
  {
    lllllIIIlIIl = new String[lllllIIIllII[0]];
    lllllIIIlIIl[lllllIIIllII[2]] = lIllllIllIIIlI("o0aWtc8+nZ9R23hp9gOIt/UIQQFMchVKlBZgrYqxu+Y=", "gyyrb");
  }
  
  static
  {
    lIllllIllIIlll();
    lIllllIllIIIll();
  }
  
  public void updateScreen()
  {
    ;
    progress += lllllIIIllII[0];
    if (lIllllIllIlIII(progress % lllllIIIllII[1])) {
      netHandlerPlayClient.addToSendQueue(new C00PacketKeepAlive());
    }
  }
  
  public boolean doesGuiPauseGame()
  {
    return lllllIIIllII[2];
  }
  
  private static String lIllllIllIIIlI(String llllllllllllllIllIIllIlIlIIlIllI, String llllllllllllllIllIIllIlIlIIlIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIllIlIlIIllIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIllIlIlIIlIlIl.getBytes(StandardCharsets.UTF_8)), lllllIIIllII[6]), "DES");
      Cipher llllllllllllllIllIIllIlIlIIllIII = Cipher.getInstance("DES");
      llllllllllllllIllIIllIlIlIIllIII.init(lllllIIIllII[3], llllllllllllllIllIIllIlIlIIllIIl);
      return new String(llllllllllllllIllIIllIlIlIIllIII.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIllIlIlIIlIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIllIlIlIIlIlll)
    {
      llllllllllllllIllIIllIlIlIIlIlll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIllllIllIlIII(int ???)
  {
    double llllllllllllllIllIIllIlIlIIIllll;
    return ??? == 0;
  }
}

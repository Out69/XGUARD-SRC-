package net.minecraft.client.gui;

public abstract interface GuiYesNoCallback
{
  public abstract void confirmClicked(boolean paramBoolean, int paramInt);
}

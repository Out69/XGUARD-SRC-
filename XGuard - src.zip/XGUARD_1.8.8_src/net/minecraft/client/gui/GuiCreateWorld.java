package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.WorldSettings.GameType;
import net.minecraft.world.WorldType;
import net.minecraft.world.storage.ISaveFormat;
import net.minecraft.world.storage.WorldInfo;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.input.Keyboard;

public class GuiCreateWorld
  extends GuiScreen
{
  public void updateScreen()
  {
    ;
    field_146333_g.updateCursorCounter();
    field_146335_h.updateCursorCounter();
  }
  
  public void drawScreen(int llllllllllllllllIlIIlIIlllllllIl, int llllllllllllllllIlIIlIIlllllllII, float llllllllllllllllIlIIlIIllllllIll)
  {
    ;
    ;
    ;
    ;
    llllllllllllllllIlIIlIlIIIIIIIlI.drawDefaultBackground();
    llllllllllllllllIlIIlIlIIIIIIIlI.drawCenteredString(fontRendererObj, I18n.format(llIlIllIIIl[llIlIllIllI[84]], new Object[llIlIllIllI[1]]), width / llIlIllIllI[3], llIlIllIllI[21], llIlIllIllI[85]);
    if (lIlIIlIIIllIl(field_146344_y))
    {
      llllllllllllllllIlIIlIlIIIIIIIlI.drawString(fontRendererObj, I18n.format(llIlIllIIIl[llIlIllIllI[86]], new Object[llIlIllIllI[1]]), width / llIlIllIllI[3] - llIlIllIllI[37], llIlIllIllI[58], llIlIllIllI[87]);
      llllllllllllllllIlIIlIlIIIIIIIlI.drawString(fontRendererObj, I18n.format(llIlIllIIIl[llIlIllIllI[32]], new Object[llIlIllIllI[1]]), width / llIlIllIllI[3] - llIlIllIllI[37], llIlIllIllI[88], llIlIllIllI[87]);
      if (lIlIIlIIIllIl(btnMapFeatures.visible)) {
        llllllllllllllllIlIIlIlIIIIIIIlI.drawString(fontRendererObj, I18n.format(llIlIllIIIl[llIlIllIllI[89]], new Object[llIlIllIllI[1]]), width / llIlIllIllI[3] - llIlIllIllI[30], llIlIllIllI[90], llIlIllIllI[87]);
      }
      if (lIlIIlIIIllIl(btnAllowCommands.visible)) {
        llllllllllllllllIlIIlIlIIIIIIIlI.drawString(fontRendererObj, I18n.format(llIlIllIIIl[llIlIllIllI[91]], new Object[llIlIllIllI[1]]), width / llIlIllIllI[3] - llIlIllIllI[30], llIlIllIllI[92], llIlIllIllI[87]);
      }
      field_146335_h.drawTextBox();
      if (lIlIIlIIIllIl(WorldType.worldTypes[selectedIndex].showWorldInfoNotice()))
      {
        fontRendererObj.drawSplitString(I18n.format(WorldType.worldTypes[selectedIndex].func_151359_c(), new Object[llIlIllIllI[1]]), btnMapType.xPosition + llIlIllIllI[3], btnMapType.yPosition + llIlIllIllI[23], btnMapType.getButtonWidth(), llIlIllIllI[93]);
        "".length();
        if (null == null) {}
      }
    }
    else
    {
      llllllllllllllllIlIIlIlIIIIIIIlI.drawString(fontRendererObj, I18n.format(llIlIllIIIl[llIlIllIllI[94]], new Object[llIlIllIllI[1]]), width / llIlIllIllI[3] - llIlIllIllI[37], llIlIllIllI[58], llIlIllIllI[87]);
      llllllllllllllllIlIIlIlIIIIIIIlI.drawString(fontRendererObj, String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIllIIIl[llIlIllIllI[95]], new Object[llIlIllIllI[1]]))).append(llIlIllIIIl[llIlIllIllI[96]]).append(field_146336_i)), width / llIlIllIllI[3] - llIlIllIllI[37], llIlIllIllI[88], llIlIllIllI[87]);
      field_146333_g.drawTextBox();
      llllllllllllllllIlIIlIlIIIIIIIlI.drawString(fontRendererObj, field_146323_G, width / llIlIllIllI[3] - llIlIllIllI[37], llIlIllIllI[97], llIlIllIllI[87]);
      llllllllllllllllIlIIlIlIIIIIIIlI.drawString(fontRendererObj, field_146328_H, width / llIlIllIllI[3] - llIlIllIllI[37], llIlIllIllI[98], llIlIllIllI[87]);
    }
    llllllllllllllllIlIIlIlIIIIIIIlI.drawScreen(llllllllllllllllIlIIlIIlllllllIl, llllllllllllllllIlIIlIIlllllllII, llllllllllllllllIlIIlIIllllllIll);
  }
  
  public static String func_146317_a(ISaveFormat llllllllllllllllIlIIlIlIIlIIlIII, String llllllllllllllllIlIIlIlIIlIIIlII)
  {
    ;
    ;
    ;
    float llllllllllllllllIlIIlIlIIlIIIlII = llllllllllllllllIlIIlIlIIlIIIlII.replaceAll(llIlIllIIIl[llIlIllIllI[70]], llIlIllIIIl[llIlIllIllI[45]]);
    int llllllllllllllllIlIIlIlIIlIIIIIl = (llllllllllllllllIlIIlIlIIlIIIIII = disallowedFilenames).length;
    double llllllllllllllllIlIIlIlIIlIIIIlI = llIlIllIllI[1];
    "".length();
    if (" ".length() > "  ".length()) {
      return null;
    }
    while (!lIlIIlIIIllII(llllllllllllllllIlIIlIlIIlIIIIlI, llllllllllllllllIlIIlIlIIlIIIIIl))
    {
      String llllllllllllllllIlIIlIlIIlIIIllI = llllllllllllllllIlIIlIlIIlIIIIII[llllllllllllllllIlIIlIlIIlIIIIlI];
      if (lIlIIlIIIllIl(llllllllllllllllIlIIlIlIIlIIIlII.equalsIgnoreCase(llllllllllllllllIlIIlIlIIlIIIllI))) {
        llllllllllllllllIlIIlIlIIlIIIlII = String.valueOf(new StringBuilder(llIlIllIIIl[llIlIllIllI[71]]).append(llllllllllllllllIlIIlIlIIlIIIlII).append(llIlIllIIIl[llIlIllIllI[72]]));
      }
      llllllllllllllllIlIIlIlIIlIIIIlI++;
    }
    "".length();
    if ((0x17 ^ 0x4A ^ 0x9B ^ 0xC2) <= ((0xEF ^ 0x96 ^ 0x37 ^ 0x11) & (0x1C ^ 0x56 ^ 0x74 ^ 0x61 ^ -" ".length()))) {
      return null;
    }
    while (!lIlIIlIIIllll(llllllllllllllllIlIIlIlIIlIIlIII.getWorldInfo(llllllllllllllllIlIIlIlIIlIIIlII))) {
      llllllllllllllllIlIIlIlIIlIIIlII = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllllIlIIlIlIIlIIIlII)).append(llIlIllIIIl[llIlIllIllI[73]]));
    }
    return llllllllllllllllIlIIlIlIIlIIIlII;
  }
  
  private static boolean lIlIIlIIlIIIl(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllIlIIlIIllIllllll;
    return ??? == i;
  }
  
  private boolean func_175299_g()
  {
    ;
    ;
    WorldType llllllllllllllllIlIIlIlIIIlIIlll = WorldType.worldTypes[selectedIndex];
    if ((lIlIIlIIlIIll(llllllllllllllllIlIIlIlIIIlIIlll)) && (lIlIIlIIIllIl(llllllllllllllllIlIIlIlIIIlIIlll.getCanBeCreated())))
    {
      if (lIlIIlIIlIIlI(llllllllllllllllIlIIlIlIIIlIIlll, WorldType.DEBUG_WORLD))
      {
        "".length();
        if (" ".length() < "   ".length()) {
          break label121;
        }
        return " ".length() & (" ".length() ^ -" ".length());
      }
      "".length();
      if (" ".length() != -" ".length()) {
        break label121;
      }
      return (0x65 ^ 0x3B) & (0x79 ^ 0x27 ^ 0xFFFFFFFF);
    }
    label121:
    return llIlIllIllI[1];
  }
  
  private static void lIlIIlIIIlIII()
  {
    llIlIllIllI = new int[103];
    llIlIllIllI[0] = (" ".length() ^ 0x2C ^ 0x35);
    llIlIllIllI[1] = ((0xE5 ^ 0x9F ^ 0x59 ^ 0x7E) & (0x8C ^ 0xA9 ^ 0x19 ^ 0x61 ^ -" ".length()));
    llIlIllIllI[2] = " ".length();
    llIlIllIllI[3] = "  ".length();
    llIlIllIllI[4] = "   ".length();
    llIlIllIllI[5] = (0x7B ^ 0x3 ^ 0x3B ^ 0x47);
    llIlIllIllI[6] = (0x97 ^ 0x92);
    llIlIllIllI[7] = (0xA9 ^ 0xAF);
    llIlIllIllI[8] = (55 + 116 - 94 + 57 ^ 58 + 126 - 118 + 63);
    llIlIllIllI[9] = (0xAF ^ 0x90 ^ 0x5D ^ 0x6A);
    llIlIllIllI[10] = (0xCC ^ 0xC5);
    llIlIllIllI[11] = (0x4E ^ 0x44);
    llIlIllIllI[12] = (70 + 52 - 9 + 71 ^ 52 + 74 - -10 + 43);
    llIlIllIllI[13] = (0x6D ^ 0x61);
    llIlIllIllI[14] = (0xAE ^ 0xA3);
    llIlIllIllI[15] = (0xB ^ 0x5);
    llIlIllIllI[16] = (0x70 ^ 0x7F);
    llIlIllIllI[17] = (0x7A ^ 0x6A);
    llIlIllIllI[18] = (109 + 68 - 161 + 136 ^ 125 + 83 - 134 + 63);
    llIlIllIllI[19] = (0x34 ^ 0x26);
    llIlIllIllI[20] = (0x56 ^ 0x74 ^ 0x52 ^ 0x63);
    llIlIllIllI[21] = ('' + 10 - 97 + 102 ^ 72 + 0 - 10 + 73);
    llIlIllIllI[22] = (0xA1 ^ 0xB4);
    llIlIllIllI[23] = (0x13 ^ 0x5);
    llIlIllIllI[24] = (0x48 ^ 0x5F);
    llIlIllIllI[25] = (0x9A ^ 0x83);
    llIlIllIllI[26] = (0x55 ^ 0x4F);
    llIlIllIllI[27] = (0x95 ^ 0x8E);
    llIlIllIllI[28] = (83 + '' - 89 + 22);
    llIlIllIllI[29] = (0xA6 ^ 0xBA);
    llIlIllIllI[30] = (35 + '' - 76 + 59);
    llIlIllIllI[31] = (0x6F ^ 0x72);
    llIlIllIllI[32] = (0x18 ^ 0x2A ^ 0x5 ^ 0x7C);
    llIlIllIllI[33] = (0xE8 ^ 0x9B);
    llIlIllIllI[34] = (0xAF ^ 0xB1);
    llIlIllIllI[35] = ((0x12 ^ 0x14) + (0x6A ^ 0x5F) - (0x5E ^ 0x5A) + (13 + 104 - 28 + 43));
    llIlIllIllI[36] = (0x94 ^ 0x8B);
    llIlIllIllI[37] = (0x3C ^ 0x58);
    llIlIllIllI[38] = (0xBB ^ 0x9B);
    llIlIllIllI[39] = (86 + 41 - 21 + 45);
    llIlIllIllI[40] = (0xBC ^ 0xA1 ^ 0x2F ^ 0x13);
    llIlIllIllI[41] = (0x11 ^ 0x33);
    llIlIllIllI[42] = (0x3C ^ 0x1F);
    llIlIllIllI[43] = (0xBE ^ 0xC6);
    llIlIllIllI[44] = (0xA2 ^ 0x86);
    llIlIllIllI[45] = (0x68 ^ 0x54);
    llIlIllIllI[46] = (37 + 93 - 17 + 87);
    llIlIllIllI[47] = (0xB5 ^ 0x99 ^ 0x4A ^ 0x39);
    llIlIllIllI[48] = (0xF ^ 0x61 ^ 0xEF ^ 0xA4);
    llIlIllIllI[49] = (0x1A ^ 0x3C);
    llIlIllIllI[50] = (90 + 120 - 38 + 6 ^ 20 + 31 - 34 + 132);
    llIlIllIllI[51] = (0x3C ^ 0x57 ^ 0xC3 ^ 0x80);
    llIlIllIllI[52] = (0x0 ^ 0x29);
    llIlIllIllI[53] = (0x9D ^ 0xB7);
    llIlIllIllI[54] = (0x67 ^ 0x6D ^ 0x92 ^ 0xB3);
    llIlIllIllI[55] = (0x20 ^ 0xC);
    llIlIllIllI[56] = (0x9B ^ 0xB6);
    llIlIllIllI[57] = (0x59 ^ 0x77);
    llIlIllIllI[58] = (0x8C ^ 0xC1 ^ 0xF8 ^ 0x9A);
    llIlIllIllI[59] = (0x4A ^ 0x7A);
    llIlIllIllI[60] = (0x3 ^ 0x5 ^ 0x8A ^ 0xBD);
    llIlIllIllI[61] = (30 + 50 - 54 + 119 ^ 44 + 82 - -17 + 20);
    llIlIllIllI[62] = (117 + 92 - 94 + 57 ^ 29 + 52 - 67 + 145);
    llIlIllIllI[63] = (0x5D ^ 0x69);
    llIlIllIllI[64] = (0xB ^ 0x3E);
    llIlIllIllI[65] = (0x37 ^ 0x1);
    llIlIllIllI[66] = (0x4A ^ 0x7D);
    llIlIllIllI[67] = (0x43 ^ 0x5 ^ 0x25 ^ 0x5B);
    llIlIllIllI[68] = (43 + 51 - -32 + 50 ^ 5 + 10 - -3 + 119);
    llIlIllIllI[69] = (0x61 ^ 0x5B);
    llIlIllIllI[70] = (0x54 ^ 0x1D ^ 0x1F ^ 0x6D);
    llIlIllIllI[71] = (127 + '' - 115 + 1 ^ 71 + '' - 172 + 103);
    llIlIllIllI[72] = (0x66 ^ 0x58);
    llIlIllIllI[73] = (0x96 ^ 0xA9);
    llIlIllIllI[74] = (119 + 74 - 31 + 85 ^ '' + 120 - 180 + 105);
    llIlIllIllI[75] = (0x6F ^ 0x2E);
    llIlIllIllI[76] = (0x3E ^ 0x7C);
    llIlIllIllI[77] = (0x1F ^ 0x5A ^ 0x64 ^ 0x62);
    llIlIllIllI[78] = (80 + '¯' - 170 + 139 ^ 26 + 47 - 71 + 162);
    llIlIllIllI[79] = (0x1F ^ 0x5A);
    llIlIllIllI[80] = (0x18 ^ 0x5E);
    llIlIllIllI[81] = (0x52 ^ 0x10 ^ 0x11 ^ 0x14);
    llIlIllIllI[82] = (0x67 ^ 0x5B ^ 0x32 ^ 0x46);
    llIlIllIllI[83] = ((0xB3 ^ 0xA1) + " ".length() - -(0x2D ^ 0x5A) + (0x42 ^ 0x50));
    llIlIllIllI[84] = (0x4E ^ 0x39 ^ 0x81 ^ 0xBF);
    llIlIllIllI[85] = (-" ".length());
    llIlIllIllI[86] = (0xD0 ^ 0x9A);
    llIlIllIllI[87] = (-(-(0xA13F & 0x7ED0) & 0xFF7F & 0x5F7FEF));
    llIlIllIllI[88] = (" ".length() ^ 0xD5 ^ 0x81);
    llIlIllIllI[89] = (0x68 ^ 0x25 ^ " ".length());
    llIlIllIllI[90] = (0x61 ^ 0x77 ^ 0xE3 ^ 0x8F);
    llIlIllIllI[91] = (0xC ^ 0x41);
    llIlIllIllI[92] = ((0x4E ^ 0x41) + (62 + '' - 173 + 113) - (0xA4 ^ 0xBD) + (0x54 ^ 0x70));
    llIlIllIllI[93] = (0xAAE2 & 0xA0F5BD);
    llIlIllIllI[94] = ("  ".length() ^ 0xB ^ 0x47);
    llIlIllIllI[95] = (0x21 ^ 0x25 ^ 0xF0 ^ 0xBB);
    llIlIllIllI[96] = (0x8 ^ 0x58);
    llIlIllIllI[97] = (59 + 123 - 176 + 131);
    llIlIllIllI[98] = ((0x73 ^ 0x25) + (0x4D ^ 0x33) - ('·' + 39 - 176 + 143) + (0x4C ^ 0x32));
    llIlIllIllI[99] = (23 + 103 - 56 + 78 ^ '·' + 88 - 86 + 12);
    llIlIllIllI[100] = ('æ' + 'Û' - 236 + 36 ^ 18 + 43 - -1 + 109);
    llIlIllIllI[101] = (0x7A ^ 0x29);
    llIlIllIllI[102] = (0x52 ^ 0x6);
  }
  
  private static void lIlIIlIIIIlll()
  {
    llIlIllIIIl = new String[llIlIllIllI[88]];
    llIlIllIIIl[llIlIllIllI[1]] = lIlIIIllIlIII("DXW1A54yS04=", "ZNTam");
    llIlIllIIIl[llIlIllIllI[2]] = lIlIIIlllIIll("IDoG", "cuKyo");
    llIlIllIIIl[llIlIllIllI[3]] = lIlIIIllIlIII("NbM6wGSyWh4=", "cCzqR");
    llIlIllIIIl[llIlIllIllI[4]] = lIlIIIllIlIII("Gsb+EREbMvI=", "ZwZpX");
    llIlIllIIIl[llIlIllIllI[5]] = lIlIIIlllIlII("3o/j7Co/RCk=", "QvoqT");
    llIlIllIIIl[llIlIllIllI[6]] = lIlIIIlllIlII("llAt2K70rpE=", "iFgVw");
    llIlIllIIIl[llIlIllIllI[7]] = lIlIIIlllIIll("BxYJRg==", "DYDwk");
    llIlIllIIIl[llIlIllIllI[8]] = lIlIIIlllIIll("KQEofQ==", "jNeOa");
    llIlIllIIIl[llIlIllIllI[9]] = lIlIIIlllIlII("keikHcuCMLE=", "Cpwun");
    llIlIllIIIl[llIlIllIllI[10]] = lIlIIIllIlIII("0gNTnb6Dxtk=", "DmXvN");
    llIlIllIIIl[llIlIllIllI[11]] = lIlIIIllIlIII("fjEmMFMhtKE=", "hdxyB");
    llIlIllIIIl[llIlIllIllI[12]] = lIlIIIlllIIll("Lzg/bA==", "lwrZx");
    llIlIllIIIl[llIlIllIllI[13]] = lIlIIIlllIIll("LT8ldg==", "nphAc");
    llIlIllIIIl[llIlIllIllI[14]] = lIlIIIlllIIll("MhY1cQ==", "qYxIp");
    llIlIllIIIl[llIlIllIllI[15]] = lIlIIIllIlIII("OsLAOMCn04M=", "mSGql");
    llIlIllIIIl[llIlIllIllI[16]] = lIlIIIlllIIll("GTwmfQ==", "UlrLq");
    llIlIllIIIl[llIlIllIllI[17]] = lIlIIIllIlIII("K2+REiPVz2I=", "YjSQY");
    llIlIllIIIl[llIlIllIllI[18]] = lIlIIIlllIIll("IxkYeg==", "oILIq");
    llIlIllIIIl[llIlIllIllI[19]] = lIlIIIlllIIll("CSEHUQ==", "EqSeG");
    llIlIllIIIl[llIlIllIllI[20]] = lIlIIIlllIIll("CSUVVg==", "EuAcV");
    llIlIllIIIl[llIlIllIllI[21]] = lIlIIIlllIlII("8IB6UIK/aRQ=", "knhSr");
    llIlIllIIIl[llIlIllIllI[22]] = lIlIIIlllIlII("bS0NCb2o0L4=", "IyCVi");
    llIlIllIIIl[llIlIllIllI[23]] = lIlIIIlllIlII("284Ardl7zo0=", "ZvDep");
    llIlIllIIIl[llIlIllIllI[24]] = lIlIIIlllIlII("5Kv5xw3IT8o=", "jzhpX");
    llIlIllIIIl[llIlIllIllI[0]] = lIlIIIlllIlII("ItXBTbfPOFSjRxoZGityDg==", "WJXgg");
    llIlIllIIIl[llIlIllIllI[25]] = lIlIIIllIlIII("X+/L+Rsfnic=", "DlOzA");
    llIlIllIIIl[llIlIllIllI[26]] = lIlIIIlllIlII("qpoZInk8+Ss=", "tudRZ");
    llIlIllIIIl[llIlIllIllI[27]] = lIlIIIlllIlII("pihKMgJLCzB59FdqczH+59hEbg7P6n+x", "XvouJ");
    llIlIllIIIl[llIlIllIllI[29]] = lIlIIIlllIlII("pU0ufzRr5iPcQKwwwsOXb4pzURK2OzZr", "xdDpD");
    llIlIllIIIl[llIlIllIllI[31]] = lIlIIIllIlIII("PGc5pja5Pl4Qu+6Fm4BR4w==", "WCrqA");
    llIlIllIIIl[llIlIllIllI[34]] = lIlIIIllIlIII("93lgk3Wl59+256PH8/ExOoCXsOMv42fx", "VDneH");
    llIlIllIIIl[llIlIllIllI[36]] = lIlIIIlllIIll("Nw8jLAEwPSA7DiBEIiYQIT0gOw4gJT89CysEPA==", "DjOIb");
    llIlIllIIIl[llIlIllIllI[38]] = lIlIIIlllIIll("AwYjIC0ENCA3IhRNIiQ+NgYuMTsCBjw=", "pcOEN");
    llIlIllIIIl[llIlIllIllI[40]] = lIlIIIllIlIII("7z+bSSIlKN7qSGnCEaJ+D05ddS6DTwni", "RbtcE");
    llIlIllIIIl[llIlIllIllI[41]] = lIlIIIlllIlII("qF+zFimAblCWIyczN7AJ4cSgwNc0CcD4", "otKfN");
    llIlIllIIIl[llIlIllIllI[42]] = lIlIIIlllIIll("NAY+JhszND0xFCNNMy8UKBQRLBUqAjwnCw==", "GcRCx");
    llIlIllIIIl[llIlIllIllI[44]] = lIlIIIllIlIII("zhgoqAL8obcccrzInHvHROwBEHxLcPetzhjhDnkMxV8=", "WPmuZ");
    llIlIllIIIl[llIlIllIllI[48]] = lIlIIIlllIlII("0QtJ3EleWBs=", "DwglG");
    llIlIllIIIl[llIlIllIllI[49]] = lIlIIIlllIIll("OgQGIQI9NgU2DS1PDSUMLCwFIAQ=", "IajDa");
    llIlIllIIIl[llIlIllIllI[50]] = lIlIIIlllIIll("YFo=", "ZzixQ");
    llIlIllIIIl[llIlIllIllI[51]] = lIlIIIllIlIII("bV/YDY6RMWftZ64giPeK3f8WZ+e3N/q+", "ErCYK");
    llIlIllIIIl[llIlIllIllI[52]] = lIlIIIllIlIII("5ZZGz2GOkCSCCFzfPUM5wCyhVPpLEo/p", "qnNdQ");
    llIlIllIIIl[llIlIllIllI[53]] = lIlIIIlllIIll("XCUlKTJD", "rILGW");
    llIlIllIIIl[llIlIllIllI[54]] = lIlIIIllIlIII("HmcxxIHXv62vgSNudbjPpv3frUUqSptW", "BbsJk");
    llIlIllIIIl[llIlIllIllI[55]] = lIlIIIllIlIII("lYeLoPJ++SA=", "JsUrU");
    llIlIllIIIl[llIlIllIllI[56]] = lIlIIIlllIlII("sosY3L/MJSGGNrpngGza1++3Qfp+mXud", "KbiOB");
    llIlIllIIIl[llIlIllIllI[57]] = lIlIIIlllIIll("dQ==", "UzQHj");
    llIlIllIIIl[llIlIllIllI[58]] = lIlIIIllIlIII("8LH7CJ/BHiw1VcYhiv/Ylw==", "uAduE");
    llIlIllIIIl[llIlIllIllI[59]] = lIlIIIlllIIll("FQUlLwkUBn8pABw=", "zuQFf");
    llIlIllIIIl[llIlIllIllI[60]] = lIlIIIlllIIll("KSYaCBQuFBkfGz5tFAIZLzA/GRI3MA==", "ZCvmw");
    llIlIllIIIl[llIlIllIllI[61]] = lIlIIIlllIlII("EiqWnZNY6WU=", "uKiMs");
    llIlIllIIIl[llIlIllIllI[62]] = lIlIIIlllIlII("lF6/vhhxOrKwJnyYNZyR1A==", "eZEOj");
    llIlIllIIIl[llIlIllIllI[63]] = lIlIIIllIlIII("AmUioP52hvughQGLQTP8vw==", "RxWKw");
    llIlIllIIIl[llIlIllIllI[64]] = lIlIIIlllIlII("Z+gAnowdIxXBdVWSlCELtsrXZHNsObDt", "qkcRj");
    llIlIllIIIl[llIlIllIllI[65]] = lIlIIIlllIIll("cA==", "PUggK");
    llIlIllIIIl[llIlIllIllI[66]] = lIlIIIlllIlII("U2K32BR1rKReUefj1wEfn3risisrvt7JqmHz7IjYlGs=", "GMpsT");
    llIlIllIIIl[llIlIllIllI[67]] = lIlIIIllIlIII("2QJ54W//M6A=", "JEvtQ");
    llIlIllIIIl[llIlIllIllI[68]] = lIlIIIlllIIll("NTwGAwY0P1wFBw==", "ZLrji");
    llIlIllIIIl[llIlIllIllI[69]] = lIlIIIllIlIII("ViQ099IGmwX5q+Zw1FiDDQ==", "naRMu");
    llIlIllIIIl[llIlIllIllI[70]] = lIlIIIlllIlII("+1fwo5hB7/k=", "oOIHC");
    llIlIllIIIl[llIlIllIllI[45]] = lIlIIIlllIIll("Mw==", "lMGgP");
    llIlIllIIIl[llIlIllIllI[71]] = lIlIIIllIlIII("Y6Ilq3SLtM4=", "ZfZuE");
    llIlIllIIIl[llIlIllIllI[72]] = lIlIIIlllIIll("Mg==", "mguBK");
    llIlIllIIIl[llIlIllIllI[73]] = lIlIIIlllIlII("RbW/VUKxbTI=", "qncir");
    llIlIllIIIl[llIlIllIllI[74]] = lIlIIIlllIIll("GBMTJB4dBw0=", "kfaRw");
    llIlIllIIIl[llIlIllIllI[75]] = lIlIIIlllIlII("bCHs3gAlBYfFr52UMj27ig==", "xiVAR");
    llIlIllIIIl[llIlIllIllI[76]] = lIlIIIlllIIll("OxIeCwI8AQk=", "Ssloa");
    llIlIllIIIl[llIlIllIllI[77]] = lIlIIIlllIIll("ITciIxMrMyI=", "BEGBg");
    llIlIllIIIl[llIlIllIllI[78]] = lIlIIIllIlIII("WrJYM4gZNU7UKIlfaOmmww==", "Ecdre");
    llIlIllIIIl[llIlIllIllI[79]] = lIlIIIlllIlII("NGA/ziJ5JXw=", "aeexb");
    llIlIllIIIl[llIlIllIllI[80]] = lIlIIIlllIlII("Nd6oUhmrHvsfa9d8NFQ2ew==", "hqRCL");
    llIlIllIIIl[llIlIllIllI[81]] = lIlIIIlllIlII("40GVG7aXBfJo7eFpMT02Zg==", "zaVHu");
    llIlIllIIIl[llIlIllIllI[82]] = lIlIIIlllIlII("82qQHEeuDPgOZZc4kwBMtZggi5RXkhiNPV7+zT3jvlg=", "bZYWg");
    llIlIllIIIl[llIlIllIllI[84]] = lIlIIIllIlIII("HHcL+n0uXgUlFXS43AYFuvwe1EZ5Is4H", "UEHqz");
    llIlIllIIIl[llIlIllIllI[86]] = lIlIIIllIlIII("PMmZYT6uEQfayfzBH2Ov+8d/Xx09oW43", "zFOoM");
    llIlIllIIIl[llIlIllIllI[32]] = lIlIIIlllIIll("CQk6NRkOOzkiFh5CJTUfHiU4NhU=", "zlVPz");
    llIlIllIIIl[llIlIllIllI[89]] = lIlIIIllIlIII("opRDFHBSrZXu8+Cld7btkfN8jUZiz8pUMMhLaLcD1PE=", "vgfLi");
    llIlIllIIIl[llIlIllIllI[91]] = lIlIIIlllIIll("CikGEBUNGwUHGh1iCxkaFjspGhsULQQRBVclBBMZ", "yLjuv");
    llIlIllIIIl[llIlIllIllI[94]] = lIlIIIllIlIII("FfCczaoQubbwyrHRLV9ci6c5SrRGd0Bp", "QWrTJ");
    llIlIllIIIl[llIlIllIllI[95]] = lIlIIIlllIlII("BaC5Q3GT5MzK73NMCBgkHU7mbzixktKahJOIMwex3/M=", "MvnAJ");
    llIlIllIIIl[llIlIllIllI[96]] = lIlIIIllIlIII("tyB/gCzjinI=", "ToRiQ");
    llIlIllIIIl[llIlIllIllI[99]] = lIlIIIlllIlII("cqWGgqX4oHf1JYZ6h1B4yFXLmq+IXs1MjVeWU32L7/s=", "BthPg");
    llIlIllIIIl[llIlIllIllI[100]] = lIlIIIlllIlII("Wi/FDjX+7aF/+w/+Sg6Fpg==", "FjPuF");
    llIlIllIIIl[llIlIllIllI[101]] = lIlIIIllIlIII("DZKIo/lgdeS9gESKVJnLoQ==", "bbYcf");
    llIlIllIIIl[llIlIllIllI[102]] = lIlIIIlllIlII("OnXS+cI9ZkkmsNCWNTiUug==", "YvuLQ");
  }
  
  private void func_146315_i()
  {
    ;
    if (lIlIIlIIIllIl(field_146344_y))
    {
      "".length();
      if (((0x51 ^ 0xA ^ 0xFC ^ 0x94) & (0xF1 ^ 0x84 ^ 0x35 ^ 0x73 ^ -" ".length())) == 0) {
        break label65;
      }
    }
    label65:
    llIlIllIllI[1].func_146316_a(llIlIllIllI[2]);
  }
  
  private static boolean lIlIIlIIlIllI(int ???)
  {
    short llllllllllllllllIlIIlIIllIlIIlIl;
    return ??? > 0;
  }
  
  private static String lIlIIIllIlIII(String llllllllllllllllIlIIlIIlllIIlIII, String llllllllllllllllIlIIlIIlllIIIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIlIIlIIlllIIlIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlIIlIIlllIIIlll.getBytes(StandardCharsets.UTF_8)), llIlIllIllI[9]), "DES");
      Cipher llllllllllllllllIlIIlIIlllIIlIlI = Cipher.getInstance("DES");
      llllllllllllllllIlIIlIIlllIIlIlI.init(llIlIllIllI[3], llllllllllllllllIlIIlIIlllIIlIll);
      return new String(llllllllllllllllIlIIlIIlllIIlIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllIlIIlIIlllIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIlIIlIIlllIIlIIl)
    {
      llllllllllllllllIlIIlIIlllIIlIIl.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIlIIlIIIlIII();
    lIlIIlIIIIlll();
  }
  
  private void func_146314_g()
  {
    ;
    ;
    ;
    field_146336_i = field_146333_g.getText().trim();
    byte llllllllllllllllIlIIlIlIIlIlIIll = (llllllllllllllllIlIIlIlIIlIlIIlI = ChatAllowedCharacters.allowedCharactersArray).length;
    long llllllllllllllllIlIIlIlIIlIlIlII = llIlIllIllI[1];
    "".length();
    if ("  ".length() == -" ".length()) {
      return;
    }
    while (!lIlIIlIIIllII(llllllllllllllllIlIIlIlIIlIlIlII, llllllllllllllllIlIIlIlIIlIlIIll))
    {
      char llllllllllllllllIlIIlIlIIlIlIlll = llllllllllllllllIlIIlIlIIlIlIIlI[llllllllllllllllIlIIlIlIIlIlIlII];
      field_146336_i = field_146336_i.replace(llllllllllllllllIlIIlIlIIlIlIlll, llIlIllIllI[47]);
      llllllllllllllllIlIIlIlIIlIlIlII++;
    }
    if (lIlIIlIIIllIl(StringUtils.isEmpty(field_146336_i))) {
      field_146336_i = llIlIllIIIl[llIlIllIllI[48]];
    }
    field_146336_i = func_146317_a(mc.getSaveLoader(), field_146336_i);
  }
  
  protected void mouseClicked(int llllllllllllllllIlIIlIlIIIIIllIl, int llllllllllllllllIlIIlIlIIIIIllII, int llllllllllllllllIlIIlIlIIIIIIlll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    llllllllllllllllIlIIlIlIIIIIlllI.mouseClicked(llllllllllllllllIlIIlIlIIIIIllIl, llllllllllllllllIlIIlIlIIIIIllII, llllllllllllllllIlIIlIlIIIIIIlll);
    if (lIlIIlIIIllIl(field_146344_y))
    {
      field_146335_h.mouseClicked(llllllllllllllllIlIIlIlIIIIIllIl, llllllllllllllllIlIIlIlIIIIIllII, llllllllllllllllIlIIlIlIIIIIIlll);
      "".length();
      if ("   ".length() > "  ".length()) {}
    }
    else
    {
      field_146333_g.mouseClicked(llllllllllllllllIlIIlIlIIIIIllIl, llllllllllllllllIlIIlIlIIIIIllII, llllllllllllllllIlIIlIlIIIIIIlll);
    }
  }
  
  private static boolean lIlIIlIIlIlII(Object ???, Object arg1)
  {
    Object localObject;
    boolean llllllllllllllllIlIIlIIllIllIIll;
    return ??? != localObject;
  }
  
  protected void actionPerformed(GuiButton llllllllllllllllIlIIlIlIIIllIlll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIIlIIIllIl(enabled)) {
      if (lIlIIlIIlIIIl(id, llIlIllIllI[2]))
      {
        mc.displayGuiScreen(parentScreen);
        "".length();
        if ("   ".length() != 0) {}
      }
      else if (lIlIIlIIIlllI(id))
      {
        mc.displayGuiScreen(null);
        if (lIlIIlIIIllIl(field_146345_x)) {
          return;
        }
        field_146345_x = llIlIllIllI[2];
        long llllllllllllllllIlIIlIlIIIllIllI = new Random().nextLong();
        String llllllllllllllllIlIIlIlIIIllIlIl = field_146335_h.getText();
        if (lIlIIlIIIlllI(StringUtils.isEmpty(llllllllllllllllIlIIlIlIIIllIlIl))) {
          try
          {
            long llllllllllllllllIlIIlIlIIIllIlII = Long.parseLong(llllllllllllllllIlIIlIlIIIllIlIl);
            if (lIlIIlIIIllIl(lIlIIlIIlIIII(llllllllllllllllIlIIlIlIIIllIlII, 0L)))
            {
              llllllllllllllllIlIIlIlIIIllIllI = llllllllllllllllIlIIlIlIIIllIlII;
              "".length();
              if (-"  ".length() >= 0) {
                return;
              }
            }
          }
          catch (NumberFormatException llllllllllllllllIlIIlIlIIIllIIll)
          {
            llllllllllllllllIlIIlIlIIIllIllI = llllllllllllllllIlIIlIlIIIllIlIl.hashCode();
          }
        }
        WorldSettings.GameType llllllllllllllllIlIIlIlIIIllIIlI = WorldSettings.GameType.getByName(gameMode);
        WorldSettings llllllllllllllllIlIIlIlIIIllIIIl = new WorldSettings(llllllllllllllllIlIIlIlIIIllIllI, llllllllllllllllIlIIlIlIIIllIIlI, field_146341_s, field_146337_w, WorldType.worldTypes[selectedIndex]);
        "".length();
        if ((lIlIIlIIIllIl(field_146338_v)) && (lIlIIlIIIlllI(field_146337_w))) {
          "".length();
        }
        if ((lIlIIlIIIllIl(allowCheats)) && (lIlIIlIIIlllI(field_146337_w))) {
          "".length();
        }
        mc.launchIntegratedServer(field_146336_i, field_146333_g.getText().trim(), llllllllllllllllIlIIlIlIIIllIIIl);
        "".length();
        if (-"  ".length() <= 0) {}
      }
      else if (lIlIIlIIlIIIl(id, llIlIllIllI[4]))
      {
        llllllllllllllllIlIIlIlIIIllIIII.func_146315_i();
        "".length();
        if (-" ".length() < "   ".length()) {}
      }
      else if (lIlIIlIIlIIIl(id, llIlIllIllI[3]))
      {
        if (lIlIIlIIIllIl(gameMode.equals(llIlIllIIIl[llIlIllIllI[74]])))
        {
          if (lIlIIlIIIlllI(field_146339_u)) {
            allowCheats = llIlIllIllI[1];
          }
          field_146337_w = llIlIllIllI[1];
          gameMode = llIlIllIIIl[llIlIllIllI[75]];
          field_146337_w = llIlIllIllI[2];
          btnAllowCommands.enabled = llIlIllIllI[1];
          btnBonusItems.enabled = llIlIllIllI[1];
          llllllllllllllllIlIIlIlIIIllIIII.func_146319_h();
          "".length();
          if ((0x5A ^ 0x5F) != 0) {}
        }
        else if (lIlIIlIIIllIl(gameMode.equals(llIlIllIIIl[llIlIllIllI[76]])))
        {
          if (lIlIIlIIIlllI(field_146339_u)) {
            allowCheats = llIlIllIllI[2];
          }
          field_146337_w = llIlIllIllI[1];
          gameMode = llIlIllIIIl[llIlIllIllI[77]];
          llllllllllllllllIlIIlIlIIIllIIII.func_146319_h();
          field_146337_w = llIlIllIllI[1];
          btnAllowCommands.enabled = llIlIllIllI[2];
          btnBonusItems.enabled = llIlIllIllI[2];
          "".length();
          if (((0x5E ^ 0x27 ^ 0xA9 ^ 0xC2) & (66 + '' - 200 + 154 ^ 96 + 91 - 76 + 77 ^ -" ".length())) >= 0) {}
        }
        else
        {
          if (lIlIIlIIIlllI(field_146339_u)) {
            allowCheats = llIlIllIllI[1];
          }
          gameMode = llIlIllIIIl[llIlIllIllI[78]];
          llllllllllllllllIlIIlIlIIIllIIII.func_146319_h();
          btnAllowCommands.enabled = llIlIllIllI[2];
          btnBonusItems.enabled = llIlIllIllI[2];
          field_146337_w = llIlIllIllI[1];
        }
        llllllllllllllllIlIIlIlIIIllIIII.func_146319_h();
        "".length();
        if (-"  ".length() < 0) {}
      }
      else if (lIlIIlIIlIIIl(id, llIlIllIllI[5]))
      {
        if (lIlIIlIIIllIl(field_146341_s))
        {
          "".length();
          if (((0x25 ^ 0x9) & (0x4B ^ 0x67 ^ 0xFFFFFFFF)) >= 0) {
            break label800;
          }
        }
        label800:
        llIlIllIllI1field_146341_s = llIlIllIllI[2];
        llllllllllllllllIlIIlIlIIIllIIII.func_146319_h();
        "".length();
        if ((('' + 'Ï' - 165 + 36 ^ 24 + 97 - 37 + 106) & (0xEC ^ 0xA6 ^ 0x70 ^ 0x6C ^ -" ".length())) != -" ".length()) {}
      }
      else if (lIlIIlIIlIIIl(id, llIlIllIllI[8]))
      {
        if (lIlIIlIIIllIl(field_146338_v))
        {
          "".length();
          if ("   ".length() >= " ".length()) {
            break label927;
          }
        }
        label927:
        llIlIllIllI1field_146338_v = llIlIllIllI[2];
        llllllllllllllllIlIIlIlIIIllIIII.func_146319_h();
        "".length();
        if (" ".length() != 0) {}
      }
      else if (lIlIIlIIlIIIl(id, llIlIllIllI[6]))
      {
        selectedIndex += llIlIllIllI[2];
        if (lIlIIlIIIllII(selectedIndex, WorldType.worldTypes.length))
        {
          selectedIndex = llIlIllIllI[1];
          "".length();
          if (" ".length() < -" ".length()) {
            return;
          }
        }
        while (!lIlIIlIIIllIl(llllllllllllllllIlIIlIlIIIllIIII.func_175299_g()))
        {
          selectedIndex += llIlIllIllI[2];
          if (lIlIIlIIIllII(selectedIndex, WorldType.worldTypes.length)) {
            selectedIndex = llIlIllIllI[1];
          }
        }
        chunkProviderSettingsJson = llIlIllIIIl[llIlIllIllI[79]];
        llllllllllllllllIlIIlIlIIIllIIII.func_146319_h();
        llllllllllllllllIlIIlIlIIIllIIII.func_146316_a(field_146344_y);
        "".length();
        if (-"   ".length() <= 0) {}
      }
      else if (lIlIIlIIlIIIl(id, llIlIllIllI[7]))
      {
        field_146339_u = llIlIllIllI[2];
        if (lIlIIlIIIllIl(allowCheats))
        {
          "".length();
          if ("  ".length() >= 0) {
            break label1173;
          }
        }
        label1173:
        llIlIllIllI1allowCheats = llIlIllIllI[2];
        llllllllllllllllIlIIlIlIIIllIIII.func_146319_h();
        "".length();
        if (null == null) {}
      }
      else if (lIlIIlIIlIIIl(id, llIlIllIllI[9]))
      {
        if (lIlIIlIIlIIlI(WorldType.worldTypes[selectedIndex], WorldType.FLAT))
        {
          mc.displayGuiScreen(new GuiCreateFlatWorld(llllllllllllllllIlIIlIlIIIllIIII, chunkProviderSettingsJson));
          "".length();
          if ("  ".length() < "   ".length()) {}
        }
        else
        {
          mc.displayGuiScreen(new GuiCustomizeWorldScreen(llllllllllllllllIlIIlIlIIIllIIII, chunkProviderSettingsJson));
        }
      }
    }
  }
  
  public void onGuiClosed()
  {
    Keyboard.enableRepeatEvents(llIlIllIllI[1]);
  }
  
  private static int lIlIIlIIlIIII(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  private static boolean lIlIIlIlIIIll(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllIlIIlIIllIllIlll;
    return ??? < i;
  }
  
  protected void keyTyped(char llllllllllllllllIlIIlIlIIIIlIlll, int llllllllllllllllIlIIlIlIIIIlIIll)
    throws IOException
  {
    ;
    ;
    ;
    if ((lIlIIlIIIllIl(field_146333_g.isFocused())) && (lIlIIlIIIlllI(field_146344_y)))
    {
      "".length();
      field_146330_J = field_146333_g.getText();
      "".length();
      if (" ".length() == " ".length()) {}
    }
    else if ((lIlIIlIIIllIl(field_146335_h.isFocused())) && (lIlIIlIIIllIl(field_146344_y)))
    {
      "".length();
      field_146329_I = field_146335_h.getText();
    }
    if ((!lIlIIlIIlIlIl(llllllllllllllllIlIIlIlIIIIlIIll, llIlIllIllI[29])) || (lIlIIlIIlIIIl(llllllllllllllllIlIIlIlIIIIlIIll, llIlIllIllI[83]))) {
      llllllllllllllllIlIIlIlIIIIllIII.actionPerformed((GuiButton)buttonList.get(llIlIllIllI[1]));
    }
    if (lIlIIlIIlIllI(field_146333_g.getText().length()))
    {
      "".length();
      if (null == null) {
        break label219;
      }
    }
    label219:
    llIlIllIllI2enabled = llIlIllIllI[1];
    llllllllllllllllIlIIlIlIIIIllIII.func_146314_g();
  }
  
  public void initGui()
  {
    ;
    Keyboard.enableRepeatEvents(llIlIllIllI[2]);
    buttonList.clear();
    new GuiButton(llIlIllIllI[1], width / llIlIllIllI[3] - llIlIllIllI[28], height - llIlIllIllI[29], llIlIllIllI[30], llIlIllIllI[21], I18n.format(llIlIllIIIl[llIlIllIllI[29]], new Object[llIlIllIllI[1]]));
    "".length();
    new GuiButton(llIlIllIllI[2], width / llIlIllIllI[3] + llIlIllIllI[6], height - llIlIllIllI[29], llIlIllIllI[30], llIlIllIllI[21], I18n.format(llIlIllIIIl[llIlIllIllI[31]], new Object[llIlIllIllI[1]]));
    "".length();
    btnGameMode = new GuiButton(llIlIllIllI[3], width / llIlIllIllI[3] - llIlIllIllI[32], llIlIllIllI[33], llIlIllIllI[30], llIlIllIllI[21], I18n.format(llIlIllIIIl[llIlIllIllI[34]], new Object[llIlIllIllI[1]]));
    "".length();
    btnMoreOptions = new GuiButton(llIlIllIllI[4], width / llIlIllIllI[3] - llIlIllIllI[32], llIlIllIllI[35], llIlIllIllI[30], llIlIllIllI[21], I18n.format(llIlIllIIIl[llIlIllIllI[36]], new Object[llIlIllIllI[1]]));
    "".length();
    btnMapFeatures = new GuiButton(llIlIllIllI[5], width / llIlIllIllI[3] - llIlIllIllI[28], llIlIllIllI[37], llIlIllIllI[30], llIlIllIllI[21], I18n.format(llIlIllIIIl[llIlIllIllI[38]], new Object[llIlIllIllI[1]]));
    "".length();
    btnMapFeatures.visible = llIlIllIllI[1];
    btnBonusItems = new GuiButton(llIlIllIllI[8], width / llIlIllIllI[3] + llIlIllIllI[6], llIlIllIllI[39], llIlIllIllI[30], llIlIllIllI[21], I18n.format(llIlIllIIIl[llIlIllIllI[40]], new Object[llIlIllIllI[1]]));
    "".length();
    btnBonusItems.visible = llIlIllIllI[1];
    btnMapType = new GuiButton(llIlIllIllI[6], width / llIlIllIllI[3] + llIlIllIllI[6], llIlIllIllI[37], llIlIllIllI[30], llIlIllIllI[21], I18n.format(llIlIllIIIl[llIlIllIllI[41]], new Object[llIlIllIllI[1]]));
    "".length();
    btnMapType.visible = llIlIllIllI[1];
    btnAllowCommands = new GuiButton(llIlIllIllI[7], width / llIlIllIllI[3] - llIlIllIllI[28], llIlIllIllI[39], llIlIllIllI[30], llIlIllIllI[21], I18n.format(llIlIllIIIl[llIlIllIllI[42]], new Object[llIlIllIllI[1]]));
    "".length();
    btnAllowCommands.visible = llIlIllIllI[1];
    btnCustomizeType = new GuiButton(llIlIllIllI[9], width / llIlIllIllI[3] + llIlIllIllI[6], llIlIllIllI[43], llIlIllIllI[30], llIlIllIllI[21], I18n.format(llIlIllIIIl[llIlIllIllI[44]], new Object[llIlIllIllI[1]]));
    "".length();
    btnCustomizeType.visible = llIlIllIllI[1];
    field_146333_g = new GuiTextField(llIlIllIllI[10], fontRendererObj, width / llIlIllIllI[3] - llIlIllIllI[37], llIlIllIllI[45], llIlIllIllI[46], llIlIllIllI[21]);
    field_146333_g.setFocused(llIlIllIllI[2]);
    field_146333_g.setText(field_146330_J);
    field_146335_h = new GuiTextField(llIlIllIllI[11], fontRendererObj, width / llIlIllIllI[3] - llIlIllIllI[37], llIlIllIllI[45], llIlIllIllI[46], llIlIllIllI[21]);
    field_146335_h.setText(field_146329_I);
    llllllllllllllllIlIIlIlIIlIlllll.func_146316_a(field_146344_y);
    llllllllllllllllIlIIlIlIIlIlllll.func_146314_g();
    llllllllllllllllIlIIlIlIIlIlllll.func_146319_h();
  }
  
  private static boolean lIlIIlIIIllIl(int ???)
  {
    long llllllllllllllllIlIIlIIllIlIlIIl;
    return ??? != 0;
  }
  
  private static boolean lIlIIlIIlIIll(Object ???)
  {
    byte llllllllllllllllIlIIlIIllIlIllIl;
    return ??? != null;
  }
  
  private void func_146319_h()
  {
    ;
    btnGameMode.displayString = String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIllIIIl[llIlIllIllI[49]], new Object[llIlIllIllI[1]]))).append(llIlIllIIIl[llIlIllIllI[50]]).append(I18n.format(String.valueOf(new StringBuilder(llIlIllIIIl[llIlIllIllI[51]]).append(gameMode)), new Object[llIlIllIllI[1]])));
    field_146323_G = I18n.format(String.valueOf(new StringBuilder(llIlIllIIIl[llIlIllIllI[52]]).append(gameMode).append(llIlIllIIIl[llIlIllIllI[53]])), new Object[llIlIllIllI[1]]);
    field_146328_H = I18n.format(String.valueOf(new StringBuilder(llIlIllIIIl[llIlIllIllI[54]]).append(gameMode).append(llIlIllIIIl[llIlIllIllI[55]])), new Object[llIlIllIllI[1]]);
    btnMapFeatures.displayString = String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIllIIIl[llIlIllIllI[56]], new Object[llIlIllIllI[1]]))).append(llIlIllIIIl[llIlIllIllI[57]]));
    if (lIlIIlIIIllIl(field_146341_s))
    {
      btnMapFeatures.displayString = String.valueOf(new StringBuilder(String.valueOf(btnMapFeatures.displayString)).append(I18n.format(llIlIllIIIl[llIlIllIllI[58]], new Object[llIlIllIllI[1]])));
      "".length();
      if (null == null) {}
    }
    else
    {
      btnMapFeatures.displayString = String.valueOf(new StringBuilder(String.valueOf(btnMapFeatures.displayString)).append(I18n.format(llIlIllIIIl[llIlIllIllI[59]], new Object[llIlIllIllI[1]])));
    }
    btnBonusItems.displayString = String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIllIIIl[llIlIllIllI[60]], new Object[llIlIllIllI[1]]))).append(llIlIllIIIl[llIlIllIllI[61]]));
    if ((lIlIIlIIIllIl(field_146338_v)) && (lIlIIlIIIlllI(field_146337_w)))
    {
      btnBonusItems.displayString = String.valueOf(new StringBuilder(String.valueOf(btnBonusItems.displayString)).append(I18n.format(llIlIllIIIl[llIlIllIllI[62]], new Object[llIlIllIllI[1]])));
      "".length();
      if (null == null) {}
    }
    else
    {
      btnBonusItems.displayString = String.valueOf(new StringBuilder(String.valueOf(btnBonusItems.displayString)).append(I18n.format(llIlIllIIIl[llIlIllIllI[63]], new Object[llIlIllIllI[1]])));
    }
    btnMapType.displayString = String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIllIIIl[llIlIllIllI[64]], new Object[llIlIllIllI[1]]))).append(llIlIllIIIl[llIlIllIllI[65]]).append(I18n.format(WorldType.worldTypes[selectedIndex].getTranslateName(), new Object[llIlIllIllI[1]])));
    btnAllowCommands.displayString = String.valueOf(new StringBuilder(String.valueOf(I18n.format(llIlIllIIIl[llIlIllIllI[66]], new Object[llIlIllIllI[1]]))).append(llIlIllIIIl[llIlIllIllI[67]]));
    if ((lIlIIlIIIllIl(allowCheats)) && (lIlIIlIIIlllI(field_146337_w)))
    {
      btnAllowCommands.displayString = String.valueOf(new StringBuilder(String.valueOf(btnAllowCommands.displayString)).append(I18n.format(llIlIllIIIl[llIlIllIllI[68]], new Object[llIlIllIllI[1]])));
      "".length();
      if ((0x31 ^ 0x49 ^ 0x55 ^ 0x28) > 0) {}
    }
    else
    {
      btnAllowCommands.displayString = String.valueOf(new StringBuilder(String.valueOf(btnAllowCommands.displayString)).append(I18n.format(llIlIllIIIl[llIlIllIllI[69]], new Object[llIlIllIllI[1]])));
    }
  }
  
  public void func_146318_a(WorldInfo llllllllllllllllIlIIlIIlllllIlll)
  {
    ;
    ;
    field_146330_J = I18n.format(llIlIllIIIl[llIlIllIllI[99]], new Object[] { llllllllllllllllIlIIlIIlllllIlll.getWorldName() });
    field_146329_I = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllllIlIIlIIlllllIlll.getSeed())));
    selectedIndex = llllllllllllllllIlIIlIIlllllIlll.getTerrainType().getWorldTypeID();
    chunkProviderSettingsJson = llllllllllllllllIlIIlIIlllllIlll.getGeneratorOptions();
    field_146341_s = llllllllllllllllIlIIlIIlllllIlll.isMapFeaturesEnabled();
    allowCheats = llllllllllllllllIlIIlIIlllllIlll.areCommandsAllowed();
    if (lIlIIlIIIllIl(llllllllllllllllIlIIlIIlllllIlll.isHardcoreModeEnabled()))
    {
      gameMode = llIlIllIIIl[llIlIllIllI[100]];
      "".length();
      if (-" ".length() <= 0) {}
    }
    else if (lIlIIlIIIllIl(llllllllllllllllIlIIlIIlllllIlll.getGameType().isSurvivalOrAdventure()))
    {
      gameMode = llIlIllIIIl[llIlIllIllI[101]];
      "".length();
      if ((0x52 ^ 0x2C ^ 0xF4 ^ 0x8E) != -" ".length()) {}
    }
    else if (lIlIIlIIIllIl(llllllllllllllllIlIIlIIlllllIlll.getGameType().isCreative()))
    {
      gameMode = llIlIllIIIl[llIlIllIllI[102]];
    }
  }
  
  private static String lIlIIIlllIIll(String llllllllllllllllIlIIlIIllllIIlIl, String llllllllllllllllIlIIlIIllllIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIlIIlIIllllIIlIl = new String(Base64.getDecoder().decode(llllllllllllllllIlIIlIIllllIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIlIIlIIllllIlIII = new StringBuilder();
    char[] llllllllllllllllIlIIlIIllllIIlll = llllllllllllllllIlIIlIIllllIlIIl.toCharArray();
    int llllllllllllllllIlIIlIIllllIIllI = llIlIllIllI[1];
    char llllllllllllllllIlIIlIIllllIIIII = llllllllllllllllIlIIlIIllllIIlIl.toCharArray();
    long llllllllllllllllIlIIlIIlllIlllll = llllllllllllllllIlIIlIIllllIIIII.length;
    byte llllllllllllllllIlIIlIIlllIllllI = llIlIllIllI[1];
    while (lIlIIlIlIIIll(llllllllllllllllIlIIlIIlllIllllI, llllllllllllllllIlIIlIIlllIlllll))
    {
      char llllllllllllllllIlIIlIIllllIlIll = llllllllllllllllIlIIlIIllllIIIII[llllllllllllllllIlIIlIIlllIllllI];
      "".length();
      "".length();
      if (" ".length() != " ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIlIIlIIllllIlIII);
  }
  
  private static String lIlIIIlllIlII(String llllllllllllllllIlIIlIIlllIlIIll, String llllllllllllllllIlIIlIIlllIlIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIlIIlIIlllIllIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlIIlIIlllIlIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIlIIlIIlllIlIlll = Cipher.getInstance("Blowfish");
      llllllllllllllllIlIIlIIlllIlIlll.init(llIlIllIllI[3], llllllllllllllllIlIIlIIlllIllIII);
      return new String(llllllllllllllllIlIIlIIlllIlIlll.doFinal(Base64.getDecoder().decode(llllllllllllllllIlIIlIIlllIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIlIIlIIlllIlIllI)
    {
      llllllllllllllllIlIIlIIlllIlIllI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlIIlIIIlllI(int ???)
  {
    long llllllllllllllllIlIIlIIllIlIIlll;
    return ??? == 0;
  }
  
  private void func_146316_a(boolean llllllllllllllllIlIIlIlIIIIllllI)
  {
    ;
    ;
    field_146344_y = llllllllllllllllIlIIlIlIIIIllllI;
    if (lIlIIlIIlIIlI(WorldType.worldTypes[selectedIndex], WorldType.DEBUG_WORLD))
    {
      if (lIlIIlIIIllIl(field_146344_y))
      {
        "".length();
        if ("  ".length() == "  ".length()) {
          break label66;
        }
      }
      label66:
      llIlIllIllI1visible = llIlIllIllI[2];
      btnGameMode.enabled = llIlIllIllI[1];
      if (lIlIIlIIIllll(field_175300_s)) {
        field_175300_s = gameMode;
      }
      gameMode = llIlIllIIIl[llIlIllIllI[80]];
      btnMapFeatures.visible = llIlIllIllI[1];
      btnBonusItems.visible = llIlIllIllI[1];
      btnMapType.visible = field_146344_y;
      btnAllowCommands.visible = llIlIllIllI[1];
      btnCustomizeType.visible = llIlIllIllI[1];
      "".length();
      if (null == null) {}
    }
    else
    {
      if (lIlIIlIIIllIl(field_146344_y))
      {
        "".length();
        if ("  ".length() > " ".length()) {
          break label227;
        }
      }
      label227:
      llIlIllIllI1visible = llIlIllIllI[2];
      btnGameMode.enabled = llIlIllIllI[2];
      if (lIlIIlIIlIIll(field_175300_s))
      {
        gameMode = field_175300_s;
        field_175300_s = null;
      }
      if ((lIlIIlIIIllIl(field_146344_y)) && (lIlIIlIIlIlII(WorldType.worldTypes[selectedIndex], WorldType.CUSTOMIZED)))
      {
        "".length();
        if (-(0x9C ^ 0x98) < 0) {
          break label324;
        }
      }
      label324:
      llIlIllIllI2visible = llIlIllIllI[1];
      btnBonusItems.visible = field_146344_y;
      btnMapType.visible = field_146344_y;
      btnAllowCommands.visible = field_146344_y;
      if ((lIlIIlIIIllIl(field_146344_y)) && ((!lIlIIlIIlIlII(WorldType.worldTypes[selectedIndex], WorldType.FLAT)) || (lIlIIlIIlIIlI(WorldType.worldTypes[selectedIndex], WorldType.CUSTOMIZED))))
      {
        "".length();
        if (((0x2 ^ 0x61 ^ 0x9B ^ 0xAA) & (0xE1 ^ 0xBE ^ 0x28 ^ 0x25 ^ -" ".length())) == 0) {
          break label461;
        }
      }
      label461:
      llIlIllIllI2visible = llIlIllIllI[1];
    }
    llllllllllllllllIlIIlIlIIIIlllIl.func_146319_h();
    if (lIlIIlIIIllIl(field_146344_y))
    {
      btnMoreOptions.displayString = I18n.format(llIlIllIIIl[llIlIllIllI[81]], new Object[llIlIllIllI[1]]);
      "".length();
      if ("   ".length() == "   ".length()) {}
    }
    else
    {
      btnMoreOptions.displayString = I18n.format(llIlIllIIIl[llIlIllIllI[82]], new Object[llIlIllIllI[1]]);
    }
  }
  
  private static boolean lIlIIlIIIllll(Object ???)
  {
    int llllllllllllllllIlIIlIIllIlIlIll;
    return ??? == null;
  }
  
  private static boolean lIlIIlIIlIIlI(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllllIlIIlIIllIlIllll;
    return ??? == localObject;
  }
  
  public GuiCreateWorld(GuiScreen llllllllllllllllIlIIlIlIIllIIlII)
  {
    parentScreen = llllllllllllllllIlIIlIlIIllIIlII;
    field_146329_I = llIlIllIIIl[llIlIllIllI[26]];
    field_146330_J = I18n.format(llIlIllIIIl[llIlIllIllI[27]], new Object[llIlIllIllI[1]]);
  }
  
  private static boolean lIlIIlIIIllII(int ???, int arg1)
  {
    int i;
    byte llllllllllllllllIlIIlIIllIlllIll;
    return ??? >= i;
  }
  
  private static boolean lIlIIlIIlIlIl(int ???, int arg1)
  {
    int i;
    byte llllllllllllllllIlIIlIIllIlIIIIl;
    return ??? != i;
  }
}

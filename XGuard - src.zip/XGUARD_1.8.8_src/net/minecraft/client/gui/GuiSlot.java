package net.minecraft.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Mouse;

public abstract class GuiSlot
{
  protected void drawListHeader(int llllllllllllllllIIllIllIIlIIlIll, int llllllllllllllllIIllIllIIlIIlIlI, Tessellator llllllllllllllllIIllIllIIlIIlIIl) {}
  
  public void handleMouseInput()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIllllllIIl(llllllllllllllllIIllIlIlllIlIlII.isMouseYWithinSlotBounds(mouseY)))
    {
      if ((lIlIlllllIlII(Mouse.getEventButton())) && (lIlIllllllIIl(Mouse.getEventButtonState())) && (lIlIlllllIllI(mouseY, top)) && (lIlIlllllIlll(mouseY, bottom)))
      {
        int llllllllllllllllIIllIlIlllIlIIll = (width - llllllllllllllllIIllIlIlllIIIlII.getListWidth()) / lllIIlIIIll[4];
        int llllllllllllllllIIllIlIlllIlIIlI = (width + llllllllllllllllIIllIlIlllIIIlII.getListWidth()) / lllIIlIIIll[4];
        int llllllllllllllllIIllIlIlllIlIIIl = mouseY - top - headerPadding + (int)amountScrolled - lllIIlIIIll[5];
        int llllllllllllllllIIllIlIlllIlIIII = llllllllllllllllIIllIlIlllIlIIIl / slotHeight;
        if ((lIlIlllllIlIl(llllllllllllllllIIllIlIlllIlIIII, llllllllllllllllIIllIlIlllIIIlII.getSize())) && (lIlIlllllIllI(mouseX, llllllllllllllllIIllIlIlllIlIIll)) && (lIlIlllllIlll(mouseX, llllllllllllllllIIllIlIlllIlIIlI)) && (lIlIllllllIII(llllllllllllllllIIllIlIlllIlIIII)) && (lIlIllllllIII(llllllllllllllllIIllIlIlllIlIIIl)))
        {
          llllllllllllllllIIllIlIlllIIIlII.elementClicked(llllllllllllllllIIllIlIlllIlIIII, lllIIlIIIll[3], mouseX, mouseY);
          selectedElement = llllllllllllllllIIllIlIlllIlIIII;
          "".length();
          if ((0x89 ^ 0x8D) >= " ".length()) {}
        }
        else if ((lIlIlllllIllI(mouseX, llllllllllllllllIIllIlIlllIlIIll)) && (lIlIlllllIlll(mouseX, llllllllllllllllIIllIlIlllIlIIlI)) && (lIllIIIIIIIII(llllllllllllllllIIllIlIlllIlIIIl)))
        {
          llllllllllllllllIIllIlIlllIIIlII.func_148132_a(mouseX - llllllllllllllllIIllIlIlllIlIIll, mouseY - top + (int)amountScrolled - lllIIlIIIll[5]);
        }
      }
      if ((lIlIllllllIIl(Mouse.isButtonDown(lllIIlIIIll[3]))) && (lIlIllllllIIl(llllllllllllllllIIllIlIlllIIIlII.getEnabled())))
      {
        if (lIlIllllllIlI(initialClickY, lllIIlIIIll[2]))
        {
          boolean llllllllllllllllIIllIlIlllIIllll = lllIIlIIIll[0];
          if ((lIlIlllllIllI(mouseY, top)) && (lIlIlllllIlll(mouseY, bottom)))
          {
            int llllllllllllllllIIllIlIlllIIlllI = (width - llllllllllllllllIIllIlIlllIIIlII.getListWidth()) / lllIIlIIIll[4];
            int llllllllllllllllIIllIlIlllIIllIl = (width + llllllllllllllllIIllIlIlllIIIlII.getListWidth()) / lllIIlIIIll[4];
            int llllllllllllllllIIllIlIlllIIllII = mouseY - top - headerPadding + (int)amountScrolled - lllIIlIIIll[5];
            int llllllllllllllllIIllIlIlllIIlIll = llllllllllllllllIIllIlIlllIIllII / slotHeight;
            if ((lIlIlllllIlIl(llllllllllllllllIIllIlIlllIIlIll, llllllllllllllllIIllIlIlllIIIlII.getSize())) && (lIlIlllllIllI(mouseX, llllllllllllllllIIllIlIlllIIlllI)) && (lIlIlllllIlll(mouseX, llllllllllllllllIIllIlIlllIIllIl)) && (lIlIllllllIII(llllllllllllllllIIllIlIlllIIlIll)) && (lIlIllllllIII(llllllllllllllllIIllIlIlllIIllII)))
            {
              if ((lIlIllllllIlI(llllllllllllllllIIllIlIlllIIlIll, selectedElement)) && (lIllIIIIIIIII(lIlIlllllllll(Minecraft.getSystemTime() - lastClicked, 250L))))
              {
                "".length();
                if (-" ".length() == -" ".length()) {
                  break label539;
                }
              }
              label539:
              boolean llllllllllllllllIIllIlIlllIIlIlI = lllIIlIIIll[3];
              llllllllllllllllIIllIlIlllIIIlII.elementClicked(llllllllllllllllIIllIlIlllIIlIll, llllllllllllllllIIllIlIlllIIlIlI, mouseX, mouseY);
              selectedElement = llllllllllllllllIIllIlIlllIIlIll;
              lastClicked = Minecraft.getSystemTime();
              "".length();
              if (-"  ".length() < 0) {}
            }
            else if ((lIlIlllllIllI(mouseX, llllllllllllllllIIllIlIlllIIlllI)) && (lIlIlllllIlll(mouseX, llllllllllllllllIIllIlIlllIIllIl)) && (lIllIIIIIIIII(llllllllllllllllIIllIlIlllIIllII)))
            {
              llllllllllllllllIIllIlIlllIIIlII.func_148132_a(mouseX - llllllllllllllllIIllIlIlllIIlllI, mouseY - top + (int)amountScrolled - lllIIlIIIll[5]);
              llllllllllllllllIIllIlIlllIIllll = lllIIlIIIll[3];
            }
            int llllllllllllllllIIllIlIlllIIlIIl = llllllllllllllllIIllIlIlllIIIlII.getScrollBarX();
            int llllllllllllllllIIllIlIlllIIlIII = llllllllllllllllIIllIlIlllIIlIIl + lllIIlIIIll[7];
            if ((lIlIlllllIllI(mouseX, llllllllllllllllIIllIlIlllIIlIIl)) && (lIlIlllllIlll(mouseX, llllllllllllllllIIllIlIlllIIlIII)))
            {
              scrollMultiplier = -1.0F;
              int llllllllllllllllIIllIlIlllIIIlll = llllllllllllllllIIllIlIlllIIIlII.func_148135_f();
              if (lIlIlllllIlIl(llllllllllllllllIIllIlIlllIIIlll, lllIIlIIIll[0])) {
                llllllllllllllllIIllIlIlllIIIlll = lllIIlIIIll[0];
              }
              int llllllllllllllllIIllIlIlllIIIllI = (int)((bottom - top) * (bottom - top) / llllllllllllllllIIllIlIlllIIIlII.getContentHeight());
              llllllllllllllllIIllIlIlllIIIllI = MathHelper.clamp_int(llllllllllllllllIIllIlIlllIIIllI, lllIIlIIIll[9], bottom - top - lllIIlIIIll[14]);
              scrollMultiplier /= (bottom - top - llllllllllllllllIIllIlIlllIIIllI) / llllllllllllllllIIllIlIlllIIIlll;
              "".length();
              if (((0x5A ^ 0x49 ^ 0x1D ^ 0x0) & (120 + 124 - 199 + 107 ^ 34 + 114 - 51 + 53 ^ -" ".length())) == 0) {}
            }
            else
            {
              scrollMultiplier = 1.0F;
            }
            if (lIlIllllllIIl(llllllllllllllllIIllIlIlllIIllll))
            {
              initialClickY = mouseY;
              "".length();
              if ("  ".length() != 0) {}
            }
            else
            {
              initialClickY = lllIIlIIIll[1];
              "".length();
              if ("  ".length() != 0) {}
            }
          }
          else
          {
            initialClickY = lllIIlIIIll[1];
            "".length();
            if (null == null) {}
          }
        }
        else if (lIlIllllllIII(initialClickY))
        {
          amountScrolled -= (mouseY - initialClickY) * scrollMultiplier;
          initialClickY = mouseY;
          "".length();
          if (("  ".length() & ("  ".length() ^ 0xFFFFFFFF)) < " ".length()) {}
        }
      }
      else {
        initialClickY = lllIIlIIIll[2];
      }
      int llllllllllllllllIIllIlIlllIIIlIl = Mouse.getEventDWheel();
      if (lIlIllllllIIl(llllllllllllllllIIllIlIlllIIIlIl))
      {
        if (lIlIlllllllII(llllllllllllllllIIllIlIlllIIIlIl))
        {
          llllllllllllllllIIllIlIlllIIIlIl = lllIIlIIIll[2];
          "".length();
          if (-(0x23 ^ 0x27) <= 0) {}
        }
        else if (lIllIIIIIIIII(llllllllllllllllIIllIlIlllIIIlIl))
        {
          llllllllllllllllIIllIlIlllIIIlIl = lllIIlIIIll[0];
        }
        amountScrolled += llllllllllllllllIIllIlIlllIIIlIl * slotHeight / lllIIlIIIll[4];
      }
    }
  }
  
  protected abstract void elementClicked(int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3);
  
  public int getListWidth()
  {
    return lllIIlIIIll[18];
  }
  
  public void setSlotXBoundsFromLeft(int llllllllllllllllIIllIlIlIllIlIIl)
  {
    ;
    ;
    left = llllllllllllllllIIllIlIlIllIlIIl;
    right = (llllllllllllllllIIllIlIlIllIlIIl + width);
  }
  
  protected void func_148132_a(int llllllllllllllllIIllIllIIlIIIlll, int llllllllllllllllIIllIllIIlIIIllI) {}
  
  public void setShowSelectionBox(boolean llllllllllllllllIIllIllIIlIlllIl)
  {
    ;
    ;
    showSelectionBox = llllllllllllllllIIllIllIIlIlllIl;
  }
  
  static {}
  
  private static boolean lIlIlllllIllI(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllllIIllIlIlIlIllllI;
    return ??? >= i;
  }
  
  public boolean isMouseYWithinSlotBounds(int llllllllllllllllIIllIllIIIIllIII)
  {
    ;
    ;
    if ((lIlIlllllIllI(llllllllllllllllIIllIllIIIIllIII, top)) && (lIlIlllllIlll(llllllllllllllllIIllIllIIIIllIII, bottom)) && (lIlIlllllIllI(mouseX, left)) && (lIlIlllllIlll(mouseX, right))) {
      return lllIIlIIIll[0];
    }
    return lllIIlIIIll[3];
  }
  
  public void registerScrollButtons(int llllllllllllllllIIllIllIIIlIIllI, int llllllllllllllllIIllIllIIIlIlIII)
  {
    ;
    ;
    ;
    scrollUpButtonID = llllllllllllllllIIllIllIIIlIlIIl;
    scrollDownButtonID = llllllllllllllllIIllIllIIIlIlIII;
  }
  
  public void scrollBy(int llllllllllllllllIIllIllIIIIlIIII)
  {
    ;
    ;
    amountScrolled += llllllllllllllllIIllIllIIIIlIIII;
    llllllllllllllllIIllIllIIIIlIIIl.bindAmountScrolled();
    initialClickY = lllIIlIIIll[1];
  }
  
  public void actionPerformed(GuiButton llllllllllllllllIIllIllIIIIIlIlI)
  {
    ;
    ;
    if (lIlIllllllIIl(enabled)) {
      if (lIlIllllllIlI(id, scrollUpButtonID))
      {
        amountScrolled -= slotHeight * lllIIlIIIll[4] / lllIIlIIIll[6];
        initialClickY = lllIIlIIIll[1];
        llllllllllllllllIIllIllIIIIIlIll.bindAmountScrolled();
        "".length();
        if (null == null) {}
      }
      else if (lIlIllllllIlI(id, scrollDownButtonID))
      {
        amountScrolled += slotHeight * lllIIlIIIll[4] / lllIIlIIIll[6];
        initialClickY = lllIIlIIIll[1];
        llllllllllllllllIIllIllIIIIIlIll.bindAmountScrolled();
      }
    }
  }
  
  protected abstract int getSize();
  
  protected void overlayBackground(int llllllllllllllllIIllIlIlIlllllIl, int llllllllllllllllIIllIlIlIlllIlII, int llllllllllllllllIIllIlIlIllllIll, int llllllllllllllllIIllIlIlIllllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Tessellator llllllllllllllllIIllIlIlIllllIIl = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIIllIlIlIllllIII = llllllllllllllllIIllIlIlIllllIIl.getWorldRenderer();
    mc.getTextureManager().bindTexture(Gui.optionsBackground);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    float llllllllllllllllIIllIlIlIlllIlll = 32.0F;
    llllllllllllllllIIllIlIlIllllIII.begin(lllIIlIIIll[8], DefaultVertexFormats.POSITION_TEX_COLOR);
    llllllllllllllllIIllIlIlIllllIII.pos(left, llllllllllllllllIIllIlIlIlllllII, 0.0D).tex(0.0D, llllllllllllllllIIllIlIlIlllllII / 32.0F).color(lllIIlIIIll[20], lllIIlIIIll[20], lllIIlIIIll[20], llllllllllllllllIIllIlIlIllllIlI).endVertex();
    llllllllllllllllIIllIlIlIllllIII.pos(left + width, llllllllllllllllIIllIlIlIlllllII, 0.0D).tex(width / 32.0F, llllllllllllllllIIllIlIlIlllllII / 32.0F).color(lllIIlIIIll[20], lllIIlIIIll[20], lllIIlIIIll[20], llllllllllllllllIIllIlIlIllllIlI).endVertex();
    llllllllllllllllIIllIlIlIllllIII.pos(left + width, llllllllllllllllIIllIlIlIlllllIl, 0.0D).tex(width / 32.0F, llllllllllllllllIIllIlIlIlllllIl / 32.0F).color(lllIIlIIIll[20], lllIIlIIIll[20], lllIIlIIIll[20], llllllllllllllllIIllIlIlIllllIll).endVertex();
    llllllllllllllllIIllIlIlIllllIII.pos(left, llllllllllllllllIIllIlIlIlllllIl, 0.0D).tex(0.0D, llllllllllllllllIIllIlIlIlllllIl / 32.0F).color(lllIIlIIIll[20], lllIIlIIIll[20], lllIIlIIIll[20], llllllllllllllllIIllIlIlIllllIll).endVertex();
    llllllllllllllllIIllIlIlIllllIIl.draw();
  }
  
  public void drawScreen(int llllllllllllllllIIllIlIllllllIlI, int llllllllllllllllIIllIlIllllIlIlI, float llllllllllllllllIIllIlIllllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIllllllIIl(field_178041_q))
    {
      mouseX = llllllllllllllllIIllIlIllllllIlI;
      mouseY = llllllllllllllllIIllIlIllllIlIlI;
      llllllllllllllllIIllIlIllllllIll.drawBackground();
      int llllllllllllllllIIllIlIlllllIlll = llllllllllllllllIIllIlIllllllIll.getScrollBarX();
      int llllllllllllllllIIllIlIlllllIllI = llllllllllllllllIIllIlIlllllIlll + lllIIlIIIll[7];
      llllllllllllllllIIllIlIllllllIll.bindAmountScrolled();
      GlStateManager.disableLighting();
      GlStateManager.disableFog();
      Tessellator llllllllllllllllIIllIlIlllllIlIl = Tessellator.getInstance();
      WorldRenderer llllllllllllllllIIllIlIlllllIlII = llllllllllllllllIIllIlIlllllIlIl.getWorldRenderer();
      mc.getTextureManager().bindTexture(Gui.optionsBackground);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      float llllllllllllllllIIllIlIlllllIIll = 32.0F;
      llllllllllllllllIIllIlIlllllIlII.begin(lllIIlIIIll[8], DefaultVertexFormats.POSITION_TEX_COLOR);
      llllllllllllllllIIllIlIlllllIlII.pos(left, bottom, 0.0D).tex(left / llllllllllllllllIIllIlIlllllIIll, (bottom + (int)amountScrolled) / llllllllllllllllIIllIlIlllllIIll).color(lllIIlIIIll[9], lllIIlIIIll[9], lllIIlIIIll[9], lllIIlIIIll[10]).endVertex();
      llllllllllllllllIIllIlIlllllIlII.pos(right, bottom, 0.0D).tex(right / llllllllllllllllIIllIlIlllllIIll, (bottom + (int)amountScrolled) / llllllllllllllllIIllIlIlllllIIll).color(lllIIlIIIll[9], lllIIlIIIll[9], lllIIlIIIll[9], lllIIlIIIll[10]).endVertex();
      llllllllllllllllIIllIlIlllllIlII.pos(right, top, 0.0D).tex(right / llllllllllllllllIIllIlIlllllIIll, (top + (int)amountScrolled) / llllllllllllllllIIllIlIlllllIIll).color(lllIIlIIIll[9], lllIIlIIIll[9], lllIIlIIIll[9], lllIIlIIIll[10]).endVertex();
      llllllllllllllllIIllIlIlllllIlII.pos(left, top, 0.0D).tex(left / llllllllllllllllIIllIlIlllllIIll, (top + (int)amountScrolled) / llllllllllllllllIIllIlIlllllIIll).color(lllIIlIIIll[9], lllIIlIIIll[9], lllIIlIIIll[9], lllIIlIIIll[10]).endVertex();
      llllllllllllllllIIllIlIlllllIlIl.draw();
      int llllllllllllllllIIllIlIlllllIIlI = left + width / lllIIlIIIll[4] - llllllllllllllllIIllIlIllllllIll.getListWidth() / lllIIlIIIll[4] + lllIIlIIIll[4];
      int llllllllllllllllIIllIlIlllllIIIl = top + lllIIlIIIll[5] - (int)amountScrolled;
      if (lIlIllllllIIl(hasListHeader)) {
        llllllllllllllllIIllIlIllllllIll.drawListHeader(llllllllllllllllIIllIlIlllllIIlI, llllllllllllllllIIllIlIlllllIIIl, llllllllllllllllIIllIlIlllllIlIl);
      }
      llllllllllllllllIIllIlIllllllIll.drawSelectionBox(llllllllllllllllIIllIlIlllllIIlI, llllllllllllllllIIllIlIlllllIIIl, llllllllllllllllIIllIlIllllllIlI, llllllllllllllllIIllIlIllllIlIlI);
      GlStateManager.disableDepth();
      int llllllllllllllllIIllIlIlllllIIII = lllIIlIIIll[5];
      llllllllllllllllIIllIlIllllllIll.overlayBackground(lllIIlIIIll[3], top, lllIIlIIIll[10], lllIIlIIIll[10]);
      llllllllllllllllIIllIlIllllllIll.overlayBackground(bottom, height, lllIIlIIIll[10], lllIIlIIIll[10]);
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(lllIIlIIIll[11], lllIIlIIIll[12], lllIIlIIIll[3], lllIIlIIIll[0]);
      GlStateManager.disableAlpha();
      GlStateManager.shadeModel(lllIIlIIIll[13]);
      GlStateManager.disableTexture2D();
      llllllllllllllllIIllIlIlllllIlII.begin(lllIIlIIIll[8], DefaultVertexFormats.POSITION_TEX_COLOR);
      llllllllllllllllIIllIlIlllllIlII.pos(left, top + llllllllllllllllIIllIlIlllllIIII, 0.0D).tex(0.0D, 1.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3]).endVertex();
      llllllllllllllllIIllIlIlllllIlII.pos(right, top + llllllllllllllllIIllIlIlllllIIII, 0.0D).tex(1.0D, 1.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3]).endVertex();
      llllllllllllllllIIllIlIlllllIlII.pos(right, top, 0.0D).tex(1.0D, 0.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
      llllllllllllllllIIllIlIlllllIlII.pos(left, top, 0.0D).tex(0.0D, 0.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
      llllllllllllllllIIllIlIlllllIlIl.draw();
      llllllllllllllllIIllIlIlllllIlII.begin(lllIIlIIIll[8], DefaultVertexFormats.POSITION_TEX_COLOR);
      llllllllllllllllIIllIlIlllllIlII.pos(left, bottom, 0.0D).tex(0.0D, 1.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
      llllllllllllllllIIllIlIlllllIlII.pos(right, bottom, 0.0D).tex(1.0D, 1.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
      llllllllllllllllIIllIlIlllllIlII.pos(right, bottom - llllllllllllllllIIllIlIlllllIIII, 0.0D).tex(1.0D, 0.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3]).endVertex();
      llllllllllllllllIIllIlIlllllIlII.pos(left, bottom - llllllllllllllllIIllIlIlllllIIII, 0.0D).tex(0.0D, 0.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3]).endVertex();
      llllllllllllllllIIllIlIlllllIlIl.draw();
      int llllllllllllllllIIllIlIllllIllll = llllllllllllllllIIllIlIllllllIll.func_148135_f();
      if (lIlIlllllllII(llllllllllllllllIIllIlIllllIllll))
      {
        int llllllllllllllllIIllIlIllllIlllI = (bottom - top) * (bottom - top) / llllllllllllllllIIllIlIllllllIll.getContentHeight();
        llllllllllllllllIIllIlIllllIlllI = MathHelper.clamp_int(llllllllllllllllIIllIlIllllIlllI, lllIIlIIIll[9], bottom - top - lllIIlIIIll[14]);
        int llllllllllllllllIIllIlIllllIllIl = (int)amountScrolled * (bottom - top - llllllllllllllllIIllIlIllllIlllI) / llllllllllllllllIIllIlIllllIllll + top;
        if (lIlIlllllIlIl(llllllllllllllllIIllIlIllllIllIl, top)) {
          llllllllllllllllIIllIlIllllIllIl = top;
        }
        llllllllllllllllIIllIlIlllllIlII.begin(lllIIlIIIll[8], DefaultVertexFormats.POSITION_TEX_COLOR);
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIlll, bottom, 0.0D).tex(0.0D, 1.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIllI, bottom, 0.0D).tex(1.0D, 1.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIllI, top, 0.0D).tex(1.0D, 0.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIlll, top, 0.0D).tex(0.0D, 0.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlIl.draw();
        llllllllllllllllIIllIlIlllllIlII.begin(lllIIlIIIll[8], DefaultVertexFormats.POSITION_TEX_COLOR);
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIlll, llllllllllllllllIIllIlIllllIllIl + llllllllllllllllIIllIlIllllIlllI, 0.0D).tex(0.0D, 1.0D).color(lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIllI, llllllllllllllllIIllIlIllllIllIl + llllllllllllllllIIllIlIllllIlllI, 0.0D).tex(1.0D, 1.0D).color(lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIllI, llllllllllllllllIIllIlIllllIllIl, 0.0D).tex(1.0D, 0.0D).color(lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIlll, llllllllllllllllIIllIlIllllIllIl, 0.0D).tex(0.0D, 0.0D).color(lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlIl.draw();
        llllllllllllllllIIllIlIlllllIlII.begin(lllIIlIIIll[8], DefaultVertexFormats.POSITION_TEX_COLOR);
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIlll, llllllllllllllllIIllIlIllllIllIl + llllllllllllllllIIllIlIllllIlllI - lllIIlIIIll[0], 0.0D).tex(0.0D, 1.0D).color(lllIIlIIIll[16], lllIIlIIIll[16], lllIIlIIIll[16], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIllI - lllIIlIIIll[0], llllllllllllllllIIllIlIllllIllIl + llllllllllllllllIIllIlIllllIlllI - lllIIlIIIll[0], 0.0D).tex(1.0D, 1.0D).color(lllIIlIIIll[16], lllIIlIIIll[16], lllIIlIIIll[16], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIllI - lllIIlIIIll[0], llllllllllllllllIIllIlIllllIllIl, 0.0D).tex(1.0D, 0.0D).color(lllIIlIIIll[16], lllIIlIIIll[16], lllIIlIIIll[16], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlII.pos(llllllllllllllllIIllIlIlllllIlll, llllllllllllllllIIllIlIllllIllIl, 0.0D).tex(0.0D, 0.0D).color(lllIIlIIIll[16], lllIIlIIIll[16], lllIIlIIIll[16], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIlllllIlIl.draw();
      }
      llllllllllllllllIIllIlIllllllIll.func_148142_b(llllllllllllllllIIllIlIllllllIlI, llllllllllllllllIIllIlIllllIlIlI);
      GlStateManager.enableTexture2D();
      GlStateManager.shadeModel(lllIIlIIIll[17]);
      GlStateManager.enableAlpha();
      GlStateManager.disableBlend();
    }
  }
  
  public boolean getEnabled()
  {
    ;
    return enabled;
  }
  
  public int getSlotIndexFromScreenCoords(int llllllllllllllllIIllIllIIIlllIlI, int llllllllllllllllIIllIllIIIlllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllllIIllIllIIIlllIII = left + width / lllIIlIIIll[4] - llllllllllllllllIIllIllIIIlllIll.getListWidth() / lllIIlIIIll[4];
    int llllllllllllllllIIllIllIIIllIlll = left + width / lllIIlIIIll[4] + llllllllllllllllIIllIllIIIlllIll.getListWidth() / lllIIlIIIll[4];
    int llllllllllllllllIIllIllIIIllIllI = llllllllllllllllIIllIllIIIlllIIl - top - headerPadding + (int)amountScrolled - lllIIlIIIll[5];
    int llllllllllllllllIIllIllIIIllIlIl = llllllllllllllllIIllIllIIIllIllI / slotHeight;
    if ((lIlIlllllIlIl(llllllllllllllllIIllIllIIIllIIll, llllllllllllllllIIllIllIIIlllIll.getScrollBarX())) && (lIlIlllllIllI(llllllllllllllllIIllIllIIIllIIll, llllllllllllllllIIllIllIIIlllIII)) && (lIlIlllllIlll(llllllllllllllllIIllIllIIIllIIll, llllllllllllllllIIllIllIIIllIlll)) && (lIlIllllllIII(llllllllllllllllIIllIllIIIllIlIl)) && (lIlIllllllIII(llllllllllllllllIIllIllIIIllIllI)) && (lIlIlllllIlIl(llllllllllllllllIIllIllIIIllIlIl, llllllllllllllllIIllIllIIIlllIll.getSize())))
    {
      "".length();
      if ("   ".length() >= " ".length()) {
        break label205;
      }
      return (0x4A ^ 0xA ^ 0x74 ^ 0x2E) & (0x5C ^ 0x43 ^ 0x8A ^ 0x8F ^ -" ".length());
    }
    label205:
    return lllIIlIIIll[2];
  }
  
  protected void func_178040_a(int llllllllllllllllIIllIllIIlIIllll, int llllllllllllllllIIllIllIIlIIlllI, int llllllllllllllllIIllIllIIlIIllIl) {}
  
  private static boolean lIlIlllllllII(int ???)
  {
    Exception llllllllllllllllIIllIlIlIlIIllII;
    return ??? > 0;
  }
  
  public int func_148135_f()
  {
    ;
    return Math.max(lllIIlIIIll[3], llllllllllllllllIIllIllIIIlIIIII.getContentHeight() - (bottom - top - lllIIlIIIll[5]));
  }
  
  protected abstract void drawSlot(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  private static boolean lIlIlllllIlll(int ???, int arg1)
  {
    int i;
    char llllllllllllllllIIllIlIlIlIlIllI;
    return ??? <= i;
  }
  
  private static boolean lIlIllllllIII(int ???)
  {
    byte llllllllllllllllIIllIlIlIlIlIIII;
    return ??? >= 0;
  }
  
  public void setEnabled(boolean llllllllllllllllIIllIlIllIllIlIl)
  {
    ;
    ;
    enabled = llllllllllllllllIIllIlIllIllIlIl;
  }
  
  private static void lIlIlllllIIll()
  {
    lllIIlIIIll = new int[21];
    lllIIlIIIll[0] = " ".length();
    lllIIlIIIll[1] = (-"  ".length());
    lllIIlIIIll[2] = (-" ".length());
    lllIIlIIIll[3] = ((0x21 ^ 0x66 ^ 0x6F ^ 0x1) & (100 + 110 - 49 + 14 ^ 44 + 9 - -17 + 64 ^ -" ".length()));
    lllIIlIIIll[4] = "  ".length();
    lllIIlIIIll[5] = (0x29 ^ 0x60 ^ 0x4B ^ 0x6);
    lllIIlIIIll[6] = "   ".length();
    lllIIlIIIll[7] = (0x23 ^ 0x55 ^ 0x30 ^ 0x40);
    lllIIlIIIll[8] = (0xBD ^ 0xB7 ^ 0x7A ^ 0x77);
    lllIIlIIIll[9] = (0x9F ^ 0xBF);
    lllIIlIIIll[10] = (96 + 3 - -13 + 43 + ('°' + 17 - -26 + 29) - (118 + '¾' - 118 + 4) + (0x3A ^ 0x14));
    lllIIlIIIll[11] = (-(0xE4AB & 0x5B7D) & 0xF32A & 0x4FFF);
    lllIIlIIIll[12] = (-(0xDEFD & 0x31DF) & 0xDFFF & 0x33DF);
    lllIIlIIIll[13] = (0xBF8D & 0x5D73);
    lllIIlIIIll[14] = (0x40 ^ 0x48);
    lllIIlIIIll[15] = (2 + 72 - -29 + 25);
    lllIIlIIIll[16] = (43 + '½' - 213 + 173);
    lllIIlIIIll[17] = (-(0xF6DB & 0x6B7D) & 0xFF7B & 0x7FDC);
    lllIIlIIIll[18] = (91 + 60 - 22 + 81 + (117 + '' - 158 + 70) - (0xD9FA & 0x277F) + (91 + 'Å' - 146 + 66));
    lllIIlIIIll[19] = (0x44 ^ 0x38);
    lllIIlIIIll[20] = (0x85 ^ 0x90 ^ 0xC2 ^ 0x97);
  }
  
  public void setDimensions(int llllllllllllllllIIllIllIIllIlIll, int llllllllllllllllIIllIllIIllIlIlI, int llllllllllllllllIIllIllIIllIIlII, int llllllllllllllllIIllIllIIllIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    width = llllllllllllllllIIllIllIIllIlIll;
    height = llllllllllllllllIIllIllIIllIIlIl;
    top = llllllllllllllllIIllIllIIllIIlII;
    bottom = llllllllllllllllIIllIllIIllIIIll;
    left = lllIIlIIIll[3];
    right = llllllllllllllllIIllIllIIllIlIll;
  }
  
  public int getAmountScrolled()
  {
    ;
    return (int)amountScrolled;
  }
  
  protected int getScrollBarX()
  {
    ;
    return width / lllIIlIIIll[4] + lllIIlIIIll[19];
  }
  
  private static int lIlIlllllllll(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  protected void func_148142_b(int llllllllllllllllIIllIllIIlIIIlII, int llllllllllllllllIIllIllIIlIIIIll) {}
  
  private static boolean lIlIllllllIlI(int ???, int arg1)
  {
    int i;
    byte llllllllllllllllIIllIlIlIllIIIlI;
    return ??? == i;
  }
  
  protected void setHasListHeader(boolean llllllllllllllllIIllIllIIlIllIII, int llllllllllllllllIIllIllIIlIlIlII)
  {
    ;
    ;
    ;
    hasListHeader = llllllllllllllllIIllIllIIlIlIlIl;
    headerPadding = llllllllllllllllIIllIllIIlIlIlII;
    if (lIlIlllllIlII(llllllllllllllllIIllIllIIlIlIlIl)) {
      headerPadding = lllIIlIIIll[3];
    }
  }
  
  private static boolean lIlIllllllIIl(int ???)
  {
    int llllllllllllllllIIllIlIlIlIlIlII;
    return ??? != 0;
  }
  
  public GuiSlot(Minecraft llllllllllllllllIIllIllIIlllIlll, int llllllllllllllllIIllIllIIlllIllI, int llllllllllllllllIIllIllIIlllllII, int llllllllllllllllIIllIllIIllllIll, int llllllllllllllllIIllIllIIllllIlI, int llllllllllllllllIIllIllIIlllIIlI)
  {
    mc = llllllllllllllllIIllIllIIlllIlll;
    width = llllllllllllllllIIllIllIIlllIllI;
    height = llllllllllllllllIIllIllIIlllIlIl;
    top = llllllllllllllllIIllIllIIllllIll;
    bottom = llllllllllllllllIIllIllIIllllIlI;
    slotHeight = llllllllllllllllIIllIllIIlllIIlI;
    left = lllIIlIIIll[3];
    right = llllllllllllllllIIllIllIIlllIllI;
  }
  
  public int getSlotHeight()
  {
    ;
    return slotHeight;
  }
  
  protected abstract void drawBackground();
  
  private static boolean lIlIlllllIlII(int ???)
  {
    int llllllllllllllllIIllIlIlIlIlIIlI;
    return ??? == 0;
  }
  
  private static boolean lIlIlllllIlIl(int ???, int arg1)
  {
    int i;
    int llllllllllllllllIIllIlIlIlIllIlI;
    return ??? < i;
  }
  
  protected int getContentHeight()
  {
    ;
    return llllllllllllllllIIllIllIIlIlIIlI.getSize() * slotHeight + headerPadding;
  }
  
  protected void bindAmountScrolled()
  {
    ;
    amountScrolled = MathHelper.clamp_float(amountScrolled, 0.0F, llllllllllllllllIIllIllIIIlIIIll.func_148135_f());
  }
  
  protected void drawSelectionBox(int llllllllllllllllIIllIlIllIlIIIlI, int llllllllllllllllIIllIlIllIIlIlII, int llllllllllllllllIIllIlIllIIlIIll, int llllllllllllllllIIllIlIllIIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllllIIllIlIllIIllllI = llllllllllllllllIIllIlIllIIlIllI.getSize();
    Tessellator llllllllllllllllIIllIlIllIIlllIl = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIIllIlIllIIlllII = llllllllllllllllIIllIlIllIIlllIl.getWorldRenderer();
    int llllllllllllllllIIllIlIllIIllIll = lllIIlIIIll[3];
    "".length();
    if ((0x5F ^ 0x5B) < 0) {
      return;
    }
    while (!lIlIlllllIllI(llllllllllllllllIIllIlIllIIllIll, llllllllllllllllIIllIlIllIIllllI))
    {
      int llllllllllllllllIIllIlIllIIllIlI = llllllllllllllllIIllIlIllIlIIIIl + llllllllllllllllIIllIlIllIIllIll * slotHeight + headerPadding;
      int llllllllllllllllIIllIlIllIIllIIl = slotHeight - lllIIlIIIll[5];
      if ((!lIlIlllllIlll(llllllllllllllllIIllIlIllIIllIlI, bottom)) || (lIlIlllllIlIl(llllllllllllllllIIllIlIllIIllIlI + llllllllllllllllIIllIlIllIIllIIl, top))) {
        llllllllllllllllIIllIlIllIIlIllI.func_178040_a(llllllllllllllllIIllIlIllIIllIll, llllllllllllllllIIllIlIllIlIIIlI, llllllllllllllllIIllIlIllIIllIlI);
      }
      if ((lIlIllllllIIl(showSelectionBox)) && (lIlIllllllIIl(llllllllllllllllIIllIlIllIIlIllI.isSelected(llllllllllllllllIIllIlIllIIllIll))))
      {
        int llllllllllllllllIIllIlIllIIllIII = left + (width / lllIIlIIIll[4] - llllllllllllllllIIllIlIllIIlIllI.getListWidth() / lllIIlIIIll[4]);
        int llllllllllllllllIIllIlIllIIlIlll = left + width / lllIIlIIIll[4] + llllllllllllllllIIllIlIllIIlIllI.getListWidth() / lllIIlIIIll[4];
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.disableTexture2D();
        llllllllllllllllIIllIlIllIIlllII.begin(lllIIlIIIll[8], DefaultVertexFormats.POSITION_TEX_COLOR);
        llllllllllllllllIIllIlIllIIlllII.pos(llllllllllllllllIIllIlIllIIllIII, llllllllllllllllIIllIlIllIIllIlI + llllllllllllllllIIllIlIllIIllIIl + lllIIlIIIll[4], 0.0D).tex(0.0D, 1.0D).color(lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIllIIlllII.pos(llllllllllllllllIIllIlIllIIlIlll, llllllllllllllllIIllIlIllIIllIlI + llllllllllllllllIIllIlIllIIllIIl + lllIIlIIIll[4], 0.0D).tex(1.0D, 1.0D).color(lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIllIIlllII.pos(llllllllllllllllIIllIlIllIIlIlll, llllllllllllllllIIllIlIllIIllIlI - lllIIlIIIll[4], 0.0D).tex(1.0D, 0.0D).color(lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIllIIlllII.pos(llllllllllllllllIIllIlIllIIllIII, llllllllllllllllIIllIlIllIIllIlI - lllIIlIIIll[4], 0.0D).tex(0.0D, 0.0D).color(lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[15], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIllIIlllII.pos(llllllllllllllllIIllIlIllIIllIII + lllIIlIIIll[0], llllllllllllllllIIllIlIllIIllIlI + llllllllllllllllIIllIlIllIIllIIl + lllIIlIIIll[0], 0.0D).tex(0.0D, 1.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIllIIlllII.pos(llllllllllllllllIIllIlIllIIlIlll - lllIIlIIIll[0], llllllllllllllllIIllIlIllIIllIlI + llllllllllllllllIIllIlIllIIllIIl + lllIIlIIIll[0], 0.0D).tex(1.0D, 1.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIllIIlllII.pos(llllllllllllllllIIllIlIllIIlIlll - lllIIlIIIll[0], llllllllllllllllIIllIlIllIIllIlI - lllIIlIIIll[0], 0.0D).tex(1.0D, 0.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIllIIlllII.pos(llllllllllllllllIIllIlIllIIllIII + lllIIlIIIll[0], llllllllllllllllIIllIlIllIIllIlI - lllIIlIIIll[0], 0.0D).tex(0.0D, 0.0D).color(lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[3], lllIIlIIIll[10]).endVertex();
        llllllllllllllllIIllIlIllIIlllIl.draw();
        GlStateManager.enableTexture2D();
      }
      llllllllllllllllIIllIlIllIIlIllI.drawSlot(llllllllllllllllIIllIlIllIIllIll, llllllllllllllllIIllIlIllIlIIIlI, llllllllllllllllIIllIlIllIIllIlI, llllllllllllllllIIllIlIllIIllIIl, llllllllllllllllIIllIlIllIIlIIll, llllllllllllllllIIllIlIllIIlllll);
      llllllllllllllllIIllIlIllIIllIll++;
    }
  }
  
  private static boolean lIllIIIIIIIII(int ???)
  {
    long llllllllllllllllIIllIlIlIlIIlllI;
    return ??? < 0;
  }
  
  protected abstract boolean isSelected(int paramInt);
}

package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.world.storage.WorldInfo;

public class GuiGameOver
  extends GuiScreen
  implements GuiYesNoCallback
{
  private static String lIIIIIIlllIII(String lllllllllllllllllIIIlIIllIllllIl, String lllllllllllllllllIIIlIIllIllllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIlIIllIllllIl = new String(Base64.getDecoder().decode(lllllllllllllllllIIIlIIllIllllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIIlIIlllIIIIII = new StringBuilder();
    char[] lllllllllllllllllIIIlIIllIllllll = lllllllllllllllllIIIlIIllIllllII.toCharArray();
    int lllllllllllllllllIIIlIIllIlllllI = lIlIlIIIlIl[0];
    int lllllllllllllllllIIIlIIllIlllIII = lllllllllllllllllIIIlIIllIllllIl.toCharArray();
    String lllllllllllllllllIIIlIIllIllIlll = lllllllllllllllllIIIlIIllIlllIII.length;
    short lllllllllllllllllIIIlIIllIllIllI = lIlIlIIIlIl[0];
    while (lIIIIIlIIIlII(lllllllllllllllllIIIlIIllIllIllI, lllllllllllllllllIIIlIIllIllIlll))
    {
      char lllllllllllllllllIIIlIIlllIIIIll = lllllllllllllllllIIIlIIllIlllIII[lllllllllllllllllIIIlIIllIllIllI];
      "".length();
      "".length();
      if (-" ".length() >= (0x5A ^ 0x5E)) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIIIlIIlllIIIIII);
  }
  
  private static void lIIIIIIlllIlI()
  {
    lIlIlIIIIll = new String[lIlIlIIIlIl[22]];
    lIlIlIIIIll[lIlIlIIIlIl[0]] = lIIIIIIllIllI("3NNbKLotH2QqhtQ3NJoxVKg1+kSQfLPg", "uUhQp");
    lIlIlIIIIll[lIlIlIIIlIl[1]] = lIIIIIIllIllI("g2WwzZvgtwACxxh+WEtsFSJWghPgfhwj", "VZDkJ");
    lIlIlIIIIll[lIlIlIIIlIl[2]] = lIIIIIIllIllI("L9cgs8llBeprqkan08zoplMPuVW3itaZ", "opKvG");
    lIlIlIIIIll[lIlIlIIIlIl[7]] = lIIIIIIllIlll("UeaGs3xVKYmOF7BFOeIHwLbjffxl3WGp", "JTLcq");
    lIlIlIIIIll[lIlIlIIIlIl[4]] = lIIIIIIllIllI("Utj7FcDd2/lM/7Y14qDI/kfkf0Xpdvj7o/E0c1mHTrA=", "VOELM");
    lIlIlIIIIll[lIlIlIIIlIl[8]] = lIIIIIIllIllI("YOArE4TI+h0=", "dfHtp");
    lIlIlIIIIll[lIlIlIIIlIl[9]] = lIIIIIIllIlll("CFkCQDM8I/tv6RwjGOyX22TvcE86CtdM", "FZrXR");
    lIlIlIIIIll[lIlIlIIIlIl[10]] = lIIIIIIllIlll("nM+WWeB3CNgMu3wGpmyS9dGoBQkjMDcI", "EMKio");
    lIlIlIIIIll[lIlIlIIIlIl[14]] = lIIIIIIllIllI("R4mbs134SaruDA5LagzINdHL4RfJZisXN0o0CuGE0FY=", "sKtoc");
    lIlIlIIIIll[lIlIlIIIlIl[15]] = lIIIIIIllIllI("/HBG2BSKWgWI+LiNXM0De5/woEcreOH3", "EIReK");
    lIlIlIIIIll[lIlIlIIIlIl[18]] = lIIIIIIllIllI("RfbU2Hn4P5DnP24kOiknOG8rZxYw/otsR+V7qlu8YcI=", "UhDOR");
    lIlIlIIIIll[lIlIlIIIlIl[20]] = lIIIIIIlllIII("MzcmDjsEMTUfNjl8NBk8JTc=", "WRGzS");
    lIlIlIIIIll[lIlIlIIIlIl[21]] = lIIIIIIllIllI("xK9umlYyyAE=", "UedGZ");
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllllIIIlIlIIIIIllIl)
    throws IOException
  {
    ;
    ;
    ;
    switch (id)
    {
    case 0: 
      mc.thePlayer.respawnPlayer();
      mc.displayGuiScreen(null);
      "".length();
      if (null != null) {}
      break;
    case 1: 
      if (lIIIIIIlllllI(mc.theWorld.getWorldInfo().isHardcoreModeEnabled()))
      {
        mc.displayGuiScreen(new GuiMainMenu());
        "".length();
        if ((0xC ^ 0x8) > "   ".length()) {
          break;
        }
      }
      else
      {
        GuiYesNo lllllllllllllllllIIIlIlIIIIIllII = new GuiYesNo(lllllllllllllllllIIIlIlIIIIIlIll, I18n.format(lIlIlIIIIll[lIlIlIIIlIl[4]], new Object[lIlIlIIIlIl[0]]), lIlIlIIIIll[lIlIlIIIlIl[8]], I18n.format(lIlIlIIIIll[lIlIlIIIlIl[9]], new Object[lIlIlIIIlIl[0]]), I18n.format(lIlIlIIIIll[lIlIlIIIlIl[10]], new Object[lIlIlIIIlIl[0]]), lIlIlIIIlIl[0]);
        mc.displayGuiScreen(lllllllllllllllllIIIlIlIIIIIllII);
        lllllllllllllllllIIIlIlIIIIIllII.setButtonDelay(lIlIlIIIlIl[11]);
      }
      break;
    }
  }
  
  private static void lIIIIIIllllIl()
  {
    lIlIlIIIlIl = new int[23];
    lIlIlIIIlIl[0] = ((0x33 ^ 0x0 ^ 0xD0 ^ 0xC7) & (88 + 54 - 44 + 74 ^ 13 + 81 - 49 + 91 ^ -" ".length()));
    lIlIlIIIlIl[1] = " ".length();
    lIlIlIIIlIl[2] = "  ".length();
    lIlIlIIIlIl[3] = (0x4B ^ 0x5A ^ 0x10 ^ 0x65);
    lIlIlIIIlIl[4] = (0x4 ^ 0x6D ^ 0x58 ^ 0x35);
    lIlIlIIIlIl[5] = (0x35 ^ 0x55);
    lIlIlIIIlIl[6] = (0xD0 ^ 0x98);
    lIlIlIIIlIl[7] = "   ".length();
    lIlIlIIIlIl[8] = (0x48 ^ 0x1B ^ 0x60 ^ 0x36);
    lIlIlIIIlIl[9] = (0x21 ^ 0x27);
    lIlIlIIIlIl[10] = (16 + 71 - 69 + 155 ^ '§' + '' - 162 + 29);
    lIlIlIIIlIl[11] = (0x1D ^ 0x9);
    lIlIlIIIlIl[12] = (-(0xEEF7 & 0x75EF) & 0xE4FE & 0x60507FE7);
    lIlIlIIIlIl[13] = (-(-(0xF67F & 0x29AD) & 0xFFFFFFFD & 0x5F7FEFFE));
    lIlIlIIIlIl[14] = (0xC9 ^ 0xC1);
    lIlIlIIIlIl[15] = (0xAA ^ 0xA3);
    lIlIlIIIlIl[16] = (94 + 52 - 77 + 58 ^ 0x59 ^ 0x38);
    lIlIlIIIlIl[17] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIlIlIIIlIl[18] = (0x29 ^ 0x4B ^ 0xD ^ 0x65);
    lIlIlIIIlIl[19] = ('' + 99 - 205 + 109 + (0xA9 ^ 0xB1) - (46 + '' - 98 + 70) + (121 + 57 - 55 + 15));
    lIlIlIIIlIl[20] = (0x0 ^ 0xB);
    lIlIlIIIlIl[21] = (0x9 ^ 0x5);
    lIlIlIIIlIl[22] = (0xF8 ^ 0xB4 ^ 0xB ^ 0x4A);
  }
  
  private static boolean lIIIIIlIIIIll(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllllIIIlIIllIllIIIl;
    return ??? == i;
  }
  
  private static String lIIIIIIllIllI(String lllllllllllllllllIIIlIIlllIlllIl, String lllllllllllllllllIIIlIIlllIlllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIIlIIllllIIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIlIIlllIlllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIIIlIIllllIIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllllIIIlIIllllIIIIl.init(lIlIlIIIlIl[2], lllllllllllllllllIIIlIIllllIIIlI);
      return new String(lllllllllllllllllIIIlIIllllIIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIlIIlllIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIIlIIllllIIIII)
    {
      lllllllllllllllllIIIlIIllllIIIII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIIIIlllllI(int ???)
  {
    float lllllllllllllllllIIIlIIllIlIlIIl;
    return ??? != 0;
  }
  
  static
  {
    lIIIIIIllllIl();
    lIIIIIIlllIlI();
  }
  
  public void updateScreen()
  {
    ;
    ;
    ;
    lllllllllllllllllIIIlIIllllIlIll.updateScreen();
    enableButtonsTimer += lIlIlIIIlIl[1];
    if (lIIIIIlIIIIll(enableButtonsTimer, lIlIlIIIlIl[11]))
    {
      lllllllllllllllllIIIlIIllllIIlll = buttonList.iterator();
      "".length();
      if ((81 + 78 - 157 + 150 ^ 30 + 98 - 76 + 104) < ('' + 81 - 79 + 13 ^ 73 + '' - 190 + 128)) {
        return;
      }
      while (!lIIIIIlIIIIII(lllllllllllllllllIIIlIIllllIIlll.hasNext()))
      {
        GuiButton lllllllllllllllllIIIlIIllllIlIlI = (GuiButton)lllllllllllllllllIIIlIIllllIIlll.next();
        enabled = lIlIlIIIlIl[1];
      }
    }
  }
  
  protected void keyTyped(char lllllllllllllllllIIIlIlIIIIlIIll, int lllllllllllllllllIIIlIlIIIIlIIlI)
    throws IOException
  {}
  
  private static boolean lIIIIIlIIIIII(int ???)
  {
    long lllllllllllllllllIIIlIIllIlIIlll;
    return ??? == 0;
  }
  
  public GuiGameOver() {}
  
  public void initGui()
  {
    ;
    ;
    buttonList.clear();
    if (lIIIIIIlllllI(mc.theWorld.getWorldInfo().isHardcoreModeEnabled()))
    {
      if (lIIIIIIlllllI(mc.isIntegratedServerRunning()))
      {
        new GuiButton(lIlIlIIIlIl[1], width / lIlIlIIIlIl[2] - lIlIlIIIlIl[3], height / lIlIlIIIlIl[4] + lIlIlIIIlIl[5], I18n.format(lIlIlIIIIll[lIlIlIIIlIl[0]], new Object[lIlIlIIIlIl[0]]));
        "".length();
        "".length();
        if ((45 + 101 - 15 + 26 ^ 122 + 103 - 123 + 51) != 0) {}
      }
      else
      {
        new GuiButton(lIlIlIIIlIl[1], width / lIlIlIIIlIl[2] - lIlIlIIIlIl[3], height / lIlIlIIIlIl[4] + lIlIlIIIlIl[5], I18n.format(lIlIlIIIIll[lIlIlIIIlIl[1]], new Object[lIlIlIIIlIl[0]]));
        "".length();
        "".length();
        if (((0x4 ^ 0x2 ^ 0x29 ^ 0x11) & (52 + 127 - 79 + 41 ^ 68 + 18 - 82 + 175 ^ -" ".length())) >= 0) {}
      }
    }
    else
    {
      new GuiButton(lIlIlIIIlIl[0], width / lIlIlIIIlIl[2] - lIlIlIIIlIl[3], height / lIlIlIIIlIl[4] + lIlIlIIIlIl[6], I18n.format(lIlIlIIIIll[lIlIlIIIlIl[2]], new Object[lIlIlIIIlIl[0]]));
      "".length();
      new GuiButton(lIlIlIIIlIl[1], width / lIlIlIIIlIl[2] - lIlIlIIIlIl[3], height / lIlIlIIIlIl[4] + lIlIlIIIlIl[5], I18n.format(lIlIlIIIIll[lIlIlIIIlIl[7]], new Object[lIlIlIIIlIl[0]]));
      "".length();
      if (lIIIIIIllllll(mc.getSession())) {
        buttonList.get(lIlIlIIIlIl[1])).enabled = lIlIlIIIlIl[0];
      }
    }
    short lllllllllllllllllIIIlIlIIIIlIlIl = buttonList.iterator();
    "".length();
    if ((8 + '' - 98 + 93 ^ 119 + 93 - 149 + 87) == 0) {
      return;
    }
    while (!lIIIIIlIIIIII(lllllllllllllllllIIIlIlIIIIlIlIl.hasNext()))
    {
      GuiButton lllllllllllllllllIIIlIlIIIIllIII = (GuiButton)lllllllllllllllllIIIlIlIIIIlIlIl.next();
      enabled = lIlIlIIIlIl[0];
    }
  }
  
  private static boolean lIIIIIlIIIlII(int ???, int arg1)
  {
    int i;
    char lllllllllllllllllIIIlIIllIlIllIl;
    return ??? < i;
  }
  
  public void drawScreen(int lllllllllllllllllIIIlIIlllllIlII, int lllllllllllllllllIIIlIIlllllIIll, float lllllllllllllllllIIIlIIlllllIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIlIIlllllIlIl.drawGradientRect(lIlIlIIIlIl[0], lIlIlIIIlIl[0], width, height, lIlIlIIIlIl[12], lIlIlIIIlIl[13]);
    GlStateManager.pushMatrix();
    GlStateManager.scale(2.0F, 2.0F, 2.0F);
    boolean lllllllllllllllllIIIlIIlllllIlll = mc.theWorld.getWorldInfo().isHardcoreModeEnabled();
    if (lIIIIIIlllllI(lllllllllllllllllIIIlIIlllllIlll))
    {
      "".length();
      if (((0x7F ^ 0x33) & (0x76 ^ 0x3A ^ 0xFFFFFFFF)) >= 0) {
        break label131;
      }
    }
    label131:
    String lllllllllllllllllIIIlIIlllllIllI = I18n.format(lIlIlIIIIll[lIlIlIIIlIl[15]], new Object[lIlIlIIIlIl[0]]);
    lllllllllllllllllIIIlIIlllllIlIl.drawCenteredString(fontRendererObj, lllllllllllllllllIIIlIIlllllIllI, width / lIlIlIIIlIl[2] / lIlIlIIIlIl[2], lIlIlIIIlIl[16], lIlIlIIIlIl[17]);
    GlStateManager.popMatrix();
    if (lIIIIIIlllllI(lllllllllllllllllIIIlIIlllllIlll)) {
      lllllllllllllllllIIIlIIlllllIlIl.drawCenteredString(fontRendererObj, I18n.format(lIlIlIIIIll[lIlIlIIIlIl[18]], new Object[lIlIlIIIlIl[0]]), width / lIlIlIIIlIl[2], lIlIlIIIlIl[19], lIlIlIIIlIl[17]);
    }
    lllllllllllllllllIIIlIIlllllIlIl.drawCenteredString(fontRendererObj, String.valueOf(new StringBuilder(String.valueOf(I18n.format(lIlIlIIIIll[lIlIlIIIlIl[20]], new Object[lIlIlIIIlIl[0]]))).append(lIlIlIIIIll[lIlIlIIIlIl[21]]).append(EnumChatFormatting.YELLOW).append(mc.thePlayer.getScore())), width / lIlIlIIIlIl[2], lIlIlIIIlIl[3], lIlIlIIIlIl[17]);
    lllllllllllllllllIIIlIIlllllIlIl.drawScreen(lllllllllllllllllIIIlIIlllllIlII, lllllllllllllllllIIIlIIlllllIIll, lllllllllllllllllIIIlIIlllllIIlI);
  }
  
  public boolean doesGuiPauseGame()
  {
    return lIlIlIIIlIl[0];
  }
  
  public void confirmClicked(boolean lllllllllllllllllIIIlIlIIIIIIlIl, int lllllllllllllllllIIIlIlIIIIIIlII)
  {
    ;
    ;
    if (lIIIIIIlllllI(lllllllllllllllllIIIlIlIIIIIIlIl))
    {
      mc.theWorld.sendQuittingDisconnectingPacket();
      mc.loadWorld(null);
      mc.displayGuiScreen(new GuiMainMenu());
      "".length();
      if (" ".length() >= 0) {}
    }
    else
    {
      mc.thePlayer.respawnPlayer();
      mc.displayGuiScreen(null);
    }
  }
  
  private static boolean lIIIIIIllllll(Object ???)
  {
    Exception lllllllllllllllllIIIlIIllIlIlIll;
    return ??? == null;
  }
  
  private static String lIIIIIIllIlll(String lllllllllllllllllIIIlIIlllIlIIII, String lllllllllllllllllIIIlIIlllIlIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIIlIIlllIlIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIlIIlllIlIIIl.getBytes(StandardCharsets.UTF_8)), lIlIlIIIlIl[14]), "DES");
      Cipher lllllllllllllllllIIIlIIlllIlIlII = Cipher.getInstance("DES");
      lllllllllllllllllIIIlIIlllIlIlII.init(lIlIlIIIlIl[2], lllllllllllllllllIIIlIIlllIlIlIl);
      return new String(lllllllllllllllllIIIlIIlllIlIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIlIIlllIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIIlIIlllIlIIll)
    {
      lllllllllllllllllIIIlIIlllIlIIll.printStackTrace();
    }
    return null;
  }
}

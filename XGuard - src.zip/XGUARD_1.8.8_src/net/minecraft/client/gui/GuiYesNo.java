package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.resources.I18n;

public class GuiYesNo
  extends GuiScreen
{
  public GuiYesNo(GuiYesNoCallback lllllllllllllllIIlllIIllIIIIIlIl, String lllllllllllllllIIlllIIllIIIIIlII, String lllllllllllllllIIlllIIllIIIIIIll, String lllllllllllllllIIlllIIlIlllllIll, String lllllllllllllllIIlllIIllIIIIIIIl, int lllllllllllllllIIlllIIlIlllllIIl)
  {
    parentScreen = lllllllllllllllIIlllIIllIIIIIlIl;
    messageLine1 = lllllllllllllllIIlllIIllIIIIIlII;
    messageLine2 = lllllllllllllllIIlllIIlIllllllII;
    confirmButtonText = lllllllllllllllIIlllIIlIlllllIll;
    cancelButtonText = lllllllllllllllIIlllIIllIIIIIIIl;
    parentButtonClickedId = lllllllllllllllIIlllIIlIlllllIIl;
  }
  
  public void updateScreen()
  {
    ;
    ;
    ;
    lllllllllllllllIIlllIIlIllIIlIll.updateScreen();
    if (lIIIlIIIIIlllI(lllllllllllllllIIlllIIlIllIIllIl.ticksUntilEnable -= lIlIlllllllI[1]))
    {
      lllllllllllllllIIlllIIlIllIIlIIl = buttonList.iterator();
      "".length();
      if ((0x24 ^ 0x20) <= " ".length()) {
        return;
      }
      while (!lIIIlIIIIIlllI(lllllllllllllllIIlllIIlIllIIlIIl.hasNext()))
      {
        GuiButton lllllllllllllllIIlllIIlIllIIllII = (GuiButton)lllllllllllllllIIlllIIlIllIIlIIl.next();
        enabled = lIlIlllllllI[1];
      }
    }
  }
  
  private static boolean lIIIlIIIIIlllI(int ???)
  {
    int lllllllllllllllIIlllIIlIlIIllllI;
    return ??? == 0;
  }
  
  static
  {
    lIIIlIIIIIllIl();
    lIIIlIIIIIlIIl();
  }
  
  public void drawScreen(int lllllllllllllllIIlllIIlIlllIIlll, int lllllllllllllllIIlllIIlIlllIIIII, float lllllllllllllllIIlllIIlIllIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlllIIlIlllIlIII.drawDefaultBackground();
    lllllllllllllllIIlllIIlIlllIlIII.drawCenteredString(fontRendererObj, messageLine1, width / lIlIlllllllI[2], lIlIlllllllI[8], lIlIlllllllI[9]);
    int lllllllllllllllIIlllIIlIlllIIlII = lIlIlllllllI[10];
    boolean lllllllllllllllIIlllIIlIllIlllII = field_175298_s.iterator();
    "".length();
    if (null != null) {
      return;
    }
    while (!lIIIlIIIIIlllI(lllllllllllllllIIlllIIlIllIlllII.hasNext()))
    {
      String lllllllllllllllIIlllIIlIlllIIIll = (String)lllllllllllllllIIlllIIlIllIlllII.next();
      lllllllllllllllIIlllIIlIlllIlIII.drawCenteredString(fontRendererObj, lllllllllllllllIIlllIIlIlllIIIll, width / lIlIlllllllI[2], lllllllllllllllIIlllIIlIlllIIlII, lIlIlllllllI[9]);
      lllllllllllllllIIlllIIlIlllIIlII += fontRendererObj.FONT_HEIGHT;
    }
    lllllllllllllllIIlllIIlIlllIlIII.drawScreen(lllllllllllllllIIlllIIlIlllIIlll, lllllllllllllllIIlllIIlIlllIIIII, lllllllllllllllIIlllIIlIllIlllll);
  }
  
  private static String lIIIlIIIIIlIII(String lllllllllllllllIIlllIIlIlIlllllI, String lllllllllllllllIIlllIIlIlIllllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlllIIlIlIlllllI = new String(Base64.getDecoder().decode(lllllllllllllllIIlllIIlIlIlllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlllIIlIlIllllII = new StringBuilder();
    char[] lllllllllllllllIIlllIIlIlIlllIll = lllllllllllllllIIlllIIlIlIllllIl.toCharArray();
    int lllllllllllllllIIlllIIlIlIlllIlI = lIlIlllllllI[0];
    char lllllllllllllllIIlllIIlIlIllIlII = lllllllllllllllIIlllIIlIlIlllllI.toCharArray();
    int lllllllllllllllIIlllIIlIlIllIIll = lllllllllllllllIIlllIIlIlIllIlII.length;
    boolean lllllllllllllllIIlllIIlIlIllIIlI = lIlIlllllllI[0];
    while (lIIIlIIIIIllll(lllllllllllllllIIlllIIlIlIllIIlI, lllllllllllllllIIlllIIlIlIllIIll))
    {
      char lllllllllllllllIIlllIIlIlIllllll = lllllllllllllllIIlllIIlIlIllIlII[lllllllllllllllIIlllIIlIlIllIIlI];
      "".length();
      "".length();
      if (-(0x5B ^ 0x5F) >= 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlllIIlIlIllllII);
  }
  
  public void initGui()
  {
    ;
    new GuiOptionButton(lIlIlllllllI[0], width / lIlIlllllllI[2] - lIlIlllllllI[3], height / lIlIlllllllI[4] + lIlIlllllllI[5], confirmButtonText);
    "".length();
    new GuiOptionButton(lIlIlllllllI[1], width / lIlIlllllllI[2] - lIlIlllllllI[3] + lIlIlllllllI[6], height / lIlIlllllllI[4] + lIlIlllllllI[5], cancelButtonText);
    "".length();
    field_175298_s.clear();
    "".length();
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllIIlllIIlIllllIIlI)
    throws IOException
  {
    ;
    ;
    if (lIIIlIIIIIlllI(id))
    {
      "".length();
      if (((0x8D ^ 0xA9 ^ 0x37 ^ 0x41) & (0xDE ^ 0x94 ^ 0xB1 ^ 0xA9 ^ -" ".length())) != "  ".length()) {
        break label76;
      }
    }
    label76:
    lIlIlllllllI[1].confirmClicked(lIlIlllllllI[0], parentButtonClickedId);
  }
  
  private static void lIIIlIIIIIlIIl()
  {
    lIlIllllllII = new String[lIlIlllllllI[2]];
    lIlIllllllII[lIlIlllllllI[0]] = lIIIlIIIIIIlll("g61ezDb4iPA=", "uWoTB");
    lIlIllllllII[lIlIlllllllI[1]] = lIIIlIIIIIlIII("EAMHdBgY", "wvnZv");
  }
  
  public void setButtonDelay(int lllllllllllllllIIlllIIlIllIlIllI)
  {
    ;
    ;
    ;
    ticksUntilEnable = lllllllllllllllIIlllIIlIllIlIllI;
    long lllllllllllllllIIlllIIlIllIlIIIl = buttonList.iterator();
    "".length();
    if ((0x1 ^ 0x5) < 0) {
      return;
    }
    while (!lIIIlIIIIIlllI(lllllllllllllllIIlllIIlIllIlIIIl.hasNext()))
    {
      GuiButton lllllllllllllllIIlllIIlIllIlIlIl = (GuiButton)lllllllllllllllIIlllIIlIllIlIIIl.next();
      enabled = lIlIlllllllI[0];
    }
  }
  
  public GuiYesNo(GuiYesNoCallback lllllllllllllllIIlllIIllIIIlIIIl, String lllllllllllllllIIlllIIllIIIlIlIl, String lllllllllllllllIIlllIIllIIIIllll, int lllllllllllllllIIlllIIllIIIIlllI)
  {
    parentScreen = lllllllllllllllIIlllIIllIIIlIIIl;
    messageLine1 = lllllllllllllllIIlllIIllIIIlIIII;
    messageLine2 = lllllllllllllllIIlllIIllIIIIllll;
    parentButtonClickedId = lllllllllllllllIIlllIIllIIIIlllI;
    confirmButtonText = I18n.format(lIlIllllllII[lIlIlllllllI[0]], new Object[lIlIlllllllI[0]]);
    cancelButtonText = I18n.format(lIlIllllllII[lIlIlllllllI[1]], new Object[lIlIlllllllI[0]]);
  }
  
  private static boolean lIIIlIIIIIllll(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIIlllIIlIlIlIIIII;
    return ??? < i;
  }
  
  private static String lIIIlIIIIIIlll(String lllllllllllllllIIlllIIlIlIlIlIIl, String lllllllllllllllIIlllIIlIlIlIlIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlllIIlIlIlIllII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlllIIlIlIlIlIII.getBytes(StandardCharsets.UTF_8)), lIlIlllllllI[11]), "DES");
      Cipher lllllllllllllllIIlllIIlIlIlIlIll = Cipher.getInstance("DES");
      lllllllllllllllIIlllIIlIlIlIlIll.init(lIlIlllllllI[2], lllllllllllllllIIlllIIlIlIlIllII);
      return new String(lllllllllllllllIIlllIIlIlIlIlIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlllIIlIlIlIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlllIIlIlIlIlIlI)
    {
      lllllllllllllllIIlllIIlIlIlIlIlI.printStackTrace();
    }
    return null;
  }
  
  private static void lIIIlIIIIIllIl()
  {
    lIlIlllllllI = new int[12];
    lIlIlllllllI[0] = ((0x87 ^ 0x93 ^ 0x8 ^ 0x4) & (0xA ^ 0x59 ^ 0xE2 ^ 0xA9 ^ -" ".length()));
    lIlIlllllllI[1] = " ".length();
    lIlIlllllllI[2] = "  ".length();
    lIlIlllllllI[3] = (92 + 111 - 77 + 29);
    lIlIlllllllI[4] = (0xB3 ^ 0xB5);
    lIlIlllllllI[5] = (48 + 67 - 48 + 133 ^ 119 + '¢' - 263 + 150);
    lIlIlllllllI[6] = ((0x57 ^ 0x64) + (0x94 ^ 0x9E) - -(0xF9 ^ 0xBB) + (0x7B ^ 0x5A));
    lIlIlllllllI[7] = (0x66 ^ 0x54);
    lIlIlllllllI[8] = (0xBF ^ 0xB2 ^ 0x59 ^ 0x12);
    lIlIlllllllI[9] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIlIlllllllI[10] = (0xDB ^ 0x81);
    lIlIlllllllI[11] = (0x65 ^ 0x6D);
  }
}

package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.material.MapColor;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.Vec4b;
import net.minecraft.world.storage.MapData;

public class MapItemRenderer
{
  private static boolean llIllIIIIlIII(int ???)
  {
    Exception lllllllllllllllIlllIIlIllllIlIII;
    return ??? == 0;
  }
  
  private static boolean llIllIIIIIlll(Object ???)
  {
    double lllllllllllllllIlllIIlIllllIlIlI;
    return ??? == null;
  }
  
  static
  {
    llIllIIIIIllI();
    llIllIIIIIlIl();
  }
  
  private static void llIllIIIIIlIl()
  {
    lIIIlIllllIl = new String[lIIIlIlllllI[1]];
    lIIIlIllllIl[lIIIlIlllllI[0]] = llIllIIIIIlII("mCcNShL05jO8c4usxZ8RgqC4D3xCXaCmscCbKf4oCpk=", "jNMLO");
  }
  
  private static void llIllIIIIIllI()
  {
    lIIIlIlllllI = new int[4];
    lIIIlIlllllI[0] = ((0xD9 ^ 0xC1 ^ 0xC ^ 0x11) & (79 + 36 - 9 + 89 ^ '' + 1 - 109 + 175 ^ -" ".length()));
    lIIIlIlllllI[1] = " ".length();
    lIIIlIlllllI[2] = (0xB2 ^ 0xBA);
    lIIIlIlllllI[3] = "  ".length();
  }
  
  public void clearLoadedMaps()
  {
    ;
    ;
    char lllllllllllllllIlllIIlIllllllIll = loadedMaps.values().iterator();
    "".length();
    if ("  ".length() != "  ".length()) {
      return;
    }
    while (!llIllIIIIlIII(lllllllllllllllIlllIIlIllllllIll.hasNext()))
    {
      Instance lllllllllllllllIlllIIlIllllllllI = (Instance)lllllllllllllllIlllIIlIllllllIll.next();
      textureManager.deleteTexture(location);
    }
    loadedMaps.clear();
  }
  
  public void renderMap(MapData lllllllllllllllIlllIIllIIIIIllIl, boolean lllllllllllllllIlllIIllIIIIIllII)
  {
    ;
    ;
    ;
    lllllllllllllllIlllIIllIIIIIlllI.getMapRendererInstance(lllllllllllllllIlllIIllIIIIlIIII).render(lllllllllllllllIlllIIllIIIIIllII);
  }
  
  private static String llIllIIIIIlII(String lllllllllllllllIlllIIlIllllIllll, String lllllllllllllllIlllIIlIlllllIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlllIIlIlllllIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIlIlllllIIII.getBytes(StandardCharsets.UTF_8)), lIIIlIlllllI[2]), "DES");
      Cipher lllllllllllllllIlllIIlIlllllIIll = Cipher.getInstance("DES");
      lllllllllllllllIlllIIlIlllllIIll.init(lIIIlIlllllI[3], lllllllllllllllIlllIIlIlllllIlII);
      return new String(lllllllllllllllIlllIIlIlllllIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIlIllllIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlllIIlIlllllIIlI)
    {
      lllllllllllllllIlllIIlIlllllIIlI.printStackTrace();
    }
    return null;
  }
  
  public MapItemRenderer(TextureManager lllllllllllllllIlllIIllIIIIlllIl)
  {
    textureManager = lllllllllllllllIlllIIllIIIIlllIl;
  }
  
  private Instance getMapRendererInstance(MapData lllllllllllllllIlllIIllIIIIIIlII)
  {
    ;
    ;
    ;
    Instance lllllllllllllllIlllIIllIIIIIIllI = (Instance)loadedMaps.get(mapName);
    if (llIllIIIIIlll(lllllllllllllllIlllIIllIIIIIIllI))
    {
      lllllllllllllllIlllIIllIIIIIIllI = new Instance(lllllllllllllllIlllIIllIIIIIIlII, null);
      "".length();
    }
    return lllllllllllllllIlllIIllIIIIIIllI;
  }
  
  public void updateMapTexture(MapData lllllllllllllllIlllIIllIIIIlIlIl)
  {
    ;
    ;
    lllllllllllllllIlllIIllIIIIllIII.getMapRendererInstance(lllllllllllllllIlllIIllIIIIlIlIl).updateMapTexture();
  }
  
  class Instance
  {
    private static boolean lllIlIIlIIllII(int ???)
    {
      int llllllllllllllIIlllIIIlIIIIIIlll;
      return ??? == 0;
    }
    
    private Instance(MapData llllllllllllllIIlllIIIlIIlllIllI)
    {
      mapData = llllllllllllllIIlllIIIlIIlllIllI;
      mapTexture = new DynamicTexture(lIIlIlllllIIl[0], lIIlIlllllIIl[0]);
      mapTextureData = mapTexture.getTextureData();
      location = textureManager.getDynamicTextureLocation(String.valueOf(new StringBuilder(lIIlIlllllIII[lIIlIlllllIIl[1]]).append(mapName)), mapTexture);
      int llllllllllllllIIlllIIIlIIllllIIl = lIIlIlllllIIl[1];
      "".length();
      if ("   ".length() == ((0x32 ^ 0x16 ^ 0xAE ^ 0xC2) & (0x6F ^ 0x55 ^ 0xC6 ^ 0xB4 ^ -" ".length()))) {
        throw null;
      }
      while (!lllIlIIlIIlIll(llllllllllllllIIlllIIIlIIllllIIl, mapTextureData.length))
      {
        mapTextureData[llllllllllllllIIlllIIIlIIllllIIl] = lIIlIlllllIIl[1];
        llllllllllllllIIlllIIIlIIllllIIl++;
      }
    }
    
    private static String lllIlIIlIIlIII(String llllllllllllllIIlllIIIlIIIIlllll, String llllllllllllllIIlllIIIlIIIIllllI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIIlllIIIlIIIIlllll = new String(Base64.getDecoder().decode(llllllllllllllIIlllIIIlIIIIlllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIIlllIIIlIIIlIIIlI = new StringBuilder();
      char[] llllllllllllllIIlllIIIlIIIlIIIIl = llllllllllllllIIlllIIIlIIIIllllI.toCharArray();
      int llllllllllllllIIlllIIIlIIIlIIIII = lIIlIlllllIIl[1];
      int llllllllllllllIIlllIIIlIIIIllIlI = llllllllllllllIIlllIIIlIIIIlllll.toCharArray();
      float llllllllllllllIIlllIIIlIIIIllIIl = llllllllllllllIIlllIIIlIIIIllIlI.length;
      long llllllllllllllIIlllIIIlIIIIllIII = lIIlIlllllIIl[1];
      while (lllIlIIlIIllll(llllllllllllllIIlllIIIlIIIIllIII, llllllllllllllIIlllIIIlIIIIllIIl))
      {
        char llllllllllllllIIlllIIIlIIIlIIlIl = llllllllllllllIIlllIIIlIIIIllIlI[llllllllllllllIIlllIIIlIIIIllIII];
        "".length();
        "".length();
        if (" ".length() <= 0) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIIlllIIIlIIIlIIIlI);
    }
    
    private static boolean lllIlIIlIIlIll(int ???, int arg1)
    {
      int i;
      char llllllllllllllIIlllIIIlIIIIIllll;
      return ??? >= i;
    }
    
    private static boolean lllIlIIlIIllIl(int ???)
    {
      byte llllllllllllllIIlllIIIlIIIIIlIIl;
      return ??? != 0;
    }
    
    private static void lllIlIIlIIlIIl()
    {
      lIIlIlllllIII = new String[lIIlIlllllIIl[4]];
      lIIlIlllllIII[lIIlIlllllIIl[1]] = lllIlIIlIIlIII("ICoGdg==", "MKvYj");
    }
    
    private static boolean lllIlIIlIIllll(int ???, int arg1)
    {
      int i;
      float llllllllllllllIIlllIIIlIIIIIlIll;
      return ??? < i;
    }
    
    private static void lllIlIIlIIlIlI()
    {
      lIIlIlllllIIl = new int[13];
      lIIlIlllllIIl[0] = ((0x74 ^ 0x23) + (0xE0 ^ 0x88) - (112 + 114 - 116 + 19) + (0xD9 ^ 0x9B));
      lIIlIlllllIIl[1] = (('Ç' + 78 - 233 + 211 ^ 94 + 91 - 113 + 86) & (0x7 ^ 0xF ^ 0x64 ^ 0xD ^ -" ".length()));
      lIIlIlllllIIl[2] = (29 + 27 - 37 + 236);
      lIIlIlllllIIl[3] = (28 + '' - 115 + 93 ^ 13 + '' - 55 + 58);
      lIIlIlllllIIl[4] = " ".length();
      lIIlIlllllIIl[5] = (0xDE ^ 0xB0 ^ 0x4E ^ 0x28);
      lIIlIlllllIIl[6] = (0x89 ^ 0xC0 ^ 0xF8 ^ 0xA1);
      lIIlIlllllIIl[7] = (0x81 ^ 0x99);
      lIIlIlllllIIl[8] = "   ".length();
      lIIlIlllllIIl[9] = (-(0xFC6F & 0x33FB) & 0xF87E & 0x77EB);
      lIIlIlllllIIl[10] = (0xC3D7 & 0x3F2B);
      lIIlIlllllIIl[11] = (66 + 86 - 49 + 31 ^ 118 + 123 - 181 + 69);
      lIIlIlllllIIl[12] = (-(0x9FD7 & 0x6E3E) & 0xBFFD & 0x4F7F);
    }
    
    static
    {
      lllIlIIlIIlIlI();
      lllIlIIlIIlIIl();
    }
    
    private void updateMapTexture()
    {
      ;
      ;
      ;
      int llllllllllllllIIlllIIIlIIlllIIII = lIIlIlllllIIl[1];
      "".length();
      if (-" ".length() == (0x3B ^ 0x3F)) {
        return;
      }
      while (!lllIlIIlIIlIll(llllllllllllllIIlllIIIlIIlllIIII, lIIlIlllllIIl[9]))
      {
        int llllllllllllllIIlllIIIlIIllIllll = mapData.colors[llllllllllllllIIlllIIIlIIlllIIII] & lIIlIlllllIIl[2];
        if (lllIlIIlIIllII(llllllllllllllIIlllIIIlIIllIllll / lIIlIlllllIIl[3]))
        {
          mapTextureData[llllllllllllllIIlllIIIlIIlllIIII] = ((llllllllllllllIIlllIIIlIIlllIIII + llllllllllllllIIlllIIIlIIlllIIII / lIIlIlllllIIl[0] & lIIlIlllllIIl[4]) * lIIlIlllllIIl[5] + lIIlIlllllIIl[6] << lIIlIlllllIIl[7]);
          "".length();
          if (((113 + '' - 227 + 136 ^ 57 + 111 - 57 + 28) & ('¬' + '¸' - 284 + 119 ^ 19 + 38 - 36 + 107 ^ -" ".length())) == 0) {}
        }
        else
        {
          mapTextureData[llllllllllllllIIlllIIIlIIlllIIII] = MapColor.mapColorArray[(llllllllllllllIIlllIIIlIIllIllll / lIIlIlllllIIl[3])].func_151643_b(llllllllllllllIIlllIIIlIIllIllll & lIIlIlllllIIl[8]);
        }
        llllllllllllllIIlllIIIlIIlllIIII++;
      }
      mapTexture.updateDynamicTexture();
    }
    
    private void render(boolean llllllllllllllIIlllIIIlIIlIIlIll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      int llllllllllllllIIlllIIIlIIlIllIIl = lIIlIlllllIIl[1];
      int llllllllllllllIIlllIIIlIIlIllIII = lIIlIlllllIIl[1];
      Tessellator llllllllllllllIIlllIIIlIIlIlIlll = Tessellator.getInstance();
      WorldRenderer llllllllllllllIIlllIIIlIIlIlIllI = llllllllllllllIIlllIIIlIIlIlIlll.getWorldRenderer();
      float llllllllllllllIIlllIIIlIIlIlIlIl = 0.0F;
      textureManager.bindTexture(location);
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(lIIlIlllllIIl[4], lIIlIlllllIIl[10], lIIlIlllllIIl[1], lIIlIlllllIIl[4]);
      GlStateManager.disableAlpha();
      llllllllllllllIIlllIIIlIIlIlIllI.begin(lIIlIlllllIIl[11], DefaultVertexFormats.POSITION_TEX);
      llllllllllllllIIlllIIIlIIlIlIllI.pos(llllllllllllllIIlllIIIlIIlIllIIl + lIIlIlllllIIl[1] + llllllllllllllIIlllIIIlIIlIlIlIl, llllllllllllllIIlllIIIlIIlIllIII + lIIlIlllllIIl[0] - llllllllllllllIIlllIIIlIIlIlIlIl, -0.009999999776482582D).tex(0.0D, 1.0D).endVertex();
      llllllllllllllIIlllIIIlIIlIlIllI.pos(llllllllllllllIIlllIIIlIIlIllIIl + lIIlIlllllIIl[0] - llllllllllllllIIlllIIIlIIlIlIlIl, llllllllllllllIIlllIIIlIIlIllIII + lIIlIlllllIIl[0] - llllllllllllllIIlllIIIlIIlIlIlIl, -0.009999999776482582D).tex(1.0D, 1.0D).endVertex();
      llllllllllllllIIlllIIIlIIlIlIllI.pos(llllllllllllllIIlllIIIlIIlIllIIl + lIIlIlllllIIl[0] - llllllllllllllIIlllIIIlIIlIlIlIl, llllllllllllllIIlllIIIlIIlIllIII + lIIlIlllllIIl[1] + llllllllllllllIIlllIIIlIIlIlIlIl, -0.009999999776482582D).tex(1.0D, 0.0D).endVertex();
      llllllllllllllIIlllIIIlIIlIlIllI.pos(llllllllllllllIIlllIIIlIIlIllIIl + lIIlIlllllIIl[1] + llllllllllllllIIlllIIIlIIlIlIlIl, llllllllllllllIIlllIIIlIIlIllIII + lIIlIlllllIIl[1] + llllllllllllllIIlllIIIlIIlIlIlIl, -0.009999999776482582D).tex(0.0D, 0.0D).endVertex();
      llllllllllllllIIlllIIIlIIlIlIlll.draw();
      GlStateManager.enableAlpha();
      GlStateManager.disableBlend();
      textureManager.bindTexture(MapItemRenderer.mapIcons);
      int llllllllllllllIIlllIIIlIIlIlIlII = lIIlIlllllIIl[1];
      byte llllllllllllllIIlllIIIlIIlIIIIll = mapData.mapDecorations.values().iterator();
      "".length();
      if (-"  ".length() > 0) {
        return;
      }
      while (!lllIlIIlIIllII(llllllllllllllIIlllIIIlIIlIIIIll.hasNext()))
      {
        Vec4b llllllllllllllIIlllIIIlIIlIlIIll = (Vec4b)llllllllllllllIIlllIIIlIIlIIIIll.next();
        if ((!lllIlIIlIIllIl(llllllllllllllIIlllIIIlIIlIIlIll)) || (lllIlIIlIIlllI(llllllllllllllIIlllIIIlIIlIlIIll.func_176110_a(), lIIlIlllllIIl[4])))
        {
          GlStateManager.pushMatrix();
          GlStateManager.translate(llllllllllllllIIlllIIIlIIlIllIIl + llllllllllllllIIlllIIIlIIlIlIIll.func_176112_b() / 2.0F + 64.0F, llllllllllllllIIlllIIIlIIlIllIII + llllllllllllllIIlllIIIlIIlIlIIll.func_176113_c() / 2.0F + 64.0F, -0.02F);
          GlStateManager.rotate(llllllllllllllIIlllIIIlIIlIlIIll.func_176111_d() * lIIlIlllllIIl[12] / 16.0F, 0.0F, 0.0F, 1.0F);
          GlStateManager.scale(4.0F, 4.0F, 3.0F);
          GlStateManager.translate(-0.125F, 0.125F, 0.0F);
          byte llllllllllllllIIlllIIIlIIlIlIIlI = llllllllllllllIIlllIIIlIIlIlIIll.func_176110_a();
          float llllllllllllllIIlllIIIlIIlIlIIIl = (llllllllllllllIIlllIIIlIIlIlIIlI % lIIlIlllllIIl[3] + lIIlIlllllIIl[1]) / 4.0F;
          float llllllllllllllIIlllIIIlIIlIlIIII = (llllllllllllllIIlllIIIlIIlIlIIlI / lIIlIlllllIIl[3] + lIIlIlllllIIl[1]) / 4.0F;
          float llllllllllllllIIlllIIIlIIlIIllll = (llllllllllllllIIlllIIIlIIlIlIIlI % lIIlIlllllIIl[3] + lIIlIlllllIIl[4]) / 4.0F;
          float llllllllllllllIIlllIIIlIIlIIlllI = (llllllllllllllIIlllIIIlIIlIlIIlI / lIIlIlllllIIl[3] + lIIlIlllllIIl[4]) / 4.0F;
          llllllllllllllIIlllIIIlIIlIlIllI.begin(lIIlIlllllIIl[11], DefaultVertexFormats.POSITION_TEX);
          float llllllllllllllIIlllIIIlIIlIIllIl = -0.001F;
          llllllllllllllIIlllIIIlIIlIlIllI.pos(-1.0D, 1.0D, llllllllllllllIIlllIIIlIIlIlIlII * -0.001F).tex(llllllllllllllIIlllIIIlIIlIlIIIl, llllllllllllllIIlllIIIlIIlIlIIII).endVertex();
          llllllllllllllIIlllIIIlIIlIlIllI.pos(1.0D, 1.0D, llllllllllllllIIlllIIIlIIlIlIlII * -0.001F).tex(llllllllllllllIIlllIIIlIIlIIllll, llllllllllllllIIlllIIIlIIlIlIIII).endVertex();
          llllllllllllllIIlllIIIlIIlIlIllI.pos(1.0D, -1.0D, llllllllllllllIIlllIIIlIIlIlIlII * -0.001F).tex(llllllllllllllIIlllIIIlIIlIIllll, llllllllllllllIIlllIIIlIIlIIlllI).endVertex();
          llllllllllllllIIlllIIIlIIlIlIllI.pos(-1.0D, -1.0D, llllllllllllllIIlllIIIlIIlIlIlII * -0.001F).tex(llllllllllllllIIlllIIIlIIlIlIIIl, llllllllllllllIIlllIIIlIIlIIlllI).endVertex();
          llllllllllllllIIlllIIIlIIlIlIlll.draw();
          GlStateManager.popMatrix();
          llllllllllllllIIlllIIIlIIlIlIlII++;
        }
      }
      GlStateManager.pushMatrix();
      GlStateManager.translate(0.0F, 0.0F, -0.04F);
      GlStateManager.scale(1.0F, 1.0F, 1.0F);
      GlStateManager.popMatrix();
    }
    
    private static boolean lllIlIIlIIlllI(int ???, int arg1)
    {
      int i;
      Exception llllllllllllllIIlllIIIlIIIIlIIll;
      return ??? == i;
    }
  }
}

package net.minecraft.client.gui;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.ResourceLocation;
import pl.xguard.modification.ColorUtil;
import pl.xguard.modification.R2DUtils;

public class GuiButton
  extends Gui
{
  public void mouseReleased(int lllllllllllllllIlllllllllllIlIIl, int lllllllllllllllIlllllllllllIlIII) {}
  
  private static boolean llIIlIIlllllI(int ???)
  {
    float lllllllllllllllIlllllllllIlIIlll;
    return ??? != 0;
  }
  
  static
  {
    llIIlIIllllII();
    llIIlIIllIIll();
    __OBFID = lIIIIIlIIIIl[lIIIIIlIIIlI[0]];
    mc = Minecraft.getMinecraft();
  }
  
  public boolean isMouseOver()
  {
    ;
    return hovered;
  }
  
  private static String llIIlIIllIIlI(String lllllllllllllllIllllllllllIIIIll, String lllllllllllllllIllllllllllIIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllllllllllIIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllllllllllIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllllllllllIIIlIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllllllllllIIIlIl.init(lIIIIIlIIIlI[5], lllllllllllllllIllllllllllIIIllI);
      return new String(lllllllllllllllIllllllllllIIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllllllllllIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllllllllllIIIlII)
    {
      lllllllllllllllIllllllllllIIIlII.printStackTrace();
    }
    return null;
  }
  
  public void drawButtonForegroundLayer(int lllllllllllllllIllllllllllIllIIl, int lllllllllllllllIllllllllllIllIII) {}
  
  public void setWidth(int lllllllllllllllIllllllllllIIlIll)
  {
    ;
    ;
    width = lllllllllllllllIllllllllllIIlIll;
  }
  
  public void drawButton(Minecraft lllllllllllllllIllllllllllllIlII, int lllllllllllllllIlllllllllllllIlI, int lllllllllllllllIlllllllllllllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIlIIlllllI(visible))
    {
      FontRenderer lllllllllllllllIlllllllllllllIII = Minecraft.fontRendererObj;
      lllllllllllllllIllllllllllllIlII.getTextureManager().bindTexture(buttonTextures);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      if ((llIIlIIllllll(lllllllllllllllIlllllllllllllIlI, xPosition)) && (llIIlIIllllll(lllllllllllllllIlllllllllllllIIl, yPosition)) && (llIIlIlIIIIII(lllllllllllllllIlllllllllllllIlI, xPosition + width)) && (llIIlIlIIIIII(lllllllllllllllIlllllllllllllIIl, yPosition + height)))
      {
        "".length();
        if (" ".length() < "   ".length()) {
          break label117;
        }
      }
      label117:
      lIIIIIlIIIlI1hovered = lIIIIIlIIIlI[0];
      int lllllllllllllllIllllllllllllIlll = lllllllllllllllIllllllllllllIlIl.getHoverState(hovered);
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(lIIIIIlIIIlI[6], lIIIIIlIIIlI[7], lIIIIIlIIIlI[1], lIIIIIlIIIlI[0]);
      GlStateManager.blendFunc(lIIIIIlIIIlI[6], lIIIIIlIIIlI[7]);
      if (llIIlIIllllIl(hovered))
      {
        cs = lIIIIIlIIIlI[8];
        Gui.outlineRect(xPosition + cs, yPosition, xPosition + width - cs, yPosition + height, ColorUtil.getRGB(lIIIIIlIIIlI[9], lIIIIIlIIIlI[10]), lIIIIIlIIIlI[1]);
        R2DUtils.drawFullCircle(xPosition + cs + lIIIIIlIIIlI[5], yPosition + lIIIIIlIIIlI[4], 10.5D, lIIIIIlIIIlI[11]);
        R2DUtils.drawCircle(xPosition + cs + lIIIIIlIIIlI[5], yPosition + lIIIIIlIIIlI[4], 10.5F, lIIIIIlIIIlI[12], ColorUtil.getRGB(lIIIIIlIIIlI[9], lIIIIIlIIIlI[10]));
        R2DUtils.drawCircle(xPosition + cs + lIIIIIlIIIlI[5], yPosition + lIIIIIlIIIlI[4], 10.7F, lIIIIIlIIIlI[12], ColorUtil.getRGB(lIIIIIlIIIlI[9], lIIIIIlIIIlI[10]));
        R2DUtils.drawFullCircle(xPosition + width - cs - lIIIIIlIIIlI[5], yPosition + lIIIIIlIIIlI[4], 10.5D, lIIIIIlIIIlI[11]);
        R2DUtils.drawCircle(xPosition + width - cs - lIIIIIlIIIlI[1], yPosition + lIIIIIlIIIlI[4], 10.5F, lIIIIIlIIIlI[12], ColorUtil.getRGB(lIIIIIlIIIlI[9], lIIIIIlIIIlI[10]));
        R2DUtils.drawCircle(xPosition + width - cs - lIIIIIlIIIlI[1], yPosition + lIIIIIlIIIlI[4], 10.7F, lIIIIIlIIIlI[12], ColorUtil.getRGB(lIIIIIlIIIlI[9], lIIIIIlIIIlI[10]));
        Gui.drawRect(xPosition + cs, yPosition, xPosition + width - cs, yPosition + height, lIIIIIlIIIlI[11]);
      }
      lllllllllllllllIllllllllllllIlIl.mouseDragged(lllllllllllllllIllllllllllllIlII, lllllllllllllllIlllllllllllllIlI, lllllllllllllllIlllllllllllllIIl);
      int lllllllllllllllIllllllllllllIllI = lIIIIIlIIIlI[13];
      if (llIIlIIllllIl(enabled))
      {
        lllllllllllllllIllllllllllllIllI = lIIIIIlIIIlI[14];
        "".length();
        if ((('à' + 'â' - 291 + 80 ^ 83 + '¡' - 110 + 60) & (13 + 'Ù' - 82 + 91 ^ 118 + 21 - -38 + 17 ^ -" ".length())) <= 0) {}
      }
      else if (llIIlIIlllllI(hovered))
      {
        lllllllllllllllIllllllllllllIllI = lIIIIIlIIIlI[15];
      }
      lllllllllllllllIllllllllllllIlIl.drawCenteredString(lllllllllllllllIlllllllllllllIII, displayString, xPosition + width / lIIIIIlIIIlI[5], yPosition + (height - lIIIIIlIIIlI[16]) / lIIIIIlIIIlI[5], lllllllllllllllIllllllllllllIllI);
    }
  }
  
  public void playPressSound(SoundHandler lllllllllllllllIllllllllllIlIlII)
  {
    ;
    lllllllllllllllIllllllllllIlIlII.playSound(PositionedSoundRecord.create(new ResourceLocation(lIIIIIlIIIIl[lIIIIIlIIIlI[5]]), 1.0F));
  }
  
  public GuiButton(int llllllllllllllllIIIIIIIIIIIllIIl, int llllllllllllllllIIIIIIIIIIIllIII, int llllllllllllllllIIIIIIIIIIIlIlll, int llllllllllllllllIIIIIIIIIIIIllll, int llllllllllllllllIIIIIIIIIIIlIlIl, String llllllllllllllllIIIIIIIIIIIIllIl)
  {
    id = llllllllllllllllIIIIIIIIIIIllIIl;
    xPosition = llllllllllllllllIIIIIIIIIIIllIII;
    yPosition = llllllllllllllllIIIIIIIIIIIlIIII;
    width = (llllllllllllllllIIIIIIIIIIIIllll - lIIIIIlIIIlI[4]);
    height = llllllllllllllllIIIIIIIIIIIlIlIl;
    displayString = llllllllllllllllIIIIIIIIIIIIllIl;
  }
  
  public GuiButton(int llllllllllllllllIIIIIIIIIIlIIlIl, int llllllllllllllllIIIIIIIIIIlIIlII, int llllllllllllllllIIIIIIIIIIlIlIII, String llllllllllllllllIIIIIIIIIIlIIIlI)
  {
    llllllllllllllllIIIIIIIIIIlIlIll.<init>(llllllllllllllllIIIIIIIIIIlIIlIl, llllllllllllllllIIIIIIIIIIlIlIIl, llllllllllllllllIIIIIIIIIIlIlIII, lIIIIIlIIIlI[2], lIIIIIlIIIlI[3], llllllllllllllllIIIIIIIIIIlIIIlI);
  }
  
  protected void mouseDragged(Minecraft lllllllllllllllIlllllllllllIllIl, int lllllllllllllllIlllllllllllIllII, int lllllllllllllllIlllllllllllIlIll) {}
  
  private static void llIIlIIllIIll()
  {
    lIIIIIlIIIIl = new String[lIIIIIlIIIlI[17]];
    lIIIIIlIIIIl[lIIIIIlIIIlI[0]] = llIIlIIllIIIl("kCY/U+22jBoYAILD6iRNkg==", "MEUdL");
    lIIIIIlIIIIl[lIIIIIlIIIlI[1]] = llIIlIIllIIlI("pbEurKH3/OZ9oVId2TADBWlwm/l33sDKER1tzTEN02M=", "PaXZu");
    lIIIIIlIIIIl[lIIIIIlIIIlI[5]] = llIIlIIllIIIl("5KtBB79AcrIkvjI3wziNnCB2Z2tOccYK", "GNhfC");
  }
  
  private static boolean llIIlIlIIIIII(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIlllllllllIlIlIIl;
    return ??? < i;
  }
  
  private static void llIIlIIllllII()
  {
    lIIIIIlIIIlI = new int[18];
    lIIIIIlIIIlI[0] = ((0x75 ^ 0x6A) & (0xB4 ^ 0xAB ^ 0xFFFFFFFF));
    lIIIIIlIIIlI[1] = " ".length();
    lIIIIIlIIIlI[2] = (8 + 54 - -38 + 100);
    lIIIIIlIIIlI[3] = (0xAB ^ 0xBF);
    lIIIIIlIIIlI[4] = (0xB3 ^ 0xA3 ^ 0xD8 ^ 0xC2);
    lIIIIIlIIIlI[5] = "  ".length();
    lIIIIIlIIIlI[6] = (0xE3EE & 0x1F13);
    lIIIIIlIIIlI[7] = (-(0xBDD7 & 0x7679) & 0xF77B & 0x3FD7);
    lIIIIIlIIIlI[8] = (0xB ^ 0x49 ^ 0x61 ^ 0x26);
    lIIIIIlIIIlI[9] = (0xBBBB & 0x4FFC);
    lIIIIIlIIIlI[10] = (0x29 ^ 0x4D);
    lIIIIIlIIIlI[11] = (-(0xFDFE & 0xEDEFEF));
    lIIIIIlIIIlI[12] = (-(0xDAEE & 0x7F15) & 0xDFFF & 0x7BF7);
    lIIIIIlIIIlI[13] = (0xF3FC & 0xE0ECE3);
    lIIIIIlIIIlI[14] = (-(0xBF9C & 0x5B7B) & 0xFFFFFFFF & 0xA0BBB7);
    lIIIIIlIIIlI[15] = (-(0x1B ^ 0x3) & 0xFFFFFFFF & 0xFFFFB7);
    lIIIIIlIIIlI[16] = (122 + 38 - 92 + 97 ^ 113 + 46 - 18 + 32);
    lIIIIIlIIIlI[17] = "   ".length();
  }
  
  public boolean mousePressed(Minecraft lllllllllllllllIlllllllllllIIIll, int lllllllllllllllIllllllllllIlllll, int lllllllllllllllIlllllllllllIIIIl)
  {
    ;
    ;
    ;
    if ((llIIlIIlllllI(enabled)) && (llIIlIIlllllI(visible)) && (llIIlIIllllll(lllllllllllllllIlllllllllllIIIlI, xPosition)) && (llIIlIIllllll(lllllllllllllllIlllllllllllIIIIl, yPosition)) && (llIIlIlIIIIII(lllllllllllllllIlllllllllllIIIlI, xPosition + width)) && (llIIlIlIIIIII(lllllllllllllllIlllllllllllIIIIl, yPosition + height))) {
      return lIIIIIlIIIlI[1];
    }
    return lIIIIIlIIIlI[0];
  }
  
  protected int getHoverState(boolean llllllllllllllllIIIIIIIIIIIIlIII)
  {
    ;
    ;
    ;
    byte llllllllllllllllIIIIIIIIIIIIIlll = lIIIIIlIIIlI[1];
    if (llIIlIIllllIl(enabled))
    {
      llllllllllllllllIIIIIIIIIIIIIlll = lIIIIIlIIIlI[0];
      "".length();
      if ((0x94 ^ 0xC2 ^ 0xDA ^ 0x88) <= "  ".length()) {
        return (0xCD ^ 0xB8 ^ 0x35 ^ 0x4E) & (0xE7 ^ 0xC3 ^ 0x6A ^ 0x40 ^ -" ".length());
      }
    }
    else if (llIIlIIlllllI(llllllllllllllllIIIIIIIIIIIIlIII))
    {
      llllllllllllllllIIIIIIIIIIIIIlll = lIIIIIlIIIlI[5];
    }
    return llllllllllllllllIIIIIIIIIIIIIlll;
  }
  
  private static String llIIlIIllIIIl(String lllllllllllllllIlllllllllIllIllI, String lllllllllllllllIlllllllllIllIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlllllllllIlllIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllllllllIllIlIl.getBytes(StandardCharsets.UTF_8)), lIIIIIlIIIlI[16]), "DES");
      Cipher lllllllllllllllIlllllllllIlllIII = Cipher.getInstance("DES");
      lllllllllllllllIlllllllllIlllIII.init(lIIIIIlIIIlI[5], lllllllllllllllIlllllllllIlllIIl);
      return new String(lllllllllllllllIlllllllllIlllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllllllllIllIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlllllllllIllIlll)
    {
      lllllllllllllllIlllllllllIllIlll.printStackTrace();
    }
    return null;
  }
  
  public int getButtonWidth()
  {
    ;
    return width;
  }
  
  private static boolean llIIlIIllllll(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIlllllllllIlIllIl;
    return ??? >= i;
  }
  
  private static boolean llIIlIIllllIl(int ???)
  {
    String lllllllllllllllIlllllllllIlIIlIl;
    return ??? == 0;
  }
}

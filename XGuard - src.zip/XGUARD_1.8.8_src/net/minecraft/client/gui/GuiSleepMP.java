package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.resources.I18n;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.client.C0BPacketEntityAction.Action;

public class GuiSleepMP
  extends GuiChat
{
  static
  {
    lIIlIllllllII();
    lIIlIlllllIII();
  }
  
  private static String lIIlIllllIlll(String llllllllllllllllIllIIIIllIIllllI, String llllllllllllllllIllIIIIllIIllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIllIIIIllIlIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllIIIIllIIllIll.getBytes(StandardCharsets.UTF_8)), llIIIllIlII[7]), "DES");
      Cipher llllllllllllllllIllIIIIllIlIIIII = Cipher.getInstance("DES");
      llllllllllllllllIllIIIIllIlIIIII.init(llIIIllIlII[1], llllllllllllllllIllIIIIllIlIIIIl);
      return new String(llllllllllllllllIllIIIIllIlIIIII.doFinal(Base64.getDecoder().decode(llllllllllllllllIllIIIIllIIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIllIIIIllIIlllll)
    {
      llllllllllllllllIllIIIIllIIlllll.printStackTrace();
    }
    return null;
  }
  
  protected void actionPerformed(GuiButton llllllllllllllllIllIIIIllIlIllII)
    throws IOException
  {
    ;
    ;
    if (lIIlIllllllIl(id, llIIIllIlII[0]))
    {
      llllllllllllllllIllIIIIllIlIllll.wakeFromSleep();
      "".length();
      if (((0x50 ^ 0x33) & (0x5B ^ 0x38 ^ 0xFFFFFFFF)) == 0) {}
    }
    else
    {
      llllllllllllllllIllIIIIllIlIllll.actionPerformed(llllllllllllllllIllIIIIllIlIllII);
    }
  }
  
  private static void lIIlIlllllIII()
  {
    llIIIllIIIl = new String[llIIIllIlII[1]];
    llIIIllIIIl[llIIIllIlII[4]] = lIIlIllllIllI("M4EVlLCwUBna9jDuQoe4ej7SJiHRDU3SPtQCLZPmsbQ=", "SifGS");
    llIIIllIIIl[llIIIllIlII[0]] = lIIlIllllIlll("qzH+gNtfjwc=", "CtSRG");
  }
  
  public void initGui()
  {
    ;
    llllllllllllllllIllIIIIllIlllllI.initGui();
    new GuiButton(llIIIllIlII[0], width / llIIIllIlII[1] - llIIIllIlII[2], height - llIIIllIlII[3], I18n.format(llIIIllIIIl[llIIIllIlII[4]], new Object[llIIIllIlII[4]]));
    "".length();
  }
  
  private static void lIIlIllllllII()
  {
    llIIIllIlII = new int[8];
    llIIIllIlII[0] = " ".length();
    llIIIllIlII[1] = "  ".length();
    llIIIllIlII[2] = (0x62 ^ 0x6);
    llIIIllIlII[3] = (0x47 ^ 0x15 ^ 0x3E ^ 0x44);
    llIIIllIlII[4] = ((0x4C ^ 0x26 ^ 0x64 ^ 0x1F) & (0x4A ^ 0x2C ^ 0x58 ^ 0x2F ^ -" ".length()));
    llIIIllIlII[5] = (0x5D ^ 0x14 ^ 0xDC ^ 0x89);
    llIIIllIlII[6] = (14 + 66 - 68 + 144);
    llIIIllIlII[7] = (0x40 ^ 0x48);
  }
  
  private static boolean lIIlIllllllll(int ???)
  {
    long llllllllllllllllIllIIIIllIIIIllI;
    return ??? == 0;
  }
  
  public GuiSleepMP() {}
  
  private static boolean lIIlIllllllIl(int ???, int arg1)
  {
    int i;
    int llllllllllllllllIllIIIIllIIIlIII;
    return ??? == i;
  }
  
  private static String lIIlIllllIllI(String llllllllllllllllIllIIIIllIIIllll, String llllllllllllllllIllIIIIllIIlIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIllIIIIllIIlIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllIIIIllIIlIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIllIIIIllIIlIIll = Cipher.getInstance("Blowfish");
      llllllllllllllllIllIIIIllIIlIIll.init(llIIIllIlII[1], llllllllllllllllIllIIIIllIIlIlII);
      return new String(llllllllllllllllIllIIIIllIIlIIll.doFinal(Base64.getDecoder().decode(llllllllllllllllIllIIIIllIIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIllIIIIllIIlIIlI)
    {
      llllllllllllllllIllIIIIllIIlIIlI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIlIlllllllI(int ???, int arg1)
  {
    int i;
    int llllllllllllllllIllIIIIllIIIIIlI;
    return ??? != i;
  }
  
  protected void keyTyped(char llllllllllllllllIllIIIIllIllIlII, int llllllllllllllllIllIIIIllIllIIll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    if (lIIlIllllllIl(llllllllllllllllIllIIIIllIllIIll, llIIIllIlII[0]))
    {
      llllllllllllllllIllIIIIllIlllIIl.wakeFromSleep();
      "".length();
      if (null == null) {}
    }
    else if ((lIIlIlllllllI(llllllllllllllllIllIIIIllIllIIll, llIIIllIlII[5])) && (lIIlIlllllllI(llllllllllllllllIllIIIIllIllIIll, llIIIllIlII[6])))
    {
      llllllllllllllllIllIIIIllIlllIIl.keyTyped(llllllllllllllllIllIIIIllIlllIII, llllllllllllllllIllIIIIllIllIIll);
      "".length();
      if ((0x7D ^ 0x6A ^ 0x81 ^ 0x92) > -" ".length()) {}
    }
    else
    {
      String llllllllllllllllIllIIIIllIllIllI = inputField.getText().trim();
      if (lIIlIllllllll(llllllllllllllllIllIIIIllIllIllI.isEmpty())) {
        mc.thePlayer.sendChatMessage(llllllllllllllllIllIIIIllIllIllI);
      }
      inputField.setText(llIIIllIIIl[llIIIllIlII[0]]);
      mc.ingameGUI.getChatGUI().resetScroll();
    }
  }
  
  private void wakeFromSleep()
  {
    ;
    ;
    NetHandlerPlayClient llllllllllllllllIllIIIIllIlIlIII = mc.thePlayer.sendQueue;
    llllllllllllllllIllIIIIllIlIlIII.addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SLEEPING));
  }
}

package net.minecraft.client.gui;

import io.netty.buffer.Unpooled;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerRepair;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.world.World;
import org.lwjgl.input.Keyboard;

public class GuiRepair
  extends GuiContainer
  implements ICrafting
{
  private static void lIlllIllIlI()
  {
    lllIIlIlI = new String[lllIIlIll[20]];
    lllIIlIlI[lllIIlIll[0]] = lIlllIlIlll("5jZrof4wSPcENHPbtyqbQ6GDdUKOiN+75vhPFLRe3dnl/xku/mv8Ig==", "YTiSn");
    lllIIlIlI[lllIIlIll[1]] = lIlllIlIlll("pxrTZidoky4zUuG/8l8GVVmIqZ62BBer", "YfXIM");
    lllIIlIlI[lllIIlIll[2]] = lIlllIllIII("MVdJmKbQqsTwHEHC1B5m9/P64b8pnkIa", "oYrGb");
    lllIIlIlI[lllIIlIll[14]] = lIlllIllIIl("BTsePiwPOhU4YxQxACskFHoVMj0DOgMjOwM=", "fTpJM");
    lllIIlIlI[lllIIlIll[24]] = lIlllIllIIl("", "tKZuN");
    lllIIlIlI[lllIIlIll[25]] = lIlllIlIlll("nDsE6vM4ci6cEgGrgwARXw==", "UVztg");
    lllIIlIlI[lllIIlIll[10]] = lIlllIllIIl("", "TEFjb");
  }
  
  protected void drawGuiContainerForegroundLayer(int lIIllllIlIlllI, int lIIllllIlIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.disableLighting();
    GlStateManager.disableBlend();
    "".length();
    if (lIlllIlllII(anvil.maximumCost))
    {
      int lIIllllIlIllII = lllIIlIll[12];
      boolean lIIllllIlIlIll = lllIIlIll[1];
      String lIIllllIlIlIlI = I18n.format(lllIIlIlI[lllIIlIll[2]], new Object[] { Integer.valueOf(anvil.maximumCost) });
      if ((lIlllIlllIl(anvil.maximumCost, lllIIlIll[13])) && (lIlllIllllI(mc.thePlayer.capabilities.isCreativeMode)))
      {
        lIIllllIlIlIlI = I18n.format(lllIIlIlI[lllIIlIll[14]], new Object[lllIIlIll[0]]);
        lIIllllIlIllII = lllIIlIll[15];
        "".length();
        if ("   ".length() >= 0) {}
      }
      else if (lIlllIllllI(anvil.getSlot(lllIIlIll[2]).getHasStack()))
      {
        lIIllllIlIlIll = lllIIlIll[0];
        "".length();
        if (-(0x2B ^ 0x2F) <= 0) {}
      }
      else if (lIlllIllllI(anvil.getSlot(lllIIlIll[2]).canTakeStack(playerInventory.player)))
      {
        lIIllllIlIllII = lllIIlIll[15];
      }
      if (lIlllIlllll(lIIllllIlIlIll))
      {
        int lIIllllIlIlIIl = lllIIlIll[16] | (lIIllllIlIllII & lllIIlIll[17]) >> lllIIlIll[2] | lIIllllIlIllII & lllIIlIll[16];
        int lIIllllIlIlIII = xSize - lllIIlIll[18] - fontRendererObj.getStringWidth(lIIllllIlIlIlI);
        int lIIllllIlIIlll = lllIIlIll[19];
        if (lIlllIlllll(fontRendererObj.getUnicodeFlag()))
        {
          drawRect(lIIllllIlIlIII - lllIIlIll[14], lIIllllIlIIlll - lllIIlIll[2], xSize - lllIIlIll[20], lIIllllIlIIlll + lllIIlIll[21], lllIIlIll[16]);
          drawRect(lIIllllIlIlIII - lllIIlIll[2], lIIllllIlIIlll - lllIIlIll[1], xSize - lllIIlIll[18], lIIllllIlIIlll + lllIIlIll[22], lllIIlIll[23]);
          "".length();
          if (null == null) {}
        }
        else
        {
          "".length();
          "".length();
          "".length();
        }
        "".length();
      }
    }
    GlStateManager.enableLighting();
  }
  
  public GuiRepair(InventoryPlayer lIIlllllIIIlII, World lIIlllllIIIIll)
  {
    lIIlllllIIIlIl.<init>(new ContainerRepair(lIIlllllIIIlll, lIIlllllIIIIll, getMinecraftthePlayer));
    playerInventory = lIIlllllIIIlll;
    anvil = ((ContainerRepair)inventorySlots);
  }
  
  private static boolean lIlllIlllII(int ???)
  {
    double lIIlllIIIIlllI;
    return ??? > 0;
  }
  
  private static String lIlllIllIIl(String lIIlllIIllIlIl, String lIIlllIIlllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIIlllIIllIlIl = new String(Base64.getDecoder().decode(lIIlllIIllIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIIlllIIlllIII = new StringBuilder();
    char[] lIIlllIIllIlll = lIIlllIIlllIIl.toCharArray();
    int lIIlllIIllIllI = lllIIlIll[0];
    long lIIlllIIllIIII = lIIlllIIllIlIl.toCharArray();
    long lIIlllIIlIllll = lIIlllIIllIIII.length;
    short lIIlllIIlIlllI = lllIIlIll[0];
    while (lIllllIIIlI(lIIlllIIlIlllI, lIIlllIIlIllll))
    {
      char lIIlllIIlllIll = lIIlllIIllIIII[lIIlllIIlIlllI];
      "".length();
      "".length();
      if ("   ".length() < "  ".length()) {
        return null;
      }
    }
    return String.valueOf(lIIlllIIlllIII);
  }
  
  private static String lIlllIlIlll(String lIIlllIlIIlIII, String lIIlllIlIIlIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIlllIlIIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIIlllIlIIlIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIIlllIlIIllII = Cipher.getInstance("Blowfish");
      lIIlllIlIIllII.init(lllIIlIll[2], lIIlllIlIIllIl);
      return new String(lIIlllIlIIllII.doFinal(Base64.getDecoder().decode(lIIlllIlIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIlllIlIIlIll)
    {
      lIIlllIlIIlIll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlllIlllIl(int ???, int arg1)
  {
    int i;
    short lIIlllIIIlllII;
    return ??? >= i;
  }
  
  static
  {
    lIlllIllIll();
    lIlllIllIlI();
  }
  
  public void sendProgressBarUpdate(Container lIIlllIlIlIlll, int lIIlllIlIlIllI, int lIIlllIlIlIlIl) {}
  
  public void drawScreen(int lIIlllIlllllII, int lIIlllIllllIll, float lIIlllIllllIlI)
  {
    ;
    ;
    ;
    ;
    lIIlllIllllIIl.drawScreen(lIIlllIlllllII, lIIlllIllllIll, lIIlllIllllIlI);
    GlStateManager.disableLighting();
    GlStateManager.disableBlend();
    nameField.drawTextBox();
  }
  
  public void onGuiClosed()
  {
    ;
    lIIllllIlllIII.onGuiClosed();
    Keyboard.enableRepeatEvents(lllIIlIll[0]);
    inventorySlots.removeCraftingFromCrafters(lIIllllIllIlll);
  }
  
  protected void drawGuiContainerBackgroundLayer(float lIIlllIlllIIIl, int lIIlllIlllIIII, int lIIlllIllIllll)
  {
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(anvilResource);
    int lIIlllIllIlllI = (width - xSize) / lllIIlIll[2];
    int lIIlllIllIllIl = (height - ySize) / lllIIlIll[2];
    lIIlllIllIllII.drawTexturedModalRect(lIIlllIllIlllI, lIIlllIllIllIl, lllIIlIll[0], lllIIlIll[0], xSize, ySize);
    if (lIlllIlllll(anvil.getSlot(lllIIlIll[0]).getHasStack()))
    {
      "".length();
      if ((('©' + '' - 311 + 154 ^ 32 + 35 - 10 + 127) & (0x7D ^ 0x37 ^ 0xEE ^ 0xB7 ^ -" ".length())) != "  ".length()) {
        break label205;
      }
    }
    label205:
    (lIIlllIllIlllI + lllIIlIll[26]).drawTexturedModalRect(lIIlllIllIllIl + lllIIlIll[27], lllIIlIll[0], ySize, lllIIlIll[0] + lllIIlIll[28], lllIIlIll[29], lllIIlIll[28]);
    if (((!lIlllIllllI(anvil.getSlot(lllIIlIll[0]).getHasStack())) || (lIlllIlllll(anvil.getSlot(lllIIlIll[1]).getHasStack()))) && (lIlllIllllI(anvil.getSlot(lllIIlIll[2]).getHasStack()))) {
      lIIlllIllIllII.drawTexturedModalRect(lIIlllIllIlllI + lllIIlIll[30], lIIlllIllIllIl + lllIIlIll[31], xSize, lllIIlIll[0], lllIIlIll[32], lllIIlIll[33]);
    }
  }
  
  protected void keyTyped(char lIIllllIIllIII, int lIIllllIIllIlI)
    throws IOException
  {
    ;
    ;
    ;
    if (lIlllIlllll(nameField.textboxKeyTyped(lIIllllIIllIll, lIIllllIIllIlI)))
    {
      lIIllllIIlllII.renameItem();
      "".length();
      if (null == null) {}
    }
    else
    {
      lIIllllIIlllII.keyTyped(lIIllllIIllIll, lIIllllIIllIlI);
    }
  }
  
  public void func_175173_a(Container lIIlllIlIlIIll, IInventory lIIlllIlIlIIlI) {}
  
  public void updateCraftingInventory(Container lIIlllIllIIllI, List<ItemStack> lIIlllIllIIlIl)
  {
    ;
    ;
    lIIlllIllIIlll.sendSlotContents(lIIlllIllIIIll, lllIIlIll[0], lIIlllIllIIIll.getSlot(lllIIlIll[0]).getStack());
  }
  
  private static String lIlllIllIII(String lIIlllIIlIIIll, String lIIlllIIlIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIlllIIlIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIIlllIIlIIIlI.getBytes(StandardCharsets.UTF_8)), lllIIlIll[18]), "DES");
      Cipher lIIlllIIlIIlll = Cipher.getInstance("DES");
      lIIlllIIlIIlll.init(lllIIlIll[2], lIIlllIIlIlIII);
      return new String(lIIlllIIlIIlll.doFinal(Base64.getDecoder().decode(lIIlllIIlIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIlllIIlIIllI)
    {
      lIIlllIIlIIllI.printStackTrace();
    }
    return null;
  }
  
  private void renameItem()
  {
    ;
    ;
    ;
    String lIIllllIIlIIlI = nameField.getText();
    Slot lIIllllIIlIIIl = anvil.getSlot(lllIIlIll[0]);
    if ((lIllllIIIII(lIIllllIIlIIIl)) && (lIlllIlllll(lIIllllIIlIIIl.getHasStack())) && (lIlllIllllI(lIIllllIIlIIIl.getStack().hasDisplayName())) && (lIlllIlllll(lIIllllIIlIIlI.equals(lIIllllIIlIIIl.getStack().getDisplayName())))) {
      lIIllllIIlIIlI = lllIIlIlI[lllIIlIll[24]];
    }
    anvil.updateItemName(lIIllllIIlIIlI);
    mc.thePlayer.sendQueue.addToSendQueue(new C17PacketCustomPayload(lllIIlIlI[lllIIlIll[25]], new PacketBuffer(Unpooled.buffer()).writeString(lIIllllIIlIIlI)));
  }
  
  public void initGui()
  {
    ;
    ;
    ;
    lIIllllIllllll.initGui();
    Keyboard.enableRepeatEvents(lllIIlIll[1]);
    int lIIllllIlllllI = (width - xSize) / lllIIlIll[2];
    int lIIllllIllllIl = (height - ySize) / lllIIlIll[2];
    nameField = new GuiTextField(lllIIlIll[0], fontRendererObj, lIIllllIlllllI + lllIIlIll[3], lIIllllIllllIl + lllIIlIll[4], lllIIlIll[5], lllIIlIll[6]);
    nameField.setTextColor(lllIIlIll[7]);
    nameField.setDisabledTextColour(lllIIlIll[7]);
    nameField.setEnableBackgroundDrawing(lllIIlIll[0]);
    nameField.setMaxStringLength(lllIIlIll[8]);
    inventorySlots.removeCraftingFromCrafters(lIIllllIllllII);
    inventorySlots.onCraftGuiOpened(lIIllllIllllII);
  }
  
  public void sendSlotContents(Container lIIlllIlIllllI, int lIIlllIlIllIlI, ItemStack lIIlllIlIlllII)
  {
    ;
    ;
    ;
    if (lIlllIllllI(lIIlllIlIllIlI))
    {
      if (lIllllIIIIl(lIIlllIlIlllII))
      {
        "".length();
        if (" ".length() <= " ".length()) {
          break label54;
        }
      }
      label54:
      lllIIlIlI[lllIIlIll[10]].setText(lIIlllIlIlllII.getDisplayName());
      if (lIllllIIIII(lIIlllIlIlllII))
      {
        "".length();
        if (null == null) {
          break label89;
        }
      }
      label89:
      lllIIlIll[1].setEnabled(lllIIlIll[0]);
      if (lIllllIIIII(lIIlllIlIlllII)) {
        lIIlllIlIlllll.renameItem();
      }
    }
  }
  
  protected void mouseClicked(int lIIllllIIIIlII, int lIIllllIIIIlll, int lIIllllIIIIIlI)
    throws IOException
  {
    ;
    ;
    ;
    ;
    lIIllllIIIlIIl.mouseClicked(lIIllllIIIIlII, lIIllllIIIIlll, lIIllllIIIIIlI);
    nameField.mouseClicked(lIIllllIIIIlII, lIIllllIIIIlll, lIIllllIIIIIlI);
  }
  
  private static boolean lIllllIIIlI(int ???, int arg1)
  {
    int i;
    float lIIlllIIIllIII;
    return ??? < i;
  }
  
  private static boolean lIllllIIIIl(Object ???)
  {
    boolean lIIlllIIIlIlII;
    return ??? == null;
  }
  
  private static boolean lIlllIllllI(int ???)
  {
    int lIIlllIIIlIIII;
    return ??? == 0;
  }
  
  private static boolean lIllllIIIII(Object ???)
  {
    char lIIlllIIIlIllI;
    return ??? != null;
  }
  
  private static boolean lIlllIlllll(int ???)
  {
    float lIIlllIIIlIIlI;
    return ??? != 0;
  }
  
  private static void lIlllIllIll()
  {
    lllIIlIll = new int[34];
    lllIIlIll[0] = ((0x38 ^ 0x1) & (0x59 ^ 0x60 ^ 0xFFFFFFFF));
    lllIIlIll[1] = " ".length();
    lllIIlIll[2] = "  ".length();
    lllIIlIll[3] = (0x41 ^ 0x6D ^ 0x79 ^ 0x6B);
    lllIIlIll[4] = (26 + 125 - 145 + 143 ^ 54 + 42 - -13 + 32);
    lllIIlIll[5] = (0x9B ^ 0x9F ^ 0x7D ^ 0x1E);
    lllIIlIll[6] = (0xFF ^ 0xA6 ^ 0xEF ^ 0xBA);
    lllIIlIll[7] = (-" ".length());
    lllIIlIll[8] = (127 + 91 - 169 + 120 ^ 87 + 51 - 73 + 118);
    lllIIlIll[9] = (93 + 47 - 26 + 34 ^ 94 + '' - 149 + 83);
    lllIIlIll[10] = (0x8A ^ 0xBF ^ 0x36 ^ 0x5);
    lllIIlIll[11] = (-(0xBD2C & 0x4FFF) & 0xFF7B & 0x404DEF);
    lllIIlIll[12] = (-(87 + 99 - 164 + 115) & 0xFFFFFFBE & 0x80FFE9);
    lllIIlIll[13] = (0xBA ^ 0x92);
    lllIIlIll[14] = "   ".length();
    lllIIlIll[15] = (0xF5F1 & 0xFF6A6E);
    lllIIlIll[16] = (-(-(0xBAFB & 0x6F3F) & 0xFFFFFFFB & 0x1002A3E));
    lllIIlIll[17] = (-" ".length() & 0xFFFFFFFF & 0xFCFCFC);
    lllIIlIll[18] = (0x33 ^ 0x3B);
    lllIIlIll[19] = (61 + 91 - 32 + 87 ^ '' + 65 - 117 + 57);
    lllIIlIll[20] = (0xE3 ^ 0xA6 ^ 0x6D ^ 0x2F);
    lllIIlIll[21] = (0xBC ^ 0xB6);
    lllIIlIll[22] = ("  ".length() ^ 0x98 ^ 0x93);
    lllIIlIll[23] = (-(0xFCC7 & 0xC4C7FD));
    lllIIlIll[24] = (0x2F ^ 0x2B);
    lllIIlIll[25] = (0xB8 ^ 0xBD);
    lllIIlIll[26] = (0xFF ^ 0xC4);
    lllIIlIll[27] = (0xE3 ^ 0x89 ^ 0xC1 ^ 0xBF);
    lllIIlIll[28] = (0x0 ^ 0xD ^ 0x93 ^ 0x8E);
    lllIIlIll[29] = (0xD3 ^ 0xBD);
    lllIIlIll[30] = (0x6E ^ 0xD);
    lllIIlIll[31] = (48 + 38 - -55 + 4 ^ '®' + 61 - 188 + 141);
    lllIIlIll[32] = (0x20 ^ 0x14 ^ 0xA3 ^ 0x8B);
    lllIIlIll[33] = (0x3 ^ 0x16);
  }
}

package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatStyle;
import net.minecraft.util.IChatComponent;

public class GuiUtilRenderComponents
{
  private static String lllIIlIIlIIIll(String llllllllllllllIIllllIlIlIllIIIIl, String llllllllllllllIIllllIlIlIllIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllllIlIlIllIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllllIlIlIllIIIII.getBytes(StandardCharsets.UTF_8)), lIIlIlIllIllI[9]), "DES");
      Cipher llllllllllllllIIllllIlIlIllIIIll = Cipher.getInstance("DES");
      llllllllllllllIIllllIlIlIllIIIll.init(lIIlIlIllIllI[3], llllllllllllllIIllllIlIlIllIIlII);
      return new String(llllllllllllllIIllllIlIlIllIIIll.doFinal(Base64.getDecoder().decode(llllllllllllllIIllllIlIlIllIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllllIlIlIllIIIlI)
    {
      llllllllllllllIIllllIlIlIllIIIlI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIlIIlIlIlI(int ???, int arg1)
  {
    int i;
    char llllllllllllllIIllllIlIlIIlIllll;
    return ??? < i;
  }
  
  private static boolean lllIIlIIlIlIll(Object ???)
  {
    byte llllllllllllllIIllllIlIlIIlIIlIl;
    return ??? != null;
  }
  
  private static boolean lllIIlIIlIllII(int ???)
  {
    short llllllllllllllIIllllIlIlIIIlllIl;
    return ??? > 0;
  }
  
  private static boolean lllIIlIIlIIlll(int ???)
  {
    int llllllllllllllIIllllIlIlIIlIIIIl;
    return ??? == 0;
  }
  
  private static boolean lllIIlIIlIlIII(int ???)
  {
    byte llllllllllllllIIllllIlIlIIlIIIll;
    return ??? != 0;
  }
  
  private static void lllIIlIIlIIlIl()
  {
    lIIlIlIllIlIl = new String[lIIlIlIllIllI[8]];
    lIIlIlIllIlIl[lIIlIlIllIllI[0]] = lllIIlIIlIIIlI("PLnHwbNMkW4=", "rKMrd");
    lIIlIlIllIlIl[lIIlIlIllIllI[1]] = lllIIlIIlIIIll("3Qan6AkYgXQ=", "FMTGW");
    lIIlIlIllIlIl[lIIlIlIllIllI[3]] = lllIIlIIlIIlII("cw==", "yxPnX");
    lIIlIlIllIlIl[lIIlIlIllIllI[4]] = lllIIlIIlIIlII("cg==", "RynAV");
    lIIlIlIllIlIl[lIIlIlIllIllI[5]] = lllIIlIIlIIIlI("1kaBM7yY3oY=", "zWEXN");
    lIIlIlIllIlIl[lIIlIlIllIllI[6]] = lllIIlIIlIIlII("", "stvTA");
    lIIlIlIllIlIl[lIIlIlIllIllI[7]] = lllIIlIIlIIlII("", "oLFhv");
  }
  
  private static void lllIIlIIlIIllI()
  {
    lIIlIlIllIllI = new int[10];
    lIIlIlIllIllI[0] = ((0x81 ^ 0x9A ^ 0x80 ^ 0xC3) & (0x37 ^ 0x74 ^ 0x96 ^ 0x8D ^ -" ".length()));
    lIIlIlIllIllI[1] = " ".length();
    lIIlIlIllIllI[2] = (0x9 ^ 0x4 ^ 0xA4 ^ 0xA3);
    lIIlIlIllIllI[3] = "  ".length();
    lIIlIlIllIllI[4] = "   ".length();
    lIIlIlIllIllI[5] = (0x34 ^ 0x30);
    lIIlIlIllIllI[6] = (0x9A ^ 0x9F);
    lIIlIlIllIllI[7] = (0x85 ^ 0x83);
    lIIlIlIllIllI[8] = (0xB4 ^ 0xB3);
    lIIlIlIllIllI[9] = (0x4B ^ 0x43);
  }
  
  public GuiUtilRenderComponents() {}
  
  private static String lllIIlIIlIIIlI(String llllllllllllllIIllllIlIlIIllllII, String llllllllllllllIIllllIlIlIIlllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllllIlIlIIllllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllllIlIlIIlllIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIIllllIlIlIIlllllI = Cipher.getInstance("Blowfish");
      llllllllllllllIIllllIlIlIIlllllI.init(lIIlIlIllIllI[3], llllllllllllllIIllllIlIlIIllllll);
      return new String(llllllllllllllIIllllIlIlIIlllllI.doFinal(Base64.getDecoder().decode(llllllllllllllIIllllIlIlIIllllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllllIlIlIIllllIl)
    {
      llllllllllllllIIllllIlIlIIllllIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIlIIlIllll(int ???, int arg1)
  {
    int i;
    char llllllllllllllIIllllIlIlIIllIIll;
    return ??? >= i;
  }
  
  private static boolean lllIIlIIlIllIl(int ???)
  {
    short llllllllllllllIIllllIlIlIIIlllll;
    return ??? >= 0;
  }
  
  private static boolean lllIIlIIlIlIIl(int ???, int arg1)
  {
    int i;
    long llllllllllllllIIllllIlIlIIlIIlll;
    return ??? > i;
  }
  
  public static List<IChatComponent> func_178908_a(IChatComponent llllllllllllllIIllllIlIllIIlIlIl, int llllllllllllllIIllllIlIllIIlIlII, FontRenderer llllllllllllllIIllllIlIlIllllIll, boolean llllllllllllllIIllllIlIlIllllIlI, boolean llllllllllllllIIllllIlIllIIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIIllllIlIllIIlIIII = lIIlIlIllIllI[0];
    IChatComponent llllllllllllllIIllllIlIllIIIllll = new ChatComponentText(lIIlIlIllIlIl[lIIlIlIllIllI[0]]);
    List<IChatComponent> llllllllllllllIIllllIlIllIIIlllI = Lists.newArrayList();
    List<IChatComponent> llllllllllllllIIllllIlIllIIIllIl = Lists.newArrayList(llllllllllllllIIllllIlIllIIlIlIl);
    int llllllllllllllIIllllIlIllIIIllII = lIIlIlIllIllI[0];
    "".length();
    if (((116 + 110 - 215 + 176 ^ 98 + 7 - -43 + 24) & (0x78 ^ 0x32 ^ 0x50 ^ 0xD ^ -" ".length())) < 0) {
      return null;
    }
    label353:
    label473:
    while (!lllIIlIIlIllll(llllllllllllllIIllllIlIllIIIllII, llllllllllllllIIllllIlIllIIIllIl.size()))
    {
      IChatComponent llllllllllllllIIllllIlIllIIIlIll = (IChatComponent)llllllllllllllIIllllIlIllIIIllIl.get(llllllllllllllIIllllIlIllIIIllII);
      String llllllllllllllIIllllIlIllIIIlIlI = llllllllllllllIIllllIlIllIIIlIll.getUnformattedTextForChat();
      boolean llllllllllllllIIllllIlIllIIIlIIl = lIIlIlIllIllI[0];
      if (lllIIlIIlIlIII(llllllllllllllIIllllIlIllIIIlIlI.contains(lIIlIlIllIlIl[lIIlIlIllIllI[1]])))
      {
        int llllllllllllllIIllllIlIllIIIlIII = llllllllllllllIIllllIlIllIIIlIlI.indexOf(lIIlIlIllIllI[2]);
        String llllllllllllllIIllllIlIllIIIIlll = llllllllllllllIIllllIlIllIIIlIlI.substring(llllllllllllllIIllllIlIllIIIlIII + lIIlIlIllIllI[1]);
        llllllllllllllIIllllIlIllIIIlIlI = llllllllllllllIIllllIlIllIIIlIlI.substring(lIIlIlIllIllI[0], llllllllllllllIIllllIlIllIIIlIII + lIIlIlIllIllI[1]);
        ChatComponentText llllllllllllllIIllllIlIllIIIIllI = new ChatComponentText(llllllllllllllIIllllIlIllIIIIlll);
        "".length();
        llllllllllllllIIllllIlIllIIIllIl.add(llllllllllllllIIllllIlIllIIIllII + lIIlIlIllIllI[1], llllllllllllllIIllllIlIllIIIIllI);
        llllllllllllllIIllllIlIllIIIlIIl = lIIlIlIllIllI[1];
      }
      String llllllllllllllIIllllIlIllIIIIlIl = func_178909_a(String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIIllllIlIllIIIlIll.getChatStyle().getFormattingCode())).append(llllllllllllllIIllllIlIllIIIlIlI)), llllllllllllllIIllllIlIllIIlIIIl);
      if (lllIIlIIlIlIII(llllllllllllllIIllllIlIllIIIIlIl.endsWith(lIIlIlIllIlIl[lIIlIlIllIllI[3]])))
      {
        "".length();
        if (((0x7F ^ 0x53) & (0x3D ^ 0x11 ^ 0xFFFFFFFF)) == 0) {
          break label353;
        }
        return null;
      }
      String llllllllllllllIIllllIlIllIIIIlII = llllllllllllllIIllllIlIllIIIIlIl;
      int llllllllllllllIIllllIlIllIIIIIll = llllllllllllllIIllllIlIllIIlIIll.getStringWidth(llllllllllllllIIllllIlIllIIIIlII);
      ChatComponentText llllllllllllllIIllllIlIllIIIIIlI = new ChatComponentText(llllllllllllllIIllllIlIllIIIIlII);
      "".length();
      if (lllIIlIIlIlIIl(llllllllllllllIIllllIlIllIIlIIII + llllllllllllllIIllllIlIllIIIIIll, llllllllllllllIIllllIlIllIIlIlII))
      {
        String llllllllllllllIIllllIlIllIIIIIIl = llllllllllllllIIllllIlIllIIlIIll.trimStringToWidth(llllllllllllllIIllllIlIllIIIIlIl, llllllllllllllIIllllIlIllIIlIlII - llllllllllllllIIllllIlIllIIlIIII, lIIlIlIllIllI[0]);
        if (lllIIlIIlIlIlI(llllllllllllllIIllllIlIllIIIIIIl.length(), llllllllllllllIIllllIlIllIIIIlIl.length()))
        {
          "".length();
          if (-" ".length() < "   ".length()) {
            break label473;
          }
          return null;
        }
        String llllllllllllllIIllllIlIllIIIIIII = null;
        if ((lllIIlIIlIlIll(llllllllllllllIIllllIlIllIIIIIII)) && (lllIIlIIlIllII(llllllllllllllIIllllIlIllIIIIIII.length())))
        {
          int llllllllllllllIIllllIlIlIlllllll = llllllllllllllIIllllIlIllIIIIIIl.lastIndexOf(lIIlIlIllIlIl[lIIlIlIllIllI[4]]);
          if ((lllIIlIIlIllIl(llllllllllllllIIllllIlIlIlllllll)) && (lllIIlIIlIllII(llllllllllllllIIllllIlIllIIlIIll.getStringWidth(llllllllllllllIIllllIlIllIIIIlIl.substring(lIIlIlIllIllI[0], llllllllllllllIIllllIlIlIlllllll)))))
          {
            llllllllllllllIIllllIlIllIIIIIIl = llllllllllllllIIllllIlIllIIIIlIl.substring(lIIlIlIllIllI[0], llllllllllllllIIllllIlIlIlllllll);
            if (lllIIlIIlIlIII(llllllllllllllIIllllIlIlIllllIlI)) {}
            llllllllllllllIIllllIlIllIIIIIII = llllllllllllllIIllllIlIllIIIIlIl.substring(llllllllllllllIIllllIlIlIlllllll);
            "".length();
            if (((0xE0 ^ 0x85 ^ 0xC7 ^ 0xA9) & (66 + 125 - 61 + 29 ^ 93 + '' - 215 + 139 ^ -" ".length())) != 0) {
              return null;
            }
          }
          else if ((lllIIlIIlIllII(llllllllllllllIIllllIlIllIIlIIII)) && (lllIIlIIlIIlll(llllllllllllllIIllllIlIllIIIIlIl.contains(lIIlIlIllIlIl[lIIlIlIllIllI[5]]))))
          {
            llllllllllllllIIllllIlIllIIIIIIl = lIIlIlIllIlIl[lIIlIlIllIllI[6]];
            llllllllllllllIIllllIlIllIIIIIII = llllllllllllllIIllllIlIllIIIIlIl;
          }
          ChatComponentText llllllllllllllIIllllIlIlIllllllI = new ChatComponentText(llllllllllllllIIllllIlIllIIIIIII);
          "".length();
          llllllllllllllIIllllIlIllIIIllIl.add(llllllllllllllIIllllIlIllIIIllII + lIIlIlIllIllI[1], llllllllllllllIIllllIlIlIllllllI);
        }
        llllllllllllllIIllllIlIllIIIIIll = llllllllllllllIIllllIlIllIIlIIll.getStringWidth(llllllllllllllIIllllIlIllIIIIIIl);
        llllllllllllllIIllllIlIllIIIIIlI = new ChatComponentText(llllllllllllllIIllllIlIllIIIIIIl);
        "".length();
        llllllllllllllIIllllIlIllIIIlIIl = lIIlIlIllIllI[1];
      }
      if (lllIIlIIlIlllI(llllllllllllllIIllllIlIllIIlIIII + llllllllllllllIIllllIlIllIIIIIll, llllllllllllllIIllllIlIllIIlIlII))
      {
        llllllllllllllIIllllIlIllIIlIIII += llllllllllllllIIllllIlIllIIIIIll;
        "".length();
        "".length();
        if ((122 + 97 - 173 + 98 ^ 7 + 42 - -28 + 71) <= -" ".length()) {
          return null;
        }
      }
      else
      {
        llllllllllllllIIllllIlIllIIIlIIl = lIIlIlIllIllI[1];
      }
      if (lllIIlIIlIlIII(llllllllllllllIIllllIlIllIIIlIIl))
      {
        "".length();
        llllllllllllllIIllllIlIllIIlIIII = lIIlIlIllIllI[0];
        llllllllllllllIIllllIlIllIIIllll = new ChatComponentText(lIIlIlIllIlIl[lIIlIlIllIllI[7]]);
      }
      llllllllllllllIIllllIlIllIIIllII++;
    }
    "".length();
    return llllllllllllllIIllllIlIllIIIlllI;
  }
  
  private static boolean lllIIlIIlIlllI(int ???, int arg1)
  {
    int i;
    short llllllllllllllIIllllIlIlIIlIlIll;
    return ??? <= i;
  }
  
  public static String func_178909_a(String llllllllllllllIIllllIlIllIlIllII, boolean llllllllllllllIIllllIlIllIlIlIll)
  {
    ;
    ;
    if ((lllIIlIIlIIlll(llllllllllllllIIllllIlIllIlIlIll)) && (lllIIlIIlIIlll(getMinecraftgameSettings.chatColours)))
    {
      "".length();
      if (" ".length() < (0x2B ^ 0x2F)) {
        break label48;
      }
      return null;
    }
    label48:
    return llllllllllllllIIllllIlIllIlIllII;
  }
  
  private static String lllIIlIIlIIlII(String llllllllllllllIIllllIlIlIlIIllII, String llllllllllllllIIllllIlIlIlIIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllllIlIlIlIIllII = new String(Base64.getDecoder().decode(llllllllllllllIIllllIlIlIlIIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIllllIlIlIlIIllll = new StringBuilder();
    char[] llllllllllllllIIllllIlIlIlIIlllI = llllllllllllllIIllllIlIlIlIIlIll.toCharArray();
    int llllllllllllllIIllllIlIlIlIIllIl = lIIlIlIllIllI[0];
    String llllllllllllllIIllllIlIlIlIIIlll = llllllllllllllIIllllIlIlIlIIllII.toCharArray();
    char llllllllllllllIIllllIlIlIlIIIllI = llllllllllllllIIllllIlIlIlIIIlll.length;
    int llllllllllllllIIllllIlIlIlIIIlIl = lIIlIlIllIllI[0];
    while (lllIIlIIlIlIlI(llllllllllllllIIllllIlIlIlIIIlIl, llllllllllllllIIllllIlIlIlIIIllI))
    {
      char llllllllllllllIIllllIlIlIlIlIIlI = llllllllllllllIIllllIlIlIlIIIlll[llllllllllllllIIllllIlIlIlIIIlIl];
      "".length();
      "".length();
      if (((0xAB ^ 0x89) & (0xB3 ^ 0x91 ^ 0xFFFFFFFF)) > "   ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIllllIlIlIlIIllll);
  }
  
  static
  {
    lllIIlIIlIIllI();
    lllIIlIIlIIlIl();
  }
}

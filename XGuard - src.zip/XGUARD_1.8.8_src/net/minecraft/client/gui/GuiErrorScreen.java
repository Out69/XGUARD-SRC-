package net.minecraft.client.gui;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.I18n;

public class GuiErrorScreen
  extends GuiScreen
{
  protected void keyTyped(char lIIlIlllIIllI, int lIIlIlllIIlIl)
    throws IOException
  {}
  
  static
  {
    lllIlIlIIlI();
    lllIlIIllIl();
  }
  
  private static String lllIlIIllII(String lIIlIllIlIIIl, String lIIlIllIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIIlIllIlIIIl = new String(Base64.getDecoder().decode(lIIlIllIlIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIIlIllIlIlII = new StringBuilder();
    char[] lIIlIllIlIIll = lIIlIllIlIIII.toCharArray();
    int lIIlIllIlIIlI = lIIIlllIlI[0];
    Exception lIIlIllIIllII = lIIlIllIlIIIl.toCharArray();
    char lIIlIllIIlIll = lIIlIllIIllII.length;
    Exception lIIlIllIIlIlI = lIIIlllIlI[0];
    while (lllIlIlIIll(lIIlIllIIlIlI, lIIlIllIIlIll))
    {
      char lIIlIllIlIlll = lIIlIllIIllII[lIIlIllIIlIlI];
      "".length();
      "".length();
      if (((0 + 94 - 61 + 98 ^ 61 + '±' - 163 + 116) & (125 + 95 - 200 + 134 ^ 63 + 107 - 155 + 151 ^ -" ".length())) != 0) {
        return null;
      }
    }
    return String.valueOf(lIIlIllIlIlII);
  }
  
  private static boolean lllIlIlIIll(int ???, int arg1)
  {
    int i;
    float lIIlIllIIIlIl;
    return ??? < i;
  }
  
  private static void lllIlIlIIlI()
  {
    lIIIlllIlI = new int[10];
    lIIIlllIlI[0] = ((0x81 ^ 0x96) & (0x82 ^ 0x95 ^ 0xFFFFFFFF));
    lIIIlllIlI[1] = "  ".length();
    lIIIlllIlI[2] = (0xD2 ^ 0xB6);
    lIIIlllIlI[3] = (105 + 95 - 116 + 56);
    lIIIlllIlI[4] = (-(-(0xC ^ 0x1A) & 0xFFFFFFFD & 0xBFDFF7));
    lIIIlllIlI[5] = (-(0xFFFFFFFD & 0xAFEFF2));
    lIIIlllIlI[6] = (0x73 ^ 0x6C ^ 0xB ^ 0x4E);
    lIIIlllIlI[7] = (0xFFFFFFFF & 0xFFFFFF);
    lIIIlllIlI[8] = (0xFE ^ 0x90);
    lIIIlllIlI[9] = " ".length();
  }
  
  private static void lllIlIIllIl()
  {
    lIIIllIlll = new String[lIIIlllIlI[9]];
    lIIIllIlll[lIIIlllIlI[0]] = lllIlIIllII("CjsxbQcMIDsmCA==", "mNXCd");
  }
  
  public void initGui()
  {
    ;
    lIIlIllllIlIl.initGui();
    new GuiButton(lIIIlllIlI[0], width / lIIIlllIlI[1] - lIIIlllIlI[2], lIIIlllIlI[3], I18n.format(lIIIllIlll[lIIIlllIlI[0]], new Object[lIIIlllIlI[0]]));
    "".length();
  }
  
  protected void actionPerformed(GuiButton lIIlIlllIIIlI)
    throws IOException
  {
    ;
    mc.displayGuiScreen(null);
  }
  
  public void drawScreen(int lIIlIlllIlIlI, int lIIlIlllIlIIl, float lIIlIlllIllII)
  {
    ;
    ;
    ;
    ;
    lIIlIlllIllll.drawGradientRect(lIIIlllIlI[0], lIIIlllIlI[0], width, height, lIIIlllIlI[4], lIIIlllIlI[5]);
    lIIlIlllIllll.drawCenteredString(fontRendererObj, field_146313_a, width / lIIIlllIlI[1], lIIIlllIlI[6], lIIIlllIlI[7]);
    lIIlIlllIllll.drawCenteredString(fontRendererObj, field_146312_f, width / lIIIlllIlI[1], lIIIlllIlI[8], lIIIlllIlI[7]);
    lIIlIlllIllll.drawScreen(lIIlIlllIlIlI, lIIlIlllIlIIl, lIIlIlllIllII);
  }
  
  public GuiErrorScreen(String lIIlIlllllIII, String lIIlIllllIlll)
  {
    field_146313_a = lIIlIlllllIll;
    field_146312_f = lIIlIllllIlll;
  }
}

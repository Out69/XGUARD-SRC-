package net.minecraft.client.gui.inventory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;
import org.lwjgl.input.Keyboard;

public abstract class GuiContainer
  extends GuiScreen
{
  private static void lIlIIllIIlIl()
  {
    llIlIIIlII = new String[llIlIIIllI[4]];
    llIlIIIlII[llIlIIIllI[0]] = lIlIIllIIIll("FzQRJSQRNBp+NhY4RjI+DSUIOD8GI0Y4PxU0ByU+EShHIT8E", "cQiQQ");
    llIlIIIlII[llIlIIIllI[3]] = lIlIIllIIlII("vHGGZsz4IVk=", "LSQgr");
  }
  
  protected void mouseReleased(int lllllllllllllllllllIIIlIIlIlllIl, int lllllllllllllllllllIIIlIIlllIIlI, int lllllllllllllllllllIIIlIIlllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Slot lllllllllllllllllllIIIlIIllIllll = lllllllllllllllllllIIIlIIlIllllI.getSlotAtPosition(lllllllllllllllllllIIIlIIlIlllIl, lllllllllllllllllllIIIlIIlllIIlI);
    int lllllllllllllllllllIIIlIIllIlllI = guiLeft;
    int lllllllllllllllllllIIIlIIllIllII = guiTop;
    if ((lIlIIlllIIII(lllllllllllllllllllIIIlIIlIlllIl, lllllllllllllllllllIIIlIIllIlllI)) && (lIlIIlllIIII(lllllllllllllllllllIIIlIIlllIIlI, lllllllllllllllllllIIIlIIllIllII)) && (lIlIIllllIll(lllllllllllllllllllIIIlIIlIlllIl, lllllllllllllllllllIIIlIIllIlllI + xSize)) && (lIlIIllllIll(lllllllllllllllllllIIIlIIlllIIlI, lllllllllllllllllllIIIlIIllIllII + ySize)))
    {
      "".length();
      if (null == null) {
        break label87;
      }
    }
    label87:
    boolean lllllllllllllllllllIIIlIIllIlIll = llIlIIIllI[3];
    int lllllllllllllllllllIIIlIIllIlIII = llIlIIIllI[10];
    if (lIlIIlllIIlI(lllllllllllllllllllIIIlIIllIllll)) {
      lllllllllllllllllllIIIlIIllIlIII = slotNumber;
    }
    if (lIlIIllIllll(lllllllllllllllllllIIIlIIllIlIll)) {
      lllllllllllllllllllIIIlIIllIlIII = llIlIIIllI[11];
    }
    if ((lIlIIllIllll(doubleClick)) && (lIlIIlllIIlI(lllllllllllllllllllIIIlIIllIllll)) && (lIlIIlllIlII(lllllllllllllllllllIIIlIIlllIIIl)) && (lIlIIllIllll(inventorySlots.canMergeSlot(null, lllllllllllllllllllIIIlIIllIllll))))
    {
      if (lIlIIllIllll(isShiftKeyDown()))
      {
        if ((lIlIIlllIIlI(lllllllllllllllllllIIIlIIllIllll)) && (lIlIIlllIIlI(inventory)) && (lIlIIlllIIlI(shiftClickedSlot)))
        {
          lllllllllllllllllllIIIlIIlIIIlll = inventorySlots.inventorySlots.iterator();
          "".length();
          if ("   ".length() < " ".length()) {
            return;
          }
          while (!lIlIIlllIlII(lllllllllllllllllllIIIlIIlIIIlll.hasNext()))
          {
            Slot lllllllllllllllllllIIIlIIllIIllI = (Slot)lllllllllllllllllllIIIlIIlIIIlll.next();
            if ((lIlIIlllIIlI(lllllllllllllllllllIIIlIIllIIllI)) && (lIlIIllIllll(lllllllllllllllllllIIIlIIllIIllI.canTakeStack(mc.thePlayer))) && (lIlIIllIllll(lllllllllllllllllllIIIlIIllIIllI.getHasStack())) && (lIlIIlllIllI(inventory, inventory)) && (lIlIIllIllll(Container.canAddItemToSlot(lllllllllllllllllllIIIlIIllIIllI, shiftClickedSlot, llIlIIIllI[3])))) {
              lllllllllllllllllllIIIlIIlIllllI.handleMouseClick(lllllllllllllllllllIIIlIIllIIllI, slotNumber, lllllllllllllllllllIIIlIIlllIIIl, llIlIIIllI[3]);
            }
          }
          "".length();
          if (((0xE2 ^ 0x8C ^ 0x16 ^ 0x27) & (0x8E ^ 0x9E ^ 0xEC ^ 0xA3 ^ -" ".length())) == 0) {}
        }
      }
      else {
        lllllllllllllllllllIIIlIIlIllllI.handleMouseClick(lllllllllllllllllllIIIlIIllIllll, lllllllllllllllllllIIIlIIllIlIII, lllllllllllllllllllIIIlIIlllIIIl, llIlIIIllI[16]);
      }
      doubleClick = llIlIIIllI[0];
      lastClickTime = 0L;
      "".length();
      if (-" ".length() <= 0) {}
    }
    else
    {
      if ((lIlIIllIllll(dragSplitting)) && (lIlIIllllIlI(dragSplittingButton, lllllllllllllllllllIIIlIIlllIIIl)))
      {
        dragSplitting = llIlIIIllI[0];
        dragSplittingSlots.clear();
        ignoreMouseUp = llIlIIIllI[3];
        return;
      }
      if (lIlIIllIllll(ignoreMouseUp))
      {
        ignoreMouseUp = llIlIIIllI[0];
        return;
      }
      if ((lIlIIlllIIlI(clickedSlot)) && (lIlIIllIllll(mc.gameSettings.touchscreen)))
      {
        if ((!lIlIIllIllll(lllllllllllllllllllIIIlIIlllIIIl)) || (lIlIIlllIlll(lllllllllllllllllllIIIlIIlllIIIl, llIlIIIllI[3])))
        {
          if ((lIlIIlllIIIl(draggedStack)) && (lIlIIlllllIl(lllllllllllllllllllIIIlIIllIllll, clickedSlot))) {
            draggedStack = clickedSlot.getStack();
          }
          boolean lllllllllllllllllllIIIlIIllIIlII = Container.canAddItemToSlot(lllllllllllllllllllIIIlIIllIllll, draggedStack, llIlIIIllI[0]);
          if ((lIlIIllllIlI(lllllllllllllllllllIIIlIIllIlIII, llIlIIIllI[10])) && (lIlIIlllIIlI(draggedStack)) && (lIlIIllIllll(lllllllllllllllllllIIIlIIllIIlII)))
          {
            lllllllllllllllllllIIIlIIlIllllI.handleMouseClick(clickedSlot, clickedSlot.slotNumber, lllllllllllllllllllIIIlIIlllIIIl, llIlIIIllI[0]);
            lllllllllllllllllllIIIlIIlIllllI.handleMouseClick(lllllllllllllllllllIIIlIIllIllll, lllllllllllllllllllIIIlIIllIlIII, llIlIIIllI[0], llIlIIIllI[0]);
            if (lIlIIlllIIlI(mc.thePlayer.inventory.getItemStack()))
            {
              lllllllllllllllllllIIIlIIlIllllI.handleMouseClick(clickedSlot, clickedSlot.slotNumber, lllllllllllllllllllIIIlIIlllIIIl, llIlIIIllI[0]);
              touchUpX = (lllllllllllllllllllIIIlIIlIlllIl - lllllllllllllllllllIIIlIIllIlllI);
              touchUpY = (lllllllllllllllllllIIIlIIlllIIlI - lllllllllllllllllllIIIlIIllIllII);
              returningStackDestSlot = clickedSlot;
              returningStack = draggedStack;
              returningStackTime = Minecraft.getSystemTime();
              "".length();
              if (((0x3D ^ 0x22 ^ 0x54 ^ 0x0) & (0x7D ^ 0x63 ^ 0xF4 ^ 0xA1 ^ -" ".length())) < (0x25 ^ 0x59 ^ 0x1C ^ 0x64)) {}
            }
            else
            {
              returningStack = null;
              "".length();
              if ((("   ".length() ^ 0x20 ^ 0x61) & ('Ì' + 76 - 204 + 161 ^ 88 + '¬' - 106 + 21 ^ -" ".length())) == 0) {}
            }
          }
          else if (lIlIIlllIIlI(draggedStack))
          {
            touchUpX = (lllllllllllllllllllIIIlIIlIlllIl - lllllllllllllllllllIIIlIIllIlllI);
            touchUpY = (lllllllllllllllllllIIIlIIlllIIlI - lllllllllllllllllllIIIlIIllIllII);
            returningStackDestSlot = clickedSlot;
            returningStack = draggedStack;
            returningStackTime = Minecraft.getSystemTime();
          }
          draggedStack = null;
          clickedSlot = null;
          "".length();
          if ((0xA4 ^ 0xA0) >= "   ".length()) {}
        }
      }
      else if ((lIlIIllIllll(dragSplitting)) && (lIlIIlllIlII(dragSplittingSlots.isEmpty())))
      {
        lllllllllllllllllllIIIlIIlIllllI.handleMouseClick(null, llIlIIIllI[11], Container.func_94534_d(llIlIIIllI[0], dragSplittingLimit), llIlIIIllI[17]);
        lllllllllllllllllllIIIlIIlIIIlll = dragSplittingSlots.iterator();
        "".length();
        if (" ".length() >= "   ".length()) {
          return;
        }
        while (!lIlIIlllIlII(lllllllllllllllllllIIIlIIlIIIlll.hasNext()))
        {
          Slot lllllllllllllllllllIIIlIIllIIIlI = (Slot)lllllllllllllllllllIIIlIIlIIIlll.next();
          lllllllllllllllllllIIIlIIlIllllI.handleMouseClick(lllllllllllllllllllIIIlIIllIIIlI, slotNumber, Container.func_94534_d(llIlIIIllI[3], dragSplittingLimit), llIlIIIllI[17]);
        }
        lllllllllllllllllllIIIlIIlIllllI.handleMouseClick(null, llIlIIIllI[11], Container.func_94534_d(llIlIIIllI[4], dragSplittingLimit), llIlIIIllI[17]);
        "".length();
        if (" ".length() != ((0x3F ^ 0x61) & (0x68 ^ 0x36 ^ 0xFFFFFFFF))) {}
      }
      else if (lIlIIlllIIlI(mc.thePlayer.inventory.getItemStack()))
      {
        if (lIlIIlllIlll(lllllllllllllllllllIIIlIIlllIIIl, mc.gameSettings.keyBindPickBlock.getKeyCode() + llIlIIIllI[9]))
        {
          lllllllllllllllllllIIIlIIlIllllI.handleMouseClick(lllllllllllllllllllIIIlIIllIllll, lllllllllllllllllllIIIlIIllIlIII, lllllllllllllllllllIIIlIIlllIIIl, llIlIIIllI[12]);
          "".length();
          if ("   ".length() == "   ".length()) {}
        }
        else
        {
          if ((lIlIIllllIlI(lllllllllllllllllllIIIlIIllIlIII, llIlIIIllI[11])) && ((!lIlIIlllIlII(Keyboard.isKeyDown(llIlIIIllI[13]))) || (lIlIIllIllll(Keyboard.isKeyDown(llIlIIIllI[14])))))
          {
            "".length();
            if (((0x13 ^ 0x51) & (0x29 ^ 0x6B ^ 0xFFFFFFFF)) == 0) {
              break label1308;
            }
          }
          label1308:
          boolean lllllllllllllllllllIIIlIIllIIIII = llIlIIIllI[0];
          if (lIlIIllIllll(lllllllllllllllllllIIIlIIllIIIII))
          {
            if ((lIlIIlllIIlI(lllllllllllllllllllIIIlIIllIllll)) && (lIlIIllIllll(lllllllllllllllllllIIIlIIllIllll.getHasStack())))
            {
              "".length();
              if (((0x63 ^ 0x78 ^ 0xAE ^ 0xAA) & (0xB8 ^ 0x83 ^ 0x7E ^ 0x5A ^ -" ".length())) >= 0) {
                break label1388;
              }
            }
            label1388:
            getStackshiftClickedSlot = null;
          }
          if (lIlIIllIllll(lllllllllllllllllllIIIlIIllIIIII))
          {
            "".length();
            if (((0x30 ^ 0x3) & (0x56 ^ 0x65 ^ 0xFFFFFFFF)) == 0) {
              break label1437;
            }
          }
          label1437:
          lllllllllllllllllllIIIlIIllIllll.handleMouseClick(lllllllllllllllllllIIIlIIllIlIII, lllllllllllllllllllIIIlIIlllIIIl, llIlIIIllI[3], llIlIIIllI[0]);
        }
      }
    }
    if (lIlIIlllIIIl(mc.thePlayer.inventory.getItemStack())) {
      lastClickTime = 0L;
    }
    dragSplitting = llIlIIIllI[0];
  }
  
  private static int lIlIIlllllII(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  private static boolean lIlIIlllIlIl(int ???)
  {
    short lllllllllllllllllllIIIIllIlIlIlI;
    return ??? >= 0;
  }
  
  private static boolean lIlIIlllIIlI(Object ???)
  {
    int lllllllllllllllllllIIIIllIllIllI;
    return ??? != null;
  }
  
  private static boolean lIlIIlllIIII(int ???, int arg1)
  {
    int i;
    long lllllllllllllllllllIIIIlllIIIlII;
    return ??? >= i;
  }
  
  private static boolean lIlIIlllIIIl(Object ???)
  {
    long lllllllllllllllllllIIIIllIllIIII;
    return ??? == null;
  }
  
  private void updateDragSplitting()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ItemStack lllllllllllllllllllIIIlIllIllIII = mc.thePlayer.inventory.getItemStack();
    if ((lIlIIlllIIlI(lllllllllllllllllllIIIlIllIllIII)) && (lIlIIllIllll(dragSplitting)))
    {
      dragSplittingRemnant = stackSize;
      lllllllllllllllllllIIIlIllIlIIIl = dragSplittingSlots.iterator();
      "".length();
      if (((0x7C ^ 0x33) & (0x16 ^ 0x59 ^ 0xFFFFFFFF)) >= "  ".length()) {
        return;
      }
      label131:
      while (!lIlIIlllIlII(lllllllllllllllllllIIIlIllIlIIIl.hasNext()))
      {
        Slot lllllllllllllllllllIIIlIllIlIlll = (Slot)lllllllllllllllllllIIIlIllIlIIIl.next();
        ItemStack lllllllllllllllllllIIIlIllIlIllI = lllllllllllllllllllIIIlIllIllIII.copy();
        if (lIlIIlllIIIl(lllllllllllllllllllIIIlIllIlIlll.getStack()))
        {
          "".length();
          if ((0x56 ^ 0x53) > 0) {
            break label131;
          }
        }
        int lllllllllllllllllllIIIlIllIlIlIl = getStackstackSize;
        Container.computeStackSize(dragSplittingSlots, dragSplittingLimit, lllllllllllllllllllIIIlIllIlIllI, lllllllllllllllllllIIIlIllIlIlIl);
        if (lIlIIlllIIll(stackSize, lllllllllllllllllllIIIlIllIlIllI.getMaxStackSize())) {
          stackSize = lllllllllllllllllllIIIlIllIlIllI.getMaxStackSize();
        }
        if (lIlIIlllIIll(stackSize, lllllllllllllllllllIIIlIllIlIlll.getItemStackLimit(lllllllllllllllllllIIIlIllIlIllI))) {
          stackSize = lllllllllllllllllllIIIlIllIlIlll.getItemStackLimit(lllllllllllllllllllIIIlIllIlIllI);
        }
        dragSplittingRemnant -= stackSize - lllllllllllllllllllIIIlIllIlIlIl;
      }
    }
  }
  
  private static boolean lIlIIlllIIll(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllllllIIIIllIllllII;
    return ??? > i;
  }
  
  protected void mouseClickMove(int lllllllllllllllllllIIIlIlIIlIIII, int lllllllllllllllllllIIIlIlIIIIlll, int lllllllllllllllllllIIIlIlIIIlllI, long lllllllllllllllllllIIIlIlIIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Slot lllllllllllllllllllIIIlIlIIIllII = lllllllllllllllllllIIIlIlIIlIIIl.getSlotAtPosition(lllllllllllllllllllIIIlIlIIlIIII, lllllllllllllllllllIIIlIlIIIllll);
    ItemStack lllllllllllllllllllIIIlIlIIIlIll = mc.thePlayer.inventory.getItemStack();
    if ((lIlIIlllIIlI(clickedSlot)) && (lIlIIllIllll(mc.gameSettings.touchscreen)))
    {
      if ((!lIlIIllIllll(lllllllllllllllllllIIIlIlIIIlllI)) || (lIlIIlllIlll(lllllllllllllllllllIIIlIlIIIlllI, llIlIIIllI[3]))) {
        if (lIlIIlllIIIl(draggedStack))
        {
          if ((lIlIIlllllIl(lllllllllllllllllllIIIlIlIIIllII, clickedSlot)) && (lIlIIlllIIlI(clickedSlot.getStack())))
          {
            draggedStack = clickedSlot.getStack().copy();
            "".length();
            if ("  ".length() <= (0x9B ^ 0xB4 ^ 0xA4 ^ 0x8F)) {}
          }
        }
        else if ((lIlIIlllIIll(draggedStack.stackSize, llIlIIIllI[3])) && (lIlIIlllIIlI(lllllllllllllllllllIIIlIlIIIllII)) && (lIlIIllIllll(Container.canAddItemToSlot(lllllllllllllllllllIIIlIlIIIllII, draggedStack, llIlIIIllI[0]))))
        {
          long lllllllllllllllllllIIIlIlIIIlIlI = Minecraft.getSystemTime();
          if (lIlIIlllIllI(currentDragTargetSlot, lllllllllllllllllllIIIlIlIIIllII))
          {
            if (lIlIIllllllI(lIlIIlllllII(lllllllllllllllllllIIIlIlIIIlIlI - dragItemDropDelay, 500L)))
            {
              lllllllllllllllllllIIIlIlIIlIIIl.handleMouseClick(clickedSlot, clickedSlot.slotNumber, llIlIIIllI[0], llIlIIIllI[0]);
              lllllllllllllllllllIIIlIlIIlIIIl.handleMouseClick(lllllllllllllllllllIIIlIlIIIllII, slotNumber, llIlIIIllI[3], llIlIIIllI[0]);
              lllllllllllllllllllIIIlIlIIlIIIl.handleMouseClick(clickedSlot, clickedSlot.slotNumber, llIlIIIllI[0], llIlIIIllI[0]);
              dragItemDropDelay = (lllllllllllllllllllIIIlIlIIIlIlI + 750L);
              draggedStack.stackSize -= llIlIIIllI[3];
              "".length();
              if (-" ".length() <= 0) {}
            }
          }
          else
          {
            currentDragTargetSlot = lllllllllllllllllllIIIlIlIIIllII;
            dragItemDropDelay = lllllllllllllllllllIIIlIlIIIlIlI;
            "".length();
            if (null == null) {}
          }
        }
      }
    }
    else if ((lIlIIllIllll(dragSplitting)) && (lIlIIlllIIlI(lllllllllllllllllllIIIlIlIIIllII)) && (lIlIIlllIIlI(lllllllllllllllllllIIIlIlIIIlIll)) && (lIlIIlllIIll(stackSize, dragSplittingSlots.size())) && (lIlIIllIllll(Container.canAddItemToSlot(lllllllllllllllllllIIIlIlIIIllII, lllllllllllllllllllIIIlIlIIIlIll, llIlIIIllI[3]))) && (lIlIIllIllll(lllllllllllllllllllIIIlIlIIIllII.isItemValid(lllllllllllllllllllIIIlIlIIIlIll))) && (lIlIIllIllll(inventorySlots.canDragIntoSlot(lllllllllllllllllllIIIlIlIIIllII))))
    {
      "".length();
      lllllllllllllllllllIIIlIlIIlIIIl.updateDragSplitting();
    }
  }
  
  public GuiContainer(Container lllllllllllllllllllIIIllIlllIIIl)
  {
    inventorySlots = lllllllllllllllllllIIIllIlllIIIl;
    ignoreMouseUp = llIlIIIllI[3];
  }
  
  protected void keyTyped(char lllllllllllllllllllIIIlIIIIIIlII, int lllllllllllllllllllIIIlIIIIIIIll)
    throws IOException
  {
    ;
    ;
    if ((!lIlIIllllIlI(lllllllllllllllllllIIIlIIIIIIIll, llIlIIIllI[3])) || (lIlIIlllIlll(lllllllllllllllllllIIIlIIIIIIIll, mc.gameSettings.keyBindInventory.getKeyCode()))) {
      mc.thePlayer.closeScreen();
    }
    "".length();
    if ((lIlIIlllIIlI(theSlot)) && (lIlIIllIllll(theSlot.getHasStack()))) {
      if (lIlIIlllIlll(lllllllllllllllllllIIIlIIIIIIIll, mc.gameSettings.keyBindPickBlock.getKeyCode()))
      {
        lllllllllllllllllllIIIlIIIIIIIlI.handleMouseClick(theSlot, theSlot.slotNumber, llIlIIIllI[0], llIlIIIllI[12]);
        "".length();
        if (-" ".length() <= (0x45 ^ 0x41)) {}
      }
      else if (lIlIIlllIlll(lllllllllllllllllllIIIlIIIIIIIll, mc.gameSettings.keyBindDrop.getKeyCode()))
      {
        if (lIlIIllIllll(isCtrlKeyDown()))
        {
          "".length();
          if (-(0x9D ^ 0x99 ^ (0xA ^ 0x1) & (0x54 ^ 0x5F ^ 0xFFFFFFFF)) <= 0) {
            break label225;
          }
        }
        label225:
        theSlot.handleMouseClick(theSlot.slotNumber, llIlIIIllI[3], llIlIIIllI[0], llIlIIIllI[15]);
      }
    }
  }
  
  public boolean doesGuiPauseGame()
  {
    return llIlIIIllI[0];
  }
  
  private static void lIlIIllIllIl()
  {
    llIlIIIllI = new int[19];
    llIlIIIllI[0] = ((0xA4 ^ 0xB8) & (0x93 ^ 0x8F ^ 0xFFFFFFFF));
    llIlIIIllI[1] = (120 + 88 - 56 + 3 + (0x5D ^ 0x13) - (122 + 119 - 126 + 105) + (81 + '' - 187 + 136));
    llIlIIIllI[2] = ('' + '' - 229 + 104);
    llIlIIIllI[3] = " ".length();
    llIlIIIllI[4] = "  ".length();
    llIlIIIllI[5] = (29 + 'à' - 225 + 212);
    llIlIIIllI[6] = (16 + 6 - -38 + 71 ^ 93 + 93 - 85 + 46);
    llIlIIIllI[7] = (-(-(0xFEB7 & 0x7FFF) & 0xFFFFFFF7 & 0x7F007EBF));
    llIlIIIllI[8] = (70 + 119 - 171 + 125 ^ 101 + 92 - 174 + 116);
    llIlIIIllI[9] = (0x65 ^ 0x3E ^ 0xBD ^ 0x82);
    llIlIIIllI[10] = (-" ".length());
    llIlIIIllI[11] = (-(-(0xE0BB & 0x5F4D) & 0xEFEF & 0x53FF));
    llIlIIIllI[12] = "   ".length();
    llIlIIIllI[13] = (0x42 ^ 0x6A ^ "  ".length());
    llIlIIIllI[14] = (0x0 ^ 0x36);
    llIlIIIllI[15] = (0x42 ^ 0x46);
    llIlIIIllI[16] = (0xB5 ^ 0xB3);
    llIlIIIllI[17] = (0xC ^ 0x9);
    llIlIIIllI[18] = (0xCB ^ 0xC2);
  }
  
  private static boolean lIlIIlllllIl(Object ???, Object arg1)
  {
    Object localObject;
    long lllllllllllllllllllIIIIllIlllIII;
    return ??? != localObject;
  }
  
  protected abstract void drawGuiContainerBackgroundLayer(float paramFloat, int paramInt1, int paramInt2);
  
  private static String lIlIIllIIIll(String lllllllllllllllllllIIIIllllIIIIl, String lllllllllllllllllllIIIIllllIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIIIIllllIIIIl = new String(Base64.getDecoder().decode(lllllllllllllllllllIIIIllllIIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllllIIIIllllIIlII = new StringBuilder();
    char[] lllllllllllllllllllIIIIllllIIIll = lllllllllllllllllllIIIIllllIIIII.toCharArray();
    int lllllllllllllllllllIIIIllllIIIlI = llIlIIIllI[0];
    int lllllllllllllllllllIIIIlllIlllII = lllllllllllllllllllIIIIllllIIIIl.toCharArray();
    boolean lllllllllllllllllllIIIIlllIllIll = lllllllllllllllllllIIIIlllIlllII.length;
    char lllllllllllllllllllIIIIlllIllIlI = llIlIIIllI[0];
    while (lIlIIllllIll(lllllllllllllllllllIIIIlllIllIlI, lllllllllllllllllllIIIIlllIllIll))
    {
      char lllllllllllllllllllIIIIllllIIlll = lllllllllllllllllllIIIIlllIlllII[lllllllllllllllllllIIIIlllIllIlI];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllllIIIIllllIIlII);
  }
  
  public void onGuiClosed()
  {
    ;
    if (lIlIIlllIIlI(mc.thePlayer)) {
      inventorySlots.onContainerClosed(mc.thePlayer);
    }
  }
  
  private void drawSlot(Slot lllllllllllllllllllIIIlIlllIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllllllIIIlIllllIIll = xDisplayPosition;
    int lllllllllllllllllllIIIlIllllIIlI = yDisplayPosition;
    ItemStack lllllllllllllllllllIIIlIllllIIIl = lllllllllllllllllllIIIlIlllIlIIl.getStack();
    boolean lllllllllllllllllllIIIlIllllIIII = llIlIIIllI[0];
    if ((lIlIIlllIllI(lllllllllllllllllllIIIlIlllIlIIl, clickedSlot)) && (lIlIIlllIIlI(draggedStack)) && (lIlIIlllIlII(isRightMouseClick)))
    {
      "".length();
      if ("   ".length() != ((112 + 28 - 42 + 31 ^ 51 + 7 - -99 + 18) & (0x7F ^ 0x6F ^ 0x98 ^ 0xA6 ^ -" ".length()))) {
        break label123;
      }
    }
    label123:
    boolean lllllllllllllllllllIIIlIlllIllll = llIlIIIllI[0];
    ItemStack lllllllllllllllllllIIIlIlllIlllI = mc.thePlayer.inventory.getItemStack();
    String lllllllllllllllllllIIIlIlllIllIl = null;
    if ((lIlIIlllIllI(lllllllllllllllllllIIIlIlllIlIIl, clickedSlot)) && (lIlIIlllIIlI(draggedStack)) && (lIlIIllIllll(isRightMouseClick)) && (lIlIIlllIIlI(lllllllllllllllllllIIIlIllllIIIl)))
    {
      lllllllllllllllllllIIIlIllllIIIl = lllllllllllllllllllIIIlIllllIIIl.copy();
      stackSize /= llIlIIIllI[4];
      "".length();
      if ((0x9A ^ 0xC5 ^ 0xCF ^ 0x94) >= "   ".length()) {}
    }
    else if ((lIlIIllIllll(dragSplitting)) && (lIlIIllIllll(dragSplittingSlots.contains(lllllllllllllllllllIIIlIlllIlIIl))) && (lIlIIlllIIlI(lllllllllllllllllllIIIlIlllIlllI)))
    {
      if (lIlIIlllIlll(dragSplittingSlots.size(), llIlIIIllI[3])) {
        return;
      }
      if ((lIlIIllIllll(Container.canAddItemToSlot(lllllllllllllllllllIIIlIlllIlIIl, lllllllllllllllllllIIIlIlllIlllI, llIlIIIllI[3]))) && (lIlIIllIllll(inventorySlots.canDragIntoSlot(lllllllllllllllllllIIIlIlllIlIIl))))
      {
        lllllllllllllllllllIIIlIllllIIIl = lllllllllllllllllllIIIlIlllIlllI.copy();
        lllllllllllllllllllIIIlIllllIIII = llIlIIIllI[3];
        if (lIlIIlllIIIl(lllllllllllllllllllIIIlIlllIlIIl.getStack()))
        {
          "".length();
          if (((0x23 ^ 0xB) & (0x80 ^ 0xA8 ^ 0xFFFFFFFF)) <= 0) {
            break label391;
          }
        }
        label391:
        Container.computeStackSize(dragSplittingLimit, lllllllllllllllllllIIIlIllllIIIl, llIlIIIllI[0], getStackstackSize);
        if (lIlIIlllIIll(stackSize, lllllllllllllllllllIIIlIllllIIIl.getMaxStackSize()))
        {
          lllllllllllllllllllIIIlIlllIllIl = String.valueOf(new StringBuilder().append(EnumChatFormatting.YELLOW).append(lllllllllllllllllllIIIlIllllIIIl.getMaxStackSize()));
          stackSize = lllllllllllllllllllIIIlIllllIIIl.getMaxStackSize();
        }
        if (lIlIIlllIIll(stackSize, lllllllllllllllllllIIIlIlllIlIIl.getItemStackLimit(lllllllllllllllllllIIIlIllllIIIl)))
        {
          lllllllllllllllllllIIIlIlllIllIl = String.valueOf(new StringBuilder().append(EnumChatFormatting.YELLOW).append(lllllllllllllllllllIIIlIlllIlIIl.getItemStackLimit(lllllllllllllllllllIIIlIllllIIIl)));
          stackSize = lllllllllllllllllllIIIlIlllIlIIl.getItemStackLimit(lllllllllllllllllllIIIlIllllIIIl);
          "".length();
          if ("  ".length() < "   ".length()) {}
        }
      }
      else
      {
        "".length();
        lllllllllllllllllllIIIlIlllIlIlI.updateDragSplitting();
      }
    }
    zLevel = 100.0F;
    itemRender.zLevel = 100.0F;
    if (lIlIIlllIIIl(lllllllllllllllllllIIIlIllllIIIl))
    {
      String lllllllllllllllllllIIIlIlllIllII = lllllllllllllllllllIIIlIlllIlIIl.getSlotTexture();
      if (lIlIIlllIIlI(lllllllllllllllllllIIIlIlllIllII))
      {
        TextureAtlasSprite lllllllllllllllllllIIIlIlllIlIll = mc.getTextureMapBlocks().getAtlasSprite(lllllllllllllllllllIIIlIlllIllII);
        GlStateManager.disableLighting();
        mc.getTextureManager().bindTexture(TextureMap.locationBlocksTexture);
        lllllllllllllllllllIIIlIlllIlIlI.drawTexturedModalRect(lllllllllllllllllllIIIlIllllIIll, lllllllllllllllllllIIIlIllllIIlI, lllllllllllllllllllIIIlIlllIlIll, llIlIIIllI[6], llIlIIIllI[6]);
        GlStateManager.enableLighting();
        lllllllllllllllllllIIIlIlllIllll = llIlIIIllI[3];
      }
    }
    if (lIlIIlllIlII(lllllllllllllllllllIIIlIlllIllll))
    {
      if (lIlIIllIllll(lllllllllllllllllllIIIlIllllIIII)) {
        drawRect(lllllllllllllllllllIIIlIllllIIll, lllllllllllllllllllIIIlIllllIIlI, lllllllllllllllllllIIIlIllllIIll + llIlIIIllI[6], lllllllllllllllllllIIIlIllllIIlI + llIlIIIllI[6], llIlIIIllI[7]);
      }
      GlStateManager.enableDepth();
      itemRender.renderItemAndEffectIntoGUI(lllllllllllllllllllIIIlIllllIIIl, lllllllllllllllllllIIIlIllllIIll, lllllllllllllllllllIIIlIllllIIlI);
      itemRender.renderItemOverlayIntoGUI(fontRendererObj, lllllllllllllllllllIIIlIllllIIIl, lllllllllllllllllllIIIlIllllIIll, lllllllllllllllllllIIIlIllllIIlI, lllllllllllllllllllIIIlIlllIllIl);
    }
    itemRender.zLevel = 0.0F;
    zLevel = 0.0F;
  }
  
  private static boolean lIlIIllllIll(int ???, int arg1)
  {
    int i;
    int lllllllllllllllllllIIIIlllIIIIII;
    return ??? < i;
  }
  
  public void drawScreen(int lllllllllllllllllllIIIllIlIlllIl, int lllllllllllllllllllIIIllIlIIIlIl, float lllllllllllllllllllIIIllIlIIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIIIllIlIllllI.drawDefaultBackground();
    int lllllllllllllllllllIIIllIlIllIlI = guiLeft;
    int lllllllllllllllllllIIIllIlIllIIl = guiTop;
    lllllllllllllllllllIIIllIlIllllI.drawGuiContainerBackgroundLayer(lllllllllllllllllllIIIllIlIIIlII, lllllllllllllllllllIIIllIlIlllIl, lllllllllllllllllllIIIllIlIIIlIl);
    GlStateManager.disableRescaleNormal();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableLighting();
    GlStateManager.disableDepth();
    lllllllllllllllllllIIIllIlIllllI.drawScreen(lllllllllllllllllllIIIllIlIlllIl, lllllllllllllllllllIIIllIlIIIlIl, lllllllllllllllllllIIIllIlIIIlII);
    RenderHelper.enableGUIStandardItemLighting();
    GlStateManager.pushMatrix();
    GlStateManager.translate(lllllllllllllllllllIIIllIlIllIlI, lllllllllllllllllllIIIllIlIllIIl, 0.0F);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.enableRescaleNormal();
    theSlot = null;
    int lllllllllllllllllllIIIllIlIllIII = llIlIIIllI[5];
    int lllllllllllllllllllIIIllIlIlIlll = llIlIIIllI[5];
    OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, lllllllllllllllllllIIIllIlIllIII / 1.0F, lllllllllllllllllllIIIllIlIlIlll / 1.0F);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    int lllllllllllllllllllIIIllIlIlIllI = llIlIIIllI[0];
    "".length();
    if (((0x59 ^ 0x4C ^ 0x14 ^ 0xD) & (102 + 37 - -56 + 8 ^ 8 + 69 - -120 + 2 ^ -" ".length())) != 0) {
      return;
    }
    while (!lIlIIlllIIII(lllllllllllllllllllIIIllIlIlIllI, inventorySlots.inventorySlots.size()))
    {
      Slot lllllllllllllllllllIIIllIlIlIlIl = (Slot)inventorySlots.inventorySlots.get(lllllllllllllllllllIIIllIlIlIllI);
      lllllllllllllllllllIIIllIlIllllI.drawSlot(lllllllllllllllllllIIIllIlIlIlIl);
      if ((lIlIIllIllll(lllllllllllllllllllIIIllIlIllllI.isMouseOverSlot(lllllllllllllllllllIIIllIlIlIlIl, lllllllllllllllllllIIIllIlIlllIl, lllllllllllllllllllIIIllIlIIIlIl))) && (lIlIIllIllll(lllllllllllllllllllIIIllIlIlIlIl.canBeHovered())))
      {
        theSlot = lllllllllllllllllllIIIllIlIlIlIl;
        GlStateManager.disableLighting();
        GlStateManager.disableDepth();
        int lllllllllllllllllllIIIllIlIlIlII = xDisplayPosition;
        int lllllllllllllllllllIIIllIlIlIIll = yDisplayPosition;
        GlStateManager.colorMask(llIlIIIllI[3], llIlIIIllI[3], llIlIIIllI[3], llIlIIIllI[0]);
        lllllllllllllllllllIIIllIlIllllI.drawGradientRect(lllllllllllllllllllIIIllIlIlIlII, lllllllllllllllllllIIIllIlIlIIll, lllllllllllllllllllIIIllIlIlIlII + llIlIIIllI[6], lllllllllllllllllllIIIllIlIlIIll + llIlIIIllI[6], llIlIIIllI[7], llIlIIIllI[7]);
        GlStateManager.colorMask(llIlIIIllI[3], llIlIIIllI[3], llIlIIIllI[3], llIlIIIllI[3]);
        GlStateManager.enableLighting();
        GlStateManager.enableDepth();
      }
      lllllllllllllllllllIIIllIlIlIllI++;
    }
    RenderHelper.disableStandardItemLighting();
    lllllllllllllllllllIIIllIlIllllI.drawGuiContainerForegroundLayer(lllllllllllllllllllIIIllIlIlllIl, lllllllllllllllllllIIIllIlIIIlIl);
    RenderHelper.enableGUIStandardItemLighting();
    InventoryPlayer lllllllllllllllllllIIIllIlIlIIlI = mc.thePlayer.inventory;
    if (lIlIIlllIIIl(draggedStack))
    {
      "".length();
      if (-" ".length() != "  ".length()) {
        break label422;
      }
    }
    label422:
    ItemStack lllllllllllllllllllIIIllIlIlIIIl = draggedStack;
    if (lIlIIlllIIlI(lllllllllllllllllllIIIllIlIlIIIl))
    {
      int lllllllllllllllllllIIIllIlIlIIII = llIlIIIllI[8];
      if (lIlIIlllIIIl(draggedStack))
      {
        "".length();
        if ("  ".length() > -" ".length()) {
          break label484;
        }
      }
      label484:
      int lllllllllllllllllllIIIllIlIIllll = llIlIIIllI[6];
      String lllllllllllllllllllIIIllIlIIlllI = null;
      if ((lIlIIlllIIlI(draggedStack)) && (lIlIIllIllll(isRightMouseClick)))
      {
        lllllllllllllllllllIIIllIlIlIIIl = lllllllllllllllllllIIIllIlIlIIIl.copy();
        stackSize = MathHelper.ceiling_float_int(stackSize / 2.0F);
        "".length();
        if (null == null) {}
      }
      else if ((lIlIIllIllll(dragSplitting)) && (lIlIIlllIIll(dragSplittingSlots.size(), llIlIIIllI[3])))
      {
        lllllllllllllllllllIIIllIlIlIIIl = lllllllllllllllllllIIIllIlIlIIIl.copy();
        stackSize = dragSplittingRemnant;
        if (lIlIIlllIlII(stackSize)) {
          lllllllllllllllllllIIIllIlIIlllI = String.valueOf(new StringBuilder().append(EnumChatFormatting.YELLOW).append(llIlIIIlII[llIlIIIllI[3]]));
        }
      }
      lllllllllllllllllllIIIllIlIllllI.drawItemStack(lllllllllllllllllllIIIllIlIlIIIl, lllllllllllllllllllIIIllIlIlllIl - lllllllllllllllllllIIIllIlIllIlI - lllllllllllllllllllIIIllIlIlIIII, lllllllllllllllllllIIIllIlIIIlIl - lllllllllllllllllllIIIllIlIllIIl - lllllllllllllllllllIIIllIlIIllll, lllllllllllllllllllIIIllIlIIlllI);
    }
    if (lIlIIlllIIlI(returningStack))
    {
      float lllllllllllllllllllIIIllIlIIllIl = (float)(Minecraft.getSystemTime() - returningStackTime) / 100.0F;
      if (lIlIIlllIlIl(lIlIIllIlllI(lllllllllllllllllllIIIllIlIIllIl, 1.0F)))
      {
        lllllllllllllllllllIIIllIlIIllIl = 1.0F;
        returningStack = null;
      }
      int lllllllllllllllllllIIIllIlIIllII = returningStackDestSlot.xDisplayPosition - touchUpX;
      int lllllllllllllllllllIIIllIlIIlIll = returningStackDestSlot.yDisplayPosition - touchUpY;
      int lllllllllllllllllllIIIllIlIIlIlI = touchUpX + (int)(lllllllllllllllllllIIIllIlIIllII * lllllllllllllllllllIIIllIlIIllIl);
      int lllllllllllllllllllIIIllIlIIlIIl = touchUpY + (int)(lllllllllllllllllllIIIllIlIIlIll * lllllllllllllllllllIIIllIlIIllIl);
      lllllllllllllllllllIIIllIlIllllI.drawItemStack(returningStack, lllllllllllllllllllIIIllIlIIlIlI, lllllllllllllllllllIIIllIlIIlIIl, null);
    }
    GlStateManager.popMatrix();
    if ((lIlIIlllIIIl(lllllllllllllllllllIIIllIlIlIIlI.getItemStack())) && (lIlIIlllIIlI(theSlot)) && (lIlIIllIllll(theSlot.getHasStack())))
    {
      ItemStack lllllllllllllllllllIIIllIlIIlIII = theSlot.getStack();
      lllllllllllllllllllIIIllIlIllllI.renderToolTip(lllllllllllllllllllIIIllIlIIlIII, lllllllllllllllllllIIIllIlIlllIl, lllllllllllllllllllIIIllIlIIIlIl);
    }
    GlStateManager.enableLighting();
    GlStateManager.enableDepth();
    RenderHelper.enableStandardItemLighting();
  }
  
  protected boolean checkHotbarKeys(int lllllllllllllllllllIIIIlllllllII)
  {
    ;
    ;
    ;
    if ((lIlIIlllIIIl(mc.thePlayer.inventory.getItemStack())) && (lIlIIlllIIlI(theSlot)))
    {
      int lllllllllllllllllllIIIIllllllIll = llIlIIIllI[0];
      "".length();
      if ("   ".length() == 0) {
        return (0x5A ^ 0x7A ^ 0x3C ^ 0x3A) & (17 + 44 - 3 + 95 ^ 13 + 93 - 11 + 96 ^ -" ".length());
      }
      while (!lIlIIlllIIII(lllllllllllllllllllIIIIllllllIll, llIlIIIllI[18]))
      {
        if (lIlIIlllIlll(lllllllllllllllllllIIIIlllllllII, mc.gameSettings.keyBindsHotbar[lllllllllllllllllllIIIIllllllIll].getKeyCode()))
        {
          lllllllllllllllllllIIIIlllllllIl.handleMouseClick(theSlot, theSlot.slotNumber, lllllllllllllllllllIIIIllllllIll, llIlIIIllI[4]);
          return llIlIIIllI[3];
        }
        lllllllllllllllllllIIIIllllllIll++;
      }
    }
    return llIlIIIllI[0];
  }
  
  private static int lIlIIllIlllI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  protected void handleMouseClick(Slot lllllllllllllllllllIIIlIIIIlIIII, int lllllllllllllllllllIIIlIIIIIllll, int lllllllllllllllllllIIIlIIIIIlllI, int lllllllllllllllllllIIIlIIIIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIlIIlllIIlI(lllllllllllllllllllIIIlIIIIlIIII)) {
      lllllllllllllllllllIIIlIIIIIlIlI = slotNumber;
    }
    "".length();
  }
  
  public void updateScreen()
  {
    ;
    lllllllllllllllllllIIIIlllllIIIl.updateScreen();
    if ((!lIlIIllIllll(mc.thePlayer.isEntityAlive())) || (lIlIIllIllll(mc.thePlayer.isDead))) {
      mc.thePlayer.closeScreen();
    }
  }
  
  private boolean isMouseOverSlot(Slot lllllllllllllllllllIIIlIIIlllIll, int lllllllllllllllllllIIIlIIIllIlII, int lllllllllllllllllllIIIlIIIllIIll)
  {
    ;
    ;
    ;
    ;
    return lllllllllllllllllllIIIlIIIllIlll.isPointInRegion(xDisplayPosition, yDisplayPosition, llIlIIIllI[6], llIlIIIllI[6], lllllllllllllllllllIIIlIIIllIlII, lllllllllllllllllllIIIlIIIllIIll);
  }
  
  private static boolean lIlIIllIllll(int ???)
  {
    byte lllllllllllllllllllIIIIllIlIlllI;
    return ??? != 0;
  }
  
  private static boolean lIlIIlllIlII(int ???)
  {
    byte lllllllllllllllllllIIIIllIlIllII;
    return ??? == 0;
  }
  
  protected void mouseClicked(int lllllllllllllllllllIIIlIlIlIIlII, int lllllllllllllllllllIIIlIlIlIIIll, int lllllllllllllllllllIIIlIlIlIIIlI)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIIIlIlIllIIlI.mouseClicked(lllllllllllllllllllIIIlIlIlIIlII, lllllllllllllllllllIIIlIlIlIIIll, lllllllllllllllllllIIIlIlIlIIIlI);
    if (lIlIIlllIlll(lllllllllllllllllllIIIlIlIlIIIlI, mc.gameSettings.keyBindPickBlock.getKeyCode() + llIlIIIllI[9]))
    {
      "".length();
      if (-(0xC6 ^ 0xC2) <= 0) {
        break label62;
      }
    }
    label62:
    boolean lllllllllllllllllllIIIlIlIlIlllI = llIlIIIllI[0];
    Slot lllllllllllllllllllIIIlIlIlIllIl = lllllllllllllllllllIIIlIlIllIIlI.getSlotAtPosition(lllllllllllllllllllIIIlIlIlIIlII, lllllllllllllllllllIIIlIlIlIIIll);
    long lllllllllllllllllllIIIlIlIlIllII = Minecraft.getSystemTime();
    if ((lIlIIlllIllI(lastClickSlot, lllllllllllllllllllIIIlIlIlIllIl)) && (lIlIIllllIIl(lIlIIllllIII(lllllllllllllllllllIIIlIlIlIllII - lastClickTime, 250L))) && (lIlIIlllIlll(lastClickButton, lllllllllllllllllllIIIlIlIlIIIlI)))
    {
      "".length();
      if (-"   ".length() < 0) {
        break label146;
      }
    }
    label146:
    llIlIIIllI3doubleClick = llIlIIIllI[0];
    ignoreMouseUp = llIlIIIllI[0];
    if ((!lIlIIllIllll(lllllllllllllllllllIIIlIlIlIIIlI)) || (!lIlIIllllIlI(lllllllllllllllllllIIIlIlIlIIIlI, llIlIIIllI[3])) || (lIlIIllIllll(lllllllllllllllllllIIIlIlIlIlllI)))
    {
      int lllllllllllllllllllIIIlIlIlIlIll = guiLeft;
      int lllllllllllllllllllIIIlIlIlIlIlI = guiTop;
      if ((lIlIIlllIIII(lllllllllllllllllllIIIlIlIlIIlII, lllllllllllllllllllIIIlIlIlIlIll)) && (lIlIIlllIIII(lllllllllllllllllllIIIlIlIlIIIll, lllllllllllllllllllIIIlIlIlIlIlI)) && (lIlIIllllIll(lllllllllllllllllllIIIlIlIlIIlII, lllllllllllllllllllIIIlIlIlIlIll + xSize)) && (lIlIIllllIll(lllllllllllllllllllIIIlIlIlIIIll, lllllllllllllllllllIIIlIlIlIlIlI + ySize)))
      {
        "".length();
        if (-"   ".length() <= 0) {
          break label269;
        }
      }
      label269:
      boolean lllllllllllllllllllIIIlIlIlIlIIl = llIlIIIllI[3];
      int lllllllllllllllllllIIIlIlIlIlIII = llIlIIIllI[10];
      if (lIlIIlllIIlI(lllllllllllllllllllIIIlIlIlIllIl)) {
        lllllllllllllllllllIIIlIlIlIlIII = slotNumber;
      }
      if (lIlIIllIllll(lllllllllllllllllllIIIlIlIlIlIIl)) {
        lllllllllllllllllllIIIlIlIlIlIII = llIlIIIllI[11];
      }
      if ((lIlIIllIllll(mc.gameSettings.touchscreen)) && (lIlIIllIllll(lllllllllllllllllllIIIlIlIlIlIIl)) && (lIlIIlllIIIl(mc.thePlayer.inventory.getItemStack())))
      {
        mc.displayGuiScreen(null);
        return;
      }
      if (lIlIIllllIlI(lllllllllllllllllllIIIlIlIlIlIII, llIlIIIllI[10])) {
        if (lIlIIllIllll(mc.gameSettings.touchscreen))
        {
          if ((lIlIIlllIIlI(lllllllllllllllllllIIIlIlIlIllIl)) && (lIlIIllIllll(lllllllllllllllllllIIIlIlIlIllIl.getHasStack())))
          {
            clickedSlot = lllllllllllllllllllIIIlIlIlIllIl;
            draggedStack = null;
            if (lIlIIlllIlll(lllllllllllllllllllIIIlIlIlIIIlI, llIlIIIllI[3]))
            {
              "".length();
              if (((59 + 40 - -31 + 17 ^ '' + '' - 259 + 129) & ((0xFB ^ 0xB9) & (0x1B ^ 0x59 ^ 0xFFFFFFFF) ^ 0x8B ^ 0xBD ^ -" ".length())) <= "  ".length()) {
                break label519;
              }
            }
            label519:
            llIlIIIllI3isRightMouseClick = llIlIIIllI[0];
            "".length();
            if ("   ".length() > -" ".length()) {}
          }
          else
          {
            clickedSlot = null;
            "".length();
            if (" ".length() >= " ".length()) {}
          }
        }
        else if (lIlIIlllIlII(dragSplitting)) {
          if (lIlIIlllIIIl(mc.thePlayer.inventory.getItemStack()))
          {
            if (lIlIIlllIlll(lllllllllllllllllllIIIlIlIlIIIlI, mc.gameSettings.keyBindPickBlock.getKeyCode() + llIlIIIllI[9]))
            {
              lllllllllllllllllllIIIlIlIllIIlI.handleMouseClick(lllllllllllllllllllIIIlIlIlIllIl, lllllllllllllllllllIIIlIlIlIlIII, lllllllllllllllllllIIIlIlIlIIIlI, llIlIIIllI[12]);
              "".length();
              if ("   ".length() != 0) {}
            }
            else
            {
              if ((lIlIIllllIlI(lllllllllllllllllllIIIlIlIlIlIII, llIlIIIllI[11])) && ((!lIlIIlllIlII(Keyboard.isKeyDown(llIlIIIllI[13]))) || (lIlIIllIllll(Keyboard.isKeyDown(llIlIIIllI[14])))))
              {
                "".length();
                if ("  ".length() > ((0xF2 ^ 0xAF) & (0x73 ^ 0x2E ^ 0xFFFFFFFF))) {
                  break label739;
                }
              }
              label739:
              boolean lllllllllllllllllllIIIlIlIlIIlll = llIlIIIllI[0];
              int lllllllllllllllllllIIIlIlIlIIllI = llIlIIIllI[0];
              if (lIlIIllIllll(lllllllllllllllllllIIIlIlIlIIlll))
              {
                if ((lIlIIlllIIlI(lllllllllllllllllllIIIlIlIlIllIl)) && (lIlIIllIllll(lllllllllllllllllllIIIlIlIlIllIl.getHasStack())))
                {
                  "".length();
                  if ("   ".length() > ((0x85 ^ 0x83) & (0xB4 ^ 0xB2 ^ 0xFFFFFFFF))) {
                    break label814;
                  }
                }
                label814:
                getStackshiftClickedSlot = null;
                lllllllllllllllllllIIIlIlIlIIllI = llIlIIIllI[3];
                "".length();
                if (-(68 + 81 - 16 + 6 ^ 106 + 91 - 77 + 23) <= 0) {}
              }
              else if (lIlIIlllIlll(lllllllllllllllllllIIIlIlIlIlIII, llIlIIIllI[11]))
              {
                lllllllllllllllllllIIIlIlIlIIllI = llIlIIIllI[15];
              }
              lllllllllllllllllllIIIlIlIllIIlI.handleMouseClick(lllllllllllllllllllIIIlIlIlIllIl, lllllllllllllllllllIIIlIlIlIlIII, lllllllllllllllllllIIIlIlIlIIIlI, lllllllllllllllllllIIIlIlIlIIllI);
            }
            ignoreMouseUp = llIlIIIllI[3];
            "".length();
            if ("   ".length() != 0) {}
          }
          else
          {
            dragSplitting = llIlIIIllI[3];
            dragSplittingButton = lllllllllllllllllllIIIlIlIlIIIlI;
            dragSplittingSlots.clear();
            if (lIlIIlllIlII(lllllllllllllllllllIIIlIlIlIIIlI))
            {
              dragSplittingLimit = llIlIIIllI[0];
              "".length();
              if ("   ".length() >= 0) {}
            }
            else if (lIlIIlllIlll(lllllllllllllllllllIIIlIlIlIIIlI, llIlIIIllI[3]))
            {
              dragSplittingLimit = llIlIIIllI[3];
              "".length();
              if ("  ".length() != 0) {}
            }
            else if (lIlIIlllIlll(lllllllllllllllllllIIIlIlIlIIIlI, mc.gameSettings.keyBindPickBlock.getKeyCode() + llIlIIIllI[9]))
            {
              dragSplittingLimit = llIlIIIllI[4];
            }
          }
        }
      }
    }
    lastClickSlot = lllllllllllllllllllIIIlIlIlIllIl;
    lastClickTime = lllllllllllllllllllIIIlIlIlIllII;
    lastClickButton = lllllllllllllllllllIIIlIlIlIIIlI;
  }
  
  static
  {
    lIlIIllIllIl();
    lIlIIllIIlIl();
  }
  
  protected boolean isPointInRegion(int lllllllllllllllllllIIIlIIIlIIlll, int lllllllllllllllllllIIIlIIIlIIllI, int lllllllllllllllllllIIIlIIIIlllII, int lllllllllllllllllllIIIlIIIlIIlII, int lllllllllllllllllllIIIlIIIlIIIll, int lllllllllllllllllllIIIlIIIlIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllllllIIIlIIIlIIIIl = guiLeft;
    int lllllllllllllllllllIIIlIIIlIIIII = guiTop;
    lllllllllllllllllllIIIlIIIlIIIll -= lllllllllllllllllllIIIlIIIlIIIIl;
    lllllllllllllllllllIIIlIIIlIIIlI -= lllllllllllllllllllIIIlIIIlIIIII;
    if ((lIlIIlllIIII(lllllllllllllllllllIIIlIIIlIIIll, lllllllllllllllllllIIIlIIIlIIlll - llIlIIIllI[3])) && (lIlIIllllIll(lllllllllllllllllllIIIlIIIlIIIll, lllllllllllllllllllIIIlIIIlIIlll + lllllllllllllllllllIIIlIIIlIIlIl + llIlIIIllI[3])) && (lIlIIlllIIII(lllllllllllllllllllIIIlIIIlIIIlI, lllllllllllllllllllIIIlIIIlIIllI - llIlIIIllI[3])) && (lIlIIllllIll(lllllllllllllllllllIIIlIIIlIIIlI, lllllllllllllllllllIIIlIIIlIIllI + lllllllllllllllllllIIIlIIIlIIlII + llIlIIIllI[3]))) {
      return llIlIIIllI[3];
    }
    return llIlIIIllI[0];
  }
  
  protected void drawGuiContainerForegroundLayer(int lllllllllllllllllllIIIllIIlIlIII, int lllllllllllllllllllIIIllIIlIIlll) {}
  
  private void drawItemStack(ItemStack lllllllllllllllllllIIIllIIlIllIl, int lllllllllllllllllllIIIllIIlIllII, int lllllllllllllllllllIIIllIIllIIII, String lllllllllllllllllllIIIllIIlIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    GlStateManager.translate(0.0F, 0.0F, 32.0F);
    zLevel = 200.0F;
    itemRender.zLevel = 200.0F;
    itemRender.renderItemAndEffectIntoGUI(lllllllllllllllllllIIIllIIlIllIl, lllllllllllllllllllIIIllIIllIIIl, lllllllllllllllllllIIIllIIllIIII);
    if (lIlIIlllIIIl(draggedStack))
    {
      "".length();
      if ("  ".length() == "  ".length()) {
        break label89;
      }
    }
    label89:
    fontRendererObj.renderItemOverlayIntoGUI(lllllllllllllllllllIIIllIIlIllIl, lllllllllllllllllllIIIllIIllIIIl, lllllllllllllllllllIIIllIIllIIII, llIlIIIllI[0] - llIlIIIllI[8], lllllllllllllllllllIIIllIIlIlIlI);
    zLevel = 0.0F;
    itemRender.zLevel = 0.0F;
  }
  
  private static boolean lIlIIlllIllI(Object ???, Object arg1)
  {
    Object localObject;
    String lllllllllllllllllllIIIIllIllIIlI;
    return ??? == localObject;
  }
  
  private static boolean lIlIIllllIlI(int ???, int arg1)
  {
    int i;
    int lllllllllllllllllllIIIIllIlIIIlI;
    return ??? != i;
  }
  
  private static boolean lIlIIllllIIl(int ???)
  {
    double lllllllllllllllllllIIIIllIlIlIII;
    return ??? < 0;
  }
  
  public void initGui()
  {
    ;
    lllllllllllllllllllIIIllIllIlllI.initGui();
    mc.thePlayer.openContainer = inventorySlots;
    guiLeft = ((width - xSize) / llIlIIIllI[4]);
    guiTop = ((height - ySize) / llIlIIIllI[4]);
  }
  
  private static String lIlIIllIIlII(String lllllllllllllllllllIIIIlllIlIIIl, String lllllllllllllllllllIIIIlllIlIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllllIIIIlllIlIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIIIIlllIlIIII.getBytes(StandardCharsets.UTF_8)), llIlIIIllI[8]), "DES");
      Cipher lllllllllllllllllllIIIIlllIlIIll = Cipher.getInstance("DES");
      lllllllllllllllllllIIIIlllIlIIll.init(llIlIIIllI[4], lllllllllllllllllllIIIIlllIlIlII);
      return new String(lllllllllllllllllllIIIIlllIlIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIIIIlllIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllllIIIIlllIlIIlI)
    {
      lllllllllllllllllllIIIIlllIlIIlI.printStackTrace();
    }
    return null;
  }
  
  private static int lIlIIllllIII(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  private static boolean lIlIIlllIlll(int ???, int arg1)
  {
    int i;
    String lllllllllllllllllllIIIIlllIIlIII;
    return ??? == i;
  }
  
  private Slot getSlotAtPosition(int lllllllllllllllllllIIIlIllIIlIII, int lllllllllllllllllllIIIlIllIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllllllIIIlIllIIIllI = llIlIIIllI[0];
    "".length();
    if (-" ".length() != -" ".length()) {
      return null;
    }
    while (!lIlIIlllIIII(lllllllllllllllllllIIIlIllIIIllI, inventorySlots.inventorySlots.size()))
    {
      Slot lllllllllllllllllllIIIlIllIIIlIl = (Slot)inventorySlots.inventorySlots.get(lllllllllllllllllllIIIlIllIIIllI);
      if (lIlIIllIllll(lllllllllllllllllllIIIlIllIIlIIl.isMouseOverSlot(lllllllllllllllllllIIIlIllIIIlIl, lllllllllllllllllllIIIlIllIIIIll, lllllllllllllllllllIIIlIllIIIlll))) {
        return lllllllllllllllllllIIIlIllIIIlIl;
      }
      lllllllllllllllllllIIIlIllIIIllI++;
    }
    return null;
  }
  
  private static boolean lIlIIllllllI(int ???)
  {
    char lllllllllllllllllllIIIIllIlIIllI;
    return ??? > 0;
  }
}

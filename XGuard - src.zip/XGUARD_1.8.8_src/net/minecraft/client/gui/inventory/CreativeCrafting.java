package net.minecraft.client.gui.inventory;

import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ICrafting;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;

public class CreativeCrafting
  implements ICrafting
{
  public void func_175173_a(Container llllllllllllllllIlllllllllIIIIII, IInventory llllllllllllllllIllllllllIllllll) {}
  
  public void sendSlotContents(Container llllllllllllllllIlllllllllIIlIll, int llllllllllllllllIlllllllllIIIlll, ItemStack llllllllllllllllIlllllllllIIIllI)
  {
    ;
    ;
    ;
    mc.playerController.sendSlotPacket(llllllllllllllllIlllllllllIIIllI, llllllllllllllllIlllllllllIIlIlI);
  }
  
  public void sendProgressBarUpdate(Container llllllllllllllllIlllllllllIIIlII, int llllllllllllllllIlllllllllIIIIll, int llllllllllllllllIlllllllllIIIIlI) {}
  
  public CreativeCrafting(Minecraft llllllllllllllllIlllllllllIlIIll)
  {
    mc = llllllllllllllllIlllllllllIlIIll;
  }
  
  public void updateCraftingInventory(Container llllllllllllllllIlllllllllIlIIIl, List<ItemStack> llllllllllllllllIlllllllllIlIIII) {}
}

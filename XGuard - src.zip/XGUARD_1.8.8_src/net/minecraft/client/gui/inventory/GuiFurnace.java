package net.minecraft.client.gui.inventory;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ContainerFurnace;
import net.minecraft.inventory.IInventory;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.util.IChatComponent;

public class GuiFurnace
  extends GuiContainer
{
  private static boolean lIlIIlIIlIll(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllllllIIlIlIlIIllIl;
    return ??? < i;
  }
  
  private static void lIlIIIIIIIIl()
  {
    llIIlIIlll = new String[llIIlllIII[12]];
    llIIlIIlll[llIIlllIII[0]] = lIlIIIIIIIII("GjE2FxEcMT1MAxs9YQALACAvCgoLJmEFERw6LwABQCQgBA==", "nTNcd");
  }
  
  private static void lIlIIlIIIlll()
  {
    llIIlllIII = new int[19];
    llIIlllIII[0] = ((0xA ^ 0x15 ^ 0x21 ^ 0x78) & (44 + '' - 12 + 78 ^ 96 + '' - 102 + 56 ^ -" ".length()));
    llIIlllIII[1] = "  ".length();
    llIIlllIII[2] = (0x8A ^ 0x8C);
    llIIlllIII[3] = (0xCE7B & 0x4071C4);
    llIIlllIII[4] = (0x7E ^ 0x76);
    llIIlllIII[5] = (0x40 ^ 0x39 ^ 0xA4 ^ 0xBD);
    llIIlllIII[6] = (0xCF ^ 0xC2);
    llIIlllIII[7] = (0x89 ^ 0x8C ^ 0x7B ^ 0x46);
    llIIlllIII[8] = (0x53 ^ 0x77);
    llIIlllIII[9] = (0x27 ^ 0x2B);
    llIIlllIII[10] = ((0xEE ^ 0x83) + (0x63 ^ 0x1F) - (0x2E ^ 0x45) + (0x24 ^ 0x16));
    llIIlllIII[11] = (0x23 ^ 0x2D);
    llIIlllIII[12] = " ".length();
    llIIlllIII[13] = (0x2C ^ 0x29 ^ 0x22 ^ 0x3F);
    llIIlllIII[14] = (0x6 ^ 0x49);
    llIIlllIII[15] = (0xFE ^ 0xC5 ^ 0x3A ^ 0x23);
    llIIlllIII[16] = (0x4B ^ 0x74 ^ 0x8E ^ 0xA1);
    llIIlllIII[17] = "   ".length();
    llIIlllIII[18] = ((0x3E ^ 0x7A) + (0x43 ^ 0x4A) - (0x15 ^ 0x5C) + (25 + 78 - 81 + 174));
  }
  
  private int getCookProgressScaled(int lllllllllllllllllllIIlIlIlllIlII)
  {
    ;
    ;
    ;
    ;
    int lllllllllllllllllllIIlIlIlllIlll = tileFurnace.getField(llIIlllIII[1]);
    int lllllllllllllllllllIIlIlIlllIllI = tileFurnace.getField(llIIlllIII[17]);
    if ((lIlIIlIIlIIl(lllllllllllllllllllIIlIlIlllIllI)) && (lIlIIlIIlIIl(lllllllllllllllllllIIlIlIlllIlll)))
    {
      "".length();
      if ((('' + 39 - 70 + 47 ^ '' + 84 - 85 + 22) & (0x81 ^ 0xBD ^ 0x78 ^ 0x4B ^ -" ".length())) >= -" ".length()) {
        break label149;
      }
      return (0x79 ^ 0x2E ^ 0x2C ^ 0x76) & (0x62 ^ 0x59 ^ 0x8B ^ 0xBD ^ -" ".length());
    }
    label149:
    return llIIlllIII[0];
  }
  
  private static boolean lIlIIlIIlIlI(int ???)
  {
    byte lllllllllllllllllllIIlIlIlIIlIIl;
    return ??? == 0;
  }
  
  protected void drawGuiContainerForegroundLayer(int lllllllllllllllllllIIlIllIIlIIlI, int lllllllllllllllllllIIlIllIIlIIIl)
  {
    ;
    ;
    String lllllllllllllllllllIIlIllIIlIIII = tileFurnace.getDisplayName().getUnformattedText();
    "".length();
    "".length();
  }
  
  protected void drawGuiContainerBackgroundLayer(float lllllllllllllllllllIIlIllIIIlIII, int lllllllllllllllllllIIlIllIIIIlll, int lllllllllllllllllllIIlIllIIIIllI)
  {
    ;
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(furnaceGuiTextures);
    int lllllllllllllllllllIIlIllIIIIlIl = (width - xSize) / llIIlllIII[1];
    int lllllllllllllllllllIIlIllIIIIlII = (height - ySize) / llIIlllIII[1];
    lllllllllllllllllllIIlIllIIIlIIl.drawTexturedModalRect(lllllllllllllllllllIIlIllIIIIlIl, lllllllllllllllllllIIlIllIIIIlII, llIIlllIII[0], llIIlllIII[0], xSize, ySize);
    if (lIlIIlIIlIIl(TileEntityFurnace.isBurning(tileFurnace)))
    {
      int lllllllllllllllllllIIlIllIIIIIll = lllllllllllllllllllIIlIllIIIlIIl.getBurnLeftScaled(llIIlllIII[6]);
      lllllllllllllllllllIIlIllIIIlIIl.drawTexturedModalRect(lllllllllllllllllllIIlIllIIIIlIl + llIIlllIII[7], lllllllllllllllllllIIlIllIIIIlII + llIIlllIII[8] + llIIlllIII[9] - lllllllllllllllllllIIlIllIIIIIll, llIIlllIII[10], llIIlllIII[9] - lllllllllllllllllllIIlIllIIIIIll, llIIlllIII[11], lllllllllllllllllllIIlIllIIIIIll + llIIlllIII[12]);
    }
    int lllllllllllllllllllIIlIllIIIIIlI = lllllllllllllllllllIIlIllIIIlIIl.getCookProgressScaled(llIIlllIII[13]);
    lllllllllllllllllllIIlIllIIIlIIl.drawTexturedModalRect(lllllllllllllllllllIIlIllIIIIlIl + llIIlllIII[14], lllllllllllllllllllIIlIllIIIIlII + llIIlllIII[15], llIIlllIII[10], llIIlllIII[11], lllllllllllllllllllIIlIllIIIIIlI + llIIlllIII[12], llIIlllIII[16]);
  }
  
  private static boolean lIlIIlIIlIIl(int ???)
  {
    boolean lllllllllllllllllllIIlIlIlIIlIll;
    return ??? != 0;
  }
  
  private int getBurnLeftScaled(int lllllllllllllllllllIIlIlIllIlIlI)
  {
    ;
    ;
    ;
    int lllllllllllllllllllIIlIlIllIllII = tileFurnace.getField(llIIlllIII[12]);
    if (lIlIIlIIlIlI(lllllllllllllllllllIIlIlIllIllII)) {
      lllllllllllllllllllIIlIlIllIllII = llIIlllIII[18];
    }
    return tileFurnace.getField(llIIlllIII[0]) * lllllllllllllllllllIIlIlIllIlIlI / lllllllllllllllllllIIlIlIllIllII;
  }
  
  static
  {
    lIlIIlIIIlll();
    lIlIIIIIIIIl();
  }
  
  public GuiFurnace(InventoryPlayer lllllllllllllllllllIIlIllIIlIlll, IInventory lllllllllllllllllllIIlIllIIllIIl)
  {
    lllllllllllllllllllIIlIllIIllIII.<init>(new ContainerFurnace(lllllllllllllllllllIIlIllIIllIlI, lllllllllllllllllllIIlIllIIllIIl));
    playerInventory = lllllllllllllllllllIIlIllIIllIlI;
    tileFurnace = lllllllllllllllllllIIlIllIIllIIl;
  }
  
  private static String lIlIIIIIIIII(String lllllllllllllllllllIIlIlIlIllllI, String lllllllllllllllllllIIlIlIlIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIIlIlIlIllllI = new String(Base64.getDecoder().decode(lllllllllllllllllllIIlIlIlIllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllllIIlIlIlIlllII = new StringBuilder();
    char[] lllllllllllllllllllIIlIlIlIllIll = lllllllllllllllllllIIlIlIlIllIII.toCharArray();
    int lllllllllllllllllllIIlIlIlIllIlI = llIIlllIII[0];
    float lllllllllllllllllllIIlIlIlIlIlII = lllllllllllllllllllIIlIlIlIllllI.toCharArray();
    byte lllllllllllllllllllIIlIlIlIlIIll = lllllllllllllllllllIIlIlIlIlIlII.length;
    float lllllllllllllllllllIIlIlIlIlIIlI = llIIlllIII[0];
    while (lIlIIlIIlIll(lllllllllllllllllllIIlIlIlIlIIlI, lllllllllllllllllllIIlIlIlIlIIll))
    {
      char lllllllllllllllllllIIlIlIlIlllll = lllllllllllllllllllIIlIlIlIlIlII[lllllllllllllllllllIIlIlIlIlIIlI];
      "".length();
      "".length();
      if (-(0xBA ^ 0xBD ^ "   ".length()) > 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllllIIlIlIlIlllII);
  }
}

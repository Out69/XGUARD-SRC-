package net.minecraft.client.gui.inventory;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.inventory.ContainerHorseInventory;
import net.minecraft.inventory.IInventory;

public class GuiScreenHorseInventory
  extends GuiContainer
{
  private static void lllIIlIIllII()
  {
    lIIlIIIIIll = new int[18];
    lIIlIIIIIll[0] = ((0xF1 ^ 0xAB) & (0x1B ^ 0x41 ^ 0xFFFFFFFF));
    lIIlIIIIIll[1] = (' ' + '¨' - 179 + 41 ^ 76 + 39 - 56 + 123);
    lIIlIIIIIll[2] = (0x72 ^ 0xE ^ 0xBC ^ 0xC6);
    lIIlIIIIIll[3] = (-(0xE8F3 & 0x1F3F) & 0xDF72 & 0x4068FF);
    lIIlIIIIIll[4] = ('¬' + 93 - 83 + 12 ^ 65 + 64 - 120 + 153);
    lIIlIIIIIll[5] = "  ".length();
    lIIlIIIIIll[6] = (0xC9 ^ 0xA7 ^ 0x72 ^ 0x53);
    lIIlIIIIIll[7] = (0x81 ^ 0x90);
    lIIlIIIIIll[8] = (0x3E ^ 0x64);
    lIIlIIIIIll[9] = (0x35 ^ 0x3);
    lIIlIIIIIll[10] = (0x6F ^ 0x1D ^ 0x21 ^ 0x54);
    lIIlIIIIIll[11] = (0x1E ^ 0x56 ^ 0x1 ^ 0x6A);
    lIIlIIIIIll[12] = (16 + 11 - -114 + 42 ^ 4 + 106 - 103 + 158);
    lIIlIIIIIll[13] = (74 + 108 - 56 + 21 ^ 51 + 87 - 18 + 40);
    lIIlIIIIIll[14] = (0x7A ^ 0x46);
    lIIlIIIIIll[15] = (0xCB ^ 0x80);
    lIIlIIIIIll[16] = (0x8E ^ 0xBC);
    lIIlIIIIIll[17] = " ".length();
  }
  
  public GuiScreenHorseInventory(IInventory lllllllllllllllllIlIIllIIlIIlIIl, IInventory lllllllllllllllllIlIIllIIlIIlIII, EntityHorse lllllllllllllllllIlIIllIIlIIIlll)
  {
    lllllllllllllllllIlIIllIIlIIlllI.<init>(new ContainerHorseInventory(lllllllllllllllllIlIIllIIlIIlIIl, lllllllllllllllllIlIIllIIlIIlIII, lllllllllllllllllIlIIllIIlIIIlll, getMinecraftthePlayer));
    playerInventory = lllllllllllllllllIlIIllIIlIIlIIl;
    horseInventory = lllllllllllllllllIlIIllIIlIIlIII;
    horseEntity = lllllllllllllllllIlIIllIIlIIIlll;
    allowUserInput = lIIlIIIIIll[0];
  }
  
  public void drawScreen(int lllllllllllllllllIlIIllIIIllIIII, int lllllllllllllllllIlIIllIIIlIllll, float lllllllllllllllllIlIIllIIIlIlllI)
  {
    ;
    ;
    ;
    ;
    mousePosx = lllllllllllllllllIlIIllIIIllIIII;
    mousePosY = lllllllllllllllllIlIIllIIIlIllll;
    lllllllllllllllllIlIIllIIIllIIIl.drawScreen(lllllllllllllllllIlIIllIIIllIIII, lllllllllllllllllIlIIllIIIlIllll, lllllllllllllllllIlIIllIIIlIlllI);
  }
  
  protected void drawGuiContainerBackgroundLayer(float lllllllllllllllllIlIIllIIIllllIl, int lllllllllllllllllIlIIllIIIllllII, int lllllllllllllllllIlIIllIIIlllIll)
  {
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(horseGuiTextures);
    int lllllllllllllllllIlIIllIIIlllIlI = (width - xSize) / lIIlIIIIIll[5];
    int lllllllllllllllllIlIIllIIIlllIIl = (height - ySize) / lIIlIIIIIll[5];
    lllllllllllllllllIlIIllIIIlllllI.drawTexturedModalRect(lllllllllllllllllIlIIllIIIlllIlI, lllllllllllllllllIlIIllIIIlllIIl, lIIlIIIIIll[0], lIIlIIIIIll[0], xSize, ySize);
    if (lllIIlIIllIl(horseEntity.isChested())) {
      lllllllllllllllllIlIIllIIIlllllI.drawTexturedModalRect(lllllllllllllllllIlIIllIIIlllIlI + lIIlIIIIIll[6], lllllllllllllllllIlIIllIIIlllIIl + lIIlIIIIIll[7], lIIlIIIIIll[0], ySize, lIIlIIIIIll[8], lIIlIIIIIll[9]);
    }
    if (lllIIlIIllIl(horseEntity.canWearArmor())) {
      lllllllllllllllllIlIIllIIIlllllI.drawTexturedModalRect(lllllllllllllllllIlIIllIIIlllIlI + lIIlIIIIIll[10], lllllllllllllllllIlIIllIIIlllIIl + lIIlIIIIIll[11], lIIlIIIIIll[0], ySize + lIIlIIIIIll[9], lIIlIIIIIll[12], lIIlIIIIIll[12]);
    }
    GuiInventory.drawEntityOnScreen(lllllllllllllllllIlIIllIIIlllIlI + lIIlIIIIIll[13], lllllllllllllllllIlIIllIIIlllIIl + lIIlIIIIIll[14], lIIlIIIIIll[7], lllllllllllllllllIlIIllIIIlllIlI + lIIlIIIIIll[13] - mousePosx, lllllllllllllllllIlIIllIIIlllIIl + lIIlIIIIIll[15] - lIIlIIIIIll[16] - mousePosY, horseEntity);
  }
  
  static
  {
    lllIIlIIllII();
    lllIIlIIIlll();
  }
  
  private static boolean lllIIlIIlllI(int ???, int arg1)
  {
    int i;
    double lllllllllllllllllIlIIllIIIIIlllI;
    return ??? < i;
  }
  
  private static String lllIIlIIIllI(String lllllllllllllllllIlIIllIIIIlllll, String lllllllllllllllllIlIIllIIIIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIlIIllIIIIlllll = new String(Base64.getDecoder().decode(lllllllllllllllllIlIIllIIIIlllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIlIIllIIIIlllIl = new StringBuilder();
    char[] lllllllllllllllllIlIIllIIIIlllII = lllllllllllllllllIlIIllIIIIllllI.toCharArray();
    int lllllllllllllllllIlIIllIIIIllIll = lIIlIIIIIll[0];
    String lllllllllllllllllIlIIllIIIIlIlIl = lllllllllllllllllIlIIllIIIIlllll.toCharArray();
    double lllllllllllllllllIlIIllIIIIlIlII = lllllllllllllllllIlIIllIIIIlIlIl.length;
    double lllllllllllllllllIlIIllIIIIlIIll = lIIlIIIIIll[0];
    while (lllIIlIIlllI(lllllllllllllllllIlIIllIIIIlIIll, lllllllllllllllllIlIIllIIIIlIlII))
    {
      char lllllllllllllllllIlIIllIIIlIIIII = lllllllllllllllllIlIIllIIIIlIlIl[lllllllllllllllllIlIIllIIIIlIIll];
      "".length();
      "".length();
      if (" ".length() <= -" ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIlIIllIIIIlllIl);
  }
  
  private static boolean lllIIlIIllIl(int ???)
  {
    boolean lllllllllllllllllIlIIllIIIIIllII;
    return ??? != 0;
  }
  
  protected void drawGuiContainerForegroundLayer(int lllllllllllllllllIlIIllIIlIIIlII, int lllllllllllllllllIlIIllIIlIIIIll)
  {
    ;
    "".length();
    "".length();
  }
  
  private static void lllIIlIIIlll()
  {
    lIIIlllllll = new String[lIIlIIIIIll[17]];
    lIIIlllllll[lIIlIIIIIll[0]] = lllIIlIIIllI("EwcAARMVBwtaARILVxYJCRYZHAgCEFcdCRURHVsWCQU=", "gbxuf");
  }
}

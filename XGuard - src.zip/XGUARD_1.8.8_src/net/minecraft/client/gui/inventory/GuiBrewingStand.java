package net.minecraft.client.gui.inventory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ContainerBrewingStand;
import net.minecraft.inventory.IInventory;
import net.minecraft.util.IChatComponent;

public class GuiBrewingStand
  extends GuiContainer
{
  public GuiBrewingStand(InventoryPlayer llllllllllllllIIllIlllIllIIIIIII, IInventory llllllllllllllIIllIlllIlIlllllII)
  {
    llllllllllllllIIllIlllIllIIIIIIl.<init>(new ContainerBrewingStand(llllllllllllllIIllIlllIlIlllllIl, llllllllllllllIIllIlllIlIlllllII));
    playerInventory = llllllllllllllIIllIlllIlIlllllIl;
    tileBrewingStand = llllllllllllllIIllIlllIlIlllllII;
  }
  
  private static void lllIlIlIIIIIII()
  {
    lIIllIIIlIIlI = new int[20];
    lIIllIIIlIIlI[0] = ((0xAA ^ 0xB6) & (0xAC ^ 0xB0 ^ 0xFFFFFFFF));
    lIIllIIIlIIlI[1] = "  ".length();
    lIIllIIIlIIlI[2] = (0x64 ^ 0x57 ^ 0x46 ^ 0x73);
    lIIllIIIlIIlI[3] = (-(0xAAB6 & 0x77FD) & 0xFAF3 & 0x4067FF);
    lIIllIIIlIIlI[4] = (0x1A ^ 0x5D ^ 0x10 ^ 0x5F);
    lIIllIIIlIIlI[5] = (58 + 14 - -97 + 29 ^ 126 + '' - 233 + 129);
    lIIllIIIlIIlI[6] = (0x23 ^ 0x3A ^ 0x9 ^ 0x71);
    lIIllIIIlIIlI[7] = (66 + '©' - 217 + 171 ^ 12 + 39 - 44 + 166);
    lIIllIIIlIIlI[8] = ((0xAF ^ 0x85) + (0x88 ^ 0xC5) - -(0x1C ^ 0x17) + (0x8B ^ 0xA5));
    lIIllIIIlIIlI[9] = (0xAC ^ 0xA5);
    lIIllIIIlIIlI[10] = (0x44 ^ 0xF ^ 0xD4 ^ 0x98);
    lIIllIIIlIIlI[11] = (0x12 ^ 0xF);
    lIIllIIIlIIlI[12] = (0xA8 ^ 0xB8 ^ 0xCB ^ 0xC3);
    lIIllIIIlIIlI[13] = (0x4D ^ 0x23 ^ 0x5C ^ 0x26);
    lIIllIIIlIIlI[14] = (0x65 ^ 0x6E);
    lIIllIIIlIIlI[15] = (0x24 ^ 0x6E ^ 0x85 ^ 0x8E);
    lIIllIIIlIIlI[16] = (0xAF ^ 0xA1);
    lIIllIIIlIIlI[17] = (21 + 11 - -79 + 74);
    lIIllIIIlIIlI[18] = ('' + '' - 164 + 42 ^ 40 + 104 - 130 + 152);
    lIIllIIIlIIlI[19] = " ".length();
  }
  
  private static String lllIlIIllllllI(String llllllllllllllIIllIlllIlIlIlIlll, String llllllllllllllIIllIlllIlIlIlIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllIlllIlIlIllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllIlllIlIlIlIlII.getBytes(StandardCharsets.UTF_8)), lIIllIIIlIIlI[4]), "DES");
      Cipher llllllllllllllIIllIlllIlIlIllIIl = Cipher.getInstance("DES");
      llllllllllllllIIllIlllIlIlIllIIl.init(lIIllIIIlIIlI[1], llllllllllllllIIllIlllIlIlIllIlI);
      return new String(llllllllllllllIIllIlllIlIlIllIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIIllIlllIlIlIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllIlllIlIlIllIII)
    {
      llllllllllllllIIllIlllIlIlIllIII.printStackTrace();
    }
    return null;
  }
  
  private static void lllIlIIlllllll()
  {
    lIIllIIIlIIIl = new String[lIIllIIIlIIlI[19]];
    lIIllIIIlIIIl[lIIllIIIlIIlI[0]] = lllIlIIllllllI("6GF1+kN9el/mmzENG02HA/lTPnI6YS74DzlXZWsuqeM4J+SPhFXfG6D/gCBWX3/i", "hAfoX");
  }
  
  private static boolean lllIlIlIIIIIIl(int ???)
  {
    short llllllllllllllIIllIlllIlIlIlIIII;
    return ??? > 0;
  }
  
  static
  {
    lllIlIlIIIIIII();
    lllIlIIlllllll();
  }
  
  protected void drawGuiContainerForegroundLayer(int llllllllllllllIIllIlllIlIllllIII, int llllllllllllllIIllIlllIlIlllIlll)
  {
    ;
    ;
    String llllllllllllllIIllIlllIlIlllIllI = tileBrewingStand.getDisplayName().getUnformattedText();
    "".length();
    "".length();
  }
  
  protected void drawGuiContainerBackgroundLayer(float llllllllllllllIIllIlllIlIllIllII, int llllllllllllllIIllIlllIlIllIlIll, int llllllllllllllIIllIlllIlIllIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(brewingStandGuiTextures);
    int llllllllllllllIIllIlllIlIllIlIIl = (width - xSize) / lIIllIIIlIIlI[1];
    int llllllllllllllIIllIlllIlIllIlIII = (height - ySize) / lIIllIIIlIIlI[1];
    llllllllllllllIIllIlllIlIllIIlII.drawTexturedModalRect(llllllllllllllIIllIlllIlIllIlIIl, llllllllllllllIIllIlllIlIllIlIII, lIIllIIIlIIlI[0], lIIllIIIlIIlI[0], xSize, ySize);
    int llllllllllllllIIllIlllIlIllIIlll = tileBrewingStand.getField(lIIllIIIlIIlI[0]);
    if (lllIlIlIIIIIIl(llllllllllllllIIllIlllIlIllIIlll))
    {
      int llllllllllllllIIllIlllIlIllIIllI = (int)(28.0F * (1.0F - llllllllllllllIIllIlllIlIllIIlll / 400.0F));
      if (lllIlIlIIIIIIl(llllllllllllllIIllIlllIlIllIIllI)) {
        llllllllllllllIIllIlllIlIllIIlII.drawTexturedModalRect(llllllllllllllIIllIlllIlIllIlIIl + lIIllIIIlIIlI[6], llllllllllllllIIllIlllIlIllIlIII + lIIllIIIlIIlI[7], lIIllIIIlIIlI[8], lIIllIIIlIIlI[0], lIIllIIIlIIlI[9], llllllllllllllIIllIlllIlIllIIllI);
      }
      int llllllllllllllIIllIlllIlIllIIlIl = llllllllllllllIIllIlllIlIllIIlll / lIIllIIIlIIlI[1] % lIIllIIIlIIlI[10];
      switch (llllllllllllllIIllIlllIlIllIIlIl)
      {
      case 0: 
        llllllllllllllIIllIlllIlIllIIllI = lIIllIIIlIIlI[11];
        "".length();
        if (null != null) {
          return;
        }
        break;
      case 1: 
        llllllllllllllIIllIlllIlIllIIllI = lIIllIIIlIIlI[12];
        "".length();
        if (((0xB6 ^ 0x89) & (0x96 ^ 0xA9 ^ 0xFFFFFFFF)) > 0) {
          return;
        }
        break;
      case 2: 
        llllllllllllllIIllIlllIlIllIIllI = lIIllIIIlIIlI[13];
        "".length();
        if (((0x3C ^ 0x2) & (0xC ^ 0x32 ^ 0xFFFFFFFF)) != 0) {
          return;
        }
        break;
      case 3: 
        llllllllllllllIIllIlllIlIllIIllI = lIIllIIIlIIlI[7];
        "".length();
        if (null != null) {
          return;
        }
        break;
      case 4: 
        llllllllllllllIIllIlllIlIllIIllI = lIIllIIIlIIlI[14];
        "".length();
        if (-" ".length() == ((5 + 106 - 62 + 119 ^ '' + 71 - 52 + 5) & (0x4B ^ 0x43 ^ 0x97 ^ 0x98 ^ -" ".length()))) {
          return;
        }
        break;
      case 5: 
        llllllllllllllIIllIlllIlIllIIllI = lIIllIIIlIIlI[2];
        "".length();
        if (" ".length() <= 0) {
          return;
        }
        break;
      case 6: 
        llllllllllllllIIllIlllIlIllIIllI = lIIllIIIlIIlI[0];
      }
      if (lllIlIlIIIIIIl(llllllllllllllIIllIlllIlIllIIllI)) {
        llllllllllllllIIllIlllIlIllIIlII.drawTexturedModalRect(llllllllllllllIIllIlllIlIllIlIIl + lIIllIIIlIIlI[15], llllllllllllllIIllIlllIlIllIlIII + lIIllIIIlIIlI[16] + lIIllIIIlIIlI[11] - llllllllllllllIIllIlllIlIllIIllI, lIIllIIIlIIlI[17], lIIllIIIlIIlI[11] - llllllllllllllIIllIlllIlIllIIllI, lIIllIIIlIIlI[18], llllllllllllllIIllIlllIlIllIIllI);
      }
    }
  }
}

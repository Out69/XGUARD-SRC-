package net.minecraft.client.gui.inventory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.achievement.GuiAchievements;
import net.minecraft.client.gui.achievement.GuiStats;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.InventoryEffectRenderer;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

public class GuiInventory
  extends InventoryEffectRenderer
{
  public void drawScreen(int llllllllllllllIllllIllIlIIlllIll, int llllllllllllllIllllIllIlIIlllIlI, float llllllllllllllIllllIllIlIIlllIIl)
  {
    ;
    ;
    ;
    ;
    llllllllllllllIllllIllIlIlIIIIII.drawScreen(llllllllllllllIllllIllIlIIlllIll, llllllllllllllIllllIllIlIIlllIlI, llllllllllllllIllllIllIlIIlllIIl);
    oldMouseX = llllllllllllllIllllIllIlIIlllIll;
    oldMouseY = llllllllllllllIllllIllIlIIlllIlI;
  }
  
  protected void drawGuiContainerForegroundLayer(int llllllllllllllIllllIllIlIlIIIlll, int llllllllllllllIllllIllIlIlIIIllI)
  {
    ;
    "".length();
  }
  
  private static boolean lIlIlIIIIllIII(int ???)
  {
    long llllllllllllllIllllIllIIlllIlllI;
    return ??? == 0;
  }
  
  private static boolean lIlIlIIIIllIIl(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIllllIllIIllllIIlI;
    return ??? == i;
  }
  
  public static void drawEntityOnScreen(int llllllllllllllIllllIllIlIIlIIIII, int llllllllllllllIllllIllIlIIIlIIll, int llllllllllllllIllllIllIlIIIlIIlI, float llllllllllllllIllllIllIlIIIlllIl, float llllllllllllllIllllIllIlIIIlllII, EntityLivingBase llllllllllllllIllllIllIlIIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.enableColorMaterial();
    GlStateManager.pushMatrix();
    GlStateManager.translate(llllllllllllllIllllIllIlIIlIIIII, llllllllllllllIllllIllIlIIIlIIll, 50.0F);
    GlStateManager.scale(-llllllllllllllIllllIllIlIIIlIIlI, llllllllllllllIllllIllIlIIIlIIlI, llllllllllllllIllllIllIlIIIlIIlI);
    GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
    float llllllllllllllIllllIllIlIIIllIlI = renderYawOffset;
    float llllllllllllllIllllIllIlIIIllIIl = rotationYaw;
    float llllllllllllllIllllIllIlIIIllIII = rotationPitch;
    float llllllllllllllIllllIllIlIIIlIlll = prevRotationYawHead;
    float llllllllllllllIllllIllIlIIIlIllI = rotationYawHead;
    GlStateManager.rotate(135.0F, 0.0F, 1.0F, 0.0F);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.rotate(-135.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-(float)Math.atan(llllllllllllllIllllIllIlIIIlllII / 40.0F) * 20.0F, 1.0F, 0.0F, 0.0F);
    renderYawOffset = ((float)Math.atan(llllllllllllllIllllIllIlIIIlllIl / 40.0F) * 20.0F);
    rotationYaw = ((float)Math.atan(llllllllllllllIllllIllIlIIIlllIl / 40.0F) * 40.0F);
    rotationPitch = (-(float)Math.atan(llllllllllllllIllllIllIlIIIlllII / 40.0F) * 20.0F);
    rotationYawHead = rotationYaw;
    prevRotationYawHead = rotationYaw;
    GlStateManager.translate(0.0F, 0.0F, 0.0F);
    RenderManager llllllllllllllIllllIllIlIIIlIlIl = Minecraft.getMinecraft().getRenderManager();
    llllllllllllllIllllIllIlIIIlIlIl.setPlayerViewY(180.0F);
    llllllllllllllIllllIllIlIIIlIlIl.setRenderShadow(llIllIlllIll[1]);
    "".length();
    llllllllllllllIllllIllIlIIIlIlIl.setRenderShadow(llIllIlllIll[0]);
    renderYawOffset = llllllllllllllIllllIllIlIIIllIlI;
    rotationYaw = llllllllllllllIllllIllIlIIIllIIl;
    rotationPitch = llllllllllllllIllllIllIlIIIllIII;
    prevRotationYawHead = llllllllllllllIllllIllIlIIIlIlll;
    rotationYawHead = llllllllllllllIllllIllIlIIIlIllI;
    GlStateManager.popMatrix();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableRescaleNormal();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  private static void lIlIlIIIIlIlIl()
  {
    llIllIlllIll = new int[11];
    llIllIlllIll[0] = " ".length();
    llIllIlllIll[1] = ((0x7A ^ 0x7D) & (0x51 ^ 0x56 ^ 0xFFFFFFFF));
    llIllIlllIll[2] = (0x21 ^ 0x77);
    llIllIlllIll[3] = (0x3 ^ 0x13);
    llIllIlllIll[4] = (0xEADD & 0x405562);
    llIllIlllIll[5] = (101 + 85 - 125 + 73 ^ '' + 39 - 171 + 158);
    llIllIlllIll[6] = (0xDE ^ 0xB7 ^ 0x7D ^ 0x5F);
    llIllIlllIll[7] = (0x8E ^ 0x90);
    llIllIlllIll[8] = (" ".length() ^ 0x3A ^ 0x9);
    llIllIlllIll[9] = (0x1 ^ 0x14 ^ 0x5B ^ 0x46);
    llIllIlllIll[10] = "  ".length();
  }
  
  private static void lIlIlIIIIlIIll()
  {
    llIllIllIlll = new String[llIllIlllIll[0]];
    llIllIllIlll[llIllIlllIll[1]] = lIlIlIIIIlIIlI("RCDBZ4ld4fiG+byMBB/bgETLhbG45Os8", "KHute");
  }
  
  public void updateScreen()
  {
    ;
    if (lIlIlIIIIlIlll(mc.playerController.isInCreativeMode())) {
      mc.displayGuiScreen(new GuiContainerCreative(mc.thePlayer));
    }
    llllllllllllllIllllIllIlIlIIllIl.updateActivePotionEffects();
  }
  
  private static boolean lIlIlIIIIlIlll(int ???)
  {
    Exception llllllllllllllIllllIllIIllllIIII;
    return ??? != 0;
  }
  
  protected void drawGuiContainerBackgroundLayer(float llllllllllllllIllllIllIlIIllIlII, int llllllllllllllIllllIllIlIIllIIll, int llllllllllllllIllllIllIlIIllIIlI)
  {
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(inventoryBackground);
    int llllllllllllllIllllIllIlIIllIIIl = guiLeft;
    int llllllllllllllIllllIllIlIIllIIII = guiTop;
    llllllllllllllIllllIllIlIIllIlIl.drawTexturedModalRect(llllllllllllllIllllIllIlIIllIIIl, llllllllllllllIllllIllIlIIllIIII, llIllIlllIll[1], llIllIlllIll[1], xSize, ySize);
    drawEntityOnScreen(llllllllllllllIllllIllIlIIllIIIl + llIllIlllIll[5], llllllllllllllIllllIllIlIIllIIII + llIllIlllIll[6], llIllIlllIll[7], llllllllllllllIllllIllIlIIllIIIl + llIllIlllIll[5] - oldMouseX, llllllllllllllIllllIllIlIIllIIII + llIllIlllIll[6] - llIllIlllIll[8] - oldMouseY, mc.thePlayer);
  }
  
  public void initGui()
  {
    ;
    buttonList.clear();
    if (lIlIlIIIIlIlll(mc.playerController.isInCreativeMode()))
    {
      mc.displayGuiScreen(new GuiContainerCreative(mc.thePlayer));
      "".length();
      if (((0x88 ^ 0x95) & (0x70 ^ 0x6D ^ 0xFFFFFFFF)) < "   ".length()) {}
    }
    else
    {
      llllllllllllllIllllIllIlIlIIlIlI.initGui();
    }
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIllllIllIlIIIIIIll)
    throws IOException
  {
    ;
    ;
    if (lIlIlIIIIllIII(id)) {
      mc.displayGuiScreen(new GuiAchievements(llllllllllllllIllllIllIlIIIIIllI, mc.thePlayer.getStatFileWriter()));
    }
    if (lIlIlIIIIllIIl(id, llIllIlllIll[0])) {
      mc.displayGuiScreen(new GuiStats(llllllllllllllIllllIllIlIIIIIllI, mc.thePlayer.getStatFileWriter()));
    }
  }
  
  private static String lIlIlIIIIlIIlI(String llllllllllllllIllllIllIIlllllIIl, String llllllllllllllIllllIllIIlllllIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllllIllIIlllllllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllllIllIIlllllIlI.getBytes(StandardCharsets.UTF_8)), llIllIlllIll[9]), "DES");
      Cipher llllllllllllllIllllIllIIllllllIl = Cipher.getInstance("DES");
      llllllllllllllIllllIllIIllllllIl.init(llIllIlllIll[10], llllllllllllllIllllIllIIlllllllI);
      return new String(llllllllllllllIllllIllIIllllllIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllllIllIIlllllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllllIllIIllllllII)
    {
      llllllllllllllIllllIllIIllllllII.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIlIlIIIIlIlIl();
    lIlIlIIIIlIIll();
  }
  
  public GuiInventory(EntityPlayer llllllllllllllIllllIllIlIlIlIIII)
  {
    llllllllllllllIllllIllIlIlIlIIll.<init>(inventoryContainer);
    allowUserInput = llIllIlllIll[0];
  }
}

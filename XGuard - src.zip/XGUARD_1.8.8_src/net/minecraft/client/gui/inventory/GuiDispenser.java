package net.minecraft.client.gui.inventory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ContainerDispenser;
import net.minecraft.inventory.IInventory;
import net.minecraft.util.IChatComponent;

public class GuiDispenser
  extends GuiContainer
{
  private static void lllIIlIIlIIlI()
  {
    lIIlIIllllll = new int[7];
    lIIlIIllllll[0] = ((0xBE ^ 0x97) & (0x4 ^ 0x2D ^ 0xFFFFFFFF));
    lIIlIIllllll[1] = "  ".length();
    lIIlIIllllll[2] = (0x66 ^ 0x60);
    lIIlIIllllll[3] = (-(0xFCA7 & 0xF7C) & 0xDD77 & 0x406EEB);
    lIIlIIllllll[4] = (0xA9 ^ 0xA1);
    lIIlIIllllll[5] = (98 + '¬' - 41 + 0 ^ 43 + 47 - 48 + 91);
    lIIlIIllllll[6] = " ".length();
  }
  
  protected void drawGuiContainerForegroundLayer(int lllllllllllllllIllIIllIlIIlllIIl, int lllllllllllllllIllIIllIlIIlllIII)
  {
    ;
    ;
    String lllllllllllllllIllIIllIlIIllIlll = dispenserInventory.getDisplayName().getUnformattedText();
    "".length();
    "".length();
  }
  
  private static void lllIIlIIIIIIl()
  {
    lIIlIIlllllI = new String[lIIlIIllllll[6]];
    lIIlIIlllllI[lIIlIIllllll[0]] = lllIIIlllllll("K+5rsuoqs/vDRNkMRMBcoOHQ4geSn07WBqpCLVMlsc4RScsOupa0cA==", "VgACr");
  }
  
  private static String lllIIIlllllll(String lllllllllllllllIllIIllIlIIlIIIIl, String lllllllllllllllIllIIllIlIIIllllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIIllIlIIlIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIllIlIIIllllI.getBytes(StandardCharsets.UTF_8)), lIIlIIllllll[4]), "DES");
      Cipher lllllllllllllllIllIIllIlIIlIIIll = Cipher.getInstance("DES");
      lllllllllllllllIllIIllIlIIlIIIll.init(lIIlIIllllll[1], lllllllllllllllIllIIllIlIIlIIlII);
      return new String(lllllllllllllllIllIIllIlIIlIIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIllIlIIlIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIIllIlIIlIIIlI)
    {
      lllllllllllllllIllIIllIlIIlIIIlI.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lllIIlIIlIIlI();
    lllIIlIIIIIIl();
  }
  
  protected void drawGuiContainerBackgroundLayer(float lllllllllllllllIllIIllIlIIllIIII, int lllllllllllllllIllIIllIlIIlIllll, int lllllllllllllllIllIIllIlIIlIlllI)
  {
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(dispenserGuiTextures);
    int lllllllllllllllIllIIllIlIIlIllIl = (width - xSize) / lIIlIIllllll[1];
    int lllllllllllllllIllIIllIlIIlIllII = (height - ySize) / lIIlIIllllll[1];
    lllllllllllllllIllIIllIlIIlIlIll.drawTexturedModalRect(lllllllllllllllIllIIllIlIIlIllIl, lllllllllllllllIllIIllIlIIlIllII, lIIlIIllllll[0], lIIlIIllllll[0], xSize, ySize);
  }
  
  public GuiDispenser(InventoryPlayer lllllllllllllllIllIIllIlIlIIIIIl, IInventory lllllllllllllllIllIIllIlIlIIIIII)
  {
    lllllllllllllllIllIIllIlIlIIIIlI.<init>(new ContainerDispenser(lllllllllllllllIllIIllIlIIlllllI, lllllllllllllllIllIIllIlIlIIIIII));
    playerInventory = lllllllllllllllIllIIllIlIIlllllI;
    dispenserInventory = lllllllllllllllIllIIllIlIlIIIIII;
  }
}

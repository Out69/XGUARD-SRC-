package net.minecraft.client.gui.inventory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ContainerWorkbench;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class GuiCrafting
  extends GuiContainer
{
  private static String lIlIIIIlllIIIl(String lllllllllllllllIIIIIlIllllIllllI, String lllllllllllllllIIIIIlIllllIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIIIlIllllIllllI = new String(Base64.getDecoder().decode(lllllllllllllllIIIIIlIllllIllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIIIIlIllllIlllII = new StringBuilder();
    char[] lllllllllllllllIIIIIlIllllIllIll = lllllllllllllllIIIIIlIllllIllIII.toCharArray();
    int lllllllllllllllIIIIIlIllllIllIlI = llIlIIlllIIl[0];
    Exception lllllllllllllllIIIIIlIllllIlIlII = lllllllllllllllIIIIIlIllllIllllI.toCharArray();
    int lllllllllllllllIIIIIlIllllIlIIll = lllllllllllllllIIIIIlIllllIlIlII.length;
    float lllllllllllllllIIIIIlIllllIlIIlI = llIlIIlllIIl[0];
    while (lIlIIIIlllIlII(lllllllllllllllIIIIIlIllllIlIIlI, lllllllllllllllIIIIIlIllllIlIIll))
    {
      char lllllllllllllllIIIIIlIllllIlllll = lllllllllllllllIIIIIlIllllIlIlII[lllllllllllllllIIIIIlIllllIlIIlI];
      "".length();
      "".length();
      if ("   ".length() <= ((0xE3 ^ 0xAC) & (0x67 ^ 0x28 ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIIIIlIllllIlllII);
  }
  
  public GuiCrafting(InventoryPlayer lllllllllllllllIIIIIllIIIIIIllIl, World lllllllllllllllIIIIIllIIIIIIlIII, BlockPos lllllllllllllllIIIIIllIIIIIIlIll)
  {
    lllllllllllllllIIIIIllIIIIIIlIlI.<init>(new ContainerWorkbench(lllllllllllllllIIIIIllIIIIIIllIl, lllllllllllllllIIIIIllIIIIIIlIII, lllllllllllllllIIIIIllIIIIIIlIll));
  }
  
  private static String lIlIIIIlllIIII(String lllllllllllllllIIIIIlIlllllIlllI, String lllllllllllllllIIIIIlIlllllIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIIIIlIllllllIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIIIlIlllllIlIll.getBytes(StandardCharsets.UTF_8)), llIlIIlllIIl[6]), "DES");
      Cipher lllllllllllllllIIIIIlIllllllIIII = Cipher.getInstance("DES");
      lllllllllllllllIIIIIlIllllllIIII.init(llIlIIlllIIl[5], lllllllllllllllIIIIIlIllllllIIIl);
      return new String(lllllllllllllllIIIIIlIllllllIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIIIlIlllllIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIIIIlIlllllIllll)
    {
      lllllllllllllllIIIIIlIlllllIllll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlIIIIlllIlII(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIIIIIlIllllIIllIl;
    return ??? < i;
  }
  
  static
  {
    lIlIIIIlllIIll();
    lIlIIIIlllIIlI();
  }
  
  private static void lIlIIIIlllIIlI()
  {
    llIlIIlllIII = new String[llIlIIlllIIl[8]];
    llIlIIlllIII[llIlIIlllIIl[0]] = lIlIIIIlllIIII("8hLRJqNZVOSjhCTIlBSJesg8d3KbpLfgrOSl/thQV+xlzTSbjAGz38GSPYlWuzhm", "UrOXF");
    llIlIIlllIII[llIlIIlllIIl[1]] = lIlIIIIlllIIII("ECGRvL7lKlPid+CcglSMT3TxmB25AM3H", "JnjTN");
    llIlIIlllIII[llIlIIlllIIl[5]] = lIlIIIIlllIIIl("Cy4FOjkBLw48dgEvHSs2HC4ZNw==", "hAkNX");
  }
  
  private static void lIlIIIIlllIIll()
  {
    llIlIIlllIIl = new int[9];
    llIlIIlllIIl[0] = ((0x19 ^ 0x15) & (0x27 ^ 0x2B ^ 0xFFFFFFFF));
    llIlIIlllIIl[1] = " ".length();
    llIlIIlllIIl[2] = (0x6D ^ 0x71);
    llIlIIlllIIl[3] = (0x6B ^ 0x24 ^ 0x68 ^ 0x21);
    llIlIIlllIIl[4] = (-(0xDFE6 & 0x3BD9) & 0xFFFFFFFF & 0x405BFF);
    llIlIIlllIIl[5] = "  ".length();
    llIlIIlllIIl[6] = (0xAD ^ 0xA5);
    llIlIIlllIIl[7] = (0x6A ^ 0x56 ^ 0x5C ^ 0x0);
    llIlIIlllIIl[8] = "   ".length();
  }
  
  protected void drawGuiContainerForegroundLayer(int lllllllllllllllIIIIIllIIIIIIIlII, int lllllllllllllllIIIIIllIIIIIIIIll)
  {
    ;
    "".length();
    "".length();
  }
  
  protected void drawGuiContainerBackgroundLayer(float lllllllllllllllIIIIIlIllllllllIl, int lllllllllllllllIIIIIlIllllllllII, int lllllllllllllllIIIIIlIlllllllIll)
  {
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(craftingTableGuiTextures);
    int lllllllllllllllIIIIIlIlllllllIlI = (width - xSize) / llIlIIlllIIl[5];
    int lllllllllllllllIIIIIlIlllllllIIl = (height - ySize) / llIlIIlllIIl[5];
    lllllllllllllllIIIIIlIlllllllllI.drawTexturedModalRect(lllllllllllllllIIIIIlIlllllllIlI, lllllllllllllllIIIIIlIlllllllIIl, llIlIIlllIIl[0], llIlIIlllIIl[0], xSize, ySize);
  }
  
  public GuiCrafting(InventoryPlayer lllllllllllllllIIIIIllIIIIIlIlII, World lllllllllllllllIIIIIllIIIIIlIllI)
  {
    lllllllllllllllIIIIIllIIIIIlIlIl.<init>(lllllllllllllllIIIIIllIIIIIlIlll, lllllllllllllllIIIIIllIIIIIlIllI, BlockPos.ORIGIN);
  }
}

package net.minecraft.client.gui.inventory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.inventory.IInventory;

public class GuiChest
  extends GuiContainer
{
  public GuiChest(IInventory llllllllllllllllIIIlIlIIlIIlIlII, IInventory llllllllllllllllIIIlIlIIlIIlIIll)
  {
    llllllllllllllllIIIlIlIIlIIlIIII.<init>(new ContainerChest(llllllllllllllllIIIlIlIIlIIIllll, llllllllllllllllIIIlIlIIlIIlIIll, getMinecraftthePlayer));
    upperChestInventory = llllllllllllllllIIIlIlIIlIIIllll;
    lowerChestInventory = llllllllllllllllIIIlIlIIlIIlIIll;
    allowUserInput = lllllIlIIII[0];
    int llllllllllllllllIIIlIlIIlIIlIIlI = lllllIlIIII[1];
    int llllllllllllllllIIIlIlIIlIIlIIIl = llllllllllllllllIIIlIlIIlIIlIIlI - lllllIlIIII[2];
    inventoryRows = (llllllllllllllllIIIlIlIIlIIlIIll.getSizeInventory() / lllllIlIIII[3]);
    ySize = (llllllllllllllllIIIlIlIIlIIlIIIl + inventoryRows * lllllIlIIII[4]);
  }
  
  private static String llIIIIIIIIllI(String llllllllllllllllIIIlIlIIIlllIIIl, String llllllllllllllllIIIlIlIIIlllIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIIlIlIIIlllIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIIlIlIIIlllIIlI.getBytes(StandardCharsets.UTF_8)), lllllIlIIII[5]), "DES");
      Cipher llllllllllllllllIIIlIlIIIlllIlIl = Cipher.getInstance("DES");
      llllllllllllllllIIIlIlIIIlllIlIl.init(lllllIlIIII[9], llllllllllllllllIIIlIlIIIlllIllI);
      return new String(llllllllllllllllIIIlIlIIIlllIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllllIIIlIlIIIlllIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIIlIlIIIlllIlII)
    {
      llllllllllllllllIIIlIlIIIlllIlII.printStackTrace();
    }
    return null;
  }
  
  private static void llIIIIIIIIlll()
  {
    lllllIIllll = new String[lllllIlIIII[12]];
    lllllIIllll[lllllIlIIII[0]] = llIIIIIIIIllI("L4Jvjyi2kta9P/is3muY/LVUIUjlKpENa9wqaXq1RwlsZuGaDfz4DA==", "xSCmc");
  }
  
  static
  {
    llIIIIIIIlIII();
    llIIIIIIIIlll();
  }
  
  protected void drawGuiContainerBackgroundLayer(float llllllllllllllllIIIlIlIIlIIIIIlI, int llllllllllllllllIIIlIlIIlIIIIIIl, int llllllllllllllllIIIlIlIIlIIIIIII)
  {
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(CHEST_GUI_TEXTURE);
    int llllllllllllllllIIIlIlIIIlllllll = (width - xSize) / lllllIlIIII[9];
    int llllllllllllllllIIIlIlIIIllllllI = (height - ySize) / lllllIlIIII[9];
    llllllllllllllllIIIlIlIIIlllllIl.drawTexturedModalRect(llllllllllllllllIIIlIlIIIlllllll, llllllllllllllllIIIlIlIIIllllllI, lllllIlIIII[0], lllllIlIIII[0], xSize, inventoryRows * lllllIlIIII[4] + lllllIlIIII[10]);
    llllllllllllllllIIIlIlIIIlllllIl.drawTexturedModalRect(llllllllllllllllIIIlIlIIIlllllll, llllllllllllllllIIIlIlIIIllllllI + inventoryRows * lllllIlIIII[4] + lllllIlIIII[10], lllllIlIIII[0], lllllIlIIII[11], xSize, lllllIlIIII[8]);
  }
  
  private static void llIIIIIIIlIII()
  {
    lllllIlIIII = new int[13];
    lllllIlIIII[0] = ((94 + '«' - 232 + 147 ^ 64 + 13 - 59 + 115) & (0x42 ^ 0x1A ^ 0x41 ^ 0x28 ^ -" ".length()));
    lllllIlIIII[1] = ('' + 60 - 139 + 85 + (0x8B ^ 0x8C) - (0x68 ^ 0x71) + (0xD ^ 0x6D));
    lllllIlIIII[2] = (0x2B ^ 0x47);
    lllllIlIIII[3] = (0x95 ^ 0x9C);
    lllllIlIIII[4] = (0x52 ^ 0x40);
    lllllIlIIII[5] = (" ".length() ^ 0x3D ^ 0x34);
    lllllIlIIII[6] = (0x9A ^ 0x9C);
    lllllIlIIII[7] = (-(0xF9DF & 0x3EBE) & 0xFCDD & 0x407BFF);
    lllllIlIIII[8] = (0xC8 ^ 0xA8);
    lllllIlIIII[9] = "  ".length();
    lllllIlIIII[10] = (0x5 ^ 0x14);
    lllllIlIIII[11] = (37 + '' - -44 + 0 ^ '' + 103 - 169 + 73);
    lllllIlIIII[12] = " ".length();
  }
  
  protected void drawGuiContainerForegroundLayer(int llllllllllllllllIIIlIlIIlIIIlIIl, int llllllllllllllllIIIlIlIIlIIIlIII)
  {
    ;
    "".length();
    "".length();
  }
}

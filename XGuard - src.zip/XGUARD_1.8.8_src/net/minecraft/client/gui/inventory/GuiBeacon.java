package net.minecraft.client.gui.inventory;

import io.netty.buffer.Unpooled;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ContainerBeacon;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.potion.Potion;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;

public class GuiBeacon
  extends GuiContainer
{
  private static boolean lIIllIIlIIIllI(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIIIllIIIIlIIIIlII;
    return ??? < i;
  }
  
  private static boolean lIIllIIlIIIlIl(Object ???)
  {
    String lllllllllllllllIIIllIIIIIllllllI;
    return ??? != null;
  }
  
  public GuiBeacon(InventoryPlayer lllllllllllllllIIIllIIIlIIIlIlII, IInventory lllllllllllllllIIIllIIIlIIIlIIII)
  {
    lllllllllllllllIIIllIIIlIIIlIIlI.<init>(new ContainerBeacon(lllllllllllllllIIIllIIIlIIIlIIIl, lllllllllllllllIIIllIIIlIIIlIIII));
    tileBeacon = lllllllllllllllIIIllIIIlIIIlIIII;
    xSize = llIIlIIIIIll[1];
    ySize = llIIlIIIIIll[2];
  }
  
  private static boolean lIIllIIlIIIIIl(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIIIllIIIIlIIIlIII;
    return ??? >= i;
  }
  
  private static boolean lIIllIIlIIIIlI(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIIIllIIIIlIIIllII;
    return ??? == i;
  }
  
  static
  {
    lIIllIIIlllllI();
    lIIllIIIlllIlI();
    logger = LogManager.getLogger();
  }
  
  private static boolean lIIllIIIllllll(int ???)
  {
    short lllllllllllllllIIIllIIIIIlllllII;
    return ??? != 0;
  }
  
  private static boolean lIIllIIlIIIIII(int ???)
  {
    long lllllllllllllllIIIllIIIIIllllIII;
    return ??? >= 0;
  }
  
  public void initGui()
  {
    ;
    lllllllllllllllIIIllIIIlIIIIllIl.initGui();
    beaconConfirmButton = new ConfirmButton(llIIlIIIIIll[3], guiLeft + llIIlIIIIIll[4], guiTop + llIIlIIIIIll[5]);
    "".length();
    new CancelButton(llIIlIIIIIll[6], guiLeft + llIIlIIIIIll[7], guiTop + llIIlIIIIIll[5]);
    "".length();
    buttonsNotDrawn = llIIlIIIIIll[8];
    beaconConfirmButton.enabled = llIIlIIIIIll[0];
  }
  
  protected void drawGuiContainerBackgroundLayer(float lllllllllllllllIIIllIIIIllIIIlII, int lllllllllllllllIIIllIIIIllIIIIll, int lllllllllllllllIIIllIIIIllIIIIlI)
  {
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    mc.getTextureManager().bindTexture(beaconGuiTextures);
    int lllllllllllllllIIIllIIIIllIIIIIl = (width - xSize) / llIIlIIIIIll[9];
    int lllllllllllllllIIIllIIIIllIIIIII = (height - ySize) / llIIlIIIIIll[9];
    lllllllllllllllIIIllIIIIllIIIlIl.drawTexturedModalRect(lllllllllllllllIIIllIIIIllIIIIIl, lllllllllllllllIIIllIIIIllIIIIII, llIIlIIIIIll[0], llIIlIIIIIll[0], xSize, ySize);
    itemRender.zLevel = 100.0F;
    itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.emerald), lllllllllllllllIIIllIIIIllIIIIIl + llIIlIIIIIll[23], lllllllllllllllIIIllIIIIllIIIIII + llIIlIIIIIll[24]);
    itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.diamond), lllllllllllllllIIIllIIIIllIIIIIl + llIIlIIIIIll[23] + llIIlIIIIIll[10], lllllllllllllllIIIllIIIIllIIIIII + llIIlIIIIIll[24]);
    itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.gold_ingot), lllllllllllllllIIIllIIIIllIIIIIl + llIIlIIIIIll[23] + llIIlIIIIIll[25], lllllllllllllllIIIllIIIIllIIIIII + llIIlIIIIIll[24]);
    itemRender.renderItemAndEffectIntoGUI(new ItemStack(Items.iron_ingot), lllllllllllllllIIIllIIIIllIIIIIl + llIIlIIIIIll[23] + llIIlIIIIIll[26], lllllllllllllllIIIllIIIIllIIIIII + llIIlIIIIIll[24]);
    itemRender.zLevel = 0.0F;
  }
  
  protected void drawGuiContainerForegroundLayer(int lllllllllllllllIIIllIIIIllIlIIII, int lllllllllllllllIIIllIIIIllIIllll)
  {
    ;
    ;
    ;
    ;
    RenderHelper.disableStandardItemLighting();
    lllllllllllllllIIIllIIIIllIlIIIl.drawCenteredString(fontRendererObj, I18n.format(llIIlIIIIIIl[llIIlIIIIIll[9]], new Object[llIIlIIIIIll[0]]), llIIlIIIIIll[19], llIIlIIIIIll[20], llIIlIIIIIll[21]);
    lllllllllllllllIIIllIIIIllIlIIIl.drawCenteredString(fontRendererObj, I18n.format(llIIlIIIIIIl[llIIlIIIIIll[15]], new Object[llIIlIIIIIll[0]]), llIIlIIIIIll[22], llIIlIIIIIll[20], llIIlIIIIIll[21]);
    String lllllllllllllllIIIllIIIIllIIlIIl = buttonList.iterator();
    "".length();
    if ("   ".length() == 0) {
      return;
    }
    while (!lIIllIIlIIIlll(lllllllllllllllIIIllIIIIllIIlIIl.hasNext()))
    {
      GuiButton lllllllllllllllIIIllIIIIllIIlllI = (GuiButton)lllllllllllllllIIIllIIIIllIIlIIl.next();
      if (lIIllIIIllllll(lllllllllllllllIIIllIIIIllIIlllI.isMouseOver()))
      {
        lllllllllllllllIIIllIIIIllIIlllI.drawButtonForegroundLayer(lllllllllllllllIIIllIIIIllIIllII - guiLeft, lllllllllllllllIIIllIIIIllIIllll - guiTop);
        "".length();
        if (-" ".length() <= 0) {
          break;
        }
        return;
      }
    }
    RenderHelper.enableGUIStandardItemLighting();
  }
  
  private static String lIIllIIIlllIII(String lllllllllllllllIIIllIIIIlIlIIlIl, String lllllllllllllllIIIllIIIIlIlIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIllIIIIlIlIIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIIIllIIIIlIlIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIIllIIIIlIlIlIII = new StringBuilder();
    char[] lllllllllllllllIIIllIIIIlIlIIlll = lllllllllllllllIIIllIIIIlIlIlIIl.toCharArray();
    int lllllllllllllllIIIllIIIIlIlIIllI = llIIlIIIIIll[0];
    char lllllllllllllllIIIllIIIIlIlIIIII = lllllllllllllllIIIllIIIIlIlIIlIl.toCharArray();
    float lllllllllllllllIIIllIIIIlIIlllll = lllllllllllllllIIIllIIIIlIlIIIII.length;
    Exception lllllllllllllllIIIllIIIIlIIllllI = llIIlIIIIIll[0];
    while (lIIllIIlIIIllI(lllllllllllllllIIIllIIIIlIIllllI, lllllllllllllllIIIllIIIIlIIlllll))
    {
      char lllllllllllllllIIIllIIIIlIlIlIll = lllllllllllllllIIIllIIIIlIlIIIII[lllllllllllllllIIIllIIIIlIIllllI];
      "".length();
      "".length();
      if (" ".length() > " ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIIllIIIIlIlIlIII);
  }
  
  private static boolean lIIllIIlIIIlll(int ???)
  {
    char lllllllllllllllIIIllIIIIIllllIlI;
    return ??? == 0;
  }
  
  private static boolean lIIllIIlIIIlII(int ???)
  {
    char lllllllllllllllIIIllIIIIIlllIllI;
    return ??? > 0;
  }
  
  private static void lIIllIIIlllIlI()
  {
    llIIlIIIIIIl = new String[llIIlIIIIIll[27]];
    llIIlIIIIIIl[llIIlIIIIIll[0]] = lIIllIIIlllIII("BTwKMywDPAFoPgQwXSQ2Hy0TLjcUK10lPBA6HSl3ATcV", "qYrGY");
    llIIlIIIIIIl[llIIlIIIIIll[8]] = lIIllIIIlllIIl("aTun2OAIe3D9BRiMYOq9pA==", "kIGsF");
    llIIlIIIIIIl[llIIlIIIIIll[9]] = lIIllIIIlllIII("LQEKIEs7DQcmCjdGFjcMNAkUPA==", "YhfEe");
    llIIlIIIIIIl[llIIlIIIIIll[15]] = lIIllIIIlllIIl("+wfya+lGEpaEii/icTCFTxWKHTNoUMTy", "LJZZA");
  }
  
  public void updateScreen()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIllIIIIllllIIIl.updateScreen();
    int lllllllllllllllIIIllIIIlIIIIIIIl = tileBeacon.getField(llIIlIIIIIll[0]);
    int lllllllllllllllIIIllIIIlIIIIIIII = tileBeacon.getField(llIIlIIIIIll[8]);
    int lllllllllllllllIIIllIIIIllllllll = tileBeacon.getField(llIIlIIIIIll[9]);
    if ((lIIllIIIllllll(buttonsNotDrawn)) && (lIIllIIlIIIIII(lllllllllllllllIIIllIIIlIIIIIIIl)))
    {
      buttonsNotDrawn = llIIlIIIIIll[0];
      int lllllllllllllllIIIllIIIIlllllllI = llIIlIIIIIll[0];
      "".length();
      if ((0x9F ^ 0x9B) > (0x4E ^ 0x4A)) {
        return;
      }
      while (!lIIllIIlIIIIll(lllllllllllllllIIIllIIIIlllllllI, llIIlIIIIIll[9]))
      {
        int lllllllllllllllIIIllIIIIllllllIl = net.minecraft.tileentity.TileEntityBeacon.effectsList[lllllllllllllllIIIllIIIIlllllllI].length;
        int lllllllllllllllIIIllIIIIllllllII = lllllllllllllllIIIllIIIIllllllIl * llIIlIIIIIll[10] + (lllllllllllllllIIIllIIIIllllllIl - llIIlIIIIIll[8]) * llIIlIIIIIll[9];
        int lllllllllllllllIIIllIIIIlllllIll = llIIlIIIIIll[0];
        "".length();
        if ((0x2C ^ 0x28) <= 0) {
          return;
        }
        while (!lIIllIIlIIIIIl(lllllllllllllllIIIllIIIIlllllIll, lllllllllllllllIIIllIIIIllllllIl))
        {
          int lllllllllllllllIIIllIIIIlllllIlI = effectsListid;
          PowerButton lllllllllllllllIIIllIIIIlllllIIl = new PowerButton(lllllllllllllllIIIllIIIIlllllllI << llIIlIIIIIll[11] | lllllllllllllllIIIllIIIIlllllIlI, guiLeft + llIIlIIIIIll[12] + lllllllllllllllIIIllIIIIlllllIll * llIIlIIIIIll[13] - lllllllllllllllIIIllIIIIllllllII / llIIlIIIIIll[9], guiTop + llIIlIIIIIll[10] + lllllllllllllllIIIllIIIIlllllllI * llIIlIIIIIll[14], lllllllllllllllIIIllIIIIlllllIlI, lllllllllllllllIIIllIIIIlllllllI);
          "".length();
          if (lIIllIIlIIIIIl(lllllllllllllllIIIllIIIIlllllllI, lllllllllllllllIIIllIIIlIIIIIIIl))
          {
            enabled = llIIlIIIIIll[0];
            "".length();
            if (-"  ".length() <= 0) {}
          }
          else if (lIIllIIlIIIIlI(lllllllllllllllIIIllIIIIlllllIlI, lllllllllllllllIIIllIIIlIIIIIIII))
          {
            lllllllllllllllIIIllIIIIlllllIIl.func_146140_b(llIIlIIIIIll[8]);
          }
          lllllllllllllllIIIllIIIIlllllIll++;
        }
      }
      int lllllllllllllllIIIllIIIIlllllIII = llIIlIIIIIll[15];
      int lllllllllllllllIIIllIIIIllllIlll = net.minecraft.tileentity.TileEntityBeacon.effectsList[lllllllllllllllIIIllIIIIlllllIII].length + llIIlIIIIIll[8];
      lllllllllllllllIIIllIIIIlllllllI++;
      int lllllllllllllllIIIllIIIIllllIllI = lllllllllllllllIIIllIIIIllllIlll * llIIlIIIIIll[10] + (lllllllllllllllIIIllIIIIllllIlll - llIIlIIIIIll[8]) * llIIlIIIIIll[9];
      int lllllllllllllllIIIllIIIIllllIlIl = llIIlIIIIIll[0];
      "".length();
      if (null != null) {
        return;
      }
      while (!lIIllIIlIIIIIl(lllllllllllllllIIIllIIIIllllIlIl, lllllllllllllllIIIllIIIIllllIlll - llIIlIIIIIll[8]))
      {
        int lllllllllllllllIIIllIIIIllllIlII = effectsListid;
        PowerButton lllllllllllllllIIIllIIIIllllIIll = new PowerButton(lllllllllllllllIIIllIIIIlllllIII << llIIlIIIIIll[11] | lllllllllllllllIIIllIIIIllllIlII, guiLeft + llIIlIIIIIll[16] + lllllllllllllllIIIllIIIIllllIlIl * llIIlIIIIIll[13] - lllllllllllllllIIIllIIIIllllIllI / llIIlIIIIIll[9], guiTop + llIIlIIIIIll[17], lllllllllllllllIIIllIIIIllllIlII, lllllllllllllllIIIllIIIIlllllIII);
        "".length();
        if (lIIllIIlIIIIIl(lllllllllllllllIIIllIIIIlllllIII, lllllllllllllllIIIllIIIlIIIIIIIl))
        {
          enabled = llIIlIIIIIll[0];
          "".length();
          if ((0x62 ^ 0xE ^ 0xCD ^ 0xA5) > 0) {}
        }
        else if (lIIllIIlIIIIlI(lllllllllllllllIIIllIIIIllllIlII, lllllllllllllllIIIllIIIIllllllll))
        {
          lllllllllllllllIIIllIIIIllllIIll.func_146140_b(llIIlIIIIIll[8]);
        }
        lllllllllllllllIIIllIIIIllllIlIl++;
      }
      if (lIIllIIlIIIlII(lllllllllllllllIIIllIIIlIIIIIIII))
      {
        PowerButton lllllllllllllllIIIllIIIIllllIIlI = new PowerButton(lllllllllllllllIIIllIIIIlllllIII << llIIlIIIIIll[11] | lllllllllllllllIIIllIIIlIIIIIIII, guiLeft + llIIlIIIIIll[16] + (lllllllllllllllIIIllIIIIllllIlll - llIIlIIIIIll[8]) * llIIlIIIIIll[13] - lllllllllllllllIIIllIIIIllllIllI / llIIlIIIIIll[9], guiTop + llIIlIIIIIll[17], lllllllllllllllIIIllIIIlIIIIIIII, lllllllllllllllIIIllIIIIlllllIII);
        "".length();
        if (lIIllIIlIIIIIl(lllllllllllllllIIIllIIIIlllllIII, lllllllllllllllIIIllIIIlIIIIIIIl))
        {
          enabled = llIIlIIIIIll[0];
          "".length();
          if (null == null) {}
        }
        else if (lIIllIIlIIIIlI(lllllllllllllllIIIllIIIlIIIIIIII, lllllllllllllllIIIllIIIIllllllll))
        {
          lllllllllllllllIIIllIIIIllllIIlI.func_146140_b(llIIlIIIIIll[8]);
        }
      }
    }
    if ((lIIllIIlIIIlIl(tileBeacon.getStackInSlot(llIIlIIIIIll[0]))) && (lIIllIIlIIIlII(lllllllllllllllIIIllIIIlIIIIIIII)))
    {
      "".length();
      if ("   ".length() >= 0) {
        break label815;
      }
    }
    label815:
    llIIlIIIIIll8enabled = llIIlIIIIIll[0];
  }
  
  private static void lIIllIIIlllllI()
  {
    llIIlIIIIIll = new int[28];
    llIIlIIIIIll[0] = ((0x96 ^ 0xBD ^ 0x72 ^ 0x3) & (97 + 'Ô' - 197 + 130 ^ 94 + '' - 228 + 152 ^ -" ".length()));
    llIIlIIIIIll[1] = (75 + '' - 61 + 61);
    llIIlIIIIIll[2] = (97 + 32 - 114 + 204);
    llIIlIIIIIll[3] = (-" ".length());
    llIIlIIIIIll[4] = ((0x65 ^ 0x37) + (0x4 ^ 0x51) - (0x74 ^ 0x44) + (0xBE ^ 0x93));
    llIIlIIIIIll[5] = (0x66 ^ 0xD);
    llIIlIIIIIll[6] = (-"  ".length());
    llIIlIIIIIll[7] = (87 + '' - 175 + 92 + (22 + 28 - -59 + 73) - (14 + 105 - 47 + 109) + (0xB6 ^ 0x99));
    llIIlIIIIIll[8] = " ".length();
    llIIlIIIIIll[9] = "  ".length();
    llIIlIIIIIll[10] = (0x5F ^ 0x49);
    llIIlIIIIIll[11] = (0x1A ^ 0x5F ^ 0x1F ^ 0x52);
    llIIlIIIIIll[12] = (0xDA ^ 0x96);
    llIIlIIIIIll[13] = (0xA3 ^ 0xBB);
    llIIlIIIIIll[14] = (0xC2 ^ 0xBB ^ 0x55 ^ 0x35);
    llIIlIIIIIll[15] = "   ".length();
    llIIlIIIIIll[16] = ((0x45 ^ 0x26) + (0x35 ^ 0x4F) - (0x77 ^ 0x1B) + (0x3D ^ 0xB));
    llIIlIIIIIll[17] = ('' + 2 - 67 + 75 ^ 93 + '' - 90 + 28);
    llIIlIIIIIll[18] = (28 + 62 - -89 + 76);
    llIIlIIIIIll[19] = (0x71 ^ 0x4F);
    llIIlIIIIIll[20] = ('' + 71 - 116 + 86 ^ 118 + 25 - -9 + 14);
    llIIlIIIIIll[21] = (-(0x9F7D & 0x6C9F) & 0xFCFE & 0xE0EFFD);
    llIIlIIIIIll[22] = ((0x1C ^ 0x77) + (0xDD ^ 0x9E) - (43 + 72 - -14 + 2) + (0xED ^ 0x93));
    llIIlIIIIIll[23] = (0xED ^ 0xC7);
    llIIlIIIIIll[24] = ('¹' + 45 - 227 + 191 ^ 127 + '¤' - 278 + 162);
    llIIlIIIIIll[25] = (0x58 ^ 0x2F ^ 0x0 ^ 0x5B);
    llIIlIIIIIll[26] = (0x26 ^ 0x64);
    llIIlIIIIIll[27] = (0x10 ^ 0x6B ^ 111 + 73 - 181 + 124);
  }
  
  private static String lIIllIIIlllIIl(String lllllllllllllllIIIllIIIIlIIlIlIl, String lllllllllllllllIIIllIIIIlIIlIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIIllIIIIlIIllIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIllIIIIlIIlIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIIllIIIIlIIlIlll = Cipher.getInstance("Blowfish");
      lllllllllllllllIIIllIIIIlIIlIlll.init(llIIlIIIIIll[9], lllllllllllllllIIIllIIIIlIIllIII);
      return new String(lllllllllllllllIIIllIIIIlIIlIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIllIIIIlIIlIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIIllIIIIlIIlIllI)
    {
      lllllllllllllllIIIllIIIIlIIlIllI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIllIIlIIIIll(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllIIIllIIIIlIIIIIII;
    return ??? > i;
  }
  
  protected void actionPerformed(GuiButton lllllllllllllllIIIllIIIIlllIIIIl)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIllIIlIIIIlI(id, llIIlIIIIIll[6]))
    {
      mc.displayGuiScreen(null);
      "".length();
      if ("   ".length() >= 0) {}
    }
    else if (lIIllIIlIIIIlI(id, llIIlIIIIIll[3]))
    {
      String lllllllllllllllIIIllIIIIlllIIIII = llIIlIIIIIIl[llIIlIIIIIll[8]];
      PacketBuffer lllllllllllllllIIIllIIIIllIlllll = new PacketBuffer(Unpooled.buffer());
      "".length();
      "".length();
      mc.getNetHandler().addToSendQueue(new C17PacketCustomPayload(lllllllllllllllIIIllIIIIlllIIIII, lllllllllllllllIIIllIIIIllIlllll));
      mc.displayGuiScreen(null);
      "".length();
      if ("   ".length() <= "   ".length()) {}
    }
    else if (lIIllIIIllllll(lllllllllllllllIIIllIIIIlllIIIIl instanceof PowerButton))
    {
      if (lIIllIIIllllll(((PowerButton)lllllllllllllllIIIllIIIIlllIIIIl).func_146141_c())) {
        return;
      }
      int lllllllllllllllIIIllIIIIllIllllI = id;
      int lllllllllllllllIIIllIIIIllIlllIl = lllllllllllllllIIIllIIIIllIllllI & llIIlIIIIIll[18];
      int lllllllllllllllIIIllIIIIllIlllII = lllllllllllllllIIIllIIIIllIllllI >> llIIlIIIIIll[11];
      if (lIIllIIlIIIllI(lllllllllllllllIIIllIIIIllIlllII, llIIlIIIIIll[15]))
      {
        tileBeacon.setField(llIIlIIIIIll[8], lllllllllllllllIIIllIIIIllIlllIl);
        "".length();
        if (((0xB3 ^ 0x8A) & (0xAF ^ 0x96 ^ 0xFFFFFFFF)) <= 0) {}
      }
      else
      {
        tileBeacon.setField(llIIlIIIIIll[9], lllllllllllllllIIIllIIIIllIlllIl);
      }
      buttonList.clear();
      lllllllllllllllIIIllIIIIlllIIIlI.initGui();
      lllllllllllllllIIIllIIIIlllIIIlI.updateScreen();
    }
  }
  
  class CancelButton
    extends GuiBeacon.Button
  {
    static
    {
      llIlllIlIlII();
      llIlllIlIIIl();
    }
    
    private static void llIlllIlIIIl()
    {
      lIIIlIIIllI = new String[lIIIlIIIlll[3]];
      lIIIlIIIllI[lIIIlIIIlll[2]] = llIlllIIlIll("R6vXmm39wEG5Yst6XPGRog==", "YWuFx");
    }
    
    private static void llIlllIlIlII()
    {
      lIIIlIIIlll = new int[5];
      lIIIlIIIlll[0] = (0x44 ^ 0x34);
      lIIIlIIIlll[1] = (31 + 20 - 65384 + 17);
      lIIIlIIIlll[2] = ((0x97 ^ 0x8F ^ 0x9C ^ 0xA6) & (126 + 120 - 113 + 95 ^ 36 + 126 - 157 + 193 ^ -" ".length()));
      lIIIlIIIlll[3] = " ".length();
      lIIIlIIIlll[4] = "  ".length();
    }
    
    public CancelButton(int lllllllllllllllllIlIllIlIIIIlIII, int lllllllllllllllllIlIllIlIIIIIlll, int lllllllllllllllllIlIllIlIIIIIIII)
    {
      lllllllllllllllllIlIllIlIIIIIlIl.<init>(lllllllllllllllllIlIllIlIIIIlIII, lllllllllllllllllIlIllIlIIIIIlll, lllllllllllllllllIlIllIlIIIIIIII, GuiBeacon.beaconGuiTextures, lIIIlIIIlll[0], lIIIlIIIlll[1]);
    }
    
    private static String llIlllIIlIll(String lllllllllllllllllIlIllIIllIlllIl, String lllllllllllllllllIlIllIIllIllIll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllllIlIllIIlllIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlIllIIllIllIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllllIlIllIIlllIIlIl = Cipher.getInstance("Blowfish");
        lllllllllllllllllIlIllIIlllIIlIl.init(lIIIlIIIlll[4], lllllllllllllllllIlIllIIlllIIlll);
        return new String(lllllllllllllllllIlIllIIlllIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlIllIIllIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllllIlIllIIlllIIIll)
      {
        lllllllllllllllllIlIllIIlllIIIll.printStackTrace();
      }
      return null;
    }
    
    public void drawButtonForegroundLayer(int lllllllllllllllllIlIllIIllllIIll, int lllllllllllllllllIlIllIIllllIIlI)
    {
      ;
      ;
      ;
      drawCreativeTabHoveringText(I18n.format(lIIIlIIIllI[lIIIlIIIlll[2]], new Object[lIIIlIIIlll[2]]), lllllllllllllllllIlIllIIlllllIII, lllllllllllllllllIlIllIIllllIIlI);
    }
  }
  
  static class Button
    extends GuiButton
  {
    private static boolean lllIIlIlIllIl(int ???, int arg1)
    {
      int i;
      String lllllllllllllllIllIIlIlIIlIllIII;
      return ??? < i;
    }
    
    private static void lllIIlIlIlIII()
    {
      lIIlIlIIIlIl = new String[lIIlIlIIIllI[2]];
      lIIlIlIIIlIl[lIIlIlIIIllI[1]] = lllIIlIlIIllI("", "QYTSU");
    }
    
    private static boolean lllIIlIlIlIll(int ???)
    {
      byte lllllllllllllllIllIIlIlIIlIlIllI;
      return ??? != 0;
    }
    
    private static String lllIIlIlIIllI(String lllllllllllllllIllIIlIlIIllIlIII, String lllllllllllllllIllIIlIlIIllIIlll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIllIIlIlIIllIlIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlIlIIllIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllIIlIlIIllIlIll = new StringBuilder();
      char[] lllllllllllllllIllIIlIlIIllIlIlI = lllllllllllllllIllIIlIlIIllIIlll.toCharArray();
      int lllllllllllllllIllIIlIlIIllIlIIl = lIIlIlIIIllI[1];
      char lllllllllllllllIllIIlIlIIllIIIll = lllllllllllllllIllIIlIlIIllIlIII.toCharArray();
      double lllllllllllllllIllIIlIlIIllIIIlI = lllllllllllllllIllIIlIlIIllIIIll.length;
      int lllllllllllllllIllIIlIlIIllIIIIl = lIIlIlIIIllI[1];
      while (lllIIlIlIllIl(lllllllllllllllIllIIlIlIIllIIIIl, lllllllllllllllIllIIlIlIIllIIIlI))
      {
        char lllllllllllllllIllIIlIlIIllIlllI = lllllllllllllllIllIIlIlIIllIIIll[lllllllllllllllIllIIlIlIIllIIIIl];
        "".length();
        "".length();
        if ("  ".length() == 0) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIllIIlIlIIllIlIll);
    }
    
    private static boolean lllIIlIlIllII(int ???, int arg1)
    {
      int i;
      double lllllllllllllllIllIIlIlIIlIlllII;
      return ??? >= i;
    }
    
    static
    {
      lllIIlIlIlIlI();
      lllIIlIlIlIII();
    }
    
    private static boolean lllIIlIlIlllI(int ???)
    {
      String lllllllllllllllIllIIlIlIIlIlIlII;
      return ??? == 0;
    }
    
    private static void lllIIlIlIlIlI()
    {
      lIIlIlIIIllI = new int[7];
      lIIlIlIIIllI[0] = (94 + '' - 211 + 120 ^ 100 + '' - 100 + 4);
      lIIlIlIIIllI[1] = ((0xB9 ^ 0x8D) & (0xE ^ 0x3A ^ 0xFFFFFFFF));
      lIIlIlIIIllI[2] = " ".length();
      lIIlIlIIIllI[3] = ((0xF0 ^ 0x8A) + (0xAC ^ 0xC3) - (76 + 37 - 17 + 128) + ('±' + '³' - 243 + 97));
      lIIlIlIIIllI[4] = "  ".length();
      lIIlIlIIIllI[5] = "   ".length();
      lIIlIlIIIllI[6] = ((0x65 ^ 0x24) & (0x20 ^ 0x61 ^ 0xFFFFFFFF) ^ 0x68 ^ 0x7A);
    }
    
    public boolean func_146141_c()
    {
      ;
      return field_146142_r;
    }
    
    public void drawButton(Minecraft lllllllllllllllIllIIlIlIlIIIIlIl, int lllllllllllllllIllIIlIlIlIIIlIlI, int lllllllllllllllIllIIlIlIlIIIlIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      if (lllIIlIlIlIll(visible))
      {
        lllllllllllllllIllIIlIlIlIIIIlIl.getTextureManager().bindTexture(GuiBeacon.beaconGuiTextures);
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        if ((lllIIlIlIllII(lllllllllllllllIllIIlIlIlIIIlIlI, xPosition)) && (lllIIlIlIllII(lllllllllllllllIllIIlIlIlIIIlIIl, yPosition)) && (lllIIlIlIllIl(lllllllllllllllIllIIlIlIlIIIlIlI, xPosition + width)) && (lllIIlIlIllIl(lllllllllllllllIllIIlIlIlIIIlIIl, yPosition + height)))
        {
          "".length();
          if (null == null) {
            break label103;
          }
        }
        label103:
        lIIlIlIIIllI2hovered = lIIlIlIIIllI[1];
        int lllllllllllllllIllIIlIlIlIIIlIII = lIIlIlIIIllI[3];
        int lllllllllllllllIllIIlIlIlIIIIlll = lIIlIlIIIllI[1];
        if (lllIIlIlIlllI(enabled))
        {
          lllllllllllllllIllIIlIlIlIIIIlll += width * lIIlIlIIIllI[4];
          "".length();
          if ((85 + 56 - -13 + 16 ^ '' + '' - 215 + 76) >= "   ".length()) {}
        }
        else if (lllIIlIlIlIll(field_146142_r))
        {
          lllllllllllllllIllIIlIlIlIIIIlll += width * lIIlIlIIIllI[2];
          "".length();
          if (-" ".length() < 0) {}
        }
        else if (lllIIlIlIlIll(hovered))
        {
          lllllllllllllllIllIIlIlIlIIIIlll += width * lIIlIlIIIllI[5];
        }
        lllllllllllllllIllIIlIlIlIIIllII.drawTexturedModalRect(xPosition, yPosition, lllllllllllllllIllIIlIlIlIIIIlll, lllllllllllllllIllIIlIlIlIIIlIII, width, height);
        if (lllIIlIlIlllI(GuiBeacon.beaconGuiTextures.equals(field_146145_o))) {
          lllllllllllllllIllIIlIlIlIIIIlIl.getTextureManager().bindTexture(field_146145_o);
        }
        lllllllllllllllIllIIlIlIlIIIllII.drawTexturedModalRect(xPosition + lIIlIlIIIllI[4], yPosition + lIIlIlIIIllI[4], field_146144_p, field_146143_q, lIIlIlIIIllI[6], lIIlIlIIIllI[6]);
      }
    }
    
    protected Button(int lllllllllllllllIllIIlIlIlIIllIII, int lllllllllllllllIllIIlIlIlIIllllI, int lllllllllllllllIllIIlIlIlIIlllIl, ResourceLocation lllllllllllllllIllIIlIlIlIIlIlIl, int lllllllllllllllIllIIlIlIlIIlIlII, int lllllllllllllllIllIIlIlIlIIlIIll)
    {
      lllllllllllllllIllIIlIlIlIlIIIII.<init>(lllllllllllllllIllIIlIlIlIIllIII, lllllllllllllllIllIIlIlIlIIllllI, lllllllllllllllIllIIlIlIlIIlIllI, lIIlIlIIIllI[0], lIIlIlIIIllI[0], lIIlIlIIIlIl[lIIlIlIIIllI[1]]);
      field_146145_o = lllllllllllllllIllIIlIlIlIIlIlIl;
      field_146144_p = lllllllllllllllIllIIlIlIlIIlIlII;
      field_146143_q = lllllllllllllllIllIIlIlIlIIlIIll;
    }
    
    public void func_146140_b(boolean lllllllllllllllIllIIlIlIIllllIII)
    {
      ;
      ;
      field_146142_r = lllllllllllllllIllIIlIlIIllllIII;
    }
  }
  
  class PowerButton
    extends GuiBeacon.Button
  {
    private static void llIIIlIIlIIl()
    {
      llllIllIll = new String[llllIlllIl[5]];
      llllIllIll[llllIlllIl[0]] = llIIIlIIlIII("Ryo6", "gcsSv");
    }
    
    private static boolean llIIIlIIllIl(int ???, int arg1)
    {
      int i;
      long llllllllllllllllllIIIlllIIlIIllI;
      return ??? >= i;
    }
    
    private static boolean llIIIlIIllll(int ???, int arg1)
    {
      int i;
      Exception llllllllllllllllllIIIlllIIlIIIlI;
      return ??? < i;
    }
    
    static
    {
      llIIIlIIlIll();
      llIIIlIIlIIl();
    }
    
    public PowerButton(int llllllllllllllllllIIIlllIlIlIIlI, int llllllllllllllllllIIIlllIlIlIIIl, int llllllllllllllllllIIIlllIlIlIlll, int llllllllllllllllllIIIlllIlIlIllI, int llllllllllllllllllIIIlllIlIlIlIl)
    {
      llllllllllllllllllIIIlllIlIlIlII.<init>(llllllllllllllllllIIIlllIlIlIIlI, llllllllllllllllllIIIlllIlIlIIIl, llllllllllllllllllIIIlllIlIlIlll, GuiContainer.inventoryBackground, llllIlllIl[0] + Potion.potionTypes[llllllllllllllllllIIIlllIlIlIllI].getStatusIconIndex() % llllIlllIl[1] * llllIlllIl[2], llllIlllIl[3] + Potion.potionTypes[llllllllllllllllllIIIlllIlIlIllI].getStatusIconIndex() / llllIlllIl[1] * llllIlllIl[2]);
      field_146149_p = llllllllllllllllllIIIlllIlIlIllI;
      field_146148_q = llllllllllllllllllIIIlllIlIlIlIl;
    }
    
    private static boolean llIIIlIIlllI(int ???, int arg1)
    {
      int i;
      int llllllllllllllllllIIIlllIIIllllI;
      return ??? != i;
    }
    
    private static void llIIIlIIlIll()
    {
      llllIlllIl = new int[6];
      llllIlllIl[0] = ((0xE9 ^ 0xC4 ^ "   ".length()) & ("  ".length() ^ 0xAE ^ 0x82 ^ -" ".length()));
      llllIlllIl[1] = (0x4F ^ 0x47);
      llllIlllIl[2] = (0xD3 ^ 0xC1 ^ (0xF0 ^ 0xC5) & (0x52 ^ 0x67 ^ 0xFFFFFFFF));
      llllIlllIl[3] = ('¸' + 32 - 110 + 92);
      llllIlllIl[4] = "   ".length();
      llllIlllIl[5] = " ".length();
    }
    
    public void drawButtonForegroundLayer(int llllllllllllllllllIIIlllIlIIlIII, int llllllllllllllllllIIIlllIlIIIlll)
    {
      ;
      ;
      ;
      ;
      String llllllllllllllllllIIIlllIlIIIllI = I18n.format(Potion.potionTypes[field_146149_p].getName(), new Object[llllIlllIl[0]]);
      if ((llIIIlIIllIl(field_146148_q, llllIlllIl[4])) && (llIIIlIIlllI(field_146149_p, regenerationid))) {
        llllllllllllllllllIIIlllIlIIIllI = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllllllIIIlllIlIIIllI)).append(llllIllIll[llllIlllIl[0]]));
      }
      drawCreativeTabHoveringText(llllllllllllllllllIIIlllIlIIIllI, llllllllllllllllllIIIlllIlIIIlII, llllllllllllllllllIIIlllIlIIIlll);
    }
    
    private static String llIIIlIIlIII(String llllllllllllllllllIIIlllIIllIIlI, String llllllllllllllllllIIIlllIIllIIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllllllIIIlllIIllIIlI = new String(Base64.getDecoder().decode(llllllllllllllllllIIIlllIIllIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllllllIIIlllIIllIlIl = new StringBuilder();
      char[] llllllllllllllllllIIIlllIIllIlII = llllllllllllllllllIIIlllIIllIIIl.toCharArray();
      int llllllllllllllllllIIIlllIIllIIll = llllIlllIl[0];
      String llllllllllllllllllIIIlllIIlIllIl = llllllllllllllllllIIIlllIIllIIlI.toCharArray();
      short llllllllllllllllllIIIlllIIlIllII = llllllllllllllllllIIIlllIIlIllIl.length;
      Exception llllllllllllllllllIIIlllIIlIlIll = llllIlllIl[0];
      while (llIIIlIIllll(llllllllllllllllllIIIlllIIlIlIll, llllllllllllllllllIIIlllIIlIllII))
      {
        char llllllllllllllllllIIIlllIIlllIII = llllllllllllllllllIIIlllIIlIllIl[llllllllllllllllllIIIlllIIlIlIll];
        "".length();
        "".length();
        if (" ".length() == 0) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllllllIIIlllIIllIlIl);
    }
  }
  
  class ConfirmButton
    extends GuiBeacon.Button
  {
    public ConfirmButton(int llllllllllllllIlIIlIIlllIlllIlII, int llllllllllllllIlIIlIIlllIlllIIll, int llllllllllllllIlIIlIIlllIlllIlll)
    {
      llllllllllllllIlIIlIIlllIllllIlI.<init>(llllllllllllllIlIIlIIlllIlllIlII, llllllllllllllIlIIlIIlllIlllIIll, llllllllllllllIlIIlIIlllIlllIlll, GuiBeacon.beaconGuiTextures, lIIIlllIlIlII[0], lIIIlllIlIlII[1]);
    }
    
    private static void llIllIIlIIIlII()
    {
      lIIIlllIlIlII = new int[6];
      lIIIlllIlIlII[0] = (0x8 ^ 0x52);
      lIIIlllIlIlII[1] = (4 + 110 - -43 + 63);
      lIIIlllIlIlII[2] = (("  ".length() ^ 0x54 ^ 0x6D) & (12 + 118 - -30 + 24 ^ 27 + 78 - 98 + 124 ^ -" ".length()));
      lIIIlllIlIlII[3] = " ".length();
      lIIIlllIlIlII[4] = (0x9 ^ 0x79 ^ 0xF4 ^ 0x8C);
      lIIIlllIlIlII[5] = "  ".length();
    }
    
    private static String llIllIIIllllII(String llllllllllllllIlIIlIIlllIllIIIIl, String llllllllllllllIlIIlIIlllIllIIIII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlIIlIIlllIllIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIlIIlllIllIIIII.getBytes(StandardCharsets.UTF_8)), lIIIlllIlIlII[4]), "DES");
        Cipher llllllllllllllIlIIlIIlllIllIIIll = Cipher.getInstance("DES");
        llllllllllllllIlIIlIIlllIllIIIll.init(lIIIlllIlIlII[5], llllllllllllllIlIIlIIlllIllIIlII);
        return new String(llllllllllllllIlIIlIIlllIllIIIll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIlIIlllIllIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlIIlIIlllIllIIIlI)
      {
        llllllllllllllIlIIlIIlllIllIIIlI.printStackTrace();
      }
      return null;
    }
    
    public void drawButtonForegroundLayer(int llllllllllllllIlIIlIIlllIllIllIl, int llllllllllllllIlIIlIIlllIllIllII)
    {
      ;
      ;
      ;
      drawCreativeTabHoveringText(I18n.format(lIIIlllIlIIIl[lIIIlllIlIlII[2]], new Object[lIIIlllIlIlII[2]]), llllllllllllllIlIIlIIlllIllIlIlI, llllllllllllllIlIIlIIlllIllIllII);
    }
    
    private static void llIllIIIllllIl()
    {
      lIIIlllIlIIIl = new String[lIIIlllIlIlII[3]];
      lIIIlllIlIIIl[lIIIlllIlIlII[2]] = llIllIIIllllII("BdEVT2EirFrfdLGiyQlwkg==", "BSkIz");
    }
    
    static
    {
      llIllIIlIIIlII();
      llIllIIIllllIl();
    }
  }
}

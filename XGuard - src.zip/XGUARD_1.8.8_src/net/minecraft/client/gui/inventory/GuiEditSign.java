package net.minecraft.client.gui.inventory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.resources.I18n;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C12PacketUpdateSign;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.ChatAllowedCharacters;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;
import org.lwjgl.input.Keyboard;

public class GuiEditSign
  extends GuiScreen
{
  private static boolean lIllIlIIlllIII(int ???)
  {
    String llllllllllllllIllIllllIIIlllIIII;
    return ??? == 0;
  }
  
  private static boolean lIllIlIIllIlll(int ???)
  {
    boolean llllllllllllllIllIllllIIIlllIIlI;
    return ??? != 0;
  }
  
  protected void keyTyped(char llllllllllllllIllIllllIIllIIlIlI, int llllllllllllllIllIllllIIllIIIlIl)
    throws IOException
  {
    ;
    ;
    ;
    ;
    if (lIllIlIIlllIIl(llllllllllllllIllIllllIIllIIIlIl, lllIllIIIlll[6])) {
      editLine = (editLine - lllIllIIIlll[0] & lllIllIIIlll[7]);
    }
    if ((!lIllIlIIlllIlI(llllllllllllllIllIllllIIllIIIlIl, lllIllIIIlll[8])) || (!lIllIlIIlllIlI(llllllllllllllIllIllllIIllIIIlIl, lllIllIIIlll[9])) || (lIllIlIIlllIIl(llllllllllllllIllIllllIIllIIIlIl, lllIllIIIlll[10]))) {
      editLine = (editLine + lllIllIIIlll[0] & lllIllIIIlll[7]);
    }
    String llllllllllllllIllIllllIIllIIlIII = tileSign.signText[editLine].getUnformattedText();
    if ((lIllIlIIlllIIl(llllllllllllllIllIllllIIllIIIlIl, lllIllIIIlll[11])) && (lIllIlIIlllIll(llllllllllllllIllIllllIIllIIlIII.length()))) {
      llllllllllllllIllIllllIIllIIlIII = llllllllllllllIllIllllIIllIIlIII.substring(lllIllIIIlll[1], llllllllllllllIllIllllIIllIIlIII.length() - lllIllIIIlll[0]);
    }
    if ((lIllIlIIllIlll(ChatAllowedCharacters.isAllowedCharacter(llllllllllllllIllIllllIIllIIIllI))) && (lIllIlIIllllII(fontRendererObj.getStringWidth(String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIllIllllIIllIIlIII)).append(llllllllllllllIllIllllIIllIIIllI))), lllIllIIIlll[12]))) {
      llllllllllllllIllIllllIIllIIlIII = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIllIllllIIllIIlIII)).append(llllllllllllllIllIllllIIllIIIllI));
    }
    tileSign.signText[editLine] = new ChatComponentText(llllllllllllllIllIllllIIllIIlIII);
    if (lIllIlIIlllIIl(llllllllllllllIllIllllIIllIIIlIl, lllIllIIIlll[0])) {
      llllllllllllllIllIllllIIllIIIlll.actionPerformed(doneBtn);
    }
  }
  
  private static String lIllIlIIllIIll(String llllllllllllllIllIllllIIlIlIIIIl, String llllllllllllllIllIllllIIlIlIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIllllIIlIlIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIllllIIlIlIIIlI.getBytes(StandardCharsets.UTF_8)), lllIllIIIlll[19]), "DES");
      Cipher llllllllllllllIllIllllIIlIlIIlIl = Cipher.getInstance("DES");
      llllllllllllllIllIllllIIlIlIIlIl.init(lllIllIIIlll[2], llllllllllllllIllIllllIIlIlIIllI);
      return new String(llllllllllllllIllIllllIIlIlIIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIllllIIlIlIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIllllIIlIlIIlII)
    {
      llllllllllllllIllIllllIIlIlIIlII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIllIlIIlllllI(int ???, int arg1)
  {
    int i;
    float llllllllllllllIllIllllIIIllllllI;
    return ??? < i;
  }
  
  public GuiEditSign(TileEntitySign llllllllllllllIllIllllIIlllIIIlI)
  {
    tileSign = llllllllllllllIllIllllIIlllIIIlI;
  }
  
  private static String lIllIlIIllIIlI(String llllllllllllllIllIllllIIlIIlIIll, String llllllllllllllIllIllllIIlIIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIllllIIlIIlIIll = new String(Base64.getDecoder().decode(llllllllllllllIllIllllIIlIIlIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIllllIIlIIlIIIl = new StringBuilder();
    char[] llllllllllllllIllIllllIIlIIlIIII = llllllllllllllIllIllllIIlIIIllIl.toCharArray();
    int llllllllllllllIllIllllIIlIIIllll = lllIllIIIlll[1];
    double llllllllllllllIllIllllIIlIIIlIIl = llllllllllllllIllIllllIIlIIlIIll.toCharArray();
    double llllllllllllllIllIllllIIlIIIlIII = llllllllllllllIllIllllIIlIIIlIIl.length;
    long llllllllllllllIllIllllIIlIIIIlll = lllIllIIIlll[1];
    while (lIllIlIIlllllI(llllllllllllllIllIllllIIlIIIIlll, llllllllllllllIllIllllIIlIIIlIII))
    {
      char llllllllllllllIllIllllIIlIIlIlII = llllllllllllllIllIllllIIlIIIlIIl[llllllllllllllIllIllllIIlIIIIlll];
      "".length();
      "".length();
      if (((0xC6 ^ 0x9F) & (0x98 ^ 0xC1 ^ 0xFFFFFFFF)) != ((0x6F ^ 0x5B) & (0xB3 ^ 0x87 ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIllllIIlIIlIIIl);
  }
  
  public void onGuiClosed()
  {
    ;
    ;
    Keyboard.enableRepeatEvents(lllIllIIIlll[1]);
    NetHandlerPlayClient llllllllllllllIllIllllIIllIllIll = mc.getNetHandler();
    if (lIllIlIIllIllI(llllllllllllllIllIllllIIllIllIll)) {
      llllllllllllllIllIllllIIllIllIll.addToSendQueue(new C12PacketUpdateSign(tileSign.getPos(), tileSign.signText));
    }
    tileSign.setEditable(lllIllIIIlll[0]);
  }
  
  private static void lIllIlIIllIlII()
  {
    lllIllIIIllI = new String[lllIllIIIlll[2]];
    lllIllIIIllI[lllIllIIIlll[1]] = lIllIlIIllIIlI("BB8TaCMMBB8=", "cjzFG");
    lllIllIIIllI[lllIllIIIlll[0]] = lIllIlIIllIIll("z5sYZkKuWtkpG9Zwj6r/lg==", "BQfBO");
  }
  
  public void updateScreen()
  {
    ;
    updateCounter += lllIllIIIlll[0];
  }
  
  private static boolean lIllIlIIllllIl(Object ???, Object arg1)
  {
    Object localObject;
    double llllllllllllllIllIllllIIIlllIlII;
    return ??? == localObject;
  }
  
  private static boolean lIllIlIIllllII(int ???, int arg1)
  {
    int i;
    double llllllllllllllIllIllllIIIllllIlI;
    return ??? <= i;
  }
  
  public void drawScreen(int llllllllllllllIllIllllIIlIlllIlI, int llllllllllllllIllIllllIIlIllIIII, float llllllllllllllIllIllllIIlIlllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIllllIIlIllIIlI.drawDefaultBackground();
    llllllllllllllIllIllllIIlIllIIlI.drawCenteredString(fontRendererObj, I18n.format(lllIllIIIllI[lllIllIIIlll[0]], new Object[lllIllIIIlll[1]]), width / lllIllIIIlll[2], lllIllIIIlll[13], lllIllIIIlll[14]);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.pushMatrix();
    GlStateManager.translate(width / lllIllIIIlll[2], 0.0F, 50.0F);
    float llllllllllllllIllIllllIIlIllIlll = 93.75F;
    GlStateManager.scale(-llllllllllllllIllIllllIIlIllIlll, -llllllllllllllIllIllllIIlIllIlll, -llllllllllllllIllIllllIIlIllIlll);
    GlStateManager.rotate(180.0F, 0.0F, 1.0F, 0.0F);
    Block llllllllllllllIllIllllIIlIllIllI = tileSign.getBlockType();
    if (lIllIlIIllllIl(llllllllllllllIllIllllIIlIllIllI, Blocks.standing_sign))
    {
      float llllllllllllllIllIllllIIlIllIlIl = tileSign.getBlockMetadata() * lllIllIIIlll[15] / 16.0F;
      GlStateManager.rotate(llllllllllllllIllIllllIIlIllIlIl, 0.0F, 1.0F, 0.0F);
      GlStateManager.translate(0.0F, -1.0625F, 0.0F);
      "".length();
      if (" ".length() == " ".length()) {}
    }
    else
    {
      int llllllllllllllIllIllllIIlIllIlII = tileSign.getBlockMetadata();
      float llllllllllllllIllIllllIIlIllIIll = 0.0F;
      if (lIllIlIIlllIIl(llllllllllllllIllIllllIIlIllIlII, lllIllIIIlll[2])) {
        llllllllllllllIllIllllIIlIllIIll = 180.0F;
      }
      if (lIllIlIIlllIIl(llllllllllllllIllIllllIIlIllIlII, lllIllIIIlll[4])) {
        llllllllllllllIllIllllIIlIllIIll = 90.0F;
      }
      if (lIllIlIIlllIIl(llllllllllllllIllIllllIIlIllIlII, lllIllIIIlll[16])) {
        llllllllllllllIllIllllIIlIllIIll = -90.0F;
      }
      GlStateManager.rotate(llllllllllllllIllIllllIIlIllIIll, 0.0F, 1.0F, 0.0F);
      GlStateManager.translate(0.0F, -1.0625F, 0.0F);
    }
    if (lIllIlIIlllIII(updateCounter / lllIllIIIlll[17] % lllIllIIIlll[2])) {
      tileSign.lineBeingEdited = editLine;
    }
    TileEntityRendererDispatcher.instance.renderTileEntityAt(tileSign, -0.5D, -0.75D, -0.5D, 0.0F);
    tileSign.lineBeingEdited = lllIllIIIlll[18];
    GlStateManager.popMatrix();
    llllllllllllllIllIllllIIlIllIIlI.drawScreen(llllllllllllllIllIllllIIlIlllIlI, llllllllllllllIllIllllIIlIllIIII, llllllllllllllIllIllllIIlIlllIII);
  }
  
  private static boolean lIllIlIIlllIll(int ???)
  {
    float llllllllllllllIllIllllIIIllIlllI;
    return ??? > 0;
  }
  
  public void initGui()
  {
    ;
    buttonList.clear();
    Keyboard.enableRepeatEvents(lllIllIIIlll[0]);
    doneBtn = new GuiButton(lllIllIIIlll[1], width / lllIllIIIlll[2] - lllIllIIIlll[3], height / lllIllIIIlll[4] + lllIllIIIlll[5], I18n.format(lllIllIIIllI[lllIllIIIlll[1]], new Object[lllIllIIIlll[1]]));
    "".length();
    tileSign.setEditable(lllIllIIIlll[1]);
  }
  
  private static boolean lIllIlIIlllIIl(int ???, int arg1)
  {
    int i;
    long llllllllllllllIllIllllIIlIIIIIlI;
    return ??? == i;
  }
  
  private static boolean lIllIlIIlllIlI(int ???, int arg1)
  {
    int i;
    short llllllllllllllIllIllllIIIllIlIlI;
    return ??? != i;
  }
  
  private static void lIllIlIIllIlIl()
  {
    lllIllIIIlll = new int[20];
    lllIllIIIlll[0] = " ".length();
    lllIllIIIlll[1] = ((0x12 ^ 0x64 ^ 0x27 ^ 0x11) & (0x47 ^ 0x29 ^ 0x37 ^ 0x19 ^ -" ".length()));
    lllIllIIIlll[2] = "  ".length();
    lllIllIIIlll[3] = ("  ".length() ^ 0x61 ^ 0x7);
    lllIllIIIlll[4] = (0x6F ^ 0x6B);
    lllIllIIIlll[5] = (52 + 69 - 34 + 137 ^ 8 + 67 - -29 + 48);
    lllIllIIIlll[6] = ('§' + 43 - 205 + 166 + (0x93 ^ 0xA3) - (36 + 87 - 96 + 101) + (0x1B ^ 0x76));
    lllIllIIIlll[7] = "   ".length();
    lllIllIIIlll[8] = (37 + 118 - 103 + 81 + (0x42 ^ 0x2A) - (0x4D ^ 0x18) + (0xB4 ^ 0x8C));
    lllIllIIIlll[9] = (0x6C ^ 0x35 ^ 0x4A ^ 0xF);
    lllIllIIIlll[10] = ((0xA9 ^ 0x8E) + (0x20 ^ 0x2B) - -(0x81 ^ 0x8A) + (0xD ^ 0x52));
    lllIllIIIlll[11] = (4 + 124 - 31 + 37 ^ 29 + 6 - -80 + 21);
    lllIllIIIlll[12] = (0xA ^ 0x50);
    lllIllIIIlll[13] = (0x52 ^ 0x7A);
    lllIllIIIlll[14] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lllIllIIIlll[15] = (0xB3F9 & 0x4D6E);
    lllIllIIIlll[16] = (110 + 61 - 53 + 66 ^ '' + 76 - 86 + 50);
    lllIllIIIlll[17] = (0x90 ^ 0xB2 ^ 0x37 ^ 0x13);
    lllIllIIIlll[18] = (-" ".length());
    lllIllIIIlll[19] = (0x56 ^ 0x5E);
  }
  
  private static boolean lIllIlIIllIllI(Object ???)
  {
    boolean llllllllllllllIllIllllIIIllllIII;
    return ??? != null;
  }
  
  static
  {
    lIllIlIIllIlIl();
    lIllIlIIllIlII();
  }
  
  protected void actionPerformed(GuiButton llllllllllllllIllIllllIIllIlIIlI)
    throws IOException
  {
    ;
    ;
    if ((lIllIlIIllIlll(enabled)) && (lIllIlIIlllIII(id)))
    {
      tileSign.markDirty();
      mc.displayGuiScreen(null);
    }
  }
}

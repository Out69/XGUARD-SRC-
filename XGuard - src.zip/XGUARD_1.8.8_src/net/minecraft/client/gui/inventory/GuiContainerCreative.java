package net.minecraft.client.gui.inventory;

import com.google.common.collect.Lists;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.achievement.GuiAchievements;
import net.minecraft.client.gui.achievement.GuiStats;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.InventoryEffectRenderer;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemEnchantedBook;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;
import net.minecraft.util.RegistryNamespaced;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class GuiContainerCreative
  extends InventoryEffectRenderer
{
  private static boolean lIllIIllIIllI(int ???, int arg1)
  {
    int i;
    float llllllllllllllllIIlIlIlIlIlIIIIl;
    return ??? <= i;
  }
  
  public void onGuiClosed()
  {
    ;
    llllllllllllllllIIlIllIIIIlIlIII.onGuiClosed();
    if ((lIllIIllIIIII(mc.thePlayer)) && (lIllIIllIIIII(mc.thePlayer.inventory))) {
      mc.thePlayer.inventoryContainer.removeCraftingFromCrafters(field_147059_E);
    }
    Keyboard.enableRepeatEvents(lllIlIIIlll[0]);
  }
  
  private static boolean lIllIIlIlllll(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllllIIlIlIlIlIIIlIll;
    return ??? != i;
  }
  
  public GuiContainerCreative(EntityPlayer llllllllllllllllIIlIllIIIllIIIIl)
  {
    llllllllllllllllIIlIllIIIllIIIII.<init>(new ContainerCreative(llllllllllllllllIIlIllIIIllIIIIl));
    openContainer = inventorySlots;
    allowUserInput = lllIlIIIlll[1];
    ySize = lllIlIIIlll[3];
    xSize = lllIlIIIlll[4];
  }
  
  private static boolean lIllIIllIIlII(int ???)
  {
    char llllllllllllllllIIlIlIlIlIIlIIll;
    return ??? >= 0;
  }
  
  private static boolean lIllIIllIIIII(Object ???)
  {
    String llllllllllllllllIIlIlIlIlIIlllll;
    return ??? != null;
  }
  
  public int getSelectedTabIndex()
  {
    return selectedTabIndex;
  }
  
  protected void mouseReleased(int llllllllllllllllIIlIlIllllIlIllI, int llllllllllllllllIIlIlIllllIIlllI, int llllllllllllllllIIlIlIllllIlIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllIIlIlllII(llllllllllllllllIIlIlIllllIlIlII))
    {
      int llllllllllllllllIIlIlIllllIlIIll = llllllllllllllllIIlIlIllllIlIllI - guiLeft;
      int llllllllllllllllIIlIlIllllIlIIlI = llllllllllllllllIIlIlIllllIIlllI - guiTop;
      llllllllllllllllIIlIlIllllIIlIII = (llllllllllllllllIIlIlIllllIIIlll = CreativeTabs.creativeTabArray).length;
      llllllllllllllllIIlIlIllllIIlIIl = lllIlIIIlll[0];
      "".length();
      if ("   ".length() < ((0x86 ^ 0xA3) & (0x8D ^ 0xA8 ^ 0xFFFFFFFF))) {
        return;
      }
      while (!lIllIIllIIIll(llllllllllllllllIIlIlIllllIIlIIl, llllllllllllllllIIlIlIllllIIlIII))
      {
        CreativeTabs llllllllllllllllIIlIlIllllIlIIIl = llllllllllllllllIIlIlIllllIIIlll[llllllllllllllllIIlIlIllllIIlIIl];
        if (lIllIIllIIIlI(llllllllllllllllIIlIlIllllIlIlll.func_147049_a(llllllllllllllllIIlIlIllllIlIIIl, llllllllllllllllIIlIlIllllIlIIll, llllllllllllllllIIlIlIllllIlIIlI)))
        {
          llllllllllllllllIIlIlIllllIlIlll.setCurrentCreativeTab(llllllllllllllllIIlIlIllllIlIIIl);
          return;
        }
        llllllllllllllllIIlIlIllllIIlIIl++;
      }
    }
    llllllllllllllllIIlIlIllllIlIlll.mouseReleased(llllllllllllllllIIlIlIllllIlIllI, llllllllllllllllIIlIlIllllIIlllI, llllllllllllllllIIlIlIllllIlIlII);
  }
  
  protected boolean renderCreativeInventoryHoveringText(CreativeTabs llllllllllllllllIIlIlIllIIIlIIII, int llllllllllllllllIIlIlIllIIIIllll, int llllllllllllllllIIlIlIllIIIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllllIIlIlIllIIIlIlII = llllllllllllllllIIlIlIllIIIlIIII.getTabColumn();
    int llllllllllllllllIIlIlIllIIIlIIll = lllIlIIIlll[35] * llllllllllllllllIIlIlIllIIIlIlII;
    int llllllllllllllllIIlIlIllIIIlIIlI = lllIlIIIlll[0];
    if (lIllIIlIlllIl(llllllllllllllllIIlIlIllIIIlIlII, lllIlIIIlll[7]))
    {
      llllllllllllllllIIlIlIllIIIlIIll = xSize - lllIlIIIlll[35] + lllIlIIIlll[8];
      "".length();
      if (null != null) {
        return ('' + 127 - 144 + 59 ^ 47 + 65 - 49 + 69) & (0xA2 ^ 0x9D ^ 0x11 ^ 0x16 ^ -" ".length());
      }
    }
    else if (lIllIIlllIllI(llllllllllllllllIIlIlIllIIIlIlII))
    {
      llllllllllllllllIIlIlIllIIIlIIll += llllllllllllllllIIlIlIllIIIlIlII;
    }
    if (lIllIIllIIIlI(llllllllllllllllIIlIlIllIIIlIIII.isTabInFirstRow()))
    {
      llllllllllllllllIIlIlIllIIIlIIlI -= 32;
      "".length();
      if (" ".length() >= "  ".length()) {
        return (0x50 ^ 0x1B) & (0xFD ^ 0xB6 ^ 0xFFFFFFFF) & ((0x15 ^ 0x4E) & (0x5E ^ 0x5 ^ 0xFFFFFFFF) ^ 0xFFFFFFFF);
      }
    }
    else
    {
      llllllllllllllllIIlIlIllIIIlIIlI += ySize;
    }
    if (lIllIIllIIIlI(llllllllllllllllIIlIlIllIIIlIIIl.isPointInRegion(llllllllllllllllIIlIlIllIIIlIIll + lllIlIIIlll[10], llllllllllllllllIIlIlIllIIIlIIlI + lllIlIIIlll[10], lllIlIIIlll[37], lllIlIIIlll[21], llllllllllllllllIIlIlIllIIIIllll, llllllllllllllllIIlIlIllIIIIlllI)))
    {
      llllllllllllllllIIlIlIllIIIlIIIl.drawCreativeTabHoveringText(I18n.format(llllllllllllllllIIlIlIllIIIlIIII.getTranslatedTabLabel(), new Object[lllIlIIIlll[0]]), llllllllllllllllIIlIlIllIIIIllll, llllllllllllllllIIlIlIllIIIIlllI);
      return lllIlIIIlll[1];
    }
    return lllIlIIIlll[0];
  }
  
  private void updateCreativeSearch()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ContainerCreative llllllllllllllllIIlIllIIIIIlIlII = (ContainerCreative)inventorySlots;
    itemList.clear();
    char llllllllllllllllIIlIllIIIIIIlIIl = Item.itemRegistry.iterator();
    "".length();
    if (" ".length() > " ".length()) {
      return;
    }
    while (!lIllIIlIlllII(llllllllllllllllIIlIllIIIIIIlIIl.hasNext()))
    {
      Item llllllllllllllllIIlIllIIIIIlIIll = (Item)llllllllllllllllIIlIllIIIIIIlIIl.next();
      if ((lIllIIllIIIII(llllllllllllllllIIlIllIIIIIlIIll)) && (lIllIIllIIIII(llllllllllllllllIIlIllIIIIIlIIll.getCreativeTab()))) {
        llllllllllllllllIIlIllIIIIIlIIll.getSubItems(llllllllllllllllIIlIllIIIIIlIIll, null, itemList);
      }
    }
    long llllllllllllllllIIlIllIIIIIIlIII = (llllllllllllllllIIlIllIIIIIIIlll = Enchantment.enchantmentsBookList).length;
    llllllllllllllllIIlIllIIIIIIlIIl = lllIlIIIlll[0];
    "".length();
    if ((0x33 ^ 0x37) > (0x38 ^ 0x3C)) {
      return;
    }
    while (!lIllIIllIIIll(llllllllllllllllIIlIllIIIIIIlIIl, llllllllllllllllIIlIllIIIIIIlIII))
    {
      Enchantment llllllllllllllllIIlIllIIIIIlIIlI = llllllllllllllllIIlIllIIIIIIIlll[llllllllllllllllIIlIllIIIIIIlIIl];
      if ((lIllIIllIIIII(llllllllllllllllIIlIllIIIIIlIIlI)) && (lIllIIllIIIII(type))) {
        Items.enchanted_book.getAll(llllllllllllllllIIlIllIIIIIlIIlI, itemList);
      }
      llllllllllllllllIIlIllIIIIIIlIIl++;
    }
    Iterator<ItemStack> llllllllllllllllIIlIllIIIIIlIIIl = itemList.iterator();
    String llllllllllllllllIIlIllIIIIIlIIII = searchField.getText().toLowerCase();
    "".length();
    if (-"  ".length() >= 0) {
      return;
    }
    while (!lIllIIlIlllII(llllllllllllllllIIlIllIIIIIlIIIl.hasNext()))
    {
      ItemStack llllllllllllllllIIlIllIIIIIIllll = (ItemStack)llllllllllllllllIIlIllIIIIIlIIIl.next();
      boolean llllllllllllllllIIlIllIIIIIIlllI = lllIlIIIlll[0];
      llllllllllllllllIIlIllIIIIIIIlIl = llllllllllllllllIIlIllIIIIIIllll.getTooltip(mc.thePlayer, mc.gameSettings.advancedItemTooltips).iterator();
      "".length();
      if ("   ".length() <= " ".length()) {
        return;
      }
      while (!lIllIIlIlllII(llllllllllllllllIIlIllIIIIIIIlIl.hasNext()))
      {
        String llllllllllllllllIIlIllIIIIIIllIl = (String)llllllllllllllllIIlIllIIIIIIIlIl.next();
        if (lIllIIllIIIlI(EnumChatFormatting.getTextWithoutFormattingCodes(llllllllllllllllIIlIllIIIIIIllIl).toLowerCase().contains(llllllllllllllllIIlIllIIIIIlIIII)))
        {
          llllllllllllllllIIlIllIIIIIIlllI = lllIlIIIlll[1];
          "".length();
          if (-"  ".length() <= 0) {
            break;
          }
          return;
        }
      }
      if (lIllIIlIlllII(llllllllllllllllIIlIllIIIIIIlllI)) {
        llllllllllllllllIIlIllIIIIIlIIIl.remove();
      }
    }
    currentScroll = 0.0F;
    llllllllllllllllIIlIllIIIIIlIlII.scrollTo(0.0F);
  }
  
  protected void mouseClicked(int llllllllllllllllIIlIlIllllllIIIl, int llllllllllllllllIIlIlIlllllIlIIl, int llllllllllllllllIIlIlIlllllIllll)
    throws IOException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllIIlIlllII(llllllllllllllllIIlIlIlllllIllll))
    {
      int llllllllllllllllIIlIlIlllllIlllI = llllllllllllllllIIlIlIllllllIIIl - guiLeft;
      int llllllllllllllllIIlIlIlllllIllIl = llllllllllllllllIIlIlIlllllIlIIl - guiTop;
      llllllllllllllllIIlIlIlllllIIIll = (llllllllllllllllIIlIlIlllllIIIlI = CreativeTabs.creativeTabArray).length;
      llllllllllllllllIIlIlIlllllIIlII = lllIlIIIlll[0];
      "".length();
      if (-(0xA2 ^ 0xBF ^ 0x4C ^ 0x55) >= 0) {
        return;
      }
      while (!lIllIIllIIIll(llllllllllllllllIIlIlIlllllIIlII, llllllllllllllllIIlIlIlllllIIIll))
      {
        CreativeTabs llllllllllllllllIIlIlIlllllIllII = llllllllllllllllIIlIlIlllllIIIlI[llllllllllllllllIIlIlIlllllIIlII];
        if (lIllIIllIIIlI(llllllllllllllllIIlIlIllllllIIlI.func_147049_a(llllllllllllllllIIlIlIlllllIllII, llllllllllllllllIIlIlIlllllIlllI, llllllllllllllllIIlIlIlllllIllIl))) {
          return;
        }
        llllllllllllllllIIlIlIlllllIIlII++;
      }
    }
    llllllllllllllllIIlIlIllllllIIlI.mouseClicked(llllllllllllllllIIlIlIllllllIIIl, llllllllllllllllIIlIlIlllllIlIIl, llllllllllllllllIIlIlIlllllIllll);
  }
  
  private static boolean lIllIIllIIlIl(int ???, int arg1)
  {
    int i;
    String llllllllllllllllIIlIlIlIlIlIIlIl;
    return ??? < i;
  }
  
  public void updateScreen()
  {
    ;
    if (lIllIIlIlllII(mc.playerController.isInCreativeMode())) {
      mc.displayGuiScreen(new GuiInventory(mc.thePlayer));
    }
    llllllllllllllllIIlIllIIIlIlllII.updateActivePotionEffects();
  }
  
  protected boolean func_147049_a(CreativeTabs llllllllllllllllIIlIlIllIIlIllII, int llllllllllllllllIIlIlIllIIlIIlII, int llllllllllllllllIIlIlIllIIlIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllllIIlIlIllIIlIlIIl = llllllllllllllllIIlIlIllIIlIllII.getTabColumn();
    int llllllllllllllllIIlIlIllIIlIlIII = lllIlIIIlll[35] * llllllllllllllllIIlIlIllIIlIlIIl;
    int llllllllllllllllIIlIlIllIIlIIlll = lllIlIIIlll[0];
    if (lIllIIlIlllIl(llllllllllllllllIIlIlIllIIlIlIIl, lllIlIIIlll[7]))
    {
      llllllllllllllllIIlIlIllIIlIlIII = xSize - lllIlIIIlll[35] + lllIlIIIlll[8];
      "".length();
      if ("   ".length() != "   ".length()) {
        return (0x86 ^ 0xA8) & (0x4B ^ 0x65 ^ 0xFFFFFFFF);
      }
    }
    else if (lIllIIlllIllI(llllllllllllllllIIlIlIllIIlIlIIl))
    {
      llllllllllllllllIIlIlIllIIlIlIII += llllllllllllllllIIlIlIllIIlIlIIl;
    }
    if (lIllIIllIIIlI(llllllllllllllllIIlIlIllIIlIllII.isTabInFirstRow()))
    {
      llllllllllllllllIIlIlIllIIlIIlll -= 32;
      "".length();
      if (((0x8C ^ 0xB3 ^ 0x51 ^ 0x5B) & (0x81 ^ 0xC7 ^ 0xCA ^ 0xB9 ^ -" ".length())) != 0) {
        return (124 + 28 - -16 + 40 ^ 100 + 125 - 211 + 182) & (47 + 61 - 81 + 141 ^ 0 + 56 - -60 + 72 ^ -" ".length());
      }
    }
    else
    {
      llllllllllllllllIIlIlIllIIlIIlll += ySize;
    }
    if ((lIllIIllIIIll(llllllllllllllllIIlIlIllIIlIIlII, llllllllllllllllIIlIlIllIIlIlIII)) && (lIllIIllIIllI(llllllllllllllllIIlIlIllIIlIIlII, llllllllllllllllIIlIlIllIIlIlIII + lllIlIIIlll[35])) && (lIllIIllIIIll(llllllllllllllllIIlIlIllIIlIlIlI, llllllllllllllllIIlIlIllIIlIIlll)) && (lIllIIllIIllI(llllllllllllllllIIlIlIllIIlIlIlI, llllllllllllllllIIlIlIllIIlIIlll + lllIlIIIlll[36]))) {
      return lllIlIIIlll[1];
    }
    return lllIlIIIlll[0];
  }
  
  private static boolean lIllIIlIllllI(Object ???)
  {
    byte llllllllllllllllIIlIlIlIlIIllIIl;
    return ??? == null;
  }
  
  private static boolean lIllIIlllIlll(int ???)
  {
    boolean llllllllllllllllIIlIlIlIlIIlIIIl;
    return ??? < 0;
  }
  
  private static boolean lIllIIlIlllII(int ???)
  {
    short llllllllllllllllIIlIlIlIlIIlIlIl;
    return ??? == 0;
  }
  
  private static boolean lIllIIllIIIlI(int ???)
  {
    byte llllllllllllllllIIlIlIlIlIIlIlll;
    return ??? != 0;
  }
  
  protected void renderToolTip(ItemStack llllllllllllllllIIlIlIllIlIllIII, int llllllllllllllllIIlIlIllIlIlIlll, int llllllllllllllllIIlIlIllIlIlIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllIIlIlllIl(selectedTabIndex, CreativeTabs.tabAllSearch.getTabIndex()))
    {
      List<String> llllllllllllllllIIlIlIllIlIlllll = llllllllllllllllIIlIlIllIlIllIII.getTooltip(mc.thePlayer, mc.gameSettings.advancedItemTooltips);
      CreativeTabs llllllllllllllllIIlIlIllIlIllllI = llllllllllllllllIIlIlIllIlIllIII.getItem().getCreativeTab();
      if ((lIllIIlIllllI(llllllllllllllllIIlIlIllIlIllllI)) && (lIllIIllIIIIl(llllllllllllllllIIlIlIllIlIllIII.getItem(), Items.enchanted_book)))
      {
        Map<Integer, Integer> llllllllllllllllIIlIlIllIlIlllIl = EnchantmentHelper.getEnchantments(llllllllllllllllIIlIlIllIlIllIII);
        if (lIllIIlIlllIl(llllllllllllllllIIlIlIllIlIlllIl.size(), lllIlIIIlll[1]))
        {
          Enchantment llllllllllllllllIIlIlIllIlIlllII = Enchantment.getEnchantmentById(((Integer)llllllllllllllllIIlIlIllIlIlllIl.keySet().iterator().next()).intValue());
          llllllllllllllllIIlIlIllIlIIllll = (llllllllllllllllIIlIlIllIlIIlllI = CreativeTabs.creativeTabArray).length;
          llllllllllllllllIIlIlIllIlIlIIII = lllIlIIIlll[0];
          "".length();
          if (null != null) {
            return;
          }
          while (!lIllIIllIIIll(llllllllllllllllIIlIlIllIlIlIIII, llllllllllllllllIIlIlIllIlIIllll))
          {
            CreativeTabs llllllllllllllllIIlIlIllIlIllIll = llllllllllllllllIIlIlIllIlIIlllI[llllllllllllllllIIlIlIllIlIlIIII];
            if (lIllIIllIIIlI(llllllllllllllllIIlIlIllIlIllIll.hasRelevantEnchantmentType(type)))
            {
              llllllllllllllllIIlIlIllIlIllllI = llllllllllllllllIIlIlIllIlIllIll;
              "".length();
              if (-(0x34 ^ 0x30) < 0) {
                break;
              }
              return;
            }
            llllllllllllllllIIlIlIllIlIlIIII++;
          }
        }
      }
      if (lIllIIllIIIII(llllllllllllllllIIlIlIllIlIllllI)) {
        llllllllllllllllIIlIlIllIlIlllll.add(lllIlIIIlll[1], String.valueOf(new StringBuilder().append(EnumChatFormatting.BOLD).append(EnumChatFormatting.BLUE).append(I18n.format(llllllllllllllllIIlIlIllIlIllllI.getTranslatedTabLabel(), new Object[lllIlIIIlll[0]]))));
      }
      int llllllllllllllllIIlIlIllIlIllIlI = lllIlIIIlll[0];
      "".length();
      if ("  ".length() < 0) {
        return;
      }
      while (!lIllIIllIIIll(llllllllllllllllIIlIlIllIlIllIlI, llllllllllllllllIIlIlIllIlIlllll.size()))
      {
        if (lIllIIlIlllII(llllllllllllllllIIlIlIllIlIllIlI))
        {
          new StringBuilder();
          "".length();
          "".length();
          if (" ".length() != 0) {}
        }
        else
        {
          new StringBuilder();
          "".length();
        }
        llllllllllllllllIIlIlIllIlIllIlI++;
      }
      llllllllllllllllIIlIlIllIllIIIll.drawHoveringText(llllllllllllllllIIlIlIllIlIlllll, llllllllllllllllIIlIlIllIlIlIlll, llllllllllllllllIIlIlIllIlIlIllI);
      "".length();
      if ((0x79 ^ 0x7D) != ((0xA ^ 0x2D) & (0x22 ^ 0x5 ^ 0xFFFFFFFF))) {}
    }
    else
    {
      llllllllllllllllIIlIlIllIllIIIll.renderToolTip(llllllllllllllllIIlIlIllIlIllIII, llllllllllllllllIIlIlIllIlIlIlll, llllllllllllllllIIlIlIllIlIlIllI);
    }
  }
  
  private static String lIllIIlIlIlII(String llllllllllllllllIIlIlIlIlIllIllI, String llllllllllllllllIIlIlIlIlIllIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIlIlIlIlIlllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIlIlIlIlIllIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIIlIlIlIlIlllIII = Cipher.getInstance("Blowfish");
      llllllllllllllllIIlIlIlIlIlllIII.init(lllIlIIIlll[8], llllllllllllllllIIlIlIlIlIlllIIl);
      return new String(llllllllllllllllIIlIlIlIlIlllIII.doFinal(Base64.getDecoder().decode(llllllllllllllllIIlIlIlIlIllIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIlIlIlIlIllIlll)
    {
      llllllllllllllllIIlIlIlIlIllIlll.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIllIIlIllIll();
    lIllIIlIlIlll();
    creativeInventoryTabs = new ResourceLocation(lllIlIIIlIl[lllIlIIIlll[0]]);
    field_147060_v = new InventoryBasic(lllIlIIIlIl[lllIlIIIlll[1]], lllIlIIIlll[1], lllIlIIIlll[2]);
  }
  
  protected void handleMouseClick(Slot llllllllllllllllIIlIllIIIlIlIIII, int llllllllllllllllIIlIllIIIIllllIl, int llllllllllllllllIIlIllIIIIllllII, int llllllllllllllllIIlIllIIIIlllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    field_147057_D = lllIlIIIlll[1];
    if (lIllIIlIlllIl(llllllllllllllllIIlIllIIIIlllIll, lllIlIIIlll[1]))
    {
      "".length();
      if ((0xC5 ^ 0x9B ^ 0x14 ^ 0x4E) > " ".length()) {
        break label60;
      }
    }
    label60:
    boolean llllllllllllllllIIlIllIIIlIIllII = lllIlIIIlll[0];
    if ((lIllIIlIlllIl(llllllllllllllllIIlIllIIIlIIllll, lllIlIIIlll[5])) && (lIllIIlIlllII(llllllllllllllllIIlIllIIIIlllIll)))
    {
      "".length();
      if (" ".length() == " ".length()) {
        break label110;
      }
    }
    label110:
    int llllllllllllllllIIlIllIIIIlllIll = llllllllllllllllIIlIllIIIIlllIll;
    if ((lIllIIlIllllI(llllllllllllllllIIlIllIIIlIlIIII)) && (lIllIIlIlllll(selectedTabIndex, CreativeTabs.tabInventory.getTabIndex())) && (lIllIIlIlllll(llllllllllllllllIIlIllIIIIlllIll, lllIlIIIlll[7])))
    {
      InventoryPlayer llllllllllllllllIIlIllIIIlIIlIll = mc.thePlayer.inventory;
      if (lIllIIllIIIII(llllllllllllllllIIlIllIIIlIIlIll.getItemStack()))
      {
        if (lIllIIlIlllII(llllllllllllllllIIlIllIIIIllllII))
        {
          "".length();
          mc.playerController.sendPacketDropItem(llllllllllllllllIIlIllIIIlIIlIll.getItemStack());
          llllllllllllllllIIlIllIIIlIIlIll.setItemStack(null);
        }
        if (lIllIIlIlllIl(llllllllllllllllIIlIllIIIIllllII, lllIlIIIlll[1]))
        {
          ItemStack llllllllllllllllIIlIllIIIlIIlIlI = llllllllllllllllIIlIllIIIlIIlIll.getItemStack().splitStack(lllIlIIIlll[1]);
          "".length();
          mc.playerController.sendPacketDropItem(llllllllllllllllIIlIllIIIlIIlIlI);
          if (lIllIIlIlllII(getItemStackstackSize))
          {
            llllllllllllllllIIlIllIIIlIIlIll.setItemStack(null);
            "".length();
            if ("   ".length() != ((0x45 ^ 0x69) & (0x9B ^ 0xB7 ^ 0xFFFFFFFF))) {}
          }
        }
      }
    }
    else if ((lIllIIllIIIIl(llllllllllllllllIIlIllIIIlIlIIII, field_147064_C)) && (lIllIIllIIIlI(llllllllllllllllIIlIllIIIlIIllII)))
    {
      int llllllllllllllllIIlIllIIIlIIlIIl = lllIlIIIlll[0];
      "".length();
      if ((68 + 34 - -29 + 13 ^ 76 + 79 - 108 + 101) < -" ".length()) {
        return;
      }
      while (!lIllIIllIIIll(llllllllllllllllIIlIllIIIlIIlIIl, mc.thePlayer.inventoryContainer.getInventory().size())) {
        mc.playerController.sendSlotPacket(null, llllllllllllllllIIlIllIIIlIIlIIl);
      }
      "".length();
      if (((0x47 ^ 0x4F) & (0xC ^ 0x4 ^ 0xFFFFFFFF)) == 0) {}
    }
    else if (lIllIIlIlllIl(selectedTabIndex, CreativeTabs.tabInventory.getTabIndex()))
    {
      if (lIllIIllIIIIl(llllllllllllllllIIlIllIIIlIlIIII, field_147064_C))
      {
        mc.thePlayer.inventory.setItemStack(null);
        "".length();
        if (((11 + 45 - 4 + 100 ^ 127 + 53 - 120 + 75) & ('«' + '' - 247 + 111 ^ 118 + 67 - 33 + 11 ^ -" ".length())) != (0xE4 ^ 0x86 ^ 0xA3 ^ 0xC5)) {}
      }
      else if ((lIllIIlIlllIl(llllllllllllllllIIlIllIIIIlllIll, lllIlIIIlll[6])) && (lIllIIllIIIII(llllllllllllllllIIlIllIIIlIlIIII)) && (lIllIIllIIIlI(llllllllllllllllIIlIllIIIlIlIIII.getHasStack())))
      {
        if (lIllIIlIlllII(llllllllllllllllIIlIllIIIIllllII))
        {
          "".length();
          if (" ".length() != "   ".length()) {
            break label658;
          }
        }
        label658:
        ItemStack llllllllllllllllIIlIllIIIlIIlIII = lllIlIIIlll[1].decrStackSize(llllllllllllllllIIlIllIIIlIlIIII.getStack().getMaxStackSize());
        "".length();
        mc.playerController.sendPacketDropItem(llllllllllllllllIIlIllIIIlIIlIII);
        "".length();
        if (null == null) {}
      }
      else if ((lIllIIlIlllIl(llllllllllllllllIIlIllIIIIlllIll, lllIlIIIlll[6])) && (lIllIIllIIIII(mc.thePlayer.inventory.getItemStack())))
      {
        "".length();
        mc.playerController.sendPacketDropItem(mc.thePlayer.inventory.getItemStack());
        mc.thePlayer.inventory.setItemStack(null);
        "".length();
        if ((0x7C ^ 0x7 ^ 0x5B ^ 0x25) > 0) {}
      }
      else
      {
        if (lIllIIlIllllI(llllllllllllllllIIlIllIIIlIlIIII))
        {
          "".length();
          if (-" ".length() < " ".length()) {
            break label883;
          }
        }
        label883:
        "".length();
        mc.thePlayer.inventoryContainer.detectAndSendChanges();
        "".length();
        if (-"  ".length() < 0) {}
      }
    }
    else if ((lIllIIlIlllll(llllllllllllllllIIlIllIIIIlllIll, lllIlIIIlll[7])) && (lIllIIllIIIIl(inventory, field_147060_v)))
    {
      InventoryPlayer llllllllllllllllIIlIllIIIlIIIlll = mc.thePlayer.inventory;
      ItemStack llllllllllllllllIIlIllIIIlIIIllI = llllllllllllllllIIlIllIIIlIIIlll.getItemStack();
      ItemStack llllllllllllllllIIlIllIIIlIIIlIl = llllllllllllllllIIlIllIIIlIlIIII.getStack();
      if (lIllIIlIlllIl(llllllllllllllllIIlIllIIIIlllIll, lllIlIIIlll[8]))
      {
        if ((lIllIIllIIIII(llllllllllllllllIIlIllIIIlIIIlIl)) && (lIllIIllIIlII(llllllllllllllllIIlIllIIIIllllII)) && (lIllIIllIIlIl(llllllllllllllllIIlIllIIIIllllII, lllIlIIIlll[9])))
        {
          ItemStack llllllllllllllllIIlIllIIIlIIIlII = llllllllllllllllIIlIllIIIlIIIlIl.copy();
          stackSize = llllllllllllllllIIlIllIIIlIIIlII.getMaxStackSize();
          mc.thePlayer.inventory.setInventorySlotContents(llllllllllllllllIIlIllIIIIllllII, llllllllllllllllIIlIllIIIlIIIlII);
          mc.thePlayer.inventoryContainer.detectAndSendChanges();
        }
        return;
      }
      if (lIllIIlIlllIl(llllllllllllllllIIlIllIIIIlllIll, lllIlIIIlll[10]))
      {
        if ((lIllIIlIllllI(llllllllllllllllIIlIllIIIlIIIlll.getItemStack())) && (lIllIIllIIIlI(llllllllllllllllIIlIllIIIlIlIIII.getHasStack())))
        {
          ItemStack llllllllllllllllIIlIllIIIlIIIIll = llllllllllllllllIIlIllIIIlIlIIII.getStack().copy();
          stackSize = llllllllllllllllIIlIllIIIlIIIIll.getMaxStackSize();
          llllllllllllllllIIlIllIIIlIIIlll.setItemStack(llllllllllllllllIIlIllIIIlIIIIll);
        }
        return;
      }
      if (lIllIIlIlllIl(llllllllllllllllIIlIllIIIIlllIll, lllIlIIIlll[6]))
      {
        if (lIllIIllIIIII(llllllllllllllllIIlIllIIIlIIIlIl))
        {
          ItemStack llllllllllllllllIIlIllIIIlIIIIlI = llllllllllllllllIIlIllIIIlIIIlIl.copy();
          if (lIllIIlIlllII(llllllllllllllllIIlIllIIIIllllII))
          {
            "".length();
            if ("   ".length() > 0) {
              break label1197;
            }
          }
          label1197:
          lllIlIIIlll1stackSize = llllllllllllllllIIlIllIIIlIIIIlI.getMaxStackSize();
          "".length();
          mc.playerController.sendPacketDropItem(llllllllllllllllIIlIllIIIlIIIIlI);
        }
        return;
      }
      if ((lIllIIllIIIII(llllllllllllllllIIlIllIIIlIIIllI)) && (lIllIIllIIIII(llllllllllllllllIIlIllIIIlIIIlIl)) && (lIllIIllIIIlI(llllllllllllllllIIlIllIIIlIIIllI.isItemEqual(llllllllllllllllIIlIllIIIlIIIlIl))))
      {
        if (lIllIIlIlllII(llllllllllllllllIIlIllIIIIllllII))
        {
          if (lIllIIllIIIlI(llllllllllllllllIIlIllIIIlIIllII))
          {
            stackSize = llllllllllllllllIIlIllIIIlIIIllI.getMaxStackSize();
            "".length();
            if ((0xAD ^ 0xA9) >= 0) {}
          }
          else if (lIllIIllIIlIl(stackSize, llllllllllllllllIIlIllIIIlIIIllI.getMaxStackSize()))
          {
            stackSize += lllIlIIIlll[1];
            "".length();
            if ("   ".length() != 0) {}
          }
        }
        else if (lIllIIllIIllI(stackSize, lllIlIIIlll[1]))
        {
          llllllllllllllllIIlIllIIIlIIIlll.setItemStack(null);
          "".length();
          if (((0xF9 ^ 0xBB ^ 0x7E ^ 0x5C) & (63 + 78 - 38 + 98 ^ '' + '' - 201 + 91 ^ -" ".length())) <= 0) {}
        }
        else
        {
          stackSize -= lllIlIIIlll[1];
          "".length();
          if (null == null) {}
        }
      }
      else if ((lIllIIllIIIII(llllllllllllllllIIlIllIIIlIIIlIl)) && (lIllIIlIllllI(llllllllllllllllIIlIllIIIlIIIllI)))
      {
        llllllllllllllllIIlIllIIIlIIIlll.setItemStack(ItemStack.copyItemStack(llllllllllllllllIIlIllIIIlIIIlIl));
        llllllllllllllllIIlIllIIIlIIIllI = llllllllllllllllIIlIllIIIlIIIlll.getItemStack();
        if (lIllIIllIIIlI(llllllllllllllllIIlIllIIIlIIllII))
        {
          stackSize = llllllllllllllllIIlIllIIIlIIIllI.getMaxStackSize();
          "".length();
          if ((27 + 9 - 11 + 130 ^ '' + 81 - 124 + 47) != 0) {}
        }
      }
      else
      {
        llllllllllllllllIIlIllIIIlIIIlll.setItemStack(null);
        "".length();
        if (" ".length() != -" ".length()) {}
      }
    }
    else
    {
      if (lIllIIlIllllI(llllllllllllllllIIlIllIIIlIlIIII))
      {
        "".length();
        if ("  ".length() != 0) {
          break label1602;
        }
      }
      label1602:
      "".length();
      if (lIllIIlIlllIl(Container.getDragEvent(llllllllllllllllIIlIllIIIIllllII), lllIlIIIlll[8]))
      {
        int llllllllllllllllIIlIllIIIlIIIIIl = lllIlIIIlll[0];
        "".length();
        if (-" ".length() >= 0) {
          return;
        }
        while (!lIllIIllIIIll(llllllllllllllllIIlIllIIIlIIIIIl, lllIlIIIlll[9])) {
          mc.playerController.sendSlotPacket(inventorySlots.getSlot(lllIlIIIlll[2] + llllllllllllllllIIlIllIIIlIIIIIl).getStack(), lllIlIIIlll[11] + llllllllllllllllIIlIllIIIlIIIIIl);
        }
        "".length();
        if ("   ".length() != 0) {}
      }
      else if (lIllIIllIIIII(llllllllllllllllIIlIllIIIlIlIIII))
      {
        ItemStack llllllllllllllllIIlIllIIIlIIIIII = inventorySlots.getSlot(slotNumber).getStack();
        mc.playerController.sendSlotPacket(llllllllllllllllIIlIllIIIlIIIIII, slotNumber - inventorySlots.inventorySlots.size() + lllIlIIIlll[9] + lllIlIIIlll[11]);
      }
    }
  }
  
  protected void updateActivePotionEffects()
  {
    ;
    ;
    int llllllllllllllllIIlIllIIIIllIIlI = guiLeft;
    llllllllllllllllIIlIllIIIIllIIIl.updateActivePotionEffects();
    if ((lIllIIllIIIII(searchField)) && (lIllIIlIlllll(guiLeft, llllllllllllllllIIlIllIIIIllIIlI))) {
      searchField.xPosition = (guiLeft + lllIlIIIlll[12]);
    }
  }
  
  private static String lIllIIlIlIlIl(String llllllllllllllllIIlIlIlIllIlIIll, String llllllllllllllllIIlIlIlIllIlIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIlIlIlIllIlIIll = new String(Base64.getDecoder().decode(llllllllllllllllIIlIlIlIllIlIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIIlIlIlIllIlIllI = new StringBuilder();
    char[] llllllllllllllllIIlIlIlIllIlIlIl = llllllllllllllllIIlIlIlIllIlIIlI.toCharArray();
    int llllllllllllllllIIlIlIlIllIlIlII = lllIlIIIlll[0];
    double llllllllllllllllIIlIlIlIllIIlllI = llllllllllllllllIIlIlIlIllIlIIll.toCharArray();
    String llllllllllllllllIIlIlIlIllIIllIl = llllllllllllllllIIlIlIlIllIIlllI.length;
    String llllllllllllllllIIlIlIlIllIIllII = lllIlIIIlll[0];
    while (lIllIIllIIlIl(llllllllllllllllIIlIlIlIllIIllII, llllllllllllllllIIlIlIlIllIIllIl))
    {
      char llllllllllllllllIIlIlIlIllIllIIl = llllllllllllllllIIlIlIlIllIIlllI[llllllllllllllllIIlIlIlIllIIllII];
      "".length();
      "".length();
      if ("   ".length() < " ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIIlIlIlIllIlIllI);
  }
  
  private static boolean lIllIIllIIIIl(Object ???, Object arg1)
  {
    Object localObject;
    boolean llllllllllllllllIIlIlIlIlIIllIll;
    return ??? == localObject;
  }
  
  private void setCurrentCreativeTab(CreativeTabs llllllllllllllllIIlIlIlllIlllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllllIIlIlIlllIllIlll = selectedTabIndex;
    selectedTabIndex = llllllllllllllllIIlIlIlllIlllIII.getTabIndex();
    ContainerCreative llllllllllllllllIIlIlIlllIllIllI = (ContainerCreative)inventorySlots;
    dragSplittingSlots.clear();
    itemList.clear();
    llllllllllllllllIIlIlIlllIlllIII.displayAllReleventItems(itemList);
    if (lIllIIllIIIIl(llllllllllllllllIIlIlIlllIlllIII, CreativeTabs.tabInventory))
    {
      Container llllllllllllllllIIlIlIlllIllIlIl = mc.thePlayer.inventoryContainer;
      if (lIllIIlIllllI(field_147063_B)) {
        field_147063_B = inventorySlots;
      }
      inventorySlots = Lists.newArrayList();
      int llllllllllllllllIIlIlIlllIllIlII = lllIlIIIlll[0];
      "".length();
      if ((0x5C ^ 0x62 ^ 0x7B ^ 0x40) <= 0) {
        return;
      }
      while (!lIllIIllIIIll(llllllllllllllllIIlIlIlllIllIlII, inventorySlots.size()))
      {
        Slot llllllllllllllllIIlIlIlllIllIIll = new CreativeSlot((Slot)inventorySlots.get(llllllllllllllllIIlIlIlllIllIlII), llllllllllllllllIIlIlIlllIllIlII);
        "".length();
        if ((lIllIIllIIIll(llllllllllllllllIIlIlIlllIllIlII, lllIlIIIlll[7])) && (lIllIIllIIlIl(llllllllllllllllIIlIlIlllIllIlII, lllIlIIIlll[9])))
        {
          int llllllllllllllllIIlIlIlllIllIIlI = llllllllllllllllIIlIlIlllIllIlII - lllIlIIIlll[7];
          int llllllllllllllllIIlIlIlllIllIIIl = llllllllllllllllIIlIlIlllIllIIlI / lllIlIIIlll[8];
          int llllllllllllllllIIlIlIlllIllIIII = llllllllllllllllIIlIlIlllIllIIlI % lllIlIIIlll[8];
          xDisplayPosition = (lllIlIIIlll[9] + llllllllllllllllIIlIlIlllIllIIIl * lllIlIIIlll[20]);
          yDisplayPosition = (lllIlIIIlll[13] + llllllllllllllllIIlIlIlllIllIIII * lllIlIIIlll[21]);
          "".length();
          if (null == null) {}
        }
        else if ((lIllIIllIIlII(llllllllllllllllIIlIlIlllIllIlII)) && (lIllIIllIIlIl(llllllllllllllllIIlIlIlllIllIlII, lllIlIIIlll[7])))
        {
          yDisplayPosition = lllIlIIIlll[22];
          xDisplayPosition = lllIlIIIlll[22];
          "".length();
          if (-(0x63 ^ 0x66) < 0) {}
        }
        else if (lIllIIllIIlIl(llllllllllllllllIIlIlIlllIllIlII, inventorySlots.size()))
        {
          int llllllllllllllllIIlIlIlllIlIllll = llllllllllllllllIIlIlIlllIllIlII - lllIlIIIlll[9];
          int llllllllllllllllIIlIlIlllIlIlllI = llllllllllllllllIIlIlIlllIlIllll % lllIlIIIlll[9];
          int llllllllllllllllIIlIlIlllIlIllIl = llllllllllllllllIIlIlIlllIlIllll / lllIlIIIlll[9];
          xDisplayPosition = (lllIlIIIlll[9] + llllllllllllllllIIlIlIlllIlIlllI * lllIlIIIlll[23]);
          if (lIllIIllIIIll(llllllllllllllllIIlIlIlllIllIlII, lllIlIIIlll[11]))
          {
            yDisplayPosition = lllIlIIIlll[24];
            "".length();
            if (-" ".length() <= 0) {}
          }
          else
          {
            yDisplayPosition = (lllIlIIIlll[20] + llllllllllllllllIIlIlIlllIlIllIl * lllIlIIIlll[23]);
          }
        }
        llllllllllllllllIIlIlIlllIllIlII++;
      }
      field_147064_C = new Slot(field_147060_v, lllIlIIIlll[0], lllIlIIIlll[25], lllIlIIIlll[24]);
      "".length();
      "".length();
      if (" ".length() != 0) {}
    }
    else if (lIllIIlIlllIl(llllllllllllllllIIlIlIlllIllIlll, CreativeTabs.tabInventory.getTabIndex()))
    {
      inventorySlots = field_147063_B;
      field_147063_B = null;
    }
    if (lIllIIllIIIII(searchField)) {
      if (lIllIIllIIIIl(llllllllllllllllIIlIlIlllIlllIII, CreativeTabs.tabAllSearch))
      {
        searchField.setVisible(lllIlIIIlll[1]);
        searchField.setCanLoseFocus(lllIlIIIlll[0]);
        searchField.setFocused(lllIlIIIlll[1]);
        searchField.setText(lllIlIIIlIl[lllIlIIIlll[10]]);
        llllllllllllllllIIlIlIlllIlIllII.updateCreativeSearch();
        "".length();
        if (((0x4D ^ 0x16 ^ 0xD7 ^ 0xB8) & (65 + 83 - 5 + 35 ^ 9 + 110 - 96 + 111 ^ -" ".length())) > -" ".length()) {}
      }
      else
      {
        searchField.setVisible(lllIlIIIlll[0]);
        searchField.setCanLoseFocus(lllIlIIIlll[1]);
        searchField.setFocused(lllIlIIIlll[0]);
      }
    }
    currentScroll = 0.0F;
    llllllllllllllllIIlIlIlllIllIllI.scrollTo(0.0F);
  }
  
  protected void func_147051_a(CreativeTabs llllllllllllllllIIlIlIlIlllllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllIIlIlllIl(llllllllllllllllIIlIlIlIlllllllI.getTabIndex(), selectedTabIndex))
    {
      "".length();
      if (((37 + 89 - -23 + 49 ^ 73 + 97 - 136 + 102) & (0x27 ^ 0x2D ^ 0xFD ^ 0xB9 ^ -" ".length())) == 0) {
        break label78;
      }
    }
    label78:
    boolean llllllllllllllllIIlIlIlIllllllIl = lllIlIIIlll[0];
    boolean llllllllllllllllIIlIlIlIllllllII = llllllllllllllllIIlIlIlIlllllllI.isTabInFirstRow();
    int llllllllllllllllIIlIlIlIlllllIll = llllllllllllllllIIlIlIlIlllllllI.getTabColumn();
    int llllllllllllllllIIlIlIlIlllllIlI = llllllllllllllllIIlIlIlIlllllIll * lllIlIIIlll[35];
    int llllllllllllllllIIlIlIlIlllllIIl = lllIlIIIlll[0];
    int llllllllllllllllIIlIlIlIlllllIII = guiLeft + lllIlIIIlll[35] * llllllllllllllllIIlIlIlIlllllIll;
    int llllllllllllllllIIlIlIlIllllIlll = guiTop;
    int llllllllllllllllIIlIlIlIllllIllI = lllIlIIIlll[36];
    if (lIllIIllIIIlI(llllllllllllllllIIlIlIlIllllllIl)) {
      llllllllllllllllIIlIlIlIlllllIIl += 32;
    }
    if (lIllIIlIlllIl(llllllllllllllllIIlIlIlIlllllIll, lllIlIIIlll[7]))
    {
      llllllllllllllllIIlIlIlIlllllIII = guiLeft + xSize - lllIlIIIlll[35];
      "".length();
      if (((0xE2 ^ 0x99 ^ 0x73 ^ 0x5D) & (0x25 ^ 0x4B ^ 0x5B ^ 0x60 ^ -" ".length())) == 0) {}
    }
    else if (lIllIIlllIllI(llllllllllllllllIIlIlIlIlllllIll))
    {
      llllllllllllllllIIlIlIlIlllllIII += llllllllllllllllIIlIlIlIlllllIll;
    }
    if (lIllIIllIIIlI(llllllllllllllllIIlIlIlIllllllII))
    {
      llllllllllllllllIIlIlIlIllllIlll -= 28;
      "".length();
      if (-" ".length() != "  ".length()) {}
    }
    else
    {
      llllllllllllllllIIlIlIlIlllllIIl += 64;
      llllllllllllllllIIlIlIlIllllIlll += ySize - lllIlIIIlll[6];
    }
    GlStateManager.disableLighting();
    llllllllllllllllIIlIlIlIllllIlII.drawTexturedModalRect(llllllllllllllllIIlIlIlIlllllIII, llllllllllllllllIIlIlIlIllllIlll, llllllllllllllllIIlIlIlIlllllIlI, llllllllllllllllIIlIlIlIlllllIIl, lllIlIIIlll[35], llllllllllllllllIIlIlIlIllllIllI);
    zLevel = 100.0F;
    itemRender.zLevel = 100.0F;
    llllllllllllllllIIlIlIlIlllllIII += 6;
    if (lIllIIllIIIlI(llllllllllllllllIIlIlIlIllllllII))
    {
      "".length();
      if (null == null) {
        break label368;
      }
    }
    label368:
    llllllllllllllllIIlIlIlIllllIlll = lllIlIIIlll[1] + lllIlIIIlll[17];
    GlStateManager.enableLighting();
    GlStateManager.enableRescaleNormal();
    ItemStack llllllllllllllllIIlIlIlIllllIlIl = llllllllllllllllIIlIlIlIlllllllI.getIconItemStack();
    itemRender.renderItemAndEffectIntoGUI(llllllllllllllllIIlIlIlIllllIlIl, llllllllllllllllIIlIlIlIlllllIII, llllllllllllllllIIlIlIlIllllIlll);
    itemRender.renderItemOverlays(fontRendererObj, llllllllllllllllIIlIlIlIllllIlIl, llllllllllllllllIIlIlIlIlllllIII, llllllllllllllllIIlIlIlIllllIlll);
    GlStateManager.disableLighting();
    itemRender.zLevel = 0.0F;
    zLevel = 0.0F;
  }
  
  private static boolean lIllIIlllIllI(int ???)
  {
    int llllllllllllllllIIlIlIlIlIIIllll;
    return ??? > 0;
  }
  
  private static boolean lIllIIllIIIll(int ???, int arg1)
  {
    int i;
    short llllllllllllllllIIlIlIlIlIlIlIIl;
    return ??? >= i;
  }
  
  private static String lIllIIlIlIIll(String llllllllllllllllIIlIlIlIllIIIIll, String llllllllllllllllIIlIlIlIllIIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIlIlIlIllIIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIlIlIlIllIIIIII.getBytes(StandardCharsets.UTF_8)), lllIlIIIlll[18]), "DES");
      Cipher llllllllllllllllIIlIlIlIllIIIlIl = Cipher.getInstance("DES");
      llllllllllllllllIIlIlIlIllIIIlIl.init(lllIlIIIlll[8], llllllllllllllllIIlIlIlIllIIIllI);
      return new String(llllllllllllllllIIlIlIlIllIIIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllllIIlIlIlIllIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIlIlIlIllIIIlII)
    {
      llllllllllllllllIIlIlIlIllIIIlII.printStackTrace();
    }
    return null;
  }
  
  protected void keyTyped(char llllllllllllllllIIlIllIIIIIlllll, int llllllllllllllllIIlIllIIIIlIIIIl)
    throws IOException
  {
    ;
    ;
    ;
    if (lIllIIlIlllll(selectedTabIndex, CreativeTabs.tabAllSearch.getTabIndex()))
    {
      if (lIllIIllIIIlI(GameSettings.isKeyDown(mc.gameSettings.keyBindChat)))
      {
        llllllllllllllllIIlIllIIIIlIIIII.setCurrentCreativeTab(CreativeTabs.tabAllSearch);
        "".length();
        if (((0x3 ^ 0x17) & (0xD3 ^ 0xC7 ^ 0xFFFFFFFF)) >= -" ".length()) {}
      }
      else
      {
        llllllllllllllllIIlIllIIIIlIIIII.keyTyped(llllllllllllllllIIlIllIIIIlIIIlI, llllllllllllllllIIlIllIIIIlIIIIl);
        "".length();
        if (((0x1E ^ 0x11) & (0x60 ^ 0x6F ^ 0xFFFFFFFF)) == 0) {}
      }
    }
    else
    {
      if (lIllIIllIIIlI(field_147057_D))
      {
        field_147057_D = lllIlIIIlll[0];
        searchField.setText(lllIlIIIlIl[lllIlIIIlll[8]]);
      }
      if (lIllIIlIlllII(llllllllllllllllIIlIllIIIIlIIIII.checkHotbarKeys(llllllllllllllllIIlIllIIIIlIIIIl))) {
        if (lIllIIllIIIlI(searchField.textboxKeyTyped(llllllllllllllllIIlIllIIIIlIIIlI, llllllllllllllllIIlIllIIIIlIIIIl)))
        {
          llllllllllllllllIIlIllIIIIlIIIII.updateCreativeSearch();
          "".length();
          if ("  ".length() <= (0xC3 ^ 0x88 ^ 0xEC ^ 0xA3)) {}
        }
        else
        {
          llllllllllllllllIIlIllIIIIlIIIII.keyTyped(llllllllllllllllIIlIllIIIIlIIIlI, llllllllllllllllIIlIllIIIIlIIIIl);
        }
      }
    }
  }
  
  public void drawScreen(int llllllllllllllllIIlIlIlllIIIlIIl, int llllllllllllllllIIlIlIllIlllllII, float llllllllllllllllIIlIlIllIllllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    boolean llllllllllllllllIIlIlIlllIIIIllI = Mouse.isButtonDown(lllIlIIIlll[0]);
    int llllllllllllllllIIlIlIlllIIIIlIl = guiLeft;
    int llllllllllllllllIIlIlIlllIIIIlII = guiTop;
    int llllllllllllllllIIlIlIlllIIIIIll = llllllllllllllllIIlIlIlllIIIIlIl + lllIlIIIlll[26];
    int llllllllllllllllIIlIlIlllIIIIIlI = llllllllllllllllIIlIlIlllIIIIlII + lllIlIIIlll[23];
    int llllllllllllllllIIlIlIlllIIIIIIl = llllllllllllllllIIlIlIlllIIIIIll + lllIlIIIlll[27];
    int llllllllllllllllIIlIlIlllIIIIIII = llllllllllllllllIIlIlIlllIIIIIlI + lllIlIIIlll[24];
    if ((lIllIIlIlllII(wasClicking)) && (lIllIIllIIIlI(llllllllllllllllIIlIlIlllIIIIllI)) && (lIllIIllIIIll(llllllllllllllllIIlIlIlllIIIlIIl, llllllllllllllllIIlIlIlllIIIIIll)) && (lIllIIllIIIll(llllllllllllllllIIlIlIllIlllllII, llllllllllllllllIIlIlIlllIIIIIlI)) && (lIllIIllIIlIl(llllllllllllllllIIlIlIlllIIIlIIl, llllllllllllllllIIlIlIlllIIIIIIl)) && (lIllIIllIIlIl(llllllllllllllllIIlIlIllIlllllII, llllllllllllllllIIlIlIlllIIIIIII))) {
      isScrolling = llllllllllllllllIIlIlIlllIIIlIlI.needsScrollBars();
    }
    if (lIllIIlIlllII(llllllllllllllllIIlIlIlllIIIIllI)) {
      isScrolling = lllIlIIIlll[0];
    }
    wasClicking = llllllllllllllllIIlIlIlllIIIIllI;
    if (lIllIIllIIIlI(isScrolling))
    {
      currentScroll = ((llllllllllllllllIIlIlIllIlllllII - llllllllllllllllIIlIlIlllIIIIIlI - 7.5F) / (llllllllllllllllIIlIlIlllIIIIIII - llllllllllllllllIIlIlIlllIIIIIlI - 15.0F));
      currentScroll = MathHelper.clamp_float(currentScroll, 0.0F, 1.0F);
      ((ContainerCreative)inventorySlots).scrollTo(currentScroll);
    }
    llllllllllllllllIIlIlIlllIIIlIlI.drawScreen(llllllllllllllllIIlIlIlllIIIlIIl, llllllllllllllllIIlIlIllIlllllII, llllllllllllllllIIlIlIllIllllIll);
    boolean llllllllllllllllIIlIlIllIlllIIIl = (llllllllllllllllIIlIlIllIlllIIII = CreativeTabs.creativeTabArray).length;
    double llllllllllllllllIIlIlIllIlllIIlI = lllIlIIIlll[0];
    "".length();
    if (-" ".length() > "   ".length()) {
      return;
    }
    while (!lIllIIllIIIll(llllllllllllllllIIlIlIllIlllIIlI, llllllllllllllllIIlIlIllIlllIIIl))
    {
      CreativeTabs llllllllllllllllIIlIlIllIlllllll = llllllllllllllllIIlIlIllIlllIIII[llllllllllllllllIIlIlIllIlllIIlI];
      if (lIllIIllIIIlI(llllllllllllllllIIlIlIlllIIIlIlI.renderCreativeInventoryHoveringText(llllllllllllllllIIlIlIllIlllllll, llllllllllllllllIIlIlIlllIIIlIIl, llllllllllllllllIIlIlIllIlllllII)))
      {
        "".length();
        if (((0xEF ^ 0xAD ^ 0x67 ^ 0x2) & (0x9B ^ 0x90 ^ 0x82 ^ 0xAE ^ -" ".length())) != " ".length()) {
          break;
        }
        return;
      }
      llllllllllllllllIIlIlIllIlllIIlI++;
    }
    if ((lIllIIllIIIII(field_147064_C)) && (lIllIIlIlllIl(selectedTabIndex, CreativeTabs.tabInventory.getTabIndex())) && (lIllIIllIIIlI(llllllllllllllllIIlIlIlllIIIlIlI.isPointInRegion(field_147064_C.xDisplayPosition, field_147064_C.yDisplayPosition, lllIlIIIlll[28], lllIlIIIlll[28], llllllllllllllllIIlIlIlllIIIlIIl, llllllllllllllllIIlIlIllIlllllII)))) {
      llllllllllllllllIIlIlIlllIIIlIlI.drawCreativeTabHoveringText(I18n.format(lllIlIIIlIl[lllIlIIIlll[6]], new Object[lllIlIIIlll[0]]), llllllllllllllllIIlIlIlllIIIlIIl, llllllllllllllllIIlIlIllIlllllII);
    }
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.disableLighting();
  }
  
  public void handleMouseInput()
    throws IOException
  {
    ;
    ;
    ;
    llllllllllllllllIIlIlIlllIIlllll.handleMouseInput();
    int llllllllllllllllIIlIlIlllIIllllI = Mouse.getEventDWheel();
    if ((lIllIIllIIIlI(llllllllllllllllIIlIlIlllIIllllI)) && (lIllIIllIIIlI(llllllllllllllllIIlIlIlllIIlllII.needsScrollBars())))
    {
      int llllllllllllllllIIlIlIlllIIlllIl = inventorySlots).itemList.size() / lllIlIIIlll[9] - lllIlIIIlll[7];
      if (lIllIIlllIllI(llllllllllllllllIIlIlIlllIIllllI)) {
        llllllllllllllllIIlIlIlllIIllllI = lllIlIIIlll[1];
      }
      if (lIllIIlllIlll(llllllllllllllllIIlIlIlllIIllllI)) {
        llllllllllllllllIIlIlIlllIIllllI = lllIlIIIlll[17];
      }
      currentScroll = ((float)(currentScroll - llllllllllllllllIIlIlIlllIIllllI / llllllllllllllllIIlIlIlllIIlllIl));
      currentScroll = MathHelper.clamp_float(currentScroll, 0.0F, 1.0F);
      ((ContainerCreative)inventorySlots).scrollTo(currentScroll);
    }
  }
  
  protected void drawGuiContainerBackgroundLayer(float llllllllllllllllIIlIlIllIlIIIlII, int llllllllllllllllIIlIlIllIlIIIIll, int llllllllllllllllIIlIlIllIlIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    RenderHelper.enableGUIStandardItemLighting();
    CreativeTabs llllllllllllllllIIlIlIllIlIIIIIl = CreativeTabs.creativeTabArray[selectedTabIndex];
    char llllllllllllllllIIlIlIllIIllIllI = (llllllllllllllllIIlIlIllIIllIlIl = CreativeTabs.creativeTabArray).length;
    float llllllllllllllllIIlIlIllIIllIlll = lllIlIIIlll[0];
    "".length();
    if ((0 + 27 - -72 + 79 ^ 47 + 46 - 63 + 152) < "  ".length()) {
      return;
    }
    while (!lIllIIllIIIll(llllllllllllllllIIlIlIllIIllIlll, llllllllllllllllIIlIlIllIIllIllI))
    {
      CreativeTabs llllllllllllllllIIlIlIllIlIIIIII = llllllllllllllllIIlIlIllIIllIlIl[llllllllllllllllIIlIlIllIIllIlll];
      mc.getTextureManager().bindTexture(creativeInventoryTabs);
      if (lIllIIlIlllll(llllllllllllllllIIlIlIllIlIIIIII.getTabIndex(), selectedTabIndex)) {
        llllllllllllllllIIlIlIllIIllllII.func_147051_a(llllllllllllllllIIlIlIllIlIIIIII);
      }
      llllllllllllllllIIlIlIllIIllIlll++;
    }
    mc.getTextureManager().bindTexture(new ResourceLocation(String.valueOf(new StringBuilder(lllIlIIIlIl[lllIlIIIlll[7]]).append(llllllllllllllllIIlIlIllIlIIIIIl.getBackgroundImageName()))));
    llllllllllllllllIIlIlIllIIllllII.drawTexturedModalRect(guiLeft, guiTop, lllIlIIIlll[0], lllIlIIIlll[0], xSize, ySize);
    searchField.drawTextBox();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    int llllllllllllllllIIlIlIllIIllllll = guiLeft + lllIlIIIlll[26];
    int llllllllllllllllIIlIlIllIIlllllI = guiTop + lllIlIIIlll[23];
    int llllllllllllllllIIlIlIllIIllllIl = llllllllllllllllIIlIlIllIIlllllI + lllIlIIIlll[24];
    mc.getTextureManager().bindTexture(creativeInventoryTabs);
    if (lIllIIllIIIlI(llllllllllllllllIIlIlIllIlIIIIIl.shouldHidePlayerInventory()))
    {
      if (lIllIIllIIIlI(llllllllllllllllIIlIlIllIIllllII.needsScrollBars()))
      {
        "".length();
        if (-"   ".length() < 0) {
          break label344;
        }
      }
      label344:
      llllllllllllllllIIlIlIllIIllllll.drawTexturedModalRect(llllllllllllllllIIlIlIllIIlllllI + (int)((llllllllllllllllIIlIlIllIIllllIl - llllllllllllllllIIlIlIllIIlllllI - lllIlIIIlll[29]) * currentScroll), lllIlIIIlll[30], lllIlIIIlll[0] + lllIlIIIlll[31], lllIlIIIlll[0], lllIlIIIlll[31], lllIlIIIlll[15]);
    }
    llllllllllllllllIIlIlIllIIllllII.func_147051_a(llllllllllllllllIIlIlIllIlIIIIIl);
    if (lIllIIllIIIIl(llllllllllllllllIIlIlIllIlIIIIIl, CreativeTabs.tabInventory)) {
      GuiInventory.drawEntityOnScreen(guiLeft + lllIlIIIlll[32], guiTop + lllIlIIIlll[2], lllIlIIIlll[33], guiLeft + lllIlIIIlll[32] - llllllllllllllllIIlIlIllIIlllIll, guiTop + lllIlIIIlll[2] - lllIlIIIlll[34] - llllllllllllllllIIlIlIllIlIIIIlI, mc.thePlayer);
    }
  }
  
  private static void lIllIIlIlIlll()
  {
    lllIlIIIlIl = new String[lllIlIIIlll[13]];
    lllIlIIIlIl[lllIlIIIlll[0]] = lIllIIlIlIIll("uol8Zzbd4JKGxmAVCUQxxfYS0yOa762npQUeudkSFb6Ju+wq1kNgAluwGZ3fQstQlrK5qJX34cA=", "YrCNw");
    lllIlIIIlIl[lllIlIIIlll[1]] = lIllIIlIlIlII("v8PLh04Q2FY=", "cEeoY");
    lllIlIIIlIl[lllIlIIIlll[8]] = lIllIIlIlIlII("f9XKtOI/xAo=", "ZPwJt");
    lllIlIIIlIl[lllIlIIIlll[10]] = lIllIIlIlIlIl("", "tEBZt");
    lllIlIIIlIl[lllIlIIIlll[6]] = lIllIIlIlIlII("9kZTaspJJmtYz+n4vUsgezc1PZu+spUX", "SwpFD");
    lllIlIIIlIl[lllIlIIIlll[7]] = lIllIIlIlIlII("65os7xOBwu7cZ4xVACh6rvUrjcJ8EPUz4xXuVOxFHw/yeNNsuMOLWrjPUvBJe5DU", "edaUp");
  }
  
  protected void actionPerformed(GuiButton llllllllllllllllIIlIlIlIlllIIllI)
    throws IOException
  {
    ;
    ;
    if (lIllIIlIlllII(id)) {
      mc.displayGuiScreen(new GuiAchievements(llllllllllllllllIIlIlIlIlllIIlll, mc.thePlayer.getStatFileWriter()));
    }
    if (lIllIIlIlllIl(id, lllIlIIIlll[1])) {
      mc.displayGuiScreen(new GuiStats(llllllllllllllllIIlIlIlIlllIIlll, mc.thePlayer.getStatFileWriter()));
    }
  }
  
  private boolean needsScrollBars()
  {
    ;
    if ((lIllIIlIlllll(selectedTabIndex, CreativeTabs.tabInventory.getTabIndex())) && (lIllIIllIIIlI(CreativeTabs.creativeTabArray[selectedTabIndex].shouldHidePlayerInventory())) && (lIllIIllIIIlI(((ContainerCreative)inventorySlots).func_148328_e()))) {
      return lllIlIIIlll[1];
    }
    return lllIlIIIlll[0];
  }
  
  private static void lIllIIlIllIll()
  {
    lllIlIIIlll = new int[38];
    lllIlIIIlll[0] = ((0xCB ^ 0x84 ^ 0x10 ^ 0x58) & (0x7D ^ 0x25 ^ 0xE1 ^ 0xBE ^ -" ".length()));
    lllIlIIIlll[1] = " ".length();
    lllIlIIIlll[2] = (0xA8 ^ 0x85);
    lllIlIIIlll[3] = ((0x17 ^ 0x5B) + (0x86 ^ 0x91) - (0x6D ^ 0x46) + (0xCD ^ 0x9D));
    lllIlIIIlll[4] = (67 + 70 - -22 + 10 + (0x54 ^ 0x79) - ('' + 49 - 163 + 180) + (101 + 16 - 77 + 152));
    lllIlIIIlll[5] = (-(0xDBEF & 0x27F7));
    lllIlIIIlll[6] = (0xBE ^ 0xBA);
    lllIlIIIlll[7] = (0x61 ^ 0x64);
    lllIlIIIlll[8] = "  ".length();
    lllIlIIIlll[9] = (0x11 ^ 0x18);
    lllIlIIIlll[10] = "   ".length();
    lllIlIIIlll[11] = (0xA8 ^ 0xC7 ^ 0xC1 ^ 0x8A);
    lllIlIIIlll[12] = (0x52 ^ 0x0);
    lllIlIIIlll[13] = (0x70 ^ 0x76);
    lllIlIIIlll[14] = (0xC0 ^ 0x99);
    lllIlIIIlll[15] = (0x38 ^ 0x2E ^ 0x94 ^ 0x8D);
    lllIlIIIlll[16] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lllIlIIIlll[17] = (-" ".length());
    lllIlIIIlll[18] = (0x51 ^ 0x59 ^ (0x6F ^ 0x71) & (0x6 ^ 0x18 ^ 0xFFFFFFFF));
    lllIlIIIlll[19] = (0xE3C6 & 0x405C79);
    lllIlIIIlll[20] = (0x15 ^ 0x66 ^ 0x57 ^ 0x12);
    lllIlIIIlll[21] = ('' + 70 - 60 + 24 ^ 68 + 99 - 139 + 134);
    lllIlIIIlll[22] = (-(0x9FF8 & 0x67D7));
    lllIlIIIlll[23] = (0x4 ^ 0x16);
    lllIlIIIlll[24] = (11 + 75 - 37 + 129 ^ 55 + '¸' - 78 + 33);
    lllIlIIIlll[25] = ((0xB1 ^ 0xC2) + (0xDA ^ 0xBB) - (44 + 12 - 65396 + 13) + ('' + 24 - 47 + 51));
    lllIlIIIlll[26] = ((0x4B ^ 0x18) + (0x48 ^ 0x5C) - (0xCF ^ 0x9F) + (76 + 90 - 71 + 57));
    lllIlIIIlll[27] = (0x19 ^ 0x71 ^ 0xE7 ^ 0x81);
    lllIlIIIlll[28] = (0x4D ^ 0x5D);
    lllIlIIIlll[29] = (0xBF ^ 0xAE);
    lllIlIIIlll[30] = (24 + 80 - 96 + 224);
    lllIlIIIlll[31] = (0xA4 ^ 0xA8);
    lllIlIIIlll[32] = (0x0 ^ 0x1A ^ 0xB3 ^ 0x82);
    lllIlIIIlll[33] = (0x75 ^ 0x61);
    lllIlIIIlll[34] = (119 + '' - 205 + 106 ^ 77 + 37 - -35 + 39);
    lllIlIIIlll[35] = (0x61 ^ 0x6 ^ 0x7F ^ 0x4);
    lllIlIIIlll[36] = (0x14 ^ 0x34);
    lllIlIIIlll[37] = (0xAA ^ 0x8E ^ 0xB2 ^ 0x81);
  }
  
  public void initGui()
  {
    ;
    ;
    if (lIllIIllIIIlI(mc.playerController.isInCreativeMode()))
    {
      llllllllllllllllIIlIllIIIIlIllIl.initGui();
      buttonList.clear();
      Keyboard.enableRepeatEvents(lllIlIIIlll[1]);
      searchField = new GuiTextField(lllIlIIIlll[0], fontRendererObj, guiLeft + lllIlIIIlll[12], guiTop + lllIlIIIlll[13], lllIlIIIlll[14], fontRendererObj.FONT_HEIGHT);
      searchField.setMaxStringLength(lllIlIIIlll[15]);
      searchField.setEnableBackgroundDrawing(lllIlIIIlll[0]);
      searchField.setVisible(lllIlIIIlll[0]);
      searchField.setTextColor(lllIlIIIlll[16]);
      int llllllllllllllllIIlIllIIIIlIllII = selectedTabIndex;
      selectedTabIndex = lllIlIIIlll[17];
      llllllllllllllllIIlIllIIIIlIllIl.setCurrentCreativeTab(CreativeTabs.creativeTabArray[llllllllllllllllIIlIllIIIIlIllII]);
      field_147059_E = new CreativeCrafting(mc);
      mc.thePlayer.inventoryContainer.onCraftGuiOpened(field_147059_E);
      "".length();
      if ((0x0 ^ 0x60 ^ 0xA0 ^ 0xC4) == (118 + 31 - 77 + 66 ^ 68 + 83 - 15 + 6)) {}
    }
    else
    {
      mc.displayGuiScreen(new GuiInventory(mc.thePlayer));
    }
  }
  
  protected void drawGuiContainerForegroundLayer(int llllllllllllllllIIlIllIIIIIIIIIl, int llllllllllllllllIIlIllIIIIIIIIII)
  {
    ;
    ;
    CreativeTabs llllllllllllllllIIlIlIllllllllll = CreativeTabs.creativeTabArray[selectedTabIndex];
    if (lIllIIllIIIlI(llllllllllllllllIIlIlIllllllllll.drawInForegroundOfTab()))
    {
      GlStateManager.disableBlend();
      "".length();
    }
  }
  
  private static boolean lIllIIlIlllIl(int ???, int arg1)
  {
    int i;
    String llllllllllllllllIIlIlIlIlIlIllIl;
    return ??? == i;
  }
  
  class CreativeSlot
    extends Slot
  {
    public int getItemStackLimit(ItemStack lllllllllllllllIIlIllIllIlIIlllI)
    {
      ;
      ;
      return slot.getItemStackLimit(lllllllllllllllIIlIllIllIlIIlllI);
    }
    
    private static void lIIIlllIIllIIl()
    {
      lIlllIIlIlll = new int[1];
      lIlllIIlIlll[0] = ((0xD3 ^ 0x8C) & (0xD8 ^ 0x87 ^ 0xFFFFFFFF));
    }
    
    public void putStack(ItemStack lllllllllllllllIIlIllIllIlIllIII)
    {
      ;
      ;
      slot.putStack(lllllllllllllllIIlIllIllIlIllIII);
    }
    
    public boolean getHasStack()
    {
      ;
      return slot.getHasStack();
    }
    
    public CreativeSlot(Slot lllllllllllllllIIlIllIllIlllIlII, int lllllllllllllllIIlIllIllIlllIlll)
    {
      lllllllllllllllIIlIllIllIlllIllI.<init>(inventory, lllllllllllllllIIlIllIllIlllIlll, lIlllIIlIlll[0], lIlllIIlIlll[0]);
      slot = lllllllllllllllIIlIllIllIllllIII;
    }
    
    public ItemStack getStack()
    {
      ;
      return slot.getStack();
    }
    
    static {}
    
    public String getSlotTexture()
    {
      ;
      return slot.getSlotTexture();
    }
    
    public boolean isItemValid(ItemStack lllllllllllllllIIlIllIllIllIIllI)
    {
      ;
      ;
      return slot.isItemValid(lllllllllllllllIIlIllIllIllIIllI);
    }
    
    public ItemStack decrStackSize(int lllllllllllllllIIlIllIllIlIIIlIl)
    {
      ;
      ;
      return slot.decrStackSize(lllllllllllllllIIlIllIllIlIIIlIl);
    }
    
    public int getSlotStackLimit()
    {
      ;
      return slot.getSlotStackLimit();
    }
    
    public void onPickupFromSlot(EntityPlayer lllllllllllllllIIlIllIllIllIlIll, ItemStack lllllllllllllllIIlIllIllIllIllIl)
    {
      ;
      ;
      ;
      slot.onPickupFromSlot(lllllllllllllllIIlIllIllIllIlllI, lllllllllllllllIIlIllIllIllIllIl);
    }
    
    public void onSlotChanged()
    {
      ;
      slot.onSlotChanged();
    }
    
    public boolean isHere(IInventory lllllllllllllllIIlIllIllIIlllIll, int lllllllllllllllIIlIllIllIIlllIlI)
    {
      ;
      ;
      ;
      return slot.isHere(lllllllllllllllIIlIllIllIIlllllI, lllllllllllllllIIlIllIllIIlllIlI);
    }
  }
  
  static class ContainerCreative
    extends Container
  {
    static {}
    
    private static boolean lIIIlllIlIllII(int ???)
    {
      int lllllllllllllllIIlIllIIlllllIllI;
      return ??? >= 0;
    }
    
    public ItemStack transferStackInSlot(EntityPlayer lllllllllllllllIIlIllIlIIIIllIII, int lllllllllllllllIIlIllIlIIIIlIlll)
    {
      ;
      ;
      ;
      if ((lIIIlllIlIlIlI(lllllllllllllllIIlIllIlIIIIlIlll, inventorySlots.size() - lIlllIIllIlI[1])) && (lIIIlllIlIllIl(lllllllllllllllIIlIllIlIIIIlIlll, inventorySlots.size())))
      {
        Slot lllllllllllllllIIlIllIlIIIIlIllI = (Slot)inventorySlots.get(lllllllllllllllIIlIllIlIIIIlIlll);
        if ((lIIIlllIlIllll(lllllllllllllllIIlIllIlIIIIlIllI)) && (lIIIlllIllIIII(lllllllllllllllIIlIllIlIIIIlIllI.getHasStack()))) {
          lllllllllllllllIIlIllIlIIIIlIllI.putStack(null);
        }
      }
      return null;
    }
    
    private static boolean lIIIlllIlIllll(Object ???)
    {
      byte lllllllllllllllIIlIllIIlllllllII;
      return ??? != null;
    }
    
    public void scrollTo(float lllllllllllllllIIlIllIlIIIllIIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      int lllllllllllllllIIlIllIlIIIllIIII = (itemList.size() + lIlllIIllIlI[1] - lIlllIIllIlI[5]) / lIlllIIllIlI[1] - lIlllIIllIlI[3];
      int lllllllllllllllIIlIllIlIIIlIllll = (int)(lllllllllllllllIIlIllIlIIIllIIIl * lllllllllllllllIIlIllIlIIIllIIII + 0.5D);
      if (lIIIlllIlIlIll(lllllllllllllllIIlIllIlIIIlIllll)) {
        lllllllllllllllIIlIllIlIIIlIllll = lIlllIIllIlI[0];
      }
      int lllllllllllllllIIlIllIlIIIlIlllI = lIlllIIllIlI[0];
      "".length();
      if ("  ".length() == 0) {
        return;
      }
      while (!lIIIlllIlIlIlI(lllllllllllllllIIlIllIlIIIlIlllI, lIlllIIllIlI[3]))
      {
        int lllllllllllllllIIlIllIlIIIlIllIl = lIlllIIllIlI[0];
        "".length();
        if (-"  ".length() > 0) {
          return;
        }
        while (!lIIIlllIlIlIlI(lllllllllllllllIIlIllIlIIIlIllIl, lIlllIIllIlI[1]))
        {
          int lllllllllllllllIIlIllIlIIIlIllII = lllllllllllllllIIlIllIlIIIlIllIl + (lllllllllllllllIIlIllIlIIIlIlllI + lllllllllllllllIIlIllIlIIIlIllll) * lIlllIIllIlI[1];
          if ((lIIIlllIlIllII(lllllllllllllllIIlIllIlIIIlIllII)) && (lIIIlllIlIllIl(lllllllllllllllIIlIllIlIIIlIllII, itemList.size())))
          {
            GuiContainerCreative.field_147060_v.setInventorySlotContents(lllllllllllllllIIlIllIlIIIlIllIl + lllllllllllllllIIlIllIlIIIlIlllI * lIlllIIllIlI[1], (ItemStack)itemList.get(lllllllllllllllIIlIllIlIIIlIllII));
            "".length();
            if (" ".length() != 0) {}
          }
          else
          {
            GuiContainerCreative.field_147060_v.setInventorySlotContents(lllllllllllllllIIlIllIlIIIlIllIl + lllllllllllllllIIlIllIlIIIlIlllI * lIlllIIllIlI[1], null);
          }
          lllllllllllllllIIlIllIlIIIlIllIl++;
        }
        lllllllllllllllIIlIllIlIIIlIlllI++;
      }
    }
    
    public ContainerCreative(EntityPlayer lllllllllllllllIIlIllIlIIlIIIlIl)
    {
      InventoryPlayer lllllllllllllllIIlIllIlIIlIIIlII = inventory;
      int lllllllllllllllIIlIllIlIIlIIIIll = lIlllIIllIlI[0];
      "".length();
      if ((0x6 ^ 0x53 ^ 0x4F ^ 0x1E) < 0) {
        throw null;
      }
      while (!lIIIlllIlIlIlI(lllllllllllllllIIlIllIlIIlIIIIll, lIlllIIllIlI[3]))
      {
        int lllllllllllllllIIlIllIlIIlIIIIlI = lIlllIIllIlI[0];
        "".length();
        if ("  ".length() < -" ".length()) {
          throw null;
        }
        while (!lIIIlllIlIlIlI(lllllllllllllllIIlIllIlIIlIIIIlI, lIlllIIllIlI[1]))
        {
          new Slot(GuiContainerCreative.field_147060_v, lllllllllllllllIIlIllIlIIlIIIIll * lIlllIIllIlI[1] + lllllllllllllllIIlIllIlIIlIIIIlI, lIlllIIllIlI[1] + lllllllllllllllIIlIllIlIIlIIIIlI * lIlllIIllIlI[2], lIlllIIllIlI[2] + lllllllllllllllIIlIllIlIIlIIIIll * lIlllIIllIlI[2]);
          "".length();
        }
      }
      int lllllllllllllllIIlIllIlIIlIIIIIl = lIlllIIllIlI[0];
      "".length();
      if ((0x14 ^ 0x10) <= 0) {
        throw null;
      }
      while (!lIIIlllIlIlIlI(lllllllllllllllIIlIllIlIIlIIIIIl, lIlllIIllIlI[1]))
      {
        new Slot(lllllllllllllllIIlIllIlIIlIIIlII, lllllllllllllllIIlIllIlIIlIIIIIl, lIlllIIllIlI[1] + lllllllllllllllIIlIllIlIIlIIIIIl * lIlllIIllIlI[2], lIlllIIllIlI[4]);
        "".length();
      }
      lllllllllllllllIIlIllIlIIlIIIllI.scrollTo(0.0F);
    }
    
    private static boolean lIIIlllIlIlIlI(int ???, int arg1)
    {
      int i;
      long lllllllllllllllIIlIllIlIIIIIIllI;
      return ??? >= i;
    }
    
    public boolean canInteractWith(EntityPlayer lllllllllllllllIIlIllIlIIIlllIlI)
    {
      return lIlllIIllIlI[5];
    }
    
    public boolean canDragIntoSlot(Slot lllllllllllllllIIlIllIlIIIIIlIlI)
    {
      ;
      if ((lIIIlllIllIIIl(inventory instanceof InventoryPlayer)) && ((!lIIIlllIlIlllI(yDisplayPosition, lIlllIIllIlI[7])) || (lIIIlllIlIlllI(xDisplayPosition, lIlllIIllIlI[8])))) {
        return lIlllIIllIlI[0];
      }
      return lIlllIIllIlI[5];
    }
    
    private static void lIIIlllIlIlIIl()
    {
      lIlllIIllIlI = new int[9];
      lIlllIIllIlI[0] = ((0x86 ^ 0xAC) & (0x9D ^ 0xB7 ^ 0xFFFFFFFF));
      lIlllIIllIlI[1] = (0xE5 ^ 0x97 ^ 0xCC ^ 0xB7);
      lIlllIIllIlI[2] = (0x8 ^ 0x1A);
      lIlllIIllIlI[3] = (0xE6 ^ 0x9E ^ 0x3C ^ 0x41);
      lIlllIIllIlI[4] = (0xF5 ^ 0x82 ^ 0x94 ^ 0x93);
      lIlllIIllIlI[5] = " ".length();
      lIlllIIllIlI[6] = (0xFE ^ 0x82 ^ 0x4D ^ 0x1C);
      lIlllIIllIlI[7] = (0x41 ^ 0x4D ^ 0xF ^ 0x59);
      lIlllIIllIlI[8] = ((0x64 ^ 0x52) + (0xF8 ^ 0x84) - (52 + 111 - 74 + 65) + (2 + 4 - -70 + 62));
    }
    
    private static boolean lIIIlllIlIlIll(int ???)
    {
      short lllllllllllllllIIlIllIIlllllIlII;
      return ??? < 0;
    }
    
    private static boolean lIIIlllIllIIII(int ???)
    {
      String lllllllllllllllIIlIllIIllllllIlI;
      return ??? != 0;
    }
    
    private static boolean lIIIlllIlIllIl(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllIIlIllIlIIIIIIIlI;
      return ??? < i;
    }
    
    private static boolean lIIIlllIllIIIl(int ???)
    {
      double lllllllllllllllIIlIllIIllllllIII;
      return ??? == 0;
    }
    
    public boolean func_148328_e()
    {
      ;
      if (lIIIlllIlIlllI(itemList.size(), lIlllIIllIlI[6])) {
        return lIlllIIllIlI[5];
      }
      return lIlllIIllIlI[0];
    }
    
    protected void retrySlotClick(int lllllllllllllllIIlIllIlIIIlIIIII, int lllllllllllllllIIlIllIlIIIIlllll, boolean lllllllllllllllIIlIllIlIIIIllllI, EntityPlayer lllllllllllllllIIlIllIlIIIIlllIl) {}
    
    public boolean canMergeSlot(ItemStack lllllllllllllllIIlIllIlIIIIlIIII, Slot lllllllllllllllIIlIllIlIIIIIllll)
    {
      ;
      if (lIIIlllIlIlllI(yDisplayPosition, lIlllIIllIlI[7])) {
        return lIlllIIllIlI[5];
      }
      return lIlllIIllIlI[0];
    }
    
    private static boolean lIIIlllIlIlllI(int ???, int arg1)
    {
      int i;
      float lllllllllllllllIIlIllIIllllllllI;
      return ??? > i;
    }
  }
}

package net.minecraft.client;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;

public class ClientBrandRetriever
{
  public ClientBrandRetriever() {}
  
  private static boolean llIlIllllIIII(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIlllIIlllIIlIIllI;
    return ??? < i;
  }
  
  public static String getClientModName()
  {
    return lIIIlIllIIII[lIIIlIllIIll[0]];
  }
  
  private static void llIlIlllIllII()
  {
    lIIIlIllIIII = new String[lIIIlIllIIll[1]];
    lIIIlIllIIII[lIIIlIllIIll[0]] = llIlIlllIlIll("Ly44GiU1Lg==", "YOVsI");
  }
  
  private static String llIlIlllIlIll(String lllllllllllllllIlllIIlllIIllIlll, String lllllllllllllllIlllIIlllIIllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlllIIlllIIllIlll = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIlllIIllIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIlllIIllIlIl = new StringBuilder();
    char[] lllllllllllllllIlllIIlllIIllIlII = lllllllllllllllIlllIIlllIIllIllI.toCharArray();
    int lllllllllllllllIlllIIlllIIllIIll = lIIIlIllIIll[0];
    char lllllllllllllllIlllIIlllIIlIllIl = lllllllllllllllIlllIIlllIIllIlll.toCharArray();
    boolean lllllllllllllllIlllIIlllIIlIllII = lllllllllllllllIlllIIlllIIlIllIl.length;
    short lllllllllllllllIlllIIlllIIlIlIll = lIIIlIllIIll[0];
    while (llIlIllllIIII(lllllllllllllllIlllIIlllIIlIlIll, lllllllllllllllIlllIIlllIIlIllII))
    {
      char lllllllllllllllIlllIIlllIIlllIII = lllllllllllllllIlllIIlllIIlIllIl[lllllllllllllllIlllIIlllIIlIlIll];
      "".length();
      "".length();
      if (-" ".length() > ((0x54 ^ 0x78) & (0x92 ^ 0xBE ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIlllIIlllIIllIlIl);
  }
  
  static
  {
    llIlIlllIllll();
    llIlIlllIllII();
  }
  
  private static void llIlIlllIllll()
  {
    lIIIlIllIIll = new int[2];
    lIIIlIllIIll[0] = ((0x82 ^ 0x93) & (0x14 ^ 0x5 ^ 0xFFFFFFFF));
    lIIIlIllIIll[1] = " ".length();
  }
}

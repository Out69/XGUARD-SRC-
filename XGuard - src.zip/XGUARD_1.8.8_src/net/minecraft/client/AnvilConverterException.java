package net.minecraft.client;

public class AnvilConverterException
  extends Exception
{
  public AnvilConverterException(String llllllllllllllIllllIlIIlIlllIIIl)
  {
    llllllllllllllIllllIlIIlIlllIIII.<init>(llllllllllllllIllllIlIIlIlllIIIl);
  }
}

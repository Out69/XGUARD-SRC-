package net.minecraft.client.audio;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class MovingSoundMinecart
  extends MovingSound
{
  public void update()
  {
    ;
    ;
    if (lIlIllIIIIl(minecart.isDead))
    {
      donePlaying = llIIlllIl[1];
      "".length();
      if ("   ".length() > ((0x2F ^ 0x4C) & (0x1A ^ 0x79 ^ 0xFFFFFFFF))) {}
    }
    else
    {
      xPosF = ((float)minecart.posX);
      yPosF = ((float)minecart.posY);
      zPosF = ((float)minecart.posZ);
      float lIlllIIIllIllI = MathHelper.sqrt_double(minecart.motionX * minecart.motionX + minecart.motionZ * minecart.motionZ);
      if (lIlIllIIIlI(lIlIllIIIII(lIlllIIIllIllI, 0.01D)))
      {
        distance = MathHelper.clamp_float(distance + 0.0025F, 0.0F, 1.0F);
        volume = (0.0F + MathHelper.clamp_float(lIlllIIIllIllI, 0.0F, 0.5F) * 0.7F);
        "".length();
        if (null == null) {}
      }
      else
      {
        distance = 0.0F;
        volume = 0.0F;
      }
    }
  }
  
  public MovingSoundMinecart(EntityMinecart lIlllIIIlllIlI)
  {
    lIlllIIIllllIl.<init>(new ResourceLocation(llIIlllII[llIIlllIl[0]]));
    minecart = lIlllIIIlllIlI;
    repeat = llIIlllIl[1];
    repeatDelay = llIIlllIl[0];
  }
  
  private static String lIlIlIlllIl(String lIlllIIIlIlIlI, String lIlllIIIlIlIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIlllIIIlIllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIlllIIIlIlIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIlllIIIlIlllI = Cipher.getInstance("Blowfish");
      lIlllIIIlIlllI.init(llIIlllIl[2], lIlllIIIlIllll);
      return new String(lIlllIIIlIlllI.doFinal(Base64.getDecoder().decode(lIlllIIIlIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIlllIIIlIllIl)
    {
      lIlllIIIlIllIl.printStackTrace();
    }
    return null;
  }
  
  private static int lIlIllIIIII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static void lIlIlIllllI()
  {
    llIIlllII = new String[llIIlllIl[1]];
    llIIlllII[llIIlllIl[0]] = lIlIlIlllIl("849SdMmzuvYEvUi/ZSzXuMnarhpOFwWT", "AoJgr");
  }
  
  private static boolean lIlIllIIIlI(int ???)
  {
    char lIlllIIIlIIIll;
    return ??? >= 0;
  }
  
  private static boolean lIlIllIIIIl(int ???)
  {
    long lIlllIIIlIIlIl;
    return ??? != 0;
  }
  
  private static void lIlIlIlllll()
  {
    llIIlllIl = new int[3];
    llIIlllIl[0] = ((6 + 46 - -75 + 34 ^ 5 + '' - 29 + 60) & (0x2B ^ 0x8 ^ 0x7A ^ 0x47 ^ -" ".length()));
    llIIlllIl[1] = " ".length();
    llIIlllIl[2] = "  ".length();
  }
  
  static
  {
    lIlIlIlllll();
    lIlIlIllllI();
  }
}

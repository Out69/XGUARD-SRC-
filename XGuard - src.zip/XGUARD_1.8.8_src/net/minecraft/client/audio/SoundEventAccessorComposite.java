package net.minecraft.client.audio;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.util.ResourceLocation;

public class SoundEventAccessorComposite
  implements ISoundEventAccessor<SoundPoolEntry>
{
  private static boolean lllIIIllllIll(int ???)
  {
    Exception lllllllllllllllIllIIllIlIlIIlIII;
    return ??? == 0;
  }
  
  private static void lllIIIllllIlI()
  {
    lIIlIIllllII = new int[1];
    lIIlIIllllII[0] = ((0xFA ^ 0xBC ^ 0x2A ^ 0x70) & (0x1F ^ 0x78 ^ 0x35 ^ 0x4E ^ -" ".length()));
  }
  
  private static boolean lllIIIlllllII(int ???)
  {
    char lllllllllllllllIllIIllIlIlIIlIlI;
    return ??? != 0;
  }
  
  public void addSoundToEventPool(ISoundEventAccessor<SoundPoolEntry> lllllllllllllllIllIIllIlIlIlIlII)
  {
    ;
    ;
    "".length();
  }
  
  private static boolean lllIIIlllllIl(int ???)
  {
    String lllllllllllllllIllIIllIlIlIIIllI;
    return ??? < 0;
  }
  
  public SoundPoolEntry cloneEntry()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIllIIllIlIllIIIll = lllllllllllllllIllIIllIlIllIIlII.getWeight();
    if ((lllIIIllllIll(soundPool.isEmpty())) && (lllIIIlllllII(lllllllllllllllIllIIllIlIllIIIll)))
    {
      int lllllllllllllllIllIIllIlIllIIIlI = rnd.nextInt(lllllllllllllllIllIIllIlIllIIIll);
      lllllllllllllllIllIIllIlIlIllIll = soundPool.iterator();
      "".length();
      if (((76 + 71 - 1 + 29 ^ 17 + 21 - -31 + 98) & (0xDE ^ 0x99 ^ 0x78 ^ 0x37 ^ -" ".length())) < 0) {
        return null;
      }
      while (!lllIIIllllIll(lllllllllllllllIllIIllIlIlIllIll.hasNext()))
      {
        ISoundEventAccessor<SoundPoolEntry> lllllllllllllllIllIIllIlIllIIIIl = (ISoundEventAccessor)lllllllllllllllIllIIllIlIlIllIll.next();
        lllllllllllllllIllIIllIlIllIIIlI -= lllllllllllllllIllIIllIlIllIIIIl.getWeight();
        if (lllIIIlllllIl(lllllllllllllllIllIIllIlIllIIIlI))
        {
          SoundPoolEntry lllllllllllllllIllIIllIlIllIIIII = (SoundPoolEntry)lllllllllllllllIllIIllIlIllIIIIl.cloneEntry();
          lllllllllllllllIllIIllIlIllIIIII.setPitch(lllllllllllllllIllIIllIlIllIIIII.getPitch() * eventPitch);
          lllllllllllllllIllIIllIlIllIIIII.setVolume(lllllllllllllllIllIIllIlIllIIIII.getVolume() * eventVolume);
          return lllllllllllllllIllIIllIlIllIIIII;
        }
      }
      return SoundHandler.missing_sound;
    }
    return SoundHandler.missing_sound;
  }
  
  public int getWeight()
  {
    ;
    ;
    ;
    int lllllllllllllllIllIIllIlIlllIIII = lIIlIIllllII[0];
    int lllllllllllllllIllIIllIlIllIlIll = soundPool.iterator();
    "".length();
    if ((0x1C ^ 0x18) <= 0) {
      return (0x74 ^ 0x2A) & (0xF5 ^ 0xAB ^ 0xFFFFFFFF);
    }
    while (!lllIIIllllIll(lllllllllllllllIllIIllIlIllIlIll.hasNext()))
    {
      ISoundEventAccessor<SoundPoolEntry> lllllllllllllllIllIIllIlIllIllll = (ISoundEventAccessor)lllllllllllllllIllIIllIlIllIlIll.next();
      lllllllllllllllIllIIllIlIlllIIII += lllllllllllllllIllIIllIlIllIllll.getWeight();
    }
    return lllllllllllllllIllIIllIlIlllIIII;
  }
  
  public SoundCategory getSoundCategory()
  {
    ;
    return category;
  }
  
  static {}
  
  public SoundEventAccessorComposite(ResourceLocation lllllllllllllllIllIIllIlIllllllI, double lllllllllllllllIllIIllIlIllllIII, double lllllllllllllllIllIIllIlIlllIlll, SoundCategory lllllllllllllllIllIIllIlIllllIll)
  {
    soundLocation = lllllllllllllllIllIIllIlIllllllI;
    eventVolume = lllllllllllllllIllIIllIlIlllIlll;
    eventPitch = lllllllllllllllIllIIllIlIlllllIl;
    category = lllllllllllllllIllIIllIlIllllIll;
  }
  
  public ResourceLocation getSoundEventLocation()
  {
    ;
    return soundLocation;
  }
}

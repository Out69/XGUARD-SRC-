package net.minecraft.client.audio;

import com.google.common.collect.Multimap;
import io.netty.util.internal.ThreadLocalRandom;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLStreamHandler;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.IResource;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.MarkerManager;
import paulscode.sound.Library;
import paulscode.sound.SoundSystem;
import paulscode.sound.SoundSystemConfig;
import paulscode.sound.SoundSystemException;
import paulscode.sound.SoundSystemLogger;
import paulscode.sound.Source;
import paulscode.sound.codecs.CodecJOrbis;
import paulscode.sound.libraries.LibraryLWJGLOpenAL;

public class SoundManager
{
  private static boolean lIIlIIIIIIIlll(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllIIlIlIlIllIllIllI;
    return ??? > i;
  }
  
  private static int lIIlIIIIIIlIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void resumeAllSounds()
  {
    ;
    ;
    short lllllllllllllllIIlIlIllIIlIIllll = playingSounds.keySet().iterator();
    "".length();
    if ((0xB5 ^ 0xB0) <= 0) {
      return;
    }
    while (!lIIIllllllllII(lllllllllllllllIIlIlIllIIlIIllll.hasNext()))
    {
      String lllllllllllllllIIlIlIllIIlIlIIlI = (String)lllllllllllllllIIlIlIllIIlIIllll.next();
      logger.debug(LOG_MARKER, lIlllIlIllll[lIlllIllIIll[13]], new Object[] { lllllllllllllllIIlIlIllIIlIlIIlI });
      sndSystem.play(lllllllllllllllIIlIlIllIIlIlIIlI);
    }
  }
  
  private static boolean lIIlIIIIIIIIll(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIIlIlIlIllIlllIlI;
    return ??? <= i;
  }
  
  public void stopSound(ISound lllllllllllllllIIlIlIllIlIIlIlll)
  {
    ;
    ;
    ;
    if (lIIlIIIIIIIIII(loaded))
    {
      String lllllllllllllllIIlIlIllIlIIllIIl = (String)invPlayingSounds.get(lllllllllllllllIIlIlIllIlIIlIlll);
      if (lIIIllllllllIl(lllllllllllllllIIlIlIllIlIIllIIl)) {
        sndSystem.stop(lllllllllllllllIIlIlIllIlIIllIIl);
      }
    }
  }
  
  private static boolean lIIIllllllllIl(Object ???)
  {
    short lllllllllllllllIIlIlIlIllIllIIII;
    return ??? != null;
  }
  
  public void setSoundCategoryVolume(SoundCategory lllllllllllllllIIlIlIllIllIllIlI, float lllllllllllllllIIlIlIllIllIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIlIIIIIIIIII(loaded)) {
      if (lIIlIIIIIIIIIl(lllllllllllllllIIlIlIllIllIlIlII, SoundCategory.MASTER))
      {
        sndSystem.setMasterVolume(lllllllllllllllIIlIlIllIllIlIIll);
        "".length();
        if ("  ".length() != 0) {}
      }
      else
      {
        lllllllllllllllIIlIlIllIllIlIIIl = categorySounds.get(lllllllllllllllIIlIlIllIllIlIlII).iterator();
        "".length();
        if ("  ".length() == " ".length()) {
          return;
        }
        while (!lIIIllllllllII(lllllllllllllllIIlIlIllIllIlIIIl.hasNext()))
        {
          String lllllllllllllllIIlIlIllIllIllIII = (String)lllllllllllllllIIlIlIllIllIlIIIl.next();
          ISound lllllllllllllllIIlIlIllIllIlIlll = (ISound)playingSounds.get(lllllllllllllllIIlIlIllIllIllIII);
          float lllllllllllllllIIlIlIllIllIlIllI = lllllllllllllllIIlIlIllIllIllIll.getNormalizedVolume(lllllllllllllllIIlIlIllIllIlIlll, (SoundPoolEntry)playingSoundPoolEntries.get(lllllllllllllllIIlIlIllIllIlIlll), lllllllllllllllIIlIlIllIllIlIlII);
          if (lIIlIIIIIIIIlI(lIIIllllllllll(lllllllllllllllIIlIlIllIllIlIllI, 0.0F)))
          {
            lllllllllllllllIIlIlIllIllIllIll.stopSound(lllllllllllllllIIlIlIllIllIlIlll);
            "".length();
            if (((0x7E ^ 0x33 ^ 0x6A ^ 0x30) & ('¬' + '' - 254 + 137 ^ 51 + '¬' - 172 + 145 ^ -" ".length())) == 0) {}
          }
          else
          {
            sndSystem.setVolume(lllllllllllllllIIlIlIllIllIllIII, lllllllllllllllIIlIlIllIllIlIllI);
          }
        }
      }
    }
  }
  
  private synchronized void loadSoundSystem()
  {
    ;
    ;
    if (lIIIllllllllII(loaded)) {
      try
      {
        new Thread(new Runnable()
        {
          static
          {
            lIIllIIIlIIlI();
            lIIllIIIIlllI();
          }
          
          private static String lIIllIIIIllIl(String llllllllllllllllIllIIIIIlIlIIIIl, String llllllllllllllllIllIIIIIlIlIIIII)
          {
            try
            {
              ;
              ;
              ;
              ;
              SecretKeySpec llllllllllllllllIllIIIIIlIlIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllIIIIIlIlIIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
              Cipher llllllllllllllllIllIIIIIlIlIIlIl = Cipher.getInstance("Blowfish");
              llllllllllllllllIllIIIIIlIlIIlIl.init(llIIIlllIll[2], llllllllllllllllIllIIIIIlIlIIllI);
              return new String(llllllllllllllllIllIIIIIlIlIIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllllIllIIIIIlIlIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
            }
            catch (Exception llllllllllllllllIllIIIIIlIlIIlII)
            {
              llllllllllllllllIllIIIIIlIlIIlII.printStackTrace();
            }
            return null;
          }
          
          public void run()
          {
            ;
            SoundSystemConfig.setLogger(new SoundSystemLogger()
            {
              private static boolean llIIIIIIlIl(int ???, int arg1)
              {
                int i;
                byte lIIlIlIllIlIIl;
                return ??? < i;
              }
              
              public void importantMessage(String lIIlIllIIIllll, int lIIlIllIIIlllI)
              {
                ;
                if (llIIIIIIlII(lIIlIllIIIllll.isEmpty())) {
                  SoundManager.logger.warn(lIIlIllIIIllll);
                }
              }
              
              private static String llIIIIIIIIl(String lIIlIlIllllIlI, String lIIlIlIllllIIl)
              {
                ;
                ;
                ;
                ;
                ;
                ;
                lIIlIlIllllIlI = new String(Base64.getDecoder().decode(lIIlIlIllllIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
                StringBuilder lIIlIlIllllIII = new StringBuilder();
                char[] lIIlIlIlllIlll = lIIlIlIllllIIl.toCharArray();
                int lIIlIlIlllIllI = lllIlllll[0];
                String lIIlIlIlllIIII = lIIlIlIllllIlI.toCharArray();
                String lIIlIlIllIllll = lIIlIlIlllIIII.length;
                short lIIlIlIllIlllI = lllIlllll[0];
                while (llIIIIIIlIl(lIIlIlIllIlllI, lIIlIlIllIllll))
                {
                  char lIIlIlIllllIll = lIIlIlIlllIIII[lIIlIlIllIlllI];
                  "".length();
                  "".length();
                  if (((0x8F ^ 0xAD) & (0xB9 ^ 0x9B ^ 0xFFFFFFFF)) != 0) {
                    return null;
                  }
                }
                return String.valueOf(lIIlIlIllllIII);
              }
              
              public void errorMessage(String lIIlIllIIIIllI, String lIIlIllIIIlIII, int lIIlIllIIIIlll)
              {
                ;
                ;
                if (llIIIIIIlII(lIIlIllIIIlIII.isEmpty()))
                {
                  SoundManager.logger.error(String.valueOf(new StringBuilder(lllIllllI[lllIlllll[0]]).append(lIIlIllIIIIllI).append(lllIllllI[lllIlllll[1]])));
                  SoundManager.logger.error(lIIlIllIIIIlIl);
                }
              }
              
              private static void llIIIIIIIlI()
              {
                lllIllllI = new String[lllIlllll[2]];
                lllIllllI[lllIlllll[0]] = llIIIIIIIIl("KRYIPwdMDRRwFgAFCSNVSw==", "ldzPu");
                lllIllllI[lllIlllll[1]] = llIIIIIIIIl("Sg==", "moNka");
              }
              
              private static boolean llIIIIIIlII(int ???)
              {
                float lIIlIlIllIIlll;
                return ??? == 0;
              }
              
              public void message(String lIIlIllIIlIlII, int lIIlIllIIlIIll)
              {
                ;
                if (llIIIIIIlII(lIIlIllIIlIlII.isEmpty())) {
                  SoundManager.logger.info(lIIlIllIIlIlII);
                }
              }
              
              static
              {
                llIIIIIIIll();
                llIIIIIIIlI();
              }
              
              private static void llIIIIIIIll()
              {
                lllIlllll = new int[3];
                lllIlllll[0] = ("   ".length() & ("   ".length() ^ 0xFFFFFFFF));
                lllIlllll[1] = " ".length();
                lllIlllll[2] = "  ".length();
              }
            });
            SoundManager.SoundSystemStarterThread tmp18_15 = new net/minecraft/client/audio/SoundManager$SoundSystemStarterThread;
            SoundManager tmp23_20 = SoundManager.this;
            "".length();
            tmp23_20.<init>(tmp23_20.getClass(), null);
            1815sndSystem = tmp18_15;
            loaded = llIIIlllIll[0];
            sndSystem.setMasterVolume(options.getSoundLevel(SoundCategory.MASTER));
            SoundManager.logger.info(SoundManager.LOG_MARKER, llIIIlllIIl[llIIIlllIll[1]]);
          }
          
          private static void lIIllIIIlIIlI()
          {
            llIIIlllIll = new int[3];
            llIIIlllIll[0] = " ".length();
            llIIIlllIll[1] = ((0xAC ^ 0xA0) & (0x6F ^ 0x63 ^ 0xFFFFFFFF));
            llIIIlllIll[2] = "  ".length();
          }
          
          private static void lIIllIIIIlllI()
          {
            llIIIlllIIl = new String[llIIIlllIll[0]];
            llIIIlllIIl[llIIIlllIll[1]] = lIIllIIIIllIl("0C4q53VfliapgpTOq67aDDwvaODrpUn2", "IqQMR");
          }
        }, lIlllIlIllll[lIlllIllIIll[3]]).start();
        "".length();
        if (((0x2F ^ 0x3F) & (0x2 ^ 0x12 ^ 0xFFFFFFFF)) != 0) {}
      }
      catch (RuntimeException lllllllllllllllIIlIlIllIlllIlIll)
      {
        logger.error(LOG_MARKER, lIlllIlIllll[lIlllIllIIll[4]], lllllllllllllllIIlIlIllIlllIlIll);
        options.setSoundLevel(SoundCategory.MASTER, 0.0F);
        options.saveOptions();
      }
    }
  }
  
  public boolean isSoundPlaying(ISound lllllllllllllllIIlIlIllIlIlIIIll)
  {
    ;
    ;
    ;
    if (lIIIllllllllII(loaded)) {
      return lIlllIllIIll[0];
    }
    String lllllllllllllllIIlIlIllIlIlIIIlI = (String)invPlayingSounds.get(lllllllllllllllIIlIlIllIlIlIIIll);
    if (lIIlIIIIIIIllI(lllllllllllllllIIlIlIllIlIlIIIlI))
    {
      "".length();
      if (-"   ".length() >= 0) {
        return (0x40 ^ 0x6D ^ 0x12 ^ 0x6B) & (16 + 95 - -45 + 78 ^ 108 + 127 - 134 + 89 ^ -" ".length());
      }
    }
    else if ((lIIIllllllllII(sndSystem.playing(lllllllllllllllIIlIlIllIlIlIIIlI))) && ((!lIIlIIIIIIIIII(playingSoundsStopTime.containsKey(lllllllllllllllIIlIlIllIlIlIIIlI))) || (lIIlIIIIIIIlll(((Integer)playingSoundsStopTime.get(lllllllllllllllIIlIlIllIlIlIIIlI)).intValue(), playTime))))
    {
      "".length();
      if (-"   ".length() < 0) {
        break label219;
      }
      return (0xA4 ^ 0x9D ^ 0x9B ^ 0x9C) & (0xA ^ 0x65 ^ 0x1E ^ 0x4F ^ -" ".length());
    }
    label219:
    return lIlllIllIIll[1];
  }
  
  public SoundManager(SoundHandler lllllllllllllllIIlIlIllIlllllIII, GameSettings lllllllllllllllIIlIlIllIllllIIll)
  {
    sndHandler = lllllllllllllllIIlIlIllIllllIlII;
    options = lllllllllllllllIIlIlIllIllllIIll;
    try
    {
      SoundSystemConfig.addLibrary(LibraryLWJGLOpenAL.class);
      SoundSystemConfig.setCodec(lIlllIlIllll[lIlllIllIIll[1]], CodecJOrbis.class);
      "".length();
      if (((0x58 ^ 0x13) & (0xE1 ^ 0xAA ^ 0xFFFFFFFF)) > (0x8F ^ 0x8B)) {
        throw null;
      }
    }
    catch (SoundSystemException lllllllllllllllIIlIlIllIllllIllI)
    {
      logger.error(LOG_MARKER, lIlllIlIllll[lIlllIllIIll[2]], lllllllllllllllIIlIlIllIllllIllI);
    }
  }
  
  private static String lIIIlllllIIIIl(String lllllllllllllllIIlIlIlIlllllIIII, String lllllllllllllllIIlIlIlIllllIllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlIlIlIlllllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlIlIlIllllIllll.getBytes(StandardCharsets.UTF_8)), lIlllIllIIll[8]), "DES");
      Cipher lllllllllllllllIIlIlIlIlllllIIlI = Cipher.getInstance("DES");
      lllllllllllllllIIlIlIlIlllllIIlI.init(lIlllIllIIll[2], lllllllllllllllIIlIlIlIlllllIIll);
      return new String(lllllllllllllllIIlIlIlIlllllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlIlIlIlllllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlIlIlIlllllIIIl)
    {
      lllllllllllllllIIlIlIlIlllllIIIl.printStackTrace();
    }
    return null;
  }
  
  private float getNormalizedVolume(ISound lllllllllllllllIIlIlIllIIllIIIIl, SoundPoolEntry lllllllllllllllIIlIlIllIIllIIlII, SoundCategory lllllllllllllllIIlIlIllIIlIlllll)
  {
    ;
    ;
    ;
    ;
    return (float)MathHelper.clamp_double(lllllllllllllllIIlIlIllIIllIIIIl.getVolume() * lllllllllllllllIIlIlIllIIllIIlII.getVolume(), 0.0D, 1.0D) * lllllllllllllllIIlIlIllIIllIIllI.getSoundCategoryVolume(lllllllllllllllIIlIlIllIIlIlllll);
  }
  
  private static boolean lIIIlllllllllI(Object ???, Object arg1)
  {
    Object localObject;
    float lllllllllllllllIIlIlIlIllIllIIlI;
    return ??? != localObject;
  }
  
  private static boolean lIIlIIIIIIIIlI(int ???)
  {
    boolean lllllllllllllllIIlIlIlIllIlIIlII;
    return ??? <= 0;
  }
  
  public void updateAllSounds()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    playTime += lIlllIllIIll[1];
    short lllllllllllllllIIlIlIllIlIlIllIl = tickableSounds.iterator();
    "".length();
    if ((72 + 11 - -46 + 29 ^ 29 + '' - 55 + 52) == 0) {
      return;
    }
    while (!lIIIllllllllII(lllllllllllllllIIlIlIllIlIlIllIl.hasNext()))
    {
      ITickableSound lllllllllllllllIIlIlIllIlIlllIlI = (ITickableSound)lllllllllllllllIIlIlIllIlIlIllIl.next();
      lllllllllllllllIIlIlIllIlIlllIlI.update();
      if (lIIlIIIIIIIIII(lllllllllllllllIIlIlIllIlIlllIlI.isDonePlaying()))
      {
        lllllllllllllllIIlIlIllIlIlllIll.stopSound(lllllllllllllllIIlIlIllIlIlllIlI);
        "".length();
        if (((0x24 ^ 0x3F ^ 0x22 ^ 0x2D) & (0xBF ^ 0xA3 ^ 0x2D ^ 0x25 ^ -" ".length())) != -" ".length()) {}
      }
      else
      {
        String lllllllllllllllIIlIlIllIlIlllIIl = (String)invPlayingSounds.get(lllllllllllllllIIlIlIllIlIlllIlI);
        sndSystem.setVolume(lllllllllllllllIIlIlIllIlIlllIIl, lllllllllllllllIIlIlIllIlIlllIll.getNormalizedVolume(lllllllllllllllIIlIlIllIlIlllIlI, (SoundPoolEntry)playingSoundPoolEntries.get(lllllllllllllllIIlIlIllIlIlllIlI), sndHandler.getSound(lllllllllllllllIIlIlIllIlIlllIlI.getSoundLocation()).getSoundCategory()));
        sndSystem.setPitch(lllllllllllllllIIlIlIllIlIlllIIl, lllllllllllllllIIlIlIllIlIlllIll.getNormalizedPitch(lllllllllllllllIIlIlIllIlIlllIlI, (SoundPoolEntry)playingSoundPoolEntries.get(lllllllllllllllIIlIlIllIlIlllIlI)));
        sndSystem.setPosition(lllllllllllllllIIlIlIllIlIlllIIl, lllllllllllllllIIlIlIllIlIlllIlI.getXPosF(), lllllllllllllllIIlIlIllIlIlllIlI.getYPosF(), lllllllllllllllIIlIlIllIlIlllIlI.getZPosF());
      }
    }
    Iterator<Map.Entry<String, ISound>> lllllllllllllllIIlIlIllIlIlllIII = playingSounds.entrySet().iterator();
    "".length();
    if (((87 + 8 - 38 + 89 ^ 4 + 108 - 98 + 134) & (71 + 89 - 13 + 4 ^ 117 + 75 - 117 + 70 ^ -" ".length())) != 0) {
      return;
    }
    while (!lIIIllllllllII(lllllllllllllllIIlIlIllIlIlllIII.hasNext()))
    {
      Map.Entry<String, ISound> lllllllllllllllIIlIlIllIlIllIlll = (Map.Entry)lllllllllllllllIIlIlIllIlIlllIII.next();
      String lllllllllllllllIIlIlIllIlIllIllI = (String)lllllllllllllllIIlIlIllIlIllIlll.getKey();
      ISound lllllllllllllllIIlIlIllIlIllIlIl = (ISound)lllllllllllllllIIlIlIllIlIllIlll.getValue();
      if (lIIIllllllllII(sndSystem.playing(lllllllllllllllIIlIlIllIlIllIllI)))
      {
        int lllllllllllllllIIlIlIllIlIllIlII = ((Integer)playingSoundsStopTime.get(lllllllllllllllIIlIlIllIlIllIllI)).intValue();
        if (lIIlIIIIIIIIll(lllllllllllllllIIlIlIllIlIllIlII, playTime))
        {
          int lllllllllllllllIIlIlIllIlIllIIll = lllllllllllllllIIlIlIllIlIllIlIl.getRepeatDelay();
          if ((lIIlIIIIIIIIII(lllllllllllllllIIlIlIllIlIllIlIl.canRepeat())) && (lIIlIIIIIIIlII(lllllllllllllllIIlIlIllIlIllIIll))) {
            "".length();
          }
          lllllllllllllllIIlIlIllIlIlllIII.remove();
          logger.debug(LOG_MARKER, lIlllIlIllll[lIlllIllIIll[5]], new Object[] { lllllllllllllllIIlIlIllIlIllIllI });
          sndSystem.removeSource(lllllllllllllllIIlIlIllIlIllIllI);
          "".length();
          "".length();
          try
          {
            "".length();
            "".length();
            if ("  ".length() > "   ".length()) {
              return;
            }
          }
          catch (RuntimeException localRuntimeException)
          {
            if (lIIlIIIIIIIIII(lllllllllllllllIIlIlIllIlIllIlIl instanceof ITickableSound)) {
              "".length();
            }
          }
        }
      }
    }
    Iterator<Map.Entry<ISound, Integer>> lllllllllllllllIIlIlIllIlIllIIlI = delayedSounds.entrySet().iterator();
    "".length();
    if (" ".length() < 0) {
      return;
    }
    while (!lIIIllllllllII(lllllllllllllllIIlIlIllIlIllIIlI.hasNext()))
    {
      Map.Entry<ISound, Integer> lllllllllllllllIIlIlIllIlIllIIIl = (Map.Entry)lllllllllllllllIIlIlIllIlIllIIlI.next();
      if (lIIlIIIIIIIlIl(playTime, ((Integer)lllllllllllllllIIlIlIllIlIllIIIl.getValue()).intValue()))
      {
        ISound lllllllllllllllIIlIlIllIlIllIIII = (ISound)lllllllllllllllIIlIlIllIlIllIIIl.getKey();
        if (lIIlIIIIIIIIII(lllllllllllllllIIlIlIllIlIllIIII instanceof ITickableSound)) {
          ((ITickableSound)lllllllllllllllIIlIlIllIlIllIIII).update();
        }
        lllllllllllllllIIlIlIllIlIlllIll.playSound(lllllllllllllllIIlIlIllIlIllIIII);
        lllllllllllllllIIlIlIllIlIllIIlI.remove();
      }
    }
  }
  
  private static boolean lIIlIIIIIIIIII(int ???)
  {
    int lllllllllllllllIIlIlIlIllIlIlIII;
    return ??? != 0;
  }
  
  private static void lIIIlllllllIll()
  {
    lIlllIllIIll = new int[18];
    lIlllIllIIll[0] = ((36 + 62 - 78 + 116 ^ '¤' + 38 - 40 + 21) & (0x7C ^ 0x7B ^ 0x11 ^ 0x29 ^ -" ".length()));
    lIlllIllIIll[1] = " ".length();
    lIlllIllIIll[2] = "  ".length();
    lIlllIllIIll[3] = "   ".length();
    lIlllIllIIll[4] = (0xBE ^ 0xBA);
    lIlllIllIIll[5] = (0x60 ^ 0x65);
    lIlllIllIIll[6] = (0x26 ^ 0x20);
    lIlllIllIIll[7] = (0x9E ^ 0x99);
    lIlllIllIIll[8] = (0xDB ^ 0x9B ^ 0x40 ^ 0x8);
    lIlllIllIIll[9] = (0x1C ^ 0x15);
    lIlllIllIIll[10] = (0x6F ^ 0x65);
    lIlllIllIIll[11] = (0x5A ^ 0x4E);
    lIlllIllIIll[12] = (0x77 ^ 0x7C);
    lIlllIllIIll[13] = (0xCE ^ 0xC2 ^ (0x1B ^ 0x35) & (0x5 ^ 0x2B ^ 0xFFFFFFFF));
    lIlllIllIIll[14] = (0x3 ^ 0xE);
    lIlllIllIIll[15] = (114 + 43 - 150 + 137 ^ 33 + 39 - -14 + 72);
    lIlllIllIIll[16] = (0x94 ^ 0x9B);
    lIlllIllIIll[17] = (0xB2 ^ 0xA2);
  }
  
  private static URL getURLForSoundResource(ResourceLocation lllllllllllllllIIlIlIllIIIllllIl)
  {
    ;
    ;
    ;
    ;
    String lllllllllllllllIIlIlIllIIlIIIIII = String.format(lIlllIlIllll[lIlllIllIIll[14]], new Object[] { lIlllIlIllll[lIlllIllIIll[15]], lllllllllllllllIIlIlIllIIlIIIIIl.getResourceDomain(), lllllllllllllllIIlIlIllIIlIIIIIl.getResourcePath() });
    URLStreamHandler lllllllllllllllIIlIlIllIIIllllll = new URLStreamHandler()
    {
      protected URLConnection openConnection(URL lllllllllllllllIIlIlIlIIIlllIlIl)
      {
        ;
        ;
        new URLConnection(lllllllllllllllIIlIlIlIIIlllIlIl)
        {
          public InputStream getInputStream()
            throws IOException
          {
            ;
            return Minecraft.getMinecraft().getResourceManager().getResource(val$p_148612_0_).getInputStream();
          }
          
          public void connect()
            throws IOException
          {}
        };
      }
    };
    try
    {
      return new URL(null, lllllllllllllllIIlIlIllIIlIIIIII, lllllllllllllllIIlIlIllIIIllllll);
    }
    catch (MalformedURLException lllllllllllllllIIlIlIllIIIlllllI)
    {
      throw new Error(lIlllIlIllll[lIlllIllIIll[16]]);
    }
  }
  
  private static String lIIIlllllIIlll(String lllllllllllllllIIlIlIlIlllIIlllI, String lllllllllllllllIIlIlIlIlllIlIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIlIlIlllIIlllI = new String(Base64.getDecoder().decode(lllllllllllllllIIlIlIlIlllIIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlIlIlIlllIlIIIl = new StringBuilder();
    char[] lllllllllllllllIIlIlIlIlllIlIIII = lllllllllllllllIIlIlIlIlllIlIIlI.toCharArray();
    int lllllllllllllllIIlIlIlIlllIIllll = lIlllIllIIll[0];
    char lllllllllllllllIIlIlIlIlllIIlIIl = lllllllllllllllIIlIlIlIlllIIlllI.toCharArray();
    float lllllllllllllllIIlIlIlIlllIIlIII = lllllllllllllllIIlIlIlIlllIIlIIl.length;
    char lllllllllllllllIIlIlIlIlllIIIlll = lIlllIllIIll[0];
    while (lIIlIIIIIIlIlI(lllllllllllllllIIlIlIlIlllIIIlll, lllllllllllllllIIlIlIlIlllIIlIII))
    {
      char lllllllllllllllIIlIlIlIlllIlIlII = lllllllllllllllIIlIlIlIlllIIlIIl[lllllllllllllllIIlIlIlIlllIIIlll];
      "".length();
      "".length();
      if (" ".length() < 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlIlIlIlllIlIIIl);
  }
  
  public void playSound(ISound lllllllllllllllIIlIlIllIlIIIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIlIIIIIIIIII(loaded)) {
      if (lIIlIIIIIIIIlI(lIIlIIIIIIlIII(sndSystem.getMasterVolume(), 0.0F)))
      {
        logger.debug(LOG_MARKER, lIlllIlIllll[lIlllIllIIll[6]], new Object[] { lllllllllllllllIIlIlIllIlIIIlIII.getSoundLocation() });
        "".length();
        if (null == null) {}
      }
      else
      {
        SoundEventAccessorComposite lllllllllllllllIIlIlIllIlIIIIlll = sndHandler.getSound(lllllllllllllllIIlIlIllIlIIIlIII.getSoundLocation());
        if (lIIlIIIIIIIllI(lllllllllllllllIIlIlIllIlIIIIlll))
        {
          logger.warn(LOG_MARKER, lIlllIlIllll[lIlllIllIIll[7]], new Object[] { lllllllllllllllIIlIlIllIlIIIlIII.getSoundLocation() });
          "".length();
          if ("   ".length() != " ".length()) {}
        }
        else
        {
          SoundPoolEntry lllllllllllllllIIlIlIllIlIIIIllI = lllllllllllllllIIlIlIllIlIIIIlll.cloneEntry();
          if (lIIlIIIIIIIIIl(lllllllllllllllIIlIlIllIlIIIIllI, SoundHandler.missing_sound))
          {
            logger.warn(LOG_MARKER, lIlllIlIllll[lIlllIllIIll[8]], new Object[] { lllllllllllllllIIlIlIllIlIIIIlll.getSoundEventLocation() });
            "".length();
            if (null == null) {}
          }
          else
          {
            float lllllllllllllllIIlIlIllIlIIIIlIl = lllllllllllllllIIlIlIllIlIIIlIII.getVolume();
            float lllllllllllllllIIlIlIllIlIIIIlII = 16.0F;
            if (lIIlIIIIIIIlII(lIIlIIIIIIlIIl(lllllllllllllllIIlIlIllIlIIIIlIl, 1.0F))) {
              lllllllllllllllIIlIlIllIlIIIIlII *= lllllllllllllllIIlIlIllIlIIIIlIl;
            }
            SoundCategory lllllllllllllllIIlIlIllIlIIIIIll = lllllllllllllllIIlIlIllIlIIIIlll.getSoundCategory();
            float lllllllllllllllIIlIlIllIlIIIIIlI = lllllllllllllllIIlIlIllIIlllllIl.getNormalizedVolume(lllllllllllllllIIlIlIllIlIIIlIII, lllllllllllllllIIlIlIllIlIIIIllI, lllllllllllllllIIlIlIllIlIIIIIll);
            double lllllllllllllllIIlIlIllIlIIIIIIl = lllllllllllllllIIlIlIllIIlllllIl.getNormalizedPitch(lllllllllllllllIIlIlIllIlIIIlIII, lllllllllllllllIIlIlIllIlIIIIllI);
            ResourceLocation lllllllllllllllIIlIlIllIlIIIIIII = lllllllllllllllIIlIlIllIlIIIIllI.getSoundPoolEntryLocation();
            if (lIIIllllllllII(lIIlIIIIIIlIIl(lllllllllllllllIIlIlIllIlIIIIIlI, 0.0F)))
            {
              logger.debug(LOG_MARKER, lIlllIlIllll[lIlllIllIIll[9]], new Object[] { lllllllllllllllIIlIlIllIlIIIIIII });
              "".length();
              if (" ".length() < (28 + 91 - -12 + 31 ^ '' + 114 - 247 + 152)) {}
            }
            else
            {
              if ((lIIlIIIIIIIIII(lllllllllllllllIIlIlIllIlIIIlIII.canRepeat())) && (lIIIllllllllII(lllllllllllllllIIlIlIllIlIIIlIII.getRepeatDelay())))
              {
                "".length();
                if (-"  ".length() <= 0) {
                  break label434;
                }
              }
              label434:
              boolean lllllllllllllllIIlIlIllIIlllllll = lIlllIllIIll[0];
              String lllllllllllllllIIlIlIllIIllllllI = MathHelper.getRandomUuid(ThreadLocalRandom.current()).toString();
              if (lIIlIIIIIIIIII(lllllllllllllllIIlIlIllIlIIIIllI.isStreamingSound()))
              {
                sndSystem.newStreamingSource(lIlllIllIIll[0], lllllllllllllllIIlIlIllIIllllllI, getURLForSoundResource(lllllllllllllllIIlIlIllIlIIIIIII), lllllllllllllllIIlIlIllIlIIIIIII.toString(), lllllllllllllllIIlIlIllIIlllllll, lllllllllllllllIIlIlIllIlIIIlIII.getXPosF(), lllllllllllllllIIlIlIllIlIIIlIII.getYPosF(), lllllllllllllllIIlIlIllIlIIIlIII.getZPosF(), lllllllllllllllIIlIlIllIlIIIlIII.getAttenuationType().getTypeInt(), lllllllllllllllIIlIlIllIlIIIIlII);
                "".length();
                if (-"   ".length() <= 0) {}
              }
              else
              {
                sndSystem.newSource(lIlllIllIIll[0], lllllllllllllllIIlIlIllIIllllllI, getURLForSoundResource(lllllllllllllllIIlIlIllIlIIIIIII), lllllllllllllllIIlIlIllIlIIIIIII.toString(), lllllllllllllllIIlIlIllIIlllllll, lllllllllllllllIIlIlIllIlIIIlIII.getXPosF(), lllllllllllllllIIlIlIllIlIIIlIII.getYPosF(), lllllllllllllllIIlIlIllIlIIIlIII.getZPosF(), lllllllllllllllIIlIlIllIlIIIlIII.getAttenuationType().getTypeInt(), lllllllllllllllIIlIlIllIlIIIIlII);
              }
              logger.debug(LOG_MARKER, lIlllIlIllll[lIlllIllIIll[10]], new Object[] { lllllllllllllllIIlIlIllIlIIIIllI.getSoundPoolEntryLocation(), lllllllllllllllIIlIlIllIlIIIIlll.getSoundEventLocation(), lllllllllllllllIIlIlIllIIllllllI });
              sndSystem.setPitch(lllllllllllllllIIlIlIllIIllllllI, (float)lllllllllllllllIIlIlIllIlIIIIIIl);
              sndSystem.setVolume(lllllllllllllllIIlIlIllIIllllllI, lllllllllllllllIIlIlIllIlIIIIIlI);
              sndSystem.play(lllllllllllllllIIlIlIllIIllllllI);
              "".length();
              "".length();
              "".length();
              if (lIIIlllllllllI(lllllllllllllllIIlIlIllIlIIIIIll, SoundCategory.MASTER)) {
                "".length();
              }
              if (lIIlIIIIIIIIII(lllllllllllllllIIlIlIllIlIIIlIII instanceof ITickableSound)) {
                "".length();
              }
            }
          }
        }
      }
    }
  }
  
  private static int lIIlIIIIIIlIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIIlIIIIIIIllI(Object ???)
  {
    int lllllllllllllllIIlIlIlIllIlIlIlI;
    return ??? == null;
  }
  
  private static boolean lIIlIIIIIIIIIl(Object ???, Object arg1)
  {
    Object localObject;
    double lllllllllllllllIIlIlIlIllIlIllII;
    return ??? == localObject;
  }
  
  private float getNormalizedPitch(ISound lllllllllllllllIIlIlIllIIllIlllI, SoundPoolEntry lllllllllllllllIIlIlIllIIllIlIll)
  {
    ;
    ;
    return (float)MathHelper.clamp_double(lllllllllllllllIIlIlIllIIllIlllI.getPitch() * lllllllllllllllIIlIlIllIIllIlIll.getPitch(), 0.5D, 2.0D);
  }
  
  private static boolean lIIlIIIIIIIlII(int ???)
  {
    float lllllllllllllllIIlIlIlIllIlIIIlI;
    return ??? > 0;
  }
  
  private float getSoundCategoryVolume(SoundCategory lllllllllllllllIIlIlIllIlllIIIll)
  {
    ;
    ;
    if ((lIIIllllllllIl(lllllllllllllllIIlIlIllIlllIIIll)) && (lIIIlllllllllI(lllllllllllllllIIlIlIllIlllIIIll, SoundCategory.MASTER)))
    {
      "".length();
      if (" ".length() > -" ".length()) {
        break label48;
      }
      return 0.0F;
    }
    label48:
    return 1.0F;
  }
  
  public void unloadSoundSystem()
  {
    ;
    if (lIIlIIIIIIIIII(loaded))
    {
      lllllllllllllllIIlIlIllIllIIllII.stopAllSounds();
      sndSystem.cleanup();
      loaded = lIlllIllIIll[0];
    }
  }
  
  private static String lIIIlllllIIIII(String lllllllllllllllIIlIlIlIllllIIIIl, String lllllllllllllllIIlIlIlIllllIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlIlIlIllllIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlIlIlIllllIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIlIlIlIllllIIlIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIIlIlIlIllllIIlIl.init(lIlllIllIIll[2], lllllllllllllllIIlIlIlIllllIIllI);
      return new String(lllllllllllllllIIlIlIlIllllIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlIlIlIllllIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlIlIlIllllIIlII)
    {
      lllllllllllllllIIlIlIlIllllIIlII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIlIIIIIIlIlI(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIIlIlIlIllIlllllI;
    return ??? < i;
  }
  
  private static void lIIIlllllIlIlI()
  {
    lIlllIlIllll = new String[lIlllIllIIll[17]];
    lIlllIlIllll[lIlllIllIIll[0]] = lIIIlllllIIIII("wsJjKfi9Rss=", "omodv");
    lIlllIlIllll[lIlllIllIIll[1]] = lIIIlllllIIIII("Kcp7219OHOs=", "fQjVR");
    lIlllIlIllll[lIlllIllIIll[2]] = lIIIlllllIIIIl("aP1KmBk2BJyBB7t3S/gRsfrtAjxma7tXuLXdUy3DeDUwvicrijKaeBWB9Zk5/YZO", "frwLL");
    lIlllIlIllll[lIlllIllIIll[3]] = lIIIlllllIIIII("e4nvVK2YxIGMFgABWls6jEkTF0rBpb0B", "kAvtg");
    lIlllIlIllll[lIlllIllIIll[4]] = lIIIlllllIIIIl("Gs+fxeUTux48hxdKY5F05lfy8lLJd4Toa24TaW8Qa2gpJCQtYp/mWJ1kSXiyxvnMM+GxutY0s9o=", "cYKKk");
    lIlllIlIllll[lIlllIllIIll[5]] = lIIIlllllIIIII("i8wExVizs8Wh0ZBK6QJk7ajH/CfbE4T+6JYj4Tr7S/IpjwTOynAItyJCYib8FhAtbgCiLU5gp4Y=", "WHpVI");
    lIlllIlIllll[lIlllIllIIll[6]] = lIIIlllllIIIIl("NlOeO66EkvNm04BWaGk0r0nz+A8UMdHHGpF+CWWN4XDwDs0z9B0Wz6HgkoaIbNW67/9+jguWDbc=", "gFlqa");
    lIlllIlIllll[lIlllIllIIll[7]] = lIIIlllllIIlll("MxQZJwgDWgwqRBYWGTxEExQTKwsRFFg2CxMUHAASAxQMf0QdBw==", "fzxEd");
    lIlllIlIllll[lIlllIllIIll[8]] = lIIIlllllIIIII("T1Zaz94gX82xKRzg0fKtn6UOiztGDeTznf+jDTksvVK/oqV+GGtsYQ==", "PYJoz");
    lIlllIlIllll[lIlllIllIIll[9]] = lIIIlllllIIIII("5Mdrae69OTqeYnHoSVZDeliUE9rJsoBoH8/NmjvgTJw8Lau6jgkKNrmSLbEzvjSx", "svqIW");
    lIlllIlIllll[lIlllIllIIll[10]] = lIIIlllllIIIIl("B8OGb6WqxUuN1gW90PvDMQ0+vt0V0GMZK/7DIVaIQwo6iOonvzxSUCdj7sCYgEt8", "PuDgs");
    lIlllIlIllll[lIlllIllIIll[12]] = lIIIlllllIIIII("Qr8FIjXxXXrWLS+Grkxmq+l8wAAnVRxy", "IgwXC");
    lIlllIlIllll[lIlllIllIIll[13]] = lIIIlllllIIlll("HQYXBygmDQNSJicCChwgI0MfDw==", "OcdrE");
    lIlllIlIllll[lIlllIllIIll[14]] = lIIIlllllIIlll("XylPditAfwY=", "zZuSX");
    lIlllIlIllll[lIlllIllIIll[15]] = lIIIlllllIIlll("Nww9PyA0Cyo/ODsGIA==", "ZoNPU");
    lIlllIlIllll[lIlllIllIIll[16]] = lIIIlllllIIIIl("Vj4nZrTHKkEgWhPrFzzWPLAleW14idPuuePOkhg/vhHnHqptsblpQA==", "XcZgK");
  }
  
  public void pauseAllSounds()
  {
    ;
    ;
    float lllllllllllllllIIlIlIllIIlIlIlll = playingSounds.keySet().iterator();
    "".length();
    if (-" ".length() == "  ".length()) {
      return;
    }
    while (!lIIIllllllllII(lllllllllllllllIIlIlIllIIlIlIlll.hasNext()))
    {
      String lllllllllllllllIIlIlIllIIlIllIlI = (String)lllllllllllllllIIlIlIllIIlIlIlll.next();
      logger.debug(LOG_MARKER, lIlllIlIllll[lIlllIllIIll[12]], new Object[] { lllllllllllllllIIlIlIllIIlIllIlI });
      sndSystem.pause(lllllllllllllllIIlIlIllIIlIllIlI);
    }
  }
  
  public void setListener(EntityPlayer lllllllllllllllIIlIlIllIIIIlIlII, float lllllllllllllllIIlIlIllIIIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIIlIIIIIIIIII(loaded)) && (lIIIllllllllIl(lllllllllllllllIIlIlIllIIIlIIllI)))
    {
      float lllllllllllllllIIlIlIllIIIlIIlII = prevRotationPitch + (rotationPitch - prevRotationPitch) * lllllllllllllllIIlIlIllIIIIlIIll;
      float lllllllllllllllIIlIlIllIIIlIIIll = prevRotationYaw + (rotationYaw - prevRotationYaw) * lllllllllllllllIIlIlIllIIIIlIIll;
      double lllllllllllllllIIlIlIllIIIlIIIlI = prevPosX + (posX - prevPosX) * lllllllllllllllIIlIlIllIIIIlIIll;
      double lllllllllllllllIIlIlIllIIIlIIIIl = prevPosY + (posY - prevPosY) * lllllllllllllllIIlIlIllIIIIlIIll + lllllllllllllllIIlIlIllIIIlIIllI.getEyeHeight();
      double lllllllllllllllIIlIlIllIIIlIIIII = prevPosZ + (posZ - prevPosZ) * lllllllllllllllIIlIlIllIIIIlIIll;
      float lllllllllllllllIIlIlIllIIIIlllll = MathHelper.cos((lllllllllllllllIIlIlIllIIIlIIIll + 90.0F) * 0.017453292F);
      float lllllllllllllllIIlIlIllIIIIllllI = MathHelper.sin((lllllllllllllllIIlIlIllIIIlIIIll + 90.0F) * 0.017453292F);
      float lllllllllllllllIIlIlIllIIIIlllIl = MathHelper.cos(-lllllllllllllllIIlIlIllIIIlIIlII * 0.017453292F);
      float lllllllllllllllIIlIlIllIIIIlllII = MathHelper.sin(-lllllllllllllllIIlIlIllIIIlIIlII * 0.017453292F);
      float lllllllllllllllIIlIlIllIIIIllIll = MathHelper.cos((-lllllllllllllllIIlIlIllIIIlIIlII + 90.0F) * 0.017453292F);
      float lllllllllllllllIIlIlIllIIIIllIlI = MathHelper.sin((-lllllllllllllllIIlIlIllIIIlIIlII + 90.0F) * 0.017453292F);
      float lllllllllllllllIIlIlIllIIIIllIIl = lllllllllllllllIIlIlIllIIIIlllll * lllllllllllllllIIlIlIllIIIIlllIl;
      float lllllllllllllllIIlIlIllIIIIllIII = lllllllllllllllIIlIlIllIIIIllllI * lllllllllllllllIIlIlIllIIIIlllIl;
      float lllllllllllllllIIlIlIllIIIIlIlll = lllllllllllllllIIlIlIllIIIIlllll * lllllllllllllllIIlIlIllIIIIllIll;
      float lllllllllllllllIIlIlIllIIIIlIllI = lllllllllllllllIIlIlIllIIIIllllI * lllllllllllllllIIlIlIllIIIIllIll;
      sndSystem.setListenerPosition((float)lllllllllllllllIIlIlIllIIIlIIIlI, (float)lllllllllllllllIIlIlIllIIIlIIIIl, (float)lllllllllllllllIIlIlIllIIIlIIIII);
      sndSystem.setListenerOrientation(lllllllllllllllIIlIlIllIIIIllIIl, lllllllllllllllIIlIlIllIIIIlllII, lllllllllllllllIIlIlIllIIIIllIII, lllllllllllllllIIlIlIllIIIIlIlll, lllllllllllllllIIlIlIllIIIIllIlI, lllllllllllllllIIlIlIllIIIIlIllI);
    }
  }
  
  private static boolean lIIIllllllllII(int ???)
  {
    char lllllllllllllllIIlIlIlIllIlIIllI;
    return ??? == 0;
  }
  
  static
  {
    lIIIlllllllIll();
    lIIIlllllIlIlI();
    LOG_MARKER = MarkerManager.getMarker(lIlllIlIllll[lIlllIllIIll[0]]);
  }
  
  private static int lIIIllllllllll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void reloadSoundSystem()
  {
    ;
    lllllllllllllllIIlIlIllIllllIIII.unloadSoundSystem();
    lllllllllllllllIIlIlIllIlllIllll.loadSoundSystem();
  }
  
  private static boolean lIIlIIIIIIIlIl(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIIlIlIlIlllIIIIlI;
    return ??? >= i;
  }
  
  public void stopAllSounds()
  {
    ;
    ;
    ;
    if (lIIlIIIIIIIIII(loaded))
    {
      lllllllllllllllIIlIlIllIllIIIlII = playingSounds.keySet().iterator();
      "".length();
      if (null != null) {
        return;
      }
      while (!lIIIllllllllII(lllllllllllllllIIlIlIllIllIIIlII.hasNext()))
      {
        String lllllllllllllllIIlIlIllIllIIIlll = (String)lllllllllllllllIIlIlIllIllIIIlII.next();
        sndSystem.stop(lllllllllllllllIIlIlIllIllIIIlll);
      }
      playingSounds.clear();
      delayedSounds.clear();
      tickableSounds.clear();
      categorySounds.clear();
      playingSoundPoolEntries.clear();
      playingSoundsStopTime.clear();
    }
  }
  
  public void playDelayedSound(ISound lllllllllllllllIIlIlIllIIlIIIlll, int lllllllllllllllIIlIlIllIIlIIIllI)
  {
    ;
    ;
    ;
    "".length();
  }
  
  class SoundSystemStarterThread
    extends SoundSystem
  {
    static {}
    
    private static boolean lllIlIIlIIIl(Object ???)
    {
      int lllllllllllllllllIlIIIlllIlIIlIl;
      return ??? == null;
    }
    
    private SoundSystemStarterThread() {}
    
    private static void lllIlIIlIIII()
    {
      lIIlIIlllII = new int[2];
      lIIlIIlllII[0] = ((0x5F ^ 0x40 ^ 0xBC ^ 0x92) & (0x10 ^ 0x15 ^ 0xA6 ^ 0x92 ^ -" ".length()));
      lIIlIIlllII[1] = " ".length();
    }
    
    private static boolean lllIlIIlIIll(int ???)
    {
      String lllllllllllllllllIlIIIlllIlIIIll;
      return ??? == 0;
    }
    
    public boolean playing(String lllllllllllllllllIlIIIlllIllIIII)
    {
      synchronized (SoundSystemConfig.THREAD_SYNC)
      {
        ;
        ;
        ;
        ;
        if (lllIlIIlIIIl(soundLibrary)) {
          return lIIlIIlllII[0];
        }
        Source lllllllllllllllllIlIIIlllIlIllll = (Source)soundLibrary.getSources().get(lllllllllllllllllIlIIIlllIllIIII);
        if (lllIlIIlIIIl(lllllllllllllllllIlIIIlllIlIllll))
        {
          "".length();
          if (-"   ".length() >= 0) {
            return (38 + 82 - 80 + 143 ^ 76 + 63 - 137 + 134) & (0x73 ^ 0x8 ^ 0xE7 ^ 0xA3 ^ -" ".length());
          }
        }
        else if ((lllIlIIlIIll(lllllllllllllllllIlIIIlllIlIllll.playing())) && (lllIlIIlIIll(lllllllllllllllllIlIIIlllIlIllll.paused())) && (lllIlIIlIIll(preLoad)))
        {
          "".length();
          if (null == null) {
            break label180;
          }
          return (0xB ^ 0x4B) & (0xEA ^ 0xAA ^ 0xFFFFFFFF);
        }
        label180:
        return lIIlIIlllII[1];
      }
    }
  }
}

package net.minecraft.client.audio;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.util.RegistrySimple;
import net.minecraft.util.ResourceLocation;

public class SoundRegistry
  extends RegistrySimple<ResourceLocation, SoundEventAccessorComposite>
{
  protected Map<ResourceLocation, SoundEventAccessorComposite> createUnderlyingMap()
  {
    ;
    soundRegistry = Maps.newHashMap();
    return soundRegistry;
  }
  
  public void clearMap()
  {
    ;
    soundRegistry.clear();
  }
  
  public SoundRegistry() {}
  
  public void registerSound(SoundEventAccessorComposite lllllllllllllllIIlIIlllIlIIIIIll)
  {
    ;
    ;
    lllllllllllllllIIlIIlllIlIIIIIlI.putObject(lllllllllllllllIIlIIlllIlIIIIIll.getSoundEventLocation(), lllllllllllllllIIlIIlllIlIIIIIll);
  }
}

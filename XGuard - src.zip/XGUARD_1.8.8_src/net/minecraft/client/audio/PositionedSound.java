package net.minecraft.client.audio;

import net.minecraft.util.ResourceLocation;

public abstract class PositionedSound
  implements ISound
{
  public float getZPosF()
  {
    ;
    return zPosF;
  }
  
  protected PositionedSound(ResourceLocation lllllllllllllllIlllIIlIIIlllIlII)
  {
    positionedSoundLocation = lllllllllllllllIlllIIlIIIlllIlII;
  }
  
  static {}
  
  public float getXPosF()
  {
    ;
    return xPosF;
  }
  
  public float getYPosF()
  {
    ;
    return yPosF;
  }
  
  public int getRepeatDelay()
  {
    ;
    return repeatDelay;
  }
  
  public ISound.AttenuationType getAttenuationType()
  {
    ;
    return attenuationType;
  }
  
  public ResourceLocation getSoundLocation()
  {
    ;
    return positionedSoundLocation;
  }
  
  private static void llIllIIIlllII()
  {
    lIIIllIIIlIl = new int[1];
    lIIIllIIIlIl[0] = ((0x86 ^ 0x9A) & (0xD8 ^ 0xC4 ^ 0xFFFFFFFF));
  }
  
  public float getPitch()
  {
    ;
    return pitch;
  }
  
  public boolean canRepeat()
  {
    ;
    return repeat;
  }
  
  public float getVolume()
  {
    ;
    return volume;
  }
}

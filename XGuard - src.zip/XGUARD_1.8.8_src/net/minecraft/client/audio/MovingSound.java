package net.minecraft.client.audio;

import net.minecraft.util.ResourceLocation;

public abstract class MovingSound
  extends PositionedSound
  implements ITickableSound
{
  private static void lIIIIIIllIIl()
  {
    lIlIIIIlII = new int[1];
    lIlIIIIlII[0] = ((0x90 ^ 0x80) & (0x7 ^ 0x17 ^ 0xFFFFFFFF));
  }
  
  protected MovingSound(ResourceLocation lIIIlIIIIlIl)
  {
    lIIIlIIIIllI.<init>(lIIIlIIIIlIl);
  }
  
  static {}
  
  public boolean isDonePlaying()
  {
    ;
    return donePlaying;
  }
}

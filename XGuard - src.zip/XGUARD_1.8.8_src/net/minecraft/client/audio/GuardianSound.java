package net.minecraft.client.audio;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.entity.monster.EntityGuardian;
import net.minecraft.util.ResourceLocation;

public class GuardianSound
  extends MovingSound
{
  private static void llllIlIlIllI()
  {
    lIIlllIIllI = new int[4];
    lIIlllIIllI[0] = ((0x5A ^ 0x34 ^ 0x8 ^ 0x3C) & (0xE ^ 0x7D ^ 0x4D ^ 0x64 ^ -" ".length()));
    lIIlllIIllI[1] = " ".length();
    lIIlllIIllI[2] = (0x56 ^ 0x75 ^ 0xA8 ^ 0x83);
    lIIlllIIllI[3] = "  ".length();
  }
  
  private static boolean llllIlIllIII(int ???)
  {
    Exception lllllllllllllllllIIlIllIllIIllIl;
    return ??? != 0;
  }
  
  public GuardianSound(EntityGuardian lllllllllllllllllIIlIllIlllIIlII)
  {
    lllllllllllllllllIIlIllIlllIIlIl.<init>(new ResourceLocation(lIIlllIIlIl[lIIlllIIllI[0]]));
    guardian = lllllllllllllllllIIlIllIlllIIlII;
    attenuationType = ISound.AttenuationType.NONE;
    repeat = lIIlllIIllI[1];
    repeatDelay = lIIlllIIllI[0];
  }
  
  private static boolean llllIlIlIlll(int ???)
  {
    byte lllllllllllllllllIIlIllIllIIlIll;
    return ??? == 0;
  }
  
  private static void llllIlIlIlIl()
  {
    lIIlllIIlIl = new String[lIIlllIIllI[1]];
    lIIlllIIlIl[lIIlllIIllI[0]] = llllIlIlIlII("z25r8I5yJTGhxJoDnKi9gPmaYSW3kDiO3gwkgs//eRk=", "iNknn");
  }
  
  static
  {
    llllIlIlIllI();
    llllIlIlIlIl();
  }
  
  public void update()
  {
    ;
    ;
    if ((llllIlIlIlll(guardian.isDead)) && (llllIlIllIII(guardian.hasTargetedEntity())))
    {
      xPosF = ((float)guardian.posX);
      yPosF = ((float)guardian.posY);
      zPosF = ((float)guardian.posZ);
      float lllllllllllllllllIIlIllIllIllllI = guardian.func_175477_p(0.0F);
      volume = (0.0F + 1.0F * lllllllllllllllllIIlIllIllIllllI * lllllllllllllllllIIlIllIllIllllI);
      pitch = (0.7F + 0.5F * lllllllllllllllllIIlIllIllIllllI);
      "".length();
      if (-" ".length() <= 0) {}
    }
    else
    {
      donePlaying = lIIlllIIllI[1];
    }
  }
  
  private static String llllIlIlIlII(String lllllllllllllllllIIlIllIllIlIlII, String lllllllllllllllllIIlIllIllIlIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIlIllIllIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIlIllIllIlIIll.getBytes(StandardCharsets.UTF_8)), lIIlllIIllI[2]), "DES");
      Cipher lllllllllllllllllIIlIllIllIlIllI = Cipher.getInstance("DES");
      lllllllllllllllllIIlIllIllIlIllI.init(lIIlllIIllI[3], lllllllllllllllllIIlIllIllIlIlll);
      return new String(lllllllllllllllllIIlIllIllIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIlIllIllIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIlIllIllIlIlIl)
    {
      lllllllllllllllllIIlIllIllIlIlIl.printStackTrace();
    }
    return null;
  }
}

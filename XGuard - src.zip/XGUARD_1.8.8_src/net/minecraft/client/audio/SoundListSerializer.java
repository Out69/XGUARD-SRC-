package net.minecraft.client.audio;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.JsonUtils;
import org.apache.commons.lang3.Validate;

public class SoundListSerializer
  implements JsonDeserializer<SoundList>
{
  private static void lIllllIIIIIlll()
  {
    llllIlllIIIl = new String[llllIlllIlII[23]];
    llllIlllIIIl[llllIlllIlII[0]] = lIllllIIIIIlII("rjHBFcodQKw=", "Jahdq");
    llllIlllIIIl[llllIlllIlII[1]] = lIllllIIIIIlII("+qO5V4lPl4M=", "FXwVu");
    llllIlllIIIl[llllIlllIlII[2]] = lIllllIIIIIlIl("JTUmPwkpJis=", "FTRZn");
    llllIlllIIIl[llllIlllIlII[3]] = lIllllIIIIIlIl("BTwbGDUlNk0aODg3ChYrNQ==", "LRmyY");
    llllIlllIIIl[llllIlllIlII[4]] = lIllllIIIIIllI("NJrR0IH9NO4=", "FsBFS");
    llllIlllIIIl[llllIlllIlII[5]] = lIllllIIIIIllI("FCbVUuEmvFQ=", "JWDzi");
    llllIlllIIIl[llllIlllIlII[6]] = lIllllIIIIIlIl("NAw8OQM=", "GcIWg");
    llllIlllIIIl[llllIlllIlII[7]] = lIllllIIIIIlII("E3kh8QAO3lg=", "TEpoW");
    llllIlllIIIl[llllIlllIlII[8]] = lIllllIIIIIlIl("DQIMMQ==", "ccaTp");
    llllIlllIIIl[llllIlllIlII[9]] = lIllllIIIIIlIl("DgsICg==", "zrxoo");
    llllIlllIIIl[llllIlllIlII[10]] = lIllllIIIIIlII("/EeB7dJsyYA=", "AgIjD");
    llllIlllIIIl[llllIlllIlII[11]] = lIllllIIIIIlII("7unBk4E0t8BW9zgNzlC/VQ==", "wBvQf");
    llllIlllIIIl[llllIlllIlII[12]] = lIllllIIIIIlIl("LCkoMwM/", "ZFDFn");
    llllIlllIIIl[llllIlllIlII[13]] = lIllllIIIIIlIl("Fx0FGRoE", "arilw");
    llllIlllIIIl[llllIlllIlII[14]] = lIllllIIIIIllI("06Z06EYgFzhXNYfKz0uoow==", "OTLmm");
    llllIlllIIIl[llllIlllIlII[15]] = lIllllIIIIIlII("5IHvq5GZSc0=", "BLNGr");
    llllIlllIIIl[llllIlllIlII[16]] = lIllllIIIIIlIl("MR4QMxA=", "AwdPx");
    llllIlllIIIl[llllIlllIlII[17]] = lIllllIIIIIlIl("PDYBJhscPFc3HgE7Hw==", "uXwGw");
    llllIlllIIIl[llllIlllIlII[18]] = lIllllIIIIIllI("eSTT4hNIn9Q=", "JLLxg");
    llllIlllIIIl[llllIlllIlII[19]] = lIllllIIIIIlIl("BAQ5DSIH", "saPjJ");
    llllIlllIIIl[llllIlllIlII[20]] = lIllllIIIIIlII("O7fVndou97glcB0xQbSI2w==", "vdqvz");
    llllIlllIIIl[llllIlllIlII[21]] = lIllllIIIIIlIl("IBIBPxQ+", "SfsZu");
    llllIlllIIIl[llllIlllIlII[22]] = lIllllIIIIIlIl("NxADBBgp", "Ddqay");
  }
  
  private static int lIllllIIIIlIll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static void lIllllIIIIlIlI()
  {
    llllIlllIlII = new int[24];
    llllIlllIlII[0] = ((0xF4 ^ 0xB7) & (0x5F ^ 0x1C ^ 0xFFFFFFFF));
    llllIlllIlII[1] = " ".length();
    llllIlllIlII[2] = "  ".length();
    llllIlllIlII[3] = "   ".length();
    llllIlllIlII[4] = ('' + 65 - 187 + 149 ^ 60 + 84 - 72 + 80);
    llllIlllIlII[5] = (0x93 ^ 0x96);
    llllIlllIlII[6] = (73 + 44 - 31 + 46 ^ 56 + 44 - -19 + 11);
    llllIlllIlII[7] = (0xAB ^ 0x8A ^ 0xE7 ^ 0xC1);
    llllIlllIlII[8] = (0x82 ^ 0x8A);
    llllIlllIlII[9] = (0x43 ^ 0x63 ^ 0x33 ^ 0x1A);
    llllIlllIlII[10] = (0x37 ^ 0x49 ^ 0x17 ^ 0x63);
    llllIlllIlII[11] = (0xF5 ^ 0xB6 ^ 0xFB ^ 0xB3);
    llllIlllIlII[12] = (0x4C ^ 0x40);
    llllIlllIlII[13] = (0xAC ^ 0xA1);
    llllIlllIlII[14] = (26 + '³' - 157 + 156 ^ 127 + 'º' - 227 + 108);
    llllIlllIlII[15] = (0x5A ^ 0x6 ^ 0xD5 ^ 0x86);
    llllIlllIlII[16] = (111 + 56 - 121 + 100 ^ 123 + 74 - 159 + 92);
    llllIlllIlII[17] = (0x1C ^ 0x44 ^ 0xE7 ^ 0xAE);
    llllIlllIlII[18] = (71 + 47 - 86 + 142 ^ 11 + 36 - -20 + 121);
    llllIlllIlII[19] = (0x67 ^ 0x6 ^ 0x9 ^ 0x7B);
    llllIlllIlII[20] = (0x5F ^ 0x1C ^ 0x36 ^ 0x61);
    llllIlllIlII[21] = (0x7F ^ 0x6A);
    llllIlllIlII[22] = (0x90 ^ 0x86);
    llllIlllIlII[23] = (0x16 ^ 0x1);
  }
  
  static
  {
    lIllllIIIIlIlI();
    lIllllIIIIIlll();
  }
  
  private static String lIllllIIIIIllI(String llllllllllllllIllIlIIIIlllIIIlIl, String llllllllllllllIllIlIIIIlllIIIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIlIIIIlllIIlIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIIIIlllIIIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIlIIIIlllIIlIIl = Cipher.getInstance("Blowfish");
      llllllllllllllIllIlIIIIlllIIlIIl.init(llllIlllIlII[2], llllllllllllllIllIlIIIIlllIIlIlI);
      return new String(llllllllllllllIllIlIIIIlllIIlIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIIIIlllIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIlIIIIlllIIlIII)
    {
      llllllllllllllIllIlIIIIlllIIlIII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIllllIIIIlllI(int ???, int arg1)
  {
    int i;
    int llllllllllllllIllIlIIIIllIIllIIl;
    return ??? >= i;
  }
  
  private static boolean lIllllIIIIllIl(int ???)
  {
    boolean llllllllllllllIllIlIIIIllIIlIIIl;
    return ??? > 0;
  }
  
  private static boolean lIllllIIIIllII(int ???)
  {
    char llllllllllllllIllIlIIIIllIIlIIll;
    return ??? != 0;
  }
  
  public SoundList deserialize(JsonElement llllllllllllllIllIlIIIIllllIIIII, Type llllllllllllllIllIlIIIIllllIlllI, JsonDeserializationContext llllllllllllllIllIlIIIIllllIllIl)
    throws JsonParseException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    JsonObject llllllllllllllIllIlIIIIllllIllII = JsonUtils.getJsonObject(llllllllllllllIllIlIIIIllllIIIII, llllIlllIIIl[llllIlllIlII[0]]);
    SoundList llllllllllllllIllIlIIIIllllIlIll = new SoundList();
    llllllllllllllIllIlIIIIllllIlIll.setReplaceExisting(JsonUtils.getBoolean(llllllllllllllIllIlIIIIllllIllII, llllIlllIIIl[llllIlllIlII[1]], llllIlllIlII[0]));
    SoundCategory llllllllllllllIllIlIIIIllllIlIlI = SoundCategory.getCategory(JsonUtils.getString(llllllllllllllIllIlIIIIllllIllII, llllIlllIIIl[llllIlllIlII[2]], SoundCategory.MASTER.getCategoryName()));
    llllllllllllllIllIlIIIIllllIlIll.setSoundCategory(llllllllllllllIllIlIIIIllllIlIlI);
    "".length();
    if (lIllllIIIIllII(llllllllllllllIllIlIIIIllllIllII.has(llllIlllIIIl[llllIlllIlII[4]])))
    {
      JsonArray llllllllllllllIllIlIIIIllllIlIIl = JsonUtils.getJsonArray(llllllllllllllIllIlIIIIllllIllII, llllIlllIIIl[llllIlllIlII[5]]);
      int llllllllllllllIllIlIIIIllllIlIII = llllIlllIlII[0];
      "".length();
      if (((25 + 127 - 17 + 107 ^ 'º' + '£' - 258 + 96) & (0x7E ^ 0x6E ^ 0xD0 ^ 0x89 ^ -" ".length())) != 0) {
        return null;
      }
      label465:
      label601:
      label702:
      while (!lIllllIIIIlllI(llllllllllllllIllIlIIIIllllIlIII, llllllllllllllIllIlIIIIllllIlIIl.size()))
      {
        JsonElement llllllllllllllIllIlIIIIllllIIlll = llllllllllllllIllIlIIIIllllIlIIl.get(llllllllllllllIllIlIIIIllllIlIII);
        SoundList.SoundEntry llllllllllllllIllIlIIIIllllIIllI = new SoundList.SoundEntry();
        if (lIllllIIIIllII(JsonUtils.isString(llllllllllllllIllIlIIIIllllIIlll)))
        {
          llllllllllllllIllIlIIIIllllIIllI.setSoundEntryName(JsonUtils.getString(llllllllllllllIllIlIIIIllllIIlll, llllIlllIIIl[llllIlllIlII[6]]));
          "".length();
          if ((0x6B ^ 0x6F) <= 0) {
            return null;
          }
        }
        else
        {
          JsonObject llllllllllllllIllIlIIIIllllIIlIl = JsonUtils.getJsonObject(llllllllllllllIllIlIIIIllllIIlll, llllIlllIIIl[llllIlllIlII[7]]);
          llllllllllllllIllIlIIIIllllIIllI.setSoundEntryName(JsonUtils.getString(llllllllllllllIllIlIIIIllllIIlIl, llllIlllIIIl[llllIlllIlII[8]]));
          if (lIllllIIIIllII(llllllllllllllIllIlIIIIllllIIlIl.has(llllIlllIIIl[llllIlllIlII[9]])))
          {
            SoundList.SoundEntry.Type llllllllllllllIllIlIIIIllllIIlII = SoundList.SoundEntry.Type.getType(JsonUtils.getString(llllllllllllllIllIlIIIIllllIIlIl, llllIlllIIIl[llllIlllIlII[10]]));
            "".length();
            llllllllllllllIllIlIIIIllllIIllI.setSoundEntryType(llllllllllllllIllIlIIIIllllIIlII);
          }
          if (lIllllIIIIllII(llllllllllllllIllIlIIIIllllIIlIl.has(llllIlllIIIl[llllIlllIlII[12]])))
          {
            float llllllllllllllIllIlIIIIllllIIIll = JsonUtils.getFloat(llllllllllllllIllIlIIIIllllIIlIl, llllIlllIIIl[llllIlllIlII[13]]);
            if (lIllllIIIIllIl(lIllllIIIIlIll(llllllllllllllIllIlIIIIllllIIIll, 0.0F)))
            {
              "".length();
              if (null == null) {
                break label465;
              }
              return null;
            }
            Validate.isTrue(llllIlllIlII[0], llllIlllIIIl[llllIlllIlII[14]], new Object[llllIlllIlII[0]]);
            llllllllllllllIllIlIIIIllllIIllI.setSoundEntryVolume(llllllllllllllIllIlIIIIllllIIIll);
          }
          if (lIllllIIIIllII(llllllllllllllIllIlIIIIllllIIlIl.has(llllIlllIIIl[llllIlllIlII[15]])))
          {
            float llllllllllllllIllIlIIIIllllIIIlI = JsonUtils.getFloat(llllllllllllllIllIlIIIIllllIIlIl, llllIlllIIIl[llllIlllIlII[16]]);
            if (lIllllIIIIllIl(lIllllIIIIlIll(llllllllllllllIllIlIIIIllllIIIlI, 0.0F)))
            {
              "".length();
              if (((0xB6 ^ 0xBD ^ 0x8B ^ 0xB6) & (0x44 ^ 0x1F ^ 0xCA ^ 0xA7 ^ -" ".length())) == 0) {
                break label601;
              }
              return null;
            }
            Validate.isTrue(llllIlllIlII[0], llllIlllIIIl[llllIlllIlII[17]], new Object[llllIlllIlII[0]]);
            llllllllllllllIllIlIIIIllllIIllI.setSoundEntryPitch(llllllllllllllIllIlIIIIllllIIIlI);
          }
          if (lIllllIIIIllII(llllllllllllllIllIlIIIIllllIIlIl.has(llllIlllIIIl[llllIlllIlII[18]])))
          {
            int llllllllllllllIllIlIIIIllllIIIIl = JsonUtils.getInt(llllllllllllllIllIlIIIIllllIIlIl, llllIlllIIIl[llllIlllIlII[19]]);
            if (lIllllIIIIllIl(llllllllllllllIllIlIIIIllllIIIIl))
            {
              "".length();
              if (" ".length() > 0) {
                break label702;
              }
              return null;
            }
            Validate.isTrue(llllIlllIlII[0], llllIlllIIIl[llllIlllIlII[20]], new Object[llllIlllIlII[0]]);
            llllllllllllllIllIlIIIIllllIIllI.setSoundEntryWeight(llllllllllllllIllIlIIIIllllIIIIl);
          }
          if (lIllllIIIIllII(llllllllllllllIllIlIIIIllllIIlIl.has(llllIlllIIIl[llllIlllIlII[21]]))) {
            llllllllllllllIllIlIIIIllllIIllI.setStreaming(JsonUtils.getBoolean(llllllllllllllIllIlIIIIllllIIlIl, llllIlllIIIl[llllIlllIlII[22]]));
          }
        }
        "".length();
      }
    }
    return llllllllllllllIllIlIIIIllllIlIll;
  }
  
  private static boolean lIllllIIIIllll(int ???, int arg1)
  {
    int i;
    String llllllllllllllIllIlIIIIllIIlIlIl;
    return ??? < i;
  }
  
  private static String lIllllIIIIIlIl(String llllllllllllllIllIlIIIIllIllIIlI, String llllllllllllllIllIlIIIIllIllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIlIIIIllIllIIlI = new String(Base64.getDecoder().decode(llllllllllllllIllIlIIIIllIllIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIlIIIIllIllIlIl = new StringBuilder();
    char[] llllllllllllllIllIlIIIIllIllIlII = llllllllllllllIllIlIIIIllIllIllI.toCharArray();
    int llllllllllllllIllIlIIIIllIllIIll = llllIlllIlII[0];
    short llllllllllllllIllIlIIIIllIlIllIl = llllllllllllllIllIlIIIIllIllIIlI.toCharArray();
    float llllllllllllllIllIlIIIIllIlIllII = llllllllllllllIllIlIIIIllIlIllIl.length;
    String llllllllllllllIllIlIIIIllIlIlIll = llllIlllIlII[0];
    while (lIllllIIIIllll(llllllllllllllIllIlIIIIllIlIlIll, llllllllllllllIllIlIIIIllIlIllII))
    {
      char llllllllllllllIllIlIIIIllIlllIII = llllllllllllllIllIlIIIIllIlIllIl[llllllllllllllIllIlIIIIllIlIlIll];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIlIIIIllIllIlIl);
  }
  
  public SoundListSerializer() {}
  
  private static String lIllllIIIIIlII(String llllllllllllllIllIlIIIIllIlIIIlI, String llllllllllllllIllIlIIIIllIlIIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIlIIIIllIlIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIIIIllIlIIIIl.getBytes(StandardCharsets.UTF_8)), llllIlllIlII[8]), "DES");
      Cipher llllllllllllllIllIlIIIIllIlIIlII = Cipher.getInstance("DES");
      llllllllllllllIllIlIIIIllIlIIlII.init(llllIlllIlII[2], llllllllllllllIllIlIIIIllIlIIlIl);
      return new String(llllllllllllllIllIlIIIIllIlIIlII.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIIIIllIlIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIlIIIIllIlIIIll)
    {
      llllllllllllllIllIlIIIIllIlIIIll.printStackTrace();
    }
    return null;
  }
}

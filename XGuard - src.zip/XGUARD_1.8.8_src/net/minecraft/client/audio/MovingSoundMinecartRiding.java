package net.minecraft.client.audio;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class MovingSoundMinecartRiding
  extends MovingSound
{
  private static boolean lIIIIlIlIIl(int ???)
  {
    int lIIIIIIIIIlIIIl;
    return ??? >= 0;
  }
  
  private static void lIIIIlIIIIl()
  {
    lIIlllIIl = new String[lIIllllIl[1]];
    lIIlllIIl[lIIllllIl[0]] = lIIIIlIIIII("9YLeKz9P64V83ud8weJvt/wzMH/GS24F6jpDWHypeZU=", "YhOjJ");
  }
  
  public MovingSoundMinecartRiding(EntityPlayer lIIIIIIIIllIIlI, EntityMinecart lIIIIIIIIllIIIl)
  {
    lIIIIIIIIllIIll.<init>(new ResourceLocation(lIIlllIIl[lIIllllIl[0]]));
    player = lIIIIIIIIlIllll;
    minecart = lIIIIIIIIllIIIl;
    attenuationType = ISound.AttenuationType.NONE;
    repeat = lIIllllIl[1];
    repeatDelay = lIIllllIl[0];
  }
  
  private static boolean lIIIIlIIlll(int ???)
  {
    boolean lIIIIIIIIIlIlIl;
    return ??? != 0;
  }
  
  private static void lIIIIlIIlII()
  {
    lIIllllIl = new int[3];
    lIIllllIl[0] = ((0x3A ^ 0x1D) & (0x82 ^ 0xA5 ^ 0xFFFFFFFF));
    lIIllllIl[1] = " ".length();
    lIIllllIl[2] = "  ".length();
  }
  
  private static boolean lIIIIlIIllI(int ???)
  {
    String lIIIIIIIIIlIIll;
    return ??? == 0;
  }
  
  static
  {
    lIIIIlIIlII();
    lIIIIlIIIIl();
  }
  
  private static boolean lIIIIlIlIII(Object ???, Object arg1)
  {
    Object localObject;
    String lIIIIIIIIIlIlll;
    return ??? == localObject;
  }
  
  private static String lIIIIlIIIII(String lIIIIIIIIlIIIII, String lIIIIIIIIIlllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIIIIIIIlIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIIIIIIIIIlllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIIIIIIIIlIIIlI = Cipher.getInstance("Blowfish");
      lIIIIIIIIlIIIlI.init(lIIllllIl[2], lIIIIIIIIlIIIll);
      return new String(lIIIIIIIIlIIIlI.doFinal(Base64.getDecoder().decode(lIIIIIIIIlIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIIIIIIIlIIIIl)
    {
      lIIIIIIIIlIIIIl.printStackTrace();
    }
    return null;
  }
  
  public void update()
  {
    ;
    ;
    if ((lIIIIlIIllI(minecart.isDead)) && (lIIIIlIIlll(player.isRiding())) && (lIIIIlIlIII(player.ridingEntity, minecart)))
    {
      float lIIIIIIIIlIlIlI = MathHelper.sqrt_double(minecart.motionX * minecart.motionX + minecart.motionZ * minecart.motionZ);
      if (lIIIIlIlIIl(lIIIIlIIlIl(lIIIIIIIIlIlIlI, 0.01D)))
      {
        volume = (0.0F + MathHelper.clamp_float(lIIIIIIIIlIlIlI, 0.0F, 1.0F) * 0.75F);
        "".length();
        if (null == null) {}
      }
      else
      {
        volume = 0.0F;
        "".length();
        if ("   ".length() > " ".length()) {}
      }
    }
    else
    {
      donePlaying = lIIllllIl[1];
    }
  }
  
  private static int lIIIIlIIlIl(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
}

package net.minecraft.client.audio;

public abstract interface ISoundEventAccessor<T>
{
  public abstract int getWeight();
  
  public abstract T cloneEntry();
}

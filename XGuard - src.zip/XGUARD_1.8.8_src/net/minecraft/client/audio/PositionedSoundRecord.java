package net.minecraft.client.audio;

import net.minecraft.util.ResourceLocation;

public class PositionedSoundRecord
  extends PositionedSound
{
  public static PositionedSoundRecord create(ResourceLocation llllllllllllllllllllIllllIIlllll)
  {
    ;
    return new PositionedSoundRecord(llllllllllllllllllllIllllIIllllI, 1.0F, 1.0F, lIllIlllIl[0], lIllIlllIl[0], ISound.AttenuationType.NONE, 0.0F, 0.0F, 0.0F);
  }
  
  public static PositionedSoundRecord create(ResourceLocation llllllllllllllllllllIllllIlIIIlI, float llllllllllllllllllllIllllIlIIIIl)
  {
    ;
    ;
    return new PositionedSoundRecord(llllllllllllllllllllIllllIlIIIlI, 0.25F, llllllllllllllllllllIllllIlIIIIl, lIllIlllIl[0], lIllIlllIl[0], ISound.AttenuationType.NONE, 0.0F, 0.0F, 0.0F);
  }
  
  private static void lIIlIIIllllI()
  {
    lIllIlllIl = new int[1];
    lIllIlllIl[0] = ((0x48 ^ 0x5A) & (0x81 ^ 0x93 ^ 0xFFFFFFFF));
  }
  
  public PositionedSoundRecord(ResourceLocation llllllllllllllllllllIllllIIIIIlI, float llllllllllllllllllllIllllIIIlIII, float llllllllllllllllllllIllllIIIIIII, float llllllllllllllllllllIllllIIIIllI, float llllllllllllllllllllIlllIllllllI, float llllllllllllllllllllIlllIlllllIl)
  {
    llllllllllllllllllllIllllIIIlIlI.<init>(llllllllllllllllllllIllllIIIIIlI, llllllllllllllllllllIllllIIIlIII, llllllllllllllllllllIllllIIIIlll, lIllIlllIl[0], lIllIlllIl[0], ISound.AttenuationType.LINEAR, llllllllllllllllllllIllllIIIIllI, llllllllllllllllllllIlllIllllllI, llllllllllllllllllllIlllIlllllIl);
  }
  
  static {}
  
  public static PositionedSoundRecord create(ResourceLocation llllllllllllllllllllIllllIIlIlIl, float llllllllllllllllllllIllllIIlIlII, float llllllllllllllllllllIllllIIlIlll, float llllllllllllllllllllIllllIIlIllI)
  {
    ;
    ;
    ;
    ;
    return new PositionedSoundRecord(llllllllllllllllllllIllllIIlIlIl, 4.0F, 1.0F, lIllIlllIl[0], lIllIlllIl[0], ISound.AttenuationType.LINEAR, llllllllllllllllllllIllllIIlIlII, llllllllllllllllllllIllllIIlIlll, llllllllllllllllllllIllllIIlIllI);
  }
  
  private PositionedSoundRecord(ResourceLocation llllllllllllllllllllIlllIlllIIIl, float llllllllllllllllllllIlllIlllIIII, float llllllllllllllllllllIlllIllIIlIl, boolean llllllllllllllllllllIlllIllIlllI, int llllllllllllllllllllIlllIllIIIll, ISound.AttenuationType llllllllllllllllllllIlllIllIIIlI, float llllllllllllllllllllIlllIllIIIIl, float llllllllllllllllllllIlllIllIlIlI, float llllllllllllllllllllIlllIlIlllll)
  {
    llllllllllllllllllllIlllIlllIIlI.<init>(llllllllllllllllllllIlllIlllIIIl);
    volume = llllllllllllllllllllIlllIlllIIII;
    pitch = llllllllllllllllllllIlllIllIIlIl;
    xPosF = llllllllllllllllllllIlllIllIIIIl;
    yPosF = llllllllllllllllllllIlllIllIlIlI;
    zPosF = llllllllllllllllllllIlllIlIlllll;
    repeat = llllllllllllllllllllIlllIllIlllI;
    repeatDelay = llllllllllllllllllllIlllIllIIIll;
    attenuationType = llllllllllllllllllllIlllIllIIIlI;
  }
}

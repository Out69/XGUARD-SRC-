package net.minecraft.client.audio;

import net.minecraft.util.ResourceLocation;

public class SoundPoolEntry
{
  public SoundPoolEntry(ResourceLocation lIlIlIIlIIllIIl, double lIlIlIIlIIlIIll, double lIlIlIIlIIlIlll, boolean lIlIlIIlIIlIllI)
  {
    location = lIlIlIIlIIllIIl;
    pitch = lIlIlIIlIIllIII;
    volume = lIlIlIIlIIlIlll;
    streamingSound = lIlIlIIlIIlIllI;
  }
  
  public double getVolume()
  {
    ;
    return volume;
  }
  
  public double getPitch()
  {
    ;
    return pitch;
  }
  
  public ResourceLocation getSoundPoolEntryLocation()
  {
    ;
    return location;
  }
  
  public void setPitch(double lIlIlIIlIIIIIIl)
  {
    ;
    ;
    pitch = lIlIlIIlIIIIIIl;
  }
  
  public SoundPoolEntry(SoundPoolEntry lIlIlIIlIIIllIl)
  {
    location = location;
    pitch = pitch;
    volume = volume;
    streamingSound = streamingSound;
  }
  
  public boolean isStreamingSound()
  {
    ;
    return streamingSound;
  }
  
  public void setVolume(double lIlIlIIIlllIllI)
  {
    ;
    ;
    volume = lIlIlIIIlllIllI;
  }
}

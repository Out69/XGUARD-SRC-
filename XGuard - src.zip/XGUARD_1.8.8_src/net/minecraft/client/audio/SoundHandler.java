package net.minecraft.client.audio;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.resources.IResource;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourceManagerReloadListener;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ITickable;
import net.minecraft.util.ResourceLocation;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class SoundHandler
  implements ITickable, IResourceManagerReloadListener
{
  public SoundHandler(IResourceManager llllllllllllllllIIlIIIllllllIIlI, GameSettings llllllllllllllllIIlIIIllllllIIIl)
  {
    mcResourceManager = llllllllllllllllIIlIIIllllllIlIl;
    sndManager = new SoundManager(llllllllllllllllIIlIIIllllllIIll, llllllllllllllllIIlIIIllllllIIIl);
  }
  
  private static void lIllIllllIlll()
  {
    lllIllIIlII = new String[lllIlllIlII[11]];
    lllIllIIlII[lllIlllIlII[0]] = lIllIllIlllll("dyRS4hfCQuzlNDXQoDZPEB/cX4xoEXd8", "iSqwf");
    lllIllIIlII[lllIlllIlII[1]] = lIllIlllIIIII("PzzjLP/KidZ/e48siPStJA==", "rmTKf");
    lllIllIIlII[lllIlllIlII[2]] = lIllIllIlllll("DJ97cuGoh6fPAoihIDaSK0m3+z8Rct39", "ZSOWA");
    lllIllIIlII[lllIlllIlII[3]] = lIllIllIlllll("AXIOPqFCptsRXs1UOMzWey7VyKgDhXp6MNLs360RYw3jurgrXIm0EA==", "fqzKe");
    lllIllIIlII[lllIlllIlII[4]] = lIllIlllIIIII("H95EMpniNBk=", "txBLt");
    lllIllIIlII[lllIlllIlII[5]] = lIllIllllIIIl("HjsvATAeew==", "mTZoT");
    lllIllIIlII[lllIlllIlII[6]] = lIllIllllIIIl("TTg0Cg==", "cWSmn");
    lllIllIIlII[lllIlllIlII[7]] = lIllIlllIIIII("lH7zL5j1hBgnH2vLoS62Its7VqFZIRkUndwRMb4ZXp7F0hpk1iszH1iEvdAc70bzyTGFm5SrGcM=", "OhHhf");
    lllIllIIlII[lllIlllIlII[8]] = lIllIlllIIIII("grsLmgB3cf3OJaiTj2sZCkp8t6nbdXDpscIriUS/wK8=", "uapEG");
    lllIllIIlII[lllIlllIlII[9]] = lIllIllIlllll("5hI9c42EpAzX6bDX/Bsk7Fyc/rvCvpL7jgYFCWzIZQ4=", "AaZql");
    lllIllIIlII[lllIlllIlII[10]] = lIllIllIlllll("VHQKg3YBYJfW3qKBBWeQrw==", "srfUD");
  }
  
  public void setSoundLevel(SoundCategory llllllllllllllllIIlIIIllIIlIlIlI, float llllllllllllllllIIlIIIllIIlIlIIl)
  {
    ;
    ;
    ;
    if ((lIlllIIIIllIl(llllllllllllllllIIlIIIllIIlIlIlI, SoundCategory.MASTER)) && (lIlllIIIIlllI(lIlllIIIIllII(llllllllllllllllIIlIIIllIIlIlIIl, 0.0F)))) {
      llllllllllllllllIIlIIIllIIlIlIll.stopSounds();
    }
    sndManager.setSoundCategoryVolume(llllllllllllllllIIlIIIllIIlIllIl, llllllllllllllllIIlIIIllIIlIlIIl);
  }
  
  public void unloadSounds()
  {
    ;
    sndManager.unloadSoundSystem();
  }
  
  public void pauseSounds()
  {
    ;
    sndManager.pauseAllSounds();
  }
  
  private static boolean lIlllIIIIllll(Object ???)
  {
    boolean llllllllllllllllIIlIIIlIllIIllII;
    return ??? != null;
  }
  
  private static String lIllIllIlllll(String llllllllllllllllIIlIIIlIllllIIIl, String llllllllllllllllIIlIIIlIllllIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIlIIIlIllllIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIlIIIlIllllIIII.getBytes(StandardCharsets.UTF_8)), lllIlllIlII[8]), "DES");
      Cipher llllllllllllllllIIlIIIlIllllIlIl = Cipher.getInstance("DES");
      llllllllllllllllIIlIIIlIllllIlIl.init(lllIlllIlII[2], llllllllllllllllIIlIIIlIllllIllI);
      return new String(llllllllllllllllIIlIIIlIllllIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllllIIlIIIlIllllIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIlIIIlIllllIlII)
    {
      llllllllllllllllIIlIIIlIllllIlII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlllIIIIlIlI(int ???)
  {
    boolean llllllllllllllllIIlIIIlIllIIlIlI;
    return ??? != 0;
  }
  
  private static int lIlllIIIIllII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIlllIIIlIIlI(int ???, int arg1)
  {
    int i;
    char llllllllllllllllIIlIIIlIllIlIIlI;
    return ??? < i;
  }
  
  public void stopSound(ISound llllllllllllllllIIlIIIllIIlIIlIl)
  {
    ;
    ;
    sndManager.stopSound(llllllllllllllllIIlIIIllIIlIIlIl);
  }
  
  public boolean isSoundPlaying(ISound llllllllllllllllIIlIIIllIIIIllII)
  {
    ;
    ;
    return sndManager.isSoundPlaying(llllllllllllllllIIlIIIllIIIIllII);
  }
  
  public void playDelayedSound(ISound llllllllllllllllIIlIIIllIlIIlIll, int llllllllllllllllIIlIIIllIlIIlIlI)
  {
    ;
    ;
    ;
    sndManager.playDelayedSound(llllllllllllllllIIlIIIllIlIIlllI, llllllllllllllllIIlIIIllIlIIlIlI);
  }
  
  public SoundEventAccessorComposite getSound(ResourceLocation llllllllllllllllIIlIIIllIlIllIIl)
  {
    ;
    ;
    return (SoundEventAccessorComposite)sndRegistry.getObject(llllllllllllllllIIlIIIllIlIllIIl);
  }
  
  private static boolean lIlllIIIIlllI(int ???)
  {
    float llllllllllllllllIIlIIIlIllIIIllI;
    return ??? <= 0;
  }
  
  private static String lIllIlllIIIII(String llllllllllllllllIIlIIIllIIIIIIII, String llllllllllllllllIIlIIIlIllllllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIlIIIllIIIIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIlIIIlIllllllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIIlIIIllIIIIIIlI = Cipher.getInstance("Blowfish");
      llllllllllllllllIIlIIIllIIIIIIlI.init(lllIlllIlII[2], llllllllllllllllIIlIIIllIIIIIIll);
      return new String(llllllllllllllllIIlIIIllIIIIIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllIIlIIIllIIIIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIlIIIllIIIIIIIl)
    {
      llllllllllllllllIIlIIIllIIIIIIIl.printStackTrace();
    }
    return null;
  }
  
  public void stopSounds()
  {
    ;
    sndManager.stopAllSounds();
  }
  
  public void setListener(EntityPlayer llllllllllllllllIIlIIIllIlIIIIlI, float llllllllllllllllIIlIIIllIlIIIIIl)
  {
    ;
    ;
    ;
    sndManager.setListener(llllllllllllllllIIlIIIllIlIIIlIl, llllllllllllllllIIlIIIllIlIIIIIl);
  }
  
  protected Map<String, SoundList> getSoundMap(InputStream llllllllllllllllIIlIIIllllIIIlll)
  {
    try
    {
      ;
      ;
      Map llllllllllllllllIIlIIIllllIIlIIl = (Map)GSON.fromJson(new InputStreamReader(llllllllllllllllIIlIIIllllIIlIlI), TYPE);
      "".length();
      if ((0x9 ^ 0xD) > (0xC4 ^ 0xC0)) {
        return null;
      }
    }
    finally
    {
      IOUtils.closeQuietly(llllllllllllllllIIlIIIllllIIlIlI);
    }
    Map llllllllllllllllIIlIIIllllIIlIII;
    IOUtils.closeQuietly(llllllllllllllllIIlIIIllllIIlIlI);
    return llllllllllllllllIIlIIIllllIIlIII;
  }
  
  private static boolean lIlllIIIIlIIl(int ???)
  {
    String llllllllllllllllIIlIIIlIllIIlIII;
    return ??? == 0;
  }
  
  public SoundEventAccessorComposite getRandomSoundFromCategories(SoundCategory... llllllllllllllllIIlIIIllIIIllIll)
  {
    ;
    ;
    ;
    ;
    ;
    List<SoundEventAccessorComposite> llllllllllllllllIIlIIIllIIIllIlI = Lists.newArrayList();
    boolean llllllllllllllllIIlIIIllIIIlIIll = sndRegistry.getKeys().iterator();
    "".length();
    if ((0xBE ^ 0xBA) == " ".length()) {
      return null;
    }
    while (!lIlllIIIIlIIl(llllllllllllllllIIlIIIllIIIlIIll.hasNext()))
    {
      ResourceLocation llllllllllllllllIIlIIIllIIIllIIl = (ResourceLocation)llllllllllllllllIIlIIIllIIIlIIll.next();
      SoundEventAccessorComposite llllllllllllllllIIlIIIllIIIllIII = (SoundEventAccessorComposite)sndRegistry.getObject(llllllllllllllllIIlIIIllIIIllIIl);
      if (lIlllIIIIlIlI(ArrayUtils.contains(llllllllllllllllIIlIIIllIIIllIll, llllllllllllllllIIlIIIllIIIllIII.getSoundCategory()))) {
        "".length();
      }
    }
    if (lIlllIIIIlIlI(llllllllllllllllIIlIIIllIIIllIlI.isEmpty())) {
      return null;
    }
    return (SoundEventAccessorComposite)llllllllllllllllIIlIIIllIIIllIlI.get(new Random().nextInt(llllllllllllllllIIlIIIllIIIllIlI.size()));
  }
  
  private static void lIlllIIIIlIII()
  {
    lllIlllIlII = new int[12];
    lllIlllIlII[0] = ((0x6B ^ 0x55 ^ 0xBB ^ 0xC1) & (0xC6 ^ 0x88 ^ 0x2 ^ 0x8 ^ -" ".length()));
    lllIlllIlII[1] = " ".length();
    lllIlllIlII[2] = "  ".length();
    lllIlllIlII[3] = "   ".length();
    lllIlllIlII[4] = (0x75 ^ 0x71);
    lllIlllIlII[5] = (61 + 58 - 9 + 38 ^ '' + 41 - 136 + 100);
    lllIlllIlII[6] = (0x6F ^ 0x69);
    lllIlllIlII[7] = (0x21 ^ 0x26);
    lllIlllIlII[8] = ('' + 32 - 159 + 171 ^ 45 + 16 - -50 + 78);
    lllIlllIlII[9] = (25 + 27 - 45 + 128 ^ 99 + 112 - 92 + 23);
    lllIlllIlII[10] = (56 + 126 - 103 + 71 ^ 69 + 14 - 47 + 120);
    lllIlllIlII[11] = (" ".length() ^ 0xB5 ^ 0xBF);
  }
  
  public void playSound(ISound llllllllllllllllIIlIIIllIlIlIIll)
  {
    ;
    ;
    sndManager.playSound(llllllllllllllllIIlIIIllIlIlIIll);
  }
  
  public void update()
  {
    ;
    sndManager.updateAllSounds();
  }
  
  private static String lIllIllllIIIl(String llllllllllllllllIIlIIIlIllIllllI, String llllllllllllllllIIlIIIlIllIlllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIlIIIlIllIllllI = new String(Base64.getDecoder().decode(llllllllllllllllIIlIIIlIllIllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIIlIIIlIlllIIIIl = new StringBuilder();
    char[] llllllllllllllllIIlIIIlIlllIIIII = llllllllllllllllIIlIIIlIllIlllIl.toCharArray();
    int llllllllllllllllIIlIIIlIllIlllll = lllIlllIlII[0];
    String llllllllllllllllIIlIIIlIllIllIIl = llllllllllllllllIIlIIIlIllIllllI.toCharArray();
    char llllllllllllllllIIlIIIlIllIllIII = llllllllllllllllIIlIIIlIllIllIIl.length;
    byte llllllllllllllllIIlIIIlIllIlIlll = lllIlllIlII[0];
    while (lIlllIIIlIIlI(llllllllllllllllIIlIIIlIllIlIlll, llllllllllllllllIIlIIIlIllIllIII))
    {
      char llllllllllllllllIIlIIIlIlllIIlII = llllllllllllllllIIlIIIlIllIllIIl[llllllllllllllllIIlIIIlIllIlIlll];
      "".length();
      "".length();
      if ("   ".length() != "   ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIIlIIIlIlllIIIIl);
  }
  
  private static boolean lIlllIIIIllIl(Object ???, Object arg1)
  {
    Object localObject;
    short llllllllllllllllIIlIIIlIllIIlllI;
    return ??? == localObject;
  }
  
  static
  {
    lIlllIIIIlIII();
    lIllIllllIlll();
    logger = LogManager.getLogger();
    GSON = new GsonBuilder().registerTypeAdapter(SoundList.class, new SoundListSerializer()).create();
  }
  
  public void resumeSounds()
  {
    ;
    sndManager.resumeAllSounds();
  }
  
  private void loadSoundResource(ResourceLocation llllllllllllllllIIlIIIllIllIllII, SoundList llllllllllllllllIIlIIIllIllIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlllIIIIlIlI(sndRegistry.containsKey(llllllllllllllllIIlIIIllIlllllll)))
    {
      "".length();
      if ("   ".length() >= " ".length()) {
        break label47;
      }
    }
    label47:
    boolean llllllllllllllllIIlIIIllIlllllIl = lllIlllIlII[1];
    SoundEventAccessorComposite llllllllllllllllIIlIIIllIllllIll;
    if ((lIlllIIIIlIIl(llllllllllllllllIIlIIIllIlllllIl)) && (lIlllIIIIlIIl(llllllllllllllllIIlIIIllIllIlIll.canReplaceExisting())))
    {
      SoundEventAccessorComposite llllllllllllllllIIlIIIllIlllllII = (SoundEventAccessorComposite)sndRegistry.getObject(llllllllllllllllIIlIIIllIlllllll);
      "".length();
      if ("  ".length() >= ((0xA1 ^ 0x8E) & (0x69 ^ 0x46 ^ 0xFFFFFFFF))) {}
    }
    else
    {
      if (lIlllIIIIlIIl(llllllllllllllllIIlIIIllIlllllIl)) {
        logger.debug(lllIllIIlII[lllIlllIlII[3]], new Object[] { llllllllllllllllIIlIIIllIlllllll });
      }
      llllllllllllllllIIlIIIllIllllIll = new SoundEventAccessorComposite(llllllllllllllllIIlIIIllIlllllll, 1.0D, 1.0D, llllllllllllllllIIlIIIllIllIlIll.getSoundCategory());
      sndRegistry.registerSound(llllllllllllllllIIlIIIllIllllIll);
    }
    byte llllllllllllllllIIlIIIllIllIIlll = llllllllllllllllIIlIIIllIllIlIll.getSoundList().iterator();
    "".length();
    if (((38 + 14 - -2 + 153 ^ ' ' + 23 - 14 + 29) & (0x6A ^ 0x6E ^ 0x30 ^ 0x3D ^ -" ".length())) > (0x72 ^ 0x16 ^ 0x53 ^ 0x33)) {
      return;
    }
    label335:
    while (!lIlllIIIIlIIl(llllllllllllllllIIlIIIllIllIIlll.hasNext()))
    {
      SoundList.SoundEntry llllllllllllllllIIlIIIllIllllIlI = (SoundList.SoundEntry)llllllllllllllllIIlIIIllIllIIlll.next();
      String llllllllllllllllIIlIIIllIllllIIl = llllllllllllllllIIlIIIllIllllIlI.getSoundEntryName();
      ResourceLocation llllllllllllllllIIlIIIllIllllIII = new ResourceLocation(llllllllllllllllIIlIIIllIllllIIl);
      if (lIlllIIIIlIlI(llllllllllllllllIIlIIIllIllllIIl.contains(lllIllIIlII[lllIlllIlII[4]])))
      {
        "".length();
        if ((0x2 ^ 0xD ^ 0x81 ^ 0x8A) > 0) {
          break label335;
        }
      }
      String llllllllllllllllIIlIIIllIlllIlll = llllllllllllllllIIlIIIllIlllllll.getResourceDomain();
      switch ($SWITCH_TABLE$net$minecraft$client$audio$SoundList$SoundEntry$Type()[llllllllllllllllIIlIIIllIllllIlI.getSoundEntryType().ordinal()])
      {
      case 1: 
        ResourceLocation llllllllllllllllIIlIIIllIlllIIlI = new ResourceLocation(llllllllllllllllIIlIIIllIlllIlll, String.valueOf(new StringBuilder(lllIllIIlII[lllIlllIlII[5]]).append(llllllllllllllllIIlIIIllIllllIII.getResourcePath()).append(lllIllIIlII[lllIlllIlII[6]])));
        InputStream llllllllllllllllIIlIIIllIlllIIIl = null;
        try
        {
          llllllllllllllllIIlIIIllIlllIIIl = mcResourceManager.getResource(llllllllllllllllIIlIIIllIlllIIlI).getInputStream();
          "".length();
          if ("  ".length() != "  ".length()) {
            return;
          }
        }
        catch (FileNotFoundException llllllllllllllllIIlIIIllIlllIIII)
        {
          logger.warn(lllIllIIlII[lllIlllIlII[7]], new Object[] { llllllllllllllllIIlIIIllIlllIIlI, llllllllllllllllIIlIIIllIlllllll });
          IOUtils.closeQuietly(llllllllllllllllIIlIIIllIlllIIIl);
          "".length();
          if (" ".length() >= 0) {
            continue;
          }
          return;
        }
        catch (IOException llllllllllllllllIIlIIIllIllIllll)
        {
          logger.warn(String.valueOf(new StringBuilder(lllIllIIlII[lllIlllIlII[8]]).append(llllllllllllllllIIlIIIllIlllIIlI).append(lllIllIIlII[lllIlllIlII[9]]).append(llllllllllllllllIIlIIIllIlllllll)), llllllllllllllllIIlIIIllIllIllll);
          IOUtils.closeQuietly(llllllllllllllllIIlIIIllIlllIIIl);
          "".length();
          if ((0x38 ^ 0x3C) >= 0) {
            continue;
          }
          return;
        }
        finally
        {
          IOUtils.closeQuietly(llllllllllllllllIIlIIIllIlllIIIl);
        }
        IOUtils.closeQuietly(llllllllllllllllIIlIIIllIlllIIIl);
        Object llllllllllllllllIIlIIIllIlllIllI = new SoundEventAccessor(new SoundPoolEntry(llllllllllllllllIIlIIIllIlllIIlI, llllllllllllllllIIlIIIllIllllIlI.getSoundEntryPitch(), llllllllllllllllIIlIIIllIllllIlI.getSoundEntryVolume(), llllllllllllllllIIlIIIllIllllIlI.isStreaming()), llllllllllllllllIIlIIIllIllllIlI.getSoundEntryWeight());
        "".length();
        if ((0x90 ^ 0x94) < 0) {
          return;
        }
        break;
      case 2: 
        Object llllllllllllllllIIlIIIllIlllIlIl = new ISoundEventAccessor()
        {
          public int getWeight()
          {
            ;
            ;
            SoundEventAccessorComposite llllllllllllllIllllllllllllIIlll = (SoundEventAccessorComposite)sndRegistry.getObject(field_148726_a);
            if (lIlIIlIIlIIIII(llllllllllllllIllllllllllllIIlll))
            {
              "".length();
              if (((0x6C ^ 0x54) & (0xA9 ^ 0x91 ^ 0xFFFFFFFF)) == 0) {
                break label72;
              }
              return (0x12 ^ 0x2D) & (0x64 ^ 0x5B ^ 0xFFFFFFFF);
            }
            label72:
            return llllllllllllllIllllllllllllIIlll.getWeight();
          }
          
          private static void lIlIIlIIIlllll()
          {
            llIlIllIIllI = new int[1];
            llIlIllIIllI[0] = ((0x8B ^ 0x85) & (0xA4 ^ 0xAA ^ 0xFFFFFFFF));
          }
          
          private static boolean lIlIIlIIlIIIII(Object ???)
          {
            Exception llllllllllllllIlllllllllllIllIll;
            return ??? == null;
          }
          
          static {}
          
          public SoundPoolEntry cloneEntry()
          {
            ;
            ;
            SoundEventAccessorComposite llllllllllllllIllllllllllllIIIIl = (SoundEventAccessorComposite)sndRegistry.getObject(field_148726_a);
            if (lIlIIlIIlIIIII(llllllllllllllIllllllllllllIIIIl))
            {
              "".length();
              if (" ".length() <= "  ".length()) {
                break label53;
              }
              return null;
            }
            label53:
            return llllllllllllllIllllllllllllIIIIl.cloneEntry();
          }
        };
        "".length();
        if ("   ".length() > (0x66 ^ 0x16 ^ 0x35 ^ 0x41)) {
          return;
        }
        break;
      default: 
        throw new IllegalStateException(lllIllIIlII[lllIlllIlII[10]]);
      }
      Object llllllllllllllllIIlIIIllIlllIIll;
      llllllllllllllllIIlIIIllIllllIll.addSoundToEventPool((ISoundEventAccessor)llllllllllllllllIIlIIIllIlllIIll);
    }
  }
  
  public void onResourceManagerReload(IResourceManager llllllllllllllllIIlIIIlllllIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    sndManager.reloadSoundSystem();
    sndRegistry.clearMap();
    short llllllllllllllllIIlIIIllllIlIlIl = llllllllllllllllIIlIIIlllllIIlIl.getResourceDomains().iterator();
    "".length();
    if ((0xF2 ^ 0x91 ^ 0x4D ^ 0x2A) <= 0) {
      return;
    }
    while (!lIlllIIIIlIIl(llllllllllllllllIIlIIIllllIlIlIl.hasNext()))
    {
      String llllllllllllllllIIlIIIlllllIIIll = (String)llllllllllllllllIIlIIIllllIlIlIl.next();
      try
      {
        llllllllllllllllIIlIIIllllIlIIlI = llllllllllllllllIIlIIIlllllIIlIl.getAllResources(new ResourceLocation(llllllllllllllllIIlIIIlllllIIIll, lllIllIIlII[lllIlllIlII[1]])).iterator();
        "".length();
        if (((75 + 27 - 53 + 190 ^ 10 + '' - 47 + 55) & ('´' + '' - 152 + 40 ^ 29 + 3 - -17 + 91 ^ -" ".length())) > (('' + '¸' - 168 + 59 ^ 17 + 122 - 46 + 53) & (0x60 ^ 0x44 ^ 0xA ^ 0x77 ^ -" ".length()))) {
          return;
        }
        while (!lIlllIIIIlIIl(llllllllllllllllIIlIIIllllIlIIlI.hasNext()))
        {
          IResource llllllllllllllllIIlIIIlllllIIIIl = (IResource)llllllllllllllllIIlIIIllllIlIIlI.next();
          try
          {
            Map<String, SoundList> llllllllllllllllIIlIIIlllllIIIII = llllllllllllllllIIlIIIlllllIIllI.getSoundMap(llllllllllllllllIIlIIIlllllIIIIl.getInputStream());
            llllllllllllllllIIlIIIllllIIllll = llllllllllllllllIIlIIIlllllIIIII.entrySet().iterator();
            "".length();
            if (-"   ".length() > 0) {
              return;
            }
            while (!lIlllIIIIlIIl(llllllllllllllllIIlIIIllllIIllll.hasNext()))
            {
              Map.Entry<String, SoundList> llllllllllllllllIIlIIIllllIlllll = (Map.Entry)llllllllllllllllIIlIIIllllIIllll.next();
              llllllllllllllllIIlIIIlllllIIllI.loadSoundResource(new ResourceLocation(llllllllllllllllIIlIIIlllllIIIll, (String)llllllllllllllllIIlIIIllllIlllll.getKey()), (SoundList)llllllllllllllllIIlIIIllllIlllll.getValue());
            }
            "".length();
            if (-(0xC4 ^ 0xC1) >= 0) {
              return;
            }
          }
          catch (RuntimeException llllllllllllllllIIlIIIllllIlllIl)
          {
            logger.warn(lllIllIIlII[lllIlllIlII[2]], llllllllllllllllIIlIIIllllIlllIl);
          }
        }
        "".length();
        if ("   ".length() == 0) {
          return;
        }
      }
      catch (IOException localIOException) {}
    }
  }
}

package net.minecraft.client.audio;

import net.minecraft.util.ITickable;

public abstract interface ITickableSound
  extends ISound, ITickable
{
  public abstract boolean isDonePlaying();
}

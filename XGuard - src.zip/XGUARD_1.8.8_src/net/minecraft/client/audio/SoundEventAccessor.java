package net.minecraft.client.audio;

public class SoundEventAccessor
  implements ISoundEventAccessor<SoundPoolEntry>
{
  public SoundPoolEntry cloneEntry()
  {
    ;
    return new SoundPoolEntry(entry);
  }
  
  SoundEventAccessor(SoundPoolEntry llllllllllllllIIllIlIIlIlIlIIllI, int llllllllllllllIIllIlIIlIlIlIlIII)
  {
    entry = llllllllllllllIIllIlIIlIlIlIlIIl;
    weight = llllllllllllllIIllIlIIlIlIlIlIII;
  }
  
  public int getWeight()
  {
    ;
    return weight;
  }
}

package net.minecraft.client.audio;

import com.google.common.collect.Maps;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public enum SoundCategory
{
  private static boolean lllIIlIllIlII(int ???)
  {
    int lllllllllllllllIllIIlIIllIIlIIll;
    return ??? == 0;
  }
  
  private static String lllIIlIlIIlIl(String lllllllllllllllIllIIlIIlllIIIlll, String lllllllllllllllIllIIlIIlllIIIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIIlIIlllIIllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIIlllIIIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIIlIIlllIIlIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIIlIIlllIIlIll.init(lIIlIlIIlIlI[2], lllllllllllllllIllIIlIIlllIIllII);
      return new String(lllllllllllllllIllIIlIIlllIIlIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIIlllIIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIIlIIlllIIlIlI)
    {
      lllllllllllllllIllIIlIIlllIIlIlI.printStackTrace();
    }
    return null;
  }
  
  public static SoundCategory getCategory(String lllllllllllllllIllIIlIIlllIllIlI)
  {
    ;
    return (SoundCategory)NAME_CATEGORY_MAP.get(lllllllllllllllIllIIlIIlllIllIIl);
  }
  
  public int getCategoryId()
  {
    ;
    return categoryId;
  }
  
  private static boolean lllIIlIllIlIl(int ???)
  {
    double lllllllllllllllIllIIlIIllIIlIlIl;
    return ??? != 0;
  }
  
  private static boolean lllIIlIllIllI(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIllIIlIIllIIllIll;
    return ??? >= i;
  }
  
  private static String lllIIlIlIIlll(String lllllllllllllllIllIIlIIllIlIllII, String lllllllllllllllIllIIlIIllIlIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllIIlIIllIlIllII = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlIIllIlIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlIIllIlIlIlI = new StringBuilder();
    char[] lllllllllllllllIllIIlIIllIlIlIIl = lllllllllllllllIllIIlIIllIlIIllI.toCharArray();
    int lllllllllllllllIllIIlIIllIlIlIII = lIIlIlIIlIlI[0];
    Exception lllllllllllllllIllIIlIIllIlIIIlI = lllllllllllllllIllIIlIIllIlIllII.toCharArray();
    short lllllllllllllllIllIIlIIllIlIIIIl = lllllllllllllllIllIIlIIllIlIIIlI.length;
    short lllllllllllllllIllIIlIIllIlIIIII = lIIlIlIIlIlI[0];
    while (lllIIlIlllIII(lllllllllllllllIllIIlIIllIlIIIII, lllllllllllllllIllIIlIIllIlIIIIl))
    {
      char lllllllllllllllIllIIlIIllIlIllIl = lllllllllllllllIllIIlIIllIlIIIlI[lllllllllllllllIllIIlIIllIlIIIII];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIllIIlIIllIlIlIlI);
  }
  
  private static void lllIIlIllIIll()
  {
    lIIlIlIIlIlI = new int[20];
    lIIlIlIIlIlI[0] = ((0x63 ^ 0x66 ^ 0x23 ^ 0x45) & (115 + '' - 73 + 22 ^ 66 + 11 - -103 + 5 ^ -" ".length()));
    lIIlIlIIlIlI[1] = " ".length();
    lIIlIlIIlIlI[2] = "  ".length();
    lIIlIlIIlIlI[3] = "   ".length();
    lIIlIlIIlIlI[4] = (0xC0 ^ 0xA3 ^ 0xDC ^ 0xBB);
    lIIlIlIIlIlI[5] = (112 + '' - 249 + 170 ^ 121 + 71 - 131 + 115);
    lIIlIlIIlIlI[6] = (0x11 ^ 0x4F ^ 0x52 ^ 0xA);
    lIIlIlIIlIlI[7] = (0x4E ^ 0x49);
    lIIlIlIIlIlI[8] = (0xB ^ 0x6D ^ 0x14 ^ 0x7A);
    lIIlIlIIlIlI[9] = (0x97 ^ 0x9E);
    lIIlIlIIlIlI[10] = (0x8A ^ 0x80);
    lIIlIlIIlIlI[11] = ('' + 114 - 93 + 30 ^ 5 + 22 - 65389 + 2);
    lIIlIlIIlIlI[12] = (0x74 ^ 0x78);
    lIIlIlIIlIlI[13] = (0xAA ^ 0xA7);
    lIIlIlIIlIlI[14] = (4 + 17 - -7 + 138 ^ 92 + 38 - -17 + 21);
    lIIlIlIIlIlI[15] = (59 + 67 - -12 + 31 ^ 20 + 90 - 78 + 134);
    lIIlIlIIlIlI[16] = (0x3 ^ 0x13);
    lIIlIlIIlIlI[17] = (57 + 0 - -18 + 92 ^ '¡' + '¤' - 156 + 13);
    lIIlIlIIlIlI[18] = (0x56 ^ 0x44);
    lIIlIlIIlIlI[19] = (122 + 98 - 83 + 50 ^ 81 + 79 - 21 + 29);
  }
  
  public String getCategoryName()
  {
    ;
    return categoryName;
  }
  
  private static boolean lllIIlIlllIII(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIllIIlIIllIIlIlll;
    return ??? < i;
  }
  
  private SoundCategory(String lllllllllllllllIllIIlIIllllIIIll, int lllllllllllllllIllIIlIIllllIIlll)
  {
    categoryName = lllllllllllllllIllIIlIIllllIlIII;
    categoryId = lllllllllllllllIllIIlIIllllIIlll;
  }
  
  static
  {
    lllIIlIllIIll();
    lllIIlIlIllll();
    float lllllllllllllllIllIIlIIllllIllll;
    String lllllllllllllllIllIIlIIlllllIIlI;
    MASTER = new SoundCategory(lIIlIlIIIlII[lIIlIlIIlIlI[0]], lIIlIlIIlIlI[0], lIIlIlIIIlII[lIIlIlIIlIlI[1]], lIIlIlIIlIlI[0]);
    MUSIC = new SoundCategory(lIIlIlIIIlII[lIIlIlIIlIlI[2]], lIIlIlIIlIlI[1], lIIlIlIIIlII[lIIlIlIIlIlI[3]], lIIlIlIIlIlI[1]);
    RECORDS = new SoundCategory(lIIlIlIIIlII[lIIlIlIIlIlI[4]], lIIlIlIIlIlI[2], lIIlIlIIIlII[lIIlIlIIlIlI[5]], lIIlIlIIlIlI[2]);
    WEATHER = new SoundCategory(lIIlIlIIIlII[lIIlIlIIlIlI[6]], lIIlIlIIlIlI[3], lIIlIlIIIlII[lIIlIlIIlIlI[7]], lIIlIlIIlIlI[3]);
    BLOCKS = new SoundCategory(lIIlIlIIIlII[lIIlIlIIlIlI[8]], lIIlIlIIlIlI[4], lIIlIlIIIlII[lIIlIlIIlIlI[9]], lIIlIlIIlIlI[4]);
    MOBS = new SoundCategory(lIIlIlIIIlII[lIIlIlIIlIlI[10]], lIIlIlIIlIlI[5], lIIlIlIIIlII[lIIlIlIIlIlI[11]], lIIlIlIIlIlI[5]);
    ANIMALS = new SoundCategory(lIIlIlIIIlII[lIIlIlIIlIlI[12]], lIIlIlIIlIlI[6], lIIlIlIIIlII[lIIlIlIIlIlI[13]], lIIlIlIIlIlI[6]);
    PLAYERS = new SoundCategory(lIIlIlIIIlII[lIIlIlIIlIlI[14]], lIIlIlIIlIlI[7], lIIlIlIIIlII[lIIlIlIIlIlI[15]], lIIlIlIIlIlI[7]);
    AMBIENT = new SoundCategory(lIIlIlIIIlII[lIIlIlIIlIlI[16]], lIIlIlIIlIlI[8], lIIlIlIIIlII[lIIlIlIIlIlI[17]], lIIlIlIIlIlI[8]);
    ENUM$VALUES = new SoundCategory[] { MASTER, MUSIC, RECORDS, WEATHER, BLOCKS, MOBS, ANIMALS, PLAYERS, AMBIENT };
    NAME_CATEGORY_MAP = Maps.newHashMap();
    ID_CATEGORY_MAP = Maps.newHashMap();
    double lllllllllllllllIllIIlIIlllllIIII = (lllllllllllllllIllIIlIIllllIllll = values()).length;
    boolean lllllllllllllllIllIIlIIlllllIIIl = lIIlIlIIlIlI[0];
    "".length();
    if (((0x0 ^ 0x62) & (0x7A ^ 0x18 ^ 0xFFFFFFFF)) > 0) {
      return;
    }
    while (!lllIIlIllIllI(lllllllllllllllIllIIlIIlllllIIIl, lllllllllllllllIllIIlIIlllllIIII))
    {
      SoundCategory lllllllllllllllIllIIlIIlllllIIll = lllllllllllllllIllIIlIIllllIllll[lllllllllllllllIllIIlIIlllllIIIl];
      if ((!lllIIlIllIlII(NAME_CATEGORY_MAP.containsKey(lllllllllllllllIllIIlIIlllllIIll.getCategoryName()))) || (lllIIlIllIlIl(ID_CATEGORY_MAP.containsKey(Integer.valueOf(lllllllllllllllIllIIlIIlllllIIll.getCategoryId()))))) {
        throw new Error(String.valueOf(new StringBuilder(lIIlIlIIIlII[lIIlIlIIlIlI[18]]).append(lllllllllllllllIllIIlIIlllllIIll)));
      }
      "".length();
      "".length();
    }
  }
  
  private static String lllIIlIlIlIIl(String lllllllllllllllIllIIlIIllIllllII, String lllllllllllllllIllIIlIIllIlllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIIlIIllIllllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlIIllIlllIll.getBytes(StandardCharsets.UTF_8)), lIIlIlIIlIlI[8]), "DES");
      Cipher lllllllllllllllIllIIlIIllIlllllI = Cipher.getInstance("DES");
      lllllllllllllllIllIIlIIllIlllllI.init(lIIlIlIIlIlI[2], lllllllllllllllIllIIlIIllIllllll);
      return new String(lllllllllllllllIllIIlIIllIlllllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlIIllIllllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIIlIIllIllllIl)
    {
      lllllllllllllllIllIIlIIllIllllIl.printStackTrace();
    }
    return null;
  }
  
  private static void lllIIlIlIllll()
  {
    lIIlIlIIIlII = new String[lIIlIlIIlIlI[19]];
    lIIlIlIIIlII[lIIlIlIIlIlI[0]] = lllIIlIlIIlIl("MTtJ/wwCzxM=", "vdpfB");
    lIIlIlIIIlII[lIIlIlIIlIlI[1]] = lllIIlIlIIlIl("9X72qQV+OpU=", "zgEQr");
    lIIlIlIIIlII[lIIlIlIIlIlI[2]] = lllIIlIlIIlll("CgweKgE=", "GYMcB");
    lIIlIlIIIlII[lIIlIlIIlIlI[3]] = lllIIlIlIIlll("Lj0ZPgc=", "CHjWd");
    lIIlIlIIIlII[lIIlIlIIlIlI[4]] = lllIIlIlIIlll("NCEuJiUiNw==", "fdmiw");
    lIIlIlIIIlII[lIIlIlIIlIlI[5]] = lllIIlIlIlIIl("Tu1jY2xP3nA=", "TisOI");
    lIIlIlIIIlII[lIIlIlIIlIlI[6]] = lllIIlIlIIlll("OCAWOyEqNw==", "oeWoi");
    lIIlIlIIIlII[lIIlIlIIlIlI[7]] = lllIIlIlIlIIl("MUEvq08aODA=", "kLVfx");
    lIIlIlIIIlII[lIIlIlIIlIlI[8]] = lllIIlIlIIlll("Aw49JjwS", "ABrew");
    lIIlIlIIIlII[lIIlIlIIlIlI[9]] = lllIIlIlIlIIl("IdB+Vuo/BhI=", "PNQkJ");
    lIIlIlIIIlII[lIIlIlIIlIlI[10]] = lllIIlIlIIlIl("rfcy7nDc1qc=", "wHVPh");
    lIIlIlIIIlII[lIIlIlIIlIlI[11]] = lllIIlIlIlIIl("57J8UOXAtN0=", "KgvFo");
    lIIlIlIIIlII[lIIlIlIIlIlI[12]] = lllIIlIlIIlIl("hiBL1x5tiwI=", "KUXuU");
    lIIlIlIIIlII[lIIlIlIIlIlI[13]] = lllIIlIlIIlll("HAgnMB0TAQ==", "rmRDo");
    lIIlIlIIIlII[lIIlIlIIlIlI[14]] = lllIIlIlIIlIl("eyY2lpVZOkc=", "kTdeC");
    lIIlIlIIIlII[lIIlIlIIlIlI[15]] = lllIIlIlIIlIl("kpIcbvUWcFc=", "tSZEr");
    lIIlIlIIIlII[lIIlIlIIlIlI[16]] = lllIIlIlIIlll("GT4yHgMWJw==", "XspWF");
    lIIlIlIIIlII[lIIlIlIIlIlI[17]] = lllIIlIlIlIIl("B0n3y9pncB4=", "ZGksV");
    lIIlIlIIIlII[lIIlIlIIlIlI[18]] = lllIIlIlIlIIl("QtgH4QB9nKHh59ESEUe+5j2NhSs3qS/GVvdR76zWlRnYanX4/ST9Euny7H7xNWYFRJsf+EtgVeo=", "QXqOg");
  }
}

package net.minecraft.client.player.inventory;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.IInteractionObject;

public class LocalBlockIntercommunication
  implements IInteractionObject
{
  public String getGuiID()
  {
    ;
    return guiID;
  }
  
  public LocalBlockIntercommunication(String llllllllllllllIllIlIlllIIIllllIl, IChatComponent llllllllllllllIllIlIlllIIIllIlll)
  {
    guiID = llllllllllllllIllIlIlllIIIlllIII;
    displayName = llllllllllllllIllIlIlllIIIllIlll;
  }
  
  public String getName()
  {
    ;
    return displayName.getUnformattedText();
  }
  
  static {}
  
  public Container createContainer(InventoryPlayer llllllllllllllIllIlIlllIIIllIIIl, EntityPlayer llllllllllllllIllIlIlllIIIlIllll)
  {
    throw new UnsupportedOperationException();
  }
  
  public IChatComponent getDisplayName()
  {
    ;
    return displayName;
  }
  
  public boolean hasCustomName()
  {
    return llllIIlIlIlI[0];
  }
  
  private static void lIlllIIIllIllI()
  {
    llllIIlIlIlI = new int[1];
    llllIIlIlIlI[0] = " ".length();
  }
}

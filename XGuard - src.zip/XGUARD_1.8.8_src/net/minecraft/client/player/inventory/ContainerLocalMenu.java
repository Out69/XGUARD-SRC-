package net.minecraft.client.player.inventory;

import java.util.Map;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.util.IChatComponent;
import net.minecraft.world.ILockableContainer;
import net.minecraft.world.LockCode;

public class ContainerLocalMenu
  extends InventoryBasic
  implements ILockableContainer
{
  static {}
  
  public String getGuiID()
  {
    ;
    return guiID;
  }
  
  public int getField(int llllllllllllllllIlllIIlIIlllllIl)
  {
    ;
    ;
    if (lIIIllIllllIl(field_174895_b.containsKey(Integer.valueOf(llllllllllllllllIlllIIlIIlllllIl))))
    {
      "".length();
      if (null == null) {
        break label66;
      }
      return (0x2E ^ 0x19) & (0x5 ^ 0x32 ^ 0xFFFFFFFF);
    }
    label66:
    return lIlllIIllII[0];
  }
  
  private static void lIIIllIllllII()
  {
    lIlllIIllII = new int[1];
    lIlllIIllII[0] = ((0xDE ^ 0x88) & (0x7E ^ 0x28 ^ 0xFFFFFFFF));
  }
  
  public void setLockCode(LockCode llllllllllllllllIlllIIlIIllIllII) {}
  
  public int getFieldCount()
  {
    ;
    return field_174895_b.size();
  }
  
  public boolean isLocked()
  {
    return lIlllIIllII[0];
  }
  
  public Container createContainer(InventoryPlayer llllllllllllllllIlllIIlIIllIIllI, EntityPlayer llllllllllllllllIlllIIlIIllIIlIl)
  {
    throw new UnsupportedOperationException();
  }
  
  private static boolean lIIIllIllllIl(int ???)
  {
    boolean llllllllllllllllIlllIIlIIllIIIll;
    return ??? != 0;
  }
  
  public void setField(int llllllllllllllllIlllIIlIIlllIllI, int llllllllllllllllIlllIIlIIlllIlIl)
  {
    ;
    ;
    ;
    "".length();
  }
  
  public ContainerLocalMenu(String llllllllllllllllIlllIIlIlIIIIIll, IChatComponent llllllllllllllllIlllIIlIlIIIIllI, int llllllllllllllllIlllIIlIlIIIIlIl)
  {
    llllllllllllllllIlllIIlIlIIIlIII.<init>(llllllllllllllllIlllIIlIlIIIIllI, llllllllllllllllIlllIIlIlIIIIlIl);
    guiID = llllllllllllllllIlllIIlIlIIIIIll;
  }
  
  public LockCode getLockCode()
  {
    return LockCode.EMPTY_CODE;
  }
}

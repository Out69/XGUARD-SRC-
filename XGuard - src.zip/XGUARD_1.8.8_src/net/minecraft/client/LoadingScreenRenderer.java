package net.minecraft.client;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.util.MinecraftError;

public class LoadingScreenRenderer
  implements IProgressUpdate
{
  public void displayLoadingString(String llllllllllllllllIIIIIllIIIlIllll)
  {
    ;
    ;
    if (llIIIllIlIlll(mc.running))
    {
      if (llIIIllIlIlll(field_73724_e)) {
        throw new MinecraftError();
      }
    }
    else
    {
      systemTime = 0L;
      message = llllllllllllllllIIIIIllIIIlIllll;
      llllllllllllllllIIIIIllIIIllIIlI.setLoadingProgress(lIIIIIIIIIlI[6]);
      systemTime = 0L;
    }
  }
  
  public void setDoneWorking() {}
  
  private static boolean llIIIllIllIlI(int ???)
  {
    byte llllllllllllllllIIIIIlIlllllIIIl;
    return ??? >= 0;
  }
  
  private static void llIIIllIlIllI()
  {
    lIIIIIIIIIlI = new int[20];
    lIIIIIIIIIlI[0] = ((0xE1 ^ 0xA5) & (0x4 ^ 0x40 ^ 0xFFFFFFFF));
    lIIIIIIIIIlI[1] = " ".length();
    lIIIIIIIIIlI[2] = (0xBFEA & 0x6615);
    lIIIIIIIIIlI[3] = (-(0xD549 & 0x6AFE) & 0xE57F & 0x5BC7);
    lIIIIIIIIIlI[4] = (-(0xF3FF & 0x6CB7) & 0xF7B7 & 0x7FFF);
    lIIIIIIIIIlI[5] = (-(0xE3FB & 0x7CEF) & 0xF7FA & 0x7FEF);
    lIIIIIIIIIlI[6] = (-" ".length());
    lIIIIIIIIIlI[7] = (-(0xFFFFFFF5 & 0x2EFF) & 0xFFFFFFFD & 0x6FF6);
    lIIIIIIIIIlI[8] = (0xB9 ^ 0x9D ^ 0xAB ^ 0x88);
    lIIIIIIIIIlI[9] = (0x0 ^ 0x40);
    lIIIIIIIIIlI[10] = ('' + 43 - -55 + 16);
    lIIIIIIIIIlI[11] = (8 + 'Ð' - 143 + 142 ^ 4 + 78 - -3 + 94);
    lIIIIIIIIIlI[12] = "  ".length();
    lIIIIIIIIIlI[13] = (0x25 ^ 0x23 ^ 0x57 ^ 0x41);
    lIIIIIIIIIlI[14] = (122 + 32 - 123 + 96 + (0x50 ^ 0x3A) - (16 + '¦' - 149 + 139) + (0xC8 ^ 0x8B));
    lIIIIIIIIIlI[15] = (0xCF83 & 0x337E);
    lIIIIIIIIIlI[16] = (-(0xFCAB & 0x7F5D) & 0xFFFFFFAF & 0x7F5B);
    lIIIIIIIIIlI[17] = (0x98 ^ 0x9C);
    lIIIIIIIIIlI[18] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIIIIIIIIIlI[19] = (0xEC ^ 0x95 ^ 0x29 ^ 0x58);
  }
  
  private static boolean llIIIllIlIlll(int ???)
  {
    char llllllllllllllllIIIIIlIlllllIIll;
    return ??? == 0;
  }
  
  private static int llIIIllIllIIl(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  private void displayString(String llllllllllllllllIIIIIllIIIlllIlI)
  {
    ;
    ;
    ;
    currentlyDisplayedText = llllllllllllllllIIIIIllIIIlllIlI;
    if (llIIIllIlIlll(mc.running))
    {
      if (llIIIllIlIlll(field_73724_e)) {
        throw new MinecraftError();
      }
    }
    else
    {
      GlStateManager.clear(lIIIIIIIIIlI[3]);
      GlStateManager.matrixMode(lIIIIIIIIIlI[4]);
      GlStateManager.loadIdentity();
      if (llIIIllIllIII(OpenGlHelper.isFramebufferEnabled()))
      {
        int llllllllllllllllIIIIIllIIIlllIIl = scaledResolution.getScaleFactor();
        GlStateManager.ortho(0.0D, ScaledResolution.getScaledWidth() * llllllllllllllllIIIIIllIIIlllIIl, scaledResolution.getScaledHeight() * llllllllllllllllIIIIIllIIIlllIIl, 0.0D, 100.0D, 300.0D);
        "".length();
        if (((0x2E ^ 0x18) & (0x6D ^ 0x5B ^ 0xFFFFFFFF)) == 0) {}
      }
      else
      {
        ScaledResolution llllllllllllllllIIIIIllIIIlllIII = new ScaledResolution(mc);
        GlStateManager.ortho(0.0D, llllllllllllllllIIIIIllIIIlllIII.getScaledWidth_double(), llllllllllllllllIIIIIllIIIlllIII.getScaledHeight_double(), 0.0D, 100.0D, 300.0D);
      }
      GlStateManager.matrixMode(lIIIIIIIIIlI[5]);
      GlStateManager.loadIdentity();
      GlStateManager.translate(0.0F, 0.0F, -200.0F);
    }
  }
  
  private static String llIIIllIlIlII(String llllllllllllllllIIIIIlIllllllIlI, String llllllllllllllllIIIIIlIllllllIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIIIIlIlllllllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIIIIlIllllllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIIIIIlIllllllllI = Cipher.getInstance("Blowfish");
      llllllllllllllllIIIIIlIllllllllI.init(lIIIIIIIIIlI[12], llllllllllllllllIIIIIlIlllllllll);
      return new String(llllllllllllllllIIIIIlIllllllllI.doFinal(Base64.getDecoder().decode(llllllllllllllllIIIIIlIllllllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIIIIlIlllllllIl)
    {
      llllllllllllllllIIIIIlIlllllllIl.printStackTrace();
    }
    return null;
  }
  
  public void setLoadingProgress(int llllllllllllllllIIIIIllIIIIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIIllIlIlll(mc.running))
    {
      if (llIIIllIlIlll(field_73724_e)) {
        throw new MinecraftError();
      }
    }
    else
    {
      long llllllllllllllllIIIIIllIIIIllllI = Minecraft.getSystemTime();
      if (llIIIllIllIlI(llIIIllIllIIl(llllllllllllllllIIIIIllIIIIllllI - systemTime, 100L)))
      {
        systemTime = llllllllllllllllIIIIIllIIIIllllI;
        ScaledResolution llllllllllllllllIIIIIllIIIIlllIl = new ScaledResolution(mc);
        int llllllllllllllllIIIIIllIIIIlllII = llllllllllllllllIIIIIllIIIIlllIl.getScaleFactor();
        int llllllllllllllllIIIIIllIIIIllIll = ScaledResolution.getScaledWidth();
        int llllllllllllllllIIIIIllIIIIllIlI = llllllllllllllllIIIIIllIIIIlllIl.getScaledHeight();
        if (llIIIllIllIII(OpenGlHelper.isFramebufferEnabled()))
        {
          framebuffer.framebufferClear();
          "".length();
          if (" ".length() >= 0) {}
        }
        else
        {
          GlStateManager.clear(lIIIIIIIIIlI[3]);
        }
        framebuffer.bindFramebuffer(lIIIIIIIIIlI[0]);
        GlStateManager.matrixMode(lIIIIIIIIIlI[4]);
        GlStateManager.loadIdentity();
        GlStateManager.ortho(0.0D, llllllllllllllllIIIIIllIIIIlllIl.getScaledWidth_double(), llllllllllllllllIIIIIllIIIIlllIl.getScaledHeight_double(), 0.0D, 100.0D, 300.0D);
        GlStateManager.matrixMode(lIIIIIIIIIlI[5]);
        GlStateManager.loadIdentity();
        GlStateManager.translate(0.0F, 0.0F, -200.0F);
        if (llIIIllIlIlll(OpenGlHelper.isFramebufferEnabled())) {
          GlStateManager.clear(lIIIIIIIIIlI[7]);
        }
        Tessellator llllllllllllllllIIIIIllIIIIllIIl = Tessellator.getInstance();
        WorldRenderer llllllllllllllllIIIIIllIIIIllIII = llllllllllllllllIIIIIllIIIIllIIl.getWorldRenderer();
        mc.getTextureManager().bindTexture(Gui.optionsBackground);
        float llllllllllllllllIIIIIllIIIIlIlll = 32.0F;
        llllllllllllllllIIIIIllIIIIllIII.begin(lIIIIIIIIIlI[8], DefaultVertexFormats.POSITION_TEX_COLOR);
        llllllllllllllllIIIIIllIIIIllIII.pos(0.0D, llllllllllllllllIIIIIllIIIIllIlI, 0.0D).tex(0.0D, llllllllllllllllIIIIIllIIIIllIlI / llllllllllllllllIIIIIllIIIIlIlll).color(lIIIIIIIIIlI[9], lIIIIIIIIIlI[9], lIIIIIIIIIlI[9], lIIIIIIIIIlI[10]).endVertex();
        llllllllllllllllIIIIIllIIIIllIII.pos(llllllllllllllllIIIIIllIIIIllIll, llllllllllllllllIIIIIllIIIIllIlI, 0.0D).tex(llllllllllllllllIIIIIllIIIIllIll / llllllllllllllllIIIIIllIIIIlIlll, llllllllllllllllIIIIIllIIIIllIlI / llllllllllllllllIIIIIllIIIIlIlll).color(lIIIIIIIIIlI[9], lIIIIIIIIIlI[9], lIIIIIIIIIlI[9], lIIIIIIIIIlI[10]).endVertex();
        llllllllllllllllIIIIIllIIIIllIII.pos(llllllllllllllllIIIIIllIIIIllIll, 0.0D, 0.0D).tex(llllllllllllllllIIIIIllIIIIllIll / llllllllllllllllIIIIIllIIIIlIlll, 0.0D).color(lIIIIIIIIIlI[9], lIIIIIIIIIlI[9], lIIIIIIIIIlI[9], lIIIIIIIIIlI[10]).endVertex();
        llllllllllllllllIIIIIllIIIIllIII.pos(0.0D, 0.0D, 0.0D).tex(0.0D, 0.0D).color(lIIIIIIIIIlI[9], lIIIIIIIIIlI[9], lIIIIIIIIIlI[9], lIIIIIIIIIlI[10]).endVertex();
        llllllllllllllllIIIIIllIIIIllIIl.draw();
        if (llIIIllIllIlI(llllllllllllllllIIIIIllIIIIlIIIl))
        {
          int llllllllllllllllIIIIIllIIIIlIllI = lIIIIIIIIIlI[11];
          int llllllllllllllllIIIIIllIIIIlIlIl = lIIIIIIIIIlI[12];
          int llllllllllllllllIIIIIllIIIIlIlII = llllllllllllllllIIIIIllIIIIllIll / lIIIIIIIIIlI[12] - llllllllllllllllIIIIIllIIIIlIllI / lIIIIIIIIIlI[12];
          int llllllllllllllllIIIIIllIIIIlIIll = llllllllllllllllIIIIIllIIIIllIlI / lIIIIIIIIIlI[12] + lIIIIIIIIIlI[13];
          GlStateManager.disableTexture2D();
          llllllllllllllllIIIIIllIIIIllIII.begin(lIIIIIIIIIlI[8], DefaultVertexFormats.POSITION_COLOR);
          llllllllllllllllIIIIIllIIIIllIII.pos(llllllllllllllllIIIIIllIIIIlIlII, llllllllllllllllIIIIIllIIIIlIIll, 0.0D).color(lIIIIIIIIIlI[14], lIIIIIIIIIlI[14], lIIIIIIIIIlI[14], lIIIIIIIIIlI[10]).endVertex();
          llllllllllllllllIIIIIllIIIIllIII.pos(llllllllllllllllIIIIIllIIIIlIlII, llllllllllllllllIIIIIllIIIIlIIll + llllllllllllllllIIIIIllIIIIlIlIl, 0.0D).color(lIIIIIIIIIlI[14], lIIIIIIIIIlI[14], lIIIIIIIIIlI[14], lIIIIIIIIIlI[10]).endVertex();
          llllllllllllllllIIIIIllIIIIllIII.pos(llllllllllllllllIIIIIllIIIIlIlII + llllllllllllllllIIIIIllIIIIlIllI, llllllllllllllllIIIIIllIIIIlIIll + llllllllllllllllIIIIIllIIIIlIlIl, 0.0D).color(lIIIIIIIIIlI[14], lIIIIIIIIIlI[14], lIIIIIIIIIlI[14], lIIIIIIIIIlI[10]).endVertex();
          llllllllllllllllIIIIIllIIIIllIII.pos(llllllllllllllllIIIIIllIIIIlIlII + llllllllllllllllIIIIIllIIIIlIllI, llllllllllllllllIIIIIllIIIIlIIll, 0.0D).color(lIIIIIIIIIlI[14], lIIIIIIIIIlI[14], lIIIIIIIIIlI[14], lIIIIIIIIIlI[10]).endVertex();
          llllllllllllllllIIIIIllIIIIllIII.pos(llllllllllllllllIIIIIllIIIIlIlII, llllllllllllllllIIIIIllIIIIlIIll, 0.0D).color(lIIIIIIIIIlI[14], lIIIIIIIIIlI[10], lIIIIIIIIIlI[14], lIIIIIIIIIlI[10]).endVertex();
          llllllllllllllllIIIIIllIIIIllIII.pos(llllllllllllllllIIIIIllIIIIlIlII, llllllllllllllllIIIIIllIIIIlIIll + llllllllllllllllIIIIIllIIIIlIlIl, 0.0D).color(lIIIIIIIIIlI[14], lIIIIIIIIIlI[10], lIIIIIIIIIlI[14], lIIIIIIIIIlI[10]).endVertex();
          llllllllllllllllIIIIIllIIIIllIII.pos(llllllllllllllllIIIIIllIIIIlIlII + llllllllllllllllIIIIIllIIIIlIIIl, llllllllllllllllIIIIIllIIIIlIIll + llllllllllllllllIIIIIllIIIIlIlIl, 0.0D).color(lIIIIIIIIIlI[14], lIIIIIIIIIlI[10], lIIIIIIIIIlI[14], lIIIIIIIIIlI[10]).endVertex();
          llllllllllllllllIIIIIllIIIIllIII.pos(llllllllllllllllIIIIIllIIIIlIlII + llllllllllllllllIIIIIllIIIIlIIIl, llllllllllllllllIIIIIllIIIIlIIll, 0.0D).color(lIIIIIIIIIlI[14], lIIIIIIIIIlI[10], lIIIIIIIIIlI[14], lIIIIIIIIIlI[10]).endVertex();
          llllllllllllllllIIIIIllIIIIllIIl.draw();
          GlStateManager.enableTexture2D();
        }
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(lIIIIIIIIIlI[15], lIIIIIIIIIlI[16], lIIIIIIIIIlI[1], lIIIIIIIIIlI[0]);
        "".length();
        "".length();
        framebuffer.unbindFramebuffer();
        if (llIIIllIllIII(OpenGlHelper.isFramebufferEnabled())) {
          framebuffer.framebufferRender(llllllllllllllllIIIIIllIIIIllIll * llllllllllllllllIIIIIllIIIIlllII, llllllllllllllllIIIIIllIIIIllIlI * llllllllllllllllIIIIIllIIIIlllII);
        }
        mc.updateDisplay();
        try
        {
          Thread.yield();
          "".length();
          if (((16 + '' - 11 + 42 ^ 86 + 74 - 121 + 121) & (0x9B ^ 0xAB ^ 0x58 ^ 0x77 ^ -" ".length())) < 0) {}
        }
        catch (Exception localException) {}
      }
    }
  }
  
  private static boolean llIIIllIllIII(int ???)
  {
    Exception llllllllllllllllIIIIIlIlllllIlIl;
    return ??? != 0;
  }
  
  private static void llIIIllIlIlIl()
  {
    lIIIIIIIIIIl = new String[lIIIIIIIIIlI[12]];
    lIIIIIIIIIIl[lIIIIIIIIIlI[0]] = llIIIllIlIlII("Bo5fRGtQzXs=", "Dlmek");
    lIIIIIIIIIIl[lIIIIIIIIIlI[1]] = llIIIllIlIlII("Gy+3Ynsp6cY=", "vfbnT");
  }
  
  public void resetProgressAndMessage(String llllllllllllllllIIIIIllIIlIIIlIl)
  {
    ;
    ;
    field_73724_e = lIIIIIIIIIlI[0];
    llllllllllllllllIIIIIllIIlIIlIII.displayString(llllllllllllllllIIIIIllIIlIIIlIl);
  }
  
  public void displaySavingString(String llllllllllllllllIIIIIllIIIllllll)
  {
    ;
    ;
    field_73724_e = lIIIIIIIIIlI[1];
    llllllllllllllllIIIIIllIIlIIIIII.displayString(llllllllllllllllIIIIIllIIIllllll);
  }
  
  static
  {
    llIIIllIlIllI();
    llIIIllIlIlIl();
  }
  
  public LoadingScreenRenderer(Minecraft llllllllllllllllIIIIIllIIlIIlIll)
  {
    mc = llllllllllllllllIIIIIllIIlIIlIll;
    scaledResolution = new ScaledResolution(llllllllllllllllIIIIIllIIlIIlIll);
    framebuffer = new Framebuffer(displayWidth, displayHeight, lIIIIIIIIIlI[0]);
    framebuffer.setFramebufferFilter(lIIIIIIIIIlI[2]);
  }
}

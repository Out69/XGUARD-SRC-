package net.minecraft.client.model;

import java.util.Random;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelGhast
  extends ModelBase
{
  static {}
  
  public void render(Entity llllllllllllllIIllIlIlIIllIlIlIl, float llllllllllllllIIllIlIlIIllIlIlII, float llllllllllllllIIllIlIlIIllIlllII, float llllllllllllllIIllIlIlIIllIlIIlI, float llllllllllllllIIllIlIlIIllIlIIIl, float llllllllllllllIIllIlIlIIllIlIIII, float llllllllllllllIIllIlIlIIllIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIlIlIIllIlIllI.setRotationAngles(llllllllllllllIIllIlIlIIllIlIlII, llllllllllllllIIllIlIlIIllIlllII, llllllllllllllIIllIlIlIIllIlIIlI, llllllllllllllIIllIlIlIIllIlIIIl, llllllllllllllIIllIlIlIIllIlIIII, llllllllllllllIIllIlIlIIllIIllll, llllllllllllllIIllIlIlIIllIlIlIl);
    GlStateManager.pushMatrix();
    GlStateManager.translate(0.0F, 0.6F, 0.0F);
    body.render(llllllllllllllIIllIlIlIIllIIllll);
    short llllllllllllllIIllIlIlIIllIIllII = (llllllllllllllIIllIlIlIIllIIlIll = tentacles).length;
    long llllllllllllllIIllIlIlIIllIIllIl = lIIllIlIllIll[2];
    "".length();
    if (null != null) {
      return;
    }
    while (!lllIllIIIIllIl(llllllllllllllIIllIlIlIIllIIllIl, llllllllllllllIIllIlIlIIllIIllII))
    {
      ModelRenderer llllllllllllllIIllIlIlIIllIlIlll = llllllllllllllIIllIlIlIIllIIlIll[llllllllllllllIIllIlIlIIllIIllIl];
      llllllllllllllIIllIlIlIIllIlIlll.render(llllllllllllllIIllIlIlIIllIIllll);
      llllllllllllllIIllIlIlIIllIIllIl++;
    }
    GlStateManager.popMatrix();
  }
  
  public ModelGhast()
  {
    int llllllllllllllIIllIlIlIlIIIIIlll = lIIllIlIllIll[1];
    body = new ModelRenderer(llllllllllllllIIllIlIlIlIIIIIIIl, lIIllIlIllIll[2], lIIllIlIllIll[2]);
    "".length();
    body.rotationPointY += lIIllIlIllIll[4] + llllllllllllllIIllIlIlIlIIIIIlll;
    Random llllllllllllllIIllIlIlIlIIIIIllI = new Random(1660L);
    int llllllllllllllIIllIlIlIlIIIIIlIl = lIIllIlIllIll[2];
    "".length();
    if (null != null) {
      throw null;
    }
    while (!lllIllIIIIllIl(llllllllllllllIIllIlIlIlIIIIIlIl, tentacles.length))
    {
      tentacles[llllllllllllllIIllIlIlIlIIIIIlIl] = new ModelRenderer(llllllllllllllIIllIlIlIlIIIIIIIl, lIIllIlIllIll[2], lIIllIlIllIll[2]);
      float llllllllllllllIIllIlIlIlIIIIIlII = ((llllllllllllllIIllIlIlIlIIIIIlIl % lIIllIlIllIll[5] - llllllllllllllIIllIlIlIlIIIIIlIl / lIIllIlIllIll[5] % lIIllIlIllIll[6] * 0.5F + 0.25F) / 2.0F * 2.0F - 1.0F) * 5.0F;
      float llllllllllllllIIllIlIlIlIIIIIIll = (llllllllllllllIIllIlIlIlIIIIIlIl / lIIllIlIllIll[5] / 2.0F * 2.0F - 1.0F) * 5.0F;
      int llllllllllllllIIllIlIlIlIIIIIIlI = llllllllllllllIIllIlIlIlIIIIIllI.nextInt(lIIllIlIllIll[7]) + lIIllIlIllIll[8];
      "".length();
      tentacles[llllllllllllllIIllIlIlIlIIIIIlIl].rotationPointX = llllllllllllllIIllIlIlIlIIIIIlII;
      tentacles[llllllllllllllIIllIlIlIlIIIIIlIl].rotationPointZ = llllllllllllllIIllIlIlIlIIIIIIll;
      tentacles[llllllllllllllIIllIlIlIlIIIIIlIl].rotationPointY = (lIIllIlIllIll[9] + llllllllllllllIIllIlIlIlIIIIIlll);
    }
  }
  
  public void setRotationAngles(float llllllllllllllIIllIlIlIIllllIllI, float llllllllllllllIIllIlIlIIllllIlIl, float llllllllllllllIIllIlIlIIllllIlII, float llllllllllllllIIllIlIlIIllllIIll, float llllllllllllllIIllIlIlIIllllIIlI, float llllllllllllllIIllIlIlIIllllIIIl, Entity llllllllllllllIIllIlIlIIllllIIII)
  {
    ;
    ;
    ;
    int llllllllllllllIIllIlIlIIlllIllll = lIIllIlIllIll[2];
    "".length();
    if (null != null) {
      return;
    }
    while (!lllIllIIIIllIl(llllllllllllllIIllIlIlIIlllIllll, tentacles.length))
    {
      tentacles[llllllllllllllIIllIlIlIIlllIllll].rotateAngleX = (0.2F * MathHelper.sin(llllllllllllllIIllIlIlIIllllIlII * 0.3F + llllllllllllllIIllIlIlIIlllIllll) + 0.4F);
      llllllllllllllIIllIlIlIIlllIllll++;
    }
  }
  
  private static boolean lllIllIIIIllIl(int ???, int arg1)
  {
    int i;
    double llllllllllllllIIllIlIlIIllIIIlll;
    return ??? >= i;
  }
  
  private static void lllIllIIIIllII()
  {
    lIIllIlIllIll = new int[10];
    lIIllIlIllIll[0] = (0x96 ^ 0xB6 ^ 0x9A ^ 0xB3);
    lIIllIlIllIll[1] = (-(0x24 ^ 0x22 ^ 0xC ^ 0x1A));
    lIIllIlIllIll[2] = ("   ".length() & ("   ".length() ^ 0xFFFFFFFF));
    lIIllIlIllIll[3] = (0x74 ^ 0x64);
    lIIllIlIllIll[4] = (0xDA ^ 0xC2);
    lIIllIlIllIll[5] = "   ".length();
    lIIllIlIllIll[6] = "  ".length();
    lIIllIlIllIll[7] = (0x19 ^ 0x7 ^ 0x68 ^ 0x71);
    lIIllIlIllIll[8] = (0x68 ^ 0x2A ^ 0xCE ^ 0x84);
    lIIllIlIllIll[9] = (62 + 16 - -72 + 35 ^ 55 + 32 - 76 + 155);
  }
}

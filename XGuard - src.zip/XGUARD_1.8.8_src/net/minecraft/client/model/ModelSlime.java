package net.minecraft.client.model;

import net.minecraft.entity.Entity;

public class ModelSlime
  extends ModelBase
{
  private static void lllIIIIIllll()
  {
    lIIIllIIllI = new int[7];
    lIIIllIIllI[0] = ((0x75 ^ 0x70 ^ 0x53 ^ 0x70) & ('' + 46 - 113 + 90 ^ 105 + 119 - 126 + 37 ^ -" ".length()));
    lIIIllIIllI[1] = (0xCB ^ 0xC3);
    lIIIllIIllI[2] = (0x3A ^ 0x3C);
    lIIIllIIllI[3] = (0x2 ^ 0x2E ^ 0x4F ^ 0x43);
    lIIIllIIllI[4] = "  ".length();
    lIIIllIIllI[5] = (0x83 ^ 0x87);
    lIIIllIIllI[6] = " ".length();
  }
  
  private static boolean lllIIIIlIIII(int ???)
  {
    byte lllllllllllllllllIlIlIIllIlIlIll;
    return ??? > 0;
  }
  
  public ModelSlime(int lllllllllllllllllIlIlIIlllIIIlll)
  {
    slimeBodies = new ModelRenderer(lllllllllllllllllIlIlIIlllIIlIlI, lIIIllIIllI[0], lllllllllllllllllIlIlIIlllIIIlll);
    "".length();
    if (lllIIIIlIIII(lllllllllllllllllIlIlIIlllIIIlll))
    {
      slimeBodies = new ModelRenderer(lllllllllllllllllIlIlIIlllIIlIlI, lIIIllIIllI[0], lllllllllllllllllIlIlIIlllIIIlll);
      "".length();
      slimeRightEye = new ModelRenderer(lllllllllllllllllIlIlIIlllIIlIlI, lIIIllIIllI[3], lIIIllIIllI[0]);
      "".length();
      slimeLeftEye = new ModelRenderer(lllllllllllllllllIlIlIIlllIIlIlI, lIIIllIIllI[3], lIIIllIIllI[5]);
      "".length();
      slimeMouth = new ModelRenderer(lllllllllllllllllIlIlIIlllIIlIlI, lIIIllIIllI[3], lIIIllIIllI[1]);
      "".length();
    }
  }
  
  private static boolean lllIIIIlIIIl(Object ???)
  {
    Exception lllllllllllllllllIlIlIIllIlIllIl;
    return ??? != null;
  }
  
  static {}
  
  public void render(Entity lllllllllllllllllIlIlIIllIllllIl, float lllllllllllllllllIlIlIIllIllllII, float lllllllllllllllllIlIlIIllIllIIll, float lllllllllllllllllIlIlIIllIllIIlI, float lllllllllllllllllIlIlIIllIlllIIl, float lllllllllllllllllIlIlIIllIlllIII, float lllllllllllllllllIlIlIIllIllIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIlIlIIllIlllllI.setRotationAngles(lllllllllllllllllIlIlIIllIllllII, lllllllllllllllllIlIlIIllIllIIll, lllllllllllllllllIlIlIIllIllIIlI, lllllllllllllllllIlIlIIllIlllIIl, lllllllllllllllllIlIlIIllIlllIII, lllllllllllllllllIlIlIIllIllIlll, lllllllllllllllllIlIlIIllIllllIl);
    slimeBodies.render(lllllllllllllllllIlIlIIllIllIlll);
    if (lllIIIIlIIIl(slimeRightEye))
    {
      slimeRightEye.render(lllllllllllllllllIlIlIIllIllIlll);
      slimeLeftEye.render(lllllllllllllllllIlIlIIllIllIlll);
      slimeMouth.render(lllllllllllllllllIlIlIIllIllIlll);
    }
  }
}

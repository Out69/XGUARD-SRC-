package net.minecraft.client.model;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.util.MathHelper;

public class ModelHorse
  extends ModelBase
{
  private static int llIIlIlIlIIIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private void setBoxRotation(ModelRenderer llllllllllllllIlIllIIIIlllIlllIl, float llllllllllllllIlIllIIIIlllIlllII, float llllllllllllllIlIllIIIIlllIllIll, float llllllllllllllIlIllIIIIlllIllIlI)
  {
    ;
    ;
    ;
    ;
    rotateAngleX = llllllllllllllIlIllIIIIlllIlllII;
    rotateAngleY = llllllllllllllIlIllIIIIlllIllIll;
    rotateAngleZ = llllllllllllllIlIllIIIIlllIllIlI;
  }
  
  private static int llIIlIlIlIlIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llIIlIlIlIlllI(int ???)
  {
    long llllllllllllllIlIllIIIIIlllIlIll;
    return ??? >= 0;
  }
  
  private static boolean llIIlIlIllIlII(int ???)
  {
    short llllllllllllllIlIllIIIIIllIllIll;
    return ??? > 0;
  }
  
  private static void llIIlIlIIllIlI()
  {
    lIIIIlIIlIIll = new int[35];
    lIIIIlIIlIIll[0] = ((0x3C ^ 0x1B) + (125 + 53 - 94 + 43) - (124 + 26 - 106 + 85) + (0x15 ^ 0x4E));
    lIIIIlIIlIIll[1] = ((98 + 101 - 157 + 92 ^ 3 + 64 - -60 + 3) & (0xE0 ^ 0xBD ^ 0x65 ^ 0x3C ^ -" ".length()));
    lIIIIlIIlIIll[2] = (28 + 110 - 41 + 35 ^ '' + 73 - 157 + 98);
    lIIIIlIIlIIll[3] = (0xCE ^ 0xC4);
    lIIIIlIIlIIll[4] = (0x3B ^ 0x23);
    lIIIIlIIlIIll[5] = (0x6E ^ 0x42);
    lIIIIlIIlIIll[6] = "  ".length();
    lIIIIlIIlIIll[7] = "   ".length();
    lIIIIlIIlIIll[8] = (0x20 ^ 0x6);
    lIIIIlIIlIIll[9] = (0x36 ^ 0x48 ^ 0xB ^ 0x72);
    lIIIIlIIlIIll[10] = (42 + 'º' - 95 + 54 ^ '¥' + '' - 150 + 41);
    lIIIIlIIlIIll[11] = (0x70 ^ 0x3E);
    lIIIIlIIlIIll[12] = (0x3A ^ 0x27);
    lIIIIlIIlIIll[13] = (0xA0 ^ 0xA9);
    lIIIIlIIlIIll[14] = (0xF ^ 0x5D ^ 0x97 ^ 0xC0);
    lIIIIlIIlIIll[15] = ('' + '' - 263 + 148 ^ 89 + 94 - 112 + 57);
    lIIIIlIIlIIll[16] = (49 + 3 - -12 + 71 ^ 123 + '¬' - 147 + 32);
    lIIIIlIIlIIll[17] = (0x7 ^ 0x67);
    lIIIIlIIlIIll[18] = (0x46 ^ 0x4E);
    lIIIIlIIlIIll[19] = (4 + '' - 77 + 99 ^ 77 + 106 - 38 + 33);
    lIIIIlIIlIIll[20] = (0xFF ^ 0x89 ^ 0x6D ^ 0x27);
    lIIIIlIIlIIll[21] = (0x62 ^ 0x3B ^ 0x2B ^ 0x60);
    lIIIIlIIlIIll[22] = (0xB6 ^ 0x99 ^ 0x11 ^ 0x38);
    lIIIIlIIlIIll[23] = (0xCD ^ 0xA7 ^ 0x71 ^ 0x0);
    lIIIIlIIlIIll[24] = " ".length();
    lIIIIlIIlIIll[25] = (0x18 ^ 0x14);
    lIIIIlIIlIIll[26] = (0x1B ^ 0x15);
    lIIIIlIIlIIll[27] = (0x5F ^ 0x4 ^ 0xDE ^ 0xAA);
    lIIIIlIIlIIll[28] = (0x65 ^ 0x13 ^ 0xA7 ^ 0x81);
    lIIIIlIIlIIll[29] = (0xAF ^ 0xA8 ^ 0x42 ^ 0x2F);
    lIIIIlIIlIIll[30] = (85 + 10 - -4 + 124 ^ 119 + 116 - 147 + 61);
    lIIIIlIIlIIll[31] = (0xC0 ^ 0xA1 ^ 0x2E ^ 0x9);
    lIIIIlIIlIIll[32] = (0x9D ^ 0x90);
    lIIIIlIIlIIll[33] = (0xD6 ^ 0xC6);
    lIIIIlIIlIIll[34] = ("  ".length() ^ 0xA7 ^ 0x9F);
  }
  
  private static int llIIlIlIllIIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static int llIIlIlIllIIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llIIlIlIlIIlII(int ???)
  {
    char llllllllllllllIlIllIIIIIlllIllIl;
    return ??? == 0;
  }
  
  public ModelHorse()
  {
    textureWidth = lIIIIlIIlIIll[0];
    textureHeight = lIIIIlIIlIIll[0];
    "".length();
    body.setRotationPoint(0.0F, 11.0F, 9.0F);
    tailBase = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[5], lIIIIlIIlIIll[1]);
    "".length();
    tailBase.setRotationPoint(0.0F, 3.0F, 14.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(tailBase, -1.134464F, 0.0F, 0.0F);
    tailMiddle = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[8], lIIIIlIIlIIll[9]);
    "".length();
    tailMiddle.setRotationPoint(0.0F, 3.0F, 14.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(tailMiddle, -1.134464F, 0.0F, 0.0F);
    tailTip = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[4], lIIIIlIIlIIll[7]);
    "".length();
    tailTip.setRotationPoint(0.0F, 3.0F, 14.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(tailTip, -1.40215F, 0.0F, 0.0F);
    backLeftLeg = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[11], lIIIIlIIlIIll[12]);
    "".length();
    backLeftLeg.setRotationPoint(4.0F, 9.0F, 11.0F);
    backLeftShin = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[11], lIIIIlIIlIIll[15]);
    "".length();
    backLeftShin.setRotationPoint(4.0F, 16.0F, 11.0F);
    backLeftHoof = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[11], lIIIIlIIlIIll[16]);
    "".length();
    backLeftHoof.setRotationPoint(4.0F, 16.0F, 11.0F);
    backRightLeg = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[17], lIIIIlIIlIIll[12]);
    "".length();
    backRightLeg.setRotationPoint(-4.0F, 9.0F, 11.0F);
    backRightShin = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[17], lIIIIlIIlIIll[15]);
    "".length();
    backRightShin.setRotationPoint(-4.0F, 16.0F, 11.0F);
    backRightHoof = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[17], lIIIIlIIlIIll[16]);
    "".length();
    backRightHoof.setRotationPoint(-4.0F, 16.0F, 11.0F);
    frontLeftLeg = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[5], lIIIIlIIlIIll[12]);
    "".length();
    frontLeftLeg.setRotationPoint(4.0F, 9.0F, -8.0F);
    frontLeftShin = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[5], lIIIIlIIlIIll[19]);
    "".length();
    frontLeftShin.setRotationPoint(4.0F, 16.0F, -8.0F);
    frontLeftHoof = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[5], lIIIIlIIlIIll[16]);
    "".length();
    frontLeftHoof.setRotationPoint(4.0F, 16.0F, -8.0F);
    frontRightLeg = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[20], lIIIIlIIlIIll[12]);
    "".length();
    frontRightLeg.setRotationPoint(-4.0F, 9.0F, -8.0F);
    frontRightShin = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[20], lIIIIlIIlIIll[19]);
    "".length();
    frontRightShin.setRotationPoint(-4.0F, 16.0F, -8.0F);
    frontRightHoof = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[20], lIIIIlIIlIIll[16]);
    "".length();
    frontRightHoof.setRotationPoint(-4.0F, 16.0F, -8.0F);
    head = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[1], lIIIIlIIlIIll[1]);
    "".length();
    head.setRotationPoint(0.0F, 4.0F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(head, 0.5235988F, 0.0F, 0.0F);
    field_178711_b = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[4], lIIIIlIIlIIll[21]);
    "".length();
    field_178711_b.setRotationPoint(0.0F, 3.95F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(field_178711_b, 0.5235988F, 0.0F, 0.0F);
    field_178712_c = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[4], lIIIIlIIlIIll[23]);
    "".length();
    field_178712_c.setRotationPoint(0.0F, 4.0F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(field_178712_c, 0.5235988F, 0.0F, 0.0F);
    head.addChild(field_178711_b);
    head.addChild(field_178712_c);
    horseLeftEar = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[1], lIIIIlIIlIIll[1]);
    "".length();
    horseLeftEar.setRotationPoint(0.0F, 4.0F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(horseLeftEar, 0.5235988F, 0.0F, 0.0F);
    horseRightEar = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[1], lIIIIlIIlIIll[1]);
    "".length();
    horseRightEar.setRotationPoint(0.0F, 4.0F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(horseRightEar, 0.5235988F, 0.0F, 0.0F);
    muleLeftEar = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[1], lIIIIlIIlIIll[25]);
    "".length();
    muleLeftEar.setRotationPoint(0.0F, 4.0F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(muleLeftEar, 0.5235988F, 0.0F, 0.2617994F);
    muleRightEar = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[1], lIIIIlIIlIIll[25]);
    "".length();
    muleRightEar.setRotationPoint(0.0F, 4.0F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(muleRightEar, 0.5235988F, 0.0F, -0.2617994F);
    neck = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[1], lIIIIlIIlIIll[25]);
    "".length();
    neck.setRotationPoint(0.0F, 4.0F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(neck, 0.5235988F, 0.0F, 0.0F);
    muleLeftChest = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[1], lIIIIlIIlIIll[2]);
    "".length();
    muleLeftChest.setRotationPoint(-7.5F, 3.0F, 10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(muleLeftChest, 0.0F, 1.5707964F, 0.0F);
    muleRightChest = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[1], lIIIIlIIlIIll[27]);
    "".length();
    muleRightChest.setRotationPoint(4.5F, 3.0F, 10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(muleRightChest, 0.0F, 1.5707964F, 0.0F);
    horseSaddleBottom = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[28], lIIIIlIIlIIll[1]);
    "".length();
    horseSaddleBottom.setRotationPoint(0.0F, 2.0F, 2.0F);
    horseSaddleFront = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[29], lIIIIlIIlIIll[13]);
    "".length();
    horseSaddleFront.setRotationPoint(0.0F, 2.0F, 2.0F);
    horseSaddleBack = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[28], lIIIIlIIlIIll[13]);
    "".length();
    horseSaddleBack.setRotationPoint(0.0F, 2.0F, 2.0F);
    horseLeftSaddleMetal = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[30], lIIIIlIIlIIll[1]);
    "".length();
    horseLeftSaddleMetal.setRotationPoint(5.0F, 3.0F, 2.0F);
    horseLeftSaddleRope = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[31], lIIIIlIIlIIll[1]);
    "".length();
    horseLeftSaddleRope.setRotationPoint(5.0F, 3.0F, 2.0F);
    horseRightSaddleMetal = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[30], lIIIIlIIlIIll[10]);
    "".length();
    horseRightSaddleMetal.setRotationPoint(-5.0F, 3.0F, 2.0F);
    horseRightSaddleRope = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[28], lIIIIlIIlIIll[1]);
    "".length();
    horseRightSaddleRope.setRotationPoint(-5.0F, 3.0F, 2.0F);
    horseLeftFaceMetal = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[30], lIIIIlIIlIIll[32]);
    "".length();
    horseLeftFaceMetal.setRotationPoint(0.0F, 4.0F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(horseLeftFaceMetal, 0.5235988F, 0.0F, 0.0F);
    horseRightFaceMetal = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[30], lIIIIlIIlIIll[32]);
    "".length();
    horseRightFaceMetal.setRotationPoint(0.0F, 4.0F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(horseRightFaceMetal, 0.5235988F, 0.0F, 0.0F);
    horseLeftRein = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[5], lIIIIlIIlIIll[3]);
    "".length();
    horseLeftRein.setRotationPoint(0.0F, 4.0F, -10.0F);
    horseRightRein = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[5], lIIIIlIIlIIll[14]);
    "".length();
    horseRightRein.setRotationPoint(0.0F, 4.0F, -10.0F);
    mane = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[34], lIIIIlIIlIIll[1]);
    "".length();
    mane.setRotationPoint(0.0F, 4.0F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(mane, 0.5235988F, 0.0F, 0.0F);
    horseFaceRopes = new ModelRenderer(llllllllllllllIlIllIIIlIIlIIlIll, lIIIIlIIlIIll[28], lIIIIlIIlIIll[25]);
    horseFaceRopes.addBox(-2.5F, -10.1F, -7.0F, lIIIIlIIlIIll[14], lIIIIlIIlIIll[14], lIIIIlIIlIIll[25], 0.2F);
    horseFaceRopes.setRotationPoint(0.0F, 4.0F, -10.0F);
    llllllllllllllIlIllIIIlIIlIIlIll.setBoxRotation(horseFaceRopes, 0.5235988F, 0.0F, 0.0F);
  }
  
  private static boolean llIIlIlIlIIIIl(int ???)
  {
    char llllllllllllllIlIllIIIIIlllIllll;
    return ??? != 0;
  }
  
  public void render(Entity llllllllllllllIlIllIIIlIIIlIIllI, float llllllllllllllIlIllIIIlIIIlIIlII, float llllllllllllllIlIllIIIlIIIlIIIlI, float llllllllllllllIlIllIIIlIIIlIIIII, float llllllllllllllIlIllIIIlIIIIllllI, float llllllllllllllIlIllIIIlIIIIlllIl, float llllllllllllllIlIllIIIlIIIIIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EntityHorse llllllllllllllIlIllIIIlIIIIllIll = (EntityHorse)llllllllllllllIlIllIIIlIIIlIIllI;
    int llllllllllllllIlIllIIIlIIIIllIlI = llllllllllllllIlIllIIIlIIIIllIll.getHorseType();
    float llllllllllllllIlIllIIIlIIIIllIIl = llllllllllllllIlIllIIIlIIIIllIll.getGrassEatingAmount(0.0F);
    boolean llllllllllllllIlIllIIIlIIIIllIII = llllllllllllllIlIllIIIlIIIIllIll.isAdultHorse();
    if ((llIIlIlIlIIIIl(llllllllllllllIlIllIIIlIIIIllIII)) && (llIIlIlIlIIIIl(llllllllllllllIlIllIIIlIIIIllIll.isHorseSaddled())))
    {
      "".length();
      if ((0xA3 ^ 0xAF ^ 0x5 ^ 0xD) != 0) {
        break label80;
      }
    }
    label80:
    boolean llllllllllllllIlIllIIIlIIIIlIlll = lIIIIlIIlIIll[1];
    if ((llIIlIlIlIIIIl(llllllllllllllIlIllIIIlIIIIllIII)) && (llIIlIlIlIIIIl(llllllllllllllIlIllIIIlIIIIllIll.isChested())))
    {
      "".length();
      if ("   ".length() == "   ".length()) {
        break label132;
      }
    }
    label132:
    boolean llllllllllllllIlIllIIIlIIIIlIllI = lIIIIlIIlIIll[1];
    if ((llIIlIlIlIIIlI(llllllllllllllIlIllIIIlIIIIllIlI, lIIIIlIIlIIll[24])) && (llIIlIlIlIIIlI(llllllllllllllIlIllIIIlIIIIllIlI, lIIIIlIIlIIll[6])))
    {
      "".length();
      if (" ".length() != 0) {
        break label188;
      }
    }
    label188:
    boolean llllllllllllllIlIllIIIlIIIIlIlIl = lIIIIlIIlIIll[24];
    float llllllllllllllIlIllIIIlIIIIlIlII = llllllllllllllIlIllIIIlIIIIllIll.getHorseSize();
    if (llIIlIlIlIIIll(riddenByEntity))
    {
      "".length();
      if (-" ".length() <= 0) {
        break label235;
      }
    }
    label235:
    boolean llllllllllllllIlIllIIIlIIIIlIIll = lIIIIlIIlIIll[1];
    if (llIIlIlIlIIIIl(llllllllllllllIlIllIIIlIIIIlIlll))
    {
      horseFaceRopes.render(llllllllllllllIlIllIIIlIIIIIIllI);
      horseSaddleBottom.render(llllllllllllllIlIllIIIlIIIIIIllI);
      horseSaddleFront.render(llllllllllllllIlIllIIIlIIIIIIllI);
      horseSaddleBack.render(llllllllllllllIlIllIIIlIIIIIIllI);
      horseLeftSaddleRope.render(llllllllllllllIlIllIIIlIIIIIIllI);
      horseLeftSaddleMetal.render(llllllllllllllIlIllIIIlIIIIIIllI);
      horseRightSaddleRope.render(llllllllllllllIlIllIIIlIIIIIIllI);
      horseRightSaddleMetal.render(llllllllllllllIlIllIIIlIIIIIIllI);
      horseLeftFaceMetal.render(llllllllllllllIlIllIIIlIIIIIIllI);
      horseRightFaceMetal.render(llllllllllllllIlIllIIIlIIIIIIllI);
      if (llIIlIlIlIIIIl(llllllllllllllIlIllIIIlIIIIlIIll))
      {
        horseLeftRein.render(llllllllllllllIlIllIIIlIIIIIIllI);
        horseRightRein.render(llllllllllllllIlIllIIIlIIIIIIllI);
      }
    }
    if (llIIlIlIlIIlII(llllllllllllllIlIllIIIlIIIIllIII))
    {
      GlStateManager.pushMatrix();
      GlStateManager.scale(llllllllllllllIlIllIIIlIIIIlIlII, 0.5F + llllllllllllllIlIllIIIlIIIIlIlII * 0.5F, llllllllllllllIlIllIIIlIIIIlIlII);
      GlStateManager.translate(0.0F, 0.95F * (1.0F - llllllllllllllIlIllIIIlIIIIlIlII), 0.0F);
    }
    backLeftLeg.render(llllllllllllllIlIllIIIlIIIIIIllI);
    backLeftShin.render(llllllllllllllIlIllIIIlIIIIIIllI);
    backLeftHoof.render(llllllllllllllIlIllIIIlIIIIIIllI);
    backRightLeg.render(llllllllllllllIlIllIIIlIIIIIIllI);
    backRightShin.render(llllllllllllllIlIllIIIlIIIIIIllI);
    backRightHoof.render(llllllllllllllIlIllIIIlIIIIIIllI);
    frontLeftLeg.render(llllllllllllllIlIllIIIlIIIIIIllI);
    frontLeftShin.render(llllllllllllllIlIllIIIlIIIIIIllI);
    frontLeftHoof.render(llllllllllllllIlIllIIIlIIIIIIllI);
    frontRightLeg.render(llllllllllllllIlIllIIIlIIIIIIllI);
    frontRightShin.render(llllllllllllllIlIllIIIlIIIIIIllI);
    frontRightHoof.render(llllllllllllllIlIllIIIlIIIIIIllI);
    if (llIIlIlIlIIlII(llllllllllllllIlIllIIIlIIIIllIII))
    {
      GlStateManager.popMatrix();
      GlStateManager.pushMatrix();
      GlStateManager.scale(llllllllllllllIlIllIIIlIIIIlIlII, llllllllllllllIlIllIIIlIIIIlIlII, llllllllllllllIlIllIIIlIIIIlIlII);
      GlStateManager.translate(0.0F, 1.35F * (1.0F - llllllllllllllIlIllIIIlIIIIlIlII), 0.0F);
    }
    body.render(llllllllllllllIlIllIIIlIIIIIIllI);
    tailBase.render(llllllllllllllIlIllIIIlIIIIIIllI);
    tailMiddle.render(llllllllllllllIlIllIIIlIIIIIIllI);
    tailTip.render(llllllllllllllIlIllIIIlIIIIIIllI);
    neck.render(llllllllllllllIlIllIIIlIIIIIIllI);
    mane.render(llllllllllllllIlIllIIIlIIIIIIllI);
    if (llIIlIlIlIIlII(llllllllllllllIlIllIIIlIIIIllIII))
    {
      GlStateManager.popMatrix();
      GlStateManager.pushMatrix();
      float llllllllllllllIlIllIIIlIIIIlIIIl = 0.5F + llllllllllllllIlIllIIIlIIIIlIlII * llllllllllllllIlIllIIIlIIIIlIlII * 0.5F;
      GlStateManager.scale(llllllllllllllIlIllIIIlIIIIlIIIl, llllllllllllllIlIllIIIlIIIIlIIIl, llllllllllllllIlIllIIIlIIIIlIIIl);
      if (llIIlIlIlIIllI(llIIlIlIlIIIII(llllllllllllllIlIllIIIlIIIIllIIl, 0.0F)))
      {
        GlStateManager.translate(0.0F, 1.35F * (1.0F - llllllllllllllIlIllIIIlIIIIlIlII), 0.0F);
        "".length();
        if (-" ".length() <= 0) {}
      }
      else
      {
        GlStateManager.translate(0.0F, 0.9F * (1.0F - llllllllllllllIlIllIIIlIIIIlIlII) * llllllllllllllIlIllIIIlIIIIllIIl + 1.35F * (1.0F - llllllllllllllIlIllIIIlIIIIlIlII) * (1.0F - llllllllllllllIlIllIIIlIIIIllIIl), 0.15F * (1.0F - llllllllllllllIlIllIIIlIIIIlIlII) * llllllllllllllIlIllIIIlIIIIllIIl);
      }
    }
    if (llIIlIlIlIIIIl(llllllllllllllIlIllIIIlIIIIlIlIl))
    {
      muleLeftEar.render(llllllllllllllIlIllIIIlIIIIIIllI);
      muleRightEar.render(llllllllllllllIlIllIIIlIIIIIIllI);
      "".length();
      if ("   ".length() >= 0) {}
    }
    else
    {
      horseLeftEar.render(llllllllllllllIlIllIIIlIIIIIIllI);
      horseRightEar.render(llllllllllllllIlIllIIIlIIIIIIllI);
    }
    head.render(llllllllllllllIlIllIIIlIIIIIIllI);
    if (llIIlIlIlIIlII(llllllllllllllIlIllIIIlIIIIllIII)) {
      GlStateManager.popMatrix();
    }
    if (llIIlIlIlIIIIl(llllllllllllllIlIllIIIlIIIIlIllI))
    {
      muleLeftChest.render(llllllllllllllIlIllIIIlIIIIIIllI);
      muleRightChest.render(llllllllllllllIlIllIIIlIIIIIIllI);
    }
  }
  
  private static boolean llIIlIlIlIIllI(int ???)
  {
    float llllllllllllllIlIllIIIIIlllIIlll;
    return ??? <= 0;
  }
  
  private static boolean llIIlIlIlIIIll(Object ???)
  {
    byte llllllllllllllIlIllIIIIIllllIIIl;
    return ??? != null;
  }
  
  static {}
  
  private float updateHorseRotation(float llllllllllllllIlIllIIIIlllIIIlll, float llllllllllllllIlIllIIIIlllIIIlIl, float llllllllllllllIlIllIIIIllIllllII)
  {
    ;
    ;
    ;
    ;
    float llllllllllllllIlIllIIIIlllIIIIIl = llllllllllllllIlIllIIIIlllIIIlIl - llllllllllllllIlIllIIIIlllIIIlll;
    "".length();
    if ((0x8B ^ 0x83 ^ 0x26 ^ 0x2A) <= "   ".length()) {
      return 0.0F;
    }
    while (!llIIlIlIlIlllI(llIIlIlIlIlIIl(llllllllllllllIlIllIIIIlllIIIIIl, -180.0F))) {
      llllllllllllllIlIllIIIIlllIIIIIl += 360.0F;
    }
    "".length();
    if (("   ".length() ^ 0xA4 ^ 0xA3) != (0x91 ^ 0x9C ^ 0xB5 ^ 0xBC)) {
      return 0.0F;
    }
    while (!llIIlIlIllIIII(llIIlIlIlIlIlI(llllllllllllllIlIllIIIIlllIIIIIl, 180.0F))) {
      llllllllllllllIlIllIIIIlllIIIIIl -= 360.0F;
    }
    return llllllllllllllIlIllIIIIlllIIIlll + llllllllllllllIlIllIIIIllIllllII * llllllllllllllIlIllIIIIlllIIIIIl;
  }
  
  private static boolean llIIlIlIlIIIlI(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIlIllIIIIIllIlIIll;
    return ??? != i;
  }
  
  private static boolean llIIlIlIllIIII(int ???)
  {
    int llllllllllllllIlIllIIIIIlllIlIIl;
    return ??? < 0;
  }
  
  private static int llIIlIlIlIlIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void setLivingAnimations(EntityLivingBase llllllllllllllIlIllIIIIlIlIIllIl, float llllllllllllllIlIllIIIIlIIlIIIII, float llllllllllllllIlIllIIIIlIlIIlIll, float llllllllllllllIlIllIIIIlIlIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIllIIIIlIlIIlllI.setLivingAnimations(llllllllllllllIlIllIIIIlIlIIllIl, llllllllllllllIlIllIIIIlIlIIllII, llllllllllllllIlIllIIIIlIlIIlIll, llllllllllllllIlIllIIIIlIlIIlIlI);
    float llllllllllllllIlIllIIIIlIlIIlIIl = llllllllllllllIlIllIIIIlIlIIlllI.updateHorseRotation(prevRenderYawOffset, renderYawOffset, llllllllllllllIlIllIIIIlIlIIlIlI);
    float llllllllllllllIlIllIIIIlIlIIlIII = llllllllllllllIlIllIIIIlIlIIlllI.updateHorseRotation(prevRotationYawHead, rotationYawHead, llllllllllllllIlIllIIIIlIlIIlIlI);
    float llllllllllllllIlIllIIIIlIlIIIlll = prevRotationPitch + (rotationPitch - prevRotationPitch) * llllllllllllllIlIllIIIIlIlIIlIlI;
    float llllllllllllllIlIllIIIIlIlIIIllI = llllllllllllllIlIllIIIIlIlIIlIII - llllllllllllllIlIllIIIIlIlIIlIIl;
    float llllllllllllllIlIllIIIIlIlIIIlIl = llllllllllllllIlIllIIIIlIlIIIlll / 57.295776F;
    if (llIIlIlIllIlII(llIIlIlIllIIIl(llllllllllllllIlIllIIIIlIlIIIllI, 20.0F))) {
      llllllllllllllIlIllIIIIlIlIIIllI = 20.0F;
    }
    if (llIIlIlIllIIII(llIIlIlIllIIlI(llllllllllllllIlIllIIIIlIlIIIllI, -20.0F))) {
      llllllllllllllIlIllIIIIlIlIIIllI = -20.0F;
    }
    if (llIIlIlIllIlII(llIIlIlIllIIIl(llllllllllllllIlIllIIIIlIlIIlIll, 0.2F))) {
      llllllllllllllIlIllIIIIlIlIIIlIl += MathHelper.cos(llllllllllllllIlIllIIIIlIlIIllII * 0.4F) * 0.15F * llllllllllllllIlIllIIIIlIlIIlIll;
    }
    EntityHorse llllllllllllllIlIllIIIIlIlIIIIIl = (EntityHorse)llllllllllllllIlIllIIIIlIlIIllIl;
    float llllllllllllllIlIllIIIIlIIllllll = llllllllllllllIlIllIIIIlIlIIIIIl.getGrassEatingAmount(llllllllllllllIlIllIIIIlIlIIlIlI);
    float llllllllllllllIlIllIIIIlIIllllIl = llllllllllllllIlIllIIIIlIlIIIIIl.getRearingAmount(llllllllllllllIlIllIIIIlIlIIlIlI);
    float llllllllllllllIlIllIIIIlIIlllIll = 1.0F - llllllllllllllIlIllIIIIlIIllllIl;
    float llllllllllllllIlIllIIIIlIIlllIIl = llllllllllllllIlIllIIIIlIlIIIIIl.getMouthOpennessAngle(llllllllllllllIlIllIIIIlIlIIlIlI);
    if (llIIlIlIlIIIIl(field_110278_bp))
    {
      "".length();
      if (" ".length() < "   ".length()) {
        break label226;
      }
    }
    label226:
    boolean llllllllllllllIlIllIIIIlIIllIlll = lIIIIlIIlIIll[1];
    boolean llllllllllllllIlIllIIIIlIIllIllI = llllllllllllllIlIllIIIIlIlIIIIIl.isHorseSaddled();
    if (llIIlIlIlIIIll(riddenByEntity))
    {
      "".length();
      if (((0x41 ^ 0x7F) & (0x31 ^ 0xF ^ 0xFFFFFFFF)) == 0) {
        break label280;
      }
    }
    label280:
    boolean llllllllllllllIlIllIIIIlIIllIlII = lIIIIlIIlIIll[1];
    float llllllllllllllIlIllIIIIlIIllIIlI = ticksExisted + llllllllllllllIlIllIIIIlIlIIlIlI;
    float llllllllllllllIlIllIIIIlIIllIIIl = MathHelper.cos(llllllllllllllIlIllIIIIlIlIIllII * 0.6662F + 3.1415927F);
    float llllllllllllllIlIllIIIIlIIllIIII = llllllllllllllIlIllIIIIlIIllIIIl * 0.8F * llllllllllllllIlIllIIIIlIlIIlIll;
    head.rotationPointY = 4.0F;
    head.rotationPointZ = -10.0F;
    tailBase.rotationPointY = 3.0F;
    tailMiddle.rotationPointZ = 14.0F;
    muleRightChest.rotationPointY = 3.0F;
    muleRightChest.rotationPointZ = 10.0F;
    body.rotateAngleX = 0.0F;
    head.rotateAngleX = (0.5235988F + llllllllllllllIlIllIIIIlIlIIIlIl);
    head.rotateAngleY = (llllllllllllllIlIllIIIIlIlIIIllI / 57.295776F);
    head.rotateAngleX = (llllllllllllllIlIllIIIIlIIllllIl * (0.2617994F + llllllllllllllIlIllIIIIlIlIIIlIl) + llllllllllllllIlIllIIIIlIIllllll * 2.18166F + (1.0F - Math.max(llllllllllllllIlIllIIIIlIIllllIl, llllllllllllllIlIllIIIIlIIllllll)) * head.rotateAngleX);
    head.rotateAngleY = (llllllllllllllIlIllIIIIlIIllllIl * llllllllllllllIlIllIIIIlIlIIIllI / 57.295776F + (1.0F - Math.max(llllllllllllllIlIllIIIIlIIllllIl, llllllllllllllIlIllIIIIlIIllllll)) * head.rotateAngleY);
    head.rotationPointY = (llllllllllllllIlIllIIIIlIIllllIl * -6.0F + llllllllllllllIlIllIIIIlIIllllll * 11.0F + (1.0F - Math.max(llllllllllllllIlIllIIIIlIIllllIl, llllllllllllllIlIllIIIIlIIllllll)) * head.rotationPointY);
    head.rotationPointZ = (llllllllllllllIlIllIIIIlIIllllIl * -1.0F + llllllllllllllIlIllIIIIlIIllllll * -10.0F + (1.0F - Math.max(llllllllllllllIlIllIIIIlIIllllIl, llllllllllllllIlIllIIIIlIIllllll)) * head.rotationPointZ);
    tailBase.rotationPointY = (llllllllllllllIlIllIIIIlIIllllIl * 9.0F + llllllllllllllIlIllIIIIlIIlllIll * tailBase.rotationPointY);
    tailMiddle.rotationPointZ = (llllllllllllllIlIllIIIIlIIllllIl * 18.0F + llllllllllllllIlIllIIIIlIIlllIll * tailMiddle.rotationPointZ);
    muleRightChest.rotationPointY = (llllllllllllllIlIllIIIIlIIllllIl * 5.5F + llllllllllllllIlIllIIIIlIIlllIll * muleRightChest.rotationPointY);
    muleRightChest.rotationPointZ = (llllllllllllllIlIllIIIIlIIllllIl * 15.0F + llllllllllllllIlIllIIIIlIIlllIll * muleRightChest.rotationPointZ);
    body.rotateAngleX = (llllllllllllllIlIllIIIIlIIllllIl * -45.0F / 57.295776F + llllllllllllllIlIllIIIIlIIlllIll * body.rotateAngleX);
    horseLeftEar.rotationPointY = head.rotationPointY;
    horseRightEar.rotationPointY = head.rotationPointY;
    muleLeftEar.rotationPointY = head.rotationPointY;
    muleRightEar.rotationPointY = head.rotationPointY;
    neck.rotationPointY = head.rotationPointY;
    field_178711_b.rotationPointY = 0.02F;
    field_178712_c.rotationPointY = 0.0F;
    mane.rotationPointY = head.rotationPointY;
    horseLeftEar.rotationPointZ = head.rotationPointZ;
    horseRightEar.rotationPointZ = head.rotationPointZ;
    muleLeftEar.rotationPointZ = head.rotationPointZ;
    muleRightEar.rotationPointZ = head.rotationPointZ;
    neck.rotationPointZ = head.rotationPointZ;
    field_178711_b.rotationPointZ = (0.02F - llllllllllllllIlIllIIIIlIIlllIIl * 1.0F);
    field_178712_c.rotationPointZ = (0.0F + llllllllllllllIlIllIIIIlIIlllIIl * 1.0F);
    mane.rotationPointZ = head.rotationPointZ;
    horseLeftEar.rotateAngleX = head.rotateAngleX;
    horseRightEar.rotateAngleX = head.rotateAngleX;
    muleLeftEar.rotateAngleX = head.rotateAngleX;
    muleRightEar.rotateAngleX = head.rotateAngleX;
    neck.rotateAngleX = head.rotateAngleX;
    field_178711_b.rotateAngleX = (0.0F - 0.09424778F * llllllllllllllIlIllIIIIlIIlllIIl);
    field_178712_c.rotateAngleX = (0.0F + 0.15707964F * llllllllllllllIlIllIIIIlIIlllIIl);
    mane.rotateAngleX = head.rotateAngleX;
    horseLeftEar.rotateAngleY = head.rotateAngleY;
    horseRightEar.rotateAngleY = head.rotateAngleY;
    muleLeftEar.rotateAngleY = head.rotateAngleY;
    muleRightEar.rotateAngleY = head.rotateAngleY;
    neck.rotateAngleY = head.rotateAngleY;
    field_178711_b.rotateAngleY = 0.0F;
    field_178712_c.rotateAngleY = 0.0F;
    mane.rotateAngleY = head.rotateAngleY;
    muleLeftChest.rotateAngleX = (llllllllllllllIlIllIIIIlIIllIIII / 5.0F);
    muleRightChest.rotateAngleX = (-llllllllllllllIlIllIIIIlIIllIIII / 5.0F);
    float llllllllllllllIlIllIIIIlIIlIllll = 1.5707964F;
    float llllllllllllllIlIllIIIIlIIlIlllI = 4.712389F;
    float llllllllllllllIlIllIIIIlIIlIllIl = -1.0471976F;
    float llllllllllllllIlIllIIIIlIIlIllII = 0.2617994F * llllllllllllllIlIllIIIIlIIllllIl;
    float llllllllllllllIlIllIIIIlIIlIlIll = MathHelper.cos(llllllllllllllIlIllIIIIlIIllIIlI * 0.6F + 3.1415927F);
    frontLeftLeg.rotationPointY = (-2.0F * llllllllllllllIlIllIIIIlIIllllIl + 9.0F * llllllllllllllIlIllIIIIlIIlllIll);
    frontLeftLeg.rotationPointZ = (-2.0F * llllllllllllllIlIllIIIIlIIllllIl + -8.0F * llllllllllllllIlIllIIIIlIIlllIll);
    frontRightLeg.rotationPointY = frontLeftLeg.rotationPointY;
    frontRightLeg.rotationPointZ = frontLeftLeg.rotationPointZ;
    backLeftShin.rotationPointY = (backLeftLeg.rotationPointY + MathHelper.sin(1.5707964F + llllllllllllllIlIllIIIIlIIlIllII + llllllllllllllIlIllIIIIlIIlllIll * -llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll) * 7.0F);
    backLeftShin.rotationPointZ = (backLeftLeg.rotationPointZ + MathHelper.cos(4.712389F + llllllllllllllIlIllIIIIlIIlIllII + llllllllllllllIlIllIIIIlIIlllIll * -llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll) * 7.0F);
    backRightShin.rotationPointY = (backRightLeg.rotationPointY + MathHelper.sin(1.5707964F + llllllllllllllIlIllIIIIlIIlIllII + llllllllllllllIlIllIIIIlIIlllIll * llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll) * 7.0F);
    backRightShin.rotationPointZ = (backRightLeg.rotationPointZ + MathHelper.cos(4.712389F + llllllllllllllIlIllIIIIlIIlIllII + llllllllllllllIlIllIIIIlIIlllIll * llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll) * 7.0F);
    float llllllllllllllIlIllIIIIlIIlIlIlI = (-1.0471976F + llllllllllllllIlIllIIIIlIIlIlIll) * llllllllllllllIlIllIIIIlIIllllIl + llllllllllllllIlIllIIIIlIIllIIII * llllllllllllllIlIllIIIIlIIlllIll;
    float llllllllllllllIlIllIIIIlIIlIlIIl = (-1.0471976F + -llllllllllllllIlIllIIIIlIIlIlIll) * llllllllllllllIlIllIIIIlIIllllIl + -llllllllllllllIlIllIIIIlIIllIIII * llllllllllllllIlIllIIIIlIIlllIll;
    frontLeftShin.rotationPointY = (frontLeftLeg.rotationPointY + MathHelper.sin(1.5707964F + llllllllllllllIlIllIIIIlIIlIlIlI) * 7.0F);
    frontLeftShin.rotationPointZ = (frontLeftLeg.rotationPointZ + MathHelper.cos(4.712389F + llllllllllllllIlIllIIIIlIIlIlIlI) * 7.0F);
    frontRightShin.rotationPointY = (frontRightLeg.rotationPointY + MathHelper.sin(1.5707964F + llllllllllllllIlIllIIIIlIIlIlIIl) * 7.0F);
    frontRightShin.rotationPointZ = (frontRightLeg.rotationPointZ + MathHelper.cos(4.712389F + llllllllllllllIlIllIIIIlIIlIlIIl) * 7.0F);
    backLeftLeg.rotateAngleX = (llllllllllllllIlIllIIIIlIIlIllII + -llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll * llllllllllllllIlIllIIIIlIIlllIll);
    backLeftShin.rotateAngleX = (-0.08726646F * llllllllllllllIlIllIIIIlIIllllIl + (-llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll - Math.max(0.0F, llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll)) * llllllllllllllIlIllIIIIlIIlllIll);
    backLeftHoof.rotateAngleX = backLeftShin.rotateAngleX;
    backRightLeg.rotateAngleX = (llllllllllllllIlIllIIIIlIIlIllII + llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll * llllllllllllllIlIllIIIIlIIlllIll);
    backRightShin.rotateAngleX = (-0.08726646F * llllllllllllllIlIllIIIIlIIllllIl + (llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll - Math.max(0.0F, -llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll)) * llllllllllllllIlIllIIIIlIIlllIll);
    backRightHoof.rotateAngleX = backRightShin.rotateAngleX;
    frontLeftLeg.rotateAngleX = llllllllllllllIlIllIIIIlIIlIlIlI;
    frontLeftShin.rotateAngleX = ((frontLeftLeg.rotateAngleX + 3.1415927F * Math.max(0.0F, 0.2F + llllllllllllllIlIllIIIIlIIlIlIll * 0.2F)) * llllllllllllllIlIllIIIIlIIllllIl + (llllllllllllllIlIllIIIIlIIllIIII + Math.max(0.0F, llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll)) * llllllllllllllIlIllIIIIlIIlllIll);
    frontLeftHoof.rotateAngleX = frontLeftShin.rotateAngleX;
    frontRightLeg.rotateAngleX = llllllllllllllIlIllIIIIlIIlIlIIl;
    frontRightShin.rotateAngleX = ((frontRightLeg.rotateAngleX + 3.1415927F * Math.max(0.0F, 0.2F - llllllllllllllIlIllIIIIlIIlIlIll * 0.2F)) * llllllllllllllIlIllIIIIlIIllllIl + (-llllllllllllllIlIllIIIIlIIllIIII + Math.max(0.0F, -llllllllllllllIlIllIIIIlIIllIIIl * 0.5F * llllllllllllllIlIllIIIIlIlIIlIll)) * llllllllllllllIlIllIIIIlIIlllIll);
    frontRightHoof.rotateAngleX = frontRightShin.rotateAngleX;
    backLeftHoof.rotationPointY = backLeftShin.rotationPointY;
    backLeftHoof.rotationPointZ = backLeftShin.rotationPointZ;
    backRightHoof.rotationPointY = backRightShin.rotationPointY;
    backRightHoof.rotationPointZ = backRightShin.rotationPointZ;
    frontLeftHoof.rotationPointY = frontLeftShin.rotationPointY;
    frontLeftHoof.rotationPointZ = frontLeftShin.rotationPointZ;
    frontRightHoof.rotationPointY = frontRightShin.rotationPointY;
    frontRightHoof.rotationPointZ = frontRightShin.rotationPointZ;
    if (llIIlIlIlIIIIl(llllllllllllllIlIllIIIIlIIllIllI))
    {
      horseSaddleBottom.rotationPointY = (llllllllllllllIlIllIIIIlIIllllIl * 0.5F + llllllllllllllIlIllIIIIlIIlllIll * 2.0F);
      horseSaddleBottom.rotationPointZ = (llllllllllllllIlIllIIIIlIIllllIl * 11.0F + llllllllllllllIlIllIIIIlIIlllIll * 2.0F);
      horseSaddleFront.rotationPointY = horseSaddleBottom.rotationPointY;
      horseSaddleBack.rotationPointY = horseSaddleBottom.rotationPointY;
      horseLeftSaddleRope.rotationPointY = horseSaddleBottom.rotationPointY;
      horseRightSaddleRope.rotationPointY = horseSaddleBottom.rotationPointY;
      horseLeftSaddleMetal.rotationPointY = horseSaddleBottom.rotationPointY;
      horseRightSaddleMetal.rotationPointY = horseSaddleBottom.rotationPointY;
      muleLeftChest.rotationPointY = muleRightChest.rotationPointY;
      horseSaddleFront.rotationPointZ = horseSaddleBottom.rotationPointZ;
      horseSaddleBack.rotationPointZ = horseSaddleBottom.rotationPointZ;
      horseLeftSaddleRope.rotationPointZ = horseSaddleBottom.rotationPointZ;
      horseRightSaddleRope.rotationPointZ = horseSaddleBottom.rotationPointZ;
      horseLeftSaddleMetal.rotationPointZ = horseSaddleBottom.rotationPointZ;
      horseRightSaddleMetal.rotationPointZ = horseSaddleBottom.rotationPointZ;
      muleLeftChest.rotationPointZ = muleRightChest.rotationPointZ;
      horseSaddleBottom.rotateAngleX = body.rotateAngleX;
      horseSaddleFront.rotateAngleX = body.rotateAngleX;
      horseSaddleBack.rotateAngleX = body.rotateAngleX;
      horseLeftRein.rotationPointY = head.rotationPointY;
      horseRightRein.rotationPointY = head.rotationPointY;
      horseFaceRopes.rotationPointY = head.rotationPointY;
      horseLeftFaceMetal.rotationPointY = head.rotationPointY;
      horseRightFaceMetal.rotationPointY = head.rotationPointY;
      horseLeftRein.rotationPointZ = head.rotationPointZ;
      horseRightRein.rotationPointZ = head.rotationPointZ;
      horseFaceRopes.rotationPointZ = head.rotationPointZ;
      horseLeftFaceMetal.rotationPointZ = head.rotationPointZ;
      horseRightFaceMetal.rotationPointZ = head.rotationPointZ;
      horseLeftRein.rotateAngleX = llllllllllllllIlIllIIIIlIlIIIlIl;
      horseRightRein.rotateAngleX = llllllllllllllIlIllIIIIlIlIIIlIl;
      horseFaceRopes.rotateAngleX = head.rotateAngleX;
      horseLeftFaceMetal.rotateAngleX = head.rotateAngleX;
      horseRightFaceMetal.rotateAngleX = head.rotateAngleX;
      horseFaceRopes.rotateAngleY = head.rotateAngleY;
      horseLeftFaceMetal.rotateAngleY = head.rotateAngleY;
      horseLeftRein.rotateAngleY = head.rotateAngleY;
      horseRightFaceMetal.rotateAngleY = head.rotateAngleY;
      horseRightRein.rotateAngleY = head.rotateAngleY;
      if (llIIlIlIlIIIIl(llllllllllllllIlIllIIIIlIIllIlII))
      {
        horseLeftSaddleRope.rotateAngleX = -1.0471976F;
        horseLeftSaddleMetal.rotateAngleX = -1.0471976F;
        horseRightSaddleRope.rotateAngleX = -1.0471976F;
        horseRightSaddleMetal.rotateAngleX = -1.0471976F;
        horseLeftSaddleRope.rotateAngleZ = 0.0F;
        horseLeftSaddleMetal.rotateAngleZ = 0.0F;
        horseRightSaddleRope.rotateAngleZ = 0.0F;
        horseRightSaddleMetal.rotateAngleZ = 0.0F;
        "".length();
        if (" ".length() > 0) {}
      }
      else
      {
        horseLeftSaddleRope.rotateAngleX = (llllllllllllllIlIllIIIIlIIllIIII / 3.0F);
        horseLeftSaddleMetal.rotateAngleX = (llllllllllllllIlIllIIIIlIIllIIII / 3.0F);
        horseRightSaddleRope.rotateAngleX = (llllllllllllllIlIllIIIIlIIllIIII / 3.0F);
        horseRightSaddleMetal.rotateAngleX = (llllllllllllllIlIllIIIIlIIllIIII / 3.0F);
        horseLeftSaddleRope.rotateAngleZ = (llllllllllllllIlIllIIIIlIIllIIII / 5.0F);
        horseLeftSaddleMetal.rotateAngleZ = (llllllllllllllIlIllIIIIlIIllIIII / 5.0F);
        horseRightSaddleRope.rotateAngleZ = (-llllllllllllllIlIllIIIIlIIllIIII / 5.0F);
        horseRightSaddleMetal.rotateAngleZ = (-llllllllllllllIlIllIIIIlIIllIIII / 5.0F);
      }
    }
    llllllllllllllIlIllIIIIlIIlIllll = -1.3089F + llllllllllllllIlIllIIIIlIlIIlIll * 1.5F;
    if (llIIlIlIllIlII(llIIlIlIllIIIl(llllllllllllllIlIllIIIIlIIlIllll, 0.0F))) {
      llllllllllllllIlIllIIIIlIIlIllll = 0.0F;
    }
    if (llIIlIlIlIIIIl(llllllllllllllIlIllIIIIlIIllIlll))
    {
      tailBase.rotateAngleY = MathHelper.cos(llllllllllllllIlIllIIIIlIIllIIlI * 0.7F);
      llllllllllllllIlIllIIIIlIIlIllll = 0.0F;
      "".length();
      if ((0x49 ^ 0x4D) > "   ".length()) {}
    }
    else
    {
      tailBase.rotateAngleY = 0.0F;
    }
    tailMiddle.rotateAngleY = tailBase.rotateAngleY;
    tailTip.rotateAngleY = tailBase.rotateAngleY;
    tailMiddle.rotationPointY = tailBase.rotationPointY;
    tailTip.rotationPointY = tailBase.rotationPointY;
    tailMiddle.rotationPointZ = tailBase.rotationPointZ;
    tailTip.rotationPointZ = tailBase.rotationPointZ;
    tailBase.rotateAngleX = llllllllllllllIlIllIIIIlIIlIllll;
    tailMiddle.rotateAngleX = llllllllllllllIlIllIIIIlIIlIllll;
    tailTip.rotateAngleX = (-0.2618F + llllllllllllllIlIllIIIIlIIlIllll);
  }
}

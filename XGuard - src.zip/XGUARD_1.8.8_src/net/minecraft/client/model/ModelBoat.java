package net.minecraft.client.model;

import net.minecraft.entity.Entity;

public class ModelBoat
  extends ModelBase
{
  static {}
  
  public void render(Entity lllllllllllllllIlllllIIlllllIIII, float lllllllllllllllIlllllIIllllIllll, float lllllllllllllllIlllllIIllllIlllI, float lllllllllllllllIlllllIIllllIllIl, float lllllllllllllllIlllllIIllllIllII, float lllllllllllllllIlllllIIllllIlIll, float lllllllllllllllIlllllIIllllIIlll)
  {
    ;
    ;
    ;
    int lllllllllllllllIlllllIIllllIlIIl = lIIIIlIllIll[1];
    "".length();
    if ("   ".length() == 0) {
      return;
    }
    while (!llIIllIllIllI(lllllllllllllllIlllllIIllllIlIIl, lIIIIlIllIll[0]))
    {
      boatSides[lllllllllllllllIlllllIIllllIlIIl].render(lllllllllllllllIlllllIIllllIIlll);
      lllllllllllllllIlllllIIllllIlIIl++;
    }
  }
  
  public ModelBoat()
  {
    boatSides[lIIIIlIllIll[1]] = new ModelRenderer(lllllllllllllllIlllllIIllllllIIl, lIIIIlIllIll[1], lIIIIlIllIll[2]);
    boatSides[lIIIIlIllIll[3]] = new ModelRenderer(lllllllllllllllIlllllIIllllllIIl, lIIIIlIllIll[1], lIIIIlIllIll[1]);
    boatSides[lIIIIlIllIll[4]] = new ModelRenderer(lllllllllllllllIlllllIIllllllIIl, lIIIIlIllIll[1], lIIIIlIllIll[1]);
    boatSides[lIIIIlIllIll[5]] = new ModelRenderer(lllllllllllllllIlllllIIllllllIIl, lIIIIlIllIll[1], lIIIIlIllIll[1]);
    boatSides[lIIIIlIllIll[6]] = new ModelRenderer(lllllllllllllllIlllllIIllllllIIl, lIIIIlIllIll[1], lIIIIlIllIll[1]);
    int lllllllllllllllIlllllIIlllllllIl = lIIIIlIllIll[7];
    int lllllllllllllllIlllllIIlllllllII = lIIIIlIllIll[8];
    int lllllllllllllllIlllllIIllllllIll = lIIIIlIllIll[9];
    int lllllllllllllllIlllllIIllllllIlI = lIIIIlIllIll[6];
    boatSides[lIIIIlIllIll[1]].addBox(-lllllllllllllllIlllllIIlllllllIl / lIIIIlIllIll[4], -lllllllllllllllIlllllIIllllllIll / lIIIIlIllIll[4] + lIIIIlIllIll[4], -3.0F, lllllllllllllllIlllllIIlllllllIl, lllllllllllllllIlllllIIllllllIll - lIIIIlIllIll[6], lIIIIlIllIll[6], 0.0F);
    boatSides[lIIIIlIllIll[1]].setRotationPoint(0.0F, lllllllllllllllIlllllIIllllllIlI, 0.0F);
    boatSides[lIIIIlIllIll[3]].addBox(-lllllllllllllllIlllllIIlllllllIl / lIIIIlIllIll[4] + lIIIIlIllIll[4], -lllllllllllllllIlllllIIlllllllII - lIIIIlIllIll[3], -1.0F, lllllllllllllllIlllllIIlllllllIl - lIIIIlIllIll[6], lllllllllllllllIlllllIIlllllllII, lIIIIlIllIll[4], 0.0F);
    boatSides[lIIIIlIllIll[3]].setRotationPoint(-lllllllllllllllIlllllIIlllllllIl / lIIIIlIllIll[4] + lIIIIlIllIll[3], lllllllllllllllIlllllIIllllllIlI, 0.0F);
    boatSides[lIIIIlIllIll[4]].addBox(-lllllllllllllllIlllllIIlllllllIl / lIIIIlIllIll[4] + lIIIIlIllIll[4], -lllllllllllllllIlllllIIlllllllII - lIIIIlIllIll[3], -1.0F, lllllllllllllllIlllllIIlllllllIl - lIIIIlIllIll[6], lllllllllllllllIlllllIIlllllllII, lIIIIlIllIll[4], 0.0F);
    boatSides[lIIIIlIllIll[4]].setRotationPoint(lllllllllllllllIlllllIIlllllllIl / lIIIIlIllIll[4] - lIIIIlIllIll[3], lllllllllllllllIlllllIIllllllIlI, 0.0F);
    boatSides[lIIIIlIllIll[5]].addBox(-lllllllllllllllIlllllIIlllllllIl / lIIIIlIllIll[4] + lIIIIlIllIll[4], -lllllllllllllllIlllllIIlllllllII - lIIIIlIllIll[3], -1.0F, lllllllllllllllIlllllIIlllllllIl - lIIIIlIllIll[6], lllllllllllllllIlllllIIlllllllII, lIIIIlIllIll[4], 0.0F);
    boatSides[lIIIIlIllIll[5]].setRotationPoint(0.0F, lllllllllllllllIlllllIIllllllIlI, -lllllllllllllllIlllllIIllllllIll / lIIIIlIllIll[4] + lIIIIlIllIll[3]);
    boatSides[lIIIIlIllIll[6]].addBox(-lllllllllllllllIlllllIIlllllllIl / lIIIIlIllIll[4] + lIIIIlIllIll[4], -lllllllllllllllIlllllIIlllllllII - lIIIIlIllIll[3], -1.0F, lllllllllllllllIlllllIIlllllllIl - lIIIIlIllIll[6], lllllllllllllllIlllllIIlllllllII, lIIIIlIllIll[4], 0.0F);
    boatSides[lIIIIlIllIll[6]].setRotationPoint(0.0F, lllllllllllllllIlllllIIllllllIlI, lllllllllllllllIlllllIIllllllIll / lIIIIlIllIll[4] - lIIIIlIllIll[3]);
    boatSides[lIIIIlIllIll[1]].rotateAngleX = 1.5707964F;
    boatSides[lIIIIlIllIll[3]].rotateAngleY = 4.712389F;
    boatSides[lIIIIlIllIll[4]].rotateAngleY = 1.5707964F;
    boatSides[lIIIIlIllIll[5]].rotateAngleY = 3.1415927F;
  }
  
  private static void llIIllIllIlIl()
  {
    lIIIIlIllIll = new int[10];
    lIIIIlIllIll[0] = (0x72 ^ 0x77);
    lIIIIlIllIll[1] = ((0x75 ^ 0x64) & (0x17 ^ 0x6 ^ 0xFFFFFFFF));
    lIIIIlIllIll[2] = (0xCF ^ 0xC7);
    lIIIIlIllIll[3] = " ".length();
    lIIIIlIllIll[4] = "  ".length();
    lIIIIlIllIll[5] = "   ".length();
    lIIIIlIllIll[6] = (0x3C ^ 0x38);
    lIIIIlIllIll[7] = (0xB0 ^ 0xA8);
    lIIIIlIllIll[8] = (0x38 ^ 0x46 ^ 0x6C ^ 0x14);
    lIIIIlIllIll[9] = (0x67 ^ 0x41 ^ 0x6C ^ 0x5E);
  }
  
  private static boolean llIIllIllIllI(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllIlllllIIllllIIIlI;
    return ??? >= i;
  }
}

package net.minecraft.client.model;

import net.minecraft.entity.Entity;

public class ModelSkeletonHead
  extends ModelBase
{
  public void setRotationAngles(float llllllllllllllIllIIllllIlIlIIIll, float llllllllllllllIllIIllllIlIIllIlI, float llllllllllllllIllIIllllIlIIllIIl, float llllllllllllllIllIIllllIlIlIIIII, float llllllllllllllIllIIllllIlIIlIlll, float llllllllllllllIllIIllllIlIIlIllI, Entity llllllllllllllIllIIllllIlIIlIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIllllIlIlIIlII.setRotationAngles(llllllllllllllIllIIllllIlIlIIIll, llllllllllllllIllIIllllIlIIllIlI, llllllllllllllIllIIllllIlIIllIIl, llllllllllllllIllIIllllIlIlIIIII, llllllllllllllIllIIllllIlIIlIlll, llllllllllllllIllIIllllIlIIlIllI, llllllllllllllIllIIllllIlIIlIlIl);
    skeletonHead.rotateAngleY = (llllllllllllllIllIIllllIlIlIIIII / 57.295776F);
    skeletonHead.rotateAngleX = (llllllllllllllIllIIllllIlIIlIlll / 57.295776F);
  }
  
  static {}
  
  public ModelSkeletonHead()
  {
    llllllllllllllIllIIllllIllIlIlII.<init>(llllIllllIll[0], llllIllllIll[1], llllIllllIll[2], llllIllllIll[2]);
  }
  
  public ModelSkeletonHead(int llllllllllllllIllIIllllIllIIllIl, int llllllllllllllIllIIllllIllIIllII, int llllllllllllllIllIIllllIllIIlIll, int llllllllllllllIllIIllllIllIIlIlI)
  {
    textureWidth = llllllllllllllIllIIllllIllIIlIll;
    textureHeight = llllllllllllllIllIIllllIllIIlIlI;
    skeletonHead = new ModelRenderer(llllllllllllllIllIIllllIllIIlllI, llllllllllllllIllIIllllIllIIllIl, llllllllllllllIllIIllllIllIIIlll);
    skeletonHead.addBox(-4.0F, -8.0F, -4.0F, llllIllllIll[3], llllIllllIll[3], llllIllllIll[3], 0.0F);
    skeletonHead.setRotationPoint(0.0F, 0.0F, 0.0F);
  }
  
  public void render(Entity llllllllllllllIllIIllllIlIlllIll, float llllllllllllllIllIIllllIlIlllIlI, float llllllllllllllIllIIllllIlIllIIIl, float llllllllllllllIllIIllllIlIllIIII, float llllllllllllllIllIIllllIlIllIlll, float llllllllllllllIllIIllllIlIllIllI, float llllllllllllllIllIIllllIlIllIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIllllIlIllllII.setRotationAngles(llllllllllllllIllIIllllIlIlllIlI, llllllllllllllIllIIllllIlIllIIIl, llllllllllllllIllIIllllIlIllIIII, llllllllllllllIllIIllllIlIllIlll, llllllllllllllIllIIllllIlIllIllI, llllllllllllllIllIIllllIlIllIlIl, llllllllllllllIllIIllllIlIlllIll);
    skeletonHead.render(llllllllllllllIllIIllllIlIllIlIl);
  }
  
  private static void lIllllIIllIlIl()
  {
    llllIllllIll = new int[4];
    llllIllllIll[0] = ((0x4E ^ 0x50) & (0x67 ^ 0x79 ^ 0xFFFFFFFF));
    llllIllllIll[1] = (0x37 ^ 0x28 ^ 0xAE ^ 0x92);
    llllIllllIll[2] = (0x9E ^ 0xA5 ^ 0xED ^ 0x96);
    llllIllllIll[3] = (0xA4 ^ 0xAC);
  }
}

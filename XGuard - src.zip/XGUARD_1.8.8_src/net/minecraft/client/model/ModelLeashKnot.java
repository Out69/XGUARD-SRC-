package net.minecraft.client.model;

import net.minecraft.entity.Entity;

public class ModelLeashKnot
  extends ModelBase
{
  public ModelLeashKnot()
  {
    llllllllllllllIIllIlllIlllIllIlI.<init>(lIIllIIIIllII[0], lIIllIIIIllII[0], lIIllIIIIllII[1], lIIllIIIIllII[1]);
  }
  
  public void setRotationAngles(float llllllllllllllIIllIlllIllIlIIIIl, float llllllllllllllIIllIlllIllIlIIIII, float llllllllllllllIIllIlllIllIIlllll, float llllllllllllllIIllIlllIllIlIIllI, float llllllllllllllIIllIlllIllIlIIlIl, float llllllllllllllIIllIlllIllIIlllII, Entity llllllllllllllIIllIlllIllIlIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIlllIllIlIlIlI.setRotationAngles(llllllllllllllIIllIlllIllIlIIIIl, llllllllllllllIIllIlllIllIlIIIII, llllllllllllllIIllIlllIllIIlllll, llllllllllllllIIllIlllIllIlIIllI, llllllllllllllIIllIlllIllIlIIlIl, llllllllllllllIIllIlllIllIIlllII, llllllllllllllIIllIlllIllIlIIIll);
    field_110723_a.rotateAngleY = (llllllllllllllIIllIlllIllIlIIllI / 57.295776F);
    field_110723_a.rotateAngleX = (llllllllllllllIIllIlllIllIlIIlIl / 57.295776F);
  }
  
  public ModelLeashKnot(int llllllllllllllIIllIlllIlllIlIIll, int llllllllllllllIIllIlllIlllIlIIlI, int llllllllllllllIIllIlllIlllIlIIIl, int llllllllllllllIIllIlllIlllIlIIII)
  {
    textureWidth = llllllllllllllIIllIlllIlllIlIIIl;
    textureHeight = llllllllllllllIIllIlllIlllIlIIII;
    field_110723_a = new ModelRenderer(llllllllllllllIIllIlllIlllIIllll, llllllllllllllIIllIlllIlllIlIIll, llllllllllllllIIllIlllIlllIIllIl);
    field_110723_a.addBox(-3.0F, -6.0F, -3.0F, lIIllIIIIllII[2], lIIllIIIIllII[3], lIIllIIIIllII[2], 0.0F);
    field_110723_a.setRotationPoint(0.0F, 0.0F, 0.0F);
  }
  
  static {}
  
  public void render(Entity llllllllllllllIIllIlllIlllIIIIIl, float llllllllllllllIIllIlllIllIlllIII, float llllllllllllllIIllIlllIllIllllll, float llllllllllllllIIllIlllIllIllIllI, float llllllllllllllIIllIlllIllIllllIl, float llllllllllllllIIllIlllIllIllllII, float llllllllllllllIIllIlllIllIllIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIlllIllIlllIlI.setRotationAngles(llllllllllllllIIllIlllIllIlllIII, llllllllllllllIIllIlllIllIllllll, llllllllllllllIIllIlllIllIllIllI, llllllllllllllIIllIlllIllIllllIl, llllllllllllllIIllIlllIllIllllII, llllllllllllllIIllIlllIllIllIIll, llllllllllllllIIllIlllIlllIIIIIl);
    field_110723_a.render(llllllllllllllIIllIlllIllIllIIll);
  }
  
  private static void lllIlIIlllllIl()
  {
    lIIllIIIIllII = new int[4];
    lIIllIIIIllII[0] = ((0x2A ^ 0x19 ^ 0x22 ^ 0x6) & (0x83 ^ 0xB9 ^ 0x14 ^ 0x39 ^ -" ".length()));
    lIIllIIIIllII[1] = (32 + 15 - -54 + 65 ^ 20 + 3 - 9 + 120);
    lIIllIIIIllII[2] = (0x30 ^ 0x36);
    lIIllIIIIllII[3] = (0x36 ^ 0x45 ^ 0x4 ^ 0x7F);
  }
}

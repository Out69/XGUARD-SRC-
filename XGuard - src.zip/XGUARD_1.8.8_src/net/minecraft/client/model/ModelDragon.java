package net.minecraft.client.model;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityDragon;

public class ModelDragon
  extends ModelBase
{
  static
  {
    lIIIlIIIIlIlII();
    lIIIlIIIIlIIll();
  }
  
  private static void lIIIlIIIIlIIll()
  {
    lIlIllllllll = new String[lIllIIIIIIII[72]];
    lIlIllllllll[lIllIIIIIIII[1]] = lIIIlIIIIlIIII("GmwuLl3xuYQTWe/46K8BJA==", "fUJIi");
    lIlIllllllll[lIllIIIIIIII[2]] = lIIIlIIIIlIIIl("S/uemBBsHlcTnORv28R5Ng==", "WxzVG");
    lIlIllllllll[lIllIIIIIIII[5]] = lIIIlIIIIlIIlI("EywrNDsNNWsgJA0r", "dEESO");
    lIlIllllllll[lIllIIIIIIII[7]] = lIIIlIIIIlIIIl("lwrln2jrqip6T1i/2gZ5mg==", "OUCYn");
    lIlIllllllll[lIllIIIIIIII[8]] = lIIIlIIIIlIIlI("KC0vFD81JzpINDshIA==", "ZHNfY");
    lIlIllllllll[lIllIIIIIIII[10]] = lIIIlIIIIlIIlI("Ew8pNAEEDTwvHU8HKS8D", "ajHFm");
    lIlIllllllll[lIllIIIIIIII[12]] = lIIIlIIIIlIIII("Taj+E6KVyeXxpccB9FPOag==", "XLcvZ");
    lIlIllllllll[lIllIIIIIIII[14]] = lIIIlIIIIlIIlI("NCg/BHQhLj8G", "CAQcZ");
    lIlIllllllll[lIllIIIIIIII[15]] = lIIIlIIIIlIIIl("IttgXaHbb/5mjsQYy5CS6A==", "qHbfe");
    lIlIllllllll[lIllIIIIIIII[18]] = lIIIlIIIIlIIII("4zSpRCBy0us=", "qqxlE");
    lIlIllllllll[lIllIIIIIIII[20]] = lIIIlIIIIlIIlI("JxY+OREtATZ5CCANPw==", "AdQWe");
    lIlIllllllll[lIllIIIIIIII[22]] = lIIIlIIIIlIIII("oeCmo4ey9ozjgBOpZzdf0w==", "jmfzk");
    lIlIllllllll[lIllIIIIIIII[24]] = lIIIlIIIIlIIlI("EBQ3FAEQCTcOWxsHMRQ=", "vfXzu");
    lIlIllllllll[lIllIIIIIIII[25]] = lIIIlIIIIlIIII("N6ZOi3n5mz5m4TqUPWH6dg==", "BjKuh");
    lIlIllllllll[lIllIIIIIIII[27]] = lIIIlIIIIlIIII("V5zjzONJfTt+t75MswfV9tz7qy2g7ix+", "wxeTB");
    lIlIllllllll[lIllIIIIIIII[30]] = lIIIlIIIIlIIII("wTGdcHlr53LZ6aVzVfCM4g==", "eFclz");
    lIlIllllllll[lIllIIIIIIII[33]] = lIIIlIIIIlIIII("99nResKpILBTFuz3NTTY0A==", "NWfVU");
    lIlIllllllll[lIllIIIIIIII[34]] = lIIIlIIIIlIIlI("Ig0vAVo/Cy0GEQ==", "LhLjt");
    lIlIllllllll[lIllIIIIIIII[36]] = lIIIlIIIIlIIII("4WI5VfCfTHWem+l9iSFPvA==", "NDiMK");
    lIlIllllllll[lIllIIIIIIII[37]] = lIIIlIIIIlIIII("I8RTl4vmQ+c=", "wOsUV");
    lIlIllllllll[lIllIIIIIIII[38]] = lIIIlIIIIlIIlI("NxkeHBUuAB4=", "Binyg");
    lIlIllllllll[lIllIIIIIIII[39]] = lIIIlIIIIlIIlI("BCE0MxYZNCUy", "qQDVd");
    lIlIllllllll[lIllIIIIIIII[40]] = lIIIlIIIIlIIIl("WmcTd+DdMm4=", "qlghX");
    lIlIllllllll[lIllIIIIIIII[41]] = lIIIlIIIIlIIIl("iW6iZRkddIg=", "XhLvo");
    lIlIllllllll[lIllIIIIIIII[42]] = lIIIlIIIIlIIlI("ODcYIBc=", "KTyLr");
    lIlIllllllll[lIllIIIIIIII[43]] = lIIIlIIIIlIIlI("Iys3BwYkKA==", "MDDst");
    lIlIllllllll[lIllIIIIIIII[44]] = lIIIlIIIIlIIIl("uh8cr4/Bdp4=", "gIVMz");
    lIlIllllllll[lIllIIIIIIII[45]] = lIIIlIIIIlIIlI("GA0c", "rlkSa");
    lIlIllllllll[lIllIIIIIIII[46]] = lIIIlIIIIlIIlI("CDITBg==", "fWpmW");
    lIlIllllllll[lIllIIIIIIII[47]] = lIIIlIIIIlIIIl("SmrAjOgPc5c=", "MfrYy");
    lIlIllllllll[lIllIIIIIIII[13]] = lIIIlIIIIlIIlI("Hgw3JiQ=", "moVJA");
    lIlIllllllll[lIllIIIIIIII[48]] = lIIIlIIIIlIIIl("yQjHCNhRLTE=", "rTAec");
    lIlIllllllll[lIllIIIIIIII[49]] = lIIIlIIIIlIIIl("yBGYpbtPPaY=", "rQiyk");
    lIlIllllllll[lIllIIIIIIII[51]] = lIIIlIIIIlIIIl("3PuEASOjQYM=", "QSYgv");
    lIlIllllllll[lIllIIIIIIII[52]] = lIIIlIIIIlIIIl("1oce6BNKAdI=", "fMPSl");
    lIlIllllllll[lIllIIIIIIII[53]] = lIIIlIIIIlIIII("g0xyvPUzxJ0=", "dgkJk");
    lIlIllllllll[lIllIIIIIIII[54]] = lIIIlIIIIlIIII("ViqN/e87heQ=", "otzfJ");
    lIlIllllllll[lIllIIIIIIII[55]] = lIIIlIIIIlIIII("fosEUYPAKpU=", "iSwqZ");
    lIlIllllllll[lIllIIIIIIII[57]] = lIIIlIIIIlIIIl("1nHHMFxujjk=", "uEzId");
    lIlIllllllll[lIllIIIIIIII[58]] = lIIIlIIIIlIIlI("JyUgBCM5PA==", "PLNcW");
    lIlIllllllll[lIllIIIIIIII[59]] = lIIIlIIIIlIIlI("BSYoFA==", "gIFqp");
    lIlIllllllll[lIllIIIIIIII[60]] = lIIIlIIIIlIIIl("EEHW/vTfbF4=", "LncXf");
    lIlIllllllll[lIllIIIIIIII[61]] = lIIIlIIIIlIIII("WCBOLbEQ5iLX8Bi1hZEe6A==", "SriZP");
    lIlIllllllll[lIllIIIIIIII[62]] = lIIIlIIIIlIIIl("SRmkl7O6BqE=", "JsZfJ");
    lIlIllllllll[lIllIIIIIIII[17]] = lIIIlIIIIlIIIl("e/q24UVd7DozgxJG0FCgqg==", "WKuGu");
    lIlIllllllll[lIllIIIIIIII[63]] = lIIIlIIIIlIIlI("GjImOw==", "wSOUU");
    lIlIllllllll[lIllIIIIIIII[64]] = lIIIlIIIIlIIIl("3Bg0tDLJoYCUnMiMCTalCQ==", "CswBE");
    lIlIllllllll[lIllIIIIIIII[65]] = lIIIlIIIIlIIII("uyk4b1rwqH8=", "zisvn");
    lIlIllllllll[lIllIIIIIIII[35]] = lIIIlIIIIlIIlI("IS8OHx42LQ==", "SJomr");
    lIlIllllllll[lIllIIIIIIII[66]] = lIIIlIIIIlIIII("YPeh5nOcJGA=", "NTTPd");
    lIlIllllllll[lIllIIIIIIII[67]] = lIIIlIIIIlIIlI("FBYCMCMDFBcrPw==", "fscBO");
    lIlIllllllll[lIllIIIIIIII[68]] = lIIIlIIIIlIIII("dU3C4xVF7Jg=", "fmeGj");
    lIlIllllllll[lIllIIIIIIII[69]] = lIIIlIIIIlIIII("mjcx5SEXigU52NEEN+y1PQ==", "VVGIe");
    lIlIllllllll[lIllIIIIIIII[32]] = lIIIlIIIIlIIlI("AhkNPg==", "oxdPd");
  }
  
  private static String lIIIlIIIIlIIII(String lllllllllllllllIIlllIIlIIlIIIIll, String lllllllllllllllIIlllIIlIIlIIIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlllIIlIIlIIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlllIIlIIlIIIlII.getBytes(StandardCharsets.UTF_8)), lIllIIIIIIII[15]), "DES");
      Cipher lllllllllllllllIIlllIIlIIlIIIlll = Cipher.getInstance("DES");
      lllllllllllllllIIlllIIlIIlIIIlll.init(lIllIIIIIIII[5], lllllllllllllllIIlllIIlIIlIIlIII);
      return new String(lllllllllllllllIIlllIIlIIlIIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlllIIlIIlIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlllIIlIIlIIIllI)
    {
      lllllllllllllllIIlllIIlIIlIIIllI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIlIIIIllIll(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIIlllIIlIIIIlIIll;
    return ??? < i;
  }
  
  private float updateRotations(double lllllllllllllllIIlllIIlIIlIIllIl)
  {
    ;
    "".length();
    if (-"  ".length() >= 0) {
      return 0.0F;
    }
    while (!lIIIlIIIIllIIl(lIIIlIIIIlIlll(lllllllllllllllIIlllIIlIIlIIlllI, 180.0D))) {
      lllllllllllllllIIlllIIlIIlIIlllI -= 360.0D;
    }
    "".length();
    if (null != null) {
      return 0.0F;
    }
    while (!lIIIlIIIIllIlI(lIIIlIIIIllIII(lllllllllllllllIIlllIIlIIlIIlllI, -180.0D))) {
      lllllllllllllllIIlllIIlIIlIIlllI += 360.0D;
    }
    return (float)lllllllllllllllIIlllIIlIIlIIlllI;
  }
  
  public void render(Entity lllllllllllllllIIlllIIlIIllllIll, float lllllllllllllllIIlllIIlIIllllIlI, float lllllllllllllllIIlllIIlIIllllIIl, float lllllllllllllllIIlllIIlIIllllIII, float lllllllllllllllIIlllIIlIIlllIlll, float lllllllllllllllIIlllIIlIIlllIllI, float lllllllllllllllIIlllIIlIIlIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.pushMatrix();
    EntityDragon lllllllllllllllIIlllIIlIIlllIlII = (EntityDragon)lllllllllllllllIIlllIIlIIllllIll;
    float lllllllllllllllIIlllIIlIIlllIIll = prevAnimTime + (animTime - prevAnimTime) * partialTicks;
    jaw.rotateAngleX = ((float)(Math.sin(lllllllllllllllIIlllIIlIIlllIIll * 3.1415927F * 2.0F) + 1.0D) * 0.2F);
    float lllllllllllllllIIlllIIlIIlllIIlI = (float)(Math.sin(lllllllllllllllIIlllIIlIIlllIIll * 3.1415927F * 2.0F - 1.0F) + 1.0D);
    lllllllllllllllIIlllIIlIIlllIIlI = (lllllllllllllllIIlllIIlIIlllIIlI * lllllllllllllllIIlllIIlIIlllIIlI * 1.0F + lllllllllllllllIIlllIIlIIlllIIlI * 2.0F) * 0.05F;
    GlStateManager.translate(0.0F, lllllllllllllllIIlllIIlIIlllIIlI - 2.0F, -3.0F);
    GlStateManager.rotate(lllllllllllllllIIlllIIlIIlllIIlI * 2.0F, 1.0F, 0.0F, 0.0F);
    float lllllllllllllllIIlllIIlIIlllIIIl = -30.0F;
    float lllllllllllllllIIlllIIlIIlllIIII = 0.0F;
    float lllllllllllllllIIlllIIlIIllIllll = 1.5F;
    double[] lllllllllllllllIIlllIIlIIllIlllI = lllllllllllllllIIlllIIlIIlllIlII.getMovementOffsets(lIllIIIIIIII[12], partialTicks);
    float lllllllllllllllIIlllIIlIIllIllIl = lllllllllllllllIIlllIIlIIllIIIIl.updateRotations(lllllllllllllllIIlllIIlIIlllIlII.getMovementOffsets(lIllIIIIIIII[10], partialTicks)[lIllIIIIIIII[1]] - lllllllllllllllIIlllIIlIIlllIlII.getMovementOffsets(lIllIIIIIIII[20], partialTicks)[lIllIIIIIIII[1]]);
    float lllllllllllllllIIlllIIlIIllIllII = lllllllllllllllIIlllIIlIIllIIIIl.updateRotations(lllllllllllllllIIlllIIlIIlllIlII.getMovementOffsets(lIllIIIIIIII[10], partialTicks)[lIllIIIIIIII[1]] + lllllllllllllllIIlllIIlIIllIllIl / 2.0F);
    lllllllllllllllIIlllIIlIIlllIIIl += 2.0F;
    float lllllllllllllllIIlllIIlIIllIlIll = lllllllllllllllIIlllIIlIIlllIIll * 3.1415927F * 2.0F;
    lllllllllllllllIIlllIIlIIlllIIIl = 20.0F;
    float lllllllllllllllIIlllIIlIIllIlIlI = -12.0F;
    int lllllllllllllllIIlllIIlIIllIlIIl = lIllIIIIIIII[1];
    "".length();
    if (((" ".length() ^ 0x5C ^ 0x12) & ('Ú' + 124 - 185 + 72 ^ 119 + '©' - 210 + 92 ^ -" ".length())) <= -" ".length()) {
      return;
    }
    while (!lIIIlIIIIlIlIl(lllllllllllllllIIlllIIlIIllIlIIl, lIllIIIIIIII[10]))
    {
      double[] lllllllllllllllIIlllIIlIIllIlIII = lllllllllllllllIIlllIIlIIlllIlII.getMovementOffsets(lIllIIIIIIII[10] - lllllllllllllllIIlllIIlIIllIlIIl, partialTicks);
      float lllllllllllllllIIlllIIlIIllIIlll = (float)Math.cos(lllllllllllllllIIlllIIlIIllIlIIl * 0.45F + lllllllllllllllIIlllIIlIIllIlIll) * 0.15F;
      spine.rotateAngleY = (lllllllllllllllIIlllIIlIIllIIIIl.updateRotations(lllllllllllllllIIlllIIlIIllIlIII[lIllIIIIIIII[1]] - lllllllllllllllIIlllIIlIIllIlllI[lIllIIIIIIII[1]]) * 3.1415927F / 180.0F * lllllllllllllllIIlllIIlIIllIllll);
      spine.rotateAngleX = (lllllllllllllllIIlllIIlIIllIIlll + (float)(lllllllllllllllIIlllIIlIIllIlIII[lIllIIIIIIII[2]] - lllllllllllllllIIlllIIlIIllIlllI[lIllIIIIIIII[2]]) * 3.1415927F / 180.0F * lllllllllllllllIIlllIIlIIllIllll * 5.0F);
      spine.rotateAngleZ = (-lllllllllllllllIIlllIIlIIllIIIIl.updateRotations(lllllllllllllllIIlllIIlIIllIlIII[lIllIIIIIIII[1]] - lllllllllllllllIIlllIIlIIllIllII) * 3.1415927F / 180.0F * lllllllllllllllIIlllIIlIIllIllll);
      spine.rotationPointY = lllllllllllllllIIlllIIlIIlllIIIl;
      spine.rotationPointZ = lllllllllllllllIIlllIIlIIllIlIlI;
      spine.rotationPointX = lllllllllllllllIIlllIIlIIlllIIII;
      lllllllllllllllIIlllIIlIIlllIIIl = (float)(lllllllllllllllIIlllIIlIIlllIIIl + Math.sin(spine.rotateAngleX) * 10.0D);
      lllllllllllllllIIlllIIlIIllIlIlI = (float)(lllllllllllllllIIlllIIlIIllIlIlI - Math.cos(spine.rotateAngleY) * Math.cos(spine.rotateAngleX) * 10.0D);
      lllllllllllllllIIlllIIlIIlllIIII = (float)(lllllllllllllllIIlllIIlIIlllIIII - Math.sin(spine.rotateAngleY) * Math.cos(spine.rotateAngleX) * 10.0D);
      spine.render(lllllllllllllllIIlllIIlIIlIlllll);
      lllllllllllllllIIlllIIlIIllIlIIl++;
    }
    head.rotationPointY = lllllllllllllllIIlllIIlIIlllIIIl;
    head.rotationPointZ = lllllllllllllllIIlllIIlIIllIlIlI;
    head.rotationPointX = lllllllllllllllIIlllIIlIIlllIIII;
    double[] lllllllllllllllIIlllIIlIIllIIllI = lllllllllllllllIIlllIIlIIlllIlII.getMovementOffsets(lIllIIIIIIII[1], partialTicks);
    head.rotateAngleY = (lllllllllllllllIIlllIIlIIllIIIIl.updateRotations(lllllllllllllllIIlllIIlIIllIIllI[lIllIIIIIIII[1]] - lllllllllllllllIIlllIIlIIllIlllI[lIllIIIIIIII[1]]) * 3.1415927F / 180.0F * 1.0F);
    head.rotateAngleZ = (-lllllllllllllllIIlllIIlIIllIIIIl.updateRotations(lllllllllllllllIIlllIIlIIllIIllI[lIllIIIIIIII[1]] - lllllllllllllllIIlllIIlIIllIllII) * 3.1415927F / 180.0F * 1.0F);
    head.render(lllllllllllllllIIlllIIlIIlIlllll);
    GlStateManager.pushMatrix();
    GlStateManager.translate(0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-lllllllllllllllIIlllIIlIIllIllIl * lllllllllllllllIIlllIIlIIllIllll * 1.0F, 0.0F, 0.0F, 1.0F);
    GlStateManager.translate(0.0F, -1.0F, 0.0F);
    body.rotateAngleZ = 0.0F;
    body.render(lllllllllllllllIIlllIIlIIlIlllll);
    int lllllllllllllllIIlllIIlIIllIIlIl = lIllIIIIIIII[1];
    "".length();
    if (-(0x11 ^ 0x15) >= 0) {
      return;
    }
    while (!lIIIlIIIIlIlIl(lllllllllllllllIIlllIIlIIllIIlIl, lIllIIIIIIII[5]))
    {
      GlStateManager.enableCull();
      float lllllllllllllllIIlllIIlIIllIIlII = lllllllllllllllIIlllIIlIIlllIIll * 3.1415927F * 2.0F;
      wing.rotateAngleX = (0.125F - (float)Math.cos(lllllllllllllllIIlllIIlIIllIIlII) * 0.2F);
      wing.rotateAngleY = 0.25F;
      wing.rotateAngleZ = ((float)(Math.sin(lllllllllllllllIIlllIIlIIllIIlII) + 0.125D) * 0.8F);
      wingTip.rotateAngleZ = (-(float)(Math.sin(lllllllllllllllIIlllIIlIIllIIlII + 2.0F) + 0.5D) * 0.75F);
      rearLeg.rotateAngleX = (1.0F + lllllllllllllllIIlllIIlIIlllIIlI * 0.1F);
      rearLegTip.rotateAngleX = (0.5F + lllllllllllllllIIlllIIlIIlllIIlI * 0.1F);
      rearFoot.rotateAngleX = (0.75F + lllllllllllllllIIlllIIlIIlllIIlI * 0.1F);
      frontLeg.rotateAngleX = (1.3F + lllllllllllllllIIlllIIlIIlllIIlI * 0.1F);
      frontLegTip.rotateAngleX = (-0.5F - lllllllllllllllIIlllIIlIIlllIIlI * 0.1F);
      frontFoot.rotateAngleX = (0.75F + lllllllllllllllIIlllIIlIIlllIIlI * 0.1F);
      wing.render(lllllllllllllllIIlllIIlIIlIlllll);
      frontLeg.render(lllllllllllllllIIlllIIlIIlIlllll);
      rearLeg.render(lllllllllllllllIIlllIIlIIlIlllll);
      GlStateManager.scale(-1.0F, 1.0F, 1.0F);
      if (lIIIlIIIIlIllI(lllllllllllllllIIlllIIlIIllIIlIl)) {
        GlStateManager.cullFace(lIllIIIIIIII[70]);
      }
      lllllllllllllllIIlllIIlIIllIIlIl++;
    }
    GlStateManager.popMatrix();
    GlStateManager.cullFace(lIllIIIIIIII[71]);
    GlStateManager.disableCull();
    float lllllllllllllllIIlllIIlIIllIIIll = -(float)Math.sin(lllllllllllllllIIlllIIlIIlllIIll * 3.1415927F * 2.0F) * 0.0F;
    lllllllllllllllIIlllIIlIIllIlIll = lllllllllllllllIIlllIIlIIlllIIll * 3.1415927F * 2.0F;
    lllllllllllllllIIlllIIlIIlllIIIl = 10.0F;
    lllllllllllllllIIlllIIlIIllIlIlI = 60.0F;
    lllllllllllllllIIlllIIlIIlllIIII = 0.0F;
    lllllllllllllllIIlllIIlIIllIlllI = lllllllllllllllIIlllIIlIIlllIlII.getMovementOffsets(lIllIIIIIIII[22], partialTicks);
    int lllllllllllllllIIlllIIlIIllIIIlI = lIllIIIIIIII[1];
    "".length();
    if (((0x12 ^ 0x2E) & (0x4E ^ 0x72 ^ 0xFFFFFFFF)) >= (0x16 ^ 0x12)) {
      return;
    }
    while (!lIIIlIIIIlIlIl(lllllllllllllllIIlllIIlIIllIIIlI, lIllIIIIIIII[24]))
    {
      lllllllllllllllIIlllIIlIIllIIllI = lllllllllllllllIIlllIIlIIlllIlII.getMovementOffsets(lIllIIIIIIII[24] + lllllllllllllllIIlllIIlIIllIIIlI, partialTicks);
      lllllllllllllllIIlllIIlIIllIIIll = (float)(lllllllllllllllIIlllIIlIIllIIIll + Math.sin(lllllllllllllllIIlllIIlIIllIIIlI * 0.45F + lllllllllllllllIIlllIIlIIllIlIll) * 0.05000000074505806D);
      spine.rotateAngleY = ((lllllllllllllllIIlllIIlIIllIIIIl.updateRotations(lllllllllllllllIIlllIIlIIllIIllI[lIllIIIIIIII[1]] - lllllllllllllllIIlllIIlIIllIlllI[lIllIIIIIIII[1]]) * lllllllllllllllIIlllIIlIIllIllll + 180.0F) * 3.1415927F / 180.0F);
      spine.rotateAngleX = (lllllllllllllllIIlllIIlIIllIIIll + (float)(lllllllllllllllIIlllIIlIIllIIllI[lIllIIIIIIII[2]] - lllllllllllllllIIlllIIlIIllIlllI[lIllIIIIIIII[2]]) * 3.1415927F / 180.0F * lllllllllllllllIIlllIIlIIllIllll * 5.0F);
      spine.rotateAngleZ = (lllllllllllllllIIlllIIlIIllIIIIl.updateRotations(lllllllllllllllIIlllIIlIIllIIllI[lIllIIIIIIII[1]] - lllllllllllllllIIlllIIlIIllIllII) * 3.1415927F / 180.0F * lllllllllllllllIIlllIIlIIllIllll);
      spine.rotationPointY = lllllllllllllllIIlllIIlIIlllIIIl;
      spine.rotationPointZ = lllllllllllllllIIlllIIlIIllIlIlI;
      spine.rotationPointX = lllllllllllllllIIlllIIlIIlllIIII;
      lllllllllllllllIIlllIIlIIlllIIIl = (float)(lllllllllllllllIIlllIIlIIlllIIIl + Math.sin(spine.rotateAngleX) * 10.0D);
      lllllllllllllllIIlllIIlIIllIlIlI = (float)(lllllllllllllllIIlllIIlIIllIlIlI - Math.cos(spine.rotateAngleY) * Math.cos(spine.rotateAngleX) * 10.0D);
      lllllllllllllllIIlllIIlIIlllIIII = (float)(lllllllllllllllIIlllIIlIIlllIIII - Math.sin(spine.rotateAngleY) * Math.cos(spine.rotateAngleX) * 10.0D);
      spine.render(lllllllllllllllIIlllIIlIIlIlllll);
      lllllllllllllllIIlllIIlIIllIIIlI++;
    }
    GlStateManager.popMatrix();
  }
  
  private static boolean lIIIlIIIIlIlIl(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIIlllIIlIIIIlIlll;
    return ??? >= i;
  }
  
  private static int lIIIlIIIIllIII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static void lIIIlIIIIlIlII()
  {
    lIllIIIIIIII = new int[73];
    lIllIIIIIIII[0] = (-(0xD1FD & 0x3ED3) & 0xB5D8 & 0x5BF7);
    lIllIIIIIIII[1] = ((0x8F ^ 0xBF) & (0x8E ^ 0xBE ^ 0xFFFFFFFF));
    lIllIIIIIIII[2] = " ".length();
    lIllIIIIIIII[3] = (-(0x5F ^ 0x67));
    lIllIIIIIIII[4] = (0x38 ^ 0x60);
    lIllIIIIIIII[5] = "  ".length();
    lIllIIIIIIII[6] = (31 + 56 - 57 + 114);
    lIllIIIIIIII[7] = "   ".length();
    lIllIIIIIIII[8] = (0x99 ^ 0x9D);
    lIllIIIIIIII[9] = (0xDF ^ 0xAF);
    lIllIIIIIIII[10] = (60 + 72 - 107 + 164 ^ 100 + 78 - 76 + 82);
    lIllIIIIIIII[11] = ((0x25 ^ 0x52) + (0x28 ^ 0x70) - (0x18 ^ 0x43) + (0x52 ^ 0x2));
    lIllIIIIIIII[12] = (0xC2 ^ 0xC4);
    lIllIIIIIIII[13] = (0x2F ^ 0x31);
    lIllIIIIIIII[14] = (0x9B ^ 0x9C);
    lIllIIIIIIII[15] = (0x95 ^ 0x8D ^ 0x47 ^ 0x57);
    lIllIIIIIIII[16] = ((0x73 ^ 0x6F) + (0x1D ^ 0x69) - -"   ".length() + (0xDC ^ 0xC1));
    lIllIIIIIIII[17] = (0xDA ^ 0xA6 ^ 0xDB ^ 0x8B);
    lIllIIIIIIII[18] = (0x15 ^ 0x69 ^ 0xFA ^ 0x8F);
    lIllIIIIIIII[19] = (3 + 'À' - 94 + 154 ^ 26 + '' - 65 + 91);
    lIllIIIIIIII[20] = (0xC6 ^ 0x95 ^ 0xD3 ^ 0x8A);
    lIllIIIIIIII[21] = (0xDA ^ 0xB2);
    lIllIIIIIIII[22] = (0x3F ^ 0x34);
    lIllIIIIIIII[23] = ((0xC1 ^ 0xAA) + (0x4A ^ 0x6D) - (0xCE ^ 0x8B) + (0x44 ^ 0x7F));
    lIllIIIIIIII[24] = (0x3A ^ 0x36);
    lIllIIIIIIII[25] = (0x6C ^ 0x56 ^ 0x32 ^ 0x5);
    lIllIIIIIIII[26] = (19 + 18 - -43 + 112);
    lIllIIIIIIII[27] = (0x76 ^ 0x7B ^ "   ".length());
    lIllIIIIIIII[28] = ('È' + '´' - 294 + 140);
    lIllIIIIIIII[29] = ((0x6E ^ 0x27) + (0x67 ^ 0xA) - (0xD4 ^ 0xB1) + (0xBC ^ 0x85));
    lIllIIIIIIII[30] = (69 + 60 - 32 + 43 ^ 8 + 9 - -10 + 104);
    lIllIIIIIIII[31] = ((0x5B ^ 0x62) + (0x13 ^ 0x0) - -(0x4A ^ 0x6) + (0x2B ^ 0x6F));
    lIllIIIIIIII[32] = (0x5F ^ 0x6A);
    lIllIIIIIIII[33] = (0xBB ^ 0xAB);
    lIllIIIIIIII[34] = (0x5C ^ 0x67 ^ 0x4E ^ 0x64);
    lIllIIIIIIII[35] = (0x5F ^ 0x6F);
    lIllIIIIIIII[36] = (0x90 ^ 0xB3 ^ 0x7D ^ 0x4C);
    lIllIIIIIIII[37] = (0x35 ^ 0x73 ^ 0x37 ^ 0x62);
    lIllIIIIIIII[38] = (0xAF ^ 0xBB);
    lIllIIIIIIII[39] = (0x6A ^ 0x47 ^ 0x42 ^ 0x7A);
    lIllIIIIIIII[40] = (0x41 ^ 0x79 ^ 0x76 ^ 0x58);
    lIllIIIIIIII[41] = (0xD0 ^ 0xC7);
    lIllIIIIIIII[42] = (0xA0 ^ 0x93 ^ 0xE ^ 0x25);
    lIllIIIIIIII[43] = (0x1B ^ 0x2);
    lIllIIIIIIII[44] = (0x29 ^ 0x75 ^ 0x3D ^ 0x7B);
    lIllIIIIIIII[45] = (0x7E ^ 0x31 ^ 0xC2 ^ 0x96);
    lIllIIIIIIII[46] = (0x96 ^ 0x8A);
    lIllIIIIIIII[47] = (0x9B ^ 0x90 ^ 0x24 ^ 0x32);
    lIllIIIIIIII[48] = (0x51 ^ 0x39 ^ 0xDC ^ 0xAB);
    lIllIIIIIIII[49] = (0xA ^ 0x2A);
    lIllIIIIIIII[50] = (0x0 ^ 0x40);
    lIllIIIIIIII[51] = (0xF ^ 0x2E);
    lIllIIIIIIII[52] = (0x3D ^ 0x73 ^ 0x2D ^ 0x41);
    lIllIIIIIIII[53] = (65 + 29 - 63 + 195 ^ '' + 16 - 85 + 130);
    lIllIIIIIIII[54] = (0xBF ^ 0x9B);
    lIllIIIIIIII[55] = (0x23 ^ 0x10 ^ 0xB1 ^ 0xA7);
    lIllIIIIIIII[56] = (0x48 ^ 0x33 ^ 0xE6 ^ 0xA5);
    lIllIIIIIIII[57] = (0xEF ^ 0xA1 ^ 0xC6 ^ 0xAE);
    lIllIIIIIIII[58] = (62 + 124 - 124 + 73 ^ 50 + 99 - 55 + 66);
    lIllIIIIIIII[59] = (0x10 ^ 0x46 ^ 0xCA ^ 0xB4);
    lIllIIIIIIII[60] = (0x75 ^ 0x12 ^ 0x5B ^ 0x15);
    lIllIIIIIIII[61] = (0xED ^ 0xC7);
    lIllIIIIIIII[62] = (0xF ^ 0x4E ^ 0x1D ^ 0x77);
    lIllIIIIIIII[63] = (0x42 ^ 0x6F);
    lIllIIIIIIII[64] = (0x6 ^ 0x20 ^ 0xB7 ^ 0xBF);
    lIllIIIIIIII[65] = (0xFC ^ 0x99 ^ 0x1C ^ 0x56);
    lIllIIIIIIII[66] = (0x16 ^ 0x27);
    lIllIIIIIIII[67] = (0x64 ^ 0x56);
    lIllIIIIIIII[68] = (58 + 45 - 14 + 58 ^ 93 + 67 - 144 + 144);
    lIllIIIIIIII[69] = (0x96 ^ 0xA2);
    lIllIIIIIIII[70] = (0x8EE7 & 0x751C);
    lIllIIIIIIII[71] = (-(0xE3B5 & 0x7F7B) & 0xE7FD & 0x7F37);
    lIllIIIIIIII[72] = (0x45 ^ 0x73);
  }
  
  private static String lIIIlIIIIlIIlI(String lllllllllllllllIIlllIIlIIIllIIII, String lllllllllllllllIIlllIIlIIIllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlllIIlIIIllIIII = new String(Base64.getDecoder().decode(lllllllllllllllIIlllIIlIIIllIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlllIIlIIIllIIll = new StringBuilder();
    char[] lllllllllllllllIIlllIIlIIIllIIlI = lllllllllllllllIIlllIIlIIIllIlII.toCharArray();
    int lllllllllllllllIIlllIIlIIIllIIIl = lIllIIIIIIII[1];
    boolean lllllllllllllllIIlllIIlIIIlIlIll = lllllllllllllllIIlllIIlIIIllIIII.toCharArray();
    boolean lllllllllllllllIIlllIIlIIIlIlIlI = lllllllllllllllIIlllIIlIIIlIlIll.length;
    float lllllllllllllllIIlllIIlIIIlIlIIl = lIllIIIIIIII[1];
    while (lIIIlIIIIllIll(lllllllllllllllIIlllIIlIIIlIlIIl, lllllllllllllllIIlllIIlIIIlIlIlI))
    {
      char lllllllllllllllIIlllIIlIIIllIllI = lllllllllllllllIIlllIIlIIIlIlIll[lllllllllllllllIIlllIIlIIIlIlIIl];
      "".length();
      "".length();
      if (-" ".length() != -" ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlllIIlIIIllIIll);
  }
  
  private static String lIIIlIIIIlIIIl(String lllllllllllllllIIlllIIlIIIIllllI, String lllllllllllllllIIlllIIlIIIIlllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlllIIlIIIlIIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlllIIlIIIIlllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIlllIIlIIIlIIIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIIlllIIlIIIlIIIlI.init(lIllIIIIIIII[5], lllllllllllllllIIlllIIlIIIlIIIll);
      return new String(lllllllllllllllIIlllIIlIIIlIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlllIIlIIIIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlllIIlIIIlIIIIl)
    {
      lllllllllllllllIIlllIIlIIIlIIIIl.printStackTrace();
    }
    return null;
  }
  
  public ModelDragon(float lllllllllllllllIIlllIIlIlIIllIlI)
  {
    textureWidth = lIllIIIIIIII[0];
    textureHeight = lIllIIIIIIII[0];
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[1]], lIllIIIIIIII[1], lIllIIIIIIII[1]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[2]], lIllIIIIIIII[3], lIllIIIIIIII[4]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[5]], lIllIIIIIIII[3], lIllIIIIIIII[6]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[7]], lIllIIIIIIII[1], lIllIIIIIIII[1]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[8]], lIllIIIIIIII[9], lIllIIIIIIII[1]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[10]], lIllIIIIIIII[11], lIllIIIIIIII[1]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[12]], lIllIIIIIIII[9], lIllIIIIIIII[13]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[14]], lIllIIIIIIII[9], lIllIIIIIIII[4]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[15]], lIllIIIIIIII[16], lIllIIIIIIII[17]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[18]], lIllIIIIIIII[16], lIllIIIIIIII[19]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[20]], lIllIIIIIIII[9], lIllIIIIIIII[21]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[22]], lIllIIIIIIII[9], lIllIIIIIIII[23]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[24]], lIllIIIIIIII[6], lIllIIIIIIII[21]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[25]], lIllIIIIIIII[26], lIllIIIIIIII[21]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[27]], lIllIIIIIIII[28], lIllIIIIIIII[29]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[30]], lIllIIIIIIII[31], lIllIIIIIIII[32]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[33]], lIllIIIIIIII[1], lIllIIIIIIII[1]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[34]], lIllIIIIIIII[35], lIllIIIIIIII[1]);
    lllllllllllllllIIlllIIlIlIIllIll.setTextureOffset(lIlIllllllll[lIllIIIIIIII[36]], lIllIIIIIIII[9], lIllIIIIIIII[1]);
    float lllllllllllllllIIlllIIlIlIIllIIl = -16.0F;
    head = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[37]]);
    "".length();
    "".length();
    head.mirror = lIllIIIIIIII[2];
    "".length();
    "".length();
    head.mirror = lIllIIIIIIII[1];
    "".length();
    "".length();
    jaw = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[44]]);
    jaw.setRotationPoint(0.0F, 4.0F, 8.0F + lllllllllllllllIIlllIIlIlIIllIIl);
    "".length();
    head.addChild(jaw);
    spine = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[46]]);
    "".length();
    "".length();
    body = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[48]]);
    body.setRotationPoint(0.0F, 4.0F, 8.0F);
    "".length();
    "".length();
    "".length();
    "".length();
    wing = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[54]]);
    wing.setRotationPoint(-12.0F, 5.0F, 2.0F);
    "".length();
    "".length();
    wingTip = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[58]]);
    wingTip.setRotationPoint(-56.0F, 0.0F, 0.0F);
    "".length();
    "".length();
    wing.addChild(wingTip);
    frontLeg = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[61]]);
    frontLeg.setRotationPoint(-12.0F, 20.0F, 2.0F);
    "".length();
    frontLegTip = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[17]]);
    frontLegTip.setRotationPoint(0.0F, 20.0F, -1.0F);
    "".length();
    frontLeg.addChild(frontLegTip);
    frontFoot = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[64]]);
    frontFoot.setRotationPoint(0.0F, 23.0F, 0.0F);
    "".length();
    frontLegTip.addChild(frontFoot);
    rearLeg = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[35]]);
    rearLeg.setRotationPoint(-16.0F, 16.0F, 42.0F);
    "".length();
    rearLegTip = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[67]]);
    rearLegTip.setRotationPoint(0.0F, 32.0F, -4.0F);
    "".length();
    rearLeg.addChild(rearLegTip);
    rearFoot = new ModelRenderer(lllllllllllllllIIlllIIlIlIIllIll, lIlIllllllll[lIllIIIIIIII[69]]);
    rearFoot.setRotationPoint(0.0F, 31.0F, 4.0F);
    "".length();
    rearLegTip.addChild(rearFoot);
  }
  
  private static int lIIIlIIIIlIlll(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean lIIIlIIIIlIllI(int ???)
  {
    long lllllllllllllllIIlllIIlIIIIlIIIl;
    return ??? == 0;
  }
  
  private static boolean lIIIlIIIIllIlI(int ???)
  {
    byte lllllllllllllllIIlllIIlIIIIIllll;
    return ??? >= 0;
  }
  
  public void setLivingAnimations(EntityLivingBase lllllllllllllllIIlllIIlIlIIlIIll, float lllllllllllllllIIlllIIlIlIIlIIlI, float lllllllllllllllIIlllIIlIlIIlIIIl, float lllllllllllllllIIlllIIlIlIIlIIII)
  {
    ;
    ;
    partialTicks = lllllllllllllllIIlllIIlIlIIlIIII;
  }
  
  private static boolean lIIIlIIIIllIIl(int ???)
  {
    char lllllllllllllllIIlllIIlIIIIIllIl;
    return ??? < 0;
  }
}

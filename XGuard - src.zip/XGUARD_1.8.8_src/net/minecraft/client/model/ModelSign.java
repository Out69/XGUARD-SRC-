package net.minecraft.client.model;

public class ModelSign
  extends ModelBase
{
  private static void lllllllI()
  {
    lIIIlII = new int[5];
    lIIIlII[0] = ((57 + 38 - -20 + 51 ^ 9 + 109 - 57 + 88) & (123 + '±' - 127 + 16 ^ 50 + 88 - 94 + 98 ^ -" ".length()));
    lIIIlII[1] = (0x24 ^ 0x3C);
    lIIIlII[2] = (0xB6 ^ 0xBA);
    lIIIlII[3] = "  ".length();
    lIIIlII[4] = (0x1E ^ 0x10);
  }
  
  public void renderSign()
  {
    ;
    signBoard.render(0.0625F);
    signStick.render(0.0625F);
  }
  
  static {}
  
  public ModelSign()
  {
    signBoard.addBox(-12.0F, -14.0F, -1.0F, lIIIlII[1], lIIIlII[2], lIIIlII[3], 0.0F);
    signStick = new ModelRenderer(lllIIIIIIIIIlIl, lIIIlII[0], lIIIlII[4]);
    signStick.addBox(-1.0F, -2.0F, -1.0F, lIIIlII[3], lIIIlII[4], lIIIlII[3], 0.0F);
  }
}

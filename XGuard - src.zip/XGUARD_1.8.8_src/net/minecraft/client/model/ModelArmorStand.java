package net.minecraft.client.model;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.util.Rotations;

public class ModelArmorStand
  extends ModelArmorStandArmor
{
  public void postRenderArm(float lllllllllllllllIllIIIIIlllIllIlI)
  {
    ;
    ;
    ;
    boolean lllllllllllllllIllIIIIIlllIlllII = bipedRightArm.showModel;
    bipedRightArm.showModel = lIIllIIIIIll[10];
    lllllllllllllllIllIIIIIlllIllllI.postRenderArm(lllllllllllllllIllIIIIIlllIllIlI);
    bipedRightArm.showModel = lllllllllllllllIllIIIIIlllIlllII;
  }
  
  static {}
  
  private static void lllIlIlIIlIlI()
  {
    lIIllIIIIIll = new int[15];
    lIIllIIIIIll[0] = (0x7A ^ 0x3A);
    lIIllIIIIIll[1] = ((0xDC ^ 0x9C ^ 0x61 ^ 0x5) & (51 + 124 - 72 + 31 ^ 66 + 50 - 47 + 93 ^ -" ".length()));
    lIIllIIIIIll[2] = "  ".length();
    lIIllIIIIIll[3] = (0x67 ^ 0x60);
    lIIllIIIIIll[4] = (0xA1 ^ 0xBB);
    lIIllIIIIIll[5] = (0xBD ^ 0xB1);
    lIIllIIIIIll[6] = "   ".length();
    lIIllIIIIIll[7] = (0x96 ^ 0x9E ^ 0x91 ^ 0x81);
    lIIllIIIIIll[8] = (0x56 ^ 0x1 ^ 0xEA ^ 0x9D);
    lIIllIIIIIll[9] = (0xF0 ^ 0xA4 ^ 0xD5 ^ 0x91);
    lIIllIIIIIll[10] = " ".length();
    lIIllIIIIIll[11] = (0xD5 ^ 0xC1 ^ 0x42 ^ 0x5E);
    lIIllIIIIIll[12] = (0x58 ^ 0x53);
    lIIllIIIIIll[13] = (13 + 61 - -48 + 38 ^ 81 + 22 - 56 + 89);
    lIIllIIIIIll[14] = (13 + 60 - -4 + 60 ^ 66 + 101 - 9 + 27);
  }
  
  private static boolean lllIlIlIIlIll(int ???)
  {
    boolean lllllllllllllllIllIIIIIlllIlIlll;
    return ??? != 0;
  }
  
  public void render(Entity lllllllllllllllIllIIIIIllllIlIIl, float lllllllllllllllIllIIIIIlllllIIIl, float lllllllllllllllIllIIIIIlllllIIII, float lllllllllllllllIllIIIIIllllIIllI, float lllllllllllllllIllIIIIIllllIIlIl, float lllllllllllllllIllIIIIIllllIIlII, float lllllllllllllllIllIIIIIllllIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllIIIIIlllllIIll.render(lllllllllllllllIllIIIIIllllIlIIl, lllllllllllllllIllIIIIIlllllIIIl, lllllllllllllllIllIIIIIlllllIIII, lllllllllllllllIllIIIIIllllIIllI, lllllllllllllllIllIIIIIllllIIlIl, lllllllllllllllIllIIIIIllllIIlII, lllllllllllllllIllIIIIIllllIIIll);
    GlStateManager.pushMatrix();
    if (lllIlIlIIlIll(isChild))
    {
      float lllllllllllllllIllIIIIIllllIlIll = 2.0F;
      GlStateManager.scale(1.0F / lllllllllllllllIllIIIIIllllIlIll, 1.0F / lllllllllllllllIllIIIIIllllIlIll, 1.0F / lllllllllllllllIllIIIIIllllIlIll);
      GlStateManager.translate(0.0F, 24.0F * lllllllllllllllIllIIIIIllllIIIll, 0.0F);
      standRightSide.render(lllllllllllllllIllIIIIIllllIIIll);
      standLeftSide.render(lllllllllllllllIllIIIIIllllIIIll);
      standWaist.render(lllllllllllllllIllIIIIIllllIIIll);
      standBase.render(lllllllllllllllIllIIIIIllllIIIll);
      "".length();
      if (-(0xB9 ^ 0xBD) < 0) {}
    }
    else
    {
      if (lllIlIlIIlIll(lllllllllllllllIllIIIIIllllIlIIl.isSneaking())) {
        GlStateManager.translate(0.0F, 0.2F, 0.0F);
      }
      standRightSide.render(lllllllllllllllIllIIIIIllllIIIll);
      standLeftSide.render(lllllllllllllllIllIIIIIllllIIIll);
      standWaist.render(lllllllllllllllIllIIIIIllllIIIll);
      standBase.render(lllllllllllllllIllIIIIIllllIIIll);
    }
    GlStateManager.popMatrix();
  }
  
  public ModelArmorStand()
  {
    lllllllllllllllIllIIIIlIIIlIIlll.<init>(0.0F);
  }
  
  public ModelArmorStand(float lllllllllllllllIllIIIIlIIIlIIIIl)
  {
    lllllllllllllllIllIIIIlIIIlIIIlI.<init>(lllllllllllllllIllIIIIlIIIlIIIIl, lIIllIIIIIll[0], lIIllIIIIIll[0]);
    bipedHead = new ModelRenderer(lllllllllllllllIllIIIIlIIIlIIIlI, lIIllIIIIIll[1], lIIllIIIIIll[1]);
    bipedHead.addBox(-1.0F, -7.0F, -1.0F, lIIllIIIIIll[2], lIIllIIIIIll[3], lIIllIIIIIll[2], lllllllllllllllIllIIIIlIIIlIIIIl);
    bipedHead.setRotationPoint(0.0F, 0.0F, 0.0F);
    bipedBody = new ModelRenderer(lllllllllllllllIllIIIIlIIIlIIIlI, lIIllIIIIIll[1], lIIllIIIIIll[4]);
    bipedBody.addBox(-6.0F, 0.0F, -1.5F, lIIllIIIIIll[5], lIIllIIIIIll[6], lIIllIIIIIll[6], lllllllllllllllIllIIIIlIIIlIIIIl);
    bipedBody.setRotationPoint(0.0F, 0.0F, 0.0F);
    bipedRightArm = new ModelRenderer(lllllllllllllllIllIIIIlIIIlIIIlI, lIIllIIIIIll[7], lIIllIIIIIll[1]);
    bipedRightArm.addBox(-2.0F, -2.0F, -1.0F, lIIllIIIIIll[2], lIIllIIIIIll[5], lIIllIIIIIll[2], lllllllllllllllIllIIIIlIIIlIIIIl);
    bipedRightArm.setRotationPoint(-5.0F, 2.0F, 0.0F);
    bipedLeftArm = new ModelRenderer(lllllllllllllllIllIIIIlIIIlIIIlI, lIIllIIIIIll[8], lIIllIIIIIll[9]);
    bipedLeftArm.mirror = lIIllIIIIIll[10];
    bipedLeftArm.addBox(0.0F, -2.0F, -1.0F, lIIllIIIIIll[2], lIIllIIIIIll[5], lIIllIIIIIll[2], lllllllllllllllIllIIIIlIIIlIIIIl);
    bipedLeftArm.setRotationPoint(5.0F, 2.0F, 0.0F);
    bipedRightLeg = new ModelRenderer(lllllllllllllllIllIIIIlIIIlIIIlI, lIIllIIIIIll[11], lIIllIIIIIll[1]);
    bipedRightLeg.addBox(-1.0F, 0.0F, -1.0F, lIIllIIIIIll[2], lIIllIIIIIll[12], lIIllIIIIIll[2], lllllllllllllllIllIIIIlIIIlIIIIl);
    bipedRightLeg.setRotationPoint(-1.9F, 12.0F, 0.0F);
    bipedLeftLeg = new ModelRenderer(lllllllllllllllIllIIIIlIIIlIIIlI, lIIllIIIIIll[13], lIIllIIIIIll[9]);
    bipedLeftLeg.mirror = lIIllIIIIIll[10];
    bipedLeftLeg.addBox(-1.0F, 0.0F, -1.0F, lIIllIIIIIll[2], lIIllIIIIIll[12], lIIllIIIIIll[2], lllllllllllllllIllIIIIlIIIlIIIIl);
    bipedLeftLeg.setRotationPoint(1.9F, 12.0F, 0.0F);
    standRightSide = new ModelRenderer(lllllllllllllllIllIIIIlIIIlIIIlI, lIIllIIIIIll[9], lIIllIIIIIll[1]);
    standRightSide.addBox(-3.0F, 3.0F, -1.0F, lIIllIIIIIll[2], lIIllIIIIIll[3], lIIllIIIIIll[2], lllllllllllllllIllIIIIlIIIlIIIIl);
    standRightSide.setRotationPoint(0.0F, 0.0F, 0.0F);
    standRightSide.showModel = lIIllIIIIIll[10];
    standLeftSide = new ModelRenderer(lllllllllllllllIllIIIIlIIIlIIIlI, lIIllIIIIIll[14], lIIllIIIIIll[9]);
    standLeftSide.addBox(1.0F, 3.0F, -1.0F, lIIllIIIIIll[2], lIIllIIIIIll[3], lIIllIIIIIll[2], lllllllllllllllIllIIIIlIIIlIIIIl);
    standLeftSide.setRotationPoint(0.0F, 0.0F, 0.0F);
    standWaist = new ModelRenderer(lllllllllllllllIllIIIIlIIIlIIIlI, lIIllIIIIIll[1], lIIllIIIIIll[14]);
    standWaist.addBox(-4.0F, 10.0F, -1.0F, lIIllIIIIIll[11], lIIllIIIIIll[2], lIIllIIIIIll[2], lllllllllllllllIllIIIIlIIIlIIIIl);
    standWaist.setRotationPoint(0.0F, 0.0F, 0.0F);
    standBase = new ModelRenderer(lllllllllllllllIllIIIIlIIIlIIIlI, lIIllIIIIIll[1], lIIllIIIIIll[8]);
    standBase.addBox(-6.0F, 11.0F, -6.0F, lIIllIIIIIll[5], lIIllIIIIIll[10], lIIllIIIIIll[5], lllllllllllllllIllIIIIlIIIlIIIIl);
    standBase.setRotationPoint(0.0F, 12.0F, 0.0F);
  }
  
  public void setRotationAngles(float lllllllllllllllIllIIIIlIIIIlIIll, float lllllllllllllllIllIIIIlIIIIIIllI, float lllllllllllllllIllIIIIlIIIIlIIIl, float lllllllllllllllIllIIIIlIIIIIIlII, float lllllllllllllllIllIIIIlIIIIIIIll, float lllllllllllllllIllIIIIlIIIIIlllI, Entity lllllllllllllllIllIIIIlIIIIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllIIIIlIIIIlIlII.setRotationAngles(lllllllllllllllIllIIIIlIIIIlIIll, lllllllllllllllIllIIIIlIIIIIIllI, lllllllllllllllIllIIIIlIIIIlIIIl, lllllllllllllllIllIIIIlIIIIIIlII, lllllllllllllllIllIIIIlIIIIIIIll, lllllllllllllllIllIIIIlIIIIIlllI, lllllllllllllllIllIIIIlIIIIIllIl);
    if (lllIlIlIIlIll(lllllllllllllllIllIIIIlIIIIIllIl instanceof EntityArmorStand))
    {
      EntityArmorStand lllllllllllllllIllIIIIlIIIIIllII = (EntityArmorStand)lllllllllllllllIllIIIIlIIIIIllIl;
      bipedLeftArm.showModel = lllllllllllllllIllIIIIlIIIIIllII.getShowArms();
      bipedRightArm.showModel = lllllllllllllllIllIIIIlIIIIIllII.getShowArms();
      if (lllIlIlIIlIll(lllllllllllllllIllIIIIlIIIIIllII.hasNoBasePlate()))
      {
        "".length();
        if ((0x8B ^ 0x8F) > "  ".length()) {
          break label105;
        }
      }
      label105:
      lIIllIIIIIll1showModel = lIIllIIIIIll[10];
      bipedLeftLeg.setRotationPoint(1.9F, 12.0F, 0.0F);
      bipedRightLeg.setRotationPoint(-1.9F, 12.0F, 0.0F);
      standRightSide.rotateAngleX = (0.017453292F * lllllllllllllllIllIIIIlIIIIIllII.getBodyRotation().getX());
      standRightSide.rotateAngleY = (0.017453292F * lllllllllllllllIllIIIIlIIIIIllII.getBodyRotation().getY());
      standRightSide.rotateAngleZ = (0.017453292F * lllllllllllllllIllIIIIlIIIIIllII.getBodyRotation().getZ());
      standLeftSide.rotateAngleX = (0.017453292F * lllllllllllllllIllIIIIlIIIIIllII.getBodyRotation().getX());
      standLeftSide.rotateAngleY = (0.017453292F * lllllllllllllllIllIIIIlIIIIIllII.getBodyRotation().getY());
      standLeftSide.rotateAngleZ = (0.017453292F * lllllllllllllllIllIIIIlIIIIIllII.getBodyRotation().getZ());
      standWaist.rotateAngleX = (0.017453292F * lllllllllllllllIllIIIIlIIIIIllII.getBodyRotation().getX());
      standWaist.rotateAngleY = (0.017453292F * lllllllllllllllIllIIIIlIIIIIllII.getBodyRotation().getY());
      standWaist.rotateAngleZ = (0.017453292F * lllllllllllllllIllIIIIlIIIIIllII.getBodyRotation().getZ());
      float lllllllllllllllIllIIIIlIIIIIlIll = (lllllllllllllllIllIIIIlIIIIIllII.getLeftLegRotation().getX() + lllllllllllllllIllIIIIlIIIIIllII.getRightLegRotation().getX()) / 2.0F;
      float lllllllllllllllIllIIIIlIIIIIlIlI = (lllllllllllllllIllIIIIlIIIIIllII.getLeftLegRotation().getY() + lllllllllllllllIllIIIIlIIIIIllII.getRightLegRotation().getY()) / 2.0F;
      float lllllllllllllllIllIIIIlIIIIIlIIl = (lllllllllllllllIllIIIIlIIIIIllII.getLeftLegRotation().getZ() + lllllllllllllllIllIIIIlIIIIIllII.getRightLegRotation().getZ()) / 2.0F;
      standBase.rotateAngleX = 0.0F;
      standBase.rotateAngleY = (0.017453292F * -rotationYaw);
      standBase.rotateAngleZ = 0.0F;
    }
  }
}

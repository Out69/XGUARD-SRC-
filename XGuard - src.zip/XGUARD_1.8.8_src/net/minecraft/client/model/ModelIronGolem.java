package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityIronGolem;

public class ModelIronGolem
  extends ModelBase
{
  private static void lIlIIlIllIIl()
  {
    llIlIIIIIl = new int[23];
    llIlIIIIIl[0] = ((0x7B ^ 0x68) + (0x91 ^ 0x81) - -(0x77 ^ 0x7E) + (0x43 ^ 0x17));
    llIlIIIIIl[1] = ((0xA ^ 0x4) & (0x8 ^ 0x6 ^ 0xFFFFFFFF));
    llIlIIIIIl[2] = (0xA ^ 0x2);
    llIlIIIIIl[3] = (13 + 116 - 110 + 124 ^ 21 + 119 - 117 + 110);
    llIlIIIIIl[4] = (0xFC ^ 0x85 ^ 0x12 ^ 0x73);
    llIlIIIIIl[5] = "  ".length();
    llIlIIIIIl[6] = (0x20 ^ 0x24);
    llIlIIIIIl[7] = (0xCD ^ 0xB9 ^ 0xF7 ^ 0xAB);
    llIlIIIIIl[8] = (0x11 ^ 0x3);
    llIlIIIIIl[9] = (0xCE ^ 0xC2);
    llIlIIIIIl[10] = (0x82 ^ 0x89);
    llIlIIIIIl[11] = (0x79 ^ 0x33 ^ 0x3 ^ 0xF);
    llIlIIIIIl[12] = (0xAB ^ 0xA2);
    llIlIIIIIl[13] = (0x89 ^ 0x8C);
    llIlIIIIIl[14] = (0x4A ^ 0x7D ^ 0x58 ^ 0x69);
    llIlIIIIIl[15] = (0xB6 ^ 0x8A);
    llIlIIIIIl[16] = (0xC2 ^ 0xBE ^ 0x2E ^ 0x47);
    llIlIIIIIl[17] = ('©' + 14 - 43 + 77 ^ 27 + 100 - -27 + 45);
    llIlIIIIIl[18] = (113 + 85 - 117 + 70 ^ 66 + 79 - 89 + 117);
    llIlIIIIIl[19] = (0x7D ^ 0x6B);
    llIlIIIIIl[20] = (0x34 ^ 0x6B ^ 0x20 ^ 0x5A);
    llIlIIIIIl[21] = (111 + 45 - 138 + 147 ^ 24 + '­' - 48 + 32);
    llIlIIIIIl[22] = " ".length();
  }
  
  private float func_78172_a(float lllllllllllllllllllIIlIIIlIIIllI, float lllllllllllllllllllIIlIIIlIIIIll)
  {
    ;
    ;
    return (Math.abs(lllllllllllllllllllIIlIIIlIIIllI % lllllllllllllllllllIIlIIIlIIIIll - lllllllllllllllllllIIlIIIlIIIIll * 0.5F) - lllllllllllllllllllIIlIIIlIIIIll * 0.25F) / (lllllllllllllllllllIIlIIIlIIIIll * 0.25F);
  }
  
  private static boolean lIlIIlIllIlI(int ???)
  {
    char lllllllllllllllllllIIlIIIlIIIIIl;
    return ??? > 0;
  }
  
  public void setLivingAnimations(EntityLivingBase lllllllllllllllllllIIlIIIlIllIII, float lllllllllllllllllllIIlIIIlIIllll, float lllllllllllllllllllIIlIIIlIlIllI, float lllllllllllllllllllIIlIIIlIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EntityIronGolem lllllllllllllllllllIIlIIIlIlIlII = (EntityIronGolem)lllllllllllllllllllIIlIIIlIllIII;
    int lllllllllllllllllllIIlIIIlIlIIll = lllllllllllllllllllIIlIIIlIlIlII.getAttackTimer();
    if (lIlIIlIllIlI(lllllllllllllllllllIIlIIIlIlIIll))
    {
      ironGolemRightArm.rotateAngleX = (-2.0F + 1.5F * lllllllllllllllllllIIlIIIlIllIIl.func_78172_a(lllllllllllllllllllIIlIIIlIlIIll - lllllllllllllllllllIIlIIIlIIllIl, 10.0F));
      ironGolemLeftArm.rotateAngleX = (-2.0F + 1.5F * lllllllllllllllllllIIlIIIlIllIIl.func_78172_a(lllllllllllllllllllIIlIIIlIlIIll - lllllllllllllllllllIIlIIIlIIllIl, 10.0F));
      "".length();
      if (-" ".length() < (0x22 ^ 0x26)) {}
    }
    else
    {
      int lllllllllllllllllllIIlIIIlIlIIlI = lllllllllllllllllllIIlIIIlIlIlII.getHoldRoseTick();
      if (lIlIIlIllIlI(lllllllllllllllllllIIlIIIlIlIIlI))
      {
        ironGolemRightArm.rotateAngleX = (-0.8F + 0.025F * lllllllllllllllllllIIlIIIlIllIIl.func_78172_a(lllllllllllllllllllIIlIIIlIlIIlI, 70.0F));
        ironGolemLeftArm.rotateAngleX = 0.0F;
        "".length();
        if ((0x2D ^ 0x29) > 0) {}
      }
      else
      {
        ironGolemRightArm.rotateAngleX = ((-0.2F + 1.5F * lllllllllllllllllllIIlIIIlIllIIl.func_78172_a(lllllllllllllllllllIIlIIIlIlIlll, 13.0F)) * lllllllllllllllllllIIlIIIlIlIllI);
        ironGolemLeftArm.rotateAngleX = ((-0.2F - 1.5F * lllllllllllllllllllIIlIIIlIllIIl.func_78172_a(lllllllllllllllllllIIlIIIlIlIlll, 13.0F)) * lllllllllllllllllllIIlIIIlIlIllI);
      }
    }
  }
  
  public void setRotationAngles(float lllllllllllllllllllIIlIIIllIIlIl, float lllllllllllllllllllIIlIIIllIllII, float lllllllllllllllllllIIlIIIllIlIll, float lllllllllllllllllllIIlIIIllIlIlI, float lllllllllllllllllllIIlIIIllIlIIl, float lllllllllllllllllllIIlIIIllIlIII, Entity lllllllllllllllllllIIlIIIllIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ironGolemHead.rotateAngleY = (lllllllllllllllllllIIlIIIllIIIll / 57.295776F);
    ironGolemHead.rotateAngleX = (lllllllllllllllllllIIlIIIllIlIIl / 57.295776F);
    ironGolemLeftLeg.rotateAngleX = (-1.5F * lllllllllllllllllllIIlIIIllIIllI.func_78172_a(lllllllllllllllllllIIlIIIllIIlIl, 13.0F) * lllllllllllllllllllIIlIIIllIllII);
    ironGolemRightLeg.rotateAngleX = (1.5F * lllllllllllllllllllIIlIIIllIIllI.func_78172_a(lllllllllllllllllllIIlIIIllIIlIl, 13.0F) * lllllllllllllllllllIIlIIIllIllII);
    ironGolemLeftLeg.rotateAngleY = 0.0F;
    ironGolemRightLeg.rotateAngleY = 0.0F;
  }
  
  public ModelIronGolem()
  {
    lllllllllllllllllllIIlIIlIlIIIIl.<init>(0.0F);
  }
  
  public void render(Entity lllllllllllllllllllIIlIIIllllIlI, float lllllllllllllllllllIIlIIlIIIIIIl, float lllllllllllllllllllIIlIIIllllIII, float lllllllllllllllllllIIlIIIlllIlll, float lllllllllllllllllllIIlIIIlllIllI, float lllllllllllllllllllIIlIIIlllllIl, float lllllllllllllllllllIIlIIIlllllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIIlIIlIIIIIll.setRotationAngles(lllllllllllllllllllIIlIIlIIIIIIl, lllllllllllllllllllIIlIIIllllIII, lllllllllllllllllllIIlIIIlllIlll, lllllllllllllllllllIIlIIIlllIllI, lllllllllllllllllllIIlIIIlllllIl, lllllllllllllllllllIIlIIIlllllII, lllllllllllllllllllIIlIIIllllIlI);
    ironGolemHead.render(lllllllllllllllllllIIlIIIlllllII);
    ironGolemBody.render(lllllllllllllllllllIIlIIIlllllII);
    ironGolemLeftLeg.render(lllllllllllllllllllIIlIIIlllllII);
    ironGolemRightLeg.render(lllllllllllllllllllIIlIIIlllllII);
    ironGolemRightArm.render(lllllllllllllllllllIIlIIIlllllII);
    ironGolemLeftArm.render(lllllllllllllllllllIIlIIIlllllII);
  }
  
  public ModelIronGolem(float lllllllllllllllllllIIlIIlIIlllIl)
  {
    lllllllllllllllllllIIlIIlIIllllI.<init>(lllllllllllllllllllIIlIIlIIlllIl, -7.0F);
  }
  
  public ModelIronGolem(float lllllllllllllllllllIIlIIlIIlIlII, float lllllllllllllllllllIIlIIlIIlIIll)
  {
    int lllllllllllllllllllIIlIIlIIlIIlI = llIlIIIIIl[0];
    int lllllllllllllllllllIIlIIlIIlIIIl = llIlIIIIIl[0];
    ironGolemHead = new ModelRenderer(lllllllllllllllllllIIlIIlIIlIIII).setTextureSize(lllllllllllllllllllIIlIIlIIlIIlI, lllllllllllllllllllIIlIIlIIlIIIl);
    ironGolemHead.setRotationPoint(0.0F, 0.0F + lllllllllllllllllllIIlIIlIIlIIll, -2.0F);
    ironGolemHead.setTextureOffset(llIlIIIIIl[1], llIlIIIIIl[1]).addBox(-4.0F, -12.0F, -5.5F, llIlIIIIIl[2], llIlIIIIIl[3], llIlIIIIIl[2], lllllllllllllllllllIIlIIlIIIllll);
    ironGolemHead.setTextureOffset(llIlIIIIIl[4], llIlIIIIIl[1]).addBox(-1.0F, -5.0F, -7.5F, llIlIIIIIl[5], llIlIIIIIl[6], llIlIIIIIl[5], lllllllllllllllllllIIlIIlIIIllll);
    ironGolemBody = new ModelRenderer(lllllllllllllllllllIIlIIlIIlIIII).setTextureSize(lllllllllllllllllllIIlIIlIIlIIlI, lllllllllllllllllllIIlIIlIIlIIIl);
    ironGolemBody.setRotationPoint(0.0F, 0.0F + lllllllllllllllllllIIlIIlIIlIIll, 0.0F);
    ironGolemBody.setTextureOffset(llIlIIIIIl[1], llIlIIIIIl[7]).addBox(-9.0F, -2.0F, -6.0F, llIlIIIIIl[8], llIlIIIIIl[9], llIlIIIIIl[10], lllllllllllllllllllIIlIIlIIIllll);
    ironGolemBody.setTextureOffset(llIlIIIIIl[1], llIlIIIIIl[11]).addBox(-4.5F, 10.0F, -3.0F, llIlIIIIIl[12], llIlIIIIIl[13], llIlIIIIIl[14], lllllllllllllllllllIIlIIlIIIllll + 0.5F);
    ironGolemRightArm = new ModelRenderer(lllllllllllllllllllIIlIIlIIlIIII).setTextureSize(lllllllllllllllllllIIlIIlIIlIIlI, lllllllllllllllllllIIlIIlIIlIIIl);
    ironGolemRightArm.setRotationPoint(0.0F, -7.0F, 0.0F);
    ironGolemRightArm.setTextureOffset(llIlIIIIIl[15], llIlIIIIIl[16]).addBox(-13.0F, -2.5F, -3.0F, llIlIIIIIl[6], llIlIIIIIl[17], llIlIIIIIl[14], lllllllllllllllllllIIlIIlIIIllll);
    ironGolemLeftArm = new ModelRenderer(lllllllllllllllllllIIlIIlIIlIIII).setTextureSize(lllllllllllllllllllIIlIIlIIlIIlI, lllllllllllllllllllIIlIIlIIlIIIl);
    ironGolemLeftArm.setRotationPoint(0.0F, -7.0F, 0.0F);
    ironGolemLeftArm.setTextureOffset(llIlIIIIIl[15], llIlIIIIIl[18]).addBox(9.0F, -2.5F, -3.0F, llIlIIIIIl[6], llIlIIIIIl[17], llIlIIIIIl[14], lllllllllllllllllllIIlIIlIIIllll);
    ironGolemLeftLeg = new ModelRenderer(lllllllllllllllllllIIlIIlIIlIIII, llIlIIIIIl[1], llIlIIIIIl[19]).setTextureSize(lllllllllllllllllllIIlIIlIIlIIlI, lllllllllllllllllllIIlIIlIIlIIIl);
    ironGolemLeftLeg.setRotationPoint(-4.0F, 18.0F + lllllllllllllllllllIIlIIlIIlIIll, 0.0F);
    ironGolemLeftLeg.setTextureOffset(llIlIIIIIl[20], llIlIIIIIl[1]).addBox(-3.5F, -3.0F, -3.0F, llIlIIIIIl[14], llIlIIIIIl[21], llIlIIIIIl[13], lllllllllllllllllllIIlIIlIIIllll);
    ironGolemRightLeg = new ModelRenderer(lllllllllllllllllllIIlIIlIIlIIII, llIlIIIIIl[1], llIlIIIIIl[19]).setTextureSize(lllllllllllllllllllIIlIIlIIlIIlI, lllllllllllllllllllIIlIIlIIlIIIl);
    ironGolemRightLeg.mirror = llIlIIIIIl[22];
    ironGolemRightLeg.setTextureOffset(llIlIIIIIl[15], llIlIIIIIl[1]).setRotationPoint(5.0F, 18.0F + lllllllllllllllllllIIlIIlIIlIIll, 0.0F);
    ironGolemRightLeg.addBox(-3.5F, -3.0F, -3.0F, llIlIIIIIl[14], llIlIIIIIl[21], llIlIIIIIl[13], lllllllllllllllllllIIlIIlIIIllll);
  }
  
  static {}
}

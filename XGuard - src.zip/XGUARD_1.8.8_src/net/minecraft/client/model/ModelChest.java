package net.minecraft.client.model;

public class ModelChest
  extends ModelBase
{
  public ModelChest()
  {
    chestLid.addBox(0.0F, -5.0F, -14.0F, llllI[2], llllI[3], llllI[2], 0.0F);
    chestLid.rotationPointX = 1.0F;
    chestLid.rotationPointY = 7.0F;
    chestLid.rotationPointZ = 15.0F;
    chestKnob = new ModelRenderer(lllIlllIIllIlIl, llllI[0], llllI[0]).setTextureSize(llllI[1], llllI[1]);
    chestKnob.addBox(-1.0F, -2.0F, -15.0F, llllI[4], llllI[5], llllI[6], 0.0F);
    chestKnob.rotationPointX = 8.0F;
    chestKnob.rotationPointY = 7.0F;
    chestKnob.rotationPointZ = 15.0F;
    chestBelow = new ModelRenderer(lllIlllIIllIlIl, llllI[0], llllI[7]).setTextureSize(llllI[1], llllI[1]);
    chestBelow.addBox(0.0F, 0.0F, 0.0F, llllI[2], llllI[8], llllI[2], 0.0F);
    chestBelow.rotationPointX = 1.0F;
    chestBelow.rotationPointY = 6.0F;
    chestBelow.rotationPointZ = 1.0F;
  }
  
  public void renderAll()
  {
    ;
    chestKnob.rotateAngleX = chestLid.rotateAngleX;
    chestLid.render(0.0625F);
    chestKnob.render(0.0625F);
    chestBelow.render(0.0625F);
  }
  
  static {}
  
  private static void lIIIllII()
  {
    llllI = new int[9];
    llllI[0] = ("  ".length() & ("  ".length() ^ 0xFFFFFFFF));
    llllI[1] = ('' + 29 - 96 + 140 ^ 54 + 67 - 97 + 130);
    llllI[2] = (0xB8 ^ 0xB6);
    llllI[3] = (0x57 ^ 0x52);
    llllI[4] = "  ".length();
    llllI[5] = (0x8E ^ 0xA6 ^ 0x21 ^ 0xD);
    llllI[6] = " ".length();
    llllI[7] = (60 + 26 - -14 + 49 ^ 110 + '' - 218 + 113);
    llllI[8] = (0xF8 ^ 0x98 ^ 0xAF ^ 0xC5);
  }
}

package net.minecraft.client.model;

import net.minecraft.util.Vec3;

public class PositionTextureVertex
{
  public PositionTextureVertex(Vec3 llIIIlIII, float llIIIIlll, float llIIIIllI)
  {
    vector3D = llIIIlIII;
    texturePositionX = llIIIIlll;
    texturePositionY = llIIIIllI;
  }
  
  public PositionTextureVertex(PositionTextureVertex llIIlIIII, float llIIlIIll, float llIIlIIlI)
  {
    vector3D = vector3D;
    texturePositionX = llIIlIIll;
    texturePositionY = llIIlIIlI;
  }
  
  public PositionTextureVertex(float llIlIllIl, float llIlIllII, float llIlIIlIl, float llIlIIlII, float llIlIIIll)
  {
    llIlIlIII.<init>(new Vec3(llIlIllIl, llIlIllII, llIlIIlIl), llIlIIlII, llIlIIIll);
  }
  
  public PositionTextureVertex setTexturePosition(float llIIllIll, float llIIllIlI)
  {
    ;
    ;
    ;
    return new PositionTextureVertex(llIIlllII, llIIllllI, llIIllIlI);
  }
}

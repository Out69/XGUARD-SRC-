package net.minecraft.client.model;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityRabbit;
import net.minecraft.util.MathHelper;

public class ModelRabbit
  extends ModelBase
{
  public void setLivingAnimations(EntityLivingBase llllllllllllllIllIIIIlIIlIIlllII, float llllllllllllllIllIIIIlIIlIIllIll, float llllllllllllllIllIIIIlIIlIIllIlI, float llllllllllllllIllIIIIlIIlIIllIIl) {}
  
  private static String llIIIIllIlIlIl(String llllllllllllllIllIIIIlIIlIIIIlII, String llllllllllllllIllIIIIlIIlIIIIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIIIlIIlIIIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIIIlIIlIIIIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIIIIlIIlIIIIllI = Cipher.getInstance("Blowfish");
      llllllllllllllIllIIIIlIIlIIIIllI.init(llllllllIIII[3], llllllllllllllIllIIIIlIIlIIIIlll);
      return new String(llllllllllllllIllIIIIlIIlIIIIllI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIIIlIIlIIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIIIlIIlIIIIlIl)
    {
      llllllllllllllIllIIIIlIIlIIIIlIl.printStackTrace();
    }
    return null;
  }
  
  private static String llIIIIllIlIlII(String llllllllllllllIllIIIIlIIlIIIllll, String llllllllllllllIllIIIIlIIlIIlIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIIIIlIIlIIlIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIIIlIIlIIlIIII.getBytes(StandardCharsets.UTF_8)), llllllllIIII[9]), "DES");
      Cipher llllllllllllllIllIIIIlIIlIIlIIll = Cipher.getInstance("DES");
      llllllllllllllIllIIIIlIIlIIlIIll.init(llllllllIIII[3], llllllllllllllIllIIIIlIIlIIlIlII);
      return new String(llllllllllllllIllIIIIlIIlIIlIIll.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIIIlIIlIIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIIIIlIIlIIlIIlI)
    {
      llllllllllllllIllIIIIlIIlIIlIIlI.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIIIIllIllIIl(int ???)
  {
    float llllllllllllllIllIIIIlIIIlllllIl;
    return ??? != 0;
  }
  
  private static void llIIIIllIlIllI()
  {
    lllllllIlllI = new String[llllllllIIII[12]];
    lllllllIlllI[llllllllIIII[0]] = llIIIIllIlIlII("Ovt/wjim9QoDzWxI9oHiVw==", "lZaVZ");
    lllllllIlllI[llllllllIIII[1]] = llIIIIllIlIlII("xwqkWacQiW8oZokociz88g==", "WkhbV");
    lllllllIlllI[llllllllIIII[3]] = llIIIIllIlIlII("8oU/NIFJEuG5stNg15ENMQ==", "WfdZQ");
    lllllllIlllI[llllllllIIII[5]] = llIIIIllIlIlIl("rVmemUOzcIHuI7SDtZoSfw==", "VYAAP");
  }
  
  static
  {
    llIIIIllIlIlll();
    llIIIIllIlIllI();
  }
  
  public void render(Entity llllllllllllllIllIIIIlIIlIllllIl, float llllllllllllllIllIIIIlIIllIIIlIl, float llllllllllllllIllIIIIlIIlIlllIll, float llllllllllllllIllIIIIlIIlIlllIlI, float llllllllllllllIllIIIIlIIllIIIIlI, float llllllllllllllIllIIIIlIIlIlllIII, float llllllllllllllIllIIIIlIIlIllIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIIIIlIIllIIIlll.setRotationAngles(llllllllllllllIllIIIIlIIllIIIlIl, llllllllllllllIllIIIIlIIlIlllIll, llllllllllllllIllIIIIlIIlIlllIlI, llllllllllllllIllIIIIlIIllIIIIlI, llllllllllllllIllIIIIlIIlIlllIII, llllllllllllllIllIIIIlIIlIllIlll, llllllllllllllIllIIIIlIIlIllllIl);
    if (llIIIIllIllIIl(isChild))
    {
      float llllllllllllllIllIIIIlIIlIllllll = 2.0F;
      GlStateManager.pushMatrix();
      GlStateManager.translate(0.0F, 5.0F * llllllllllllllIllIIIIlIIlIllIlll, 2.0F * llllllllllllllIllIIIIlIIlIllIlll);
      rabbitHead.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitLeftEar.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitRightEar.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitNose.render(llllllllllllllIllIIIIlIIlIllIlll);
      GlStateManager.popMatrix();
      GlStateManager.pushMatrix();
      GlStateManager.scale(1.0F / llllllllllllllIllIIIIlIIlIllllll, 1.0F / llllllllllllllIllIIIIlIIlIllllll, 1.0F / llllllllllllllIllIIIIlIIlIllllll);
      GlStateManager.translate(0.0F, 24.0F * llllllllllllllIllIIIIlIIlIllIlll, 0.0F);
      rabbitLeftFoot.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitRightFoot.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitLeftThigh.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitRightThigh.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitBody.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitLeftArm.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitRightArm.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitTail.render(llllllllllllllIllIIIIlIIlIllIlll);
      GlStateManager.popMatrix();
      "".length();
      if (((0xC9 ^ 0x96) & (0xD2 ^ 0x8D ^ 0xFFFFFFFF)) == 0) {}
    }
    else
    {
      rabbitLeftFoot.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitRightFoot.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitLeftThigh.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitRightThigh.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitBody.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitLeftArm.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitRightArm.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitHead.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitRightEar.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitLeftEar.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitTail.render(llllllllllllllIllIIIIlIIlIllIlll);
      rabbitNose.render(llllllllllllllIllIIIIlIIlIllIlll);
    }
  }
  
  public void setRotationAngles(float llllllllllllllIllIIIIlIIlIlIllIl, float llllllllllllllIllIIIIlIIlIlIllII, float llllllllllllllIllIIIIlIIlIlIIIll, float llllllllllllllIllIIIIlIIlIlIIIlI, float llllllllllllllIllIIIIlIIlIlIIIIl, float llllllllllllllIllIIIIlIIlIlIlIII, Entity llllllllllllllIllIIIIlIIlIlIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIllIIIIlIIlIlIIllI = llllllllllllllIllIIIIlIIlIlIIIll - ticksExisted;
    EntityRabbit llllllllllllllIllIIIIlIIlIlIIlIl = (EntityRabbit)llllllllllllllIllIIIIlIIlIlIIlll;
    rabbitNose.rotateAngleX = (rabbitHead.rotateAngleX = rabbitRightEar.rotateAngleX = rabbitLeftEar.rotateAngleX = llllllllllllllIllIIIIlIIlIlIIIIl * 0.017453292F);
    rabbitNose.rotateAngleY = (rabbitHead.rotateAngleY = llllllllllllllIllIIIIlIIlIlIIIlI * 0.017453292F);
    rabbitRightEar.rotateAngleY = (rabbitNose.rotateAngleY - 0.2617994F);
    rabbitLeftEar.rotateAngleY = (rabbitNose.rotateAngleY + 0.2617994F);
    field_178701_m = MathHelper.sin(llllllllllllllIllIIIIlIIlIlIIlIl.func_175521_o(llllllllllllllIllIIIIlIIlIlIIllI) * 3.1415927F);
    rabbitLeftThigh.rotateAngleX = (rabbitRightThigh.rotateAngleX = (field_178701_m * 50.0F - 21.0F) * 0.017453292F);
    rabbitLeftFoot.rotateAngleX = (rabbitRightFoot.rotateAngleX = field_178701_m * 50.0F * 0.017453292F);
    rabbitLeftArm.rotateAngleX = (rabbitRightArm.rotateAngleX = (field_178701_m * -40.0F - 11.0F) * 0.017453292F);
  }
  
  private static void llIIIIllIlIlll()
  {
    llllllllIIII = new int[19];
    llllllllIIII[0] = ((0x43 ^ 0x1B) & (0x18 ^ 0x40 ^ 0xFFFFFFFF));
    llllllllIIII[1] = " ".length();
    llllllllIIII[2] = (0x14 ^ 0xC);
    llllllllIIII[3] = "  ".length();
    llllllllIIII[4] = (0x7B ^ 0x71);
    llllllllIIII[5] = "   ".length();
    llllllllIIII[6] = (0x6E ^ 0x4D ^ 0xE ^ 0x2B);
    llllllllIIII[7] = (0x6A ^ 0x70);
    llllllllIIII[8] = (0x7A ^ 0x7D);
    llllllllIIII[9] = (0x9B ^ 0x93);
    llllllllIIII[10] = (14 + '' - 91 + 90 ^ 62 + 58 - 55 + 65);
    llllllllIIII[11] = (0x97 ^ 0x98);
    llllllllIIII[12] = (0x7F ^ 0x28 ^ 0x33 ^ 0x60);
    llllllllIIII[13] = (0x30 ^ 0x35);
    llllllllIIII[14] = (0x66 ^ 0x29 ^ 0xE1 ^ 0xBE);
    llllllllIIII[15] = (0x65 ^ 0x45);
    llllllllIIII[16] = (0x4C ^ 0x78);
    llllllllIIII[17] = (0x67 ^ 0x5D);
    llllllllIIII[18] = (0x9A ^ 0x9D ^ 0xA6 ^ 0xA8);
  }
  
  public ModelRabbit()
  {
    llllllllllllllIllIIIIlIIllIllllI.setTextureOffset(lllllllIlllI[llllllllIIII[0]], llllllllIIII[0], llllllllIIII[0]);
    llllllllllllllIllIIIIlIIllIllllI.setTextureOffset(lllllllIlllI[llllllllIIII[1]], llllllllIIII[0], llllllllIIII[2]);
    llllllllllllllIllIIIIlIIllIllllI.setTextureOffset(lllllllIlllI[llllllllIIII[3]], llllllllIIII[0], llllllllIIII[4]);
    llllllllllllllIllIIIIlIIllIllllI.setTextureOffset(lllllllIlllI[llllllllIIII[5]], llllllllIIII[6], llllllllIIII[4]);
    rabbitLeftFoot = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[7], llllllllIIII[2]);
    "".length();
    rabbitLeftFoot.setRotationPoint(3.0F, 17.5F, 3.7F);
    rabbitLeftFoot.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitLeftFoot, 0.0F, 0.0F, 0.0F);
    rabbitRightFoot = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[9], llllllllIIII[2]);
    "".length();
    rabbitRightFoot.setRotationPoint(-3.0F, 17.5F, 3.7F);
    rabbitRightFoot.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitRightFoot, 0.0F, 0.0F, 0.0F);
    rabbitLeftThigh = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[10], llllllllIIII[11]);
    "".length();
    rabbitLeftThigh.setRotationPoint(3.0F, 17.5F, 3.7F);
    rabbitLeftThigh.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitLeftThigh, -0.34906584F, 0.0F, 0.0F);
    rabbitRightThigh = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[14], llllllllIIII[11]);
    "".length();
    rabbitRightThigh.setRotationPoint(-3.0F, 17.5F, 3.7F);
    rabbitRightThigh.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitRightThigh, -0.34906584F, 0.0F, 0.0F);
    rabbitBody = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[0], llllllllIIII[0]);
    "".length();
    rabbitBody.setRotationPoint(0.0F, 19.0F, 8.0F);
    rabbitBody.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitBody, -0.34906584F, 0.0F, 0.0F);
    rabbitLeftArm = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[9], llllllllIIII[11]);
    "".length();
    rabbitLeftArm.setRotationPoint(3.0F, 17.0F, -1.0F);
    rabbitLeftArm.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitLeftArm, -0.17453292F, 0.0F, 0.0F);
    rabbitRightArm = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[0], llllllllIIII[11]);
    "".length();
    rabbitRightArm.setRotationPoint(-3.0F, 17.0F, -1.0F);
    rabbitRightArm.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitRightArm, -0.17453292F, 0.0F, 0.0F);
    rabbitHead = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[15], llllllllIIII[0]);
    "".length();
    rabbitHead.setRotationPoint(0.0F, 16.0F, -1.0F);
    rabbitHead.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitHead, 0.0F, 0.0F, 0.0F);
    rabbitRightEar = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[16], llllllllIIII[0]);
    "".length();
    rabbitRightEar.setRotationPoint(0.0F, 16.0F, -1.0F);
    rabbitRightEar.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitRightEar, 0.0F, -0.2617994F, 0.0F);
    rabbitLeftEar = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[17], llllllllIIII[0]);
    "".length();
    rabbitLeftEar.setRotationPoint(0.0F, 16.0F, -1.0F);
    rabbitLeftEar.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitLeftEar, 0.0F, 0.2617994F, 0.0F);
    rabbitTail = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[16], llllllllIIII[6]);
    "".length();
    rabbitTail.setRotationPoint(0.0F, 20.0F, 7.0F);
    rabbitTail.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitTail, -0.3490659F, 0.0F, 0.0F);
    rabbitNose = new ModelRenderer(llllllllllllllIllIIIIlIIllIllllI, llllllllIIII[15], llllllllIIII[18]);
    "".length();
    rabbitNose.setRotationPoint(0.0F, 16.0F, -1.0F);
    rabbitNose.mirror = llllllllIIII[1];
    llllllllllllllIllIIIIlIIllIllllI.setRotationOffset(rabbitNose, 0.0F, 0.0F, 0.0F);
  }
  
  private void setRotationOffset(ModelRenderer llllllllllllllIllIIIIlIIllIllIII, float llllllllllllllIllIIIIlIIllIlIIll, float llllllllllllllIllIIIIlIIllIlIllI, float llllllllllllllIllIIIIlIIllIlIIIl)
  {
    ;
    ;
    ;
    ;
    rotateAngleX = llllllllllllllIllIIIIlIIllIlIIll;
    rotateAngleY = llllllllllllllIllIIIIlIIllIlIllI;
    rotateAngleZ = llllllllllllllIllIIIIlIIllIlIIIl;
  }
}

package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntitySheep;

public class ModelSheep2
  extends ModelQuadruped
{
  public ModelSheep2()
  {
    lIIIIlIIlIIIIlI.<init>(lIIlIlIIl[0], 0.0F);
    head = new ModelRenderer(lIIIIlIIlIIIIIl, lIIlIlIIl[1], lIIlIlIIl[1]);
    head.addBox(-3.0F, -4.0F, -6.0F, lIIlIlIIl[2], lIIlIlIIl[2], lIIlIlIIl[3], 0.0F);
    head.setRotationPoint(0.0F, 6.0F, -8.0F);
    body = new ModelRenderer(lIIIIlIIlIIIIIl, lIIlIlIIl[4], lIIlIlIIl[3]);
    body.addBox(-4.0F, -10.0F, -7.0F, lIIlIlIIl[3], lIIlIlIIl[5], lIIlIlIIl[2], 0.0F);
    body.setRotationPoint(0.0F, 5.0F, 2.0F);
  }
  
  static {}
  
  private static void lllllllIlI()
  {
    lIIlIlIIl = new int[6];
    lIIlIlIIl[0] = (0x6 ^ 0x35 ^ 0x99 ^ 0xA6);
    lIIlIlIIl[1] = ((0x31 ^ 0x75) & (0x23 ^ 0x67 ^ 0xFFFFFFFF));
    lIIlIlIIl[2] = (0x1F ^ 0x19);
    lIIlIlIIl[3] = (0x21 ^ 0x29);
    lIIlIlIIl[4] = (95 + 50 - 34 + 19 ^ 91 + 60 - 5 + 12);
    lIIlIlIIl[5] = (90 + 111 - 136 + 91 ^ 48 + 66 - 69 + 95);
  }
  
  public void setRotationAngles(float lIIIIlIIIlIIIII, float lIIIIlIIIIlllll, float lIIIIlIIIlIIllI, float lIIIIlIIIIlllIl, float lIIIIlIIIlIIlII, float lIIIIlIIIlIIIll, Entity lIIIIlIIIIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lIIIIlIIIlIlIIl.setRotationAngles(lIIIIlIIIlIIIII, lIIIIlIIIIlllll, lIIIIlIIIlIIllI, lIIIIlIIIIlllIl, lIIIIlIIIlIIlII, lIIIIlIIIlIIIll, lIIIIlIIIIllIlI);
    head.rotateAngleX = headRotationAngleX;
  }
  
  public void setLivingAnimations(EntityLivingBase lIIIIlIIIlllIlI, float lIIIIlIIIllIlII, float lIIIIlIIIlllIII, float lIIIIlIIIllIlll)
  {
    ;
    ;
    ;
    ;
    ;
    lIIIIlIIIlllIll.setLivingAnimations(lIIIIlIIIlllIlI, lIIIIlIIIlllIIl, lIIIIlIIIlllIII, lIIIIlIIIllIlll);
    head.rotationPointY = (6.0F + ((EntitySheep)lIIIIlIIIlllIlI).getHeadRotationPointY(lIIIIlIIIllIlll) * 9.0F);
    headRotationAngleX = ((EntitySheep)lIIIIlIIIlllIlI).getHeadRotationAngleX(lIIIIlIIIllIlll);
  }
}

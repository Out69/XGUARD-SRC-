package net.minecraft.client.model;

import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;

public abstract class ModelBase
{
  static {}
  
  public void setLivingAnimations(EntityLivingBase llllllllllllllllllIlIIlllIIlIIIl, float llllllllllllllllllIlIIlllIIlIIII, float llllllllllllllllllIlIIlllIIIllll, float llllllllllllllllllIlIIlllIIIlllI) {}
  
  public void render(Entity llllllllllllllllllIlIIlllIlIIIIl, float llllllllllllllllllIlIIlllIlIIIII, float llllllllllllllllllIlIIlllIIlllll, float llllllllllllllllllIlIIlllIIllllI, float llllllllllllllllllIlIIlllIIlllIl, float llllllllllllllllllIlIIlllIIlllII, float llllllllllllllllllIlIIlllIIllIll) {}
  
  public void setModelAttributes(ModelBase llllllllllllllllllIlIIllIllIlIlI)
  {
    ;
    ;
    swingProgress = swingProgress;
    isRiding = isRiding;
    isChild = isChild;
  }
  
  public ModelBase() {}
  
  protected void setTextureOffset(String llllllllllllllllllIlIIllIllllllI, int llllllllllllllllllIlIIllIlllllIl, int llllllllllllllllllIlIIllIlllllII)
  {
    ;
    ;
    ;
    ;
    new TextureOffset(llllllllllllllllllIlIIllIlllllIl, llllllllllllllllllIlIIllIlllllII);
    "".length();
  }
  
  public static void copyModelAngles(ModelRenderer llllllllllllllllllIlIIllIlllIIIl, ModelRenderer llllllllllllllllllIlIIllIlllIIII)
  {
    ;
    ;
    rotateAngleX = rotateAngleX;
    rotateAngleY = rotateAngleY;
    rotateAngleZ = rotateAngleZ;
    rotationPointX = rotationPointX;
    rotationPointY = rotationPointY;
    rotationPointZ = rotationPointZ;
  }
  
  public TextureOffset getTextureOffset(String llllllllllllllllllIlIIllIlllIllI)
  {
    ;
    ;
    return (TextureOffset)modelTextureMap.get(llllllllllllllllllIlIIllIlllIllI);
  }
  
  private static void lIllIllIIlIl()
  {
    lllIIlIlII = new int[3];
    lllIIlIlII[0] = " ".length();
    lllIIlIlII[1] = (0x31 ^ 0x71);
    lllIIlIlII[2] = (104 + '' - 120 + 18 ^ '' + '' - 232 + 132);
  }
  
  public ModelRenderer getRandomModelBox(Random llllllllllllllllllIlIIlllIIIlIII)
  {
    ;
    ;
    return (ModelRenderer)boxList.get(llllllllllllllllllIlIIlllIIIlIII.nextInt(boxList.size()));
  }
  
  public void setRotationAngles(float llllllllllllllllllIlIIlllIIllIIl, float llllllllllllllllllIlIIlllIIllIII, float llllllllllllllllllIlIIlllIIlIlll, float llllllllllllllllllIlIIlllIIlIllI, float llllllllllllllllllIlIIlllIIlIlIl, float llllllllllllllllllIlIIlllIIlIlII, Entity llllllllllllllllllIlIIlllIIlIIll) {}
}

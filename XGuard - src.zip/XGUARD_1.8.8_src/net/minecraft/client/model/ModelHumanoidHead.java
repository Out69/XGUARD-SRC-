package net.minecraft.client.model;

import net.minecraft.entity.Entity;

public class ModelHumanoidHead
  extends ModelSkeletonHead
{
  public void render(Entity lllllllllllllllIlIllIlIIllIIllII, float lllllllllllllllIlIllIlIIllIIlIll, float lllllllllllllllIlIllIlIIllIlIIlI, float lllllllllllllllIlIllIlIIllIlIIIl, float lllllllllllllllIlIllIlIIllIlIIII, float lllllllllllllllIlIllIlIIllIIllll, float lllllllllllllllIlIllIlIIllIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIllIlIIllIlIlIl.render(lllllllllllllllIlIllIlIIllIIllII, lllllllllllllllIlIllIlIIllIIlIll, lllllllllllllllIlIllIlIIllIlIIlI, lllllllllllllllIlIllIlIIllIlIIIl, lllllllllllllllIlIllIlIIllIlIIII, lllllllllllllllIlIllIlIIllIIllll, lllllllllllllllIlIllIlIIllIIlllI);
    head.render(lllllllllllllllIlIllIlIIllIIlllI);
  }
  
  public void setRotationAngles(float lllllllllllllllIlIllIlIIlIllllII, float lllllllllllllllIlIllIlIIlIllIIll, float lllllllllllllllIlIllIlIIlIlllIlI, float lllllllllllllllIlIllIlIIlIllIIIl, float lllllllllllllllIlIllIlIIlIllIIII, float lllllllllllllllIlIllIlIIlIllIlll, Entity lllllllllllllllIlIllIlIIlIllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIllIlIIlIllIlIl.setRotationAngles(lllllllllllllllIlIllIlIIlIllllII, lllllllllllllllIlIllIlIIlIllIIll, lllllllllllllllIlIllIlIIlIlllIlI, lllllllllllllllIlIllIlIIlIllIIIl, lllllllllllllllIlIllIlIIlIllIIII, lllllllllllllllIlIllIlIIlIllIlll, lllllllllllllllIlIllIlIIlIllIllI);
    head.rotateAngleY = skeletonHead.rotateAngleY;
    head.rotateAngleX = skeletonHead.rotateAngleX;
  }
  
  static {}
  
  private static void llllIIIIlIllI()
  {
    lIIlllIIIIlI = new int[4];
    lIIlllIIIIlI[0] = ((97 + 31 - 109 + 199 ^ '' + 23 - 87 + 74) & (0x48 ^ 0x3E ^ 0x3 ^ 0x37 ^ -" ".length()));
    lIIlllIIIIlI[1] = (0x97 ^ 0x83 ^ 0x76 ^ 0x22);
    lIIlllIIIIlI[2] = (0x21 ^ 0x4D ^ 0xFC ^ 0xB0);
    lIIlllIIIIlI[3] = (0x7D ^ 0x47 ^ 0x4 ^ 0x36);
  }
  
  public ModelHumanoidHead()
  {
    lllllllllllllllIlIllIlIIllIlllll.<init>(lIIlllIIIIlI[0], lIIlllIIIIlI[0], lIIlllIIIIlI[1], lIIlllIIIIlI[1]);
    head.addBox(-4.0F, -8.0F, -4.0F, lIIlllIIIIlI[3], lIIlllIIIIlI[3], lIIlllIIIIlI[3], 0.25F);
    head.setRotationPoint(0.0F, 0.0F, 0.0F);
  }
}

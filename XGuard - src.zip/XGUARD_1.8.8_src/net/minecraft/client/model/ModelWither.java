package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.util.MathHelper;

public class ModelWither
  extends ModelBase
{
  private static void llIlIllIIlIllI()
  {
    lIIIllIIllIll = new int[15];
    lIIIllIIllIll[0] = ('Ñ' + 25 - 143 + 122 ^ 101 + 124 - 203 + 127);
    lIIIllIIllIll[1] = "   ".length();
    lIIIllIIllIll[2] = ((0xAE ^ 0xA0) & (0xBF ^ 0xB1 ^ 0xFFFFFFFF));
    lIIIllIIllIll[3] = (0x8C ^ 0x9C);
    lIIIllIIllIll[4] = (0x17 ^ 0x3);
    lIIIllIIllIll[5] = " ".length();
    lIIIllIIllIll[6] = (0xBF ^ 0x9E ^ 0xF ^ 0x38);
    lIIIllIIllIll[7] = (0xA3 ^ 0x94 ^ 0x14 ^ 0x29);
    lIIIllIIllIll[8] = (0x26 ^ 0x3E);
    lIIIllIIllIll[9] = (0xDC ^ 0xAC ^ 0x76 ^ 0xD);
    lIIIllIIllIll[10] = "  ".length();
    lIIIllIIllIll[11] = (0x6D ^ 0x32 ^ 0xF9 ^ 0xAA);
    lIIIllIIllIll[12] = (0x9 ^ 0x17 ^ 0x9B ^ 0x83);
    lIIIllIIllIll[13] = (0x23 ^ 0x2B);
    lIIIllIIllIll[14] = (0xF ^ 0x2F);
  }
  
  public ModelWither(float llllllllllllllIlIIllIIIllIIIlIIl)
  {
    textureWidth = lIIIllIIllIll[0];
    textureHeight = lIIIllIIllIll[0];
    field_82905_a[lIIIllIIllIll[2]] = new ModelRenderer(llllllllllllllIlIIllIIIllIIIlIlI, lIIIllIIllIll[2], lIIIllIIllIll[3]);
    field_82905_a[lIIIllIIllIll[2]].addBox(-10.0F, 3.9F, -0.5F, lIIIllIIllIll[4], lIIIllIIllIll[1], lIIIllIIllIll[1], llllllllllllllIlIIllIIIllIIIlIIl);
    field_82905_a[lIIIllIIllIll[5]] = new ModelRenderer(llllllllllllllIlIIllIIIllIIIlIlI).setTextureSize(textureWidth, textureHeight);
    field_82905_a[lIIIllIIllIll[5]].setRotationPoint(-2.0F, 6.9F, -0.5F);
    field_82905_a[lIIIllIIllIll[5]].setTextureOffset(lIIIllIIllIll[2], lIIIllIIllIll[6]).addBox(0.0F, 0.0F, 0.0F, lIIIllIIllIll[1], lIIIllIIllIll[7], lIIIllIIllIll[1], llllllllllllllIlIIllIIIllIIIlIIl);
    field_82905_a[lIIIllIIllIll[5]].setTextureOffset(lIIIllIIllIll[8], lIIIllIIllIll[6]).addBox(-4.0F, 1.5F, 0.5F, lIIIllIIllIll[9], lIIIllIIllIll[10], lIIIllIIllIll[10], llllllllllllllIlIIllIIIllIIIlIIl);
    field_82905_a[lIIIllIIllIll[5]].setTextureOffset(lIIIllIIllIll[8], lIIIllIIllIll[6]).addBox(-4.0F, 4.0F, 0.5F, lIIIllIIllIll[9], lIIIllIIllIll[10], lIIIllIIllIll[10], llllllllllllllIlIIllIIIllIIIlIIl);
    field_82905_a[lIIIllIIllIll[5]].setTextureOffset(lIIIllIIllIll[8], lIIIllIIllIll[6]).addBox(-4.0F, 6.5F, 0.5F, lIIIllIIllIll[9], lIIIllIIllIll[10], lIIIllIIllIll[10], llllllllllllllIlIIllIIIllIIIlIIl);
    field_82905_a[lIIIllIIllIll[10]] = new ModelRenderer(llllllllllllllIlIIllIIIllIIIlIlI, lIIIllIIllIll[11], lIIIllIIllIll[6]);
    field_82905_a[lIIIllIIllIll[10]].addBox(0.0F, 0.0F, 0.0F, lIIIllIIllIll[1], lIIIllIIllIll[12], lIIIllIIllIll[1], llllllllllllllIlIIllIIIllIIIlIIl);
    field_82904_b = new ModelRenderer[lIIIllIIllIll[1]];
    field_82904_b[lIIIllIIllIll[2]] = new ModelRenderer(llllllllllllllIlIIllIIIllIIIlIlI, lIIIllIIllIll[2], lIIIllIIllIll[2]);
    field_82904_b[lIIIllIIllIll[2]].addBox(-4.0F, -4.0F, -4.0F, lIIIllIIllIll[13], lIIIllIIllIll[13], lIIIllIIllIll[13], llllllllllllllIlIIllIIIllIIIlIIl);
    field_82904_b[lIIIllIIllIll[5]] = new ModelRenderer(llllllllllllllIlIIllIIIllIIIlIlI, lIIIllIIllIll[14], lIIIllIIllIll[2]);
    field_82904_b[lIIIllIIllIll[5]].addBox(-4.0F, -4.0F, -4.0F, lIIIllIIllIll[12], lIIIllIIllIll[12], lIIIllIIllIll[12], llllllllllllllIlIIllIIIllIIIlIIl);
    field_82904_b[lIIIllIIllIll[5]].rotationPointX = -8.0F;
    field_82904_b[lIIIllIIllIll[5]].rotationPointY = 4.0F;
    field_82904_b[lIIIllIIllIll[10]] = new ModelRenderer(llllllllllllllIlIIllIIIllIIIlIlI, lIIIllIIllIll[14], lIIIllIIllIll[2]);
    field_82904_b[lIIIllIIllIll[10]].addBox(-4.0F, -4.0F, -4.0F, lIIIllIIllIll[12], lIIIllIIllIll[12], lIIIllIIllIll[12], llllllllllllllIlIIllIIIllIIIlIIl);
    field_82904_b[lIIIllIIllIll[10]].rotationPointX = 10.0F;
    field_82904_b[lIIIllIIllIll[10]].rotationPointY = 4.0F;
  }
  
  public void setLivingAnimations(EntityLivingBase llllllllllllllIlIIllIIIlIlIIlllI, float llllllllllllllIlIIllIIIlIlIIllIl, float llllllllllllllIlIIllIIIlIlIIllII, float llllllllllllllIlIIllIIIlIlIIlIll)
  {
    ;
    ;
    ;
    ;
    EntityWither llllllllllllllIlIIllIIIlIlIIlIlI = (EntityWither)llllllllllllllIlIIllIIIlIlIIlllI;
    int llllllllllllllIlIIllIIIlIlIIlIIl = lIIIllIIllIll[5];
    "".length();
    if (null != null) {
      return;
    }
    while (!llIlIllIIlIlll(llllllllllllllIlIIllIIIlIlIIlIIl, lIIIllIIllIll[1]))
    {
      field_82904_b[llllllllllllllIlIIllIIIlIlIIlIIl].rotateAngleY = ((llllllllllllllIlIIllIIIlIlIIlIlI.func_82207_a(llllllllllllllIlIIllIIIlIlIIlIIl - lIIIllIIllIll[5]) - renderYawOffset) / 57.295776F);
      field_82904_b[llllllllllllllIlIIllIIIlIlIIlIIl].rotateAngleX = (llllllllllllllIlIIllIIIlIlIIlIlI.func_82210_r(llllllllllllllIlIIllIIIlIlIIlIIl - lIIIllIIllIll[5]) / 57.295776F);
      llllllllllllllIlIIllIIIlIlIIlIIl++;
    }
  }
  
  public void render(Entity llllllllllllllIlIIllIIIlIlllIIIl, float llllllllllllllIlIIllIIIlIllllIlI, float llllllllllllllIlIIllIIIlIllIllll, float llllllllllllllIlIIllIIIlIllllIII, float llllllllllllllIlIIllIIIlIlllIlll, float llllllllllllllIlIIllIIIlIllIllII, float llllllllllllllIlIIllIIIlIllIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIllIIIlIlllIIlI.setRotationAngles(llllllllllllllIlIIllIIIlIllllIlI, llllllllllllllIlIIllIIIlIllIllll, llllllllllllllIlIIllIIIlIllllIII, llllllllllllllIlIIllIIIlIlllIlll, llllllllllllllIlIIllIIIlIllIllII, llllllllllllllIlIIllIIIlIllIlIll, llllllllllllllIlIIllIIIlIlllIIIl);
    long llllllllllllllIlIIllIIIlIllIlIII = (llllllllllllllIlIIllIIIlIllIIlll = field_82904_b).length;
    double llllllllllllllIlIIllIIIlIllIlIIl = lIIIllIIllIll[2];
    "".length();
    if ((0xA6 ^ 0xA2) != (0x9A ^ 0x9E)) {
      return;
    }
    while (!llIlIllIIlIlll(llllllllllllllIlIIllIIIlIllIlIIl, llllllllllllllIlIIllIIIlIllIlIII))
    {
      ModelRenderer llllllllllllllIlIIllIIIlIlllIlII = llllllllllllllIlIIllIIIlIllIIlll[llllllllllllllIlIIllIIIlIllIlIIl];
      llllllllllllllIlIIllIIIlIlllIlII.render(llllllllllllllIlIIllIIIlIllIlIll);
      llllllllllllllIlIIllIIIlIllIlIIl++;
    }
    llllllllllllllIlIIllIIIlIllIlIII = (llllllllllllllIlIIllIIIlIllIIlll = field_82905_a).length;
    llllllllllllllIlIIllIIIlIllIlIIl = lIIIllIIllIll[2];
    "".length();
    if (null != null) {
      return;
    }
    while (!llIlIllIIlIlll(llllllllllllllIlIIllIIIlIllIlIIl, llllllllllllllIlIIllIIIlIllIlIII))
    {
      ModelRenderer llllllllllllllIlIIllIIIlIlllIIll = llllllllllllllIlIIllIIIlIllIIlll[llllllllllllllIlIIllIIIlIllIlIIl];
      llllllllllllllIlIIllIIIlIlllIIll.render(llllllllllllllIlIIllIIIlIllIlIll);
      llllllllllllllIlIIllIIIlIllIlIIl++;
    }
  }
  
  static {}
  
  public void setRotationAngles(float llllllllllllllIlIIllIIIlIllIIIII, float llllllllllllllIlIIllIIIlIlIlllll, float llllllllllllllIlIIllIIIlIlIlIlll, float llllllllllllllIlIIllIIIlIlIlllIl, float llllllllllllllIlIIllIIIlIlIlIlIl, float llllllllllllllIlIIllIIIlIlIllIll, Entity llllllllllllllIlIIllIIIlIlIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIlIIllIIIlIlIllIIl = MathHelper.cos(llllllllllllllIlIIllIIIlIlIlIlll * 0.1F);
    field_82905_a[lIIIllIIllIll[5]].rotateAngleX = ((0.065F + 0.05F * llllllllllllllIlIIllIIIlIlIllIIl) * 3.1415927F);
    field_82905_a[lIIIllIIllIll[10]].setRotationPoint(-2.0F, 6.9F + MathHelper.cos(field_82905_a[lIIIllIIllIll[5]].rotateAngleX) * 10.0F, -0.5F + MathHelper.sin(field_82905_a[lIIIllIIllIll[5]].rotateAngleX) * 10.0F);
    field_82905_a[lIIIllIIllIll[10]].rotateAngleX = ((0.265F + 0.1F * llllllllllllllIlIIllIIIlIlIllIIl) * 3.1415927F);
    field_82904_b[lIIIllIIllIll[2]].rotateAngleY = (llllllllllllllIlIIllIIIlIlIlllIl / 57.295776F);
    field_82904_b[lIIIllIIllIll[2]].rotateAngleX = (llllllllllllllIlIIllIIIlIlIlIlIl / 57.295776F);
  }
  
  private static boolean llIlIllIIlIlll(int ???, int arg1)
  {
    int i;
    short llllllllllllllIlIIllIIIlIlIIIIIl;
    return ??? >= i;
  }
}

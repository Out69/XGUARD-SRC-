package net.minecraft.client.model;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import pl.xguard.loaders.ItemMadufakaSrakaManager;
import pl.xguard.loaders.OgunekManager;
import pl.xguard.loaders.WingsManager;
import pl.xguard.models.ItemikiSrikiOdPatyki;
import pl.xguard.models.Ogunek;
import pl.xguard.models.WingsModel;
import pl.xguard.modules.WingsModule;

public class ModelPlayer
  extends ModelBiped
{
  public void postRenderArm(float lllllllllllllllllllIlllllIlllIIl)
  {
    ;
    ;
    if (lIIlIlllllIl(smallArms))
    {
      bipedRightArm.rotationPointX += 1.0F;
      bipedRightArm.postRender(lllllllllllllllllllIlllllIlllIIl);
      bipedRightArm.rotationPointX -= 1.0F;
      "".length();
      if ("   ".length() >= ((57 + 62 - 81 + 90 ^ '' + 26 - 144 + 140) & (0xB5 ^ 0x89 ^ 0x34 ^ 0x39 ^ -" ".length()))) {}
    }
    else
    {
      bipedRightArm.postRender(lllllllllllllllllllIlllllIlllIIl);
    }
  }
  
  public void renderDeadmau5Head(float lllllllllllllllllllIlllllllIlIll)
  {
    ;
    ;
    copyModelAngles(bipedHead, bipedDeadmau5Head);
    bipedDeadmau5Head.rotationPointX = 0.0F;
    bipedDeadmau5Head.rotationPointY = 0.0F;
    bipedDeadmau5Head.render(lllllllllllllllllllIlllllllIlIll);
  }
  
  private static void lIIlIlllllII()
  {
    lIllllllII = new int[20];
    lIllllllII[0] = (0x36 ^ 0x4 ^ 0xF ^ 0x7D);
    lIllllllII[1] = (0xD ^ 0x15);
    lIllllllII[2] = ((0x24 ^ 0x7A) & (0x7D ^ 0x23 ^ 0xFFFFFFFF));
    lIllllllII[3] = (0xC6 ^ 0x92 ^ 0xD7 ^ 0x85);
    lIllllllII[4] = " ".length();
    lIllllllII[5] = (0x54 ^ 0x1A ^ 0xC5 ^ 0xAB);
    lIllllllII[6] = (56 + 87 - 22 + 18 ^ 11 + 105 - 61 + 74);
    lIllllllII[7] = (0x82 ^ 0xA1 ^ 0xAB ^ 0x98);
    lIllllllII[8] = ((0x92 ^ 0xAE) + (0x13 ^ 0x3B) - (0x5 ^ 0x5D) + (0x63 ^ 0x17));
    lIllllllII[9] = "  ".length();
    lIllllllII[10] = (0xE9 ^ 0xA5);
    lIllllllII[11] = (0x69 ^ 0x6E);
    lIllllllII[12] = (0x2 ^ 0x6);
    lIllllllII[13] = (0x45 ^ 0x4 ^ 0x51 ^ 0x47);
    lIllllllII[14] = (4 + 58 - 58 + 148 ^ 14 + 109 - -4 + 72);
    lIllllllII[15] = (0x60 ^ 0x50);
    lIllllllII[16] = "   ".length();
    lIllllllII[17] = (0x8B ^ 0x87);
    lIllllllII[18] = (0x64 ^ 0x5 ^ 0x5E ^ 0x17);
    lIllllllII[19] = (0x8A ^ 0x9E ^ 0x83 ^ 0x9F);
  }
  
  private static boolean lIIlIlllllIl(int ???)
  {
    double lllllllllllllllllllIlllllIIIllII;
    return ??? != 0;
  }
  
  private static boolean lIIlIlllllll(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllllllIlllllIIlIIII;
    return ??? < i;
  }
  
  private static String lIIlIlIIllII(String lllllllllllllllllllIlllllIllIIIl, String lllllllllllllllllllIlllllIlIlllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllllIlllllIllIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIlllllIlIlllI.getBytes(StandardCharsets.UTF_8)), lIllllllII[19]), "DES");
      Cipher lllllllllllllllllllIlllllIllIIll = Cipher.getInstance("DES");
      lllllllllllllllllllIlllllIllIIll.init(lIllllllII[9], lllllllllllllllllllIlllllIllIlII);
      return new String(lllllllllllllllllllIlllllIllIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIlllllIllIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllllIlllllIllIIlI)
    {
      lllllllllllllllllllIlllllIllIIlI.printStackTrace();
    }
    return null;
  }
  
  public void setInvisible(boolean lllllllllllllllllllIlllllIllllll)
  {
    ;
    ;
    lllllllllllllllllllIllllllIIIIII.setInvisible(lllllllllllllllllllIlllllIllllll);
    bipedLeftArmwear.showModel = lllllllllllllllllllIlllllIllllll;
    bipedRightArmwear.showModel = lllllllllllllllllllIlllllIllllll;
    bipedLeftLegwear.showModel = lllllllllllllllllllIlllllIllllll;
    bipedRightLegwear.showModel = lllllllllllllllllllIlllllIllllll;
    bipedBodyWear.showModel = lllllllllllllllllllIlllllIllllll;
    bipedCape.showModel = lllllllllllllllllllIlllllIllllll;
    bipedDeadmau5Head.showModel = lllllllllllllllllllIlllllIllllll;
  }
  
  public ModelPlayer(float llllllllllllllllllllIIIIIIIIlllI, boolean llllllllllllllllllllIIIIIIIIllIl)
  {
    llllllllllllllllllllIIIIIIIIllll.<init>(llllllllllllllllllllIIIIIIIlIlII, 0.0F, lIllllllII[0], lIllllllII[0]);
    smallArms = llllllllllllllllllllIIIIIIIIllIl;
    bipedDeadmau5Head = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[1], lIllllllII[2]);
    bipedDeadmau5Head.addBox(-3.0F, -6.0F, -1.0F, lIllllllII[3], lIllllllII[3], lIllllllII[4], llllllllllllllllllllIIIIIIIlIlII);
    bipedCape = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[2], lIllllllII[2]);
    "".length();
    bipedCape.addBox(-5.0F, 0.0F, -1.0F, lIllllllII[6], lIllllllII[7], lIllllllII[4], llllllllllllllllllllIIIIIIIlIlII);
    bipedHat = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll).setTextureSize(lIllllllII[0], lIllllllII[8]);
    bipedHat.setRotationPoint(-5.0F, -10.03125F, -5.0F);
    "".length();
    ModelRenderer llllllllllllllllllllIIIIIIIlIIlI = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll).setTextureSize(lIllllllII[0], lIllllllII[8]);
    llllllllllllllllllllIIIIIIIlIIlI.setRotationPoint(1.75F, -4.0F, 2.0F);
    "".length();
    rotateAngleX = -0.05235988F;
    rotateAngleZ = 0.02617994F;
    bipedHat.addChild(llllllllllllllllllllIIIIIIIlIIlI);
    ModelRenderer llllllllllllllllllllIIIIIIIlIIIl = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll).setTextureSize(lIllllllII[0], lIllllllII[8]);
    llllllllllllllllllllIIIIIIIlIIIl.setRotationPoint(1.75F, -4.0F, 2.0F);
    "".length();
    rotateAngleX = -0.10471976F;
    rotateAngleZ = 0.05235988F;
    llllllllllllllllllllIIIIIIIlIIlI.addChild(llllllllllllllllllllIIIIIIIlIIIl);
    ModelRenderer llllllllllllllllllllIIIIIIIlIIII = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll).setTextureSize(lIllllllII[0], lIllllllII[8]);
    llllllllllllllllllllIIIIIIIlIIII.setRotationPoint(1.75F, -2.0F, 2.0F);
    llllllllllllllllllllIIIIIIIlIIII.setTextureOffset(lIllllllII[2], lIllllllII[14]).addBox(-6.0F, -7.0F, -5.0F, lIllllllII[4], lIllllllII[9], lIllllllII[4], 0.25F);
    rotateAngleX = -0.20943952F;
    rotateAngleZ = 0.10471976F;
    llllllllllllllllllllIIIIIIIlIIIl.addChild(llllllllllllllllllllIIIIIIIlIIII);
    if (lIIlIlllllIl(llllllllllllllllllllIIIIIIIIllIl))
    {
      bipedLeftArm = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[5], lIllllllII[15]);
      bipedLeftArm.addBox(-1.0F, -2.0F, -2.0F, lIllllllII[16], lIllllllII[17], lIllllllII[12], llllllllllllllllllllIIIIIIIlIlII);
      bipedLeftArm.setRotationPoint(5.0F, 2.5F, 0.0F);
      bipedRightArm = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[18], lIllllllII[7]);
      bipedRightArm.addBox(-2.0F, -2.0F, -2.0F, lIllllllII[16], lIllllllII[17], lIllllllII[12], llllllllllllllllllllIIIIIIIlIlII);
      bipedRightArm.setRotationPoint(-5.0F, 2.5F, 0.0F);
      bipedLeftArmwear = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[15], lIllllllII[15]);
      bipedLeftArmwear.addBox(-1.0F, -2.0F, -2.0F, lIllllllII[16], lIllllllII[17], lIllllllII[12], llllllllllllllllllllIIIIIIIlIlII + 0.25F);
      bipedLeftArmwear.setRotationPoint(5.0F, 2.5F, 0.0F);
      bipedRightArmwear = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[18], lIllllllII[5]);
      bipedRightArmwear.addBox(-2.0F, -2.0F, -2.0F, lIllllllII[16], lIllllllII[17], lIllllllII[12], llllllllllllllllllllIIIIIIIlIlII + 0.25F);
      bipedRightArmwear.setRotationPoint(-5.0F, 2.5F, 10.0F);
      "".length();
      if (-"   ".length() >= 0) {
        throw null;
      }
    }
    else
    {
      bipedLeftArm = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[5], lIllllllII[15]);
      bipedLeftArm.addBox(-1.0F, -2.0F, -2.0F, lIllllllII[12], lIllllllII[17], lIllllllII[12], llllllllllllllllllllIIIIIIIlIlII);
      bipedLeftArm.setRotationPoint(5.0F, 2.0F, 0.0F);
      bipedLeftArmwear = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[15], lIllllllII[15]);
      bipedLeftArmwear.addBox(-1.0F, -2.0F, -2.0F, lIllllllII[12], lIllllllII[17], lIllllllII[12], llllllllllllllllllllIIIIIIIlIlII + 0.25F);
      bipedLeftArmwear.setRotationPoint(5.0F, 2.0F, 0.0F);
      bipedRightArmwear = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[18], lIllllllII[5]);
      bipedRightArmwear.addBox(-3.0F, -2.0F, -2.0F, lIllllllII[12], lIllllllII[17], lIllllllII[12], llllllllllllllllllllIIIIIIIlIlII + 0.25F);
      bipedRightArmwear.setRotationPoint(-5.0F, 2.0F, 10.0F);
    }
    bipedLeftLeg = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[7], lIllllllII[15]);
    bipedLeftLeg.addBox(-2.0F, 0.0F, -2.0F, lIllllllII[12], lIllllllII[17], lIllllllII[12], llllllllllllllllllllIIIIIIIlIlII);
    bipedLeftLeg.setRotationPoint(1.9F, 12.0F, 0.0F);
    bipedLeftLegwear = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[2], lIllllllII[15]);
    bipedLeftLegwear.addBox(-2.0F, 0.0F, -2.0F, lIllllllII[12], lIllllllII[17], lIllllllII[12], llllllllllllllllllllIIIIIIIlIlII + 0.25F);
    bipedLeftLegwear.setRotationPoint(1.9F, 12.0F, 0.0F);
    bipedRightLegwear = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[2], lIllllllII[5]);
    bipedRightLegwear.addBox(-2.0F, 0.0F, -2.0F, lIllllllII[12], lIllllllII[17], lIllllllII[12], llllllllllllllllllllIIIIIIIlIlII + 0.25F);
    bipedRightLegwear.setRotationPoint(-1.9F, 12.0F, 0.0F);
    bipedBodyWear = new ModelRenderer(llllllllllllllllllllIIIIIIIIllll, lIllllllII[7], lIllllllII[5]);
    bipedBodyWear.addBox(-4.0F, 0.0F, -2.0F, lIllllllII[19], lIllllllII[17], lIllllllII[12], llllllllllllllllllllIIIIIIIlIlII + 0.25F);
    bipedBodyWear.setRotationPoint(0.0F, 0.0F, 0.0F);
    wingsModel = new WingsModel();
    itemModel = new ItemikiSrikiOdPatyki();
    tailsModel = new Ogunek();
  }
  
  public void render(Entity lllllllllllllllllllIllllllllllll, float lllllllllllllllllllIllllllllIlIl, float lllllllllllllllllllIllllllllIlII, float lllllllllllllllllllIllllllllllII, float lllllllllllllllllllIllllllllIIlI, float lllllllllllllllllllIllllllllIIIl, float lllllllllllllllllllIllllllllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIllllllllIlll.render(lllllllllllllllllllIllllllllllll, lllllllllllllllllllIllllllllIlIl, lllllllllllllllllllIllllllllIlII, lllllllllllllllllllIllllllllllII, lllllllllllllllllllIllllllllIIlI, lllllllllllllllllllIllllllllIIIl, lllllllllllllllllllIllllllllIIII);
    GlStateManager.pushMatrix();
    if (lIIlIlllllIl(isChild))
    {
      float lllllllllllllllllllIlllllllllIII = 2.0F;
      GlStateManager.scale(1.0F / lllllllllllllllllllIlllllllllIII, 1.0F / lllllllllllllllllllIlllllllllIII, 1.0F / lllllllllllllllllllIlllllllllIII);
      GlStateManager.translate(0.0F, 24.0F * lllllllllllllllllllIllllllllIIII, 0.0F);
      bipedLeftLegwear.render(lllllllllllllllllllIllllllllIIII);
      bipedRightLegwear.render(lllllllllllllllllllIllllllllIIII);
      bipedLeftArmwear.render(lllllllllllllllllllIllllllllIIII);
      bipedRightArmwear.render(lllllllllllllllllllIllllllllIIII);
      bipedBodyWear.render(lllllllllllllllllllIllllllllIIII);
      bipedHatImg = new ResourceLocation(lIlllIllIl[lIllllllII[2]]);
      Minecraft.getMinecraft().getTextureManager().bindTexture(bipedHatImg);
      bipedHat.render(lllllllllllllllllllIllllllllIIII);
      "".length();
      if (((0x6 ^ 0x19) & (0x56 ^ 0x49 ^ 0xFFFFFFFF)) >= 0) {}
    }
    else
    {
      if (lIIlIlllllIl(lllllllllllllllllllIllllllllllll.isSneaking())) {
        GlStateManager.translate(0.0F, 0.2F, 0.0F);
      }
      bipedLeftLegwear.render(lllllllllllllllllllIllllllllIIII);
      bipedRightLegwear.render(lllllllllllllllllllIllllllllIIII);
      bipedLeftArmwear.render(lllllllllllllllllllIllllllllIIII);
      bipedRightArmwear.render(lllllllllllllllllllIllllllllIIII);
      bipedBodyWear.render(lllllllllllllllllllIllllllllIIII);
      bipedHatImg = new ResourceLocation(lIlllIllIl[lIllllllII[4]]);
      Minecraft.getMinecraft().getTextureManager().bindTexture(bipedHatImg);
      bipedHat.render(lllllllllllllllllllIllllllllIIII);
    }
    if ((lIIlIlllllIl(WingsModule.isEnabled())) && (lIIlIlllllIl(ItemMadufakaSrakaManager.haveWings(lllllllllllllllllllIllllllllllll.getName())))) {
      itemModel.render(bipedLeftArm, lllllllllllllllllllIllllllllIIII, ItemMadufakaSrakaManager.getWingsID(lllllllllllllllllllIllllllllllll.getName()));
    }
    if ((lIIlIlllllIl(WingsModule.isEnabled())) && (lIIlIlllllIl(OgunekManager.haveWings(lllllllllllllllllllIllllllllllll.getName())))) {
      tailsModel.render(getMinecraftthePlayer, lllllllllllllllllllIllllllllllll.isSneaking(), OgunekManager.getWingsID(lllllllllllllllllllIllllllllllll.getName()));
    }
    if (lIIlIlllllIl(WingsModule.isEnabled())) {
      if (lIIlIllllllI(getMinecraftthePlayer))
      {
        if (lIIlIlllllIl(WingsManager.haveWings(lllllllllllllllllllIllllllllllll.getName())))
        {
          wingsModel.init(WingsManager.getWingsID(lllllllllllllllllllIllllllllllll.getName()));
          wingsModel.render(getMinecraftthePlayer, lllllllllllllllllllIllllllllllll.isSneaking());
        }
        GlStateManager.popMatrix();
        "".length();
        if (null == null) {}
      }
      else
      {
        GlStateManager.popMatrix();
      }
    }
  }
  
  static
  {
    lIIlIlllllII();
    lIIlIlIIllIl();
  }
  
  public void renderCape(float lllllllllllllllllllIlllllllIIIll)
  {
    ;
    ;
    bipedCape.render(lllllllllllllllllllIlllllllIIIll);
  }
  
  private static boolean lIIlIllllllI(Object ???)
  {
    short lllllllllllllllllllIlllllIIIlllI;
    return ??? != null;
  }
  
  public void setRotationAngles(float lllllllllllllllllllIllllllIllIIl, float lllllllllllllllllllIllllllIllIII, float lllllllllllllllllllIllllllIIllll, float lllllllllllllllllllIllllllIIlllI, float lllllllllllllllllllIllllllIlIlIl, float lllllllllllllllllllIllllllIIllII, Entity lllllllllllllllllllIllllllIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIllllllIlIIlI.setRotationAngles(lllllllllllllllllllIllllllIllIIl, lllllllllllllllllllIllllllIllIII, lllllllllllllllllllIllllllIIllll, lllllllllllllllllllIllllllIIlllI, lllllllllllllllllllIllllllIlIlIl, lllllllllllllllllllIllllllIIllII, lllllllllllllllllllIllllllIlIIll);
    copyModelAngles(bipedLeftLeg, bipedLeftLegwear);
    copyModelAngles(bipedRightLeg, bipedRightLegwear);
    copyModelAngles(bipedLeftArm, bipedLeftArmwear);
    copyModelAngles(bipedRightArm, bipedRightArmwear);
    copyModelAngles(bipedBody, bipedBodyWear);
    copyModelAngles(bipedHead, bipedHat);
  }
  
  private static void lIIlIlIIllIl()
  {
    lIlllIllIl = new String[lIllllllII[16]];
    lIlllIllIl[lIllllllII[2]] = lIIlIlIIlIll("FQs+BgwTCzVdEQAaaRoYFV9oAhcG", "anFry");
    lIlllIllIl[lIllllllII[4]] = lIIlIlIIllII("zAtnLklR15bo8mBVqY8NsGwHJfqtdfXk", "CKVoP");
    lIlllIllIl[lIllllllII[9]] = lIIlIlIIlIll("NDkxWWVHRVxfZ0E=", "wuniU");
  }
  
  public void renderRightArm()
  {
    ;
    bipedRightArm.render(0.0625F);
    bipedRightArmwear.render(0.0625F);
  }
  
  public void renderLeftArm()
  {
    ;
    bipedLeftArm.render(0.0625F);
    bipedLeftArmwear.render(0.0625F);
  }
  
  private static String lIIlIlIIlIll(String lllllllllllllllllllIlllllIIlllII, String lllllllllllllllllllIlllllIIllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIlllllIIlllII = new String(Base64.getDecoder().decode(lllllllllllllllllllIlllllIIlllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllllIlllllIIlllll = new StringBuilder();
    char[] lllllllllllllllllllIlllllIIllllI = lllllllllllllllllllIlllllIIllIll.toCharArray();
    int lllllllllllllllllllIlllllIIlllIl = lIllllllII[2];
    int lllllllllllllllllllIlllllIIlIlll = lllllllllllllllllllIlllllIIlllII.toCharArray();
    String lllllllllllllllllllIlllllIIlIllI = lllllllllllllllllllIlllllIIlIlll.length;
    String lllllllllllllllllllIlllllIIlIlIl = lIllllllII[2];
    while (lIIlIlllllll(lllllllllllllllllllIlllllIIlIlIl, lllllllllllllllllllIlllllIIlIllI))
    {
      char lllllllllllllllllllIlllllIlIIIlI = lllllllllllllllllllIlllllIIlIlll[lllllllllllllllllllIlllllIIlIlIl];
      "".length();
      "".length();
      if ("   ".length() < ((0x3A ^ 0x72 ^ 0xDD ^ 0xB7) & (0xD9 ^ 0xAB ^ 0x1F ^ 0x4F ^ -" ".length()))) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllllIlllllIIlllll);
  }
}

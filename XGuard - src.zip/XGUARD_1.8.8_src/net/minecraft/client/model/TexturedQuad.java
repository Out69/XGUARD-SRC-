package net.minecraft.client.model;

import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.Vec3;

public class TexturedQuad
{
  private static boolean lIlllIIlIIIIII(int ???, int arg1)
  {
    int i;
    String llllllllllllllIllIlIllIIlllllIll;
    return ??? >= i;
  }
  
  public TexturedQuad(PositionTextureVertex[] llllllllllllllIllIlIllIlIlIIIlll)
  {
    vertexPositions = llllllllllllllIllIlIllIlIlIIIlll;
    nVertices = llllllllllllllIllIlIllIlIlIIIlll.length;
  }
  
  static {}
  
  private static void lIlllIIIllllll()
  {
    llllIIlIlllI = new int[6];
    llllIIlIlllI[0] = (" ".length() & (" ".length() ^ 0xFFFFFFFF));
    llllIIlIlllI[1] = " ".length();
    llllIIlIlllI[2] = "  ".length();
    llllIIlIlllI[3] = "   ".length();
    llllIIlIlllI[4] = (0x34 ^ 0x5B ^ 0x36 ^ 0x5E);
    llllIIlIlllI[5] = (8 + '' - -23 + 4 ^ 56 + 44 - 45 + 106);
  }
  
  private static boolean lIlllIIlIIIIIl(int ???)
  {
    float llllllllllllllIllIlIllIIlllllIIl;
    return ??? != 0;
  }
  
  public void flipFace()
  {
    ;
    ;
    ;
    PositionTextureVertex[] llllllllllllllIllIlIllIlIIlIIlII = new PositionTextureVertex[vertexPositions.length];
    int llllllllllllllIllIlIllIlIIlIIIll = llllIIlIlllI[0];
    "".length();
    if (-" ".length() > 0) {
      return;
    }
    while (!lIlllIIlIIIIII(llllllllllllllIllIlIllIlIIlIIIll, vertexPositions.length))
    {
      llllllllllllllIllIlIllIlIIlIIlII[llllllllllllllIllIlIllIlIIlIIIll] = vertexPositions[(vertexPositions.length - llllllllllllllIllIlIllIlIIlIIIll - llllIIlIlllI[1])];
      llllllllllllllIllIlIllIlIIlIIIll++;
    }
    vertexPositions = llllllllllllllIllIlIllIlIIlIIlII;
  }
  
  public void draw(WorldRenderer llllllllllllllIllIlIllIlIIIlIIll, float llllllllllllllIllIlIllIlIIIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Vec3 llllllllllllllIllIlIllIlIIIlIIIl = vertexPositions[llllIIlIlllI[1]].vector3D.subtractReverse(vertexPositions[llllIIlIlllI[0]].vector3D);
    Vec3 llllllllllllllIllIlIllIlIIIlIIII = vertexPositions[llllIIlIlllI[1]].vector3D.subtractReverse(vertexPositions[llllIIlIlllI[2]].vector3D);
    Vec3 llllllllllllllIllIlIllIlIIIIllll = llllllllllllllIllIlIllIlIIIlIIII.crossProduct(llllllllllllllIllIlIllIlIIIlIIIl).normalize();
    float llllllllllllllIllIlIllIlIIIIlllI = (float)xCoord;
    float llllllllllllllIllIlIllIlIIIIllIl = (float)yCoord;
    float llllllllllllllIllIlIllIlIIIIllII = (float)zCoord;
    if (lIlllIIlIIIIIl(invertNormal))
    {
      llllllllllllllIllIlIllIlIIIIlllI = -llllllllllllllIllIlIllIlIIIIlllI;
      llllllllllllllIllIlIllIlIIIIllIl = -llllllllllllllIllIlIllIlIIIIllIl;
      llllllllllllllIllIlIllIlIIIIllII = -llllllllllllllIllIlIllIlIIIIllII;
    }
    llllllllllllllIllIlIllIlIIIIlIII.begin(llllIIlIlllI[4], DefaultVertexFormats.OLDMODEL_POSITION_TEX_NORMAL);
    int llllllllllllllIllIlIllIlIIIIlIll = llllIIlIlllI[0];
    "".length();
    if ("  ".length() < 0) {
      return;
    }
    while (!lIlllIIlIIIIII(llllllllllllllIllIlIllIlIIIIlIll, llllIIlIlllI[5]))
    {
      PositionTextureVertex llllllllllllllIllIlIllIlIIIIlIlI = vertexPositions[llllllllllllllIllIlIllIlIIIIlIll];
      llllllllllllllIllIlIllIlIIIIlIII.pos(vector3D.xCoord * llllllllllllllIllIlIllIlIIIIIlll, vector3D.yCoord * llllllllllllllIllIlIllIlIIIIIlll, vector3D.zCoord * llllllllllllllIllIlIllIlIIIIIlll).tex(texturePositionX, texturePositionY).normal(llllllllllllllIllIlIllIlIIIIlllI, llllllllllllllIllIlIllIlIIIIllIl, llllllllllllllIllIlIllIlIIIIllII).endVertex();
      llllllllllllllIllIlIllIlIIIIlIll++;
    }
    Tessellator.getInstance().draw();
  }
  
  public TexturedQuad(PositionTextureVertex[] llllllllllllllIllIlIllIlIIllIIIl, int llllllllllllllIllIlIllIlIIllIIII, int llllllllllllllIllIlIllIlIIlIllll, int llllllllllllllIllIlIllIlIIlllIII, int llllllllllllllIllIlIllIlIIllIlll, float llllllllllllllIllIlIllIlIIlIllII, float llllllllllllllIllIlIllIlIIllIlIl)
  {
    llllllllllllllIllIlIllIlIIllllII.<init>(llllllllllllllIllIlIllIlIIllIIIl);
    float llllllllllllllIllIlIllIlIIllIlII = 0.0F / llllllllllllllIllIlIllIlIIlIllII;
    float llllllllllllllIllIlIllIlIIllIIll = 0.0F / llllllllllllllIllIlIllIlIIllIlIl;
    llllllllllllllIllIlIllIlIIllIIIl[llllIIlIlllI[0]] = llllllllllllllIllIlIllIlIIllIIIl[llllIIlIlllI[0]].setTexturePosition(llllllllllllllIllIlIllIlIIlllIII / llllllllllllllIllIlIllIlIIlIllII - llllllllllllllIllIlIllIlIIllIlII, llllllllllllllIllIlIllIlIIlIllll / llllllllllllllIllIlIllIlIIllIlIl + llllllllllllllIllIlIllIlIIllIIll);
    llllllllllllllIllIlIllIlIIllIIIl[llllIIlIlllI[1]] = llllllllllllllIllIlIllIlIIllIIIl[llllIIlIlllI[1]].setTexturePosition(llllllllllllllIllIlIllIlIIllIIII / llllllllllllllIllIlIllIlIIlIllII + llllllllllllllIllIlIllIlIIllIlII, llllllllllllllIllIlIllIlIIlIllll / llllllllllllllIllIlIllIlIIllIlIl + llllllllllllllIllIlIllIlIIllIIll);
    llllllllllllllIllIlIllIlIIllIIIl[llllIIlIlllI[2]] = llllllllllllllIllIlIllIlIIllIIIl[llllIIlIlllI[2]].setTexturePosition(llllllllllllllIllIlIllIlIIllIIII / llllllllllllllIllIlIllIlIIlIllII + llllllllllllllIllIlIllIlIIllIlII, llllllllllllllIllIlIllIlIIllIlll / llllllllllllllIllIlIllIlIIllIlIl - llllllllllllllIllIlIllIlIIllIIll);
    llllllllllllllIllIlIllIlIIllIIIl[llllIIlIlllI[3]] = llllllllllllllIllIlIllIlIIllIIIl[llllIIlIlllI[3]].setTexturePosition(llllllllllllllIllIlIllIlIIlllIII / llllllllllllllIllIlIllIlIIlIllII - llllllllllllllIllIlIllIlIIllIlII, llllllllllllllIllIlIllIlIIllIlll / llllllllllllllIllIlIllIlIIllIlIl - llllllllllllllIllIlIllIlIIllIIll);
  }
}

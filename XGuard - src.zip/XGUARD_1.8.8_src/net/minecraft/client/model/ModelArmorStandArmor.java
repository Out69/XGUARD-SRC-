package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.util.Rotations;

public class ModelArmorStandArmor
  extends ModelBiped
{
  public void setRotationAngles(float lIllIlIllIlIll, float lIllIlIllIlIlI, float lIllIlIllIlIIl, float lIllIlIllIlIII, float lIllIlIllIIlll, float lIllIlIllIIllI, Entity lIllIlIllIIIlI)
  {
    ;
    ;
    ;
    if (lIlIllIllIl(lIllIlIllIIIlI instanceof EntityArmorStand))
    {
      EntityArmorStand lIllIlIllIIlII = (EntityArmorStand)lIllIlIllIIIlI;
      bipedHead.rotateAngleX = (0.017453292F * lIllIlIllIIlII.getHeadRotation().getX());
      bipedHead.rotateAngleY = (0.017453292F * lIllIlIllIIlII.getHeadRotation().getY());
      bipedHead.rotateAngleZ = (0.017453292F * lIllIlIllIIlII.getHeadRotation().getZ());
      bipedHead.setRotationPoint(0.0F, 1.0F, 0.0F);
      bipedBody.rotateAngleX = (0.017453292F * lIllIlIllIIlII.getBodyRotation().getX());
      bipedBody.rotateAngleY = (0.017453292F * lIllIlIllIIlII.getBodyRotation().getY());
      bipedBody.rotateAngleZ = (0.017453292F * lIllIlIllIIlII.getBodyRotation().getZ());
      bipedLeftArm.rotateAngleX = (0.017453292F * lIllIlIllIIlII.getLeftArmRotation().getX());
      bipedLeftArm.rotateAngleY = (0.017453292F * lIllIlIllIIlII.getLeftArmRotation().getY());
      bipedLeftArm.rotateAngleZ = (0.017453292F * lIllIlIllIIlII.getLeftArmRotation().getZ());
      bipedRightArm.rotateAngleX = (0.017453292F * lIllIlIllIIlII.getRightArmRotation().getX());
      bipedRightArm.rotateAngleY = (0.017453292F * lIllIlIllIIlII.getRightArmRotation().getY());
      bipedRightArm.rotateAngleZ = (0.017453292F * lIllIlIllIIlII.getRightArmRotation().getZ());
      bipedLeftLeg.rotateAngleX = (0.017453292F * lIllIlIllIIlII.getLeftLegRotation().getX());
      bipedLeftLeg.rotateAngleY = (0.017453292F * lIllIlIllIIlII.getLeftLegRotation().getY());
      bipedLeftLeg.rotateAngleZ = (0.017453292F * lIllIlIllIIlII.getLeftLegRotation().getZ());
      bipedLeftLeg.setRotationPoint(1.9F, 11.0F, 0.0F);
      bipedRightLeg.rotateAngleX = (0.017453292F * lIllIlIllIIlII.getRightLegRotation().getX());
      bipedRightLeg.rotateAngleY = (0.017453292F * lIllIlIllIIlII.getRightLegRotation().getY());
      bipedRightLeg.rotateAngleZ = (0.017453292F * lIllIlIllIIlII.getRightLegRotation().getZ());
      bipedRightLeg.setRotationPoint(-1.9F, 11.0F, 0.0F);
      copyModelAngles(bipedHead, bipedHeadwear);
    }
  }
  
  public ModelArmorStandArmor(float lIllIlIllllllI)
  {
    lIllIlIlllllll.<init>(lIllIlIllllllI, llIlIIlII[0], llIlIIlII[1]);
  }
  
  static {}
  
  private static void lIlIllIllII()
  {
    llIlIIlII = new int[2];
    llIlIIlII[0] = (0x34 ^ 0x74);
    llIlIIlII[1] = (0x2B ^ 0xB);
  }
  
  private static boolean lIlIllIllIl(int ???)
  {
    double lIllIlIlIlllll;
    return ??? != 0;
  }
  
  protected ModelArmorStandArmor(float lIllIlIlllIllI, int lIllIlIlllIIIl, int lIllIlIlllIlII)
  {
    lIllIlIlllIIll.<init>(lIllIlIlllIllI, 0.0F, lIllIlIlllIIIl, lIllIlIlllIlII);
  }
  
  public ModelArmorStandArmor()
  {
    lIllIllIIIIIll.<init>(0.0F);
  }
}

package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelZombie
  extends ModelBiped
{
  private static void lIllIllllllIIl()
  {
    llllIIIlIlIl = new int[3];
    llllIIIlIlIl[0] = ((86 + 94 - 154 + 114 ^ '' + 71 - 60 + 9) & (0xAC ^ 0xC1 ^ 0x65 ^ 0x12 ^ -" ".length()));
    llllIIIlIlIl[1] = (0x32 ^ 0x72);
    llllIIIlIlIl[2] = (0x61 ^ 0x41);
  }
  
  public void setRotationAngles(float llllllllllllllIllIllIIIlIIIlllll, float llllllllllllllIllIllIIIlIIIllllI, float llllllllllllllIllIllIIIlIIIlllIl, float llllllllllllllIllIllIIIlIIIlllII, float llllllllllllllIllIllIIIlIIIllIll, float llllllllllllllIllIllIIIlIIIllIlI, Entity llllllllllllllIllIllIIIlIIlIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIllIIIlIIlIIIII.setRotationAngles(llllllllllllllIllIllIIIlIIIlllll, llllllllllllllIllIllIIIlIIIllllI, llllllllllllllIllIllIIIlIIIlllIl, llllllllllllllIllIllIIIlIIIlllII, llllllllllllllIllIllIIIlIIIllIll, llllllllllllllIllIllIIIlIIIllIlI, llllllllllllllIllIllIIIlIIlIIIll);
    float llllllllllllllIllIllIIIlIIlIIIlI = MathHelper.sin(swingProgress * 3.1415927F);
    float llllllllllllllIllIllIIIlIIlIIIIl = MathHelper.sin((1.0F - (1.0F - swingProgress) * (1.0F - swingProgress)) * 3.1415927F);
    bipedRightArm.rotateAngleZ = 0.0F;
    bipedLeftArm.rotateAngleZ = 0.0F;
    bipedRightArm.rotateAngleY = (-(0.1F - llllllllllllllIllIllIIIlIIlIIIlI * 0.6F));
    bipedLeftArm.rotateAngleY = (0.1F - llllllllllllllIllIllIIIlIIlIIIlI * 0.6F);
    bipedRightArm.rotateAngleX = -1.5707964F;
    bipedLeftArm.rotateAngleX = -1.5707964F;
    bipedRightArm.rotateAngleX -= llllllllllllllIllIllIIIlIIlIIIlI * 1.2F - llllllllllllllIllIllIIIlIIlIIIIl * 0.4F;
    bipedLeftArm.rotateAngleX -= llllllllllllllIllIllIIIlIIlIIIlI * 1.2F - llllllllllllllIllIllIIIlIIlIIIIl * 0.4F;
    bipedRightArm.rotateAngleZ += MathHelper.cos(llllllllllllllIllIllIIIlIIIlllIl * 0.09F) * 0.05F + 0.05F;
    bipedLeftArm.rotateAngleZ -= MathHelper.cos(llllllllllllllIllIllIIIlIIIlllIl * 0.09F) * 0.05F + 0.05F;
    bipedRightArm.rotateAngleX += MathHelper.sin(llllllllllllllIllIllIIIlIIIlllIl * 0.067F) * 0.05F;
    bipedLeftArm.rotateAngleX -= MathHelper.sin(llllllllllllllIllIllIIIlIIIlllIl * 0.067F) * 0.05F;
  }
  
  static {}
  
  public ModelZombie()
  {
    llllllllllllllIllIllIIIlIlIIllIl.<init>(0.0F, llllIIIlIlIl[0]);
  }
  
  public ModelZombie(float llllllllllllllIllIllIIIlIIllIllI, boolean llllllllllllllIllIllIIIlIIlllIII) {}
  
  protected ModelZombie(float llllllllllllllIllIllIIIlIlIIIllI, float llllllllllllllIllIllIIIlIlIIIlIl, int llllllllllllllIllIllIIIlIIllllll, int llllllllllllllIllIllIIIlIIlllllI)
  {
    llllllllllllllIllIllIIIlIlIIIIlI.<init>(llllllllllllllIllIllIIIlIlIIIllI, llllllllllllllIllIllIIIlIlIIIIII, llllllllllllllIllIllIIIlIIllllll, llllllllllllllIllIllIIIlIIlllllI);
  }
  
  private static boolean lIllIllllllIlI(int ???)
  {
    float llllllllllllllIllIllIIIlIIIlIlIl;
    return ??? != 0;
  }
}

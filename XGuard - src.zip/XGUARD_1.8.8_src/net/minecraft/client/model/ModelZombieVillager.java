package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelZombieVillager
  extends ModelBiped
{
  public ModelZombieVillager(float llllllllllllllIlIIIlIIllIlIllIII, float llllllllllllllIlIIIlIIllIlIlIlll, boolean llllllllllllllIlIIIlIIllIlIlIIlI) {}
  
  private static void llIlllIlIlllll()
  {
    lIIlIIIlIlIll = new int[8];
    lIIlIIIlIlIll[0] = ("  ".length() & ("  ".length() ^ -" ".length()));
    lIIlIIIlIlIll[1] = ('' + 57 - 91 + 142 ^ 45 + 79 - -53 + 9);
    lIIlIIIlIlIll[2] = (0x40 ^ 0x4C ^ 0x2A ^ 0x6);
    lIIlIIIlIlIll[3] = (0x65 ^ 0x6D);
    lIIlIIIlIlIll[4] = (0xAC ^ 0xA6);
    lIIlIIIlIlIll[5] = (0x65 ^ 0x7D);
    lIIlIIIlIlIll[6] = "  ".length();
    lIIlIIIlIlIll[7] = (0x65 ^ 0x4 ^ 0x72 ^ 0x17);
  }
  
  public void setRotationAngles(float llllllllllllllIlIIIlIIllIlIIIllI, float llllllllllllllIlIIIlIIllIlIIIlIl, float llllllllllllllIlIIIlIIllIlIIIlII, float llllllllllllllIlIIIlIIllIIlllIIl, float llllllllllllllIlIIIlIIllIIlllIII, float llllllllllllllIlIIIlIIllIIllIlll, Entity llllllllllllllIlIIIlIIllIIllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIIlIIllIIllllIl.setRotationAngles(llllllllllllllIlIIIlIIllIlIIIllI, llllllllllllllIlIIIlIIllIlIIIlIl, llllllllllllllIlIIIlIIllIlIIIlII, llllllllllllllIlIIIlIIllIIlllIIl, llllllllllllllIlIIIlIIllIIlllIII, llllllllllllllIlIIIlIIllIIllIlll, llllllllllllllIlIIIlIIllIIllIllI);
    float llllllllllllllIlIIIlIIllIIllllll = MathHelper.sin(swingProgress * 3.1415927F);
    float llllllllllllllIlIIIlIIllIIlllllI = MathHelper.sin((1.0F - (1.0F - swingProgress) * (1.0F - swingProgress)) * 3.1415927F);
    bipedRightArm.rotateAngleZ = 0.0F;
    bipedLeftArm.rotateAngleZ = 0.0F;
    bipedRightArm.rotateAngleY = (-(0.1F - llllllllllllllIlIIIlIIllIIllllll * 0.6F));
    bipedLeftArm.rotateAngleY = (0.1F - llllllllllllllIlIIIlIIllIIllllll * 0.6F);
    bipedRightArm.rotateAngleX = -1.5707964F;
    bipedLeftArm.rotateAngleX = -1.5707964F;
    bipedRightArm.rotateAngleX -= llllllllllllllIlIIIlIIllIIllllll * 1.2F - llllllllllllllIlIIIlIIllIIlllllI * 0.4F;
    bipedLeftArm.rotateAngleX -= llllllllllllllIlIIIlIIllIIllllll * 1.2F - llllllllllllllIlIIIlIIllIIlllllI * 0.4F;
    bipedRightArm.rotateAngleZ += MathHelper.cos(llllllllllllllIlIIIlIIllIlIIIlII * 0.09F) * 0.05F + 0.05F;
    bipedLeftArm.rotateAngleZ -= MathHelper.cos(llllllllllllllIlIIIlIIllIlIIIlII * 0.09F) * 0.05F + 0.05F;
    bipedRightArm.rotateAngleX += MathHelper.sin(llllllllllllllIlIIIlIIllIlIIIlII * 0.067F) * 0.05F;
    bipedLeftArm.rotateAngleX -= MathHelper.sin(llllllllllllllIlIIIlIIllIlIIIlII * 0.067F) * 0.05F;
  }
  
  static {}
  
  private static boolean llIlllIllIIIII(int ???)
  {
    long llllllllllllllIlIIIlIIllIIllIIlI;
    return ??? != 0;
  }
  
  public ModelZombieVillager()
  {
    llllllllllllllIlIIIlIIllIlIlllll.<init>(0.0F, 0.0F, lIIlIIIlIlIll[0]);
  }
}

package net.minecraft.client.model;

public class TextureOffset
{
  public TextureOffset(int llllllllllllllIlIlIIlIlIlIlIIlII, int llllllllllllllIlIlIIlIlIlIlIIIII)
  {
    textureOffsetX = llllllllllllllIlIlIIlIlIlIlIIIIl;
    textureOffsetY = llllllllllllllIlIlIIlIlIlIlIIIII;
  }
}

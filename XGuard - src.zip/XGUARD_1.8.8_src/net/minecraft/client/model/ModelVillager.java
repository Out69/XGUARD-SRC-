package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelVillager
  extends ModelBase
{
  public void render(Entity llllllllllllllIlIIlllIlIIIIlIlll, float llllllllllllllIlIIlllIlIIIIlIllI, float llllllllllllllIlIIlllIlIIIIlIlIl, float llllllllllllllIlIIlllIlIIIIIllII, float llllllllllllllIlIIlllIlIIIIIlIll, float llllllllllllllIlIIlllIlIIIIIlIlI, float llllllllllllllIlIIlllIlIIIIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIlllIlIIIIlIIII.setRotationAngles(llllllllllllllIlIIlllIlIIIIlIllI, llllllllllllllIlIIlllIlIIIIlIlIl, llllllllllllllIlIIlllIlIIIIIllII, llllllllllllllIlIIlllIlIIIIIlIll, llllllllllllllIlIIlllIlIIIIIlIlI, llllllllllllllIlIIlllIlIIIIlIIIl, llllllllllllllIlIIlllIlIIIIlIlll);
    villagerHead.render(llllllllllllllIlIIlllIlIIIIlIIIl);
    villagerBody.render(llllllllllllllIlIIlllIlIIIIlIIIl);
    rightVillagerLeg.render(llllllllllllllIlIIlllIlIIIIlIIIl);
    leftVillagerLeg.render(llllllllllllllIlIIlllIlIIIIlIIIl);
    villagerArms.render(llllllllllllllIlIIlllIlIIIIlIIIl);
  }
  
  public ModelVillager(float llllllllllllllIlIIlllIlIIIlIlIIl, float llllllllllllllIlIIlllIlIIIlIlIII, int llllllllllllllIlIIlllIlIIIlIIIlI, int llllllllllllllIlIIlllIlIIIlIIIIl)
  {
    villagerHead = new ModelRenderer(llllllllllllllIlIIlllIlIIIlIIlIl).setTextureSize(llllllllllllllIlIIlllIlIIIlIIIlI, llllllllllllllIlIIlllIlIIIlIIIIl);
    villagerHead.setRotationPoint(0.0F, 0.0F + llllllllllllllIlIIlllIlIIIlIIIll, 0.0F);
    villagerHead.setTextureOffset(lIIIlIlIllIlI[1], lIIIlIlIllIlI[1]).addBox(-4.0F, -10.0F, -4.0F, lIIIlIlIllIlI[2], lIIIlIlIllIlI[3], lIIIlIlIllIlI[2], llllllllllllllIlIIlllIlIIIlIlIIl);
    villagerNose = new ModelRenderer(llllllllllllllIlIIlllIlIIIlIIlIl).setTextureSize(llllllllllllllIlIIlllIlIIIlIIIlI, llllllllllllllIlIIlllIlIIIlIIIIl);
    villagerNose.setRotationPoint(0.0F, llllllllllllllIlIIlllIlIIIlIIIll - 2.0F, 0.0F);
    villagerNose.setTextureOffset(lIIIlIlIllIlI[4], lIIIlIlIllIlI[1]).addBox(-1.0F, -1.0F, -6.0F, lIIIlIlIllIlI[5], lIIIlIlIllIlI[6], lIIIlIlIllIlI[5], llllllllllllllIlIIlllIlIIIlIlIIl);
    villagerHead.addChild(villagerNose);
    villagerBody = new ModelRenderer(llllllllllllllIlIIlllIlIIIlIIlIl).setTextureSize(llllllllllllllIlIIlllIlIIIlIIIlI, llllllllllllllIlIIlllIlIIIlIIIIl);
    villagerBody.setRotationPoint(0.0F, 0.0F + llllllllllllllIlIIlllIlIIIlIIIll, 0.0F);
    villagerBody.setTextureOffset(lIIIlIlIllIlI[7], lIIIlIlIllIlI[8]).addBox(-4.0F, 0.0F, -3.0F, lIIIlIlIllIlI[2], lIIIlIlIllIlI[9], lIIIlIlIllIlI[10], llllllllllllllIlIIlllIlIIIlIlIIl);
    villagerBody.setTextureOffset(lIIIlIlIllIlI[1], lIIIlIlIllIlI[11]).addBox(-4.0F, 0.0F, -3.0F, lIIIlIlIllIlI[2], lIIIlIlIllIlI[12], lIIIlIlIllIlI[10], llllllllllllllIlIIlllIlIIIlIlIIl + 0.5F);
    villagerArms = new ModelRenderer(llllllllllllllIlIIlllIlIIIlIIlIl).setTextureSize(llllllllllllllIlIIlllIlIIIlIIIlI, llllllllllllllIlIIlllIlIIIlIIIIl);
    villagerArms.setRotationPoint(0.0F, 0.0F + llllllllllllllIlIIlllIlIIIlIIIll + 2.0F, 0.0F);
    villagerArms.setTextureOffset(lIIIlIlIllIlI[13], lIIIlIlIllIlI[14]).addBox(-8.0F, -2.0F, -2.0F, lIIIlIlIllIlI[6], lIIIlIlIllIlI[2], lIIIlIlIllIlI[6], llllllllllllllIlIIlllIlIIIlIlIIl);
    villagerArms.setTextureOffset(lIIIlIlIllIlI[13], lIIIlIlIllIlI[14]).addBox(4.0F, -2.0F, -2.0F, lIIIlIlIllIlI[6], lIIIlIlIllIlI[2], lIIIlIlIllIlI[6], llllllllllllllIlIIlllIlIIIlIlIIl);
    villagerArms.setTextureOffset(lIIIlIlIllIlI[15], lIIIlIlIllIlI[11]).addBox(-4.0F, 2.0F, -2.0F, lIIIlIlIllIlI[2], lIIIlIlIllIlI[6], lIIIlIlIllIlI[6], llllllllllllllIlIIlllIlIIIlIlIIl);
    rightVillagerLeg = new ModelRenderer(llllllllllllllIlIIlllIlIIIlIIlIl, lIIIlIlIllIlI[1], lIIIlIlIllIlI[14]).setTextureSize(llllllllllllllIlIIlllIlIIIlIIIlI, llllllllllllllIlIIlllIlIIIlIIIIl);
    rightVillagerLeg.setRotationPoint(-2.0F, 12.0F + llllllllllllllIlIIlllIlIIIlIIIll, 0.0F);
    rightVillagerLeg.addBox(-2.0F, 0.0F, -2.0F, lIIIlIlIllIlI[6], lIIIlIlIllIlI[9], lIIIlIlIllIlI[6], llllllllllllllIlIIlllIlIIIlIlIIl);
    leftVillagerLeg = new ModelRenderer(llllllllllllllIlIIlllIlIIIlIIlIl, lIIIlIlIllIlI[1], lIIIlIlIllIlI[14]).setTextureSize(llllllllllllllIlIIlllIlIIIlIIIlI, llllllllllllllIlIIlllIlIIIlIIIIl);
    leftVillagerLeg.mirror = lIIIlIlIllIlI[16];
    leftVillagerLeg.setRotationPoint(2.0F, 12.0F + llllllllllllllIlIIlllIlIIIlIIIll, 0.0F);
    leftVillagerLeg.addBox(-2.0F, 0.0F, -2.0F, lIIIlIlIllIlI[6], lIIIlIlIllIlI[9], lIIIlIlIllIlI[6], llllllllllllllIlIIlllIlIIIlIlIIl);
  }
  
  static {}
  
  public ModelVillager(float llllllllllllllIlIIlllIlIIIllIIlI)
  {
    llllllllllllllIlIIlllIlIIIllIIll.<init>(llllllllllllllIlIIlllIlIIIllIIlI, 0.0F, lIIIlIlIllIlI[0], lIIIlIlIllIlI[0]);
  }
  
  public void setRotationAngles(float llllllllllllllIlIIlllIlIIIIIIIlI, float llllllllllllllIlIIlllIlIIIIIIIIl, float llllllllllllllIlIIlllIlIIIIIIIII, float llllllllllllllIlIIlllIIllllllIII, float llllllllllllllIlIIlllIIlllllIlll, float llllllllllllllIlIIlllIIlllllllIl, Entity llllllllllllllIlIIlllIIlllllllII)
  {
    ;
    ;
    ;
    ;
    ;
    villagerHead.rotateAngleY = (llllllllllllllIlIIlllIIlllllllll / 57.295776F);
    villagerHead.rotateAngleX = (llllllllllllllIlIIlllIIlllllIlll / 57.295776F);
    villagerArms.rotationPointY = 3.0F;
    villagerArms.rotationPointZ = -1.0F;
    villagerArms.rotateAngleX = -0.75F;
    rightVillagerLeg.rotateAngleX = (MathHelper.cos(llllllllllllllIlIIlllIlIIIIIIIlI * 0.6662F) * 1.4F * llllllllllllllIlIIlllIlIIIIIIIIl * 0.5F);
    leftVillagerLeg.rotateAngleX = (MathHelper.cos(llllllllllllllIlIIlllIlIIIIIIIlI * 0.6662F + 3.1415927F) * 1.4F * llllllllllllllIlIIlllIlIIIIIIIIl * 0.5F);
    rightVillagerLeg.rotateAngleY = 0.0F;
    leftVillagerLeg.rotateAngleY = 0.0F;
  }
  
  private static void llIlIIllllIlII()
  {
    lIIIlIlIllIlI = new int[17];
    lIIIlIlIllIlI[0] = (13 + '' - 14 + 75 ^ 14 + 40 - -4 + 100);
    lIIIlIlIllIlI[1] = ((0xD1 ^ 0x88) & (0x4B ^ 0x12 ^ 0xFFFFFFFF));
    lIIIlIlIllIlI[2] = (0x4C ^ 0x44);
    lIIIlIlIllIlI[3] = (0xBE ^ 0xC0 ^ 0xD3 ^ 0xA7);
    lIIIlIlIllIlI[4] = (0x3B ^ 0x1 ^ 0xBA ^ 0x98);
    lIIIlIlIllIlI[5] = "  ".length();
    lIIIlIlIllIlI[6] = (0x69 ^ 0x6D);
    lIIIlIlIllIlI[7] = (0xB3 ^ 0xA3);
    lIIIlIlIllIlI[8] = (0x5B ^ 0x4F);
    lIIIlIlIllIlI[9] = (0x61 ^ 0x1D ^ 0x1C ^ 0x6C);
    lIIIlIlIllIlI[10] = (0xFB ^ 0x9B ^ 0xD7 ^ 0xB1);
    lIIIlIlIllIlI[11] = (0xB5 ^ 0x93);
    lIIIlIlIllIlI[12] = (0xB0 ^ 0x9D ^ 0xFE ^ 0xC1);
    lIIIlIlIllIlI[13] = (0xA6 ^ 0x9E ^ 0x87 ^ 0x93);
    lIIIlIlIllIlI[14] = (0xF1 ^ 0xA0 ^ 0xDF ^ 0x98);
    lIIIlIlIllIlI[15] = (0xA0 ^ 0x88);
    lIIIlIlIllIlI[16] = " ".length();
  }
}

package net.minecraft.client.model;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;

public class ModelEnderCrystal
  extends ModelBase
{
  private static boolean lIllIlIllllI(int ???, int arg1)
  {
    int i;
    int llllllllllllllllllIlIIlllllIlIII;
    return ??? < i;
  }
  
  private static void lIllIlIllIlI()
  {
    lllIIIllll = new String[lllIIlIIII[8]];
    lllIIIllll[lllIIlIIII[0]] = lIllIlIllIII("bduiK6NKnGo=", "uUKLB");
    lllIIIllll[lllIIlIIII[2]] = lIllIlIllIII("eU0A7OkLEbs=", "lChsN");
    lllIIIllll[lllIIlIIII[4]] = lIllIlIllIIl("Bio8FA==", "dKOqE");
  }
  
  public ModelEnderCrystal(float llllllllllllllllllIlIlIIIIlIIlll, boolean llllllllllllllllllIlIlIIIIlIIlII)
  {
    "".length();
    cube = new ModelRenderer(llllllllllllllllllIlIlIIIIlIlIII, lllIIIllll[lllIIlIIII[2]]);
    "".length();
    if (lIllIlIlllII(llllllllllllllllllIlIlIIIIlIIlII))
    {
      base = new ModelRenderer(llllllllllllllllllIlIlIIIIlIlIII, lllIIIllll[lllIIlIIII[4]]);
      "".length();
    }
  }
  
  private static String lIllIlIllIII(String llllllllllllllllllIlIlIIIIIIIlll, String llllllllllllllllllIlIlIIIIIIlIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIlIlIIIIIIllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlIlIIIIIIlIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIlIlIIIIIIlIll = Cipher.getInstance("Blowfish");
      llllllllllllllllllIlIlIIIIIIlIll.init(lllIIlIIII[4], llllllllllllllllllIlIlIIIIIIllII);
      return new String(llllllllllllllllllIlIlIIIIIIlIll.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlIlIIIIIIIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIlIlIIIIIIlIlI)
    {
      llllllllllllllllllIlIlIIIIIIlIlI.printStackTrace();
    }
    return null;
  }
  
  public void render(Entity llllllllllllllllllIlIlIIIIIlllIl, float llllllllllllllllllIlIlIIIIIlllII, float llllllllllllllllllIlIlIIIIIlIlII, float llllllllllllllllllIlIlIIIIIllIlI, float llllllllllllllllllIlIlIIIIIllIIl, float llllllllllllllllllIlIlIIIIIllIII, float llllllllllllllllllIlIlIIIIIlIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    GlStateManager.pushMatrix();
    GlStateManager.scale(2.0F, 2.0F, 2.0F);
    GlStateManager.translate(0.0F, -0.5F, 0.0F);
    if (lIllIlIlllIl(base)) {
      base.render(llllllllllllllllllIlIlIIIIIlIIlI);
    }
    GlStateManager.rotate(llllllllllllllllllIlIlIIIIIlIlII, 0.0F, 1.0F, 0.0F);
    GlStateManager.translate(0.0F, 0.8F + llllllllllllllllllIlIlIIIIIllIlI, 0.0F);
    GlStateManager.rotate(60.0F, 0.7071F, 0.0F, 0.7071F);
    glass.render(llllllllllllllllllIlIlIIIIIlIIlI);
    float llllllllllllllllllIlIlIIIIIlIllI = 0.875F;
    GlStateManager.scale(llllllllllllllllllIlIlIIIIIlIllI, llllllllllllllllllIlIlIIIIIlIllI, llllllllllllllllllIlIlIIIIIlIllI);
    GlStateManager.rotate(60.0F, 0.7071F, 0.0F, 0.7071F);
    GlStateManager.rotate(llllllllllllllllllIlIlIIIIIlIlII, 0.0F, 1.0F, 0.0F);
    glass.render(llllllllllllllllllIlIlIIIIIlIIlI);
    GlStateManager.scale(llllllllllllllllllIlIlIIIIIlIllI, llllllllllllllllllIlIlIIIIIlIllI, llllllllllllllllllIlIlIIIIIlIllI);
    GlStateManager.rotate(60.0F, 0.7071F, 0.0F, 0.7071F);
    GlStateManager.rotate(llllllllllllllllllIlIlIIIIIlIlII, 0.0F, 1.0F, 0.0F);
    cube.render(llllllllllllllllllIlIlIIIIIlIIlI);
    GlStateManager.popMatrix();
  }
  
  private static boolean lIllIlIlllIl(Object ???)
  {
    short llllllllllllllllllIlIIlllllIIllI;
    return ??? != null;
  }
  
  private static boolean lIllIlIlllII(int ???)
  {
    short llllllllllllllllllIlIIlllllIIlII;
    return ??? != 0;
  }
  
  private static void lIllIlIllIll()
  {
    lllIIlIIII = new int[9];
    lllIIlIIII[0] = ((0x28 ^ 0x56 ^ 0x97 ^ 0xBA) & (0x53 ^ 0x4B ^ 0x4D ^ 0x6 ^ -" ".length()));
    lllIIlIIII[1] = (51 + 126 - 116 + 123 ^ '' + 103 - 95 + 39);
    lllIIlIIII[2] = " ".length();
    lllIIlIIII[3] = (126 + 47 - 48 + 11 ^ 76 + 34 - 32 + 90);
    lllIIlIIII[4] = "  ".length();
    lllIIlIIII[5] = (0x53 ^ 0x43);
    lllIIlIIII[6] = (0x33 ^ 0x9 ^ 0x5F ^ 0x69);
    lllIIlIIII[7] = (0x6 ^ 0x63 ^ 0x2 ^ 0x63);
    lllIIlIIII[8] = "   ".length();
  }
  
  private static String lIllIlIllIIl(String llllllllllllllllllIlIIllllllIlII, String llllllllllllllllllIlIIlllllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllllIlIIllllllIlII = new String(Base64.getDecoder().decode(llllllllllllllllllIlIIllllllIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllIlIIllllllIlll = new StringBuilder();
    char[] llllllllllllllllllIlIIllllllIllI = llllllllllllllllllIlIIlllllllIII.toCharArray();
    int llllllllllllllllllIlIIllllllIlIl = lllIIlIIII[0];
    short llllllllllllllllllIlIIlllllIllll = llllllllllllllllllIlIIllllllIlII.toCharArray();
    int llllllllllllllllllIlIIlllllIlllI = llllllllllllllllllIlIIlllllIllll.length;
    byte llllllllllllllllllIlIIlllllIllIl = lllIIlIIII[0];
    while (lIllIlIllllI(llllllllllllllllllIlIIlllllIllIl, llllllllllllllllllIlIIlllllIlllI))
    {
      char llllllllllllllllllIlIIlllllllIlI = llllllllllllllllllIlIIlllllIllll[llllllllllllllllllIlIIlllllIllIl];
      "".length();
      "".length();
      if ("   ".length() == 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllllIlIIllllllIlll);
  }
  
  static
  {
    lIllIlIllIll();
    lIllIlIllIlI();
  }
}

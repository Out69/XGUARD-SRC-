package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelSnowMan
  extends ModelBase
{
  private static void lllllIllIlII()
  {
    lIlIIIlIlll = new int[9];
    lIlIIIlIlll[0] = ((0x19 ^ 0x33 ^ 0x1E ^ 0x2) & (45 + 87 - 131 + 179 ^ 126 + '' - 212 + 88 ^ -" ".length()));
    lIlIIIlIlll[1] = (0xF2 ^ 0xB2);
    lIlIIIlIlll[2] = (113 + '' - 143 + 59 ^ 46 + 60 - -20 + 45);
    lIlIIIlIlll[3] = (0xA8 ^ 0x88);
    lIlIIIlIlll[4] = (0x21 ^ 0x2D);
    lIlIIIlIlll[5] = "  ".length();
    lIlIIIlIlll[6] = (96 + 17 - 70 + 132 ^ 115 + 'µ' - 210 + 105);
    lIlIIIlIlll[7] = (0x26 ^ 0x36 ^ 0x27 ^ 0x3D);
    lIlIIIlIlll[8] = (0x89 ^ 0xAD);
  }
  
  public void setRotationAngles(float lllllllllllllllllIIlIIIlIIIIllIl, float lllllllllllllllllIIlIIIlIIIIIIlI, float lllllllllllllllllIIlIIIlIIIIlIll, float lllllllllllllllllIIlIIIlIIIIIIII, float lllllllllllllllllIIlIIIlIIIIlIIl, float lllllllllllllllllIIlIIIlIIIIlIII, Entity lllllllllllllllllIIlIIIIllllllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIlIIIlIIIIlllI.setRotationAngles(lllllllllllllllllIIlIIIlIIIIllIl, lllllllllllllllllIIlIIIlIIIIIIlI, lllllllllllllllllIIlIIIlIIIIlIll, lllllllllllllllllIIlIIIlIIIIIIII, lllllllllllllllllIIlIIIlIIIIlIIl, lllllllllllllllllIIlIIIlIIIIlIII, lllllllllllllllllIIlIIIIllllllIl);
    head.rotateAngleY = (lllllllllllllllllIIlIIIlIIIIIIII / 57.295776F);
    head.rotateAngleX = (lllllllllllllllllIIlIIIlIIIIlIIl / 57.295776F);
    body.rotateAngleY = (lllllllllllllllllIIlIIIlIIIIIIII / 57.295776F * 0.25F);
    float lllllllllllllllllIIlIIIlIIIIIllI = MathHelper.sin(body.rotateAngleY);
    float lllllllllllllllllIIlIIIlIIIIIlIl = MathHelper.cos(body.rotateAngleY);
    rightHand.rotateAngleZ = 1.0F;
    leftHand.rotateAngleZ = -1.0F;
    rightHand.rotateAngleY = (0.0F + body.rotateAngleY);
    leftHand.rotateAngleY = (3.1415927F + body.rotateAngleY);
    rightHand.rotationPointX = (lllllllllllllllllIIlIIIlIIIIIlIl * 5.0F);
    rightHand.rotationPointZ = (-lllllllllllllllllIIlIIIlIIIIIllI * 5.0F);
    leftHand.rotationPointX = (-lllllllllllllllllIIlIIIlIIIIIlIl * 5.0F);
    leftHand.rotationPointZ = (lllllllllllllllllIIlIIIlIIIIIllI * 5.0F);
  }
  
  static {}
  
  public void render(Entity lllllllllllllllllIIlIIIIllllIIIl, float lllllllllllllllllIIlIIIIllllIIII, float lllllllllllllllllIIlIIIIlllIIlll, float lllllllllllllllllIIlIIIIlllIlllI, float lllllllllllllllllIIlIIIIlllIIlIl, float lllllllllllllllllIIlIIIIlllIIlII, float lllllllllllllllllIIlIIIIlllIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIlIIIIlllIlIlI.setRotationAngles(lllllllllllllllllIIlIIIIllllIIII, lllllllllllllllllIIlIIIIlllIIlll, lllllllllllllllllIIlIIIIlllIlllI, lllllllllllllllllIIlIIIIlllIIlIl, lllllllllllllllllIIlIIIIlllIIlII, lllllllllllllllllIIlIIIIlllIIIll, lllllllllllllllllIIlIIIIllllIIIl);
    body.render(lllllllllllllllllIIlIIIIlllIIIll);
    bottomBody.render(lllllllllllllllllIIlIIIIlllIIIll);
    head.render(lllllllllllllllllIIlIIIIlllIIIll);
    rightHand.render(lllllllllllllllllIIlIIIIlllIIIll);
    leftHand.render(lllllllllllllllllIIlIIIIlllIIIll);
  }
  
  public ModelSnowMan()
  {
    float lllllllllllllllllIIlIIIlIIIlllIl = 4.0F;
    float lllllllllllllllllIIlIIIlIIIlllII = 0.0F;
    head = new ModelRenderer(lllllllllllllllllIIlIIIlIIIllllI, lIlIIIlIlll[0], lIlIIIlIlll[0]).setTextureSize(lIlIIIlIlll[1], lIlIIIlIlll[1]);
    head.addBox(-4.0F, -8.0F, -4.0F, lIlIIIlIlll[2], lIlIIIlIlll[2], lIlIIIlIlll[2], lllllllllllllllllIIlIIIlIIIlllII - 0.5F);
    head.setRotationPoint(0.0F, 0.0F + lllllllllllllllllIIlIIIlIIIlllIl, 0.0F);
    rightHand = new ModelRenderer(lllllllllllllllllIIlIIIlIIIllllI, lIlIIIlIlll[3], lIlIIIlIlll[0]).setTextureSize(lIlIIIlIlll[1], lIlIIIlIlll[1]);
    rightHand.addBox(-1.0F, 0.0F, -1.0F, lIlIIIlIlll[4], lIlIIIlIlll[5], lIlIIIlIlll[5], lllllllllllllllllIIlIIIlIIIlllII - 0.5F);
    rightHand.setRotationPoint(0.0F, 0.0F + lllllllllllllllllIIlIIIlIIIlllIl + 9.0F - 7.0F, 0.0F);
    leftHand = new ModelRenderer(lllllllllllllllllIIlIIIlIIIllllI, lIlIIIlIlll[3], lIlIIIlIlll[0]).setTextureSize(lIlIIIlIlll[1], lIlIIIlIlll[1]);
    leftHand.addBox(-1.0F, 0.0F, -1.0F, lIlIIIlIlll[4], lIlIIIlIlll[5], lIlIIIlIlll[5], lllllllllllllllllIIlIIIlIIIlllII - 0.5F);
    leftHand.setRotationPoint(0.0F, 0.0F + lllllllllllllllllIIlIIIlIIIlllIl + 9.0F - 7.0F, 0.0F);
    body = new ModelRenderer(lllllllllllllllllIIlIIIlIIIllllI, lIlIIIlIlll[0], lIlIIIlIlll[6]).setTextureSize(lIlIIIlIlll[1], lIlIIIlIlll[1]);
    body.addBox(-5.0F, -10.0F, -5.0F, lIlIIIlIlll[7], lIlIIIlIlll[7], lIlIIIlIlll[7], lllllllllllllllllIIlIIIlIIIlllII - 0.5F);
    body.setRotationPoint(0.0F, 0.0F + lllllllllllllllllIIlIIIlIIIlllIl + 9.0F, 0.0F);
    bottomBody = new ModelRenderer(lllllllllllllllllIIlIIIlIIIllllI, lIlIIIlIlll[0], lIlIIIlIlll[8]).setTextureSize(lIlIIIlIlll[1], lIlIIIlIlll[1]);
    bottomBody.addBox(-6.0F, -12.0F, -6.0F, lIlIIIlIlll[4], lIlIIIlIlll[4], lIlIIIlIlll[4], lllllllllllllllllIIlIIIlIIIlllII - 0.5F);
    bottomBody.setRotationPoint(0.0F, 0.0F + lllllllllllllllllIIlIIIlIIIlllIl + 20.0F, 0.0F);
  }
}

package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelWitch
  extends ModelVillager
{
  private static boolean lllIlllIIIllIl(int ???)
  {
    String llllllllllllllIIllIIllIlIIIIIIll;
    return ??? != 0;
  }
  
  private static void lllIlllIIIllII()
  {
    lIIlllIIlIlIl = new int[11];
    lIIlllIIlIlIl[0] = (0xD4 ^ 0x94);
    lIIlllIIlIlIl[1] = ((0x33 ^ 0x7C) + (0x25 ^ 0x3A) - -(0x8E ^ 0x83) + (0xBF ^ 0xBA));
    lIIlllIIlIlIl[2] = (('' + '' - 148 + 28 ^ 112 + 6 - 37 + 102) & (0x88 ^ 0xC4 ^ 0x54 ^ 0x5 ^ -" ".length()));
    lIIlllIIlIlIl[3] = " ".length();
    lIIlllIIlIlIl[4] = (0x2B ^ 0x7B ^ 0x64 ^ 0x3E);
    lIIlllIIlIlIl[5] = "  ".length();
    lIIlllIIlIlIl[6] = (0x1E ^ 0x7B ^ 0x47 ^ 0x6E);
    lIIlllIIlIlIl[7] = (0xA2 ^ 0xA5);
    lIIlllIIlIlIl[8] = (0x1 ^ 0x5);
    lIIlllIIlIlIl[9] = (0x7B ^ 0x3A ^ 0xE ^ 0x18);
    lIIlllIIlIlIl[10] = ('¤' + 'Í' - 270 + 116 ^ 80 + 72 - 75 + 59);
  }
  
  public ModelWitch(float llllllllllllllIIllIIllIlIIlIIIll)
  {
    llllllllllllllIIllIIllIlIIlIlIIl.<init>(llllllllllllllIIllIIllIlIIlIIIll, 0.0F, lIIlllIIlIlIl[0], lIIlllIIlIlIl[1]);
    field_82901_h.setRotationPoint(0.0F, -2.0F, 0.0F);
    field_82901_h.setTextureOffset(lIIlllIIlIlIl[2], lIIlllIIlIlIl[2]).addBox(0.0F, 3.0F, -6.75F, lIIlllIIlIlIl[3], lIIlllIIlIlIl[3], lIIlllIIlIlIl[3], -0.25F);
    villagerNose.addChild(field_82901_h);
    witchHat = new ModelRenderer(llllllllllllllIIllIIllIlIIlIlIIl).setTextureSize(lIIlllIIlIlIl[0], lIIlllIIlIlIl[1]);
    witchHat.setRotationPoint(-5.0F, -10.03125F, -5.0F);
    "".length();
    villagerHead.addChild(witchHat);
    ModelRenderer llllllllllllllIIllIIllIlIIlIIlll = new ModelRenderer(llllllllllllllIIllIIllIlIIlIlIIl).setTextureSize(lIIlllIIlIlIl[0], lIIlllIIlIlIl[1]);
    llllllllllllllIIllIIllIlIIlIIlll.setRotationPoint(1.75F, -4.0F, 2.0F);
    "".length();
    rotateAngleX = -0.05235988F;
    rotateAngleZ = 0.02617994F;
    witchHat.addChild(llllllllllllllIIllIIllIlIIlIIlll);
    ModelRenderer llllllllllllllIIllIIllIlIIlIIllI = new ModelRenderer(llllllllllllllIIllIIllIlIIlIlIIl).setTextureSize(lIIlllIIlIlIl[0], lIIlllIIlIlIl[1]);
    llllllllllllllIIllIIllIlIIlIIllI.setRotationPoint(1.75F, -4.0F, 2.0F);
    "".length();
    rotateAngleX = -0.10471976F;
    rotateAngleZ = 0.05235988F;
    llllllllllllllIIllIIllIlIIlIIlll.addChild(llllllllllllllIIllIIllIlIIlIIllI);
    ModelRenderer llllllllllllllIIllIIllIlIIlIIlIl = new ModelRenderer(llllllllllllllIIllIIllIlIIlIlIIl).setTextureSize(lIIlllIIlIlIl[0], lIIlllIIlIlIl[1]);
    llllllllllllllIIllIIllIlIIlIIlIl.setRotationPoint(1.75F, -2.0F, 2.0F);
    llllllllllllllIIllIIllIlIIlIIlIl.setTextureOffset(lIIlllIIlIlIl[2], lIIlllIIlIlIl[10]).addBox(0.0F, 0.0F, 0.0F, lIIlllIIlIlIl[3], lIIlllIIlIlIl[5], lIIlllIIlIlIl[3], 0.25F);
    rotateAngleX = -0.20943952F;
    rotateAngleZ = 0.10471976F;
    llllllllllllllIIllIIllIlIIlIIllI.addChild(llllllllllllllIIllIIllIlIIlIIlIl);
  }
  
  public void setRotationAngles(float llllllllllllllIIllIIllIlIIIlIlIl, float llllllllllllllIIllIIllIlIIIlIlII, float llllllllllllllIIllIIllIlIIIlIIll, float llllllllllllllIIllIIllIlIIIlIIlI, float llllllllllllllIIllIIllIlIIIIlIII, float llllllllllllllIIllIIllIlIIIIIlll, Entity llllllllllllllIIllIIllIlIIIIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIIllIlIIIlIllI.setRotationAngles(llllllllllllllIIllIIllIlIIIlIlIl, llllllllllllllIIllIIllIlIIIlIlII, llllllllllllllIIllIIllIlIIIlIIll, llllllllllllllIIllIIllIlIIIlIIlI, llllllllllllllIIllIIllIlIIIIlIII, llllllllllllllIIllIIllIlIIIIIlll, llllllllllllllIIllIIllIlIIIIIllI);
    villagerNose.offsetX = (villagerNose.offsetY = villagerNose.offsetZ = 0.0F);
    float llllllllllllllIIllIIllIlIIIIlllI = 0.01F * (llllllllllllllIIllIIllIlIIIIIllI.getEntityId() % lIIlllIIlIlIl[4]);
    villagerNose.rotateAngleX = (MathHelper.sin(ticksExisted * llllllllllllllIIllIIllIlIIIIlllI) * 4.5F * 3.1415927F / 180.0F);
    villagerNose.rotateAngleY = 0.0F;
    villagerNose.rotateAngleZ = (MathHelper.cos(ticksExisted * llllllllllllllIIllIIllIlIIIIlllI) * 2.5F * 3.1415927F / 180.0F);
    if (lllIlllIIIllIl(field_82900_g))
    {
      villagerNose.rotateAngleX = -0.9F;
      villagerNose.offsetZ = -0.09375F;
      villagerNose.offsetY = 0.1875F;
    }
  }
  
  static {}
}

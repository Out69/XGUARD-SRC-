package net.minecraft.client.model;

import net.minecraft.entity.Entity;

public class ModelMinecart
  extends ModelBase
{
  private static boolean llIIllIllllIlI(int ???, int arg1)
  {
    int i;
    String llllllllllllllIlIlIlIIIllllIllII;
    return ??? >= i;
  }
  
  static {}
  
  public void render(Entity llllllllllllllIlIlIlIIIllllllIll, float llllllllllllllIlIlIlIIIllllllIlI, float llllllllllllllIlIlIlIIIllllllIIl, float llllllllllllllIlIlIlIIIllllllIII, float llllllllllllllIlIlIlIIIlllllIlll, float llllllllllllllIlIlIlIIIlllllIllI, float llllllllllllllIlIlIlIIIlllllIIIl)
  {
    ;
    ;
    ;
    ;
    sideModels[lIIIIllIlIIlI[7]].rotationPointY = (4.0F - llllllllllllllIlIlIlIIIllllllIII);
    int llllllllllllllIlIlIlIIIlllllIlII = lIIIIllIlIIlI[1];
    "".length();
    if (((0x7D ^ 0x41 ^ 0x2F ^ 0x56) & (0x1C ^ 0x43 ^ 0x76 ^ 0x6C ^ -" ".length())) > "   ".length()) {
      return;
    }
    while (!llIIllIllllIlI(llllllllllllllIlIlIlIIIlllllIlII, lIIIIllIlIIlI[12]))
    {
      sideModels[llllllllllllllIlIlIlIIIlllllIlII].render(llllllllllllllIlIlIlIIIlllllIIIl);
      llllllllllllllIlIlIlIIIlllllIlII++;
    }
  }
  
  public ModelMinecart()
  {
    sideModels[lIIIIllIlIIlI[1]] = new ModelRenderer(llllllllllllllIlIlIlIIlIIIIIlIlI, lIIIIllIlIIlI[1], lIIIIllIlIIlI[2]);
    sideModels[lIIIIllIlIIlI[3]] = new ModelRenderer(llllllllllllllIlIlIlIIlIIIIIlIlI, lIIIIllIlIIlI[1], lIIIIllIlIIlI[1]);
    sideModels[lIIIIllIlIIlI[4]] = new ModelRenderer(llllllllllllllIlIlIlIIlIIIIIlIlI, lIIIIllIlIIlI[1], lIIIIllIlIIlI[1]);
    sideModels[lIIIIllIlIIlI[5]] = new ModelRenderer(llllllllllllllIlIlIlIIlIIIIIlIlI, lIIIIllIlIIlI[1], lIIIIllIlIIlI[1]);
    sideModels[lIIIIllIlIIlI[6]] = new ModelRenderer(llllllllllllllIlIlIlIIlIIIIIlIlI, lIIIIllIlIIlI[1], lIIIIllIlIIlI[1]);
    sideModels[lIIIIllIlIIlI[7]] = new ModelRenderer(llllllllllllllIlIlIlIIlIIIIIlIlI, lIIIIllIlIIlI[8], lIIIIllIlIIlI[2]);
    int llllllllllllllIlIlIlIIlIIIIIlIIl = lIIIIllIlIIlI[9];
    int llllllllllllllIlIlIlIIlIIIIIlIII = lIIIIllIlIIlI[10];
    int llllllllllllllIlIlIlIIlIIIIIIlll = lIIIIllIlIIlI[11];
    int llllllllllllllIlIlIlIIlIIIIIIllI = lIIIIllIlIIlI[6];
    sideModels[lIIIIllIlIIlI[1]].addBox(-llllllllllllllIlIlIlIIlIIIIIlIIl / lIIIIllIlIIlI[4], -llllllllllllllIlIlIlIIlIIIIIIlll / lIIIIllIlIIlI[4], -1.0F, llllllllllllllIlIlIlIIlIIIIIlIIl, llllllllllllllIlIlIlIIlIIIIIIlll, lIIIIllIlIIlI[4], 0.0F);
    sideModels[lIIIIllIlIIlI[1]].setRotationPoint(0.0F, llllllllllllllIlIlIlIIlIIIIIIllI, 0.0F);
    sideModels[lIIIIllIlIIlI[7]].addBox(-llllllllllllllIlIlIlIIlIIIIIlIIl / lIIIIllIlIIlI[4] + lIIIIllIlIIlI[3], -llllllllllllllIlIlIlIIlIIIIIIlll / lIIIIllIlIIlI[4] + lIIIIllIlIIlI[3], -1.0F, llllllllllllllIlIlIlIIlIIIIIlIIl - lIIIIllIlIIlI[4], llllllllllllllIlIlIlIIlIIIIIIlll - lIIIIllIlIIlI[4], lIIIIllIlIIlI[3], 0.0F);
    sideModels[lIIIIllIlIIlI[7]].setRotationPoint(0.0F, llllllllllllllIlIlIlIIlIIIIIIllI, 0.0F);
    sideModels[lIIIIllIlIIlI[3]].addBox(-llllllllllllllIlIlIlIIlIIIIIlIIl / lIIIIllIlIIlI[4] + lIIIIllIlIIlI[4], -llllllllllllllIlIlIlIIlIIIIIlIII - lIIIIllIlIIlI[3], -1.0F, llllllllllllllIlIlIlIIlIIIIIlIIl - lIIIIllIlIIlI[6], llllllllllllllIlIlIlIIlIIIIIlIII, lIIIIllIlIIlI[4], 0.0F);
    sideModels[lIIIIllIlIIlI[3]].setRotationPoint(-llllllllllllllIlIlIlIIlIIIIIlIIl / lIIIIllIlIIlI[4] + lIIIIllIlIIlI[3], llllllllllllllIlIlIlIIlIIIIIIllI, 0.0F);
    sideModels[lIIIIllIlIIlI[4]].addBox(-llllllllllllllIlIlIlIIlIIIIIlIIl / lIIIIllIlIIlI[4] + lIIIIllIlIIlI[4], -llllllllllllllIlIlIlIIlIIIIIlIII - lIIIIllIlIIlI[3], -1.0F, llllllllllllllIlIlIlIIlIIIIIlIIl - lIIIIllIlIIlI[6], llllllllllllllIlIlIlIIlIIIIIlIII, lIIIIllIlIIlI[4], 0.0F);
    sideModels[lIIIIllIlIIlI[4]].setRotationPoint(llllllllllllllIlIlIlIIlIIIIIlIIl / lIIIIllIlIIlI[4] - lIIIIllIlIIlI[3], llllllllllllllIlIlIlIIlIIIIIIllI, 0.0F);
    sideModels[lIIIIllIlIIlI[5]].addBox(-llllllllllllllIlIlIlIIlIIIIIlIIl / lIIIIllIlIIlI[4] + lIIIIllIlIIlI[4], -llllllllllllllIlIlIlIIlIIIIIlIII - lIIIIllIlIIlI[3], -1.0F, llllllllllllllIlIlIlIIlIIIIIlIIl - lIIIIllIlIIlI[6], llllllllllllllIlIlIlIIlIIIIIlIII, lIIIIllIlIIlI[4], 0.0F);
    sideModels[lIIIIllIlIIlI[5]].setRotationPoint(0.0F, llllllllllllllIlIlIlIIlIIIIIIllI, -llllllllllllllIlIlIlIIlIIIIIIlll / lIIIIllIlIIlI[4] + lIIIIllIlIIlI[3]);
    sideModels[lIIIIllIlIIlI[6]].addBox(-llllllllllllllIlIlIlIIlIIIIIlIIl / lIIIIllIlIIlI[4] + lIIIIllIlIIlI[4], -llllllllllllllIlIlIlIIlIIIIIlIII - lIIIIllIlIIlI[3], -1.0F, llllllllllllllIlIlIlIIlIIIIIlIIl - lIIIIllIlIIlI[6], llllllllllllllIlIlIlIIlIIIIIlIII, lIIIIllIlIIlI[4], 0.0F);
    sideModels[lIIIIllIlIIlI[6]].setRotationPoint(0.0F, llllllllllllllIlIlIlIIlIIIIIIllI, llllllllllllllIlIlIlIIlIIIIIIlll / lIIIIllIlIIlI[4] - lIIIIllIlIIlI[3]);
    sideModels[lIIIIllIlIIlI[1]].rotateAngleX = 1.5707964F;
    sideModels[lIIIIllIlIIlI[3]].rotateAngleY = 4.712389F;
    sideModels[lIIIIllIlIIlI[4]].rotateAngleY = 1.5707964F;
    sideModels[lIIIIllIlIIlI[5]].rotateAngleY = 3.1415927F;
    sideModels[lIIIIllIlIIlI[7]].rotateAngleX = -1.5707964F;
  }
  
  private static void llIIllIllllIIl()
  {
    lIIIIllIlIIlI = new int[13];
    lIIIIllIlIIlI[0] = (0x1F ^ 0x18);
    lIIIIllIlIIlI[1] = ((0x2E ^ 0x6D ^ 0x38 ^ 0x21) & (0x10 ^ 0x6E ^ 0x68 ^ 0x4C ^ -" ".length()));
    lIIIIllIlIIlI[2] = (0xF ^ 0x5);
    lIIIIllIlIIlI[3] = " ".length();
    lIIIIllIlIIlI[4] = "  ".length();
    lIIIIllIlIIlI[5] = "   ".length();
    lIIIIllIlIIlI[6] = (0x5B ^ 0x5F);
    lIIIIllIlIIlI[7] = (74 + 56 - 54 + 110 ^ 35 + 'º' - 90 + 60);
    lIIIIllIlIIlI[8] = (8 + 55 - -42 + 134 ^ '' + '' - 157 + 66);
    lIIIIllIlIIlI[9] = (0x38 ^ 0x2C);
    lIIIIllIlIIlI[10] = (0x81 ^ 0x89);
    lIIIIllIlIIlI[11] = (0x28 ^ 0x38);
    lIIIIllIlIIlI[12] = (100 + 100 - 176 + 124 ^ '' + 55 - 69 + 18);
  }
}

package net.minecraft.client.model;

import net.minecraft.entity.Entity;

public class ModelEnderman
  extends ModelBiped
{
  public ModelEnderman(float llllllllllllllllllIIIllIIlIIlIIl)
  {
    llllllllllllllllllIIIllIIlIIllIl.<init>(0.0F, -14.0F, lllllIIIlI[0], lllllIIIlI[1]);
    float llllllllllllllllllIIIllIIlIIlIll = -14.0F;
    bipedHeadwear = new ModelRenderer(llllllllllllllllllIIIllIIlIIllIl, lllllIIIlI[2], lllllIIIlI[3]);
    bipedHeadwear.addBox(-4.0F, -8.0F, -4.0F, lllllIIIlI[4], lllllIIIlI[4], lllllIIIlI[4], llllllllllllllllllIIIllIIlIIlIIl - 0.5F);
    bipedHeadwear.setRotationPoint(0.0F, 0.0F + llllllllllllllllllIIIllIIlIIlIll, 0.0F);
    bipedBody = new ModelRenderer(llllllllllllllllllIIIllIIlIIllIl, lllllIIIlI[1], lllllIIIlI[3]);
    bipedBody.addBox(-4.0F, 0.0F, -2.0F, lllllIIIlI[4], lllllIIIlI[5], lllllIIIlI[6], llllllllllllllllllIIIllIIlIIlIIl);
    bipedBody.setRotationPoint(0.0F, 0.0F + llllllllllllllllllIIIllIIlIIlIll, 0.0F);
    bipedRightArm = new ModelRenderer(llllllllllllllllllIIIllIIlIIllIl, lllllIIIlI[7], lllllIIIlI[2]);
    bipedRightArm.addBox(-1.0F, -2.0F, -1.0F, lllllIIIlI[8], lllllIIIlI[9], lllllIIIlI[8], llllllllllllllllllIIIllIIlIIlIIl);
    bipedRightArm.setRotationPoint(-3.0F, 2.0F + llllllllllllllllllIIIllIIlIIlIll, 0.0F);
    bipedLeftArm = new ModelRenderer(llllllllllllllllllIIIllIIlIIllIl, lllllIIIlI[7], lllllIIIlI[2]);
    bipedLeftArm.mirror = lllllIIIlI[10];
    bipedLeftArm.addBox(-1.0F, -2.0F, -1.0F, lllllIIIlI[8], lllllIIIlI[9], lllllIIIlI[8], llllllllllllllllllIIIllIIlIIlIIl);
    bipedLeftArm.setRotationPoint(5.0F, 2.0F + llllllllllllllllllIIIllIIlIIlIll, 0.0F);
    bipedRightLeg = new ModelRenderer(llllllllllllllllllIIIllIIlIIllIl, lllllIIIlI[7], lllllIIIlI[2]);
    bipedRightLeg.addBox(-1.0F, 0.0F, -1.0F, lllllIIIlI[8], lllllIIIlI[9], lllllIIIlI[8], llllllllllllllllllIIIllIIlIIlIIl);
    bipedRightLeg.setRotationPoint(-2.0F, 12.0F + llllllllllllllllllIIIllIIlIIlIll, 0.0F);
    bipedLeftLeg = new ModelRenderer(llllllllllllllllllIIIllIIlIIllIl, lllllIIIlI[7], lllllIIIlI[2]);
    bipedLeftLeg.mirror = lllllIIIlI[10];
    bipedLeftLeg.addBox(-1.0F, 0.0F, -1.0F, lllllIIIlI[8], lllllIIIlI[9], lllllIIIlI[8], llllllllllllllllllIIIllIIlIIlIIl);
    bipedLeftLeg.setRotationPoint(2.0F, 12.0F + llllllllllllllllllIIIllIIlIIlIll, 0.0F);
  }
  
  public void setRotationAngles(float llllllllllllllllllIIIllIIIlllIll, float llllllllllllllllllIIIllIIIlIllll, float llllllllllllllllllIIIllIIIlllIIl, float llllllllllllllllllIIIllIIIlllIII, float llllllllllllllllllIIIllIIIlIllII, float llllllllllllllllllIIIllIIIlIlIll, Entity llllllllllllllllllIIIllIIIllIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllllIIIllIIIllllII.setRotationAngles(llllllllllllllllllIIIllIIIlllIll, llllllllllllllllllIIIllIIIlIllll, llllllllllllllllllIIIllIIIlllIIl, llllllllllllllllllIIIllIIIlllIII, llllllllllllllllllIIIllIIIlIllII, llllllllllllllllllIIIllIIIlIlIll, llllllllllllllllllIIIllIIIllIlIl);
    bipedHead.showModel = lllllIIIlI[10];
    float llllllllllllllllllIIIllIIIllIlII = -14.0F;
    bipedBody.rotateAngleX = 0.0F;
    bipedBody.rotationPointY = llllllllllllllllllIIIllIIIllIlII;
    bipedBody.rotationPointZ = -0.0F;
    bipedRightLeg.rotateAngleX -= 0.0F;
    bipedLeftLeg.rotateAngleX -= 0.0F;
    bipedRightArm.rotateAngleX = ((float)(bipedRightArm.rotateAngleX * 0.5D));
    bipedLeftArm.rotateAngleX = ((float)(bipedLeftArm.rotateAngleX * 0.5D));
    bipedRightLeg.rotateAngleX = ((float)(bipedRightLeg.rotateAngleX * 0.5D));
    bipedLeftLeg.rotateAngleX = ((float)(bipedLeftLeg.rotateAngleX * 0.5D));
    float llllllllllllllllllIIIllIIIllIIll = 0.4F;
    if (llIIIllIIIII(llIIIlIllllI(bipedRightArm.rotateAngleX, llllllllllllllllllIIIllIIIllIIll))) {
      bipedRightArm.rotateAngleX = llllllllllllllllllIIIllIIIllIIll;
    }
    if (llIIIllIIIII(llIIIlIllllI(bipedLeftArm.rotateAngleX, llllllllllllllllllIIIllIIIllIIll))) {
      bipedLeftArm.rotateAngleX = llllllllllllllllllIIIllIIIllIIll;
    }
    if (llIIIllIIIIl(llIIIlIlllll(bipedRightArm.rotateAngleX, -llllllllllllllllllIIIllIIIllIIll))) {
      bipedRightArm.rotateAngleX = (-llllllllllllllllllIIIllIIIllIIll);
    }
    if (llIIIllIIIIl(llIIIlIlllll(bipedLeftArm.rotateAngleX, -llllllllllllllllllIIIllIIIllIIll))) {
      bipedLeftArm.rotateAngleX = (-llllllllllllllllllIIIllIIIllIIll);
    }
    if (llIIIllIIIII(llIIIlIllllI(bipedRightLeg.rotateAngleX, llllllllllllllllllIIIllIIIllIIll))) {
      bipedRightLeg.rotateAngleX = llllllllllllllllllIIIllIIIllIIll;
    }
    if (llIIIllIIIII(llIIIlIllllI(bipedLeftLeg.rotateAngleX, llllllllllllllllllIIIllIIIllIIll))) {
      bipedLeftLeg.rotateAngleX = llllllllllllllllllIIIllIIIllIIll;
    }
    if (llIIIllIIIIl(llIIIlIlllll(bipedRightLeg.rotateAngleX, -llllllllllllllllllIIIllIIIllIIll))) {
      bipedRightLeg.rotateAngleX = (-llllllllllllllllllIIIllIIIllIIll);
    }
    if (llIIIllIIIIl(llIIIlIlllll(bipedLeftLeg.rotateAngleX, -llllllllllllllllllIIIllIIIllIIll))) {
      bipedLeftLeg.rotateAngleX = (-llllllllllllllllllIIIllIIIllIIll);
    }
    if (llIIIllIIIlI(isCarrying))
    {
      bipedRightArm.rotateAngleX = -0.5F;
      bipedLeftArm.rotateAngleX = -0.5F;
      bipedRightArm.rotateAngleZ = 0.05F;
      bipedLeftArm.rotateAngleZ = -0.05F;
    }
    bipedRightArm.rotationPointZ = 0.0F;
    bipedLeftArm.rotationPointZ = 0.0F;
    bipedRightLeg.rotationPointZ = 0.0F;
    bipedLeftLeg.rotationPointZ = 0.0F;
    bipedRightLeg.rotationPointY = (9.0F + llllllllllllllllllIIIllIIIllIlII);
    bipedLeftLeg.rotationPointY = (9.0F + llllllllllllllllllIIIllIIIllIlII);
    bipedHead.rotationPointZ = -0.0F;
    bipedHead.rotationPointY = (llllllllllllllllllIIIllIIIllIlII + 1.0F);
    bipedHeadwear.rotationPointX = bipedHead.rotationPointX;
    bipedHeadwear.rotationPointY = bipedHead.rotationPointY;
    bipedHeadwear.rotationPointZ = bipedHead.rotationPointZ;
    bipedHeadwear.rotateAngleX = bipedHead.rotateAngleX;
    bipedHeadwear.rotateAngleY = bipedHead.rotateAngleY;
    bipedHeadwear.rotateAngleZ = bipedHead.rotateAngleZ;
    if (llIIIllIIIlI(isAttacking))
    {
      float llllllllllllllllllIIIllIIIllIIlI = 1.0F;
      bipedHead.rotationPointY -= llllllllllllllllllIIIllIIIllIIlI * 5.0F;
    }
  }
  
  private static boolean llIIIllIIIIl(int ???)
  {
    int llllllllllllllllllIIIllIIIlIIIll;
    return ??? < 0;
  }
  
  static {}
  
  private static boolean llIIIllIIIII(int ???)
  {
    short llllllllllllllllllIIIllIIIlIIIIl;
    return ??? > 0;
  }
  
  private static boolean llIIIllIIIlI(int ???)
  {
    short llllllllllllllllllIIIllIIIlIIlIl;
    return ??? != 0;
  }
  
  private static int llIIIlIlllll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static void llIIIlIlllIl()
  {
    lllllIIIlI = new int[11];
    lllllIIIlI[0] = (0x76 ^ 0x36);
    lllllIIIlI[1] = (0x41 ^ 0x61);
    lllllIIIlI[2] = ((0xBC ^ 0x82 ^ 0x26 ^ 0xA) & (0xF ^ 0x42 ^ 0x1C ^ 0x43 ^ -" ".length()));
    lllllIIIlI[3] = (0x3D ^ 0x55 ^ 0x66 ^ 0x1E);
    lllllIIIlI[4] = (0x86 ^ 0xBD ^ 0x41 ^ 0x72);
    lllllIIIlI[5] = (0xA2 ^ 0xAE);
    lllllIIIlI[6] = (0x88 ^ 0xC5 ^ 0x9 ^ 0x40);
    lllllIIIlI[7] = (100 + '' - 171 + 85 ^ 7 + 105 - 42 + 99);
    lllllIIIlI[8] = "  ".length();
    lllllIIIlI[9] = (0xD2 ^ 0x82 ^ 0x9 ^ 0x47);
    lllllIIIlI[10] = " ".length();
  }
  
  private static int llIIIlIllllI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
}

package net.minecraft.client.model;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityOcelot;
import net.minecraft.util.MathHelper;

public class ModelOcelot
  extends ModelBase
{
  private static String lIIlIIlIIlIl(String lllllllllllllllllllIllllIIllIIll, String lllllllllllllllllllIllllIIllIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIllllIIllIIll = new String(Base64.getDecoder().decode(lllllllllllllllllllIllllIIllIIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllllIllllIIllIllI = new StringBuilder();
    char[] lllllllllllllllllllIllllIIllIlIl = lllllllllllllllllllIllllIIllIIlI.toCharArray();
    int lllllllllllllllllllIllllIIllIlII = lIllllllll[1];
    byte lllllllllllllllllllIllllIIlIlllI = lllllllllllllllllllIllllIIllIIll.toCharArray();
    double lllllllllllllllllllIllllIIlIllIl = lllllllllllllllllllIllllIIlIlllI.length;
    int lllllllllllllllllllIllllIIlIllII = lIllllllll[1];
    while (lIIllIIIlIII(lllllllllllllllllllIllllIIlIllII, lllllllllllllllllllIllllIIlIllIl))
    {
      char lllllllllllllllllllIllllIIlllIIl = lllllllllllllllllllIllllIIlIlllI[lllllllllllllllllllIllllIIlIllII];
      "".length();
      "".length();
      if (-"   ".length() > 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllllIllllIIllIllI);
  }
  
  public void setRotationAngles(float lllllllllllllllllllIllllIllIIlll, float lllllllllllllllllllIllllIlIllllI, float lllllllllllllllllllIllllIllIIlIl, float lllllllllllllllllllIllllIlIlllIl, float lllllllllllllllllllIllllIlIlllII, float lllllllllllllllllllIllllIllIIIlI, Entity lllllllllllllllllllIllllIllIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ocelotHead.rotateAngleX = (lllllllllllllllllllIllllIlIlllII / 57.295776F);
    ocelotHead.rotateAngleY = (lllllllllllllllllllIllllIllIIlII / 57.295776F);
    if (lIIllIIIIllI(field_78163_i, lIllllllll[5]))
    {
      ocelotBody.rotateAngleX = 1.5707964F;
      if (lIIllIIIIlll(field_78163_i, lIllllllll[3]))
      {
        ocelotBackLeftLeg.rotateAngleX = (MathHelper.cos(lllllllllllllllllllIllllIllIIlll * 0.6662F) * 1.0F * lllllllllllllllllllIllllIlIllllI);
        ocelotBackRightLeg.rotateAngleX = (MathHelper.cos(lllllllllllllllllllIllllIllIIlll * 0.6662F + 0.3F) * 1.0F * lllllllllllllllllllIllllIlIllllI);
        ocelotFrontLeftLeg.rotateAngleX = (MathHelper.cos(lllllllllllllllllllIllllIllIIlll * 0.6662F + 3.1415927F + 0.3F) * 1.0F * lllllllllllllllllllIllllIlIllllI);
        ocelotFrontRightLeg.rotateAngleX = (MathHelper.cos(lllllllllllllllllllIllllIllIIlll * 0.6662F + 3.1415927F) * 1.0F * lllllllllllllllllllIllllIlIllllI);
        ocelotTail2.rotateAngleX = (1.7278761F + 0.31415927F * MathHelper.cos(lllllllllllllllllllIllllIllIIlll) * lllllllllllllllllllIllllIlIllllI);
        "".length();
        if (" ".length() <= "  ".length()) {}
      }
      else
      {
        ocelotBackLeftLeg.rotateAngleX = (MathHelper.cos(lllllllllllllllllllIllllIllIIlll * 0.6662F) * 1.0F * lllllllllllllllllllIllllIlIllllI);
        ocelotBackRightLeg.rotateAngleX = (MathHelper.cos(lllllllllllllllllllIllllIllIIlll * 0.6662F + 3.1415927F) * 1.0F * lllllllllllllllllllIllllIlIllllI);
        ocelotFrontLeftLeg.rotateAngleX = (MathHelper.cos(lllllllllllllllllllIllllIllIIlll * 0.6662F + 3.1415927F) * 1.0F * lllllllllllllllllllIllllIlIllllI);
        ocelotFrontRightLeg.rotateAngleX = (MathHelper.cos(lllllllllllllllllllIllllIllIIlll * 0.6662F) * 1.0F * lllllllllllllllllllIllllIlIllllI);
        if (lIIllIIIIlll(field_78163_i, lIllllllll[0]))
        {
          ocelotTail2.rotateAngleX = (1.7278761F + 0.7853982F * MathHelper.cos(lllllllllllllllllllIllllIllIIlll) * lllllllllllllllllllIllllIlIllllI);
          "".length();
          if ("   ".length() > "  ".length()) {}
        }
        else
        {
          ocelotTail2.rotateAngleX = (1.7278761F + 0.47123894F * MathHelper.cos(lllllllllllllllllllIllllIllIIlll) * lllllllllllllllllllIllllIlIllllI);
        }
      }
    }
  }
  
  private static String lIIlIIlIIlII(String lllllllllllllllllllIllllIIlIIIIl, String lllllllllllllllllllIllllIIlIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllllIllllIIlIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIllllIIlIIIlI.getBytes(StandardCharsets.UTF_8)), lIllllllll[10]), "DES");
      Cipher lllllllllllllllllllIllllIIlIIlIl = Cipher.getInstance("DES");
      lllllllllllllllllllIllllIIlIIlIl.init(lIllllllll[3], lllllllllllllllllllIllllIIlIIllI);
      return new String(lllllllllllllllllllIllllIIlIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIllllIIlIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllllIllllIIlIIlII)
    {
      lllllllllllllllllllIllllIIlIIlII.printStackTrace();
    }
    return null;
  }
  
  public ModelOcelot()
  {
    lllllllllllllllllllIlllllIIIlIIl.setTextureOffset(lIllIllllI[lIllllllll[1]], lIllllllll[1], lIllllllll[1]);
    lllllllllllllllllllIlllllIIIlIIl.setTextureOffset(lIllIllllI[lIllllllll[0]], lIllllllll[1], lIllllllll[2]);
    lllllllllllllllllllIlllllIIIlIIl.setTextureOffset(lIllIllllI[lIllllllll[3]], lIllllllll[1], lIllllllll[4]);
    lllllllllllllllllllIlllllIIIlIIl.setTextureOffset(lIllIllllI[lIllllllll[5]], lIllllllll[6], lIllllllll[4]);
    ocelotHead = new ModelRenderer(lllllllllllllllllllIlllllIIIlIIl, lIllIllllI[lIllllllll[7]]);
    "".length();
    "".length();
    "".length();
    "".length();
    ocelotHead.setRotationPoint(0.0F, 15.0F, -9.0F);
    ocelotBody = new ModelRenderer(lllllllllllllllllllIlllllIIIlIIl, lIllllllll[11], lIllllllll[1]);
    ocelotBody.addBox(-2.0F, 3.0F, -8.0F, lIllllllll[7], lIllllllll[12], lIllllllll[6], 0.0F);
    ocelotBody.setRotationPoint(0.0F, 12.0F, -10.0F);
    ocelotTail = new ModelRenderer(lllllllllllllllllllIlllllIIIlIIl, lIllllllll[1], lIllllllll[13]);
    "".length();
    ocelotTail.rotateAngleX = 0.9F;
    ocelotTail.setRotationPoint(0.0F, 15.0F, 8.0F);
    ocelotTail2 = new ModelRenderer(lllllllllllllllllllIlllllIIIlIIl, lIllllllll[7], lIllllllll[13]);
    "".length();
    ocelotTail2.setRotationPoint(0.0F, 20.0F, 14.0F);
    ocelotBackLeftLeg = new ModelRenderer(lllllllllllllllllllIlllllIIIlIIl, lIllllllll[10], lIllllllll[14]);
    "".length();
    ocelotBackLeftLeg.setRotationPoint(1.1F, 18.0F, 5.0F);
    ocelotBackRightLeg = new ModelRenderer(lllllllllllllllllllIlllllIIIlIIl, lIllllllll[10], lIllllllll[14]);
    "".length();
    ocelotBackRightLeg.setRotationPoint(-1.1F, 18.0F, 5.0F);
    ocelotFrontLeftLeg = new ModelRenderer(lllllllllllllllllllIlllllIIIlIIl, lIllllllll[15], lIllllllll[1]);
    "".length();
    ocelotFrontLeftLeg.setRotationPoint(1.2F, 13.8F, -5.0F);
    ocelotFrontRightLeg = new ModelRenderer(lllllllllllllllllllIlllllIIIlIIl, lIllllllll[15], lIllllllll[1]);
    "".length();
    ocelotFrontRightLeg.setRotationPoint(-1.2F, 13.8F, -5.0F);
  }
  
  public void render(Entity lllllllllllllllllllIllllIllllllI, float lllllllllllllllllllIllllIlllIlII, float lllllllllllllllllllIllllIlllIIll, float lllllllllllllllllllIllllIlllIIlI, float lllllllllllllllllllIllllIllllIlI, float lllllllllllllllllllIllllIlllIIII, float lllllllllllllllllllIllllIllIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllIllllIlllIllI.setRotationAngles(lllllllllllllllllllIllllIlllIlII, lllllllllllllllllllIllllIlllIIll, lllllllllllllllllllIllllIlllIIlI, lllllllllllllllllllIllllIllllIlI, lllllllllllllllllllIllllIlllIIII, lllllllllllllllllllIllllIllIllll, lllllllllllllllllllIllllIllllllI);
    if (lIIllIIIIlIl(isChild))
    {
      float lllllllllllllllllllIllllIlllIlll = 2.0F;
      GlStateManager.pushMatrix();
      GlStateManager.scale(1.5F / lllllllllllllllllllIllllIlllIlll, 1.5F / lllllllllllllllllllIllllIlllIlll, 1.5F / lllllllllllllllllllIllllIlllIlll);
      GlStateManager.translate(0.0F, 10.0F * lllllllllllllllllllIllllIllIllll, 4.0F * lllllllllllllllllllIllllIllIllll);
      ocelotHead.render(lllllllllllllllllllIllllIllIllll);
      GlStateManager.popMatrix();
      GlStateManager.pushMatrix();
      GlStateManager.scale(1.0F / lllllllllllllllllllIllllIlllIlll, 1.0F / lllllllllllllllllllIllllIlllIlll, 1.0F / lllllllllllllllllllIllllIlllIlll);
      GlStateManager.translate(0.0F, 24.0F * lllllllllllllllllllIllllIllIllll, 0.0F);
      ocelotBody.render(lllllllllllllllllllIllllIllIllll);
      ocelotBackLeftLeg.render(lllllllllllllllllllIllllIllIllll);
      ocelotBackRightLeg.render(lllllllllllllllllllIllllIllIllll);
      ocelotFrontLeftLeg.render(lllllllllllllllllllIllllIllIllll);
      ocelotFrontRightLeg.render(lllllllllllllllllllIllllIllIllll);
      ocelotTail.render(lllllllllllllllllllIllllIllIllll);
      ocelotTail2.render(lllllllllllllllllllIllllIllIllll);
      GlStateManager.popMatrix();
      "".length();
      if (" ".length() < "  ".length()) {}
    }
    else
    {
      ocelotHead.render(lllllllllllllllllllIllllIllIllll);
      ocelotBody.render(lllllllllllllllllllIllllIllIllll);
      ocelotTail.render(lllllllllllllllllllIllllIllIllll);
      ocelotTail2.render(lllllllllllllllllllIllllIllIllll);
      ocelotBackLeftLeg.render(lllllllllllllllllllIllllIllIllll);
      ocelotBackRightLeg.render(lllllllllllllllllllIllllIllIllll);
      ocelotFrontLeftLeg.render(lllllllllllllllllllIllllIllIllll);
      ocelotFrontRightLeg.render(lllllllllllllllllllIllllIllIllll);
    }
  }
  
  public void setLivingAnimations(EntityLivingBase lllllllllllllllllllIllllIlIlIIIl, float lllllllllllllllllllIllllIlIlIllI, float lllllllllllllllllllIllllIlIlIlIl, float lllllllllllllllllllIllllIlIlIlII)
  {
    ;
    ;
    ;
    EntityOcelot lllllllllllllllllllIllllIlIlIIll = (EntityOcelot)lllllllllllllllllllIllllIlIlIIIl;
    ocelotBody.rotationPointY = 12.0F;
    ocelotBody.rotationPointZ = -10.0F;
    ocelotHead.rotationPointY = 15.0F;
    ocelotHead.rotationPointZ = -9.0F;
    ocelotTail.rotationPointY = 15.0F;
    ocelotTail.rotationPointZ = 8.0F;
    ocelotTail2.rotationPointY = 20.0F;
    ocelotTail2.rotationPointZ = 14.0F;
    ocelotFrontLeftLeg.rotationPointY = (ocelotFrontRightLeg.rotationPointY = 13.8F);
    ocelotFrontLeftLeg.rotationPointZ = (ocelotFrontRightLeg.rotationPointZ = -5.0F);
    ocelotBackLeftLeg.rotationPointY = (ocelotBackRightLeg.rotationPointY = 18.0F);
    ocelotBackLeftLeg.rotationPointZ = (ocelotBackRightLeg.rotationPointZ = 5.0F);
    ocelotTail.rotateAngleX = 0.9F;
    if (lIIllIIIIlIl(lllllllllllllllllllIllllIlIlIIll.isSneaking()))
    {
      ocelotBody.rotationPointY += 1.0F;
      ocelotHead.rotationPointY += 2.0F;
      ocelotTail.rotationPointY += 1.0F;
      ocelotTail2.rotationPointY += -4.0F;
      ocelotTail2.rotationPointZ += 2.0F;
      ocelotTail.rotateAngleX = 1.5707964F;
      ocelotTail2.rotateAngleX = 1.5707964F;
      field_78163_i = lIllllllll[1];
      "".length();
      if (-"  ".length() < 0) {}
    }
    else if (lIIllIIIIlIl(lllllllllllllllllllIllllIlIlIIll.isSprinting()))
    {
      ocelotTail2.rotationPointY = ocelotTail.rotationPointY;
      ocelotTail2.rotationPointZ += 2.0F;
      ocelotTail.rotateAngleX = 1.5707964F;
      ocelotTail2.rotateAngleX = 1.5707964F;
      field_78163_i = lIllllllll[3];
      "".length();
      if ("  ".length() != "   ".length()) {}
    }
    else if (lIIllIIIIlIl(lllllllllllllllllllIllllIlIlIIll.isSitting()))
    {
      ocelotBody.rotateAngleX = 0.7853982F;
      ocelotBody.rotationPointY += -4.0F;
      ocelotBody.rotationPointZ += 5.0F;
      ocelotHead.rotationPointY += -3.3F;
      ocelotHead.rotationPointZ += 1.0F;
      ocelotTail.rotationPointY += 8.0F;
      ocelotTail.rotationPointZ += -2.0F;
      ocelotTail2.rotationPointY += 2.0F;
      ocelotTail2.rotationPointZ += -0.8F;
      ocelotTail.rotateAngleX = 1.7278761F;
      ocelotTail2.rotateAngleX = 2.670354F;
      ocelotFrontLeftLeg.rotateAngleX = (ocelotFrontRightLeg.rotateAngleX = -0.15707964F);
      ocelotFrontLeftLeg.rotationPointY = (ocelotFrontRightLeg.rotationPointY = 15.8F);
      ocelotFrontLeftLeg.rotationPointZ = (ocelotFrontRightLeg.rotationPointZ = -7.0F);
      ocelotBackLeftLeg.rotateAngleX = (ocelotBackRightLeg.rotateAngleX = -1.5707964F);
      ocelotBackLeftLeg.rotationPointY = (ocelotBackRightLeg.rotationPointY = 21.0F);
      ocelotBackLeftLeg.rotationPointZ = (ocelotBackRightLeg.rotationPointZ = 1.0F);
      field_78163_i = lIllllllll[5];
      "".length();
      if (null == null) {}
    }
    else
    {
      field_78163_i = lIllllllll[0];
    }
  }
  
  static
  {
    lIIllIIIIlII();
    lIIlIIlIIllI();
  }
  
  private static void lIIllIIIIlII()
  {
    lIllllllll = new int[17];
    lIllllllll[0] = " ".length();
    lIllllllll[1] = ((0x1E ^ 0x38) & (0x57 ^ 0x71 ^ 0xFFFFFFFF));
    lIllllllll[2] = (120 + 43 - 156 + 122 ^ 75 + 83 - 134 + 129);
    lIllllllll[3] = "  ".length();
    lIllllllll[4] = (0xBF ^ 0xB5);
    lIllllllll[5] = "   ".length();
    lIllllllll[6] = (74 + 3 - 22 + 144 ^ 19 + '­' - 163 + 164);
    lIllllllll[7] = (0x8D ^ 0x89);
    lIllllllll[8] = (0xF6 ^ 0x98 ^ 0x7B ^ 0x10);
    lIllllllll[9] = (0x37 ^ 0x30);
    lIllllllll[10] = (0x6B ^ 0x63);
    lIllllllll[11] = (0xB2 ^ 0xA6);
    lIllllllll[12] = (0xF ^ 0x1F);
    lIllllllll[13] = (0x38 ^ 0x37);
    lIllllllll[14] = (124 + 38 - 124 + 120 ^ 33 + 11 - 43 + 146);
    lIllllllll[15] = (0x9 ^ 0x21);
    lIllllllll[16] = (0xF ^ 0x5E ^ 0xD3 ^ 0x8B);
  }
  
  private static boolean lIIllIIIIlll(int ???, int arg1)
  {
    int i;
    long lllllllllllllllllllIllllIIIllIlI;
    return ??? == i;
  }
  
  private static boolean lIIllIIIlIII(int ???, int arg1)
  {
    int i;
    char lllllllllllllllllllIllllIIIlIllI;
    return ??? < i;
  }
  
  private static String lIIlIIIlllll(String lllllllllllllllllllIllllIlIIlIII, String lllllllllllllllllllIllllIlIIIlIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllllIllllIlIIlIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIllllIlIIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllllIllllIlIIlIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllllllIllllIlIIlIlI.init(lIllllllll[3], lllllllllllllllllllIllllIlIIlIll);
      return new String(lllllllllllllllllllIllllIlIIlIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIllllIlIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllllIllllIlIIlIIl)
    {
      lllllllllllllllllllIllllIlIIlIIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIllIIIIllI(int ???, int arg1)
  {
    int i;
    double lllllllllllllllllllIllllIIIlIIII;
    return ??? != i;
  }
  
  private static void lIIlIIlIIllI()
  {
    lIllIllllI = new String[lIllllllll[16]];
    lIllIllllI[lIllllllll[1]] = lIIlIIIlllll("AOeNcXe488MrwCqtrm5knQ==", "XflYS");
    lIllIllllI[lIllllllll[0]] = lIIlIIIlllll("hKLQ0ALY43V3h9P0lsTZ2w==", "qzKQR");
    lIllIllllI[lIllllllll[3]] = lIIlIIlIIlII("buGOTKFYoX0Ug/mJyrEWCA==", "HgAeB");
    lIllIllllI[lIllllllll[5]] = lIIlIIlIIlII("Gm47a1OVsFkimhLQdXjWqQ==", "WOwmX");
    lIllIllllI[lIllllllll[7]] = lIIlIIlIIlIl("Ii8DAw==", "JJbgM");
    lIllIllllI[lIllllllll[8]] = lIIlIIlIIlIl("Kgs7AA==", "GjRnB");
    lIllIllllI[lIllllllll[6]] = lIIlIIlIIlII("GUPASNaQLaM=", "YAgWY");
    lIllIllllI[lIllllllll[9]] = lIIlIIIlllll("i0PapdKKops=", "rHrDq");
    lIllIllllI[lIllllllll[10]] = lIIlIIlIIlIl("JxE/ZA==", "BpMVb");
  }
  
  private static boolean lIIllIIIIlIl(int ???)
  {
    float lllllllllllllllllllIllllIIIlIlII;
    return ??? != 0;
  }
}

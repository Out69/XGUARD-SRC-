package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMagmaCube;

public class ModelMagmaCube
  extends ModelBase
{
  public void setLivingAnimations(EntityLivingBase llllllllllllllIlllIIlIlIlIIIIlII, float llllllllllllllIlllIIlIlIlIIlIIlI, float llllllllllllllIlllIIlIlIlIIlIIII, float llllllllllllllIlllIIlIlIlIIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    EntityMagmaCube llllllllllllllIlllIIlIlIlIIIllII = (EntityMagmaCube)llllllllllllllIlllIIlIlIlIIIIlII;
    float llllllllllllllIlllIIlIlIlIIIlIlI = prevSquishFactor + (squishFactor - prevSquishFactor) * llllllllllllllIlllIIlIlIlIIIlllI;
    if (lIllIIIlIIIIIl(lIllIIIlIIIIII(llllllllllllllIlllIIlIlIlIIIlIlI, 0.0F))) {
      llllllllllllllIlllIIlIlIlIIIlIlI = 0.0F;
    }
    int llllllllllllllIlllIIlIlIlIIIlIII = lllIIllIlllI[1];
    "".length();
    if (null != null) {
      return;
    }
    while (!lIllIIIIllllll(llllllllllllllIlllIIlIlIlIIIlIII, segments.length))
    {
      segments[llllllllllllllIlllIIlIlIlIIIlIII].rotationPointY = (-(lllIIllIlllI[9] - llllllllllllllIlllIIlIlIlIIIlIII) * llllllllllllllIlllIIlIlIlIIIlIlI * 1.7F);
      llllllllllllllIlllIIlIlIlIIIlIII++;
    }
  }
  
  public void render(Entity llllllllllllllIlllIIlIlIIllIllll, float llllllllllllllIlllIIlIlIIllIIIII, float llllllllllllllIlllIIlIlIIlIllllI, float llllllllllllllIlllIIlIlIIllIllII, float llllllllllllllIlllIIlIlIIlIlllII, float llllllllllllllIlllIIlIlIIllIlIIl, float llllllllllllllIlllIIlIlIIlIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlllIIlIlIIlllIIII.setRotationAngles(llllllllllllllIlllIIlIlIIllIIIII, llllllllllllllIlllIIlIlIIlIllllI, llllllllllllllIlllIIlIlIIllIllII, llllllllllllllIlllIIlIlIIlIlllII, llllllllllllllIlllIIlIlIIllIlIIl, llllllllllllllIlllIIlIlIIlIllIlI, llllllllllllllIlllIIlIlIIllIllll);
    core.render(llllllllllllllIlllIIlIlIIlIllIlI);
    int llllllllllllllIlllIIlIlIIllIIllI = lllIIllIlllI[1];
    "".length();
    if (-"  ".length() > 0) {
      return;
    }
    while (!lIllIIIIllllll(llllllllllllllIlllIIlIlIIllIIllI, segments.length))
    {
      segments[llllllllllllllIlllIIlIlIIllIIllI].render(llllllllllllllIlllIIlIlIIlIllIlI);
      llllllllllllllIlllIIlIlIIllIIllI++;
    }
  }
  
  private static boolean lIllIIIIllllll(int ???, int arg1)
  {
    int i;
    int llllllllllllllIlllIIlIlIIlIIIlll;
    return ??? >= i;
  }
  
  static {}
  
  private static int lIllIIIlIIIIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIllIIIlIIIIIl(int ???)
  {
    char llllllllllllllIlllIIlIlIIlIIIlIl;
    return ??? < 0;
  }
  
  private static void lIllIIIIllllIl()
  {
    lllIIllIlllI = new int[10];
    lllIIllIlllI[0] = (65 + 106 - 44 + 33 ^ 38 + 6 - -32 + 92);
    lllIIllIlllI[1] = ((0x3F ^ 0x7C) & (0x47 ^ 0x4 ^ 0xFFFFFFFF));
    lllIIllIlllI[2] = "  ".length();
    lllIIllIlllI[3] = (0x63 ^ 0x16 ^ 0xDC ^ 0xB1);
    lllIIllIlllI[4] = ('' + 22 - 131 + 113 ^ 118 + 45 - 45 + 12);
    lllIIllIlllI[5] = "   ".length();
    lllIIllIlllI[6] = (0xB9 ^ 0xAA);
    lllIIllIlllI[7] = (0x8 ^ 0x3A ^ 0x5F ^ 0x7D);
    lllIIllIlllI[8] = " ".length();
    lllIIllIlllI[9] = (0x6F ^ 0x26 ^ 0x8D ^ 0xC0);
  }
  
  private static boolean lIllIIIIlllllI(int ???, int arg1)
  {
    int i;
    short llllllllllllllIlllIIlIlIIlIIlIll;
    return ??? == i;
  }
  
  public ModelMagmaCube()
  {
    int llllllllllllllIlllIIlIlIlIlIllll = lllIIllIlllI[1];
    "".length();
    if (-" ".length() >= " ".length()) {
      throw null;
    }
    while (!lIllIIIIllllll(llllllllllllllIlllIIlIlIlIlIllll, segments.length))
    {
      int llllllllllllllIlllIIlIlIlIlIlllI = lllIIllIlllI[1];
      int llllllllllllllIlllIIlIlIlIlIllIl = llllllllllllllIlllIIlIlIlIlIllll;
      if (lIllIIIIlllllI(llllllllllllllIlllIIlIlIlIlIllll, lllIIllIlllI[2]))
      {
        llllllllllllllIlllIIlIlIlIlIlllI = lllIIllIlllI[3];
        llllllllllllllIlllIIlIlIlIlIllIl = lllIIllIlllI[4];
        "".length();
        if (-(0x3D ^ 0xB ^ 0x58 ^ 0x6B) >= 0) {
          throw null;
        }
      }
      else if (lIllIIIIlllllI(llllllllllllllIlllIIlIlIlIlIllll, lllIIllIlllI[5]))
      {
        llllllllllllllIlllIIlIlIlIlIlllI = lllIIllIlllI[3];
        llllllllllllllIlllIIlIlIlIlIllIl = lllIIllIlllI[6];
      }
      segments[llllllllllllllIlllIIlIlIlIlIllll] = new ModelRenderer(llllllllllllllIlllIIlIlIlIllIIII, llllllllllllllIlllIIlIlIlIlIlllI, llllllllllllllIlllIIlIlIlIlIllIl);
      "".length();
    }
    core = new ModelRenderer(llllllllllllllIlllIIlIlIlIllIIII, lllIIllIlllI[1], lllIIllIlllI[7]);
    "".length();
  }
}

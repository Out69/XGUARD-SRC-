package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelSpider
  extends ModelBase
{
  public void render(Entity lllllllllllllllIlIIllllllIIllIIl, float lllllllllllllllIlIIllllllIIlIIII, float lllllllllllllllIlIIllllllIIIllll, float lllllllllllllllIlIIllllllIIlIllI, float lllllllllllllllIlIIllllllIIIllIl, float lllllllllllllllIlIIllllllIIIllII, float lllllllllllllllIlIIllllllIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIIllllllIIllIlI.setRotationAngles(lllllllllllllllIlIIllllllIIlIIII, lllllllllllllllIlIIllllllIIIllll, lllllllllllllllIlIIllllllIIlIllI, lllllllllllllllIlIIllllllIIIllIl, lllllllllllllllIlIIllllllIIIllII, lllllllllllllllIlIIllllllIIlIIll, lllllllllllllllIlIIllllllIIllIIl);
    spiderHead.render(lllllllllllllllIlIIllllllIIlIIll);
    spiderNeck.render(lllllllllllllllIlIIllllllIIlIIll);
    spiderBody.render(lllllllllllllllIlIIllllllIIlIIll);
    spiderLeg1.render(lllllllllllllllIlIIllllllIIlIIll);
    spiderLeg2.render(lllllllllllllllIlIIllllllIIlIIll);
    spiderLeg3.render(lllllllllllllllIlIIllllllIIlIIll);
    spiderLeg4.render(lllllllllllllllIlIIllllllIIlIIll);
    spiderLeg5.render(lllllllllllllllIlIIllllllIIlIIll);
    spiderLeg6.render(lllllllllllllllIlIIllllllIIlIIll);
    spiderLeg7.render(lllllllllllllllIlIIllllllIIlIIll);
    spiderLeg8.render(lllllllllllllllIlIIllllllIIlIIll);
  }
  
  public ModelSpider()
  {
    float lllllllllllllllIlIIllllllIlIIlll = 0.0F;
    int lllllllllllllllIlIIllllllIlIIllI = lIlIIIlIlIll[0];
    spiderHead = new ModelRenderer(lllllllllllllllIlIIllllllIlIlIII, lIlIIIlIlIll[1], lIlIIIlIlIll[2]);
    spiderHead.addBox(-4.0F, -4.0F, -8.0F, lIlIIIlIlIll[3], lIlIIIlIlIll[3], lIlIIIlIlIll[3], lllllllllllllllIlIIllllllIlIIlll);
    spiderHead.setRotationPoint(0.0F, lllllllllllllllIlIIllllllIlIIllI, -3.0F);
    spiderNeck = new ModelRenderer(lllllllllllllllIlIIllllllIlIlIII, lIlIIIlIlIll[4], lIlIIIlIlIll[4]);
    spiderNeck.addBox(-3.0F, -3.0F, -3.0F, lIlIIIlIlIll[5], lIlIIIlIlIll[5], lIlIIIlIlIll[5], lllllllllllllllIlIIllllllIlIIlll);
    spiderNeck.setRotationPoint(0.0F, lllllllllllllllIlIIllllllIlIIllI, 0.0F);
    spiderBody = new ModelRenderer(lllllllllllllllIlIIllllllIlIlIII, lIlIIIlIlIll[4], lIlIIIlIlIll[6]);
    spiderBody.addBox(-5.0F, -4.0F, -6.0F, lIlIIIlIlIll[7], lIlIIIlIlIll[3], lIlIIIlIlIll[6], lllllllllllllllIlIIllllllIlIIlll);
    spiderBody.setRotationPoint(0.0F, lllllllllllllllIlIIllllllIlIIllI, 9.0F);
    spiderLeg1 = new ModelRenderer(lllllllllllllllIlIIllllllIlIlIII, lIlIIIlIlIll[8], lIlIIIlIlIll[4]);
    spiderLeg1.addBox(-15.0F, -1.0F, -1.0F, lIlIIIlIlIll[9], lIlIIIlIlIll[10], lIlIIIlIlIll[10], lllllllllllllllIlIIllllllIlIIlll);
    spiderLeg1.setRotationPoint(-4.0F, lllllllllllllllIlIIllllllIlIIllI, 2.0F);
    spiderLeg2 = new ModelRenderer(lllllllllllllllIlIIllllllIlIlIII, lIlIIIlIlIll[8], lIlIIIlIlIll[4]);
    spiderLeg2.addBox(-1.0F, -1.0F, -1.0F, lIlIIIlIlIll[9], lIlIIIlIlIll[10], lIlIIIlIlIll[10], lllllllllllllllIlIIllllllIlIIlll);
    spiderLeg2.setRotationPoint(4.0F, lllllllllllllllIlIIllllllIlIIllI, 2.0F);
    spiderLeg3 = new ModelRenderer(lllllllllllllllIlIIllllllIlIlIII, lIlIIIlIlIll[8], lIlIIIlIlIll[4]);
    spiderLeg3.addBox(-15.0F, -1.0F, -1.0F, lIlIIIlIlIll[9], lIlIIIlIlIll[10], lIlIIIlIlIll[10], lllllllllllllllIlIIllllllIlIIlll);
    spiderLeg3.setRotationPoint(-4.0F, lllllllllllllllIlIIllllllIlIIllI, 1.0F);
    spiderLeg4 = new ModelRenderer(lllllllllllllllIlIIllllllIlIlIII, lIlIIIlIlIll[8], lIlIIIlIlIll[4]);
    spiderLeg4.addBox(-1.0F, -1.0F, -1.0F, lIlIIIlIlIll[9], lIlIIIlIlIll[10], lIlIIIlIlIll[10], lllllllllllllllIlIIllllllIlIIlll);
    spiderLeg4.setRotationPoint(4.0F, lllllllllllllllIlIIllllllIlIIllI, 1.0F);
    spiderLeg5 = new ModelRenderer(lllllllllllllllIlIIllllllIlIlIII, lIlIIIlIlIll[8], lIlIIIlIlIll[4]);
    spiderLeg5.addBox(-15.0F, -1.0F, -1.0F, lIlIIIlIlIll[9], lIlIIIlIlIll[10], lIlIIIlIlIll[10], lllllllllllllllIlIIllllllIlIIlll);
    spiderLeg5.setRotationPoint(-4.0F, lllllllllllllllIlIIllllllIlIIllI, 0.0F);
    spiderLeg6 = new ModelRenderer(lllllllllllllllIlIIllllllIlIlIII, lIlIIIlIlIll[8], lIlIIIlIlIll[4]);
    spiderLeg6.addBox(-1.0F, -1.0F, -1.0F, lIlIIIlIlIll[9], lIlIIIlIlIll[10], lIlIIIlIlIll[10], lllllllllllllllIlIIllllllIlIIlll);
    spiderLeg6.setRotationPoint(4.0F, lllllllllllllllIlIIllllllIlIIllI, 0.0F);
    spiderLeg7 = new ModelRenderer(lllllllllllllllIlIIllllllIlIlIII, lIlIIIlIlIll[8], lIlIIIlIlIll[4]);
    spiderLeg7.addBox(-15.0F, -1.0F, -1.0F, lIlIIIlIlIll[9], lIlIIIlIlIll[10], lIlIIIlIlIll[10], lllllllllllllllIlIIllllllIlIIlll);
    spiderLeg7.setRotationPoint(-4.0F, lllllllllllllllIlIIllllllIlIIllI, -1.0F);
    spiderLeg8 = new ModelRenderer(lllllllllllllllIlIIllllllIlIlIII, lIlIIIlIlIll[8], lIlIIIlIlIll[4]);
    spiderLeg8.addBox(-1.0F, -1.0F, -1.0F, lIlIIIlIlIll[9], lIlIIIlIlIll[10], lIlIIIlIlIll[10], lllllllllllllllIlIIllllllIlIIlll);
    spiderLeg8.setRotationPoint(4.0F, lllllllllllllllIlIIllllllIlIIllI, -1.0F);
  }
  
  public void setRotationAngles(float lllllllllllllllIlIIlllllIllllIIl, float lllllllllllllllIlIIlllllIllllIII, float lllllllllllllllIlIIlllllIlllIlll, float lllllllllllllllIlIIlllllIlllIllI, float lllllllllllllllIlIIlllllIllIIIll, float lllllllllllllllIlIIlllllIlllIlII, Entity lllllllllllllllIlIIlllllIlllIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    spiderHead.rotateAngleY = (lllllllllllllllIlIIlllllIllIIlII / 57.295776F);
    spiderHead.rotateAngleX = (lllllllllllllllIlIIlllllIllIIIll / 57.295776F);
    float lllllllllllllllIlIIlllllIlllIIlI = 0.7853982F;
    spiderLeg1.rotateAngleZ = (-lllllllllllllllIlIIlllllIlllIIlI);
    spiderLeg2.rotateAngleZ = lllllllllllllllIlIIlllllIlllIIlI;
    spiderLeg3.rotateAngleZ = (-lllllllllllllllIlIIlllllIlllIIlI * 0.74F);
    spiderLeg4.rotateAngleZ = (lllllllllllllllIlIIlllllIlllIIlI * 0.74F);
    spiderLeg5.rotateAngleZ = (-lllllllllllllllIlIIlllllIlllIIlI * 0.74F);
    spiderLeg6.rotateAngleZ = (lllllllllllllllIlIIlllllIlllIIlI * 0.74F);
    spiderLeg7.rotateAngleZ = (-lllllllllllllllIlIIlllllIlllIIlI);
    spiderLeg8.rotateAngleZ = lllllllllllllllIlIIlllllIlllIIlI;
    float lllllllllllllllIlIIlllllIlllIIIl = -0.0F;
    float lllllllllllllllIlIIlllllIlllIIII = 0.3926991F;
    spiderLeg1.rotateAngleY = (lllllllllllllllIlIIlllllIlllIIII * 2.0F + lllllllllllllllIlIIlllllIlllIIIl);
    spiderLeg2.rotateAngleY = (-lllllllllllllllIlIIlllllIlllIIII * 2.0F - lllllllllllllllIlIIlllllIlllIIIl);
    spiderLeg3.rotateAngleY = (lllllllllllllllIlIIlllllIlllIIII * 1.0F + lllllllllllllllIlIIlllllIlllIIIl);
    spiderLeg4.rotateAngleY = (-lllllllllllllllIlIIlllllIlllIIII * 1.0F - lllllllllllllllIlIIlllllIlllIIIl);
    spiderLeg5.rotateAngleY = (-lllllllllllllllIlIIlllllIlllIIII * 1.0F + lllllllllllllllIlIIlllllIlllIIIl);
    spiderLeg6.rotateAngleY = (lllllllllllllllIlIIlllllIlllIIII * 1.0F - lllllllllllllllIlIIlllllIlllIIIl);
    spiderLeg7.rotateAngleY = (-lllllllllllllllIlIIlllllIlllIIII * 2.0F + lllllllllllllllIlIIlllllIlllIIIl);
    spiderLeg8.rotateAngleY = (lllllllllllllllIlIIlllllIlllIIII * 2.0F - lllllllllllllllIlIIlllllIlllIIIl);
    float lllllllllllllllIlIIlllllIllIllll = -(MathHelper.cos(lllllllllllllllIlIIlllllIllllIIl * 0.6662F * 2.0F + 0.0F) * 0.4F) * lllllllllllllllIlIIlllllIllllIII;
    float lllllllllllllllIlIIlllllIllIlllI = -(MathHelper.cos(lllllllllllllllIlIIlllllIllllIIl * 0.6662F * 2.0F + 3.1415927F) * 0.4F) * lllllllllllllllIlIIlllllIllllIII;
    float lllllllllllllllIlIIlllllIllIllIl = -(MathHelper.cos(lllllllllllllllIlIIlllllIllllIIl * 0.6662F * 2.0F + 1.5707964F) * 0.4F) * lllllllllllllllIlIIlllllIllllIII;
    float lllllllllllllllIlIIlllllIllIllII = -(MathHelper.cos(lllllllllllllllIlIIlllllIllllIIl * 0.6662F * 2.0F + 4.712389F) * 0.4F) * lllllllllllllllIlIIlllllIllllIII;
    float lllllllllllllllIlIIlllllIllIlIll = Math.abs(MathHelper.sin(lllllllllllllllIlIIlllllIllllIIl * 0.6662F + 0.0F) * 0.4F) * lllllllllllllllIlIIlllllIllllIII;
    float lllllllllllllllIlIIlllllIllIlIlI = Math.abs(MathHelper.sin(lllllllllllllllIlIIlllllIllllIIl * 0.6662F + 3.1415927F) * 0.4F) * lllllllllllllllIlIIlllllIllllIII;
    float lllllllllllllllIlIIlllllIllIlIIl = Math.abs(MathHelper.sin(lllllllllllllllIlIIlllllIllllIIl * 0.6662F + 1.5707964F) * 0.4F) * lllllllllllllllIlIIlllllIllllIII;
    float lllllllllllllllIlIIlllllIllIlIII = Math.abs(MathHelper.sin(lllllllllllllllIlIIlllllIllllIIl * 0.6662F + 4.712389F) * 0.4F) * lllllllllllllllIlIIlllllIllllIII;
    spiderLeg1.rotateAngleY += lllllllllllllllIlIIlllllIllIllll;
    spiderLeg2.rotateAngleY += -lllllllllllllllIlIIlllllIllIllll;
    spiderLeg3.rotateAngleY += lllllllllllllllIlIIlllllIllIlllI;
    spiderLeg4.rotateAngleY += -lllllllllllllllIlIIlllllIllIlllI;
    spiderLeg5.rotateAngleY += lllllllllllllllIlIIlllllIllIllIl;
    spiderLeg6.rotateAngleY += -lllllllllllllllIlIIlllllIllIllIl;
    spiderLeg7.rotateAngleY += lllllllllllllllIlIIlllllIllIllII;
    spiderLeg8.rotateAngleY += -lllllllllllllllIlIIlllllIllIllII;
    spiderLeg1.rotateAngleZ += lllllllllllllllIlIIlllllIllIlIll;
    spiderLeg2.rotateAngleZ += -lllllllllllllllIlIIlllllIllIlIll;
    spiderLeg3.rotateAngleZ += lllllllllllllllIlIIlllllIllIlIlI;
    spiderLeg4.rotateAngleZ += -lllllllllllllllIlIIlllllIllIlIlI;
    spiderLeg5.rotateAngleZ += lllllllllllllllIlIIlllllIllIlIIl;
    spiderLeg6.rotateAngleZ += -lllllllllllllllIlIIlllllIllIlIIl;
    spiderLeg7.rotateAngleZ += lllllllllllllllIlIIlllllIllIlIII;
    spiderLeg8.rotateAngleZ += -lllllllllllllllIlIIlllllIllIlIII;
  }
  
  static {}
  
  private static void lllllIllIIIll()
  {
    lIlIIIlIlIll = new int[11];
    lIlIIIlIlIll[0] = (0x87 ^ 0x88);
    lIlIIIlIlIll[1] = (0x50 ^ 0x14 ^ 0xFB ^ 0x9F);
    lIlIIIlIlIll[2] = (0xB6 ^ 0xB2);
    lIlIIIlIlIll[3] = (17 + '¿' - 122 + 115 ^ 49 + 'µ' - 219 + 182);
    lIlIIIlIlIll[4] = ((0x37 ^ 0x63) & (0x3 ^ 0x57 ^ 0xFFFFFFFF));
    lIlIIIlIlIll[5] = (0x96 ^ 0x90);
    lIlIIIlIlIll[6] = (0x37 ^ 0x3B);
    lIlIIIlIlIll[7] = (98 + 12 - 11 + 33 ^ 74 + 14 - 87 + 141);
    lIlIIIlIlIll[8] = (0x10 ^ 0x2);
    lIlIIIlIlIll[9] = (0xB3 ^ 0xA3);
    lIlIIIlIlIll[10] = "  ".length();
  }
}

package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelCreeper
  extends ModelBase
{
  private static void lllIIllllllIII()
  {
    lIIlIlllIIlIl = new int[7];
    lIIlIlllIIlIl[0] = (0x2E ^ 0x62 ^ 0x18 ^ 0x52);
    lIIlIlllIIlIl[1] = (('' + 72 - 34 + 45 ^ 112 + 118 - 191 + 112) & (0xFA ^ 0x88 ^ 0xA6 ^ 0x9E ^ -" ".length()));
    lIIlIlllIIlIl[2] = (0x32 ^ 0x43 ^ 0xDA ^ 0xA3);
    lIIlIlllIIlIl[3] = (0xD4 ^ 0xA6 ^ 0x51 ^ 0x3);
    lIIlIlllIIlIl[4] = (0x2D ^ 0x3D);
    lIIlIlllIIlIl[5] = (0x78 ^ 0x74);
    lIIlIlllIIlIl[6] = (0x16 ^ 0x40 ^ 0x58 ^ 0xA);
  }
  
  public ModelCreeper()
  {
    llllllllllllllIIlllIlIIlIIIlllll.<init>(0.0F);
  }
  
  public ModelCreeper(float llllllllllllllIIlllIlIIlIIIlIllI)
  {
    int llllllllllllllIIlllIlIIlIIIllIII = lIIlIlllIIlIl[0];
    head = new ModelRenderer(llllllllllllllIIlllIlIIlIIIlIlll, lIIlIlllIIlIl[1], lIIlIlllIIlIl[1]);
    head.addBox(-4.0F, -8.0F, -4.0F, lIIlIlllIIlIl[2], lIIlIlllIIlIl[2], lIIlIlllIIlIl[2], llllllllllllllIIlllIlIIlIIIlIllI);
    head.setRotationPoint(0.0F, llllllllllllllIIlllIlIIlIIIllIII, 0.0F);
    creeperArmor = new ModelRenderer(llllllllllllllIIlllIlIIlIIIlIlll, lIIlIlllIIlIl[3], lIIlIlllIIlIl[1]);
    creeperArmor.addBox(-4.0F, -8.0F, -4.0F, lIIlIlllIIlIl[2], lIIlIlllIIlIl[2], lIIlIlllIIlIl[2], llllllllllllllIIlllIlIIlIIIlIllI + 0.5F);
    creeperArmor.setRotationPoint(0.0F, llllllllllllllIIlllIlIIlIIIllIII, 0.0F);
    body = new ModelRenderer(llllllllllllllIIlllIlIIlIIIlIlll, lIIlIlllIIlIl[4], lIIlIlllIIlIl[4]);
    body.addBox(-4.0F, 0.0F, -2.0F, lIIlIlllIIlIl[2], lIIlIlllIIlIl[5], lIIlIlllIIlIl[6], llllllllllllllIIlllIlIIlIIIlIllI);
    body.setRotationPoint(0.0F, llllllllllllllIIlllIlIIlIIIllIII, 0.0F);
    leg1 = new ModelRenderer(llllllllllllllIIlllIlIIlIIIlIlll, lIIlIlllIIlIl[1], lIIlIlllIIlIl[4]);
    leg1.addBox(-2.0F, 0.0F, -2.0F, lIIlIlllIIlIl[6], lIIlIlllIIlIl[0], lIIlIlllIIlIl[6], llllllllllllllIIlllIlIIlIIIlIllI);
    leg1.setRotationPoint(-2.0F, lIIlIlllIIlIl[5] + llllllllllllllIIlllIlIIlIIIllIII, 4.0F);
    leg2 = new ModelRenderer(llllllllllllllIIlllIlIIlIIIlIlll, lIIlIlllIIlIl[1], lIIlIlllIIlIl[4]);
    leg2.addBox(-2.0F, 0.0F, -2.0F, lIIlIlllIIlIl[6], lIIlIlllIIlIl[0], lIIlIlllIIlIl[6], llllllllllllllIIlllIlIIlIIIlIllI);
    leg2.setRotationPoint(2.0F, lIIlIlllIIlIl[5] + llllllllllllllIIlllIlIIlIIIllIII, 4.0F);
    leg3 = new ModelRenderer(llllllllllllllIIlllIlIIlIIIlIlll, lIIlIlllIIlIl[1], lIIlIlllIIlIl[4]);
    leg3.addBox(-2.0F, 0.0F, -2.0F, lIIlIlllIIlIl[6], lIIlIlllIIlIl[0], lIIlIlllIIlIl[6], llllllllllllllIIlllIlIIlIIIlIllI);
    leg3.setRotationPoint(-2.0F, lIIlIlllIIlIl[5] + llllllllllllllIIlllIlIIlIIIllIII, -4.0F);
    leg4 = new ModelRenderer(llllllllllllllIIlllIlIIlIIIlIlll, lIIlIlllIIlIl[1], lIIlIlllIIlIl[4]);
    leg4.addBox(-2.0F, 0.0F, -2.0F, lIIlIlllIIlIl[6], lIIlIlllIIlIl[0], lIIlIlllIIlIl[6], llllllllllllllIIlllIlIIlIIIlIllI);
    leg4.setRotationPoint(2.0F, lIIlIlllIIlIl[5] + llllllllllllllIIlllIlIIlIIIllIII, -4.0F);
  }
  
  public void setRotationAngles(float llllllllllllllIIlllIlIIIllllIllI, float llllllllllllllIIlllIlIIIlllIllIl, float llllllllllllllIIlllIlIIIllllIlII, float llllllllllllllIIlllIlIIIllllIIll, float llllllllllllllIIlllIlIIIlllIlIll, float llllllllllllllIIlllIlIIIllllIIIl, Entity llllllllllllllIIlllIlIIIllllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    head.rotateAngleY = (llllllllllllllIIlllIlIIIlllIllII / 57.295776F);
    head.rotateAngleX = (llllllllllllllIIlllIlIIIlllIlIll / 57.295776F);
    leg1.rotateAngleX = (MathHelper.cos(llllllllllllllIIlllIlIIIllllIllI * 0.6662F) * 1.4F * llllllllllllllIIlllIlIIIlllIllIl);
    leg2.rotateAngleX = (MathHelper.cos(llllllllllllllIIlllIlIIIllllIllI * 0.6662F + 3.1415927F) * 1.4F * llllllllllllllIIlllIlIIIlllIllIl);
    leg3.rotateAngleX = (MathHelper.cos(llllllllllllllIIlllIlIIIllllIllI * 0.6662F + 3.1415927F) * 1.4F * llllllllllllllIIlllIlIIIlllIllIl);
    leg4.rotateAngleX = (MathHelper.cos(llllllllllllllIIlllIlIIIllllIllI * 0.6662F) * 1.4F * llllllllllllllIIlllIlIIIlllIllIl);
  }
  
  static {}
  
  public void render(Entity llllllllllllllIIlllIlIIlIIIIIIll, float llllllllllllllIIlllIlIIlIIIIIIlI, float llllllllllllllIIlllIlIIlIIIIlIIl, float llllllllllllllIIlllIlIIlIIIIIIII, float llllllllllllllIIlllIlIIlIIIIIlll, float llllllllllllllIIlllIlIIIlllllllI, float llllllllllllllIIlllIlIIlIIIIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIlllIlIIlIIIIllII.setRotationAngles(llllllllllllllIIlllIlIIlIIIIIIlI, llllllllllllllIIlllIlIIlIIIIlIIl, llllllllllllllIIlllIlIIlIIIIIIII, llllllllllllllIIlllIlIIlIIIIIlll, llllllllllllllIIlllIlIIIlllllllI, llllllllllllllIIlllIlIIlIIIIIlIl, llllllllllllllIIlllIlIIlIIIIIIll);
    head.render(llllllllllllllIIlllIlIIlIIIIIlIl);
    body.render(llllllllllllllIIlllIlIIlIIIIIlIl);
    leg1.render(llllllllllllllIIlllIlIIlIIIIIlIl);
    leg2.render(llllllllllllllIIlllIlIIlIIIIIlIl);
    leg3.render(llllllllllllllIIlllIlIIlIIIIIlIl);
    leg4.render(llllllllllllllIIlllIlIIlIIIIIlIl);
  }
}

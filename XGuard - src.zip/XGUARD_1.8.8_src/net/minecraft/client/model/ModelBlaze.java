package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelBlaze
  extends ModelBase
{
  public ModelBlaze()
  {
    int llllllllllllllIlIlIIIIIIlIlllIlI = lIIIlIIllIlll[1];
    "".length();
    if ("   ".length() <= 0) {
      throw null;
    }
    while (!llIlIIlIIllIIl(llllllllllllllIlIlIIIIIIlIlllIlI, blazeSticks.length))
    {
      blazeSticks[llllllllllllllIlIlIIIIIIlIlllIlI] = new ModelRenderer(llllllllllllllIlIlIIIIIIlIlllIll, lIIIlIIllIlll[1], lIIIlIIllIlll[2]);
      "".length();
    }
    blazeHead = new ModelRenderer(llllllllllllllIlIlIIIIIIlIlllIll, lIIIlIIllIlll[1], lIIIlIIllIlll[1]);
    "".length();
  }
  
  private static void llIlIIlIIllIII()
  {
    lIIIlIIllIlll = new int[6];
    lIIIlIIllIlll[0] = (0x30 ^ 0x3C);
    lIIIlIIllIlll[1] = ((0xA7 ^ 0x9E ^ 0x43 ^ 0x77) & (0x98 ^ 0x9D ^ 0xCC ^ 0xC4 ^ -" ".length()));
    lIIIlIIllIlll[2] = ('¨' + '' - 153 + 41 ^ 9 + 26 - -115 + 23);
    lIIIlIIllIlll[3] = "  ".length();
    lIIIlIIllIlll[4] = (0xF4 ^ 0xC0 ^ 0xB9 ^ 0x85);
    lIIIlIIllIlll[5] = (0x8E ^ 0x8A);
  }
  
  static {}
  
  public void setRotationAngles(float llllllllllllllIlIlIIIIIIIllIIllI, float llllllllllllllIlIlIIIIIIIllIIlII, float llllllllllllllIlIlIIIIIIIlIlIIII, float llllllllllllllIlIlIIIIIIIllIIIII, float llllllllllllllIlIlIIIIIIIlIIlllI, float llllllllllllllIlIlIIIIIIIlIlllII, Entity llllllllllllllIlIlIIIIIIIlIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIlIlIIIIIIIlIllIII = llllllllllllllIlIlIIIIIIIlIlIIII * 3.1415927F * -0.1F;
    int llllllllllllllIlIlIIIIIIIlIlIllI = lIIIlIIllIlll[1];
    "".length();
    if (((0xEF ^ 0xB2) & (0xC7 ^ 0x9A ^ 0xFFFFFFFF)) != ((0xBD ^ 0x89) & (0xA7 ^ 0x93 ^ 0xFFFFFFFF))) {
      return;
    }
    while (!llIlIIlIIllIIl(llllllllllllllIlIlIIIIIIIlIlIllI, lIIIlIIllIlll[5]))
    {
      blazeSticks[llllllllllllllIlIlIIIIIIIlIlIllI].rotationPointY = (-2.0F + MathHelper.cos((llllllllllllllIlIlIIIIIIIlIlIllI * lIIIlIIllIlll[3] + llllllllllllllIlIlIIIIIIIlIlIIII) * 0.25F));
      blazeSticks[llllllllllllllIlIlIIIIIIIlIlIllI].rotationPointX = (MathHelper.cos(llllllllllllllIlIlIIIIIIIlIllIII) * 9.0F);
      blazeSticks[llllllllllllllIlIlIIIIIIIlIlIllI].rotationPointZ = (MathHelper.sin(llllllllllllllIlIlIIIIIIIlIllIII) * 9.0F);
      llllllllllllllIlIlIIIIIIIlIllIII += 1.0F;
      llllllllllllllIlIlIIIIIIIlIlIllI++;
    }
    llllllllllllllIlIlIIIIIIIlIllIII = 0.7853982F + llllllllllllllIlIlIIIIIIIlIlIIII * 3.1415927F * 0.03F;
    int llllllllllllllIlIlIIIIIIIlIlIlII = lIIIlIIllIlll[5];
    "".length();
    if ("   ".length() > "   ".length()) {
      return;
    }
    while (!llIlIIlIIllIIl(llllllllllllllIlIlIIIIIIIlIlIlII, lIIIlIIllIlll[4]))
    {
      blazeSticks[llllllllllllllIlIlIIIIIIIlIlIlII].rotationPointY = (2.0F + MathHelper.cos((llllllllllllllIlIlIIIIIIIlIlIlII * lIIIlIIllIlll[3] + llllllllllllllIlIlIIIIIIIlIlIIII) * 0.25F));
      blazeSticks[llllllllllllllIlIlIIIIIIIlIlIlII].rotationPointX = (MathHelper.cos(llllllllllllllIlIlIIIIIIIlIllIII) * 7.0F);
      blazeSticks[llllllllllllllIlIlIIIIIIIlIlIlII].rotationPointZ = (MathHelper.sin(llllllllllllllIlIlIIIIIIIlIllIII) * 7.0F);
      llllllllllllllIlIlIIIIIIIlIllIII += 1.0F;
      llllllllllllllIlIlIIIIIIIlIlIlII++;
    }
    llllllllllllllIlIlIIIIIIIlIllIII = 0.47123894F + llllllllllllllIlIlIIIIIIIlIlIIII * 3.1415927F * -0.05F;
    int llllllllllllllIlIlIIIIIIIlIlIIlI = lIIIlIIllIlll[4];
    "".length();
    if (((0xD9 ^ 0x81 ^ 0xCE ^ 0x86) & ((0x39 ^ 0x6D) & (0xC0 ^ 0x94 ^ 0xFFFFFFFF) ^ 0xB0 ^ 0xA0 ^ -" ".length())) != ((0x36 ^ 0x55 ^ 0x1F ^ 0x21) & (0x40 ^ 0x69 ^ 0x26 ^ 0x52 ^ -" ".length()))) {
      return;
    }
    while (!llIlIIlIIllIIl(llllllllllllllIlIlIIIIIIIlIlIIlI, lIIIlIIllIlll[0]))
    {
      blazeSticks[llllllllllllllIlIlIIIIIIIlIlIIlI].rotationPointY = (11.0F + MathHelper.cos((llllllllllllllIlIlIIIIIIIlIlIIlI * 1.5F + llllllllllllllIlIlIIIIIIIlIlIIII) * 0.5F));
      blazeSticks[llllllllllllllIlIlIIIIIIIlIlIIlI].rotationPointX = (MathHelper.cos(llllllllllllllIlIlIIIIIIIlIllIII) * 5.0F);
      blazeSticks[llllllllllllllIlIlIIIIIIIlIlIIlI].rotationPointZ = (MathHelper.sin(llllllllllllllIlIlIIIIIIIlIllIII) * 5.0F);
      llllllllllllllIlIlIIIIIIIlIllIII += 1.0F;
      llllllllllllllIlIlIIIIIIIlIlIIlI++;
    }
    blazeHead.rotateAngleY = (llllllllllllllIlIlIIIIIIIllIIIII / 57.295776F);
    blazeHead.rotateAngleX = (llllllllllllllIlIlIIIIIIIlIIlllI / 57.295776F);
  }
  
  public void render(Entity llllllllllllllIlIlIIIIIIlIIIIlIl, float llllllllllllllIlIlIIIIIIlIIIIIll, float llllllllllllllIlIlIIIIIIlIIIIIlI, float llllllllllllllIlIlIIIIIIlIIIIIIl, float llllllllllllllIlIlIIIIIIlIIlIIlI, float llllllllllllllIlIlIIIIIIlIIlIIII, float llllllllllllllIlIlIIIIIIIllllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIlIIIIIIlIIIIlll.setRotationAngles(llllllllllllllIlIlIIIIIIlIIIIIll, llllllllllllllIlIlIIIIIIlIIIIIlI, llllllllllllllIlIlIIIIIIlIIIIIIl, llllllllllllllIlIlIIIIIIlIIlIIlI, llllllllllllllIlIlIIIIIIlIIlIIII, llllllllllllllIlIlIIIIIIIllllllI, llllllllllllllIlIlIIIIIIlIIIIlIl);
    blazeHead.render(llllllllllllllIlIlIIIIIIIllllllI);
    int llllllllllllllIlIlIIIIIIlIIIlIIl = lIIIlIIllIlll[1];
    "".length();
    if (" ".length() == "  ".length()) {
      return;
    }
    while (!llIlIIlIIllIIl(llllllllllllllIlIlIIIIIIlIIIlIIl, blazeSticks.length))
    {
      blazeSticks[llllllllllllllIlIlIIIIIIlIIIlIIl].render(llllllllllllllIlIlIIIIIIIllllllI);
      llllllllllllllIlIlIIIIIIlIIIlIIl++;
    }
  }
  
  private static boolean llIlIIlIIllIIl(int ???, int arg1)
  {
    int i;
    int llllllllllllllIlIlIIIIIIIlIIIIll;
    return ??? >= i;
  }
}

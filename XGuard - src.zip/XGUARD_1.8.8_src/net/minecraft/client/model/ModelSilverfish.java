package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelSilverfish
  extends ModelBase
{
  static
  {
    lIlIIllllllIII();
    silverfishBoxLength = new int[][] { { llIllIllIIII[2], llIllIllIIII[4], llIllIllIIII[4] }, { llIllIllIIII[5], llIllIllIIII[2], llIllIllIIII[4] }, { llIllIllIIII[6], llIllIllIIII[5], llIllIllIIII[2] }, { llIllIllIIII[2], llIllIllIIII[2], llIllIllIIII[2] }, { llIllIllIIII[4], llIllIllIIII[4], llIllIllIIII[2] }, { llIllIllIIII[4], llIllIllIIII[3], llIllIllIIII[4] }, { llIllIllIIII[3], llIllIllIIII[3], llIllIllIIII[4] } };
  }
  
  private static void lIlIIllllllIII()
  {
    llIllIllIIII = new int[18];
    llIllIllIIII[0] = (0x3B ^ 0x3C);
    llIllIllIIII[1] = ((0x57 ^ 0x72) & (0x2F ^ 0xA ^ 0xFFFFFFFF));
    llIllIllIIII[2] = "   ".length();
    llIllIllIIII[3] = " ".length();
    llIllIllIIII[4] = "  ".length();
    llIllIllIIII[5] = (0x49 ^ 0x4D);
    llIllIllIIII[6] = (0xB0 ^ 0xB6);
    llIllIllIIII[7] = ('' + 105 - 82 + 47 ^ 19 + '' - 115 + 162);
    llIllIllIIII[8] = (0x15 ^ 0x1C);
    llIllIllIIII[9] = (0x42 ^ 0x52);
    llIllIllIIII[10] = (0x2C ^ 0x1A ^ 0x21 ^ 0x1);
    llIllIllIIII[11] = (0x8E ^ 0x85);
    llIllIllIIII[12] = (0xE9 ^ 0x92 ^ 0x1 ^ 0x77);
    llIllIllIIII[13] = (0xB0 ^ 0xA8);
    llIllIllIIII[14] = (0xA5 ^ 0xB1);
    llIllIllIIII[15] = ('' + '' - 148 + 39 ^ 63 + 45 - 20 + 75);
    llIllIllIIII[16] = (0x10 ^ 0x18);
    llIllIllIIII[17] = (0xD0 ^ 0xC2);
  }
  
  private static boolean lIlIIllllllIIl(int ???, int arg1)
  {
    int i;
    float llllllllllllllIllllIlllIIllIlIlI;
    return ??? < i;
  }
  
  public ModelSilverfish()
  {
    float llllllllllllllIllllIlllIlIlIIIIl = -3.5F;
    int llllllllllllllIllllIlllIlIlIIIII = llIllIllIIII[1];
    "".length();
    if ((0x3 ^ 0x6) <= 0) {
      throw null;
    }
    while (!lIlIIllllllIlI(llllllllllllllIllllIlllIlIlIIIII, silverfishBodyParts.length))
    {
      silverfishBodyParts[llllllllllllllIllllIlllIlIlIIIII] = new ModelRenderer(llllllllllllllIllllIlllIlIIlllll, silverfishTexturePositions[llllllllllllllIllllIlllIlIlIIIII][llIllIllIIII[1]], silverfishTexturePositions[llllllllllllllIllllIlllIlIlIIIII][llIllIllIIII[3]]);
      "".length();
      silverfishBodyParts[llllllllllllllIllllIlllIlIlIIIII].setRotationPoint(0.0F, llIllIllIIII[13] - silverfishBoxLength[llllllllllllllIllllIlllIlIlIIIII][llIllIllIIII[3]], llllllllllllllIllllIlllIlIlIIIIl);
      field_78170_c[llllllllllllllIllllIlllIlIlIIIII] = llllllllllllllIllllIlllIlIlIIIIl;
      if (lIlIIllllllIIl(llllllllllllllIllllIlllIlIlIIIII, silverfishBodyParts.length - llIllIllIIII[3])) {
        llllllllllllllIllllIlllIlIlIIIIl += (silverfishBoxLength[llllllllllllllIllllIlllIlIlIIIII][llIllIllIIII[4]] + silverfishBoxLength[(llllllllllllllIllllIlllIlIlIIIII + llIllIllIIII[3])][llIllIllIIII[4]]) * 0.5F;
      }
      llllllllllllllIllllIlllIlIlIIIII++;
    }
    silverfishWings = new ModelRenderer[llIllIllIIII[2]];
    silverfishWings[llIllIllIIII[1]] = new ModelRenderer(llllllllllllllIllllIlllIlIIlllll, llIllIllIIII[14], llIllIllIIII[1]);
    "".length();
    silverfishWings[llIllIllIIII[1]].setRotationPoint(0.0F, 16.0F, field_78170_c[llIllIllIIII[4]]);
    silverfishWings[llIllIllIIII[3]] = new ModelRenderer(llllllllllllllIllllIlllIlIIlllll, llIllIllIIII[14], llIllIllIIII[11]);
    "".length();
    silverfishWings[llIllIllIIII[3]].setRotationPoint(0.0F, 20.0F, field_78170_c[llIllIllIIII[5]]);
    silverfishWings[llIllIllIIII[4]] = new ModelRenderer(llllllllllllllIllllIlllIlIIlllll, llIllIllIIII[14], llIllIllIIII[17]);
    "".length();
    silverfishWings[llIllIllIIII[4]].setRotationPoint(0.0F, 19.0F, field_78170_c[llIllIllIIII[3]]);
  }
  
  public void render(Entity llllllllllllllIllllIlllIlIIIlIII, float llllllllllllllIllllIlllIlIIIIlll, float llllllllllllllIllllIlllIlIIlIIII, float llllllllllllllIllllIlllIlIIIIlIl, float llllllllllllllIllllIlllIlIIIlllI, float llllllllllllllIllllIlllIlIIIllIl, float llllllllllllllIllllIlllIlIIIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllllIlllIlIIIlIIl.setRotationAngles(llllllllllllllIllllIlllIlIIIIlll, llllllllllllllIllllIlllIlIIlIIII, llllllllllllllIllllIlllIlIIIIlIl, llllllllllllllIllllIlllIlIIIlllI, llllllllllllllIllllIlllIlIIIllIl, llllllllllllllIllllIlllIlIIIllII, llllllllllllllIllllIlllIlIIIlIII);
    int llllllllllllllIllllIlllIlIIIlIll = llIllIllIIII[1];
    "".length();
    if ("  ".length() < -" ".length()) {
      return;
    }
    while (!lIlIIllllllIlI(llllllllllllllIllllIlllIlIIIlIll, silverfishBodyParts.length))
    {
      silverfishBodyParts[llllllllllllllIllllIlllIlIIIlIll].render(llllllllllllllIllllIlllIlIIIllII);
      llllllllllllllIllllIlllIlIIIlIll++;
    }
    int llllllllllllllIllllIlllIlIIIlIlI = llIllIllIIII[1];
    "".length();
    if ((0x23 ^ 0x27) <= " ".length()) {
      return;
    }
    while (!lIlIIllllllIlI(llllllllllllllIllllIlllIlIIIlIlI, silverfishWings.length))
    {
      silverfishWings[llllllllllllllIllllIlllIlIIIlIlI].render(llllllllllllllIllllIlllIlIIIllII);
      llllllllllllllIllllIlllIlIIIlIlI++;
    }
  }
  
  public void setRotationAngles(float llllllllllllllIllllIlllIIlllllII, float llllllllllllllIllllIlllIIllllIll, float llllllllllllllIllllIlllIIllllIlI, float llllllllllllllIllllIlllIIllllIIl, float llllllllllllllIllllIlllIIllllIII, float llllllllllllllIllllIlllIIlllIlll, Entity llllllllllllllIllllIlllIIlllIllI)
  {
    ;
    ;
    ;
    int llllllllllllllIllllIlllIIlllIlIl = llIllIllIIII[1];
    "".length();
    if ("   ".length() == 0) {
      return;
    }
    while (!lIlIIllllllIlI(llllllllllllllIllllIlllIIlllIlIl, silverfishBodyParts.length))
    {
      silverfishBodyParts[llllllllllllllIllllIlllIIlllIlIl].rotateAngleY = (MathHelper.cos(llllllllllllllIllllIlllIIllllIlI * 0.9F + llllllllllllllIllllIlllIIlllIlIl * 0.15F * 3.1415927F) * 3.1415927F * 0.05F * (llIllIllIIII[3] + Math.abs(llllllllllllllIllllIlllIIlllIlIl - llIllIllIIII[4])));
      silverfishBodyParts[llllllllllllllIllllIlllIIlllIlIl].rotationPointX = (MathHelper.sin(llllllllllllllIllllIlllIIllllIlI * 0.9F + llllllllllllllIllllIlllIIlllIlIl * 0.15F * 3.1415927F) * 3.1415927F * 0.2F * Math.abs(llllllllllllllIllllIlllIIlllIlIl - llIllIllIIII[4]));
      llllllllllllllIllllIlllIIlllIlIl++;
    }
    silverfishWings[llIllIllIIII[1]].rotateAngleY = silverfishBodyParts[llIllIllIIII[4]].rotateAngleY;
    silverfishWings[llIllIllIIII[3]].rotateAngleY = silverfishBodyParts[llIllIllIIII[5]].rotateAngleY;
    silverfishWings[llIllIllIIII[3]].rotationPointX = silverfishBodyParts[llIllIllIIII[5]].rotationPointX;
    silverfishWings[llIllIllIIII[4]].rotateAngleY = silverfishBodyParts[llIllIllIIII[3]].rotateAngleY;
    silverfishWings[llIllIllIIII[4]].rotationPointX = silverfishBodyParts[llIllIllIIII[3]].rotationPointX;
  }
  
  private static boolean lIlIIllllllIlI(int ???, int arg1)
  {
    int i;
    double llllllllllllllIllllIlllIIllIlllI;
    return ??? >= i;
  }
}

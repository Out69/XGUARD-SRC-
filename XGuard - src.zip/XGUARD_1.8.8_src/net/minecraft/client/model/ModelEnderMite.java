package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelEnderMite
  extends ModelBase
{
  private static boolean llIllIllIIIIIl(int ???, int arg1)
  {
    int i;
    int llllllllllllllIlIIIlllIllllIIIII;
    return ??? < i;
  }
  
  private static boolean llIllIllIIIIlI(int ???, int arg1)
  {
    int i;
    short llllllllllllllIlIIIlllIllllIIlII;
    return ??? >= i;
  }
  
  public ModelEnderMite()
  {
    float llllllllllllllIlIIIllllIIIIlIllI = -3.5F;
    int llllllllllllllIlIIIllllIIIIlIlIl = lIIlIIIIIIIll[1];
    "".length();
    if ((0x7A ^ 0x7E) > (0x86 ^ 0x82)) {
      throw null;
    }
    while (!llIllIllIIIIlI(llllllllllllllIlIIIllllIIIIlIlIl, field_178713_d.length))
    {
      field_178713_d[llllllllllllllIlIIIllllIIIIlIlIl] = new ModelRenderer(llllllllllllllIlIIIllllIIIIlIlII, field_178714_b[llllllllllllllIlIIIllllIIIIlIlIl][lIIlIIIIIIIll[1]], field_178714_b[llllllllllllllIlIIIllllIIIIlIlIl][lIIlIIIIIIIll[3]]);
      "".length();
      field_178713_d[llllllllllllllIlIIIllllIIIIlIlIl].setRotationPoint(0.0F, lIIlIIIIIIIll[9] - field_178716_a[llllllllllllllIlIIIllllIIIIlIlIl][lIIlIIIIIIIll[3]], llllllllllllllIlIIIllllIIIIlIllI);
      if (llIllIllIIIIIl(llllllllllllllIlIIIllllIIIIlIlIl, field_178713_d.length - lIIlIIIIIIIll[3])) {
        llllllllllllllIlIIIllllIIIIlIllI += (field_178716_a[llllllllllllllIlIIIllllIIIIlIlIl][lIIlIIIIIIIll[4]] + field_178716_a[(llllllllllllllIlIIIllllIIIIlIlIl + lIIlIIIIIIIll[3])][lIIlIIIIIIIll[4]]) * 0.5F;
      }
      llllllllllllllIlIIIllllIIIIlIlIl++;
    }
  }
  
  private static void llIllIlIllllll()
  {
    lIIlIIIIIIIll = new int[10];
    lIIlIIIIIIIll[0] = (113 + 110 - 195 + 166 ^ 111 + 51 - -25 + 11);
    lIIlIIIIIIIll[1] = ((0xE ^ 0x2) & (0x7A ^ 0x76 ^ 0xFFFFFFFF));
    lIIlIIIIIIIll[2] = "   ".length();
    lIIlIIIIIIIll[3] = " ".length();
    lIIlIIIIIIIll[4] = "  ".length();
    lIIlIIIIIIIll[5] = (0x83 ^ 0x85);
    lIIlIIIIIIIll[6] = (111 + 27 - 96 + 91 ^ 58 + 23 - 71 + 118);
    lIIlIIIIIIIll[7] = (84 + 24 - 55 + 121 ^ 52 + 49 - -45 + 14);
    lIIlIIIIIIIll[8] = (0x86 ^ 0x94);
    lIIlIIIIIIIll[9] = (0x18 ^ 0x0);
  }
  
  static
  {
    llIllIlIllllll();
    field_178716_a = new int[][] { { lIIlIIIIIIIll[0], lIIlIIIIIIIll[2], lIIlIIIIIIIll[4] }, { lIIlIIIIIIIll[5], lIIlIIIIIIIll[0], lIIlIIIIIIIll[6] }, { lIIlIIIIIIIll[2], lIIlIIIIIIIll[2], lIIlIIIIIIIll[3] }, { lIIlIIIIIIIll[3], lIIlIIIIIIIll[4], lIIlIIIIIIIll[3] } };
    field_178714_b = new int[][] { new int[lIIlIIIIIIIll[4]], { lIIlIIIIIIIll[6] }, { lIIlIIIIIIIll[7] }, { lIIlIIIIIIIll[8] } };
  }
  
  public void render(Entity llllllllllllllIlIIIllllIIIIIIlll, float llllllllllllllIlIIIllllIIIIIIllI, float llllllllllllllIlIIIllllIIIIIIlIl, float llllllllllllllIlIIIllllIIIIIIlII, float llllllllllllllIlIIIlllIllllllIlI, float llllllllllllllIlIIIllllIIIIIIIlI, float llllllllllllllIlIIIlllIllllllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIIllllIIIIIlIII.setRotationAngles(llllllllllllllIlIIIllllIIIIIIllI, llllllllllllllIlIIIllllIIIIIIlIl, llllllllllllllIlIIIllllIIIIIIlII, llllllllllllllIlIIIlllIllllllIlI, llllllllllllllIlIIIllllIIIIIIIlI, llllllllllllllIlIIIlllIllllllIII, llllllllllllllIlIIIllllIIIIIIlll);
    int llllllllllllllIlIIIllllIIIIIIIII = lIIlIIIIIIIll[1];
    "".length();
    if ("   ".length() > "   ".length()) {
      return;
    }
    while (!llIllIllIIIIlI(llllllllllllllIlIIIllllIIIIIIIII, field_178713_d.length))
    {
      field_178713_d[llllllllllllllIlIIIllllIIIIIIIII].render(llllllllllllllIlIIIlllIllllllIII);
      llllllllllllllIlIIIllllIIIIIIIII++;
    }
  }
  
  public void setRotationAngles(float llllllllllllllIlIIIlllIlllllIIlI, float llllllllllllllIlIIIlllIlllllIIIl, float llllllllllllllIlIIIlllIllllIlIIl, float llllllllllllllIlIIIlllIllllIllll, float llllllllllllllIlIIIlllIllllIlllI, float llllllllllllllIlIIIlllIllllIllIl, Entity llllllllllllllIlIIIlllIllllIllII)
  {
    ;
    ;
    ;
    int llllllllllllllIlIIIlllIllllIlIll = lIIlIIIIIIIll[1];
    "".length();
    if (((79 + '³' - 127 + 104 ^ 54 + 27 - -15 + 43) & (0xB7 ^ 0xAF ^ 0x76 ^ 0xE ^ -" ".length())) != ((0x2B ^ 0x51 ^ 0xD6 ^ 0x9F) & (0xF0 ^ 0xB5 ^ 0x64 ^ 0x12 ^ -" ".length()))) {
      return;
    }
    while (!llIllIllIIIIlI(llllllllllllllIlIIIlllIllllIlIll, field_178713_d.length))
    {
      field_178713_d[llllllllllllllIlIIIlllIllllIlIll].rotateAngleY = (MathHelper.cos(llllllllllllllIlIIIlllIllllIlIIl * 0.9F + llllllllllllllIlIIIlllIllllIlIll * 0.15F * 3.1415927F) * 3.1415927F * 0.01F * (lIIlIIIIIIIll[3] + Math.abs(llllllllllllllIlIIIlllIllllIlIll - lIIlIIIIIIIll[4])));
      field_178713_d[llllllllllllllIlIIIlllIllllIlIll].rotationPointX = (MathHelper.sin(llllllllllllllIlIIIlllIllllIlIIl * 0.9F + llllllllllllllIlIIIlllIllllIlIll * 0.15F * 3.1415927F) * 3.1415927F * 0.1F * Math.abs(llllllllllllllIlIIIlllIllllIlIll - lIIlIIIIIIIll[4]));
      llllllllllllllIlIIIlllIllllIlIll++;
    }
  }
}

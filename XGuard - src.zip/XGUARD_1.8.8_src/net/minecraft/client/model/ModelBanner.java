package net.minecraft.client.model;

public class ModelBanner
  extends ModelBase
{
  public ModelBanner()
  {
    textureWidth = lIIIIIIlIlIII[0];
    textureHeight = lIIIIIIlIlIII[0];
    bannerSlate.addBox(-10.0F, 0.0F, -2.0F, lIIIIIIlIlIII[2], lIIIIIIlIlIII[3], lIIIIIIlIlIII[4], 0.0F);
    bannerStand = new ModelRenderer(llllllllllllllIlIllIllllIIIIllIl, lIIIIIIlIlIII[5], lIIIIIIlIlIII[1]);
    bannerStand.addBox(-1.0F, -30.0F, -1.0F, lIIIIIIlIlIII[6], lIIIIIIlIlIII[7], lIIIIIIlIlIII[6], 0.0F);
    bannerTop = new ModelRenderer(llllllllllllllIlIllIllllIIIIllIl, lIIIIIIlIlIII[1], lIIIIIIlIlIII[7]);
    bannerTop.addBox(-10.0F, -32.0F, -1.0F, lIIIIIIlIlIII[2], lIIIIIIlIlIII[6], lIIIIIIlIlIII[6], 0.0F);
  }
  
  private static void llIIIllIlIIIlI()
  {
    lIIIIIIlIlIII = new int[8];
    lIIIIIIlIlIII[0] = (0xEF ^ 0xAF);
    lIIIIIIlIlIII[1] = ((0x1 ^ 0x48 ^ 0x11 ^ 0x8) & (0xC2 ^ 0x87 ^ 0x11 ^ 0x4 ^ -" ".length()));
    lIIIIIIlIlIII[2] = (0xFB ^ 0x91 ^ 0xD6 ^ 0xA8);
    lIIIIIIlIlIII[3] = (0x67 ^ 0x41 ^ 0xAF ^ 0xA1);
    lIIIIIIlIlIII[4] = " ".length();
    lIIIIIIlIlIII[5] = (0x16 ^ 0x3A);
    lIIIIIIlIlIII[6] = "  ".length();
    lIIIIIIlIlIII[7] = (0x6 ^ 0x2C);
  }
  
  public void renderBanner()
  {
    ;
    bannerSlate.rotationPointY = -32.0F;
    bannerSlate.render(0.0625F);
    bannerStand.render(0.0625F);
    bannerTop.render(0.0625F);
  }
  
  static {}
}

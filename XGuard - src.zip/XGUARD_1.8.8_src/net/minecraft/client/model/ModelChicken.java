package net.minecraft.client.model;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelChicken
  extends ModelBase
{
  static {}
  
  private static boolean lllIlIIllIllIl(int ???)
  {
    float llllllllllllllIIllIllllIlIllllll;
    return ??? != 0;
  }
  
  private static void lllIlIIllIllII()
  {
    lIIllIIIIIlII = new int[16];
    lIIllIIIIIlII[0] = (0xBC ^ 0xC4 ^ 0x67 ^ 0xF);
    lIIllIIIIIlII[1] = ((0x23 ^ 0x15 ^ 0x29 ^ 0x25) & (74 + 80 - 116 + 89 ^ 0x6D ^ 0x28 ^ -" ".length()));
    lIIllIIIIIlII[2] = (0xE4 ^ 0xC0 ^ 0x94 ^ 0xB4);
    lIIllIIIIIlII[3] = (0x90 ^ 0x96);
    lIIllIIIIIlII[4] = "   ".length();
    lIIllIIIIIlII[5] = (-" ".length());
    lIIllIIIIIlII[6] = (0x3B ^ 0x35);
    lIIllIIIIIlII[7] = "  ".length();
    lIIllIIIIIlII[8] = (0xCD ^ 0xC4);
    lIIllIIIIIlII[9] = (0xDB ^ 0x86 ^ 0x78 ^ 0x2D);
    lIIllIIIIIlII[10] = (0xB4 ^ 0xAE);
    lIIllIIIIIlII[11] = (0xBE ^ 0xBB);
    lIIllIIIIIlII[12] = (0x2E ^ 0x36);
    lIIllIIIIIlII[13] = (0x9D ^ 0x90);
    lIIllIIIIIlII[14] = " ".length();
    lIIllIIIIIlII[15] = (-"   ".length());
  }
  
  public void render(Entity llllllllllllllIIllIllllIllIlllII, float llllllllllllllIIllIllllIllIllIll, float llllllllllllllIIllIllllIlllIIIll, float llllllllllllllIIllIllllIllIllIIl, float llllllllllllllIIllIllllIllIllIII, float llllllllllllllIIllIllllIlllIIIII, float llllllllllllllIIllIllllIllIlIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIllllIlllIIllI.setRotationAngles(llllllllllllllIIllIllllIllIllIll, llllllllllllllIIllIllllIlllIIIll, llllllllllllllIIllIllllIllIllIIl, llllllllllllllIIllIllllIllIllIII, llllllllllllllIIllIllllIlllIIIII, llllllllllllllIIllIllllIllIlIllI, llllllllllllllIIllIllllIllIlllII);
    if (lllIlIIllIllIl(isChild))
    {
      float llllllllllllllIIllIllllIllIllllI = 2.0F;
      GlStateManager.pushMatrix();
      GlStateManager.translate(0.0F, 5.0F * llllllllllllllIIllIllllIllIlIllI, 2.0F * llllllllllllllIIllIllllIllIlIllI);
      head.render(llllllllllllllIIllIllllIllIlIllI);
      bill.render(llllllllllllllIIllIllllIllIlIllI);
      chin.render(llllllllllllllIIllIllllIllIlIllI);
      GlStateManager.popMatrix();
      GlStateManager.pushMatrix();
      GlStateManager.scale(1.0F / llllllllllllllIIllIllllIllIllllI, 1.0F / llllllllllllllIIllIllllIllIllllI, 1.0F / llllllllllllllIIllIllllIllIllllI);
      GlStateManager.translate(0.0F, 24.0F * llllllllllllllIIllIllllIllIlIllI, 0.0F);
      body.render(llllllllllllllIIllIllllIllIlIllI);
      rightLeg.render(llllllllllllllIIllIllllIllIlIllI);
      leftLeg.render(llllllllllllllIIllIllllIllIlIllI);
      rightWing.render(llllllllllllllIIllIllllIllIlIllI);
      leftWing.render(llllllllllllllIIllIllllIllIlIllI);
      GlStateManager.popMatrix();
      "".length();
      if (((0x4A ^ 0x43 ^ 0xD3 ^ 0xB8) & (0xDE ^ 0x8B ^ 0x38 ^ 0xF ^ -" ".length())) >= 0) {}
    }
    else
    {
      head.render(llllllllllllllIIllIllllIllIlIllI);
      bill.render(llllllllllllllIIllIllllIllIlIllI);
      chin.render(llllllllllllllIIllIllllIllIlIllI);
      body.render(llllllllllllllIIllIllllIllIlIllI);
      rightLeg.render(llllllllllllllIIllIllllIllIlIllI);
      leftLeg.render(llllllllllllllIIllIllllIllIlIllI);
      rightWing.render(llllllllllllllIIllIllllIllIlIllI);
      leftWing.render(llllllllllllllIIllIllllIllIlIllI);
    }
  }
  
  public ModelChicken()
  {
    int llllllllllllllIIllIllllIllllIIlI = lIIllIIIIIlII[0];
    head = new ModelRenderer(llllllllllllllIIllIllllIllllIIIl, lIIllIIIIIlII[1], lIIllIIIIIlII[1]);
    head.addBox(-2.0F, -6.0F, -2.0F, lIIllIIIIIlII[2], lIIllIIIIIlII[3], lIIllIIIIIlII[4], 0.0F);
    head.setRotationPoint(0.0F, lIIllIIIIIlII[5] + llllllllllllllIIllIllllIllllIIlI, -4.0F);
    bill = new ModelRenderer(llllllllllllllIIllIllllIllllIIIl, lIIllIIIIIlII[6], lIIllIIIIIlII[1]);
    bill.addBox(-2.0F, -4.0F, -4.0F, lIIllIIIIIlII[2], lIIllIIIIIlII[7], lIIllIIIIIlII[7], 0.0F);
    bill.setRotationPoint(0.0F, lIIllIIIIIlII[5] + llllllllllllllIIllIllllIllllIIlI, -4.0F);
    chin = new ModelRenderer(llllllllllllllIIllIllllIllllIIIl, lIIllIIIIIlII[6], lIIllIIIIIlII[2]);
    chin.addBox(-1.0F, -2.0F, -3.0F, lIIllIIIIIlII[7], lIIllIIIIIlII[7], lIIllIIIIIlII[7], 0.0F);
    chin.setRotationPoint(0.0F, lIIllIIIIIlII[5] + llllllllllllllIIllIllllIllllIIlI, -4.0F);
    body = new ModelRenderer(llllllllllllllIIllIllllIllllIIIl, lIIllIIIIIlII[1], lIIllIIIIIlII[8]);
    body.addBox(-3.0F, -4.0F, -3.0F, lIIllIIIIIlII[3], lIIllIIIIIlII[9], lIIllIIIIIlII[3], 0.0F);
    body.setRotationPoint(0.0F, llllllllllllllIIllIllllIllllIIlI, 0.0F);
    rightLeg = new ModelRenderer(llllllllllllllIIllIllllIllllIIIl, lIIllIIIIIlII[10], lIIllIIIIIlII[1]);
    "".length();
    rightLeg.setRotationPoint(-2.0F, lIIllIIIIIlII[4] + llllllllllllllIIllIllllIllllIIlI, 1.0F);
    leftLeg = new ModelRenderer(llllllllllllllIIllIllllIllllIIIl, lIIllIIIIIlII[10], lIIllIIIIIlII[1]);
    "".length();
    leftLeg.setRotationPoint(1.0F, lIIllIIIIIlII[4] + llllllllllllllIIllIllllIllllIIlI, 1.0F);
    rightWing = new ModelRenderer(llllllllllllllIIllIllllIllllIIIl, lIIllIIIIIlII[12], lIIllIIIIIlII[13]);
    "".length();
    rightWing.setRotationPoint(-4.0F, lIIllIIIIIlII[15] + llllllllllllllIIllIllllIllllIIlI, 0.0F);
    leftWing = new ModelRenderer(llllllllllllllIIllIllllIllllIIIl, lIIllIIIIIlII[12], lIIllIIIIIlII[13]);
    "".length();
    leftWing.setRotationPoint(4.0F, lIIllIIIIIlII[15] + llllllllllllllIIllIllllIllllIIlI, 0.0F);
  }
  
  public void setRotationAngles(float llllllllllllllIIllIllllIllIIllIl, float llllllllllllllIIllIllllIllIIIlII, float llllllllllllllIIllIllllIllIIlIll, float llllllllllllllIIllIllllIllIIlIlI, float llllllllllllllIIllIllllIllIIlIIl, float llllllllllllllIIllIllllIllIIlIII, Entity llllllllllllllIIllIllllIllIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    head.rotateAngleX = (llllllllllllllIIllIllllIllIIlIIl / 57.295776F);
    head.rotateAngleY = (llllllllllllllIIllIllllIllIIlIlI / 57.295776F);
    bill.rotateAngleX = head.rotateAngleX;
    bill.rotateAngleY = head.rotateAngleY;
    chin.rotateAngleX = head.rotateAngleX;
    chin.rotateAngleY = head.rotateAngleY;
    body.rotateAngleX = 1.5707964F;
    rightLeg.rotateAngleX = (MathHelper.cos(llllllllllllllIIllIllllIllIIllIl * 0.6662F) * 1.4F * llllllllllllllIIllIllllIllIIIlII);
    leftLeg.rotateAngleX = (MathHelper.cos(llllllllllllllIIllIllllIllIIllIl * 0.6662F + 3.1415927F) * 1.4F * llllllllllllllIIllIllllIllIIIlII);
    rightWing.rotateAngleZ = llllllllllllllIIllIllllIllIIlIll;
    leftWing.rotateAngleZ = (-llllllllllllllIIllIllllIllIIlIll);
  }
}

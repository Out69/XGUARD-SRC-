package net.minecraft.client.model;

import net.minecraft.client.renderer.WorldRenderer;

public class ModelBox
{
  public ModelBox setBoxName(String llIllIlllIII)
  {
    ;
    ;
    boxName = llIllIlllIII;
    return llIllIlllIlI;
  }
  
  public ModelBox(ModelRenderer llIllllIlllI, int lllIIIIIlIII, int lllIIIIIIlll, float llIllllIlIlI, float llIllllIlIIl, float lllIIIIIIlII, int lllIIIIIIIll, int llIllllIIllI, int lllIIIIIIIIl, float llIlllllllll, boolean llIllllllllI)
  {
    posX1 = llIllllIlIlI;
    posY1 = llIllllIlIIl;
    posZ1 = lllIIIIIIlII;
    posX2 = (llIllllIlIlI + lllIIIIIIIll);
    posY2 = (llIllllIlIIl + llIllllIIllI);
    posZ2 = (lllIIIIIIlII + lllIIIIIIIIl);
    vertexPositions = new PositionTextureVertex[lIIlIllllI[0]];
    quadList = new TexturedQuad[lIIlIllllI[1]];
    float llIlllllllIl = llIllllIlIlI + lllIIIIIIIll;
    float llIlllllllII = llIllllIlIIl + llIllllIIllI;
    float llIllllllIll = lllIIIIIIlII + lllIIIIIIIIl;
    llIllllIlIlI -= llIlllllllll;
    llIllllIlIIl -= llIlllllllll;
    lllIIIIIIlII -= llIlllllllll;
    llIlllllllIl += llIlllllllll;
    llIlllllllII += llIlllllllll;
    llIllllllIll += llIlllllllll;
    if (llllIllIlII(llIllllllllI))
    {
      float llIllllllIlI = llIlllllllIl;
      llIlllllllIl = llIllllIlIlI;
      llIllllIlIlI = llIllllllIlI;
    }
    PositionTextureVertex llIllllllIIl = new PositionTextureVertex(llIllllIlIlI, llIllllIlIIl, lllIIIIIIlII, 0.0F, 0.0F);
    PositionTextureVertex llIllllllIII = new PositionTextureVertex(llIlllllllIl, llIllllIlIIl, lllIIIIIIlII, 0.0F, 8.0F);
    PositionTextureVertex llIlllllIlll = new PositionTextureVertex(llIlllllllIl, llIlllllllII, lllIIIIIIlII, 8.0F, 8.0F);
    PositionTextureVertex llIlllllIllI = new PositionTextureVertex(llIllllIlIlI, llIlllllllII, lllIIIIIIlII, 8.0F, 0.0F);
    PositionTextureVertex llIlllllIlIl = new PositionTextureVertex(llIllllIlIlI, llIllllIlIIl, llIllllllIll, 0.0F, 0.0F);
    PositionTextureVertex llIlllllIlII = new PositionTextureVertex(llIlllllllIl, llIllllIlIIl, llIllllllIll, 0.0F, 8.0F);
    PositionTextureVertex llIlllllIIll = new PositionTextureVertex(llIlllllllIl, llIlllllllII, llIllllllIll, 8.0F, 8.0F);
    PositionTextureVertex llIlllllIIlI = new PositionTextureVertex(llIllllIlIlI, llIlllllllII, llIllllllIll, 8.0F, 0.0F);
    vertexPositions[lIIlIllllI[2]] = llIllllllIIl;
    vertexPositions[lIIlIllllI[3]] = llIllllllIII;
    vertexPositions[lIIlIllllI[4]] = llIlllllIlll;
    vertexPositions[lIIlIllllI[5]] = llIlllllIllI;
    vertexPositions[lIIlIllllI[6]] = llIlllllIlIl;
    vertexPositions[lIIlIllllI[7]] = llIlllllIlII;
    vertexPositions[lIIlIllllI[1]] = llIlllllIIll;
    vertexPositions[lIIlIllllI[8]] = llIlllllIIlI;
    quadList[lIIlIllllI[2]] = new TexturedQuad(new PositionTextureVertex[] { llIlllllIlII, llIllllllIII, llIlllllIlll, llIlllllIIll }, lllIIIIIlIII + lllIIIIIIIIl + lllIIIIIIIll, lllIIIIIIlll + lllIIIIIIIIl, lllIIIIIlIII + lllIIIIIIIIl + lllIIIIIIIll + lllIIIIIIIIl, lllIIIIIIlll + lllIIIIIIIIl + llIllllIIllI, textureWidth, textureHeight);
    quadList[lIIlIllllI[3]] = new TexturedQuad(new PositionTextureVertex[] { llIllllllIIl, llIlllllIlIl, llIlllllIIlI, llIlllllIllI }, lllIIIIIlIII, lllIIIIIIlll + lllIIIIIIIIl, lllIIIIIlIII + lllIIIIIIIIl, lllIIIIIIlll + lllIIIIIIIIl + llIllllIIllI, textureWidth, textureHeight);
    quadList[lIIlIllllI[4]] = new TexturedQuad(new PositionTextureVertex[] { llIlllllIlII, llIlllllIlIl, llIllllllIIl, llIllllllIII }, lllIIIIIlIII + lllIIIIIIIIl, lllIIIIIIlll, lllIIIIIlIII + lllIIIIIIIIl + lllIIIIIIIll, lllIIIIIIlll + lllIIIIIIIIl, textureWidth, textureHeight);
    quadList[lIIlIllllI[5]] = new TexturedQuad(new PositionTextureVertex[] { llIlllllIlll, llIlllllIllI, llIlllllIIlI, llIlllllIIll }, lllIIIIIlIII + lllIIIIIIIIl + lllIIIIIIIll, lllIIIIIIlll + lllIIIIIIIIl, lllIIIIIlIII + lllIIIIIIIIl + lllIIIIIIIll + lllIIIIIIIll, lllIIIIIIlll, textureWidth, textureHeight);
    quadList[lIIlIllllI[6]] = new TexturedQuad(new PositionTextureVertex[] { llIllllllIII, llIllllllIIl, llIlllllIllI, llIlllllIlll }, lllIIIIIlIII + lllIIIIIIIIl, lllIIIIIIlll + lllIIIIIIIIl, lllIIIIIlIII + lllIIIIIIIIl + lllIIIIIIIll, lllIIIIIIlll + lllIIIIIIIIl + llIllllIIllI, textureWidth, textureHeight);
    quadList[lIIlIllllI[7]] = new TexturedQuad(new PositionTextureVertex[] { llIlllllIlIl, llIlllllIlII, llIlllllIIll, llIlllllIIlI }, lllIIIIIlIII + lllIIIIIIIIl + lllIIIIIIIll + lllIIIIIIIIl, lllIIIIIIlll + lllIIIIIIIIl, lllIIIIIlIII + lllIIIIIIIIl + lllIIIIIIIll + lllIIIIIIIIl + lllIIIIIIIll, lllIIIIIIlll + lllIIIIIIIIl + llIllllIIllI, textureWidth, textureHeight);
    if (llllIllIlII(llIllllllllI))
    {
      int llIlllllIIIl = lIIlIllllI[2];
      "".length();
      if ((0x6A ^ 0x6E) != (0xC4 ^ 0xC0)) {
        throw null;
      }
      while (!llllIlllIIl(llIlllllIIIl, quadList.length))
      {
        quadList[llIlllllIIIl].flipFace();
        llIlllllIIIl++;
      }
    }
  }
  
  public ModelBox(ModelRenderer lllIIIlIllII, int lllIIIlIlIll, int lllIIIlIlIlI, float lllIIIllIlII, float lllIIIllIIll, float lllIIIllIIlI, int lllIIIlIIllI, int lllIIIlIIlIl, int lllIIIlIIlII, float lllIIIlIlllI)
  {
    lllIIIlIllIl.<init>(lllIIIlIllII, lllIIIlIlIll, lllIIIlIlIlI, lllIIIllIlII, lllIIIlIlIII, lllIIIllIIlI, lllIIIlIIllI, lllIIIlIIlIl, lllIIIlIIlII, lllIIIlIlllI, mirror);
  }
  
  private static void llllIllIIll()
  {
    lIIlIllllI = new int[9];
    lIIlIllllI[0] = (0x66 ^ 0x6E);
    lIIlIllllI[1] = (0x4E ^ 0x48);
    lIIlIllllI[2] = ((0x90 ^ 0x9B ^ 0xB7 ^ 0xBA) & (0x84 ^ 0xB1 ^ 0x96 ^ 0xA5 ^ -" ".length()));
    lIIlIllllI[3] = " ".length();
    lIIlIllllI[4] = "  ".length();
    lIIlIllllI[5] = "   ".length();
    lIIlIllllI[6] = (0x34 ^ 0x4D ^ 0xF7 ^ 0x8A);
    lIIlIllllI[7] = (0x4F ^ 0x4A);
    lIIlIllllI[8] = (0x5A ^ 0x22 ^ 115 + 120 - 169 + 61);
  }
  
  private static boolean llllIlllIIl(int ???, int arg1)
  {
    int i;
    short llIllIlIIlIl;
    return ??? >= i;
  }
  
  static {}
  
  public void render(WorldRenderer llIlllIIIlll, float llIlllIIIllI)
  {
    ;
    ;
    ;
    ;
    int llIlllIIIlIl = lIIlIllllI[2];
    "".length();
    if ("   ".length() <= 0) {
      return;
    }
    while (!llllIlllIIl(llIlllIIIlIl, quadList.length))
    {
      quadList[llIlllIIIlIl].draw(llIlllIIIIll, llIlllIIIllI);
      llIlllIIIlIl++;
    }
  }
  
  private static boolean llllIllIlII(int ???)
  {
    short llIllIlIIIll;
    return ??? != 0;
  }
}

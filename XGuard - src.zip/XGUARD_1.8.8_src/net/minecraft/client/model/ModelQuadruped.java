package net.minecraft.client.model;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelQuadruped
  extends ModelBase
{
  public void setRotationAngles(float llllllllllllllIllllIlIIlIIlllIlI, float llllllllllllllIllllIlIIlIIlllIIl, float llllllllllllllIllllIlIIlIlIIIIIl, float llllllllllllllIllllIlIIlIIlllIII, float llllllllllllllIllllIlIIlIIllIlll, float llllllllllllllIllllIlIIlIIlllllI, Entity llllllllllllllIllllIlIIlIIllllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIllllIlIIlIIllllII = 57.295776F;
    head.rotateAngleX = (llllllllllllllIllllIlIIlIIllIlll / 57.295776F);
    head.rotateAngleY = (llllllllllllllIllllIlIIlIlIIIIII / 57.295776F);
    body.rotateAngleX = 1.5707964F;
    leg1.rotateAngleX = (MathHelper.cos(llllllllllllllIllllIlIIlIIlllIlI * 0.6662F) * 1.4F * llllllllllllllIllllIlIIlIIlllIIl);
    leg2.rotateAngleX = (MathHelper.cos(llllllllllllllIllllIlIIlIIlllIlI * 0.6662F + 3.1415927F) * 1.4F * llllllllllllllIllllIlIIlIIlllIIl);
    leg3.rotateAngleX = (MathHelper.cos(llllllllllllllIllllIlIIlIIlllIlI * 0.6662F + 3.1415927F) * 1.4F * llllllllllllllIllllIlIIlIIlllIIl);
    leg4.rotateAngleX = (MathHelper.cos(llllllllllllllIllllIlIIlIIlllIlI * 0.6662F) * 1.4F * llllllllllllllIllllIlIIlIIlllIIl);
  }
  
  public ModelQuadruped(int llllllllllllllIllllIlIIlIllIlIlI, float llllllllllllllIllllIlIIlIllIlIIl)
  {
    head.addBox(-4.0F, -4.0F, -8.0F, llIlllIlllII[1], llIlllIlllII[1], llIlllIlllII[1], llllllllllllllIllllIlIIlIllIlIIl);
    head.setRotationPoint(0.0F, llIlllIlllII[2] - llllllllllllllIllllIlIIlIllIIlll, -6.0F);
    body = new ModelRenderer(llllllllllllllIllllIlIIlIllIlIll, llIlllIlllII[3], llIlllIlllII[1]);
    body.addBox(-5.0F, -10.0F, -7.0F, llIlllIlllII[4], llIlllIlllII[5], llIlllIlllII[1], llllllllllllllIllllIlIIlIllIlIIl);
    body.setRotationPoint(0.0F, llIlllIlllII[6] - llllllllllllllIllllIlIIlIllIIlll, 2.0F);
    leg1 = new ModelRenderer(llllllllllllllIllllIlIIlIllIlIll, llIlllIlllII[0], llIlllIlllII[5]);
    leg1.addBox(-2.0F, 0.0F, -2.0F, llIlllIlllII[7], llllllllllllllIllllIlIIlIllIIlll, llIlllIlllII[7], llllllllllllllIllllIlIIlIllIlIIl);
    leg1.setRotationPoint(-3.0F, llIlllIlllII[8] - llllllllllllllIllllIlIIlIllIIlll, 7.0F);
    leg2 = new ModelRenderer(llllllllllllllIllllIlIIlIllIlIll, llIlllIlllII[0], llIlllIlllII[5]);
    leg2.addBox(-2.0F, 0.0F, -2.0F, llIlllIlllII[7], llllllllllllllIllllIlIIlIllIIlll, llIlllIlllII[7], llllllllllllllIllllIlIIlIllIlIIl);
    leg2.setRotationPoint(3.0F, llIlllIlllII[8] - llllllllllllllIllllIlIIlIllIIlll, 7.0F);
    leg3 = new ModelRenderer(llllllllllllllIllllIlIIlIllIlIll, llIlllIlllII[0], llIlllIlllII[5]);
    leg3.addBox(-2.0F, 0.0F, -2.0F, llIlllIlllII[7], llllllllllllllIllllIlIIlIllIIlll, llIlllIlllII[7], llllllllllllllIllllIlIIlIllIlIIl);
    leg3.setRotationPoint(-3.0F, llIlllIlllII[8] - llllllllllllllIllllIlIIlIllIIlll, -5.0F);
    leg4 = new ModelRenderer(llllllllllllllIllllIlIIlIllIlIll, llIlllIlllII[0], llIlllIlllII[5]);
    leg4.addBox(-2.0F, 0.0F, -2.0F, llIlllIlllII[7], llllllllllllllIllllIlIIlIllIIlll, llIlllIlllII[7], llllllllllllllIllllIlIIlIllIlIIl);
    leg4.setRotationPoint(3.0F, llIlllIlllII[8] - llllllllllllllIllllIlIIlIllIIlll, -5.0F);
  }
  
  static {}
  
  private static void lIlIlIIlIllIII()
  {
    llIlllIlllII = new int[9];
    llIlllIlllII[0] = ((0x60 ^ 0x7B ^ 0xAF ^ 0xA0) & (53 + 93 - 1 + 26 ^ '' + 95 - 70 + 28 ^ -" ".length()));
    llIlllIlllII[1] = (0x0 ^ 0x8);
    llIlllIlllII[2] = (0x3A ^ 0x78 ^ 0x49 ^ 0x19);
    llIlllIlllII[3] = (0x6D ^ 0x7F ^ 0x2 ^ 0xC);
    llIlllIlllII[4] = (0x3A ^ 0x30);
    llIlllIlllII[5] = (0x33 ^ 0x54 ^ 0xE5 ^ 0x92);
    llIlllIlllII[6] = (0x89 ^ 0x98);
    llIlllIlllII[7] = ('' + '¦' - 178 + 59 ^ 29 + 14 - 8 + 143);
    llIlllIlllII[8] = (0xDF ^ 0xC7);
  }
  
  public void render(Entity llllllllllllllIllllIlIIlIlIllIll, float llllllllllllllIllllIlIIlIlIllIlI, float llllllllllllllIllllIlIIlIlIllIIl, float llllllllllllllIllllIlIIlIlIllIII, float llllllllllllllIllllIlIIlIlIlIlll, float llllllllllllllIllllIlIIlIlIlIllI, float llllllllllllllIllllIlIIlIlIIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllllIlIIlIlIlIIll.setRotationAngles(llllllllllllllIllllIlIIlIlIllIlI, llllllllllllllIllllIlIIlIlIllIIl, llllllllllllllIllllIlIIlIlIllIII, llllllllllllllIllllIlIIlIlIlIlll, llllllllllllllIllllIlIIlIlIlIllI, llllllllllllllIllllIlIIlIlIIllII, llllllllllllllIllllIlIIlIlIllIll);
    if (lIlIlIIlIllIIl(isChild))
    {
      float llllllllllllllIllllIlIIlIlIlIlII = 2.0F;
      GlStateManager.pushMatrix();
      GlStateManager.translate(0.0F, childYOffset * llllllllllllllIllllIlIIlIlIIllII, childZOffset * llllllllllllllIllllIlIIlIlIIllII);
      head.render(llllllllllllllIllllIlIIlIlIIllII);
      GlStateManager.popMatrix();
      GlStateManager.pushMatrix();
      GlStateManager.scale(1.0F / llllllllllllllIllllIlIIlIlIlIlII, 1.0F / llllllllllllllIllllIlIIlIlIlIlII, 1.0F / llllllllllllllIllllIlIIlIlIlIlII);
      GlStateManager.translate(0.0F, 24.0F * llllllllllllllIllllIlIIlIlIIllII, 0.0F);
      body.render(llllllllllllllIllllIlIIlIlIIllII);
      leg1.render(llllllllllllllIllllIlIIlIlIIllII);
      leg2.render(llllllllllllllIllllIlIIlIlIIllII);
      leg3.render(llllllllllllllIllllIlIIlIlIIllII);
      leg4.render(llllllllllllllIllllIlIIlIlIIllII);
      GlStateManager.popMatrix();
      "".length();
      if (((0xB2 ^ 0x84 ^ (0x25 ^ 0x6A) & (0xF ^ 0x40 ^ 0xFFFFFFFF)) & (30 + 125 - 50 + 27 ^ 43 + 86 - -19 + 30 ^ -" ".length())) < "   ".length()) {}
    }
    else
    {
      head.render(llllllllllllllIllllIlIIlIlIIllII);
      body.render(llllllllllllllIllllIlIIlIlIIllII);
      leg1.render(llllllllllllllIllllIlIIlIlIIllII);
      leg2.render(llllllllllllllIllllIlIIlIlIIllII);
      leg3.render(llllllllllllllIllllIlIIlIlIIllII);
      leg4.render(llllllllllllllIllllIlIIlIlIIllII);
    }
  }
  
  private static boolean lIlIlIIlIllIIl(int ???)
  {
    Exception llllllllllllllIllllIlIIlIIllIlII;
    return ??? != 0;
  }
}

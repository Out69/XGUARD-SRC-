package net.minecraft.client.model;

public class ModelPig
  extends ModelQuadruped
{
  private static void llIIIlIlIlIlI()
  {
    lllllllIlII = new int[5];
    lllllllIlII[0] = (0xB0 ^ 0xB6);
    lllllllIlII[1] = (0x68 ^ 0x77 ^ 0x34 ^ 0x3B);
    lllllllIlII[2] = (0x92 ^ 0x96);
    lllllllIlII[3] = "   ".length();
    lllllllIlII[4] = " ".length();
  }
  
  static {}
  
  public ModelPig(float llllllllllllllllIIIIlIIIlIIlIIll)
  {
    llllllllllllllllIIIIlIIIlIIlIllI.<init>(lllllllIlII[0], llllllllllllllllIIIIlIIIlIIlIIll);
    head.setTextureOffset(lllllllIlII[1], lllllllIlII[1]).addBox(-2.0F, 0.0F, -9.0F, lllllllIlII[2], lllllllIlII[3], lllllllIlII[4], llllllllllllllllIIIIlIIIlIIlIIll);
    childYOffset = 4.0F;
  }
  
  public ModelPig()
  {
    llllllllllllllllIIIIlIIIlIIllIlI.<init>(0.0F);
  }
}

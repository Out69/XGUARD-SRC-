package net.minecraft.client.model;

public class ModelLargeChest
  extends ModelChest
{
  static {}
  
  public ModelLargeChest()
  {
    chestLid = new ModelRenderer(llllllllllllllIlIIIIIIlIIlIllIIl, lIIlIlIIIIIII[0], lIIlIlIIIIIII[0]).setTextureSize(lIIlIlIIIIIII[1], lIIlIlIIIIIII[2]);
    chestLid.addBox(0.0F, -5.0F, -14.0F, lIIlIlIIIIIII[3], lIIlIlIIIIIII[4], lIIlIlIIIIIII[5], 0.0F);
    chestLid.rotationPointX = 1.0F;
    chestLid.rotationPointY = 7.0F;
    chestLid.rotationPointZ = 15.0F;
    chestKnob = new ModelRenderer(llllllllllllllIlIIIIIIlIIlIllIIl, lIIlIlIIIIIII[0], lIIlIlIIIIIII[0]).setTextureSize(lIIlIlIIIIIII[1], lIIlIlIIIIIII[2]);
    chestKnob.addBox(-1.0F, -2.0F, -15.0F, lIIlIlIIIIIII[6], lIIlIlIIIIIII[7], lIIlIlIIIIIII[8], 0.0F);
    chestKnob.rotationPointX = 16.0F;
    chestKnob.rotationPointY = 7.0F;
    chestKnob.rotationPointZ = 15.0F;
    chestBelow = new ModelRenderer(llllllllllllllIlIIIIIIlIIlIllIIl, lIIlIlIIIIIII[0], lIIlIlIIIIIII[9]).setTextureSize(lIIlIlIIIIIII[1], lIIlIlIIIIIII[2]);
    chestBelow.addBox(0.0F, 0.0F, 0.0F, lIIlIlIIIIIII[3], lIIlIlIIIIIII[10], lIIlIlIIIIIII[5], 0.0F);
    chestBelow.rotationPointX = 1.0F;
    chestBelow.rotationPointY = 6.0F;
    chestBelow.rotationPointZ = 1.0F;
  }
  
  private static void lllIIIIlllIllI()
  {
    lIIlIlIIIIIII = new int[11];
    lIIlIlIIIIIII[0] = ((0x6F ^ 0x36) & (0x6E ^ 0x37 ^ 0xFFFFFFFF));
    lIIlIlIIIIIII[1] = (64 + 21 - -17 + 26);
    lIIlIlIIIIIII[2] = (0xE2 ^ 0xA2);
    lIIlIlIIIIIII[3] = (0x95 ^ 0x83 ^ 0xCE ^ 0xC6);
    lIIlIlIIIIIII[4] = (0x3D ^ 0x64 ^ 0x1E ^ 0x42);
    lIIlIlIIIIIII[5] = (0x56 ^ 0x58);
    lIIlIlIIIIIII[6] = "  ".length();
    lIIlIlIIIIIII[7] = (0x7D ^ 0x8 ^ 0x25 ^ 0x54);
    lIIlIlIIIIIII[8] = " ".length();
    lIIlIlIIIIIII[9] = (0x32 ^ 0x21);
    lIIlIlIIIIIII[10] = (0xAA ^ 0x94 ^ 0x27 ^ 0x13);
  }
}

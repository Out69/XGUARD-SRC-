package net.minecraft.client.model;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityGuardian;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class ModelGuardian
  extends ModelBase
{
  static {}
  
  public int func_178706_a()
  {
    return lIIlIlIIIIIlI[12];
  }
  
  private static boolean lllIIIIllllIIl(int ???, int arg1)
  {
    int i;
    char llllllllllllllIlIIIIIIIlIlllllII;
    return ??? >= i;
  }
  
  private static void lllIIIIllllIII()
  {
    lIIlIlIIIIIlI = new int[22];
    lIIlIlIIIIIlI[0] = (0x86 ^ 0xB6 ^ 0xF0 ^ 0x80);
    lIIlIlIIIIIlI[1] = (0x32 ^ 0x3E);
    lIIlIlIIIIIlI[2] = ((0x4E ^ 0x3) & (0x30 ^ 0x7D ^ 0xFFFFFFFF));
    lIIlIlIIIIIlI[3] = (0xBE ^ 0xAE);
    lIIlIlIIIIIlI[4] = (0x5E ^ 0x53 ^ 0x23 ^ 0x32);
    lIIlIlIIIIIlI[5] = "  ".length();
    lIIlIlIIIIIlI[6] = " ".length();
    lIIlIlIIIIIlI[7] = ('' + 58 - 191 + 150 ^ 40 + 57 - 81 + 122);
    lIIlIlIIIIIlI[8] = (0x2E ^ 0x67 ^ 0xD1 ^ 0x91);
    lIIlIlIIIIIlI[9] = (49 + 58 - -21 + 20 ^ 52 + 85 - 125 + 144);
    lIIlIlIIIIIlI[10] = "   ".length();
    lIIlIlIIIIIlI[11] = (0x60 ^ 0x14 ^ 0x3 ^ 0x73);
    lIIlIlIIIIIlI[12] = (0x3 ^ 0x35);
    lIIlIlIIIIIlI[13] = (0xFF ^ 0x91 ^ 0x9 ^ 0x60);
    lIIlIlIIIIIlI[14] = (0xAC ^ 0x85);
    lIIlIlIIIIIlI[15] = (29 + '¥' - 171 + 150 ^ 122 + 11 - 62 + 70);
    lIIlIlIIIIIlI[16] = (0x6C ^ 0x25 ^ 0x7A ^ 0x35);
    lIIlIlIIIIIlI[17] = (0x37 ^ 0x54 ^ 0x7C ^ 0x6);
    lIIlIlIIIIIlI[18] = (25 + 110 - 55 + 96 ^ 85 + '' - 112 + 53);
    lIIlIlIIIIIlI[19] = (0x61 ^ 0x64);
    lIIlIlIIIIIlI[20] = ('¨' + '' - 197 + 80 ^ 64 + 110 - 99 + 116);
    lIIlIlIIIIIlI[21] = (38 + 58 - 71 + 106 ^ 50 + 59 - 79 + 106);
  }
  
  public ModelGuardian()
  {
    textureWidth = lIIlIlIIIIIlI[0];
    textureHeight = lIIlIlIIIIIlI[0];
    "".length();
    "".length();
    "".length();
    "".length();
    "".length();
    int llllllllllllllIlIIIIIIIllllIIIlI = lIIlIlIIIIIlI[2];
    "".length();
    if ("   ".length() < -" ".length()) {
      throw null;
    }
    while (!lllIIIIllllIIl(llllllllllllllIlIIIIIIIllllIIIlI, guardianSpines.length))
    {
      guardianSpines[llllllllllllllIlIIIIIIIllllIIIlI] = new ModelRenderer(llllllllllllllIlIIIIIIIllllIIIll, lIIlIlIIIIIlI[2], lIIlIlIIIIIlI[2]);
      "".length();
      guardianBody.addChild(guardianSpines[llllllllllllllIlIIIIIIIllllIIIlI]);
    }
    guardianEye = new ModelRenderer(llllllllllllllIlIIIIIIIllllIIIll, lIIlIlIIIIIlI[9], lIIlIlIIIIIlI[2]);
    "".length();
    guardianBody.addChild(guardianEye);
    guardianTail = new ModelRenderer[lIIlIlIIIIIlI[10]];
    guardianTail[lIIlIlIIIIIlI[2]] = new ModelRenderer(llllllllllllllIlIIIIIIIllllIIIll, lIIlIlIIIIIlI[7], lIIlIlIIIIIlI[2]);
    "".length();
    guardianTail[lIIlIlIIIIIlI[6]] = new ModelRenderer(llllllllllllllIlIIIIIIIllllIIIll, lIIlIlIIIIIlI[2], lIIlIlIIIIIlI[12]);
    "".length();
    guardianTail[lIIlIlIIIIIlI[5]] = new ModelRenderer(llllllllllllllIlIIIIIIIllllIIIll);
    "".length();
    "".length();
    guardianBody.addChild(guardianTail[lIIlIlIIIIIlI[2]]);
    guardianTail[lIIlIlIIIIIlI[2]].addChild(guardianTail[lIIlIlIIIIIlI[6]]);
    guardianTail[lIIlIlIIIIIlI[6]].addChild(guardianTail[lIIlIlIIIIIlI[5]]);
  }
  
  private static boolean lllIIIIlllllIl(int ???)
  {
    Exception llllllllllllllIlIIIIIIIlIlllIllI;
    return ??? > 0;
  }
  
  public void render(Entity llllllllllllllIlIIIIIIIlllIlIlIl, float llllllllllllllIlIIIIIIIlllIlIlII, float llllllllllllllIlIIIIIIIlllIlIIll, float llllllllllllllIlIIIIIIIlllIIlIlI, float llllllllllllllIlIIIIIIIlllIlIIIl, float llllllllllllllIlIIIIIIIlllIIlIII, float llllllllllllllIlIIIIIIIlllIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlIIIIIIIlllIIlllI.setRotationAngles(llllllllllllllIlIIIIIIIlllIlIlII, llllllllllllllIlIIIIIIIlllIlIIll, llllllllllllllIlIIIIIIIlllIIlIlI, llllllllllllllIlIIIIIIIlllIlIIIl, llllllllllllllIlIIIIIIIlllIIlIII, llllllllllllllIlIIIIIIIlllIIIlll, llllllllllllllIlIIIIIIIlllIlIlIl);
    guardianBody.render(llllllllllllllIlIIIIIIIlllIIIlll);
  }
  
  private static boolean lllIIIIlllllII(Object ???)
  {
    long llllllllllllllIlIIIIIIIlIllllIlI;
    return ??? != null;
  }
  
  private static boolean lllIIIIllllIll(int ???)
  {
    int llllllllllllllIlIIIIIIIlIllllIII;
    return ??? != 0;
  }
  
  private static int lllIIIIllllIlI(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public void setRotationAngles(float llllllllllllllIlIIIIIIIllIlIllIl, float llllllllllllllIlIIIIIIIllIlIllII, float llllllllllllllIlIIIIIIIllIIlIIll, float llllllllllllllIlIIIIIIIllIIlIIlI, float llllllllllllllIlIIIIIIIllIlIlIIl, float llllllllllllllIlIIIIIIIllIlIlIII, Entity llllllllllllllIlIIIIIIIllIlIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EntityGuardian llllllllllllllIlIIIIIIIllIlIIllI = (EntityGuardian)llllllllllllllIlIIIIIIIllIlIIlll;
    float llllllllllllllIlIIIIIIIllIlIIlIl = llllllllllllllIlIIIIIIIllIIlIIll - ticksExisted;
    guardianBody.rotateAngleY = (llllllllllllllIlIIIIIIIllIIlIIlI / 57.295776F);
    guardianBody.rotateAngleX = (llllllllllllllIlIIIIIIIllIlIlIIl / 57.295776F);
    float[] llllllllllllllIlIIIIIIIllIlIIlII = { 1.75F, 0.25F, 0.0F, 0.0F, 0.5F, 0.5F, 0.5F, 0.5F, 1.25F, 0.75F, 0.0F, 0.0F };
    float[] llllllllllllllIlIIIIIIIllIlIIIll = { 0.0F, 0.0F, 0.0F, 0.0F, 0.25F, 1.75F, 1.25F, 0.75F, 0.0F, 0.0F, 0.0F, 0.0F };
    float[] llllllllllllllIlIIIIIIIllIlIIIlI = { 0.0F, 0.0F, 0.25F, 1.75F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.75F, 1.25F };
    float[] llllllllllllllIlIIIIIIIllIlIIIIl = { 0.0F, 0.0F, 8.0F, -8.0F, -8.0F, 8.0F, 8.0F, -8.0F, 0.0F, 0.0F, 8.0F, -8.0F };
    float[] llllllllllllllIlIIIIIIIllIlIIIII = { -8.0F, -8.0F, -8.0F, -8.0F, 0.0F, 0.0F, 0.0F, 0.0F, 8.0F, 8.0F, 8.0F, 8.0F };
    float[] llllllllllllllIlIIIIIIIllIIlllll = { 8.0F, -8.0F, 0.0F, 0.0F, -8.0F, -8.0F, 8.0F, 8.0F, 8.0F, -8.0F, 0.0F, 0.0F };
    float llllllllllllllIlIIIIIIIllIIllllI = (1.0F - llllllllllllllIlIIIIIIIllIlIIllI.func_175469_o(llllllllllllllIlIIIIIIIllIlIIlIl)) * 0.55F;
    int llllllllllllllIlIIIIIIIllIIlllIl = lIIlIlIIIIIlI[2];
    "".length();
    if ("  ".length() > "   ".length()) {
      return;
    }
    while (!lllIIIIllllIIl(llllllllllllllIlIIIIIIIllIIlllIl, lIIlIlIIIIIlI[1]))
    {
      guardianSpines[llllllllllllllIlIIIIIIIllIIlllIl].rotateAngleX = (3.1415927F * llllllllllllllIlIIIIIIIllIlIIlII[llllllllllllllIlIIIIIIIllIIlllIl]);
      guardianSpines[llllllllllllllIlIIIIIIIllIIlllIl].rotateAngleY = (3.1415927F * llllllllllllllIlIIIIIIIllIlIIIll[llllllllllllllIlIIIIIIIllIIlllIl]);
      guardianSpines[llllllllllllllIlIIIIIIIllIIlllIl].rotateAngleZ = (3.1415927F * llllllllllllllIlIIIIIIIllIlIIIlI[llllllllllllllIlIIIIIIIllIIlllIl]);
      guardianSpines[llllllllllllllIlIIIIIIIllIIlllIl].rotationPointX = (llllllllllllllIlIIIIIIIllIlIIIIl[llllllllllllllIlIIIIIIIllIIlllIl] * (1.0F + MathHelper.cos(llllllllllllllIlIIIIIIIllIIlIIll * 1.5F + llllllllllllllIlIIIIIIIllIIlllIl) * 0.01F - llllllllllllllIlIIIIIIIllIIllllI));
      guardianSpines[llllllllllllllIlIIIIIIIllIIlllIl].rotationPointY = (16.0F + llllllllllllllIlIIIIIIIllIlIIIII[llllllllllllllIlIIIIIIIllIIlllIl] * (1.0F + MathHelper.cos(llllllllllllllIlIIIIIIIllIIlIIll * 1.5F + llllllllllllllIlIIIIIIIllIIlllIl) * 0.01F - llllllllllllllIlIIIIIIIllIIllllI));
      guardianSpines[llllllllllllllIlIIIIIIIllIIlllIl].rotationPointZ = (llllllllllllllIlIIIIIIIllIIlllll[llllllllllllllIlIIIIIIIllIIlllIl] * (1.0F + MathHelper.cos(llllllllllllllIlIIIIIIIllIIlIIll * 1.5F + llllllllllllllIlIIIIIIIllIIlllIl) * 0.01F - llllllllllllllIlIIIIIIIllIIllllI));
      llllllllllllllIlIIIIIIIllIIlllIl++;
    }
    guardianEye.rotationPointZ = -8.25F;
    Entity llllllllllllllIlIIIIIIIllIIlllII = Minecraft.getMinecraft().getRenderViewEntity();
    if (lllIIIIllllIll(llllllllllllllIlIIIIIIIllIlIIllI.hasTargetedEntity())) {
      llllllllllllllIlIIIIIIIllIIlllII = llllllllllllllIlIIIIIIIllIlIIllI.getTargetedEntity();
    }
    if (lllIIIIlllllII(llllllllllllllIlIIIIIIIllIIlllII))
    {
      Vec3 llllllllllllllIlIIIIIIIllIIllIll = llllllllllllllIlIIIIIIIllIIlllII.getPositionEyes(0.0F);
      Vec3 llllllllllllllIlIIIIIIIllIIllIlI = llllllllllllllIlIIIIIIIllIlIIlll.getPositionEyes(0.0F);
      double llllllllllllllIlIIIIIIIllIIllIIl = yCoord - yCoord;
      if (lllIIIIlllllIl(lllIIIIllllIlI(llllllllllllllIlIIIIIIIllIIllIIl, 0.0D)))
      {
        guardianEye.rotationPointY = 0.0F;
        "".length();
        if (-(0x41 ^ 0x44) < 0) {}
      }
      else
      {
        guardianEye.rotationPointY = 1.0F;
      }
      Vec3 llllllllllllllIlIIIIIIIllIIllIII = llllllllllllllIlIIIIIIIllIlIIlll.getLook(0.0F);
      llllllllllllllIlIIIIIIIllIIllIII = new Vec3(xCoord, 0.0D, zCoord);
      Vec3 llllllllllllllIlIIIIIIIllIIlIlll = new Vec3(xCoord - xCoord, 0.0D, zCoord - zCoord).normalize().rotateYaw(1.5707964F);
      double llllllllllllllIlIIIIIIIllIIlIllI = llllllllllllllIlIIIIIIIllIIllIII.dotProduct(llllllllllllllIlIIIIIIIllIIlIlll);
      guardianEye.rotationPointX = (MathHelper.sqrt_float((float)Math.abs(llllllllllllllIlIIIIIIIllIIlIllI)) * 2.0F * (float)Math.signum(llllllllllllllIlIIIIIIIllIIlIllI));
    }
    guardianEye.showModel = lIIlIlIIIIIlI[6];
    float llllllllllllllIlIIIIIIIllIIlIlIl = llllllllllllllIlIIIIIIIllIlIIllI.func_175471_a(llllllllllllllIlIIIIIIIllIlIIlIl);
    guardianTail[lIIlIlIIIIIlI[2]].rotateAngleY = (MathHelper.sin(llllllllllllllIlIIIIIIIllIIlIlIl) * 3.1415927F * 0.05F);
    guardianTail[lIIlIlIIIIIlI[6]].rotateAngleY = (MathHelper.sin(llllllllllllllIlIIIIIIIllIIlIlIl) * 3.1415927F * 0.1F);
    guardianTail[lIIlIlIIIIIlI[6]].rotationPointX = -1.5F;
    guardianTail[lIIlIlIIIIIlI[6]].rotationPointY = 0.5F;
    guardianTail[lIIlIlIIIIIlI[6]].rotationPointZ = 14.0F;
    guardianTail[lIIlIlIIIIIlI[5]].rotateAngleY = (MathHelper.sin(llllllllllllllIlIIIIIIIllIIlIlIl) * 3.1415927F * 0.15F);
    guardianTail[lIIlIlIIIIIlI[5]].rotationPointX = 0.5F;
    guardianTail[lIIlIlIIIIIlI[5]].rotationPointY = 0.5F;
    guardianTail[lIIlIlIIIIIlI[5]].rotationPointZ = 6.0F;
  }
}

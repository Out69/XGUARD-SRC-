package net.minecraft.client.model;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.util.MathHelper;

public class ModelWolf
  extends ModelBase
{
  public void render(Entity llllllllllllllIllllIllIIlIlllIIl, float llllllllllllllIllllIllIIlIlllIII, float llllllllllllllIllllIllIIlIllIlll, float llllllllllllllIllllIllIIlIlIllIl, float llllllllllllllIllllIllIIlIllIlIl, float llllllllllllllIllllIllIIlIllIlII, float llllllllllllllIllllIllIIlIlIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllllIllIIlIlllIlI.render(llllllllllllllIllllIllIIlIlllIIl, llllllllllllllIllllIllIIlIlllIII, llllllllllllllIllllIllIIlIllIlll, llllllllllllllIllllIllIIlIlIllIl, llllllllllllllIllllIllIIlIllIlIl, llllllllllllllIllllIllIIlIllIlII, llllllllllllllIllllIllIIlIlIlIlI);
    llllllllllllllIllllIllIIlIlllIlI.setRotationAngles(llllllllllllllIllllIllIIlIlllIII, llllllllllllllIllllIllIIlIllIlll, llllllllllllllIllllIllIIlIlIllIl, llllllllllllllIllllIllIIlIllIlIl, llllllllllllllIllllIllIIlIllIlII, llllllllllllllIllllIllIIlIlIlIlI, llllllllllllllIllllIllIIlIlllIIl);
    if (lIlIlIIIIlllIl(isChild))
    {
      float llllllllllllllIllllIllIIlIllIIlI = 2.0F;
      GlStateManager.pushMatrix();
      GlStateManager.translate(0.0F, 5.0F * llllllllllllllIllllIllIIlIlIlIlI, 2.0F * llllllllllllllIllllIllIIlIlIlIlI);
      wolfHeadMain.renderWithRotation(llllllllllllllIllllIllIIlIlIlIlI);
      GlStateManager.popMatrix();
      GlStateManager.pushMatrix();
      GlStateManager.scale(1.0F / llllllllllllllIllllIllIIlIllIIlI, 1.0F / llllllllllllllIllllIllIIlIllIIlI, 1.0F / llllllllllllllIllllIllIIlIllIIlI);
      GlStateManager.translate(0.0F, 24.0F * llllllllllllllIllllIllIIlIlIlIlI, 0.0F);
      wolfBody.render(llllllllllllllIllllIllIIlIlIlIlI);
      wolfLeg1.render(llllllllllllllIllllIllIIlIlIlIlI);
      wolfLeg2.render(llllllllllllllIllllIllIIlIlIlIlI);
      wolfLeg3.render(llllllllllllllIllllIllIIlIlIlIlI);
      wolfLeg4.render(llllllllllllllIllllIllIIlIlIlIlI);
      wolfTail.renderWithRotation(llllllllllllllIllllIllIIlIlIlIlI);
      wolfMane.render(llllllllllllllIllllIllIIlIlIlIlI);
      GlStateManager.popMatrix();
      "".length();
      if (null == null) {}
    }
    else
    {
      wolfHeadMain.renderWithRotation(llllllllllllllIllllIllIIlIlIlIlI);
      wolfBody.render(llllllllllllllIllllIllIIlIlIlIlI);
      wolfLeg1.render(llllllllllllllIllllIllIIlIlIlIlI);
      wolfLeg2.render(llllllllllllllIllllIllIIlIlIlIlI);
      wolfLeg3.render(llllllllllllllIllllIllIIlIlIlIlI);
      wolfLeg4.render(llllllllllllllIllllIllIIlIlIlIlI);
      wolfTail.renderWithRotation(llllllllllllllIllllIllIIlIlIlIlI);
      wolfMane.render(llllllllllllllIllllIllIIlIlIlIlI);
    }
  }
  
  public ModelWolf()
  {
    float llllllllllllllIllllIllIIllIIlIII = 0.0F;
    float llllllllllllllIllllIllIIllIIIlll = 13.5F;
    wolfHeadMain = new ModelRenderer(llllllllllllllIllllIllIIllIIlIIl, llIlllIIIIII[0], llIlllIIIIII[0]);
    wolfHeadMain.addBox(-3.0F, -3.0F, -2.0F, llIlllIIIIII[1], llIlllIIIIII[1], llIlllIIIIII[2], llllllllllllllIllllIllIIllIIlIII);
    wolfHeadMain.setRotationPoint(-1.0F, llllllllllllllIllllIllIIllIIIlll, -7.0F);
    wolfBody = new ModelRenderer(llllllllllllllIllllIllIIllIIlIIl, llIlllIIIIII[3], llIlllIIIIII[4]);
    wolfBody.addBox(-4.0F, -2.0F, -3.0F, llIlllIIIIII[1], llIlllIIIIII[5], llIlllIIIIII[1], llllllllllllllIllllIllIIllIIlIII);
    wolfBody.setRotationPoint(0.0F, 14.0F, 2.0F);
    wolfMane = new ModelRenderer(llllllllllllllIllllIllIIllIIlIIl, llIlllIIIIII[6], llIlllIIIIII[0]);
    wolfMane.addBox(-4.0F, -3.0F, -3.0F, llIlllIIIIII[7], llIlllIIIIII[1], llIlllIIIIII[8], llllllllllllllIllllIllIIllIIlIII);
    wolfMane.setRotationPoint(-1.0F, 14.0F, 2.0F);
    wolfLeg1 = new ModelRenderer(llllllllllllllIllllIllIIllIIlIIl, llIlllIIIIII[0], llIlllIIIIII[3]);
    wolfLeg1.addBox(-1.0F, 0.0F, -1.0F, llIlllIIIIII[9], llIlllIIIIII[7], llIlllIIIIII[9], llllllllllllllIllllIllIIllIIlIII);
    wolfLeg1.setRotationPoint(-2.5F, 16.0F, 7.0F);
    wolfLeg2 = new ModelRenderer(llllllllllllllIllllIllIIllIIlIIl, llIlllIIIIII[0], llIlllIIIIII[3]);
    wolfLeg2.addBox(-1.0F, 0.0F, -1.0F, llIlllIIIIII[9], llIlllIIIIII[7], llIlllIIIIII[9], llllllllllllllIllllIllIIllIIlIII);
    wolfLeg2.setRotationPoint(0.5F, 16.0F, 7.0F);
    wolfLeg3 = new ModelRenderer(llllllllllllllIllllIllIIllIIlIIl, llIlllIIIIII[0], llIlllIIIIII[3]);
    wolfLeg3.addBox(-1.0F, 0.0F, -1.0F, llIlllIIIIII[9], llIlllIIIIII[7], llIlllIIIIII[9], llllllllllllllIllllIllIIllIIlIII);
    wolfLeg3.setRotationPoint(-2.5F, 16.0F, -4.0F);
    wolfLeg4 = new ModelRenderer(llllllllllllllIllllIllIIllIIlIIl, llIlllIIIIII[0], llIlllIIIIII[3]);
    wolfLeg4.addBox(-1.0F, 0.0F, -1.0F, llIlllIIIIII[9], llIlllIIIIII[7], llIlllIIIIII[9], llllllllllllllIllllIllIIllIIlIII);
    wolfLeg4.setRotationPoint(0.5F, 16.0F, -4.0F);
    wolfTail = new ModelRenderer(llllllllllllllIllllIllIIllIIlIIl, llIlllIIIIII[5], llIlllIIIIII[3]);
    wolfTail.addBox(-1.0F, 0.0F, -1.0F, llIlllIIIIII[9], llIlllIIIIII[7], llIlllIIIIII[9], llllllllllllllIllllIllIIllIIlIII);
    wolfTail.setRotationPoint(-1.0F, 12.0F, 8.0F);
    wolfHeadMain.setTextureOffset(llIlllIIIIII[10], llIlllIIIIII[4]).addBox(-3.0F, -5.0F, 0.0F, llIlllIIIIII[9], llIlllIIIIII[9], llIlllIIIIII[11], llllllllllllllIllllIllIIllIIlIII);
    wolfHeadMain.setTextureOffset(llIlllIIIIII[10], llIlllIIIIII[4]).addBox(1.0F, -5.0F, 0.0F, llIlllIIIIII[9], llIlllIIIIII[9], llIlllIIIIII[11], llllllllllllllIllllIllIIllIIlIII);
    wolfHeadMain.setTextureOffset(llIlllIIIIII[0], llIlllIIIIII[12]).addBox(-1.5F, 0.0F, -5.0F, llIlllIIIIII[13], llIlllIIIIII[13], llIlllIIIIII[2], llllllllllllllIllllIllIIllIIlIII);
  }
  
  public void setLivingAnimations(EntityLivingBase llllllllllllllIllllIllIIlIIllIll, float llllllllllllllIllllIllIIlIIllIlI, float llllllllllllllIllllIllIIlIIlllll, float llllllllllllllIllllIllIIlIIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    EntityWolf llllllllllllllIllllIllIIlIIlllIl = (EntityWolf)llllllllllllllIllllIllIIlIIllIll;
    if (lIlIlIIIIlllIl(llllllllllllllIllllIllIIlIIlllIl.isAngry()))
    {
      wolfTail.rotateAngleY = 0.0F;
      "".length();
      if (-"  ".length() <= 0) {}
    }
    else
    {
      wolfTail.rotateAngleY = (MathHelper.cos(llllllllllllllIllllIllIIlIlIIIII * 0.6662F) * 1.4F * llllllllllllllIllllIllIIlIIlllll);
    }
    if (lIlIlIIIIlllIl(llllllllllllllIllllIllIIlIIlllIl.isSitting()))
    {
      wolfMane.setRotationPoint(-1.0F, 16.0F, -3.0F);
      wolfMane.rotateAngleX = 1.2566371F;
      wolfMane.rotateAngleY = 0.0F;
      wolfBody.setRotationPoint(0.0F, 18.0F, 0.0F);
      wolfBody.rotateAngleX = 0.7853982F;
      wolfTail.setRotationPoint(-1.0F, 21.0F, 6.0F);
      wolfLeg1.setRotationPoint(-2.5F, 22.0F, 2.0F);
      wolfLeg1.rotateAngleX = 4.712389F;
      wolfLeg2.setRotationPoint(0.5F, 22.0F, 2.0F);
      wolfLeg2.rotateAngleX = 4.712389F;
      wolfLeg3.rotateAngleX = 5.811947F;
      wolfLeg3.setRotationPoint(-2.49F, 17.0F, -4.0F);
      wolfLeg4.rotateAngleX = 5.811947F;
      wolfLeg4.setRotationPoint(0.51F, 17.0F, -4.0F);
      "".length();
      if (null == null) {}
    }
    else
    {
      wolfBody.setRotationPoint(0.0F, 14.0F, 2.0F);
      wolfBody.rotateAngleX = 1.5707964F;
      wolfMane.setRotationPoint(-1.0F, 14.0F, -3.0F);
      wolfMane.rotateAngleX = wolfBody.rotateAngleX;
      wolfTail.setRotationPoint(-1.0F, 12.0F, 8.0F);
      wolfLeg1.setRotationPoint(-2.5F, 16.0F, 7.0F);
      wolfLeg2.setRotationPoint(0.5F, 16.0F, 7.0F);
      wolfLeg3.setRotationPoint(-2.5F, 16.0F, -4.0F);
      wolfLeg4.setRotationPoint(0.5F, 16.0F, -4.0F);
      wolfLeg1.rotateAngleX = (MathHelper.cos(llllllllllllllIllllIllIIlIlIIIII * 0.6662F) * 1.4F * llllllllllllllIllllIllIIlIIlllll);
      wolfLeg2.rotateAngleX = (MathHelper.cos(llllllllllllllIllllIllIIlIlIIIII * 0.6662F + 3.1415927F) * 1.4F * llllllllllllllIllllIllIIlIIlllll);
      wolfLeg3.rotateAngleX = (MathHelper.cos(llllllllllllllIllllIllIIlIlIIIII * 0.6662F + 3.1415927F) * 1.4F * llllllllllllllIllllIllIIlIIlllll);
      wolfLeg4.rotateAngleX = (MathHelper.cos(llllllllllllllIllllIllIIlIlIIIII * 0.6662F) * 1.4F * llllllllllllllIllllIllIIlIIlllll);
    }
    wolfHeadMain.rotateAngleZ = (llllllllllllllIllllIllIIlIIlllIl.getInterestedAngle(llllllllllllllIllllIllIIlIIllllI) + llllllllllllllIllllIllIIlIIlllIl.getShakeAngle(llllllllllllllIllllIllIIlIIllllI, 0.0F));
    wolfMane.rotateAngleZ = llllllllllllllIllllIllIIlIIlllIl.getShakeAngle(llllllllllllllIllllIllIIlIIllllI, -0.08F);
    wolfBody.rotateAngleZ = llllllllllllllIllllIllIIlIIlllIl.getShakeAngle(llllllllllllllIllllIllIIlIIllllI, -0.16F);
    wolfTail.rotateAngleZ = llllllllllllllIllllIllIIlIIlllIl.getShakeAngle(llllllllllllllIllllIllIIlIIllllI, -0.2F);
  }
  
  private static boolean lIlIlIIIIlllIl(int ???)
  {
    short llllllllllllllIllllIllIIIlllllIl;
    return ??? != 0;
  }
  
  public void setRotationAngles(float llllllllllllllIllllIllIIlIIIllIl, float llllllllllllllIllllIllIIlIIIllII, float llllllllllllllIllllIllIIlIIIIIll, float llllllllllllllIllllIllIIlIIIlIlI, float llllllllllllllIllllIllIIlIIIIIIl, float llllllllllllllIllllIllIIlIIIIIII, Entity llllllllllllllIllllIllIIIlllllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllllIllIIlIIIIllI.setRotationAngles(llllllllllllllIllllIllIIlIIIllIl, llllllllllllllIllllIllIIlIIIllII, llllllllllllllIllllIllIIlIIIIIll, llllllllllllllIllllIllIIlIIIlIlI, llllllllllllllIllllIllIIlIIIIIIl, llllllllllllllIllllIllIIlIIIIIII, llllllllllllllIllllIllIIIlllllll);
    wolfHeadMain.rotateAngleX = (llllllllllllllIllllIllIIlIIIIIIl / 57.295776F);
    wolfHeadMain.rotateAngleY = (llllllllllllllIllllIllIIlIIIlIlI / 57.295776F);
    wolfTail.rotateAngleX = llllllllllllllIllllIllIIlIIIIIll;
  }
  
  static {}
  
  private static void lIlIlIIIIlllII()
  {
    llIlllIIIIII = new int[14];
    llIlllIIIIII[0] = ((0xAE ^ 0xA9) & (0x7D ^ 0x7A ^ 0xFFFFFFFF));
    llIlllIIIIII[1] = (0x80 ^ 0x86);
    llIlllIIIIII[2] = (0xE6 ^ 0xC1 ^ 0xC ^ 0x2F);
    llIlllIIIIII[3] = (9 + 63 - -59 + 6 ^ 103 + 73 - 109 + 88);
    llIlllIIIIII[4] = (0xB3 ^ 0xBD);
    llIlllIIIIII[5] = (0x23 ^ 0x2A);
    llIlllIIIIII[6] = (0x75 ^ 0x60);
    llIlllIIIIII[7] = (0x52 ^ 0x5A);
    llIlllIIIIII[8] = (0x2D ^ 0x29 ^ "   ".length());
    llIlllIIIIII[9] = "  ".length();
    llIlllIIIIII[10] = (0xB1 ^ 0xA1);
    llIlllIIIIII[11] = " ".length();
    llIlllIIIIII[12] = (0xB3 ^ 0xB9);
    llIlllIIIIII[13] = "   ".length();
  }
}

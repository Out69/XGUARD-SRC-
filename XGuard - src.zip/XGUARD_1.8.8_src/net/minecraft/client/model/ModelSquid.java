package net.minecraft.client.model;

import net.minecraft.entity.Entity;

public class ModelSquid
  extends ModelBase
{
  public ModelSquid()
  {
    int llllllllllllllIllIlllIllIIllllll = lllIllIlIIll[1];
    squidBody = new ModelRenderer(llllllllllllllIllIlllIllIIlllIlI, lllIllIlIIll[2], lllIllIlIIll[2]);
    "".length();
    squidBody.rotationPointY += lllIllIlIIll[5] + llllllllllllllIllIlllIllIIllllll;
    int llllllllllllllIllIlllIllIIlllllI = lllIllIlIIll[2];
    "".length();
    if ((0xBE ^ 0xBA) < (0x9B ^ 0x9F)) {
      throw null;
    }
    while (!lIllIlIlIlIlIl(llllllllllllllIllIlllIllIIlllllI, squidTentacles.length))
    {
      squidTentacles[llllllllllllllIllIlllIllIIlllllI] = new ModelRenderer(llllllllllllllIllIlllIllIIlllIlI, lllIllIlIIll[6], lllIllIlIIll[2]);
      double llllllllllllllIllIlllIllIIllllIl = llllllllllllllIllIlllIllIIlllllI * 3.141592653589793D * 2.0D / squidTentacles.length;
      float llllllllllllllIllIlllIllIIllllII = (float)Math.cos(llllllllllllllIllIlllIllIIllllIl) * 5.0F;
      float llllllllllllllIllIlllIllIIlllIll = (float)Math.sin(llllllllllllllIllIlllIllIIllllIl) * 5.0F;
      "".length();
      squidTentacles[llllllllllllllIllIlllIllIIlllllI].rotationPointX = llllllllllllllIllIlllIllIIllllII;
      squidTentacles[llllllllllllllIllIlllIllIIlllllI].rotationPointZ = llllllllllllllIllIlllIllIIlllIll;
      squidTentacles[llllllllllllllIllIlllIllIIlllllI].rotationPointY = (lllIllIlIIll[9] + llllllllllllllIllIlllIllIIllllll);
      llllllllllllllIllIlllIllIIllllIl = llllllllllllllIllIlllIllIIlllllI * 3.141592653589793D * -2.0D / squidTentacles.length + 1.5707963267948966D;
      squidTentacles[llllllllllllllIllIlllIllIIlllllI].rotateAngleY = ((float)llllllllllllllIllIlllIllIIllllIl);
    }
  }
  
  private static void lIllIlIlIlIlII()
  {
    lllIllIlIIll = new int[10];
    lllIllIlIIll[0] = (0xB7 ^ 0x95 ^ 0x90 ^ 0xBA);
    lllIllIlIIll[1] = (-(0x3D ^ 0x2D));
    lllIllIlIIll[2] = ((0x3A ^ 0x13) & (0xB5 ^ 0x9C ^ 0xFFFFFFFF));
    lllIllIlIIll[3] = (0xD ^ 0x56 ^ 0xD1 ^ 0x86);
    lllIllIlIIll[4] = (0x26 ^ 0x36);
    lllIllIlIIll[5] = (0x50 ^ 0xB ^ 0x7D ^ 0x3E);
    lllIllIlIIll[6] = (0x51 ^ 0x61);
    lllIllIlIIll[7] = "  ".length();
    lllIllIlIIll[8] = (0x1F ^ 0x54 ^ 0xC7 ^ 0x9E);
    lllIllIlIIll[9] = (0x64 ^ 0x7D ^ 0xD ^ 0xB);
  }
  
  public void setRotationAngles(float llllllllllllllIllIlllIllIIlIllIl, float llllllllllllllIllIlllIllIIlIllII, float llllllllllllllIllIlllIllIIlIlIll, float llllllllllllllIllIlllIllIIlIlIlI, float llllllllllllllIllIlllIllIIlIlIIl, float llllllllllllllIllIlllIllIIlIlIII, Entity llllllllllllllIllIlllIllIIlIIlll)
  {
    ;
    ;
    ;
    ;
    Exception llllllllllllllIllIlllIllIIlIIIIl = (llllllllllllllIllIlllIllIIlIIIII = squidTentacles).length;
    Exception llllllllllllllIllIlllIllIIlIIIlI = lllIllIlIIll[2];
    "".length();
    if ((0x7F ^ 0x7B) < (0xB5 ^ 0xB1)) {
      return;
    }
    while (!lIllIlIlIlIlIl(llllllllllllllIllIlllIllIIlIIIlI, llllllllllllllIllIlllIllIIlIIIIl))
    {
      ModelRenderer llllllllllllllIllIlllIllIIlIIllI = llllllllllllllIllIlllIllIIlIIIII[llllllllllllllIllIlllIllIIlIIIlI];
      rotateAngleX = llllllllllllllIllIlllIllIIlIlIll;
      llllllllllllllIllIlllIllIIlIIIlI++;
    }
  }
  
  private static boolean lIllIlIlIlIlIl(int ???, int arg1)
  {
    int i;
    short llllllllllllllIllIlllIllIIIIIIIl;
    return ??? >= i;
  }
  
  static {}
  
  public void render(Entity llllllllllllllIllIlllIllIIIlIlIl, float llllllllllllllIllIlllIllIIIIlIll, float llllllllllllllIllIlllIllIIIlIIll, float llllllllllllllIllIlllIllIIIlIIlI, float llllllllllllllIllIlllIllIIIIlIII, float llllllllllllllIllIlllIllIIIIIlll, float llllllllllllllIllIlllIllIIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIlllIllIIIIllIl.setRotationAngles(llllllllllllllIllIlllIllIIIIlIll, llllllllllllllIllIlllIllIIIlIIll, llllllllllllllIllIlllIllIIIlIIlI, llllllllllllllIllIlllIllIIIIlIII, llllllllllllllIllIlllIllIIIIIlll, llllllllllllllIllIlllIllIIIIllll, llllllllllllllIllIlllIllIIIlIlIl);
    squidBody.render(llllllllllllllIllIlllIllIIIIllll);
    int llllllllllllllIllIlllIllIIIIlllI = lllIllIlIIll[2];
    "".length();
    if (" ".length() >= "   ".length()) {
      return;
    }
    while (!lIllIlIlIlIlIl(llllllllllllllIllIlllIllIIIIlllI, squidTentacles.length))
    {
      squidTentacles[llllllllllllllIllIlllIllIIIIlllI].render(llllllllllllllIllIlllIllIIIIllll);
      llllllllllllllIllIlllIllIIIIlllI++;
    }
  }
}

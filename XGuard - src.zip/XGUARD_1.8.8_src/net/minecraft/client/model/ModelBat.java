package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.util.MathHelper;

public class ModelBat
  extends ModelBase
{
  public void setRotationAngles(float llllllllllllllllIIIlllIIllIlllll, float llllllllllllllllIIIlllIIllIllllI, float llllllllllllllllIIIlllIIllIlllIl, float llllllllllllllllIIIlllIIllIlllII, float llllllllllllllllIIIlllIIllIllIll, float llllllllllllllllIIIlllIIllIllIlI, Entity llllllllllllllllIIIlllIIllIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllllIIIIIlI(((EntityBat)llllllllllllllllIIIlllIIllIllIIl).getIsBatHanging()))
    {
      float llllllllllllllllIIIlllIIllIllIII = 57.295776F;
      batHead.rotateAngleX = (llllllllllllllllIIIlllIIllIllIll / 57.295776F);
      batHead.rotateAngleY = (3.1415927F - llllllllllllllllIIIlllIIllIlllII / 57.295776F);
      batHead.rotateAngleZ = 3.1415927F;
      batHead.setRotationPoint(0.0F, -2.0F, 0.0F);
      batRightWing.setRotationPoint(-3.0F, 0.0F, 3.0F);
      batLeftWing.setRotationPoint(3.0F, 0.0F, 3.0F);
      batBody.rotateAngleX = 3.1415927F;
      batRightWing.rotateAngleX = -0.15707964F;
      batRightWing.rotateAngleY = -1.2566371F;
      batOuterRightWing.rotateAngleY = -1.7278761F;
      batLeftWing.rotateAngleX = batRightWing.rotateAngleX;
      batLeftWing.rotateAngleY = (-batRightWing.rotateAngleY);
      batOuterLeftWing.rotateAngleY = (-batOuterRightWing.rotateAngleY);
      "".length();
      if ("  ".length() >= 0) {}
    }
    else
    {
      float llllllllllllllllIIIlllIIllIlIlll = 57.295776F;
      batHead.rotateAngleX = (llllllllllllllllIIIlllIIllIllIll / 57.295776F);
      batHead.rotateAngleY = (llllllllllllllllIIIlllIIllIlllII / 57.295776F);
      batHead.rotateAngleZ = 0.0F;
      batHead.setRotationPoint(0.0F, 0.0F, 0.0F);
      batRightWing.setRotationPoint(0.0F, 0.0F, 0.0F);
      batLeftWing.setRotationPoint(0.0F, 0.0F, 0.0F);
      batBody.rotateAngleX = (0.7853982F + MathHelper.cos(llllllllllllllllIIIlllIIllIlllIl * 0.1F) * 0.15F);
      batBody.rotateAngleY = 0.0F;
      batRightWing.rotateAngleY = (MathHelper.cos(llllllllllllllllIIIlllIIllIlllIl * 1.3F) * 3.1415927F * 0.25F);
      batLeftWing.rotateAngleY = (-batRightWing.rotateAngleY);
      batOuterRightWing.rotateAngleY = (batRightWing.rotateAngleY * 0.5F);
      batOuterLeftWing.rotateAngleY = (-batRightWing.rotateAngleY * 0.5F);
    }
  }
  
  static {}
  
  public ModelBat()
  {
    textureWidth = llllIIllllI[0];
    textureHeight = llllIIllllI[0];
    "".length();
    ModelRenderer llllllllllllllllIIIlllIlIIIIIIll = new ModelRenderer(llllllllllllllllIIIlllIlIIIIIIIl, llllIIllllI[3], llllIIllllI[1]);
    "".length();
    batHead.addChild(llllllllllllllllIIIlllIlIIIIIIll);
    ModelRenderer llllllllllllllllIIIlllIlIIIIIIlI = new ModelRenderer(llllllllllllllllIIIlllIlIIIIIIIl, llllIIllllI[3], llllIIllllI[1]);
    mirror = llllIIllllI[6];
    "".length();
    batHead.addChild(llllllllllllllllIIIlllIlIIIIIIlI);
    batBody = new ModelRenderer(llllllllllllllllIIIlllIlIIIIIIIl, llllIIllllI[1], llllIIllllI[7]);
    "".length();
    "".length();
    batRightWing = new ModelRenderer(llllllllllllllllIIIlllIlIIIIIIIl, llllIIllllI[11], llllIIllllI[1]);
    "".length();
    batOuterRightWing = new ModelRenderer(llllllllllllllllIIIlllIlIIIIIIIl, llllIIllllI[3], llllIIllllI[7]);
    batOuterRightWing.setRotationPoint(-12.0F, 1.0F, 1.5F);
    "".length();
    batLeftWing = new ModelRenderer(llllllllllllllllIIIlllIlIIIIIIIl, llllIIllllI[11], llllIIllllI[1]);
    batLeftWing.mirror = llllIIllllI[6];
    "".length();
    batOuterLeftWing = new ModelRenderer(llllllllllllllllIIIlllIlIIIIIIIl, llllIIllllI[3], llllIIllllI[7]);
    batOuterLeftWing.mirror = llllIIllllI[6];
    batOuterLeftWing.setRotationPoint(12.0F, 1.0F, 1.5F);
    "".length();
    batBody.addChild(batRightWing);
    batBody.addChild(batLeftWing);
    batRightWing.addChild(batOuterRightWing);
    batLeftWing.addChild(batOuterLeftWing);
  }
  
  private static boolean lIllllIIIIIlI(int ???)
  {
    Exception llllllllllllllllIIIlllIIllIIllll;
    return ??? != 0;
  }
  
  public void render(Entity llllllllllllllllIIIlllIIllllIlIl, float llllllllllllllllIIIlllIIlllIllII, float llllllllllllllllIIIlllIIlllIlIll, float llllllllllllllllIIIlllIIllllIIlI, float llllllllllllllllIIIlllIIlllIlIIl, float llllllllllllllllIIIlllIIlllIlIII, float llllllllllllllllIIIlllIIlllIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIIlllIIlllIlllI.setRotationAngles(llllllllllllllllIIIlllIIlllIllII, llllllllllllllllIIIlllIIlllIlIll, llllllllllllllllIIIlllIIllllIIlI, llllllllllllllllIIIlllIIlllIlIIl, llllllllllllllllIIIlllIIlllIlIII, llllllllllllllllIIIlllIIlllIllll, llllllllllllllllIIIlllIIllllIlIl);
    batHead.render(llllllllllllllllIIIlllIIlllIllll);
    batBody.render(llllllllllllllllIIIlllIIlllIllll);
  }
  
  private static void lIllllIIIIIIl()
  {
    llllIIllllI = new int[13];
    llllIIllllI[0] = (0xDC ^ 0x9C);
    llllIIllllI[1] = ((0xF2 ^ 0xB0 ^ 0xB5 ^ 0xBF) & ('·' + 87 - 61 + 17 ^ '' + '' - 213 + 91 ^ -" ".length()));
    llllIIllllI[2] = (0x3B ^ 0x3D);
    llllIIllllI[3] = (0x26 ^ 0x3E);
    llllIIllllI[4] = "   ".length();
    llllIIllllI[5] = (56 + 24 - 16 + 71 ^ 117 + 20 - 101 + 95);
    llllIIllllI[6] = " ".length();
    llllIIllllI[7] = (0x29 ^ 0x39);
    llllIIllllI[8] = (0x30 ^ 0x16 ^ 0x39 ^ 0x13);
    llllIIllllI[9] = ('' + 62 - 123 + 94 ^ 45 + 108 - 98 + 78);
    llllIIllllI[10] = (0x39 ^ 0x33);
    llllIIllllI[11] = (0x42 ^ 0x68);
    llllIIllllI[12] = ('´' + 29 - 79 + 55 ^ 116 + 33 - 93 + 121);
  }
}

package net.minecraft.client.model;

public class ModelCow
  extends ModelQuadruped
{
  private static void lIlIIlIllIIlll()
  {
    llIllIIIlIII = new int[11];
    llIllIIIlIII[0] = (0x22 ^ 0x2E);
    llIllIIIlIII[1] = (('' + 36 - 108 + 100 ^ 117 + 31 - 52 + 88) & (0xF5 ^ 0xAC ^ 0x4E ^ 0xB ^ -" ".length()));
    llIllIIIlIII[2] = ("   ".length() ^ 0x5C ^ 0x57);
    llIllIIIlIII[3] = (47 + 125 - 108 + 112 ^ 88 + 126 - 182 + 150);
    llIllIIIlIII[4] = (0x1D ^ 0x16 ^ 0x2B ^ 0x36);
    llIllIIIlIII[5] = " ".length();
    llIllIIIlIII[6] = "   ".length();
    llIllIIIlIII[7] = (0x8B ^ 0x8D ^ 0x19 ^ 0xD);
    llIllIIIlIII[8] = (0xA1 ^ 0xA5);
    llIllIIIlIII[9] = (0x9B ^ 0x85 ^ 0x55 ^ 0x41);
    llIllIIIlIII[10] = (4 + '' - 118 + 203 ^ '«' + 85 - 185 + 123);
  }
  
  static {}
  
  public ModelCow()
  {
    llllllllllllllIlllllllIIIlllIIlI.<init>(llIllIIIlIII[0], 0.0F);
    head = new ModelRenderer(llllllllllllllIlllllllIIIlllIIIl, llIllIIIlIII[1], llIllIIIlIII[1]);
    head.addBox(-4.0F, -4.0F, -6.0F, llIllIIIlIII[2], llIllIIIlIII[2], llIllIIIlIII[3], 0.0F);
    head.setRotationPoint(0.0F, 4.0F, -8.0F);
    head.setTextureOffset(llIllIIIlIII[4], llIllIIIlIII[1]).addBox(-5.0F, -5.0F, -4.0F, llIllIIIlIII[5], llIllIIIlIII[6], llIllIIIlIII[5], 0.0F);
    head.setTextureOffset(llIllIIIlIII[4], llIllIIIlIII[1]).addBox(4.0F, -5.0F, -4.0F, llIllIIIlIII[5], llIllIIIlIII[6], llIllIIIlIII[5], 0.0F);
    body = new ModelRenderer(llllllllllllllIlllllllIIIlllIIIl, llIllIIIlIII[7], llIllIIIlIII[8]);
    body.addBox(-6.0F, -10.0F, -7.0F, llIllIIIlIII[0], llIllIIIlIII[7], llIllIIIlIII[9], 0.0F);
    body.setRotationPoint(0.0F, 5.0F, 2.0F);
    "".length();
    leg1.rotationPointX -= 1.0F;
    leg2.rotationPointX += 1.0F;
    leg1.rotationPointZ += 0.0F;
    leg2.rotationPointZ += 0.0F;
    leg3.rotationPointX -= 1.0F;
    leg4.rotationPointX += 1.0F;
    leg3.rotationPointZ -= 1.0F;
    leg4.rotationPointZ -= 1.0F;
    childZOffset += 2.0F;
  }
}

package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelBook
  extends ModelBase
{
  public void setRotationAngles(float lllllllllllllllIllIIIlllIlIIIlIl, float lllllllllllllllIllIIIlllIlIIIlII, float lllllllllllllllIllIIIlllIIlllIlI, float lllllllllllllllIllIIIlllIIlllIIl, float lllllllllllllllIllIIIlllIlIIIIIl, float lllllllllllllllIllIIIlllIlIIIIII, Entity lllllllllllllllIllIIIlllIIllllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIllIIIlllIIlllllI = (MathHelper.sin(lllllllllllllllIllIIIlllIlIIIlIl * 0.02F) * 0.1F + 1.25F) * lllllllllllllllIllIIIlllIIlllIIl;
    coverRight.rotateAngleY = (3.1415927F + lllllllllllllllIllIIIlllIIlllllI);
    coverLeft.rotateAngleY = (-lllllllllllllllIllIIIlllIIlllllI);
    pagesRight.rotateAngleY = lllllllllllllllIllIIIlllIIlllllI;
    pagesLeft.rotateAngleY = (-lllllllllllllllIllIIIlllIIlllllI);
    flippingPageRight.rotateAngleY = (lllllllllllllllIllIIIlllIIlllllI - lllllllllllllllIllIIIlllIIlllllI * 2.0F * lllllllllllllllIllIIIlllIlIIIlII);
    flippingPageLeft.rotateAngleY = (lllllllllllllllIllIIIlllIIlllllI - lllllllllllllllIllIIIlllIIlllllI * 2.0F * lllllllllllllllIllIIIlllIIlllIlI);
    pagesRight.rotationPointX = MathHelper.sin(lllllllllllllllIllIIIlllIIlllllI);
    pagesLeft.rotationPointX = MathHelper.sin(lllllllllllllllIllIIIlllIIlllllI);
    flippingPageRight.rotationPointX = MathHelper.sin(lllllllllllllllIllIIIlllIIlllllI);
    flippingPageLeft.rotationPointX = MathHelper.sin(lllllllllllllllIllIIIlllIIlllllI);
  }
  
  private static void lllIIllIllIlI()
  {
    lIIlIlIlllII = new int[10];
    lIIlIlIlllII[0] = ((0x63 ^ 0x6 ^ 0xCC ^ 0x95) & (112 + '' - 56 + 3 ^ 73 + 90 - 144 + 116 ^ -" ".length()));
    lIIlIlIlllII[1] = (0x33 ^ 0x35);
    lIIlIlIlllII[2] = (0x38 ^ 0x32);
    lIIlIlIlllII[3] = (80 + 11 - 3 + 40 ^ 115 + 83 - 115 + 61);
    lIIlIlIlllII[4] = (0x58 ^ 0x5D);
    lIIlIlIlllII[5] = (0x50 ^ 0x44 ^ 0xB2 ^ 0xAE);
    lIIlIlIlllII[6] = " ".length();
    lIIlIlIlllII[7] = (0x47 ^ 0x6F ^ 0xBA ^ 0x9E);
    lIIlIlIlllII[8] = (0x8F ^ 0x86 ^ 0x52 ^ 0x43);
    lIIlIlIlllII[9] = "  ".length();
  }
  
  public ModelBook()
  {
    coverRight.setRotationPoint(0.0F, 0.0F, -1.0F);
    coverLeft.setRotationPoint(0.0F, 0.0F, 1.0F);
    bookSpine.rotateAngleY = 1.5707964F;
  }
  
  static {}
  
  public void render(Entity lllllllllllllllIllIIIlllIlIllIll, float lllllllllllllllIllIIIlllIlIllIlI, float lllllllllllllllIllIIIlllIlIlIIIl, float lllllllllllllllIllIIIlllIlIllIII, float lllllllllllllllIllIIIlllIlIIllll, float lllllllllllllllIllIIIlllIlIlIllI, float lllllllllllllllIllIIIlllIlIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllIIIlllIlIlllII.setRotationAngles(lllllllllllllllIllIIIlllIlIllIlI, lllllllllllllllIllIIIlllIlIlIIIl, lllllllllllllllIllIIIlllIlIllIII, lllllllllllllllIllIIIlllIlIIllll, lllllllllllllllIllIIIlllIlIlIllI, lllllllllllllllIllIIIlllIlIIllIl, lllllllllllllllIllIIIlllIlIllIll);
    coverRight.render(lllllllllllllllIllIIIlllIlIIllIl);
    coverLeft.render(lllllllllllllllIllIIIlllIlIIllIl);
    bookSpine.render(lllllllllllllllIllIIIlllIlIIllIl);
    pagesRight.render(lllllllllllllllIllIIIlllIlIIllIl);
    pagesLeft.render(lllllllllllllllIllIIIlllIlIIllIl);
    flippingPageRight.render(lllllllllllllllIllIIIlllIlIIllIl);
    flippingPageLeft.render(lllllllllllllllIllIIIlllIlIIllIl);
  }
}

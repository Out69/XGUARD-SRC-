package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.passive.EntitySheep;

public class ModelSheep1
  extends ModelQuadruped
{
  static {}
  
  private static void lIlIIlIIIlIIIl()
  {
    llIlIlIllIll = new int[7];
    llIlIlIllIll[0] = (0x9F ^ 0x93);
    llIlIlIllIll[1] = ((106 + '¤' - 146 + 55 ^ 64 + 100 - 140 + 107) & (0x3B ^ 0xD ^ 0x38 ^ 0x3E ^ -" ".length()));
    llIlIlIllIll[2] = (0x70 ^ 0x76);
    llIlIlIllIll[3] = (0x5E ^ 0x42);
    llIlIlIllIll[4] = (0x75 ^ 0x6E ^ 0x8 ^ 0x1B);
    llIlIlIllIll[5] = (0x7A ^ 0x6A);
    llIlIlIllIll[6] = (18 + 12 - -31 + 74 ^ 114 + 48 - 147 + 116);
  }
  
  public void setRotationAngles(float lllllllllllllllIIIIIIIIIlIlIllII, float lllllllllllllllIIIIIIIIIlIlIlIll, float lllllllllllllllIIIIIIIIIlIlIlIlI, float lllllllllllllllIIIIIIIIIlIlIlIIl, float lllllllllllllllIIIIIIIIIlIlIIIII, float lllllllllllllllIIIIIIIIIlIlIIlll, Entity lllllllllllllllIIIIIIIIIlIIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIIIIIIIlIlIllIl.setRotationAngles(lllllllllllllllIIIIIIIIIlIlIllII, lllllllllllllllIIIIIIIIIlIlIlIll, lllllllllllllllIIIIIIIIIlIlIlIlI, lllllllllllllllIIIIIIIIIlIlIlIIl, lllllllllllllllIIIIIIIIIlIlIIIII, lllllllllllllllIIIIIIIIIlIlIIlll, lllllllllllllllIIIIIIIIIlIIllllI);
    head.rotateAngleX = headRotationAngleX;
  }
  
  public void setLivingAnimations(EntityLivingBase lllllllllllllllIIIIIIIIIlIlllllI, float lllllllllllllllIIIIIIIIIlIllllIl, float lllllllllllllllIIIIIIIIIlIllIlll, float lllllllllllllllIIIIIIIIIlIllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIIIIIIIlIlllIlI.setLivingAnimations(lllllllllllllllIIIIIIIIIlIlllllI, lllllllllllllllIIIIIIIIIlIlllIII, lllllllllllllllIIIIIIIIIlIllIlll, lllllllllllllllIIIIIIIIIlIllIllI);
    head.rotationPointY = (6.0F + ((EntitySheep)lllllllllllllllIIIIIIIIIlIlllllI).getHeadRotationPointY(lllllllllllllllIIIIIIIIIlIllIllI) * 9.0F);
    headRotationAngleX = ((EntitySheep)lllllllllllllllIIIIIIIIIlIlllllI).getHeadRotationAngleX(lllllllllllllllIIIIIIIIIlIllIllI);
  }
  
  public ModelSheep1()
  {
    lllllllllllllllIIIIIIIIIllIIIllI.<init>(llIlIlIllIll[0], 0.0F);
    head = new ModelRenderer(lllllllllllllllIIIIIIIIIllIIlIII, llIlIlIllIll[1], llIlIlIllIll[1]);
    head.addBox(-3.0F, -4.0F, -4.0F, llIlIlIllIll[2], llIlIlIllIll[2], llIlIlIllIll[2], 0.6F);
    head.setRotationPoint(0.0F, 6.0F, -8.0F);
    body = new ModelRenderer(lllllllllllllllIIIIIIIIIllIIlIII, llIlIlIllIll[3], llIlIlIllIll[4]);
    body.addBox(-4.0F, -10.0F, -7.0F, llIlIlIllIll[4], llIlIlIllIll[5], llIlIlIllIll[2], 1.75F);
    body.setRotationPoint(0.0F, 5.0F, 2.0F);
    float lllllllllllllllIIIIIIIIIllIIIlll = 0.5F;
    leg1 = new ModelRenderer(lllllllllllllllIIIIIIIIIllIIlIII, llIlIlIllIll[1], llIlIlIllIll[5]);
    leg1.addBox(-2.0F, 0.0F, -2.0F, llIlIlIllIll[6], llIlIlIllIll[2], llIlIlIllIll[6], lllllllllllllllIIIIIIIIIllIIIlll);
    leg1.setRotationPoint(-3.0F, 12.0F, 7.0F);
    leg2 = new ModelRenderer(lllllllllllllllIIIIIIIIIllIIlIII, llIlIlIllIll[1], llIlIlIllIll[5]);
    leg2.addBox(-2.0F, 0.0F, -2.0F, llIlIlIllIll[6], llIlIlIllIll[2], llIlIlIllIll[6], lllllllllllllllIIIIIIIIIllIIIlll);
    leg2.setRotationPoint(3.0F, 12.0F, 7.0F);
    leg3 = new ModelRenderer(lllllllllllllllIIIIIIIIIllIIlIII, llIlIlIllIll[1], llIlIlIllIll[5]);
    leg3.addBox(-2.0F, 0.0F, -2.0F, llIlIlIllIll[6], llIlIlIllIll[2], llIlIlIllIll[6], lllllllllllllllIIIIIIIIIllIIIlll);
    leg3.setRotationPoint(-3.0F, 12.0F, -5.0F);
    leg4 = new ModelRenderer(lllllllllllllllIIIIIIIIIllIIlIII, llIlIlIllIll[1], llIlIlIllIll[5]);
    leg4.addBox(-2.0F, 0.0F, -2.0F, llIlIlIllIll[6], llIlIlIllIll[2], llIlIlIllIll[6], lllllllllllllllIIIIIIIIIllIIIlll);
    leg4.setRotationPoint(3.0F, 12.0F, -5.0F);
  }
}

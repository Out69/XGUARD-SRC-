package net.minecraft.client.model;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntitySkeleton;

public class ModelSkeleton
  extends ModelZombie
{
  private static void lIlIIIIlIlllIl()
  {
    llIlIIllIIlI = new int[8];
    llIlIIllIIlI[0] = ((0xB1 ^ 0x81) & (0xB8 ^ 0x88 ^ 0xFFFFFFFF));
    llIlIIllIIlI[1] = (0x6B ^ 0x73 ^ 0x24 ^ 0x7C);
    llIlIIllIIlI[2] = (0xD ^ 0x2D);
    llIlIIllIIlI[3] = (0x29 ^ 0x1);
    llIlIIllIIlI[4] = (62 + 76 - 102 + 108 ^ 62 + 124 - 166 + 108);
    llIlIIllIIlI[5] = "  ".length();
    llIlIIllIIlI[6] = (0xCC ^ 0xC0);
    llIlIIllIIlI[7] = " ".length();
  }
  
  public ModelSkeleton()
  {
    lllllllllllllllIIIIIllIllIIIlIll.<init>(0.0F, llIlIIllIIlI[0]);
  }
  
  private static boolean lIlIIIIlIlllll(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIIIIIllIlIlIlIllI;
    return ??? == i;
  }
  
  private static boolean lIlIIIIlIllllI(int ???)
  {
    char lllllllllllllllIIIIIllIlIlIlIlII;
    return ??? == 0;
  }
  
  public ModelSkeleton(float lllllllllllllllIIIIIllIllIIIIlIl, boolean lllllllllllllllIIIIIllIllIIIIlII)
  {
    lllllllllllllllIIIIIllIllIIIIllI.<init>(lllllllllllllllIIIIIllIllIIIIIlI, 0.0F, llIlIIllIIlI[1], llIlIIllIIlI[2]);
    if (lIlIIIIlIllllI(lllllllllllllllIIIIIllIllIIIIlII))
    {
      bipedRightArm = new ModelRenderer(lllllllllllllllIIIIIllIllIIIIllI, llIlIIllIIlI[3], llIlIIllIIlI[4]);
      bipedRightArm.addBox(-1.0F, -2.0F, -1.0F, llIlIIllIIlI[5], llIlIIllIIlI[6], llIlIIllIIlI[5], lllllllllllllllIIIIIllIllIIIIIlI);
      bipedRightArm.setRotationPoint(-5.0F, 2.0F, 0.0F);
      bipedLeftArm = new ModelRenderer(lllllllllllllllIIIIIllIllIIIIllI, llIlIIllIIlI[3], llIlIIllIIlI[4]);
      bipedLeftArm.mirror = llIlIIllIIlI[7];
      bipedLeftArm.addBox(-1.0F, -2.0F, -1.0F, llIlIIllIIlI[5], llIlIIllIIlI[6], llIlIIllIIlI[5], lllllllllllllllIIIIIllIllIIIIIlI);
      bipedLeftArm.setRotationPoint(5.0F, 2.0F, 0.0F);
      bipedRightLeg = new ModelRenderer(lllllllllllllllIIIIIllIllIIIIllI, llIlIIllIIlI[0], llIlIIllIIlI[4]);
      bipedRightLeg.addBox(-1.0F, 0.0F, -1.0F, llIlIIllIIlI[5], llIlIIllIIlI[6], llIlIIllIIlI[5], lllllllllllllllIIIIIllIllIIIIIlI);
      bipedRightLeg.setRotationPoint(-2.0F, 12.0F, 0.0F);
      bipedLeftLeg = new ModelRenderer(lllllllllllllllIIIIIllIllIIIIllI, llIlIIllIIlI[0], llIlIIllIIlI[4]);
      bipedLeftLeg.mirror = llIlIIllIIlI[7];
      bipedLeftLeg.addBox(-1.0F, 0.0F, -1.0F, llIlIIllIIlI[5], llIlIIllIIlI[6], llIlIIllIIlI[5], lllllllllllllllIIIIIllIllIIIIIlI);
      bipedLeftLeg.setRotationPoint(2.0F, 12.0F, 0.0F);
    }
  }
  
  static {}
  
  public void setLivingAnimations(EntityLivingBase lllllllllllllllIIIIIllIlIlllIlIl, float lllllllllllllllIIIIIllIlIlllIlII, float lllllllllllllllIIIIIllIlIllllIII, float lllllllllllllllIIIIIllIlIlllIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIlIIIIlIlllll(((EntitySkeleton)lllllllllllllllIIIIIllIlIlllIlIl).getSkeletonType(), llIlIIllIIlI[7]))
    {
      "".length();
      if (" ".length() == " ".length()) {
        break label51;
      }
    }
    label51:
    llIlIIllIIlI7aimedBow = llIlIIllIIlI[0];
    lllllllllllllllIIIIIllIlIlllIllI.setLivingAnimations(lllllllllllllllIIIIIllIlIlllIlIl, lllllllllllllllIIIIIllIlIllllIIl, lllllllllllllllIIIIIllIlIllllIII, lllllllllllllllIIIIIllIlIlllIIlI);
  }
  
  public void setRotationAngles(float lllllllllllllllIIIIIllIlIllIlIII, float lllllllllllllllIIIIIllIlIllIIlll, float lllllllllllllllIIIIIllIlIllIIllI, float lllllllllllllllIIIIIllIlIllIIlIl, float lllllllllllllllIIIIIllIlIllIIlII, float lllllllllllllllIIIIIllIlIlIllIll, Entity lllllllllllllllIIIIIllIlIllIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIIIllIlIllIlIIl.setRotationAngles(lllllllllllllllIIIIIllIlIllIlIII, lllllllllllllllIIIIIllIlIllIIlll, lllllllllllllllIIIIIllIlIllIIllI, lllllllllllllllIIIIIllIlIllIIlIl, lllllllllllllllIIIIIllIlIllIIlII, lllllllllllllllIIIIIllIlIlIllIll, lllllllllllllllIIIIIllIlIllIIIlI);
  }
}

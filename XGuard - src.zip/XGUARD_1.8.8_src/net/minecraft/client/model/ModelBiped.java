package net.minecraft.client.model;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;

public class ModelBiped
  extends ModelBase
{
  public void postRenderArm(float llllllllllllllIlllllIlllIIllIIIl)
  {
    ;
    ;
    bipedRightArm.postRender(llllllllllllllIlllllIlllIIllIIIl);
  }
  
  public ModelBiped()
  {
    llllllllllllllIlllllIllllIIlIIll.<init>(0.0F);
  }
  
  private static boolean lIlIIllIllIIII(int ???)
  {
    long llllllllllllllIlllllIlllIIlIlIll;
    return ??? > 0;
  }
  
  private static int lIlIIllIlIllll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static void lIlIIllIlIllIl()
  {
    llIllIlIIIII = new int[9];
    llIllIlIIIII[0] = (0xE2 ^ 0xA2);
    llIllIlIIIII[1] = (0x7A ^ 0x2E ^ 0xC5 ^ 0xB1);
    llIllIlIIIII[2] = ((0xEF ^ 0xC1 ^ 0xB5 ^ 0xC6) & (0x51 ^ 0x6F ^ 0x13 ^ 0x70 ^ -" ".length()));
    llIllIlIIIII[3] = (0xBF ^ 0xB7);
    llIllIlIIIII[4] = (0x1 ^ 0x11);
    llIllIlIIIII[5] = (0x6A ^ 0x66);
    llIllIlIIIII[6] = (0xD0 ^ 0x96 ^ 0xCF ^ 0x8D);
    llIllIlIIIII[7] = (61 + '¢' - 159 + 100 ^ 24 + '' - 74 + 52);
    llIllIlIIIII[8] = " ".length();
  }
  
  public void setRotationAngles(float llllllllllllllIlllllIlllIlIIlIll, float llllllllllllllIlllllIlllIlIlIlll, float llllllllllllllIlllllIlllIlIIlIIl, float llllllllllllllIlllllIlllIlIlIlIl, float llllllllllllllIlllllIlllIlIlIlII, float llllllllllllllIlllllIlllIlIlIIll, Entity llllllllllllllIlllllIlllIlIlIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    bipedHead.rotateAngleY = (llllllllllllllIlllllIlllIlIlIlIl / 57.295776F);
    bipedHead.rotateAngleX = (llllllllllllllIlllllIlllIlIlIlII / 57.295776F);
    bipedRightArm.rotateAngleX = (MathHelper.cos(llllllllllllllIlllllIlllIlIIlIll * 0.6662F + 3.1415927F) * 2.0F * llllllllllllllIlllllIlllIlIlIlll * 0.5F);
    bipedLeftArm.rotateAngleX = (MathHelper.cos(llllllllllllllIlllllIlllIlIIlIll * 0.6662F) * 2.0F * llllllllllllllIlllllIlllIlIlIlll * 0.5F);
    bipedRightArm.rotateAngleZ = 0.0F;
    bipedLeftArm.rotateAngleZ = 0.0F;
    bipedRightLeg.rotateAngleX = (MathHelper.cos(llllllllllllllIlllllIlllIlIIlIll * 0.6662F) * 1.4F * llllllllllllllIlllllIlllIlIlIlll);
    bipedLeftLeg.rotateAngleX = (MathHelper.cos(llllllllllllllIlllllIlllIlIIlIll * 0.6662F + 3.1415927F) * 1.4F * llllllllllllllIlllllIlllIlIlIlll);
    bipedRightLeg.rotateAngleY = 0.0F;
    bipedLeftLeg.rotateAngleY = 0.0F;
    if (lIlIIllIlIlllI(isRiding))
    {
      bipedRightArm.rotateAngleX += -0.62831855F;
      bipedLeftArm.rotateAngleX += -0.62831855F;
      bipedRightLeg.rotateAngleX = -1.2566371F;
      bipedLeftLeg.rotateAngleX = -1.2566371F;
      bipedRightLeg.rotateAngleY = 0.31415927F;
      bipedLeftLeg.rotateAngleY = -0.31415927F;
    }
    if (lIlIIllIlIlllI(heldItemLeft)) {
      bipedLeftArm.rotateAngleX = (bipedLeftArm.rotateAngleX * 0.5F - 0.31415927F * heldItemLeft);
    }
    bipedRightArm.rotateAngleY = 0.0F;
    bipedRightArm.rotateAngleZ = 0.0F;
    switch (heldItemRight)
    {
    case 0: 
    case 2: 
    default: 
      "".length();
      if ((0xB1 ^ 0xB5) != (0xC5 ^ 0xC1)) {
        return;
      }
      break;
    case 1: 
      bipedRightArm.rotateAngleX = (bipedRightArm.rotateAngleX * 0.5F - 0.31415927F * heldItemRight);
      "".length();
      if ("   ".length() == 0) {
        return;
      }
      break;
    case 3: 
      bipedRightArm.rotateAngleX = (bipedRightArm.rotateAngleX * 0.5F - 0.31415927F * heldItemRight);
      bipedRightArm.rotateAngleY = -0.5235988F;
    }
    bipedLeftArm.rotateAngleY = 0.0F;
    if (lIlIIllIllIIII(lIlIIllIlIllll(swingProgress, -9990.0F)))
    {
      float llllllllllllllIlllllIlllIlIlIIIl = swingProgress;
      bipedBody.rotateAngleY = (MathHelper.sin(MathHelper.sqrt_float(llllllllllllllIlllllIlllIlIlIIIl) * 3.1415927F * 2.0F) * 0.2F);
      bipedRightArm.rotationPointZ = (MathHelper.sin(bipedBody.rotateAngleY) * 5.0F);
      bipedRightArm.rotationPointX = (-MathHelper.cos(bipedBody.rotateAngleY) * 5.0F);
      bipedLeftArm.rotationPointZ = (-MathHelper.sin(bipedBody.rotateAngleY) * 5.0F);
      bipedLeftArm.rotationPointX = (MathHelper.cos(bipedBody.rotateAngleY) * 5.0F);
      bipedRightArm.rotateAngleY += bipedBody.rotateAngleY;
      bipedLeftArm.rotateAngleY += bipedBody.rotateAngleY;
      bipedLeftArm.rotateAngleX += bipedBody.rotateAngleY;
      llllllllllllllIlllllIlllIlIlIIIl = 1.0F - swingProgress;
      llllllllllllllIlllllIlllIlIlIIIl *= llllllllllllllIlllllIlllIlIlIIIl;
      llllllllllllllIlllllIlllIlIlIIIl *= llllllllllllllIlllllIlllIlIlIIIl;
      llllllllllllllIlllllIlllIlIlIIIl = 1.0F - llllllllllllllIlllllIlllIlIlIIIl;
      float llllllllllllllIlllllIlllIlIlIIII = MathHelper.sin(llllllllllllllIlllllIlllIlIlIIIl * 3.1415927F);
      float llllllllllllllIlllllIlllIlIIllll = MathHelper.sin(swingProgress * 3.1415927F) * -(bipedHead.rotateAngleX - 0.7F) * 0.75F;
      bipedRightArm.rotateAngleX = ((float)(bipedRightArm.rotateAngleX - (llllllllllllllIlllllIlllIlIlIIII * 1.2D + llllllllllllllIlllllIlllIlIIllll)));
      bipedRightArm.rotateAngleY += bipedBody.rotateAngleY * 2.0F;
      bipedRightArm.rotateAngleZ += MathHelper.sin(swingProgress * 3.1415927F) * -0.4F;
    }
    if (lIlIIllIlIlllI(isSneak))
    {
      bipedBody.rotateAngleX = 0.5F;
      bipedRightArm.rotateAngleX += 0.4F;
      bipedLeftArm.rotateAngleX += 0.4F;
      bipedRightLeg.rotationPointZ = 4.0F;
      bipedLeftLeg.rotationPointZ = 4.0F;
      bipedRightLeg.rotationPointY = 9.0F;
      bipedLeftLeg.rotationPointY = 9.0F;
      bipedHead.rotationPointY = 1.0F;
      "".length();
      if (null == null) {}
    }
    else
    {
      bipedBody.rotateAngleX = 0.0F;
      bipedRightLeg.rotationPointZ = 0.1F;
      bipedLeftLeg.rotationPointZ = 0.1F;
      bipedRightLeg.rotationPointY = 12.0F;
      bipedLeftLeg.rotationPointY = 12.0F;
      bipedHead.rotationPointY = 0.0F;
    }
    bipedRightArm.rotateAngleZ += MathHelper.cos(llllllllllllllIlllllIlllIlIIlIIl * 0.09F) * 0.05F + 0.05F;
    bipedLeftArm.rotateAngleZ -= MathHelper.cos(llllllllllllllIlllllIlllIlIIlIIl * 0.09F) * 0.05F + 0.05F;
    bipedRightArm.rotateAngleX += MathHelper.sin(llllllllllllllIlllllIlllIlIIlIIl * 0.067F) * 0.05F;
    bipedLeftArm.rotateAngleX -= MathHelper.sin(llllllllllllllIlllllIlllIlIIlIIl * 0.067F) * 0.05F;
    if (lIlIIllIlIlllI(aimedBow))
    {
      float llllllllllllllIlllllIlllIlIIlllI = 0.0F;
      float llllllllllllllIlllllIlllIlIIllIl = 0.0F;
      bipedRightArm.rotateAngleZ = 0.0F;
      bipedLeftArm.rotateAngleZ = 0.0F;
      bipedRightArm.rotateAngleY = (-(0.1F - llllllllllllllIlllllIlllIlIIlllI * 0.6F) + bipedHead.rotateAngleY);
      bipedLeftArm.rotateAngleY = (0.1F - llllllllllllllIlllllIlllIlIIlllI * 0.6F + bipedHead.rotateAngleY + 0.4F);
      bipedRightArm.rotateAngleX = (-1.5707964F + bipedHead.rotateAngleX);
      bipedLeftArm.rotateAngleX = (-1.5707964F + bipedHead.rotateAngleX);
      bipedRightArm.rotateAngleX -= llllllllllllllIlllllIlllIlIIlllI * 1.2F - llllllllllllllIlllllIlllIlIIllIl * 0.4F;
      bipedLeftArm.rotateAngleX -= llllllllllllllIlllllIlllIlIIlllI * 1.2F - llllllllllllllIlllllIlllIlIIllIl * 0.4F;
      bipedRightArm.rotateAngleZ += MathHelper.cos(llllllllllllllIlllllIlllIlIIlIIl * 0.09F) * 0.05F + 0.05F;
      bipedLeftArm.rotateAngleZ -= MathHelper.cos(llllllllllllllIlllllIlllIlIIlIIl * 0.09F) * 0.05F + 0.05F;
      bipedRightArm.rotateAngleX += MathHelper.sin(llllllllllllllIlllllIlllIlIIlIIl * 0.067F) * 0.05F;
      bipedLeftArm.rotateAngleX -= MathHelper.sin(llllllllllllllIlllllIlllIlIIlIIl * 0.067F) * 0.05F;
    }
    copyModelAngles(bipedHead, bipedHeadwear);
  }
  
  public void render(Entity llllllllllllllIlllllIlllIllIlIlI, float llllllllllllllIlllllIlllIllIlIIl, float llllllllllllllIlllllIlllIlllIIIl, float llllllllllllllIlllllIlllIllIIlll, float llllllllllllllIlllllIlllIllIIllI, float llllllllllllllIlllllIlllIllIIlIl, float llllllllllllllIlllllIlllIllIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlllllIlllIllIlIll.setRotationAngles(llllllllllllllIlllllIlllIllIlIIl, llllllllllllllIlllllIlllIlllIIIl, llllllllllllllIlllllIlllIllIIlll, llllllllllllllIlllllIlllIllIIllI, llllllllllllllIlllllIlllIllIIlIl, llllllllllllllIlllllIlllIllIllIl, llllllllllllllIlllllIlllIllIlIlI);
    GlStateManager.pushMatrix();
    if (lIlIIllIlIlllI(isChild))
    {
      float llllllllllllllIlllllIlllIllIllII = 2.0F;
      GlStateManager.scale(1.5F / llllllllllllllIlllllIlllIllIllII, 1.5F / llllllllllllllIlllllIlllIllIllII, 1.5F / llllllllllllllIlllllIlllIllIllII);
      GlStateManager.translate(0.0F, 16.0F * llllllllllllllIlllllIlllIllIllIl, 0.0F);
      bipedHead.render(llllllllllllllIlllllIlllIllIllIl);
      GlStateManager.popMatrix();
      GlStateManager.pushMatrix();
      GlStateManager.scale(1.0F / llllllllllllllIlllllIlllIllIllII, 1.0F / llllllllllllllIlllllIlllIllIllII, 1.0F / llllllllllllllIlllllIlllIllIllII);
      GlStateManager.translate(0.0F, 24.0F * llllllllllllllIlllllIlllIllIllIl, 0.0F);
      bipedBody.render(llllllllllllllIlllllIlllIllIllIl);
      bipedRightArm.render(llllllllllllllIlllllIlllIllIllIl);
      bipedLeftArm.render(llllllllllllllIlllllIlllIllIllIl);
      bipedRightLeg.render(llllllllllllllIlllllIlllIllIllIl);
      bipedLeftLeg.render(llllllllllllllIlllllIlllIllIllIl);
      bipedHeadwear.render(llllllllllllllIlllllIlllIllIllIl);
      "".length();
      if ((89 + 108 - 4 + 1 ^ '¹' + 103 - 285 + 195) >= -" ".length()) {}
    }
    else
    {
      if (lIlIIllIlIlllI(llllllllllllllIlllllIlllIllIlIlI.isSneaking())) {
        GlStateManager.translate(0.0F, 0.2F, 0.0F);
      }
      bipedHead.render(llllllllllllllIlllllIlllIllIllIl);
      bipedBody.render(llllllllllllllIlllllIlllIllIllIl);
      bipedRightArm.render(llllllllllllllIlllllIlllIllIllIl);
      bipedLeftArm.render(llllllllllllllIlllllIlllIllIllIl);
      bipedRightLeg.render(llllllllllllllIlllllIlllIllIllIl);
      bipedLeftLeg.render(llllllllllllllIlllllIlllIllIllIl);
      bipedHeadwear.render(llllllllllllllIlllllIlllIllIllIl);
    }
    GlStateManager.popMatrix();
  }
  
  public void setInvisible(boolean llllllllllllllIlllllIlllIIllIlIl)
  {
    ;
    ;
    bipedHead.showModel = llllllllllllllIlllllIlllIIllIlIl;
    bipedHeadwear.showModel = llllllllllllllIlllllIlllIIllIlIl;
    bipedRightArm.showModel = llllllllllllllIlllllIlllIIllIlIl;
    bipedLeftArm.showModel = llllllllllllllIlllllIlllIIllIlIl;
    bipedRightLeg.showModel = llllllllllllllIlllllIlllIIllIlIl;
    bipedLeftLeg.showModel = llllllllllllllIlllllIlllIIllIlIl;
  }
  
  static {}
  
  public ModelBiped(float llllllllllllllIlllllIllllIIIllll)
  {
    llllllllllllllIlllllIllllIIIlllI.<init>(llllllllllllllIlllllIllllIIIllll, 0.0F, llIllIlIIIII[0], llIllIlIIIII[1]);
  }
  
  private static boolean lIlIIllIlIlllI(int ???)
  {
    double llllllllllllllIlllllIlllIIlIllIl;
    return ??? != 0;
  }
  
  public void setModelAttributes(ModelBase llllllllllllllIlllllIlllIIllllll)
  {
    ;
    ;
    ;
    llllllllllllllIlllllIlllIIllllIl.setModelAttributes(llllllllllllllIlllllIlllIIllllll);
    if (lIlIIllIlIlllI(llllllllllllllIlllllIlllIIllllll instanceof ModelBiped))
    {
      ModelBiped llllllllllllllIlllllIlllIIlllllI = (ModelBiped)llllllllllllllIlllllIlllIIllllll;
      heldItemLeft = heldItemLeft;
      heldItemRight = heldItemRight;
      isSneak = isSneak;
      aimedBow = aimedBow;
    }
  }
  
  public ModelBiped(float llllllllllllllIlllllIllllIIIIIIl, float llllllllllllllIlllllIllllIIIIlIl, int llllllllllllllIlllllIlllIlllllll, int llllllllllllllIlllllIllllIIIIIll)
  {
    textureWidth = llllllllllllllIlllllIlllIlllllll;
    textureHeight = llllllllllllllIlllllIllllIIIIIll;
    bipedHead = new ModelRenderer(llllllllllllllIlllllIllllIIIIIlI, llIllIlIIIII[2], llIllIlIIIII[2]);
    bipedHead.addBox(-4.0F, -8.0F, -4.0F, llIllIlIIIII[3], llIllIlIIIII[3], llIllIlIIIII[3], llllllllllllllIlllllIllllIIIIIIl);
    bipedHead.setRotationPoint(0.0F, 0.0F + llllllllllllllIlllllIllllIIIIIII, 0.0F);
    bipedHeadwear = new ModelRenderer(llllllllllllllIlllllIllllIIIIIlI, llIllIlIIIII[1], llIllIlIIIII[2]);
    bipedHeadwear.addBox(-4.0F, -8.0F, -4.0F, llIllIlIIIII[3], llIllIlIIIII[3], llIllIlIIIII[3], llllllllllllllIlllllIllllIIIIIIl + 0.5F);
    bipedHeadwear.setRotationPoint(0.0F, 0.0F + llllllllllllllIlllllIllllIIIIIII, 0.0F);
    bipedBody = new ModelRenderer(llllllllllllllIlllllIllllIIIIIlI, llIllIlIIIII[4], llIllIlIIIII[4]);
    bipedBody.addBox(-4.0F, 0.0F, -2.0F, llIllIlIIIII[3], llIllIlIIIII[5], llIllIlIIIII[6], llllllllllllllIlllllIllllIIIIIIl);
    bipedBody.setRotationPoint(0.0F, 0.0F + llllllllllllllIlllllIllllIIIIIII, 0.0F);
    bipedRightArm = new ModelRenderer(llllllllllllllIlllllIllllIIIIIlI, llIllIlIIIII[7], llIllIlIIIII[4]);
    bipedRightArm.addBox(-3.0F, -2.0F, -2.0F, llIllIlIIIII[6], llIllIlIIIII[5], llIllIlIIIII[6], llllllllllllllIlllllIllllIIIIIIl);
    bipedRightArm.setRotationPoint(-5.0F, 2.0F + llllllllllllllIlllllIllllIIIIIII, 0.0F);
    bipedLeftArm = new ModelRenderer(llllllllllllllIlllllIllllIIIIIlI, llIllIlIIIII[7], llIllIlIIIII[4]);
    bipedLeftArm.mirror = llIllIlIIIII[8];
    bipedLeftArm.addBox(-1.0F, -2.0F, -2.0F, llIllIlIIIII[6], llIllIlIIIII[5], llIllIlIIIII[6], llllllllllllllIlllllIllllIIIIIIl);
    bipedLeftArm.setRotationPoint(5.0F, 2.0F + llllllllllllllIlllllIllllIIIIIII, 0.0F);
    bipedRightLeg = new ModelRenderer(llllllllllllllIlllllIllllIIIIIlI, llIllIlIIIII[2], llIllIlIIIII[4]);
    bipedRightLeg.addBox(-2.0F, 0.0F, -2.0F, llIllIlIIIII[6], llIllIlIIIII[5], llIllIlIIIII[6], llllllllllllllIlllllIllllIIIIIIl);
    bipedRightLeg.setRotationPoint(-1.9F, 12.0F + llllllllllllllIlllllIllllIIIIIII, 0.0F);
    bipedLeftLeg = new ModelRenderer(llllllllllllllIlllllIllllIIIIIlI, llIllIlIIIII[2], llIllIlIIIII[4]);
    bipedLeftLeg.mirror = llIllIlIIIII[8];
    bipedLeftLeg.addBox(-2.0F, 0.0F, -2.0F, llIllIlIIIII[6], llIllIlIIIII[5], llIllIlIIIII[6], llllllllllllllIlllllIllllIIIIIIl);
    bipedLeftLeg.setRotationPoint(1.9F, 12.0F + llllllllllllllIlllllIllllIIIIIII, 0.0F);
  }
}

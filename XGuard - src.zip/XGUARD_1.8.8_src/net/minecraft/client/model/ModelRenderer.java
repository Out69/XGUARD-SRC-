package net.minecraft.client.model;

import com.google.common.collect.Lists;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import optfine.ModelSprite;
import org.lwjgl.opengl.GL11;

public class ModelRenderer
{
  private static void llIIllllIIII()
  {
    lIIIIIlIllI = new int[4];
    lIIIIIlIllI[0] = ((0x35 ^ 0x3D) & (0xA4 ^ 0xAC ^ 0xFFFFFFFF));
    lIIIIIlIllI[1] = " ".length();
    lIIIIIlIllI[2] = (-(0xEAFB & 0x7DF6) & 0xFBF7 & 0x7FF9);
    lIIIIIlIllI[3] = "  ".length();
  }
  
  public ModelRenderer(ModelBase lllllllllllllllllIlllllIIIIllIll, String lllllllllllllllllIlllllIIIIllIlI)
  {
    baseModel = lllllllllllllllllIlllllIIIIllllI;
    "".length();
    boxName = lllllllllllllllllIlllllIIIIllIlI;
    "".length();
  }
  
  private void compileDisplayList(float lllllllllllllllllIllllIlIllIllll)
  {
    ;
    ;
    ;
    ;
    ;
    displayList = GLAllocation.generateDisplayLists(lIIIIIlIllI[1]);
    GL11.glNewList(displayList, lIIIIIlIllI[2]);
    WorldRenderer lllllllllllllllllIllllIlIllIlllI = Tessellator.getInstance().getWorldRenderer();
    int lllllllllllllllllIllllIlIllIllIl = lIIIIIlIllI[0];
    "".length();
    if ((0x27 ^ 0x23) <= ((0x42 ^ 0x4A) & (0x74 ^ 0x7C ^ 0xFFFFFFFF))) {
      return;
    }
    while (!llIIllllIllI(lllllllllllllllllIllllIlIllIllIl, cubeList.size()))
    {
      ((ModelBox)cubeList.get(lllllllllllllllllIllllIlIllIllIl)).render(lllllllllllllllllIllllIlIllIlllI, lllllllllllllllllIllllIlIllIllll);
      lllllllllllllllllIllllIlIllIllIl++;
    }
    int lllllllllllllllllIllllIlIllIllII = lIIIIIlIllI[0];
    "".length();
    if ((0x48 ^ 0x44 ^ 0x9D ^ 0x94) <= 0) {
      return;
    }
    while (!llIIllllIllI(lllllllllllllllllIllllIlIllIllII, spriteList.size()))
    {
      ModelSprite lllllllllllllllllIllllIlIllIlIll = (ModelSprite)spriteList.get(lllllllllllllllllIllllIlIllIllII);
      lllllllllllllllllIllllIlIllIlIll.render(Tessellator.getInstance(), lllllllllllllllllIllllIlIllIllll);
      lllllllllllllllllIllllIlIllIllII++;
    }
    GL11.glEndList();
    compiled = lIIIIIlIllI[1];
  }
  
  public void addChild(ModelRenderer lllllllllllllllllIlllllIIIIIIlII)
  {
    ;
    ;
    if (llIIllllIIIl(childModels)) {
      childModels = Lists.newArrayList();
    }
    "".length();
  }
  
  private static boolean llIIllllIIll(int ???)
  {
    float lllllllllllllllllIllllIlIIIlIIII;
    return ??? == 0;
  }
  
  private static int llIIlllllIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public ModelRenderer addBox(float lllllllllllllllllIllllIllIllllll, float lllllllllllllllllIllllIllIllIllI, float lllllllllllllllllIllllIllIllIlIl, int lllllllllllllllllIllllIllIllIlII, int lllllllllllllllllIllllIllIlllIll, int lllllllllllllllllIllllIllIllIIlI, boolean lllllllllllllllllIllllIllIlllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    new ModelBox(lllllllllllllllllIllllIllIlllIII, textureOffsetX, textureOffsetY, lllllllllllllllllIllllIllIllllll, lllllllllllllllllIllllIllIllIllI, lllllllllllllllllIllllIllIllIlIl, lllllllllllllllllIllllIllIllIlII, lllllllllllllllllIllllIllIlllIll, lllllllllllllllllIllllIllIllIIlI, 0.0F, lllllllllllllllllIllllIllIlllIIl);
    "".length();
    return lllllllllllllllllIllllIllIlllIII;
  }
  
  public ModelRenderer setTextureSize(int lllllllllllllllllIllllIlIllIIIIl, int lllllllllllllllllIllllIlIllIIIII)
  {
    ;
    ;
    ;
    textureWidth = lllllllllllllllllIllllIlIlIllllI;
    textureHeight = lllllllllllllllllIllllIlIllIIIII;
    return lllllllllllllllllIllllIlIlIlllll;
  }
  
  public ModelRenderer addBox(String lllllllllllllllllIllllIllllIIlIl, float lllllllllllllllllIllllIllllIIlII, float lllllllllllllllllIllllIllllIIIll, float lllllllllllllllllIllllIllllIIIlI, int lllllllllllllllllIllllIllllIIIIl, int lllllllllllllllllIllllIllllIlIIl, int lllllllllllllllllIllllIlllIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIllllIllllIIlIl = String.valueOf(new StringBuilder(String.valueOf(boxName)).append(lIIIIIlIlIl[lIIIIIlIllI[0]]).append(lllllllllllllllllIllllIllllIIlIl));
    TextureOffset lllllllllllllllllIllllIllllIIlll = baseModel.getTextureOffset(lllllllllllllllllIllllIllllIIlIl);
    "".length();
    new ModelBox(lllllllllllllllllIllllIllllIIllI, textureOffsetX, textureOffsetY, lllllllllllllllllIllllIllllIIlII, lllllllllllllllllIllllIllllIIIll, lllllllllllllllllIllllIllllIIIlI, lllllllllllllllllIllllIllllIIIIl, lllllllllllllllllIllllIllllIlIIl, lllllllllllllllllIllllIlllIlllll, 0.0F);
    "".length();
    return lllllllllllllllllIllllIllllIIllI;
  }
  
  private static int llIIllllIIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void addBox(float lllllllllllllllllIllllIllIlIIlll, float lllllllllllllllllIllllIllIlIIllI, float lllllllllllllllllIllllIllIlIIlIl, int lllllllllllllllllIllllIllIIlllII, int lllllllllllllllllIllllIllIIllIll, int lllllllllllllllllIllllIllIlIIIlI, float lllllllllllllllllIllllIllIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    new ModelBox(lllllllllllllllllIllllIllIlIIIII, textureOffsetX, textureOffsetY, lllllllllllllllllIllllIllIlIIlll, lllllllllllllllllIllllIllIlIIllI, lllllllllllllllllIllllIllIlIIlIl, lllllllllllllllllIllllIllIIlllII, lllllllllllllllllIllllIllIIllIll, lllllllllllllllllIllllIllIlIIIlI, lllllllllllllllllIllllIllIlIIIIl);
    "".length();
  }
  
  private static boolean llIIllllIlII(int ???)
  {
    String lllllllllllllllllIllllIlIIIlIIlI;
    return ??? != 0;
  }
  
  private static String llIIlllIllII(String lllllllllllllllllIllllIlIIlllIll, String lllllllllllllllllIllllIlIIlllIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIllllIlIlIIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIllllIlIIlllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIllllIlIIllllll = Cipher.getInstance("Blowfish");
      lllllllllllllllllIllllIlIIllllll.init(lIIIIIlIllI[3], lllllllllllllllllIllllIlIlIIIIII);
      return new String(lllllllllllllllllIllllIlIIllllll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIllllIlIIlllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIllllIlIIlllllI)
    {
      lllllllllllllllllIllllIlIIlllllI.printStackTrace();
    }
    return null;
  }
  
  public ModelRenderer setTextureOffset(int lllllllllllllllllIllllIllllllIlI, int lllllllllllllllllIllllIlllllllII)
  {
    ;
    ;
    ;
    textureOffsetX = lllllllllllllllllIllllIlllllllIl;
    textureOffsetY = lllllllllllllllllIllllIlllllllII;
    return lllllllllllllllllIllllIllllllIll;
  }
  
  private static boolean llIIllllIIIl(Object ???)
  {
    int lllllllllllllllllIllllIlIIIlIlII;
    return ??? == null;
  }
  
  private static boolean llIIllllIllI(int ???, int arg1)
  {
    int i;
    char lllllllllllllllllIllllIlIIIlllII;
    return ??? >= i;
  }
  
  private static int llIIllllIlll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llIIlllllIIl(int ???, int arg1)
  {
    int i;
    char lllllllllllllllllIllllIlIIIllIII;
    return ??? < i;
  }
  
  public ModelRenderer addBox(float lllllllllllllllllIllllIlllIlIlIl, float lllllllllllllllllIllllIlllIlIlII, float lllllllllllllllllIllllIlllIIllII, int lllllllllllllllllIllllIlllIIlIll, int lllllllllllllllllIllllIlllIlIIIl, int lllllllllllllllllIllllIlllIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    new ModelBox(lllllllllllllllllIllllIlllIIllll, textureOffsetX, textureOffsetY, lllllllllllllllllIllllIlllIlIlIl, lllllllllllllllllIllllIlllIlIlII, lllllllllllllllllIllllIlllIlIIll, lllllllllllllllllIllllIlllIIlIll, lllllllllllllllllIllllIlllIlIIIl, lllllllllllllllllIllllIlllIIlIIl, 0.0F);
    "".length();
    return lllllllllllllllllIllllIlllIIllll;
  }
  
  public void addSprite(float lllllllllllllllllIllllIlIlIIlIll, float lllllllllllllllllIllllIlIlIlIIlI, float lllllllllllllllllIllllIlIlIlIIIl, int lllllllllllllllllIllllIlIlIlIIII, int lllllllllllllllllIllllIlIlIIllll, int lllllllllllllllllIllllIlIlIIIllI, float lllllllllllllllllIllllIlIlIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    new ModelSprite(lllllllllllllllllIllllIlIlIIllII, textureOffsetX, textureOffsetY, lllllllllllllllllIllllIlIlIIlIll, lllllllllllllllllIllllIlIlIlIIlI, lllllllllllllllllIllllIlIlIlIIIl, lllllllllllllllllIllllIlIlIlIIII, lllllllllllllllllIllllIlIlIIllll, lllllllllllllllllIllllIlIlIIIllI, lllllllllllllllllIllllIlIlIIllIl);
    "".length();
  }
  
  private static boolean llIIllllIlIl(Object ???)
  {
    boolean lllllllllllllllllIllllIlIIIlIllI;
    return ??? != null;
  }
  
  private static void llIIlllIlllI()
  {
    lIIIIIlIlIl = new String[lIIIIIlIllI[3]];
    lIIIIIlIlIl[lIIIIIlIllI[0]] = llIIlllIllII("EiVMNfl/zJw=", "CZMuC");
    lIIIIIlIlIl[lIIIIIlIllI[1]] = llIIlllIllIl("BR0IY2Z2YWdrYXI=", "FQWSV");
  }
  
  public ModelRenderer(ModelBase lllllllllllllllllIlllllIIIIlIllI)
  {
    lllllllllllllllllIlllllIIIIlIlIl.<init>(lllllllllllllllllIlllllIIIIlIllI, null);
  }
  
  public void setRotationPoint(float lllllllllllllllllIllllIllIIIllll, float lllllllllllllllllIllllIllIIIlllI, float lllllllllllllllllIllllIllIIlIIIl)
  {
    ;
    ;
    ;
    ;
    rotationPointX = lllllllllllllllllIllllIllIIIllll;
    rotationPointY = lllllllllllllllllIllllIllIIIlllI;
    rotationPointZ = lllllllllllllllllIllllIllIIlIIIl;
  }
  
  static
  {
    llIIllllIIII();
    llIIlllIlllI();
  }
  
  public void renderWithRotation(float lllllllllllllllllIllllIlIllllllI)
  {
    ;
    ;
    if ((llIIllllIIll(isHidden)) && (llIIllllIlII(showModel)))
    {
      if (llIIllllIIll(compiled)) {
        lllllllllllllllllIllllIlIlllllIl.compileDisplayList(lllllllllllllllllIllllIlIllllllI);
      }
      GlStateManager.pushMatrix();
      GlStateManager.translate(rotationPointX * lllllllllllllllllIllllIlIllllllI, rotationPointY * lllllllllllllllllIllllIlIllllllI, rotationPointZ * lllllllllllllllllIllllIlIllllllI);
      if (llIIllllIlII(llIIllllIlll(rotateAngleY, 0.0F))) {
        GlStateManager.rotate(rotateAngleY * 57.295776F, 0.0F, 1.0F, 0.0F);
      }
      if (llIIllllIlII(llIIllllIlll(rotateAngleX, 0.0F))) {
        GlStateManager.rotate(rotateAngleX * 57.295776F, 1.0F, 0.0F, 0.0F);
      }
      if (llIIllllIlII(llIIllllIlll(rotateAngleZ, 0.0F))) {
        GlStateManager.rotate(rotateAngleZ * 57.295776F, 0.0F, 0.0F, 1.0F);
      }
      GlStateManager.callList(displayList);
      GlStateManager.popMatrix();
    }
  }
  
  public void render(float lllllllllllllllllIllllIllIIIIIll)
  {
    ;
    ;
    ;
    if ((llIIllllIIll(isHidden)) && (llIIllllIlII(showModel)))
    {
      if (llIIllllIIll(compiled)) {
        lllllllllllllllllIllllIllIIIlIIl.compileDisplayList(lllllllllllllllllIllllIllIIIIIll);
      }
      GlStateManager.translate(offsetX, offsetY, offsetZ);
      if ((llIIllllIIll(llIIllllIIlI(rotateAngleX, 0.0F))) && (llIIllllIIll(llIIllllIIlI(rotateAngleY, 0.0F))) && (llIIllllIIll(llIIllllIIlI(rotateAngleZ, 0.0F))))
      {
        if ((llIIllllIIll(llIIllllIIlI(rotationPointX, 0.0F))) && (llIIllllIIll(llIIllllIIlI(rotationPointY, 0.0F))) && (llIIllllIIll(llIIllllIIlI(rotationPointZ, 0.0F))))
        {
          GlStateManager.callList(displayList);
          if (llIIllllIlIl(childModels))
          {
            int lllllllllllllllllIllllIllIIIIlll = lIIIIIlIllI[0];
            "".length();
            if ("  ".length() == (51 + 39 - -51 + 14 ^ 52 + 6 - 37 + 138)) {
              return;
            }
            while (!llIIllllIllI(lllllllllllllllllIllllIllIIIIlll, childModels.size()))
            {
              ((ModelRenderer)childModels.get(lllllllllllllllllIllllIllIIIIlll)).render(lllllllllllllllllIllllIllIIIIIll);
              lllllllllllllllllIllllIllIIIIlll++;
            }
            "".length();
            if (((0x64 ^ 0x73) & (0x68 ^ 0x7F ^ 0xFFFFFFFF)) == 0) {}
          }
        }
        else
        {
          GlStateManager.translate(rotationPointX * lllllllllllllllllIllllIllIIIIIll, rotationPointY * lllllllllllllllllIllllIllIIIIIll, rotationPointZ * lllllllllllllllllIllllIllIIIIIll);
          GlStateManager.callList(displayList);
          if (llIIllllIlIl(childModels))
          {
            int lllllllllllllllllIllllIllIIIIllI = lIIIIIlIllI[0];
            "".length();
            if (-" ".length() >= "  ".length()) {
              return;
            }
            while (!llIIllllIllI(lllllllllllllllllIllllIllIIIIllI, childModels.size()))
            {
              ((ModelRenderer)childModels.get(lllllllllllllllllIllllIllIIIIllI)).render(lllllllllllllllllIllllIllIIIIIll);
              lllllllllllllllllIllllIllIIIIllI++;
            }
          }
          GlStateManager.translate(-rotationPointX * lllllllllllllllllIllllIllIIIIIll, -rotationPointY * lllllllllllllllllIllllIllIIIIIll, -rotationPointZ * lllllllllllllllllIllllIllIIIIIll);
          "".length();
          if ((0x26 ^ 0x1 ^ 0x1A ^ 0x39) >= (0x3F ^ 0x1 ^ 0xBA ^ 0x80)) {}
        }
      }
      else
      {
        GlStateManager.pushMatrix();
        GlStateManager.translate(rotationPointX * lllllllllllllllllIllllIllIIIIIll, rotationPointY * lllllllllllllllllIllllIllIIIIIll, rotationPointZ * lllllllllllllllllIllllIllIIIIIll);
        if (llIIllllIlII(llIIllllIIlI(rotateAngleZ, 0.0F))) {
          GlStateManager.rotate(rotateAngleZ * 57.295776F, 0.0F, 0.0F, 1.0F);
        }
        if (llIIllllIlII(llIIllllIIlI(rotateAngleY, 0.0F))) {
          GlStateManager.rotate(rotateAngleY * 57.295776F, 0.0F, 1.0F, 0.0F);
        }
        if (llIIllllIlII(llIIllllIIlI(rotateAngleX, 0.0F))) {
          GlStateManager.rotate(rotateAngleX * 57.295776F, 1.0F, 0.0F, 0.0F);
        }
        GlStateManager.callList(displayList);
        if (llIIllllIlIl(childModels))
        {
          int lllllllllllllllllIllllIllIIIIlIl = lIIIIIlIllI[0];
          "".length();
          if (-" ".length() != -" ".length()) {
            return;
          }
          while (!llIIllllIllI(lllllllllllllllllIllllIllIIIIlIl, childModels.size()))
          {
            ((ModelRenderer)childModels.get(lllllllllllllllllIllllIllIIIIlIl)).render(lllllllllllllllllIllllIllIIIIIll);
            lllllllllllllllllIllllIllIIIIlIl++;
          }
        }
        GlStateManager.popMatrix();
      }
      GlStateManager.translate(-offsetX, -offsetY, -offsetZ);
    }
  }
  
  private static String llIIlllIllIl(String lllllllllllllllllIllllIlIIlIlIII, String lllllllllllllllllIllllIlIIlIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIllllIlIIlIlIII = new String(Base64.getDecoder().decode(lllllllllllllllllIllllIlIIlIlIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIllllIlIIlIlIll = new StringBuilder();
    char[] lllllllllllllllllIllllIlIIlIlIlI = lllllllllllllllllIllllIlIIlIllII.toCharArray();
    int lllllllllllllllllIllllIlIIlIlIIl = lIIIIIlIllI[0];
    byte lllllllllllllllllIllllIlIIlIIIll = lllllllllllllllllIllllIlIIlIlIII.toCharArray();
    long lllllllllllllllllIllllIlIIlIIIlI = lllllllllllllllllIllllIlIIlIIIll.length;
    long lllllllllllllllllIllllIlIIlIIIIl = lIIIIIlIllI[0];
    while (llIIlllllIIl(lllllllllllllllllIllllIlIIlIIIIl, lllllllllllllllllIllllIlIIlIIIlI))
    {
      char lllllllllllllllllIllllIlIIlIlllI = lllllllllllllllllIllllIlIIlIIIll[lllllllllllllllllIllllIlIIlIIIIl];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIllllIlIIlIlIll);
  }
  
  public ModelRenderer(ModelBase lllllllllllllllllIlllllIIIIIlllI, int lllllllllllllllllIlllllIIIIIllIl, int lllllllllllllllllIlllllIIIIIllII)
  {
    lllllllllllllllllIlllllIIIIIllll.<init>(lllllllllllllllllIlllllIIIIIlllI);
    "".length();
  }
  
  public void postRender(float lllllllllllllllllIllllIlIlllIllI)
  {
    ;
    ;
    if ((llIIllllIIll(isHidden)) && (llIIllllIlII(showModel)))
    {
      if (llIIllllIIll(compiled)) {
        lllllllllllllllllIllllIlIllllIIl.compileDisplayList(lllllllllllllllllIllllIlIlllIllI);
      }
      if ((llIIllllIIll(llIIlllllIII(rotateAngleX, 0.0F))) && (llIIllllIIll(llIIlllllIII(rotateAngleY, 0.0F))) && (llIIllllIIll(llIIlllllIII(rotateAngleZ, 0.0F))))
      {
        if ((!llIIllllIIll(llIIlllllIII(rotationPointX, 0.0F))) || (!llIIllllIIll(llIIlllllIII(rotationPointY, 0.0F))) || (llIIllllIlII(llIIlllllIII(rotationPointZ, 0.0F))))
        {
          GlStateManager.translate(rotationPointX * lllllllllllllllllIllllIlIlllIllI, rotationPointY * lllllllllllllllllIllllIlIlllIllI, rotationPointZ * lllllllllllllllllIllllIlIlllIllI);
          "".length();
          if (((23 + 90 - 71 + 114 ^ 66 + '±' - 165 + 103) & ('' + '' - 260 + 142 ^ 27 + '¦' - 147 + 142 ^ -" ".length()) & ((0x7 ^ 0x5E ^ 0xC1 ^ 0x8B) & (0xDF ^ 0x99 ^ 0x63 ^ 0x36 ^ -" ".length()) ^ -" ".length())) != "  ".length()) {}
        }
      }
      else
      {
        GlStateManager.translate(rotationPointX * lllllllllllllllllIllllIlIlllIllI, rotationPointY * lllllllllllllllllIllllIlIlllIllI, rotationPointZ * lllllllllllllllllIllllIlIlllIllI);
        if (llIIllllIlII(llIIlllllIII(rotateAngleZ, 0.0F))) {
          GlStateManager.rotate(rotateAngleZ * 57.295776F, 0.0F, 0.0F, 1.0F);
        }
        if (llIIllllIlII(llIIlllllIII(rotateAngleY, 0.0F))) {
          GlStateManager.rotate(rotateAngleY * 57.295776F, 0.0F, 1.0F, 0.0F);
        }
        if (llIIllllIlII(llIIlllllIII(rotateAngleX, 0.0F))) {
          GlStateManager.rotate(rotateAngleX * 57.295776F, 1.0F, 0.0F, 0.0F);
        }
      }
    }
  }
}

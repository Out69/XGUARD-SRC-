package net.minecraft.client;

import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.arikia.dev.drpc.DiscordEventHandlers;
import net.arikia.dev.drpc.DiscordEventHandlers.Builder;
import net.arikia.dev.drpc.DiscordRPC;
import net.arikia.dev.drpc.DiscordRichPresence.Builder;
import net.arikia.dev.drpc.DiscordUser;
import net.arikia.dev.drpc.callbacks.ReadyCallback;
import net.minecraft.util.Session;
import pl.xguard.loaders.WingsManager;

public class DiscordRP
{
  private static boolean lIllIlIlllIlll(int ???, int arg1)
  {
    int i;
    char llllllllllllllIllIllIlllllIIlllI;
    return ??? < i;
  }
  
  public void update(String llllllllllllllIllIllIllllllllIll, String llllllllllllllIllIllIllllllllIlI)
  {
    ;
    ;
    ;
    ;
    DiscordRichPresence.Builder llllllllllllllIllIllIlllllllllIl = new DiscordRichPresence.Builder(llllllllllllllIllIllIllllllllIlI);
    "".length();
    "".length();
    "".length();
    DiscordRPC.discordUpdatePresence(llllllllllllllIllIllIlllllllllIl.build());
  }
  
  private static String lIllIlIlllIlII(String llllllllllllllIllIllIlllllIlllll, String llllllllllllllIllIllIlllllIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIllIlllllIlllll = new String(Base64.getDecoder().decode(llllllllllllllIllIllIlllllIlllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIllIlllllIlllIl = new StringBuilder();
    char[] llllllllllllllIllIllIlllllIlllII = llllllllllllllIllIllIlllllIllllI.toCharArray();
    int llllllllllllllIllIllIlllllIllIll = lllIlllIIlIl[1];
    long llllllllllllllIllIllIlllllIlIlIl = llllllllllllllIllIllIlllllIlllll.toCharArray();
    Exception llllllllllllllIllIllIlllllIlIlII = llllllllllllllIllIllIlllllIlIlIl.length;
    long llllllllllllllIllIllIlllllIlIIll = lllIlllIIlIl[1];
    while (lIllIlIlllIlll(llllllllllllllIllIllIlllllIlIIll, llllllllllllllIllIllIlllllIlIlII))
    {
      char llllllllllllllIllIllIllllllIIIII = llllllllllllllIllIllIlllllIlIlIl[llllllllllllllIllIllIlllllIlIIll];
      "".length();
      "".length();
      if (" ".length() == 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIllIlllllIlllIl);
  }
  
  static
  {
    lIllIlIlllIllI();
    lIllIlIlllIlIl();
  }
  
  private static void lIllIlIlllIlIl()
  {
    lllIlllIIlII = new String[lllIlllIIlIl[4]];
    lllIlllIIlII[lllIlllIIlIl[1]] = lIllIlIlllIIll("X2/jXBIhe61OhtUQ1O7dnv2Mslmf4owv", "TqMPy");
    lllIlllIIlII[lllIlllIIlIl[0]] = lIllIlIlllIlII("ICURDQgWKEI8NydsIQ8LCC4DDQw=", "dLbng");
    lllIlllIIlII[lllIlllIIlIl[2]] = lIllIlIlllIlII("JQI3BQs=", "IcEbn");
    lllIlllIIlII[lllIlllIIlIl[3]] = lIllIlIlllIIll("wwE5KJkJ7qdAnYXVCQLX2Esb6ryc1N1y", "ODBoW");
  }
  
  private static void lIllIlIlllIllI()
  {
    lllIlllIIlIl = new int[5];
    lllIlllIIlIl[0] = " ".length();
    lllIlllIIlIl[1] = ((0x5B ^ 0x0 ^ 0xCE ^ 0x9B) & (69 + 32 - -15 + 47 ^ '' + 36 - 77 + 82 ^ -" ".length()));
    lllIlllIIlIl[2] = "  ".length();
    lllIlllIIlIl[3] = "   ".length();
    lllIlllIIlIl[4] = (0x4 ^ 0x0);
  }
  
  private static String lIllIlIlllIIll(String llllllllllllllIllIllIllllllIllll, String llllllllllllllIllIllIllllllIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIllIlllllllIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIllIllllllIllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIllIlllllllIIIl = Cipher.getInstance("Blowfish");
      llllllllllllllIllIllIlllllllIIIl.init(lllIlllIIlIl[2], llllllllllllllIllIllIlllllllIIlI);
      return new String(llllllllllllllIllIllIlllllllIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIllIllllllIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIllIlllllllIIII)
    {
      llllllllllllllIllIllIlllllllIIII.printStackTrace();
    }
    return null;
  }
  
  public void shutdown()
  {
    ;
    running = lllIlllIIlIl[1];
    DiscordRPC.discordShutdown();
  }
  
  public DiscordRP() {}
  
  public void start()
  {
    ;
    ;
    created = System.currentTimeMillis();
    DiscordEventHandlers llllllllllllllIllIlllIIIIIIIlIlI = new DiscordEventHandlers.Builder().setReadyEventHandler(new ReadyCallback()
    {
      private static boolean lIIllIlllIIIlI(int ???, int arg1)
      {
        int i;
        long lllllllllllllllIIIlIIlllIIlllIlI;
        return ??? == i;
      }
      
      private static String lIIllIllIllllI(String lllllllllllllllIIIlIIlllIlIlIIII, String lllllllllllllllIIIlIIlllIlIIllll)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllllllllllllllIIIlIIlllIlIlIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIlIIlllIlIIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher lllllllllllllllIIIlIIlllIlIlIIlI = Cipher.getInstance("Blowfish");
          lllllllllllllllIIIlIIlllIlIlIIlI.init(llIIlIlllIII[3], lllllllllllllllIIIlIIlllIlIlIIll);
          return new String(lllllllllllllllIIIlIIlllIlIlIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIlIIlllIlIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllllllllllllllIIIlIIlllIlIlIIIl)
        {
          lllllllllllllllIIIlIIlllIlIlIIIl.printStackTrace();
        }
        return null;
      }
      
      private static boolean lIIllIlllIIIll(int ???, int arg1)
      {
        int i;
        String lllllllllllllllIIIlIIlllIIllIllI;
        return ??? < i;
      }
      
      private static void lIIllIlllIIIII()
      {
        llIIlIllIlll = new String[llIIlIlllIII[7]];
        llIIlIllIlll[llIIlIlllIII[0]] = lIIllIllIlllIl("HjghNyJlcSEhJyM0dT0nJyU6djImIiE3JCZxJTkkKDIvOSYscS92LCAiNjk6LTQ4", "IQUVH");
        llIIlIllIlll[llIIlIlllIII[1]] = lIIllIllIlllIl("bg==", "MDUpJ");
        llIIlIllIlll[llIIlIlllIII[3]] = lIIllIllIllllI("/My8/D9KsfJDrgPcDvA+dRYM+DKh1yO5hLUXXPI15As=", "hBsNE");
        llIIlIllIlll[llIIlIlllIII[4]] = lIIllIllIlllll("yMahKsC7qCBQPXpOoFWuYRACMs+xX/f0", "MMKKn");
        llIIlIllIlll[llIIlIlllIII[5]] = lIIllIllIllllI("kL1lhLIWUyk=", "UcbEJ");
        llIIlIllIlll[llIIlIlllIII[6]] = lIIllIllIllllI("sr2QwH1Jvg4=", "LBukq");
      }
      
      private static String lIIllIllIlllIl(String lllllllllllllllIIIlIIlllIllIIlIl, String lllllllllllllllIIIlIIlllIllIIlII)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        lllllllllllllllIIIlIIlllIllIIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIIIlIIlllIllIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder lllllllllllllllIIIlIIlllIllIIIll = new StringBuilder();
        char[] lllllllllllllllIIIlIIlllIllIIIlI = lllllllllllllllIIIlIIlllIllIIlII.toCharArray();
        int lllllllllllllllIIIlIIlllIllIIIIl = llIIlIlllIII[0];
        char lllllllllllllllIIIlIIlllIlIllIll = lllllllllllllllIIIlIIlllIllIIlIl.toCharArray();
        short lllllllllllllllIIIlIIlllIlIllIlI = lllllllllllllllIIIlIIlllIlIllIll.length;
        boolean lllllllllllllllIIIlIIlllIlIllIIl = llIIlIlllIII[0];
        while (lIIllIlllIIIll(lllllllllllllllIIIlIIlllIlIllIIl, lllllllllllllllIIIlIIlllIlIllIlI))
        {
          char lllllllllllllllIIIlIIlllIllIIllI = lllllllllllllllIIIlIIlllIlIllIll[lllllllllllllllIIIlIIlllIlIllIIl];
          "".length();
          "".length();
          if (-(0x64 ^ 0x7B ^ 0x87 ^ 0x9C) >= 0) {
            return null;
          }
        }
        return String.valueOf(lllllllllllllllIIIlIIlllIllIIIll);
      }
      
      static
      {
        lIIllIlllIIIIl();
        lIIllIlllIIIII();
      }
      
      private static String lIIllIllIlllll(String lllllllllllllllIIIlIIlllIlIIIIll, String lllllllllllllllIIIlIIlllIlIIIIII)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllllllllllllllIIIlIIlllIlIIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIlIIlllIlIIIIII.getBytes(StandardCharsets.UTF_8)), llIIlIlllIII[8]), "DES");
          Cipher lllllllllllllllIIIlIIlllIlIIIlIl = Cipher.getInstance("DES");
          lllllllllllllllIIIlIIlllIlIIIlIl.init(llIIlIlllIII[3], lllllllllllllllIIIlIIlllIlIIIllI);
          return new String(lllllllllllllllIIIlIIlllIlIIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIlIIlllIlIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllllllllllllllIIIlIIlllIlIIIlII)
        {
          lllllllllllllllIIIlIIlllIlIIIlII.printStackTrace();
        }
        return null;
      }
      
      private static void lIIllIlllIIIIl()
      {
        llIIlIlllIII = new int[9];
        llIIlIlllIII[0] = ((0x7C ^ 0x1B ^ 83 + 123 - 154 + 75) & (0 + 55 - -53 + 23 ^ 121 + 74 - 40 + 0 ^ -" ".length()));
        llIIlIlllIII[1] = " ".length();
        llIIlIlllIII[2] = (0x9FFD & 0x758A);
        llIIlIlllIII[3] = "  ".length();
        llIIlIlllIII[4] = "   ".length();
        llIIlIlllIII[5] = (0x6D ^ 0x69);
        llIIlIlllIII[6] = (0x67 ^ 0x34 ^ 0x9 ^ 0x5F);
        llIIlIlllIII[7] = (30 + 86 - 86 + 114 ^ '' + 117 - 130 + 18);
        llIIlIlllIII[8] = (0x2C ^ 0x24);
      }
      
      public void apply(DiscordUser lllllllllllllllIIIlIIlllIlllIIII)
      {
        ;
        ;
        System.out.println(String.valueOf(new StringBuilder(llIIlIllIlll[llIIlIlllIII[0]]).append(username).append(llIIlIllIlll[llIIlIlllIII[1]]).append(discriminator)));
        if (lIIllIlllIIIlI(WingsManager.getWingsID(Minecraft.getMinecraft().getSession().getUsername()), llIIlIlllIII[2]))
        {
          update(llIIlIllIlll[llIIlIlllIII[3]], String.valueOf(new StringBuilder(llIIlIllIlll[llIIlIlllIII[4]]).append(Minecraft.getMinecraft().getSession().getUsername())));
          "".length();
          if (" ".length() > 0) {}
        }
        else
        {
          update(String.valueOf(new StringBuilder(llIIlIllIlll[llIIlIlllIII[5]]).append(WingsManager.getWingsID(Minecraft.getMinecraft().getSession().getUsername()))), String.valueOf(new StringBuilder(llIIlIllIlll[llIIlIlllIII[6]]).append(Minecraft.getMinecraft().getSession().getUsername())));
        }
      }
    }).build();
    DiscordRPC.discordInitialize(lllIlllIIlII[lllIlllIIlIl[1]], llllllllllllllIllIlllIIIIIIIlIlI, lllIlllIIlIl[0]);
    new Thread(lllIlllIIlII[lllIlllIIlIl[0]])
    {
      public void run()
      {
        ;
        "".length();
        if ("  ".length() < 0) {
          return;
        }
        while (!lIIIllIIIlIIl(running)) {
          DiscordRPC.discordRunCallbacks();
        }
      }
      
      private static boolean lIIIllIIIlIIl(int ???)
      {
        boolean llllllllllllllllIlllIlIlIlllIlII;
        return ??? == 0;
      }
    }.start();
  }
}

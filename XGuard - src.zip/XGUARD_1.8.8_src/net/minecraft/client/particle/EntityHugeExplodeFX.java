package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class EntityHugeExplodeFX
  extends EntityFX
{
  public void renderParticle(WorldRenderer lllIlIIIlllllIl, Entity lllIlIIIlllllII, float lllIlIIIllllIll, float lllIlIIIllllIlI, float lllIlIIIllllIIl, float lllIlIIIllllIII, float lllIlIIIlllIlll, float lllIlIIIlllIllI) {}
  
  private static boolean llIIllII(int ???, int arg1)
  {
    int i;
    double lllIlIIIllIIIlI;
    return ??? == i;
  }
  
  protected EntityHugeExplodeFX(World lllIlIIlIIIlIlI, double lllIlIIlIIIIIIl, double lllIlIIlIIIIIII, double lllIlIIlIIIIlll, double lllIlIIlIIIIllI, double lllIlIIlIIIIlIl, double lllIlIIlIIIIlII)
  {
    lllIlIIlIIIIIll.<init>(lllIlIIlIIIlIlI, lllIlIIlIIIIIIl, lllIlIIlIIIIIII, lllIlIIlIIIIlll, 0.0D, 0.0D, 0.0D);
  }
  
  public int getFXLayer()
  {
    return llIlll[3];
  }
  
  static {}
  
  private static boolean llIIlIll(int ???, int arg1)
  {
    int i;
    int lllIlIIIlIllllI;
    return ??? >= i;
  }
  
  private static void llIIlIlI()
  {
    llIlll = new int[4];
    llIlll[0] = (0x75 ^ 0x56 ^ 0x42 ^ 0x69);
    llIlll[1] = ((90 + 63 - -81 + 7 ^ 94 + '¡' - 247 + 171) & (103 + '' - 211 + 185 ^ 5 + 120 - -24 + 0 ^ -" ".length()));
    llIlll[2] = (0x78 ^ 0x1 ^ 24 + 42 - 54 + 115);
    llIlll[3] = " ".length();
  }
  
  public void onUpdate()
  {
    ;
    ;
    ;
    ;
    ;
    int lllIlIIIllIllll = llIlll[1];
    "".length();
    if (null != null) {
      return;
    }
    while (!llIIlIll(lllIlIIIllIllll, llIlll[2]))
    {
      double lllIlIIIllIlllI = posX + (rand.nextDouble() - rand.nextDouble()) * 4.0D;
      double lllIlIIIllIllIl = posY + (rand.nextDouble() - rand.nextDouble()) * 4.0D;
      double lllIlIIIllIllII = posZ + (rand.nextDouble() - rand.nextDouble()) * 4.0D;
      worldObj.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, lllIlIIIllIlllI, lllIlIIIllIllIl, lllIlIIIllIllII, timeSinceStart / maximumTime, 0.0D, 0.0D, new int[llIlll[1]]);
      lllIlIIIllIllll++;
    }
    timeSinceStart += llIlll[3];
    if (llIIllII(timeSinceStart, maximumTime)) {
      lllIlIIIllIlIll.setDead();
    }
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIllllIllIlIllIIlIl, World llllllllllllllIllllIllIlIlIlllII, double llllllllllllllIllllIllIlIlIllIll, double llllllllllllllIllllIllIlIllIIIlI, double llllllllllllllIllllIllIlIllIIIIl, double llllllllllllllIllllIllIlIllIIIII, double llllllllllllllIllllIllIlIlIlIlll, double llllllllllllllIllllIllIlIlIlIllI, int... llllllllllllllIllllIllIlIlIlllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityHugeExplodeFX(llllllllllllllIllllIllIlIlIlllII, llllllllllllllIllllIllIlIlIllIll, llllllllllllllIllllIllIlIllIIIlI, llllllllllllllIllllIllIlIllIIIIl, llllllllllllllIllllIllIlIllIIIII, llllllllllllllIllllIllIlIlIlIlll, llllllllllllllIllllIllIlIlIlIllI);
    }
  }
}

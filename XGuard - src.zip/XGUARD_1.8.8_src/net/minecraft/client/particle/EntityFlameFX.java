package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityFlameFX
  extends EntityFX
{
  private static boolean lIllIllIlIll(int ???, int arg1)
  {
    int i;
    long llllllllllllllllllIlIIllIIIIllll;
    return ??? >= i;
  }
  
  private static boolean lIllIllIlIIl(int ???, int arg1)
  {
    int i;
    short llllllllllllllllllIlIIllIIIIlIll;
    return ??? > i;
  }
  
  public void renderParticle(WorldRenderer llllllllllllllllllIlIIllIIllllII, Entity llllllllllllllllllIlIIllIlIIIlIl, float llllllllllllllllllIlIIllIIlllIlI, float llllllllllllllllllIlIIllIlIIIIll, float llllllllllllllllllIlIIllIlIIIIlI, float llllllllllllllllllIlIIllIlIIIIIl, float llllllllllllllllllIlIIllIIllIllI, float llllllllllllllllllIlIIllIIllIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllllllIlIIllIIlllllI = (particleAge + llllllllllllllllllIlIIllIIlllIlI) / particleMaxAge;
    particleScale = (flameScale * (1.0F - llllllllllllllllllIlIIllIIlllllI * llllllllllllllllllIlIIllIIlllllI * 0.5F));
    llllllllllllllllllIlIIllIlIIIlll.renderParticle(llllllllllllllllllIlIIllIIllllII, llllllllllllllllllIlIIllIlIIIlIl, llllllllllllllllllIlIIllIIlllIlI, llllllllllllllllllIlIIllIIlllIIl, llllllllllllllllllIlIIllIlIIIIlI, llllllllllllllllllIlIIllIlIIIIIl, llllllllllllllllllIlIIllIIllIllI, llllllllllllllllllIlIIllIIllIlIl);
  }
  
  public int getBrightnessForRender(float llllllllllllllllllIlIIllIIlIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllllllIlIIllIIlIlIll = (particleAge + llllllllllllllllllIlIIllIIlIIllI) / particleMaxAge;
    llllllllllllllllllIlIIllIIlIlIll = MathHelper.clamp_float(llllllllllllllllllIlIIllIIlIlIll, 0.0F, 1.0F);
    int llllllllllllllllllIlIIllIIlIlIlI = llllllllllllllllllIlIIllIIlIIlll.getBrightnessForRender(llllllllllllllllllIlIIllIIlIIllI);
    int llllllllllllllllllIlIIllIIlIlIIl = llllllllllllllllllIlIIllIIlIlIlI & lllIIllIII[3];
    int llllllllllllllllllIlIIllIIlIlIII = llllllllllllllllllIlIIllIIlIlIlI >> lllIIllIII[4] & lllIIllIII[3];
    llllllllllllllllllIlIIllIIlIlIIl += (int)(llllllllllllllllllIlIIllIIlIlIll * 15.0F * 16.0F);
    if (lIllIllIlIIl(llllllllllllllllllIlIIllIIlIlIIl, lllIIllIII[5])) {
      llllllllllllllllllIlIIllIIlIlIIl = lllIIllIII[5];
    }
    return llllllllllllllllllIlIIllIIlIlIIl | llllllllllllllllllIlIIllIIlIlIII << lllIIllIII[4];
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + lllIIllIII[1]);
    if (lIllIllIlIll(tmp29_26, particleMaxAge)) {
      llllllllllllllllllIlIIllIIIlIIll.setDead();
    }
    llllllllllllllllllIlIIllIIIlIIll.moveEntity(motionX, motionY, motionZ);
    motionX *= 0.9599999785423279D;
    motionY *= 0.9599999785423279D;
    motionZ *= 0.9599999785423279D;
    if (lIllIllIllII(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  private static void lIllIllIIlll()
  {
    lllIIllIII = new int[6];
    lllIIllIII[0] = (0x2A ^ 0x2E);
    lllIIllIII[1] = " ".length();
    lllIIllIII[2] = (0x65 ^ 0x55);
    lllIIllIII[3] = (19 + '¨' - -13 + 55);
    lllIIllIII[4] = (0xBE ^ 0xAE);
    lllIIllIII[5] = ('' + 43 - 118 + 96 + (0x0 ^ 0x45) - (54 + '' - 118 + 141) + (79 + '´' - 168 + 134));
  }
  
  protected EntityFlameFX(World llllllllllllllllllIlIIllIllIIIII, double llllllllllllllllllIlIIllIlIlllll, double llllllllllllllllllIlIIllIlIllllI, double llllllllllllllllllIlIIllIlIlllIl, double llllllllllllllllllIlIIllIlIlllII, double llllllllllllllllllIlIIllIlIlIIll, double llllllllllllllllllIlIIllIlIlIIlI)
  {
    llllllllllllllllllIlIIllIlIllIIl.<init>(llllllllllllllllllIlIIllIllIIIII, llllllllllllllllllIlIIllIlIlllll, llllllllllllllllllIlIIllIlIllllI, llllllllllllllllllIlIIllIlIlllIl, llllllllllllllllllIlIIllIlIlllII, llllllllllllllllllIlIIllIlIlIIll, llllllllllllllllllIlIIllIlIlIIlI);
    motionX = (motionX * 0.009999999776482582D + llllllllllllllllllIlIIllIlIlllII);
    motionY = (motionY * 0.009999999776482582D + llllllllllllllllllIlIIllIlIlIIll);
    motionZ = (motionZ * 0.009999999776482582D + llllllllllllllllllIlIIllIlIlIIlI);
    posX += (rand.nextFloat() - rand.nextFloat()) * 0.05F;
    posY += (rand.nextFloat() - rand.nextFloat()) * 0.05F;
    posZ += (rand.nextFloat() - rand.nextFloat()) * 0.05F;
    flameScale = particleScale;
    particleRed = (llllllllllllllllllIlIIllIlIllIIl.particleGreen = llllllllllllllllllIlIIllIlIllIIl.particleBlue = 1.0F);
    particleMaxAge = ((int)(8.0D / (Math.random() * 0.8D + 0.2D)) + lllIIllIII[0]);
    noClip = lllIIllIII[1];
    llllllllllllllllllIlIIllIlIllIIl.setParticleTextureIndex(lllIIllIII[2]);
  }
  
  private static boolean lIllIllIllII(int ???)
  {
    byte llllllllllllllllllIlIIllIIIIlIIl;
    return ??? != 0;
  }
  
  public float getBrightness(float llllllllllllllllllIlIIllIIIllIII)
  {
    ;
    ;
    ;
    ;
    float llllllllllllllllllIlIIllIIIllIll = (particleAge + llllllllllllllllllIlIIllIIIllIII) / particleMaxAge;
    llllllllllllllllllIlIIllIIIllIll = MathHelper.clamp_float(llllllllllllllllllIlIIllIIIllIll, 0.0F, 1.0F);
    float llllllllllllllllllIlIIllIIIllIlI = llllllllllllllllllIlIIllIIIllIIl.getBrightness(llllllllllllllllllIlIIllIIIllIII);
    return llllllllllllllllllIlIIllIIIllIlI * llllllllllllllllllIlIIllIIIllIll + (1.0F - llllllllllllllllllIlIIllIIIllIll);
  }
  
  static {}
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIlIIlllIlIIlIlllII, World llllllllllllllIlIIlllIlIIlIlIIll, double llllllllllllllIlIIlllIlIIlIlIIlI, double llllllllllllllIlIIlllIlIIlIlIIIl, double llllllllllllllIlIIlllIlIIlIlIIII, double llllllllllllllIlIIlllIlIIlIlIlll, double llllllllllllllIlIIlllIlIIlIlIllI, double llllllllllllllIlIIlllIlIIlIlIlIl, int... llllllllllllllIlIIlllIlIIlIlIlII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityFlameFX(llllllllllllllIlIIlllIlIIlIlIIll, llllllllllllllIlIIlllIlIIlIlIIlI, llllllllllllllIlIIlllIlIIlIlIIIl, llllllllllllllIlIIlllIlIIlIlIIII, llllllllllllllIlIIlllIlIIlIlIlll, llllllllllllllIlIIlllIlIIlIlIllI, llllllllllllllIlIIlllIlIIlIlIlIl);
    }
  }
}

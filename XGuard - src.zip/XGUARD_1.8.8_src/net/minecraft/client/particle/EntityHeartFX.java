package net.minecraft.client.particle;

import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityHeartFX
  extends EntityFX
{
  private static void lIllllIlI()
  {
    lIIIIIII = new int[4];
    lIIIIIII[0] = (0x5 ^ 0x17 ^ "  ".length());
    lIIIIIII[1] = ((0x13 ^ 0x28) & (0x86 ^ 0xBD ^ 0xFFFFFFFF));
    lIIIIIII[2] = (0xC3 ^ 0x93);
    lIIIIIII[3] = " ".length();
  }
  
  public void renderParticle(WorldRenderer llIlIIIlIllIlll, Entity llIlIIIllIIIIII, float llIlIIIlIllIlIl, float llIlIIIlIllIlII, float llIlIIIlIllIIll, float llIlIIIlIllllII, float llIlIIIlIlllIll, float llIlIIIlIlllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llIlIIIlIlllIIl = (particleAge + llIlIIIlIllIlIl) / particleMaxAge * 32.0F;
    llIlIIIlIlllIIl = MathHelper.clamp_float(llIlIIIlIlllIIl, 0.0F, 1.0F);
    particleScale = (particleScaleOverTime * llIlIIIlIlllIIl);
    llIlIIIlIlllIII.renderParticle(llIlIIIlIllIlll, llIlIIIllIIIIII, llIlIIIlIllIlIl, llIlIIIlIlllllI, llIlIIIlIllIIll, llIlIIIlIllllII, llIlIIIlIlllIll, llIlIIIlIlllIlI);
  }
  
  private static boolean lIlllllIl(int ???)
  {
    int llIlIIIlIlIIlII;
    return ??? == 0;
  }
  
  protected EntityHeartFX(World llIlIIIlllIlIII, double llIlIIIlllIllll, double llIlIIIlllIIllI, double llIlIIIlllIIlIl, double llIlIIIlllIllII, double llIlIIIlllIIIll, double llIlIIIlllIIIlI)
  {
    llIlIIIllllIIIl.<init>(llIlIIIlllIlIII, llIlIIIlllIllll, llIlIIIlllIIllI, llIlIIIlllIIlIl, llIlIIIlllIllII, llIlIIIlllIIIll, llIlIIIlllIIIlI, 2.0F);
  }
  
  static {}
  
  protected EntityHeartFX(World llIlIIIllIllIlI, double llIlIIIllIlIIII, double llIlIIIllIIllll, double llIlIIIllIIlllI, double llIlIIIllIlIllI, double llIlIIIllIlIlIl, double llIlIIIllIlIlII, float llIlIIIllIlIIll)
  {
    llIlIIIllIlIIlI.<init>(llIlIIIllIllIlI, llIlIIIllIlIIII, llIlIIIllIIllll, llIlIIIllIlIlll, 0.0D, 0.0D, 0.0D);
    motionX *= 0.009999999776482582D;
    motionY *= 0.009999999776482582D;
    motionZ *= 0.009999999776482582D;
    motionY += 0.1D;
    particleScale *= 0.75F;
    particleScale *= llIlIIIllIlIIll;
    particleScaleOverTime = particleScale;
    particleMaxAge = lIIIIIII[0];
    noClip = lIIIIIII[1];
    llIlIIIllIlIIlI.setParticleTextureIndex(lIIIIIII[2]);
  }
  
  private static boolean lIllllllI(int ???)
  {
    int llIlIIIlIlIIllI;
    return ??? != 0;
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + lIIIIIII[3]);
    if (lIlllllII(tmp29_26, particleMaxAge)) {
      llIlIIIlIlIllII.setDead();
    }
    llIlIIIlIlIllII.moveEntity(motionX, motionY, motionZ);
    if (lIlllllIl(lIllllIll(posY, prevPosY)))
    {
      motionX *= 1.1D;
      motionZ *= 1.1D;
    }
    motionX *= 0.8600000143051147D;
    motionY *= 0.8600000143051147D;
    motionZ *= 0.8600000143051147D;
    if (lIllllllI(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  private static boolean lIlllllII(int ???, int arg1)
  {
    int i;
    String llIlIIIlIlIlIII;
    return ??? >= i;
  }
  
  private static int lIllllIll(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public static class AngryVillagerFactory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int llIlIlllllIIIIl, World llIlIlllllIIIII, double llIlIllllIlllll, double llIlIllllIllllI, double llIlIllllIlIIll, double llIlIllllIlllII, double llIlIllllIllIll, double llIlIllllIllIlI, int... llIlIllllIllIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      EntityFX llIlIllllIllIII = new EntityHeartFX(llIlIlllllIIIII, llIlIllllIlllll, llIlIllllIllllI + 0.5D, llIlIllllIlIIll, llIlIllllIlllII, llIlIllllIllIll, llIlIllllIllIlI);
      llIlIllllIllIII.setParticleTextureIndex(llIIlIl[0]);
      llIlIllllIllIII.setRBGColorF(1.0F, 1.0F, 1.0F);
      return llIlIllllIllIII;
    }
    
    static {}
    
    private static void lIIlllIlI()
    {
      llIIlIl = new int[1];
      llIIlIl[0] = (0x5F ^ 0x4D ^ 0x50 ^ 0x13);
    }
    
    public AngryVillagerFactory() {}
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIIllIllllIIIIlllII, World llllllllllllllIIllIllllIIIIlIIll, double llllllllllllllIIllIllllIIIIllIlI, double llllllllllllllIIllIllllIIIIlIIIl, double llllllllllllllIIllIllllIIIIlIIII, double llllllllllllllIIllIllllIIIIIllll, double llllllllllllllIIllIllllIIIIIlllI, double llllllllllllllIIllIllllIIIIlIlIl, int... llllllllllllllIIllIllllIIIIlIlII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityHeartFX(llllllllllllllIIllIllllIIIIlIIll, llllllllllllllIIllIllllIIIIllIlI, llllllllllllllIIllIllllIIIIlIIIl, llllllllllllllIIllIllllIIIIlIIII, llllllllllllllIIllIllllIIIIIllll, llllllllllllllIIllIllllIIIIIlllI, llllllllllllllIIllIllllIIIIlIlIl);
    }
  }
}

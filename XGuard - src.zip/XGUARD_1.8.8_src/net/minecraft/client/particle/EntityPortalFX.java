package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;

public class EntityPortalFX
  extends EntityFX
{
  public float getBrightness(float llllllllllllllIIllIIIllllIIlIIII)
  {
    ;
    ;
    ;
    ;
    float llllllllllllllIIllIIIllllIIIllll = llllllllllllllIIllIIIllllIIIllIl.getBrightness(llllllllllllllIIllIIIllllIIlIIII);
    float llllllllllllllIIllIIIllllIIIlllI = particleAge / particleMaxAge;
    llllllllllllllIIllIIIllllIIIlllI = llllllllllllllIIllIIIllllIIIlllI * llllllllllllllIIllIIIllllIIIlllI * llllllllllllllIIllIIIllllIIIlllI * llllllllllllllIIllIIIllllIIIlllI;
    return llllllllllllllIIllIIIllllIIIllll * (1.0F - llllllllllllllIIllIIIllllIIIlllI) + llllllllllllllIIllIIIllllIIIlllI;
  }
  
  public void onUpdate()
  {
    ;
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    float llllllllllllllIIllIIIllllIIIIllI = particleAge / particleMaxAge;
    llllllllllllllIIllIIIllllIIIIllI = -llllllllllllllIIllIIIllllIIIIllI + llllllllllllllIIllIIIllllIIIIllI * llllllllllllllIIllIIIllllIIIIllI * 2.0F;
    llllllllllllllIIllIIIllllIIIIllI = 1.0F - llllllllllllllIIllIIIllllIIIIllI;
    posX = (portalPosX + motionX * llllllllllllllIIllIIIllllIIIIllI);
    posY = (portalPosY + motionY * llllllllllllllIIllIIIllllIIIIllI + (1.0F - llllllllllllllIIllIIIllllIIIIllI));
    posZ = (portalPosZ + motionZ * llllllllllllllIIllIIIllllIIIIllI);
    int tmp107_104 = particleAge;
    particleAge = (tmp107_104 + lIIlllIllIlll[1]);
    if (lllIllllIIllII(tmp107_104, particleMaxAge)) {
      llllllllllllllIIllIIIllllIIIIlIl.setDead();
    }
  }
  
  protected EntityPortalFX(World llllllllllllllIIllIIIlllllIlIllI, double llllllllllllllIIllIIIlllllIlIlIl, double llllllllllllllIIllIIIlllllIlIlII, double llllllllllllllIIllIIIlllllIlIIll, double llllllllllllllIIllIIIlllllIIlIIl, double llllllllllllllIIllIIIlllllIlIIIl, double llllllllllllllIIllIIIlllllIlIIII)
  {
    llllllllllllllIIllIIIlllllIlIlll.<init>(llllllllllllllIIllIIIlllllIlIllI, llllllllllllllIIllIIIlllllIlIlIl, llllllllllllllIIllIIIlllllIlIlII, llllllllllllllIIllIIIlllllIlIIll, llllllllllllllIIllIIIlllllIIlIIl, llllllllllllllIIllIIIlllllIlIIIl, llllllllllllllIIllIIIlllllIlIIII);
    motionX = llllllllllllllIIllIIIlllllIIlIIl;
    motionY = llllllllllllllIIllIIIlllllIlIIIl;
    motionZ = llllllllllllllIIllIIIlllllIlIIII;
    portalPosX = (llllllllllllllIIllIIIlllllIlIlll.posX = llllllllllllllIIllIIIlllllIlIlIl);
    portalPosY = (llllllllllllllIIllIIIlllllIlIlll.posY = llllllllllllllIIllIIIlllllIlIlII);
    portalPosZ = (llllllllllllllIIllIIIlllllIlIlll.posZ = llllllllllllllIIllIIIlllllIlIIll);
    float llllllllllllllIIllIIIlllllIIllll = rand.nextFloat() * 0.6F + 0.4F;
    portalParticleScale = (llllllllllllllIIllIIIlllllIlIlll.particleScale = rand.nextFloat() * 0.2F + 0.5F);
    particleRed = (llllllllllllllIIllIIIlllllIlIlll.particleGreen = llllllllllllllIIllIIIlllllIlIlll.particleBlue = 1.0F * llllllllllllllIIllIIIlllllIIllll);
    particleGreen *= 0.3F;
    particleRed *= 0.9F;
    particleMaxAge = ((int)(Math.random() * 10.0D) + lIIlllIllIlll[0]);
    noClip = lIIlllIllIlll[1];
    llllllllllllllIIllIIIlllllIlIlll.setParticleTextureIndex((int)(Math.random() * 8.0D));
  }
  
  static {}
  
  public void renderParticle(WorldRenderer llllllllllllllIIllIIIllllIlllIlI, Entity llllllllllllllIIllIIIllllIlIllll, float llllllllllllllIIllIIIllllIlIlllI, float llllllllllllllIIllIIIllllIllIlll, float llllllllllllllIIllIIIllllIlIllII, float llllllllllllllIIllIIIllllIllIlIl, float llllllllllllllIIllIIIllllIlIlIlI, float llllllllllllllIIllIIIllllIllIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIIllIIIllllIllIIlI = (particleAge + llllllllllllllIIllIIIllllIlIlllI) / particleMaxAge;
    llllllllllllllIIllIIIllllIllIIlI = 1.0F - llllllllllllllIIllIIIllllIllIIlI;
    llllllllllllllIIllIIIllllIllIIlI *= llllllllllllllIIllIIIllllIllIIlI;
    llllllllllllllIIllIIIllllIllIIlI = 1.0F - llllllllllllllIIllIIIllllIllIIlI;
    particleScale = (portalParticleScale * llllllllllllllIIllIIIllllIllIIlI);
    llllllllllllllIIllIIIllllIllIIIl.renderParticle(llllllllllllllIIllIIIllllIlllIlI, llllllllllllllIIllIIIllllIlIllll, llllllllllllllIIllIIIllllIlIlllI, llllllllllllllIIllIIIllllIlIllIl, llllllllllllllIIllIIIllllIlIllII, llllllllllllllIIllIIIllllIllIlIl, llllllllllllllIIllIIIllllIlIlIlI, llllllllllllllIIllIIIllllIllIIll);
  }
  
  public int getBrightnessForRender(float llllllllllllllIIllIIIllllIIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIIllIIIllllIIlllll = llllllllllllllIIllIIIllllIlIIIIl.getBrightnessForRender(llllllllllllllIIllIIIllllIIllIlI);
    float llllllllllllllIIllIIIllllIIllllI = particleAge / particleMaxAge;
    llllllllllllllIIllIIIllllIIllllI *= llllllllllllllIIllIIIllllIIllllI;
    llllllllllllllIIllIIIllllIIllllI *= llllllllllllllIIllIIIllllIIllllI;
    int llllllllllllllIIllIIIllllIIlllIl = llllllllllllllIIllIIIllllIIlllll & lIIlllIllIlll[2];
    int llllllllllllllIIllIIIllllIIlllII = llllllllllllllIIllIIIllllIIlllll >> lIIlllIllIlll[3] & lIIlllIllIlll[2];
    llllllllllllllIIllIIIllllIIlllII += (int)(llllllllllllllIIllIIIllllIIllllI * 15.0F * 16.0F);
    if (lllIllllIIlIll(llllllllllllllIIllIIIllllIIlllII, lIIlllIllIlll[4])) {
      llllllllllllllIIllIIIllllIIlllII = lIIlllIllIlll[4];
    }
    return llllllllllllllIIllIIIllllIIlllIl | llllllllllllllIIllIIIllllIIlllII << lIIlllIllIlll[3];
  }
  
  private static void lllIllllIIlIlI()
  {
    lIIlllIllIlll = new int[5];
    lIIlllIllIlll[0] = (0x27 ^ 0x69 ^ 0x54 ^ 0x32);
    lIIlllIllIlll[1] = " ".length();
    lIIlllIllIlll[2] = (43 + 43 - -33 + 103 + (0xDD ^ 0xB7) - (3 + 91 - 18 + 55) + (0x3E ^ 0x4));
    lIIlllIllIlll[3] = (0xD8 ^ 0xB8 ^ 0x44 ^ 0x34);
    lIIlllIllIlll[4] = (90 + 'Õ' - 205 + 142);
  }
  
  private static boolean lllIllllIIlIll(int ???, int arg1)
  {
    int i;
    float llllllllllllllIIllIIIlllIlllllII;
    return ??? > i;
  }
  
  private static boolean lllIllllIIllII(int ???, int arg1)
  {
    int i;
    float llllllllllllllIIllIIIllllIIIIIII;
    return ??? >= i;
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIlIllIlIlIIIlIllIl, World llllllllllllllIlIllIlIlIIIlIllII, double llllllllllllllIlIllIlIlIIIlIIIll, double llllllllllllllIlIllIlIlIIIlIlIlI, double llllllllllllllIlIllIlIlIIIlIlIIl, double llllllllllllllIlIllIlIlIIIlIIIII, double llllllllllllllIlIllIlIlIIIlIIlll, double llllllllllllllIlIllIlIlIIIIllllI, int... llllllllllllllIlIllIlIlIIIlIIlIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityPortalFX(llllllllllllllIlIllIlIlIIIlIllII, llllllllllllllIlIllIlIlIIIlIIIll, llllllllllllllIlIllIlIlIIIlIlIlI, llllllllllllllIlIllIlIlIIIlIlIIl, llllllllllllllIlIllIlIlIIIlIIIII, llllllllllllllIlIllIlIlIIIlIIlll, llllllllllllllIlIllIlIlIIIIllllI);
    }
  }
}

package net.minecraft.client.particle;

import net.minecraft.world.World;

public class EntityFishWakeFX
  extends EntityFX
{
  private static boolean lIlllIlIllIll(int ???)
  {
    Exception llllllllllllllllIIIllllIllIllllI;
    return ??? <= 0;
  }
  
  public void onUpdate()
  {
    ;
    ;
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    motionY -= particleGravity;
    llllllllllllllllIIIllllIlllIIlIl.moveEntity(motionX, motionY, motionZ);
    motionX *= 0.9800000190734863D;
    motionY *= 0.9800000190734863D;
    motionZ *= 0.9800000190734863D;
    int llllllllllllllllIIIllllIlllIIlII = llllIIlIIIl[1] - particleMaxAge;
    float llllllllllllllllIIIllllIlllIIIll = llllllllllllllllIIIllllIlllIIlII * 0.001F;
    llllllllllllllllIIIllllIlllIIlIl.setSize(llllllllllllllllIIIllllIlllIIIll, llllllllllllllllIIIllllIlllIIIll);
    llllllllllllllllIIIllllIlllIIlIl.setParticleTextureIndex(llllIIlIIIl[0] + llllllllllllllllIIIllllIlllIIlII % llllIIlIIIl[2]);
    int tmp135_132 = particleMaxAge;
    particleMaxAge = (tmp135_132 - llllIIlIIIl[3]);
    if (lIlllIlIllIll(tmp135_132)) {
      llllllllllllllllIIIllllIlllIIlIl.setDead();
    }
  }
  
  static {}
  
  private static void lIlllIlIllIlI()
  {
    llllIIlIIIl = new int[4];
    llllIIlIIIl[0] = (0x26 ^ 0x3E ^ 0xA1 ^ 0xAA);
    llllIIlIIIl[1] = (0xE3 ^ 0xA7 ^ 0x62 ^ 0x1A);
    llllIIlIIIl[2] = (" ".length() ^ 0x1D ^ 0x18);
    llllIIlIIIl[3] = " ".length();
  }
  
  protected EntityFishWakeFX(World llllllllllllllllIIIllllIlllIllll, double llllllllllllllllIIIllllIlllIlllI, double llllllllllllllllIIIllllIllllIlIl, double llllllllllllllllIIIllllIlllIllII, double llllllllllllllllIIIllllIllllIIll, double llllllllllllllllIIIllllIlllIlIlI, double llllllllllllllllIIIllllIlllIlIIl)
  {
    llllllllllllllllIIIllllIlllllIII.<init>(llllllllllllllllIIIllllIlllIllll, llllllllllllllllIIIllllIlllIlllI, llllllllllllllllIIIllllIllllIlIl, llllllllllllllllIIIllllIlllIllII, 0.0D, 0.0D, 0.0D);
    motionX *= 0.30000001192092896D;
    motionY = (Math.random() * 0.20000000298023224D + 0.10000000149011612D);
    motionZ *= 0.30000001192092896D;
    particleRed = 1.0F;
    particleGreen = 1.0F;
    particleBlue = 1.0F;
    llllllllllllllllIIIllllIlllllIII.setParticleTextureIndex(llllIIlIIIl[0]);
    llllllllllllllllIIIllllIlllllIII.setSize(0.01F, 0.01F);
    particleMaxAge = ((int)(8.0D / (Math.random() * 0.8D + 0.2D)));
    particleGravity = 0.0F;
    motionX = llllllllllllllllIIIllllIllllIIll;
    motionY = llllllllllllllllIIIllllIlllIlIlI;
    motionZ = llllllllllllllllIIIllllIlllIlIIl;
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int lllllllllllllllIIlIIIIlIlIlllIlI, World lllllllllllllllIIlIIIIlIlIllIIIl, double lllllllllllllllIIlIIIIlIlIlllIII, double lllllllllllllllIIlIIIIlIlIlIllll, double lllllllllllllllIIlIIIIlIlIllIllI, double lllllllllllllllIIlIIIIlIlIlIllIl, double lllllllllllllllIIlIIIIlIlIllIlII, double lllllllllllllllIIlIIIIlIlIlIlIll, int... lllllllllllllllIIlIIIIlIlIllIIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityFishWakeFX(lllllllllllllllIIlIIIIlIlIllIIIl, lllllllllllllllIIlIIIIlIlIlllIII, lllllllllllllllIIlIIIIlIlIlIllll, lllllllllllllllIIlIIIIlIlIllIllI, lllllllllllllllIIlIIIIlIlIlIllIl, lllllllllllllllIIlIIIIlIlIllIlII, lllllllllllllllIIlIIIIlIlIlIlIll);
    }
    
    public Factory() {}
  }
}

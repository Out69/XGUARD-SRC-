package net.minecraft.client.particle;

import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityReddustFX
  extends EntityFX
{
  private static int lllIIllllllII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static int lllIIlllllIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lllIIlllllIll(int ???)
  {
    double lllllllllllllllIllIIIlIllIIlllll;
    return ??? == 0;
  }
  
  private static void lllIIlllllIIl()
  {
    lIIlIllIIlIl = new int[4];
    lIIlIllIIlIl[0] = ((0x26 ^ 0x64) & (0xCA ^ 0x88 ^ 0xFFFFFFFF));
    lIIlIllIIlIl[1] = " ".length();
    lIIlIllIIlIl[2] = (0x47 ^ 0x40);
    lIIlIllIIlIl[3] = (0xBB ^ 0xB3);
  }
  
  static {}
  
  protected EntityReddustFX(World lllllllllllllllIllIIIlIlllIllIlI, double lllllllllllllllIllIIIlIlllIllIIl, double lllllllllllllllIllIIIlIlllIllIII, double lllllllllllllllIllIIIlIlllIlIlll, float lllllllllllllllIllIIIlIlllIIllII, float lllllllllllllllIllIIIlIlllIIlIll, float lllllllllllllllIllIIIlIlllIIlIlI, float lllllllllllllllIllIIIlIlllIIlIIl)
  {
    lllllllllllllllIllIIIlIlllIllIll.<init>(lllllllllllllllIllIIIlIlllIllIlI, lllllllllllllllIllIIIlIlllIllIIl, lllllllllllllllIllIIIlIlllIllIII, lllllllllllllllIllIIIlIlllIIllIl, 0.0D, 0.0D, 0.0D);
    motionX *= 0.10000000149011612D;
    motionY *= 0.10000000149011612D;
    motionZ *= 0.10000000149011612D;
    if (lllIIlllllIll(lllIIlllllIlI(lllllllllllllllIllIIIlIlllIIlIll, 0.0F))) {
      lllllllllllllllIllIIIlIlllIIlIll = 1.0F;
    }
    float lllllllllllllllIllIIIlIlllIlIIlI = (float)Math.random() * 0.4F + 0.6F;
    particleRed = (((float)(Math.random() * 0.20000000298023224D) + 0.8F) * lllllllllllllllIllIIIlIlllIIlIll * lllllllllllllllIllIIIlIlllIlIIlI);
    particleGreen = (((float)(Math.random() * 0.20000000298023224D) + 0.8F) * lllllllllllllllIllIIIlIlllIIlIlI * lllllllllllllllIllIIIlIlllIlIIlI);
    particleBlue = (((float)(Math.random() * 0.20000000298023224D) + 0.8F) * lllllllllllllllIllIIIlIlllIIlIIl * lllllllllllllllIllIIIlIlllIlIIlI);
    particleScale *= 0.75F;
    particleScale *= lllllllllllllllIllIIIlIlllIIllII;
    reddustParticleScale = particleScale;
    particleMaxAge = ((int)(8.0D / (Math.random() * 0.8D + 0.2D)));
    particleMaxAge = ((int)(particleMaxAge * lllllllllllllllIllIIIlIlllIIllII));
    noClip = lIIlIllIIlIl[0];
  }
  
  private static boolean lllIIlllllllI(int ???)
  {
    String lllllllllllllllIllIIIlIllIlIIIIl;
    return ??? != 0;
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + lIIlIllIIlIl[1]);
    if (lllIIllllllIl(tmp29_26, particleMaxAge)) {
      lllllllllllllllIllIIIlIllIlIIlll.setDead();
    }
    lllllllllllllllIllIIIlIllIlIIlll.setParticleTextureIndex(lIIlIllIIlIl[2] - particleAge * lIIlIllIIlIl[3] / particleMaxAge);
    lllllllllllllllIllIIIlIllIlIIlll.moveEntity(motionX, motionY, motionZ);
    if (lllIIlllllIll(lllIIllllllII(posY, prevPosY)))
    {
      motionX *= 1.1D;
      motionZ *= 1.1D;
    }
    motionX *= 0.9599999785423279D;
    motionY *= 0.9599999785423279D;
    motionZ *= 0.9599999785423279D;
    if (lllIIlllllllI(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  private static boolean lllIIllllllIl(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllIllIIIlIllIlIIIll;
    return ??? >= i;
  }
  
  protected EntityReddustFX(World lllllllllllllllIllIIIlIlllllIlII, double lllllllllllllllIllIIIlIllllIlIll, double lllllllllllllllIllIIIlIllllIlIlI, double lllllllllllllllIllIIIlIlllllIIIl, float lllllllllllllllIllIIIlIlllllIIII, float lllllllllllllllIllIIIlIllllIIlll, float lllllllllllllllIllIIIlIllllIlllI)
  {
    lllllllllllllllIllIIIlIlllllIlIl.<init>(lllllllllllllllIllIIIlIlllllIlII, lllllllllllllllIllIIIlIllllIlIll, lllllllllllllllIllIIIlIllllIlIlI, lllllllllllllllIllIIIlIlllllIIIl, 1.0F, lllllllllllllllIllIIIlIlllllIIII, lllllllllllllllIllIIIlIllllIIlll, lllllllllllllllIllIIIlIllllIlllI);
  }
  
  public void renderParticle(WorldRenderer lllllllllllllllIllIIIlIllIllllII, Entity lllllllllllllllIllIIIlIllIllIIIl, float lllllllllllllllIllIIIlIllIllIIII, float lllllllllllllllIllIIIlIllIlIllll, float lllllllllllllllIllIIIlIllIlIlllI, float lllllllllllllllIllIIIlIllIllIlll, float lllllllllllllllIllIIIlIllIllIllI, float lllllllllllllllIllIIIlIllIllIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIllIIIlIllIllIlII = (particleAge + lllllllllllllllIllIIIlIllIllIIII) / particleMaxAge * 32.0F;
    lllllllllllllllIllIIIlIllIllIlII = MathHelper.clamp_float(lllllllllllllllIllIIIlIllIllIlII, 0.0F, 1.0F);
    particleScale = (reddustParticleScale * lllllllllllllllIllIIIlIllIllIlII);
    lllllllllllllllIllIIIlIllIllllIl.renderParticle(lllllllllllllllIllIIIlIllIllllII, lllllllllllllllIllIIIlIllIllIIIl, lllllllllllllllIllIIIlIllIllIIII, lllllllllllllllIllIIIlIllIlllIIl, lllllllllllllllIllIIIlIllIlIlllI, lllllllllllllllIllIIIlIllIllIlll, lllllllllllllllIllIIIlIllIllIllI, lllllllllllllllIllIIIlIllIllIlIl);
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int lllllllllllllllIlIlIlIIIIIIIlIIl, World lllllllllllllllIlIlIlIIIIIIIIIII, double lllllllllllllllIlIlIIlllllllllll, double lllllllllllllllIlIlIlIIIIIIIIllI, double lllllllllllllllIlIlIlIIIIIIIIlIl, double lllllllllllllllIlIlIIlllllllllII, double lllllllllllllllIlIlIlIIIIIIIIIll, double lllllllllllllllIlIlIIllllllllIlI, int... lllllllllllllllIlIlIlIIIIIIIIIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityReddustFX(lllllllllllllllIlIlIlIIIIIIIIIII, lllllllllllllllIlIlIIlllllllllll, lllllllllllllllIlIlIlIIIIIIIIllI, lllllllllllllllIlIlIlIIIIIIIIlIl, (float)lllllllllllllllIlIlIIlllllllllII, (float)lllllllllllllllIlIlIlIIIIIIIIIll, (float)lllllllllllllllIlIlIIllllllllIlI);
    }
  }
}

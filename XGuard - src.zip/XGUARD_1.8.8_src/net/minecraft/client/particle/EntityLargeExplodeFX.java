package net.minecraft.client.particle;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class EntityLargeExplodeFX
  extends EntityFX
{
  private static void lIIIlIIlIlIl()
  {
    lIlIllIIII = new String[lIlIllIIIl[7]];
    lIlIllIIII[lIlIllIIIl[0]] = lIIIlIIlIlII("FxAbMwwREBBoHA0BCjMATBAbNxUMBgooF00FDSA=", "cucGy");
  }
  
  public void renderParticle(WorldRenderer llIlIll, Entity lllllII, float llllIll, float llllIlI, float llllIIl, float llllIII, float llIIllI, float lllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllIlIl = (int)((field_70581_a + llllIll) * 15.0F / field_70584_aq);
    if (lIIIlIIlIlll(lllIlIl, lIlIllIIIl[3]))
    {
      theRenderEngine.bindTexture(EXPLOSION_TEXTURE);
      float lllIlII = lllIlIl % lIlIllIIIl[2] / 4.0F;
      float lllIIll = lllIlII + 0.24975F;
      float lllIIlI = lllIlIl / lIlIllIIIl[2] / 4.0F;
      float lllIIIl = lllIIlI + 0.24975F;
      float lllIIII = 2.0F * field_70582_as;
      float llIllll = (float)(prevPosX + (posX - prevPosX) * llllIll - interpPosX);
      float llIlllI = (float)(prevPosY + (posY - prevPosY) * llllIll - interpPosY);
      float llIllIl = (float)(prevPosZ + (posZ - prevPosZ) * llllIll - interpPosZ);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.disableLighting();
      RenderHelper.disableStandardItemLighting();
      llIlIll.begin(lIlIllIIIl[4], field_181549_az);
      llIlIll.pos(llIllll - llllIlI * lllIIII - llIIllI * lllIIII, llIlllI - llllIIl * lllIIII, llIllIl - llllIII * lllIIII - lllIllI * lllIIII).tex(lllIIll, lllIIIl).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lIlIllIIIl[0], lIlIllIIIl[5]).normal(0.0F, 1.0F, 0.0F).endVertex();
      llIlIll.pos(llIllll - llllIlI * lllIIII + llIIllI * lllIIII, llIlllI + llllIIl * lllIIII, llIllIl - llllIII * lllIIII + lllIllI * lllIIII).tex(lllIIll, lllIIlI).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lIlIllIIIl[0], lIlIllIIIl[5]).normal(0.0F, 1.0F, 0.0F).endVertex();
      llIlIll.pos(llIllll + llllIlI * lllIIII + llIIllI * lllIIII, llIlllI + llllIIl * lllIIII, llIllIl + llllIII * lllIIII + lllIllI * lllIIII).tex(lllIlII, lllIIlI).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lIlIllIIIl[0], lIlIllIIIl[5]).normal(0.0F, 1.0F, 0.0F).endVertex();
      llIlIll.pos(llIllll + llllIlI * lllIIII - llIIllI * lllIIII, llIlllI - llllIIl * lllIIII, llIllIl + llllIII * lllIIII - lllIllI * lllIIII).tex(lllIlII, lllIIIl).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lIlIllIIIl[0], lIlIllIIIl[5]).normal(0.0F, 1.0F, 0.0F).endVertex();
      Tessellator.getInstance().draw();
      GlStateManager.enableLighting();
    }
  }
  
  protected EntityLargeExplodeFX(TextureManager lIIllllI, World lIIlllIl, double lIIlllII, double lIIllIll, double lIIlIIIl, double lIIllIIl, double lIIllIII, double lIIlIlll)
  {
    lIIlIllI.<init>(lIIlllIl, lIIlllII, lIIlIIlI, lIIlIIIl, 0.0D, 0.0D, 0.0D);
    theRenderEngine = lIIllllI;
    field_70584_aq = (lIlIllIIIl[1] + rand.nextInt(lIlIllIIIl[2]));
    particleRed = (lIIlIllI.particleGreen = lIIlIllI.particleBlue = rand.nextFloat() * 0.6F + 0.4F);
    field_70582_as = (1.0F - (float)lIIllIIl * 0.5F);
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    field_70581_a += lIlIllIIIl[7];
    if (lIIIlIIllIII(field_70581_a, field_70584_aq)) {
      lIllIII.setDead();
    }
  }
  
  static
  {
    lIIIlIIlIllI();
    lIIIlIIlIlIl();
    EXPLOSION_TEXTURE = new ResourceLocation(lIlIllIIII[lIlIllIIIl[0]]);
  }
  
  public int getBrightnessForRender(float lIllIlI)
  {
    return lIlIllIIIl[6];
  }
  
  public int getFXLayer()
  {
    return lIlIllIIIl[8];
  }
  
  private static String lIIIlIIlIlII(String lIIlIll, String lIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIIlIll = new String(Base64.getDecoder().decode(lIIlIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIIlIIl = new StringBuilder();
    char[] lIIlIII = lIIlIlI.toCharArray();
    int lIIIlll = lIlIllIIIl[0];
    boolean lIIIIIl = lIIlIll.toCharArray();
    Exception lIIIIII = lIIIIIl.length;
    Exception llllll = lIlIllIIIl[0];
    while (lIIIlIIllIIl(llllll, lIIIIII))
    {
      char lIIllII = lIIIIIl[llllll];
      "".length();
      "".length();
      if ((0x72 ^ 0x76) < "   ".length()) {
        return null;
      }
    }
    return String.valueOf(lIIlIIl);
  }
  
  private static boolean lIIIlIIlIlll(int ???, int arg1)
  {
    int i;
    String llIIlI;
    return ??? <= i;
  }
  
  private static boolean lIIIlIIllIII(int ???, int arg1)
  {
    int i;
    String lllIlI;
    return ??? == i;
  }
  
  private static void lIIIlIIlIllI()
  {
    lIlIllIIIl = new int[9];
    lIlIllIIIl[0] = ((0xAF ^ 0xBE ^ 0x1F ^ 0x6D) & (0xC2 ^ 0xB1 ^ 0xBC ^ 0xAC ^ -" ".length()));
    lIlIllIIIl[1] = ('Â' + '¯' - 306 + 133 ^ '½' + 92 - 209 + 122);
    lIlIllIIIl[2] = (0x6E ^ 0x0 ^ 0xCF ^ 0xA5);
    lIlIllIIIl[3] = (0xCB ^ 0xC4);
    lIlIllIIIl[4] = (0x2D ^ 0x1B ^ 0x33 ^ 0x2);
    lIlIllIIIl[5] = (124 + 91 - 91 + 27 + (0x44 ^ 0x29) - (34 + 47 - 18 + 140) + (121 + '©' - 217 + 110));
    lIlIllIIIl[6] = (0xF4F4 & 0xFBFB);
    lIlIllIIIl[7] = " ".length();
    lIlIllIIIl[8] = "   ".length();
  }
  
  private static boolean lIIIlIIllIIl(int ???, int arg1)
  {
    int i;
    float llIllI;
    return ??? < i;
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int lIIIIIIIlIIIllI, World lIIIIIIIlIIIlIl, double lIIIIIIIIllllII, double lIIIIIIIlIIIIll, double lIIIIIIIIlllIlI, double lIIIIIIIIlllIIl, double lIIIIIIIlIIIIII, double lIIIIIIIIllIlll, int... lIIIIIIIIlllllI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityLargeExplodeFX(Minecraft.getMinecraft().getTextureManager(), lIIIIIIIlIIIlIl, lIIIIIIIIllllII, lIIIIIIIlIIIIll, lIIIIIIIIlllIlI, lIIIIIIIIlllIIl, lIIIIIIIlIIIIII, lIIIIIIIIllIlll);
    }
  }
}

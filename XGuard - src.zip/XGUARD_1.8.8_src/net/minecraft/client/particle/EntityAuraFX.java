package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.world.World;

public class EntityAuraFX
  extends EntityFX
{
  static {}
  
  private static boolean lIlIlIllllIIll(int ???)
  {
    long llllllllllllllIllllIIIIlIllIIlll;
    return ??? <= 0;
  }
  
  protected EntityAuraFX(World llllllllllllllIllllIIIIlIlllllII, double llllllllllllllIllllIIIIlIllllIll, double llllllllllllllIllllIIIIlIlllIIIl, double llllllllllllllIllllIIIIlIllllIIl, double llllllllllllllIllllIIIIlIllllIII, double llllllllllllllIllllIIIIlIlllIlll, double llllllllllllllIllllIIIIlIlllIllI)
  {
    llllllllllllllIllllIIIIlIlllllIl.<init>(llllllllllllllIllllIIIIlIlllllII, llllllllllllllIllllIIIIlIllllIll, llllllllllllllIllllIIIIlIlllIIIl, llllllllllllllIllllIIIIlIllllIIl, llllllllllllllIllllIIIIlIllllIII, llllllllllllllIllllIIIIlIlllIlll, llllllllllllllIllllIIIIlIlllIllI);
    float llllllllllllllIllllIIIIlIlllIlIl = rand.nextFloat() * 0.1F + 0.2F;
    particleRed = llllllllllllllIllllIIIIlIlllIlIl;
    particleGreen = llllllllllllllIllllIIIIlIlllIlIl;
    particleBlue = llllllllllllllIllllIIIIlIlllIlIl;
    llllllllllllllIllllIIIIlIlllllIl.setParticleTextureIndex(lllIIIIlIIlI[0]);
    llllllllllllllIllllIIIIlIlllllIl.setSize(0.02F, 0.02F);
    particleScale *= (rand.nextFloat() * 0.6F + 0.5F);
    motionX *= 0.019999999552965164D;
    motionY *= 0.019999999552965164D;
    motionZ *= 0.019999999552965164D;
    particleMaxAge = ((int)(20.0D / (Math.random() * 0.8D + 0.2D)));
    noClip = lllIIIIlIIlI[1];
  }
  
  private static void lIlIlIllllIIlI()
  {
    lllIIIIlIIlI = new int[2];
    lllIIIIlIIlI[0] = ((0x2A ^ 0x45 ^ 0x94 ^ 0xA2) & (95 + '' - 201 + 125 ^ '' + 126 - 86 + 3 ^ -" ".length()));
    lllIIIIlIIlI[1] = " ".length();
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    llllllllllllllIllllIIIIlIllIlIIl.moveEntity(motionX, motionY, motionZ);
    motionX *= 0.99D;
    motionY *= 0.99D;
    motionZ *= 0.99D;
    int tmp81_78 = particleMaxAge;
    particleMaxAge = (tmp81_78 - lllIIIIlIIlI[1]);
    if (lIlIlIllllIIll(tmp81_78)) {
      llllllllllllllIllllIIIIlIllIlIIl.setDead();
    }
  }
  
  public static class HappyVillagerFactory
    implements IParticleFactory
  {
    private static void llIllIIIIIIIIl()
    {
      lIIIllIlllllI = new int[1];
      lIIIllIlllllI[0] = ('î' + 'Ï' - 211 + 5 ^ 70 + '' - 132 + 93);
    }
    
    static {}
    
    public HappyVillagerFactory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIlIIlIlIllIIIllIIl, World llllllllllllllIlIIlIlIllIIIIlllI, double llllllllllllllIlIIlIlIllIIIlIlll, double llllllllllllllIlIIlIlIllIIIlIllI, double llllllllllllllIlIIlIlIllIIIIlIll, double llllllllllllllIlIIlIlIllIIIlIlII, double llllllllllllllIlIIlIlIllIIIIlIIl, double llllllllllllllIlIIlIlIllIIIIlIII, int... llllllllllllllIlIIlIlIllIIIlIIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      EntityFX llllllllllllllIlIIlIlIllIIIlIIII = new EntityAuraFX(llllllllllllllIlIIlIlIllIIIIlllI, llllllllllllllIlIIlIlIllIIIlIlll, llllllllllllllIlIIlIlIllIIIlIllI, llllllllllllllIlIIlIlIllIIIIlIll, llllllllllllllIlIIlIlIllIIIlIlII, llllllllllllllIlIIlIlIllIIIIlIIl, llllllllllllllIlIIlIlIllIIIIlIII);
      llllllllllllllIlIIlIlIllIIIlIIII.setParticleTextureIndex(lIIIllIlllllI[0]);
      llllllllllllllIlIIlIlIllIIIlIIII.setRBGColorF(1.0F, 1.0F, 1.0F);
      return llllllllllllllIlIIlIlIllIIIlIIII;
    }
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIIllIIlIIIlIIlIIlI, World llllllllllllllIIllIIlIIIlIIlIIIl, double llllllllllllllIIllIIlIIIlIIIlIII, double llllllllllllllIIllIIlIIIlIIIIlll, double llllllllllllllIIllIIlIIIlIIIlllI, double llllllllllllllIIllIIlIIIlIIIllIl, double llllllllllllllIIllIIlIIIlIIIIlII, double llllllllllllllIIllIIlIIIlIIIIIll, int... llllllllllllllIIllIIlIIIlIIIlIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityAuraFX(llllllllllllllIIllIIlIIIlIIlIIIl, llllllllllllllIIllIIlIIIlIIIlIII, llllllllllllllIIllIIlIIIlIIIIlll, llllllllllllllIIllIIlIIIlIIIlllI, llllllllllllllIIllIIlIIIlIIIllIl, llllllllllllllIIllIIlIIIlIIIIlII, llllllllllllllIIllIIlIIIlIIIIIll);
    }
  }
}

package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityRainFX
  extends EntityFX
{
  private static int lllIIlIIllI(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean lllIIlIIlll(int ???)
  {
    double lIlIIllIIllII;
    return ??? <= 0;
  }
  
  protected EntityRainFX(World lIlIIllllIIIl, double lIlIIlllIlIll, double lIlIIlllIllll, double lIlIIlllIlllI)
  {
    lIlIIlllIllIl.<init>(lIlIIllllIIIl, lIlIIllllIIII, lIlIIlllIllll, lIlIIlllIlllI, 0.0D, 0.0D, 0.0D);
    motionX *= 0.30000001192092896D;
    motionY = (Math.random() * 0.20000000298023224D + 0.10000000149011612D);
    motionZ *= 0.30000001192092896D;
    particleRed = 1.0F;
    particleGreen = 1.0F;
    particleBlue = 1.0F;
    lIlIIlllIllIl.setParticleTextureIndex(lIIIlIllIl[0] + rand.nextInt(lIIIlIllIl[1]));
    lIlIIlllIllIl.setSize(0.01F, 0.01F);
    particleGravity = 0.06F;
    particleMaxAge = ((int)(8.0D / (Math.random() * 0.8D + 0.2D)));
  }
  
  public void onUpdate()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    motionY -= particleGravity;
    lIlIIllIllIlI.moveEntity(motionX, motionY, motionZ);
    motionX *= 0.9800000190734863D;
    motionY *= 0.9800000190734863D;
    motionZ *= 0.9800000190734863D;
    int tmp95_92 = particleMaxAge;
    particleMaxAge = (tmp95_92 - lIIIlIllIl[2]);
    if (lllIIlIIlll(tmp95_92)) {
      lIlIIllIllIlI.setDead();
    }
    if (lllIIlIlIII(onGround))
    {
      if (lllIIlIlIIl(lllIIlIIllI(Math.random(), 0.5D))) {
        lIlIIllIllIlI.setDead();
      }
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
    BlockPos lIlIIlllIIIII = new BlockPos(lIlIIllIllIlI);
    IBlockState lIlIIllIlllll = worldObj.getBlockState(lIlIIlllIIIII);
    Block lIlIIllIllllI = lIlIIllIlllll.getBlock();
    lIlIIllIllllI.setBlockBoundsBasedOnState(worldObj, lIlIIlllIIIII);
    Material lIlIIllIlllIl = lIlIIllIlllll.getBlock().getMaterial();
    if ((!lllIIlIlIlI(lIlIIllIlllIl.isLiquid())) || (lllIIlIlIII(lIlIIllIlllIl.isSolid())))
    {
      double lIlIIllIlllII = 0.0D;
      if (lllIIlIlIII(lIlIIllIlllll.getBlock() instanceof BlockLiquid))
      {
        lIlIIllIlllII = 1.0F - BlockLiquid.getLiquidHeightPercent(((Integer)lIlIIllIlllll.getValue(BlockLiquid.LEVEL)).intValue());
        "".length();
        if (null == null) {}
      }
      else
      {
        lIlIIllIlllII = lIlIIllIllllI.getBlockBoundsMaxY();
      }
      double lIlIIllIllIll = MathHelper.floor_double(posY) + lIlIIllIlllII;
      if (lllIIlIlIIl(lllIIlIIllI(posY, lIlIIllIllIll))) {
        lIlIIllIllIlI.setDead();
      }
    }
  }
  
  private static void lllIIlIIlIl()
  {
    lIIIlIllIl = new int[3];
    lIIIlIllIl[0] = (0x31 ^ 0x22);
    lIIIlIllIl[1] = ('' + 123 - 102 + 4 ^ 6 + 51 - -42 + 60);
    lIIIlIllIl[2] = " ".length();
  }
  
  private static boolean lllIIlIlIIl(int ???)
  {
    String lIlIIllIIlllI;
    return ??? < 0;
  }
  
  static {}
  
  private static boolean lllIIlIlIII(int ???)
  {
    byte lIlIIllIlIIlI;
    return ??? != 0;
  }
  
  private static boolean lllIIlIlIlI(int ???)
  {
    Exception lIlIIllIlIIII;
    return ??? == 0;
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int lllllllllllllllllIIlIlIIllIlIIlI, World lllllllllllllllllIIlIlIIllIlIIIl, double lllllllllllllllllIIlIlIIllIIlIII, double lllllllllllllllllIIlIlIIllIIllll, double lllllllllllllllllIIlIlIIllIIIllI, double lllllllllllllllllIIlIlIIllIIllIl, double lllllllllllllllllIIlIlIIllIIllII, double lllllllllllllllllIIlIlIIllIIlIll, int... lllllllllllllllllIIlIlIIllIIlIlI)
    {
      ;
      ;
      ;
      ;
      return new EntityRainFX(lllllllllllllllllIIlIlIIllIlIIIl, lllllllllllllllllIIlIlIIllIIlIII, lllllllllllllllllIIlIlIIllIIllll, lllllllllllllllllIIlIlIIllIIIllI);
    }
  }
}

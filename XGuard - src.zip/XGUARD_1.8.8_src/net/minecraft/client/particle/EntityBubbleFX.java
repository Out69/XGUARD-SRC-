package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class EntityBubbleFX
  extends EntityFX
{
  static {}
  
  private static boolean lIIIIllIIIIIlI(Object ???, Object arg1)
  {
    Object localObject;
    char lllllllllllllllIIllllIllIlIIllII;
    return ??? != localObject;
  }
  
  protected EntityBubbleFX(World lllllllllllllllIIllllIllIlIllIIl, double lllllllllllllllIIllllIllIllIIIII, double lllllllllllllllIIllllIllIlIlllll, double lllllllllllllllIIllllIllIlIllllI, double lllllllllllllllIIllllIllIlIlllIl, double lllllllllllllllIIllllIllIlIlllII, double lllllllllllllllIIllllIllIlIllIll)
  {
    lllllllllllllllIIllllIllIlIllIlI.<init>(lllllllllllllllIIllllIllIlIllIIl, lllllllllllllllIIllllIllIllIIIII, lllllllllllllllIIllllIllIlIlllll, lllllllllllllllIIllllIllIlIllllI, lllllllllllllllIIllllIllIlIlllIl, lllllllllllllllIIllllIllIlIlllII, lllllllllllllllIIllllIllIlIllIll);
    particleRed = 1.0F;
    particleGreen = 1.0F;
    particleBlue = 1.0F;
    lllllllllllllllIIllllIllIlIllIlI.setParticleTextureIndex(lIlIllIllIII[0]);
    lllllllllllllllIIllllIllIlIllIlI.setSize(0.02F, 0.02F);
    particleScale *= (rand.nextFloat() * 0.6F + 0.2F);
    motionX = (lllllllllllllllIIllllIllIlIlllIl * 0.20000000298023224D + (Math.random() * 2.0D - 1.0D) * 0.019999999552965164D);
    motionY = (lllllllllllllllIIllllIllIlIlllII * 0.20000000298023224D + (Math.random() * 2.0D - 1.0D) * 0.019999999552965164D);
    motionZ = (lllllllllllllllIIllllIllIlIllIll * 0.20000000298023224D + (Math.random() * 2.0D - 1.0D) * 0.019999999552965164D);
    particleMaxAge = ((int)(8.0D / (Math.random() * 0.8D + 0.2D)));
  }
  
  private static void lIIIIlIllllllI()
  {
    lIlIllIllIII = new int[2];
    lIlIllIllIII[0] = (0xA ^ 0x69 ^ 0x35 ^ 0x76);
    lIlIllIllIII[1] = " ".length();
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    motionY += 0.002D;
    lllllllllllllllIIllllIllIlIlIIIl.moveEntity(motionX, motionY, motionZ);
    motionX *= 0.8500000238418579D;
    motionY *= 0.8500000238418579D;
    motionZ *= 0.8500000238418579D;
    if (lIIIIllIIIIIlI(worldObj.getBlockState(new BlockPos(lllllllllllllllIIllllIllIlIlIIIl)).getBlock().getMaterial(), Material.water)) {
      lllllllllllllllIIllllIllIlIlIIIl.setDead();
    }
    int tmp129_126 = particleMaxAge;
    particleMaxAge = (tmp129_126 - lIlIllIllIII[1]);
    if (lIIIIllIIIIlII(tmp129_126)) {
      lllllllllllllllIIllllIllIlIlIIIl.setDead();
    }
  }
  
  private static boolean lIIIIllIIIIlII(int ???)
  {
    float lllllllllllllllIIllllIllIlIIlIlI;
    return ??? <= 0;
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int lllllllllllllllIlllIllIlIIlIllIl, World lllllllllllllllIlllIllIlIIlIllII, double lllllllllllllllIlllIllIlIIlIIIll, double lllllllllllllllIlllIllIlIIlIIIlI, double lllllllllllllllIlllIllIlIIlIlIIl, double lllllllllllllllIlllIllIlIIlIIIII, double lllllllllllllllIlllIllIlIIIlllll, double lllllllllllllllIlllIllIlIIIllllI, int... lllllllllllllllIlllIllIlIIlIIlIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityBubbleFX(lllllllllllllllIlllIllIlIIlIllII, lllllllllllllllIlllIllIlIIlIIIll, lllllllllllllllIlllIllIlIIlIIIlI, lllllllllllllllIlllIllIlIIlIlIIl, lllllllllllllllIlllIllIlIIlIIIII, lllllllllllllllIlllIllIlIIIlllll, lllllllllllllllIlllIllIlIIIllllI);
    }
  }
}

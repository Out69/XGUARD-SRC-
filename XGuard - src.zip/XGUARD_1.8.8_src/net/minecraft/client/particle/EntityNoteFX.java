package net.minecraft.client.particle;

import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityNoteFX
  extends EntityFX
{
  protected EntityNoteFX(World lllllllllllllllIIllIlIIlIIIlIlII, double lllllllllllllllIIllIlIIlIIIlIIll, double lllllllllllllllIIllIlIIlIIIlIIlI, double lllllllllllllllIIllIlIIlIIIlIIIl, double lllllllllllllllIIllIlIIlIIIIlIII, double lllllllllllllllIIllIlIIlIIIIllll, double lllllllllllllllIIllIlIIlIIIIIllI)
  {
    lllllllllllllllIIllIlIIlIIIIllIl.<init>(lllllllllllllllIIllIlIIlIIIlIlII, lllllllllllllllIIllIlIIlIIIlIIll, lllllllllllllllIIllIlIIlIIIlIIlI, lllllllllllllllIIllIlIIlIIIlIIIl, lllllllllllllllIIllIlIIlIIIIlIII, lllllllllllllllIIllIlIIlIIIIllll, lllllllllllllllIIllIlIIlIIIIIllI, 2.0F);
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + lIllIIlllllI[3]);
    if (lIIIlIlIllIllI(tmp29_26, particleMaxAge)) {
      lllllllllllllllIIllIlIIIllIIlllI.setDead();
    }
    lllllllllllllllIIllIlIIIllIIlllI.moveEntity(motionX, motionY, motionZ);
    if (lIIIlIlIllIlll(lIIIlIlIllIlIl(posY, prevPosY)))
    {
      motionX *= 1.1D;
      motionZ *= 1.1D;
    }
    motionX *= 0.6600000262260437D;
    motionY *= 0.6600000262260437D;
    motionZ *= 0.6600000262260437D;
    if (lIIIlIlIlllIII(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  protected EntityNoteFX(World lllllllllllllllIIllIlIIIllllllIl, double lllllllllllllllIIllIlIIIllllIIll, double lllllllllllllllIIllIlIIIlllllIll, double lllllllllllllllIIllIlIIIlllllIlI, double lllllllllllllllIIllIlIIIllllIIII, double lllllllllllllllIIllIlIIIlllllIII, double lllllllllllllllIIllIlIIIllllIlll, float lllllllllllllllIIllIlIIIlllIllll)
  {
    lllllllllllllllIIllIlIIIlllllllI.<init>(lllllllllllllllIIllIlIIIllllllIl, lllllllllllllllIIllIlIIIllllIIll, lllllllllllllllIIllIlIIIlllllIll, lllllllllllllllIIllIlIIIllllIIIl, 0.0D, 0.0D, 0.0D);
    motionX *= 0.009999999776482582D;
    motionY *= 0.009999999776482582D;
    motionZ *= 0.009999999776482582D;
    motionY += 0.2D;
    particleRed = (MathHelper.sin(((float)lllllllllllllllIIllIlIIIllllIIII + 0.0F) * 3.1415927F * 2.0F) * 0.65F + 0.35F);
    particleGreen = (MathHelper.sin(((float)lllllllllllllllIIllIlIIIllllIIII + 0.33333334F) * 3.1415927F * 2.0F) * 0.65F + 0.35F);
    particleBlue = (MathHelper.sin(((float)lllllllllllllllIIllIlIIIllllIIII + 0.6666667F) * 3.1415927F * 2.0F) * 0.65F + 0.35F);
    particleScale *= 0.75F;
    particleScale *= lllllllllllllllIIllIlIIIlllIllll;
    noteParticleScale = particleScale;
    particleMaxAge = lIllIIlllllI[0];
    noClip = lIllIIlllllI[1];
    lllllllllllllllIIllIlIIIlllllllI.setParticleTextureIndex(lIllIIlllllI[2]);
  }
  
  private static int lIIIlIlIllIlIl(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static void lIIIlIlIllIlII()
  {
    lIllIIlllllI = new int[4];
    lIllIIlllllI[0] = (46 + 105 - -7 + 37 ^ 105 + 97 - 85 + 80);
    lIllIIlllllI[1] = ((0x36 ^ 0x2 ^ " ".length()) & (0x26 ^ 0x10 ^ "   ".length() ^ -" ".length()));
    lIllIIlllllI[2] = (0x6E ^ 0x13 ^ 0x24 ^ 0x19);
    lIllIIlllllI[3] = " ".length();
  }
  
  public void renderParticle(WorldRenderer lllllllllllllllIIllIlIIIlllIIIll, Entity lllllllllllllllIIllIlIIIlllIIIlI, float lllllllllllllllIIllIlIIIllIlIlll, float lllllllllllllllIIllIlIIIlllIIIII, float lllllllllllllllIIllIlIIIllIlllll, float lllllllllllllllIIllIlIIIllIlIlII, float lllllllllllllllIIllIlIIIllIlIIll, float lllllllllllllllIIllIlIIIllIlIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIIllIlIIIllIllIll = (particleAge + lllllllllllllllIIllIlIIIllIlIlll) / particleMaxAge * 32.0F;
    lllllllllllllllIIllIlIIIllIllIll = MathHelper.clamp_float(lllllllllllllllIIllIlIIIllIllIll, 0.0F, 1.0F);
    particleScale = (noteParticleScale * lllllllllllllllIIllIlIIIllIllIll);
    lllllllllllllllIIllIlIIIllIllIlI.renderParticle(lllllllllllllllIIllIlIIIlllIIIll, lllllllllllllllIIllIlIIIlllIIIlI, lllllllllllllllIIllIlIIIllIlIlll, lllllllllllllllIIllIlIIIllIlIllI, lllllllllllllllIIllIlIIIllIlllll, lllllllllllllllIIllIlIIIllIlIlII, lllllllllllllllIIllIlIIIllIlIIll, lllllllllllllllIIllIlIIIllIlIIlI);
  }
  
  private static boolean lIIIlIlIllIlll(int ???)
  {
    String lllllllllllllllIIllIlIIIllIIIllI;
    return ??? == 0;
  }
  
  private static boolean lIIIlIlIllIllI(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIIllIlIIIllIIlIlI;
    return ??? >= i;
  }
  
  private static boolean lIIIlIlIlllIII(int ???)
  {
    int lllllllllllllllIIllIlIIIllIIlIII;
    return ??? != 0;
  }
  
  static {}
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIlIlIlIlllIllIIIlI, World llllllllllllllIlIlIlIlllIlIllIIl, double llllllllllllllIlIlIlIlllIlIllIII, double llllllllllllllIlIlIlIlllIlIlllll, double llllllllllllllIlIlIlIlllIlIllllI, double llllllllllllllIlIlIlIlllIlIlIlIl, double llllllllllllllIlIlIlIlllIlIlIlII, double llllllllllllllIlIlIlIlllIlIllIll, int... llllllllllllllIlIlIlIlllIlIllIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityNoteFX(llllllllllllllIlIlIlIlllIlIllIIl, llllllllllllllIlIlIlIlllIlIllIII, llllllllllllllIlIlIlIlllIlIlllll, llllllllllllllIlIlIlIlllIlIllllI, llllllllllllllIlIlIlIlllIlIlIlIl, llllllllllllllIlIlIlIlllIlIlIlII, llllllllllllllIlIlIlIlllIlIllIll);
    }
  }
}

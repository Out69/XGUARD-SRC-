package net.minecraft.client.particle;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityFirework
{
  public EntityFirework() {}
  
  public static class StarterFX
    extends EntityFX
  {
    private static boolean llIllllIIIllI(int ???)
    {
      boolean lllllllllllllllIllIllIIIIlIlllII;
      return ??? > 0;
    }
    
    private static boolean llIllllIIIIII(int ???, int arg1)
    {
      int i;
      short lllllllllllllllIllIllIIIIllIlllI;
      return ??? >= i;
    }
    
    private static boolean llIllllIIIlll(int ???, int arg1)
    {
      int i;
      double lllllllllllllllIllIllIIIIlIllIII;
      return ??? != i;
    }
    
    public void renderParticle(WorldRenderer lllllllllllllllIllIllIIllIlIIlll, Entity lllllllllllllllIllIllIIllIlIIllI, float lllllllllllllllIllIllIIllIlIIlIl, float lllllllllllllllIllIllIIllIlIIlII, float lllllllllllllllIllIllIIllIlIIIll, float lllllllllllllllIllIllIIllIlIIIlI, float lllllllllllllllIllIllIIllIlIIIIl, float lllllllllllllllIllIllIIllIlIIIII) {}
    
    private static String llIlllIlllIlI(String lllllllllllllllIllIllIIIlIIlllIl, String lllllllllllllllIllIllIIIlIIlllII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIllIllIIIlIIlllIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIllIIIlIIlllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllIllIIIlIIllIll = new StringBuilder();
      char[] lllllllllllllllIllIllIIIlIIllIlI = lllllllllllllllIllIllIIIlIIlllII.toCharArray();
      int lllllllllllllllIllIllIIIlIIllIIl = lIIIllllIlII[1];
      char lllllllllllllllIllIllIIIlIIlIIll = lllllllllllllllIllIllIIIlIIlllIl.toCharArray();
      String lllllllllllllllIllIllIIIlIIlIIlI = lllllllllllllllIllIllIIIlIIlIIll.length;
      char lllllllllllllllIllIllIIIlIIlIIIl = lIIIllllIlII[1];
      while (llIllllIIIIlI(lllllllllllllllIllIllIIIlIIlIIIl, lllllllllllllllIllIllIIIlIIlIIlI))
      {
        char lllllllllllllllIllIllIIIlIIllllI = lllllllllllllllIllIllIIIlIIlIIll[lllllllllllllllIllIllIIIlIIlIIIl];
        "".length();
        "".length();
        if ("   ".length() < -" ".length()) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIllIllIIIlIIllIll);
    }
    
    private static boolean llIllllIIIIll(int ???, int arg1)
    {
      int i;
      char lllllllllllllllIllIllIIIIllIIllI;
      return ??? > i;
    }
    
    private static boolean llIlllIlllllI(int ???)
    {
      char lllllllllllllllIllIllIIIIllIIIII;
      return ??? == 0;
    }
    
    private static void llIlllIlllIll()
    {
      lIIIllllIIll = new String[lIIIllllIlII[15]];
      lIIIllllIIll[lIIIllllIlII[1]] = llIlllIlllIII("NTaMdhOGLapWQSwLgg+Z2g==", "moAHd");
      lIIIllllIIll[lIIIllllIlII[4]] = llIlllIlllIII("xFe7L9Jcpk8=", "zewjS");
      lIIIllllIIll[lIIIllllIlII[3]] = llIlllIlllIIl("w9aKmRlp3Ms=", "myClG");
      lIIIllllIIll[lIIIllllIlII[6]] = llIlllIlllIII("6wWHtN6JuhksvgPuA3byvQ==", "axino");
      lIIIllllIIll[lIIIllllIlII[7]] = llIlllIlllIlI("LTEcCD8DPA8cLg==", "APnoZ");
      lIIIllllIIll[lIIIllllIlII[8]] = llIlllIlllIII("PukjXwqBMN8=", "YunLY");
      lIIIllllIIll[lIIIllllIlII[9]] = llIlllIlllIlI("EyQlAw==", "LBDqN");
      lIIIllllIIll[lIIIllllIlII[10]] = llIlllIlllIlI("", "vkTNS");
      lIIIllllIIll[lIIIllllIlII[0]] = llIlllIlllIIl("3hnPL16onHk=", "fXnvM");
      lIIIllllIIll[lIIIllllIlII[11]] = llIlllIlllIlI("Fz8QGBU=", "CMqqy");
      lIIIllllIIll[lIIIllllIlII[2]] = llIlllIlllIIl("A0uk/FNGDlg=", "SzxTP");
      lIIIllllIIll[lIIIllllIlII[12]] = llIlllIlllIII("c3AwN59eR0s=", "MnaJB");
      lIIIllllIIll[lIIIllllIlII[13]] = llIlllIlllIlI("KTkgMwUANCskNQ==", "oXDVF");
      lIIIllllIIll[lIIIllllIlII[18]] = llIlllIlllIIl("4eTkEEoYcNJtDq56SUZGCw==", "FdCtw");
      lIIIllllIIll[lIIIllllIlII[19]] = llIlllIlllIII("pYs/lLBKsvmbMUNOcW6tiA==", "HdvUo");
      lIIIllllIIll[lIIIllllIlII[5]] = llIlllIlllIIl("+oELuQrVaDs=", "vesqU");
    }
    
    private static void llIlllIllllII()
    {
      lIIIllllIlII = new int[21];
      lIIIllllIlII[0] = (0xB7 ^ 0xBF);
      lIIIllllIlII[1] = ((0xBC ^ 0xB8) & (0xA2 ^ 0xA6 ^ 0xFFFFFFFF));
      lIIIllllIlII[2] = (0xBB ^ 0xB1);
      lIIIllllIlII[3] = "  ".length();
      lIIIllllIlII[4] = " ".length();
      lIIIllllIlII[5] = (0x2 ^ 0xD);
      lIIIllllIlII[6] = "   ".length();
      lIIIllllIlII[7] = (117 + '' - 249 + 141 ^ '' + 62 - 105 + 67);
      lIIIllllIlII[8] = (0x5F ^ 0x77 ^ 0x41 ^ 0x6C);
      lIIIllllIlII[9] = (0x16 ^ 0x10);
      lIIIllllIlII[10] = (0xA3 ^ 0xA4);
      lIIIllllIlII[11] = (0xA ^ 0x3D ^ 0x8E ^ 0xB0);
      lIIIllllIlII[12] = (0x7E ^ 0x75);
      lIIIllllIlII[13] = (0x56 ^ 0x44 ^ 0x35 ^ 0x2B);
      lIIIllllIlII[14] = (0x89ED & 0xFF7612);
      lIIIllllIlII[15] = (0x61 ^ 0x71);
      lIIIllllIlII[16] = (-(114 + 14 - 44 + 139) & 0xFFFFFFDF & 0xFFFE);
      lIIIllllIlII[17] = ('' + '¡' - 116 + 28 + (0xD2 ^ 0x8C) - (76 + 27 - 0 + 92) + (27 + 109 - 113 + 104));
      lIIIllllIlII[18] = (0x7E ^ 0x6A ^ 0x39 ^ 0x20);
      lIIIllllIlII[19] = (39 + 59 - -15 + 34 ^ 59 + 111 - 58 + 45);
      lIIIllllIlII[20] = (0x4A ^ 0xC);
    }
    
    public void onUpdate()
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      if ((llIlllIlllllI(fireworkAge)) && (llIlllIllllIl(fireworkExplosions)))
      {
        boolean lllllllllllllllIllIllIIllIIlIIIl = lllllllllllllllIllIllIIllIIlIIlI.func_92037_i();
        boolean lllllllllllllllIllIllIIllIIlIIII = lIIIllllIlII[1];
        if (llIllllIIIIII(fireworkExplosions.tagCount(), lIIIllllIlII[6]))
        {
          lllllllllllllllIllIllIIllIIlIIII = lIIIllllIlII[4];
          "".length();
          if (((0x47 ^ 0x8 ^ 0x10 ^ 0x7C) & (0xC0 ^ 0x9A ^ 0x25 ^ 0x5C ^ -" ".length())) == 0) {}
        }
        else
        {
          int lllllllllllllllIllIllIIllIIIllll = lIIIllllIlII[1];
          "".length();
          if (((40 + 106 - 122 + 167 ^ '' + '' - 158 + 61) & (0x46 ^ 0x5B ^ 0xB4 ^ 0xBD ^ -" ".length())) != 0) {
            return;
          }
          while (!llIllllIIIIII(lllllllllllllllIllIllIIllIIIllll, fireworkExplosions.tagCount()))
          {
            NBTTagCompound lllllllllllllllIllIllIIllIIIlllI = fireworkExplosions.getCompoundTagAt(lllllllllllllllIllIllIIllIIIllll);
            if (llIllllIIIIIl(lllllllllllllllIllIllIIllIIIlllI.getByte(lIIIllllIIll[lIIIllllIlII[3]]), lIIIllllIlII[4]))
            {
              lllllllllllllllIllIllIIllIIlIIII = lIIIllllIlII[4];
              "".length();
              if ("  ".length() > ((0x2B ^ 0x1B ^ 0x32 ^ 0x38) & (25 + 12 - -113 + 25 ^ 109 + 74 - 79 + 45 ^ -" ".length()))) {
                break;
              }
              return;
            }
            lllllllllllllllIllIllIIllIIIllll++;
          }
        }
        new StringBuilder(lIIIllllIIll[lIIIllllIlII[6]]);
        if (llIlllIllllll(lllllllllllllllIllIllIIllIIlIIII))
        {
          "".length();
          if ("   ".length() > ((0x84 ^ 0x89 ^ 0x41 ^ 0x45) & (0xD7 ^ 0x85 ^ 0x74 ^ 0x2F ^ -" ".length()))) {
            break label370;
          }
        }
        label370:
        if (llIlllIllllll(lllllllllllllllIllIllIIllIIlIIIl))
        {
          "".length();
          if (-" ".length() <= -" ".length()) {
            break label422;
          }
        }
        label422:
        String lllllllllllllllIllIllIIllIIIllIl = String.valueOf(lIIIllllIIll[lIIIllllIlII[9]].append(lIIIllllIIll[lIIIllllIlII[10]]));
        worldObj.playSound(posX, posY, posZ, lllllllllllllllIllIllIIllIIIllIl, 20.0F, 0.95F + rand.nextFloat() * 0.1F, lIIIllllIlII[4]);
      }
      if ((llIlllIlllllI(fireworkAge % lIIIllllIlII[3])) && (llIlllIllllIl(fireworkExplosions)) && (llIllllIIIIlI(fireworkAge / lIIIllllIlII[3], fireworkExplosions.tagCount())))
      {
        int lllllllllllllllIllIllIIllIIIllII = fireworkAge / lIIIllllIlII[3];
        NBTTagCompound lllllllllllllllIllIllIIllIIIlIll = fireworkExplosions.getCompoundTagAt(lllllllllllllllIllIllIIllIIIllII);
        int lllllllllllllllIllIllIIllIIIlIlI = lllllllllllllllIllIllIIllIIIlIll.getByte(lIIIllllIIll[lIIIllllIlII[0]]);
        boolean lllllllllllllllIllIllIIllIIIlIIl = lllllllllllllllIllIllIIllIIIlIll.getBoolean(lIIIllllIIll[lIIIllllIlII[11]]);
        boolean lllllllllllllllIllIllIIllIIIlIII = lllllllllllllllIllIllIIllIIIlIll.getBoolean(lIIIllllIIll[lIIIllllIlII[2]]);
        int[] lllllllllllllllIllIllIIllIIIIlll = lllllllllllllllIllIllIIllIIIlIll.getIntArray(lIIIllllIIll[lIIIllllIlII[12]]);
        int[] lllllllllllllllIllIllIIllIIIIllI = lllllllllllllllIllIllIIllIIIlIll.getIntArray(lIIIllllIIll[lIIIllllIlII[13]]);
        if (llIlllIlllllI(lllllllllllllllIllIllIIllIIIIlll.length)) {
          lllllllllllllllIllIllIIllIIIIlll = new int[] { net.minecraft.item.ItemDye.dyeColors[lIIIllllIlII[1]] };
        }
        if (llIllllIIIIIl(lllllllllllllllIllIllIIllIIIlIlI, lIIIllllIlII[4]))
        {
          lllllllllllllllIllIllIIllIIlIIlI.createBall(0.5D, lIIIllllIlII[7], lllllllllllllllIllIllIIllIIIIlll, lllllllllllllllIllIllIIllIIIIllI, lllllllllllllllIllIllIIllIIIlIIl, lllllllllllllllIllIllIIllIIIlIII);
          "".length();
          if ("   ".length() > ((0xF ^ 0x24 ^ 0x44 ^ 0x34) & (0x79 ^ 0x35 ^ 0x8 ^ 0x1F ^ -" ".length()))) {}
        }
        else if (llIllllIIIIIl(lllllllllllllllIllIllIIllIIIlIlI, lIIIllllIlII[3]))
        {
          lllllllllllllllIllIllIIllIIlIIlI.createShaped(0.5D, new double[][] { { 0.0D, 1.0D }, { 0.3455D, 0.309D }, { 0.9511D, 0.309D }, { 0.3795918367346939D, -0.12653061224489795D }, { 0.6122448979591837D, -0.8040816326530612D }, { 0.0D, -0.35918367346938773D } }, lllllllllllllllIllIllIIllIIIIlll, lllllllllllllllIllIllIIllIIIIllI, lllllllllllllllIllIllIIllIIIlIIl, lllllllllllllllIllIllIIllIIIlIII, lIIIllllIlII[1]);
          "".length();
          if (-(0x8 ^ 0xD) < 0) {}
        }
        else if (llIllllIIIIIl(lllllllllllllllIllIllIIllIIIlIlI, lIIIllllIlII[6]))
        {
          lllllllllllllllIllIllIIllIIlIIlI.createShaped(0.5D, new double[][] { { 0.0D, 0.2D }, { 0.2D, 0.2D }, { 0.2D, 0.6D }, { 0.6D, 0.6D }, { 0.6D, 0.2D }, { 0.2D, 0.2D }, { 0.2D, 0.0D }, { 0.4D, 0.0D }, { 0.4D, -0.6D }, { 0.2D, -0.6D }, { 0.2D, -0.4D }, { 0.0D, -0.4D } }, lllllllllllllllIllIllIIllIIIIlll, lllllllllllllllIllIllIIllIIIIllI, lllllllllllllllIllIllIIllIIIlIIl, lllllllllllllllIllIllIIllIIIlIII, lIIIllllIlII[4]);
          "".length();
          if ("  ".length() >= ((0xFD ^ 0x9D ^ 0xC3 ^ 0xA4) & ('' + 60 - 143 + 147 ^ 57 + 91 - 117 + 162 ^ -" ".length()))) {}
        }
        else if (llIllllIIIIIl(lllllllllllllllIllIllIIllIIIlIlI, lIIIllllIlII[7]))
        {
          lllllllllllllllIllIllIIllIIlIIlI.createBurst(lllllllllllllllIllIllIIllIIIIlll, lllllllllllllllIllIllIIllIIIIllI, lllllllllllllllIllIllIIllIIIlIIl, lllllllllllllllIllIllIIllIIIlIII);
          "".length();
          if ("   ".length() != 0) {}
        }
        else
        {
          lllllllllllllllIllIllIIllIIlIIlI.createBall(0.25D, lIIIllllIlII[3], lllllllllllllllIllIllIIllIIIIlll, lllllllllllllllIllIllIIllIIIIllI, lllllllllllllllIllIllIIllIIIlIIl, lllllllllllllllIllIllIIllIIIlIII);
        }
        int lllllllllllllllIllIllIIllIIIIlIl = lllllllllllllllIllIllIIllIIIIlll[lIIIllllIlII[1]];
        float lllllllllllllllIllIllIIllIIIIlII = ((lllllllllllllllIllIllIIllIIIIlIl & lIIIllllIlII[14]) >> lIIIllllIlII[15]) / 255.0F;
        float lllllllllllllllIllIllIIllIIIIIll = ((lllllllllllllllIllIllIIllIIIIlIl & lIIIllllIlII[16]) >> lIIIllllIlII[0]) / 255.0F;
        float lllllllllllllllIllIllIIllIIIIIlI = ((lllllllllllllllIllIllIIllIIIIlIl & lIIIllllIlII[17]) >> lIIIllllIlII[1]) / 255.0F;
        EntityFirework.OverlayFX lllllllllllllllIllIllIIllIIIIIIl = new EntityFirework.OverlayFX(worldObj, posX, posY, posZ);
        lllllllllllllllIllIllIIllIIIIIIl.setRBGColorF(lllllllllllllllIllIllIIllIIIIlII, lllllllllllllllIllIllIIllIIIIIll, lllllllllllllllIllIllIIllIIIIIlI);
        theEffectRenderer.addEffect(lllllllllllllllIllIllIIllIIIIIIl);
      }
      fireworkAge += lIIIllllIlII[4];
      if (llIllllIIIIll(fireworkAge, particleMaxAge))
      {
        if (llIlllIllllll(twinkle))
        {
          boolean lllllllllllllllIllIllIIllIIIIIII = lllllllllllllllIllIllIIllIIlIIlI.func_92037_i();
          new StringBuilder(lIIIllllIIll[lIIIllllIlII[18]]);
          if (llIlllIllllll(lllllllllllllllIllIllIIllIIIIIII))
          {
            "".length();
            if (('' + '' - 271 + 143 ^ 106 + 66 - 88 + 61) != 0) {
              break label1807;
            }
          }
          label1807:
          String lllllllllllllllIllIllIIlIlllllll = String.valueOf(lIIIllllIIll[lIIIllllIlII[19]].append(lIIIllllIIll[lIIIllllIlII[5]]));
          worldObj.playSound(posX, posY, posZ, lllllllllllllllIllIllIIlIlllllll, 20.0F, 0.9F + rand.nextFloat() * 0.15F, lIIIllllIlII[4]);
        }
        lllllllllllllllIllIllIIllIIlIIlI.setDead();
      }
    }
    
    private static boolean llIllllIIIlIl(int ???)
    {
      String lllllllllllllllIllIllIIIIlIllllI;
      return ??? < 0;
    }
    
    static
    {
      llIlllIllllII();
      llIlllIlllIll();
    }
    
    private void createBall(double lllllllllllllllIllIllIIlIIlIIIIl, int lllllllllllllllIllIllIIlIIlIIIII, int[] lllllllllllllllIllIllIIlIIIlllll, int[] lllllllllllllllIllIllIIlIIIllllI, boolean lllllllllllllllIllIllIIlIIlIlllI, boolean lllllllllllllllIllIllIIlIIIlllII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      double lllllllllllllllIllIllIIlIIlIllII = posX;
      double lllllllllllllllIllIllIIlIIlIlIll = posY;
      double lllllllllllllllIllIllIIlIIlIlIlI = posZ;
      int lllllllllllllllIllIllIIlIIlIlIIl = -lllllllllllllllIllIllIIlIIlIIIII;
      "".length();
      if (((0xEA ^ 0xB7 ^ 0x5A ^ 0x2E) & (0xCC ^ 0x93 ^ 0x23 ^ 0x55 ^ -" ".length())) != 0) {
        return;
      }
      while (!llIllllIIIIll(lllllllllllllllIllIllIIlIIlIlIIl, lllllllllllllllIllIllIIlIIlIIIII))
      {
        int lllllllllllllllIllIllIIlIIlIlIII = -lllllllllllllllIllIllIIlIIlIIIII;
        "".length();
        if ((0x58 ^ 0x7 ^ 0xF7 ^ 0xAD) == 0) {
          return;
        }
        while (!llIllllIIIIll(lllllllllllllllIllIllIIlIIlIlIII, lllllllllllllllIllIllIIlIIlIIIII))
        {
          int lllllllllllllllIllIllIIlIIlIIlll = -lllllllllllllllIllIllIIlIIlIIIII;
          "".length();
          if (" ".length() <= 0) {
            return;
          }
          while (!llIllllIIIIll(lllllllllllllllIllIllIIlIIlIIlll, lllllllllllllllIllIllIIlIIlIIIII))
          {
            double lllllllllllllllIllIllIIlIIlIIllI = lllllllllllllllIllIllIIlIIlIlIII + (rand.nextDouble() - rand.nextDouble()) * 0.5D;
            double lllllllllllllllIllIllIIlIIlIIlIl = lllllllllllllllIllIllIIlIIlIlIIl + (rand.nextDouble() - rand.nextDouble()) * 0.5D;
            double lllllllllllllllIllIllIIlIIlIIlII = lllllllllllllllIllIllIIlIIlIIlll + (rand.nextDouble() - rand.nextDouble()) * 0.5D;
            double lllllllllllllllIllIllIIlIIlIIIll = MathHelper.sqrt_double(lllllllllllllllIllIllIIlIIlIIllI * lllllllllllllllIllIllIIlIIlIIllI + lllllllllllllllIllIllIIlIIlIIlIl * lllllllllllllllIllIllIIlIIlIIlIl + lllllllllllllllIllIllIIlIIlIIlII * lllllllllllllllIllIllIIlIIlIIlII) / lllllllllllllllIllIllIIlIIlIIIIl + rand.nextGaussian() * 0.05D;
            lllllllllllllllIllIllIIlIIlIIIlI.createParticle(lllllllllllllllIllIllIIlIIlIllII, lllllllllllllllIllIllIIlIIlIlIll, lllllllllllllllIllIllIIlIIlIlIlI, lllllllllllllllIllIllIIlIIlIIllI / lllllllllllllllIllIllIIlIIlIIIll, lllllllllllllllIllIllIIlIIlIIlIl / lllllllllllllllIllIllIIlIIlIIIll, lllllllllllllllIllIllIIlIIlIIlII / lllllllllllllllIllIllIIlIIlIIIll, lllllllllllllllIllIllIIlIIllIIII, lllllllllllllllIllIllIIlIIIllllI, lllllllllllllllIllIllIIlIIlIlllI, lllllllllllllllIllIllIIlIIIlllII);
            if ((llIllllIIIlll(lllllllllllllllIllIllIIlIIlIlIIl, -lllllllllllllllIllIllIIlIIlIIIII)) && (llIllllIIIlll(lllllllllllllllIllIllIIlIIlIlIIl, lllllllllllllllIllIllIIlIIlIIIII)) && (llIllllIIIlll(lllllllllllllllIllIllIIlIIlIlIII, -lllllllllllllllIllIllIIlIIlIIIII)) && (llIllllIIIlll(lllllllllllllllIllIllIIlIIlIlIII, lllllllllllllllIllIllIIlIIlIIIII))) {
              lllllllllllllllIllIllIIlIIlIIlll += lllllllllllllllIllIllIIlIIlIIIII * lIIIllllIlII[3] - lIIIllllIlII[4];
            }
            lllllllllllllllIllIllIIlIIlIIlll++;
          }
          lllllllllllllllIllIllIIlIIlIlIII++;
        }
        lllllllllllllllIllIllIIlIIlIlIIl++;
      }
    }
    
    public StarterFX(World lllllllllllllllIllIllIIllIllllll, double lllllllllllllllIllIllIIllIllIIII, double lllllllllllllllIllIllIIllIllllIl, double lllllllllllllllIllIllIIllIlIlllI, double lllllllllllllllIllIllIIllIlIllIl, double lllllllllllllllIllIllIIllIlllIlI, double lllllllllllllllIllIllIIllIlllIIl, EffectRenderer lllllllllllllllIllIllIIllIlIlIlI, NBTTagCompound lllllllllllllllIllIllIIllIllIlll)
    {
      lllllllllllllllIllIllIIllIllIlII.<init>(lllllllllllllllIllIllIIllIllllll, lllllllllllllllIllIllIIllIllIIII, lllllllllllllllIllIllIIllIllllIl, lllllllllllllllIllIllIIllIlIlllI, 0.0D, 0.0D, 0.0D);
      motionX = lllllllllllllllIllIllIIllIlIllIl;
      motionY = lllllllllllllllIllIllIIllIlllIlI;
      motionZ = lllllllllllllllIllIllIIllIlllIIl;
      theEffectRenderer = lllllllllllllllIllIllIIllIlIlIlI;
      particleMaxAge = lIIIllllIlII[0];
      if (llIlllIllllIl(lllllllllllllllIllIllIIllIllIlll))
      {
        fireworkExplosions = lllllllllllllllIllIllIIllIllIlll.getTagList(lIIIllllIIll[lIIIllllIlII[1]], lIIIllllIlII[2]);
        if (llIlllIlllllI(fireworkExplosions.tagCount()))
        {
          fireworkExplosions = null;
          "".length();
          if (((0xE1 ^ 0x82) & (0x1F ^ 0x7C ^ 0xFFFFFFFF)) < ((0x62 ^ 0x34) & (0xDE ^ 0x88 ^ 0xFFFFFFFF))) {
            throw null;
          }
        }
        else
        {
          particleMaxAge = (fireworkExplosions.tagCount() * lIIIllllIlII[3] - lIIIllllIlII[4]);
          int lllllllllllllllIllIllIIllIllIllI = lIIIllllIlII[1];
          "".length();
          if (-" ".length() > " ".length()) {
            throw null;
          }
          while (!llIllllIIIIII(lllllllllllllllIllIllIIllIllIllI, fireworkExplosions.tagCount()))
          {
            NBTTagCompound lllllllllllllllIllIllIIllIllIlIl = fireworkExplosions.getCompoundTagAt(lllllllllllllllIllIllIIllIllIllI);
            if (llIlllIllllll(lllllllllllllllIllIllIIllIllIlIl.getBoolean(lIIIllllIIll[lIIIllllIlII[4]])))
            {
              twinkle = lIIIllllIlII[4];
              particleMaxAge += lIIIllllIlII[5];
              "".length();
              if (-" ".length() < ((23 + 54 - -27 + 67 ^ '' + 8 - 37 + 39) & ('' + 68 - 178 + 199 ^ '' + 68 - 35 + 37 ^ -" ".length()))) {
                break;
              }
              throw null;
            }
            lllllllllllllllIllIllIIllIllIllI++;
          }
        }
      }
    }
    
    private static boolean llIllllIIIIlI(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllIllIllIIIIllIlIlI;
      return ??? < i;
    }
    
    private static boolean llIlllIllllll(int ???)
    {
      byte lllllllllllllllIllIllIIIIllIIIlI;
      return ??? != 0;
    }
    
    private boolean func_92037_i()
    {
      ;
      ;
      Minecraft lllllllllllllllIllIllIIlIllIlllI = Minecraft.getMinecraft();
      if ((llIlllIllllIl(lllllllllllllllIllIllIIlIllIlllI)) && (llIlllIllllIl(lllllllllllllllIllIllIIlIllIlllI.getRenderViewEntity())) && (llIllllIIIlIl(llIllllIIIlII(lllllllllllllllIllIllIIlIllIlllI.getRenderViewEntity().getDistanceSq(posX, posY, posZ), 256.0D)))) {
        return lIIIllllIlII[1];
      }
      return lIIIllllIlII[4];
    }
    
    private static boolean llIllllIIIIIl(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllIllIllIIIIlllIIlI;
      return ??? == i;
    }
    
    private void createBurst(int[] lllllllllllllllIllIllIIIlIllllIl, int[] lllllllllllllllIllIllIIIlIllllII, boolean lllllllllllllllIllIllIIIlIlllIll, boolean lllllllllllllllIllIllIIIlIlIllll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      double lllllllllllllllIllIllIIIlIlllIIl = rand.nextGaussian() * 0.05D;
      double lllllllllllllllIllIllIIIlIlllIII = rand.nextGaussian() * 0.05D;
      int lllllllllllllllIllIllIIIlIllIlll = lIIIllllIlII[1];
      "".length();
      if ("  ".length() < ((0x7F ^ 0x76 ^ 0x25 ^ 0x31) & (94 + 39 - 76 + 103 ^ 60 + '¥' - 83 + 47 ^ -" ".length()))) {
        return;
      }
      while (!llIllllIIIIII(lllllllllllllllIllIllIIIlIllIlll, lIIIllllIlII[20]))
      {
        double lllllllllllllllIllIllIIIlIllIllI = motionX * 0.5D + rand.nextGaussian() * 0.15D + lllllllllllllllIllIllIIIlIlllIIl;
        double lllllllllllllllIllIllIIIlIllIlIl = motionZ * 0.5D + rand.nextGaussian() * 0.15D + lllllllllllllllIllIllIIIlIlllIII;
        double lllllllllllllllIllIllIIIlIllIlII = motionY * 0.5D + rand.nextDouble() * 0.5D;
        lllllllllllllllIllIllIIIlIlllllI.createParticle(posX, posY, posZ, lllllllllllllllIllIllIIIlIllIllI, lllllllllllllllIllIllIIIlIllIlII, lllllllllllllllIllIllIIIlIllIlIl, lllllllllllllllIllIllIIIlIllllIl, lllllllllllllllIllIllIIIlIllIIIl, lllllllllllllllIllIllIIIlIlllIll, lllllllllllllllIllIllIIIlIlIllll);
        lllllllllllllllIllIllIIIlIllIlll++;
      }
    }
    
    private void createShaped(double lllllllllllllllIllIllIIIllIlllll, double[][] lllllllllllllllIllIllIIIllllIlll, int[] lllllllllllllllIllIllIIIllllIllI, int[] lllllllllllllllIllIllIIIllllIlIl, boolean lllllllllllllllIllIllIIIllllIlII, boolean lllllllllllllllIllIllIIIllllIIll, boolean lllllllllllllllIllIllIIIllIlIlll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      double lllllllllllllllIllIllIIIllllIIIl = lllllllllllllllIllIllIIIllllIlll[lIIIllllIlII[1]][lIIIllllIlII[1]];
      double lllllllllllllllIllIllIIIllllIIII = lllllllllllllllIllIllIIIllllIlll[lIIIllllIlII[1]][lIIIllllIlII[4]];
      lllllllllllllllIllIllIIIlllllIIl.createParticle(posX, posY, posZ, lllllllllllllllIllIllIIIllllIIIl * lllllllllllllllIllIllIIIllIlllll, lllllllllllllllIllIllIIIllllIIII * lllllllllllllllIllIllIIIllIlllll, 0.0D, lllllllllllllllIllIllIIIllllIllI, lllllllllllllllIllIllIIIllllIlIl, lllllllllllllllIllIllIIIllllIlII, lllllllllllllllIllIllIIIllllIIll);
      float lllllllllllllllIllIllIIIlllIllll = rand.nextFloat() * 3.1415927F;
      if (llIlllIllllll(lllllllllllllllIllIllIIIllIlIlll))
      {
        "".length();
        if ((52 + 107 - 11 + 13 ^ 22 + 93 - -3 + 47) >= "  ".length()) {
          break label128;
        }
      }
      label128:
      double lllllllllllllllIllIllIIIlllIlllI = 0.34D;
      int lllllllllllllllIllIllIIIlllIllIl = lIIIllllIlII[1];
      "".length();
      if (null != null) {
        return;
      }
      while (!llIllllIIIIII(lllllllllllllllIllIllIIIlllIllIl, lIIIllllIlII[6]))
      {
        double lllllllllllllllIllIllIIIlllIllII = lllllllllllllllIllIllIIIlllIllll + lllllllllllllllIllIllIIIlllIllIl * 3.1415927F * lllllllllllllllIllIllIIIlllIlllI;
        double lllllllllllllllIllIllIIIlllIlIll = lllllllllllllllIllIllIIIllllIIIl;
        double lllllllllllllllIllIllIIIlllIlIlI = lllllllllllllllIllIllIIIllllIIII;
        int lllllllllllllllIllIllIIIlllIlIIl = lIIIllllIlII[4];
        "".length();
        if (" ".length() <= ((0xB8 ^ 0x8E) & (0x70 ^ 0x46 ^ 0xFFFFFFFF))) {
          return;
        }
        while (!llIllllIIIIII(lllllllllllllllIllIllIIIlllIlIIl, lllllllllllllllIllIllIIIllllIlll.length))
        {
          double lllllllllllllllIllIllIIIlllIlIII = lllllllllllllllIllIllIIIllllIlll[lllllllllllllllIllIllIIIlllIlIIl][lIIIllllIlII[1]];
          double lllllllllllllllIllIllIIIlllIIlll = lllllllllllllllIllIllIIIllllIlll[lllllllllllllllIllIllIIIlllIlIIl][lIIIllllIlII[4]];
          double lllllllllllllllIllIllIIIlllIIllI = 0.25D;
          "".length();
          if (((0x48 ^ 0x78) & (0x62 ^ 0x52 ^ 0xFFFFFFFF)) != 0) {
            return;
          }
          while (!llIllllIIIllI(llIllllIIlIII(lllllllllllllllIllIllIIIlllIIllI, 1.0D)))
          {
            double lllllllllllllllIllIllIIIlllIIlIl = (lllllllllllllllIllIllIIIlllIlIll + (lllllllllllllllIllIllIIIlllIlIII - lllllllllllllllIllIllIIIlllIlIll) * lllllllllllllllIllIllIIIlllIIllI) * lllllllllllllllIllIllIIIllIlllll;
            double lllllllllllllllIllIllIIIlllIIlII = (lllllllllllllllIllIllIIIlllIlIlI + (lllllllllllllllIllIllIIIlllIIlll - lllllllllllllllIllIllIIIlllIlIlI) * lllllllllllllllIllIllIIIlllIIllI) * lllllllllllllllIllIllIIIllIlllll;
            double lllllllllllllllIllIllIIIlllIIIll = lllllllllllllllIllIllIIIlllIIlIl * Math.sin(lllllllllllllllIllIllIIIlllIllII);
            lllllllllllllllIllIllIIIlllIIlIl *= Math.cos(lllllllllllllllIllIllIIIlllIllII);
            double lllllllllllllllIllIllIIIlllIIIlI = -1.0D;
            "".length();
            if (((0xFD ^ 0xC1) & (0x14 ^ 0x28 ^ 0xFFFFFFFF)) != ((0x20 ^ 0x6C) & (0x8B ^ 0xC7 ^ 0xFFFFFFFF))) {
              return;
            }
            while (!llIllllIIIllI(llIllllIIlIII(lllllllllllllllIllIllIIIlllIIIlI, 1.0D)))
            {
              lllllllllllllllIllIllIIIlllllIIl.createParticle(posX, posY, posZ, lllllllllllllllIllIllIIIlllIIlIl * lllllllllllllllIllIllIIIlllIIIlI, lllllllllllllllIllIllIIIlllIIlII, lllllllllllllllIllIllIIIlllIIIll * lllllllllllllllIllIllIIIlllIIIlI, lllllllllllllllIllIllIIIllllIllI, lllllllllllllllIllIllIIIllllIlIl, lllllllllllllllIllIllIIIllllIlII, lllllllllllllllIllIllIIIllllIIll);
              lllllllllllllllIllIllIIIlllIIIlI += 2.0D;
            }
            lllllllllllllllIllIllIIIlllIIllI += 0.25D;
          }
          lllllllllllllllIllIllIIIlllIlIll = lllllllllllllllIllIllIIIlllIlIII;
          lllllllllllllllIllIllIIIlllIlIlI = lllllllllllllllIllIllIIIlllIIlll;
        }
      }
    }
    
    private static String llIlllIlllIII(String lllllllllllllllIllIllIIIIllllIll, String lllllllllllllllIllIllIIIIllllIII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIllIllIIIIllllllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIIIllllIII.getBytes(StandardCharsets.UTF_8)), lIIIllllIlII[0]), "DES");
        Cipher lllllllllllllllIllIllIIIIlllllIl = Cipher.getInstance("DES");
        lllllllllllllllIllIllIIIIlllllIl.init(lIIIllllIlII[3], lllllllllllllllIllIllIIIIllllllI);
        return new String(lllllllllllllllIllIllIIIIlllllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIIIllllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIllIllIIIIlllllII)
      {
        lllllllllllllllIllIllIIIIlllllII.printStackTrace();
      }
      return null;
    }
    
    public int getFXLayer()
    {
      return lIIIllllIlII[1];
    }
    
    private static boolean llIlllIllllIl(Object ???)
    {
      char lllllllllllllllIllIllIIIIllIIlII;
      return ??? != null;
    }
    
    private void createParticle(double lllllllllllllllIllIllIIlIlIlIIII, double lllllllllllllllIllIllIIlIlIlllII, double lllllllllllllllIllIllIIlIlIllIll, double lllllllllllllllIllIllIIlIlIllIlI, double lllllllllllllllIllIllIIlIlIllIIl, double lllllllllllllllIllIllIIlIlIIlIll, int[] lllllllllllllllIllIllIIlIlIlIlll, int[] lllllllllllllllIllIllIIlIlIIlIIl, boolean lllllllllllllllIllIllIIlIlIlIlIl, boolean lllllllllllllllIllIllIIlIlIlIlII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      EntityFirework.SparkFX lllllllllllllllIllIllIIlIlIlIIll = new EntityFirework.SparkFX(worldObj, lllllllllllllllIllIllIIlIlIlIIII, lllllllllllllllIllIllIIlIlIlllII, lllllllllllllllIllIllIIlIlIllIll, lllllllllllllllIllIllIIlIlIllIlI, lllllllllllllllIllIllIIlIlIIllII, lllllllllllllllIllIllIIlIlIIlIll, theEffectRenderer);
      lllllllllllllllIllIllIIlIlIlIIll.setAlphaF(0.99F);
      lllllllllllllllIllIllIIlIlIlIIll.setTrail(lllllllllllllllIllIllIIlIlIlIlIl);
      lllllllllllllllIllIllIIlIlIlIIll.setTwinkle(lllllllllllllllIllIllIIlIlIlIlII);
      int lllllllllllllllIllIllIIlIlIlIIlI = rand.nextInt(lllllllllllllllIllIllIIlIlIlIlll.length);
      lllllllllllllllIllIllIIlIlIlIIll.setColour(lllllllllllllllIllIllIIlIlIlIlll[lllllllllllllllIllIllIIlIlIlIIlI]);
      if ((llIlllIllllIl(lllllllllllllllIllIllIIlIlIIlIIl)) && (llIllllIIIllI(lllllllllllllllIllIllIIlIlIIlIIl.length))) {
        lllllllllllllllIllIllIIlIlIlIIll.setFadeColour(lllllllllllllllIllIllIIlIlIIlIIl[rand.nextInt(lllllllllllllllIllIllIIlIlIIlIIl.length)]);
      }
      theEffectRenderer.addEffect(lllllllllllllllIllIllIIlIlIlIIll);
    }
    
    private static int llIllllIIlIII(double paramDouble1, double paramDouble2)
    {
      return paramDouble1 < paramDouble2;
    }
    
    private static int llIllllIIIlII(double paramDouble1, double paramDouble2)
    {
      return paramDouble1 < paramDouble2;
    }
    
    private static String llIlllIlllIIl(String lllllllllllllllIllIllIIIlIIIlIII, String lllllllllllllllIllIllIIIlIIIIlll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIllIllIIIlIIIlIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllIIIlIIIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIllIllIIIlIIIlIlI = Cipher.getInstance("Blowfish");
        lllllllllllllllIllIllIIIlIIIlIlI.init(lIIIllllIlII[3], lllllllllllllllIllIllIIIlIIIlIll);
        return new String(lllllllllllllllIllIllIIIlIIIlIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllIIIlIIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIllIllIIIlIIIlIIl)
      {
        lllllllllllllllIllIllIIIlIIIlIIl.printStackTrace();
      }
      return null;
    }
  }
  
  public static class SparkFX
    extends EntityFX
  {
    public void setFadeColour(int lllllllllllllllllIlIIIIIlIIllIII)
    {
      ;
      ;
      fadeColourRed = (((lllllllllllllllllIlIIIIIlIIllIII & lIIlIlIIIll[4]) >> lIIlIlIIIll[5]) / 255.0F);
      fadeColourGreen = (((lllllllllllllllllIlIIIIIlIIllIII & lIIlIlIIIll[6]) >> lIIlIlIIIll[7]) / 255.0F);
      fadeColourBlue = (((lllllllllllllllllIlIIIIIlIIllIII & lIIlIlIIIll[8]) >> lIIlIlIIIll[3]) / 255.0F);
      hasFadeColour = lIIlIlIIIll[9];
    }
    
    private static boolean lllIlIlIlIlI(int ???, int arg1)
    {
      int i;
      char lllllllllllllllllIlIIIIIIllIIIll;
      return ??? > i;
    }
    
    public int getBrightnessForRender(float lllllllllllllllllIlIIIIIIlllIIIl)
    {
      return lIIlIlIIIll[13];
    }
    
    public void renderParticle(WorldRenderer lllllllllllllllllIlIIIIIlIIIlIIl, Entity lllllllllllllllllIlIIIIIlIIIlIII, float lllllllllllllllllIlIIIIIlIIIIlll, float lllllllllllllllllIlIIIIIlIIIIllI, float lllllllllllllllllIlIIIIIIlllllII, float lllllllllllllllllIlIIIIIlIIIIlII, float lllllllllllllllllIlIIIIIIllllIlI, float lllllllllllllllllIlIIIIIIllllIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      if ((!lllIlIlIIlll(twinkle)) || (!lllIlIlIlIII(particleAge, particleMaxAge / lIIlIlIIIll[10])) || (lllIlIlIlIIl((particleAge + particleMaxAge) / lIIlIlIIIll[10] % lIIlIlIIIll[11]))) {
        lllllllllllllllllIlIIIIIlIIIlIlI.renderParticle(lllllllllllllllllIlIIIIIlIIIlIIl, lllllllllllllllllIlIIIIIlIIIlIII, lllllllllllllllllIlIIIIIlIIIIlll, lllllllllllllllllIlIIIIIIlllllIl, lllllllllllllllllIlIIIIIIlllllII, lllllllllllllllllIlIIIIIlIIIIlII, lllllllllllllllllIlIIIIIIllllIlI, lllllllllllllllllIlIIIIIIllllIIl);
      }
    }
    
    public SparkFX(World lllllllllllllllllIlIIIIIllIIIIIl, double lllllllllllllllllIlIIIIIllIIlIIl, double lllllllllllllllllIlIIIIIllIIlIII, double lllllllllllllllllIlIIIIIlIlllllI, double lllllllllllllllllIlIIIIIlIllllIl, double lllllllllllllllllIlIIIIIlIllllII, double lllllllllllllllllIlIIIIIllIIIlII, EffectRenderer lllllllllllllllllIlIIIIIllIIIIll)
    {
      lllllllllllllllllIlIIIIIllIIlIll.<init>(lllllllllllllllllIlIIIIIllIIIIIl, lllllllllllllllllIlIIIIIllIIlIIl, lllllllllllllllllIlIIIIIllIIlIII, lllllllllllllllllIlIIIIIllIIIlll);
      motionX = lllllllllllllllllIlIIIIIlIllllIl;
      motionY = lllllllllllllllllIlIIIIIlIllllII;
      motionZ = lllllllllllllllllIlIIIIIllIIIlII;
      field_92047_az = lllllllllllllllllIlIIIIIllIIIIll;
      particleScale *= 0.75F;
      particleMaxAge = (lIIlIlIIIll[1] + rand.nextInt(lIIlIlIIIll[2]));
      noClip = lIIlIlIIIll[3];
    }
    
    private static void lllIlIlIIllI()
    {
      lIIlIlIIIll = new int[14];
      lIIlIlIIIll[0] = ('' + '' - 270 + 153 + (0x2B ^ 0x68) - ('' + '' - 184 + 75) + (0x75 ^ 0x29));
      lIIlIlIIIll[1] = (0x4C ^ 0x7C);
      lIIlIlIIIll[2] = (0x95 ^ 0x99);
      lIIlIlIIIll[3] = ((0x3E ^ 0x29) & (0x70 ^ 0x67 ^ 0xFFFFFFFF));
      lIIlIlIIIll[4] = (-(0xD7FE & 0x7F1B) & 0xFFFFFF99 & 0xFF577F);
      lIIlIlIIIll[5] = (0x2 ^ 0x12);
      lIIlIlIIIll[6] = (-(31 + 113 - 80 + 69) & 0xFFFFFFC7 & 0xFFBC);
      lIIlIlIIIll[7] = (0x3E ^ 0x36);
      lIIlIlIIIll[8] = (11 + '¿' - 28 + 28 + (109 + 10 - 9 + 34) - (8 + 113 - 40 + 100) + (0x5E ^ 0x4));
      lIIlIlIIIll[9] = " ".length();
      lIIlIlIIIll[10] = "   ".length();
      lIIlIlIIIll[11] = "  ".length();
      lIIlIlIIIll[12] = (0x35 ^ 0x32);
      lIIlIlIIIll[13] = (-(0xE74F & 0x3EBD) & 0xF7FD & 0xF02EFE);
    }
    
    public void setColour(int lllllllllllllllllIlIIIIIlIlIIllI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      float lllllllllllllllllIlIIIIIlIlIIlIl = ((lllllllllllllllllIlIIIIIlIlIIllI & lIIlIlIIIll[4]) >> lIIlIlIIIll[5]) / 255.0F;
      float lllllllllllllllllIlIIIIIlIlIIlII = ((lllllllllllllllllIlIIIIIlIlIIllI & lIIlIlIIIll[6]) >> lIIlIlIIIll[7]) / 255.0F;
      float lllllllllllllllllIlIIIIIlIlIIIll = ((lllllllllllllllllIlIIIIIlIlIIllI & lIIlIlIIIll[8]) >> lIIlIlIIIll[3]) / 255.0F;
      float lllllllllllllllllIlIIIIIlIlIIIlI = 1.0F;
      lllllllllllllllllIlIIIIIlIlIIlll.setRBGColorF(lllllllllllllllllIlIIIIIlIlIIlIl * lllllllllllllllllIlIIIIIlIlIIIlI, lllllllllllllllllIlIIIIIlIlIIlII * lllllllllllllllllIlIIIIIlIlIIIlI, lllllllllllllllllIlIIIIIlIlIIIll * lllllllllllllllllIlIIIIIlIlIIIlI);
    }
    
    private static boolean lllIlIlIlIII(int ???, int arg1)
    {
      int i;
      boolean lllllllllllllllllIlIIIIIIllIlIll;
      return ??? >= i;
    }
    
    public AxisAlignedBB getCollisionBoundingBox()
    {
      return null;
    }
    
    public void setTwinkle(boolean lllllllllllllllllIlIIIIIlIlIlllI)
    {
      ;
      ;
      twinkle = lllllllllllllllllIlIIIIIlIlIlllI;
    }
    
    static {}
    
    public void onUpdate()
    {
      ;
      ;
      prevPosX = posX;
      prevPosY = posY;
      prevPosZ = posZ;
      int tmp29_26 = particleAge;
      particleAge = (tmp29_26 + lIIlIlIIIll[9]);
      if (lllIlIlIlIII(tmp29_26, particleMaxAge)) {
        lllllllllllllllllIlIIIIIIlllIlII.setDead();
      }
      if (lllIlIlIlIlI(particleAge, particleMaxAge / lIIlIlIIIll[11]))
      {
        lllllllllllllllllIlIIIIIIlllIlII.setAlphaF(1.0F - (particleAge - particleMaxAge / lIIlIlIIIll[11]) / particleMaxAge);
        if (lllIlIlIIlll(hasFadeColour))
        {
          particleRed += (fadeColourRed - particleRed) * 0.2F;
          particleGreen += (fadeColourGreen - particleGreen) * 0.2F;
          particleBlue += (fadeColourBlue - particleBlue) * 0.2F;
        }
      }
      lllllllllllllllllIlIIIIIIlllIlII.setParticleTextureIndex(baseTextureIndex + (lIIlIlIIIll[12] - particleAge * lIIlIlIIIll[7] / particleMaxAge));
      motionY -= 0.004D;
      lllllllllllllllllIlIIIIIIlllIlII.moveEntity(motionX, motionY, motionZ);
      motionX *= 0.9100000262260437D;
      motionY *= 0.9100000262260437D;
      motionZ *= 0.9100000262260437D;
      if (lllIlIlIIlll(onGround))
      {
        motionX *= 0.699999988079071D;
        motionZ *= 0.699999988079071D;
      }
      if ((lllIlIlIIlll(trail)) && (lllIlIlIlIll(particleAge, particleMaxAge / lIIlIlIIIll[11])) && (lllIlIlIlIIl((particleAge + particleMaxAge) % lIIlIlIIIll[11])))
      {
        SparkFX lllllllllllllllllIlIIIIIIlllIlIl = new SparkFX(worldObj, posX, posY, posZ, 0.0D, 0.0D, 0.0D, field_92047_az);
        lllllllllllllllllIlIIIIIIlllIlIl.setAlphaF(0.99F);
        lllllllllllllllllIlIIIIIIlllIlIl.setRBGColorF(particleRed, particleGreen, particleBlue);
        particleAge = (particleMaxAge / lIIlIlIIIll[11]);
        if (lllIlIlIIlll(hasFadeColour))
        {
          hasFadeColour = lIIlIlIIIll[9];
          fadeColourRed = fadeColourRed;
          fadeColourGreen = fadeColourGreen;
          fadeColourBlue = fadeColourBlue;
        }
        twinkle = twinkle;
        field_92047_az.addEffect(lllllllllllllllllIlIIIIIIlllIlIl);
      }
    }
    
    private static boolean lllIlIlIlIIl(int ???)
    {
      byte lllllllllllllllllIlIIIIIIlIlllll;
      return ??? == 0;
    }
    
    private static boolean lllIlIlIIlll(int ???)
    {
      Exception lllllllllllllllllIlIIIIIIllIIIIl;
      return ??? != 0;
    }
    
    private static boolean lllIlIlIlIll(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllllIlIIIIIIllIIlll;
      return ??? < i;
    }
    
    public float getBrightness(float lllllllllllllllllIlIIIIIIllIllll)
    {
      return 1.0F;
    }
    
    public void setTrail(boolean lllllllllllllllllIlIIIIIlIllIlII)
    {
      ;
      ;
      trail = lllllllllllllllllIlIIIIIlIllIlII;
    }
    
    public boolean canBePushed()
    {
      return lIIlIlIIIll[3];
    }
  }
  
  public static class OverlayFX
    extends EntityFX
  {
    static {}
    
    private static void lIIIIIlllIIIll()
    {
      lIlIlIIlIIll = new int[3];
      lIlIlIIlIIll[0] = (0x75 ^ 0xB ^ 0x63 ^ 0x19);
      lIlIlIIlIIll[1] = (74 + 45 - 76 + 85 ^ 84 + 31 - -22 + 7);
      lIlIlIIlIIll[2] = (0xFFFFFFFF & 0xFFFF);
    }
    
    public void renderParticle(WorldRenderer lllllllllllllllIlIIIIIlllIlIlIlI, Entity lllllllllllllllIlIIIIIlllIlIlIII, float lllllllllllllllIlIIIIIlllIlIIllI, float lllllllllllllllIlIIIIIlllIIIIIll, float lllllllllllllllIlIIIIIlllIlIIIlI, float lllllllllllllllIlIIIIIlllIIIIIIl, float lllllllllllllllIlIIIIIlllIIIIIII, float lllllllllllllllIlIIIIIllIlllllll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      float lllllllllllllllIlIIIIIlllIIllIlI = 0.25F;
      float lllllllllllllllIlIIIIIlllIIllIII = 0.5F;
      float lllllllllllllllIlIIIIIlllIIlIllI = 0.125F;
      float lllllllllllllllIlIIIIIlllIIlIlII = 0.375F;
      float lllllllllllllllIlIIIIIlllIIlIIlI = 7.1F * MathHelper.sin((particleAge + lllllllllllllllIlIIIIIlllIlIIllI - 1.0F) * 0.25F * 3.1415927F);
      particleAlpha = (0.6F - (particleAge + lllllllllllllllIlIIIIIlllIlIIllI - 1.0F) * 0.25F * 0.5F);
      float lllllllllllllllIlIIIIIlllIIlIIII = (float)(prevPosX + (posX - prevPosX) * lllllllllllllllIlIIIIIlllIlIIllI - interpPosX);
      float lllllllllllllllIlIIIIIlllIIIlllI = (float)(prevPosY + (posY - prevPosY) * lllllllllllllllIlIIIIIlllIlIIllI - interpPosY);
      float lllllllllllllllIlIIIIIlllIIIllII = (float)(prevPosZ + (posZ - prevPosZ) * lllllllllllllllIlIIIIIlllIlIIllI - interpPosZ);
      int lllllllllllllllIlIIIIIlllIIIlIlI = lllllllllllllllIlIIIIIlllIlIllII.getBrightnessForRender(lllllllllllllllIlIIIIIlllIlIIllI);
      int lllllllllllllllIlIIIIIlllIIIlIII = lllllllllllllllIlIIIIIlllIIIlIlI >> lIlIlIIlIIll[1] & lIlIlIIlIIll[2];
      int lllllllllllllllIlIIIIIlllIIIIlll = lllllllllllllllIlIIIIIlllIIIlIlI & lIlIlIIlIIll[2];
      lllllllllllllllIlIIIIIlllIlIlIlI.pos(lllllllllllllllIlIIIIIlllIIlIIII - lllllllllllllllIlIIIIIlllIIIIIll * lllllllllllllllIlIIIIIlllIIlIIlI - lllllllllllllllIlIIIIIlllIIIIIII * lllllllllllllllIlIIIIIlllIIlIIlI, lllllllllllllllIlIIIIIlllIIIlllI - lllllllllllllllIlIIIIIlllIlIIIlI * lllllllllllllllIlIIIIIlllIIlIIlI, lllllllllllllllIlIIIIIlllIIIllII - lllllllllllllllIlIIIIIlllIIIIIIl * lllllllllllllllIlIIIIIlllIIlIIlI - lllllllllllllllIlIIIIIllIlllllll * lllllllllllllllIlIIIIIlllIIlIIlI).tex(0.5D, 0.375D).color(particleRed, particleGreen, particleBlue, particleAlpha).lightmap(lllllllllllllllIlIIIIIlllIIIlIII, lllllllllllllllIlIIIIIlllIIIIlll).endVertex();
      lllllllllllllllIlIIIIIlllIlIlIlI.pos(lllllllllllllllIlIIIIIlllIIlIIII - lllllllllllllllIlIIIIIlllIIIIIll * lllllllllllllllIlIIIIIlllIIlIIlI + lllllllllllllllIlIIIIIlllIIIIIII * lllllllllllllllIlIIIIIlllIIlIIlI, lllllllllllllllIlIIIIIlllIIIlllI + lllllllllllllllIlIIIIIlllIlIIIlI * lllllllllllllllIlIIIIIlllIIlIIlI, lllllllllllllllIlIIIIIlllIIIllII - lllllllllllllllIlIIIIIlllIIIIIIl * lllllllllllllllIlIIIIIlllIIlIIlI + lllllllllllllllIlIIIIIllIlllllll * lllllllllllllllIlIIIIIlllIIlIIlI).tex(0.5D, 0.125D).color(particleRed, particleGreen, particleBlue, particleAlpha).lightmap(lllllllllllllllIlIIIIIlllIIIlIII, lllllllllllllllIlIIIIIlllIIIIlll).endVertex();
      lllllllllllllllIlIIIIIlllIlIlIlI.pos(lllllllllllllllIlIIIIIlllIIlIIII + lllllllllllllllIlIIIIIlllIIIIIll * lllllllllllllllIlIIIIIlllIIlIIlI + lllllllllllllllIlIIIIIlllIIIIIII * lllllllllllllllIlIIIIIlllIIlIIlI, lllllllllllllllIlIIIIIlllIIIlllI + lllllllllllllllIlIIIIIlllIlIIIlI * lllllllllllllllIlIIIIIlllIIlIIlI, lllllllllllllllIlIIIIIlllIIIllII + lllllllllllllllIlIIIIIlllIIIIIIl * lllllllllllllllIlIIIIIlllIIlIIlI + lllllllllllllllIlIIIIIllIlllllll * lllllllllllllllIlIIIIIlllIIlIIlI).tex(0.25D, 0.125D).color(particleRed, particleGreen, particleBlue, particleAlpha).lightmap(lllllllllllllllIlIIIIIlllIIIlIII, lllllllllllllllIlIIIIIlllIIIIlll).endVertex();
      lllllllllllllllIlIIIIIlllIlIlIlI.pos(lllllllllllllllIlIIIIIlllIIlIIII + lllllllllllllllIlIIIIIlllIIIIIll * lllllllllllllllIlIIIIIlllIIlIIlI - lllllllllllllllIlIIIIIlllIIIIIII * lllllllllllllllIlIIIIIlllIIlIIlI, lllllllllllllllIlIIIIIlllIIIlllI - lllllllllllllllIlIIIIIlllIlIIIlI * lllllllllllllllIlIIIIIlllIIlIIlI, lllllllllllllllIlIIIIIlllIIIllII + lllllllllllllllIlIIIIIlllIIIIIIl * lllllllllllllllIlIIIIIlllIIlIIlI - lllllllllllllllIlIIIIIllIlllllll * lllllllllllllllIlIIIIIlllIIlIIlI).tex(0.25D, 0.375D).color(particleRed, particleGreen, particleBlue, particleAlpha).lightmap(lllllllllllllllIlIIIIIlllIIIlIII, lllllllllllllllIlIIIIIlllIIIIlll).endVertex();
    }
    
    protected OverlayFX(World lllllllllllllllIlIIIIIlllllIIlll, double lllllllllllllllIlIIIIIlllllIIIIl, double lllllllllllllllIlIIIIIlllllIIIII, double lllllllllllllllIlIIIIIllllIlllll)
    {
      lllllllllllllllIlIIIIIlllllIlIII.<init>(lllllllllllllllIlIIIIIlllllIIlll, lllllllllllllllIlIIIIIlllllIIllI, lllllllllllllllIlIIIIIlllllIIIII, lllllllllllllllIlIIIIIllllIlllll);
      particleMaxAge = lIlIlIIlIIll[0];
    }
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int lllllllllllllllIIIlIIIllIllIllII, World lllllllllllllllIIIlIIIllIllIlIll, double lllllllllllllllIIIlIIIllIllIIIII, double lllllllllllllllIIIlIIIllIlIlllll, double lllllllllllllllIIIlIIIllIllIlIII, double lllllllllllllllIIIlIIIllIllIIlll, double lllllllllllllllIIIlIIIllIllIIllI, double lllllllllllllllIIIlIIIllIllIIlIl, int... lllllllllllllllIIIlIIIllIllIIlII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      EntityFirework.SparkFX lllllllllllllllIIIlIIIllIllIIIll = new EntityFirework.SparkFX(lllllllllllllllIIIlIIIllIllIlIll, lllllllllllllllIIIlIIIllIllIIIII, lllllllllllllllIIIlIIIllIlIlllll, lllllllllllllllIIIlIIIllIllIlIII, lllllllllllllllIIIlIIIllIllIIlll, lllllllllllllllIIIlIIIllIllIIllI, lllllllllllllllIIIlIIIllIllIIlIl, getMinecrafteffectRenderer);
      lllllllllllllllIIIlIIIllIllIIIll.setAlphaF(0.99F);
      return lllllllllllllllIIIlIIIllIllIIIll;
    }
    
    public Factory() {}
  }
}

package net.minecraft.client.particle;

import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntitySmokeFX
  extends EntityFX
{
  public void renderParticle(WorldRenderer llllllllllllllllIllIllIlIIlIIIII, Entity llllllllllllllllIllIllIlIIIlIlIl, float llllllllllllllllIllIllIlIIIllllI, float llllllllllllllllIllIllIlIIIlllIl, float llllllllllllllllIllIllIlIIIlllII, float llllllllllllllllIllIllIlIIIlIIIl, float llllllllllllllllIllIllIlIIIllIlI, float llllllllllllllllIllIllIlIIIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllllIllIllIlIIIllIII = (particleAge + llllllllllllllllIllIllIlIIIllllI) / particleMaxAge * 32.0F;
    llllllllllllllllIllIllIlIIIllIII = MathHelper.clamp_float(llllllllllllllllIllIllIlIIIllIII, 0.0F, 1.0F);
    particleScale = (smokeParticleScale * llllllllllllllllIllIllIlIIIllIII);
    llllllllllllllllIllIllIlIIIlIlll.renderParticle(llllllllllllllllIllIllIlIIlIIIII, llllllllllllllllIllIllIlIIIlIlIl, llllllllllllllllIllIllIlIIIllllI, llllllllllllllllIllIllIlIIIlIIll, llllllllllllllllIllIllIlIIIlllII, llllllllllllllllIllIllIlIIIlIIIl, llllllllllllllllIllIllIlIIIllIlI, llllllllllllllllIllIllIlIIIIllll);
  }
  
  protected EntitySmokeFX(World llllllllllllllllIllIllIlIIllIIll, double llllllllllllllllIllIllIlIIlllIll, double llllllllllllllllIllIllIlIIllIIIl, double llllllllllllllllIllIllIlIIlllIIl, double llllllllllllllllIllIllIlIIlllIII, double llllllllllllllllIllIllIlIIllIlll, double llllllllllllllllIllIllIlIIlIllIl, float llllllllllllllllIllIllIlIIllIlIl)
  {
    llllllllllllllllIllIllIlIIllllIl.<init>(llllllllllllllllIllIllIlIIllIIll, llllllllllllllllIllIllIlIIlllIll, llllllllllllllllIllIllIlIIllIIIl, llllllllllllllllIllIllIlIIllIIII, 0.0D, 0.0D, 0.0D);
    motionX *= 0.10000000149011612D;
    motionY *= 0.10000000149011612D;
    motionZ *= 0.10000000149011612D;
    motionX += llllllllllllllllIllIllIlIIlllIII;
    motionY += llllllllllllllllIllIllIlIIllIlll;
    motionZ += llllllllllllllllIllIllIlIIlIllIl;
    particleRed = (llllllllllllllllIllIllIlIIllllIl.particleGreen = llllllllllllllllIllIllIlIIllllIl.particleBlue = (float)(Math.random() * 0.30000001192092896D));
    particleScale *= 0.75F;
    particleScale *= llllllllllllllllIllIllIlIIllIlIl;
    smokeParticleScale = particleScale;
    particleMaxAge = ((int)(8.0D / (Math.random() * 0.8D + 0.2D)));
    particleMaxAge = ((int)(particleMaxAge * llllllllllllllllIllIllIlIIllIlIl));
    noClip = lIllllIIIll[0];
  }
  
  private static boolean lIIlIIIlIIIlI(int ???)
  {
    Exception llllllllllllllllIllIllIIllllIIll;
    return ??? == 0;
  }
  
  private static void lIIlIIIIlllll()
  {
    lIllllIIIll = new int[4];
    lIllllIIIll[0] = ((103 + 117 - 153 + 86 ^ 46 + 22 - 21 + 145) & ('Ç' + 'È' - 398 + 204 ^ 83 + 99 - 35 + 1 ^ -" ".length()));
    lIllllIIIll[1] = " ".length();
    lIllllIIIll[2] = (0x44 ^ 0x43);
    lIllllIIIll[3] = (0x32 ^ 0x3A);
  }
  
  private EntitySmokeFX(World llllllllllllllllIllIllIlIlIlIlIl, double llllllllllllllllIllIllIlIlIlIlII, double llllllllllllllllIllIllIlIlIlIIll, double llllllllllllllllIllIllIlIlIlIIlI, double llllllllllllllllIllIllIlIlIlIIIl, double llllllllllllllllIllIllIlIlIIlIII, double llllllllllllllllIllIllIlIlIIllll)
  {
    llllllllllllllllIllIllIlIlIlIllI.<init>(llllllllllllllllIllIllIlIlIlIlIl, llllllllllllllllIllIllIlIlIlIlII, llllllllllllllllIllIllIlIlIlIIll, llllllllllllllllIllIllIlIlIlIIlI, llllllllllllllllIllIllIlIlIlIIIl, llllllllllllllllIllIllIlIlIIlIII, llllllllllllllllIllIllIlIlIIllll, 1.0F);
  }
  
  private static boolean lIIlIIIlIIIIl(int ???, int arg1)
  {
    int i;
    int llllllllllllllllIllIllIIllllIlll;
    return ??? >= i;
  }
  
  static {}
  
  private static int lIIlIIIlIIIII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean lIIlIIIlIIIll(int ???)
  {
    long llllllllllllllllIllIllIIllllIlIl;
    return ??? != 0;
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + lIllllIIIll[1]);
    if (lIIlIIIlIIIIl(tmp29_26, particleMaxAge)) {
      llllllllllllllllIllIllIlIIIIllII.setDead();
    }
    llllllllllllllllIllIllIlIIIIllII.setParticleTextureIndex(lIllllIIIll[2] - particleAge * lIllllIIIll[3] / particleMaxAge);
    motionY += 0.004D;
    llllllllllllllllIllIllIlIIIIllII.moveEntity(motionX, motionY, motionZ);
    if (lIIlIIIlIIIlI(lIIlIIIlIIIII(posY, prevPosY)))
    {
      motionX *= 1.1D;
      motionZ *= 1.1D;
    }
    motionX *= 0.9599999785423279D;
    motionY *= 0.9599999785423279D;
    motionZ *= 0.9599999785423279D;
    if (lIIlIIIlIIIll(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int lllllllllllllllllIlIlIllIllllIIl, World lllllllllllllllllIlIlIllIlllIIII, double lllllllllllllllllIlIlIllIllIllll, double lllllllllllllllllIlIlIllIllIlllI, double lllllllllllllllllIlIlIllIllIllIl, double lllllllllllllllllIlIlIllIlllIlII, double lllllllllllllllllIlIlIllIlllIIll, double lllllllllllllllllIlIlIllIlllIIlI, int... lllllllllllllllllIlIlIllIlllIIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntitySmokeFX(lllllllllllllllllIlIlIllIlllIIII, lllllllllllllllllIlIlIllIllIllll, lllllllllllllllllIlIlIllIllIlllI, lllllllllllllllllIlIlIllIllIllIl, lllllllllllllllllIlIlIllIlllIlII, lllllllllllllllllIlIlIllIlllIIll, lllllllllllllllllIlIlIllIlllIIlI, null);
    }
  }
}

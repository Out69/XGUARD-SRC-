package net.minecraft.client.particle;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityFX
  extends Entity
{
  public EntityFX(World lIlIIIIlllIIllI, double lIlIIIIlllIIlIl, double lIlIIIIlllIIlII, double lIlIIIIlllIllIl, double lIlIIIIlllIllII, double lIlIIIIlllIlIll, double lIlIIIIlllIlIlI)
  {
    lIlIIIIlllIIlll.<init>(lIlIIIIlllIIllI, lIlIIIIlllIIlIl, lIlIIIIlllIIlII, lIlIIIIlllIllIl);
    motionX = (lIlIIIIlllIllII + (Math.random() * 2.0D - 1.0D) * 0.4000000059604645D);
    motionY = (lIlIIIIlllIlIll + (Math.random() * 2.0D - 1.0D) * 0.4000000059604645D);
    motionZ = (lIlIIIIlllIlIlI + (Math.random() * 2.0D - 1.0D) * 0.4000000059604645D);
    float lIlIIIIlllIlIIl = (float)(Math.random() + Math.random() + 1.0D) * 0.15F;
    float lIlIIIIlllIlIII = MathHelper.sqrt_double(motionX * motionX + motionY * motionY + motionZ * motionZ);
    motionX = (motionX / lIlIIIIlllIlIII * lIlIIIIlllIlIIl * 0.4000000059604645D);
    motionY = (motionY / lIlIIIIlllIlIII * lIlIIIIlllIlIIl * 0.4000000059604645D + 0.10000000149011612D);
    motionZ = (motionZ / lIlIIIIlllIlIII * lIlIIIIlllIlIIl * 0.4000000059604645D);
  }
  
  public void writeEntityToNBT(NBTTagCompound lIlIIIIIlllIIlI) {}
  
  private static int llIIlllIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static int llIIlllIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void setParticleTextureIndex(int lIlIIIIIllIIIll)
  {
    ;
    ;
    if (llIIllllIl(lIlIIIIIllIIlII.getFXLayer())) {
      throw new RuntimeException(llllIlll[lllllIII[1]]);
    }
    particleTextureIndexX = (lIlIIIIIllIIIll % lllllIII[2]);
    particleTextureIndexY = (lIlIIIIIllIIIll / lllllIII[2]);
  }
  
  private static String llIIllIlIl(String lIlIIIIIlIIIlIl, String lIlIIIIIlIIIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIlIIIIIlIIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIlIIIIIlIIIlII.getBytes(StandardCharsets.UTF_8)), lllllIII[10]), "DES");
      Cipher lIlIIIIIlIIIlll = Cipher.getInstance("DES");
      lIlIIIIIlIIIlll.init(lllllIII[4], lIlIIIIIlIIlIII);
      return new String(lIlIIIIIlIIIlll.doFinal(Base64.getDecoder().decode(lIlIIIIIlIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIlIIIIIlIIIllI)
    {
      lIlIIIIIlIIIllI.printStackTrace();
    }
    return null;
  }
  
  public void setAlphaF(float lIlIIIIllIIIIlI)
  {
    ;
    ;
    if ((llIIlllIlI(llIIlllIII(particleAlpha, 1.0F))) && (llIIlllIll(llIIlllIIl(lIlIIIIllIIIIlI, 1.0F))))
    {
      getMinecrafteffectRenderer.moveToAlphaLayer(lIlIIIIllIIIIll);
      "".length();
      if ("  ".length() >= "  ".length()) {}
    }
    else if ((llIIlllIll(llIIlllIIl(particleAlpha, 1.0F))) && (llIIlllIlI(llIIlllIII(lIlIIIIllIIIIlI, 1.0F))))
    {
      getMinecrafteffectRenderer.moveToNoAlphaLayer(lIlIIIIllIIIIll);
    }
    particleAlpha = lIlIIIIllIIIIlI;
  }
  
  public float getGreenColorF()
  {
    ;
    return particleGreen;
  }
  
  public void setParticleIcon(TextureAtlasSprite lIlIIIIIllIlIII)
  {
    ;
    ;
    ;
    int lIlIIIIIllIlIlI = lIlIIIIIllIlIIl.getFXLayer();
    if (llIIllllll(lIlIIIIIllIlIlI, lllllIII[1]))
    {
      particleIcon = lIlIIIIIllIlIII;
      "".length();
      if (-(0xC ^ 0x8) < 0) {}
    }
    else
    {
      throw new RuntimeException(llllIlll[lllllIII[0]]);
    }
  }
  
  protected EntityFX(World lIlIIIlIIIIIlII, double lIlIIIlIIIIIIll, double lIlIIIIllllllIl, double lIlIIIIllllllII)
  {
    lIlIIIlIIIIIlIl.<init>(lIlIIIlIIIIIlII);
    lIlIIIlIIIIIlIl.setSize(0.2F, 0.2F);
    lIlIIIlIIIIIlIl.setPosition(lIlIIIIlllllllI, lIlIIIIllllllIl, lIlIIIIllllllII);
    lastTickPosX = (lIlIIIlIIIIIlIl.prevPosX = lIlIIIIlllllllI);
    lastTickPosY = (lIlIIIlIIIIIlIl.prevPosY = lIlIIIIllllllIl);
    lastTickPosZ = (lIlIIIlIIIIIlIl.prevPosZ = lIlIIIIllllllII);
    particleRed = (lIlIIIlIIIIIlIl.particleGreen = lIlIIIlIIIIIlIl.particleBlue = 1.0F);
    particleTextureJitterX = (rand.nextFloat() * 3.0F);
    particleTextureJitterY = (rand.nextFloat() * 3.0F);
    particleScale = ((rand.nextFloat() * 0.5F + 0.5F) * 2.0F);
    particleMaxAge = ((int)(4.0F / (rand.nextFloat() * 0.9F + 0.1F)));
    particleAge = lllllIII[0];
  }
  
  private static boolean llIIllllII(int ???, int arg1)
  {
    int i;
    long lIlIIIIIIlllIII;
    return ??? >= i;
  }
  
  public void setRBGColorF(float lIlIIIIllIIllII, float lIlIIIIllIIIlll, float lIlIIIIllIIlIlI)
  {
    ;
    ;
    ;
    ;
    particleRed = lIlIIIIllIIllII;
    particleGreen = lIlIIIIllIIIlll;
    particleBlue = lIlIIIIllIIlIlI;
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + lllllIII[1]);
    if (llIIllllII(tmp29_26, particleMaxAge)) {
      lIlIIIIlIlIllll.setDead();
    }
    motionY -= 0.04D * particleGravity;
    lIlIIIIlIlIllll.moveEntity(motionX, motionY, motionZ);
    motionX *= 0.9800000190734863D;
    motionY *= 0.9800000190734863D;
    motionZ *= 0.9800000190734863D;
    if (llIIllllIl(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  public void renderParticle(WorldRenderer lIlIIIIlIIllIlI, Entity lIlIIIIlIIllIIl, float lIlIIIIlIIIIlIl, float lIlIIIIlIIlIlll, float lIlIIIIlIIlIllI, float lIlIIIIlIIIIIlI, float lIlIIIIlIIlIlII, float lIlIIIIlIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lIlIIIIlIIlIIlI = particleTextureIndexX / 16.0F;
    float lIlIIIIlIIlIIIl = lIlIIIIlIIlIIlI + 0.0624375F;
    float lIlIIIIlIIlIIII = particleTextureIndexY / 16.0F;
    float lIlIIIIlIIIllll = lIlIIIIlIIlIIII + 0.0624375F;
    float lIlIIIIlIIIlllI = 0.1F * particleScale;
    if (llIIlllllI(particleIcon))
    {
      lIlIIIIlIIlIIlI = particleIcon.getMinU();
      lIlIIIIlIIlIIIl = particleIcon.getMaxU();
      lIlIIIIlIIlIIII = particleIcon.getMinV();
      lIlIIIIlIIIllll = particleIcon.getMaxV();
    }
    float lIlIIIIlIIIllIl = (float)(prevPosX + (posX - prevPosX) * lIlIIIIlIIIIlIl - interpPosX);
    float lIlIIIIlIIIllII = (float)(prevPosY + (posY - prevPosY) * lIlIIIIlIIIIlIl - interpPosY);
    float lIlIIIIlIIIlIll = (float)(prevPosZ + (posZ - prevPosZ) * lIlIIIIlIIIIlIl - interpPosZ);
    int lIlIIIIlIIIlIlI = lIlIIIIlIIllIll.getBrightnessForRender(lIlIIIIlIIIIlIl);
    int lIlIIIIlIIIlIIl = lIlIIIIlIIIlIlI >> lllllIII[2] & lllllIII[3];
    int lIlIIIIlIIIlIII = lIlIIIIlIIIlIlI & lllllIII[3];
    lIlIIIIlIIllIlI.pos(lIlIIIIlIIIllIl - lIlIIIIlIIlIlll * lIlIIIIlIIIlllI - lIlIIIIlIIlIlII * lIlIIIIlIIIlllI, lIlIIIIlIIIllII - lIlIIIIlIIlIllI * lIlIIIIlIIIlllI, lIlIIIIlIIIlIll - lIlIIIIlIIIIIlI * lIlIIIIlIIIlllI - lIlIIIIlIIlIIll * lIlIIIIlIIIlllI).tex(lIlIIIIlIIlIIIl, lIlIIIIlIIIllll).color(particleRed, particleGreen, particleBlue, particleAlpha).lightmap(lIlIIIIlIIIlIIl, lIlIIIIlIIIlIII).endVertex();
    lIlIIIIlIIllIlI.pos(lIlIIIIlIIIllIl - lIlIIIIlIIlIlll * lIlIIIIlIIIlllI + lIlIIIIlIIlIlII * lIlIIIIlIIIlllI, lIlIIIIlIIIllII + lIlIIIIlIIlIllI * lIlIIIIlIIIlllI, lIlIIIIlIIIlIll - lIlIIIIlIIIIIlI * lIlIIIIlIIIlllI + lIlIIIIlIIlIIll * lIlIIIIlIIIlllI).tex(lIlIIIIlIIlIIIl, lIlIIIIlIIlIIII).color(particleRed, particleGreen, particleBlue, particleAlpha).lightmap(lIlIIIIlIIIlIIl, lIlIIIIlIIIlIII).endVertex();
    lIlIIIIlIIllIlI.pos(lIlIIIIlIIIllIl + lIlIIIIlIIlIlll * lIlIIIIlIIIlllI + lIlIIIIlIIlIlII * lIlIIIIlIIIlllI, lIlIIIIlIIIllII + lIlIIIIlIIlIllI * lIlIIIIlIIIlllI, lIlIIIIlIIIlIll + lIlIIIIlIIIIIlI * lIlIIIIlIIIlllI + lIlIIIIlIIlIIll * lIlIIIIlIIIlllI).tex(lIlIIIIlIIlIIlI, lIlIIIIlIIlIIII).color(particleRed, particleGreen, particleBlue, particleAlpha).lightmap(lIlIIIIlIIIlIIl, lIlIIIIlIIIlIII).endVertex();
    lIlIIIIlIIllIlI.pos(lIlIIIIlIIIllIl + lIlIIIIlIIlIlll * lIlIIIIlIIIlllI - lIlIIIIlIIlIlII * lIlIIIIlIIIlllI, lIlIIIIlIIIllII - lIlIIIIlIIlIllI * lIlIIIIlIIIlllI, lIlIIIIlIIIlIll + lIlIIIIlIIIIIlI * lIlIIIIlIIIlllI - lIlIIIIlIIlIIll * lIlIIIIlIIIlllI).tex(lIlIIIIlIIlIIlI, lIlIIIIlIIIllll).color(particleRed, particleGreen, particleBlue, particleAlpha).lightmap(lIlIIIIlIIIlIIl, lIlIIIIlIIIlIII).endVertex();
  }
  
  static
  {
    llIIllIlll();
    llIIllIllI();
  }
  
  public EntityFX multipleParticleScaleBy(float lIlIIIIllIlIlII)
  {
    ;
    ;
    lIlIIIIllIlIlIl.setSize(0.2F * lIlIIIIllIlIlII, 0.2F * lIlIIIIllIlIlII);
    particleScale *= lIlIIIIllIlIlII;
    return lIlIIIIllIlIlIl;
  }
  
  private static String llIIIllllI(String lIlIIIIIlIlIIII, String lIlIIIIIlIlIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIlIIIIIlIlIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIlIIIIIlIlIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIlIIIIIlIlIlII = Cipher.getInstance("Blowfish");
      lIlIIIIIlIlIlII.init(lllllIII[4], lIlIIIIIlIlIlIl);
      return new String(lIlIIIIIlIlIlII.doFinal(Base64.getDecoder().decode(lIlIIIIIlIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIlIIIIIlIlIIll)
    {
      lIlIIIIIlIlIIll.printStackTrace();
    }
    return null;
  }
  
  public float getAlpha()
  {
    ;
    return particleAlpha;
  }
  
  private static boolean llIIllllll(int ???, int arg1)
  {
    int i;
    double lIlIIIIIIllllII;
    return ??? == i;
  }
  
  public boolean canAttackWithItem()
  {
    return lllllIII[0];
  }
  
  private static void llIIllIlll()
  {
    lllllIII = new int[13];
    lllllIII[0] = ((0xD0 ^ 0x8D) & (0x2A ^ 0x77 ^ 0xFFFFFFFF));
    lllllIII[1] = " ".length();
    lllllIII[2] = (0x2 ^ 0x2F ^ 0x20 ^ 0x1D);
    lllllIII[3] = (0xFFFFFFFF & 0xFFFF);
    lllllIII[4] = "  ".length();
    lllllIII[5] = "   ".length();
    lllllIII[6] = (0x34 ^ 0x30);
    lllllIII[7] = (0x26 ^ 0x5 ^ 0xA6 ^ 0x80);
    lllllIII[8] = (0x11 ^ 0x17);
    lllllIII[9] = (0xE2 ^ 0xB5 ^ 0x2C ^ 0x7C);
    lllllIII[10] = (0xA4 ^ 0x9C ^ 0xF0 ^ 0xC0);
    lllllIII[11] = (0x84 ^ 0x9A ^ 0x1E ^ 0x9);
    lllllIII[12] = (0x2 ^ 0x75 ^ 0x28 ^ 0x55);
  }
  
  public float getBlueColorF()
  {
    ;
    return particleBlue;
  }
  
  private static boolean llIIlllllI(Object ???)
  {
    int lIlIIIIIIllIllI;
    return ??? != null;
  }
  
  public String toString()
  {
    ;
    return String.valueOf(new StringBuilder(String.valueOf(lIlIIIIIlIllIlI.getClass().getSimpleName())).append(llllIlll[lllllIII[4]]).append(posX).append(llllIlll[lllllIII[5]]).append(posY).append(llllIlll[lllllIII[6]]).append(posZ).append(llllIlll[lllllIII[7]]).append(particleRed).append(llllIlll[lllllIII[8]]).append(particleGreen).append(llllIlll[lllllIII[9]]).append(particleBlue).append(llllIlll[lllllIII[10]]).append(particleAlpha).append(llllIlll[lllllIII[11]]).append(particleAge));
  }
  
  protected boolean canTriggerWalking()
  {
    return lllllIII[0];
  }
  
  public void readEntityFromNBT(NBTTagCompound lIlIIIIIlllIIII) {}
  
  private static boolean llIIlllIlI(int ???)
  {
    long lIlIIIIIIllIIlI;
    return ??? == 0;
  }
  
  private static boolean llIIllllIl(int ???)
  {
    boolean lIlIIIIIIllIlII;
    return ??? != 0;
  }
  
  public EntityFX multiplyVelocity(float lIlIIIIllIllIII)
  {
    ;
    ;
    motionX *= lIlIIIIllIllIII;
    motionY = ((motionY - 0.10000000149011612D) * lIlIIIIllIllIII + 0.10000000149011612D);
    motionZ *= lIlIIIIllIllIII;
    return lIlIIIIllIllIll;
  }
  
  private static boolean llIIlllIll(int ???)
  {
    byte lIlIIIIIIllIIII;
    return ??? < 0;
  }
  
  public int getFXLayer()
  {
    return lllllIII[0];
  }
  
  private static void llIIllIllI()
  {
    llllIlll = new String[lllllIII[12]];
    llllIlll[lllllIII[0]] = llIIIllllI("zkmLyJIlJ/nNBBtMR94rXBEmoyolYDRKqsFF5i9t9u6J8yT/QV32DEv40e0Y+sx765wCCi6ITDQ=", "jdcSu");
    llllIlll[lllllIII[1]] = llIIIllllI("iMagaKyZ49XesRluvkCYoQ+gdlLUO8WjirH0Q1Zt5o53/o+AdPOQdw==", "OJrkp");
    llllIlll[lllllIII[4]] = llIIIllllI("bWih45I+Sfg=", "CLIGy");
    llllIlll[lllllIII[5]] = llIIIllllI("Q9hAB9IgaAo=", "huDIf");
    llllIlll[lllllIII[6]] = llIIllIlIl("q0TfxB7wUic=", "vzGWj");
    llllIlll[lllllIII[7]] = llIIIllllI("w0N4HpJWVEZ1cBVQTMFCHg==", "aWvfN");
    llllIlll[lllllIII[8]] = llIIllIlIl("vq7uRfKEYoo=", "RueQu");
    llllIlll[lllllIII[9]] = llIIIllllI("VWzA8t0ypOU=", "tfPUh");
    llllIlll[lllllIII[10]] = llIIIllllI("+jQcSLktPIM=", "GDgbE");
    llllIlll[lllllIII[11]] = llIIllIlIl("bG6Z+mcderI=", "mOiNB");
  }
  
  protected void entityInit() {}
  
  public void nextTextureIndexX()
  {
    ;
    particleTextureIndexX += lllllIII[1];
  }
  
  public float getRedColorF()
  {
    ;
    return particleRed;
  }
}

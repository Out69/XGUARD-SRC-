package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.world.World;

public class EntityExplodeFX
  extends EntityFX
{
  static {}
  
  protected EntityExplodeFX(World llllllllllllllIlIIIIlIIIIlllIIIl, double llllllllllllllIlIIIIlIIIIlllIIII, double llllllllllllllIlIIIIlIIIIlllIlll, double llllllllllllllIlIIIIlIIIIllIlllI, double llllllllllllllIlIIIIlIIIIllIllIl, double llllllllllllllIlIIIIlIIIIllIllII, double llllllllllllllIlIIIIlIIIIlllIIll)
  {
    llllllllllllllIlIIIIlIIIIllllIlI.<init>(llllllllllllllIlIIIIlIIIIlllIIIl, llllllllllllllIlIIIIlIIIIlllIIII, llllllllllllllIlIIIIlIIIIlllIlll, llllllllllllllIlIIIIlIIIIllIlllI, llllllllllllllIlIIIIlIIIIllIllIl, llllllllllllllIlIIIIlIIIIllIllII, llllllllllllllIlIIIIlIIIIlllIIll);
    motionX = (llllllllllllllIlIIIIlIIIIllIllIl + (Math.random() * 2.0D - 1.0D) * 0.05000000074505806D);
    motionY = (llllllllllllllIlIIIIlIIIIllIllII + (Math.random() * 2.0D - 1.0D) * 0.05000000074505806D);
    motionZ = (llllllllllllllIlIIIIlIIIIlllIIll + (Math.random() * 2.0D - 1.0D) * 0.05000000074505806D);
    particleRed = (llllllllllllllIlIIIIlIIIIllllIlI.particleGreen = llllllllllllllIlIIIIlIIIIllllIlI.particleBlue = rand.nextFloat() * 0.3F + 0.7F);
    particleScale = (rand.nextFloat() * rand.nextFloat() * 6.0F + 1.0F);
    particleMaxAge = ((int)(16.0D / (rand.nextFloat() * 0.8D + 0.2D)) + lIIlIIlIllllI[0]);
  }
  
  private static boolean lllIIIIIIlIIlI(int ???, int arg1)
  {
    int i;
    boolean llllllllllllllIlIIIIlIIIIllIIlII;
    return ??? >= i;
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + lIIlIIlIllllI[1]);
    if (lllIIIIIIlIIlI(tmp29_26, particleMaxAge)) {
      llllllllllllllIlIIIIlIIIIllIlIII.setDead();
    }
    llllllllllllllIlIIIIlIIIIllIlIII.setParticleTextureIndex(lIIlIIlIllllI[2] - particleAge * lIIlIIlIllllI[3] / particleMaxAge);
    motionY += 0.004D;
    llllllllllllllIlIIIIlIIIIllIlIII.moveEntity(motionX, motionY, motionZ);
    motionX *= 0.8999999761581421D;
    motionY *= 0.8999999761581421D;
    motionZ *= 0.8999999761581421D;
    if (lllIIIIIIlIIll(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  private static void lllIIIIIIlIIIl()
  {
    lIIlIIlIllllI = new int[4];
    lIIlIIlIllllI[0] = "  ".length();
    lIIlIIlIllllI[1] = " ".length();
    lIIlIIlIllllI[2] = (86 + 27 - -18 + 33 ^ 60 + 115 - 115 + 103);
    lIIlIIlIllllI[3] = (0xA2 ^ 0xAA);
  }
  
  private static boolean lllIIIIIIlIIll(int ???)
  {
    Exception llllllllllllllIlIIIIlIIIIllIIIlI;
    return ??? != 0;
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int llllllllllllllIlIllIlIIIIIlIIlII, World llllllllllllllIlIllIlIIIIIIllIll, double llllllllllllllIlIllIlIIIIIIllIlI, double llllllllllllllIlIllIlIIIIIlIIIIl, double llllllllllllllIlIllIlIIIIIIllIII, double llllllllllllllIlIllIlIIIIIIlllll, double llllllllllllllIlIllIlIIIIIIlIllI, double llllllllllllllIlIllIlIIIIIIlIlIl, int... llllllllllllllIlIllIlIIIIIIlllII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityExplodeFX(llllllllllllllIlIllIlIIIIIIllIll, llllllllllllllIlIllIlIIIIIIllIlI, llllllllllllllIlIllIlIIIIIlIIIIl, llllllllllllllIlIllIlIIIIIIllIII, llllllllllllllIlIllIlIIIIIIlllll, llllllllllllllIlIllIlIIIIIIlIllI, llllllllllllllIlIllIlIIIIIIlIlIl);
    }
    
    public Factory() {}
  }
}

package net.minecraft.client.particle;

import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntitySnowShovelFX
  extends EntityFX
{
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + llllIIIIIIlI[1]);
    if (lIllIlllIIllIl(tmp29_26, particleMaxAge)) {
      llllllllllllllIllIllIIlIlIllIIlI.setDead();
    }
    llllllllllllllIllIllIIlIlIllIIlI.setParticleTextureIndex(llllIIIIIIlI[2] - particleAge * llllIIIIIIlI[3] / particleMaxAge);
    motionY -= 0.03D;
    llllllllllllllIllIllIIlIlIllIIlI.moveEntity(motionX, motionY, motionZ);
    motionX *= 0.9900000095367432D;
    motionY *= 0.9900000095367432D;
    motionZ *= 0.9900000095367432D;
    if (lIllIlllIIlllI(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  private static boolean lIllIlllIIlllI(int ???)
  {
    boolean llllllllllllllIllIllIIlIlIlIlIll;
    return ??? != 0;
  }
  
  public void renderParticle(WorldRenderer llllllllllllllIllIllIIlIllIIIllI, Entity llllllllllllllIllIllIIlIlIlllIll, float llllllllllllllIllIllIIlIlIlllIlI, float llllllllllllllIllIllIIlIllIIIIll, float llllllllllllllIllIllIIlIlIlllIII, float llllllllllllllIllIllIIlIlIllIlll, float llllllllllllllIllIllIIlIllIIIIII, float llllllllllllllIllIllIIlIlIllIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIllIllIIlIlIlllllI = (particleAge + llllllllllllllIllIllIIlIlIlllIlI) / particleMaxAge * 32.0F;
    llllllllllllllIllIllIIlIlIlllllI = MathHelper.clamp_float(llllllllllllllIllIllIIlIlIlllllI, 0.0F, 1.0F);
    particleScale = (snowDigParticleScale * llllllllllllllIllIllIIlIlIlllllI);
    llllllllllllllIllIllIIlIlIllllIl.renderParticle(llllllllllllllIllIllIIlIllIIIllI, llllllllllllllIllIllIIlIlIlllIll, llllllllllllllIllIllIIlIlIlllIlI, llllllllllllllIllIllIIlIlIlllIIl, llllllllllllllIllIllIIlIlIlllIII, llllllllllllllIllIllIIlIlIllIlll, llllllllllllllIllIllIIlIllIIIIII, llllllllllllllIllIllIIlIlIllIlIl);
  }
  
  protected EntitySnowShovelFX(World llllllllllllllIllIllIIlIlllIIIlI, double llllllllllllllIllIllIIlIlllIIIIl, double llllllllllllllIllIllIIlIllIlIlll, double llllllllllllllIllIllIIlIllIlllll, double llllllllllllllIllIllIIlIllIlIlIl, double llllllllllllllIllIllIIlIllIlIlII, double llllllllllllllIllIllIIlIllIlIIll, float llllllllllllllIllIllIIlIllIlIIlI)
  {
    llllllllllllllIllIllIIlIlllIIIll.<init>(llllllllllllllIllIllIIlIlllIIIlI, llllllllllllllIllIllIIlIlllIIIIl, llllllllllllllIllIllIIlIllIlIlll, llllllllllllllIllIllIIlIllIlIllI, llllllllllllllIllIllIIlIllIlIlIl, llllllllllllllIllIllIIlIllIlIlII, llllllllllllllIllIllIIlIllIlIIll);
    motionX *= 0.10000000149011612D;
    motionY *= 0.10000000149011612D;
    motionZ *= 0.10000000149011612D;
    motionX += llllllllllllllIllIllIIlIllIlIlIl;
    motionY += llllllllllllllIllIllIIlIllIlIlII;
    motionZ += llllllllllllllIllIllIIlIllIlIIll;
    particleRed = (llllllllllllllIllIllIIlIlllIIIll.particleGreen = llllllllllllllIllIllIIlIlllIIIll.particleBlue = 1.0F - (float)(Math.random() * 0.30000001192092896D));
    particleScale *= 0.75F;
    particleScale *= llllllllllllllIllIllIIlIllIlIIlI;
    snowDigParticleScale = particleScale;
    particleMaxAge = ((int)(8.0D / (Math.random() * 0.8D + 0.2D)));
    particleMaxAge = ((int)(particleMaxAge * llllllllllllllIllIllIIlIllIlIIlI));
    noClip = llllIIIIIIlI[0];
  }
  
  private static void lIllIlllIIllII()
  {
    llllIIIIIIlI = new int[4];
    llllIIIIIIlI[0] = ((0xD3 ^ 0x98 ^ 0x42 ^ 0x3E) & (0xFA ^ 0xB9 ^ 0x5C ^ 0x28 ^ -" ".length()));
    llllIIIIIIlI[1] = " ".length();
    llllIIIIIIlI[2] = (79 + 121 - 152 + 137 ^ 96 + 4 - 27 + 117);
    llllIIIIIIlI[3] = (0x62 ^ 0x6A);
  }
  
  private static boolean lIllIlllIIllIl(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIllIllIIlIlIlIllIl;
    return ??? >= i;
  }
  
  static {}
  
  protected EntitySnowShovelFX(World llllllllllllllIllIllIIlIlllllIll, double llllllllllllllIllIllIIlIlllllIlI, double llllllllllllllIllIllIIlIlllllIIl, double llllllllllllllIllIllIIlIlllllIII, double llllllllllllllIllIllIIlIlllIllll, double llllllllllllllIllIllIIlIllllIllI, double llllllllllllllIllIllIIlIllllIlIl)
  {
    llllllllllllllIllIllIIlIllllIlII.<init>(llllllllllllllIllIllIIlIlllllIll, llllllllllllllIllIllIIlIlllllIlI, llllllllllllllIllIllIIlIlllllIIl, llllllllllllllIllIllIIlIlllllIII, llllllllllllllIllIllIIlIlllIllll, llllllllllllllIllIllIIlIllllIllI, llllllllllllllIllIllIIlIllllIlIl, 1.0F);
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIIllIllIIllIIIlIII, World llllllllllllllIIllIllIIllIIIIlll, double llllllllllllllIIllIllIIllIIIIllI, double llllllllllllllIIllIllIIllIIIIlIl, double llllllllllllllIIllIllIIllIIIIlII, double llllllllllllllIIllIllIIllIIIIIll, double llllllllllllllIIllIllIIllIIIIIlI, double llllllllllllllIIllIllIIlIllllIIl, int... llllllllllllllIIllIllIIllIIIIIII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntitySnowShovelFX(llllllllllllllIIllIllIIllIIIIlll, llllllllllllllIIllIllIIllIIIIllI, llllllllllllllIIllIllIIllIIIIlIl, llllllllllllllIIllIllIIllIIIIlII, llllllllllllllIIllIllIIllIIIIIll, llllllllllllllIIllIllIIllIIIIIlI, llllllllllllllIIllIllIIlIllllIIl);
    }
  }
}

package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class EntitySuspendFX
  extends EntityFX
{
  private static boolean llIlIlIlllIllI(int ???)
  {
    short llllllllllllllIlIIllIIllIIIllIlI;
    return ??? <= 0;
  }
  
  private static boolean llIlIlIlllIlIl(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllIlIIllIIllIIIlllII;
    return ??? != localObject;
  }
  
  static {}
  
  protected EntitySuspendFX(World llllllllllllllIlIIllIIllIIllIIIl, double llllllllllllllIlIIllIIllIIllIIII, double llllllllllllllIlIIllIIllIIlIllll, double llllllllllllllIlIIllIIllIIlIIllI, double llllllllllllllIlIIllIIllIIlIllIl, double llllllllllllllIlIIllIIllIIlIIlII, double llllllllllllllIlIIllIIllIIlIlIll)
  {
    llllllllllllllIlIIllIIllIIllIIlI.<init>(llllllllllllllIlIIllIIllIIllIIIl, llllllllllllllIlIIllIIllIIllIIII, llllllllllllllIlIIllIIllIIlIllll - 0.125D, llllllllllllllIlIIllIIllIIlIIllI, llllllllllllllIlIIllIIllIIlIllIl, llllllllllllllIlIIllIIllIIlIIlII, llllllllllllllIlIIllIIllIIlIlIll);
    particleRed = 0.4F;
    particleGreen = 0.4F;
    particleBlue = 0.7F;
    llllllllllllllIlIIllIIllIIllIIlI.setParticleTextureIndex(lIIIllIIIllIl[0]);
    llllllllllllllIlIIllIIllIIllIIlI.setSize(0.01F, 0.01F);
    particleScale *= (rand.nextFloat() * 0.6F + 0.2F);
    motionX = (llllllllllllllIlIIllIIllIIlIllIl * 0.0D);
    motionY = (llllllllllllllIlIIllIIllIIlIIlII * 0.0D);
    motionZ = (llllllllllllllIlIIllIIllIIlIlIll * 0.0D);
    particleMaxAge = ((int)(16.0D / (Math.random() * 0.8D + 0.2D)));
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    llllllllllllllIlIIllIIllIIlIIIII.moveEntity(motionX, motionY, motionZ);
    if (llIlIlIlllIlIl(worldObj.getBlockState(new BlockPos(llllllllllllllIlIIllIIllIIlIIIII)).getBlock().getMaterial(), Material.water)) {
      llllllllllllllIlIIllIIllIIlIIIII.setDead();
    }
    int tmp81_78 = particleMaxAge;
    particleMaxAge = (tmp81_78 - lIIIllIIIllIl[1]);
    if (llIlIlIlllIllI(tmp81_78)) {
      llllllllllllllIlIIllIIllIIlIIIII.setDead();
    }
  }
  
  private static void llIlIlIlllIlII()
  {
    lIIIllIIIllIl = new int[2];
    lIIIllIIIllIl[0] = ((37 + 22 - 48 + 133 ^ 56 + 85 - 68 + 65) & (0x7B ^ 0x22 ^ 0xD9 ^ 0x9A ^ -" ".length()));
    lIIIllIIIllIl[1] = " ".length();
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int lllllllllllllllIIlIlIIllllIIIIII, World lllllllllllllllIIlIlIIlllIllllll, double lllllllllllllllIIlIlIIlllIllIllI, double lllllllllllllllIIlIlIIlllIllllIl, double lllllllllllllllIIlIlIIlllIllIlII, double lllllllllllllllIIlIlIIlllIlllIll, double lllllllllllllllIIlIlIIlllIllIIlI, double lllllllllllllllIIlIlIIlllIllIIIl, int... lllllllllllllllIIlIlIIlllIlllIII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntitySuspendFX(lllllllllllllllIIlIlIIlllIllllll, lllllllllllllllIIlIlIIlllIllIllI, lllllllllllllllIIlIlIIlllIllllIl, lllllllllllllllIIlIlIIlllIllIlII, lllllllllllllllIIlIlIIlllIlllIll, lllllllllllllllIIlIlIIlllIllIIlI, lllllllllllllllIIlIlIIlllIllIIIl);
    }
  }
}

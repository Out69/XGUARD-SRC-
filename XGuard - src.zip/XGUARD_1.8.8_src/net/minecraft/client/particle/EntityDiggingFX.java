package net.minecraft.client.particle;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockModelShapes;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class EntityDiggingFX
  extends EntityFX
{
  static {}
  
  public int getFXLayer()
  {
    return llIIIlll[3];
  }
  
  private static boolean lIIlllllll(Object ???)
  {
    float lIllIlIIlIIlIlI;
    return ??? != null;
  }
  
  private static boolean lIlIIIIIII(int ???)
  {
    char lIllIlIIlIIlIII;
    return ??? != 0;
  }
  
  private static void lIIlllllII()
  {
    llIIIlll = new int[6];
    llIIIlll[0] = (0xAC ^ 0xBC);
    llIIIlll[1] = ((0x9 ^ 0x71) + (99 + '' - 184 + 98) - (0x4E ^ 0x67) + (0x79 ^ 0x5B));
    llIIIlll[2] = (42 + 32 - 69 + 172 ^ '' + 20 - 138 + 163);
    llIIIlll[3] = " ".length();
    llIIIlll[4] = (-" ".length() & 0xFFFFFFFF & 0xFFFF);
    llIIIlll[5] = (('' + '' - 276 + 157 ^ 2 + 56 - -33 + 38) & (0xF4 ^ 0xBD ^ 0xD ^ 0x63 ^ -" ".length()));
  }
  
  private static boolean lIIlllllIl(Object ???, Object arg1)
  {
    Object localObject;
    boolean lIllIlIIlIIllII;
    return ??? == localObject;
  }
  
  public void renderParticle(WorldRenderer lIllIlIlIIIIIIl, Entity lIllIlIlIIIIIII, float lIllIlIIllIllII, float lIllIlIIllIlIll, float lIllIlIIllIlIlI, float lIllIlIIllIlIIl, float lIllIlIIllIlIII, float lIllIlIIllIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lIllIlIIllllIIl = (particleTextureIndexX + particleTextureJitterX / 4.0F) / 16.0F;
    float lIllIlIIllllIII = lIllIlIIllllIIl + 0.015609375F;
    float lIllIlIIlllIlll = (particleTextureIndexY + particleTextureJitterY / 4.0F) / 16.0F;
    float lIllIlIIlllIllI = lIllIlIIlllIlll + 0.015609375F;
    float lIllIlIIlllIlIl = 0.1F * particleScale;
    if (lIIlllllll(particleIcon))
    {
      lIllIlIIllllIIl = particleIcon.getInterpolatedU(particleTextureJitterX / 4.0F * 16.0F);
      lIllIlIIllllIII = particleIcon.getInterpolatedU((particleTextureJitterX + 1.0F) / 4.0F * 16.0F);
      lIllIlIIlllIlll = particleIcon.getInterpolatedV(particleTextureJitterY / 4.0F * 16.0F);
      lIllIlIIlllIllI = particleIcon.getInterpolatedV((particleTextureJitterY + 1.0F) / 4.0F * 16.0F);
    }
    float lIllIlIIlllIlII = (float)(prevPosX + (posX - prevPosX) * lIllIlIIllIllII - interpPosX);
    float lIllIlIIlllIIll = (float)(prevPosY + (posY - prevPosY) * lIllIlIIllIllII - interpPosY);
    float lIllIlIIlllIIlI = (float)(prevPosZ + (posZ - prevPosZ) * lIllIlIIllIllII - interpPosZ);
    int lIllIlIIlllIIIl = lIllIlIIllIlllI.getBrightnessForRender(lIllIlIIllIllII);
    int lIllIlIIlllIIII = lIllIlIIlllIIIl >> llIIIlll[0] & llIIIlll[4];
    int lIllIlIIllIllll = lIllIlIIlllIIIl & llIIIlll[4];
    lIllIlIlIIIIIIl.pos(lIllIlIIlllIlII - lIllIlIIllIlIll * lIllIlIIlllIlIl - lIllIlIIllIlIII * lIllIlIIlllIlIl, lIllIlIIlllIIll - lIllIlIIllIlIlI * lIllIlIIlllIlIl, lIllIlIIlllIIlI - lIllIlIIllIlIIl * lIllIlIIlllIlIl - lIllIlIIllIIlll * lIllIlIIlllIlIl).tex(lIllIlIIllllIIl, lIllIlIIlllIllI).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lIllIlIIlllIIII, lIllIlIIllIllll).endVertex();
    lIllIlIlIIIIIIl.pos(lIllIlIIlllIlII - lIllIlIIllIlIll * lIllIlIIlllIlIl + lIllIlIIllIlIII * lIllIlIIlllIlIl, lIllIlIIlllIIll + lIllIlIIllIlIlI * lIllIlIIlllIlIl, lIllIlIIlllIIlI - lIllIlIIllIlIIl * lIllIlIIlllIlIl + lIllIlIIllIIlll * lIllIlIIlllIlIl).tex(lIllIlIIllllIIl, lIllIlIIlllIlll).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lIllIlIIlllIIII, lIllIlIIllIllll).endVertex();
    lIllIlIlIIIIIIl.pos(lIllIlIIlllIlII + lIllIlIIllIlIll * lIllIlIIlllIlIl + lIllIlIIllIlIII * lIllIlIIlllIlIl, lIllIlIIlllIIll + lIllIlIIllIlIlI * lIllIlIIlllIlIl, lIllIlIIlllIIlI + lIllIlIIllIlIIl * lIllIlIIlllIlIl + lIllIlIIllIIlll * lIllIlIIlllIlIl).tex(lIllIlIIllllIII, lIllIlIIlllIlll).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lIllIlIIlllIIII, lIllIlIIllIllll).endVertex();
    lIllIlIlIIIIIIl.pos(lIllIlIIlllIlII + lIllIlIIllIlIll * lIllIlIIlllIlIl - lIllIlIIllIlIII * lIllIlIIlllIlIl, lIllIlIIlllIIll - lIllIlIIllIlIlI * lIllIlIIlllIlIl, lIllIlIIlllIIlI + lIllIlIIllIlIIl * lIllIlIIlllIlIl - lIllIlIIllIIlll * lIllIlIIlllIlIl).tex(lIllIlIIllllIII, lIllIlIIlllIllI).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lIllIlIIlllIIII, lIllIlIIllIllll).endVertex();
  }
  
  private static boolean lIlIIIIIIl(int ???)
  {
    boolean lIllIlIIlIIIllI;
    return ??? == 0;
  }
  
  public EntityDiggingFX func_174845_l()
  {
    ;
    ;
    ;
    field_181019_az = new BlockPos(posX, posY, posZ);
    Block lIllIlIlIIllIll = field_174847_a.getBlock();
    if (lIIlllllIl(lIllIlIlIIllIll, Blocks.grass)) {
      return lIllIlIlIIlllII;
    }
    int lIllIlIlIIllIlI = lIllIlIlIIllIll.getRenderColor(field_174847_a);
    particleRed *= (lIllIlIlIIllIlI >> llIIIlll[0] & llIIIlll[1]) / 255.0F;
    particleGreen *= (lIllIlIlIIllIlI >> llIIIlll[2] & llIIIlll[1]) / 255.0F;
    particleBlue *= (lIllIlIlIIllIlI & llIIIlll[1]) / 255.0F;
    return lIllIlIlIIlllII;
  }
  
  public EntityDiggingFX func_174846_a(BlockPos lIllIlIlIlIIIIl)
  {
    ;
    ;
    ;
    field_181019_az = lIllIlIlIlIIIIl;
    if (lIIlllllIl(field_174847_a.getBlock(), Blocks.grass)) {
      return lIllIlIlIlIIlIl;
    }
    int lIllIlIlIlIIIll = field_174847_a.getBlock().colorMultiplier(worldObj, lIllIlIlIlIIIIl);
    particleRed *= (lIllIlIlIlIIIll >> llIIIlll[0] & llIIIlll[1]) / 255.0F;
    particleGreen *= (lIllIlIlIlIIIll >> llIIIlll[2] & llIIIlll[1]) / 255.0F;
    particleBlue *= (lIllIlIlIlIIIll & llIIIlll[1]) / 255.0F;
    return lIllIlIlIlIIlIl;
  }
  
  protected EntityDiggingFX(World lIllIlIlIllIIII, double lIllIlIlIlIllll, double lIllIlIlIlIlllI, double lIllIlIlIllIllI, double lIllIlIlIlIllII, double lIllIlIlIllIlII, double lIllIlIlIlIlIlI, IBlockState lIllIlIlIlIlIIl)
  {
    lIllIlIlIlllIlI.<init>(lIllIlIlIllIIII, lIllIlIlIlIllll, lIllIlIlIlIlllI, lIllIlIlIlIllIl, lIllIlIlIlIllII, lIllIlIlIllIlII, lIllIlIlIlIlIlI);
    field_174847_a = lIllIlIlIlIlIIl;
    lIllIlIlIlllIlI.setParticleIcon(Minecraft.getMinecraft().getBlockRendererDispatcher().getBlockModelShapes().getTexture(lIllIlIlIlIlIIl));
    particleGravity = getBlockblockParticleGravity;
    particleRed = (lIllIlIlIlllIlI.particleGreen = lIllIlIlIlllIlI.particleBlue = 0.6F);
    particleScale /= 2.0F;
  }
  
  public int getBrightnessForRender(float lIllIlIIlIlIllI)
  {
    ;
    ;
    ;
    ;
    int lIllIlIIlIlIlIl = lIllIlIIlIlIlll.getBrightnessForRender(lIllIlIIlIlIllI);
    int lIllIlIIlIlIlII = llIIIlll[5];
    if (lIlIIIIIII(worldObj.isBlockLoaded(field_181019_az))) {
      lIllIlIIlIlIlII = worldObj.getCombinedLight(field_181019_az, llIIIlll[5]);
    }
    if (lIlIIIIIIl(lIllIlIIlIlIlIl))
    {
      "".length();
      if (-"   ".length() < 0) {
        break label85;
      }
      return (0x0 ^ 0x32) & (0x53 ^ 0x61 ^ 0xFFFFFFFF);
    }
    label85:
    return lIllIlIIlIlIlIl;
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int lllllllllllllllllllIIIIlIIIIllll, World lllllllllllllllllllIIIIlIIIIIllI, double lllllllllllllllllllIIIIlIIIIIlIl, double lllllllllllllllllllIIIIlIIIIllII, double lllllllllllllllllllIIIIlIIIIIIll, double lllllllllllllllllllIIIIlIIIIIIlI, double lllllllllllllllllllIIIIlIIIIlIIl, double lllllllllllllllllllIIIIlIIIIIIII, int... lllllllllllllllllllIIIIIllllllll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityDiggingFX(lllllllllllllllllllIIIIlIIIIIllI, lllllllllllllllllllIIIIlIIIIIlIl, lllllllllllllllllllIIIIlIIIIllII, lllllllllllllllllllIIIIlIIIIIIll, lllllllllllllllllllIIIIlIIIIIIlI, lllllllllllllllllllIIIIlIIIIlIIl, lllllllllllllllllllIIIIlIIIIIIII, Block.getStateById(lllllllllllllllllllIIIIIllllllll[llIlIlIlII[0]])).func_174845_l();
    }
    
    static {}
    
    private static void lIlIlIIlIlIl()
    {
      llIlIlIlII = new int[1];
      llIlIlIlII[0] = ((0x87 ^ 0x90) & (0x3C ^ 0x2B ^ 0xFFFFFFFF));
    }
    
    public Factory() {}
  }
}

package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityLavaFX
  extends EntityFX
{
  private static boolean lllIlIlIIIIIl(int ???)
  {
    float lllllllllllllllIllIIIIlIIlllIlII;
    return ??? > 0;
  }
  
  static {}
  
  private static void lllIlIIlllllI()
  {
    lIIlIlllllIl = new int[6];
    lIIlIlllllIl[0] = ((0x58 ^ 0x23 ^ 0xD5 ^ 0xB8) & ((0x2 ^ 0x22) & (0xAE ^ 0x8E ^ 0xFFFFFFFF) ^ 0x21 ^ 0x37 ^ -" ".length()));
    lIIlIlllllIl[1] = (0xC4 ^ 0x89 ^ 0x3F ^ 0x43);
    lIIlIlllllIl[2] = ('' + '¢' - 154 + 91);
    lIIlIlllllIl[3] = (0x4A ^ 0x5A);
    lIIlIlllllIl[4] = ('³' + 'Ã' - 172 + 53);
    lIIlIlllllIl[5] = " ".length();
  }
  
  private static int lllIlIIllllll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public float getBrightness(float lllllllllllllllIllIIIIlIlIlIIIII)
  {
    return 1.0F;
  }
  
  public void renderParticle(WorldRenderer lllllllllllllllIllIIIIlIlIIlIlII, Entity lllllllllllllllIllIIIIlIlIIlIIll, float lllllllllllllllIllIIIIlIlIIlIIlI, float lllllllllllllllIllIIIIlIlIIlIIIl, float lllllllllllllllIllIIIIlIlIIlIIII, float lllllllllllllllIllIIIIlIlIIIIlIl, float lllllllllllllllIllIIIIlIlIIIlllI, float lllllllllllllllIllIIIIlIlIIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIllIIIIlIlIIIllII = (particleAge + lllllllllllllllIllIIIIlIlIIlIIlI) / particleMaxAge;
    particleScale = (lavaParticleScale * (1.0F - lllllllllllllllIllIIIIlIlIIIllII * lllllllllllllllIllIIIIlIlIIIllII));
    lllllllllllllllIllIIIIlIlIIIlIll.renderParticle(lllllllllllllllIllIIIIlIlIIlIlII, lllllllllllllllIllIIIIlIlIIlIIll, lllllllllllllllIllIIIIlIlIIlIIlI, lllllllllllllllIllIIIIlIlIIIIlll, lllllllllllllllIllIIIIlIlIIlIIII, lllllllllllllllIllIIIIlIlIIIIlIl, lllllllllllllllIllIIIIlIlIIIlllI, lllllllllllllllIllIIIIlIlIIIIIll);
  }
  
  public void onUpdate()
  {
    ;
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + lIIlIlllllIl[5]);
    if (lllIlIlIIIIII(tmp29_26, particleMaxAge)) {
      lllllllllllllllIllIIIIlIIlllllll.setDead();
    }
    float lllllllllllllllIllIIIIlIIllllllI = particleAge / particleMaxAge;
    if (lllIlIlIIIIIl(lllIlIIllllll(rand.nextFloat(), lllllllllllllllIllIIIIlIIllllllI))) {
      worldObj.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, posX, posY, posZ, motionX, motionY, motionZ, new int[lIIlIlllllIl[0]]);
    }
    motionY -= 0.03D;
    lllllllllllllllIllIIIIlIIlllllll.moveEntity(motionX, motionY, motionZ);
    motionX *= 0.9990000128746033D;
    motionY *= 0.9990000128746033D;
    motionZ *= 0.9990000128746033D;
    if (lllIlIlIIIIlI(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  private static boolean lllIlIlIIIIlI(int ???)
  {
    boolean lllllllllllllllIllIIIIlIIlllIllI;
    return ??? != 0;
  }
  
  public int getBrightnessForRender(float lllllllllllllllIllIIIIlIlIlIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIllIIIIlIlIlIlIll = (particleAge + lllllllllllllllIllIIIIlIlIlIIllI) / particleMaxAge;
    lllllllllllllllIllIIIIlIlIlIlIll = MathHelper.clamp_float(lllllllllllllllIllIIIIlIlIlIlIll, 0.0F, 1.0F);
    int lllllllllllllllIllIIIIlIlIlIlIlI = lllllllllllllllIllIIIIlIlIlIIlll.getBrightnessForRender(lllllllllllllllIllIIIIlIlIlIIllI);
    int lllllllllllllllIllIIIIlIlIlIlIIl = lIIlIlllllIl[2];
    int lllllllllllllllIllIIIIlIlIlIlIII = lllllllllllllllIllIIIIlIlIlIlIlI >> lIIlIlllllIl[3] & lIIlIlllllIl[4];
    return lllllllllllllllIllIIIIlIlIlIlIIl | lllllllllllllllIllIIIIlIlIlIlIII << lIIlIlllllIl[3];
  }
  
  protected EntityLavaFX(World lllllllllllllllIllIIIIlIlIllllII, double lllllllllllllllIllIIIIlIlIlllIll, double lllllllllllllllIllIIIIlIlIlllIlI, double lllllllllllllllIllIIIIlIlIlllIIl)
  {
    lllllllllllllllIllIIIIlIlIllllIl.<init>(lllllllllllllllIllIIIIlIlIllllII, lllllllllllllllIllIIIIlIlIllIllI, lllllllllllllllIllIIIIlIlIlllIlI, lllllllllllllllIllIIIIlIlIlllIIl, 0.0D, 0.0D, 0.0D);
    motionX *= 0.800000011920929D;
    motionY *= 0.800000011920929D;
    motionZ *= 0.800000011920929D;
    motionY = (rand.nextFloat() * 0.4F + 0.05F);
    particleRed = (lllllllllllllllIllIIIIlIlIllllIl.particleGreen = lllllllllllllllIllIIIIlIlIllllIl.particleBlue = 1.0F);
    particleScale *= (rand.nextFloat() * 2.0F + 0.2F);
    lavaParticleScale = particleScale;
    particleMaxAge = ((int)(16.0D / (Math.random() * 0.8D + 0.2D)));
    noClip = lIIlIlllllIl[0];
    lllllllllllllllIllIIIIlIlIllllIl.setParticleTextureIndex(lIIlIlllllIl[1]);
  }
  
  private static boolean lllIlIlIIIIII(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIllIIIIlIIllllIII;
    return ??? >= i;
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIIllIlIIlIIIIllllI, World llllllllllllllIIllIlIIlIIIIlllIl, double llllllllllllllIIllIlIIlIIIIlllII, double llllllllllllllIIllIlIIlIIIIlIIll, double llllllllllllllIIllIlIIlIIIIlIIlI, double llllllllllllllIIllIlIIlIIIIllIIl, double llllllllllllllIIllIlIIlIIIIllIII, double llllllllllllllIIllIlIIlIIIIlIlll, int... llllllllllllllIIllIlIIlIIIIlIllI)
    {
      ;
      ;
      ;
      ;
      return new EntityLavaFX(llllllllllllllIIllIlIIlIIIIlllIl, llllllllllllllIIllIlIIlIIIIlllII, llllllllllllllIIllIlIIlIIIIlIIll, llllllllllllllIIllIlIIlIIIIlIIlI);
    }
  }
}

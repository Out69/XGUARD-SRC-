package net.minecraft.client.particle;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityGuardian;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class MobAppearance
  extends EntityFX
{
  public void onUpdate()
  {
    ;
    ;
    llIlllllllIlllI.onUpdate();
    if (lIIIIIIII(entity))
    {
      EntityGuardian llIlllllllIllIl = new EntityGuardian(worldObj);
      llIlllllllIllIl.setElder();
      entity = llIlllllllIllIl;
    }
  }
  
  protected MobAppearance(World llIllllllllIlIl, double llIllllllllIlII, double llIlllllllllIII, double llIllllllllIlll)
  {
    llIllllllllIllI.<init>(llIllllllllIlIl, llIlllllllllIIl, llIlllllllllIII, llIllllllllIlll, 0.0D, 0.0D, 0.0D);
    particleRed = (llIllllllllIllI.particleGreen = llIllllllllIllI.particleBlue = 1.0F);
    motionX = (llIllllllllIllI.motionY = llIllllllllIllI.motionZ = 0.0D);
    particleGravity = 0.0F;
    particleMaxAge = lIIIllI[0];
  }
  
  public void renderParticle(WorldRenderer llIlllllllIIIIl, Entity llIlllllllIIIII, float llIllllllIlIIlI, float llIllllllIllllI, float llIllllllIlllIl, float llIllllllIlllII, float llIllllllIllIll, float llIllllllIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIIIIIl(entity))
    {
      RenderManager llIllllllIllIIl = Minecraft.getMinecraft().getRenderManager();
      llIllllllIllIIl.setRenderPosition(EntityFX.interpPosX, EntityFX.interpPosY, EntityFX.interpPosZ);
      float llIllllllIllIII = 0.42553192F;
      float llIllllllIlIlll = (particleAge + llIllllllIlIIlI) / particleMaxAge;
      GlStateManager.depthMask(lIIIllI[2]);
      GlStateManager.enableBlend();
      GlStateManager.enableDepth();
      GlStateManager.blendFunc(lIIIllI[3], lIIIllI[4]);
      float llIllllllIlIllI = 240.0F;
      OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, llIllllllIlIllI, llIllllllIlIllI);
      GlStateManager.pushMatrix();
      float llIllllllIlIlIl = 0.05F + 0.5F * MathHelper.sin(llIllllllIlIlll * 3.1415927F);
      GlStateManager.color(1.0F, 1.0F, 1.0F, llIllllllIlIlIl);
      GlStateManager.translate(0.0F, 1.8F, 0.0F);
      GlStateManager.rotate(180.0F - rotationYaw, 0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(60.0F - 150.0F * llIllllllIlIlll - rotationPitch, 1.0F, 0.0F, 0.0F);
      GlStateManager.translate(0.0F, -0.4F, -1.5F);
      GlStateManager.scale(llIllllllIllIII, llIllllllIllIII, llIllllllIllIII);
      entity.rotationYaw = (entity.prevRotationYaw = 0.0F);
      entity.rotationYawHead = (entity.prevRotationYawHead = 0.0F);
      "".length();
      GlStateManager.popMatrix();
      GlStateManager.enableDepth();
    }
  }
  
  private static boolean lIIIIIIIl(Object ???)
  {
    char llIllllllIIlIll;
    return ??? != null;
  }
  
  public int getFXLayer()
  {
    return lIIIllI[1];
  }
  
  static {}
  
  private static boolean lIIIIIIII(Object ???)
  {
    String llIllllllIIlIIl;
    return ??? == null;
  }
  
  private static void llllllll()
  {
    lIIIllI = new int[5];
    lIIIllI[0] = (0x64 ^ 0x20 ^ 0xDB ^ 0x81);
    lIIIllI[1] = "   ".length();
    lIIIllI[2] = " ".length();
    lIIIllI[3] = (0xFB7E & 0x783);
    lIIIllI[4] = (-(0xE5F9 & 0x5EE7) & 0xCFEF & 0x77F3);
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int lllllllllllllllllIIllIIIIlIIlIIl, World lllllllllllllllllIIllIIIIlIIlIII, double lllllllllllllllllIIllIIIIlIIIlll, double lllllllllllllllllIIllIIIIlIIIllI, double lllllllllllllllllIIllIIIIlIIIlIl, double lllllllllllllllllIIllIIIIlIIIlII, double lllllllllllllllllIIllIIIIlIIIIll, double lllllllllllllllllIIllIIIIlIIIIlI, int... lllllllllllllllllIIllIIIIlIIIIIl)
    {
      ;
      ;
      ;
      ;
      return new MobAppearance(lllllllllllllllllIIllIIIIlIIlIII, lllllllllllllllllIIllIIIIlIIIlll, lllllllllllllllllIIllIIIIlIIIllI, lllllllllllllllllIIllIIIIlIIIlIl);
    }
  }
}

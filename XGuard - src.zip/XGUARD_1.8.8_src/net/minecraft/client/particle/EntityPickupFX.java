package net.minecraft.client.particle;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;

public class EntityPickupFX
  extends EntityFX
{
  public int getFXLayer()
  {
    return lIlIIlIIlllI[0];
  }
  
  public EntityPickupFX(World lllllllllllllllIlIIlIlIlIIIIIIll, Entity lllllllllllllllIlIIlIlIlIIIIIIlI, Entity lllllllllllllllIlIIlIlIlIIIIIIIl, float lllllllllllllllIlIIlIlIlIIIIIIII)
  {
    lllllllllllllllIlIIlIlIlIIIIlIIl.<init>(lllllllllllllllIlIIlIlIlIIIIIIll, posX, posY, posZ, motionX, motionY, motionZ);
    field_174840_a = lllllllllllllllIlIIlIlIlIIIIIlll;
    field_174843_ax = lllllllllllllllIlIIlIlIlIIIIIIIl;
    maxAge = lIlIIlIIlllI[0];
    field_174841_aA = lllllllllllllllIlIIlIlIlIIIIIIII;
  }
  
  public void renderParticle(WorldRenderer lllllllllllllllIlIIlIlIIlllIllll, Entity lllllllllllllllIlIIlIlIIlllIlllI, float lllllllllllllllIlIIlIlIIlllIllIl, float lllllllllllllllIlIIlIlIIlllIllII, float lllllllllllllllIlIIlIlIIlllIlIll, float lllllllllllllllIlIIlIlIIlllIlIlI, float lllllllllllllllIlIIlIlIIlllIlIIl, float lllllllllllllllIlIIlIlIIlllIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIlIIlIlIIlllIIlll = (age + lllllllllllllllIlIIlIlIIlllIllIl) / maxAge;
    lllllllllllllllIlIIlIlIIlllIIlll *= lllllllllllllllIlIIlIlIIlllIIlll;
    double lllllllllllllllIlIIlIlIIlllIIllI = field_174840_a.posX;
    double lllllllllllllllIlIIlIlIIlllIIlIl = field_174840_a.posY;
    double lllllllllllllllIlIIlIlIIlllIIlII = field_174840_a.posZ;
    double lllllllllllllllIlIIlIlIIlllIIIll = field_174843_ax.lastTickPosX + (field_174843_ax.posX - field_174843_ax.lastTickPosX) * lllllllllllllllIlIIlIlIIlllIllIl;
    double lllllllllllllllIlIIlIlIIlllIIIlI = field_174843_ax.lastTickPosY + (field_174843_ax.posY - field_174843_ax.lastTickPosY) * lllllllllllllllIlIIlIlIIlllIllIl + field_174841_aA;
    double lllllllllllllllIlIIlIlIIlllIIIIl = field_174843_ax.lastTickPosZ + (field_174843_ax.posZ - field_174843_ax.lastTickPosZ) * lllllllllllllllIlIIlIlIIlllIllIl;
    double lllllllllllllllIlIIlIlIIlllIIIII = lllllllllllllllIlIIlIlIIlllIIllI + (lllllllllllllllIlIIlIlIIlllIIIll - lllllllllllllllIlIIlIlIIlllIIllI) * lllllllllllllllIlIIlIlIIlllIIlll;
    double lllllllllllllllIlIIlIlIIllIlllll = lllllllllllllllIlIIlIlIIlllIIlIl + (lllllllllllllllIlIIlIlIIlllIIIlI - lllllllllllllllIlIIlIlIIlllIIlIl) * lllllllllllllllIlIIlIlIIlllIIlll;
    double lllllllllllllllIlIIlIlIIllIllllI = lllllllllllllllIlIIlIlIIlllIIlII + (lllllllllllllllIlIIlIlIIlllIIIIl - lllllllllllllllIlIIlIlIIlllIIlII) * lllllllllllllllIlIIlIlIIlllIIlll;
    int lllllllllllllllIlIIlIlIIllIlllIl = lllllllllllllllIlIIlIlIIllllIIII.getBrightnessForRender(lllllllllllllllIlIIlIlIIlllIllIl);
    int lllllllllllllllIlIIlIlIIllIlllII = lllllllllllllllIlIIlIlIIllIlllIl % lIlIIlIIlllI[1];
    int lllllllllllllllIlIIlIlIIllIllIll = lllllllllllllllIlIIlIlIIllIlllIl / lIlIIlIIlllI[1];
    OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, lllllllllllllllIlIIlIlIIllIlllII / 1.0F, lllllllllllllllIlIIlIlIIllIllIll / 1.0F);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    lllllllllllllllIlIIlIlIIlllIIIII -= interpPosX;
    lllllllllllllllIlIIlIlIIllIlllll -= interpPosY;
    lllllllllllllllIlIIlIlIIllIllllI -= interpPosZ;
    "".length();
  }
  
  static {}
  
  private static void llllllllIIlIl()
  {
    lIlIIlIIlllI = new int[3];
    lIlIIlIIlllI[0] = "   ".length();
    lIlIIlIIlllI[1] = (-(0xFF3F & 0x66DC) & 0xEFDB & 0x1763F);
    lIlIIlIIlllI[2] = " ".length();
  }
  
  public void onUpdate()
  {
    ;
    age += lIlIIlIIlllI[2];
    if (llllllllIIllI(age, maxAge)) {
      lllllllllllllllIlIIlIlIIllIIlIIl.setDead();
    }
  }
  
  private static boolean llllllllIIllI(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIlIIlIlIIllIIIlII;
    return ??? == i;
  }
}

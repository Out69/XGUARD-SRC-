package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntitySpellParticleFX
  extends EntityFX
{
  public void setBaseSpellTextureIndex(int llllllllllllllIlIIlIlIllIlIllllI)
  {
    ;
    ;
    baseSpellTextureIndex = llllllllllllllIlIIlIlIllIlIllllI;
  }
  
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + lIIIllIlllIII[2]);
    if (llIlIlllllllIl(tmp29_26, particleMaxAge)) {
      llllllllllllllIlIIlIlIllIllIIIll.setDead();
    }
    llllllllllllllIlIIlIlIllIllIIIll.setParticleTextureIndex(baseSpellTextureIndex + (lIIIllIlllIII[3] - particleAge * lIIIllIlllIII[4] / particleMaxAge));
    motionY += 0.004D;
    llllllllllllllIlIIlIlIllIllIIIll.moveEntity(motionX, motionY, motionZ);
    if (llIlIllllllIll(llIlIlllllllII(posY, prevPosY)))
    {
      motionX *= 1.1D;
      motionZ *= 1.1D;
    }
    motionX *= 0.9599999785423279D;
    motionY *= 0.9599999785423279D;
    motionZ *= 0.9599999785423279D;
    if (llIlIllllllllI(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  private static boolean llIlIllllllIll(int ???)
  {
    boolean llllllllllllllIlIIlIlIllIlIlIlII;
    return ??? == 0;
  }
  
  public void renderParticle(WorldRenderer llllllllllllllIlIIlIlIllIllIllIl, Entity llllllllllllllIlIIlIlIllIllIllII, float llllllllllllllIlIIlIlIllIllIlIll, float llllllllllllllIlIIlIlIllIlllIlII, float llllllllllllllIlIIlIlIllIllIlIIl, float llllllllllllllIlIIlIlIllIllIlIII, float llllllllllllllIlIIlIlIllIllIIlll, float llllllllllllllIlIIlIlIllIllIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIlIIlIlIllIllIllll = (particleAge + llllllllllllllIlIIlIlIllIllIlIll) / particleMaxAge * 32.0F;
    llllllllllllllIlIIlIlIllIllIllll = MathHelper.clamp_float(llllllllllllllIlIIlIlIllIllIllll, 0.0F, 1.0F);
    llllllllllllllIlIIlIlIllIllIlllI.renderParticle(llllllllllllllIlIIlIlIllIllIllIl, llllllllllllllIlIIlIlIllIllIllII, llllllllllllllIlIIlIlIllIllIlIll, llllllllllllllIlIIlIlIllIllIlIlI, llllllllllllllIlIIlIlIllIllIlIIl, llllllllllllllIlIIlIlIllIllIlIII, llllllllllllllIlIIlIlIllIllIIlll, llllllllllllllIlIIlIlIllIllIIllI);
  }
  
  private static boolean llIlIllllllllI(int ???)
  {
    long llllllllllllllIlIIlIlIllIlIlIllI;
    return ??? != 0;
  }
  
  private static boolean llIlIlllllllIl(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIlIIlIlIllIlIllIII;
    return ??? >= i;
  }
  
  private static int llIlIllllllIlI(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  static {}
  
  private static void llIlIllllllIIl()
  {
    lIIIllIlllIII = new int[5];
    lIIIllIlllIII[0] = (48 + 69 - 59 + 70);
    lIIIllIlllIII[1] = ((109 + 47 - 7 + 62 ^ '¥' + 28 - 192 + 192) & (0x3D ^ 0x23 ^ 0x4E ^ 0x42 ^ -" ".length()));
    lIIIllIlllIII[2] = " ".length();
    lIIIllIlllIII[3] = ('' + 58 - 151 + 117 ^ 89 + '¡' - 207 + 125);
    lIIIllIlllIII[4] = (112 + 95 - 114 + 36 ^ 49 + 62 - 104 + 130);
  }
  
  private static int llIlIlllllllII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  protected EntitySpellParticleFX(World llllllllllllllIlIIlIlIlllIIIlIIl, double llllllllllllllIlIIlIlIlllIIlIIII, double llllllllllllllIlIIlIlIlllIIIIlll, double llllllllllllllIlIIlIlIlllIIIlllI, double llllllllllllllIlIIlIlIlllIIIllIl, double llllllllllllllIlIIlIlIlllIIIllII, double llllllllllllllIlIIlIlIlllIIIIIll)
  {
    llllllllllllllIlIIlIlIlllIIIlIlI.<init>(llllllllllllllIlIIlIlIlllIIIlIIl, llllllllllllllIlIIlIlIlllIIlIIII, llllllllllllllIlIIlIlIlllIIIIlll, llllllllllllllIlIIlIlIlllIIIlllI, 0.5D - RANDOM.nextDouble(), llllllllllllllIlIIlIlIlllIIIllII, 0.5D - RANDOM.nextDouble());
    motionY *= 0.20000000298023224D;
    if ((llIlIllllllIll(llIlIllllllIlI(llllllllllllllIlIIlIlIlllIIIllIl, 0.0D))) && (llIlIllllllIll(llIlIllllllIlI(llllllllllllllIlIIlIlIlllIIIIIll, 0.0D))))
    {
      motionX *= 0.10000000149011612D;
      motionZ *= 0.10000000149011612D;
    }
    particleScale *= 0.75F;
    particleMaxAge = ((int)(8.0D / (Math.random() * 0.8D + 0.2D)));
    noClip = lIIIllIlllIII[1];
  }
  
  public static class AmbientMobFactory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int llllllllllllllIlIllIlIllIIlIIlIl, World llllllllllllllIlIllIlIllIIIllIlI, double llllllllllllllIlIllIlIllIIIllIIl, double llllllllllllllIlIllIlIllIIIllIII, double llllllllllllllIlIllIlIllIIlIIIIl, double llllllllllllllIlIllIlIllIIIlIllI, double llllllllllllllIlIllIlIllIIIlllll, double llllllllllllllIlIllIlIllIIIllllI, int... llllllllllllllIlIllIlIllIIIlllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      EntityFX llllllllllllllIlIllIlIllIIIlllII = new EntitySpellParticleFX(llllllllllllllIlIllIlIllIIIllIlI, llllllllllllllIlIllIlIllIIIllIIl, llllllllllllllIlIllIlIllIIIllIII, llllllllllllllIlIllIlIllIIlIIIIl, llllllllllllllIlIllIlIllIIIlIllI, llllllllllllllIlIllIlIllIIIlllll, llllllllllllllIlIllIlIllIIIllllI);
      llllllllllllllIlIllIlIllIIIlllII.setAlphaF(0.15F);
      llllllllllllllIlIllIlIllIIIlllII.setRBGColorF((float)llllllllllllllIlIllIlIllIIIlIllI, (float)llllllllllllllIlIllIlIllIIIlllll, (float)llllllllllllllIlIllIlIllIIIllllI);
      return llllllllllllllIlIllIlIllIIIlllII;
    }
    
    public AmbientMobFactory() {}
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int lIllllIIIIIllll, World lIllllIIIIIIllI, double lIllllIIIIIllIl, double lIllllIIIIIIlII, double lIllllIIIIIlIll, double lIllllIIIIIlIlI, double lIllllIIIIIIIIl, double lIllllIIIIIIIII, int... lIllllIIIIIIlll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntitySpellParticleFX(lIllllIIIIIIllI, lIllllIIIIIllIl, lIllllIIIIIIlII, lIllllIIIIIlIll, lIllllIIIIIlIlI, lIllllIIIIIIIIl, lIllllIIIIIIIII);
    }
    
    public Factory() {}
  }
  
  public static class InstantFactory
    implements IParticleFactory
  {
    private static void lllIIIIIIlIllI()
    {
      lIIlIIllIIIlI = new int[1];
      lIIlIIllIIIlI[0] = ((0x46 ^ 0x68) + (0x7D ^ 0xA) - (117 + 67 - 153 + 104) + (0x51 ^ 0x23));
    }
    
    public EntityFX getEntityFX(int llllllllllllllIlIIIIlIIIIIllIlIl, World llllllllllllllIlIIIIlIIIIIllIlII, double llllllllllllllIlIIIIlIIIIIlIlIIl, double llllllllllllllIlIIIIlIIIIIllIIlI, double llllllllllllllIlIIIIlIIIIIllIIIl, double llllllllllllllIlIIIIlIIIIIllIIII, double llllllllllllllIlIIIIlIIIIIlIllll, double llllllllllllllIlIIIIlIIIIIlIIlII, int... llllllllllllllIlIIIIlIIIIIlIllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      EntityFX llllllllllllllIlIIIIlIIIIIlIllII = new EntitySpellParticleFX(llllllllllllllIlIIIIlIIIIIllIlII, llllllllllllllIlIIIIlIIIIIlIlIIl, llllllllllllllIlIIIIlIIIIIllIIlI, llllllllllllllIlIIIIlIIIIIllIIIl, llllllllllllllIlIIIIlIIIIIllIIII, llllllllllllllIlIIIIlIIIIIlIllll, llllllllllllllIlIIIIlIIIIIlIIlII);
      ((EntitySpellParticleFX)llllllllllllllIlIIIIlIIIIIlIllII).setBaseSpellTextureIndex(lIIlIIllIIIlI[0]);
      return llllllllllllllIlIIIIlIIIIIlIllII;
    }
    
    static {}
    
    public InstantFactory() {}
  }
  
  public static class WitchFactory
    implements IParticleFactory
  {
    public WitchFactory() {}
    
    public EntityFX getEntityFX(int lllllllllllllllIIlllllIIIIlllllI, World lllllllllllllllIIlllllIIIIllIIIl, double lllllllllllllllIIlllllIIIIllllII, double lllllllllllllllIIlllllIIIIlIllll, double lllllllllllllllIIlllllIIIIlllIlI, double lllllllllllllllIIlllllIIIIlIllIl, double lllllllllllllllIIlllllIIIIlIllII, double lllllllllllllllIIlllllIIIIlIlIll, int... lllllllllllllllIIlllllIIIIllIllI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      EntityFX lllllllllllllllIIlllllIIIIllIlIl = new EntitySpellParticleFX(lllllllllllllllIIlllllIIIIllIIIl, lllllllllllllllIIlllllIIIIllllII, lllllllllllllllIIlllllIIIIlIllll, lllllllllllllllIIlllllIIIIlllIlI, lllllllllllllllIIlllllIIIIlIllIl, lllllllllllllllIIlllllIIIIlIllII, lllllllllllllllIIlllllIIIIlIlIll);
      ((EntitySpellParticleFX)lllllllllllllllIIlllllIIIIllIlIl).setBaseSpellTextureIndex(lIlIllIIllll[0]);
      float lllllllllllllllIIlllllIIIIllIlII = rand.nextFloat() * 0.5F + 0.35F;
      lllllllllllllllIIlllllIIIIllIlIl.setRBGColorF(1.0F * lllllllllllllllIIlllllIIIIllIlII, 0.0F * lllllllllllllllIIlllllIIIIllIlII, 1.0F * lllllllllllllllIIlllllIIIIllIlII);
      return lllllllllllllllIIlllllIIIIllIlIl;
    }
    
    static {}
    
    private static void lIIIIlIlllIIlI()
    {
      lIlIllIIllll = new int[1];
      lIlIllIIllll[0] = ((0x36 ^ 0x55) + (25 + 107 - 125 + 135) - (0x22 ^ 0x53) + (0x4D ^ 0x5D));
    }
  }
  
  public static class MobFactory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int llllllllllllllllIllIIlIIlIllllll, World llllllllllllllllIllIIlIIlIlllllI, double llllllllllllllllIllIIlIIlIllIIll, double llllllllllllllllIllIIlIIlIllIIlI, double llllllllllllllllIllIIlIIlIlllIll, double llllllllllllllllIllIIlIIlIlllIlI, double llllllllllllllllIllIIlIIlIlIllll, double llllllllllllllllIllIIlIIlIlIlllI, int... llllllllllllllllIllIIlIIlIllIlll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      EntityFX llllllllllllllllIllIIlIIlIllIllI = new EntitySpellParticleFX(llllllllllllllllIllIIlIIlIlllllI, llllllllllllllllIllIIlIIlIllIIll, llllllllllllllllIllIIlIIlIllIIlI, llllllllllllllllIllIIlIIlIlllIll, llllllllllllllllIllIIlIIlIlllIlI, llllllllllllllllIllIIlIIlIlIllll, llllllllllllllllIllIIlIIlIlIlllI);
      llllllllllllllllIllIIlIIlIllIllI.setRBGColorF((float)llllllllllllllllIllIIlIIlIlllIlI, (float)llllllllllllllllIllIIlIIlIlIllll, (float)llllllllllllllllIllIIlIIlIlIlllI);
      return llllllllllllllllIllIIlIIlIllIllI;
    }
    
    public MobFactory() {}
  }
}

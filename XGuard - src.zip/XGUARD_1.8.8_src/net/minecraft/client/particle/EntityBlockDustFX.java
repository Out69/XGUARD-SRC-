package net.minecraft.client.particle;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.world.World;

public class EntityBlockDustFX
  extends EntityDiggingFX
{
  protected EntityBlockDustFX(World llllllllllllllIllIllIlIIIllIIIlI, double llllllllllllllIllIllIlIIIllIlIlI, double llllllllllllllIllIllIlIIIllIIIII, double llllllllllllllIllIllIlIIIllIlIII, double llllllllllllllIllIllIlIIIlIllllI, double llllllllllllllIllIllIlIIIlIlllIl, double llllllllllllllIllIllIlIIIlIlllII, IBlockState llllllllllllllIllIllIlIIIllIIlII)
  {
    llllllllllllllIllIllIlIIIllIllII.<init>(llllllllllllllIllIllIlIIIllIIIlI, llllllllllllllIllIllIlIIIllIlIlI, llllllllllllllIllIllIlIIIllIIIII, llllllllllllllIllIllIlIIIlIlllll, llllllllllllllIllIllIlIIIlIllllI, llllllllllllllIllIllIlIIIlIlllIl, llllllllllllllIllIllIlIIIlIlllII, llllllllllllllIllIllIlIIIllIIlII);
    motionX = llllllllllllllIllIllIlIIIlIllllI;
    motionY = llllllllllllllIllIllIlIIIlIlllIl;
    motionZ = llllllllllllllIllIllIlIIIlIlllII;
  }
  
  public static class Factory
    implements IParticleFactory
  {
    static {}
    
    private static void lllIIIIlIlIl()
    {
      lIIIllIlIIl = new int[2];
      lIIIllIlIIl[0] = ((0xCB ^ 0xC7 ^ 0x1D ^ 0x55) & (0xC2 ^ 0x8D ^ 0x8C ^ 0x87 ^ -" ".length()));
      lIIIllIlIIl[1] = (-" ".length());
    }
    
    private static boolean lllIIIIlIllI(int ???, int arg1)
    {
      int i;
      float lllllllllllllllllIlIlIIlIIIlllII;
      return ??? == i;
    }
    
    public EntityFX getEntityFX(int lllllllllllllllllIlIlIIlIIllIIlI, World lllllllllllllllllIlIlIIlIIlIIlll, double lllllllllllllllllIlIlIIlIIllIIII, double lllllllllllllllllIlIlIIlIIlIllll, double lllllllllllllllllIlIlIIlIIlIlllI, double lllllllllllllllllIlIlIIlIIlIIIll, double lllllllllllllllllIlIlIIlIIlIIIlI, double lllllllllllllllllIlIlIIlIIlIIIIl, int... lllllllllllllllllIlIlIIlIIlIIIII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      IBlockState lllllllllllllllllIlIlIIlIIlIlIIl = Block.getStateById(lllllllllllllllllIlIlIIlIIlIIIII[lIIIllIlIIl[0]]);
      if (lllIIIIlIllI(lllllllllllllllllIlIlIIlIIlIlIIl.getBlock().getRenderType(), lIIIllIlIIl[1]))
      {
        "".length();
        if (-" ".length() < "   ".length()) {
          break label81;
        }
        return null;
      }
      label81:
      return new EntityBlockDustFX(lllllllllllllllllIlIlIIlIIlIIlll, lllllllllllllllllIlIlIIlIIllIIII, lllllllllllllllllIlIlIIlIIlIllll, lllllllllllllllllIlIlIIlIIlIlllI, lllllllllllllllllIlIlIIlIIlIIIll, lllllllllllllllllIlIlIIlIIlIIIlI, lllllllllllllllllIlIlIIlIIlIIIIl, lllllllllllllllllIlIlIIlIIlIlIIl).func_174845_l();
    }
    
    public Factory() {}
  }
}

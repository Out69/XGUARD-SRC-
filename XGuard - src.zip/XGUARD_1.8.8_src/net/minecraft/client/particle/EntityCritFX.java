package net.minecraft.client.particle;

import net.minecraft.world.World;

public class EntityCritFX
  extends EntitySmokeFX
{
  protected EntityCritFX(World lllllllllllllllllIIllIIllIllIIlI, double lllllllllllllllllIIllIIllIlIlIIl, double lllllllllllllllllIIllIIllIllIIII, double lllllllllllllllllIIllIIllIlIllll, double lllllllllllllllllIIllIIllIlIlllI, double lllllllllllllllllIIllIIllIlIllIl, double lllllllllllllllllIIllIIllIlIIlII)
  {
    lllllllllllllllllIIllIIllIlIlIll.<init>(lllllllllllllllllIIllIIllIllIIlI, lllllllllllllllllIIllIIllIlIlIIl, lllllllllllllllllIIllIIllIllIIII, lllllllllllllllllIIllIIllIlIllll, lllllllllllllllllIIllIIllIlIlllI, lllllllllllllllllIIllIIllIlIllIl, lllllllllllllllllIIllIIllIlIIlII, 2.5F);
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int lllllllllllllllIlIlllIllIIIIlIll, World lllllllllllllllIlIlllIllIIIIIIlI, double lllllllllllllllIlIlllIllIIIIIIIl, double lllllllllllllllIlIlllIllIIIIlIII, double lllllllllllllllIlIlllIllIIIIIlll, double lllllllllllllllIlIlllIlIlllllllI, double lllllllllllllllIlIlllIllIIIIIlIl, double lllllllllllllllIlIlllIlIllllllII, int... lllllllllllllllIlIlllIllIIIIIIll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityCritFX(lllllllllllllllIlIlllIllIIIIIIlI, lllllllllllllllIlIlllIllIIIIIIIl, lllllllllllllllIlIlllIllIIIIlIII, lllllllllllllllIlIlllIllIIIIIlll, lllllllllllllllIlIlllIlIlllllllI, lllllllllllllllIlIlllIllIIIIIlIl, lllllllllllllllIlIlllIlIllllllII);
    }
    
    public Factory() {}
  }
}

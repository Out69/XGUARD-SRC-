package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.world.World;

public class EntityParticleEmitter
  extends EntityFX
{
  public int getFXLayer()
  {
    return lIIlIllIIIIlI[0];
  }
  
  private static int lllIIlIlllIIlI(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean lllIIlIlllIlII(int ???, int arg1)
  {
    int i;
    long llllllllllllllIIllllIIIIIIlIlIll;
    return ??? >= i;
  }
  
  static {}
  
  public void renderParticle(WorldRenderer llllllllllllllIIllllIIIIIlIIllll, Entity llllllllllllllIIllllIIIIIlIIlllI, float llllllllllllllIIllllIIIIIlIIllIl, float llllllllllllllIIllllIIIIIlIIllII, float llllllllllllllIIllllIIIIIlIIlIll, float llllllllllllllIIllllIIIIIlIIlIlI, float llllllllllllllIIllllIIIIIlIIlIIl, float llllllllllllllIIllllIIIIIlIIlIII) {}
  
  private static boolean lllIIlIlllIIll(int ???)
  {
    long llllllllllllllIIllllIIIIIIlIlIIl;
    return ??? <= 0;
  }
  
  private static void lllIIlIlllIIIl()
  {
    lIIlIllIIIIlI = new int[4];
    lIIlIllIIIIlI[0] = "   ".length();
    lIIlIllIIIIlI[1] = ((25 + 99 - -8 + 35 ^ 22 + 28 - 11 + 141) & (0x86 ^ 0x88 ^ 0x74 ^ 0x69 ^ -" ".length()));
    lIIlIllIIIIlI[2] = (0x24 ^ 0x42 ^ 0xD8 ^ 0xAE);
    lIIlIllIIIIlI[3] = " ".length();
  }
  
  public void onUpdate()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIIllllIIIIIIlllllI = lIIlIllIIIIlI[1];
    "".length();
    if (-" ".length() == "  ".length()) {
      return;
    }
    while (!lllIIlIlllIlII(llllllllllllllIIllllIIIIIIlllllI, lIIlIllIIIIlI[2]))
    {
      double llllllllllllllIIllllIIIIIIllllIl = rand.nextFloat() * 2.0F - 1.0F;
      double llllllllllllllIIllllIIIIIIllllII = rand.nextFloat() * 2.0F - 1.0F;
      double llllllllllllllIIllllIIIIIIlllIll = rand.nextFloat() * 2.0F - 1.0F;
      if (lllIIlIlllIIll(lllIIlIlllIIlI(llllllllllllllIIllllIIIIIIllllIl * llllllllllllllIIllllIIIIIIllllIl + llllllllllllllIIllllIIIIIIllllII * llllllllllllllIIllllIIIIIIllllII + llllllllllllllIIllllIIIIIIlllIll * llllllllllllllIIllllIIIIIIlllIll, 1.0D)))
      {
        double llllllllllllllIIllllIIIIIIlllIlI = attachedEntity.posX + llllllllllllllIIllllIIIIIIllllIl * attachedEntity.width / 4.0D;
        double llllllllllllllIIllllIIIIIIlllIIl = attachedEntity.getEntityBoundingBox().minY + attachedEntity.height / 2.0F + llllllllllllllIIllllIIIIIIllllII * attachedEntity.height / 4.0D;
        double llllllllllllllIIllllIIIIIIlllIII = attachedEntity.posZ + llllllllllllllIIllllIIIIIIlllIll * attachedEntity.width / 4.0D;
        worldObj.spawnParticle(particleTypes, lIIlIllIIIIlI[1], llllllllllllllIIllllIIIIIIlllIlI, llllllllllllllIIllllIIIIIIlllIIl, llllllllllllllIIllllIIIIIIlllIII, llllllllllllllIIllllIIIIIIllllIl, llllllllllllllIIllllIIIIIIllllII + 0.2D, llllllllllllllIIllllIIIIIIlllIll, new int[lIIlIllIIIIlI[1]]);
      }
      llllllllllllllIIllllIIIIIIlllllI++;
    }
    age += lIIlIllIIIIlI[3];
    if (lllIIlIlllIlII(age, lifetime)) {
      llllllllllllllIIllllIIIIIIllIlll.setDead();
    }
  }
  
  public EntityParticleEmitter(World llllllllllllllIIllllIIIIIlIlIIll, Entity llllllllllllllIIllllIIIIIlIlIIlI, EnumParticleTypes llllllllllllllIIllllIIIIIlIlIlIl)
  {
    llllllllllllllIIllllIIIIIlIllIII.<init>(llllllllllllllIIllllIIIIIlIlIIll, posX, getEntityBoundingBoxminY + height / 2.0F, posZ, motionX, motionY, motionZ);
    attachedEntity = llllllllllllllIIllllIIIIIlIlIIlI;
    lifetime = lIIlIllIIIIlI[0];
    particleTypes = llllllllllllllIIllllIIIIIlIlIlIl;
    llllllllllllllIIllllIIIIIlIllIII.onUpdate();
  }
}

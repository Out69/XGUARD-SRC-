package net.minecraft.client.particle;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ItemModelMesher;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.world.World;

public class Barrier
  extends EntityFX
{
  public void renderParticle(WorldRenderer lllllllllllllllllIlIIlIIlIlllllI, Entity lllllllllllllllllIlIIlIIlIllllIl, float lllllllllllllllllIlIIlIIlIllllII, float lllllllllllllllllIlIIlIIlIlIlIII, float lllllllllllllllllIlIIlIIlIlIIlll, float lllllllllllllllllIlIIlIIlIlIIllI, float lllllllllllllllllIlIIlIIlIlIIlIl, float lllllllllllllllllIlIIlIIlIlIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllllIlIIlIIlIllIllI = particleIcon.getMinU();
    float lllllllllllllllllIlIIlIIlIllIlIl = particleIcon.getMaxU();
    float lllllllllllllllllIlIIlIIlIllIlII = particleIcon.getMinV();
    float lllllllllllllllllIlIIlIIlIllIIll = particleIcon.getMaxV();
    float lllllllllllllllllIlIIlIIlIllIIlI = 0.5F;
    float lllllllllllllllllIlIIlIIlIllIIIl = (float)(prevPosX + (posX - prevPosX) * lllllllllllllllllIlIIlIIlIllllII - interpPosX);
    float lllllllllllllllllIlIIlIIlIllIIII = (float)(prevPosY + (posY - prevPosY) * lllllllllllllllllIlIIlIIlIllllII - interpPosY);
    float lllllllllllllllllIlIIlIIlIlIllll = (float)(prevPosZ + (posZ - prevPosZ) * lllllllllllllllllIlIIlIIlIllllII - interpPosZ);
    int lllllllllllllllllIlIIlIIlIlIlllI = lllllllllllllllllIlIIlIIlIlIlIll.getBrightnessForRender(lllllllllllllllllIlIIlIIlIllllII);
    int lllllllllllllllllIlIIlIIlIlIllIl = lllllllllllllllllIlIIlIIlIlIlllI >> lIIlIIlIIll[2] & lIIlIIlIIll[3];
    int lllllllllllllllllIlIIlIIlIlIllII = lllllllllllllllllIlIIlIIlIlIlllI & lIIlIIlIIll[3];
    lllllllllllllllllIlIIlIIlIlllllI.pos(lllllllllllllllllIlIIlIIlIllIIIl - lllllllllllllllllIlIIlIIlIlIlIII * 0.5F - lllllllllllllllllIlIIlIIlIlIIlIl * 0.5F, lllllllllllllllllIlIIlIIlIllIIII - lllllllllllllllllIlIIlIIlIlIIlll * 0.5F, lllllllllllllllllIlIIlIIlIlIllll - lllllllllllllllllIlIIlIIlIlIIllI * 0.5F - lllllllllllllllllIlIIlIIlIlIIlII * 0.5F).tex(lllllllllllllllllIlIIlIIlIllIlIl, lllllllllllllllllIlIIlIIlIllIIll).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lllllllllllllllllIlIIlIIlIlIllIl, lllllllllllllllllIlIIlIIlIlIllII).endVertex();
    lllllllllllllllllIlIIlIIlIlllllI.pos(lllllllllllllllllIlIIlIIlIllIIIl - lllllllllllllllllIlIIlIIlIlIlIII * 0.5F + lllllllllllllllllIlIIlIIlIlIIlIl * 0.5F, lllllllllllllllllIlIIlIIlIllIIII + lllllllllllllllllIlIIlIIlIlIIlll * 0.5F, lllllllllllllllllIlIIlIIlIlIllll - lllllllllllllllllIlIIlIIlIlIIllI * 0.5F + lllllllllllllllllIlIIlIIlIlIIlII * 0.5F).tex(lllllllllllllllllIlIIlIIlIllIlIl, lllllllllllllllllIlIIlIIlIllIlII).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lllllllllllllllllIlIIlIIlIlIllIl, lllllllllllllllllIlIIlIIlIlIllII).endVertex();
    lllllllllllllllllIlIIlIIlIlllllI.pos(lllllllllllllllllIlIIlIIlIllIIIl + lllllllllllllllllIlIIlIIlIlIlIII * 0.5F + lllllllllllllllllIlIIlIIlIlIIlIl * 0.5F, lllllllllllllllllIlIIlIIlIllIIII + lllllllllllllllllIlIIlIIlIlIIlll * 0.5F, lllllllllllllllllIlIIlIIlIlIllll + lllllllllllllllllIlIIlIIlIlIIllI * 0.5F + lllllllllllllllllIlIIlIIlIlIIlII * 0.5F).tex(lllllllllllllllllIlIIlIIlIllIllI, lllllllllllllllllIlIIlIIlIllIlII).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lllllllllllllllllIlIIlIIlIlIllIl, lllllllllllllllllIlIIlIIlIlIllII).endVertex();
    lllllllllllllllllIlIIlIIlIlllllI.pos(lllllllllllllllllIlIIlIIlIllIIIl + lllllllllllllllllIlIIlIIlIlIlIII * 0.5F - lllllllllllllllllIlIIlIIlIlIIlIl * 0.5F, lllllllllllllllllIlIIlIIlIllIIII - lllllllllllllllllIlIIlIIlIlIIlll * 0.5F, lllllllllllllllllIlIIlIIlIlIllll + lllllllllllllllllIlIIlIIlIlIIllI * 0.5F - lllllllllllllllllIlIIlIIlIlIIlII * 0.5F).tex(lllllllllllllllllIlIIlIIlIllIllI, lllllllllllllllllIlIIlIIlIllIIll).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lllllllllllllllllIlIIlIIlIlIllIl, lllllllllllllllllIlIIlIIlIlIllII).endVertex();
  }
  
  static {}
  
  private static void lllIIlllIIII()
  {
    lIIlIIlIIll = new int[4];
    lIIlIIlIIll[0] = (0x5D ^ 0xF ^ "  ".length());
    lIIlIIlIIll[1] = " ".length();
    lIIlIIlIIll[2] = (0x33 ^ 0x23);
    lIIlIIlIIll[3] = (-" ".length() & 0xFFFFFFFF & 0xFFFF);
  }
  
  protected Barrier(World lllllllllllllllllIlIIlIIllIllllI, double lllllllllllllllllIlIIlIIllIlllIl, double lllllllllllllllllIlIIlIIllIlllII, double lllllllllllllllllIlIIlIIllIlIlIl, Item lllllllllllllllllIlIIlIIllIllIlI)
  {
    lllllllllllllllllIlIIlIIllIllIIl.<init>(lllllllllllllllllIlIIlIIllIllllI, lllllllllllllllllIlIIlIIllIlllIl, lllllllllllllllllIlIIlIIllIlllII, lllllllllllllllllIlIIlIIllIlIlIl, 0.0D, 0.0D, 0.0D);
    lllllllllllllllllIlIIlIIllIllIIl.setParticleIcon(Minecraft.getMinecraft().getRenderItem().getItemModelMesher().getParticleIcon(lllllllllllllllllIlIIlIIllIllIlI));
    particleRed = (lllllllllllllllllIlIIlIIllIllIIl.particleGreen = lllllllllllllllllIlIIlIIllIllIIl.particleBlue = 1.0F);
    motionX = (lllllllllllllllllIlIIlIIllIllIIl.motionY = lllllllllllllllllIlIIlIIllIllIIl.motionZ = 0.0D);
    particleGravity = 0.0F;
    particleMaxAge = lIIlIIlIIll[0];
  }
  
  public int getFXLayer()
  {
    return lIIlIIlIIll[1];
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIllIIlIIllIlllIlII, World llllllllllllllIllIIlIIllIllIlIll, double llllllllllllllIllIIlIIllIllIlIlI, double llllllllllllllIllIIlIIllIlllIIIl, double llllllllllllllIllIIlIIllIllIlIII, double llllllllllllllIllIIlIIllIllIllll, double llllllllllllllIllIIlIIllIllIlllI, double llllllllllllllIllIIlIIllIllIllIl, int... llllllllllllllIllIIlIIllIllIllII)
    {
      ;
      ;
      ;
      ;
      return new Barrier(llllllllllllllIllIIlIIllIllIlIll, llllllllllllllIllIIlIIllIllIlIlI, llllllllllllllIllIIlIIllIlllIIIl, llllllllllllllIllIIlIIllIllIlIII, Item.getItemFromBlock(Blocks.barrier));
    }
  }
}

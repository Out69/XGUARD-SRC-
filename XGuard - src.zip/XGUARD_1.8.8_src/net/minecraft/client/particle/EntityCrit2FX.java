package net.minecraft.client.particle;

import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityCrit2FX
  extends EntityFX
{
  public void onUpdate()
  {
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + lllllIIIIIl[2]);
    if (lIllllllIIIII(tmp29_26, particleMaxAge)) {
      llllllllllllllllIIIlIllIlIIIIIIl.setDead();
    }
    llllllllllllllllIIIlIllIlIIIIIIl.moveEntity(motionX, motionY, motionZ);
    particleGreen = ((float)(particleGreen * 0.96D));
    particleBlue = ((float)(particleBlue * 0.9D));
    motionX *= 0.699999988079071D;
    motionY *= 0.699999988079071D;
    motionZ *= 0.699999988079071D;
    motionY -= 0.019999999552965164D;
    if (lIllllllIIIIl(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  private static boolean lIllllllIIIIl(int ???)
  {
    int llllllllllllllllIIIlIllIIllllIlI;
    return ??? != 0;
  }
  
  protected EntityCrit2FX(World llllllllllllllllIIIlIllIllIIlIlI, double llllllllllllllllIIIlIllIllIIlIIl, double llllllllllllllllIIIlIllIllIIlIII, double llllllllllllllllIIIlIllIllIIIlll, double llllllllllllllllIIIlIllIllIIIllI, double llllllllllllllllIIIlIllIlIllllIl, double llllllllllllllllIIIlIllIllIIIlII)
  {
    llllllllllllllllIIIlIllIllIIIIll.<init>(llllllllllllllllIIIlIllIllIIlIlI, llllllllllllllllIIIlIllIllIIlIIl, llllllllllllllllIIIlIllIllIIlIII, llllllllllllllllIIIlIllIllIIIlll, llllllllllllllllIIIlIllIllIIIllI, llllllllllllllllIIIlIllIlIllllIl, llllllllllllllllIIIlIllIllIIIlII, 1.0F);
  }
  
  protected EntityCrit2FX(World llllllllllllllllIIIlIllIlIllIIIl, double llllllllllllllllIIIlIllIlIlIIlll, double llllllllllllllllIIIlIllIlIlIIllI, double llllllllllllllllIIIlIllIlIlIlllI, double llllllllllllllllIIIlIllIlIlIllIl, double llllllllllllllllIIIlIllIlIlIIIll, double llllllllllllllllIIIlIllIlIlIIIlI, float llllllllllllllllIIIlIllIlIlIlIlI)
  {
    llllllllllllllllIIIlIllIlIlIlIIl.<init>(llllllllllllllllIIIlIllIlIllIIIl, llllllllllllllllIIIlIllIlIlIIlll, llllllllllllllllIIIlIllIlIlIIllI, llllllllllllllllIIIlIllIlIlIIlIl, 0.0D, 0.0D, 0.0D);
    motionX *= 0.10000000149011612D;
    motionY *= 0.10000000149011612D;
    motionZ *= 0.10000000149011612D;
    motionX += llllllllllllllllIIIlIllIlIlIllIl * 0.4D;
    motionY += llllllllllllllllIIIlIllIlIlIIIll * 0.4D;
    motionZ += llllllllllllllllIIIlIllIlIlIIIlI * 0.4D;
    particleRed = (llllllllllllllllIIIlIllIlIlIlIIl.particleGreen = llllllllllllllllIIIlIllIlIlIlIIl.particleBlue = (float)(Math.random() * 0.30000001192092896D + 0.6000000238418579D));
    particleScale *= 0.75F;
    particleScale *= llllllllllllllllIIIlIllIlIlIlIlI;
    field_174839_a = particleScale;
    particleMaxAge = ((int)(6.0D / (Math.random() * 0.8D + 0.6D)));
    particleMaxAge = ((int)(particleMaxAge * llllllllllllllllIIIlIllIlIlIlIlI));
    noClip = lllllIIIIIl[0];
    llllllllllllllllIIIlIllIlIlIlIIl.setParticleTextureIndex(lllllIIIIIl[1]);
    llllllllllllllllIIIlIllIlIlIlIIl.onUpdate();
  }
  
  public void renderParticle(WorldRenderer llllllllllllllllIIIlIllIlIIIlIll, Entity llllllllllllllllIIIlIllIlIIIlIlI, float llllllllllllllllIIIlIllIlIIIlIIl, float llllllllllllllllIIIlIllIlIIlIIlI, float llllllllllllllllIIIlIllIlIIIIlll, float llllllllllllllllIIIlIllIlIIIIllI, float llllllllllllllllIIIlIllIlIIIIlIl, float llllllllllllllllIIIlIllIlIIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllllIIIlIllIlIIIllIl = (particleAge + llllllllllllllllIIIlIllIlIIIlIIl) / particleMaxAge * 32.0F;
    llllllllllllllllIIIlIllIlIIIllIl = MathHelper.clamp_float(llllllllllllllllIIIlIllIlIIIllIl, 0.0F, 1.0F);
    particleScale = (field_174839_a * llllllllllllllllIIIlIllIlIIIllIl);
    llllllllllllllllIIIlIllIlIIlIllI.renderParticle(llllllllllllllllIIIlIllIlIIIlIll, llllllllllllllllIIIlIllIlIIIlIlI, llllllllllllllllIIIlIllIlIIIlIIl, llllllllllllllllIIIlIllIlIIIlIII, llllllllllllllllIIIlIllIlIIIIlll, llllllllllllllllIIIlIllIlIIIIllI, llllllllllllllllIIIlIllIlIIIIlIl, llllllllllllllllIIIlIllIlIIIlllI);
  }
  
  private static void lIlllllIlllll()
  {
    lllllIIIIIl = new int[3];
    lllllIIIIIl[0] = ((0xF4 ^ 0xAE ^ 0x6 ^ 0x57) & (29 + 116 - 33 + 52 ^ 10 + 73 - -91 + 1 ^ -" ".length()));
    lllllIIIIIl[1] = (0x2F ^ 0x6E);
    lllllIIIIIl[2] = " ".length();
  }
  
  static {}
  
  private static boolean lIllllllIIIII(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllllIIIlIllIIlllllII;
    return ??? >= i;
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int llllllllllllllllllIIIllIIIIlIlIl, World llllllllllllllllllIIIllIIIIlIlII, double llllllllllllllllllIIIllIIIIlIIll, double llllllllllllllllllIIIllIIIIlIIlI, double llllllllllllllllllIIIllIIIIlIIIl, double llllllllllllllllllIIIllIIIIlIIII, double llllllllllllllllllIIIllIIIIIIlll, double llllllllllllllllllIIIllIIIIIlllI, int... llllllllllllllllllIIIllIIIIIllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityCrit2FX(llllllllllllllllllIIIllIIIIlIlII, llllllllllllllllllIIIllIIIIlIIll, llllllllllllllllllIIIllIIIIlIIlI, llllllllllllllllllIIIllIIIIlIIIl, llllllllllllllllllIIIllIIIIlIIII, llllllllllllllllllIIIllIIIIIIlll, llllllllllllllllllIIIllIIIIIlllI);
    }
  }
  
  public static class MagicFactory
    implements IParticleFactory
  {
    public MagicFactory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIlIllIIIlllIIlIlIl, World llllllllllllllIlIllIIIlllIIIlIlI, double llllllllllllllIlIllIIIlllIIlIIll, double llllllllllllllIlIllIIIlllIIIlIII, double llllllllllllllIlIllIIIlllIIIIlll, double llllllllllllllIlIllIIIlllIIlIIII, double llllllllllllllIlIllIIIlllIIIllll, double llllllllllllllIlIllIIIlllIIIIlII, int... llllllllllllllIlIllIIIlllIIIllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      EntityFX llllllllllllllIlIllIIIlllIIIllII = new EntityCrit2FX(llllllllllllllIlIllIIIlllIIIlIlI, llllllllllllllIlIllIIIlllIIlIIll, llllllllllllllIlIllIIIlllIIIlIII, llllllllllllllIlIllIIIlllIIIIlll, llllllllllllllIlIllIIIlllIIlIIII, llllllllllllllIlIllIIIlllIIIllll, llllllllllllllIlIllIIIlllIIIIlII);
      llllllllllllllIlIllIIIlllIIIllII.setRBGColorF(llllllllllllllIlIllIIIlllIIIllII.getRedColorF() * 0.3F, llllllllllllllIlIllIIIlllIIIllII.getGreenColorF() * 0.8F, llllllllllllllIlIllIIIlllIIIllII.getBlueColorF());
      llllllllllllllIlIllIIIlllIIIllII.nextTextureIndexX();
      return llllllllllllllIlIllIIIlllIIIllII;
    }
  }
}

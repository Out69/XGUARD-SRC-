package net.minecraft.client.particle;

import com.google.common.collect.Lists;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Callable;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ReportedException;
import net.minecraft.world.World;
import optfine.Config;
import optfine.Reflector;
import optfine.ReflectorMethod;

public class EffectRenderer
{
  private void tickParticle(final EntityFX lllllllllllllllIlIlIlIIlIlllIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIlIlIlIIlIlllIlll.onUpdate();
      "".length();
      if ("  ".length() < "  ".length()) {}
    }
    catch (Throwable lllllllllllllllIlIlIlIIlIlllIllI)
    {
      ;
      CrashReport lllllllllllllllIlIlIlIIlIlllIlIl = CrashReport.makeCrashReport(lllllllllllllllIlIlIlIIlIlllIllI, lIIlllllIlIl[lIIllllllIIl[3]]);
      CrashReportCategory lllllllllllllllIlIlIlIIlIlllIlII = lllllllllllllllIlIlIlIIlIlllIlIl.makeCategory(lIIlllllIlIl[lIIllllllIIl[5]]);
      final int lllllllllllllllIlIlIlIIlIlllIIll = lllllllllllllllIlIlIlIIlIlllIlll.getFXLayer();
      lllllllllllllllIlIlIlIIlIlllIlII.addCrashSectionCallable(lIIlllllIlIl[lIIllllllIIl[2]], new Callable()
      {
        private static void lIllIIlIllII()
        {
          llIllllIII = new int[4];
          llIllllIII[0] = ((54 + 50 - -58 + 13 ^ '´' + 92 - 125 + 35) & (0xA2 ^ 0xB2 ^ 0x6E ^ 0x67 ^ -" ".length()));
          llIllllIII[1] = " ".length();
          llIllllIII[2] = (0xB8 ^ 0xB0);
          llIllllIII[3] = "  ".length();
        }
        
        public String call()
          throws Exception
        {
          ;
          return lllllllllllllllIlIlIlIIlIlllIlll.toString();
        }
        
        static
        {
          lIllIIlIllII();
          lIlIlIlIIlIl();
        }
        
        private static String lIlIlIlIIlII(String llllllllllllllllllIlIllIIlllIlIl, String llllllllllllllllllIlIllIIlllIlII)
        {
          try
          {
            ;
            ;
            ;
            ;
            SecretKeySpec llllllllllllllllllIlIllIIllllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlIllIIlllIlII.getBytes(StandardCharsets.UTF_8)), llIllllIII[2]), "DES");
            Cipher llllllllllllllllllIlIllIIllllIIl = Cipher.getInstance("DES");
            llllllllllllllllllIlIllIIllllIIl.init(llIllllIII[3], llllllllllllllllllIlIllIIllllIlI);
            return new String(llllllllllllllllllIlIllIIllllIIl.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlIllIIlllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
          }
          catch (Exception llllllllllllllllllIlIllIIllllIII)
          {
            llllllllllllllllllIlIllIIllllIII.printStackTrace();
          }
          return null;
        }
        
        private static void lIlIlIlIIlIl()
        {
          llIlIllIIl = new String[llIllllIII[1]];
          llIlIllIIl[llIllllIII[0]] = lIlIlIlIIlII("DAbOR6Cbmfs+QNzt42z6NA==", "WQShB");
        }
      });
      lllllllllllllllIlIlIlIIlIlllIlII.addCrashSectionCallable(lIIlllllIlIl[lIIllllllIIl[6]], new Callable()
      {
        private static void lIIIlIIlIlllIl()
        {
          lIllIIlIIIII = new String[lIllIIlIIIIl[5]];
          lIllIIlIIIII[lIllIIlIIIIl[0]] = lIIIlIIlIllIIl("KRgcEi4wFBcFJDYU", "dQOQq");
          lIllIIlIIIII[lIllIIlIIIIl[1]] = lIIIlIIlIllIlI("RUMhKTavoVVQCS5FmWaOBg==", "gMasn");
          lIllIIlIIIII[lIllIIlIIIIl[3]] = lIIIlIIlIllIIl("JgkFIBw6GAEoGjcOEiUNPBMUMRw2FRQ=", "cGQiH");
          lIllIIlIIIII[lIllIIlIIIIl[2]] = lIIIlIIlIlllII("2r6w0HmAxrWwbhg7v+LUtg==", "dqKFg");
          lIllIIlIIIII[lIllIIlIIIIl[4]] = lIIIlIIlIllIlI("tBxovzNyR3+Qn39RXljybw==", "krhqO");
        }
        
        private static String lIIIlIIlIllIIl(String lllllllllllllllIIllIllIlllIlllll, String lllllllllllllllIIllIllIllllIIIll)
        {
          ;
          ;
          ;
          ;
          ;
          ;
          lllllllllllllllIIllIllIlllIlllll = new String(Base64.getDecoder().decode(lllllllllllllllIIllIllIlllIlllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
          StringBuilder lllllllllllllllIIllIllIllllIIIlI = new StringBuilder();
          char[] lllllllllllllllIIllIllIllllIIIIl = lllllllllllllllIIllIllIllllIIIll.toCharArray();
          int lllllllllllllllIIllIllIllllIIIII = lIllIIlIIIIl[0];
          Exception lllllllllllllllIIllIllIlllIllIlI = lllllllllllllllIIllIllIlllIlllll.toCharArray();
          byte lllllllllllllllIIllIllIlllIllIIl = lllllllllllllllIIllIllIlllIllIlI.length;
          String lllllllllllllllIIllIllIlllIllIII = lIllIIlIIIIl[0];
          while (lIIIlIIllIIIIl(lllllllllllllllIIllIllIlllIllIII, lllllllllllllllIIllIllIlllIllIIl))
          {
            char lllllllllllllllIIllIllIllllIIlIl = lllllllllllllllIIllIllIlllIllIlI[lllllllllllllllIIllIllIlllIllIII];
            "".length();
            "".length();
            if (null != null) {
              return null;
            }
          }
          return String.valueOf(lllllllllllllllIIllIllIllllIIIlI);
        }
        
        private static boolean lIIIlIIlIlllll(int ???)
        {
          Exception lllllllllllllllIIllIllIllIllIIll;
          return ??? == 0;
        }
        
        public String call()
          throws Exception
        {
          ;
          if (lIIIlIIlIlllll(lllllllllllllllIlIlIlIIlIlllIIll))
          {
            "".length();
            if (((61 + '' - 72 + 83 ^ 19 + 29 - -52 + 45) & (0xA3 ^ 0x95 ^ 0x54 ^ 0x26 ^ -" ".length())) >= " ".length()) {
              return null;
            }
          }
          else if (lIIIlIIllIIIII(lllllllllllllllIlIlIlIIlIlllIIll, lIllIIlIIIIl[1]))
          {
            "".length();
            if ("   ".length() <= "  ".length()) {
              return null;
            }
          }
          else if (lIIIlIIllIIIII(lllllllllllllllIlIlIlIIlIlllIIll, lIllIIlIIIIl[2]))
          {
            "".length();
            if (((0x44 ^ 0x76 ^ 0x89 ^ 0xBE) & (0x22 ^ 0x7D ^ 0x2C ^ 0x76 ^ -" ".length())) <= "   ".length()) {
              break label223;
            }
            return null;
          }
          label223:
          return String.valueOf(new StringBuilder(lIllIIlIIIII[lIllIIlIIIIl[2]]).append(lllllllllllllllIlIlIlIIlIlllIIll));
        }
        
        private static String lIIIlIIlIlllII(String lllllllllllllllIIllIllIlllIIllIl, String lllllllllllllllIIllIllIlllIIllII)
        {
          try
          {
            ;
            ;
            ;
            ;
            SecretKeySpec lllllllllllllllIIllIllIlllIlIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIllIlllIIllII.getBytes(StandardCharsets.UTF_8)), lIllIIlIIIIl[6]), "DES");
            Cipher lllllllllllllllIIllIllIlllIlIIIl = Cipher.getInstance("DES");
            lllllllllllllllIIllIllIlllIlIIIl.init(lIllIIlIIIIl[3], lllllllllllllllIIllIllIlllIlIIlI);
            return new String(lllllllllllllllIIllIllIlllIlIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIllIlllIIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
          }
          catch (Exception lllllllllllllllIIllIllIlllIlIIII)
          {
            lllllllllllllllIIllIllIlllIlIIII.printStackTrace();
          }
          return null;
        }
        
        private static boolean lIIIlIIllIIIIl(int ???, int arg1)
        {
          int i;
          long lllllllllllllllIIllIllIllIllIlIl;
          return ??? < i;
        }
        
        static
        {
          lIIIlIIlIllllI();
          lIIIlIIlIlllIl();
        }
        
        private static String lIIIlIIlIllIlI(String lllllllllllllllIIllIllIlllIIIIlI, String lllllllllllllllIIllIllIllIllllll)
        {
          try
          {
            ;
            ;
            ;
            ;
            SecretKeySpec lllllllllllllllIIllIllIlllIIIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIllIllIllllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
            Cipher lllllllllllllllIIllIllIlllIIIlII = Cipher.getInstance("Blowfish");
            lllllllllllllllIIllIllIlllIIIlII.init(lIllIIlIIIIl[3], lllllllllllllllIIllIllIlllIIIlIl);
            return new String(lllllllllllllllIIllIllIlllIIIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIllIlllIIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
          }
          catch (Exception lllllllllllllllIIllIllIlllIIIIll)
          {
            lllllllllllllllIIllIllIlllIIIIll.printStackTrace();
          }
          return null;
        }
        
        private static boolean lIIIlIIllIIIII(int ???, int arg1)
        {
          int i;
          double lllllllllllllllIIllIllIllIlllIIl;
          return ??? == i;
        }
        
        private static void lIIIlIIlIllllI()
        {
          lIllIIlIIIIl = new int[7];
          lIllIIlIIIIl[0] = ((23 + '' - 128 + 136 ^ 25 + 47 - 38 + 109) & (0x68 ^ 0x65 ^ 0x27 ^ 0x16 ^ -" ".length()));
          lIllIIlIIIIl[1] = " ".length();
          lIllIIlIIIIl[2] = "   ".length();
          lIllIIlIIIIl[3] = "  ".length();
          lIllIIlIIIIl[4] = (0x7E ^ 0x7A);
          lIllIIlIIIIl[5] = (94 + 8 - -10 + 74 ^ 17 + 116 - 103 + 161);
          lIllIIlIIIIl[6] = (121 + 53 - 158 + 158 ^ 36 + '¤' - 90 + 56);
        }
      });
      throw new ReportedException(lllllllllllllllIlIlIlIIlIlllIlIl);
    }
  }
  
  private static String llllIlIllIlIl(String lllllllllllllllIlIlIlIIIIlIlIlII, String lllllllllllllllIlIlIlIIIIlIlIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIlIIIIlIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIlIIIIlIlIIll.getBytes(StandardCharsets.UTF_8)), lIIllllllIIl[12]), "DES");
      Cipher lllllllllllllllIlIlIlIIIIlIlIllI = Cipher.getInstance("DES");
      lllllllllllllllIlIlIlIIIIlIlIllI.init(lIIllllllIIl[3], lllllllllllllllIlIlIlIIIIlIlIlll);
      return new String(lllllllllllllllIlIlIlIIIIlIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIlIIIIlIlIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIlIIIIlIlIlIl)
    {
      lllllllllllllllIlIlIlIIIIlIlIlIl.printStackTrace();
    }
    return null;
  }
  
  private void registerVanillaParticles()
  {
    ;
    lllllllllllllllIlIlIlIIlllllIIII.registerParticle(EnumParticleTypes.EXPLOSION_NORMAL.getParticleID(), new EntityExplodeFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.WATER_BUBBLE.getParticleID(), new EntityBubbleFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.WATER_SPLASH.getParticleID(), new EntitySplashFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.WATER_WAKE.getParticleID(), new EntityFishWakeFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.WATER_DROP.getParticleID(), new EntityRainFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SUSPENDED.getParticleID(), new EntitySuspendFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SUSPENDED_DEPTH.getParticleID(), new EntityAuraFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.CRIT.getParticleID(), new EntityCrit2FX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.CRIT_MAGIC.getParticleID(), new EntityCrit2FX.MagicFactory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SMOKE_NORMAL.getParticleID(), new EntitySmokeFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SMOKE_LARGE.getParticleID(), new EntityCritFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SPELL.getParticleID(), new EntitySpellParticleFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SPELL_INSTANT.getParticleID(), new EntitySpellParticleFX.InstantFactory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SPELL_MOB.getParticleID(), new EntitySpellParticleFX.MobFactory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SPELL_MOB_AMBIENT.getParticleID(), new EntitySpellParticleFX.AmbientMobFactory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SPELL_WITCH.getParticleID(), new EntitySpellParticleFX.WitchFactory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.DRIP_WATER.getParticleID(), new EntityDropParticleFX.WaterFactory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.DRIP_LAVA.getParticleID(), new EntityDropParticleFX.LavaFactory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.VILLAGER_ANGRY.getParticleID(), new EntityHeartFX.AngryVillagerFactory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.VILLAGER_HAPPY.getParticleID(), new EntityAuraFX.HappyVillagerFactory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.TOWN_AURA.getParticleID(), new EntityAuraFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.NOTE.getParticleID(), new EntityNoteFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.PORTAL.getParticleID(), new EntityPortalFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.ENCHANTMENT_TABLE.getParticleID(), new EntityEnchantmentTableParticleFX.EnchantmentTable());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.FLAME.getParticleID(), new EntityFlameFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.LAVA.getParticleID(), new EntityLavaFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.FOOTSTEP.getParticleID(), new EntityFootStepFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.CLOUD.getParticleID(), new EntityCloudFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.REDSTONE.getParticleID(), new EntityReddustFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SNOWBALL.getParticleID(), new EntityBreakingFX.SnowballFactory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SNOW_SHOVEL.getParticleID(), new EntitySnowShovelFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.SLIME.getParticleID(), new EntityBreakingFX.SlimeFactory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.HEART.getParticleID(), new EntityHeartFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.BARRIER.getParticleID(), new Barrier.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.ITEM_CRACK.getParticleID(), new EntityBreakingFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.BLOCK_CRACK.getParticleID(), new EntityDiggingFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.BLOCK_DUST.getParticleID(), new EntityBlockDustFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.EXPLOSION_HUGE.getParticleID(), new EntityHugeExplodeFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.EXPLOSION_LARGE.getParticleID(), new EntityLargeExplodeFX.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.FIREWORKS_SPARK.getParticleID(), new EntityFirework.Factory());
    lllllllllllllllIlIlIlIIllllIllll.registerParticle(EnumParticleTypes.MOB_APPEARANCE.getParticleID(), new MobAppearance.Factory());
  }
  
  private static int llllIllIIlIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llllIllIIlIIl(Object ???)
  {
    float lllllllllllllllIlIlIlIIIIlIIIIIl;
    return ??? != null;
  }
  
  private void updateEffectLayer(int lllllllllllllllIlIlIlIIllIIIllll)
  {
    ;
    ;
    ;
    int lllllllllllllllIlIlIlIIllIIlIIIl = lIIllllllIIl[0];
    "".length();
    if ("   ".length() <= 0) {
      return;
    }
    while (!llllIllIIlIII(lllllllllllllllIlIlIlIIllIIlIIIl, lIIllllllIIl[3]))
    {
      lllllllllllllllIlIlIlIIllIIlIIII.updateEffectAlphaLayer(fxLayers[lllllllllllllllIlIlIlIIllIIIllll][lllllllllllllllIlIlIlIIllIIlIIIl]);
      lllllllllllllllIlIlIlIIllIIlIIIl++;
    }
  }
  
  public void moveToNoAlphaLayer(EntityFX lllllllllllllllIlIlIlIIIlIlIllIl)
  {
    ;
    ;
    lllllllllllllllIlIlIlIIIlIlIllII.moveToLayer(lllllllllllllllIlIlIlIIIlIlIllIl, lIIllllllIIl[0], lIIllllllIIl[1]);
  }
  
  private static boolean llllIllIIlllI(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIlIlIlIIIIIllIlIl;
    return ??? != i;
  }
  
  private static boolean llllIllIIlIII(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIlIlIlIIIIlIIlIll;
    return ??? >= i;
  }
  
  public void addBlockHitEffects(BlockPos lllllllllllllllIlIlIlIIIlIIIlIIl, MovingObjectPosition lllllllllllllllIlIlIlIIIlIIIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    Block lllllllllllllllIlIlIlIIIlIIIIlll = worldObj.getBlockState(lllllllllllllllIlIlIlIIIlIIIIlII).getBlock();
    boolean lllllllllllllllIlIlIlIIIlIIIIllI = Reflector.callBoolean(lllllllllllllllIlIlIlIIIlIIIIlll, Reflector.ForgeBlock_addHitEffects, new Object[] { worldObj, lllllllllllllllIlIlIlIIIlIIIlIII, lllllllllllllllIlIlIlIIIlIIIIlIl });
    if ((llllIllIIlIIl(lllllllllllllllIlIlIlIIIlIIIIlll)) && (llllIllIIllII(lllllllllllllllIlIlIlIIIlIIIIllI))) {
      lllllllllllllllIlIlIlIIIlIIIIlIl.addBlockHitEffects(lllllllllllllllIlIlIlIIIlIIIIlII, sideHit);
    }
  }
  
  public void registerParticle(int lllllllllllllllIlIlIlIIllllIlIlI, IParticleFactory lllllllllllllllIlIlIlIIllllIIllI)
  {
    ;
    ;
    ;
    "".length();
  }
  
  public void moveToAlphaLayer(EntityFX lllllllllllllllIlIlIlIIIlIllIIll)
  {
    ;
    ;
    lllllllllllllllIlIlIlIIIlIllIlII.moveToLayer(lllllllllllllllIlIlIlIIIlIllIIll, lIIllllllIIl[1], lIIllllllIIl[0]);
  }
  
  public void renderLitParticles(Entity lllllllllllllllIlIlIlIIlIIIlIlll, float lllllllllllllllIlIlIlIIlIIIlIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIlIlIlIIlIIlIIlII = 0.017453292F;
    float lllllllllllllllIlIlIlIIlIIlIIIll = MathHelper.cos(rotationYaw * 0.017453292F);
    float lllllllllllllllIlIlIlIIlIIlIIIlI = MathHelper.sin(rotationYaw * 0.017453292F);
    float lllllllllllllllIlIlIlIIlIIlIIIIl = -lllllllllllllllIlIlIlIIlIIlIIIlI * MathHelper.sin(rotationPitch * 0.017453292F);
    float lllllllllllllllIlIlIlIIlIIlIIIII = lllllllllllllllIlIlIlIIlIIlIIIll * MathHelper.sin(rotationPitch * 0.017453292F);
    float lllllllllllllllIlIlIlIIlIIIlllll = MathHelper.cos(rotationPitch * 0.017453292F);
    int lllllllllllllllIlIlIlIIlIIIllllI = lIIllllllIIl[0];
    "".length();
    if (null != null) {
      return;
    }
    while (!llllIllIIlIII(lllllllllllllllIlIlIlIIlIIIllllI, lIIllllllIIl[3]))
    {
      List lllllllllllllllIlIlIlIIlIIIlllIl = fxLayers[lIIllllllIIl[5]][lllllllllllllllIlIlIlIIlIIIllllI];
      if (llllIllIIllII(lllllllllllllllIlIlIlIIlIIIlllIl.isEmpty()))
      {
        Tessellator lllllllllllllllIlIlIlIIlIIIlllII = Tessellator.getInstance();
        WorldRenderer lllllllllllllllIlIlIlIIlIIIllIll = lllllllllllllllIlIlIlIIlIIIlllII.getWorldRenderer();
        int lllllllllllllllIlIlIlIIlIIIllIlI = lIIllllllIIl[0];
        "".length();
        if ("   ".length() < " ".length()) {
          return;
        }
        while (!llllIllIIlIII(lllllllllllllllIlIlIlIIlIIIllIlI, lllllllllllllllIlIlIlIIlIIIlllIl.size()))
        {
          EntityFX lllllllllllllllIlIlIlIIlIIIllIIl = (EntityFX)lllllllllllllllIlIlIlIIlIIIlllIl.get(lllllllllllllllIlIlIlIIlIIIllIlI);
          lllllllllllllllIlIlIlIIlIIIllIIl.renderParticle(lllllllllllllllIlIlIlIIlIIIllIll, lllllllllllllllIlIlIlIIlIIlIIllI, lllllllllllllllIlIlIlIIlIIIlIllI, lllllllllllllllIlIlIlIIlIIlIIIll, lllllllllllllllIlIlIlIIlIIIlllll, lllllllllllllllIlIlIlIIlIIlIIIlI, lllllllllllllllIlIlIlIIlIIlIIIIl, lllllllllllllllIlIlIlIIlIIlIIIII);
          lllllllllllllllIlIlIlIIlIIIllIlI++;
        }
      }
      lllllllllllllllIlIlIlIIlIIIllllI++;
    }
  }
  
  private static void llllIllIIIlll()
  {
    lIIllllllIIl = new int[16];
    lIIllllllIIl[0] = ((0xF ^ 0x32) & (0xFE ^ 0xC3 ^ 0xFFFFFFFF));
    lIIllllllIIl[1] = " ".length();
    lIIllllllIIl[2] = (0x63 ^ 0x54 ^ 0xA4 ^ 0x97);
    lIIllllllIIl[3] = "  ".length();
    lIIllllllIIl[4] = (0xAFA0 & 0x5FFF);
    lIIllllllIIl[5] = "   ".length();
    lIIllllllIIl[6] = (0x38 ^ 0x32 ^ 0x2C ^ 0x23);
    lIIllllllIIl[7] = (0xD34B & 0x2FB6);
    lIIllllllIIl[8] = (0x87E3 & 0x7B1F);
    lIIllllllIIl[9] = (0x978E & 0x6A75);
    lIIllllllIIl[10] = (0xFC ^ 0xB9 ^ 0x81 ^ 0xC3);
    lIIllllllIIl[11] = (0x28 ^ 0x2E);
    lIIllllllIIl[12] = (0x3 ^ 0xB);
    lIIllllllIIl[13] = (0xAF ^ 0xB1 ^ 0xA8 ^ 0xBF);
    lIIllllllIIl[14] = (-" ".length());
    lIIllllllIIl[15] = (0xC ^ 0x67 ^ 0x1F ^ 0x7E);
  }
  
  public void addEffect(EntityFX lllllllllllllllIlIlIlIIllIlIllII)
  {
    ;
    ;
    ;
    ;
    if ((llllIllIIlIIl(lllllllllllllllIlIlIlIIllIlIllII)) && ((!llllIllIIlIll(lllllllllllllllIlIlIlIIllIlIllII instanceof EntityFirework.SparkFX)) || (llllIllIIlIll(Config.isFireworkParticles()))))
    {
      int lllllllllllllllIlIlIlIIllIlIlIll = lllllllllllllllIlIlIlIIllIlIllII.getFXLayer();
      if (llllIllIIlIll(llllIllIIlIlI(lllllllllllllllIlIlIlIIllIlIllII.getAlpha(), 1.0F)))
      {
        "".length();
        if (" ".length() != 0) {
          break label71;
        }
      }
      label71:
      int lllllllllllllllIlIlIlIIllIlIlIlI = lIIllllllIIl[1];
      if (llllIllIIlIII(fxLayers[lllllllllllllllIlIlIlIIllIlIlIll][lllllllllllllllIlIlIlIIllIlIlIlI].size(), lIIllllllIIl[4])) {
        "".length();
      }
      "".length();
    }
  }
  
  private static String llllIlIlllIII(String lllllllllllllllIlIlIlIIIIllIlIIl, String lllllllllllllllIlIlIlIIIIllIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIlIIIIllIlIIl = new String(Base64.getDecoder().decode(lllllllllllllllIlIlIlIIIIllIlIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlIlIlIIIIllIIlll = new StringBuilder();
    char[] lllllllllllllllIlIlIlIIIIllIIllI = lllllllllllllllIlIlIlIIIIllIIIll.toCharArray();
    int lllllllllllllllIlIlIlIIIIllIIlIl = lIIllllllIIl[0];
    Exception lllllllllllllllIlIlIlIIIIlIlllll = lllllllllllllllIlIlIlIIIIllIlIIl.toCharArray();
    boolean lllllllllllllllIlIlIlIIIIlIllllI = lllllllllllllllIlIlIlIIIIlIlllll.length;
    float lllllllllllllllIlIlIlIIIIlIlllIl = lIIllllllIIl[0];
    while (llllIllIlIIII(lllllllllllllllIlIlIlIIIIlIlllIl, lllllllllllllllIlIlIlIIIIlIllllI))
    {
      char lllllllllllllllIlIlIlIIIIllIlIlI = lllllllllllllllIlIlIlIIIIlIlllll[lllllllllllllllIlIlIlIIIIlIlllIl];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIlIlIlIIIIllIIlll);
  }
  
  public void clearEffects(World lllllllllllllllIlIlIlIIlIIIIIIII)
  {
    ;
    ;
    ;
    ;
    worldObj = lllllllllllllllIlIlIlIIlIIIIIIII;
    int lllllllllllllllIlIlIlIIlIIIIIIll = lIIllllllIIl[0];
    "".length();
    if ((0x7A ^ 0x7E) <= " ".length()) {
      return;
    }
    while (!llllIllIIlIII(lllllllllllllllIlIlIlIIlIIIIIIll, lIIllllllIIl[2]))
    {
      int lllllllllllllllIlIlIlIIlIIIIIIlI = lIIllllllIIl[0];
      "".length();
      if ("   ".length() <= 0) {
        return;
      }
      while (!llllIllIIlIII(lllllllllllllllIlIlIlIIlIIIIIIlI, lIIllllllIIl[3]))
      {
        fxLayers[lllllllllllllllIlIlIlIIlIIIIIIll][lllllllllllllllIlIlIlIIlIIIIIIlI].clear();
        lllllllllllllllIlIlIlIIlIIIIIIlI++;
      }
      lllllllllllllllIlIlIlIIlIIIIIIll++;
    }
    particleEmitters.clear();
  }
  
  private static boolean llllIllIIllIl(Object ???, Object arg1)
  {
    Object localObject;
    long lllllllllllllllIlIlIlIIIIlIIIIll;
    return ??? != localObject;
  }
  
  private static String llllIlIllIlll(String lllllllllllllllIlIlIlIIIIllllIIl, String lllllllllllllllIlIlIlIIIIllllIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIlIIIIlllllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIlIIIIllllIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlIlIlIIIIllllIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIlIlIlIIIIllllIll.init(lIIllllllIIl[3], lllllllllllllllIlIlIlIIIIlllllII);
      return new String(lllllllllllllllIlIlIlIIIIllllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIlIIIIllllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIlIIIIllllIlI)
    {
      lllllllllllllllIlIlIlIIIIllllIlI.printStackTrace();
    }
    return null;
  }
  
  private void updateEffectAlphaLayer(List lllllllllllllllIlIlIlIIllIIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ArrayList lllllllllllllllIlIlIlIIllIIIIllI = Lists.newArrayList();
    int lllllllllllllllIlIlIlIIllIIIIlIl = lIIllllllIIl[0];
    "".length();
    if (((0x4C ^ 0x68) & (0x64 ^ 0x40 ^ 0xFFFFFFFF)) != 0) {
      return;
    }
    while (!llllIllIIlIII(lllllllllllllllIlIlIlIIllIIIIlIl, lllllllllllllllIlIlIlIIllIIIIIlI.size()))
    {
      EntityFX lllllllllllllllIlIlIlIIllIIIIlII = (EntityFX)lllllllllllllllIlIlIlIIllIIIIIlI.get(lllllllllllllllIlIlIlIIllIIIIlIl);
      lllllllllllllllIlIlIlIIllIIIlIII.tickParticle(lllllllllllllllIlIlIlIIllIIIIlII);
      if (llllIllIIlIll(isDead)) {
        "".length();
      }
      lllllllllllllllIlIlIlIIllIIIIlIl++;
    }
    "".length();
  }
  
  private static boolean llllIllIIllll(Object ???, Object arg1)
  {
    Object localObject;
    byte lllllllllllllllIlIlIlIIIIIllllIl;
    return ??? == localObject;
  }
  
  public void renderParticles(Entity lllllllllllllllIlIlIlIIlIlIllIIl, float lllllllllllllllIlIlIlIIlIlIIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIlIlIlIIlIlIlIlll = ActiveRenderInfo.getRotationX();
    float lllllllllllllllIlIlIlIIlIlIlIllI = ActiveRenderInfo.getRotationZ();
    float lllllllllllllllIlIlIlIIlIlIlIlIl = ActiveRenderInfo.getRotationYZ();
    float lllllllllllllllIlIlIlIIlIlIlIlII = ActiveRenderInfo.getRotationXY();
    float lllllllllllllllIlIlIlIIlIlIlIIll = ActiveRenderInfo.getRotationXZ();
    EntityFX.interpPosX = lastTickPosX + (posX - lastTickPosX) * lllllllllllllllIlIlIlIIlIlIIIllI;
    EntityFX.interpPosY = lastTickPosY + (posY - lastTickPosY) * lllllllllllllllIlIlIlIIlIlIIIllI;
    EntityFX.interpPosZ = lastTickPosZ + (posZ - lastTickPosZ) * lllllllllllllllIlIlIlIIlIlIIIllI;
    GlStateManager.enableBlend();
    GlStateManager.blendFunc(lIIllllllIIl[7], lIIllllllIIl[8]);
    GlStateManager.alphaFunc(lIIllllllIIl[9], 0.003921569F);
    int lllllllllllllllIlIlIlIIlIlIlIIlI = lIIllllllIIl[0];
    "".length();
    if (-" ".length() >= ((0xA ^ 0x22) & (0xA8 ^ 0x80 ^ 0xFFFFFFFF))) {
      return;
    }
    while (!llllIllIIlIII(lllllllllllllllIlIlIlIIlIlIlIIlI, lIIllllllIIl[5]))
    {
      final int lllllllllllllllIlIlIlIIlIlIlIIIl = lllllllllllllllIlIlIlIIlIlIlIIlI;
      int lllllllllllllllIlIlIlIIlIlIlIIII = lIIllllllIIl[0];
      "".length();
      if (" ".length() == 0) {
        return;
      }
      while (!llllIllIIlIII(lllllllllllllllIlIlIlIIlIlIlIIII, lIIllllllIIl[3]))
      {
        if (llllIllIIllII(fxLayers[lllllllllllllllIlIlIlIIlIlIlIIIl][lllllllllllllllIlIlIlIIlIlIlIIII].isEmpty()))
        {
          switch (lllllllllllllllIlIlIlIIlIlIlIIII)
          {
          case 0: 
            GlStateManager.depthMask(lIIllllllIIl[0]);
            "".length();
            if ((0x64 ^ 0x60) != (0xB6 ^ 0xB2)) {
              return;
            }
            break;
          case 1: 
            GlStateManager.depthMask(lIIllllllIIl[1]);
          }
          switch (lllllllllllllllIlIlIlIIlIlIlIIIl)
          {
          case 0: 
          default: 
            renderer.bindTexture(particleTextures);
            "".length();
            if ("  ".length() == 0) {
              return;
            }
            break;
          case 1: 
            renderer.bindTexture(TextureMap.locationBlocksTexture);
          }
          GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
          Tessellator lllllllllllllllIlIlIlIIlIlIIllll = Tessellator.getInstance();
          WorldRenderer lllllllllllllllIlIlIlIIlIlIIlllI = lllllllllllllllIlIlIlIIlIlIIllll.getWorldRenderer();
          lllllllllllllllIlIlIlIIlIlIIlllI.begin(lIIllllllIIl[10], DefaultVertexFormats.PARTICLE_POSITION_TEX_COLOR_LMAP);
          int lllllllllllllllIlIlIlIIlIlIIllIl = lIIllllllIIl[0];
          "".length();
          if ("  ".length() != "  ".length()) {
            return;
          }
          while (!llllIllIIlIII(lllllllllllllllIlIlIlIIlIlIIllIl, fxLayers[lllllllllllllllIlIlIlIIlIlIlIIIl][lllllllllllllllIlIlIlIIlIlIlIIII].size()))
          {
            final EntityFX lllllllllllllllIlIlIlIIlIlIIllII = (EntityFX)fxLayers[lllllllllllllllIlIlIlIIlIlIlIIIl][lllllllllllllllIlIlIlIIlIlIlIIII].get(lllllllllllllllIlIlIlIIlIlIIllIl);
            try
            {
              lllllllllllllllIlIlIlIIlIlIIllII.renderParticle(lllllllllllllllIlIlIlIIlIlIIlllI, lllllllllllllllIlIlIlIIlIlIIIlll, lllllllllllllllIlIlIlIIlIlIIIllI, lllllllllllllllIlIlIlIIlIlIlIlll, lllllllllllllllIlIlIlIIlIlIlIIll, lllllllllllllllIlIlIlIIlIlIlIllI, lllllllllllllllIlIlIlIIlIlIlIlIl, lllllllllllllllIlIlIlIIlIlIlIlII);
              "".length();
              if ("  ".length() < 0) {
                return;
              }
            }
            catch (Throwable lllllllllllllllIlIlIlIIlIlIIlIll)
            {
              CrashReport lllllllllllllllIlIlIlIIlIlIIlIlI = CrashReport.makeCrashReport(lllllllllllllllIlIlIlIIlIlIIlIll, lIIlllllIlIl[lIIllllllIIl[11]]);
              CrashReportCategory lllllllllllllllIlIlIlIIlIlIIlIIl = lllllllllllllllIlIlIlIIlIlIIlIlI.makeCategory(lIIlllllIlIl[lIIllllllIIl[10]]);
              lllllllllllllllIlIlIlIIlIlIIlIIl.addCrashSectionCallable(lIIlllllIlIl[lIIllllllIIl[12]], new Callable()
              {
                public String call()
                  throws Exception
                {
                  ;
                  return lllllllllllllllIlIlIlIIlIlIIllII.toString();
                }
                
                private static String llIIllIllllI(String lllllllllllllllllIlllllIIlllIIII, String lllllllllllllllllIlllllIIllIllIl)
                {
                  try
                  {
                    ;
                    ;
                    ;
                    ;
                    SecretKeySpec lllllllllllllllllIlllllIIlllIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIlllllIIllIllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
                    Cipher lllllllllllllllllIlllllIIlllIIlI = Cipher.getInstance("Blowfish");
                    lllllllllllllllllIlllllIIlllIIlI.init(lIIIIIlIIIl[2], lllllllllllllllllIlllllIIlllIIll);
                    return new String(lllllllllllllllllIlllllIIlllIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIlllllIIlllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
                  }
                  catch (Exception lllllllllllllllllIlllllIIlllIIIl)
                  {
                    lllllllllllllllllIlllllIIlllIIIl.printStackTrace();
                  }
                  return null;
                }
                
                static
                {
                  llIIlllIIIll();
                  llIIlllIIIlI();
                }
                
                private static void llIIlllIIIlI()
                {
                  lIIIIIIlllI = new String[lIIIIIlIIIl[1]];
                  lIIIIIIlllI[lIIIIIlIIIl[0]] = llIIllIllllI("sSSIcAjAS7o9rZPzIyppAg==", "AtMdG");
                }
                
                private static void llIIlllIIIll()
                {
                  lIIIIIlIIIl = new int[3];
                  lIIIIIlIIIl[0] = ((0xB4 ^ 0x99 ^ 0x11 ^ 0x17) & (0x72 ^ 0x3D ^ 0x7B ^ 0x1F ^ -" ".length()));
                  lIIIIIlIIIl[1] = " ".length();
                  lIIIIIlIIIl[2] = "  ".length();
                }
              });
              lllllllllllllllIlIlIlIIlIlIIlIIl.addCrashSectionCallable(lIIlllllIlIl[lIIllllllIIl[13]], new Callable()
              {
                private static String lIlIIIlIlIlIII(String lllllllllllllllIIIIIIIIIlIIIIIlI, String lllllllllllllllIIIIIIIIIlIIIIllI)
                {
                  ;
                  ;
                  ;
                  ;
                  ;
                  ;
                  lllllllllllllllIIIIIIIIIlIIIIIlI = new String(Base64.getDecoder().decode(lllllllllllllllIIIIIIIIIlIIIIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
                  StringBuilder lllllllllllllllIIIIIIIIIlIIIIlIl = new StringBuilder();
                  char[] lllllllllllllllIIIIIIIIIlIIIIlII = lllllllllllllllIIIIIIIIIlIIIIllI.toCharArray();
                  int lllllllllllllllIIIIIIIIIlIIIIIll = llIlIlIlllII[0];
                  byte lllllllllllllllIIIIIIIIIIlllllIl = lllllllllllllllIIIIIIIIIlIIIIIlI.toCharArray();
                  double lllllllllllllllIIIIIIIIIIlllllII = lllllllllllllllIIIIIIIIIIlllllIl.length;
                  float lllllllllllllllIIIIIIIIIIllllIll = llIlIlIlllII[0];
                  while (lIlIIlIIIlIlIl(lllllllllllllllIIIIIIIIIIllllIll, lllllllllllllllIIIIIIIIIIlllllII))
                  {
                    char lllllllllllllllIIIIIIIIIlIIIlIII = lllllllllllllllIIIIIIIIIIlllllIl[lllllllllllllllIIIIIIIIIIllllIll];
                    "".length();
                    "".length();
                    if ((0x73 ^ 0x4 ^ 0x31 ^ 0x42) == 0) {
                      return null;
                    }
                  }
                  return String.valueOf(lllllllllllllllIIIIIIIIIlIIIIlIl);
                }
                
                private static boolean lIlIIlIIIlIIll(int ???)
                {
                  int lllllllllllllllIIIIIIIIIIlIlIllI;
                  return ??? == 0;
                }
                
                private static boolean lIlIIlIIIlIlII(int ???, int arg1)
                {
                  int i;
                  float lllllllllllllllIIIIIIIIIIlIlllII;
                  return ??? == i;
                }
                
                private static boolean lIlIIlIIIlIlIl(int ???, int arg1)
                {
                  int i;
                  String lllllllllllllllIIIIIIIIIIlIllIII;
                  return ??? < i;
                }
                
                private static void lIlIIIlIlIlIIl()
                {
                  llIlIIlllllI = new String[llIlIlIlllII[5]];
                  llIlIIlllllI[llIlIlIlllII[0]] = lIlIIIlIlIIllI("mE4UuC4g5ZkLHZ3jPkdxcg==", "zvYgt");
                  llIlIIlllllI[llIlIlIlllII[1]] = lIlIIIlIlIIlll("W+H2VKuzFyxv6yFKEQLoDA==", "HYlDB");
                  llIlIIlllllI[llIlIlIlllII[3]] = lIlIIIlIlIIlll("DNqF/Jr4c6S6ouuQgIJCNr5qudnukuVW", "lDUPO");
                  llIlIIlllllI[llIlIlIlllII[2]] = lIlIIIlIlIIlll("HGRx4/t5XYvKPqFyJQea3w==", "swSPP");
                  llIlIIlllllI[llIlIlIlllII[4]] = lIlIIIlIlIlIII("KD4FdWpbQmp8a1I=", "krZEZ");
                }
                
                public String call()
                  throws Exception
                {
                  ;
                  if (lIlIIlIIIlIIll(lllllllllllllllIlIlIlIIlIlIlIIIl))
                  {
                    "".length();
                    if (((0x56 ^ 0x6B) & (0x9C ^ 0xA1 ^ 0xFFFFFFFF)) > "  ".length()) {
                      return null;
                    }
                  }
                  else if (lIlIIlIIIlIlII(lllllllllllllllIlIlIlIIlIlIlIIIl, llIlIlIlllII[1]))
                  {
                    "".length();
                    if (((0xB6 ^ 0x91) & (0x4A ^ 0x6D ^ 0xFFFFFFFF)) < 0) {
                      return null;
                    }
                  }
                  else if (lIlIIlIIIlIlII(lllllllllllllllIlIlIlIIlIlIlIIIl, llIlIlIlllII[2]))
                  {
                    "".length();
                    if ((0x53 ^ 0x57) > 0) {
                      break label166;
                    }
                    return null;
                  }
                  label166:
                  return String.valueOf(new StringBuilder(llIlIIlllllI[llIlIlIlllII[2]]).append(lllllllllllllllIlIlIlIIlIlIlIIIl));
                }
                
                private static String lIlIIIlIlIIlll(String lllllllllllllllIIIIIIIIIIlllIIII, String lllllllllllllllIIIIIIIIIIlllIIIl)
                {
                  try
                  {
                    ;
                    ;
                    ;
                    ;
                    SecretKeySpec lllllllllllllllIIIIIIIIIIlllIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIIIIIIIIlllIIIl.getBytes(StandardCharsets.UTF_8)), llIlIlIlllII[6]), "DES");
                    Cipher lllllllllllllllIIIIIIIIIIlllIlII = Cipher.getInstance("DES");
                    lllllllllllllllIIIIIIIIIIlllIlII.init(llIlIlIlllII[3], lllllllllllllllIIIIIIIIIIlllIlIl);
                    return new String(lllllllllllllllIIIIIIIIIIlllIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIIIIIIIIlllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
                  }
                  catch (Exception lllllllllllllllIIIIIIIIIIlllIIll)
                  {
                    lllllllllllllllIIIIIIIIIIlllIIll.printStackTrace();
                  }
                  return null;
                }
                
                static
                {
                  lIlIIlIIIlIIlI();
                  lIlIIIlIlIlIIl();
                }
                
                private static void lIlIIlIIIlIIlI()
                {
                  llIlIlIlllII = new int[7];
                  llIlIlIlllII[0] = ((0x1D ^ 0x61 ^ 0xC9 ^ 0x9D) & (0x7D ^ 0x30 ^ 0xFD ^ 0x98 ^ -" ".length()));
                  llIlIlIlllII[1] = " ".length();
                  llIlIlIlllII[2] = "   ".length();
                  llIlIlIlllII[3] = "  ".length();
                  llIlIlIlllII[4] = (0x77 ^ 0x7F ^ 0x3A ^ 0x36);
                  llIlIlIlllII[5] = (0xAF ^ 0xAA);
                  llIlIlIlllII[6] = (0x14 ^ 0x55 ^ 0xCC ^ 0x85);
                }
                
                private static String lIlIIIlIlIIllI(String lllllllllllllllIIIIIIIIIIllIIIll, String lllllllllllllllIIIIIIIIIIllIIlII)
                {
                  try
                  {
                    ;
                    ;
                    ;
                    ;
                    SecretKeySpec lllllllllllllllIIIIIIIIIIllIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIIIIIIIIllIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
                    Cipher lllllllllllllllIIIIIIIIIIllIIlll = Cipher.getInstance("Blowfish");
                    lllllllllllllllIIIIIIIIIIllIIlll.init(llIlIlIlllII[3], lllllllllllllllIIIIIIIIIIllIlIII);
                    return new String(lllllllllllllllIIIIIIIIIIllIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIIIIIIIIllIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
                  }
                  catch (Exception lllllllllllllllIIIIIIIIIIllIIllI)
                  {
                    lllllllllllllllIIIIIIIIIIllIIllI.printStackTrace();
                  }
                  return null;
                }
              });
              throw new ReportedException(lllllllllllllllIlIlIlIIlIlIIlIlI);
            }
            lllllllllllllllIlIlIlIIlIlIIllIl++;
          }
          lllllllllllllllIlIlIlIIlIlIIllll.draw();
        }
        lllllllllllllllIlIlIlIIlIlIlIIII++;
      }
      lllllllllllllllIlIlIlIIlIlIlIIlI++;
    }
    GlStateManager.depthMask(lIIllllllIIl[1]);
    GlStateManager.disableBlend();
    GlStateManager.alphaFunc(lIIllllllIIl[9], 0.1F);
  }
  
  public void emitParticleAtEntity(Entity lllllllllllllllIlIlIlIIlllIlllIl, EnumParticleTypes lllllllllllllllIlIlIlIIlllIlIlll)
  {
    ;
    ;
    ;
    new EntityParticleEmitter(worldObj, lllllllllllllllIlIlIlIIlllIllIIl, lllllllllllllllIlIlIlIIlllIlIlll);
    "".length();
  }
  
  static
  {
    llllIllIIIlll();
    llllIlIlllIIl();
    __OBFID = lIIlllllIlIl[lIIllllllIIl[0]];
  }
  
  public EntityFX spawnEffectParticle(int lllllllllllllllIlIlIlIIlllIIIllI, double lllllllllllllllIlIlIlIIlllIIIlIl, double lllllllllllllllIlIlIlIIlllIIIlII, double lllllllllllllllIlIlIlIIllIllIlll, double lllllllllllllllIlIlIlIIlllIIIIlI, double lllllllllllllllIlIlIlIIllIllIlIl, double lllllllllllllllIlIlIlIIlllIIIIII, int... lllllllllllllllIlIlIlIIllIllIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    IParticleFactory lllllllllllllllIlIlIlIIllIlllllI = (IParticleFactory)particleTypes.get(Integer.valueOf(lllllllllllllllIlIlIlIIlllIIIllI));
    if (llllIllIIlIIl(lllllllllllllllIlIlIlIIllIlllllI))
    {
      EntityFX lllllllllllllllIlIlIlIIllIllllIl = lllllllllllllllIlIlIlIIllIlllllI.getEntityFX(lllllllllllllllIlIlIlIIlllIIIllI, worldObj, lllllllllllllllIlIlIlIIlllIIIlIl, lllllllllllllllIlIlIlIIlllIIIlII, lllllllllllllllIlIlIlIIlllIIIIll, lllllllllllllllIlIlIlIIlllIIIIlI, lllllllllllllllIlIlIlIIllIllIlIl, lllllllllllllllIlIlIlIIlllIIIIII, lllllllllllllllIlIlIlIIllIllIIll);
      if (llllIllIIlIIl(lllllllllllllllIlIlIlIIllIllllIl))
      {
        lllllllllllllllIlIlIlIIllIllllII.addEffect(lllllllllllllllIlIlIlIIllIllllIl);
        return lllllllllllllllIlIlIlIIllIllllIl;
      }
    }
    return null;
  }
  
  private static boolean llllIllIIllII(int ???)
  {
    float lllllllllllllllIlIlIlIIIIIlllIIl;
    return ??? == 0;
  }
  
  private static void llllIlIlllIIl()
  {
    lIIlllllIlIl = new String[lIIllllllIIl[15]];
    lIIlllllIlIl[lIIllllllIIl[0]] = llllIlIllIlIl("qf91Rjb9SQGbblUSWQglYw==", "dCsgF");
    lIIlllllIlIl[lIIllllllIIl[1]] = llllIlIllIlll("hvKnCuX4NABuzoaFUyGlFjJq7pxWxgm4IdWg7v14hYs=", "hkxjI");
    lIIlllllIlIl[lIIllllllIIl[3]] = llllIlIlllIII("EB01OCEqE3YDKTYAPzAkIQ==", "DtVSH");
    lIIlllllIlIl[lIIllllllIIl[5]] = llllIlIllIlll("DByWnpEjrzNv3AQRqpycnybnndwfAF9f", "lYPkt");
    lIIlllllIlIl[lIIllllllIIl[2]] = llllIlIllIlll("S5OVnCW7+LBOnQwv9mK+2Q==", "NYFuP");
    lIIlllllIlIl[lIIllllllIIl[6]] = llllIlIllIlIl("Zj/f6QxI+r1t74Z5hR63VA==", "gdIyJ");
    lIIlllllIlIl[lIIllllllIIl[11]] = llllIlIllIlIl("CCMhcbB3AYU9nB5wjHVzle5Q+aoLBygl", "RvvDa");
    lIIlllllIlIl[lIIllllllIIl[10]] = llllIlIllIlIl("nXdb68W+TqiNu7lWL1LSdTsBBV21vyZ0", "opqQt");
    lIIlllllIlIl[lIIllllllIIl[12]] = llllIlIlllIII("Hw40AiIsAyM=", "OoFvK");
    lIIlllllIlIl[lIIllllllIIl[13]] = llllIlIllIlIl("W5oAiNF6ttZwtPKmM5u84w==", "IgPeu");
  }
  
  public void addBlockHitEffects(BlockPos lllllllllllllllIlIlIlIIIllIIllIl, EnumFacing lllllllllllllllIlIlIlIIIllIIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState lllllllllllllllIlIlIlIIIllIIlIll = worldObj.getBlockState(lllllllllllllllIlIlIlIIIllIIIIIl);
    Block lllllllllllllllIlIlIlIIIllIIlIlI = lllllllllllllllIlIlIlIIIllIIlIll.getBlock();
    if (llllIllIIlllI(lllllllllllllllIlIlIlIIIllIIlIlI.getRenderType(), lIIllllllIIl[14]))
    {
      int lllllllllllllllIlIlIlIIIllIIlIIl = lllllllllllllllIlIlIlIIIllIIIIIl.getX();
      int lllllllllllllllIlIlIlIIIllIIlIII = lllllllllllllllIlIlIlIIIllIIIIIl.getY();
      int lllllllllllllllIlIlIlIIIllIIIlll = lllllllllllllllIlIlIlIIIllIIIIIl.getZ();
      float lllllllllllllllIlIlIlIIIllIIIllI = 0.1F;
      double lllllllllllllllIlIlIlIIIllIIIlIl = lllllllllllllllIlIlIlIIIllIIlIIl + rand.nextDouble() * (lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMaxX() - lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMinX() - lllllllllllllllIlIlIlIIIllIIIllI * 2.0F) + lllllllllllllllIlIlIlIIIllIIIllI + lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMinX();
      double lllllllllllllllIlIlIlIIIllIIIlII = lllllllllllllllIlIlIlIIIllIIlIII + rand.nextDouble() * (lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMaxY() - lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMinY() - lllllllllllllllIlIlIlIIIllIIIllI * 2.0F) + lllllllllllllllIlIlIlIIIllIIIllI + lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMinY();
      double lllllllllllllllIlIlIlIIIllIIIIll = lllllllllllllllIlIlIlIIIllIIIlll + rand.nextDouble() * (lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMaxZ() - lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMinZ() - lllllllllllllllIlIlIlIIIllIIIllI * 2.0F) + lllllllllllllllIlIlIlIIIllIIIllI + lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMinZ();
      if (llllIllIIllll(lllllllllllllllIlIlIlIIIllIIllII, EnumFacing.DOWN)) {
        lllllllllllllllIlIlIlIIIllIIIlII = lllllllllllllllIlIlIlIIIllIIlIII + lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMinY() - lllllllllllllllIlIlIlIIIllIIIllI;
      }
      if (llllIllIIllll(lllllllllllllllIlIlIlIIIllIIllII, EnumFacing.UP)) {
        lllllllllllllllIlIlIlIIIllIIIlII = lllllllllllllllIlIlIlIIIllIIlIII + lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMaxY() + lllllllllllllllIlIlIlIIIllIIIllI;
      }
      if (llllIllIIllll(lllllllllllllllIlIlIlIIIllIIllII, EnumFacing.NORTH)) {
        lllllllllllllllIlIlIlIIIllIIIIll = lllllllllllllllIlIlIlIIIllIIIlll + lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMinZ() - lllllllllllllllIlIlIlIIIllIIIllI;
      }
      if (llllIllIIllll(lllllllllllllllIlIlIlIIIllIIllII, EnumFacing.SOUTH)) {
        lllllllllllllllIlIlIlIIIllIIIIll = lllllllllllllllIlIlIlIIIllIIIlll + lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMaxZ() + lllllllllllllllIlIlIlIIIllIIIllI;
      }
      if (llllIllIIllll(lllllllllllllllIlIlIlIIIllIIllII, EnumFacing.WEST)) {
        lllllllllllllllIlIlIlIIIllIIIlIl = lllllllllllllllIlIlIlIIIllIIlIIl + lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMinX() - lllllllllllllllIlIlIlIIIllIIIllI;
      }
      if (llllIllIIllll(lllllllllllllllIlIlIlIIIllIIllII, EnumFacing.EAST)) {
        lllllllllllllllIlIlIlIIIllIIIlIl = lllllllllllllllIlIlIlIIIllIIlIIl + lllllllllllllllIlIlIlIIIllIIlIlI.getBlockBoundsMaxX() + lllllllllllllllIlIlIlIIIllIIIllI;
      }
      lllllllllllllllIlIlIlIIIllIIIIlI.addEffect(new EntityDiggingFX(worldObj, lllllllllllllllIlIlIlIIIllIIIlIl, lllllllllllllllIlIlIlIIIllIIIlII, lllllllllllllllIlIlIlIIIllIIIIll, 0.0D, 0.0D, 0.0D, lllllllllllllllIlIlIlIIIllIIlIll).func_174846_a(lllllllllllllllIlIlIlIIIllIIIIIl).multiplyVelocity(0.2F).multipleParticleScaleBy(0.6F));
    }
  }
  
  private static boolean llllIllIIlIll(int ???)
  {
    long lllllllllllllllIlIlIlIIIIIlllIll;
    return ??? != 0;
  }
  
  private void moveToLayer(EntityFX lllllllllllllllIlIlIlIIIlIIlllll, int lllllllllllllllIlIlIlIIIlIlIIIll, int lllllllllllllllIlIlIlIIIlIIlllIl)
  {
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIlIlIlIIIlIlIIIIl = lIIllllllIIl[0];
    "".length();
    if (" ".length() <= -" ".length()) {
      return;
    }
    while (!llllIllIIlIII(lllllllllllllllIlIlIlIIIlIlIIIIl, lIIllllllIIl[2]))
    {
      if (llllIllIIlIll(fxLayers[lllllllllllllllIlIlIlIIIlIlIIIIl][lllllllllllllllIlIlIlIIIlIlIIIll].contains(lllllllllllllllIlIlIlIIIlIIlllll)))
      {
        "".length();
        "".length();
      }
      lllllllllllllllIlIlIlIIIlIlIIIIl++;
    }
  }
  
  public void addBlockDestroyEffects(BlockPos lllllllllllllllIlIlIlIIIllllIIIl, IBlockState lllllllllllllllIlIlIlIIIllllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    label189:
    label259:
    boolean lllllllllllllllIlIlIlIIIlllIlllI;
    if ((llllIllIIlIll(Reflector.ForgeBlock_addDestroyEffects.exists())) && (llllIllIIlIll(Reflector.ForgeBlock_isAir.exists())))
    {
      Block lllllllllllllllIlIlIlIIIlllIllIl = lllllllllllllllIlIlIlIIIllllIIII.getBlock();
      "".length();
      if (llllIllIIllII(Reflector.callBoolean(lllllllllllllllIlIlIlIIIlllIllIl, Reflector.ForgeBlock_isAir, new Object[] { worldObj, lllllllllllllllIlIlIlIIIlllIIlII }))) {
        if (llllIllIIllII(Reflector.callBoolean(lllllllllllllllIlIlIlIIIlllIllIl, Reflector.ForgeBlock_addDestroyEffects, new Object[] { worldObj, lllllllllllllllIlIlIlIIIlllIIlII, lllllllllllllllIlIlIlIIIlllIIlIl })))
        {
          "".length();
          if ("   ".length() > 0) {
            break label189;
          }
          return;
        }
      }
      boolean lllllllllllllllIlIlIlIIIlllIllll = lIIllllllIIl[0];
      "".length();
      if ("  ".length() >= "  ".length()) {}
    }
    else
    {
      if (llllIllIIllIl(lllllllllllllllIlIlIlIIIllllIIII.getBlock().getMaterial(), Material.air))
      {
        "".length();
        if ("  ".length() > " ".length()) {
          break label259;
        }
      }
      lllllllllllllllIlIlIlIIIlllIlllI = lIIllllllIIl[0];
    }
    if (llllIllIIlIll(lllllllllllllllIlIlIlIIIlllIlllI))
    {
      lllllllllllllllIlIlIlIIIllllIIII = lllllllllllllllIlIlIlIIIllllIIII.getBlock().getActualState(lllllllllllllllIlIlIlIIIllllIIII, worldObj, lllllllllllllllIlIlIlIIIlllIIlII);
      byte lllllllllllllllIlIlIlIIIlllIllII = lIIllllllIIl[2];
      int lllllllllllllllIlIlIlIIIlllIlIll = lIIllllllIIl[0];
      "".length();
      if (-(0xD ^ 0x9) > 0) {
        return;
      }
      while (!llllIllIIlIII(lllllllllllllllIlIlIlIIIlllIlIll, lllllllllllllllIlIlIlIIIlllIllII))
      {
        int lllllllllllllllIlIlIlIIIlllIlIlI = lIIllllllIIl[0];
        "".length();
        if (((0xE9 ^ 0xC7) & (0x36 ^ 0x18 ^ 0xFFFFFFFF)) != 0) {
          return;
        }
        while (!llllIllIIlIII(lllllllllllllllIlIlIlIIIlllIlIlI, lllllllllllllllIlIlIlIIIlllIllII))
        {
          int lllllllllllllllIlIlIlIIIlllIlIIl = lIIllllllIIl[0];
          "".length();
          if (" ".length() < 0) {
            return;
          }
          while (!llllIllIIlIII(lllllllllllllllIlIlIlIIIlllIlIIl, lllllllllllllllIlIlIlIIIlllIllII))
          {
            double lllllllllllllllIlIlIlIIIlllIlIII = lllllllllllllllIlIlIlIIIlllIIlII.getX() + (lllllllllllllllIlIlIlIIIlllIlIll + 0.5D) / lllllllllllllllIlIlIlIIIlllIllII;
            double lllllllllllllllIlIlIlIIIlllIIlll = lllllllllllllllIlIlIlIIIlllIIlII.getY() + (lllllllllllllllIlIlIlIIIlllIlIlI + 0.5D) / lllllllllllllllIlIlIlIIIlllIllII;
            double lllllllllllllllIlIlIlIIIlllIIllI = lllllllllllllllIlIlIlIIIlllIIlII.getZ() + (lllllllllllllllIlIlIlIIIlllIlIIl + 0.5D) / lllllllllllllllIlIlIlIIIlllIllII;
            lllllllllllllllIlIlIlIIIlllIIlIl.addEffect(new EntityDiggingFX(worldObj, lllllllllllllllIlIlIlIIIlllIlIII, lllllllllllllllIlIlIlIIIlllIIlll, lllllllllllllllIlIlIlIIIlllIIllI, lllllllllllllllIlIlIlIIIlllIlIII - lllllllllllllllIlIlIlIIIlllIIlII.getX() - 0.5D, lllllllllllllllIlIlIlIIIlllIIlll - lllllllllllllllIlIlIlIIIlllIIlII.getY() - 0.5D, lllllllllllllllIlIlIlIIIlllIIllI - lllllllllllllllIlIlIlIIIlllIIlII.getZ() - 0.5D, lllllllllllllllIlIlIlIIIllllIIII).func_174846_a(lllllllllllllllIlIlIlIIIlllIIlII));
          }
        }
      }
    }
  }
  
  public EffectRenderer(World lllllllllllllllIlIlIlIIllllllIlI, TextureManager lllllllllllllllIlIlIlIIlllllIlII)
  {
    worldObj = lllllllllllllllIlIlIlIIlllllIlIl;
    renderer = lllllllllllllllIlIlIlIIlllllIlII;
    int lllllllllllllllIlIlIlIIllllllIII = lIIllllllIIl[0];
    "".length();
    if (" ".length() != " ".length()) {
      throw null;
    }
    while (!llllIllIIlIII(lllllllllllllllIlIlIlIIllllllIII, lIIllllllIIl[2]))
    {
      fxLayers[lllllllllllllllIlIlIlIIllllllIII] = new List[lIIllllllIIl[3]];
      int lllllllllllllllIlIlIlIIlllllIlll = lIIllllllIIl[0];
      "".length();
      if ("  ".length() <= -" ".length()) {
        throw null;
      }
      while (!llllIllIIlIII(lllllllllllllllIlIlIlIIlllllIlll, lIIllllllIIl[3]))
      {
        fxLayers[lllllllllllllllIlIlIlIIllllllIII][lllllllllllllllIlIlIlIIlllllIlll] = Lists.newArrayList();
        lllllllllllllllIlIlIlIIlllllIlll++;
      }
      lllllllllllllllIlIlIlIIllllllIII++;
    }
    lllllllllllllllIlIlIlIIlllllIllI.registerVanillaParticles();
  }
  
  public String getStatistics()
  {
    ;
    ;
    ;
    ;
    int lllllllllllllllIlIlIlIIIlIIlIllI = lIIllllllIIl[0];
    int lllllllllllllllIlIlIlIIIlIIlIlIl = lIIllllllIIl[0];
    "".length();
    if (((0x98 ^ 0x8E) & (0x19 ^ 0xF ^ 0xFFFFFFFF)) == "  ".length()) {
      return null;
    }
    while (!llllIllIIlIII(lllllllllllllllIlIlIlIIIlIIlIlIl, lIIllllllIIl[2]))
    {
      int lllllllllllllllIlIlIlIIIlIIlIlII = lIIllllllIIl[0];
      "".length();
      if (null != null) {
        return null;
      }
      while (!llllIllIIlIII(lllllllllllllllIlIlIlIIIlIIlIlII, lIIllllllIIl[3]))
      {
        lllllllllllllllIlIlIlIIIlIIlIllI += fxLayers[lllllllllllllllIlIlIlIIIlIIlIlIl][lllllllllllllllIlIlIlIIIlIIlIlII].size();
        lllllllllllllllIlIlIlIIIlIIlIlII++;
      }
      lllllllllllllllIlIlIlIIIlIIlIlIl++;
    }
    return String.valueOf(new StringBuilder().append(lllllllllllllllIlIlIlIIIlIIlIllI));
  }
  
  private static boolean llllIllIlIIII(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllIlIlIlIIIIlIIIlll;
    return ??? < i;
  }
  
  public void updateEffects()
  {
    ;
    ;
    ;
    ;
    int lllllllllllllllIlIlIlIIllIIlllll = lIIllllllIIl[0];
    "".length();
    if (-(0x6D ^ 0x68) >= 0) {
      return;
    }
    while (!llllIllIIlIII(lllllllllllllllIlIlIlIIllIIlllll, lIIllllllIIl[2]))
    {
      lllllllllllllllIlIlIlIIllIIllIll.updateEffectLayer(lllllllllllllllIlIlIlIIllIIlllll);
      lllllllllllllllIlIlIlIIllIIlllll++;
    }
    ArrayList lllllllllllllllIlIlIlIIllIIllllI = Lists.newArrayList();
    int lllllllllllllllIlIlIlIIllIIllIII = particleEmitters.iterator();
    "".length();
    if (null != null) {
      return;
    }
    while (!llllIllIIllII(lllllllllllllllIlIlIlIIllIIllIII.hasNext()))
    {
      Object lllllllllllllllIlIlIlIIllIIlllIl = lllllllllllllllIlIlIlIIllIIllIII.next();
      EntityParticleEmitter lllllllllllllllIlIlIlIIllIIlllII = (EntityParticleEmitter)lllllllllllllllIlIlIlIIllIIlllIl;
      lllllllllllllllIlIlIlIIllIIlllII.onUpdate();
      if (llllIllIIlIll(isDead)) {
        "".length();
      }
    }
    "".length();
  }
}

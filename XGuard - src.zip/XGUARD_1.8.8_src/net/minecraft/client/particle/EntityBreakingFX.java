package net.minecraft.client.particle;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ItemModelMesher;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.RenderItem;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.world.World;

public class EntityBreakingFX
  extends EntityFX
{
  protected EntityBreakingFX(World lllllllllllllllIIlIIIIIIIIIllIIl, double lllllllllllllllIIlIIIIIIIIIllIII, double lllllllllllllllIIlIIIIIIIIIlIlll, double lllllllllllllllIIlIIIIIIIIIlIllI, Item lllllllllllllllIIlIIIIIIIIIlIlIl)
  {
    lllllllllllllllIIlIIIIIIIIIlIlII.<init>(lllllllllllllllIIlIIIIIIIIIllIIl, lllllllllllllllIIlIIIIIIIIIllIII, lllllllllllllllIIlIIIIIIIIIlIlll, lllllllllllllllIIlIIIIIIIIIlIllI, lllllllllllllllIIlIIIIIIIIIlIlIl, llIIIlIIIllI[0]);
  }
  
  static {}
  
  private static boolean lIIlIlIlIlIlll(Object ???)
  {
    short lllllllllllllllIIIlllllllIIlllll;
    return ??? != null;
  }
  
  private static void lIIlIlIlIlIllI()
  {
    llIIIlIIIllI = new int[4];
    llIIIlIIIllI[0] = ((81 + 77 - 98 + 85 ^ 42 + 119 - 148 + 115) & (57 + 123 - 36 + 10 ^ 19 + 46 - 37 + 111 ^ -" ".length()));
    llIIIlIIIllI[1] = " ".length();
    llIIIlIIIllI[2] = (57 + '' - 63 + 56 ^ 75 + '' - 149 + 103);
    llIIIlIIIllI[3] = (-" ".length() & 0xFFFFFFFF & 0xFFFF);
  }
  
  protected EntityBreakingFX(World lllllllllllllllIIIlllllllllllIIl, double lllllllllllllllIIlIIIIIIIIIIIIlI, double lllllllllllllllIIlIIIIIIIIIIIIIl, double lllllllllllllllIIIllllllllllIllI, double lllllllllllllllIIIllllllllllllll, double lllllllllllllllIIIllllllllllIlII, double lllllllllllllllIIIllllllllllllIl, Item lllllllllllllllIIIllllllllllIIlI, int lllllllllllllllIIIllllllllllIIIl)
  {
    lllllllllllllllIIIlllllllllllIlI.<init>(lllllllllllllllIIIlllllllllllIIl, lllllllllllllllIIlIIIIIIIIIIIIlI, lllllllllllllllIIlIIIIIIIIIIIIIl, lllllllllllllllIIIllllllllllIllI, lllllllllllllllIIIllllllllllIIlI, lllllllllllllllIIIllllllllllIIIl);
    motionX *= 0.10000000149011612D;
    motionY *= 0.10000000149011612D;
    motionZ *= 0.10000000149011612D;
    motionX += lllllllllllllllIIIllllllllllllll;
    motionY += lllllllllllllllIIIllllllllllIlII;
    motionZ += lllllllllllllllIIIllllllllllllIl;
  }
  
  public void renderParticle(WorldRenderer lllllllllllllllIIIllllllllIIIllI, Entity lllllllllllllllIIIllllllllIIIlIl, float lllllllllllllllIIIllllllllIIIlII, float lllllllllllllllIIIlllllllIllIIII, float lllllllllllllllIIIlllllllIlIllll, float lllllllllllllllIIIllllllllIIIIIl, float lllllllllllllllIIIllllllllIIIIII, float lllllllllllllllIIIlllllllIlIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIIIlllllllIlllllI = (particleTextureIndexX + particleTextureJitterX / 4.0F) / 16.0F;
    float lllllllllllllllIIIlllllllIllllIl = lllllllllllllllIIIlllllllIlllllI + 0.015609375F;
    float lllllllllllllllIIIlllllllIllllII = (particleTextureIndexY + particleTextureJitterY / 4.0F) / 16.0F;
    float lllllllllllllllIIIlllllllIlllIll = lllllllllllllllIIIlllllllIllllII + 0.015609375F;
    float lllllllllllllllIIIlllllllIlllIlI = 0.1F * particleScale;
    if (lIIlIlIlIlIlll(particleIcon))
    {
      lllllllllllllllIIIlllllllIlllllI = particleIcon.getInterpolatedU(particleTextureJitterX / 4.0F * 16.0F);
      lllllllllllllllIIIlllllllIllllIl = particleIcon.getInterpolatedU((particleTextureJitterX + 1.0F) / 4.0F * 16.0F);
      lllllllllllllllIIIlllllllIllllII = particleIcon.getInterpolatedV(particleTextureJitterY / 4.0F * 16.0F);
      lllllllllllllllIIIlllllllIlllIll = particleIcon.getInterpolatedV((particleTextureJitterY + 1.0F) / 4.0F * 16.0F);
    }
    float lllllllllllllllIIIlllllllIlllIIl = (float)(prevPosX + (posX - prevPosX) * lllllllllllllllIIIllllllllIIIlII - interpPosX);
    float lllllllllllllllIIIlllllllIlllIII = (float)(prevPosY + (posY - prevPosY) * lllllllllllllllIIIllllllllIIIlII - interpPosY);
    float lllllllllllllllIIIlllllllIllIlll = (float)(prevPosZ + (posZ - prevPosZ) * lllllllllllllllIIIllllllllIIIlII - interpPosZ);
    int lllllllllllllllIIIlllllllIllIllI = lllllllllllllllIIIlllllllIllIIll.getBrightnessForRender(lllllllllllllllIIIllllllllIIIlII);
    int lllllllllllllllIIIlllllllIllIlIl = lllllllllllllllIIIlllllllIllIllI >> llIIIlIIIllI[2] & llIIIlIIIllI[3];
    int lllllllllllllllIIIlllllllIllIlII = lllllllllllllllIIIlllllllIllIllI & llIIIlIIIllI[3];
    lllllllllllllllIIIllllllllIIIllI.pos(lllllllllllllllIIIlllllllIlllIIl - lllllllllllllllIIIlllllllIllIIII * lllllllllllllllIIIlllllllIlllIlI - lllllllllllllllIIIllllllllIIIIII * lllllllllllllllIIIlllllllIlllIlI, lllllllllllllllIIIlllllllIlllIII - lllllllllllllllIIIlllllllIlIllll * lllllllllllllllIIIlllllllIlllIlI, lllllllllllllllIIIlllllllIllIlll - lllllllllllllllIIIllllllllIIIIIl * lllllllllllllllIIIlllllllIlllIlI - lllllllllllllllIIIlllllllIlIllII * lllllllllllllllIIIlllllllIlllIlI).tex(lllllllllllllllIIIlllllllIlllllI, lllllllllllllllIIIlllllllIlllIll).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lllllllllllllllIIIlllllllIllIlIl, lllllllllllllllIIIlllllllIllIlII).endVertex();
    lllllllllllllllIIIllllllllIIIllI.pos(lllllllllllllllIIIlllllllIlllIIl - lllllllllllllllIIIlllllllIllIIII * lllllllllllllllIIIlllllllIlllIlI + lllllllllllllllIIIllllllllIIIIII * lllllllllllllllIIIlllllllIlllIlI, lllllllllllllllIIIlllllllIlllIII + lllllllllllllllIIIlllllllIlIllll * lllllllllllllllIIIlllllllIlllIlI, lllllllllllllllIIIlllllllIllIlll - lllllllllllllllIIIllllllllIIIIIl * lllllllllllllllIIIlllllllIlllIlI + lllllllllllllllIIIlllllllIlIllII * lllllllllllllllIIIlllllllIlllIlI).tex(lllllllllllllllIIIlllllllIlllllI, lllllllllllllllIIIlllllllIllllII).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lllllllllllllllIIIlllllllIllIlIl, lllllllllllllllIIIlllllllIllIlII).endVertex();
    lllllllllllllllIIIllllllllIIIllI.pos(lllllllllllllllIIIlllllllIlllIIl + lllllllllllllllIIIlllllllIllIIII * lllllllllllllllIIIlllllllIlllIlI + lllllllllllllllIIIllllllllIIIIII * lllllllllllllllIIIlllllllIlllIlI, lllllllllllllllIIIlllllllIlllIII + lllllllllllllllIIIlllllllIlIllll * lllllllllllllllIIIlllllllIlllIlI, lllllllllllllllIIIlllllllIllIlll + lllllllllllllllIIIllllllllIIIIIl * lllllllllllllllIIIlllllllIlllIlI + lllllllllllllllIIIlllllllIlIllII * lllllllllllllllIIIlllllllIlllIlI).tex(lllllllllllllllIIIlllllllIllllIl, lllllllllllllllIIIlllllllIllllII).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lllllllllllllllIIIlllllllIllIlIl, lllllllllllllllIIIlllllllIllIlII).endVertex();
    lllllllllllllllIIIllllllllIIIllI.pos(lllllllllllllllIIIlllllllIlllIIl + lllllllllllllllIIIlllllllIllIIII * lllllllllllllllIIIlllllllIlllIlI - lllllllllllllllIIIllllllllIIIIII * lllllllllllllllIIIlllllllIlllIlI, lllllllllllllllIIIlllllllIlllIII - lllllllllllllllIIIlllllllIlIllll * lllllllllllllllIIIlllllllIlllIlI, lllllllllllllllIIIlllllllIllIlll + lllllllllllllllIIIllllllllIIIIIl * lllllllllllllllIIIlllllllIlllIlI - lllllllllllllllIIIlllllllIlIllII * lllllllllllllllIIIlllllllIlllIlI).tex(lllllllllllllllIIIlllllllIllllIl, lllllllllllllllIIIlllllllIlllIll).color(particleRed, particleGreen, particleBlue, 1.0F).lightmap(lllllllllllllllIIIlllllllIllIlIl, lllllllllllllllIIIlllllllIllIlII).endVertex();
  }
  
  protected EntityBreakingFX(World lllllllllllllllIIIlllllllllIlIII, double lllllllllllllllIIIlllllllllIIIII, double lllllllllllllllIIIllllllllIlllll, double lllllllllllllllIIIlllllllllIIlIl, Item lllllllllllllllIIIllllllllIlllIl, int lllllllllllllllIIIlllllllllIIIll)
  {
    lllllllllllllllIIIlllllllllIlIIl.<init>(lllllllllllllllIIIlllllllllIlIII, lllllllllllllllIIIlllllllllIIIII, lllllllllllllllIIIlllllllllIIllI, lllllllllllllllIIIlllllllllIIlIl, 0.0D, 0.0D, 0.0D);
    lllllllllllllllIIIlllllllllIlIIl.setParticleIcon(Minecraft.getMinecraft().getRenderItem().getItemModelMesher().getParticleIcon(lllllllllllllllIIIllllllllIlllIl, lllllllllllllllIIIlllllllllIIIll));
    particleRed = (lllllllllllllllIIIlllllllllIlIIl.particleGreen = lllllllllllllllIIIlllllllllIlIIl.particleBlue = 1.0F);
    particleGravity = snowblockParticleGravity;
    particleScale /= 2.0F;
  }
  
  public int getFXLayer()
  {
    return llIIIlIIIllI[1];
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    static {}
    
    public EntityFX getEntityFX(int llllllllllllllIlllIlIllIIIIlIlll, World llllllllllllllIlllIlIllIIIIIllII, double llllllllllllllIlllIlIllIIIIlIlIl, double llllllllllllllIlllIlIllIIIIIlIlI, double llllllllllllllIlllIlIllIIIIIlIIl, double llllllllllllllIlllIlIllIIIIlIIlI, double llllllllllllllIlllIlIllIIIIIIlll, double llllllllllllllIlllIlIllIIIIlIIII, int... llllllllllllllIlllIlIllIIIIIIlIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      if (lIlIlllIIllIlI(llllllllllllllIlllIlIllIIIIIIlIl.length, lllIIIlllllI[0]))
      {
        "".length();
        if (-" ".length() < 0) {
          break label44;
        }
        return null;
      }
      label44:
      int llllllllllllllIlllIlIllIIIIIlllI = lllIIIlllllI[1];
      return new EntityBreakingFX(llllllllllllllIlllIlIllIIIIIllII, llllllllllllllIlllIlIllIIIIlIlIl, llllllllllllllIlllIlIllIIIIIlIlI, llllllllllllllIlllIlIllIIIIIlIIl, llllllllllllllIlllIlIllIIIIlIIlI, llllllllllllllIlllIlIllIIIIIIlll, llllllllllllllIlllIlIllIIIIlIIII, Item.getItemById(llllllllllllllIlllIlIllIIIIIIlIl[lllIIIlllllI[1]]), llllllllllllllIlllIlIllIIIIIlllI);
    }
    
    private static boolean lIlIlllIIllIlI(int ???, int arg1)
    {
      int i;
      Exception llllllllllllllIlllIlIllIIIIIIIIl;
      return ??? > i;
    }
    
    private static void lIlIlllIIllIIl()
    {
      lllIIIlllllI = new int[2];
      lllIIIlllllI[0] = " ".length();
      lllIIIlllllI[1] = ((0x2B ^ 0x36) & (0x86 ^ 0x9B ^ 0xFFFFFFFF));
    }
  }
  
  public static class SnowballFactory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int lllllllllllllllIIIlIlllllIIlllll, World lllllllllllllllIIIlIlllllIIlIllI, double lllllllllllllllIIIlIlllllIIlllIl, double lllllllllllllllIIIlIlllllIIlllII, double lllllllllllllllIIIlIlllllIIllIll, double lllllllllllllllIIIlIlllllIIllIlI, double lllllllllllllllIIIlIlllllIIllIIl, double lllllllllllllllIIIlIlllllIIllIII, int... lllllllllllllllIIIlIlllllIIlIlll)
    {
      ;
      ;
      ;
      ;
      return new EntityBreakingFX(lllllllllllllllIIIlIlllllIIlIllI, lllllllllllllllIIIlIlllllIIlllIl, lllllllllllllllIIIlIlllllIIlllII, lllllllllllllllIIIlIlllllIIllIll, Items.snowball);
    }
    
    public SnowballFactory() {}
  }
  
  public static class SlimeFactory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int llllllllllllllIlllllIlIIIlIIIIlI, World llllllllllllllIlllllIlIIIlIIIIIl, double llllllllllllllIlllllIlIIIIlllIII, double llllllllllllllIlllllIlIIIIllllll, double llllllllllllllIlllllIlIIIIlllllI, double llllllllllllllIlllllIlIIIIllllIl, double llllllllllllllIlllllIlIIIIllllII, double llllllllllllllIlllllIlIIIIlllIll, int... llllllllllllllIlllllIlIIIIlllIlI)
    {
      ;
      ;
      ;
      ;
      return new EntityBreakingFX(llllllllllllllIlllllIlIIIlIIIIIl, llllllllllllllIlllllIlIIIIlllIII, llllllllllllllIlllllIlIIIIllllll, llllllllllllllIlllllIlIIIIlllllI, Items.slime_ball);
    }
    
    public SlimeFactory() {}
  }
}

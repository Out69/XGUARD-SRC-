package net.minecraft.client.particle;

import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityCloudFX
  extends EntityFX
{
  private static boolean llIIIIlIIlIIII(int ???)
  {
    boolean llllllllllllllIllIIIlIIIllllllll;
    return ??? > 0;
  }
  
  private static void llIIIIlIIIllII()
  {
    lllllllIIIII = new int[4];
    lllllllIIIII[0] = ((0xFE ^ 0x9C) & (0x64 ^ 0x6 ^ 0xFFFFFFFF));
    lllllllIIIII[1] = " ".length();
    lllllllIIIII[2] = (123 + '' - 192 + 97 ^ '' + 98 - 140 + 74);
    lllllllIIIII[3] = (0xB8 ^ 0x8C ^ 0x89 ^ 0xB5);
  }
  
  private static boolean llIIIIlIIlIIIl(int ???)
  {
    char llllllllllllllIllIIIlIIlIIIIIIIl;
    return ??? != 0;
  }
  
  static {}
  
  private static boolean llIIIIlIIIllll(Object ???)
  {
    long llllllllllllllIllIIIlIIlIIIIIIll;
    return ??? != null;
  }
  
  private static boolean llIIIIlIIIlllI(int ???, int arg1)
  {
    int i;
    double llllllllllllllIllIIIlIIlIIIIIlIl;
    return ??? >= i;
  }
  
  public void renderParticle(WorldRenderer llllllllllllllIllIIIlIIlIIIlIlll, Entity llllllllllllllIllIIIlIIlIIIlIllI, float llllllllllllllIllIIIlIIlIIIlllll, float llllllllllllllIllIIIlIIlIIIllllI, float llllllllllllllIllIIIlIIlIIIlllIl, float llllllllllllllIllIIIlIIlIIIlllII, float llllllllllllllIllIIIlIIlIIIlIIIl, float llllllllllllllIllIIIlIIlIIIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIllIIIlIIlIIIllIIl = (particleAge + llllllllllllllIllIIIlIIlIIIlllll) / particleMaxAge * 32.0F;
    llllllllllllllIllIIIlIIlIIIllIIl = MathHelper.clamp_float(llllllllllllllIllIIIlIIlIIIllIIl, 0.0F, 1.0F);
    particleScale = (field_70569_a * llllllllllllllIllIIIlIIlIIIllIIl);
    llllllllllllllIllIIIlIIlIIlIIIlI.renderParticle(llllllllllllllIllIIIlIIlIIIlIlll, llllllllllllllIllIIIlIIlIIIlIllI, llllllllllllllIllIIIlIIlIIIlllll, llllllllllllllIllIIIlIIlIIIlIlII, llllllllllllllIllIIIlIIlIIIlllIl, llllllllllllllIllIIIlIIlIIIlllII, llllllllllllllIllIIIlIIlIIIlIIIl, llllllllllllllIllIIIlIIlIIIlIIII);
  }
  
  private static int llIIIIlIIIllIl(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  protected EntityCloudFX(World llllllllllllllIllIIIlIIlIIllIlII, double llllllllllllllIllIIIlIIlIIllllII, double llllllllllllllIllIIIlIIlIIlllIll, double llllllllllllllIllIIIlIIlIIllIIIl, double llllllllllllllIllIIIlIIlIIlllIIl, double llllllllllllllIllIIIlIIlIIlIllll, double llllllllllllllIllIIIlIIlIIlIlllI)
  {
    llllllllllllllIllIIIlIIlIIlllllI.<init>(llllllllllllllIllIIIlIIlIIllIlII, llllllllllllllIllIIIlIIlIIllllII, llllllllllllllIllIIIlIIlIIlllIll, llllllllllllllIllIIIlIIlIIllIIIl, 0.0D, 0.0D, 0.0D);
    float llllllllllllllIllIIIlIIlIIllIllI = 2.5F;
    motionX *= 0.10000000149011612D;
    motionY *= 0.10000000149011612D;
    motionZ *= 0.10000000149011612D;
    motionX += llllllllllllllIllIIIlIIlIIlllIIl;
    motionY += llllllllllllllIllIIIlIIlIIlIllll;
    motionZ += llllllllllllllIllIIIlIIlIIlIlllI;
    particleRed = (llllllllllllllIllIIIlIIlIIlllllI.particleGreen = llllllllllllllIllIIIlIIlIIlllllI.particleBlue = 1.0F - (float)(Math.random() * 0.30000001192092896D));
    particleScale *= 0.75F;
    particleScale *= llllllllllllllIllIIIlIIlIIllIllI;
    field_70569_a = particleScale;
    particleMaxAge = ((int)(8.0D / (Math.random() * 0.8D + 0.3D)));
    particleMaxAge = ((int)(particleMaxAge * llllllllllllllIllIIIlIIlIIllIllI));
    noClip = lllllllIIIII[0];
  }
  
  public void onUpdate()
  {
    ;
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    int tmp29_26 = particleAge;
    particleAge = (tmp29_26 + lllllllIIIII[1]);
    if (llIIIIlIIIlllI(tmp29_26, particleMaxAge)) {
      llllllllllllllIllIIIlIIlIIIIllII.setDead();
    }
    llllllllllllllIllIIIlIIlIIIIllII.setParticleTextureIndex(lllllllIIIII[2] - particleAge * lllllllIIIII[3] / particleMaxAge);
    llllllllllllllIllIIIlIIlIIIIllII.moveEntity(motionX, motionY, motionZ);
    motionX *= 0.9599999785423279D;
    motionY *= 0.9599999785423279D;
    motionZ *= 0.9599999785423279D;
    EntityPlayer llllllllllllllIllIIIlIIlIIIIlIll = worldObj.getClosestPlayerToEntity(llllllllllllllIllIIIlIIlIIIIllII, 2.0D);
    if ((llIIIIlIIIllll(llllllllllllllIllIIIlIIlIIIIlIll)) && (llIIIIlIIlIIII(llIIIIlIIIllIl(posY, getEntityBoundingBoxminY))))
    {
      posY += (getEntityBoundingBoxminY - posY) * 0.2D;
      motionY += (motionY - motionY) * 0.2D;
      llllllllllllllIllIIIlIIlIIIIllII.setPosition(posX, posY, posZ);
    }
    if (llIIIIlIIlIIIl(onGround))
    {
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public Factory() {}
    
    public EntityFX getEntityFX(int llllllllllllllllIllIllIIlIIIIIlI, World llllllllllllllllIllIllIIIllllIIl, double llllllllllllllllIllIllIIlIIIIIII, double llllllllllllllllIllIllIIIlllIlll, double llllllllllllllllIllIllIIIllllllI, double llllllllllllllllIllIllIIIlllIlIl, double llllllllllllllllIllIllIIIlllllII, double llllllllllllllllIllIllIIIllllIll, int... llllllllllllllllIllIllIIIllllIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityCloudFX(llllllllllllllllIllIllIIIllllIIl, llllllllllllllllIllIllIIlIIIIIII, llllllllllllllllIllIllIIIlllIlll, llllllllllllllllIllIllIIIllllllI, llllllllllllllllIllIllIIIlllIlIl, llllllllllllllllIllIllIIIlllllII, llllllllllllllllIllIllIIIllllIll);
    }
  }
}

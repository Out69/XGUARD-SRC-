package net.minecraft.client.particle;

import java.util.Random;
import net.minecraft.world.World;

public class EntityEnchantmentTableParticleFX
  extends EntityFX
{
  private static void llIIIIIIIlIlI()
  {
    lllllIlIlII = new int[5];
    lllllIlIlII[0] = ('' + 26 - 78 + 111 ^ 63 + '' - 200 + 156);
    lllllIlIlII[1] = " ".length();
    lllllIlIlII[2] = (45 + '' - 75 + 149);
    lllllIlIlII[3] = (0x67 ^ 0x77);
    lllllIlIlII[4] = ('' + 57 - 178 + 223);
  }
  
  public void onUpdate()
  {
    ;
    ;
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    float llllllllllllllllIIIlIlIIIIlIIllI = particleAge / particleMaxAge;
    llllllllllllllllIIIlIlIIIIlIIllI = 1.0F - llllllllllllllllIIIlIlIIIIlIIllI;
    float llllllllllllllllIIIlIlIIIIlIIlIl = 1.0F - llllllllllllllllIIIlIlIIIIlIIllI;
    llllllllllllllllIIIlIlIIIIlIIlIl *= llllllllllllllllIIIlIlIIIIlIIlIl;
    llllllllllllllllIIIlIlIIIIlIIlIl *= llllllllllllllllIIIlIlIIIIlIIlIl;
    posX = (coordX + motionX * llllllllllllllllIIIlIlIIIIlIIllI);
    posY = (coordY + motionY * llllllllllllllllIIIlIlIIIIlIIllI - llllllllllllllllIIIlIlIIIIlIIlIl * 1.2F);
    posZ = (coordZ + motionZ * llllllllllllllllIIIlIlIIIIlIIllI);
    int tmp111_108 = particleAge;
    particleAge = (tmp111_108 + lllllIlIlII[1]);
    if (llIIIIIIIllII(tmp111_108, particleMaxAge)) {
      llllllllllllllllIIIlIlIIIIlIIlll.setDead();
    }
  }
  
  public float getBrightness(float llllllllllllllllIIIlIlIIIIlIllIl)
  {
    ;
    ;
    ;
    ;
    float llllllllllllllllIIIlIlIIIIllIIII = llllllllllllllllIIIlIlIIIIllIIlI.getBrightness(llllllllllllllllIIIlIlIIIIlIllIl);
    float llllllllllllllllIIIlIlIIIIlIllll = particleAge / particleMaxAge;
    llllllllllllllllIIIlIlIIIIlIllll *= llllllllllllllllIIIlIlIIIIlIllll;
    llllllllllllllllIIIlIlIIIIlIllll *= llllllllllllllllIIIlIlIIIIlIllll;
    return llllllllllllllllIIIlIlIIIIllIIII * (1.0F - llllllllllllllllIIIlIlIIIIlIllll) + llllllllllllllllIIIlIlIIIIlIllll;
  }
  
  static {}
  
  private static boolean llIIIIIIIllII(int ???, int arg1)
  {
    int i;
    float llllllllllllllllIIIlIlIIIIIllllI;
    return ??? >= i;
  }
  
  private static boolean llIIIIIIIlIll(int ???, int arg1)
  {
    int i;
    double llllllllllllllllIIIlIlIIIIIllIlI;
    return ??? > i;
  }
  
  protected EntityEnchantmentTableParticleFX(World llllllllllllllllIIIlIlIIIlIlIIII, double llllllllllllllllIIIlIlIIIlIIllll, double llllllllllllllllIIIlIlIIIlIIlllI, double llllllllllllllllIIIlIlIIIlIlIllI, double llllllllllllllllIIIlIlIIIlIlIlIl, double llllllllllllllllIIIlIlIIIlIIlIll, double llllllllllllllllIIIlIlIIIlIlIIll)
  {
    llllllllllllllllIIIlIlIIIlIlIIIl.<init>(llllllllllllllllIIIlIlIIIlIlIIII, llllllllllllllllIIIlIlIIIlIIllll, llllllllllllllllIIIlIlIIIlIIlllI, llllllllllllllllIIIlIlIIIlIlIllI, llllllllllllllllIIIlIlIIIlIlIlIl, llllllllllllllllIIIlIlIIIlIIlIll, llllllllllllllllIIIlIlIIIlIlIIll);
    motionX = llllllllllllllllIIIlIlIIIlIlIlIl;
    motionY = llllllllllllllllIIIlIlIIIlIIlIll;
    motionZ = llllllllllllllllIIIlIlIIIlIlIIll;
    coordX = llllllllllllllllIIIlIlIIIlIIllll;
    coordY = llllllllllllllllIIIlIlIIIlIIlllI;
    coordZ = llllllllllllllllIIIlIlIIIlIlIllI;
    posX = (llllllllllllllllIIIlIlIIIlIlIIIl.prevPosX = llllllllllllllllIIIlIlIIIlIIllll + llllllllllllllllIIIlIlIIIlIlIlIl);
    posY = (llllllllllllllllIIIlIlIIIlIlIIIl.prevPosY = llllllllllllllllIIIlIlIIIlIIlllI + llllllllllllllllIIIlIlIIIlIIlIll);
    posZ = (llllllllllllllllIIIlIlIIIlIlIIIl.prevPosZ = llllllllllllllllIIIlIlIIIlIlIllI + llllllllllllllllIIIlIlIIIlIlIIll);
    float llllllllllllllllIIIlIlIIIlIlIIlI = rand.nextFloat() * 0.6F + 0.4F;
    field_70565_a = (llllllllllllllllIIIlIlIIIlIlIIIl.particleScale = rand.nextFloat() * 0.5F + 0.2F);
    particleRed = (llllllllllllllllIIIlIlIIIlIlIIIl.particleGreen = llllllllllllllllIIIlIlIIIlIlIIIl.particleBlue = 1.0F * llllllllllllllllIIIlIlIIIlIlIIlI);
    particleGreen *= 0.9F;
    particleRed *= 0.9F;
    particleMaxAge = ((int)(Math.random() * 10.0D) + lllllIlIlII[0]);
    noClip = lllllIlIlII[1];
    llllllllllllllllIIIlIlIIIlIlIIIl.setParticleTextureIndex((int)(Math.random() * 26.0D + 1.0D + 224.0D));
  }
  
  public int getBrightnessForRender(float llllllllllllllllIIIlIlIIIlIIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllllIIIlIlIIIlIIIIII = llllllllllllllllIIIlIlIIIlIIIIlI.getBrightnessForRender(llllllllllllllllIIIlIlIIIlIIIIIl);
    float llllllllllllllllIIIlIlIIIIllllll = particleAge / particleMaxAge;
    llllllllllllllllIIIlIlIIIIllllll *= llllllllllllllllIIIlIlIIIIllllll;
    llllllllllllllllIIIlIlIIIIllllll *= llllllllllllllllIIIlIlIIIIllllll;
    int llllllllllllllllIIIlIlIIIIlllllI = llllllllllllllllIIIlIlIIIlIIIIII & lllllIlIlII[2];
    int llllllllllllllllIIIlIlIIIIllllIl = llllllllllllllllIIIlIlIIIlIIIIII >> lllllIlIlII[3] & lllllIlIlII[2];
    llllllllllllllllIIIlIlIIIIllllIl += (int)(llllllllllllllllIIIlIlIIIIllllll * 15.0F * 16.0F);
    if (llIIIIIIIlIll(llllllllllllllllIIIlIlIIIIllllIl, lllllIlIlII[4])) {
      llllllllllllllllIIIlIlIIIIllllIl = lllllIlIlII[4];
    }
    return llllllllllllllllIIIlIlIIIIlllllI | llllllllllllllllIIIlIlIIIIllllIl << lllllIlIlII[3];
  }
  
  public static class EnchantmentTable
    implements IParticleFactory
  {
    public EnchantmentTable() {}
    
    public EntityFX getEntityFX(int lllllllllllllllIlIllIIIlllIlIlII, World lllllllllllllllIlIllIIIlllIlIIll, double lllllllllllllllIlIllIIIlllIIlIII, double lllllllllllllllIlIllIIIlllIlIIII, double lllllllllllllllIlIllIIIlllIIlllI, double lllllllllllllllIlIllIIIlllIIllIl, double lllllllllllllllIlIllIIIlllIIllII, double lllllllllllllllIlIllIIIlllIIIIll, int... lllllllllllllllIlIllIIIlllIIlIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      return new EntityEnchantmentTableParticleFX(lllllllllllllllIlIllIIIlllIlIIll, lllllllllllllllIlIllIIIlllIIlIII, lllllllllllllllIlIllIIIlllIlIIII, lllllllllllllllIlIllIIIlllIIlllI, lllllllllllllllIlIllIIIlllIIllIl, lllllllllllllllIlIllIIIlllIIllII, lllllllllllllllIlIllIIIlllIIIIll);
    }
  }
}

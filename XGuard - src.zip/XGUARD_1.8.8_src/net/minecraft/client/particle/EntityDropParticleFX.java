package net.minecraft.client.particle;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityDropParticleFX
  extends EntityFX
{
  private static void lllIllIIIlIIII()
  {
    lIIllIlIlllll = new int[9];
    lIIllIlIlllll[0] = (0x2C ^ 0x77 ^ 0x64 ^ 0x4E);
    lIIllIlIlllll[1] = (0x1F ^ 0x75 ^ 0x5C ^ 0x1E);
    lIIllIlIlllll[2] = (0xCB6D & 0x3593);
    lIIllIlIlllll[3] = (0x27 ^ 0x37);
    lIIllIlIlllll[4] = (94 + 64 - -3 + 1 ^ 46 + 36 - 42 + 130);
    lIIllIlIlllll[5] = " ".length();
    lIIllIlIlllll[6] = ('µ' + 94 - 107 + 25 ^ 14 + '£' - 5 + 5);
    lIIllIlIlllll[7] = ((0xD ^ 0x5D) & (0x6E ^ 0x3E ^ 0xFFFFFFFF));
    lIIllIlIlllll[8] = (0x11 ^ 0x69 ^ 0x79 ^ 0x73);
  }
  
  private static boolean lllIllIIIlIIll(int ???)
  {
    long llllllllllllllIIllIlIlIIIllIIlll;
    return ??? > 0;
  }
  
  static {}
  
  public void onUpdate()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    prevPosX = posX;
    prevPosY = posY;
    prevPosZ = posZ;
    if (lllIllIIIlIIIl(materialType, Material.water))
    {
      particleRed = 0.2F;
      particleGreen = 0.3F;
      particleBlue = 1.0F;
      "".length();
      if ((0x6 ^ 0x2) >= 0) {}
    }
    else
    {
      particleRed = 1.0F;
      particleGreen = (16.0F / (lIIllIlIlllll[1] - bobTimer + lIIllIlIlllll[3]));
      particleBlue = (4.0F / (lIIllIlIlllll[1] - bobTimer + lIIllIlIlllll[4]));
    }
    motionY -= particleGravity;
    int tmp140_137 = bobTimer;
    bobTimer = (tmp140_137 - lIIllIlIlllll[5]);
    if (lllIllIIIlIIll(tmp140_137))
    {
      motionX *= 0.02D;
      motionY *= 0.02D;
      motionZ *= 0.02D;
      llllllllllllllIIllIlIlIIIllllIlI.setParticleTextureIndex(lIIllIlIlllll[0]);
      "".length();
      if ("  ".length() <= "  ".length()) {}
    }
    else
    {
      llllllllllllllIIllIlIlIIIllllIlI.setParticleTextureIndex(lIIllIlIlllll[6]);
    }
    llllllllllllllIIllIlIlIIIllllIlI.moveEntity(motionX, motionY, motionZ);
    motionX *= 0.9800000190734863D;
    motionY *= 0.9800000190734863D;
    motionZ *= 0.9800000190734863D;
    int tmp288_285 = particleMaxAge;
    particleMaxAge = (tmp288_285 - lIIllIlIlllll[5]);
    if (lllIllIIIlIlII(tmp288_285)) {
      llllllllllllllIIllIlIlIIIllllIlI.setDead();
    }
    if (lllIllIIIlIlIl(onGround))
    {
      if (lllIllIIIlIIIl(materialType, Material.water))
      {
        llllllllllllllIIllIlIlIIIllllIlI.setDead();
        worldObj.spawnParticle(EnumParticleTypes.WATER_SPLASH, posX, posY, posZ, 0.0D, 0.0D, 0.0D, new int[lIIllIlIlllll[7]]);
        "".length();
        if ("   ".length() > "  ".length()) {}
      }
      else
      {
        llllllllllllllIIllIlIlIIIllllIlI.setParticleTextureIndex(lIIllIlIlllll[8]);
      }
      motionX *= 0.699999988079071D;
      motionZ *= 0.699999988079071D;
    }
    BlockPos llllllllllllllIIllIlIlIIIlllllll = new BlockPos(llllllllllllllIIllIlIlIIIllllIlI);
    IBlockState llllllllllllllIIllIlIlIIIllllllI = worldObj.getBlockState(llllllllllllllIIllIlIlIIIlllllll);
    Material llllllllllllllIIllIlIlIIIlllllIl = llllllllllllllIIllIlIlIIIllllllI.getBlock().getMaterial();
    if ((!lllIllIIIlIllI(llllllllllllllIIllIlIlIIIlllllIl.isLiquid())) || (lllIllIIIlIlIl(llllllllllllllIIllIlIlIIIlllllIl.isSolid())))
    {
      double llllllllllllllIIllIlIlIIIlllllII = 0.0D;
      if (lllIllIIIlIlIl(llllllllllllllIIllIlIlIIIllllllI.getBlock() instanceof BlockLiquid)) {
        llllllllllllllIIllIlIlIIIlllllII = BlockLiquid.getLiquidHeightPercent(((Integer)llllllllllllllIIllIlIlIIIllllllI.getValue(BlockLiquid.LEVEL)).intValue());
      }
      double llllllllllllllIIllIlIlIIIllllIll = MathHelper.floor_double(posY) + lIIllIlIlllll[5] - llllllllllllllIIllIlIlIIIlllllII;
      if (lllIllIIIlIlll(lllIllIIIlIIlI(posY, llllllllllllllIIllIlIlIIIllllIll))) {
        llllllllllllllIIllIlIlIIIllllIlI.setDead();
      }
    }
  }
  
  private static boolean lllIllIIIlIlll(int ???)
  {
    char llllllllllllllIIllIlIlIIIllIlIll;
    return ??? < 0;
  }
  
  private static boolean lllIllIIIlIlIl(int ???)
  {
    long llllllllllllllIIllIlIlIIIllIllll;
    return ??? != 0;
  }
  
  private static boolean lllIllIIIlIlII(int ???)
  {
    byte llllllllllllllIIllIlIlIIIllIlIIl;
    return ??? <= 0;
  }
  
  public int getBrightnessForRender(float llllllllllllllIIllIlIlIIlIIIllIl)
  {
    ;
    ;
    if (lllIllIIIlIIIl(materialType, Material.water))
    {
      "".length();
      if ("   ".length() != 0) {
        break label100;
      }
      return ('' + '' - 132 + 49 ^ 125 + '' - 228 + 115) & (111 + 13 - 85 + 117 ^ '' + '' - 200 + 69 ^ -" ".length());
    }
    label100:
    return lIIllIlIlllll[2];
  }
  
  public float getBrightness(float llllllllllllllIIllIlIlIIlIIIIlll)
  {
    ;
    ;
    if (lllIllIIIlIIIl(materialType, Material.water))
    {
      "".length();
      if (" ".length() <= (0x83 ^ 0x87)) {
        break label42;
      }
      return 0.0F;
    }
    label42:
    return 1.0F;
  }
  
  private static boolean lllIllIIIlIllI(int ???)
  {
    int llllllllllllllIIllIlIlIIIllIllIl;
    return ??? == 0;
  }
  
  private static int lllIllIIIlIIlI(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean lllIllIIIlIIIl(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllIIllIlIlIIIlllIIIl;
    return ??? == localObject;
  }
  
  protected EntityDropParticleFX(World llllllllllllllIIllIlIlIIlIIlllIl, double llllllllllllllIIllIlIlIIlIIlllII, double llllllllllllllIIllIlIlIIlIIllIll, double llllllllllllllIIllIlIlIIlIIllIlI, Material llllllllllllllIIllIlIlIIlIIllIIl)
  {
    llllllllllllllIIllIlIlIIlIIllllI.<init>(llllllllllllllIIllIlIlIIlIIlllIl, llllllllllllllIIllIlIlIIlIIlllII, llllllllllllllIIllIlIlIIlIIllIll, llllllllllllllIIllIlIlIIlIIllIlI, 0.0D, 0.0D, 0.0D);
    motionX = (llllllllllllllIIllIlIlIIlIIllllI.motionY = llllllllllllllIIllIlIlIIlIIllllI.motionZ = 0.0D);
    if (lllIllIIIlIIIl(llllllllllllllIIllIlIlIIlIIllIIl, Material.water))
    {
      particleRed = 0.0F;
      particleGreen = 0.0F;
      particleBlue = 1.0F;
      "".length();
      if (" ".length() == 0) {
        throw null;
      }
    }
    else
    {
      particleRed = 1.0F;
      particleGreen = 0.0F;
      particleBlue = 0.0F;
    }
    llllllllllllllIIllIlIlIIlIIllllI.setParticleTextureIndex(lIIllIlIlllll[0]);
    llllllllllllllIIllIlIlIIlIIllllI.setSize(0.01F, 0.01F);
    particleGravity = 0.06F;
    materialType = llllllllllllllIIllIlIlIIlIIllIIl;
    bobTimer = lIIllIlIlllll[1];
    particleMaxAge = ((int)(64.0D / (Math.random() * 0.8D + 0.2D)));
    motionX = (llllllllllllllIIllIlIlIIlIIllllI.motionY = llllllllllllllIIllIlIlIIlIIllllI.motionZ = 0.0D);
  }
  
  public static class WaterFactory
    implements IParticleFactory
  {
    public WaterFactory() {}
    
    public EntityFX getEntityFX(int lllllllllllllllIIIIlIlIllllIlIII, World lllllllllllllllIIIIlIlIlllIlllll, double lllllllllllllllIIIIlIlIlllIllllI, double lllllllllllllllIIIIlIlIlllIlllIl, double lllllllllllllllIIIIlIlIlllIlllII, double lllllllllllllllIIIIlIlIllllIIIll, double lllllllllllllllIIIIlIlIllllIIIlI, double lllllllllllllllIIIIlIlIllllIIIIl, int... lllllllllllllllIIIIlIlIllllIIIII)
    {
      ;
      ;
      ;
      ;
      return new EntityDropParticleFX(lllllllllllllllIIIIlIlIlllIlllll, lllllllllllllllIIIIlIlIlllIllllI, lllllllllllllllIIIIlIlIlllIlllIl, lllllllllllllllIIIIlIlIlllIlllII, Material.water);
    }
  }
  
  public static class LavaFactory
    implements IParticleFactory
  {
    public LavaFactory() {}
    
    public EntityFX getEntityFX(int llllllllllllllIlIllllllIIllIIIIl, World llllllllllllllIlIllllllIIllIIIII, double llllllllllllllIlIllllllIIlIlllll, double llllllllllllllIlIllllllIIlIllllI, double llllllllllllllIlIllllllIIlIlIlIl, double llllllllllllllIlIllllllIIlIlllII, double llllllllllllllIlIllllllIIlIllIll, double llllllllllllllIlIllllllIIlIllIlI, int... llllllllllllllIlIllllllIIlIllIIl)
    {
      ;
      ;
      ;
      ;
      return new EntityDropParticleFX(llllllllllllllIlIllllllIIllIIIII, llllllllllllllIlIllllllIIlIlllll, llllllllllllllIlIllllllIIlIllllI, llllllllllllllIlIllllllIIlIlIlIl, Material.lava);
    }
  }
}

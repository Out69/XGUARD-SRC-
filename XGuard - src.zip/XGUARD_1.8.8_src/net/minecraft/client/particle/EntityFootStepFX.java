package net.minecraft.client.particle;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class EntityFootStepFX
  extends EntityFX
{
  protected EntityFootStepFX(TextureManager llllllllllllllIlIllIlllIIlIIllll, World llllllllllllllIlIllIlllIIlIIlllI, double llllllllllllllIlIllIlllIIlIIIlll, double llllllllllllllIlIllIlllIIlIIIllI, double llllllllllllllIlIllIlllIIlIIlIll)
  {
    llllllllllllllIlIllIlllIIlIIlIlI.<init>(llllllllllllllIlIllIlllIIlIIlllI, llllllllllllllIlIllIlllIIlIIIlll, llllllllllllllIlIllIlllIIlIIIllI, llllllllllllllIlIllIlllIIlIIlIll, 0.0D, 0.0D, 0.0D);
    currentFootSteps = llllllllllllllIlIllIlllIIlIIllll;
    motionX = (llllllllllllllIlIllIlllIIlIIlIlI.motionY = llllllllllllllIlIllIlllIIlIIlIlI.motionZ = 0.0D);
    footstepMaxAge = lIIIIIIllIIlI[1];
  }
  
  static
  {
    llIIIllIlllllI();
    llIIIllIllllIl();
  }
  
  private static String llIIIllIllllII(String llllllllllllllIlIllIlllIIIIlIIll, String llllllllllllllIlIllIlllIIIIlIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIllIlllIIIIllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIllIlllIIIIlIlII.getBytes(StandardCharsets.UTF_8)), lIIIIIIllIIlI[7]), "DES");
      Cipher llllllllllllllIlIllIlllIIIIlIlll = Cipher.getInstance("DES");
      llllllllllllllIlIllIlllIIIIlIlll.init(lIIIIIIllIIlI[8], llllllllllllllIlIllIlllIIIIllIII);
      return new String(llllllllllllllIlIllIlllIIIIlIlll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIllIlllIIIIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIllIlllIIIIlIllI)
    {
      llllllllllllllIlIllIlllIIIIlIllI.printStackTrace();
    }
    return null;
  }
  
  private static int llIIIllIllllll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llIIIlllIIIIIl(int ???, int arg1)
  {
    int i;
    float llllllllllllllIlIllIlllIIIIIllII;
    return ??? == i;
  }
  
  private static boolean llIIIlllIIIIII(int ???)
  {
    String llllllllllllllIlIllIlllIIIIIlIlI;
    return ??? > 0;
  }
  
  public int getFXLayer()
  {
    return lIIIIIIllIIlI[6];
  }
  
  private static void llIIIllIllllIl()
  {
    lIIIIIIllIIIl = new String[lIIIIIIllIIlI[5]];
    lIIIIIIllIIIl[lIIIIIIllIIlI[0]] = llIIIllIllllII("eR9WAq/QttC9RihF4AQQCupEdQZRGJwurGQaOYDAt0E=", "rjeSJ");
  }
  
  public void renderParticle(WorldRenderer llllllllllllllIlIllIlllIIIlllIIl, Entity llllllllllllllIlIllIlllIIIlllIII, float llllllllllllllIlIllIlllIIIlIlIII, float llllllllllllllIlIllIlllIIIllIllI, float llllllllllllllIlIllIlllIIIllIlIl, float llllllllllllllIlIllIlllIIIllIlII, float llllllllllllllIlIllIlllIIIllIIll, float llllllllllllllIlIllIlllIIIllIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIlIllIlllIIIllIIIl = (footstepAge + llllllllllllllIlIllIlllIIIlIlIII) / footstepMaxAge;
    llllllllllllllIlIllIlllIIIllIIIl *= llllllllllllllIlIllIlllIIIllIIIl;
    float llllllllllllllIlIllIlllIIIllIIII = 2.0F - llllllllllllllIlIllIlllIIIllIIIl * 2.0F;
    if (llIIIlllIIIIII(llIIIllIllllll(llllllllllllllIlIllIlllIIIllIIII, 1.0F))) {
      llllllllllllllIlIllIlllIIIllIIII = 1.0F;
    }
    llllllllllllllIlIllIlllIIIllIIII *= 0.2F;
    GlStateManager.disableLighting();
    float llllllllllllllIlIllIlllIIIlIllll = 0.125F;
    float llllllllllllllIlIllIlllIIIlIlllI = (float)(posX - interpPosX);
    float llllllllllllllIlIllIlllIIIlIllIl = (float)(posY - interpPosY);
    float llllllllllllllIlIllIlllIIIlIllII = (float)(posZ - interpPosZ);
    float llllllllllllllIlIllIlllIIIlIlIll = worldObj.getLightBrightness(new BlockPos(llllllllllllllIlIllIlllIIIlIlIlI));
    currentFootSteps.bindTexture(FOOTPRINT_TEXTURE);
    GlStateManager.enableBlend();
    GlStateManager.blendFunc(lIIIIIIllIIlI[2], lIIIIIIllIIlI[3]);
    llllllllllllllIlIllIlllIIIlllIIl.begin(lIIIIIIllIIlI[4], DefaultVertexFormats.POSITION_TEX_COLOR);
    llllllllllllllIlIllIlllIIIlllIIl.pos(llllllllllllllIlIllIlllIIIlIlllI - 0.125F, llllllllllllllIlIllIlllIIIlIllIl, llllllllllllllIlIllIlllIIIlIllII + 0.125F).tex(0.0D, 1.0D).color(llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIllIIII).endVertex();
    llllllllllllllIlIllIlllIIIlllIIl.pos(llllllllllllllIlIllIlllIIIlIlllI + 0.125F, llllllllllllllIlIllIlllIIIlIllIl, llllllllllllllIlIllIlllIIIlIllII + 0.125F).tex(1.0D, 1.0D).color(llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIllIIII).endVertex();
    llllllllllllllIlIllIlllIIIlllIIl.pos(llllllllllllllIlIllIlllIIIlIlllI + 0.125F, llllllllllllllIlIllIlllIIIlIllIl, llllllllllllllIlIllIlllIIIlIllII - 0.125F).tex(1.0D, 0.0D).color(llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIllIIII).endVertex();
    llllllllllllllIlIllIlllIIIlllIIl.pos(llllllllllllllIlIllIlllIIIlIlllI - 0.125F, llllllllllllllIlIllIlllIIIlIllIl, llllllllllllllIlIllIlllIIIlIllII - 0.125F).tex(0.0D, 0.0D).color(llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIlIlIll, llllllllllllllIlIllIlllIIIllIIII).endVertex();
    Tessellator.getInstance().draw();
    GlStateManager.disableBlend();
    GlStateManager.enableLighting();
  }
  
  private static void llIIIllIlllllI()
  {
    lIIIIIIllIIlI = new int[9];
    lIIIIIIllIIlI[0] = ((0x2 ^ 0x3E ^ 0x21 ^ 0x13) & (0xAB ^ 0x97 ^ 0xB3 ^ 0x81 ^ -" ".length()));
    lIIIIIIllIIlI[1] = ('' + 108 - 61 + 8);
    lIIIIIIllIIlI[2] = (0x834E & 0x7FB3);
    lIIIIIIllIIlI[3] = (-(0xBCBF & 0x53CD) & 0xD7EF & 0x3B9F);
    lIIIIIIllIIlI[4] = (0x3D ^ 0x63 ^ 0xA ^ 0x53);
    lIIIIIIllIIlI[5] = " ".length();
    lIIIIIIllIIlI[6] = "   ".length();
    lIIIIIIllIIlI[7] = (0x81 ^ 0x89);
    lIIIIIIllIIlI[8] = "  ".length();
  }
  
  public void onUpdate()
  {
    ;
    footstepAge += lIIIIIIllIIlI[5];
    if (llIIIlllIIIIIl(footstepAge, footstepMaxAge)) {
      llllllllllllllIlIllIlllIIIIllllI.setDead();
    }
  }
  
  public static class Factory
    implements IParticleFactory
  {
    public EntityFX getEntityFX(int llllllllllllllIlIIlIIllIllIIIlIl, World llllllllllllllIlIIlIIllIllIIIlII, double llllllllllllllIlIIlIIllIllIIIIll, double llllllllllllllIlIIlIIllIlIlllIlI, double llllllllllllllIlIIlIIllIlIlllIIl, double llllllllllllllIlIIlIIllIllIIIIII, double llllllllllllllIlIIlIIllIlIllllll, double llllllllllllllIlIIlIIllIlIlllllI, int... llllllllllllllIlIIlIIllIlIllllIl)
    {
      ;
      ;
      ;
      ;
      return new EntityFootStepFX(Minecraft.getMinecraft().getTextureManager(), llllllllllllllIlIIlIIllIllIIIlII, llllllllllllllIlIIlIIllIllIIIIll, llllllllllllllIlIIlIIllIlIlllIlI, llllllllllllllIlIIlIIllIlIlllIIl);
    }
    
    public Factory() {}
  }
}

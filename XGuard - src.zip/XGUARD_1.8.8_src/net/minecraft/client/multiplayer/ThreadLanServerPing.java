package net.minecraft.client.multiplayer;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import org.apache.logging.log4j.Logger;

public class ThreadLanServerPing
  extends Thread
{
  public void run()
  {
    ;
    ;
    ;
    ;
    ;
    String llllllllllllllIlllIllIlllIllllll = getPingResponse(motd, address);
    byte[] llllllllllllllIlllIllIlllIlllllI = llllllllllllllIlllIllIlllIllllll.getBytes();
    "".length();
    if (((0x52 ^ 0x3 ^ 0x7E ^ 0x66) & (0x30 ^ 0x14 ^ 0x2 ^ 0x6F ^ -" ".length())) != 0) {
      return;
    }
    label159:
    while ((lIlIllIIlIlllI(llllllllllllllIlllIllIllllIIIIII.isInterrupted())) && (!lIlIllIIlIlllI(isStopping)))
    {
      try
      {
        InetAddress llllllllllllllIlllIllIlllIllllIl = InetAddress.getByName(lllIIIIlIlll[lllIIIlIIlIl[1]]);
        DatagramPacket llllllllllllllIlllIllIlllIllllII = new DatagramPacket(llllllllllllllIlllIllIlllIlllllI, llllllllllllllIlllIllIlllIlllllI.length, llllllllllllllIlllIllIlllIllllIl, lllIIIlIIlIl[2]);
        socket.send(llllllllllllllIlllIllIlllIllllII);
        "".length();
        if (-(0x8A ^ 0x8E) < 0) {
          break label159;
        }
        return;
      }
      catch (IOException llllllllllllllIlllIllIlllIlllIll)
      {
        logger.warn(String.valueOf(new StringBuilder(lllIIIIlIlll[lllIIIlIIlIl[3]]).append(llllllllllllllIlllIllIlllIlllIll.getMessage())));
        "".length();
        if (null == null) {
          break;
        }
      }
      return;
      try
      {
        sleep(1500L);
        "".length();
        if (null != null) {
          return;
        }
      }
      catch (InterruptedException localInterruptedException) {}
    }
  }
  
  public static String getAdFromPingResponse(String llllllllllllllIlllIllIlllIIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlllIllIlllIIlllIl = llllllllllllllIlllIllIlllIIllllI.indexOf(lllIIIIlIlll[lllIIIlIIlIl[13]]);
    if (lIlIllIIlIllll(llllllllllllllIlllIllIlllIIlllIl)) {
      return null;
    }
    int llllllllllllllIlllIllIlllIIlllII = llllllllllllllIlllIllIlllIIllIIl.indexOf(lllIIIIlIlll[lllIIIlIIlIl[14]], llllllllllllllIlllIllIlllIIlllIl + lllIIIIlIlll[lllIIIlIIlIl[15]].length());
    if (lIlIllIIllIIIl(llllllllllllllIlllIllIlllIIlllII)) {
      return null;
    }
    int llllllllllllllIlllIllIlllIIllIll = llllllllllllllIlllIllIlllIIllIIl.indexOf(lllIIIIlIlll[lllIIIlIIlIl[16]], llllllllllllllIlllIllIlllIIlllIl + lllIIIIlIlll[lllIIIlIIlIl[17]].length());
    if (lIlIllIIlIllll(llllllllllllllIlllIllIlllIIllIll)) {
      return null;
    }
    int llllllllllllllIlllIllIlllIIllIlI = llllllllllllllIlllIllIlllIIllIIl.indexOf(lllIIIIlIlll[lllIIIlIIlIl[18]], llllllllllllllIlllIllIlllIIllIll + lllIIIIlIlll[lllIIIlIIlIl[19]].length());
    if (lIlIllIIllIIII(llllllllllllllIlllIllIlllIIllIlI, llllllllllllllIlllIllIlllIIllIll))
    {
      "".length();
      if (((29 + '' - 169 + 189 ^ 30 + 69 - -15 + 32) & (0x58 ^ 0x38 ^ 0x35 ^ 0x5 ^ -" ".length())) <= 0) {
        break label219;
      }
      return null;
    }
    label219:
    return llllllllllllllIlllIllIlllIIllIIl.substring(llllllllllllllIlllIllIlllIIllIll + lllIIIIlIlll[lllIIIlIIlIl[20]].length(), llllllllllllllIlllIllIlllIIllIlI);
  }
  
  public static String getMotdFromPingResponse(String llllllllllllllIlllIllIlllIlIIllI)
  {
    ;
    ;
    ;
    int llllllllllllllIlllIllIlllIlIlIII = llllllllllllllIlllIllIlllIlIIllI.indexOf(lllIIIIlIlll[lllIIIlIIlIl[7]]);
    if (lIlIllIIlIllll(llllllllllllllIlllIllIlllIlIlIII)) {
      return lllIIIIlIlll[lllIIIlIIlIl[8]];
    }
    int llllllllllllllIlllIllIlllIlIIlll = llllllllllllllIlllIllIlllIlIlIIl.indexOf(lllIIIIlIlll[lllIIIlIIlIl[9]], llllllllllllllIlllIllIlllIlIlIII + lllIIIIlIlll[lllIIIlIIlIl[10]].length());
    if (lIlIllIIllIIII(llllllllllllllIlllIllIlllIlIIlll, llllllllllllllIlllIllIlllIlIlIII))
    {
      "".length();
      if ((0x49 ^ 0x4C) != 0) {
        break label117;
      }
      return null;
    }
    label117:
    return llllllllllllllIlllIllIlllIlIlIIl.substring(llllllllllllllIlllIllIlllIlIlIII + lllIIIIlIlll[lllIIIlIIlIl[12]].length(), llllllllllllllIlllIllIlllIlIIlll);
  }
  
  public static String getPingResponse(String llllllllllllllIlllIllIlllIllIIII, String llllllllllllllIlllIllIlllIlIllIl)
  {
    ;
    ;
    return String.valueOf(new StringBuilder(lllIIIIlIlll[lllIIIlIIlIl[4]]).append(llllllllllllllIlllIllIlllIllIIII).append(lllIIIIlIlll[lllIIIlIIlIl[5]]).append(llllllllllllllIlllIllIlllIlIllIl).append(lllIIIIlIlll[lllIIIlIIlIl[6]]));
  }
  
  public ThreadLanServerPing(String llllllllllllllIlllIllIllllIIlIlI, String llllllllllllllIlllIllIllllIIIllI)
    throws IOException
  {
    llllllllllllllIlllIllIllllIIlIII.<init>(String.valueOf(new StringBuilder(lllIIIIlIlll[lllIIIlIIlIl[0]]).append(field_148658_a.incrementAndGet())));
    motd = llllllllllllllIlllIllIllllIIIlll;
    address = llllllllllllllIlllIllIllllIIIllI;
    llllllllllllllIlllIllIllllIIlIII.setDaemon(lllIIIlIIlIl[1]);
    socket = new DatagramSocket();
  }
  
  static
  {
    lIlIllIIlIllIl();
    lIlIllIIIllIII();
  }
  
  private static void lIlIllIIlIllIl()
  {
    lllIIIlIIlIl = new int[22];
    lllIIIlIIlIl[0] = ((0xF4 ^ 0xC7) & (0x1 ^ 0x32 ^ 0xFFFFFFFF));
    lllIIIlIIlIl[1] = " ".length();
    lllIIIlIIlIl[2] = (-(0xFE03 & 0x69FD) & 0xFDFD & 0x7B5F);
    lllIIIlIIlIl[3] = "  ".length();
    lllIIIlIIlIl[4] = "   ".length();
    lllIIIlIIlIl[5] = (0x8E ^ 0x8A);
    lllIIIlIIlIl[6] = (0x3D ^ 0x38);
    lllIIIlIIlIl[7] = (0x2E ^ 0x28);
    lllIIIlIIlIl[8] = (0xAB ^ 0xB3 ^ 0x67 ^ 0x78);
    lllIIIlIIlIl[9] = (0x6B ^ 0x63);
    lllIIIlIIlIl[10] = (98 + '' - 95 + 53 ^ 64 + 53 - 112 + 191);
    lllIIIlIIlIl[11] = (26 + 7 - -4 + 94 ^ 112 + 30 - 27 + 22);
    lllIIIlIIlIl[12] = ('·' + 84 - 214 + 150 ^ '' + '¬' - 203 + 69);
    lllIIIlIIlIl[13] = (0xFB ^ 0xBC ^ 0x1C ^ 0x57);
    lllIIIlIIlIl[14] = (0x4D ^ 0x40);
    lllIIIlIIlIl[15] = (0x22 ^ 0x2C);
    lllIIIlIIlIl[16] = (0xF ^ 0x2D ^ 0x96 ^ 0xBB);
    lllIIIlIIlIl[17] = (0x9E ^ 0x8E);
    lllIIIlIIlIl[18] = (0x3D ^ 0x40 ^ 0xD0 ^ 0xBC);
    lllIIIlIIlIl[19] = (0x5F ^ 0x4D);
    lllIIIlIIlIl[20] = ('»' + '¡' - 322 + 184 ^ 120 + '' - 245 + 172);
    lllIIIlIIlIl[21] = (0x30 ^ 0x24);
  }
  
  private static boolean lIlIllIIllIIIl(int ???)
  {
    byte llllllllllllllIlllIllIllIlIllIll;
    return ??? >= 0;
  }
  
  private static String lIlIllIIIIllll(String llllllllllllllIlllIllIlllIIIllIl, String llllllllllllllIlllIllIlllIIIlIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlllIllIlllIIlIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllIllIlllIIIlIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlllIllIlllIIIllll = Cipher.getInstance("Blowfish");
      llllllllllllllIlllIllIlllIIIllll.init(lllIIIlIIlIl[3], llllllllllllllIlllIllIlllIIlIIII);
      return new String(llllllllllllllIlllIllIlllIIIllll.doFinal(Base64.getDecoder().decode(llllllllllllllIlllIllIlllIIIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlllIllIlllIIIlllI)
    {
      llllllllllllllIlllIllIlllIIIlllI.printStackTrace();
    }
    return null;
  }
  
  private static void lIlIllIIIllIII()
  {
    lllIIIIlIlll = new String[lllIIIlIIlIl[21]];
    lllIIIIlIlll[lllIIIlIIlIl[0]] = lIlIllIIIIllIl("B4tzOGGlW3TI6qD++wNrrVqDXDGxwnO6", "kSJcH");
    lllIIIIlIlll[lllIIIlIIlIl[1]] = lIlIllIIIIlllI("RXh2VERZeGxMRA==", "wJBzt");
    lllIIIIlIlll[lllIIIlIIlIl[3]] = lIlIllIIIIlllI("HCAcPAIiNxcdNzkvFQoVamE=", "PArog");
    lllIIIIlIlll[lllIIIlIIlIl[4]] = lIlIllIIIIlllI("LQUiBTMr", "vHmQw");
    lllIIIIlIlll[lllIIIlIIlIl[5]] = lIlIllIIIIllll("fun81XyZrzNA4tpkk7zgRg==", "xziQq");
    lllIIIIlIlll[lllIIIlIIlIl[6]] = lIlIllIIIIllll("beDWnQi7JuA=", "MRyHB");
    lllIIIIlIlll[lllIIIlIIlIl[7]] = lIlIllIIIIlllI("CgoCNiEM", "QGMbe");
    lllIIIIlIlll[lllIIIlIIlIl[8]] = lIlIllIIIIlllI("JAwbKh0nAkg3Gw==", "IehYt");
    lllIIIIlIlll[lllIIIlIIlIl[9]] = lIlIllIIIIllll("rkuWf0Jdluw=", "lxBtp");
    lllIIIIlIlll[lllIIIlIIlIl[10]] = lIlIllIIIIllIl("dU9gWkt82aA=", "JRyue");
    lllIIIIlIlll[lllIIIlIIlIl[11]] = lIlIllIIIIllIl("QekoVuzi53wH+P2cZd8zxQ==", "TMQyE");
    lllIIIIlIlll[lllIIIlIIlIl[12]] = lIlIllIIIIllIl("2Ad1aMO5LeM=", "iNykC");
    lllIIIIlIlll[lllIIIlIIlIl[13]] = lIlIllIIIIllll("dbzumMtDKXE=", "BoYlM");
    lllIIIIlIlll[lllIIIlIIlIl[14]] = lIlIllIIIIllIl("XTimoGS0TlM=", "PPqKz");
    lllIIIIlIlll[lllIIIlIIlIl[15]] = lIlIllIIIIlllI("D1slOxAQKQ==", "TthtD");
    lllIIIIlIlll[lllIIIlIIlIl[16]] = lIlIllIIIIllll("bZ7Q1QUvYkk=", "MJNiO");
    lllIIIIlIlll[lllIIIlIIlIl[17]] = lIlIllIIIIlllI("Eno3BiUNCA==", "IUzIq");
    lllIIIIlIlll[lllIIIlIIlIl[18]] = lIlIllIIIIllll("XXic13VHAFU=", "cejjD");
    lllIIIIlIlll[lllIIIlIIlIl[19]] = lIlIllIIIIllIl("9tP87znJ1pA=", "XMZJK");
    lllIIIIlIlll[lllIIIlIIlIl[20]] = lIlIllIIIIlllI("GCQXLA==", "CeSqE");
  }
  
  private static String lIlIllIIIIllIl(String llllllllllllllIlllIllIlllIIIIIII, String llllllllllllllIlllIllIllIlllllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlllIllIlllIIIIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllIllIllIlllllll.getBytes(StandardCharsets.UTF_8)), lllIIIlIIlIl[9]), "DES");
      Cipher llllllllllllllIlllIllIlllIIIIIlI = Cipher.getInstance("DES");
      llllllllllllllIlllIllIlllIIIIIlI.init(lllIIIlIIlIl[3], llllllllllllllIlllIllIlllIIIIIll);
      return new String(llllllllllllllIlllIllIlllIIIIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIlllIllIlllIIIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlllIllIlllIIIIIIl)
    {
      llllllllllllllIlllIllIlllIIIIIIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlIllIIlIlllI(int ???)
  {
    float llllllllllllllIlllIllIllIlIlllIl;
    return ??? == 0;
  }
  
  private static boolean lIlIllIIlIllll(int ???)
  {
    String llllllllllllllIlllIllIllIlIllIIl;
    return ??? < 0;
  }
  
  private static String lIlIllIIIIlllI(String llllllllllllllIlllIllIllIlllIIII, String llllllllllllllIlllIllIllIllIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlllIllIllIlllIIII = new String(Base64.getDecoder().decode(llllllllllllllIlllIllIllIlllIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlllIllIllIllIlllI = new StringBuilder();
    char[] llllllllllllllIlllIllIllIllIllIl = llllllllllllllIlllIllIllIllIllll.toCharArray();
    int llllllllllllllIlllIllIllIllIllII = lllIIIlIIlIl[0];
    boolean llllllllllllllIlllIllIllIllIIllI = llllllllllllllIlllIllIllIlllIIII.toCharArray();
    long llllllllllllllIlllIllIllIllIIlIl = llllllllllllllIlllIllIllIllIIllI.length;
    double llllllllllllllIlllIllIllIllIIlII = lllIIIlIIlIl[0];
    while (lIlIllIIllIIII(llllllllllllllIlllIllIllIllIIlII, llllllllllllllIlllIllIllIllIIlIl))
    {
      char llllllllllllllIlllIllIllIlllIIIl = llllllllllllllIlllIllIllIllIIllI[llllllllllllllIlllIllIllIllIIlII];
      "".length();
      "".length();
      if (((0xA5 ^ 0x86 ^ (0x2D ^ 0x3E) & (0x18 ^ 0xB ^ 0xFFFFFFFF)) & (0x12 ^ 0x3 ^ 0x32 ^ 0x0 ^ -" ".length())) == -" ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlllIllIllIllIlllI);
  }
  
  public void interrupt()
  {
    ;
    llllllllllllllIlllIllIlllIllIlII.interrupt();
    isStopping = lllIIIlIIlIl[0];
  }
  
  private static boolean lIlIllIIllIIII(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlllIllIllIlIlllll;
    return ??? < i;
  }
}

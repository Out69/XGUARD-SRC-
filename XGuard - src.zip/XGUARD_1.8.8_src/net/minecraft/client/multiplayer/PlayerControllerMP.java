package net.minecraft.client.multiplayer;

import net.minecraft.block.Block;
import net.minecraft.block.Block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C02PacketUseEntity.Action;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C07PacketPlayerDigging.Action;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0EPacketClickWindow;
import net.minecraft.network.play.client.C10PacketCreativeInventoryAction;
import net.minecraft.network.play.client.C11PacketEnchantItem;
import net.minecraft.stats.StatFileWriter;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings.GameType;
import net.minecraft.world.border.WorldBorder;

public class PlayerControllerMP
{
  private static int lIIlIIIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  static {}
  
  private boolean isHittingPosition(BlockPos llIlllIIlIllIIl)
  {
    ;
    ;
    ;
    ;
    ItemStack llIlllIIlIllIII = mc.thePlayer.getHeldItem();
    if ((lIIIlllll(currentItemHittingBlock)) && (lIIIlllll(llIlllIIlIllIII)))
    {
      "".length();
      if (((0x74 ^ 0x58 ^ 0xD2 ^ 0xA1) & (0x2F ^ 0x3C ^ 0x3B ^ 0x77 ^ -" ".length())) < (0x42 ^ 0x6C ^ 0x9C ^ 0xB6)) {
        break label136;
      }
      return (0x41 ^ 0x44 ^ 0x9 ^ 0x3B) & ('' + 33 - 94 + 101 ^ 84 + 96 - 106 + 59 ^ -" ".length());
    }
    label136:
    boolean llIlllIIlIlIlll = lIllIII[2];
    if ((lIIlIIIII(currentItemHittingBlock)) && (lIIlIIIII(llIlllIIlIllIII)))
    {
      if ((lIIIlllIl(llIlllIIlIllIII.getItem(), currentItemHittingBlock.getItem())) && (lIIIllllI(ItemStack.areItemStackTagsEqual(llIlllIIlIllIII, currentItemHittingBlock))) && ((!lIIIlllII(llIlllIIlIllIII.isItemStackDamageable())) || (lIIlIIllI(llIlllIIlIllIII.getMetadata(), currentItemHittingBlock.getMetadata()))))
      {
        "".length();
        if (null == null) {
          break label248;
        }
        return (0x84 ^ 0x97) & (0x5A ^ 0x49 ^ 0xFFFFFFFF);
      }
      label248:
      llIlllIIlIlIlll = lIllIII[2];
    }
    if ((lIIIllllI(llIlllIIlIllIIl.equals(currentBlock))) && (lIIIllllI(llIlllIIlIlIlll))) {
      return lIllIII[1];
    }
    return lIllIII[2];
  }
  
  public void sendSlotPacket(ItemStack llIllIllIllllll, int llIllIllIlllIll)
  {
    ;
    ;
    ;
    if (lIIIllllI(currentGameType.isCreative())) {
      netClientHandler.addToSendQueue(new C10PacketCreativeInventoryAction(llIllIllIlllIll, llIllIllIllllII));
    }
  }
  
  private static boolean lIIIlllII(int ???)
  {
    double llIllIllIIIIIll;
    return ??? == 0;
  }
  
  public static void clickBlockCreative(Minecraft llIlllIlIlllIlI, PlayerControllerMP llIlllIlIlllIIl, BlockPos llIlllIlIllIlII, EnumFacing llIlllIlIllIIll)
  {
    ;
    ;
    ;
    ;
    if (lIIIlllII(theWorld.extinguishFire(thePlayer, llIlllIlIllIlII, llIlllIlIllIIll))) {
      "".length();
    }
  }
  
  public void flipPlayer(EntityPlayer llIlllIlIlIIIIl)
  {
    ;
    rotationYaw = -180.0F;
  }
  
  public void updateController()
  {
    ;
    llIlllIIlIlllll.syncCurrentPlayItem();
    if (lIIIllllI(netClientHandler.getNetworkManager().isChannelOpen()))
    {
      netClientHandler.getNetworkManager().processReceivedPackets();
      "".length();
      if (" ".length() != (0x15 ^ 0x11)) {}
    }
    else
    {
      netClientHandler.getNetworkManager().checkDisconnected();
    }
  }
  
  public boolean func_181040_m()
  {
    ;
    return isHittingBlock;
  }
  
  public void sendPacketDropItem(ItemStack llIllIllIllIlll)
  {
    ;
    ;
    if ((lIIIllllI(currentGameType.isCreative())) && (lIIlIIIII(llIllIllIllIlll))) {
      netClientHandler.addToSendQueue(new C10PacketCreativeInventoryAction(lIllIII[0], llIllIllIllIlll));
    }
  }
  
  private void syncCurrentPlayItem()
  {
    ;
    ;
    int llIlllIIlIIllll = mc.thePlayer.inventory.currentItem;
    if (lIIlIIlll(llIlllIIlIIllll, currentPlayerItem))
    {
      currentPlayerItem = llIlllIIlIIllll;
      netClientHandler.addToSendQueue(new C09PacketHeldItemChange(currentPlayerItem));
    }
  }
  
  public void setPlayerCapabilities(EntityPlayer llIlllIlIlIllll)
  {
    ;
    ;
    currentGameType.configurePlayerCapabilities(capabilities);
  }
  
  public boolean sendUseItem(EntityPlayer llIlllIIIIllIIl, World llIlllIIIIllIII, ItemStack llIlllIIIIlIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIlllIl(currentGameType, WorldSettings.GameType.SPECTATOR)) {
      return lIllIII[2];
    }
    llIlllIIIIllIlI.syncCurrentPlayItem();
    netClientHandler.addToSendQueue(new C08PacketPlayerBlockPlacement(inventory.getCurrentItem()));
    int llIlllIIIIlIllI = stackSize;
    ItemStack llIlllIIIIlIlIl = llIlllIIIIlIlll.useItemRightClick(llIlllIIIIllIII, llIlllIIIIllIIl);
    if ((!lIIIlllIl(llIlllIIIIlIlIl, llIlllIIIIlIlll)) || ((lIIlIIIII(llIlllIIIIlIlIl)) && (lIIlIIlll(stackSize, llIlllIIIIlIllI))))
    {
      inventory.mainInventory[inventory.currentItem] = llIlllIIIIlIlIl;
      if (lIIIlllII(stackSize)) {
        inventory.mainInventory[inventory.currentItem] = null;
      }
      return lIllIII[1];
    }
    return lIllIII[2];
  }
  
  public boolean extendedReach()
  {
    ;
    return currentGameType.isCreative();
  }
  
  public boolean isInCreativeMode()
  {
    ;
    return currentGameType.isCreative();
  }
  
  private static boolean lIIIllllI(int ???)
  {
    Exception llIllIllIIIIlIl;
    return ??? != 0;
  }
  
  public void setGameType(WorldSettings.GameType llIlllIlIlIIlII)
  {
    ;
    ;
    currentGameType = llIlllIlIlIIlII;
    currentGameType.configurePlayerCapabilities(mc.thePlayer.capabilities);
  }
  
  public boolean isSpectatorMode()
  {
    ;
    if (lIIIlllIl(currentGameType, WorldSettings.GameType.SPECTATOR)) {
      return lIllIII[1];
    }
    return lIllIII[2];
  }
  
  public boolean isSpectator()
  {
    ;
    if (lIIIlllIl(currentGameType, WorldSettings.GameType.SPECTATOR)) {
      return lIllIII[1];
    }
    return lIllIII[2];
  }
  
  public float getBlockReachDistance()
  {
    ;
    if (lIIIllllI(currentGameType.isCreative()))
    {
      "".length();
      if (((0x3D ^ 0x5D) & (0xA1 ^ 0xC1 ^ 0xFFFFFFFF)) >= 0) {
        break label45;
      }
      return 0.0F;
    }
    label45:
    return 4.5F;
  }
  
  public boolean gameIsSurvivalOrAdventure()
  {
    ;
    return currentGameType.isSurvivalOrAdventure();
  }
  
  private static boolean lIIIlllIl(Object ???, Object arg1)
  {
    Object localObject;
    double llIllIllIIIlIll;
    return ??? == localObject;
  }
  
  public boolean interactWithEntitySendPacket(EntityPlayer llIllIlllllIlIl, Entity llIllIlllllIlII)
  {
    ;
    ;
    ;
    llIllIlllllIllI.syncCurrentPlayItem();
    netClientHandler.addToSendQueue(new C02PacketUseEntity(llIllIlllllIlII, C02PacketUseEntity.Action.INTERACT));
    if ((lIIlIIIlI(currentGameType, WorldSettings.GameType.SPECTATOR)) && (lIIIllllI(llIllIllllllIII.interactWith(llIllIlllllIlII)))) {
      return lIllIII[1];
    }
    return lIllIII[2];
  }
  
  private static boolean lIIlIIllI(int ???, int arg1)
  {
    int i;
    double llIllIllIIlIIll;
    return ??? == i;
  }
  
  private static boolean lIIlIIlll(int ???, int arg1)
  {
    int i;
    double llIllIlIllllIll;
    return ??? != i;
  }
  
  public ItemStack windowClick(int llIllIlllIlIIll, int llIllIlllIllIlI, int llIllIlllIllIIl, int llIllIlllIllIII, EntityPlayer llIllIlllIlIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    short llIllIlllIlIllI = openContainer.getNextTransactionID(inventory);
    ItemStack llIllIlllIlIlIl = openContainer.slotClick(llIllIlllIllIlI, llIllIlllIllIIl, llIllIlllIllIII, llIllIlllIlIlll);
    netClientHandler.addToSendQueue(new C0EPacketClickWindow(llIllIlllIlIIll, llIllIlllIllIlI, llIllIlllIllIIl, llIllIlllIllIII, llIllIlllIlIlIl, llIllIlllIlIllI));
    return llIllIlllIlIlIl;
  }
  
  private static boolean lIIlIIIll(int ???)
  {
    int llIllIllIIIIIIl;
    return ??? >= 0;
  }
  
  public boolean func_178894_a(EntityPlayer llIllIllllIlIII, Entity llIllIllllIIlll, MovingObjectPosition llIllIllllIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    llIllIllllIlIIl.syncCurrentPlayItem();
    Vec3 llIllIllllIlIlI = new Vec3(hitVec.xCoord - posX, hitVec.yCoord - posY, hitVec.zCoord - posZ);
    netClientHandler.addToSendQueue(new C02PacketUseEntity(llIllIllllIIlll, llIllIllllIlIlI));
    if ((lIIlIIIlI(currentGameType, WorldSettings.GameType.SPECTATOR)) && (lIIIllllI(llIllIllllIIlll.interactAt(llIllIllllIlIII, llIllIllllIlIlI)))) {
      return lIllIII[1];
    }
    return lIllIII[2];
  }
  
  public void resetBlockRemoving()
  {
    ;
    if (lIIIllllI(isHittingBlock))
    {
      netClientHandler.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, currentBlock, EnumFacing.DOWN));
      isHittingBlock = lIllIII[2];
      curBlockDamageMP = 0.0F;
      mc.theWorld.sendBlockBreakProgress(mc.thePlayer.getEntityId(), currentBlock, lIllIII[0]);
    }
  }
  
  private static boolean lIIlIIlIl(int ???)
  {
    boolean llIllIlIlllllll;
    return ??? > 0;
  }
  
  public void sendEnchantPacket(int llIllIlllIIIlIl, int llIllIlllIIIlll)
  {
    ;
    ;
    ;
    netClientHandler.addToSendQueue(new C11PacketEnchantItem(llIllIlllIIlIII, llIllIlllIIIlll));
  }
  
  public boolean isRidingHorse()
  {
    ;
    if ((lIIIllllI(mc.thePlayer.isRiding())) && (lIIIllllI(mc.thePlayer.ridingEntity instanceof EntityHorse))) {
      return lIllIII[1];
    }
    return lIllIII[2];
  }
  
  public WorldSettings.GameType getCurrentGameType()
  {
    ;
    return currentGameType;
  }
  
  private static boolean lIIlIIIII(Object ???)
  {
    boolean llIllIllIIIlIIl;
    return ??? != null;
  }
  
  private static boolean lIIIlllll(Object ???)
  {
    byte llIllIllIIIIlll;
    return ??? == null;
  }
  
  public boolean onPlayerDestroyBlock(BlockPos llIlllIlIIlIlII, EnumFacing llIlllIlIIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIllllI(currentGameType.isAdventure()))
    {
      if (lIIIlllIl(currentGameType, WorldSettings.GameType.SPECTATOR)) {
        return lIllIII[2];
      }
      if (lIIIlllII(mc.thePlayer.isAllowEdit()))
      {
        Block llIlllIlIIlIIlI = mc.theWorld.getBlockState(llIlllIlIIIlIlI).getBlock();
        ItemStack llIlllIlIIlIIIl = mc.thePlayer.getCurrentEquippedItem();
        if (lIIIlllll(llIlllIlIIlIIIl)) {
          return lIllIII[2];
        }
        if (lIIIlllII(llIlllIlIIlIIIl.canDestroy(llIlllIlIIlIIlI))) {
          return lIllIII[2];
        }
      }
    }
    if ((lIIIllllI(currentGameType.isCreative())) && (lIIlIIIII(mc.thePlayer.getHeldItem())) && (lIIIllllI(mc.thePlayer.getHeldItem().getItem() instanceof ItemSword))) {
      return lIllIII[2];
    }
    World llIlllIlIIlIIII = mc.theWorld;
    IBlockState llIlllIlIIIllll = llIlllIlIIlIIII.getBlockState(llIlllIlIIIlIlI);
    Block llIlllIlIIIlllI = llIlllIlIIIllll.getBlock();
    if (lIIIlllIl(llIlllIlIIIlllI.getMaterial(), Material.air)) {
      return lIllIII[2];
    }
    llIlllIlIIlIIII.playAuxSFX(lIllIII[3], llIlllIlIIIlIlI, Block.getStateId(llIlllIlIIIllll));
    boolean llIlllIlIIIllIl = llIlllIlIIlIIII.setBlockToAir(llIlllIlIIIlIlI);
    if (lIIIllllI(llIlllIlIIIllIl)) {
      llIlllIlIIIlllI.onBlockDestroyedByPlayer(llIlllIlIIlIIII, llIlllIlIIIlIlI, llIlllIlIIIllll);
    }
    currentBlock = new BlockPos(currentBlock.getX(), lIllIII[0], currentBlock.getZ());
    if (lIIIlllII(currentGameType.isCreative()))
    {
      ItemStack llIlllIlIIIllII = mc.thePlayer.getCurrentEquippedItem();
      if (lIIlIIIII(llIlllIlIIIllII))
      {
        llIlllIlIIIllII.onBlockDestroyed(llIlllIlIIlIIII, llIlllIlIIIlllI, llIlllIlIIIlIlI, mc.thePlayer);
        if (lIIIlllII(stackSize)) {
          mc.thePlayer.destroyCurrentEquippedItem();
        }
      }
    }
    return llIlllIlIIIllIl;
  }
  
  public void attackEntity(EntityPlayer llIlllIIIIIIIIl, Entity llIlllIIIIIIIII)
  {
    ;
    ;
    ;
    llIlllIIIIIIIlI.syncCurrentPlayItem();
    netClientHandler.addToSendQueue(new C02PacketUseEntity(llIlllIIIIIIIII, C02PacketUseEntity.Action.ATTACK));
    if (lIIlIIIlI(currentGameType, WorldSettings.GameType.SPECTATOR)) {
      llIllIllllllllI.attackTargetEntityWithCurrentItem(llIlllIIIIIIIII);
    }
  }
  
  public PlayerControllerMP(Minecraft llIlllIllIIIIII, NetHandlerPlayClient llIlllIllIIIIlI)
  {
    mc = llIlllIllIIIIll;
    netClientHandler = llIlllIllIIIIlI;
  }
  
  public boolean isNotCreative()
  {
    ;
    if (lIIIllllI(currentGameType.isCreative()))
    {
      "".length();
      if (null == null) {
        break label68;
      }
      return (0xAF ^ 0x95 ^ 0x8C ^ 0x81) & (0x4E ^ 0x25 ^ 0x67 ^ 0x3B ^ -" ".length());
    }
    label68:
    return lIllIII[1];
  }
  
  public void onStoppedUsingItem(EntityPlayer llIllIllIllIIIl)
  {
    ;
    ;
    llIllIllIllIIlI.syncCurrentPlayItem();
    netClientHandler.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
    llIllIllIllIIIl.stopUsingItem();
  }
  
  private static int lIIlIIlII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public EntityPlayerSP func_178892_a(World llIlllIIIIIIlll, StatFileWriter llIlllIIIIIIllI)
  {
    ;
    ;
    ;
    return new EntityPlayerSP(mc, llIlllIIIIIlIlI, netClientHandler, llIlllIIIIIIllI);
  }
  
  public boolean clickBlock(BlockPos llIlllIIlllIlll, EnumFacing llIlllIIlllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIIllllI(currentGameType.isAdventure()))
    {
      if (lIIIlllIl(currentGameType, WorldSettings.GameType.SPECTATOR)) {
        return lIllIII[2];
      }
      if (lIIIlllII(mc.thePlayer.isAllowEdit()))
      {
        Block llIlllIIlllllII = mc.theWorld.getBlockState(llIlllIIllllllI).getBlock();
        ItemStack llIlllIIllllIll = mc.thePlayer.getCurrentEquippedItem();
        if (lIIIlllll(llIlllIIllllIll)) {
          return lIllIII[2];
        }
        if (lIIIlllII(llIlllIIllllIll.canDestroy(llIlllIIlllllII))) {
          return lIllIII[2];
        }
      }
    }
    if (lIIIlllII(mc.theWorld.getWorldBorder().contains(llIlllIIllllllI))) {
      return lIllIII[2];
    }
    if (lIIIllllI(currentGameType.isCreative()))
    {
      netClientHandler.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, llIlllIIllllllI, llIlllIIlllIllI));
      clickBlockCreative(mc, llIlllIIlllllll, llIlllIIllllllI, llIlllIIlllIllI);
      blockHitDelay = lIllIII[4];
      "".length();
      if ("  ".length() == -" ".length()) {
        return (0x18 ^ 0x7F ^ 0xC3 ^ 0x80) & (0x2E ^ 0x7F ^ 0x3E ^ 0x4B ^ -" ".length());
      }
    }
    else if ((!lIIIllllI(isHittingBlock)) || (lIIIlllII(llIlllIIlllllll.isHittingPosition(llIlllIIllllllI))))
    {
      if (lIIIllllI(isHittingBlock)) {
        netClientHandler.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, currentBlock, llIlllIIlllIllI));
      }
      netClientHandler.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, llIlllIIllllllI, llIlllIIlllIllI));
      Block llIlllIIllllIlI = mc.theWorld.getBlockState(llIlllIIllllllI).getBlock();
      if (lIIlIIIlI(llIlllIIllllIlI.getMaterial(), Material.air))
      {
        "".length();
        if ((0x2A ^ 0x2F) != 0) {
          break label384;
        }
        return (0xCF ^ 0x80) & (0xCD ^ 0x82 ^ 0xFFFFFFFF);
      }
      label384:
      boolean llIlllIIllllIIl = lIllIII[2];
      if ((lIIIllllI(llIlllIIllllIIl)) && (lIIIlllII(lIIlIIIIl(curBlockDamageMP, 0.0F)))) {
        llIlllIIllllIlI.onBlockClicked(mc.theWorld, llIlllIIllllllI, mc.thePlayer);
      }
      if ((lIIIllllI(llIlllIIllllIIl)) && (lIIlIIIll(lIIlIIIIl(llIlllIIllllIlI.getPlayerRelativeBlockHardness(mc.thePlayer, mc.thePlayer.worldObj, llIlllIIllllllI), 1.0F))))
      {
        "".length();
        "".length();
        if (((127 + '¯' - 152 + 65 ^ 105 + 71 - 138 + 99) & ('¶' + 20 - 36 + 61 ^ 73 + 76 - 132 + 172 ^ -" ".length())) > "   ".length()) {
          return (123 + 42 - 34 + 11 ^ 9 + 57 - 33 + 142) & (0x5B ^ 0x30 ^ 0xC2 ^ 0x88 ^ -" ".length());
        }
      }
      else
      {
        isHittingBlock = lIllIII[1];
        currentBlock = llIlllIIllllllI;
        currentItemHittingBlock = mc.thePlayer.getHeldItem();
        curBlockDamageMP = 0.0F;
        stepSoundTickCounter = 0.0F;
        mc.theWorld.sendBlockBreakProgress(mc.thePlayer.getEntityId(), currentBlock, (int)(curBlockDamageMP * 10.0F) - lIllIII[1]);
      }
    }
    return lIllIII[1];
  }
  
  public boolean onPlayerRightClick(EntityPlayerSP llIlllIIIllllIl, WorldClient llIlllIIIllllII, ItemStack llIlllIIIlllIll, BlockPos llIlllIIIlllIlI, EnumFacing llIlllIIIlIlIIl, Vec3 llIlllIIIlllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    llIlllIIIlllllI.syncCurrentPlayItem();
    float llIlllIIIllIlll = (float)(xCoord - llIlllIIIlllIlI.getX());
    float llIlllIIIllIllI = (float)(yCoord - llIlllIIIlllIlI.getY());
    float llIlllIIIllIlIl = (float)(zCoord - llIlllIIIlllIlI.getZ());
    boolean llIlllIIIllIlII = lIllIII[2];
    if (lIIIlllII(mc.theWorld.getWorldBorder().contains(llIlllIIIlllIlI))) {
      return lIllIII[2];
    }
    if (lIIlIIIlI(currentGameType, WorldSettings.GameType.SPECTATOR))
    {
      IBlockState llIlllIIIllIIll = llIlllIIIllllII.getBlockState(llIlllIIIlllIlI);
      if (((!lIIIllllI(llIlllIIIllllIl.isSneaking())) || (lIIIlllll(llIlllIIIllllIl.getHeldItem()))) && (lIIIllllI(llIlllIIIllIIll.getBlock().onBlockActivated(llIlllIIIllllII, llIlllIIIlllIlI, llIlllIIIllIIll, llIlllIIIllllIl, llIlllIIIlIlIIl, llIlllIIIllIlll, llIlllIIIllIllI, llIlllIIIllIlIl)))) {
        llIlllIIIllIlII = lIllIII[1];
      }
      if ((lIIIlllII(llIlllIIIllIlII)) && (lIIlIIIII(llIlllIIIlIlIll)) && (lIIIllllI(llIlllIIIlIlIll.getItem() instanceof ItemBlock)))
      {
        ItemBlock llIlllIIIllIIlI = (ItemBlock)llIlllIIIlIlIll.getItem();
        if (lIIIlllII(llIlllIIIllIIlI.canPlaceBlockOnSide(llIlllIIIllllII, llIlllIIIlllIlI, llIlllIIIlIlIIl, llIlllIIIllllIl, llIlllIIIlIlIll))) {
          return lIllIII[2];
        }
      }
    }
    netClientHandler.addToSendQueue(new C08PacketPlayerBlockPlacement(llIlllIIIlllIlI, llIlllIIIlIlIIl.getIndex(), inventory.getCurrentItem(), llIlllIIIllIlll, llIlllIIIllIllI, llIlllIIIllIlIl));
    if ((lIIIlllII(llIlllIIIllIlII)) && (lIIlIIIlI(currentGameType, WorldSettings.GameType.SPECTATOR)))
    {
      if (lIIIlllll(llIlllIIIlIlIll)) {
        return lIllIII[2];
      }
      if (lIIIllllI(currentGameType.isCreative()))
      {
        int llIlllIIIllIIIl = llIlllIIIlIlIll.getMetadata();
        int llIlllIIIllIIII = stackSize;
        boolean llIlllIIIlIllll = llIlllIIIlIlIll.onItemUse(llIlllIIIllllIl, llIlllIIIllllII, llIlllIIIlllIlI, llIlllIIIlIlIIl, llIlllIIIllIlll, llIlllIIIllIllI, llIlllIIIllIlIl);
        llIlllIIIlIlIll.setItemDamage(llIlllIIIllIIIl);
        stackSize = llIlllIIIllIIII;
        return llIlllIIIlIllll;
      }
      return llIlllIIIlIlIll.onItemUse(llIlllIIIllllIl, llIlllIIIllllII, llIlllIIIlllIlI, llIlllIIIlIlIIl, llIlllIIIllIlll, llIlllIIIllIllI, llIlllIIIllIlIl);
    }
    return lIllIII[1];
  }
  
  public boolean shouldDrawHUD()
  {
    ;
    return currentGameType.isSurvivalOrAdventure();
  }
  
  public boolean onPlayerDamageBlock(BlockPos llIlllIIllIIlll, EnumFacing llIlllIIllIlIlI)
  {
    ;
    ;
    ;
    ;
    llIlllIIllIlIII.syncCurrentPlayItem();
    if (lIIlIIlIl(blockHitDelay))
    {
      blockHitDelay -= lIllIII[1];
      return lIllIII[1];
    }
    if ((lIIIllllI(currentGameType.isCreative())) && (lIIIllllI(mc.theWorld.getWorldBorder().contains(llIlllIIllIlIll))))
    {
      blockHitDelay = lIllIII[4];
      netClientHandler.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, llIlllIIllIlIll, llIlllIIllIlIlI));
      clickBlockCreative(mc, llIlllIIllIlIII, llIlllIIllIlIll, llIlllIIllIlIlI);
      return lIllIII[1];
    }
    if (lIIIllllI(llIlllIIllIlIII.isHittingPosition(llIlllIIllIlIll)))
    {
      Block llIlllIIllIlIIl = mc.theWorld.getBlockState(llIlllIIllIlIll).getBlock();
      if (lIIIlllIl(llIlllIIllIlIIl.getMaterial(), Material.air))
      {
        isHittingBlock = lIllIII[2];
        return lIllIII[2];
      }
      curBlockDamageMP += llIlllIIllIlIIl.getPlayerRelativeBlockHardness(mc.thePlayer, mc.thePlayer.worldObj, llIlllIIllIlIll);
      if (lIIIlllII(lIIlIIlII(stepSoundTickCounter % 4.0F, 0.0F))) {
        mc.getSoundHandler().playSound(new PositionedSoundRecord(new ResourceLocation(stepSound.getStepSound()), (stepSound.getVolume() + 1.0F) / 8.0F, stepSound.getFrequency() * 0.5F, llIlllIIllIlIll.getX() + 0.5F, llIlllIIllIlIll.getY() + 0.5F, llIlllIIllIlIll.getZ() + 0.5F));
      }
      stepSoundTickCounter += 1.0F;
      if (lIIlIIIll(lIIlIIlII(curBlockDamageMP, 1.0F)))
      {
        isHittingBlock = lIllIII[2];
        netClientHandler.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, llIlllIIllIlIll, llIlllIIllIlIlI));
        "".length();
        curBlockDamageMP = 0.0F;
        stepSoundTickCounter = 0.0F;
        blockHitDelay = lIllIII[4];
      }
      mc.theWorld.sendBlockBreakProgress(mc.thePlayer.getEntityId(), currentBlock, (int)(curBlockDamageMP * 10.0F) - lIllIII[1]);
      return lIllIII[1];
    }
    return llIlllIIllIlIII.clickBlock(llIlllIIllIlIll, llIlllIIllIlIlI);
  }
  
  private static boolean lIIlIIIlI(Object ???, Object arg1)
  {
    Object localObject;
    Exception llIllIllIIIllll;
    return ??? != localObject;
  }
  
  private static void lIIIllIll()
  {
    lIllIII = new int[5];
    lIllIII[0] = (-" ".length());
    lIllIII[1] = " ".length();
    lIllIII[2] = ((0xC ^ 0x52 ^ 0x51 ^ 0x40) & (0x9 ^ 0x7 ^ 0x7B ^ 0x3A ^ -" ".length()));
    lIllIII[3] = (-(0x8CCF & 0x7B37) & 0xBFD7 & 0x4FFF);
    lIllIII[4] = (0x15 ^ 0xA ^ 0xB4 ^ 0xAE);
  }
}

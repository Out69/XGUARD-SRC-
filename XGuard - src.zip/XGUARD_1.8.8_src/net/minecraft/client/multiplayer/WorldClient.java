package net.minecraft.client.multiplayer;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.Callable;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.MovingSoundMinecart;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.particle.EffectRenderer;
import net.minecraft.client.particle.EntityFirework.StarterFX;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.profiler.Profiler;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.IntHashMap;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.WorldSettings.GameType;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.storage.SaveDataMemoryStorage;
import net.minecraft.world.storage.SaveHandlerMP;
import net.minecraft.world.storage.WorldInfo;
import optfine.BlockPosM;

public class WorldClient
  extends World
{
  public void sendQuittingDisconnectingPacket()
  {
    ;
    sendQueue.getNetworkManager().closeChannel(new ChatComponentText(llIIIIIlIllI[llIIIIIlIlll[12]]));
  }
  
  public void removeAllEntities()
  {
    ;
    ;
    ;
    ;
    ;
    "".length();
    int lllllllllllllllIIlIIIllIIlIlllII = llIIIIIlIlll[0];
    "".length();
    if (null != null) {
      return;
    }
    while (!lIIlIIllllIllI(lllllllllllllllIIlIIIllIIlIlllII, unloadedEntityList.size()))
    {
      Entity lllllllllllllllIIlIIIllIIlIllIll = (Entity)unloadedEntityList.get(lllllllllllllllIIlIIIllIIlIlllII);
      int lllllllllllllllIIlIIIllIIlIllIlI = chunkCoordX;
      int lllllllllllllllIIlIIIllIIlIllIIl = chunkCoordZ;
      if ((lIIlIIllllIIlI(addedToChunk)) && (lIIlIIllllIIlI(lllllllllllllllIIlIIIllIIlIlIIll.isChunkLoaded(lllllllllllllllIIlIIIllIIlIllIlI, lllllllllllllllIIlIIIllIIlIllIIl, llIIIIIlIlll[1])))) {
        lllllllllllllllIIlIIIllIIlIlIIll.getChunkFromChunkCoords(lllllllllllllllIIlIIIllIIlIllIlI, lllllllllllllllIIlIIIllIIlIllIIl).removeEntity(lllllllllllllllIIlIIIllIIlIllIll);
      }
      lllllllllllllllIIlIIIllIIlIlllII++;
    }
    int lllllllllllllllIIlIIIllIIlIllIII = llIIIIIlIlll[0];
    "".length();
    if (null != null) {
      return;
    }
    while (!lIIlIIllllIllI(lllllllllllllllIIlIIIllIIlIllIII, unloadedEntityList.size())) {
      lllllllllllllllIIlIIIllIIlIlIIll.onEntityRemoved((Entity)unloadedEntityList.get(lllllllllllllllIIlIIIllIIlIllIII));
    }
    unloadedEntityList.clear();
    int lllllllllllllllIIlIIIllIIlIlIlll = llIIIIIlIlll[0];
    "".length();
    if ((0x77 ^ 0x72) <= 0) {
      return;
    }
    while (!lIIlIIllllIllI(lllllllllllllllIIlIIIllIIlIlIlll, loadedEntityList.size()))
    {
      Entity lllllllllllllllIIlIIIllIIlIlIllI = (Entity)loadedEntityList.get(lllllllllllllllIIlIIIllIIlIlIlll);
      if (lIIlIIllllIlll(ridingEntity))
      {
        if ((lIIlIIllllIIll(ridingEntity.isDead)) && (lIIlIIlllllIII(ridingEntity.riddenByEntity, lllllllllllllllIIlIIIllIIlIlIllI)))
        {
          "".length();
          if ("  ".length() <= "  ".length()) {}
        }
        else
        {
          ridingEntity.riddenByEntity = null;
          ridingEntity = null;
        }
      }
      else if (lIIlIIllllIIlI(isDead))
      {
        int lllllllllllllllIIlIIIllIIlIlIlIl = chunkCoordX;
        int lllllllllllllllIIlIIIllIIlIlIlII = chunkCoordZ;
        if ((lIIlIIllllIIlI(addedToChunk)) && (lIIlIIllllIIlI(lllllllllllllllIIlIIIllIIlIlIIll.isChunkLoaded(lllllllllllllllIIlIIIllIIlIlIlIl, lllllllllllllllIIlIIIllIIlIlIlII, llIIIIIlIlll[1])))) {
          lllllllllllllllIIlIIIllIIlIlIIll.getChunkFromChunkCoords(lllllllllllllllIIlIIIllIIlIlIlIl, lllllllllllllllIIlIIIllIIlIlIlII).removeEntity(lllllllllllllllIIlIIIllIIlIlIllI);
        }
        "".length();
        lllllllllllllllIIlIIIllIIlIlIIll.onEntityRemoved(lllllllllllllllIIlIIIllIIlIlIllI);
      }
      lllllllllllllllIIlIIIllIIlIlIlll++;
    }
  }
  
  private static String lIIlIIlllIllll(String lllllllllllllllIIlIIIlIllllIIIIl, String lllllllllllllllIIlIIIlIlllIllllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlIIIlIllllIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlIIIlIlllIllllI.getBytes(StandardCharsets.UTF_8)), llIIIIIlIlll[3]), "DES");
      Cipher lllllllllllllllIIlIIIlIllllIIIll = Cipher.getInstance("DES");
      lllllllllllllllIIlIIIlIllllIIIll.init(llIIIIIlIlll[5], lllllllllllllllIIlIIIlIllllIIlII);
      return new String(lllllllllllllllIIlIIIlIllllIIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlIIIlIllllIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlIIIlIllllIIIlI)
    {
      lllllllllllllllIIlIIIlIllllIIIlI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIlIIllllIlll(Object ???)
  {
    float lllllllllllllllIIlIIIlIllIlIlIIl;
    return ??? != null;
  }
  
  public void playSound(double lllllllllllllllIIlIIIllIIIlIIlll, double lllllllllllllllIIlIIIllIIIIllIll, double lllllllllllllllIIlIIIllIIIIllIlI, String lllllllllllllllIIlIIIllIIIIllIIl, float lllllllllllllllIIlIIIllIIIIllIII, float lllllllllllllllIIlIIIllIIIIlIlll, boolean lllllllllllllllIIlIIIllIIIIlIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    double lllllllllllllllIIlIIIllIIIlIIIII = mc.getRenderViewEntity().getDistanceSq(lllllllllllllllIIlIIIllIIIlIIlll, lllllllllllllllIIlIIIllIIIIllIll, lllllllllllllllIIlIIIllIIIIllIlI);
    PositionedSoundRecord lllllllllllllllIIlIIIllIIIIlllll = new PositionedSoundRecord(new ResourceLocation(lllllllllllllllIIlIIIllIIIIllIIl), lllllllllllllllIIlIIIllIIIIllIII, lllllllllllllllIIlIIIllIIIIlIlll, (float)lllllllllllllllIIlIIIllIIIlIIlll, (float)lllllllllllllllIIlIIIllIIIIllIll, (float)lllllllllllllllIIlIIIllIIIIllIlI);
    if ((lIIlIIllllIIlI(lllllllllllllllIIlIIIllIIIIlIllI)) && (lIIlIIlllllIlI(lIIlIIlllllIIl(lllllllllllllllIIlIIIllIIIlIIIII, 100.0D))))
    {
      double lllllllllllllllIIlIIIllIIIIllllI = Math.sqrt(lllllllllllllllIIlIIIllIIIlIIIII) / 40.0D;
      mc.getSoundHandler().playDelayedSound(lllllllllllllllIIlIIIllIIIIlllll, (int)(lllllllllllllllIIlIIIllIIIIllllI * 20.0D));
      "".length();
      if (null == null) {}
    }
    else
    {
      mc.getSoundHandler().playSound(lllllllllllllllIIlIIIllIIIIlllll);
    }
  }
  
  private static boolean lIIlIIllllIllI(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIIlIIIlIllIlIllll;
    return ??? >= i;
  }
  
  public void doPreChunk(int lllllllllllllllIIlIIIllIlllIIIIl, int lllllllllllllllIIlIIIllIlllIIlII, boolean lllllllllllllllIIlIIIllIlllIIIll)
  {
    ;
    ;
    ;
    ;
    if (lIIlIIllllIIlI(lllllllllllllllIIlIIIllIlllIIIll))
    {
      "".length();
      "".length();
      if (-(123 + '' - 186 + 76 ^ 102 + 47 - 18 + 18) < 0) {}
    }
    else
    {
      clientChunkProvider.unloadChunk(lllllllllllllllIIlIIIllIlllIIIIl, lllllllllllllllIIlIIIllIlllIIlII);
    }
    if (lIIlIIllllIIll(lllllllllllllllIIlIIIllIlllIIIll)) {
      lllllllllllllllIIlIIIllIlllIIIlI.markBlockRangeForRenderUpdate(lllllllllllllllIIlIIIllIlllIIIIl * llIIIIIlIlll[8], llIIIIIlIlll[0], lllllllllllllllIIlIIIllIlllIIlII * llIIIIIlIlll[8], lllllllllllllllIIlIIIllIlllIIIIl * llIIIIIlIlll[8] + llIIIIIlIlll[10], llIIIIIlIlll[11], lllllllllllllllIIlIIIllIlllIIlII * llIIIIIlIlll[8] + llIIIIIlIlll[10]);
    }
  }
  
  protected void updateBlocks()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIIllIllllIIIl.updateBlocks();
    "".length();
    if (lIIlIIllllIlIl(previousActiveChunkSet.size(), activeChunkSet.size())) {
      previousActiveChunkSet.clear();
    }
    int lllllllllllllllIIlIIIllIllllIllI = llIIIIIlIlll[0];
    double lllllllllllllllIIlIIIllIlllIlllI = activeChunkSet.iterator();
    "".length();
    if ("   ".length() <= " ".length()) {
      return;
    }
    while (!lIIlIIllllIIll(lllllllllllllllIIlIIIllIlllIlllI.hasNext()))
    {
      ChunkCoordIntPair lllllllllllllllIIlIIIllIllllIlIl = (ChunkCoordIntPair)lllllllllllllllIIlIIIllIlllIlllI.next();
      if (lIIlIIllllIIll(previousActiveChunkSet.contains(lllllllllllllllIIlIIIllIllllIlIl)))
      {
        int lllllllllllllllIIlIIIllIllllIlII = chunkXPos * llIIIIIlIlll[8];
        int lllllllllllllllIIlIIIllIllllIIll = chunkZPos * llIIIIIlIlll[8];
        theProfiler.startSection(llIIIIIlIllI[llIIIIIlIlll[9]]);
        Chunk lllllllllllllllIIlIIIllIllllIIlI = lllllllllllllllIIlIIIllIllllIlll.getChunkFromChunkCoords(chunkXPos, chunkZPos);
        lllllllllllllllIIlIIIllIllllIlll.playMoodSoundAndCheckLight(lllllllllllllllIIlIIIllIllllIlII, lllllllllllllllIIlIIIllIllllIIll, lllllllllllllllIIlIIIllIllllIIlI);
        theProfiler.endSection();
        "".length();
        if (lIIlIIllllIllI(++lllllllllllllllIIlIIIllIllllIllI, llIIIIIlIlll[6])) {
          return;
        }
      }
    }
  }
  
  protected void updateWeather() {}
  
  private static boolean lIIlIIllllIIlI(int ???)
  {
    String lllllllllllllllIIlIIIlIllIlIIIll;
    return ??? != 0;
  }
  
  private static boolean lIIlIIllllIIll(int ???)
  {
    double lllllllllllllllIIlIIIlIllIlIIIIl;
    return ??? == 0;
  }
  
  protected void onEntityAdded(Entity lllllllllllllllIIlIIIllIllIIlIlI)
  {
    ;
    ;
    lllllllllllllllIIlIIIllIllIIllIl.onEntityAdded(lllllllllllllllIIlIIIllIllIIlIlI);
    if (lIIlIIllllIIlI(entitySpawnQueue.contains(lllllllllllllllIIlIIIllIllIIlIlI))) {
      "".length();
    }
  }
  
  public void invalidateBlockReceiveRegion(int lllllllllllllllIIlIIIlllIIIIIlll, int lllllllllllllllIIlIIIlllIIIIIllI, int lllllllllllllllIIlIIIlllIIIIIlIl, int lllllllllllllllIIlIIIlllIIIIIlII, int lllllllllllllllIIlIIIlllIIIIIIll, int lllllllllllllllIIlIIIlllIIIIIIlI) {}
  
  public void tick()
  {
    ;
    ;
    ;
    lllllllllllllllIIlIIIlllIIIIlllI.tick();
    lllllllllllllllIIlIIIlllIIIIlIll.setTotalWorldTime(lllllllllllllllIIlIIIlllIIIIlIll.getTotalWorldTime() + 1L);
    if (lIIlIIllllIIlI(lllllllllllllllIIlIIIlllIIIIlIll.getGameRules().getBoolean(llIIIIIlIllI[llIIIIIlIlll[1]]))) {
      lllllllllllllllIIlIIIlllIIIIlIll.setWorldTime(lllllllllllllllIIlIIIlllIIIIlIll.getWorldTime() + 1L);
    }
    theProfiler.startSection(llIIIIIlIllI[llIIIIIlIlll[5]]);
    int lllllllllllllllIIlIIIlllIIIIllIl = llIIIIIlIlll[0];
    "".length();
    if (null != null) {
      return;
    }
    while ((lIIlIIllllIlII(lllllllllllllllIIlIIIlllIIIIllIl, llIIIIIlIlll[6])) && (!lIIlIIllllIIlI(entitySpawnQueue.isEmpty())))
    {
      Entity lllllllllllllllIIlIIIlllIIIIllII = (Entity)entitySpawnQueue.iterator().next();
      "".length();
      if (lIIlIIllllIIll(loadedEntityList.contains(lllllllllllllllIIlIIIlllIIIIllII))) {
        "".length();
      }
      lllllllllllllllIIlIIIlllIIIIllIl++;
    }
    theProfiler.endStartSection(llIIIIIlIllI[llIIIIIlIlll[2]]);
    "".length();
    theProfiler.endStartSection(llIIIIIlIllI[llIIIIIlIlll[7]]);
    lllllllllllllllIIlIIIlllIIIIlIll.updateBlocks();
    theProfiler.endSection();
  }
  
  private static int lIIlIIlllllIll(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  public void doVoidFogParticles(int lllllllllllllllIIlIIIllIIlllllIl, int lllllllllllllllIIlIIIllIIlllllII, int lllllllllllllllIIlIIIllIIllIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    byte lllllllllllllllIIlIIIllIIllllIlI = llIIIIIlIlll[8];
    Random lllllllllllllllIIlIIIllIIllllIIl = new Random();
    ItemStack lllllllllllllllIIlIIIllIIllllIII = mc.thePlayer.getHeldItem();
    if ((lIIlIIlllllIII(mc.playerController.getCurrentGameType(), WorldSettings.GameType.CREATIVE)) && (lIIlIIllllIlll(lllllllllllllllIIlIIIllIIllllIII)) && (lIIlIIlllllIII(Block.getBlockFromItem(lllllllllllllllIIlIIIllIIllllIII.getItem()), Blocks.barrier)))
    {
      "".length();
      if (null == null) {
        break label94;
      }
    }
    label94:
    boolean lllllllllllllllIIlIIIllIIlllIlll = llIIIIIlIlll[0];
    BlockPosM lllllllllllllllIIlIIIllIIlllIllI = randomTickPosM;
    int lllllllllllllllIIlIIIllIIlllIlIl = llIIIIIlIlll[0];
    "".length();
    if (-(0x6A ^ 0x6F) >= 0) {
      return;
    }
    while (!lIIlIIllllIllI(lllllllllllllllIIlIIIllIIlllIlIl, llIIIIIlIlll[13]))
    {
      int lllllllllllllllIIlIIIllIIlllIlII = lllllllllllllllIIlIIIllIIlllllIl + rand.nextInt(lllllllllllllllIIlIIIllIIllllIlI) - rand.nextInt(lllllllllllllllIIlIIIllIIllllIlI);
      int lllllllllllllllIIlIIIllIIlllIIll = lllllllllllllllIIlIIIllIIlllllII + rand.nextInt(lllllllllllllllIIlIIIllIIllllIlI) - rand.nextInt(lllllllllllllllIIlIIIllIIllllIlI);
      int lllllllllllllllIIlIIIllIIlllIIlI = lllllllllllllllIIlIIIllIIllIllIl + rand.nextInt(lllllllllllllllIIlIIIllIIllllIlI) - rand.nextInt(lllllllllllllllIIlIIIllIIllllIlI);
      lllllllllllllllIIlIIIllIIlllIllI.setXyz(lllllllllllllllIIlIIIllIIlllIlII, lllllllllllllllIIlIIIllIIlllIIll, lllllllllllllllIIlIIIllIIlllIIlI);
      IBlockState lllllllllllllllIIlIIIllIIlllIIIl = lllllllllllllllIIlIIIllIIlllIIII.getBlockState(lllllllllllllllIIlIIIllIIlllIllI);
      lllllllllllllllIIlIIIllIIlllIIIl.getBlock().randomDisplayTick(lllllllllllllllIIlIIIllIIlllIIII, lllllllllllllllIIlIIIllIIlllIllI, lllllllllllllllIIlIIIllIIlllIIIl, lllllllllllllllIIlIIIllIIllllIIl);
      if ((lIIlIIllllIIlI(lllllllllllllllIIlIIIllIIlllIlll)) && (lIIlIIlllllIII(lllllllllllllllIIlIIIllIIlllIIIl.getBlock(), Blocks.barrier))) {
        lllllllllllllllIIlIIIllIIlllIIII.spawnParticle(EnumParticleTypes.BARRIER, lllllllllllllllIIlIIIllIIlllIlII + 0.5F, lllllllllllllllIIlIIIllIIlllIIll + 0.5F, lllllllllllllllIIlIIIllIIlllIIlI + 0.5F, 0.0D, 0.0D, 0.0D, new int[llIIIIIlIlll[0]]);
      }
      lllllllllllllllIIlIIIllIIlllIlIl++;
    }
  }
  
  private static void lIIlIIllllIIII()
  {
    llIIIIIlIllI = new String[llIIIIIlIlll[8]];
    llIIIIIlIllI[llIIIIIlIlll[0]] = lIIlIIlllIllIl("6muBgD+a4Pf73OAK+WUCCg==", "IHDZv");
    llIIIIIlIllI[llIIIIIlIlll[1]] = lIIlIIlllIlllI("KhsdMikiHT47JA0NOj81", "NtYSP");
    llIIIIIlIllI[llIIIIIlIlll[5]] = lIIlIIlllIllll("Ea3YgS1N/fDVz2KTIY2cNDjw6k6RMMzb", "KnhYw");
    llIIIIIlIllI[llIIIIIlIlll[2]] = lIIlIIlllIllIl("SufCRew40AAXOmM51Clv0Q==", "dCKNy");
    llIIIIIlIllI[llIIIIIlIlll[7]] = lIIlIIlllIllIl("28xf81vwIjs=", "sjcoj");
    llIIIIIlIllI[llIIIIIlIlll[9]] = lIIlIIlllIllIl("Ce3VCnqkYtF5Vu4YCFhRuA==", "NQBXq");
    llIIIIIlIllI[llIIIIIlIlll[12]] = lIIlIIlllIlllI("AjEOJzw6KgA=", "SDgSH");
    llIIIIIlIllI[llIIIIIlIlll[14]] = lIIlIIlllIlllI("HwkkCxA9RjMGATASPw0G", "YfVhu");
    llIIIIIlIllI[llIIIIIlIlll[3]] = lIIlIIlllIllll("HUpCJgbC28cS6ppl3ccs9Q==", "qIVqJ");
    llIIIIIlIllI[llIIIIIlIlll[15]] = lIIlIIlllIllll("j+m+gIKy3dY/4AKqtxkjHQ==", "Mnetk");
    llIIIIIlIllI[llIIIIIlIlll[6]] = lIIlIIlllIlllI("Kh0YLCoLWB4jPxw=", "yxjZO");
    llIIIIIlIllI[llIIIIIlIlll[16]] = lIIlIIlllIllIl("5XPV9wOgscTX5w15yo9BvA==", "ACvCS");
    llIIIIIlIllI[llIIIIIlIlll[17]] = lIIlIIlllIllll("I2wQ/eTnlho=", "buQci");
    llIIIIIlIllI[llIIIIIlIlll[18]] = lIIlIIlllIllll("QuAHyspIR7BZ6GORizop/Q==", "qRXRJ");
    llIIIIIlIllI[llIIIIIlIlll[19]] = lIIlIIlllIllIl("wcXZUUgo4ts=", "PvlAZ");
    llIIIIIlIllI[llIIIIIlIlll[10]] = lIIlIIlllIllIl("fTC/RQC4GHoyjl4ki5Fq5w==", "uVuZz");
  }
  
  private static boolean lIIlIIlllllIlI(int ???)
  {
    double lllllllllllllllIIlIIIlIllIIlllIl;
    return ??? > 0;
  }
  
  public boolean spawnEntityInWorld(Entity lllllllllllllllIIlIIIllIllIlIlll)
  {
    ;
    ;
    ;
    boolean lllllllllllllllIIlIIIllIllIllIIl = lllllllllllllllIIlIIIllIllIllIll.spawnEntityInWorld(lllllllllllllllIIlIIIllIllIlIlll);
    "".length();
    if (lIIlIIllllIIll(lllllllllllllllIIlIIIllIllIllIIl))
    {
      "".length();
      "".length();
      if (-"  ".length() > 0) {
        return (0x22 ^ 0x36) & (0x7B ^ 0x6F ^ 0xFFFFFFFF);
      }
    }
    else if (lIIlIIllllIIlI(lllllllllllllllIIlIIIllIllIlIlll instanceof EntityMinecart))
    {
      mc.getSoundHandler().playSound(new MovingSoundMinecart((EntityMinecart)lllllllllllllllIIlIIIllIllIlIlll));
    }
    return lllllllllllllllIIlIIIllIllIllIIl;
  }
  
  private static boolean lIIlIIllllIlII(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIIlIIIlIllIlIlIll;
    return ??? < i;
  }
  
  protected int getRenderDistanceChunks()
  {
    ;
    return mc.gameSettings.renderDistanceChunks;
  }
  
  public CrashReportCategory addWorldInfoToCrashReport(CrashReport lllllllllllllllIIlIIIllIIlIIIlll)
  {
    ;
    ;
    ;
    CrashReportCategory lllllllllllllllIIlIIIllIIlIIlIIl = lllllllllllllllIIlIIIllIIlIIlIII.addWorldInfoToCrashReport(lllllllllllllllIIlIIIllIIlIIIlll);
    lllllllllllllllIIlIIIllIIlIIlIIl.addCrashSectionCallable(llIIIIIlIllI[llIIIIIlIlll[14]], new Callable()
    {
      public String call()
      {
        ;
        return String.valueOf(new StringBuilder(String.valueOf(entityList.size())).append(lllIIllI[lllIIlll[0]]).append(entityList.toString()));
      }
      
      private static String lIlllIIlII(String lIlIIlllIIllIIl, String lIlIIlllIIlIllI)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lIlIIlllIIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIlIIlllIIlIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher lIlIIlllIIllIll = Cipher.getInstance("Blowfish");
          lIlIIlllIIllIll.init(lllIIlll[2], lIlIIlllIIlllII);
          return new String(lIlIIlllIIllIll.doFinal(Base64.getDecoder().decode(lIlIIlllIIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lIlIIlllIIllIlI)
        {
          lIlIIlllIIllIlI.printStackTrace();
        }
        return null;
      }
      
      static
      {
        lIlllIIlll();
        lIlllIIllI();
      }
      
      private static void lIlllIIlll()
      {
        lllIIlll = new int[3];
        lllIIlll[0] = ((0xB9 ^ 0xA5) & (0x46 ^ 0x5A ^ 0xFFFFFFFF));
        lllIIlll[1] = " ".length();
        lllIIlll[2] = "  ".length();
      }
      
      private static boolean lIlllIlIII(int ???, int arg1)
      {
        int i;
        Exception lIlIIlllIIlIIII;
        return ??? < i;
      }
      
      private static String lIlllIIlIl(String lIlIIlllIlIlllI, String lIlIIlllIlIllIl)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        lIlIIlllIlIlllI = new String(Base64.getDecoder().decode(lIlIIlllIlIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder lIlIIlllIlIllII = new StringBuilder();
        char[] lIlIIlllIlIlIll = lIlIIlllIlIllIl.toCharArray();
        int lIlIIlllIlIlIlI = lllIIlll[0];
        Exception lIlIIlllIlIIlII = lIlIIlllIlIlllI.toCharArray();
        Exception lIlIIlllIlIIIll = lIlIIlllIlIIlII.length;
        String lIlIIlllIlIIIlI = lllIIlll[0];
        while (lIlllIlIII(lIlIIlllIlIIIlI, lIlIIlllIlIIIll))
        {
          char lIlIIlllIlIllll = lIlIIlllIlIIlII[lIlIIlllIlIIIlI];
          "".length();
          "".length();
          if ((('' + 16 - 71 + 142 ^ '­' + '' - 311 + 187) & (0x31 ^ 0x75 ^ 0xF ^ 0x13 ^ -" ".length())) != 0) {
            return null;
          }
        }
        return String.valueOf(lIlIIlllIlIllII);
      }
      
      private static void lIlllIIllI()
      {
        lllIIllI = new String[lllIIlll[2]];
        lllIIllI[lllIIlll[0]] = lIlllIIlII("G4PJSdWaC7ZgX32yTKMGEA==", "Svgvt");
        lllIIllI[lllIIlll[1]] = lIlllIIlIl("GikTR0JpVXxPSmo=", "YeLwr");
      }
    });
    lllllllllllllllIIlIIIllIIlIIlIIl.addCrashSectionCallable(llIIIIIlIllI[llIIIIIlIlll[3]], new Callable()
    {
      private static void llIIlIllllIIl()
      {
        lIIIIlIIIIll = new String[lIIIIlIIIlIl[2]];
        lIIIIlIIIIll[lIIIIlIIIlIl[0]] = llIIlIllllIII("VAEZEyoYTlY=", "tuvgK");
        lIIIIlIIIIll[lIIIIlIIIlIl[1]] = llIIlIllllIII("DQ0UX3l+cXtXcXo=", "NAKoI");
      }
      
      private static boolean llIIlIlllllIl(int ???, int arg1)
      {
        int i;
        String lllllllllllllllIllllllIIllIlIlIl;
        return ??? < i;
      }
      
      public String call()
      {
        ;
        return String.valueOf(new StringBuilder(String.valueOf(entitySpawnQueue.size())).append(lIIIIlIIIIll[lIIIIlIIIlIl[0]]).append(entitySpawnQueue.toString()));
      }
      
      private static String llIIlIllllIII(String lllllllllllllllIllllllIIlllIIllI, String lllllllllllllllIllllllIIlllIIIII)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        lllllllllllllllIllllllIIlllIIllI = new String(Base64.getDecoder().decode(lllllllllllllllIllllllIIlllIIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder lllllllllllllllIllllllIIlllIIlII = new StringBuilder();
        char[] lllllllllllllllIllllllIIlllIIIll = lllllllllllllllIllllllIIlllIIIII.toCharArray();
        int lllllllllllllllIllllllIIlllIIIlI = lIIIIlIIIlIl[0];
        int lllllllllllllllIllllllIIllIlllII = lllllllllllllllIllllllIIlllIIllI.toCharArray();
        byte lllllllllllllllIllllllIIllIllIll = lllllllllllllllIllllllIIllIlllII.length;
        float lllllllllllllllIllllllIIllIllIlI = lIIIIlIIIlIl[0];
        while (llIIlIlllllIl(lllllllllllllllIllllllIIllIllIlI, lllllllllllllllIllllllIIllIllIll))
        {
          char lllllllllllllllIllllllIIlllIIlll = lllllllllllllllIllllllIIllIlllII[lllllllllllllllIllllllIIllIllIlI];
          "".length();
          "".length();
          if ("   ".length() == 0) {
            return null;
          }
        }
        return String.valueOf(lllllllllllllllIllllllIIlllIIlII);
      }
      
      private static void llIIlIlllllII()
      {
        lIIIIlIIIlIl = new int[3];
        lIIIIlIIIlIl[0] = ((0xA4 ^ 0xB0 ^ 0xB6 ^ 0xB1) & (0xE ^ 0x77 ^ 0x50 ^ 0x3A ^ -" ".length()));
        lIIIIlIIIlIl[1] = " ".length();
        lIIIIlIIIlIl[2] = "  ".length();
      }
      
      static
      {
        llIIlIlllllII();
        llIIlIllllIIl();
      }
    });
    lllllllllllllllIIlIIIllIIlIIlIIl.addCrashSectionCallable(llIIIIIlIllI[llIIIIIlIlll[15]], new Callable()
    {
      private static void lIIIIlIIlllII()
      {
        lIlIlIllllI = new String[lIlIlIlllll[1]];
        lIlIlIllllI[lIlIlIlllll[0]] = lIIIIlIIllIlI("OFxH13vtda6cnGYODKH8ZA==", "hVEPx");
      }
      
      static
      {
        lIIIIlIIlllIl();
        lIIIIlIIlllII();
      }
      
      public String call()
        throws Exception
      {
        ;
        return mc.thePlayer.getClientBrand();
      }
      
      private static String lIIIIlIIllIlI(String lllllllllllllllllIIIIlIIllllIlII, String lllllllllllllllllIIIIlIIllllIlIl)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllllllllllllllllIIIIlIIlllllIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIIlIIllllIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher lllllllllllllllllIIIIlIIlllllIII = Cipher.getInstance("Blowfish");
          lllllllllllllllllIIIIlIIlllllIII.init(lIlIlIlllll[2], lllllllllllllllllIIIIlIIlllllIIl);
          return new String(lllllllllllllllllIIIIlIIlllllIII.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIIlIIllllIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllllllllllllllllIIIIlIIllllIlll)
        {
          lllllllllllllllllIIIIlIIllllIlll.printStackTrace();
        }
        return null;
      }
      
      private static void lIIIIlIIlllIl()
      {
        lIlIlIlllll = new int[3];
        lIlIlIlllll[0] = ((0x11 ^ 0x5) & (0xA1 ^ 0xB5 ^ 0xFFFFFFFF));
        lIlIlIlllll[1] = " ".length();
        lIlIlIlllll[2] = "  ".length();
      }
    });
    lllllllllllllllIIlIIIllIIlIIlIIl.addCrashSectionCallable(llIIIIIlIllI[llIIIIIlIlll[6]], new Callable()
    {
      private static boolean llIIIlIIlIIII(int ???, int arg1)
      {
        int i;
        char llllllllllllllllIIIIlIllIIllIllI;
        return ??? < i;
      }
      
      static
      {
        llIIIlIIIlllI();
        llIIIIIIIllll();
      }
      
      private static String llIIIIIIIllIl(String llllllllllllllllIIIIlIllIlIIllll, String llllllllllllllllIIIIlIllIlIIlllI)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        llllllllllllllllIIIIlIllIlIIllll = new String(Base64.getDecoder().decode(llllllllllllllllIIIIlIllIlIIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder llllllllllllllllIIIIlIllIlIlIIlI = new StringBuilder();
        char[] llllllllllllllllIIIIlIllIlIlIIIl = llllllllllllllllIIIIlIllIlIIlllI.toCharArray();
        int llllllllllllllllIIIIlIllIlIlIIII = llllllIllII[0];
        long llllllllllllllllIIIIlIllIlIIlIlI = llllllllllllllllIIIIlIllIlIIllll.toCharArray();
        short llllllllllllllllIIIIlIllIlIIlIIl = llllllllllllllllIIIIlIllIlIIlIlI.length;
        int llllllllllllllllIIIIlIllIlIIlIII = llllllIllII[0];
        while (llIIIlIIlIIII(llllllllllllllllIIIIlIllIlIIlIII, llllllllllllllllIIIIlIllIlIIlIIl))
        {
          char llllllllllllllllIIIIlIllIlIlIlIl = llllllllllllllllIIIIlIllIlIIlIlI[llllllllllllllllIIIIlIllIlIIlIII];
          "".length();
          "".length();
          if (null != null) {
            return null;
          }
        }
        return String.valueOf(llllllllllllllllIIIIlIllIlIlIIlI);
      }
      
      private static boolean llIIIlIIIllll(Object ???)
      {
        short llllllllllllllllIIIIlIllIIllIlII;
        return ??? == null;
      }
      
      private static void llIIIlIIIlllI()
      {
        llllllIllII = new int[4];
        llllllIllII[0] = ((0x41 ^ 0x69 ^ 0x25 ^ 0x30) & (0x17 ^ 0x79 ^ 0x3 ^ 0x50 ^ -" ".length()));
        llllllIllII[1] = " ".length();
        llllllIllII[2] = "  ".length();
        llllllIllII[3] = "   ".length();
      }
      
      private static void llIIIIIIIllll()
      {
        lllllIlIlIl = new String[llllllIllII[3]];
        lllllIlIlIl[llllllIllII[0]] = llIIIIIIIllIl("Pz4tdAEfJSY+GhAlJj1IHCQvLQEBPSIgDQNxMDwaBzQx", "qQCYh");
        lllllIlIlIl[llllllIllII[1]] = llIIIIIIIlllI("kh6bRFdwXTvaQGQrxWdQQBYdgPjy7R5ZA6uAARNfVoE=", "PiFdO");
        lllllIlIlIl[llllllIllII[2]] = llIIIIIIIlllI("TlRJutFt7RnsZwnJ1SCM3w==", "PkslB");
      }
      
      private static String llIIIIIIIlllI(String llllllllllllllllIIIIlIllIIllllll, String llllllllllllllllIIIIlIllIIlllllI)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllllIIIIlIllIlIIIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIIIlIllIIlllllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher llllllllllllllllIIIIlIllIlIIIIIl = Cipher.getInstance("Blowfish");
          llllllllllllllllIIIIlIllIlIIIIIl.init(llllllIllII[2], llllllllllllllllIIIIlIllIlIIIIlI);
          return new String(llllllllllllllllIIIIlIllIlIIIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllllIIIIlIllIIllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllllIIIIlIllIlIIIIII)
        {
          llllllllllllllllIIIIlIllIlIIIIII.printStackTrace();
        }
        return null;
      }
      
      public String call()
        throws Exception
      {
        ;
        if (llIIIlIIIllll(mc.getIntegratedServer()))
        {
          "".length();
          if ("   ".length() != -" ".length()) {
            break label56;
          }
          return null;
        }
        label56:
        return lllllIlIlIl[llllllIllII[1]];
      }
    });
    return lllllllllllllllIIlIIIllIIlIIlIIl;
  }
  
  public void removeEntity(Entity lllllllllllllllIIlIIIllIllIlIIII)
  {
    ;
    ;
    lllllllllllllllIIlIIIllIllIlIIIl.removeEntity(lllllllllllllllIIlIIIllIllIlIIII);
    "".length();
  }
  
  public WorldClient(NetHandlerPlayClient lllllllllllllllIIlIIIlllIIIlllII, WorldSettings lllllllllllllllIIlIIIlllIIIllIll, int lllllllllllllllIIlIIIlllIIIlIlII, EnumDifficulty lllllllllllllllIIlIIIlllIIIlIIll, Profiler lllllllllllllllIIlIIIlllIIIllIII)
  {
    lllllllllllllllIIlIIIlllIIIlIlll.<init>(new SaveHandlerMP(), new WorldInfo(lllllllllllllllIIlIIIlllIIIllIll, llIIIIIlIllI[llIIIIIlIlll[0]]), WorldProvider.getProviderForDimension(lllllllllllllllIIlIIIlllIIIlIlII), lllllllllllllllIIlIIIlllIIIllIII, llIIIIIlIlll[1]);
    sendQueue = lllllllllllllllIIlIIIlllIIIlllII;
    lllllllllllllllIIlIIIlllIIIlIlll.getWorldInfo().setDifficulty(lllllllllllllllIIlIIIlllIIIlIIll);
    provider.registerWorld(lllllllllllllllIIlIIIlllIIIlIlll);
    lllllllllllllllIIlIIIlllIIIlIlll.setSpawnPoint(new BlockPos(llIIIIIlIlll[3], llIIIIIlIlll[4], llIIIIIlIlll[3]));
    chunkProvider = lllllllllllllllIIlIIIlllIIIlIlll.createChunkProvider();
    mapStorage = new SaveDataMemoryStorage();
    lllllllllllllllIIlIIIlllIIIlIlll.calculateInitialSkylight();
    lllllllllllllllIIlIIIlllIIIlIlll.calculateInitialWeather();
  }
  
  public void setWorldScoreboard(Scoreboard lllllllllllllllIIlIIIlIlllllIlll)
  {
    ;
    ;
    worldScoreboard = lllllllllllllllIIlIIIlIlllllIlll;
  }
  
  public void makeFireworks(double lllllllllllllllIIlIIIllIIIIIIIIl, double lllllllllllllllIIlIIIllIIIIIIIII, double lllllllllllllllIIlIIIllIIIIIIlll, double lllllllllllllllIIlIIIlIllllllllI, double lllllllllllllllIIlIIIllIIIIIIlIl, double lllllllllllllllIIlIIIllIIIIIIlII, NBTTagCompound lllllllllllllllIIlIIIllIIIIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    mc.effectRenderer.addEffect(new EntityFirework.StarterFX(lllllllllllllllIIlIIIllIIIIIlIlI, lllllllllllllllIIlIIIllIIIIIIIIl, lllllllllllllllIIlIIIllIIIIIIIII, lllllllllllllllIIlIIIllIIIIIIlll, lllllllllllllllIIlIIIlIllllllllI, lllllllllllllllIIlIIIllIIIIIIlIl, lllllllllllllllIIlIIIllIIIIIIlII, mc.effectRenderer, lllllllllllllllIIlIIIllIIIIIIIll));
  }
  
  public Entity removeEntityFromWorld(int lllllllllllllllIIlIIIllIlIlIIlll)
  {
    ;
    ;
    ;
    Entity lllllllllllllllIIlIIIllIlIlIlIIl = (Entity)entitiesById.removeObject(lllllllllllllllIIlIIIllIlIlIIlll);
    if (lIIlIIllllIlll(lllllllllllllllIIlIIIllIlIlIlIIl))
    {
      "".length();
      lllllllllllllllIIlIIIllIlIlIlIll.removeEntity(lllllllllllllllIIlIIIllIlIlIlIIl);
    }
    return lllllllllllllllIIlIIIllIlIlIlIIl;
  }
  
  public boolean invalidateRegionAndSetBlock(BlockPos lllllllllllllllIIlIIIllIlIIllllI, IBlockState lllllllllllllllIIlIIIllIlIIlIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIIlIIIllIlIIlllII = lllllllllllllllIIlIIIllIlIIllllI.getX();
    int lllllllllllllllIIlIIIllIlIIllIll = lllllllllllllllIIlIIIllIlIIllIII.getY();
    int lllllllllllllllIIlIIIllIlIIllIlI = lllllllllllllllIIlIIIllIlIIllIII.getZ();
    lllllllllllllllIIlIIIllIlIIllIIl.invalidateBlockReceiveRegion(lllllllllllllllIIlIIIllIlIIlllII, lllllllllllllllIIlIIIllIlIIllIll, lllllllllllllllIIlIIIllIlIIllIlI, lllllllllllllllIIlIIIllIlIIlllII, lllllllllllllllIIlIIIllIlIIllIll, lllllllllllllllIIlIIIllIlIIllIlI);
    return lllllllllllllllIIlIIIllIlIIllIIl.setBlockState(lllllllllllllllIIlIIIllIlIIllIII, lllllllllllllllIIlIIIllIlIIlIlll, llIIIIIlIlll[2]);
  }
  
  private static boolean lIIlIIlllllIII(Object ???, Object arg1)
  {
    Object localObject;
    char lllllllllllllllIIlIIIlIllIlIIlIl;
    return ??? == localObject;
  }
  
  public Entity getEntityByID(int lllllllllllllllIIlIIIllIlIlIllll)
  {
    ;
    ;
    if (lIIlIIllllIlIl(lllllllllllllllIIlIIIllIlIlIllll, mc.thePlayer.getEntityId()))
    {
      "".length();
      if ("  ".length() < ('' + 51 - 52 + 57 ^ 74 + '' - 21 + 9)) {
        break label70;
      }
      return null;
    }
    label70:
    return lllllllllllllllIIlIIIllIlIllIIlI.getEntityByID(lllllllllllllllIIlIIIllIlIlIllll);
  }
  
  private static String lIIlIIlllIlllI(String lllllllllllllllIIlIIIlIlllIIIlII, String lllllllllllllllIIlIIIlIlllIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIIlIlllIIIlII = new String(Base64.getDecoder().decode(lllllllllllllllIIlIIIlIlllIIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlIIIlIlllIIIIlI = new StringBuilder();
    char[] lllllllllllllllIIlIIIlIlllIIIIIl = lllllllllllllllIIlIIIlIlllIIIIll.toCharArray();
    int lllllllllllllllIIlIIIlIlllIIIIII = llIIIIIlIlll[0];
    float lllllllllllllllIIlIIIlIllIlllIlI = lllllllllllllllIIlIIIlIlllIIIlII.toCharArray();
    long lllllllllllllllIIlIIIlIllIlllIIl = lllllllllllllllIIlIIIlIllIlllIlI.length;
    float lllllllllllllllIIlIIIlIllIlllIII = llIIIIIlIlll[0];
    while (lIIlIIllllIlII(lllllllllllllllIIlIIIlIllIlllIII, lllllllllllllllIIlIIIlIllIlllIIl))
    {
      char lllllllllllllllIIlIIIlIlllIIIlIl = lllllllllllllllIIlIIIlIllIlllIlI[lllllllllllllllIIlIIIlIllIlllIII];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlIIIlIlllIIIIlI);
  }
  
  public void playSoundAtPos(BlockPos lllllllllllllllIIlIIIllIIIlllllI, String lllllllllllllllIIlIIIllIIIllllIl, float lllllllllllllllIIlIIIllIIIllllII, float lllllllllllllllIIlIIIllIIIllIlIl, boolean lllllllllllllllIIlIIIllIIIllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIIllIIIllllll.playSound(lllllllllllllllIIlIIIllIIIlllllI.getX() + 0.5D, lllllllllllllllIIlIIIllIIIlllllI.getY() + 0.5D, lllllllllllllllIIlIIIllIIIlllllI.getZ() + 0.5D, lllllllllllllllIIlIIIllIIIllllIl, lllllllllllllllIIlIIIllIIIllllII, lllllllllllllllIIlIIIllIIIllIlIl, lllllllllllllllIIlIIIllIIIllIlII);
  }
  
  public void setWorldTime(long lllllllllllllllIIlIIIlIlllllIIIl)
  {
    ;
    ;
    if (lIIlIIllllllII(lIIlIIlllllIll(lllllllllllllllIIlIIIlIlllllIIIl, 0L)))
    {
      lllllllllllllllIIlIIIlIlllllIIIl = -lllllllllllllllIIlIIIlIlllllIIIl;
      lllllllllllllllIIlIIIlIlllllIIII.getGameRules().setOrCreateGameRule(llIIIIIlIllI[llIIIIIlIlll[16]], llIIIIIlIllI[llIIIIIlIlll[17]]);
      "".length();
      if (-" ".length() != (105 + '' - 166 + 81 ^ '¨' + '«' - 323 + 157)) {}
    }
    else
    {
      lllllllllllllllIIlIIIlIlllllIIII.getGameRules().setOrCreateGameRule(llIIIIIlIllI[llIIIIIlIlll[18]], llIIIIIlIllI[llIIIIIlIlll[19]]);
    }
    lllllllllllllllIIlIIIlIlllllIIII.setWorldTime(lllllllllllllllIIlIIIlIlllllIIIl);
  }
  
  static
  {
    lIIlIIllllIIIl();
    lIIlIIllllIIII();
  }
  
  public void addEntityToWorld(int lllllllllllllllIIlIIIllIlIllIlll, Entity lllllllllllllllIIlIIIllIlIlllIlI)
  {
    ;
    ;
    ;
    ;
    Entity lllllllllllllllIIlIIIllIlIlllIIl = lllllllllllllllIIlIIIllIlIllllII.getEntityByID(lllllllllllllllIIlIIIllIlIlllIll);
    if (lIIlIIllllIlll(lllllllllllllllIIlIIIllIlIlllIIl)) {
      lllllllllllllllIIlIIIllIlIllllII.removeEntity(lllllllllllllllIIlIIIllIlIlllIIl);
    }
    "".length();
    lllllllllllllllIIlIIIllIlIlllIlI.setEntityId(lllllllllllllllIIlIIIllIlIlllIll);
    if (lIIlIIllllIIll(lllllllllllllllIIlIIIllIlIllllII.spawnEntityInWorld(lllllllllllllllIIlIIIllIlIlllIlI))) {
      "".length();
    }
    entitiesById.addKey(lllllllllllllllIIlIIIllIlIlllIll, lllllllllllllllIIlIIIllIlIlllIlI);
  }
  
  protected IChunkProvider createChunkProvider()
  {
    ;
    clientChunkProvider = new ChunkProviderClient(lllllllllllllllIIlIIIllIllllllll);
    return clientChunkProvider;
  }
  
  protected void onEntityRemoved(Entity lllllllllllllllIIlIIIllIllIIIIlI)
  {
    ;
    ;
    ;
    lllllllllllllllIIlIIIllIllIIIllI.onEntityRemoved(lllllllllllllllIIlIIIllIllIIIIlI);
    boolean lllllllllllllllIIlIIIllIllIIIlII = llIIIIIlIlll[0];
    if (lIIlIIllllIIlI(entityList.contains(lllllllllllllllIIlIIIllIllIIIIlI))) {
      if (lIIlIIllllIIlI(lllllllllllllllIIlIIIllIllIIIIlI.isEntityAlive()))
      {
        "".length();
        lllllllllllllllIIlIIIllIllIIIlII = llIIIIIlIlll[1];
        "".length();
        if (null == null) {}
      }
      else
      {
        "".length();
      }
    }
  }
  
  private static boolean lIIlIIllllllII(int ???)
  {
    String lllllllllllllllIIlIIIlIllIIlllll;
    return ??? < 0;
  }
  
  private static void lIIlIIllllIIIl()
  {
    llIIIIIlIlll = new int[20];
    llIIIIIlIlll[0] = ((0x72 ^ 0x1 ^ 0x33 ^ 0x7B) & (0x2A ^ 0x30 ^ 0x5 ^ 0x24 ^ -" ".length()));
    llIIIIIlIlll[1] = " ".length();
    llIIIIIlIlll[2] = "   ".length();
    llIIIIIlIlll[3] = (0x9E ^ 0x96);
    llIIIIIlIlll[4] = (0x48 ^ 0x7C ^ 0x6B ^ 0x1F);
    llIIIIIlIlll[5] = "  ".length();
    llIIIIIlIlll[6] = (0x5E ^ 0x41 ^ 0x32 ^ 0x27);
    llIIIIIlIlll[7] = (0x72 ^ 0x76);
    llIIIIIlIlll[8] = (0x74 ^ 0x64);
    llIIIIIlIlll[9] = (0x69 ^ 0x7E ^ 0x73 ^ 0x61);
    llIIIIIlIlll[10] = (0x73 ^ 0x7C);
    llIIIIIlIlll[11] = (-(0xF6F1 & 0x3B7E) & 0xBB6F & 0x77FF);
    llIIIIIlIlll[12] = (0x14 ^ 0x12);
    llIIIIIlIlll[13] = (0xB7E9 & 0x4BFE);
    llIIIIIlIlll[14] = (0xD ^ 0x54 ^ 0xEA ^ 0xB4);
    llIIIIIlIlll[15] = (0xF9 ^ 0xAD ^ 0xE7 ^ 0xBA);
    llIIIIIlIlll[16] = (0x50 ^ 0x64 ^ 0x89 ^ 0xB6);
    llIIIIIlIlll[17] = (0x12 ^ 0x1E);
    llIIIIIlIlll[18] = (0x84 ^ 0x89);
    llIIIIIlIlll[19] = (0x93 ^ 0x9D);
  }
  
  private static String lIIlIIlllIllIl(String lllllllllllllllIIlIIIlIlllIlIIlI, String lllllllllllllllIIlIIIlIlllIlIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlIIIlIlllIlIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlIIIlIlllIlIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIlIIIlIlllIlIllI = Cipher.getInstance("Blowfish");
      lllllllllllllllIIlIIIlIlllIlIllI.init(llIIIIIlIlll[5], lllllllllllllllIIlIIIlIlllIlIlll);
      return new String(lllllllllllllllIIlIIIlIlllIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlIIIlIlllIlIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlIIIlIlllIlIlIl)
    {
      lllllllllllllllIIlIIIlIlllIlIlIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIlIIllllIlIl(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIIlIIIlIllIllIIll;
    return ??? == i;
  }
  
  private static int lIIlIIlllllIIl(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
}

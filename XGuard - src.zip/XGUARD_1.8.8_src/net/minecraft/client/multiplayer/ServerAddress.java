package net.minecraft.client.multiplayer;

import java.net.IDN;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Hashtable;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

public class ServerAddress
{
  private static String[] getServerAddress(String lllllllllllllllIlIlIlIllllllIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      ;
      ;
      String lllllllllllllllIlIlIlIllllllIllI = lIIllllIllII[lIIlllllIlII[5]];
      "".length();
      Hashtable lllllllllllllllIlIlIlIllllllIlIl = new Hashtable();
      "".length();
      "".length();
      "".length();
      DirContext lllllllllllllllIlIlIlIllllllIlII = new InitialDirContext(lllllllllllllllIlIlIlIllllllIlIl);
      Attributes lllllllllllllllIlIlIlIllllllIIll = lllllllllllllllIlIlIlIllllllIlII.getAttributes(String.valueOf(new StringBuilder(lIIllllIllII[lIIlllllIlII[13]]).append(lllllllllllllllIlIlIlIllllllIIII)), new String[] { lIIllllIllII[lIIlllllIlII[14]] });
      String[] lllllllllllllllIlIlIlIllllllIIlI = lllllllllllllllIlIlIlIllllllIIll.get(lIIllllIllII[lIIlllllIlII[15]]).get().toString().split(lIIllllIllII[lIIlllllIlII[16]], lIIlllllIlII[5]);
      return new String[] { lllllllllllllllIlIlIlIllllllIIlI[lIIlllllIlII[3]], lllllllllllllllIlIlIlIllllllIIlI[lIIlllllIlII[2]] };
    }
    catch (Throwable lllllllllllllllIlIlIlIllllllIIIl) {}
    return tmp294_286;
  }
  
  private static boolean llllIlIllIIlI(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIlIlIlIlllIlIIlII;
    return ??? > i;
  }
  
  private static boolean llllIlIllIIll(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIlIlIlIlllIlIllII;
    return ??? == i;
  }
  
  private static int parseIntWithDefault(String lllllllllllllllIlIlIlIlllllIIlll, int lllllllllllllllIlIlIlIlllllIIllI)
  {
    ;
    try
    {
      ;
      ;
      return Integer.parseInt(lllllllllllllllIlIlIlIlllllIIlll.trim());
    }
    catch (Exception lllllllllllllllIlIlIlIlllllIIlIl) {}
    return lllllllllllllllIlIlIlIlllllIIllI;
  }
  
  static
  {
    llllIlIlIlllI();
    llllIlIlIIIII();
  }
  
  private static boolean llllIlIllIlII(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIlIlIlIlllIlIlIII;
    return ??? < i;
  }
  
  private static void llllIlIlIIIII()
  {
    lIIllllIllII = new String[lIIlllllIlII[17]];
    lIIllllIllII[lIIlllllIlII[0]] = llllIlIIlIlIl("SnUTVLaNkc4=", "NbmoZ");
    lIIllllIllII[lIIlllllIlII[1]] = llllIlIIlIlIl("Vl4WfF0IK2Q=", "IkhDZ");
    lIIllllIllII[lIIlllllIlII[2]] = llllIlIIlIllI("sTG0BPQlMP4=", "jfjUC");
    lIIllllIllII[lIIlllllIlII[3]] = llllIlIIlIlll("TA==", "vzVQZ");
    lIIllllIllII[lIIlllllIlII[5]] = llllIlIIlIllI("2v+fLpxn2KhBqYs2/HSoUfju5SQ2nyEzJp+XIVu+P3rnRaNPp6hcUw==", "jhRIM");
    lIIllllIllII[lIIlllllIlII[6]] = llllIlIIlIlll("CgInSx0cA2QPAA0EZAEAGkMOCx0qAiQRCxEZDAQNHQI4HA==", "imJen");
    lIIllllIllII[lIIlllllIlII[7]] = llllIlIIlIllI("v9xLwhKtz1UjV4kenBcGDiQg3+jDtcoPJmvxZmyuoH4=", "hSOuY");
    lIIllllIllII[lIIlllllIlII[8]] = llllIlIIlIlll("MC41YBkmL3YkBDcodioEIG8cIBkQLjY6Dys1Hi8JJy4qNw==", "SAXNj");
    lIIllllIllII[lIIlllllIlII[9]] = llllIlIIlIlll("LwM+C38rAyUDPyJMOBg+MwssDyNrFzoG", "EbHjQ");
    lIIllllIllII[lIIlllllIlII[10]] = llllIlIIlIllI("qF7TEmG5zAg=", "zsjqD");
    lIIllllIllII[lIIlllllIlII[11]] = llllIlIIlIllI("UPJ+n3bg/mx8GNYrAMr7ShGR866KDYKf9Y994y7Kx5alK1VJ2ffYAQ==", "CxGsV");
    lIIllllIllII[lIIlllllIlII[12]] = llllIlIIlIllI("po8R9htqmE8=", "mKyKG");
    lIIllllIllII[lIIlllllIlII[13]] = llllIlIIlIllI("CC7yNk+jV8hJzmWaelu3TYaPvVsSSx5l", "omqty");
    lIIllllIllII[lIIlllllIlII[14]] = llllIlIIlIlIl("AYB3nbBOvhQ=", "wrOiF");
    lIIllllIllII[lIIlllllIlII[15]] = llllIlIIlIlll("KTAj", "ZBUCF");
    lIIllllIllII[lIIlllllIlII[16]] = llllIlIIlIlIl("CGXow90btyI=", "xoIFd");
  }
  
  private static String llllIlIIlIllI(String lllllllllllllllIlIlIlIllllIllIlI, String lllllllllllllllIlIlIlIllllIllIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIlIllllIlllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIlIllllIllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlIlIlIllllIlllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIlIlIlIllllIlllII.init(lIIlllllIlII[2], lllllllllllllllIlIlIlIllllIlllIl);
      return new String(lllllllllllllllIlIlIlIllllIlllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIlIllllIllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIlIllllIllIll)
    {
      lllllllllllllllIlIlIlIllllIllIll.printStackTrace();
    }
    return null;
  }
  
  private static String llllIlIIlIlll(String lllllllllllllllIlIlIlIllllIIlIlI, String lllllllllllllllIlIlIlIllllIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlIlIllllIIlIlI = new String(Base64.getDecoder().decode(lllllllllllllllIlIlIlIllllIIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlIlIlIllllIIlIII = new StringBuilder();
    char[] lllllllllllllllIlIlIlIllllIIIlll = lllllllllllllllIlIlIlIllllIIlIIl.toCharArray();
    int lllllllllllllllIlIlIlIllllIIIllI = lIIlllllIlII[0];
    String lllllllllllllllIlIlIlIllllIIIIII = lllllllllllllllIlIlIlIllllIIlIlI.toCharArray();
    Exception lllllllllllllllIlIlIlIlllIllllll = lllllllllllllllIlIlIlIllllIIIIII.length;
    double lllllllllllllllIlIlIlIlllIlllllI = lIIlllllIlII[0];
    while (llllIlIllIlII(lllllllllllllllIlIlIlIlllIlllllI, lllllllllllllllIlIlIlIlllIllllll))
    {
      char lllllllllllllllIlIlIlIllllIIlIll = lllllllllllllllIlIlIlIllllIIIIII[lllllllllllllllIlIlIlIlllIlllllI];
      "".length();
      "".length();
      if ("  ".length() > "   ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIlIlIlIllllIIlIII);
  }
  
  private static boolean llllIlIllIIIl(int ???)
  {
    String lllllllllllllllIlIlIlIlllIIllllI;
    return ??? > 0;
  }
  
  public int getPort()
  {
    ;
    return serverPort;
  }
  
  private ServerAddress(String lllllllllllllllIlIlIllIIIIIllIlI, int lllllllllllllllIlIlIllIIIIIlIllI)
  {
    ipAddress = lllllllllllllllIlIlIllIIIIIlIlll;
    serverPort = lllllllllllllllIlIlIllIIIIIlIllI;
  }
  
  public String getIP()
  {
    ;
    return IDN.toASCII(ipAddress);
  }
  
  private static String llllIlIIlIlIl(String lllllllllllllllIlIlIlIlllIllIlIl, String lllllllllllllllIlIlIlIlllIllIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIlIlIlllIlllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIlIlIlllIllIlII.getBytes(StandardCharsets.UTF_8)), lIIlllllIlII[9]), "DES");
      Cipher lllllllllllllllIlIlIlIlllIllIlll = Cipher.getInstance("DES");
      lllllllllllllllIlIlIlIlllIllIlll.init(lIIlllllIlII[2], lllllllllllllllIlIlIlIlllIlllIII);
      return new String(lllllllllllllllIlIlIlIlllIllIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIlIlIlllIllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIlIlIlllIllIllI)
    {
      lllllllllllllllIlIlIlIlllIllIllI.printStackTrace();
    }
    return null;
  }
  
  private static boolean llllIlIllIIII(int ???)
  {
    long lllllllllllllllIlIlIlIlllIlIIIII;
    return ??? != 0;
  }
  
  private static boolean llllIlIlIllll(Object ???)
  {
    float lllllllllllllllIlIlIlIlllIlIIIlI;
    return ??? == null;
  }
  
  public static ServerAddress func_78860_a(String lllllllllllllllIlIlIllIIIIIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    if (llllIlIlIllll(lllllllllllllllIlIlIllIIIIIIIIlI)) {
      return null;
    }
    String[] lllllllllllllllIlIlIllIIIIIIlIIl = lllllllllllllllIlIlIllIIIIIIlIlI.split(lIIllllIllII[lIIlllllIlII[0]]);
    if (llllIlIllIIII(lllllllllllllllIlIlIllIIIIIIlIlI.startsWith(lIIllllIllII[lIIlllllIlII[1]])))
    {
      int lllllllllllllllIlIlIllIIIIIIlIII = lllllllllllllllIlIlIllIIIIIIlIlI.indexOf(lIIllllIllII[lIIlllllIlII[2]]);
      if (llllIlIllIIIl(lllllllllllllllIlIlIllIIIIIIlIII))
      {
        String lllllllllllllllIlIlIllIIIIIIIlll = lllllllllllllllIlIlIllIIIIIIlIlI.substring(lIIlllllIlII[1], lllllllllllllllIlIlIllIIIIIIlIII);
        String lllllllllllllllIlIlIllIIIIIIIllI = lllllllllllllllIlIlIllIIIIIIlIlI.substring(lllllllllllllllIlIlIllIIIIIIlIII + lIIlllllIlII[1]).trim();
        if ((llllIlIllIIII(lllllllllllllllIlIlIllIIIIIIIllI.startsWith(lIIllllIllII[lIIlllllIlII[3]]))) && (llllIlIllIIIl(lllllllllllllllIlIlIllIIIIIIIllI.length())))
        {
          lllllllllllllllIlIlIllIIIIIIIllI = lllllllllllllllIlIlIllIIIIIIIllI.substring(lIIlllllIlII[1]);
          lllllllllllllllIlIlIllIIIIIIlIIl = new String[] { lllllllllllllllIlIlIllIIIIIIIlll, lllllllllllllllIlIlIllIIIIIIIllI };
          "".length();
          if (" ".length() <= 0) {
            return null;
          }
        }
        else
        {
          lllllllllllllllIlIlIllIIIIIIlIIl = new String[] { lllllllllllllllIlIlIllIIIIIIIlll };
        }
      }
    }
    if (llllIlIllIIlI(lllllllllllllllIlIlIllIIIIIIlIIl.length, lIIlllllIlII[2])) {
      lllllllllllllllIlIlIllIIIIIIlIIl = new String[] { lllllllllllllllIlIlIllIIIIIIlIlI };
    }
    String lllllllllllllllIlIlIllIIIIIIIlIl = lllllllllllllllIlIlIllIIIIIIlIIl[lIIlllllIlII[0]];
    if (llllIlIllIIlI(lllllllllllllllIlIlIllIIIIIIlIIl.length, lIIlllllIlII[1]))
    {
      "".length();
      if (-" ".length() < 0) {
        break label282;
      }
      return null;
    }
    label282:
    int lllllllllllllllIlIlIllIIIIIIIlII = lIIlllllIlII[4];
    if (llllIlIllIIll(lllllllllllllllIlIlIllIIIIIIIlII, lIIlllllIlII[4]))
    {
      String[] lllllllllllllllIlIlIllIIIIIIIIll = getServerAddress(lllllllllllllllIlIlIllIIIIIIIlIl);
      lllllllllllllllIlIlIllIIIIIIIlIl = lllllllllllllllIlIlIllIIIIIIIIll[lIIlllllIlII[0]];
      lllllllllllllllIlIlIllIIIIIIIlII = parseIntWithDefault(lllllllllllllllIlIlIllIIIIIIIIll[lIIlllllIlII[1]], lIIlllllIlII[4]);
    }
    return new ServerAddress(lllllllllllllllIlIlIllIIIIIIIlIl, lllllllllllllllIlIlIllIIIIIIIlII);
  }
  
  private static void llllIlIlIlllI()
  {
    lIIlllllIlII = new int[18];
    lIIlllllIlII[0] = ((0xFF ^ 0xC6 ^ 0xB0 ^ 0xBC) & (0x88 ^ 0xAE ^ 0x44 ^ 0x57 ^ -" ".length()));
    lIIlllllIlII[1] = " ".length();
    lIIlllllIlII[2] = "  ".length();
    lIIlllllIlII[3] = "   ".length();
    lIIlllllIlII[4] = (0xEBDF & 0x77FD);
    lIIlllllIlII[5] = (122 + 80 - 151 + 107 ^ 42 + 38 - -49 + 25);
    lIIlllllIlII[6] = (0x73 ^ 0x76);
    lIIlllllIlII[7] = (0x90 ^ 0x96);
    lIIlllllIlII[8] = (84 + 120 - 194 + 154 ^ 78 + 111 - 97 + 71);
    lIIlllllIlII[9] = (" ".length() ^ 0xA0 ^ 0xA9);
    lIIlllllIlII[10] = (0x43 ^ 0x4A);
    lIIlllllIlII[11] = (0x7C ^ 0x76);
    lIIlllllIlII[12] = (0x89 ^ 0x82);
    lIIlllllIlII[13] = (0x6D ^ 0x61);
    lIIlllllIlII[14] = (0x6A ^ 0x67);
    lIIlllllIlII[15] = (0x9D ^ 0xBC ^ 0x7F ^ 0x50);
    lIIlllllIlII[16] = (0x38 ^ 0x37);
    lIIlllllIlII[17] = (0x64 ^ 0x2 ^ 0xE8 ^ 0x9E);
  }
}

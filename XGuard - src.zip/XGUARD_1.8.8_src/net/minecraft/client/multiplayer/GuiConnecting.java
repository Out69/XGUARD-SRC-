package net.minecraft.client.multiplayer;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiDisconnected;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.network.NetHandlerLoginClient;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.login.client.C00PacketLoginStart;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.Session;
import org.apache.logging.log4j.Logger;

public class GuiConnecting
  extends GuiScreen
{
  private static boolean lIllIlllllll(Object ???)
  {
    int llllllllllllllllllIlIIIlllIlllll;
    return ??? == null;
  }
  
  private static boolean lIllIlllllIl(int ???)
  {
    float llllllllllllllllllIlIIIlllIlllIl;
    return ??? != 0;
  }
  
  private void connect(String llllllllllllllllllIlIIlIIlIIIIIl, final int llllllllllllllllllIlIIlIIlIIIIII)
  {
    ;
    ;
    ;
    logger.info(String.valueOf(new StringBuilder(lllIIlIllI[lllIIlllII[0]]).append(llllllllllllllllllIlIIlIIlIIIlII).append(lllIIlIllI[lllIIlllII[1]]).append(llllllllllllllllllIlIIlIIlIIIIII)));
    new Thread(String.valueOf(new StringBuilder(lllIIlIllI[lllIIlllII[2]]).append(CONNECTION_ID.incrementAndGet())))
    {
      private static String lIIIIIIIlIII(String lIIlIIIlIIII, String lIIlIIIIllll)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lIIlIIIlIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIIlIIIIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher lIIlIIIlIlII = Cipher.getInstance("Blowfish");
          lIIlIIIlIlII.init(lIIllllIIl[3], lIIlIIIlIlIl);
          return new String(lIIlIIIlIlII.doFinal(Base64.getDecoder().decode(lIIlIIIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lIIlIIIlIIll)
        {
          lIIlIIIlIIll.printStackTrace();
        }
        return null;
      }
      
      private static boolean lIIIIIIIllII(int ???)
      {
        byte lIIlIIIIIlIl;
        return ??? != 0;
      }
      
      private static boolean lIIIIIIIllIl(Object ???)
      {
        Exception lIIlIIIIIlll;
        return ??? != null;
      }
      
      private static void lIIIIIIIlIll()
      {
        lIIllllIIl = new int[11];
        lIIllllIIl[0] = (0xD ^ 0x22);
        lIIllllIIl[1] = ((0xF ^ 0x42) & (0x76 ^ 0x3B ^ 0xFFFFFFFF));
        lIIllllIIl[2] = " ".length();
        lIIllllIIl[3] = "  ".length();
        lIIllllIIl[4] = "   ".length();
        lIIllllIIl[5] = (0xB8 ^ 0xBC);
        lIIllllIIl[6] = (0x8C ^ 0x89);
        lIIllllIIl[7] = (0x1E ^ 0x77 ^ 0x66 ^ 0x9);
        lIIllllIIl[8] = (0xE3 ^ 0xB5 ^ 0xE9 ^ 0xB8);
        lIIllllIIl[9] = (0xF ^ 0x69 ^ 0x3B ^ 0x55);
        lIIllllIIl[10] = (0x5A ^ 0x53);
      }
      
      private static void lIIIIIIIlIlI()
      {
        lIIllllIII = new String[lIIllllIIl[10]];
        lIIllllIII[lIIllllIIl[1]] = lIIIIIIIIlll("KAEmIiYFSSduIQQAPSshH04nIWIYCyE4Jxk=", "knSNB");
        lIIllllIII[lIIllllIIl[2]] = lIIIIIIIIlll("Bgc5FAsGHHkcDwwEMh4=", "ehWzn");
        lIIllllIII[lIIllllIIl[3]] = lIIIIIIIlIII("9q+bLPBy/t/UkW284m51D/7E1KNuJWFHhnT5dEQhFcA=", "bWZDH");
        lIIllllIII[lIIllllIIl[4]] = lIIIIIIIIlll("Ggo5Jyo4CnIhKjwQ", "OdRIE");
        lIIllllIII[lIIllllIIl[5]] = lIIIIIIIIlll("LhwPFAwDVA5YCwIdFB0LGVMOF0geFggODR8=", "mszxh");
        lIIllllIII[lIIllllIIl[6]] = lIIIIIIIlIIl("jtdG8aPn+m4=", "vcscv");
        lIIllllIII[lIIllllIIl[7]] = lIIIIIIIlIII("P/8n7HppNzo=", "IwWEr");
        lIIllllIII[lIIllllIIl[8]] = lIIIIIIIIlll("MCINNzYwOU0/MjohBj0=", "SMcYS");
        lIIllllIII[lIIllllIIl[9]] = lIIIIIIIIlll("LhEHBx4kFhEHBWQfEQoUOBEXNhQrCxsK", "Jxtdq");
      }
      
      public void run()
      {
        ;
        ;
        ;
        ;
        ;
        InetAddress lIIlIlIIlIII = null;
        try
        {
          if (lIIIIIIIllII(cancel)) {
            return;
          }
          lIIlIlIIlIII = InetAddress.getByName(llllllllllllllllllIlIIlIIlIIIlII);
          networkManager = NetworkManager.func_181124_a(lIIlIlIIlIII, llllllllllllllllllIlIIlIIlIIIIII, mc.gameSettings.func_181148_f());
          networkManager.setNetHandler(new NetHandlerLoginClient(networkManager, mc, previousGuiScreen));
          networkManager.sendPacket(new C00Handshake(lIIllllIIl[0], llllllllllllllllllIlIIlIIlIIIlII, llllllllllllllllllIlIIlIIlIIIIII, EnumConnectionState.LOGIN));
          networkManager.sendPacket(new C00PacketLoginStart(mc.getSession().getProfile()));
          "".length();
          if (null != null) {}
        }
        catch (UnknownHostException lIIlIlIIIlll)
        {
          if (lIIIIIIIllII(cancel)) {
            return;
          }
          GuiConnecting.logger.error(lIIllllIII[lIIllllIIl[1]], lIIlIlIIIlll);
          mc.displayGuiScreen(new GuiDisconnected(previousGuiScreen, lIIllllIII[lIIllllIIl[2]], new ChatComponentTranslation(lIIllllIII[lIIllllIIl[3]], new Object[] { lIIllllIII[lIIllllIIl[4]] })));
          "".length();
          if (null != null) {}
        }
        catch (Exception lIIlIlIIIllI)
        {
          if (lIIIIIIIllII(cancel)) {
            return;
          }
          GuiConnecting.logger.error(lIIllllIII[lIIllllIIl[5]], lIIlIlIIIllI);
          String lIIlIlIIIlIl = lIIlIlIIIllI.toString();
          if (lIIIIIIIllIl(lIIlIlIIlIII))
          {
            String lIIlIlIIIlII = String.valueOf(new StringBuilder(String.valueOf(lIIlIlIIlIII.toString())).append(lIIllllIII[lIIllllIIl[6]]).append(llllllllllllllllllIlIIlIIlIIIIII));
            lIIlIlIIIlIl = lIIlIlIIIlIl.replaceAll(lIIlIlIIIlII, lIIllllIII[lIIllllIIl[7]]);
          }
          mc.displayGuiScreen(new GuiDisconnected(previousGuiScreen, lIIllllIII[lIIllllIIl[8]], new ChatComponentTranslation(lIIllllIII[lIIllllIIl[9]], new Object[] { lIIlIlIIIlIl })));
        }
      }
      
      private static String lIIIIIIIlIIl(String lIIlIIIlllIl, String lIIlIIIllllI)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lIIlIIlIIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIIlIIIllllI.getBytes(StandardCharsets.UTF_8)), lIIllllIIl[9]), "DES");
          Cipher lIIlIIlIIIIl = Cipher.getInstance("DES");
          lIIlIIlIIIIl.init(lIIllllIIl[3], lIIlIIlIIIlI);
          return new String(lIIlIIlIIIIl.doFinal(Base64.getDecoder().decode(lIIlIIIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lIIlIIlIIIII)
        {
          lIIlIIlIIIII.printStackTrace();
        }
        return null;
      }
      
      private static boolean lIIIIIIIlllI(int ???, int arg1)
      {
        int i;
        Exception lIIlIIIIlIIl;
        return ??? < i;
      }
      
      private static String lIIIIIIIIlll(String lIIlIIlIllll, String lIIlIIllIIll)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        lIIlIIlIllll = new String(Base64.getDecoder().decode(lIIlIIlIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder lIIlIIllIIlI = new StringBuilder();
        char[] lIIlIIllIIIl = lIIlIIllIIll.toCharArray();
        int lIIlIIllIIII = lIIllllIIl[1];
        char lIIlIIlIlIlI = lIIlIIlIllll.toCharArray();
        float lIIlIIlIlIIl = lIIlIIlIlIlI.length;
        int lIIlIIlIlIII = lIIllllIIl[1];
        while (lIIIIIIIlllI(lIIlIIlIlIII, lIIlIIlIlIIl))
        {
          char lIIlIIllIlIl = lIIlIIlIlIlI[lIIlIIlIlIII];
          "".length();
          "".length();
          if (((0x4A ^ 0x7F) & (0x84 ^ 0xB1 ^ 0xFFFFFFFF)) > ((0x20 ^ 0x1) & (0x2B ^ 0xA ^ 0xFFFFFFFF))) {
            return null;
          }
        }
        return String.valueOf(lIIlIIllIIlI);
      }
      
      static
      {
        lIIIIIIIlIll();
        lIIIIIIIlIlI();
      }
    }.start();
  }
  
  private static boolean lIllIlllllII(Object ???)
  {
    double llllllllllllllllllIlIIIllllIIIIl;
    return ??? != null;
  }
  
  static
  {
    lIllIllllIll();
    lIllIllIllIl();
    CONNECTION_ID = new AtomicInteger(lllIIlllII[0]);
  }
  
  private static boolean lIlllIIIIIII(int ???, int arg1)
  {
    int i;
    long llllllllllllllllllIlIIIllllIIIll;
    return ??? < i;
  }
  
  public void drawScreen(int llllllllllllllllllIlIIlIIIlIlIll, int llllllllllllllllllIlIIlIIIlIlIlI, float llllllllllllllllllIlIIlIIIlIIlIl)
  {
    ;
    ;
    ;
    ;
    llllllllllllllllllIlIIlIIIlIllII.drawDefaultBackground();
    if (lIllIlllllll(networkManager))
    {
      llllllllllllllllllIlIIlIIIlIllII.drawCenteredString(fontRendererObj, I18n.format(lllIIlIllI[lllIIlllII[8]], new Object[lllIIlllII[0]]), width / lllIIlllII[2], height / lllIIlllII[2] - lllIIlllII[9], lllIIlllII[10]);
      "".length();
      if (((59 + 49 - 79 + 154 ^ 82 + 38 - -1 + 50) & (96 + 77 - 96 + 58 ^ 91 + 59 - 109 + 114 ^ -" ".length())) <= 0) {}
    }
    else
    {
      llllllllllllllllllIlIIlIIIlIllII.drawCenteredString(fontRendererObj, I18n.format(lllIIlIllI[lllIIlllII[11]], new Object[lllIIlllII[0]]), width / lllIIlllII[2], height / lllIIlllII[2] - lllIIlllII[9], lllIIlllII[10]);
    }
    llllllllllllllllllIlIIlIIIlIllII.drawScreen(llllllllllllllllllIlIIlIIIlIlIll, llllllllllllllllllIlIIlIIIlIlIlI, llllllllllllllllllIlIIlIIIlIIlIl);
  }
  
  protected void keyTyped(char llllllllllllllllllIlIIlIIIlllIll, int llllllllllllllllllIlIIlIIIlllIlI)
    throws IOException
  {}
  
  private static String lIllIllIlIII(String llllllllllllllllllIlIIlIIIIlIIIl, String llllllllllllllllllIlIIlIIIIIlllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIlIIlIIIIlIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlIIlIIIIIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIlIIlIIIIlIIll = Cipher.getInstance("Blowfish");
      llllllllllllllllllIlIIlIIIIlIIll.init(lllIIlllII[2], llllllllllllllllllIlIIlIIIIlIlII);
      return new String(llllllllllllllllllIlIIlIIIIlIIll.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlIIlIIIIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIlIIlIIIIlIIlI)
    {
      llllllllllllllllllIlIIlIIIIlIIlI.printStackTrace();
    }
    return null;
  }
  
  public GuiConnecting(GuiScreen llllllllllllllllllIlIIlIIllIIIII, Minecraft llllllllllllllllllIlIIlIIlIllIlI, ServerData llllllllllllllllllIlIIlIIlIllIIl)
  {
    mc = llllllllllllllllllIlIIlIIlIllIlI;
    previousGuiScreen = llllllllllllllllllIlIIlIIllIIIII;
    ServerAddress llllllllllllllllllIlIIlIIlIlllIl = ServerAddress.func_78860_a(serverIP);
    llllllllllllllllllIlIIlIIlIllIlI.loadWorld(null);
    llllllllllllllllllIlIIlIIlIllIlI.setServerData(llllllllllllllllllIlIIlIIlIllIIl);
    llllllllllllllllllIlIIlIIllIIIIl.connect(llllllllllllllllllIlIIlIIlIlllIl.getIP(), llllllllllllllllllIlIIlIIlIlllIl.getPort());
  }
  
  private static String lIllIllIIllI(String llllllllllllllllllIlIIIllllIllII, String llllllllllllllllllIlIIIllllIlIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIlIIIllllIllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlIIIllllIlIIl.getBytes(StandardCharsets.UTF_8)), lllIIlllII[13]), "DES");
      Cipher llllllllllllllllllIlIIIllllIlllI = Cipher.getInstance("DES");
      llllllllllllllllllIlIIIllllIlllI.init(lllIIlllII[2], llllllllllllllllllIlIIIllllIllll);
      return new String(llllllllllllllllllIlIIIllllIlllI.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlIIIllllIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIlIIIllllIllIl)
    {
      llllllllllllllllllIlIIIllllIllIl.printStackTrace();
    }
    return null;
  }
  
  public void updateScreen()
  {
    ;
    if (lIllIlllllII(networkManager))
    {
      "".length();
      if (lIllIlllllIl(networkManager.isChannelOpen()))
      {
        networkManager.processReceivedPackets();
        "".length();
        if (" ".length() == " ".length()) {}
      }
      else
      {
        networkManager.checkDisconnected();
      }
    }
  }
  
  private static void lIllIllllIll()
  {
    lllIIlllII = new int[14];
    lllIIlllII[0] = (('¯' + 93 - 107 + 91 ^ 5 + 8 - -108 + 63) & (0xAD ^ 0xBE ^ 0x78 ^ 0x2F ^ -" ".length()));
    lllIIlllII[1] = " ".length();
    lllIIlllII[2] = "  ".length();
    lllIIlllII[3] = (0x41 ^ 0x25);
    lllIIlllII[4] = (0x7D ^ 0x79);
    lllIIlllII[5] = ('×' + '' - 320 + 185 ^ 90 + 87 - 69 + 58);
    lllIIlllII[6] = (11 + '½' - 198 + 189 ^ '' + 5 - 107 + 123);
    lllIIlllII[7] = "   ".length();
    lllIIlllII[8] = (0xC4 ^ 0xBD ^ 0x6F ^ 0x13);
    lllIIlllII[9] = (110 + 39 - 70 + 105 ^ 0 + 5 - -6 + 127);
    lllIIlllII[10] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lllIIlllII[11] = (0x84 ^ 0x82);
    lllIIlllII[12] = (0x9 ^ 0xE);
    lllIIlllII[13] = (120 + 56 - 145 + 126 ^ 126 + 23 - 73 + 73);
  }
  
  private static void lIllIllIllIl()
  {
    lllIIlIllI = new String[lllIIlllII[12]];
    lllIIlIllI[lllIIlllII[0]] = lIllIllIIllI("MkluoT659gz+Pll4H0a2rQ==", "LHMtW");
    lllIIlIllI[lllIIlllII[1]] = lIllIllIlIII("B+z8AmZn/DQ=", "HDMdH");
    lllIIlIllI[lllIIlllII[2]] = lIllIllIlIlI("KgooAA0LTxkZBhcKOQIHC095", "yoZvh");
    lllIIlIllI[lllIIlllII[7]] = lIllIllIlIII("1ei08BZZwxilaPsvqTcrzA==", "mwYag");
    lllIIlIllI[lllIIlllII[4]] = lIllIllIIllI("QgDuCG77nK4=", "TxRTa");
    lllIIlIllI[lllIIlllII[8]] = lIllIllIlIlI("KhoMLQIqAUwgCCcbByATIBsF", "IubCg");
    lllIIlIllI[lllIIlllII[11]] = lIllIllIlIII("AA6vaC1GcmWMGq0zAhI6YhRTdb0dMDUF", "AJWCq");
  }
  
  protected void actionPerformed(GuiButton llllllllllllllllllIlIIlIIIllIIll)
    throws IOException
  {
    ;
    ;
    if (lIllIllllllI(id))
    {
      cancel = lllIIlllII[1];
      if (lIllIlllllII(networkManager)) {
        networkManager.closeChannel(new ChatComponentText(lllIIlIllI[lllIIlllII[4]]));
      }
      mc.displayGuiScreen(previousGuiScreen);
    }
  }
  
  private static boolean lIllIllllllI(int ???)
  {
    float llllllllllllllllllIlIIIlllIllIll;
    return ??? == 0;
  }
  
  private static String lIllIllIlIlI(String llllllllllllllllllIlIIlIIIIIIIIl, String llllllllllllllllllIlIIIllllllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllllIlIIlIIIIIIIIl = new String(Base64.getDecoder().decode(llllllllllllllllllIlIIlIIIIIIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllIlIIIlllllllll = new StringBuilder();
    char[] llllllllllllllllllIlIIIllllllllI = llllllllllllllllllIlIIIllllllIll.toCharArray();
    int llllllllllllllllllIlIIIlllllllIl = lllIIlllII[0];
    byte llllllllllllllllllIlIIIlllllIlll = llllllllllllllllllIlIIlIIIIIIIIl.toCharArray();
    float llllllllllllllllllIlIIIlllllIllI = llllllllllllllllllIlIIIlllllIlll.length;
    Exception llllllllllllllllllIlIIIlllllIlIl = lllIIlllII[0];
    while (lIlllIIIIIII(llllllllllllllllllIlIIIlllllIlIl, llllllllllllllllllIlIIIlllllIllI))
    {
      char llllllllllllllllllIlIIlIIIIIIIlI = llllllllllllllllllIlIIIlllllIlll[llllllllllllllllllIlIIIlllllIlIl];
      "".length();
      "".length();
      if ((0x1B ^ 0x1F) == " ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllllIlIIIlllllllll);
  }
  
  public void initGui()
  {
    ;
    buttonList.clear();
    new GuiButton(lllIIlllII[0], width / lllIIlllII[2] - lllIIlllII[3], height / lllIIlllII[4] + lllIIlllII[5] + lllIIlllII[6], I18n.format(lllIIlIllI[lllIIlllII[7]], new Object[lllIIlllII[0]]));
    "".length();
  }
  
  public GuiConnecting(GuiScreen llllllllllllllllllIlIIlIIlIIllII, Minecraft llllllllllllllllllIlIIlIIlIIlIll, String llllllllllllllllllIlIIlIIlIIllll, int llllllllllllllllllIlIIlIIlIIlIIl)
  {
    mc = llllllllllllllllllIlIIlIIlIlIIII;
    previousGuiScreen = llllllllllllllllllIlIIlIIlIIllII;
    llllllllllllllllllIlIIlIIlIlIIII.loadWorld(null);
    llllllllllllllllllIlIIlIIlIlIIlI.connect(llllllllllllllllllIlIIlIIlIIllll, llllllllllllllllllIlIIlIIlIIlIIl);
  }
}

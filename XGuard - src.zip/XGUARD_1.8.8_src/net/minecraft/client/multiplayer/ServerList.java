package net.minecraft.client.multiplayer;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompressedStreamTools;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import org.apache.logging.log4j.Logger;

public class ServerList
{
  public ServerList(Minecraft llllllllllllllllllllllIlIIIIllll)
  {
    mc = llllllllllllllllllllllIlIIIIllll;
    llllllllllllllllllllllIlIIIlIIlI.loadServerList();
  }
  
  public ServerData getServerData(int llllllllllllllllllllllIIlllIllll)
  {
    ;
    ;
    return (ServerData)servers.get(llllllllllllllllllllllIIlllIllll);
  }
  
  private static void lIIIllIIIIIl()
  {
    lIlIlllIlI = new int[9];
    lIlIlllIlI[0] = ((0x41 ^ 0x29 ^ 0x81 ^ 0xA1) & (63 + 23 - -112 + 3 ^ 16 + 80 - 82 + 115 ^ -" ".length()));
    lIlIlllIlI[1] = " ".length();
    lIlIlllIlI[2] = (0x0 ^ 0xA);
    lIlIlllIlI[3] = "  ".length();
    lIlIlllIlI[4] = "   ".length();
    lIlIlllIlI[5] = (0x3E ^ 0x2F ^ 0xD1 ^ 0xC4);
    lIlIlllIlI[6] = (0xF3 ^ 0xB7 ^ 0x0 ^ 0x41);
    lIlIlllIlI[7] = (0xB3 ^ 0xB5);
    lIlIlllIlI[8] = (0x3D ^ 0x23 ^ 0x1 ^ 0x17);
  }
  
  private static boolean lIIIllIIIlll(int ???, int arg1)
  {
    int i;
    char llllllllllllllllllllllIIlIIIIlIl;
    return ??? < i;
  }
  
  public void saveServerList()
  {
    try
    {
      ;
      ;
      ;
      NBTTagList llllllllllllllllllllllIIllllllII = new NBTTagList();
      short llllllllllllllllllllllIIllllIlIl = servers.iterator();
      "".length();
      if (" ".length() >= "   ".length()) {
        return;
      }
      while (!lIIIllIIIlIl(llllllllllllllllllllllIIllllIlIl.hasNext()))
      {
        ServerData llllllllllllllllllllllIIlllllIll = (ServerData)llllllllllllllllllllllIIllllIlIl.next();
        llllllllllllllllllllllIIllllllII.appendTag(llllllllllllllllllllllIIlllllIll.getNBTCompound());
      }
      NBTTagCompound llllllllllllllllllllllIIlllllIlI = new NBTTagCompound();
      llllllllllllllllllllllIIlllllIlI.setTag(lIlIlllIII[lIlIlllIlI[4]], llllllllllllllllllllllIIllllllII);
      CompressedStreamTools.safeWrite(llllllllllllllllllllllIIlllllIlI, new File(mc.mcDataDir, lIlIlllIII[lIlIlllIlI[5]]));
      "".length();
      if (null != null) {}
    }
    catch (Exception llllllllllllllllllllllIIlllllIIl)
    {
      logger.error(lIlIlllIII[lIlIlllIlI[6]], llllllllllllllllllllllIIlllllIIl);
    }
  }
  
  public void loadServerList()
  {
    try
    {
      ;
      ;
      ;
      ;
      servers.clear();
      NBTTagCompound llllllllllllllllllllllIlIIIIlIIl = CompressedStreamTools.read(new File(mc.mcDataDir, lIlIlllIII[lIlIlllIlI[0]]));
      if (lIIIllIIIIlI(llllllllllllllllllllllIlIIIIlIIl)) {
        return;
      }
      NBTTagList llllllllllllllllllllllIlIIIIlIII = llllllllllllllllllllllIlIIIIlIIl.getTagList(lIlIlllIII[lIlIlllIlI[1]], lIlIlllIlI[2]);
      int llllllllllllllllllllllIlIIIIIlll = lIlIlllIlI[0];
      "".length();
      if ("   ".length() <= "  ".length()) {
        return;
      }
      while (!lIIIllIIIIll(llllllllllllllllllllllIlIIIIIlll, llllllllllllllllllllllIlIIIIlIII.tagCount())) {
        "".length();
      }
      "".length();
      if (((0x7 ^ 0x53) & (0x11 ^ 0x45 ^ 0xFFFFFFFF)) <= -" ".length()) {}
    }
    catch (Exception llllllllllllllllllllllIlIIIIIllI)
    {
      logger.error(lIlIlllIII[lIlIlllIlI[3]], llllllllllllllllllllllIlIIIIIllI);
    }
  }
  
  public void func_147413_a(int llllllllllllllllllllllIIllIIllll, ServerData llllllllllllllllllllllIIllIIlllI)
  {
    ;
    ;
    ;
    "".length();
  }
  
  public int countServers()
  {
    ;
    return servers.size();
  }
  
  public void swapServers(int llllllllllllllllllllllIIllIlIllI, int llllllllllllllllllllllIIllIllIIl)
  {
    ;
    ;
    ;
    ;
    ServerData llllllllllllllllllllllIIllIllIII = llllllllllllllllllllllIIllIllIll.getServerData(llllllllllllllllllllllIIllIllIlI);
    "".length();
    "".length();
    llllllllllllllllllllllIIllIllIll.saveServerList();
  }
  
  private static boolean lIIIllIIIIll(int ???, int arg1)
  {
    int i;
    float llllllllllllllllllllllIIlIIIlIIl;
    return ??? >= i;
  }
  
  private static boolean lIIIllIIIlIl(int ???)
  {
    int llllllllllllllllllllllIIIlllllll;
    return ??? == 0;
  }
  
  public void removeServerData(int llllllllllllllllllllllIIlllIlIll)
  {
    ;
    ;
    "".length();
  }
  
  private static String lIIIlIllIlll(String llllllllllllllllllllllIIlIIlIIII, String llllllllllllllllllllllIIlIIlIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllllllIIlIIlIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllllllIIlIIlIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllllllIIlIIlIlII = Cipher.getInstance("Blowfish");
      llllllllllllllllllllllIIlIIlIlII.init(lIlIlllIlI[3], llllllllllllllllllllllIIlIIlIlIl);
      return new String(llllllllllllllllllllllIIlIIlIlII.doFinal(Base64.getDecoder().decode(llllllllllllllllllllllIIlIIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllllllIIlIIlIIll)
    {
      llllllllllllllllllllllIIlIIlIIll.printStackTrace();
    }
    return null;
  }
  
  public static void func_147414_b(ServerData llllllllllllllllllllllIIllIIIIlI)
  {
    ;
    ;
    ;
    ;
    ServerList llllllllllllllllllllllIIllIIIlIl = new ServerList(Minecraft.getMinecraft());
    llllllllllllllllllllllIIllIIIlIl.loadServerList();
    int llllllllllllllllllllllIIllIIIlII = lIlIlllIlI[0];
    "".length();
    if (((0xAD ^ 0xA2 ^ 0xC ^ 0x3F) & (0x4B ^ 0x45 ^ 0x64 ^ 0x56 ^ -" ".length())) != 0) {
      return;
    }
    while (!lIIIllIIIIll(llllllllllllllllllllllIIllIIIlII, llllllllllllllllllllllIIllIIIlIl.countServers()))
    {
      ServerData llllllllllllllllllllllIIllIIIIll = llllllllllllllllllllllIIllIIIlIl.getServerData(llllllllllllllllllllllIIllIIIlII);
      if ((lIIIllIIIllI(serverName.equals(serverName))) && (lIIIllIIIllI(serverIP.equals(serverIP))))
      {
        llllllllllllllllllllllIIllIIIlIl.func_147413_a(llllllllllllllllllllllIIllIIIlII, llllllllllllllllllllllIIllIIIllI);
        "".length();
        if ((0x9 ^ 0x16 ^ 0x45 ^ 0x5E) >= "  ".length()) {
          break;
        }
        return;
      }
      llllllllllllllllllllllIIllIIIlII++;
    }
    llllllllllllllllllllllIIllIIIlIl.saveServerList();
  }
  
  private static String lIIIlIllIllI(String llllllllllllllllllllllIIlIIlllIl, String llllllllllllllllllllllIIlIIlllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllllllIIlIlIIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllllllIIlIIlllII.getBytes(StandardCharsets.UTF_8)), lIlIlllIlI[8]), "DES");
      Cipher llllllllllllllllllllllIIlIlIIIIl = Cipher.getInstance("DES");
      llllllllllllllllllllllIIlIlIIIIl.init(lIlIlllIlI[3], llllllllllllllllllllllIIlIlIIIlI);
      return new String(llllllllllllllllllllllIIlIlIIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllllllllllIIlIIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllllllIIlIlIIIII)
    {
      llllllllllllllllllllllIIlIlIIIII.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIIIllIIIIIl();
    lIIIlIlllIII();
  }
  
  private static boolean lIIIllIIIllI(int ???)
  {
    double llllllllllllllllllllllIIlIIIIIIl;
    return ??? != 0;
  }
  
  private static String lIIIlIllIlIl(String llllllllllllllllllllllIIlIllIlII, String llllllllllllllllllllllIIlIlIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllllllllIIlIllIlII = new String(Base64.getDecoder().decode(llllllllllllllllllllllIIlIllIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllllllIIlIllIIlI = new StringBuilder();
    char[] llllllllllllllllllllllIIlIllIIIl = llllllllllllllllllllllIIlIlIlllI.toCharArray();
    int llllllllllllllllllllllIIlIllIIII = lIlIlllIlI[0];
    long llllllllllllllllllllllIIlIlIlIlI = llllllllllllllllllllllIIlIllIlII.toCharArray();
    byte llllllllllllllllllllllIIlIlIlIIl = llllllllllllllllllllllIIlIlIlIlI.length;
    boolean llllllllllllllllllllllIIlIlIlIII = lIlIlllIlI[0];
    while (lIIIllIIIlll(llllllllllllllllllllllIIlIlIlIII, llllllllllllllllllllllIIlIlIlIIl))
    {
      char llllllllllllllllllllllIIlIllIlIl = llllllllllllllllllllllIIlIlIlIlI[llllllllllllllllllllllIIlIlIlIII];
      "".length();
      "".length();
      if ("  ".length() < 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllllllllIIlIllIIlI);
  }
  
  public void addServerData(ServerData llllllllllllllllllllllIIlllIIIll)
  {
    ;
    ;
    "".length();
  }
  
  private static boolean lIIIllIIIIlI(Object ???)
  {
    float llllllllllllllllllllllIIlIIIIIll;
    return ??? == null;
  }
  
  private static void lIIIlIlllIII()
  {
    lIlIlllIII = new String[lIlIlllIlI[7]];
    lIlIlllIII[lIlIlllIlI[0]] = lIIIlIllIlIl("Iy4mPC0iOHouKSQ=", "PKTJH");
    lIlIlllIII[lIlIlllIlI[1]] = lIIIlIllIllI("RwHyS79gyNk=", "TDUuS");
    lIlIlllIII[lIlIlllIlI[3]] = lIIIlIllIllI("g7TIfuPjcdhPKzGg6Xny/Q2DiFIZnzxX6jF+KVY78Us=", "ipJcw");
    lIlIlllIII[lIlIlllIlI[4]] = lIIIlIllIllI("xL223NN3CF0=", "IXUBz");
    lIlIlllIII[lIlIlllIlI[5]] = lIIIlIllIllI("yZZCtKdngEco41TOwqZLWw==", "SezAR");
    lIlIlllIII[lIlIlllIlI[6]] = lIIIlIllIlll("cls/IkbVOH7bWZxRofpZodwC32alR2d9xrKwExMb5WA=", "wiKzF");
  }
}

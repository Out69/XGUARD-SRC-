package net.minecraft.client.multiplayer;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.BlockPos;
import net.minecraft.util.IProgressUpdate;
import net.minecraft.util.LongHashMap;
import net.minecraft.world.ChunkCoordIntPair;
import net.minecraft.world.World;
import net.minecraft.world.biome.BiomeGenBase.SpawnListEntry;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.EmptyChunk;
import net.minecraft.world.chunk.IChunkProvider;
import org.apache.logging.log4j.Logger;

public class ChunkProviderClient
  implements IChunkProvider
{
  public int getLoadedChunkCount()
  {
    ;
    return chunkListing.size();
  }
  
  public boolean func_177460_a(IChunkProvider llllllllllllllIIllllIIIIlIllIIIl, Chunk llllllllllllllIIllllIIIIlIllIIII, int llllllllllllllIIllllIIIIlIlIllll, int llllllllllllllIIllllIIIIlIlIlllI)
  {
    return lIIlIlIlllllI[0];
  }
  
  private static int lllIIlIllIlllI(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  public ChunkProviderClient(World llllllllllllllIIllllIIIIllllIIII)
  {
    blankChunk = new EmptyChunk(llllllllllllllIIllllIIIIllllIIII, lIIlIlIlllllI[0], lIIlIlIlllllI[0]);
    worldObj = llllllllllllllIIllllIIIIllllIIII;
  }
  
  private static boolean lllIIlIllIllll(int ???)
  {
    char llllllllllllllIIllllIIIIIllIlIII;
    return ??? > 0;
  }
  
  public Chunk provideChunk(int llllllllllllllIIllllIIIIllIIlIIl, int llllllllllllllIIllllIIIIllIIllII)
  {
    ;
    ;
    ;
    ;
    Chunk llllllllllllllIIllllIIIIllIIlIll = (Chunk)chunkMapping.getValueByKey(ChunkCoordIntPair.chunkXZ2Int(llllllllllllllIIllllIIIIllIIllIl, llllllllllllllIIllllIIIIllIIllII));
    if (lllIIlIllIllIl(llllllllllllllIIllllIIIIllIIlIll))
    {
      "".length();
      if ((('Þ' + 0 - 121 + 133 ^ 27 + 98 - 103 + 146) & (0x7 ^ 0x5F ^ 0x82 ^ 0x98 ^ -" ".length())) == 0) {
        break label85;
      }
      return null;
    }
    label85:
    return llllllllllllllIIllllIIIIllIIlIll;
  }
  
  public void saveExtraData() {}
  
  private static boolean lllIIlIllIllIl(Object ???)
  {
    String llllllllllllllIIllllIIIIIllIllII;
    return ??? == null;
  }
  
  static
  {
    lllIIlIllIlIll();
    lllIIlIllIlIlI();
  }
  
  public boolean chunkExists(int llllllllllllllIIllllIIIIlllIllII, int llllllllllllllIIllllIIIIlllIlIll)
  {
    return lIIlIlIlllllI[1];
  }
  
  private static String lllIIlIllIlIIl(String llllllllllllllIIllllIIIIlIIIllll, String llllllllllllllIIllllIIIIlIIIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllllIIIIlIIlIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllllIIIIlIIIllII.getBytes(StandardCharsets.UTF_8)), lIIlIlIlllllI[5]), "DES");
      Cipher llllllllllllllIIllllIIIIlIIlIIIl = Cipher.getInstance("DES");
      llllllllllllllIIllllIIIIlIIlIIIl.init(lIIlIlIlllllI[2], llllllllllllllIIllllIIIIlIIlIIlI);
      return new String(llllllllllllllIIllllIIIIlIIlIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIIllllIIIIlIIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllllIIIIlIIlIIII)
    {
      llllllllllllllIIllllIIIIlIIlIIII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIlIlllIIII(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIIllllIIIIIllIlllI;
    return ??? < i;
  }
  
  public void populate(IChunkProvider llllllllllllllIIllllIIIIlIllIlIl, int llllllllllllllIIllllIIIIlIllIlII, int llllllllllllllIIllllIIIIlIllIIll) {}
  
  public Chunk loadChunk(int llllllllllllllIIllllIIIIllIlIlIl, int llllllllllllllIIllllIIIIllIllIII)
  {
    ;
    ;
    ;
    ;
    Chunk llllllllllllllIIllllIIIIllIlIlll = new Chunk(worldObj, llllllllllllllIIllllIIIIllIllIIl, llllllllllllllIIllllIIIIllIllIII);
    chunkMapping.add(ChunkCoordIntPair.chunkXZ2Int(llllllllllllllIIllllIIIIllIllIIl, llllllllllllllIIllllIIIIllIllIII), llllllllllllllIIllllIIIIllIlIlll);
    "".length();
    llllllllllllllIIllllIIIIllIlIlll.setChunkLoaded(lIIlIlIlllllI[1]);
    return llllllllllllllIIllllIIIIllIlIlll;
  }
  
  private static boolean lllIIlIllIllII(int ???)
  {
    float llllllllllllllIIllllIIIIIllIlIlI;
    return ??? == 0;
  }
  
  public boolean canSave()
  {
    return lIIlIlIlllllI[0];
  }
  
  public boolean unloadQueuedChunks()
  {
    ;
    ;
    ;
    long llllllllllllllIIllllIIIIlIllllIl = System.currentTimeMillis();
    short llllllllllllllIIllllIIIIlIlllIII = chunkListing.iterator();
    "".length();
    if (" ".length() == 0) {
      return (0x5 ^ 0x74 ^ 0x50 ^ 0x7F) & ('±' + 88 - 94 + 81 ^ 16 + 62 - -6 + 78 ^ -" ".length());
    }
    label174:
    while (!lllIIlIllIllII(llllllllllllllIIllllIIIIlIlllIII.hasNext()))
    {
      Chunk llllllllllllllIIllllIIIIlIllllII = (Chunk)llllllllllllllIIllllIIIIlIlllIII.next();
      if (lllIIlIllIllll(lllIIlIllIlllI(System.currentTimeMillis() - llllllllllllllIIllllIIIIlIllllIl, 5L)))
      {
        "".length();
        if ((0x6A ^ 0x70 ^ 0x6A ^ 0x74) <= (0x4B ^ 0x1A ^ 0x41 ^ 0x14)) {
          break label174;
        }
        return (0x2 ^ 0x61 ^ 0x63 ^ 0x2F) & (0x30 ^ 0x62 ^ 0xB8 ^ 0xC5 ^ -" ".length());
      }
      lIIlIlIlllllI[1].func_150804_b(lIIlIlIlllllI[0]);
    }
    if (lllIIlIllIllll(lllIIlIllIlllI(System.currentTimeMillis() - llllllllllllllIIllllIIIIlIllllIl, 100L))) {
      logger.info(lIIlIlIllllIl[lIIlIlIlllllI[0]], new Object[] { Long.valueOf(System.currentTimeMillis() - llllllllllllllIIllllIIIIlIllllIl) });
    }
    return lIIlIlIlllllI[0];
  }
  
  public boolean saveChunks(boolean llllllllllllllIIllllIIIIllIIIlIl, IProgressUpdate llllllllllllllIIllllIIIIllIIIlII)
  {
    return lIIlIlIlllllI[1];
  }
  
  public void recreateStructures(Chunk llllllllllllllIIllllIIIIlIIlllll, int llllllllllllllIIllllIIIIlIIllllI, int llllllllllllllIIllllIIIIlIIlllIl) {}
  
  private static void lllIIlIllIlIlI()
  {
    lIIlIlIllllIl = new String[lIIlIlIlllllI[4]];
    lIIlIlIllllIl[lIIlIlIlllllI[0]] = lllIIlIllIlIII("ISkzPi8YL3twBRohJD4yBSElNWYVIDQ+LVY8KDMtHyYmcDIZJypwPQtoLCM=", "vHAPF");
    lIIlIlIllllIl[lIIlIlIlllllI[1]] = lllIIlIllIlIIl("vJ6cVibBd3SDcsVa+j8kAM+QcHiyztWt", "BVkIo");
    lIIlIlIllllIl[lIIlIlIlllllI[2]] = lllIIlIllIlIII("QFk=", "lyvAr");
  }
  
  public String makeString()
  {
    ;
    return String.valueOf(new StringBuilder(lIIlIlIllllIl[lIIlIlIlllllI[1]]).append(chunkMapping.getNumHashElements()).append(lIIlIlIllllIl[lIIlIlIlllllI[2]]).append(chunkListing.size()));
  }
  
  public Chunk provideChunk(BlockPos llllllllllllllIIllllIIIIlIIllIIl)
  {
    ;
    ;
    return llllllllllllllIIllllIIIIlIIllIlI.provideChunk(llllllllllllllIIllllIIIIlIIllIIl.getX() >> lIIlIlIlllllI[3], llllllllllllllIIllllIIIIlIIllIIl.getZ() >> lIIlIlIlllllI[3]);
  }
  
  public void unloadChunk(int llllllllllllllIIllllIIIIlllIIlIl, int llllllllllllllIIllllIIIIlllIIlII)
  {
    ;
    ;
    ;
    ;
    Chunk llllllllllllllIIllllIIIIlllIIIll = llllllllllllllIIllllIIIIlllIIIlI.provideChunk(llllllllllllllIIllllIIIIlllIIIIl, llllllllllllllIIllllIIIIlllIIlII);
    if (lllIIlIllIllII(llllllllllllllIIllllIIIIlllIIIll.isEmpty())) {
      llllllllllllllIIllllIIIIlllIIIll.onChunkUnload();
    }
    "".length();
    "".length();
  }
  
  public List<BiomeGenBase.SpawnListEntry> getPossibleCreatures(EnumCreatureType llllllllllllllIIllllIIIIlIlIlIIl, BlockPos llllllllllllllIIllllIIIIlIlIlIII)
  {
    return null;
  }
  
  private static String lllIIlIllIlIII(String llllllllllllllIIllllIIIIIllllIlI, String llllllllllllllIIllllIIIIIllllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllllIIIIIllllIlI = new String(Base64.getDecoder().decode(llllllllllllllIIllllIIIIIllllIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIllllIIIIIlllllIl = new StringBuilder();
    char[] llllllllllllllIIllllIIIIIlllllII = llllllllllllllIIllllIIIIIllllIIl.toCharArray();
    int llllllllllllllIIllllIIIIIllllIll = lIIlIlIlllllI[0];
    short llllllllllllllIIllllIIIIIlllIlIl = llllllllllllllIIllllIIIIIllllIlI.toCharArray();
    int llllllllllllllIIllllIIIIIlllIlII = llllllllllllllIIllllIIIIIlllIlIl.length;
    String llllllllllllllIIllllIIIIIlllIIll = lIIlIlIlllllI[0];
    while (lllIIlIlllIIII(llllllllllllllIIllllIIIIIlllIIll, llllllllllllllIIllllIIIIIlllIlII))
    {
      char llllllllllllllIIllllIIIIlIIIIIII = llllllllllllllIIllllIIIIIlllIlIl[llllllllllllllIIllllIIIIIlllIIll];
      "".length();
      "".length();
      if (" ".length() == 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIllllIIIIIlllllIl);
  }
  
  public BlockPos getStrongholdGen(World llllllllllllllIIllllIIIIlIlIIllI, String llllllllllllllIIllllIIIIlIlIIlIl, BlockPos llllllllllllllIIllllIIIIlIlIIlII)
  {
    return null;
  }
  
  private static void lllIIlIllIlIll()
  {
    lIIlIlIlllllI = new int[6];
    lIIlIlIlllllI[0] = ((0xD6 ^ 0x8F) & (0x3D ^ 0x64 ^ 0xFFFFFFFF) & ((0xB8 ^ 0x91) & (0x70 ^ 0x59 ^ 0xFFFFFFFF) ^ 0xFFFFFFFF));
    lIIlIlIlllllI[1] = " ".length();
    lIIlIlIlllllI[2] = "  ".length();
    lIIlIlIlllllI[3] = (0xE8 ^ 0x87 ^ 0xE1 ^ 0x8A);
    lIIlIlIlllllI[4] = "   ".length();
    lIIlIlIlllllI[5] = (0x69 ^ 0x61);
  }
}

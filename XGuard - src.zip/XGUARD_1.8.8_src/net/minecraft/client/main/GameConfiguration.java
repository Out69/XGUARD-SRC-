package net.minecraft.client.main;

import com.mojang.authlib.properties.PropertyMap;
import java.io.File;
import java.net.Proxy;
import net.minecraft.util.Session;

public class GameConfiguration
{
  public GameConfiguration(UserInformation lllllllllllllllIlIllIIIIlIIlllIl, DisplayInformation lllllllllllllllIlIllIIIIlIlIIIlI, FolderInformation lllllllllllllllIlIllIIIIlIlIIIIl, GameInformation lllllllllllllllIlIllIIIIlIlIIIII, ServerInformation lllllllllllllllIlIllIIIIlIIllIIl)
  {
    userInfo = lllllllllllllllIlIllIIIIlIIlllIl;
    displayInfo = lllllllllllllllIlIllIIIIlIlIIIlI;
    folderInfo = lllllllllllllllIlIllIIIIlIlIIIIl;
    gameInfo = lllllllllllllllIlIllIIIIlIlIIIII;
    serverInfo = lllllllllllllllIlIllIIIIlIIllIIl;
  }
  
  public static class FolderInformation
  {
    public FolderInformation(File lllllllllllllllllIlllllIlIIIllII, File lllllllllllllllllIlllllIlIIIlIll, File lllllllllllllllllIlllllIlIIIlIlI, String lllllllllllllllllIlllllIlIIIIlII)
    {
      mcDataDir = lllllllllllllllllIlllllIlIIIllII;
      resourcePacksDir = lllllllllllllllllIlllllIlIIIIllI;
      assetsDir = lllllllllllllllllIlllllIlIIIlIlI;
      assetIndex = lllllllllllllllllIlllllIlIIIIlII;
    }
  }
  
  public static class ServerInformation
  {
    public ServerInformation(String llllllllllllllllIIlllIlIlIIIIIII, int llllllllllllllllIIlllIlIIlllllII)
    {
      serverName = llllllllllllllllIIlllIlIIlllllIl;
      serverPort = llllllllllllllllIIlllIlIIlllllII;
    }
  }
  
  public static class DisplayInformation
  {
    public DisplayInformation(int lllllllllllllllllllIIIlllIIllIIl, int lllllllllllllllllllIIIlllIIllIII, boolean lllllllllllllllllllIIIlllIIlIIlI, boolean lllllllllllllllllllIIIlllIIlIllI)
    {
      width = lllllllllllllllllllIIIlllIIllIIl;
      height = lllllllllllllllllllIIIlllIIlIIll;
      fullscreen = lllllllllllllllllllIIIlllIIlIIlI;
      checkGlErrors = lllllllllllllllllllIIIlllIIlIllI;
    }
  }
  
  public static class GameInformation
  {
    public GameInformation(boolean lllllllllllllllIlllllllIlllIIIll, String lllllllllllllllIlllllllIlllIIIlI)
    {
      isDemo = lllllllllllllllIlllllllIlllIIIII;
      version = lllllllllllllllIlllllllIlllIIIlI;
    }
  }
  
  public static class UserInformation
  {
    public UserInformation(Session llllllllllllllIllIlIlIllllIIllII, PropertyMap llllllllllllllIllIlIlIllllIIIllI, PropertyMap llllllllllllllIllIlIlIllllIIIlIl, Proxy llllllllllllllIllIlIlIllllIIIlII)
    {
      session = llllllllllllllIllIlIlIllllIIllII;
      userProperties = llllllllllllllIllIlIlIllllIIlIll;
      field_181172_c = llllllllllllllIllIlIlIllllIIIlIl;
      proxy = llllllllllllllIllIlIlIllllIIIlII;
    }
  }
}

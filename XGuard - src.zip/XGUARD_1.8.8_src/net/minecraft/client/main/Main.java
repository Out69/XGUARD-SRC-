package net.minecraft.client.main;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.authlib.properties.PropertyMap;
import com.mojang.authlib.properties.PropertyMap.Serializer;
import java.io.File;
import java.io.PrintStream;
import java.net.Authenticator;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import joptsimple.ArgumentAcceptingOptionSpec;
import joptsimple.OptionParser;
import joptsimple.OptionSet;
import joptsimple.OptionSpec;
import joptsimple.OptionSpecBuilder;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Session;

public class Main
{
  private static String lIlllIIIlIlI(String llllllllllllllllllIIlIIlIlIlIIIl, String llllllllllllllllllIIlIIlIlIIlllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIIlIIlIlIlIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIIlIIlIlIIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIIlIIlIlIlIIll = Cipher.getInstance("Blowfish");
      llllllllllllllllllIIlIIlIlIlIIll.init(llllIlIlll[2], llllllllllllllllllIIlIIlIlIlIlII);
      return new String(llllllllllllllllllIIlIIlIlIlIIll.doFinal(Base64.getDecoder().decode(llllllllllllllllllIIlIIlIlIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIIlIIlIlIlIIlI)
    {
      llllllllllllllllllIIlIIlIlIlIIlI.printStackTrace();
    }
    return null;
  }
  
  static
  {
    llIIIIlIIlII();
    lIlllIlIIIIl();
  }
  
  private static boolean llIIIIlIIllI(Object ???)
  {
    float llllllllllllllllllIIlIIlIIlIIIIl;
    return ??? != null;
  }
  
  private static void lIlllIlIIIIl()
  {
    lllIlIIlIl = new String[llllIlIlll[41]];
    lllIlIIlIl[llllIlIlll[0]] = lIlllIIIlIIl("mI/e8TPgSmeFi0uQqdIZno/1r9T6HBYYYEddzchPRT8=", "uUOni");
    lllIlIIlIl[llllIlIlll[1]] = lIlllIIIlIIl("xNk0Jgcf8Xs=", "pjwJk");
    lllIlIIlIl[llllIlIlll[2]] = lIlllIIIlIIl("TgitGsBxzNs=", "DOvnU");
    lllIlIIlIl[llllIlIlll[3]] = lIlllIIIlIlI("oOVpQDN/9elR5vKFxUlFRQ==", "CKwDE");
    lllIlIIlIl[llllIlIlll[4]] = lIlllIIIlIIl("OsLMySpDc0geWZMr7vhuKg==", "UeTIH");
    lllIlIIlIl[llllIlIlll[5]] = lIlllIIIlIlI("dx65E6k+5bA=", "MWKoY");
    lllIlIIlIl[llllIlIlll[6]] = lIlllIIlIlII("PiEiJA==", "NNPPv");
    lllIlIIlIl[llllIlIlll[8]] = lIlllIIlIlII("BhEHACAIAg==", "apjed");
    lllIlIIlIl[llllIlIlll[9]] = lIlllIIlIlII("bw==", "AWvUR");
    lllIlIIlIl[llllIlIlll[10]] = lIlllIIIlIIl("M+tHn0JRk15Kx985ievFog==", "EMEel");
    lllIlIIlIl[llllIlIlll[11]] = lIlllIIIlIIl("rha7i6QkcBHL4BX4DMjEoQ==", "bebqh");
    lllIlIIlIl[llllIlIlll[12]] = lIlllIIIlIlI("XdLB2fmEQ1MvEYvnZbSOJQ==", "jAlQd");
    lllIlIIlIl[llllIlIlll[13]] = lIlllIIIlIlI("uJTbjIhk/U+eortxuiMcSQ==", "yIDdb");
    lllIlIIlIl[llllIlIlll[14]] = lIlllIIIlIIl("+Tp81M0iZbM=", "yMVKK");
    lllIlIIlIl[llllIlIlll[15]] = lIlllIIlIlII("ITUmLA4ENCwm", "QGITw");
    lllIlIIlIl[llllIlIlll[16]] = lIlllIIIlIlI("ThF5aflYivXDf7zSRfPihw==", "MmtQT");
    lllIlIIlIl[llllIlIlll[17]] = lIlllIIIlIlI("J0lcxxT1AxOPT4Ecjkttqg==", "tMqvk");
    lllIlIIlIl[llllIlIlll[18]] = lIlllIIIlIIl("Co/dS62MznQzCZ9M0jyb7w==", "VsIgu");
    lllIlIIlIl[llllIlIlll[19]] = lIlllIIIlIlI("P36X8usWbLM=", "mLolq");
    lllIlIIlIl[llllIlIlll[20]] = lIlllIIIlIlI("MfzKdC/UTUqzKpkWbHas8Q==", "sVbmM");
    lllIlIIlIl[llllIlIlll[21]] = lIlllIIIlIIl("KpPOhn7YJQ0=", "WXCxS");
    lllIlIIlIl[llllIlIlll[22]] = lIlllIIIlIIl("I62kfClUf6M=", "dPVrn");
    lllIlIIlIl[llllIlIlll[24]] = lIlllIIIlIIl("pig76jVXZ+g=", "sQRHn");
    lllIlIIlIl[llllIlIlll[26]] = lIlllIIIlIIl("H6RanBjdAe75z7lviARbSA==", "eNAUI");
    lllIlIIlIl[llllIlIlll[27]] = lIlllIIlIlII("KxM=", "PnHgJ");
    lllIlIIlIl[llllIlIlll[28]] = lIlllIIlIlII("GgQ2KR4GEwk9GBoTKzseDwU=", "jvYOw");
    lllIlIIlIl[llllIlIlll[29]] = lIlllIIlIlII("LjQ=", "UIVhd");
    lllIlIIlIl[llllIlIlll[30]] = lIlllIIlIlII("ChQSISUiCQUhKQ==", "kgaDQ");
    lllIlIIlIl[llllIlIlll[31]] = lIlllIIIlIIl("NMMFC5FzY9XPzJLCsVjAew==", "oNsTM");
    lllIlIIlIl[llllIlIlll[32]] = lIlllIIIlIlI("1Xhtv798omo=", "YznaT");
    lllIlIIlIl[llllIlIlll[33]] = lIlllIIlIlII("Kz8YOSgNJBAlPUg5EicrGjURaSUaNwAkIQYkBnNk", "hPuID");
    lllIlIIlIl[llllIlIlll[34]] = lIlllIIlIlII("Hj0YNB0bOhE9AA==", "xHtXn");
    lllIlIIlIl[llllIlIlll[35]] = lIlllIIlIlII("OzgLJhEfPCs3CDciHQ==", "XPnEz");
    lllIlIIlIl[llllIlIlll[36]] = lIlllIIIlIIl("GnonVYRjvXc=", "FgcMM");
    lllIlIIlIl[llllIlIlll[37]] = lIlllIIlIlII("Lxg2BhI9RA==", "NkEcf");
    lllIlIIlIl[llllIlIlll[38]] = lIlllIIIlIlI("ZJ8S6oKkNhEbhoo9tu0dwQ==", "sNZxT");
    lllIlIIlIl[llllIlIlll[39]] = lIlllIIIlIIl("u0XotJreaNfK/kWOITMpcDx3tH5srDKe", "hbpeU");
    lllIlIIlIl[llllIlIlll[40]] = lIlllIIlIlII("NCczDyADay4CPBIqPg==", "wKZjN");
  }
  
  private static String lIlllIIIlIIl(String llllllllllllllllllIIlIIlIlIIIIlI, String llllllllllllllllllIIlIIlIlIIIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIIlIIlIlIIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIIlIIlIlIIIIIl.getBytes(StandardCharsets.UTF_8)), llllIlIlll[9]), "DES");
      Cipher llllllllllllllllllIIlIIlIlIIIllI = Cipher.getInstance("DES");
      llllllllllllllllllIIlIIlIlIIIllI.init(llllIlIlll[2], llllllllllllllllllIIlIIlIlIIIlll);
      return new String(llllllllllllllllllIIlIIlIlIIIllI.doFinal(Base64.getDecoder().decode(llllllllllllllllllIIlIIlIlIIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIIlIIlIlIIIlIl)
    {
      llllllllllllllllllIIlIIlIlIIIlIl.printStackTrace();
    }
    return null;
  }
  
  public static void main(String[] llllllllllllllllllIIlIIllIllIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    "".length();
    OptionParser llllllllllllllllllIIlIIllIllIllI = new OptionParser();
    llllllllllllllllllIIlIIllIllIllI.allowsUnrecognizedOptions();
    "".length();
    "".length();
    "".length();
    OptionSpec<String> llllllllllllllllllIIlIIllIllIlIl = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[5]]).withRequiredArg();
    OptionSpec<Integer> llllllllllllllllllIIlIIllIllIlII = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[6]]).withRequiredArg().ofType(Integer.class).defaultsTo(Integer.valueOf(llllIlIlll[7]), new Integer[llllIlIlll[0]]);
    OptionSpec<File> llllllllllllllllllIIlIIllIllIIll = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[8]]).withRequiredArg().ofType(File.class).defaultsTo(new File(lllIlIIlIl[llllIlIlll[9]]), new File[llllIlIlll[0]]);
    OptionSpec<File> llllllllllllllllllIIlIIllIllIIlI = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[10]]).withRequiredArg().ofType(File.class);
    OptionSpec<File> llllllllllllllllllIIlIIllIllIIIl = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[11]]).withRequiredArg().ofType(File.class);
    OptionSpec<String> llllllllllllllllllIIlIIllIllIIII = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[12]]).withRequiredArg();
    OptionSpec<Integer> llllllllllllllllllIIlIIllIlIllll = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[13]]).withRequiredArg().defaultsTo(lllIlIIlIl[llllIlIlll[14]], new String[llllIlIlll[0]]).ofType(Integer.class);
    OptionSpec<String> llllllllllllllllllIIlIIllIlIlllI = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[15]]).withRequiredArg();
    OptionSpec<String> llllllllllllllllllIIlIIllIlIllIl = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[16]]).withRequiredArg();
    OptionSpec<String> llllllllllllllllllIIlIIllIlIllII = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[17]]).withRequiredArg().defaultsTo(lllIlIIlIl[llllIlIlll[18]], new String[llllIlIlll[0]]);
    OptionSpec<String> llllllllllllllllllIIlIIllIlIlIll = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[19]]).withRequiredArg();
    OptionSpec<String> llllllllllllllllllIIlIIllIlIlIlI = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[20]]).withRequiredArg().required();
    OptionSpec<String> llllllllllllllllllIIlIIllIlIlIIl = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[21]]).withRequiredArg().required();
    OptionSpec<Integer> llllllllllllllllllIIlIIllIlIlIII = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[22]]).withRequiredArg().ofType(Integer.class).defaultsTo(Integer.valueOf(llllIlIlll[23]), new Integer[llllIlIlll[0]]);
    OptionSpec<Integer> llllllllllllllllllIIlIIllIlIIlll = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[24]]).withRequiredArg().ofType(Integer.class).defaultsTo(Integer.valueOf(llllIlIlll[25]), new Integer[llllIlIlll[0]]);
    OptionSpec<String> llllllllllllllllllIIlIIllIlIIllI = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[26]]).withRequiredArg().defaultsTo(lllIlIIlIl[llllIlIlll[27]], new String[llllIlIlll[0]]);
    OptionSpec<String> llllllllllllllllllIIlIIllIlIIlIl = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[28]]).withRequiredArg().defaultsTo(lllIlIIlIl[llllIlIlll[29]], new String[llllIlIlll[0]]);
    OptionSpec<String> llllllllllllllllllIIlIIllIlIIlII = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[30]]).withRequiredArg();
    OptionSpec<String> llllllllllllllllllIIlIIllIlIIIll = llllllllllllllllllIIlIIllIllIllI.accepts(lllIlIIlIl[llllIlIlll[31]]).withRequiredArg().defaultsTo(lllIlIIlIl[llllIlIlll[32]], new String[llllIlIlll[0]]);
    OptionSpec<String> llllllllllllllllllIIlIIllIlIIIlI = llllllllllllllllllIIlIIllIllIllI.nonOptions();
    OptionSet llllllllllllllllllIIlIIllIlIIIIl = llllllllllllllllllIIlIIllIllIllI.parse(llllllllllllllllllIIlIIllIIIlIIl);
    List<String> llllllllllllllllllIIlIIllIlIIIII = llllllllllllllllllIIlIIllIlIIIIl.valuesOf(llllllllllllllllllIIlIIllIlIIIlI);
    if (llIIIIlIIlIl(llllllllllllllllllIIlIIllIlIIIII.isEmpty())) {
      System.out.println(String.valueOf(new StringBuilder(lllIlIIlIl[llllIlIlll[33]]).append(llllllllllllllllllIIlIIllIlIIIII)));
    }
    String llllllllllllllllllIIlIIllIIlllll = (String)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIllIIII);
    Proxy llllllllllllllllllIIlIIllIIllllI = Proxy.NO_PROXY;
    if (llIIIIlIIllI(llllllllllllllllllIIlIIllIIlllll)) {
      try
      {
        llllllllllllllllllIIlIIllIIllllI = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(llllllllllllllllllIIlIIllIIlllll, ((Integer)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIlIllll)).intValue()));
        "".length();
        if (" ".length() != " ".length()) {
          return;
        }
      }
      catch (Exception localException1) {}
    }
    String llllllllllllllllllIIlIIllIIlllIl = (String)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIlIlllI);
    final String llllllllllllllllllIIlIIllIIlllII = (String)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIlIllIl);
    if ((llIIIIlIIlIl(llllllllllllllllllIIlIIllIIllllI.equals(Proxy.NO_PROXY))) && (llIIIIlIIlll(isNullOrEmpty(llllllllllllllllllIIlIIllIIlllIl))) && (llIIIIlIIlll(isNullOrEmpty(llllllllllllllllllIIlIIllIIlllII)))) {
      Authenticator.setDefault(new Authenticator()
      {
        protected PasswordAuthentication getPasswordAuthentication()
        {
          ;
          return new PasswordAuthentication(Main.this, llllllllllllllllllIIlIIllIIlllII.toCharArray());
        }
      });
    }
    int llllllllllllllllllIIlIIllIIllIll = ((Integer)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIlIlIII)).intValue();
    int llllllllllllllllllIIlIIllIIllIlI = ((Integer)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIlIIlll)).intValue();
    boolean llllllllllllllllllIIlIIllIIllIIl = llllllllllllllllllIIlIIllIlIIIIl.has(lllIlIIlIl[llllIlIlll[34]]);
    boolean llllllllllllllllllIIlIIllIIllIII = llllllllllllllllllIIlIIllIlIIIIl.has(lllIlIIlIl[llllIlIlll[35]]);
    boolean llllllllllllllllllIIlIIllIIlIlll = llllllllllllllllllIIlIIllIlIIIIl.has(lllIlIIlIl[llllIlIlll[36]]);
    String llllllllllllllllllIIlIIllIIlIllI = (String)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIlIlIIl);
    Gson llllllllllllllllllIIlIIllIIlIlIl = new GsonBuilder().registerTypeAdapter(PropertyMap.class, new PropertyMap.Serializer()).create();
    PropertyMap llllllllllllllllllIIlIIllIIlIlII = (PropertyMap)llllllllllllllllllIIlIIllIIlIlIl.fromJson((String)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIlIIllI), PropertyMap.class);
    PropertyMap llllllllllllllllllIIlIIllIIlIIll = (PropertyMap)llllllllllllllllllIIlIIllIIlIlIl.fromJson((String)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIlIIlIl), PropertyMap.class);
    File llllllllllllllllllIIlIIllIIlIIlI = (File)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIllIIll);
    if (llIIIIlIIlll(llllllllllllllllllIIlIIllIlIIIIl.has(llllllllllllllllllIIlIIllIllIIlI)))
    {
      "".length();
      if (null == null) {
        break label1150;
      }
    }
    label1150:
    File llllllllllllllllllIIlIIllIIlIIIl = new File(llllllllllllllllllIIlIIllIIlIIlI, lllIlIIlIl[llllIlIlll[37]]);
    if (llIIIIlIIlll(llllllllllllllllllIIlIIllIlIIIIl.has(llllllllllllllllllIIlIIllIllIIIl)))
    {
      "".length();
      if (((0x41 ^ 0x63 ^ 0x59 ^ 0x2A) & (0x5D ^ 0x3F ^ 0xF0 ^ 0xC3 ^ -" ".length())) == 0) {
        break label1238;
      }
    }
    label1238:
    File llllllllllllllllllIIlIIllIIlIIII = new File(llllllllllllllllllIIlIIllIIlIIlI, lllIlIIlIl[llllIlIlll[38]]);
    if (llIIIIlIIlll(llllllllllllllllllIIlIIllIlIIIIl.has(llllllllllllllllllIIlIIllIlIlIll)))
    {
      "".length();
      if (-(41 + 49 - -8 + 70 ^ 8 + 4 - -8 + 152) < 0) {
        break label1312;
      }
    }
    label1312:
    String llllllllllllllllllIIlIIllIIIllll = (String)llllllllllllllllllIIlIIllIlIllII.value(llllllllllllllllllIIlIIllIlIIIIl);
    if (llIIIIlIIlll(llllllllllllllllllIIlIIllIlIIIIl.has(llllllllllllllllllIIlIIllIlIIlII)))
    {
      "".length();
      if (-(0x82 ^ 0x86) <= 0) {
        break label1359;
      }
    }
    label1359:
    String llllllllllllllllllIIlIIllIIIlllI = null;
    String llllllllllllllllllIIlIIllIIIllIl = (String)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIllIlIl);
    Integer llllllllllllllllllIIlIIllIIIllII = (Integer)llllllllllllllllllIIlIIllIlIIIIl.valueOf(llllllllllllllllllIIlIIllIllIlII);
    Session llllllllllllllllllIIlIIllIIIlIll = new Session((String)llllllllllllllllllIIlIIllIlIllII.value(llllllllllllllllllIIlIIllIlIIIIl), llllllllllllllllllIIlIIllIIIllll, (String)llllllllllllllllllIIlIIllIlIlIlI.value(llllllllllllllllllIIlIIllIlIIIIl), (String)llllllllllllllllllIIlIIllIlIIIll.value(llllllllllllllllllIIlIIllIlIIIIl));
    GameConfiguration llllllllllllllllllIIlIIllIIIlIlI = new GameConfiguration(new GameConfiguration.UserInformation(llllllllllllllllllIIlIIllIIIlIll, llllllllllllllllllIIlIIllIIlIlII, llllllllllllllllllIIlIIllIIlIIll, llllllllllllllllllIIlIIllIIllllI), new GameConfiguration.DisplayInformation(llllllllllllllllllIIlIIllIIllIll, llllllllllllllllllIIlIIllIIllIlI, llllllllllllllllllIIlIIllIIllIIl, llllllllllllllllllIIlIIllIIllIII), new GameConfiguration.FolderInformation(llllllllllllllllllIIlIIllIIlIIlI, llllllllllllllllllIIlIIllIIlIIII, llllllllllllllllllIIlIIllIIlIIIl, llllllllllllllllllIIlIIllIIIlllI), new GameConfiguration.GameInformation(llllllllllllllllllIIlIIllIIlIlll, llllllllllllllllllIIlIIllIIlIllI), new GameConfiguration.ServerInformation(llllllllllllllllllIIlIIllIIIllIl, llllllllllllllllllIIlIIllIIIllII.intValue()));
    Runtime.getRuntime().addShutdownHook(new Thread(lllIlIIlIl[llllIlIlll[39]])
    {
      public void run() {}
    });
    Thread.currentThread().setName(lllIlIIlIl[llllIlIlll[40]]);
    new Minecraft(llllllllllllllllllIIlIIllIIIlIlI).run();
  }
  
  private static boolean llIIIIlIIlIl(int ???)
  {
    Exception llllllllllllllllllIIlIIlIIIlllIl;
    return ??? == 0;
  }
  
  private static boolean llIIIIlIlIII(int ???, int arg1)
  {
    int i;
    short llllllllllllllllllIIlIIlIIlIIIll;
    return ??? < i;
  }
  
  private static boolean isNullOrEmpty(String llllllllllllllllllIIlIIlIlIllIIl)
  {
    ;
    if ((llIIIIlIIllI(llllllllllllllllllIIlIIlIlIllIIl)) && (llIIIIlIIlIl(llllllllllllllllllIIlIIlIlIllIlI.isEmpty()))) {
      return llllIlIlll[1];
    }
    return llllIlIlll[0];
  }
  
  public Main() {}
  
  private static void llIIIIlIIlII()
  {
    llllIlIlll = new int[42];
    llllIlIlll[0] = ((0xFB ^ 0x8D ^ 0x14 ^ 0x49) & (0x79 ^ 0x45 ^ 0xB3 ^ 0xA4 ^ -" ".length()));
    llllIlIlll[1] = " ".length();
    llllIlIlll[2] = "  ".length();
    llllIlIlll[3] = "   ".length();
    llllIlIlll[4] = (0x80 ^ 0x84);
    llllIlIlll[5] = (0xB6 ^ 0xB3);
    llllIlIlll[6] = (0x2B ^ 0x2D);
    llllIlIlll[7] = (0xFFFFFFFD & 0x63DF);
    llllIlIlll[8] = (0xA4 ^ 0x81 ^ 0x36 ^ 0x14);
    llllIlIlll[9] = (0x5D ^ 0x55);
    llllIlIlll[10] = (0xB0 ^ 0xB9);
    llllIlIlll[11] = (0x7A ^ 0x3E ^ 0x77 ^ 0x39);
    llllIlIlll[12] = (0x18 ^ 0x3C ^ 0xB1 ^ 0x9E);
    llllIlIlll[13] = (0x4E ^ 0x50 ^ 0xB7 ^ 0xA5);
    llllIlIlll[14] = (0xAA ^ 0xA7);
    llllIlIlll[15] = (0x6F ^ 0x61);
    llllIlIlll[16] = (0x41 ^ 0xC ^ 0x7A ^ 0x38);
    llllIlIlll[17] = (0x61 ^ 0x71);
    llllIlIlll[18] = (0x5E ^ 0x4F);
    llllIlIlll[19] = (0x98 ^ 0x8A);
    llllIlIlll[20] = (0x7C ^ 0x16 ^ 0x1A ^ 0x63);
    llllIlIlll[21] = (0x2F ^ 0x49 ^ 0x6E ^ 0x1C);
    llllIlIlll[22] = (0xBE ^ 0xAB);
    llllIlIlll[23] = (-(0xDEAF & 0x79D9) & 0xDBDF & 0x7FFE);
    llllIlIlll[24] = (0x11 ^ 0x7);
    llllIlIlll[25] = (-(0xC49F & 0x7F7F) & 0xC5FF & 0x7FFE);
    llllIlIlll[26] = (43 + 100 - 141 + 167 ^ 56 + '' - 153 + 155);
    llllIlIlll[27] = (13 + 96 - 91 + 169 ^ 54 + 125 - 161 + 145);
    llllIlIlll[28] = (0x6C ^ 0x75);
    llllIlIlll[29] = (0x12 ^ 0x33 ^ 0x39 ^ 0x2);
    llllIlIlll[30] = (0x5A ^ 0x49 ^ 0x87 ^ 0x8F);
    llllIlIlll[31] = (0x1B ^ 0x7);
    llllIlIlll[32] = (0x8C ^ 0xA0 ^ 0x79 ^ 0x48);
    llllIlIlll[33] = (0x49 ^ 0x57);
    llllIlIlll[34] = (104 + 123 - 142 + 136 ^ 11 + '§' - 63 + 79);
    llllIlIlll[35] = (123 + 21 - 20 + 7 ^ 37 + 29 - -20 + 77);
    llllIlIlll[36] = ('²' + 'ª' - 272 + 108 ^ 67 + 27 - 3 + 62);
    llllIlIlll[37] = (0x47 ^ 0x65);
    llllIlIlll[38] = ('' + 31 - 105 + 78 ^ '¨' + 25 - 131 + 119);
    llllIlIlll[39] = (0x16 ^ 0x32);
    llllIlIlll[40] = (0x1A ^ 0x3F);
    llllIlIlll[41] = (0x4 ^ 0x22);
  }
  
  private static String lIlllIIlIlII(String llllllllllllllllllIIlIIlIIllIlII, String llllllllllllllllllIIlIIlIIllIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllllIIlIIlIIllIlII = new String(Base64.getDecoder().decode(llllllllllllllllllIIlIIlIIllIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllIIlIIlIIllIIlI = new StringBuilder();
    char[] llllllllllllllllllIIlIIlIIllIIIl = llllllllllllllllllIIlIIlIIllIIll.toCharArray();
    int llllllllllllllllllIIlIIlIIllIIII = llllIlIlll[0];
    int llllllllllllllllllIIlIIlIIlIlIlI = llllllllllllllllllIIlIIlIIllIlII.toCharArray();
    byte llllllllllllllllllIIlIIlIIlIlIIl = llllllllllllllllllIIlIIlIIlIlIlI.length;
    Exception llllllllllllllllllIIlIIlIIlIlIII = llllIlIlll[0];
    while (llIIIIlIlIII(llllllllllllllllllIIlIIlIIlIlIII, llllllllllllllllllIIlIIlIIlIlIIl))
    {
      char llllllllllllllllllIIlIIlIIllIlIl = llllllllllllllllllIIlIIlIIlIlIlI[llllllllllllllllllIIlIIlIIlIlIII];
      "".length();
      "".length();
      if (((0x41 ^ 0x62) & (0x34 ^ 0x17 ^ 0xFFFFFFFF)) > (0x41 ^ 0x45)) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllllIIlIIlIIllIIlI);
  }
  
  private static boolean llIIIIlIIlll(int ???)
  {
    byte llllllllllllllllllIIlIIlIIIlllll;
    return ??? != 0;
  }
}

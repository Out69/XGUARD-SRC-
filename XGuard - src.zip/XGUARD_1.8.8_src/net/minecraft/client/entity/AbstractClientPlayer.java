package net.minecraft.client.entity;

import com.mojang.authlib.GameProfile;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.IImageBuffer;
import net.minecraft.client.renderer.ImageBufferDownload;
import net.minecraft.client.renderer.ThreadDownloadImageData;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import net.minecraft.util.StringUtils;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings.GameType;
import optfine.Config;
import optfine.Reflector;
import optfine.ReflectorMethod;
import org.apache.commons.io.FilenameUtils;

public abstract class AbstractClientPlayer
  extends EntityPlayer
{
  private static boolean lIllIllIIlllII(int ???)
  {
    byte llllllllllllllIllIllIlIlIlllIlll;
    return ??? > 0;
  }
  
  private static boolean lIllIllIIllIlI(int ???)
  {
    boolean llllllllllllllIllIllIlIlIllllIIl;
    return ??? == 0;
  }
  
  private static boolean lIllIllIIllIII(Object ???)
  {
    Exception llllllllllllllIllIllIlIlIlllllIl;
    return ??? == null;
  }
  
  public static ThreadDownloadImageData getDownloadImageSkin(ResourceLocation llllllllllllllIllIllIllIIIIlIllI, String llllllllllllllIllIllIllIIIIlIlIl)
  {
    ;
    ;
    ;
    ;
    TextureManager llllllllllllllIllIllIllIIIIlIlII = Minecraft.getMinecraft().getTextureManager();
    Object llllllllllllllIllIllIllIIIIlIIll = llllllllllllllIllIllIllIIIIlIlII.getTexture(llllllllllllllIllIllIllIIIIlIllI);
    if (lIllIllIIllIII(llllllllllllllIllIllIllIIIIlIIll))
    {
      llllllllllllllIllIllIllIIIIlIIll = new ThreadDownloadImageData(null, String.format(lllIllllIIlI[lllIllllIlIl[1]], new Object[] { StringUtils.stripControlCodes(llllllllllllllIllIllIllIIIIlIlIl) }), DefaultPlayerSkin.getDefaultSkin(getOfflineUUID(llllllllllllllIllIllIllIIIIlIlIl)), new ImageBufferDownload());
      "".length();
    }
    return (ThreadDownloadImageData)llllllllllllllIllIllIllIIIIlIIll;
  }
  
  public static ResourceLocation getLocationSkin(String llllllllllllllIllIllIllIIIIIllIl)
  {
    ;
    return new ResourceLocation(String.valueOf(new StringBuilder(lllIllllIIlI[lllIllllIlIl[0]]).append(StringUtils.stripControlCodes(llllllllllllllIllIllIllIIIIIllII))));
  }
  
  private static boolean lIllIllIIlIllI(Object ???)
  {
    boolean llllllllllllllIllIllIlIllIIIIIll;
    return ??? != null;
  }
  
  private void downloadCape(String llllllllllllllIllIllIlIllllIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIllIllIIlIllI(llllllllllllllIllIllIlIllllIllII)) && (lIllIllIIllIlI(llllllllllllllIllIllIlIllllIllII.isEmpty())))
    {
      llllllllllllllIllIllIlIllllIllII = StringUtils.stripControlCodes(llllllllllllllIllIllIlIllllIllII);
      String llllllllllllllIllIllIlIllllIlIll = String.valueOf(new StringBuilder(lllIllllIIlI[lllIllllIlIl[2]]).append(llllllllllllllIllIllIlIllllIllII).append(lllIllllIIlI[lllIllllIlIl[3]]));
      String llllllllllllllIllIllIlIllllIlIlI = FilenameUtils.getBaseName(llllllllllllllIllIllIlIllllIlIll);
      final ResourceLocation llllllllllllllIllIllIlIllllIlIIl = new ResourceLocation(String.valueOf(new StringBuilder(lllIllllIIlI[lllIllllIlIl[4]]).append(llllllllllllllIllIllIlIllllIlIlI)));
      TextureManager llllllllllllllIllIllIlIllllIlIII = Minecraft.getMinecraft().getTextureManager();
      ITextureObject llllllllllllllIllIllIlIllllIIlll = llllllllllllllIllIllIlIllllIlIII.getTexture(llllllllllllllIllIllIlIllllIlIIl);
      if (lIllIllIIlIlll(llllllllllllllIllIllIlIllllIllII, getMinecraftsession.getUsername())) {
        llllllllllllllIllIllIlIllllIlIll = lllIllllIIlI[lllIllllIlIl[5]];
      }
      if ((lIllIllIIlIllI(llllllllllllllIllIllIlIllllIIlll)) && (lIllIllIIllIIl(llllllllllllllIllIllIlIllllIIlll instanceof ThreadDownloadImageData)))
      {
        ThreadDownloadImageData llllllllllllllIllIllIlIllllIIllI = (ThreadDownloadImageData)llllllllllllllIllIllIlIllllIIlll;
        if (lIllIllIIlIllI(imageFound))
        {
          if (lIllIllIIllIIl(imageFound.booleanValue())) {
            ofLocationCape = llllllllllllllIllIllIlIllllIlIIl;
          }
          return;
        }
      }
      IImageBuffer llllllllllllllIllIllIlIllllIIlIl = new IImageBuffer()
      {
        public void skinAvailable()
        {
          ;
          ofLocationCape = llllllllllllllIllIllIlIllllIlIIl;
        }
        
        public BufferedImage parseUserSkin(BufferedImage llllllllllllllllIIIlIllIIIIIIlll)
        {
          ;
          ;
          return AbstractClientPlayer.this.parseCape(llllllllllllllllIIIlIllIIIIIIlll);
        }
      };
      ThreadDownloadImageData llllllllllllllIllIllIlIllllIIlII = new ThreadDownloadImageData(null, llllllllllllllIllIllIlIllllIlIll, null, llllllllllllllIllIllIlIllllIIlIl);
      "".length();
    }
  }
  
  private static boolean lIllIllIIlIlll(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllIllIllIlIlIlllllll;
    return ??? == localObject;
  }
  
  protected NetworkPlayerInfo getPlayerInfo()
  {
    ;
    if (lIllIllIIllIII(playerInfo)) {
      playerInfo = Minecraft.getMinecraft().getNetHandler().getPlayerInfo(llllllllllllllIllIllIllIIIlIllIl.getUniqueID());
    }
    return playerInfo;
  }
  
  public String getSkinType()
  {
    ;
    ;
    NetworkPlayerInfo llllllllllllllIllIllIllIIIIIlIII = llllllllllllllIllIllIllIIIIIlIIl.getPlayerInfo();
    if (lIllIllIIllIII(llllllllllllllIllIllIllIIIIIlIII))
    {
      "".length();
      if (" ".length() > 0) {
        break label39;
      }
      return null;
    }
    label39:
    return llllllllllllllIllIllIllIIIIIlIII.getSkinType();
  }
  
  private static boolean lIllIllIIllIIl(int ???)
  {
    boolean llllllllllllllIllIllIlIlIllllIll;
    return ??? != 0;
  }
  
  static
  {
    lIllIllIIlIlIl();
    lIllIllIIlIIIl();
  }
  
  public float getFovModifier()
  {
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIllIllIlIlllllllll = 1.0F;
    if (lIllIllIIllIIl(capabilities.isFlying)) {
      llllllllllllllIllIllIlIlllllllll *= 1.1F;
    }
    IAttributeInstance llllllllllllllIllIllIlIllllllllI = llllllllllllllIllIllIlIllllllIll.getEntityAttribute(SharedMonsterAttributes.movementSpeed);
    llllllllllllllIllIllIlIlllllllll = (float)(llllllllllllllIllIllIlIlllllllll * ((llllllllllllllIllIllIlIllllllllI.getAttributeValue() / capabilities.getWalkSpeed() + 1.0D) / 2.0D));
    if ((!lIllIllIIllIIl(lIllIllIIllIll(capabilities.getWalkSpeed(), 0.0F))) || (!lIllIllIIllIlI(Float.isNaN(llllllllllllllIllIllIlIlllllllll))) || (lIllIllIIllIIl(Float.isInfinite(llllllllllllllIllIllIlIlllllllll)))) {
      llllllllllllllIllIllIlIlllllllll = 1.0F;
    }
    if ((lIllIllIIllIIl(llllllllllllllIllIllIlIllllllIll.isUsingItem())) && (lIllIllIIlIlll(llllllllllllllIllIllIlIllllllIll.getItemInUse().getItem(), Items.bow)))
    {
      int llllllllllllllIllIllIlIlllllllIl = llllllllllllllIllIllIlIllllllIll.getItemInUseDuration();
      float llllllllllllllIllIllIlIlllllllII = llllllllllllllIllIllIlIlllllllIl / 20.0F;
      if (lIllIllIIlllII(lIllIllIIllIll(llllllllllllllIllIllIlIlllllllII, 1.0F)))
      {
        llllllllllllllIllIllIlIlllllllII = 1.0F;
        "".length();
        if (-"   ".length() > 0) {
          return 0.0F;
        }
      }
      else
      {
        llllllllllllllIllIllIlIlllllllII *= llllllllllllllIllIllIlIlllllllII;
      }
      llllllllllllllIllIllIlIlllllllll *= (1.0F - llllllllllllllIllIllIlIlllllllII * 0.15F);
    }
    if (lIllIllIIllIIl(Reflector.ForgeHooksClient_getOffsetFOV.exists()))
    {
      "".length();
      if (-"   ".length() < 0) {
        break label248;
      }
      return 0.0F;
    }
    label248:
    return llllllllllllllIllIllIlIlllllllll;
  }
  
  private static boolean lIllIllIIlllIl(int ???, int arg1)
  {
    int i;
    double llllllllllllllIllIllIlIllIIIlIIl;
    return ??? >= i;
  }
  
  private static boolean lIllIllIIllllI(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIllIllIlIllIIIIlIl;
    return ??? < i;
  }
  
  private static String lIllIllIIIlllI(String llllllllllllllIllIllIlIllIlIIIlI, String llllllllllllllIllIllIlIllIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIllIlIllIlIIIlI = new String(Base64.getDecoder().decode(llllllllllllllIllIllIlIllIlIIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIllIllIlIllIlIIlIl = new StringBuilder();
    char[] llllllllllllllIllIllIlIllIlIIlII = llllllllllllllIllIllIlIllIlIIIIl.toCharArray();
    int llllllllllllllIllIllIlIllIlIIIll = lllIllllIlIl[1];
    byte llllllllllllllIllIllIlIllIIlllIl = llllllllllllllIllIllIlIllIlIIIlI.toCharArray();
    double llllllllllllllIllIllIlIllIIlllII = llllllllllllllIllIllIlIllIIlllIl.length;
    char llllllllllllllIllIllIlIllIIllIll = lllIllllIlIl[1];
    while (lIllIllIIllllI(llllllllllllllIllIllIlIllIIllIll, llllllllllllllIllIllIlIllIIlllII))
    {
      char llllllllllllllIllIllIlIllIlIlIII = llllllllllllllIllIllIlIllIIlllIl[llllllllllllllIllIllIlIllIIllIll];
      "".length();
      "".length();
      if ("   ".length() < -" ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIllIllIlIllIlIIlIl);
  }
  
  private static int lIllIllIIllIll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static void lIllIllIIlIlIl()
  {
    lllIllllIlIl = new int[11];
    lllIllllIlIl[0] = " ".length();
    lllIllllIlIl[1] = ((0x51 ^ 0x36 ^ 0x7F ^ 0x53) & (0x9A ^ 0x93 ^ 0x53 ^ 0x11 ^ -" ".length()));
    lllIllllIlIl[2] = "  ".length();
    lllIllllIlIl[3] = "   ".length();
    lllIllllIlIl[4] = (0xCC ^ 0x96 ^ 0x5E ^ 0x0);
    lllIllllIlIl[5] = (0x5F ^ 0x5A);
    lllIllllIlIl[6] = (0xDD ^ 0x9D);
    lllIllllIlIl[7] = (0x63 ^ 0x6F ^ 0xA9 ^ 0x85);
    lllIllllIlIl[8] = (0xC3 ^ 0xC4 ^ " ".length());
    lllIllllIlIl[9] = (0x68 ^ 0x6F);
    lllIllllIlIl[10] = (0x37 ^ 0x3F);
  }
  
  public ResourceLocation getLocationCape()
  {
    ;
    ;
    if (lIllIllIIllIlI(Config.isShowCapes())) {
      return null;
    }
    if (lIllIllIIlIllI(ofLocationCape)) {
      return ofLocationCape;
    }
    NetworkPlayerInfo llllllllllllllIllIllIllIIIIlllIl = llllllllllllllIllIllIllIIIIllllI.getPlayerInfo();
    if (lIllIllIIllIII(llllllllllllllIllIllIllIIIIlllIl))
    {
      "".length();
      if (null == null) {
        break label55;
      }
      return null;
    }
    label55:
    return llllllllllllllIllIllIllIIIIlllIl.getLocationCape();
  }
  
  public boolean hasPlayerInfo()
  {
    ;
    if (lIllIllIIlIllI(llllllllllllllIllIllIllIIIllIIIl.getPlayerInfo())) {
      return lllIllllIlIl[0];
    }
    return lllIllllIlIl[1];
  }
  
  public ResourceLocation getLocationSkin()
  {
    ;
    ;
    NetworkPlayerInfo llllllllllllllIllIllIllIIIlIIIll = llllllllllllllIllIllIllIIIlIIIlI.getPlayerInfo();
    if (lIllIllIIllIII(llllllllllllllIllIllIllIIIlIIIll))
    {
      "".length();
      if (-" ".length() >= -" ".length()) {
        break label46;
      }
      return null;
    }
    label46:
    return llllllllllllllIllIllIllIIIlIIIll.getLocationSkin();
  }
  
  private static void lIllIllIIlIIIl()
  {
    lllIllllIIlI = new String[lllIllllIlIl[9]];
    lllIllllIIlI[lllIllllIlIl[1]] = lIllIllIIIlIlI("EeX0pMEEzR8tmutMbKFazzBZbg25mJdBI5dm6roNQn4CwJviLHtYXCpa+OwVHRs6G8gIUrzADPw=", "nEcWw");
    lllIllllIIlI[lllIllllIlIl[0]] = lIllIllIIIlllI("AQYOIxZd", "rmgMe");
    lllIllllIIlI[lllIllllIlIl[2]] = lIllIllIIIlIlI("8yEJ95epTosf8W6ZvzBluD+8EtQwHFGBQu9y5ZfbWCI=", "kVuyG");
    lllIllllIIlI[lllIllllIlIl[3]] = lIllIllIIIlIlI("uu0lXtP9Qnw=", "aLDqN");
    lllIllllIIlI[lllIllllIlIl[4]] = lIllIllIIIlllI("CxkyFCkOVw==", "hxBqF");
    lllIllllIIlI[lllIllllIlIl[5]] = lIllIllIIIlIlI("G27fQfSoSNkC56g9ETT7+DfPyW/vRxdw/PZeNJywioN0h1nzLR3Jdw==", "aCsVb");
    lllIllllIIlI[lllIllllIlIl[8]] = lIllIllIIlIIII("Aqqn/Bto7pTNm9rAsJFIAg==", "qnwRG");
  }
  
  public AbstractClientPlayer(World llllllllllllllIllIllIllIIIlllIll, GameProfile llllllllllllllIllIllIllIIIlllIlI)
  {
    llllllllllllllIllIllIllIIIllllII.<init>(llllllllllllllIllIllIllIIIllllll, llllllllllllllIllIllIllIIIlllIlI);
    String llllllllllllllIllIllIllIIIllllIl = llllllllllllllIllIllIllIIIlllIlI.getName();
    llllllllllllllIllIllIllIIIllllII.downloadCape(llllllllllllllIllIllIllIIIllllIl);
    "".length();
  }
  
  private static String lIllIllIIIlIlI(String llllllllllllllIllIllIlIllIllIlIl, String llllllllllllllIllIllIlIllIllIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIllIlIllIlllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIllIlIllIllIllI.getBytes(StandardCharsets.UTF_8)), lllIllllIlIl[10]), "DES");
      Cipher llllllllllllllIllIllIlIllIlllIIl = Cipher.getInstance("DES");
      llllllllllllllIllIllIlIllIlllIIl.init(lllIllllIlIl[2], llllllllllllllIllIllIlIllIlllIlI);
      return new String(llllllllllllllIllIllIlIllIlllIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIllIlIllIllIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIllIlIllIlllIII)
    {
      llllllllllllllIllIllIlIllIlllIII.printStackTrace();
    }
    return null;
  }
  
  private static String lIllIllIIlIIII(String llllllllllllllIllIllIlIllIIlIIII, String llllllllllllllIllIllIlIllIIIllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIllIlIllIIlIlIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIllIlIllIIIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIllIllIlIllIIlIlII = Cipher.getInstance("Blowfish");
      llllllllllllllIllIllIlIllIIlIlII.init(lllIllllIlIl[2], llllllllllllllIllIllIlIllIIlIlIl);
      return new String(llllllllllllllIllIllIlIllIIlIlII.doFinal(Base64.getDecoder().decode(llllllllllllllIllIllIlIllIIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIllIlIllIIlIIll)
    {
      llllllllllllllIllIllIlIllIIlIIll.printStackTrace();
    }
    return null;
  }
  
  public boolean hasSkin()
  {
    ;
    ;
    NetworkPlayerInfo llllllllllllllIllIllIllIIIlIlIIl = llllllllllllllIllIllIllIIIlIlIII.getPlayerInfo();
    if ((lIllIllIIlIllI(llllllllllllllIllIllIllIIIlIlIIl)) && (lIllIllIIllIIl(llllllllllllllIllIllIllIIIlIlIIl.hasLocationSkin()))) {
      return lllIllllIlIl[0];
    }
    return lllIllllIlIl[1];
  }
  
  public boolean isSpectator()
  {
    ;
    ;
    NetworkPlayerInfo llllllllllllllIllIllIllIIIllIlIl = Minecraft.getMinecraft().getNetHandler().getPlayerInfo(llllllllllllllIllIllIllIIIllIlII.getGameProfile().getId());
    if ((lIllIllIIlIllI(llllllllllllllIllIllIllIIIllIlIl)) && (lIllIllIIlIlll(llllllllllllllIllIllIllIIIllIlIl.getGameType(), WorldSettings.GameType.SPECTATOR))) {
      return lllIllllIlIl[0];
    }
    return lllIllllIlIl[1];
  }
  
  private BufferedImage parseCape(BufferedImage llllllllllllllIllIllIlIlllIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIllIllIlIlllIlIIlI = lllIllllIlIl[6];
    int llllllllllllllIllIllIlIlllIlIIIl = lllIllllIlIl[7];
    int llllllllllllllIllIllIlIlllIlIIII = llllllllllllllIllIllIlIlllIIllII.getWidth();
    int llllllllllllllIllIllIlIlllIIllll = llllllllllllllIllIllIlIlllIIllII.getHeight();
    "".length();
    if (null != null) {
      return null;
    }
    while ((!lIllIllIIlllIl(llllllllllllllIllIllIlIlllIlIIlI, llllllllllllllIllIllIlIlllIlIIII)) || (!lIllIllIIlllIl(llllllllllllllIllIllIlIlllIlIIIl, llllllllllllllIllIllIlIlllIIllll)))
    {
      llllllllllllllIllIllIlIlllIlIIlI *= lllIllllIlIl[2];
      llllllllllllllIllIllIlIlllIlIIIl *= lllIllllIlIl[2];
    }
    BufferedImage llllllllllllllIllIllIlIlllIIlllI = new BufferedImage(llllllllllllllIllIllIlIlllIlIIlI, llllllllllllllIllIllIlIlllIlIIIl, lllIllllIlIl[2]);
    Graphics llllllllllllllIllIllIlIlllIIllIl = llllllllllllllIllIllIlIlllIIlllI.getGraphics();
    "".length();
    llllllllllllllIllIllIlIlllIIllIl.dispose();
    return llllllllllllllIllIllIlIlllIIlllI;
  }
}

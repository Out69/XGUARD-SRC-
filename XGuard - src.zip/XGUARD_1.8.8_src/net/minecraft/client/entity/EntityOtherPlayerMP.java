package net.minecraft.client.entity;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;

public class EntityOtherPlayerMP
  extends AbstractClientPlayer
{
  private static boolean lIIlIIIlIllll(int ???)
  {
    long llllllllllllllllIllIllIIlIIlIIlI;
    return ??? < 0;
  }
  
  public void onLivingUpdate()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIlIIIlIIllI(otherPlayerMPPosRotationIncrements))
    {
      double llllllllllllllllIllIllIIlIlllIlI = posX + (otherPlayerMPX - posX) / otherPlayerMPPosRotationIncrements;
      double llllllllllllllllIllIllIIlIlllIIl = posY + (otherPlayerMPY - posY) / otherPlayerMPPosRotationIncrements;
      double llllllllllllllllIllIllIIlIlllIII = posZ + (otherPlayerMPZ - posZ) / otherPlayerMPPosRotationIncrements;
      double llllllllllllllllIllIllIIlIllIlll = otherPlayerMPYaw - rotationYaw;
      "".length();
      if (((" ".length() ^ 0x3A ^ 0x31) & (0xC5 ^ 0x8B ^ 0x10 ^ 0x54 ^ -" ".length())) > "   ".length()) {
        return;
      }
      while (!lIIlIIIlIlllI(lIIlIIIlIlIlI(llllllllllllllllIllIllIIlIllIlll, -180.0D))) {
        llllllllllllllllIllIllIIlIllIlll += 360.0D;
      }
      "".length();
      if ((31 + '¢' - 141 + 119 ^ 125 + 9 - 24 + 64) == 0) {
        return;
      }
      while (!lIIlIIIlIllll(lIIlIIIlIlIll(llllllllllllllllIllIllIIlIllIlll, 180.0D))) {
        llllllllllllllllIllIllIIlIllIlll -= 360.0D;
      }
      rotationYaw = ((float)(rotationYaw + llllllllllllllllIllIllIIlIllIlll / otherPlayerMPPosRotationIncrements));
      rotationPitch = ((float)(rotationPitch + (otherPlayerMPPitch - rotationPitch) / otherPlayerMPPosRotationIncrements));
      otherPlayerMPPosRotationIncrements -= lIllllIIllI[0];
      llllllllllllllllIllIllIIlIlllIll.setPosition(llllllllllllllllIllIllIIlIlllIlI, llllllllllllllllIllIllIIlIlllIIl, llllllllllllllllIllIllIIlIlllIII);
      llllllllllllllllIllIllIIlIlllIll.setRotation(rotationYaw, rotationPitch);
    }
    prevCameraYaw = cameraYaw;
    llllllllllllllllIllIllIIlIlllIll.updateArmSwingProgress();
    float llllllllllllllllIllIllIIlIllIllI = MathHelper.sqrt_double(motionX * motionX + motionZ * motionZ);
    float llllllllllllllllIllIllIIlIllIlIl = (float)Math.atan(-motionY * 0.20000000298023224D) * 15.0F;
    if (lIIlIIIlIIllI(lIIlIIIlIllII(llllllllllllllllIllIllIIlIllIllI, 0.1F))) {
      llllllllllllllllIllIllIIlIllIllI = 0.1F;
    }
    if ((!lIIlIIIlIlIII(onGround)) || (lIIlIIIllIIII(lIIlIIIlIllIl(llllllllllllllllIllIllIIlIlllIll.getHealth(), 0.0F)))) {
      llllllllllllllllIllIllIIlIllIllI = 0.0F;
    }
    if ((!lIIlIIIlIIlll(onGround)) || (lIIlIIIllIIII(lIIlIIIlIllIl(llllllllllllllllIllIllIIlIlllIll.getHealth(), 0.0F)))) {
      llllllllllllllllIllIllIIlIllIlIl = 0.0F;
    }
    cameraYaw += (llllllllllllllllIllIllIIlIllIllI - cameraYaw) * 0.4F;
    cameraPitch += (llllllllllllllllIllIllIIlIllIlIl - cameraPitch) * 0.8F;
  }
  
  private static void lIIlIIIlIIlII()
  {
    lIllllIIllI = new int[2];
    lIllllIIllI[0] = " ".length();
    lIllllIIllI[1] = ((0x22 ^ 0x12) & (0x92 ^ 0xA2 ^ 0xFFFFFFFF));
  }
  
  private static int lIIlIIIlIlIlI(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public boolean attackEntityFrom(DamageSource llllllllllllllllIllIllIIlllIlIII, float llllllllllllllllIllIllIIlllIIlll)
  {
    return lIllllIIllI[0];
  }
  
  private static boolean lIIlIIIlIlIIl(Object ???)
  {
    float llllllllllllllllIllIllIIlIIllIlI;
    return ??? != null;
  }
  
  public boolean canCommandSenderUseCommand(int llllllllllllllllIllIllIIlIlIIIII, String llllllllllllllllIllIllIIlIIlllll)
  {
    return lIllllIIllI[1];
  }
  
  private static boolean lIIlIIIlIIllI(int ???)
  {
    Exception llllllllllllllllIllIllIIlIIIlllI;
    return ??? > 0;
  }
  
  public void setCurrentItemOrArmor(int llllllllllllllllIllIllIIlIlIIlll, ItemStack llllllllllllllllIllIllIIlIlIIllI)
  {
    ;
    ;
    ;
    if (lIIlIIIlIIlll(llllllllllllllllIllIllIIlIlIIlll))
    {
      inventory.mainInventory[inventory.currentItem] = llllllllllllllllIllIllIIlIlIIllI;
      "".length();
      if (-" ".length() <= " ".length()) {}
    }
    else
    {
      inventory.armorInventory[(llllllllllllllllIllIllIIlIlIlIlI - lIllllIIllI[0])] = llllllllllllllllIllIllIIlIlIIllI;
    }
  }
  
  public EntityOtherPlayerMP(World llllllllllllllllIllIllIIlllIlIll, GameProfile llllllllllllllllIllIllIIlllIlIlI)
  {
    llllllllllllllllIllIllIIlllIllll.<init>(llllllllllllllllIllIllIIlllIlllI, llllllllllllllllIllIllIIlllIlIlI);
    stepHeight = 0.0F;
    noClip = lIllllIIllI[0];
    renderOffsetY = 0.25F;
    renderDistanceWeight = 10.0D;
  }
  
  private static boolean lIIlIIIlIIlll(int ???)
  {
    short llllllllllllllllIllIllIIlIIlIllI;
    return ??? == 0;
  }
  
  static {}
  
  public void addChatMessage(IChatComponent llllllllllllllllIllIllIIlIlIIIlI)
  {
    ;
    getMinecraftingameGUI.getChatGUI().printChatMessage(llllllllllllllllIllIllIIlIlIIIll);
  }
  
  private static boolean lIIlIIIlIlIII(int ???)
  {
    String llllllllllllllllIllIllIIlIIllIII;
    return ??? != 0;
  }
  
  private static int lIIlIIIlIllII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIIlIIIllIIII(int ???)
  {
    int llllllllllllllllIllIllIIlIIlIIII;
    return ??? <= 0;
  }
  
  public void onUpdate()
  {
    ;
    ;
    ;
    ;
    ;
    renderOffsetY = 0.0F;
    llllllllllllllllIllIllIIllIIlIll.onUpdate();
    prevLimbSwingAmount = limbSwingAmount;
    double llllllllllllllllIllIllIIllIIlIlI = posX - prevPosX;
    double llllllllllllllllIllIllIIllIIlIIl = posZ - prevPosZ;
    float llllllllllllllllIllIllIIllIIlIII = MathHelper.sqrt_double(llllllllllllllllIllIllIIllIIlIlI * llllllllllllllllIllIllIIllIIlIlI + llllllllllllllllIllIllIIllIIlIIl * llllllllllllllllIllIllIIllIIlIIl) * 4.0F;
    if (lIIlIIIlIIllI(lIIlIIIlIIlIl(llllllllllllllllIllIllIIllIIlIII, 1.0F))) {
      llllllllllllllllIllIllIIllIIlIII = 1.0F;
    }
    limbSwingAmount += (llllllllllllllllIllIllIIllIIlIII - limbSwingAmount) * 0.4F;
    limbSwing += limbSwingAmount;
    if ((lIIlIIIlIIlll(isItemInUse)) && (lIIlIIIlIlIII(llllllllllllllllIllIllIIllIIlIll.isEating())) && (lIIlIIIlIlIIl(inventory.mainInventory[inventory.currentItem])))
    {
      ItemStack llllllllllllllllIllIllIIllIIIlll = inventory.mainInventory[inventory.currentItem];
      llllllllllllllllIllIllIIllIIlIll.setItemInUse(inventory.mainInventory[inventory.currentItem], llllllllllllllllIllIllIIllIIIlll.getItem().getMaxItemUseDuration(llllllllllllllllIllIllIIllIIIlll));
      isItemInUse = lIllllIIllI[0];
      "".length();
      if (-"  ".length() <= 0) {}
    }
    else if ((lIIlIIIlIlIII(isItemInUse)) && (lIIlIIIlIIlll(llllllllllllllllIllIllIIllIIlIll.isEating())))
    {
      llllllllllllllllIllIllIIllIIlIll.clearItemInUse();
      isItemInUse = lIllllIIllI[1];
    }
  }
  
  public void setPositionAndRotation2(double llllllllllllllllIllIllIIllIllllI, double llllllllllllllllIllIllIIllIlllIl, double llllllllllllllllIllIllIIllIlllII, float llllllllllllllllIllIllIIllIllIll, float llllllllllllllllIllIllIIllIlIIlI, int llllllllllllllllIllIllIIllIllIIl, boolean llllllllllllllllIllIllIIllIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    otherPlayerMPX = llllllllllllllllIllIllIIllIllllI;
    otherPlayerMPY = llllllllllllllllIllIllIIllIlllIl;
    otherPlayerMPZ = llllllllllllllllIllIllIIllIlllII;
    otherPlayerMPYaw = llllllllllllllllIllIllIIllIllIll;
    otherPlayerMPPitch = llllllllllllllllIllIllIIllIlIIlI;
    otherPlayerMPPosRotationIncrements = llllllllllllllllIllIllIIllIllIIl;
  }
  
  private static int lIIlIIIlIIlIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIIlIIIlIlllI(int ???)
  {
    short llllllllllllllllIllIllIIlIIlIlII;
    return ??? >= 0;
  }
  
  public BlockPos getPosition()
  {
    ;
    return new BlockPos(posX + 0.5D, posY + 0.5D, posZ + 0.5D);
  }
  
  private static int lIIlIIIlIlIll(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static int lIIlIIIlIllIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
}

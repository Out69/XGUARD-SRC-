package net.minecraft.client.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.MovingSoundMinecartRiding;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.gui.GuiCommandBlock;
import net.minecraft.client.gui.GuiEnchantment;
import net.minecraft.client.gui.GuiHopper;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiMerchant;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.GuiRepair;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenBook;
import net.minecraft.client.gui.inventory.GuiBeacon;
import net.minecraft.client.gui.inventory.GuiBrewingStand;
import net.minecraft.client.gui.inventory.GuiChest;
import net.minecraft.client.gui.inventory.GuiCrafting;
import net.minecraft.client.gui.inventory.GuiDispenser;
import net.minecraft.client.gui.inventory.GuiEditSign;
import net.minecraft.client.gui.inventory.GuiFurnace;
import net.minecraft.client.gui.inventory.GuiScreenHorseInventory;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.particle.EffectRenderer;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.command.server.CommandBlockLogic;
import net.minecraft.entity.Entity;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.init.Items;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C01PacketChatMessage;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C03PacketPlayer.C04PacketPlayerPosition;
import net.minecraft.network.play.client.C03PacketPlayer.C05PacketPlayerLook;
import net.minecraft.network.play.client.C03PacketPlayer.C06PacketPlayerPosLook;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C07PacketPlayerDigging.Action;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.client.C0BPacketEntityAction.Action;
import net.minecraft.network.play.client.C0CPacketInput;
import net.minecraft.network.play.client.C0DPacketCloseWindow;
import net.minecraft.network.play.client.C13PacketPlayerAbilities;
import net.minecraft.network.play.client.C16PacketClientStatus;
import net.minecraft.network.play.client.C16PacketClientStatus.EnumState;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatFileWriter;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.FoodStats;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MovementInput;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.IInteractionObject;
import net.minecraft.world.World;
import pl.xguard.modules.SprintModule;

public class EntityPlayerSP
  extends AbstractClientPlayer
{
  public boolean isSneaking()
  {
    ;
    ;
    if (lIIIllllIlIIl(movementInput))
    {
      "".length();
      if (((0xE4 ^ 0xB0 ^ 0x6F ^ 0x37) & (0x72 ^ 0x2F ^ 0xD5 ^ 0x84 ^ -" ".length())) != -" ".length()) {
        break label118;
      }
      return (0x67 ^ 0x79 ^ 0xAA ^ 0x91) & (74 + 124 - 127 + 158 ^ '¢' + 39 - 124 + 115 ^ -" ".length());
    }
    label118:
    boolean llllllllllllllllIlllIIIIIIlIIIIl = lIlllIlIllI[0];
    if ((lIIIllllIIIII(llllllllllllllllIlllIIIIIIlIIIIl)) && (lIIIllllIIlIl(sleeping))) {
      return lIlllIlIllI[2];
    }
    return lIlllIlIllI[0];
  }
  
  private static int lIIIllllIIIIl(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean lIIIllllIIllI(Object ???)
  {
    boolean llllllllllllllllIllIlllllIlIllII;
    return ??? == null;
  }
  
  protected void damageEntity(DamageSource llllllllllllllllIlllIIIIllllIIll, float llllllllllllllllIlllIIIIllllIlIl)
  {
    ;
    ;
    ;
    if (lIIIllllIIlIl(llllllllllllllllIlllIIIIllllIlII.isEntityInvulnerable(llllllllllllllllIlllIIIIllllIllI))) {
      llllllllllllllllIlllIIIIllllIlII.setHealth(llllllllllllllllIlllIIIIllllIlII.getHealth() - llllllllllllllllIlllIIIIllllIlIl);
    }
  }
  
  private static boolean lIIIllllIIIII(int ???)
  {
    Exception llllllllllllllllIllIlllllIlIlIlI;
    return ??? != 0;
  }
  
  private static boolean lIIIllllIllll(int ???)
  {
    long llllllllllllllllIllIlllllIlIIIII;
    return ??? > 0;
  }
  
  public void closeScreenAndDropStack()
  {
    ;
    inventory.setItemStack(null);
    llllllllllllllllIlllIIIIlllIllIl.closeScreen();
    mc.displayGuiScreen(null);
  }
  
  public void onEnchantmentCritical(Entity llllllllllllllllIlllIIIIIIlIIlll)
  {
    ;
    ;
    mc.effectRenderer.emitParticleAtEntity(llllllllllllllllIlllIIIIIIlIIlll, EnumParticleTypes.CRIT_MAGIC);
  }
  
  public void setXPStats(float llllllllllllllllIlllIIIIlIIIlIlI, int llllllllllllllllIlllIIIIlIIIllIl, int llllllllllllllllIlllIIIIlIIIllII)
  {
    ;
    ;
    ;
    ;
    experience = llllllllllllllllIlllIIIIlIIIlIlI;
    experienceTotal = llllllllllllllllIlllIIIIlIIIllIl;
    experienceLevel = llllllllllllllllIlllIIIIlIIIllII;
  }
  
  public StatFileWriter getStatFileWriter()
  {
    ;
    return statWriter;
  }
  
  public void openEditCommandBlock(CommandBlockLogic llllllllllllllllIlllIIIIIlIlllIl)
  {
    ;
    ;
    mc.displayGuiScreen(new GuiCommandBlock(llllllllllllllllIlllIIIIIlIlllIl));
  }
  
  public void heal(float llllllllllllllllIlllIIIlIIlllIIl) {}
  
  public float getHorseJumpPower()
  {
    ;
    return horseJumpPower;
  }
  
  public void sendChatMessage(String llllllllllllllllIlllIIIlIIIIIIIl)
  {
    ;
    ;
    sendQueue.addToSendQueue(new C01PacketChatMessage(llllllllllllllllIlllIIIlIIIIIIIl));
  }
  
  public void updateEntityActionState()
  {
    ;
    llllllllllllllllIlllIIIIIIIlllIl.updateEntityActionState();
    if (lIIIllllIIIII(llllllllllllllllIlllIIIIIIIlllII.isCurrentViewEntity()))
    {
      moveStrafing = movementInput.moveStrafe;
      moveForward = movementInput.moveForward;
      isJumping = movementInput.jump;
      prevRenderArmYaw = renderArmYaw;
      prevRenderArmPitch = renderArmPitch;
      renderArmPitch = ((float)(renderArmPitch + (rotationPitch - renderArmPitch) * 0.5D));
      renderArmYaw = ((float)(renderArmYaw + (rotationYaw - renderArmYaw) * 0.5D));
    }
  }
  
  public void onLivingUpdate()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    
    if (lIIIllllIllll(sprintingTicksLeft))
    {
      sprintingTicksLeft -= lIlllIlIllI[2];
      if (lIIIllllIIlIl(sprintingTicksLeft)) {
        llllllllllllllllIlllIIIIIIIlIIlI.setSprinting(lIlllIlIllI[0]);
      }
    }
    if (lIIIllllIllll(sprintToggleTimer)) {
      sprintToggleTimer -= lIlllIlIllI[2];
    }
    prevTimeInPortal = timeInPortal;
    if (lIIIllllIIIII(inPortal))
    {
      if ((lIIIllllIlIIl(mc.currentScreen)) && (lIIIllllIIlIl(mc.currentScreen.doesGuiPauseGame()))) {
        mc.displayGuiScreen(null);
      }
      if (lIIIllllIIlIl(lIIIllllIllIl(timeInPortal, 0.0F))) {
        mc.getSoundHandler().playSound(PositionedSoundRecord.create(new ResourceLocation(lIlllIlIIIl[lIlllIlIllI[14]]), rand.nextFloat() * 0.4F + 0.8F));
      }
      timeInPortal += 0.0125F;
      if (lIIIlllllIIII(lIIIllllIllIl(timeInPortal, 1.0F))) {
        timeInPortal = 1.0F;
      }
      inPortal = lIlllIlIllI[0];
      "".length();
      if ((80 + '¾' - 119 + 48 ^ 103 + 35 - 33 + 90) > 0) {}
    }
    else if ((lIIIllllIIIII(llllllllllllllllIlllIIIIIIIlIIlI.isPotionActive(Potion.confusion))) && (lIIIlllllIIIl(llllllllllllllllIlllIIIIIIIlIIlI.getActivePotionEffect(Potion.confusion).getDuration(), lIlllIlIllI[15])))
    {
      timeInPortal += 0.006666667F;
      if (lIIIllllIllll(lIIIllllIllIl(timeInPortal, 1.0F)))
      {
        timeInPortal = 1.0F;
        "".length();
        if (((16 + 62 - 58 + 116 ^ 96 + 17 - 81 + 108) & (0x5F ^ 0x1B ^ 0xDF ^ 0x9F ^ -" ".length())) == 0) {}
      }
    }
    else
    {
      if (lIIIllllIllll(lIIIllllIllIl(timeInPortal, 0.0F))) {
        timeInPortal -= 0.05F;
      }
      if (lIIIllllIlIII(lIIIllllIlllI(timeInPortal, 0.0F))) {
        timeInPortal = 0.0F;
      }
    }
    if (lIIIllllIllll(timeUntilPortal)) {
      timeUntilPortal -= lIlllIlIllI[2];
    }
    boolean llllllllllllllllIlllIIIIIIIlIIIl = movementInput.jump;
    boolean llllllllllllllllIlllIIIIIIIlIIII = movementInput.sneak;
    float llllllllllllllllIlllIIIIIIIIllll = 0.8F;
    if (lIIIlllllIIII(lIIIllllIllIl(movementInput.moveForward, llllllllllllllllIlllIIIIIIIIllll)))
    {
      "".length();
      if (" ".length() >= " ".length()) {
        break label514;
      }
    }
    label514:
    boolean llllllllllllllllIlllIIIIIIIIlllI = lIlllIlIllI[0];
    movementInput.updatePlayerMoveState();
    if ((lIIIllllIIIII(llllllllllllllllIlllIIIIIIIlIIlI.isUsingItem())) && (lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIlIIlI.isRiding())))
    {
      movementInput.moveStrafe *= 0.2F;
      movementInput.moveForward *= 0.2F;
      sprintToggleTimer = lIlllIlIllI[0];
    }
    "".length();
    "".length();
    "".length();
    "".length();
    if ((lIIIllllIIIll(lIIIllllIllIl(llllllllllllllllIlllIIIIIIIlIIlI.getFoodStats().getFoodLevel(), 6.0F))) && (lIIIllllIIlIl(capabilities.allowFlying)))
    {
      "".length();
      if (-" ".length() < "   ".length()) {
        break label843;
      }
    }
    label843:
    boolean llllllllllllllllIlllIIIIIIIIllIl = lIlllIlIllI[2];
    if ((lIIIllllIIIII(onGround)) && (lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIlIIII)) && (lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIIlllI)) && (lIIIlllllIIII(lIIIllllIllIl(movementInput.moveForward, llllllllllllllllIlllIIIIIIIIllll))) && (lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIlIIlI.isSprinting())) && (lIIIllllIIIII(llllllllllllllllIlllIIIIIIIIllIl)) && (lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIlIIlI.isUsingItem())) && (lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIlIIlI.isPotionActive(Potion.blindness)))) {
      if ((lIIIllllIIIll(sprintToggleTimer)) && (lIIIllllIIlIl(mc.gameSettings.keyBindSprint.isKeyDown())))
      {
        sprintToggleTimer = lIlllIlIllI[11];
        "".length();
        if (" ".length() > 0) {}
      }
      else
      {
        llllllllllllllllIlllIIIIIIIlIIlI.setSprinting(lIlllIlIllI[2]);
      }
    }
    if ((lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIlIIlI.isSprinting())) && (lIIIlllllIIII(lIIIllllIllIl(movementInput.moveForward, llllllllllllllllIlllIIIIIIIIllll))) && (lIIIllllIIIII(llllllllllllllllIlllIIIIIIIIllIl)) && (lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIlIIlI.isUsingItem())) && (lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIlIIlI.isPotionActive(Potion.blindness))) && (lIIIllllIIIII(mc.gameSettings.keyBindSprint.isKeyDown()))) {
      llllllllllllllllIlllIIIIIIIlIIlI.setSprinting(lIlllIlIllI[2]);
    }
    if ((lIIIllllIIIII(llllllllllllllllIlllIIIIIIIlIIlI.isSprinting())) && ((!lIIIlllllIIII(lIIIllllIlllI(movementInput.moveForward, llllllllllllllllIlllIIIIIIIIllll))) || (!lIIIllllIIlIl(isCollidedHorizontally)) || (lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIIllIl)))) {
      llllllllllllllllIlllIIIIIIIlIIlI.setSprinting(lIlllIlIllI[0]);
    }
    if (lIIIllllIIIII(capabilities.allowFlying)) {
      if (lIIIllllIIIII(mc.playerController.isSpectatorMode()))
      {
        if (lIIIllllIIlIl(capabilities.isFlying))
        {
          capabilities.isFlying = lIlllIlIllI[2];
          llllllllllllllllIlllIIIIIIIlIIlI.sendPlayerAbilities();
          "".length();
          if (((0x90 ^ 0xC1) & (0x4D ^ 0x1C ^ 0xFFFFFFFF)) == ((0xB7 ^ 0x97) & (0x4E ^ 0x6E ^ 0xFFFFFFFF))) {}
        }
      }
      else if ((lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIlIIIl)) && (lIIIllllIIIII(movementInput.jump))) {
        if (lIIIllllIIlIl(flyToggleTimer))
        {
          flyToggleTimer = lIlllIlIllI[11];
          "".length();
          if (null == null) {}
        }
        else
        {
          if (lIIIllllIIIII(capabilities.isFlying))
          {
            "".length();
            if (((0x62 ^ 0x79) & (0x25 ^ 0x3E ^ 0xFFFFFFFF)) < "   ".length()) {
              break label1336;
            }
          }
          label1336:
          lIlllIlIllI0isFlying = lIlllIlIllI[2];
          llllllllllllllllIlllIIIIIIIlIIlI.sendPlayerAbilities();
          flyToggleTimer = lIlllIlIllI[0];
        }
      }
    }
    if ((lIIIllllIIIII(capabilities.isFlying)) && (lIIIllllIIIII(llllllllllllllllIlllIIIIIIIlIIlI.isCurrentViewEntity())))
    {
      if (lIIIllllIIIII(movementInput.sneak)) {
        motionY -= capabilities.getFlySpeed() * 3.0F;
      }
      if (lIIIllllIIIII(movementInput.jump)) {
        motionY += capabilities.getFlySpeed() * 3.0F;
      }
    }
    if (lIIIllllIIIII(llllllllllllllllIlllIIIIIIIlIIlI.isRidingHorse()))
    {
      if (lIIIllllIlIII(horseJumpPowerCounter))
      {
        horseJumpPowerCounter += lIlllIlIllI[2];
        if (lIIIllllIIlIl(horseJumpPowerCounter)) {
          horseJumpPower = 0.0F;
        }
      }
      if ((lIIIllllIIIII(llllllllllllllllIlllIIIIIIIlIIIl)) && (lIIIllllIIlIl(movementInput.jump)))
      {
        horseJumpPowerCounter = lIlllIlIllI[16];
        llllllllllllllllIlllIIIIIIIlIIlI.sendHorseJump();
        "".length();
        if ("   ".length() >= -" ".length()) {}
      }
      else if ((lIIIllllIIlIl(llllllllllllllllIlllIIIIIIIlIIIl)) && (lIIIllllIIIII(movementInput.jump)))
      {
        horseJumpPowerCounter = lIlllIlIllI[0];
        horseJumpPower = 0.0F;
        "".length();
        if ("   ".length() > " ".length()) {}
      }
      else if (lIIIllllIIIII(llllllllllllllllIlllIIIIIIIlIIIl))
      {
        horseJumpPowerCounter += lIlllIlIllI[2];
        if (lIIIllllIIlII(horseJumpPowerCounter, lIlllIlIllI[4]))
        {
          horseJumpPower = (horseJumpPowerCounter * 0.1F);
          "".length();
          if (" ".length() <= "   ".length()) {}
        }
        else
        {
          horseJumpPower = (0.8F + 2.0F / (horseJumpPowerCounter - lIlllIlIllI[13]) * 0.1F);
          "".length();
          if ((0x75 ^ 0x2A ^ 0x7C ^ 0x27) > "   ".length()) {}
        }
      }
    }
    else
    {
      horseJumpPower = 0.0F;
    }
    llllllllllllllllIlllIIIIIIIlIIlI.onLivingUpdate();
    if ((lIIIllllIIIII(onGround)) && (lIIIllllIIIII(capabilities.isFlying)) && (lIIIllllIIlIl(mc.playerController.isSpectatorMode())))
    {
      capabilities.isFlying = lIlllIlIllI[0];
      llllllllllllllllIlllIIIIIIIlIIlI.sendPlayerAbilities();
    }
  }
  
  private static int lIIIllllIllIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void setSpeed(float llllllllllllllllIllIlllllllllIll)
  {
    ;
    ;
    motionX = (-(Math.sin(llllllllllllllllIllIllllllllllII.getDirection()) * llllllllllllllllIllIlllllllllIll));
    motionZ = (Math.cos(llllllllllllllllIllIllllllllllII.getDirection()) * llllllllllllllllIllIlllllllllIll);
  }
  
  private static boolean lIIIllllIlIII(int ???)
  {
    float llllllllllllllllIllIlllllIlIIlII;
    return ??? < 0;
  }
  
  public void onCriticalHit(Entity llllllllllllllllIlllIIIIIIlIllIl)
  {
    ;
    ;
    mc.effectRenderer.emitParticleAtEntity(llllllllllllllllIlllIIIIIIlIllIl, EnumParticleTypes.CRIT);
  }
  
  public boolean isRidingHorse()
  {
    ;
    if ((lIIIllllIlIIl(ridingEntity)) && (lIIIllllIIIII(ridingEntity instanceof EntityHorse)) && (lIIIllllIIIII(((EntityHorse)ridingEntity).isHorseSaddled()))) {
      return lIlllIlIllI[2];
    }
    return lIlllIlIllI[0];
  }
  
  public void sendPlayerAbilities()
  {
    ;
    sendQueue.addToSendQueue(new C13PacketPlayerAbilities(capabilities));
  }
  
  public void displayGUIHorse(EntityHorse llllllllllllllllIlllIIIIIlIIIlII, IInventory llllllllllllllllIlllIIIIIlIIIIII)
  {
    ;
    ;
    ;
    mc.displayGuiScreen(new GuiScreenHorseInventory(inventory, llllllllllllllllIlllIIIIIlIIIIII, llllllllllllllllIlllIIIIIlIIIIIl));
  }
  
  private static boolean lIIIllllIllII(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllllIllIlllllIlIlllI;
    return ??? == localObject;
  }
  
  public float getSpeed()
  {
    ;
    ;
    float llllllllllllllllIlllIIIIIIIIIIll = (float)Math.sqrt(motionX * motionX + motionZ * motionZ);
    return llllllllllllllllIlllIIIIIIIIIIll;
  }
  
  public void swingItem()
  {
    ;
    llllllllllllllllIlllIIIIllllllll.swingItem();
    sendQueue.addToSendQueue(new C0APacketAnimation());
  }
  
  private static boolean lIIIllllIIlIl(int ???)
  {
    Exception llllllllllllllllIllIlllllIlIlIII;
    return ??? == 0;
  }
  
  public void playSound(String llllllllllllllllIlllIIIIIlllIIII, float llllllllllllllllIlllIIIIIllIllll, float llllllllllllllllIlllIIIIIllIlllI)
  {
    ;
    ;
    ;
    ;
    worldObj.playSound(posX, posY, posZ, llllllllllllllllIlllIIIIIlllIIII, llllllllllllllllIlllIIIIIllIllll, llllllllllllllllIlllIIIIIllIlllI, lIlllIlIllI[0]);
  }
  
  public float getDirection()
  {
    ;
    ;
    ;
    float llllllllllllllllIllIllllllllIllI = rotationYaw;
    if (lIIIllllIlIII(lIIIlllllIIlI(moveForward, 0.0F))) {
      llllllllllllllllIllIllllllllIllI += 180.0F;
    }
    float llllllllllllllllIllIllllllllIlIl = 1.0F;
    if (lIIIllllIlIII(lIIIlllllIIlI(moveForward, 0.0F)))
    {
      llllllllllllllllIllIllllllllIlIl = -0.5F;
      "".length();
      if ((0x9A ^ 0x9E) <= "  ".length()) {
        return 0.0F;
      }
    }
    else if (lIIIllllIllll(lIIIlllllIIll(moveForward, 0.0F)))
    {
      llllllllllllllllIllIllllllllIlIl = 0.5F;
      "".length();
      if (((0x27 ^ 0x37) & (0xA4 ^ 0xB4 ^ 0xFFFFFFFF)) != 0) {
        return 0.0F;
      }
    }
    else
    {
      llllllllllllllllIllIllllllllIlIl = 1.0F;
    }
    if (lIIIllllIllll(lIIIlllllIIll(moveStrafing, 0.0F))) {
      llllllllllllllllIllIllllllllIllI -= 90.0F * llllllllllllllllIllIllllllllIlIl;
    }
    if (lIIIllllIlIII(lIIIlllllIIlI(moveStrafing, 0.0F))) {
      llllllllllllllllIllIllllllllIllI += 90.0F * llllllllllllllllIllIllllllllIlIl;
    }
    llllllllllllllllIllIllllllllIllI *= 0.017453292F;
    return llllllllllllllllIllIllllllllIllI;
  }
  
  private static String lIIIlllIlIllI(String llllllllllllllllIllIllllllIIIIll, String llllllllllllllllIllIllllllIIIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIllIllllllIIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllIllllllIIIlII.getBytes(StandardCharsets.UTF_8)), lIlllIlIllI[12]), "DES");
      Cipher llllllllllllllllIllIllllllIIIlll = Cipher.getInstance("DES");
      llllllllllllllllIllIllllllIIIlll.init(lIlllIlIllI[3], llllllllllllllllIllIllllllIIlIII);
      return new String(llllllllllllllllIllIllllllIIIlll.doFinal(Base64.getDecoder().decode(llllllllllllllllIllIllllllIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIllIllllllIIIllI)
    {
      llllllllllllllllIllIllllllIIIllI.printStackTrace();
    }
    return null;
  }
  
  public void closeScreen()
  {
    ;
    sendQueue.addToSendQueue(new C0DPacketCloseWindow(openContainer.windowId));
    llllllllllllllllIlllIIIIllllIIII.closeScreenAndDropStack();
  }
  
  static
  {
    lIIIlllIlllll();
    lIIIlllIlIlll();
  }
  
  public boolean attackEntityFrom(DamageSource llllllllllllllllIlllIIIlIIllllII, float llllllllllllllllIlllIIIlIIlllIll)
  {
    return lIlllIlIllI[0];
  }
  
  public boolean canCommandSenderUseCommand(int llllllllllllllllIlllIIIIIlllllIl, String llllllllllllllllIlllIIIIIllllllI)
  {
    ;
    if (lIIIllllIIIll(llllllllllllllllIlllIIIIIlllllIl)) {
      return lIlllIlIllI[2];
    }
    return lIlllIlIllI[0];
  }
  
  public String getClientBrand()
  {
    ;
    return clientBrand;
  }
  
  public boolean isUser()
  {
    return lIlllIlIllI[2];
  }
  
  public void respawnPlayer()
  {
    ;
    sendQueue.addToSendQueue(new C16PacketClientStatus(C16PacketClientStatus.EnumState.PERFORM_RESPAWN));
  }
  
  public boolean isServerWorld()
  {
    return lIlllIlIllI[2];
  }
  
  private static boolean lIIIlllllIIII(int ???)
  {
    String llllllllllllllllIllIlllllIlIIllI;
    return ??? >= 0;
  }
  
  public void displayGui(IInteractionObject llllllllllllllllIlllIIIIIIlllIll)
  {
    ;
    ;
    ;
    String llllllllllllllllIlllIIIIIIlllIlI = llllllllllllllllIlllIIIIIIlllIll.getGuiID();
    if (lIIIllllIIIII(lIlllIlIIIl[lIlllIlIllI[12]].equals(llllllllllllllllIlllIIIIIIlllIlI)))
    {
      mc.displayGuiScreen(new GuiCrafting(inventory, worldObj));
      "".length();
      if (-"  ".length() <= 0) {}
    }
    else if (lIIIllllIIIII(lIlllIlIIIl[lIlllIlIllI[13]].equals(llllllllllllllllIlllIIIIIIlllIlI)))
    {
      mc.displayGuiScreen(new GuiEnchantment(inventory, worldObj, llllllllllllllllIlllIIIIIIlllIll));
      "".length();
      if ((0xA6 ^ 0xA2) > " ".length()) {}
    }
    else if (lIIIllllIIIII(lIlllIlIIIl[lIlllIlIllI[4]].equals(llllllllllllllllIlllIIIIIIlllIlI)))
    {
      mc.displayGuiScreen(new GuiRepair(inventory, worldObj));
    }
  }
  
  public void sendHorseInventory()
  {
    ;
    sendQueue.addToSendQueue(new C0BPacketEntityAction(llllllllllllllllIlllIIIIllIlIIII, C0BPacketEntityAction.Action.OPEN_INVENTORY));
  }
  
  protected void joinEntityItemWithWorld(EntityItem llllllllllllllllIlllIIIlIIIIIlll) {}
  
  private static String lIIIlllIlIlIl(String llllllllllllllllIllIllllllIlIlIl, String llllllllllllllllIllIllllllIllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIllIllllllIlIlIl = new String(Base64.getDecoder().decode(llllllllllllllllIllIllllllIlIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIllIllllllIllIII = new StringBuilder();
    char[] llllllllllllllllIllIllllllIlIlll = llllllllllllllllIllIllllllIllIIl.toCharArray();
    int llllllllllllllllIllIllllllIlIllI = lIlllIlIllI[0];
    float llllllllllllllllIllIllllllIlIIII = llllllllllllllllIllIllllllIlIlIl.toCharArray();
    float llllllllllllllllIllIllllllIIllll = llllllllllllllllIllIllllllIlIIII.length;
    long llllllllllllllllIllIllllllIIlllI = lIlllIlIllI[0];
    while (lIIIllllIIlII(llllllllllllllllIllIllllllIIlllI, llllllllllllllllIllIllllllIIllll))
    {
      char llllllllllllllllIllIllllllIllIll = llllllllllllllllIllIllllllIlIIII[llllllllllllllllIllIllllllIIlllI];
      "".length();
      "".length();
      if ((51 + '' - 119 + 75 ^ 33 + 116 - 24 + 17) == "  ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIllIllllllIllIII);
  }
  
  public void mountEntity(Entity llllllllllllllllIlllIIIlIIllIlIl)
  {
    ;
    ;
    llllllllllllllllIlllIIIlIIllIllI.mountEntity(llllllllllllllllIlllIIIlIIllIlIl);
    if (lIIIllllIIIII(llllllllllllllllIlllIIIlIIllIlIl instanceof EntityMinecart)) {
      mc.getSoundHandler().playSound(new MovingSoundMinecartRiding(llllllllllllllllIlllIIIlIIllIllI, (EntityMinecart)llllllllllllllllIlllIIIlIIllIlIl));
    }
  }
  
  public void setClientBrand(String llllllllllllllllIlllIIIIllIIlIlI)
  {
    ;
    ;
    clientBrand = llllllllllllllllIlllIIIIllIIlIlI;
  }
  
  private static void lIIIlllIlllll()
  {
    lIlllIlIllI = new int[18];
    lIlllIlIllI[0] = ((0x65 ^ 0x61) & (0x1E ^ 0x1A ^ 0xFFFFFFFF));
    lIlllIlIllI[1] = (0x6B ^ 0x7F);
    lIlllIlIllI[2] = " ".length();
    lIlllIlIllI[3] = "  ".length();
    lIlllIlIllI[4] = (0x98 ^ 0x92);
    lIlllIlIllI[5] = (-" ".length());
    lIlllIlIllI[6] = (0x5C ^ 0x58);
    lIlllIlIllI[7] = (0xDE ^ 0x85 ^ 0xC4 ^ 0x9A);
    lIlllIlIllI[8] = (0xAA7A & 0x57DD);
    lIlllIlIllI[9] = "   ".length();
    lIlllIlIllI[10] = (0xBB ^ 0x90 ^ 0x7 ^ 0x2A);
    lIlllIlIllI[11] = (0x4E ^ 0x49);
    lIlllIlIllI[12] = (0xA3 ^ 0x97 ^ 0x5A ^ 0x66);
    lIlllIlIllI[13] = (0x60 ^ 0x69);
    lIlllIlIllI[14] = (0x4E ^ 0x45);
    lIlllIlIllI[15] = (0x54 ^ 0x4D ^ 0xBA ^ 0x9F);
    lIlllIlIllI[16] = (-(55 + '' - 125 + 99 ^ 49 + 48 - -49 + 42));
    lIlllIlIllI[17] = (0x3 ^ 0x9 ^ 0xA5 ^ 0xA3);
  }
  
  private static int lIIIllllIlllI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public BlockPos getPosition()
  {
    ;
    return new BlockPos(posX + 0.5D, posY + 0.5D, posZ + 0.5D);
  }
  
  protected boolean isCurrentViewEntity()
  {
    ;
    if (lIIIllllIllII(mc.getRenderViewEntity(), llllllllllllllllIlllIIIIIIIllIlI)) {
      return lIlllIlIllI[2];
    }
    return lIlllIlIllI[0];
  }
  
  private static String lIIIlllIIlllI(String llllllllllllllllIllIlllllllIlIII, String llllllllllllllllIllIlllllllIIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIllIlllllllIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIllIlllllllIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIllIlllllllIllII = Cipher.getInstance("Blowfish");
      llllllllllllllllIllIlllllllIllII.init(lIlllIlIllI[3], llllllllllllllllIllIlllllllIllIl);
      return new String(llllllllllllllllIllIlllllllIllII.doFinal(Base64.getDecoder().decode(llllllllllllllllIllIlllllllIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIllIlllllllIlIll)
    {
      llllllllllllllllIllIlllllllIlIll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIllllIlIll(int ???, int arg1)
  {
    int i;
    char llllllllllllllllIllIlllllIllllII;
    return ??? == i;
  }
  
  public void setSprinting(boolean llllllllllllllllIlllIIIIlIIlIllI)
  {
    ;
    ;
    llllllllllllllllIlllIIIIlIIlIlll.setSprinting(llllllllllllllllIlllIIIIlIIlIllI);
    if (lIIIllllIIIII(llllllllllllllllIlllIIIIlIIlIllI))
    {
      "".length();
      if (-" ".length() <= (0xAF ^ 0xAB)) {
        break label47;
      }
    }
    label47:
    lIlllIlIllI8sprintingTicksLeft = lIlllIlIllI[0];
  }
  
  public EntityPlayerSP(Minecraft llllllllllllllllIlllIIIlIlIIIIIl, World llllllllllllllllIlllIIIlIlIIIlIl, NetHandlerPlayClient llllllllllllllllIlllIIIlIIllllll, StatFileWriter llllllllllllllllIlllIIIlIIlllllI)
  {
    llllllllllllllllIlllIIIlIlIIIlll.<init>(llllllllllllllllIlllIIIlIlIIIIII, llllllllllllllllIlllIIIlIIllllll.getGameProfile());
    sendQueue = llllllllllllllllIlllIIIlIIllllll;
    statWriter = llllllllllllllllIlllIIIlIIlllllI;
    mc = llllllllllllllllIlllIIIlIlIIIIIl;
    dimension = lIlllIlIllI[0];
  }
  
  private static boolean lIIIlllllIIIl(int ???, int arg1)
  {
    int i;
    byte llllllllllllllllIllIlllllIllIlII;
    return ??? > i;
  }
  
  private static int lIIIlllllIIll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void addStat(StatBase llllllllllllllllIlllIIIIllIllIll, int llllllllllllllllIlllIIIIllIllIlI)
  {
    ;
    ;
    ;
    if ((lIIIllllIlIIl(llllllllllllllllIlllIIIIllIllIll)) && (lIIIllllIIIII(isIndependent))) {
      llllllllllllllllIlllIIIIllIlllll.addStat(llllllllllllllllIlllIIIIllIllllI, llllllllllllllllIlllIIIIllIllIlI);
    }
  }
  
  protected void sendHorseJump()
  {
    ;
    sendQueue.addToSendQueue(new C0BPacketEntityAction(llllllllllllllllIlllIIIIllIlIIll, C0BPacketEntityAction.Action.RIDING_JUMP, (int)(llllllllllllllllIlllIIIIllIlIIll.getHorseJumpPower() * 100.0F)));
  }
  
  public void onUpdate()
  {
    ;
    if (lIIIllllIIIII(worldObj.isBlockLoaded(new BlockPos(posX, 0.0D, posZ))))
    {
      llllllllllllllllIlllIIIlIIllIIII.onUpdate();
      if (lIIIllllIIIII(llllllllllllllllIlllIIIlIIllIIII.isRiding()))
      {
        sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(rotationYaw, rotationPitch, onGround));
        sendQueue.addToSendQueue(new C0CPacketInput(moveStrafing, moveForward, movementInput.jump, movementInput.sneak));
        "".length();
        if ((0xC ^ 0x66 ^ 0xD ^ 0x62) != 0) {}
      }
      else
      {
        llllllllllllllllIlllIIIlIIllIIII.onUpdateWalkingPlayer();
      }
    }
  }
  
  private static boolean lIIIllllIIlII(int ???, int arg1)
  {
    int i;
    char llllllllllllllllIllIlllllIlllIII;
    return ??? < i;
  }
  
  private static int lIIIllllIlIlI(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public void addChatMessage(IChatComponent llllllllllllllllIlllIIIIlIIIIIlI)
  {
    ;
    ;
    mc.ingameGUI.getChatGUI().printChatMessage(llllllllllllllllIlllIIIIlIIIIIlI);
  }
  
  private boolean isOpenBlockSpace(BlockPos llllllllllllllllIlllIIIIlIIllIlI)
  {
    ;
    ;
    if ((lIIIllllIIlIl(worldObj.getBlockState(llllllllllllllllIlllIIIIlIIllIlI).getBlock().isNormalCube())) && (lIIIllllIIlIl(worldObj.getBlockState(llllllllllllllllIlllIIIIlIIllIlI.up()).getBlock().isNormalCube()))) {
      return lIlllIlIllI[2];
    }
    return lIlllIlIllI[0];
  }
  
  public void addChatComponentMessage(IChatComponent llllllllllllllllIlllIIIIllIIIIII)
  {
    ;
    ;
    mc.ingameGUI.getChatGUI().printChatMessage(llllllllllllllllIlllIIIIllIIIIII);
  }
  
  private static boolean lIIIllllIlIIl(Object ???)
  {
    byte llllllllllllllllIllIlllllIllIIlI;
    return ??? != null;
  }
  
  public EntityItem dropOneItem(boolean llllllllllllllllIlllIIIlIIIIllIl)
  {
    ;
    ;
    ;
    if (lIIIllllIIIII(llllllllllllllllIlllIIIlIIIIllIl))
    {
      "".length();
      if (-" ".length() <= ((0x84 ^ 0xB6) & (0xB ^ 0x39 ^ 0xFFFFFFFF))) {
        break label45;
      }
      return null;
    }
    label45:
    C07PacketPlayerDigging.Action llllllllllllllllIlllIIIlIIIIllII = C07PacketPlayerDigging.Action.DROP_ITEM;
    sendQueue.addToSendQueue(new C07PacketPlayerDigging(llllllllllllllllIlllIIIlIIIIllII, BlockPos.ORIGIN, EnumFacing.DOWN));
    return null;
  }
  
  private static int lIIIllllIIlll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void displayGUIChest(IInventory llllllllllllllllIlllIIIIIlIIlIlI)
  {
    ;
    ;
    ;
    if (lIIIllllIIIII(llllllllllllllllIlllIIIIIlIIlIlI instanceof IInteractionObject))
    {
      "".length();
      if (((0x8D ^ 0x8A ^ 0xFA ^ 0xC0) & (65 + 51 - 27 + 77 ^ 4 + 70 - 57 + 138 ^ -" ".length())) == 0) {
        break label84;
      }
    }
    label84:
    String llllllllllllllllIlllIIIIIlIIllII = lIlllIlIIIl[lIlllIlIllI[0]];
    if (lIIIllllIIIII(lIlllIlIIIl[lIlllIlIllI[2]].equals(llllllllllllllllIlllIIIIIlIIllII)))
    {
      mc.displayGuiScreen(new GuiChest(inventory, llllllllllllllllIlllIIIIIlIIlIlI));
      "".length();
      if ("  ".length() < "   ".length()) {}
    }
    else if (lIIIllllIIIII(lIlllIlIIIl[lIlllIlIllI[3]].equals(llllllllllllllllIlllIIIIIlIIllII)))
    {
      mc.displayGuiScreen(new GuiHopper(inventory, llllllllllllllllIlllIIIIIlIIlIlI));
      "".length();
      if ("  ".length() != 0) {}
    }
    else if (lIIIllllIIIII(lIlllIlIIIl[lIlllIlIllI[9]].equals(llllllllllllllllIlllIIIIIlIIllII)))
    {
      mc.displayGuiScreen(new GuiFurnace(inventory, llllllllllllllllIlllIIIIIlIIlIlI));
      "".length();
      if ((0x33 ^ 0x4E ^ 0x32 ^ 0x4A) != 0) {}
    }
    else if (lIIIllllIIIII(lIlllIlIIIl[lIlllIlIllI[6]].equals(llllllllllllllllIlllIIIIIlIIllII)))
    {
      mc.displayGuiScreen(new GuiBrewingStand(inventory, llllllllllllllllIlllIIIIIlIIlIlI));
      "".length();
      if (" ".length() == " ".length()) {}
    }
    else if (lIIIllllIIIII(lIlllIlIIIl[lIlllIlIllI[7]].equals(llllllllllllllllIlllIIIIIlIIllII)))
    {
      mc.displayGuiScreen(new GuiBeacon(inventory, llllllllllllllllIlllIIIIIlIIlIlI));
      "".length();
      if (-"   ".length() < 0) {}
    }
    else if ((lIIIllllIIlIl(lIlllIlIIIl[lIlllIlIllI[10]].equals(llllllllllllllllIlllIIIIIlIIllII))) && (lIIIllllIIlIl(lIlllIlIIIl[lIlllIlIllI[11]].equals(llllllllllllllllIlllIIIIIlIIllII))))
    {
      mc.displayGuiScreen(new GuiChest(inventory, llllllllllllllllIlllIIIIIlIIlIlI));
      "".length();
      if (-"   ".length() <= 0) {}
    }
    else
    {
      mc.displayGuiScreen(new GuiDispenser(inventory, llllllllllllllllIlllIIIIIlIIlIlI));
    }
  }
  
  public void displayGUIBook(ItemStack llllllllllllllllIlllIIIIIlIlIIll)
  {
    ;
    ;
    ;
    Item llllllllllllllllIlllIIIIIlIlIlIl = llllllllllllllllIlllIIIIIlIlIIll.getItem();
    if (lIIIllllIllII(llllllllllllllllIlllIIIIIlIlIlIl, Items.writable_book)) {
      mc.displayGuiScreen(new GuiScreenBook(llllllllllllllllIlllIIIIIlIlIlll, llllllllllllllllIlllIIIIIlIlIIll, lIlllIlIllI[2]));
    }
  }
  
  private static boolean lIIIllllIIIll(int ???)
  {
    float llllllllllllllllIllIlllllIlIIIlI;
    return ??? <= 0;
  }
  
  private static void lIIIlllIlIlll()
  {
    lIlllIlIIIl = new String[lIlllIlIllI[17]];
    lIlllIlIIIl[lIlllIlIllI[0]] = lIIIlllIIlllI("bpoIasjls1CRSRiE5BO4HKkG26MuZpnh", "QZruT");
    lIlllIlIIIl[lIlllIlIllI[2]] = lIIIlllIlIlIl("IA8NAy8/BwUSdi4OBhU4", "MfcfL");
    lIlllIlIIIl[lIlllIlIllI[3]] = lIIIlllIIlllI("t+mYMOCHxLmFcms2L1i7b7NMJVaCy3Vo", "WwTqE");
    lIlllIlIIIl[lIlllIlIllI[9]] = lIIIlllIlIllI("jEFLV4rJjNF1vrPgGAzdFTRO4vnKbJG9", "tzMPX");
    lIlllIlIIIl[lIlllIlIllI[6]] = lIIIlllIlIlIl("Oh84ADUlFzARbDUEMxI/OREJFiI2GDI=", "WvVeV");
    lIlllIlIIIl[lIlllIlIllI[7]] = lIIIlllIIlllI("wPhMZ0xJ0DjuELWCGPy3TOiCz0+V7QNR", "pVZhQ");
    lIlllIlIIIl[lIlllIlIllI[10]] = lIIIlllIlIlIl("HRwHNjkCFA8nYBQcGiM/HgYMIQ==", "puiSZ");
    lIlllIlIIIl[lIlllIlIllI[11]] = lIIIlllIlIlIl("Lg8iAwwxByoSVScUIxYfJhQ=", "CfLfo");
    lIlllIlIIIl[lIlllIlIllI[12]] = lIIIlllIlIlIl("OTE9BwUmOTUWXDcqMgQSPTY0PRI1Oj8H", "TXSbf");
    lIlllIlIIIl[lIlllIlIllI[13]] = lIIIlllIlIllI("Y5OjCXi3vpoWvbYHQd6feGwJbIy76xvg9hHtW720o4M=", "ProIA");
    lIlllIlIIIl[lIlllIlIllI[4]] = lIIIlllIlIlIl("Pg0dCRIhBRUYSzIKBQUd", "Sdslq");
    lIlllIlIIIl[lIlllIlIllI[14]] = lIIIlllIlIllI("POHcn3wGuOE5dErr+c7pGw==", "UzXrB");
  }
  
  public void openEditSign(TileEntitySign llllllllllllllllIlllIIIIIllIIIIl)
  {
    ;
    ;
    mc.displayGuiScreen(new GuiEditSign(llllllllllllllllIlllIIIIIllIIIIl));
  }
  
  public void displayVillagerTradeGui(IMerchant llllllllllllllllIlllIIIIIIllIIIl)
  {
    ;
    ;
    mc.displayGuiScreen(new GuiMerchant(inventory, llllllllllllllllIlllIIIIIIllIIIl, worldObj));
  }
  
  private static boolean lIIIllllIIIlI(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllllIllIlllllIIlllII;
    return ??? != i;
  }
  
  public void onUpdateWalkingPlayer()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    boolean llllllllllllllllIlllIIIlIIlIIlII = llllllllllllllllIlllIIIlIIIllIll.isSprinting();
    if (lIIIllllIIIlI(llllllllllllllllIlllIIIlIIlIIlII, serverSprintState))
    {
      if (lIIIllllIIIII(llllllllllllllllIlllIIIlIIlIIlII))
      {
        sendQueue.addToSendQueue(new C0BPacketEntityAction(llllllllllllllllIlllIIIlIIlIIlIl, C0BPacketEntityAction.Action.START_SPRINTING));
        "".length();
        if ((('³' + '½' - 171 + 31 ^ 102 + 122 - 147 + 57) & (0x49 ^ 0x3D ^ 0x56 ^ 0x40 ^ -" ".length())) <= ("  ".length() ^ 0xB7 ^ 0xB1)) {}
      }
      else
      {
        sendQueue.addToSendQueue(new C0BPacketEntityAction(llllllllllllllllIlllIIIlIIlIIlIl, C0BPacketEntityAction.Action.STOP_SPRINTING));
      }
      serverSprintState = llllllllllllllllIlllIIIlIIlIIlII;
    }
    boolean llllllllllllllllIlllIIIlIIlIIIll = llllllllllllllllIlllIIIlIIlIIlIl.isSneaking();
    if (lIIIllllIIIlI(llllllllllllllllIlllIIIlIIlIIIll, serverSneakState))
    {
      if (lIIIllllIIIII(llllllllllllllllIlllIIIlIIlIIIll))
      {
        sendQueue.addToSendQueue(new C0BPacketEntityAction(llllllllllllllllIlllIIIlIIlIIlIl, C0BPacketEntityAction.Action.START_SNEAKING));
        "".length();
        if (null == null) {}
      }
      else
      {
        sendQueue.addToSendQueue(new C0BPacketEntityAction(llllllllllllllllIlllIIIlIIlIIlIl, C0BPacketEntityAction.Action.STOP_SNEAKING));
      }
      serverSneakState = llllllllllllllllIlllIIIlIIlIIIll;
    }
    if (lIIIllllIIIII(llllllllllllllllIlllIIIlIIlIIlIl.isCurrentViewEntity()))
    {
      double llllllllllllllllIlllIIIlIIlIIIlI = posX - lastReportedPosX;
      double llllllllllllllllIlllIIIlIIlIIIIl = getEntityBoundingBoxminY - lastReportedPosY;
      double llllllllllllllllIlllIIIlIIlIIIII = posZ - lastReportedPosZ;
      double llllllllllllllllIlllIIIlIIIlllll = rotationYaw - lastReportedYaw;
      double llllllllllllllllIlllIIIlIIIllllI = rotationPitch - lastReportedPitch;
      if ((lIIIllllIIIll(lIIIllllIIIIl(llllllllllllllllIlllIIIlIIlIIIlI * llllllllllllllllIlllIIIlIIlIIIlI + llllllllllllllllIlllIIIlIIlIIIIl * llllllllllllllllIlllIIIlIIlIIIIl + llllllllllllllllIlllIIIlIIlIIIII * llllllllllllllllIlllIIIlIIlIIIII, 9.0E-4D))) && (lIIIllllIIlII(positionUpdateTicks, lIlllIlIllI[1])))
      {
        "".length();
        if (((0x17 ^ 0x58) & (0x41 ^ 0xE ^ 0xFFFFFFFF)) < "   ".length()) {
          break label359;
        }
      }
      label359:
      boolean llllllllllllllllIlllIIIlIIIlllIl = lIlllIlIllI[2];
      if ((lIIIllllIIlIl(lIIIllllIIIIl(llllllllllllllllIlllIIIlIIIlllll, 0.0D))) && (lIIIllllIIlIl(lIIIllllIIIIl(llllllllllllllllIlllIIIlIIIllllI, 0.0D))))
      {
        "".length();
        if (-"  ".length() <= 0) {
          break label412;
        }
      }
      label412:
      boolean llllllllllllllllIlllIIIlIIIlllII = lIlllIlIllI[2];
      if (lIIIllllIIllI(ridingEntity))
      {
        if ((lIIIllllIIIII(llllllllllllllllIlllIIIlIIIlllIl)) && (lIIIllllIIIII(llllllllllllllllIlllIIIlIIIlllII)))
        {
          sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(posX, getEntityBoundingBoxminY, posZ, rotationYaw, rotationPitch, onGround));
          "".length();
          if (((0xE1 ^ 0xA8) & (0xE2 ^ 0xAB ^ 0xFFFFFFFF)) == 0) {}
        }
        else if (lIIIllllIIIII(llllllllllllllllIlllIIIlIIIlllIl))
        {
          sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(posX, getEntityBoundingBoxminY, posZ, onGround));
          "".length();
          if (" ".length() <= (0x83 ^ 0x87)) {}
        }
        else if (lIIIllllIIIII(llllllllllllllllIlllIIIlIIIlllII))
        {
          sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(rotationYaw, rotationPitch, onGround));
          "".length();
          if ("  ".length() >= " ".length()) {}
        }
        else
        {
          sendQueue.addToSendQueue(new C03PacketPlayer(onGround));
          "".length();
          if ("  ".length() >= 0) {}
        }
      }
      else
      {
        sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(motionX, -999.0D, motionZ, rotationYaw, rotationPitch, onGround));
        llllllllllllllllIlllIIIlIIIlllIl = lIlllIlIllI[0];
      }
      positionUpdateTicks += lIlllIlIllI[2];
      if (lIIIllllIIIII(llllllllllllllllIlllIIIlIIIlllIl))
      {
        lastReportedPosX = posX;
        lastReportedPosY = getEntityBoundingBoxminY;
        lastReportedPosZ = posZ;
        positionUpdateTicks = lIlllIlIllI[0];
      }
      if (lIIIllllIIIII(llllllllllllllllIlllIIIlIIIlllII))
      {
        lastReportedYaw = rotationYaw;
        lastReportedPitch = rotationPitch;
      }
    }
  }
  
  public void setPlayerSPHealth(float llllllllllllllllIlllIIIIlllIIlll)
  {
    ;
    ;
    ;
    if (lIIIllllIIIII(hasValidHealth))
    {
      float llllllllllllllllIlllIIIIlllIIllI = llllllllllllllllIlllIIIIlllIIlIl.getHealth() - llllllllllllllllIlllIIIIlllIIlll;
      if (lIIIllllIIIll(lIIIllllIIlll(llllllllllllllllIlllIIIIlllIIllI, 0.0F)))
      {
        llllllllllllllllIlllIIIIlllIIlIl.setHealth(llllllllllllllllIlllIIIIlllIIlll);
        if (lIIIllllIlIII(lIIIllllIIlll(llllllllllllllllIlllIIIIlllIIllI, 0.0F)))
        {
          hurtResistantTime = (maxHurtResistantTime / lIlllIlIllI[3]);
          "".length();
          if ("  ".length() >= 0) {}
        }
      }
      else
      {
        lastDamage = llllllllllllllllIlllIIIIlllIIllI;
        llllllllllllllllIlllIIIIlllIIlIl.setHealth(llllllllllllllllIlllIIIIlllIIlIl.getHealth());
        hurtResistantTime = maxHurtResistantTime;
        llllllllllllllllIlllIIIIlllIIlIl.damageEntity(DamageSource.generic, llllllllllllllllIlllIIIIlllIIllI);
        hurtTime = (llllllllllllllllIlllIIIIlllIIlIl.maxHurtTime = lIlllIlIllI[4]);
        "".length();
        if (" ".length() < ('¯' + 51 - 63 + 20 ^ 3 + 20 - -32 + 124)) {}
      }
    }
    else
    {
      llllllllllllllllIlllIIIIlllIIlIl.setHealth(llllllllllllllllIlllIIIIlllIIlll);
      hasValidHealth = lIlllIlIllI[2];
    }
  }
  
  private static int lIIIlllllIIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  protected boolean pushOutOfBlocks(double llllllllllllllllIlllIIIIlIllIIlI, double llllllllllllllllIlllIIIIlIlIIlll, double llllllllllllllllIlllIIIIlIlIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIllllIIIII(noClip)) {
      return lIlllIlIllI[0];
    }
    BlockPos llllllllllllllllIlllIIIIlIlIllll = new BlockPos(llllllllllllllllIlllIIIIlIllIIlI, llllllllllllllllIlllIIIIlIlIIlll, llllllllllllllllIlllIIIIlIlIIllI);
    double llllllllllllllllIlllIIIIlIlIlllI = llllllllllllllllIlllIIIIlIllIIlI - llllllllllllllllIlllIIIIlIlIllll.getX();
    double llllllllllllllllIlllIIIIlIlIllIl = llllllllllllllllIlllIIIIlIlIIllI - llllllllllllllllIlllIIIIlIlIllll.getZ();
    if (lIIIllllIIlIl(llllllllllllllllIlllIIIIlIllIIll.isOpenBlockSpace(llllllllllllllllIlllIIIIlIlIllll)))
    {
      int llllllllllllllllIlllIIIIlIlIllII = lIlllIlIllI[5];
      double llllllllllllllllIlllIIIIlIlIlIll = 9999.0D;
      if ((lIIIllllIIIII(llllllllllllllllIlllIIIIlIllIIll.isOpenBlockSpace(llllllllllllllllIlllIIIIlIlIllll.west()))) && (lIIIllllIlIII(lIIIllllIlIlI(llllllllllllllllIlllIIIIlIlIlllI, llllllllllllllllIlllIIIIlIlIlIll))))
      {
        llllllllllllllllIlllIIIIlIlIlIll = llllllllllllllllIlllIIIIlIlIlllI;
        llllllllllllllllIlllIIIIlIlIllII = lIlllIlIllI[0];
      }
      if ((lIIIllllIIIII(llllllllllllllllIlllIIIIlIllIIll.isOpenBlockSpace(llllllllllllllllIlllIIIIlIlIllll.east()))) && (lIIIllllIlIII(lIIIllllIlIlI(1.0D - llllllllllllllllIlllIIIIlIlIlllI, llllllllllllllllIlllIIIIlIlIlIll))))
      {
        llllllllllllllllIlllIIIIlIlIlIll = 1.0D - llllllllllllllllIlllIIIIlIlIlllI;
        llllllllllllllllIlllIIIIlIlIllII = lIlllIlIllI[2];
      }
      if ((lIIIllllIIIII(llllllllllllllllIlllIIIIlIllIIll.isOpenBlockSpace(llllllllllllllllIlllIIIIlIlIllll.north()))) && (lIIIllllIlIII(lIIIllllIlIlI(llllllllllllllllIlllIIIIlIlIllIl, llllllllllllllllIlllIIIIlIlIlIll))))
      {
        llllllllllllllllIlllIIIIlIlIlIll = llllllllllllllllIlllIIIIlIlIllIl;
        llllllllllllllllIlllIIIIlIlIllII = lIlllIlIllI[6];
      }
      if ((lIIIllllIIIII(llllllllllllllllIlllIIIIlIllIIll.isOpenBlockSpace(llllllllllllllllIlllIIIIlIlIllll.south()))) && (lIIIllllIlIII(lIIIllllIlIlI(1.0D - llllllllllllllllIlllIIIIlIlIllIl, llllllllllllllllIlllIIIIlIlIlIll))))
      {
        llllllllllllllllIlllIIIIlIlIlIll = 1.0D - llllllllllllllllIlllIIIIlIlIllIl;
        llllllllllllllllIlllIIIIlIlIllII = lIlllIlIllI[7];
      }
      float llllllllllllllllIlllIIIIlIlIlIlI = 0.1F;
      if (lIIIllllIIlIl(llllllllllllllllIlllIIIIlIlIllII)) {
        motionX = (-llllllllllllllllIlllIIIIlIlIlIlI);
      }
      if (lIIIllllIlIll(llllllllllllllllIlllIIIIlIlIllII, lIlllIlIllI[2])) {
        motionX = llllllllllllllllIlllIIIIlIlIlIlI;
      }
      if (lIIIllllIlIll(llllllllllllllllIlllIIIIlIlIllII, lIlllIlIllI[6])) {
        motionZ = (-llllllllllllllllIlllIIIIlIlIlIlI);
      }
      if (lIIIllllIlIll(llllllllllllllllIlllIIIIlIlIllII, lIlllIlIllI[7])) {
        motionZ = llllllllllllllllIlllIIIIlIlIlIlI;
      }
    }
    return lIlllIlIllI[0];
  }
}

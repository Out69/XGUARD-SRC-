package net.minecraft.client.network;

import com.google.common.base.Charsets;
import com.google.common.base.Splitter;
import com.google.common.collect.Iterables;
import com.mojang.authlib.GameProfile;
import io.netty.bootstrap.Bootstrap;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelException;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.SimpleChannelInboundHandler;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ServerAddress;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.ServerStatusResponse;
import net.minecraft.network.ServerStatusResponse.MinecraftProtocolVersionIdentifier;
import net.minecraft.network.ServerStatusResponse.PlayerCountData;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.status.INetHandlerStatusClient;
import net.minecraft.network.status.client.C00PacketServerQuery;
import net.minecraft.network.status.client.C01PacketPing;
import net.minecraft.network.status.server.S00PacketServerInfo;
import net.minecraft.network.status.server.S01PacketPong;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.logging.log4j.Logger;

public class OldServerPinger
{
  public void pingPendingNetworks()
  {
    synchronized (pingDestinations)
    {
      ;
      ;
      ;
      ;
      Iterator<NetworkManager> lllllllllllllllIIllllIIllllIlIll = pingDestinations.iterator();
      "".length();
      if (((0xB1 ^ 0xA4) & (0x8 ^ 0x1D ^ 0xFFFFFFFF)) > "   ".length()) {
        return;
      }
      while (!lIIIIllIIlllll(lllllllllllllllIIllllIIllllIlIll.hasNext()))
      {
        NetworkManager lllllllllllllllIIllllIIllllIlIlI = (NetworkManager)lllllllllllllllIIllllIIllllIlIll.next();
        if (lIIIIllIIllllI(lllllllllllllllIIllllIIllllIlIlI.isChannelOpen()))
        {
          lllllllllllllllIIllllIIllllIlIlI.processReceivedPackets();
          "".length();
          if (((0x7E ^ 0x31) & (0x3 ^ 0x4C ^ 0xFFFFFFFF)) != "   ".length()) {}
        }
        else
        {
          lllllllllllllllIIllllIIllllIlIll.remove();
          lllllllllllllllIIllllIIllllIlIlI.checkDisconnected();
        }
      }
      "".length();
      if (" ".length() != " ".length()) {}
    }
  }
  
  private static void lIIIIllIIlllII()
  {
    lIlIlllIIIII = new String[lIlIlllIIIIl[4]];
    lIlIlllIIIII[lIlIlllIIIIl[0]] = lIIIIllIIllIll("XkeKPjmStm0gqgMO7ht/LA==", "GOwIt");
    lIlIlllIIIII[lIlIlllIIIIl[3]] = lIIIIllIIllIll("3B5lxPaAoqJh+OzUNKldDQ==", "aMvfH");
  }
  
  public OldServerPinger() {}
  
  private static String lIIIIllIIllIll(String lllllllllllllllIIllllIIlllIIllIl, String lllllllllllllllIIllllIIlllIIlllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIllllIIlllIlIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllllIIlllIIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIllllIIlllIlIIIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIIllllIIlllIlIIIl.init(lIlIlllIIIIl[4], lllllllllllllllIIllllIIlllIlIIlI);
      return new String(lllllllllllllllIIllllIIlllIlIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllllIIlllIIllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIllllIIlllIlIIII)
    {
      lllllllllllllllIIllllIIlllIlIIII.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIIIIllIIlllIl();
    lIIIIllIIlllII();
    PING_RESPONSE_SPLITTER = Splitter.on(lIlIlllIIIIl[0]).limit(lIlIlllIIIIl[1]);
  }
  
  private static boolean lIIIIllIIllllI(int ???)
  {
    short lllllllllllllllIIllllIIlllIIlIII;
    return ??? != 0;
  }
  
  public void clearPendingNetworks()
  {
    synchronized (pingDestinations)
    {
      ;
      ;
      ;
      ;
      Iterator<NetworkManager> lllllllllllllllIIllllIIllllIIIII = pingDestinations.iterator();
      "".length();
      if ("  ".length() > "  ".length()) {
        return;
      }
      while (!lIIIIllIIlllll(lllllllllllllllIIllllIIllllIIIII.hasNext()))
      {
        NetworkManager lllllllllllllllIIllllIIlllIlllll = (NetworkManager)lllllllllllllllIIllllIIllllIIIII.next();
        if (lIIIIllIIllllI(lllllllllllllllIIllllIIlllIlllll.isChannelOpen()))
        {
          lllllllllllllllIIllllIIllllIIIII.remove();
          lllllllllllllllIIllllIIlllIlllll.closeChannel(new ChatComponentText(lIlIlllIIIII[lIlIlllIIIIl[3]]));
        }
      }
      "".length();
      if (-"   ".length() >= 0) {}
    }
  }
  
  private void tryCompatibilityPing(final ServerData lllllllllllllllIIllllIIlllllIIlI)
  {
    ;
    ;
    ;
    final ServerAddress lllllllllllllllIIllllIIlllllIlII = ServerAddress.func_78860_a(serverIP);
    new Bootstrap();
    new ChannelInitializer();
    {
      private static void llIlllIllIll()
      {
        lIIIlIIlIll = new int[2];
        lIIIlIIlIll[0] = " ".length();
        lIIIlIIlIll[1] = ((70 + '' - 197 + 220 ^ 56 + 112 - 25 + 19) & (75 + '¾' - 151 + 80 ^ 31 + 120 - 103 + 105 ^ -" ".length()));
      }
      
      protected void initChannel(Channel lllllllllllllllllIlIllIIIIlIlIII)
        throws Exception
      {
        try
        {
          ;
          ;
          "".length();
          "".length();
          if ((0x84 ^ 0x80) <= "   ".length()) {
            return;
          }
        }
        catch (ChannelException localChannelException)
        {
          ;
          "".length();
        }
      }
      
      static {}
    };
    "".length();
  }
  
  private static boolean lIIIIllIIlllll(int ???)
  {
    int lllllllllllllllIIllllIIlllIIIllI;
    return ??? == 0;
  }
  
  public void ping(final ServerData lllllllllllllllIIllllIIlllllllIl)
    throws UnknownHostException
  {
    ;
    ;
    ;
    ;
    ;
    ServerAddress lllllllllllllllIIllllIlIIIIIIIIl = ServerAddress.func_78860_a(serverIP);
    final NetworkManager lllllllllllllllIIllllIlIIIIIIIII = NetworkManager.func_181124_a(InetAddress.getByName(lllllllllllllllIIllllIlIIIIIIIIl.getIP()), lllllllllllllllIIllllIlIIIIIIIIl.getPort(), lIlIlllIIIIl[0]);
    "".length();
    serverMOTD = lIlIlllIIIII[lIlIlllIIIIl[0]];
    pingToServer = -1L;
    playerList = null;
    lllllllllllllllIIllllIlIIIIIIIII.setNetHandler(new INetHandlerStatusClient()
    {
      private static boolean lIllllIlllllll(int ???)
      {
        Exception llllllllllllllIllIIllIIlIlllIIlI;
        return ??? != 0;
      }
      
      static
      {
        lIllllIllllllI();
        lIllllIlllIIlI();
      }
      
      private static boolean lIlllllIIIIIII(Object ???)
      {
        int llllllllllllllIllIIllIIlIlllIlII;
        return ??? != null;
      }
      
      private static String lIllllIllIlIlI(String llllllllllllllIllIIllIIllIlIlIII, String llllllllllllllIllIIllIIllIlIIlIl)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllIllIIllIIllIlIlIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIllIIllIlIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher llllllllllllllIllIIllIIllIlIlIlI = Cipher.getInstance("Blowfish");
          llllllllllllllIllIIllIIllIlIlIlI.init(lllllIIlIIll[2], llllllllllllllIllIIllIIllIlIlIll);
          return new String(llllllllllllllIllIIllIIllIlIlIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIllIIllIlIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllIllIIllIIllIlIlIIl)
        {
          llllllllllllllIllIIllIIllIlIlIIl.printStackTrace();
        }
        return null;
      }
      
      private static boolean lIlllllIIIIIIl(int ???)
      {
        float llllllllllllllIllIIllIIlIllIlllI;
        return ??? > 0;
      }
      
      private static void lIllllIlllIIlI()
      {
        lllllIIIllIl = new String[lllllIIlIIll[17]];
        lllllIIIllIl[lllllIIlIIll[0]] = lIllllIllIlIIl("GysqFCA/Ky1RPCc8LAA8LD09FC1pPT0QPTw9", "INIqI");
        lllllIIIllIl[lllllIIlIIll[1]] = lIllllIllIlIlI("uoZzbo/wkZg=", "JebBz");
        lllllIIIllIl[lllllIIlIIll[2]] = lIllllIllIlIlI("ZV/flaafG+o=", "GYieY");
        lllllIIIllIl[lllllIIlIIll[3]] = lIllllIllIlIlI("Zus4NrNf320=", "WFJAz");
        lllllIIIllIl[lllllIIlIIll[4]] = lIllllIllIlIIl("Uw==", "YFufP");
        lllllIIIllIl[lllllIIlIIll[5]] = lIllllIllIlIll("e06GZIrhdK0=", "uCEma");
        lllllIIIllIl[lllllIIlIIll[6]] = lIllllIllIlIIl("dF5kURs0FGo=", "ZpJqz");
        lllllIIIllIl[lllllIIlIIll[7]] = lIllllIllIlIlI("nCA8mkuk3vIt7eUqrEjwqA==", "tSMSd");
        lllllIIIllIl[lllllIIlIIll[8]] = lIllllIllIlIIl("XXBF", "bOzEG");
        lllllIIIllIl[lllllIIlIIll[9]] = lIllllIllIlIll("JTPdC5bdeNUD4zqaS5ZMheJL8QyanmFo", "JNIqr");
        lllllIIIllIl[lllllIIlIIll[10]] = lIllllIllIlIlI("daKgi+g400NsMq0zNhwRsL5FJ9uLEzrV", "PhYjf");
        lllllIIIllIl[lllllIIlIIll[11]] = lIllllIllIlIlI("ySQy6uIaHntUlaPlIjTnxkd5MzMbbnFmz9YLcl7NuNAeF8LYxhJ6lg==", "ibOOY");
        lllllIIIllIl[lllllIIlIIll[12]] = lIllllIllIlIIl("NQ4PEwIbAgU=", "sgazq");
        lllllIIIllIl[lllllIIlIIll[13]] = lIllllIllIlIlI("7qBji99Alwm2gA6H3/eK6A==", "WnwBv");
        lllllIIIllIl[lllllIIlIIll[14]] = lIllllIllIlIlI("E+dizvLBVgI=", "AqaWU");
        lllllIIIllIl[lllllIIlIIll[15]] = lIllllIllIlIlI("OfgUUNpHdrPgXSfCICq0HzRkALidi/28GkMSU5pglGM=", "TWkxN");
        lllllIIIllIl[lllllIIlIIll[16]] = lIllllIllIlIlI("PyW9FLsBKiU=", "yHupN");
      }
      
      private static String lIllllIllIlIll(String llllllllllllllIllIIllIIllIIIIIll, String llllllllllllllIllIIllIIllIIIIIlI)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllIllIIllIIllIIIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIIllIIllIIIIIlI.getBytes(StandardCharsets.UTF_8)), lllllIIlIIll[8]), "DES");
          Cipher llllllllllllllIllIIllIIllIIIIlIl = Cipher.getInstance("DES");
          llllllllllllllIllIIllIIllIIIIlIl.init(lllllIIlIIll[2], llllllllllllllIllIIllIIllIIIIllI);
          return new String(llllllllllllllIllIIllIIllIIIIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllIllIIllIIllIIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllIllIIllIIllIIIIlII)
        {
          llllllllllllllIllIIllIIllIIIIlII.printStackTrace();
        }
        return null;
      }
      
      public void handlePong(S01PacketPong llllllllllllllIllIIllIIllIlllIll)
      {
        ;
        ;
        ;
        long llllllllllllllIllIIllIIllIlllIlI = field_175092_e;
        long llllllllllllllIllIIllIIllIlllIIl = Minecraft.getSystemTime();
        lllllllllllllllIIllllIIlllllllIlpingToServer = (llllllllllllllIllIIllIIllIlllIIl - llllllllllllllIllIIllIIllIlllIlI);
        lllllllllllllllIIllllIlIIIIIIIII.closeChannel(new ChatComponentText(lllllIIIllIl[lllllIIlIIll[12]]));
      }
      
      private static boolean lIlllllIIIIIlI(int ???, int arg1)
      {
        int i;
        float llllllllllllllIllIIllIIlIllllIlI;
        return ??? >= i;
      }
      
      private static String lIllllIllIlIIl(String llllllllllllllIllIIllIIllIIllIII, String llllllllllllllIllIIllIIllIIlIIlI)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        llllllllllllllIllIIllIIllIIllIII = new String(Base64.getDecoder().decode(llllllllllllllIllIIllIIllIIllIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder llllllllllllllIllIIllIIllIIlIllI = new StringBuilder();
        char[] llllllllllllllIllIIllIIllIIlIlIl = llllllllllllllIllIIllIIllIIlIIlI.toCharArray();
        int llllllllllllllIllIIllIIllIIlIlII = lllllIIlIIll[0];
        boolean llllllllllllllIllIIllIIllIIIlllI = llllllllllllllIllIIllIIllIIllIII.toCharArray();
        short llllllllllllllIllIIllIIllIIIllIl = llllllllllllllIllIIllIIllIIIlllI.length;
        short llllllllllllllIllIIllIIllIIIllII = lllllIIlIIll[0];
        while (lIlllllIIIIIll(llllllllllllllIllIIllIIllIIIllII, llllllllllllllIllIIllIIllIIIllIl))
        {
          char llllllllllllllIllIIllIIllIIllIIl = llllllllllllllIllIIllIIllIIIlllI[llllllllllllllIllIIllIIllIIIllII];
          "".length();
          "".length();
          if ("   ".length() <= ((0x80 ^ 0x96) & (0xF ^ 0x19 ^ 0xFFFFFFFF))) {
            return null;
          }
        }
        return String.valueOf(llllllllllllllIllIIllIIllIIlIllI);
      }
      
      public void handleServerInfo(S00PacketServerInfo llllllllllllllIllIIllIIlllIIllII)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        ;
        ;
        if (lIllllIlllllll(field_183009_e))
        {
          lllllllllllllllIIllllIlIIIIIIIII.closeChannel(new ChatComponentText(lllllIIIllIl[lllllIIlIIll[0]]));
          "".length();
          if ("  ".length() <= "  ".length()) {}
        }
        else
        {
          field_183009_e = lllllIIlIIll[1];
          ServerStatusResponse llllllllllllllIllIIllIIlllIIlIll = llllllllllllllIllIIllIIlllIIllII.getResponse();
          if (lIlllllIIIIIII(llllllllllllllIllIIllIIlllIIlIll.getServerDescription()))
          {
            lllllllllllllllIIllllIIlllllllIlserverMOTD = llllllllllllllIllIIllIIlllIIlIll.getServerDescription().getFormattedText();
            "".length();
            if (-" ".length() < 0) {}
          }
          else
          {
            lllllllllllllllIIllllIIlllllllIlserverMOTD = lllllIIIllIl[lllllIIlIIll[1]];
          }
          if (lIlllllIIIIIII(llllllllllllllIllIIllIIlllIIlIll.getProtocolVersionInfo()))
          {
            lllllllllllllllIIllllIIlllllllIlgameVersion = llllllllllllllIllIIllIIlllIIlIll.getProtocolVersionInfo().getName();
            lllllllllllllllIIllllIIlllllllIlversion = llllllllllllllIllIIllIIlllIIlIll.getProtocolVersionInfo().getProtocol();
            "".length();
            if (((125 + '' - 273 + 207 ^ '' + 84 - 212 + 135) & (0xC7 ^ 0xC1 ^ 0x25 ^ 0x6C ^ -" ".length())) >= -" ".length()) {}
          }
          else
          {
            lllllllllllllllIIllllIIlllllllIlgameVersion = lllllIIIllIl[lllllIIlIIll[2]];
            lllllllllllllllIIllllIIlllllllIlversion = lllllIIlIIll[0];
          }
          if (lIlllllIIIIIII(llllllllllllllIllIIllIIlllIIlIll.getPlayerCountData()))
          {
            lllllllllllllllIIllllIIlllllllIlpopulationInfo = String.valueOf(new StringBuilder().append(EnumChatFormatting.GRAY).append(llllllllllllllIllIIllIIlllIIlIll.getPlayerCountData().getOnlinePlayerCount()).append(EnumChatFormatting.DARK_GRAY).append(lllllIIIllIl[lllllIIlIIll[3]]).append(EnumChatFormatting.GRAY).append(llllllllllllllIllIIllIIlllIIlIll.getPlayerCountData().getMaxPlayers()));
            if (lIllllIlllllll(ArrayUtils.isNotEmpty(llllllllllllllIllIIllIIlllIIlIll.getPlayerCountData().getPlayers())))
            {
              StringBuilder llllllllllllllIllIIllIIlllIIlIlI = new StringBuilder();
              llllllllllllllIllIIllIIlllIIIIIl = (llllllllllllllIllIIllIIlllIIIIII = llllllllllllllIllIIllIIlllIIlIll.getPlayerCountData().getPlayers()).length;
              llllllllllllllIllIIllIIlllIIIIlI = lllllIIlIIll[0];
              "".length();
              if ("  ".length() <= 0) {
                return;
              }
              while (!lIlllllIIIIIlI(llllllllllllllIllIIllIIlllIIIIlI, llllllllllllllIllIIllIIlllIIIIIl))
              {
                GameProfile llllllllllllllIllIIllIIlllIIlIIl = llllllllllllllIllIIllIIlllIIIIII[llllllllllllllIllIIllIIlllIIIIlI];
                if (lIlllllIIIIIIl(llllllllllllllIllIIllIIlllIIlIlI.length())) {
                  "".length();
                }
                "".length();
              }
              if (lIlllllIIIIIll(llllllllllllllIllIIllIIlllIIlIll.getPlayerCountData().getPlayers().length, llllllllllllllIllIIllIIlllIIlIll.getPlayerCountData().getOnlinePlayerCount()))
              {
                if (lIlllllIIIIIIl(llllllllllllllIllIIllIIlllIIlIlI.length())) {
                  "".length();
                }
                "".length();
              }
              lllllllllllllllIIllllIIlllllllIlplayerList = String.valueOf(llllllllllllllIllIIllIIlllIIlIlI);
              "".length();
              if (" ".length() >= 0) {}
            }
          }
          else
          {
            lllllllllllllllIIllllIIlllllllIlpopulationInfo = String.valueOf(new StringBuilder().append(EnumChatFormatting.DARK_GRAY).append(lllllIIIllIl[lllllIIlIIll[8]]));
          }
          if (lIlllllIIIIIII(llllllllllllllIllIIllIIlllIIlIll.getFavicon()))
          {
            String llllllllllllllIllIIllIIlllIIlIII = llllllllllllllIllIIllIIlllIIlIll.getFavicon();
            if (lIllllIlllllll(llllllllllllllIllIIllIIlllIIlIII.startsWith(lllllIIIllIl[lllllIIlIIll[9]])))
            {
              lllllllllllllllIIllllIIlllllllIl.setBase64EncodedIconData(llllllllllllllIllIIllIIlllIIlIII.substring(lllllIIIllIl[lllllIIlIIll[10]].length()));
              "".length();
              if (-"   ".length() < 0) {}
            }
            else
            {
              OldServerPinger.logger.error(lllllIIIllIl[lllllIIlIIll[11]]);
              "".length();
              if (" ".length() >= ((0xDC ^ 0x98 ^ "   ".length()) & (0x15 ^ 0x1E ^ 0x6E ^ 0x22 ^ -" ".length()))) {}
            }
          }
          else
          {
            lllllllllllllllIIllllIIlllllllIl.setBase64EncodedIconData(null);
          }
          field_175092_e = Minecraft.getSystemTime();
          lllllllllllllllIIllllIlIIIIIIIII.sendPacket(new C01PacketPing(field_175092_e));
          field_147403_d = lllllIIlIIll[1];
        }
      }
      
      private static void lIllllIllllllI()
      {
        lllllIIlIIll = new int[18];
        lllllIIlIIll[0] = ((29 + 53 - -18 + 70 ^ 108 + 42 - 28 + 63) & (0xE4 ^ 0xB7 ^ 0x60 ^ 0x20 ^ -" ".length()));
        lllllIIlIIll[1] = " ".length();
        lllllIIlIIll[2] = "  ".length();
        lllllIIlIIll[3] = "   ".length();
        lllllIIlIIll[4] = (0x81 ^ 0x85);
        lllllIIlIIll[5] = (0x8F ^ 0x8A);
        lllllIIlIIll[6] = (0x9E ^ 0x84 ^ 0x46 ^ 0x5A);
        lllllIIlIIll[7] = (0x37 ^ 0x46 ^ 0x2E ^ 0x58);
        lllllIIlIIll[8] = (0xAE ^ 0xC4 ^ 0xED ^ 0x8F);
        lllllIIlIIll[9] = (53 + 36 - 75 + 152 ^ '' + 26 - 14 + 11);
        lllllIIlIIll[10] = (123 + 20 - 69 + 133 ^ 75 + 108 - 121 + 135);
        lllllIIlIIll[11] = (0x87 ^ 0x8C);
        lllllIIlIIll[12] = (0x45 ^ 0x66 ^ 0x6A ^ 0x45);
        lllllIIlIIll[13] = (0x44 ^ 0x49);
        lllllIIlIIll[14] = (0x85 ^ 0x8B);
        lllllIIlIIll[15] = (0x91 ^ 0xB5 ^ 0xA8 ^ 0x83);
        lllllIIlIIll[16] = (0x6C ^ 0x7C);
        lllllIIlIIll[17] = (0x6C ^ 0x7D);
      }
      
      private static boolean lIlllllIIIIIll(int ???, int arg1)
      {
        int i;
        char llllllllllllllIllIIllIIlIlllIllI;
        return ??? < i;
      }
      
      private static boolean lIlllllIIIIlII(int ???)
      {
        long llllllllllllllIllIIllIIlIlllIIII;
        return ??? == 0;
      }
      
      public void onDisconnect(IChatComponent llllllllllllllIllIIllIIllIllIIlI)
      {
        ;
        ;
        if (lIlllllIIIIlII(field_147403_d))
        {
          OldServerPinger.logger.error(String.valueOf(new StringBuilder(lllllIIIllIl[lllllIIlIIll[13]]).append(lllllllllllllllIIllllIIlllllllIlserverIP).append(lllllIIIllIl[lllllIIlIIll[14]]).append(llllllllllllllIllIIllIIllIllIIlI.getUnformattedText())));
          lllllllllllllllIIllllIIlllllllIlserverMOTD = String.valueOf(new StringBuilder().append(EnumChatFormatting.DARK_RED).append(lllllIIIllIl[lllllIIlIIll[15]]));
          lllllllllllllllIIllllIIlllllllIlpopulationInfo = lllllIIIllIl[lllllIIlIIll[16]];
          OldServerPinger.this.tryCompatibilityPing(lllllllllllllllIIllllIIlllllllIl);
        }
      }
    });
    try
    {
      lllllllllllllllIIllllIlIIIIIIIII.sendPacket(new C00Handshake(lIlIlllIIIIl[2], lllllllllllllllIIllllIlIIIIIIIIl.getIP(), lllllllllllllllIIllllIlIIIIIIIIl.getPort(), EnumConnectionState.STATUS));
      lllllllllllllllIIllllIlIIIIIIIII.sendPacket(new C00PacketServerQuery());
      "".length();
      if (-"   ".length() > 0) {}
    }
    catch (Throwable lllllllllllllllIIllllIIlllllllll)
    {
      logger.error(lllllllllllllllIIllllIIlllllllll);
    }
  }
  
  private static void lIIIIllIIlllIl()
  {
    lIlIlllIIIIl = new int[5];
    lIlIlllIIIIl[0] = ((0xF3 ^ 0x9A ^ 0x5A ^ 0x6C) & (0xE4 ^ 0x98 ^ 0x3F ^ 0x1C ^ -" ".length()));
    lIlIlllIIIIl[1] = (0x2A ^ 0x2C);
    lIlIlllIIIIl[2] = (3 + '' - 86 + 106 ^ 11 + 104 - -16 + 5);
    lIlIlllIIIIl[3] = " ".length();
    lIlIlllIIIIl[4] = "  ".length();
  }
}

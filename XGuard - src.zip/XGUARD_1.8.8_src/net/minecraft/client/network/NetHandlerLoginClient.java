package net.minecraft.client.network;

import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.exceptions.AuthenticationUnavailableException;
import com.mojang.authlib.exceptions.InvalidCredentialsException;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import io.netty.util.concurrent.Future;
import io.netty.util.concurrent.GenericFutureListener;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiDisconnected;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.login.INetHandlerLoginClient;
import net.minecraft.network.login.client.C01PacketEncryptionResponse;
import net.minecraft.network.login.server.S00PacketDisconnect;
import net.minecraft.network.login.server.S01PacketEncryptionRequest;
import net.minecraft.network.login.server.S02PacketLoginSuccess;
import net.minecraft.network.login.server.S03PacketEnableCompression;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.CryptManager;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.Session;
import org.apache.logging.log4j.Logger;

public class NetHandlerLoginClient
  implements INetHandlerLoginClient
{
  public void onDisconnect(IChatComponent lllllllllllllllllIIIllIIIlIIllll)
  {
    ;
    ;
    mc.displayGuiScreen(new GuiDisconnected(previousGuiScreen, lIlIIllIIII[lIlIIllIIIl[7]], lllllllllllllllllIIIllIIIlIIllll));
  }
  
  private static boolean lIIIIIIIlIIlI(int ???)
  {
    long lllllllllllllllllIIIllIIIIIIIlll;
    return ??? != 0;
  }
  
  public void handleEncryptionRequest(S01PacketEncryptionRequest lllllllllllllllllIIIllIIIllIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    final SecretKey lllllllllllllllllIIIllIIIllIllII = CryptManager.createNewSharedKey();
    String lllllllllllllllllIIIllIIIllIlIll = lllllllllllllllllIIIllIIIllIllIl.getServerId();
    PublicKey lllllllllllllllllIIIllIIIllIlIlI = lllllllllllllllllIIIllIIIllIllIl.getPublicKey();
    String lllllllllllllllllIIIllIIIllIlIIl = new BigInteger(CryptManager.getServerIdHash(lllllllllllllllllIIIllIIIllIlIll, lllllllllllllllllIIIllIIIllIlIlI, lllllllllllllllllIIIllIIIllIllII)).toString(lIlIIllIIIl[0]);
    if ((lIIIIIIIlIIIl(mc.getCurrentServerData())) && (lIIIIIIIlIIlI(mc.getCurrentServerData().func_181041_d()))) {
      try
      {
        lllllllllllllllllIIIllIIIllIIlII.getSessionService().joinServer(mc.getSession().getProfile(), mc.getSession().getToken(), lllllllllllllllllIIIllIIIllIlIIl);
        "".length();
        if ("   ".length() > "  ".length()) {
          break label410;
        }
        return;
      }
      catch (AuthenticationException lllllllllllllllllIIIllIIIllIlIII)
      {
        logger.warn(lIlIIllIIII[lIlIIllIIIl[1]]);
        "".length();
        if ("   ".length() >= " ".length()) {
          break label410;
        }
      }
    } else {
      try
      {
        lllllllllllllllllIIIllIIIllIIlII.getSessionService().joinServer(mc.getSession().getProfile(), mc.getSession().getToken(), lllllllllllllllllIIIllIIIllIlIIl);
        "".length();
        if (((0xA5 ^ 0xA9 ^ 0x43 ^ 0x4B) & (0x52 ^ 0x3F ^ 0xFB ^ 0x92 ^ -" ".length())) > 0) {
          return;
        }
      }
      catch (AuthenticationUnavailableException lllllllllllllllllIIIllIIIllIIlll)
      {
        networkManager.closeChannel(new ChatComponentTranslation(lIlIIllIIII[lIlIIllIIIl[2]], new Object[] { new ChatComponentTranslation(lIlIIllIIII[lIlIIllIIIl[3]], new Object[lIlIIllIIIl[1]]) }));
        return;
      }
      catch (InvalidCredentialsException lllllllllllllllllIIIllIIIllIIllI)
      {
        networkManager.closeChannel(new ChatComponentTranslation(lIlIIllIIII[lIlIIllIIIl[4]], new Object[] { new ChatComponentTranslation(lIlIIllIIII[lIlIIllIIIl[5]], new Object[lIlIIllIIIl[1]]) }));
        return;
      }
      catch (AuthenticationException lllllllllllllllllIIIllIIIllIIlIl)
      {
        networkManager.closeChannel(new ChatComponentTranslation(lIlIIllIIII[lIlIIllIIIl[6]], new Object[] { lllllllllllllllllIIIllIIIllIIlIl.getMessage() }));
        return;
      }
    }
    label410:
    networkManager.sendPacket(new C01PacketEncryptionResponse(lllllllllllllllllIIIllIIIllIllII, lllllllllllllllllIIIllIIIllIlIlI, lllllllllllllllllIIIllIIIllIllIl.getVerifyToken()), new GenericFutureListener()
    {
      public void operationComplete(Future<? super Void> lllIIlIIIlIl)
        throws Exception
      {
        ;
        networkManager.enableEncryption(lllllllllllllllllIIIllIIIllIllII);
      }
    }, new GenericFutureListener[lIlIIllIIIl[1]]);
  }
  
  private static void lIIIIIIIIllIl()
  {
    lIlIIllIIII = new String[lIlIIllIIIl[8]];
    lIlIIllIIII[lIlIIllIIIl[1]] = lIIIIIIIIIIll("BCAgDhcpaCFCECghOwcQM28hDVMmOiEKUzQqJxQWNTx1AAYzbyILHytvNg0dMyY7FxZnOzpCGSgmO0I/BgE=", "GOUbs");
    lIlIIllIIII[lIlIIllIIIl[2]] = lIIIIIIIIIlII("VdcD8EAaPuMjuI6yqSriwbhwk0fFQ7NEK6rpvotHNJM=", "QDnoS");
    lIlIIllIIII[lIlIIllIIIl[3]] = lIIIIIIIIlIIl("JZmPPZtIv/gfFprqUGjfBqytD6hjelvFBNlRj+4tqqk8YxFR6HRbQdPUV8mrAhv/", "vFYvV");
    lIlIIllIIII[lIlIIllIIIl[4]] = lIIIIIIIIIIll("FgMLDR0cBB0NBlwGFwkbHCwZBx4XDjEAFB0=", "rjxnr");
    lIlIIllIIII[lIlIIllIIIl[5]] = lIIIIIIIIlIIl("C/fAWABfYOkPjLevTWhk4MVZJrOXFC3eLIrdhLKZKYqAwC/x1Lo/gUL2oJnOnN+z", "vghdb");
    lIlIIllIIII[lIlIIllIIIl[6]] = lIIIIIIIIIIll("ES4lKAobKTMoEVsrOSwMGwE3IgkQIx8lAxo=", "uGVKe");
    lIlIIllIIII[lIlIIllIIIl[7]] = lIIIIIIIIIlII("Xsduqq+llzchgxRkbd97bg==", "tWrUR");
  }
  
  public void handleLoginSuccess(S02PacketLoginSuccess lllllllllllllllllIIIllIIIlIlIlll)
  {
    ;
    ;
    gameProfile = lllllllllllllllllIIIllIIIlIlIlll.getProfile();
    networkManager.setConnectionState(EnumConnectionState.PLAY);
    networkManager.setNetHandler(new NetHandlerPlayClient(mc, previousGuiScreen, networkManager, gameProfile));
  }
  
  private static String lIIIIIIIIlIIl(String lllllllllllllllllIIIllIIIIlllIIl, String lllllllllllllllllIIIllIIIIllIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIIllIIIIllllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIllIIIIllIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIIIllIIIIlllIll = Cipher.getInstance("Blowfish");
      lllllllllllllllllIIIllIIIIlllIll.init(lIlIIllIIIl[3], lllllllllllllllllIIIllIIIIllllII);
      return new String(lllllllllllllllllIIIllIIIIlllIll.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIllIIIIlllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIIllIIIIlllIlI)
    {
      lllllllllllllllllIIIllIIIIlllIlI.printStackTrace();
    }
    return null;
  }
  
  public NetHandlerLoginClient(NetworkManager lllllllllllllllllIIIllIIIllllIII, Minecraft lllllllllllllllllIIIllIIIlllIlll, GuiScreen lllllllllllllllllIIIllIIIllllIlI)
  {
    networkManager = lllllllllllllllllIIIllIIIllllIII;
    mc = lllllllllllllllllIIIllIIIlllIlll;
    previousGuiScreen = lllllllllllllllllIIIllIIIllllIlI;
  }
  
  private static String lIIIIIIIIIlII(String lllllllllllllllllIIIllIIIIIlIIlI, String lllllllllllllllllIIIllIIIIIlIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIIllIIIIIlIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIIllIIIIIlIIIl.getBytes(StandardCharsets.UTF_8)), lIlIIllIIIl[9]), "DES");
      Cipher lllllllllllllllllIIIllIIIIIlIllI = Cipher.getInstance("DES");
      lllllllllllllllllIIIllIIIIIlIllI.init(lIlIIllIIIl[3], lllllllllllllllllIIIllIIIIIlIlll);
      return new String(lllllllllllllllllIIIllIIIIIlIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIIllIIIIIlIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIIllIIIIIlIlIl)
    {
      lllllllllllllllllIIIllIIIIIlIlIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIIIIIlIIll(int ???)
  {
    Exception lllllllllllllllllIIIllIIIIIIIlIl;
    return ??? == 0;
  }
  
  private static void lIIIIIIIlIIII()
  {
    lIlIIllIIIl = new int[10];
    lIlIIllIIIl[0] = (0x63 ^ 0x73);
    lIlIIllIIIl[1] = ((0xC8 ^ 0x8F) & (0xCB ^ 0x8C ^ 0xFFFFFFFF));
    lIlIIllIIIl[2] = " ".length();
    lIlIIllIIIl[3] = "  ".length();
    lIlIIllIIIl[4] = "   ".length();
    lIlIIllIIIl[5] = (0xC7 ^ 0xC3);
    lIlIIllIIIl[6] = (0x2E ^ 0xA ^ 0x6B ^ 0x4A);
    lIlIIllIIIl[7] = (106 + 38 - 53 + 61 ^ 14 + 9 - -115 + 20);
    lIlIIllIIIl[8] = (0x48 ^ 0x4F);
    lIlIIllIIIl[9] = (31 + 18 - 32 + 148 ^ 105 + 29 - 3 + 42);
  }
  
  private MinecraftSessionService getSessionService()
  {
    ;
    return mc.getSessionService();
  }
  
  private static boolean lIIIIIIIlIlII(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllllIIIllIIIIIIlIll;
    return ??? < i;
  }
  
  private static String lIIIIIIIIIIll(String lllllllllllllllllIIIllIIIIlIIlII, String lllllllllllllllllIIIllIIIIlIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllIIIllIIIIlIIlII = new String(Base64.getDecoder().decode(lllllllllllllllllIIIllIIIIlIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllIIIllIIIIlIIlll = new StringBuilder();
    char[] lllllllllllllllllIIIllIIIIlIIllI = lllllllllllllllllIIIllIIIIlIlIII.toCharArray();
    int lllllllllllllllllIIIllIIIIlIIlIl = lIlIIllIIIl[1];
    char lllllllllllllllllIIIllIIIIIlllll = lllllllllllllllllIIIllIIIIlIIlII.toCharArray();
    long lllllllllllllllllIIIllIIIIIllllI = lllllllllllllllllIIIllIIIIIlllll.length;
    short lllllllllllllllllIIIllIIIIIlllIl = lIlIIllIIIl[1];
    while (lIIIIIIIlIlII(lllllllllllllllllIIIllIIIIIlllIl, lllllllllllllllllIIIllIIIIIllllI))
    {
      char lllllllllllllllllIIIllIIIIlIlIlI = lllllllllllllllllIIIllIIIIIlllll[lllllllllllllllllIIIllIIIIIlllIl];
      "".length();
      "".length();
      if (-"   ".length() > 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllIIIllIIIIlIIlll);
  }
  
  public void handleDisconnect(S00PacketDisconnect lllllllllllllllllIIIllIIIlIIlIIl)
  {
    ;
    ;
    networkManager.closeChannel(lllllllllllllllllIIIllIIIlIIlIIl.func_149603_c());
  }
  
  static
  {
    lIIIIIIIlIIII();
    lIIIIIIIIllIl();
  }
  
  private static boolean lIIIIIIIlIIIl(Object ???)
  {
    byte lllllllllllllllllIIIllIIIIIIlIIl;
    return ??? != null;
  }
  
  public void handleEnableCompression(S03PacketEnableCompression lllllllllllllllllIIIllIIIlIIIlIl)
  {
    ;
    ;
    if (lIIIIIIIlIIll(networkManager.isLocalChannel())) {
      networkManager.setCompressionTreshold(lllllllllllllllllIIIllIIIlIIIlIl.getCompressionTreshold());
    }
  }
}

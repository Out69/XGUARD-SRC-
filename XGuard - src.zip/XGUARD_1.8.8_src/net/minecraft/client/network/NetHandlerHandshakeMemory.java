package net.minecraft.client.network;

import net.minecraft.network.NetworkManager;
import net.minecraft.network.handshake.INetHandlerHandshakeServer;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.NetHandlerLoginServer;
import net.minecraft.util.IChatComponent;

public class NetHandlerHandshakeMemory
  implements INetHandlerHandshakeServer
{
  public void processHandshake(C00Handshake llllllllllllllIlIlIlIlllIIIllIII)
  {
    ;
    ;
    networkManager.setConnectionState(llllllllllllllIlIlIlIlllIIIllIII.getRequestedState());
    networkManager.setNetHandler(new NetHandlerLoginServer(mcServer, networkManager));
  }
  
  public void onDisconnect(IChatComponent llllllllllllllIlIlIlIlllIIIlIlII) {}
  
  public NetHandlerHandshakeMemory(MinecraftServer llllllllllllllIlIlIlIlllIIlIIIII, NetworkManager llllllllllllllIlIlIlIlllIIIlllII)
  {
    mcServer = llllllllllllllIlIlIlIlllIIIlllIl;
    networkManager = llllllllllllllIlIlIlIlllIIIlllII;
  }
}

package net.minecraft.client.network;

import com.google.common.base.Objects;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.minecraft.MinecraftProfileTexture.Type;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.SkinManager;
import net.minecraft.client.resources.SkinManager.SkinAvailableCallback;
import net.minecraft.network.play.server.S38PacketPlayerListItem.AddPlayerData;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.WorldSettings.GameType;

public class NetworkPlayerInfo
{
  public void func_178836_b(int llllllllllllllIlIlIIlllllIIIlllI)
  {
    ;
    ;
    field_178873_i = llllllllllllllIlIlIIlllllIIIlllI;
  }
  
  public void setDisplayName(IChatComponent llllllllllllllIlIlIIlllllIIllIII)
  {
    ;
    ;
    displayName = llllllllllllllIlIlIIlllllIIllIII;
  }
  
  public int func_178860_m()
  {
    ;
    return field_178870_j;
  }
  
  public NetworkPlayerInfo(S38PacketPlayerListItem.AddPlayerData llllllllllllllIlIlIIlllllllIIIll)
  {
    gameProfile = llllllllllllllIlIlIIlllllllIIIll.getProfile();
    gameType = llllllllllllllIlIlIIlllllllIIIll.getGameMode();
    responseTime = llllllllllllllIlIlIIlllllllIIIll.getPing();
    displayName = llllllllllllllIlIlIIlllllllIIIll.getDisplayName();
  }
  
  protected void setResponseTime(int llllllllllllllIlIlIIllllllIIIIII)
  {
    ;
    ;
    responseTime = llllllllllllllIlIlIIllllllIIIIII;
  }
  
  public boolean hasLocationSkin()
  {
    ;
    if (llIIlllIIIllIl(locationSkin)) {
      return lIIIIllIllIIl[1];
    }
    return lIIIIllIllIIl[0];
  }
  
  public ResourceLocation getLocationCape()
  {
    ;
    if (llIIlllIIIlllI(locationCape)) {
      llllllllllllllIlIlIIlllllIlIIllI.loadPlayerTextures();
    }
    return locationCape;
  }
  
  public void func_178844_b(long llllllllllllllIlIlIIllllIlllIIIl)
  {
    ;
    ;
    field_178868_l = llllllllllllllIlIlIIllllIlllIIIl;
  }
  
  public NetworkPlayerInfo(GameProfile llllllllllllllIlIlIIllllllllIlII)
  {
    gameProfile = llllllllllllllIlIlIIllllllllIlII;
  }
  
  private static boolean llIIlllIIIllll(int ???)
  {
    boolean llllllllllllllIlIlIIllllIlIlIlII;
    return ??? == 0;
  }
  
  public long func_178847_n()
  {
    ;
    return field_178871_k;
  }
  
  private static boolean llIIlllIIIlllI(Object ???)
  {
    boolean llllllllllllllIlIlIIllllIlIlIllI;
    return ??? == null;
  }
  
  public void func_178843_c(long llllllllllllllIlIlIIllllIllIlIlI)
  {
    ;
    ;
    field_178869_m = llllllllllllllIlIlIIllllIllIlIlI;
  }
  
  public long func_178858_o()
  {
    ;
    return field_178868_l;
  }
  
  static {}
  
  public int func_178835_l()
  {
    ;
    return field_178873_i;
  }
  
  public int getResponseTime()
  {
    ;
    return responseTime;
  }
  
  public WorldSettings.GameType getGameType()
  {
    ;
    return gameType;
  }
  
  private static boolean llIIlllIIIllIl(Object ???)
  {
    byte llllllllllllllIlIlIIllllIlIllIII;
    return ??? != null;
  }
  
  protected void setGameType(WorldSettings.GameType llllllllllllllIlIlIIllllllIIllII)
  {
    ;
    ;
    gameType = llllllllllllllIlIlIIllllllIIllII;
  }
  
  public String getSkinType()
  {
    ;
    if (llIIlllIIIlllI(skinType))
    {
      "".length();
      if (((0x1C ^ 0x8) & (0x18 ^ 0xC ^ 0xFFFFFFFF)) >= 0) {
        break label48;
      }
      return null;
    }
    label48:
    return skinType;
  }
  
  public GameProfile getGameProfile()
  {
    ;
    return gameProfile;
  }
  
  public ResourceLocation getLocationSkin()
  {
    ;
    if (llIIlllIIIlllI(locationSkin)) {
      llllllllllllllIlIlIIlllllIlIlllI.loadPlayerTextures();
    }
    return (ResourceLocation)Objects.firstNonNull(locationSkin, DefaultPlayerSkin.getDefaultSkin(gameProfile.getId()));
  }
  
  public long func_178855_p()
  {
    ;
    return field_178869_m;
  }
  
  public void func_178857_c(int llllllllllllllIlIlIIlllllIIIIlIl)
  {
    ;
    ;
    field_178870_j = llllllllllllllIlIlIIlllllIIIIlIl;
  }
  
  public void func_178846_a(long llllllllllllllIlIlIIllllIlllllII)
  {
    ;
    ;
    field_178871_k = llllllllllllllIlIlIIllllIlllllII;
  }
  
  private static void llIIlllIIIllII()
  {
    lIIIIllIllIIl = new int[2];
    lIIIIllIllIIl[0] = ((0x9E ^ 0xC0 ^ 0x29 ^ 0x41) & ('' + 104 - 164 + 83 ^ '' + 6 - 60 + 69 ^ -" ".length()));
    lIIIIllIllIIl[1] = " ".length();
  }
  
  public IChatComponent getDisplayName()
  {
    ;
    return displayName;
  }
  
  public ScorePlayerTeam getPlayerTeam()
  {
    ;
    return getMinecrafttheWorld.getScoreboard().getPlayersTeam(llllllllllllllIlIlIIlllllIlIIlII.getGameProfile().getName());
  }
  
  protected void loadPlayerTextures()
  {
    synchronized (llllllllllllllIlIlIIlllllIIlllll)
    {
      ;
      ;
      if (llIIlllIIIllll(playerTexturesLoaded))
      {
        playerTexturesLoaded = lIIIIllIllIIl[1];
        Minecraft.getMinecraft().getSkinManager().loadProfileTextures(gameProfile, new SkinManager.SkinAvailableCallback()
        {
          private static void lIllIIIIllI()
          {
            llIlIlllI = new String[llIlIllll[2]];
            llIlIlllI[llIlIllll[0]] = lIllIIIIlIl("LhkpFi8=", "CvMsC");
            llIlIlllI[llIlIllll[1]] = lIllIIIIlIl("AgwXKg0KHQ==", "fiqKx");
          }
          
          private static boolean lIllIIIllII(int ???, int arg1)
          {
            int i;
            double lIlIlllIlllllI;
            return ??? < i;
          }
          
          public void skinAvailable(MinecraftProfileTexture.Type lIlIllllIllllI, ResourceLocation lIlIlllllIIIIl, MinecraftProfileTexture lIlIllllIlllII)
          {
            ;
            ;
            ;
            ;
            switch ($SWITCH_TABLE$com$mojang$authlib$minecraft$MinecraftProfileTexture$Type()[lIlIllllIllllI.ordinal()])
            {
            case 1: 
              locationSkin = lIlIlllllIIIIl;
              skinType = lIlIllllIlllII.getMetadata(llIlIlllI[llIlIllll[0]]);
              if (lIllIIIlIlI(skinType))
              {
                skinType = llIlIlllI[llIlIllll[1]];
                "".length();
                if (-" ".length() >= ((0xAD ^ 0x87) & (0xEF ^ 0xC5 ^ 0xFFFFFFFF))) {}
              }
              break;
            case 2: 
              locationCape = lIlIlllllIIIIl;
            }
          }
          
          static
          {
            lIllIIIlIIl();
            lIllIIIIllI();
          }
          
          private static boolean lIllIIIlIlI(Object ???)
          {
            float lIlIlllIlllIlI;
            return ??? == null;
          }
          
          private static boolean lIllIIIlIll(Object ???)
          {
            String lIlIlllIllllII;
            return ??? != null;
          }
          
          private static String lIllIIIIlIl(String lIlIllllIIlIlI, String lIlIllllIIlIIl)
          {
            ;
            ;
            ;
            ;
            ;
            ;
            lIlIllllIIlIlI = new String(Base64.getDecoder().decode(lIlIllllIIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
            StringBuilder lIlIllllIIllIl = new StringBuilder();
            char[] lIlIllllIIllII = lIlIllllIIlIIl.toCharArray();
            int lIlIllllIIlIll = llIlIllll[0];
            byte lIlIllllIIIlIl = lIlIllllIIlIlI.toCharArray();
            short lIlIllllIIIlII = lIlIllllIIIlIl.length;
            short lIlIllllIIIIll = llIlIllll[0];
            while (lIllIIIllII(lIlIllllIIIIll, lIlIllllIIIlII))
            {
              char lIlIllllIlIIII = lIlIllllIIIlIl[lIlIllllIIIIll];
              "".length();
              "".length();
              if (-" ".length() >= " ".length()) {
                return null;
              }
            }
            return String.valueOf(lIlIllllIIllIl);
          }
          
          private static void lIllIIIlIIl()
          {
            llIlIllll = new int[3];
            llIlIllll[0] = ((0x91 ^ 0xB0) & (0x7B ^ 0x5A ^ 0xFFFFFFFF));
            llIlIllll[1] = " ".length();
            llIlIllll[2] = "  ".length();
          }
        }, lIIIIllIllIIl[1]);
      }
      "".length();
      if ((0xC7 ^ 0xBE ^ 0x45 ^ 0x38) != (0x22 ^ 0x38 ^ 0x62 ^ 0x7C)) {}
    }
  }
}

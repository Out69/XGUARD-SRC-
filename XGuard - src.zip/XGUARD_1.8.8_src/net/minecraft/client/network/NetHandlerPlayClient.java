package net.minecraft.client.network;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.mojang.authlib.GameProfile;
import io.netty.buffer.Unpooled;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.GuardianSound;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiDisconnected;
import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiMerchant;
import net.minecraft.client.gui.GuiMultiplayer;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiScreenBook;
import net.minecraft.client.gui.GuiScreenDemo;
import net.minecraft.client.gui.GuiScreenRealmsProxy;
import net.minecraft.client.gui.GuiWinGame;
import net.minecraft.client.gui.GuiYesNo;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.gui.IProgressMeter;
import net.minecraft.client.gui.MapItemRenderer;
import net.minecraft.client.gui.achievement.GuiAchievement;
import net.minecraft.client.gui.inventory.GuiContainerCreative;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.ServerData.ServerResourceMode;
import net.minecraft.client.multiplayer.ServerList;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.particle.EffectRenderer;
import net.minecraft.client.particle.EntityPickupFX;
import net.minecraft.client.player.inventory.ContainerLocalMenu;
import net.minecraft.client.player.inventory.LocalBlockIntercommunication;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.ResourcePackRepository;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.stream.IStream;
import net.minecraft.client.stream.MetadataAchievement;
import net.minecraft.client.stream.MetadataCombat;
import net.minecraft.client.stream.MetadataPlayerDeath;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.DataWatcher;
import net.minecraft.entity.DataWatcher.WatchableObject;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLeashKnot;
import net.minecraft.entity.EntityList;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IMerchant;
import net.minecraft.entity.NpcMerchant;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.BaseAttributeMap;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.ai.attributes.RangedAttribute;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityEnderEye;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.entity.item.EntityFireworkRocket;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.item.EntityMinecart.EnumMinecartType;
import net.minecraft.entity.item.EntityPainting;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.monster.EntityGuardian;
import net.minecraft.entity.passive.EntityHorse;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityEgg;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.entity.projectile.EntityLargeFireball;
import net.minecraft.entity.projectile.EntityPotion;
import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.entity.projectile.EntitySnowball;
import net.minecraft.entity.projectile.EntityWitherSkull;
import net.minecraft.init.Items;
import net.minecraft.inventory.AnimalChest;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.Slot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemMap;
import net.minecraft.item.ItemStack;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.PacketThreadUtil;
import net.minecraft.network.play.INetHandlerPlayClient;
import net.minecraft.network.play.client.C00PacketKeepAlive;
import net.minecraft.network.play.client.C03PacketPlayer.C06PacketPlayerPosLook;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.network.play.client.C19PacketResourcePackStatus;
import net.minecraft.network.play.client.C19PacketResourcePackStatus.Action;
import net.minecraft.network.play.server.S00PacketKeepAlive;
import net.minecraft.network.play.server.S01PacketJoinGame;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.network.play.server.S03PacketTimeUpdate;
import net.minecraft.network.play.server.S04PacketEntityEquipment;
import net.minecraft.network.play.server.S05PacketSpawnPosition;
import net.minecraft.network.play.server.S06PacketUpdateHealth;
import net.minecraft.network.play.server.S07PacketRespawn;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.network.play.server.S08PacketPlayerPosLook.EnumFlags;
import net.minecraft.network.play.server.S09PacketHeldItemChange;
import net.minecraft.network.play.server.S0APacketUseBed;
import net.minecraft.network.play.server.S0BPacketAnimation;
import net.minecraft.network.play.server.S0CPacketSpawnPlayer;
import net.minecraft.network.play.server.S0DPacketCollectItem;
import net.minecraft.network.play.server.S0EPacketSpawnObject;
import net.minecraft.network.play.server.S0FPacketSpawnMob;
import net.minecraft.network.play.server.S10PacketSpawnPainting;
import net.minecraft.network.play.server.S11PacketSpawnExperienceOrb;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S13PacketDestroyEntities;
import net.minecraft.network.play.server.S14PacketEntity;
import net.minecraft.network.play.server.S18PacketEntityTeleport;
import net.minecraft.network.play.server.S19PacketEntityHeadLook;
import net.minecraft.network.play.server.S19PacketEntityStatus;
import net.minecraft.network.play.server.S1BPacketEntityAttach;
import net.minecraft.network.play.server.S1CPacketEntityMetadata;
import net.minecraft.network.play.server.S1DPacketEntityEffect;
import net.minecraft.network.play.server.S1EPacketRemoveEntityEffect;
import net.minecraft.network.play.server.S1FPacketSetExperience;
import net.minecraft.network.play.server.S20PacketEntityProperties;
import net.minecraft.network.play.server.S20PacketEntityProperties.Snapshot;
import net.minecraft.network.play.server.S21PacketChunkData;
import net.minecraft.network.play.server.S22PacketMultiBlockChange;
import net.minecraft.network.play.server.S22PacketMultiBlockChange.BlockUpdateData;
import net.minecraft.network.play.server.S23PacketBlockChange;
import net.minecraft.network.play.server.S24PacketBlockAction;
import net.minecraft.network.play.server.S25PacketBlockBreakAnim;
import net.minecraft.network.play.server.S26PacketMapChunkBulk;
import net.minecraft.network.play.server.S27PacketExplosion;
import net.minecraft.network.play.server.S28PacketEffect;
import net.minecraft.network.play.server.S29PacketSoundEffect;
import net.minecraft.network.play.server.S2APacketParticles;
import net.minecraft.network.play.server.S2BPacketChangeGameState;
import net.minecraft.network.play.server.S2CPacketSpawnGlobalEntity;
import net.minecraft.network.play.server.S2DPacketOpenWindow;
import net.minecraft.network.play.server.S2EPacketCloseWindow;
import net.minecraft.network.play.server.S2FPacketSetSlot;
import net.minecraft.network.play.server.S30PacketWindowItems;
import net.minecraft.network.play.server.S31PacketWindowProperty;
import net.minecraft.network.play.server.S32PacketConfirmTransaction;
import net.minecraft.network.play.server.S33PacketUpdateSign;
import net.minecraft.network.play.server.S34PacketMaps;
import net.minecraft.network.play.server.S35PacketUpdateTileEntity;
import net.minecraft.network.play.server.S36PacketSignEditorOpen;
import net.minecraft.network.play.server.S37PacketStatistics;
import net.minecraft.network.play.server.S38PacketPlayerListItem;
import net.minecraft.network.play.server.S38PacketPlayerListItem.Action;
import net.minecraft.network.play.server.S38PacketPlayerListItem.AddPlayerData;
import net.minecraft.network.play.server.S39PacketPlayerAbilities;
import net.minecraft.network.play.server.S3APacketTabComplete;
import net.minecraft.network.play.server.S3BPacketScoreboardObjective;
import net.minecraft.network.play.server.S3CPacketUpdateScore;
import net.minecraft.network.play.server.S3CPacketUpdateScore.Action;
import net.minecraft.network.play.server.S3DPacketDisplayScoreboard;
import net.minecraft.network.play.server.S3EPacketTeams;
import net.minecraft.network.play.server.S3FPacketCustomPayload;
import net.minecraft.network.play.server.S40PacketDisconnect;
import net.minecraft.network.play.server.S41PacketServerDifficulty;
import net.minecraft.network.play.server.S42PacketCombatEvent;
import net.minecraft.network.play.server.S42PacketCombatEvent.Event;
import net.minecraft.network.play.server.S43PacketCamera;
import net.minecraft.network.play.server.S44PacketWorldBorder;
import net.minecraft.network.play.server.S45PacketTitle;
import net.minecraft.network.play.server.S45PacketTitle.Type;
import net.minecraft.network.play.server.S46PacketSetCompressionLevel;
import net.minecraft.network.play.server.S47PacketPlayerListHeaderFooter;
import net.minecraft.network.play.server.S48PacketResourcePackSend;
import net.minecraft.network.play.server.S49PacketUpdateEntityNBT;
import net.minecraft.potion.PotionEffect;
import net.minecraft.realms.DisconnectedRealmsScreen;
import net.minecraft.scoreboard.IScoreObjectiveCriteria;
import net.minecraft.scoreboard.Score;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team.EnumVisible;
import net.minecraft.stats.Achievement;
import net.minecraft.stats.AchievementList;
import net.minecraft.stats.StatBase;
import net.minecraft.stats.StatFileWriter;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBanner;
import net.minecraft.tileentity.TileEntityBeacon;
import net.minecraft.tileentity.TileEntityCommandBlock;
import net.minecraft.tileentity.TileEntityFlowerPot;
import net.minecraft.tileentity.TileEntityMobSpawner;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.tileentity.TileEntitySkull;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.FoodStats;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.StringUtils;
import net.minecraft.village.MerchantRecipeList;
import net.minecraft.world.Explosion;
import net.minecraft.world.WorldProviderSurface;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.WorldSettings.GameType;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.storage.MapData;
import net.minecraft.world.storage.WorldInfo;
import org.apache.logging.log4j.Logger;

public class NetHandlerPlayClient
  implements INetHandlerPlayClient
{
  public void handleMapChunkBulk(S26PacketMapChunkBulk llllllllllllllIlllllIIllIIlIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIIlIIlIl, llllllllllllllIlllllIIllIIlIIllI, gameController);
    int llllllllllllllIlllllIIllIIlIIlII = llIllIlIIlII[1];
    "".length();
    if ("  ".length() >= (0x6D ^ 0x69)) {
      return;
    }
    while (!lIlIIlllIIlIII(llllllllllllllIlllllIIllIIlIIlII, llllllllllllllIlllllIIllIIlIIlIl.getChunkCount()))
    {
      int llllllllllllllIlllllIIllIIlIIIll = llllllllllllllIlllllIIllIIlIIlIl.getChunkX(llllllllllllllIlllllIIllIIlIIlII);
      int llllllllllllllIlllllIIllIIlIIIlI = llllllllllllllIlllllIIllIIlIIlIl.getChunkZ(llllllllllllllIlllllIIllIIlIIlII);
      clientWorldController.doPreChunk(llllllllllllllIlllllIIllIIlIIIll, llllllllllllllIlllllIIllIIlIIIlI, llIllIlIIlII[17]);
      clientWorldController.invalidateBlockReceiveRegion(llllllllllllllIlllllIIllIIlIIIll << llIllIlIIlII[26], llIllIlIIlII[1], llllllllllllllIlllllIIllIIlIIIlI << llIllIlIIlII[26], (llllllllllllllIlllllIIllIIlIIIll << llIllIlIIlII[26]) + llIllIlIIlII[27], llIllIlIIlII[28], (llllllllllllllIlllllIIllIIlIIIlI << llIllIlIIlII[26]) + llIllIlIIlII[27]);
      Chunk llllllllllllllIlllllIIllIIlIIIIl = clientWorldController.getChunkFromChunkCoords(llllllllllllllIlllllIIllIIlIIIll, llllllllllllllIlllllIIllIIlIIIlI);
      llllllllllllllIlllllIIllIIlIIIIl.fillChunk(llllllllllllllIlllllIIllIIlIIlIl.getChunkBytes(llllllllllllllIlllllIIllIIlIIlII), llllllllllllllIlllllIIllIIlIIlIl.getChunkSize(llllllllllllllIlllllIIllIIlIIlII), llIllIlIIlII[17]);
      clientWorldController.markBlockRangeForRenderUpdate(llllllllllllllIlllllIIllIIlIIIll << llIllIlIIlII[26], llIllIlIIlII[1], llllllllllllllIlllllIIllIIlIIIlI << llIllIlIIlII[26], (llllllllllllllIlllllIIllIIlIIIll << llIllIlIIlII[26]) + llIllIlIIlII[27], llIllIlIIlII[28], (llllllllllllllIlllllIIllIIlIIIlI << llIllIlIIlII[26]) + llIllIlIIlII[27]);
      if (lIlIIlllIIlIlI(clientWorldController.provider instanceof WorldProviderSurface)) {
        llllllllllllllIlllllIIllIIlIIIIl.resetRelightChecks();
      }
      llllllllllllllIlllllIIllIIlIIlII++;
    }
  }
  
  private static boolean lIlIIlllIIIlIl(int ???)
  {
    char llllllllllllllIlllllIIIlIIlIllIl;
    return ??? != 0;
  }
  
  public void handleTabComplete(S3APacketTabComplete llllllllllllllIlllllIIlIIlIlllll)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIIlIlllll, llllllllllllllIlllllIIlIIlIlllII, gameController);
    String[] llllllllllllllIlllllIIlIIlIllllI = llllllllllllllIlllllIIlIIlIlllll.func_149630_c();
    if (lIlIIlllIIIlIl(gameController.currentScreen instanceof GuiChat))
    {
      GuiChat llllllllllllllIlllllIIlIIlIlllIl = (GuiChat)gameController.currentScreen;
      llllllllllllllIlllllIIlIIlIlllIl.onAutocompleteResponse(llllllllllllllIlllllIIlIIlIllllI);
    }
  }
  
  public void handleEntityVelocity(S12PacketEntityVelocity llllllllllllllIlllllIlIlIIIIIllI)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIlIIIIIllI, llllllllllllllIlllllIlIlIIIIIlll, gameController);
    Entity llllllllllllllIlllllIlIlIIIIIlIl = clientWorldController.getEntityByID(llllllllllllllIlllllIlIlIIIIIllI.getEntityID());
    if (lIlIIlllIIIlll(llllllllllllllIlllllIlIlIIIIIlIl)) {
      llllllllllllllIlllllIlIlIIIIIlIl.setVelocity(llllllllllllllIlllllIlIlIIIIIllI.getMotionX() / 8000.0D, llllllllllllllIlllllIlIlIIIIIllI.getMotionY() / 8000.0D, llllllllllllllIlllllIlIlIIIIIllI.getMotionZ() / 8000.0D);
    }
  }
  
  private static void lIlIIlllIIIIll()
  {
    llIllIlIIlII = new int[59];
    llIllIlIIlII[0] = (0x81 ^ 0xAD ^ 0xB5 ^ 0x8D);
    llIllIlIIlII[1] = ((0x5D ^ 0x6F ^ 0xB1 ^ 0xC0) & (0x53 ^ 0x1C ^ 0x55 ^ 0x59 ^ -" ".length()));
    llIllIlIIlII[2] = (40 + '¤' - 49 + 36 ^ 113 + '£' - 172 + 77);
    llIllIlIIlII[3] = (97 + 123 - -6 + 3 ^ 58 + '¦' - 167 + 134);
    llIllIlIIlII[4] = (0x59 ^ 0x65);
    llIllIlIIlII[5] = (0x9A ^ 0xC6 ^ 0xEB ^ 0x8A);
    llIllIlIIlII[6] = (9 + 'Ç' - 130 + 131 ^ 10 + 29 - -96 + 15);
    llIllIlIIlII[7] = (0x36 ^ 0x7B);
    llIllIlIIlII[8] = (52 + 103 - 121 + 186 ^ 45 + 31 - -61 + 20);
    llIllIlIIlII[9] = (0x7B ^ 0x33);
    llIllIlIIlII[10] = (37 + 'å' - 33 + 21 ^ '¢' + 110 - 201 + 107);
    llIllIlIIlII[11] = (0x49 ^ 0x76);
    llIllIlIIlII[12] = (0x14 ^ 0x54);
    llIllIlIIlII[13] = (59 + '' - -17 + 25 ^ '«' + 68 - 230 + 167);
    llIllIlIIlII[14] = (0xAF ^ 0x91);
    llIllIlIIlII[15] = (0x54 ^ 0x1D);
    llIllIlIIlII[16] = (0x62 ^ 0x6C ^ 0x52 ^ 0x17);
    llIllIlIIlII[17] = " ".length();
    llIllIlIIlII[18] = (0xB2 ^ 0x80);
    llIllIlIIlII[19] = (0x2B ^ 0x14 ^ 0xD5 ^ 0xA4);
    llIllIlIIlII[20] = (0x94 ^ 0xA7);
    llIllIlIIlII[21] = "  ".length();
    llIllIlIIlII[22] = (0x2C ^ 0x6A);
    llIllIlIIlII[23] = (0xFFFFFFFF & 0xFFFF);
    llIllIlIIlII[24] = (0xED6E & 0x13F9);
    llIllIlIIlII[25] = "   ".length();
    llIllIlIIlII[26] = (0x22 ^ 0x79 ^ 0x3C ^ 0x63);
    llIllIlIIlII[27] = (0x8 ^ 0x7);
    llIllIlIIlII[28] = (0xB7E3 & 0x491C);
    llIllIlIIlII[29] = (0x87 ^ 0x82);
    llIllIlIIlII[30] = (0x9 ^ 0xF);
    llIllIlIIlII[31] = (0x19 ^ 0x53 ^ 0x75 ^ 0x2A);
    llIllIlIIlII[32] = (0x70 ^ 0x3B ^ 0x69 ^ 0x25);
    llIllIlIIlII[33] = (0x92 ^ 0x85 ^ 0xDF ^ 0xC0);
    llIllIlIIlII[34] = (0xAB ^ 0xA2);
    llIllIlIIlII[35] = (-" ".length());
    llIllIlIIlII[36] = (0x7B ^ 0x5F);
    llIllIlIIlII[37] = (0x2D ^ 0x0);
    llIllIlIIlII[38] = (0xE1 ^ 0xA6 ^ 0x35 ^ 0x79);
    llIllIlIIlII[39] = (0xB2 ^ 0x93 ^ 0xE ^ 0x23);
    llIllIlIIlII[40] = (0x52 ^ 0x5F);
    llIllIlIIlII[41] = (0x95 ^ 0x9B);
    llIllIlIIlII[42] = (0xA4 ^ 0xB4);
    llIllIlIIlII[43] = (0x13 ^ 0x33 ^ 0x96 ^ 0xA7);
    llIllIlIIlII[44] = (0xCFFB & 0x33EC);
    llIllIlIIlII[45] = (0x1C ^ 0x2D ^ 0xB8 ^ 0x9B);
    llIllIlIIlII[46] = (0xD8 ^ 0xBC ^ 0xA ^ 0x7D);
    llIllIlIIlII[47] = (0x1 ^ 0x35 ^ 0x99 ^ 0xBB);
    llIllIlIIlII[48] = (0xF4 ^ 0x9C ^ 93 + 31 - 8 + 11);
    llIllIlIIlII[49] = (0x84 ^ 0x9C);
    llIllIlIIlII[50] = (0xA7 ^ 0xBE);
    llIllIlIIlII[51] = (0xB8 ^ 0xA2);
    llIllIlIIlII[52] = (-" ".length() & 0xFFFFFFFF & 0x7FFF);
    llIllIlIIlII[53] = (121 + 4 - 18 + 46 ^ 86 + 95 - 75 + 24);
    llIllIlIIlII[54] = (0x45 ^ 0x59);
    llIllIlIIlII[55] = (0xA6 ^ 0x81 ^ 0x29 ^ 0x13);
    llIllIlIIlII[56] = (0x5F ^ 0x65 ^ 0xB2 ^ 0x96);
    llIllIlIIlII[57] = (0x1A ^ 0x52 ^ 0xCC ^ 0x9B);
    llIllIlIIlII[58] = (0x5E ^ 0x7E);
  }
  
  public void handleCamera(S43PacketCamera llllllllllllllIlllllIIlIlIllIIll)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIlIllIIll, llllllllllllllIlllllIIlIlIllIIIl, gameController);
    Entity llllllllllllllIlllllIIlIlIllIIlI = llllllllllllllIlllllIIlIlIllIIll.getEntity(clientWorldController);
    if (lIlIIlllIIIlll(llllllllllllllIlllllIIlIlIllIIlI)) {
      gameController.setRenderViewEntity(llllllllllllllIlllllIIlIlIllIIlI);
    }
  }
  
  public void handleSoundEffect(S29PacketSoundEffect llllllllllllllIlllllIIlIIlIlIlIl)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIIlIlIlIl, llllllllllllllIlllllIIlIIlIlIllI, gameController);
    gameController.theWorld.playSound(llllllllllllllIlllllIIlIIlIlIlIl.getX(), llllllllllllllIlllllIIlIIlIlIlIl.getY(), llllllllllllllIlllllIIlIIlIlIlIl.getZ(), llllllllllllllIlllllIIlIIlIlIlIl.getSoundName(), llllllllllllllIlllllIIlIIlIlIlIl.getVolume(), llllllllllllllIlllllIIlIIlIlIlIl.getPitch(), llIllIlIIlII[1]);
  }
  
  public void handleChangeGameState(S2BPacketChangeGameState llllllllllllllIlllllIIllIIIIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIIIIlIll, llllllllllllllIlllllIIllIIIlIIll, gameController);
    EntityPlayer llllllllllllllIlllllIIllIIIlIIIl = gameController.thePlayer;
    int llllllllllllllIlllllIIllIIIlIIII = llllllllllllllIlllllIIllIIIIlIll.getGameState();
    float llllllllllllllIlllllIIllIIIIllll = llllllllllllllIlllllIIllIIIIlIll.func_149137_d();
    int llllllllllllllIlllllIIllIIIIlllI = MathHelper.floor_float(llllllllllllllIlllllIIllIIIIllll + 0.5F);
    if ((lIlIIlllIIllll(llllllllllllllIlllllIIllIIIlIIII)) && (lIlIIlllIlIIII(llllllllllllllIlllllIIllIIIlIIII, S2BPacketChangeGameState.MESSAGE_NAMES.length)) && (lIlIIlllIIIlll(S2BPacketChangeGameState.MESSAGE_NAMES[llllllllllllllIlllllIIllIIIlIIII]))) {
      llllllllllllllIlllllIIllIIIlIIIl.addChatComponentMessage(new ChatComponentTranslation(S2BPacketChangeGameState.MESSAGE_NAMES[llllllllllllllIlllllIIllIIIlIIII], new Object[llIllIlIIlII[1]]));
    }
    if (lIlIIlllIIIlII(llllllllllllllIlllllIIllIIIlIIII, llIllIlIIlII[17]))
    {
      clientWorldController.getWorldInfo().setRaining(llIllIlIIlII[17]);
      clientWorldController.setRainStrength(0.0F);
      "".length();
      if ((0x39 ^ 0x26 ^ 0x71 ^ 0x6B) != 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIIllIIIlIIII, llIllIlIIlII[21]))
    {
      clientWorldController.getWorldInfo().setRaining(llIllIlIIlII[1]);
      clientWorldController.setRainStrength(1.0F);
      "".length();
      if ("   ".length() >= " ".length()) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIIllIIIlIIII, llIllIlIIlII[25]))
    {
      gameController.playerController.setGameType(WorldSettings.GameType.getByID(llllllllllllllIlllllIIllIIIIlllI));
      "".length();
      if (" ".length() > 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIIllIIIlIIII, llIllIlIIlII[26]))
    {
      gameController.displayGuiScreen(new GuiWinGame());
      "".length();
      if (-" ".length() <= 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIIllIIIlIIII, llIllIlIIlII[29]))
    {
      GameSettings llllllllllllllIlllllIIllIIIIllIl = gameController.gameSettings;
      if (lIlIIlllIIlIlI(lIlIIlllIlIlII(llllllllllllllIlllllIIllIIIIllll, 0.0F)))
      {
        gameController.displayGuiScreen(new GuiScreenDemo());
        "".length();
        if (" ".length() > ((0x1F ^ 0x23) & (0xB9 ^ 0x85 ^ 0xFFFFFFFF))) {}
      }
      else if (lIlIIlllIIlIlI(lIlIIlllIlIlII(llllllllllllllIlllllIIllIIIIllll, 101.0F)))
      {
        gameController.ingameGUI.getChatGUI().printChatMessage(new ChatComponentTranslation(llIllIlIIIIl[llIllIlIIlII[40]], new Object[] { GameSettings.getKeyDisplayString(keyBindForward.getKeyCode()), GameSettings.getKeyDisplayString(keyBindLeft.getKeyCode()), GameSettings.getKeyDisplayString(keyBindBack.getKeyCode()), GameSettings.getKeyDisplayString(keyBindRight.getKeyCode()) }));
        "".length();
        if (-" ".length() < 0) {}
      }
      else if (lIlIIlllIIlIlI(lIlIIlllIlIlII(llllllllllllllIlllllIIllIIIIllll, 102.0F)))
      {
        gameController.ingameGUI.getChatGUI().printChatMessage(new ChatComponentTranslation(llIllIlIIIIl[llIllIlIIlII[41]], new Object[] { GameSettings.getKeyDisplayString(keyBindJump.getKeyCode()) }));
        "".length();
        if ("  ".length() != 0) {}
      }
      else if (lIlIIlllIIlIlI(lIlIIlllIlIlII(llllllllllllllIlllllIIllIIIIllll, 103.0F)))
      {
        gameController.ingameGUI.getChatGUI().printChatMessage(new ChatComponentTranslation(llIllIlIIIIl[llIllIlIIlII[27]], new Object[] { GameSettings.getKeyDisplayString(keyBindInventory.getKeyCode()) }));
        "".length();
        if ("  ".length() <= "  ".length()) {}
      }
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIIllIIIlIIII, llIllIlIIlII[30]))
    {
      clientWorldController.playSound(posX, posY + llllllllllllllIlllllIIllIIIlIIIl.getEyeHeight(), posZ, llIllIlIIIIl[llIllIlIIlII[42]], 0.18F, 0.45F, llIllIlIIlII[1]);
      "".length();
      if (((0x54 ^ 0xD) & (0xFB ^ 0xA2 ^ 0xFFFFFFFF)) == 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIIllIIIlIIII, llIllIlIIlII[32]))
    {
      clientWorldController.setRainStrength(llllllllllllllIlllllIIllIIIIllll);
      "".length();
      if (-" ".length() < 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIIllIIIlIIII, llIllIlIIlII[33]))
    {
      clientWorldController.setThunderStrength(llllllllllllllIlllllIIllIIIIllll);
      "".length();
      if ((0x46 ^ 0x79 ^ 0xFB ^ 0xC0) <= (0x34 ^ 0x48 ^ 0xD1 ^ 0xA9)) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIIllIIIlIIII, llIllIlIIlII[2]))
    {
      clientWorldController.spawnParticle(EnumParticleTypes.MOB_APPEARANCE, posX, posY, posZ, 0.0D, 0.0D, 0.0D, new int[llIllIlIIlII[1]]);
      clientWorldController.playSound(posX, posY, posZ, llIllIlIIIIl[llIllIlIIlII[43]], 1.0F, 1.0F, llIllIlIIlII[1]);
    }
  }
  
  public void handleSpawnPainting(S10PacketSpawnPainting llllllllllllllIlllllIlIlIIIIllII)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIlIIIIllII, llllllllllllllIlllllIlIlIIIIllIl, gameController);
    EntityPainting llllllllllllllIlllllIlIlIIIIlllI = new EntityPainting(clientWorldController, llllllllllllllIlllllIlIlIIIIllII.getPosition(), llllllllllllllIlllllIlIlIIIIllII.getFacing(), llllllllllllllIlllllIlIlIIIIllII.getTitle());
    clientWorldController.addEntityToWorld(llllllllllllllIlllllIlIlIIIIllII.getEntityID(), llllllllllllllIlllllIlIlIIIIlllI);
  }
  
  public void handleRespawn(S07PacketRespawn llllllllllllllIlllllIIlllIllIIIl)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlllIllIIIl, llllllllllllllIlllllIIlllIllIlIl, gameController);
    if (lIlIIlllIlIIll(llllllllllllllIlllllIIlllIllIIIl.getDimensionID(), gameController.thePlayer.dimension))
    {
      doneLoadingTerrain = llIllIlIIlII[1];
      Scoreboard llllllllllllllIlllllIIlllIllIIll = clientWorldController.getScoreboard();
      clientWorldController = new WorldClient(llllllllllllllIlllllIIlllIllIlIl, new WorldSettings(0L, llllllllllllllIlllllIIlllIllIIIl.getGameType(), llIllIlIIlII[1], gameController.theWorld.getWorldInfo().isHardcoreModeEnabled(), llllllllllllllIlllllIIlllIllIIIl.getWorldType()), llllllllllllllIlllllIIlllIllIIIl.getDimensionID(), llllllllllllllIlllllIIlllIllIIIl.getDifficulty(), gameController.mcProfiler);
      clientWorldController.setWorldScoreboard(llllllllllllllIlllllIIlllIllIIll);
      gameController.loadWorld(clientWorldController);
      gameController.thePlayer.dimension = llllllllllllllIlllllIIlllIllIIIl.getDimensionID();
      gameController.displayGuiScreen(new GuiDownloadTerrain(llllllllllllllIlllllIIlllIllIlIl));
    }
    gameController.setDimensionAndSpawnPlayer(llllllllllllllIlllllIIlllIllIIIl.getDimensionID());
    gameController.playerController.setGameType(llllllllllllllIlllllIIlllIllIIIl.getGameType());
  }
  
  public void cleanup()
  {
    ;
    clientWorldController = null;
  }
  
  private static void lIlIIlllIIIIlI()
  {
    llIllIlIIIIl = new String[llIllIlIIlII[58]];
    llIllIlIIIIl[llIllIlIIlII[1]] = lIlIIllIllIIIl("nu/TxnwrZDQ2F43ehT3Lwg==", "MckDr");
    llIllIlIIIIl[llIllIlIIlII[17]] = lIlIIllIllIIIl("bXuBL/2mT08CAuR/UVmEfQ==", "AIMlh");
    llIllIlIIIIl[llIllIlIIlII[21]] = lIlIIllIllIIlI("HD0LIQIWOh0hGVY4FzEZ", "xTxBm");
    llIllIlIIIIl[llIllIlIIlII[25]] = lIlIIllIllIIll("WWq73tFMvgUEuqwLBRYd1Q==", "hZWOc");
    llIllIlIIIIl[llIllIlIIlII[26]] = lIlIIllIllIIlI("NRsvAAwqVC4WAQ==", "GzAdc");
    llIllIlIIIIl[llIllIlIIlII[29]] = lIlIIllIllIIlI("Gio2KikFZSghNg==", "hKXNF");
    llIllIlIIIIl[llIllIlIIlII[30]] = lIlIIllIllIIll("tjLack8b9r4yd6F+W6aWsg==", "TFnNP");
    llIllIlIIIIl[llIllIlIIlII[32]] = lIlIIllIllIIIl("awr8izwzrE92yAW0dFbtDg3OvnNZPp4P", "MJIyH");
    llIllIlIIIIl[llIllIlIIlII[33]] = lIlIIllIllIIIl("11CnJ5D44Leu9xf4hYDX7HEOs04Qr1ZV", "DQACq");
    llIllIlIIIIl[llIllIlIIlII[34]] = lIlIIllIllIIIl("eOM0Zp/9v7qmlXaktqaI8Q==", "zAIDK");
    llIllIlIIIIl[llIllIlIIlII[2]] = lIlIIllIllIIIl("9mSWaRoJJ6Mvke5WaOCRIYEckcUfwIPJhP9gyp1KBCU=", "juxsw");
    llIllIlIIIIl[llIllIlIIlII[38]] = lIlIIllIllIIll("K2EOoMzh18Q=", "ZGlTd");
    llIllIlIIIIl[llIllIlIIlII[39]] = lIlIIllIllIIIl("UwyAXQpQmAw=", "MVFPx");
    llIllIlIIIIl[llIllIlIIlII[40]] = lIlIIllIllIIlI("Mh8CNmQ+HwMpZDsVGTwnMxQb", "VzoYJ");
    llIllIlIIIIl[llIllIlIIlII[41]] = lIlIIllIllIIIl("RMInkXf7640LT/SGCPCNyA==", "eXNvC");
    llIllIlIIIIl[llIllIlIIlII[27]] = lIlIIllIllIIll("qFR+IqvItEiT2G0+CLJ/e6F+KYB1ohJn", "rxtuD");
    llIllIlIIIIl[llIllIlIIlII[42]] = lIlIIllIllIIll("eREQBBh1ZWvR6PhsAwGv2Ll1qkTJq/lv", "MNcgH");
    llIllIlIIIIl[llIllIlIIlII[43]] = lIlIIllIllIIlI("Ci0neCkSIzcyJwYsazU7FTEg", "gBEVN");
    llIllIlIIIIl[llIllIlIIlII[45]] = lIlIIllIllIIll("354zsYVQl3M=", "fYmZf");
    llIllIlIIIIl[llIllIlIIlII[46]] = lIlIIllIllIIlI("", "mCYYE");
    llIllIlIIIIl[llIllIlIIlII[0]] = lIlIIllIllIIlI("", "RFZVb");
    llIllIlIIIIl[llIllIlIIlII[31]] = lIlIIllIllIIlI("HQo1DzxLQGw=", "qoCjP");
    llIllIlIIIIl[llIllIlIIlII[47]] = lIlIIllIllIIIl("nJSDBwyR4jUt6q+98Vl1Cw==", "PUJCv");
    llIllIlIIIIl[llIllIlIIlII[48]] = lIlIIllIllIIlI("AicOFgo=", "qFxsy");
    llIllIlIIIIl[llIllIlIIlII[49]] = lIlIIllIllIIll("wsq/NKfX+y8eJIVkSsLGew==", "ApfxF");
    llIllIlIIIIl[llIllIlIIlII[50]] = lIlIIllIllIIlI("JhcROg4LXxB2BgoZAHYeFxkAM0oMFgI5", "exdVj");
    llIllIlIIIIl[llIllIlIIlII[51]] = lIlIIllIllIIIl("Nam6vGcUby0H4DoSoYjjUQ==", "hGQcy");
    llIllIlIIIIl[llIllIlIIlII[53]] = lIlIIllIllIIlI("IiAkGgEfBjY=", "ocXXN");
    llIllIlIIIIl[llIllIlIIlII[54]] = lIlIIllIllIIll("ynJjQcCpssVRAaQJ1xaoI/HUgI1Gft7AfTeTb13mXGD7sTu9//+JeQ==", "IhiTG");
    llIllIlIIIIl[llIllIlIIlII[55]] = lIlIIllIllIIIl("9+XdTmwsFuSXDzhHRJofi4Sm/xp+SSW2YD2nFIPpxAjysNW9v6e3hA==", "CsFST");
    llIllIlIIIIl[llIllIlIIlII[56]] = lIlIIllIllIIll("Po8K1kTUzpT5AAA47RkXHjVzSk0qH1Q/4cG70wFOgWpmAllD1xWvp6dL4XLn1ySLohqRMLGDWzI3QkIzZCqBNu8tI/vm5sGi", "ifncX");
    llIllIlIIIIl[llIllIlIIlII[57]] = lIlIIllIllIIlI("Qg==", "kltWQ");
  }
  
  public void handleRemoveEntityEffect(S1EPacketRemoveEntityEffect llllllllllllllIlllllIIlIlIIIIllI)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIlIIIIllI, llllllllllllllIlllllIIlIlIIIIlll, gameController);
    Entity llllllllllllllIlllllIIlIlIIIIlIl = clientWorldController.getEntityByID(llllllllllllllIlllllIIlIlIIIIllI.getEntityId());
    if (lIlIIlllIIIlIl(llllllllllllllIlllllIIlIlIIIIlIl instanceof EntityLivingBase)) {
      ((EntityLivingBase)llllllllllllllIlllllIIlIlIIIIlIl).removePotionEffectClient(llllllllllllllIlllllIIlIlIIIIllI.getEffectId());
    }
  }
  
  private static String lIlIIllIllIIIl(String llllllllllllllIlllllIIIlIlIllIIl, String llllllllllllllIlllllIIIlIlIlIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlllllIIIlIlIlllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllllIIIlIlIlIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlllllIIIlIlIllIll = Cipher.getInstance("Blowfish");
      llllllllllllllIlllllIIIlIlIllIll.init(llIllIlIIlII[21], llllllllllllllIlllllIIIlIlIlllII);
      return new String(llllllllllllllIlllllIIIlIlIllIll.doFinal(Base64.getDecoder().decode(llllllllllllllIlllllIIIlIlIllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlllllIIIlIlIllIlI)
    {
      llllllllllllllIlllllIIIlIlIllIlI.printStackTrace();
    }
    return null;
  }
  
  public void handleUpdateSign(S33PacketUpdateSign llllllllllllllIlllllIIllIllIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIllIIlIl, llllllllllllllIlllllIIllIllIIIIl, gameController);
    boolean llllllllllllllIlllllIIllIllIIlII = llIllIlIIlII[1];
    if (lIlIIlllIIIlIl(gameController.theWorld.isBlockLoaded(llllllllllllllIlllllIIllIllIIlIl.getPos())))
    {
      TileEntity llllllllllllllIlllllIIllIllIIIll = gameController.theWorld.getTileEntity(llllllllllllllIlllllIIllIllIIlIl.getPos());
      if (lIlIIlllIIIlIl(llllllllllllllIlllllIIllIllIIIll instanceof TileEntitySign))
      {
        TileEntitySign llllllllllllllIlllllIIllIllIIIlI = (TileEntitySign)llllllllllllllIlllllIIllIllIIIll;
        if (lIlIIlllIIIlIl(llllllllllllllIlllllIIllIllIIIlI.getIsEditable()))
        {
          System.arraycopy(llllllllllllllIlllllIIllIllIIlIl.getLines(), llIllIlIIlII[1], signText, llIllIlIIlII[1], llIllIlIIlII[26]);
          llllllllllllllIlllllIIllIllIIIlI.markDirty();
        }
        llllllllllllllIlllllIIllIllIIlII = llIllIlIIlII[17];
      }
    }
    if ((lIlIIlllIIlIlI(llllllllllllllIlllllIIllIllIIlII)) && (lIlIIlllIIIlll(gameController.thePlayer))) {
      gameController.thePlayer.addChatMessage(new ChatComponentText(String.valueOf(new StringBuilder(llIllIlIIIIl[llIllIlIIlII[2]]).append(llllllllllllllIlllllIIllIllIIlIl.getPos().getX()).append(llIllIlIIIIl[llIllIlIIlII[38]]).append(llllllllllllllIlllllIIllIllIIlIl.getPos().getY()).append(llIllIlIIIIl[llIllIlIIlII[39]]).append(llllllllllllllIlllllIIllIllIIlIl.getPos().getZ()))));
    }
  }
  
  public void addToSendQueue(Packet llllllllllllllIlllllIlIIIIllIlIl)
  {
    ;
    ;
    netManager.sendPacket(llllllllllllllIlllllIlIIIIllIlIl);
  }
  
  public void handleHeldItemChange(S09PacketHeldItemChange llllllllllllllIlllllIlIIlIllllIl)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIlIllllIl, llllllllllllllIlllllIlIIlIlllllI, gameController);
    if ((lIlIIlllIIllll(llllllllllllllIlllllIlIIlIllllIl.getHeldItemHotbarIndex())) && (lIlIIlllIlIIII(llllllllllllllIlllllIlIIlIllllIl.getHeldItemHotbarIndex(), InventoryPlayer.getHotbarSize()))) {
      gameController.thePlayer.inventory.currentItem = llllllllllllllIlllllIlIIlIllllIl.getHeldItemHotbarIndex();
    }
  }
  
  static
  {
    lIlIIlllIIIIll();
    lIlIIlllIIIIlI();
  }
  
  public void handleCollectItem(S0DPacketCollectItem llllllllllllllIlllllIlIIIIlIllIl)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIIIlIllIl, llllllllllllllIlllllIlIIIIlIlllI, gameController);
    Entity llllllllllllllIlllllIlIIIIlIllII = clientWorldController.getEntityByID(llllllllllllllIlllllIlIIIIlIllIl.getCollectedItemEntityID());
    EntityLivingBase llllllllllllllIlllllIlIIIIlIlIll = (EntityLivingBase)clientWorldController.getEntityByID(llllllllllllllIlllllIlIIIIlIllIl.getEntityID());
    if (lIlIIlllIlIIlI(llllllllllllllIlllllIlIIIIlIlIll)) {
      llllllllllllllIlllllIlIIIIlIlIll = gameController.thePlayer;
    }
    if (lIlIIlllIIIlll(llllllllllllllIlllllIlIIIIlIllII))
    {
      if (lIlIIlllIIIlIl(llllllllllllllIlllllIlIIIIlIllII instanceof EntityXPOrb))
      {
        clientWorldController.playSoundAtEntity(llllllllllllllIlllllIlIIIIlIllII, llIllIlIIIIl[llIllIlIIlII[26]], 0.2F, ((avRandomizer.nextFloat() - avRandomizer.nextFloat()) * 0.7F + 1.0F) * 2.0F);
        "".length();
        if (" ".length() >= 0) {}
      }
      else
      {
        clientWorldController.playSoundAtEntity(llllllllllllllIlllllIlIIIIlIllII, llIllIlIIIIl[llIllIlIIlII[29]], 0.2F, ((avRandomizer.nextFloat() - avRandomizer.nextFloat()) * 0.7F + 1.0F) * 2.0F);
      }
      gameController.effectRenderer.addEffect(new EntityPickupFX(clientWorldController, llllllllllllllIlllllIlIIIIlIllII, llllllllllllllIlllllIlIIIIlIlIll, 0.5F));
      "".length();
    }
  }
  
  private static String lIlIIllIllIIlI(String llllllllllllllIlllllIIIlIllIlIIl, String llllllllllllllIlllllIIIlIllIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlllllIIIlIllIlIIl = new String(Base64.getDecoder().decode(llllllllllllllIlllllIIIlIllIlIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlllllIIIlIllIllII = new StringBuilder();
    char[] llllllllllllllIlllllIIIlIllIlIll = llllllllllllllIlllllIIIlIllIllIl.toCharArray();
    int llllllllllllllIlllllIIIlIllIlIlI = llIllIlIIlII[1];
    byte llllllllllllllIlllllIIIlIllIIlII = llllllllllllllIlllllIIIlIllIlIIl.toCharArray();
    int llllllllllllllIlllllIIIlIllIIIll = llllllllllllllIlllllIIIlIllIIlII.length;
    long llllllllllllllIlllllIIIlIllIIIlI = llIllIlIIlII[1];
    while (lIlIIlllIlIIII(llllllllllllllIlllllIIIlIllIIIlI, llllllllllllllIlllllIIIlIllIIIll))
    {
      char llllllllllllllIlllllIIIlIllIllll = llllllllllllllIlllllIIIlIllIIlII[llllllllllllllIlllllIIIlIllIIIlI];
      "".length();
      "".length();
      if ("  ".length() == 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlllllIIIlIllIllII);
  }
  
  public void handleCustomPayload(S3FPacketCustomPayload llllllllllllllIlllllIIlIIIlIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIIIlIlIll, llllllllllllllIlllllIIlIIIlIIIll, gameController);
    if (lIlIIlllIIIlIl(llIllIlIIIIl[llIllIlIIlII[49]].equals(llllllllllllllIlllllIIlIIIlIlIll.getChannelName())))
    {
      PacketBuffer llllllllllllllIlllllIIlIIIlIlIlI = llllllllllllllIlllllIIlIIIlIlIll.getBufferData();
      try
      {
        int llllllllllllllIlllllIIlIIIlIlIIl = llllllllllllllIlllllIIlIIIlIlIlI.readInt();
        GuiScreen llllllllllllllIlllllIIlIIIlIlIII = gameController.currentScreen;
        if ((lIlIIlllIIIlll(llllllllllllllIlllllIIlIIIlIlIII)) && (lIlIIlllIIIlIl(llllllllllllllIlllllIIlIIIlIlIII instanceof GuiMerchant)) && (lIlIIlllIIIlII(llllllllllllllIlllllIIlIIIlIlIIl, gameController.thePlayer.openContainer.windowId)))
        {
          IMerchant llllllllllllllIlllllIIlIIIlIIlll = ((GuiMerchant)llllllllllllllIlllllIIlIIIlIlIII).getMerchant();
          MerchantRecipeList llllllllllllllIlllllIIlIIIlIIllI = MerchantRecipeList.readFromBuf(llllllllllllllIlllllIIlIIIlIlIlI);
          llllllllllllllIlllllIIlIIIlIIlll.setRecipes(llllllllllllllIlllllIIlIIIlIIllI);
          "".length();
          if (((0x5D ^ 0x7C) & (0x43 ^ 0x62 ^ 0xFFFFFFFF)) != 0) {
            return;
          }
        }
      }
      catch (IOException llllllllllllllIlllllIIlIIIlIIlIl)
      {
        llllllllllllllIlllllIIlIIIlIIlIl = llllllllllllllIlllllIIlIIIlIIlIl;
        logger.error(llIllIlIIIIl[llIllIlIIlII[50]], llllllllllllllIlllllIIlIIIlIIlIl);
        "".length();
        "".length();
        if (" ".length() != 0) {
          return;
        }
        return;
      }
      finally
      {
        llllllllllllllIlllllIIlIIIIlllII = finally;
        "".length();
        throw llllllllllllllIlllllIIlIIIIlllII;
      }
      "".length();
      "".length();
      if ("  ".length() != "   ".length()) {}
    }
    else if (lIlIIlllIIIlIl(llIllIlIIIIl[llIllIlIIlII[51]].equals(llllllllllllllIlllllIIlIIIlIlIll.getChannelName())))
    {
      gameController.thePlayer.setClientBrand(llllllllllllllIlllllIIlIIIlIlIll.getBufferData().readStringFromBuffer(llIllIlIIlII[52]));
      "".length();
      if ("  ".length() >= ((0x4 ^ 0x14) & (0xD ^ 0x1D ^ 0xFFFFFFFF))) {}
    }
    else if (lIlIIlllIIIlIl(llIllIlIIIIl[llIllIlIIlII[53]].equals(llllllllllllllIlllllIIlIIIlIlIll.getChannelName())))
    {
      ItemStack llllllllllllllIlllllIIlIIIlIIlII = gameController.thePlayer.getCurrentEquippedItem();
      if ((lIlIIlllIIIlll(llllllllllllllIlllllIIlIIIlIIlII)) && (lIlIIlllIlIlIl(llllllllllllllIlllllIIlIIIlIIlII.getItem(), Items.written_book))) {
        gameController.displayGuiScreen(new GuiScreenBook(gameController.thePlayer, llllllllllllllIlllllIIlIIIlIIlII, llIllIlIIlII[1]));
      }
    }
  }
  
  public void handleTitle(S45PacketTitle llllllllllllllIlllllIIlIlIIllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIlIIllIll, llllllllllllllIlllllIIlIlIlIIIlI, gameController);
    S45PacketTitle.Type llllllllllllllIlllllIIlIlIlIIIII = llllllllllllllIlllllIIlIlIIllIll.getType();
    String llllllllllllllIlllllIIlIlIIlllll = null;
    String llllllllllllllIlllllIIlIlIIllllI = null;
    if (lIlIIlllIIIlll(llllllllllllllIlllllIIlIlIIllIll.getMessage()))
    {
      "".length();
      if (-" ".length() <= ((0xA ^ 0x18 ^ 0x68 ^ 0x71) & (0x3D ^ 0x16 ^ 0x3C ^ 0x1C ^ -" ".length()))) {
        break label96;
      }
    }
    label96:
    String llllllllllllllIlllllIIlIlIIlllIl = llIllIlIIIIl[llIllIlIIlII[45]];
    switch ($SWITCH_TABLE$net$minecraft$network$play$server$S45PacketTitle$Type()[llllllllllllllIlllllIIlIlIlIIIII.ordinal()])
    {
    case 1: 
      llllllllllllllIlllllIIlIlIIlllll = llllllllllllllIlllllIIlIlIIlllIl;
      "".length();
      if (((0x3C ^ 0x66) & (0x7A ^ 0x20 ^ 0xFFFFFFFF)) > "   ".length()) {
        return;
      }
      break;
    case 2: 
      llllllllllllllIlllllIIlIlIIllllI = llllllllllllllIlllllIIlIlIIlllIl;
      "".length();
      if (((0x52 ^ 0x7E) & (0x62 ^ 0x4E ^ 0xFFFFFFFF)) >= "  ".length()) {
        return;
      }
      break;
    case 5: 
      gameController.ingameGUI.displayTitle(llIllIlIIIIl[llIllIlIIlII[46]], llIllIlIIIIl[llIllIlIIlII[0]], llIllIlIIlII[35], llIllIlIIlII[35], llIllIlIIlII[35]);
      gameController.ingameGUI.func_175177_a();
      return;
    }
    gameController.ingameGUI.displayTitle(llllllllllllllIlllllIIlIlIIlllll, llllllllllllllIlllllIIlIlIIllllI, llllllllllllllIlllllIIlIlIIllIll.getFadeInTime(), llllllllllllllIlllllIIlIlIIllIll.getDisplayTime(), llllllllllllllIlllllIIlIlIIllIll.getFadeOutTime());
  }
  
  public void onDisconnect(IChatComponent llllllllllllllIlllllIlIIIlIlIIII)
  {
    ;
    ;
    gameController.loadWorld(null);
    if (lIlIIlllIIIlll(guiScreenServer))
    {
      if (lIlIIlllIIIlIl(guiScreenServer instanceof GuiScreenRealmsProxy))
      {
        gameController.displayGuiScreen(new DisconnectedRealmsScreen(((GuiScreenRealmsProxy)guiScreenServer).func_154321_a(), llIllIlIIIIl[llIllIlIIlII[17]], llllllllllllllIlllllIlIIIlIlIIII).getProxy());
        "".length();
        if (((37 + 36 - -40 + 22 ^ 36 + 65 - 60 + 105) & (0xA5 ^ 0xB5 ^ 0x98 ^ 0x9D ^ -" ".length())) >= 0) {}
      }
      else
      {
        gameController.displayGuiScreen(new GuiDisconnected(guiScreenServer, llIllIlIIIIl[llIllIlIIlII[21]], llllllllllllllIlllllIlIIIlIlIIII));
        "".length();
        if ("   ".length() >= 0) {}
      }
    }
    else {
      gameController.displayGuiScreen(new GuiDisconnected(new GuiMultiplayer(new GuiMainMenu()), llIllIlIIIIl[llIllIlIIlII[25]], llllllllllllllIlllllIlIIIlIlIIII));
    }
  }
  
  public void handleWorldBorder(S44PacketWorldBorder llllllllllllllIlllllIIlIlIlIlIIl)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIlIlIlIIl, llllllllllllllIlllllIIlIlIlIllII, gameController);
    llllllllllllllIlllllIIlIlIlIlIIl.func_179788_a(clientWorldController.getWorldBorder());
  }
  
  public void handleEntityAttach(S1BPacketEntityAttach llllllllllllllIlllllIIllllIlIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllllIlIIlI, llllllllllllllIlllllIIllllIlIIll, gameController);
    Entity llllllllllllllIlllllIIllllIlIlll = clientWorldController.getEntityByID(llllllllllllllIlllllIIllllIlIIlI.getEntityId());
    Entity llllllllllllllIlllllIIllllIlIllI = clientWorldController.getEntityByID(llllllllllllllIlllllIIllllIlIIlI.getVehicleEntityId());
    if (lIlIIlllIIlIlI(llllllllllllllIlllllIIllllIlIIlI.getLeash()))
    {
      boolean llllllllllllllIlllllIIllllIlIlIl = llIllIlIIlII[1];
      if (lIlIIlllIIIlII(llllllllllllllIlllllIIllllIlIIlI.getEntityId(), gameController.thePlayer.getEntityId()))
      {
        llllllllllllllIlllllIIllllIlIlll = gameController.thePlayer;
        if (lIlIIlllIIIlIl(llllllllllllllIlllllIIllllIlIllI instanceof EntityBoat)) {
          ((EntityBoat)llllllllllllllIlllllIIllllIlIllI).setIsBoatEmpty(llIllIlIIlII[1]);
        }
        if ((lIlIIlllIlIIlI(ridingEntity)) && (lIlIIlllIIIlll(llllllllllllllIlllllIIllllIlIllI)))
        {
          "".length();
          if ("   ".length() > " ".length()) {
            break label150;
          }
        }
        label150:
        llllllllllllllIlllllIIllllIlIlIl = llIllIlIIlII[1];
        "".length();
        if (((0x60 ^ 0x2E ^ 0xE0 ^ 0xA1) & ('' + 85 - 116 + 48 ^ 85 + '' - 174 + 96 ^ -" ".length())) == 0) {}
      }
      else if (lIlIIlllIIIlIl(llllllllllllllIlllllIIllllIlIllI instanceof EntityBoat))
      {
        ((EntityBoat)llllllllllllllIlllllIIllllIlIllI).setIsBoatEmpty(llIllIlIIlII[17]);
      }
      if (lIlIIlllIlIIlI(llllllllllllllIlllllIIllllIlIlll)) {
        return;
      }
      llllllllllllllIlllllIIllllIlIlll.mountEntity(llllllllllllllIlllllIIllllIlIllI);
      if (lIlIIlllIIIlIl(llllllllllllllIlllllIIllllIlIlIl))
      {
        GameSettings llllllllllllllIlllllIIllllIlIlII = gameController.gameSettings;
        gameController.ingameGUI.setRecordPlaying(I18n.format(llIllIlIIIIl[llIllIlIIlII[30]], new Object[] { GameSettings.getKeyDisplayString(keyBindSneak.getKeyCode()) }), llIllIlIIlII[1]);
        "".length();
        if ((0x2 ^ 0x6) > 0) {}
      }
    }
    else if ((lIlIIlllIIIlII(llllllllllllllIlllllIIllllIlIIlI.getLeash(), llIllIlIIlII[17])) && (lIlIIlllIIIlIl(llllllllllllllIlllllIIllllIlIlll instanceof EntityLiving)))
    {
      if (lIlIIlllIIIlll(llllllllllllllIlllllIIllllIlIllI))
      {
        ((EntityLiving)llllllllllllllIlllllIIllllIlIlll).setLeashedToEntity(llllllllllllllIlllllIIllllIlIllI, llIllIlIIlII[1]);
        "".length();
        if (null == null) {}
      }
      else
      {
        ((EntityLiving)llllllllllllllIlllllIIllllIlIlll).clearLeashed(llIllIlIIlII[1], llIllIlIIlII[1]);
      }
    }
  }
  
  public void handleChunkData(S21PacketChunkData llllllllllllllIlllllIlIIIllIIlII)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIIllIIlII, llllllllllllllIlllllIlIIIllIIlIl, gameController);
    if (lIlIIlllIIIlIl(llllllllllllllIlllllIlIIIllIIlII.func_149274_i()))
    {
      if (lIlIIlllIIlIlI(llllllllllllllIlllllIlIIIllIIlII.getExtractedSize()))
      {
        clientWorldController.doPreChunk(llllllllllllllIlllllIlIIIllIIlII.getChunkX(), llllllllllllllIlllllIlIIIllIIlII.getChunkZ(), llIllIlIIlII[1]);
        return;
      }
      clientWorldController.doPreChunk(llllllllllllllIlllllIlIIIllIIlII.getChunkX(), llllllllllllllIlllllIlIIIllIIlII.getChunkZ(), llIllIlIIlII[17]);
    }
    clientWorldController.invalidateBlockReceiveRegion(llllllllllllllIlllllIlIIIllIIlII.getChunkX() << llIllIlIIlII[26], llIllIlIIlII[1], llllllllllllllIlllllIlIIIllIIlII.getChunkZ() << llIllIlIIlII[26], (llllllllllllllIlllllIlIIIllIIlII.getChunkX() << llIllIlIIlII[26]) + llIllIlIIlII[27], llIllIlIIlII[28], (llllllllllllllIlllllIlIIIllIIlII.getChunkZ() << llIllIlIIlII[26]) + llIllIlIIlII[27]);
    Chunk llllllllllllllIlllllIlIIIllIIIll = clientWorldController.getChunkFromChunkCoords(llllllllllllllIlllllIlIIIllIIlII.getChunkX(), llllllllllllllIlllllIlIIIllIIlII.getChunkZ());
    llllllllllllllIlllllIlIIIllIIIll.fillChunk(llllllllllllllIlllllIlIIIllIIlII.func_149272_d(), llllllllllllllIlllllIlIIIllIIlII.getExtractedSize(), llllllllllllllIlllllIlIIIllIIlII.func_149274_i());
    clientWorldController.markBlockRangeForRenderUpdate(llllllllllllllIlllllIlIIIllIIlII.getChunkX() << llIllIlIIlII[26], llIllIlIIlII[1], llllllllllllllIlllllIlIIIllIIlII.getChunkZ() << llIllIlIIlII[26], (llllllllllllllIlllllIlIIIllIIlII.getChunkX() << llIllIlIIlII[26]) + llIllIlIIlII[27], llIllIlIIlII[28], (llllllllllllllIlllllIlIIIllIIlII.getChunkZ() << llIllIlIIlII[26]) + llIllIlIIlII[27]);
    if ((!lIlIIlllIIIlIl(llllllllllllllIlllllIlIIIllIIlII.func_149274_i())) || (lIlIIlllIIlIlI(clientWorldController.provider instanceof WorldProviderSurface))) {
      llllllllllllllIlllllIlIIIllIIIll.resetRelightChecks();
    }
  }
  
  public void handleExplosion(S27PacketExplosion llllllllllllllIlllllIIlllIlIlIll)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlllIlIlIll, llllllllllllllIlllllIIlllIlIllII, gameController);
    Explosion llllllllllllllIlllllIIlllIlIlIlI = new Explosion(gameController.theWorld, null, llllllllllllllIlllllIIlllIlIlIll.getX(), llllllllllllllIlllllIIlllIlIlIll.getY(), llllllllllllllIlllllIIlllIlIlIll.getZ(), llllllllllllllIlllllIIlllIlIlIll.getStrength(), llllllllllllllIlllllIIlllIlIlIll.getAffectedBlockPositions());
    llllllllllllllIlllllIIlllIlIlIlI.doExplosionB(llIllIlIIlII[17]);
    gameController.thePlayer.motionX += llllllllllllllIlllllIIlllIlIlIll.func_149149_c();
    gameController.thePlayer.motionY += llllllllllllllIlllllIIlllIlIlIll.func_149144_d();
    gameController.thePlayer.motionZ += llllllllllllllIlllllIIlllIlIlIll.func_149147_e();
  }
  
  public void handleOpenWindow(S2DPacketOpenWindow llllllllllllllIlllllIIlllIlIIIIl)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlllIlIIIIl, llllllllllllllIlllllIIlllIlIIIlI, gameController);
    EntityPlayerSP llllllllllllllIlllllIIlllIlIIIII = gameController.thePlayer;
    if (lIlIIlllIIIlIl(llIllIlIIIIl[llIllIlIIlII[32]].equals(llllllllllllllIlllllIIlllIlIIIIl.getGuiId())))
    {
      llllllllllllllIlllllIIlllIlIIIII.displayGUIChest(new InventoryBasic(llllllllllllllIlllllIIlllIlIIIIl.getWindowTitle(), llllllllllllllIlllllIIlllIlIIIIl.getSlotCount()));
      openContainer.windowId = llllllllllllllIlllllIIlllIlIIIIl.getWindowId();
      "".length();
      if (null == null) {}
    }
    else if (lIlIIlllIIIlIl(llIllIlIIIIl[llIllIlIIlII[33]].equals(llllllllllllllIlllllIIlllIlIIIIl.getGuiId())))
    {
      llllllllllllllIlllllIIlllIlIIIII.displayVillagerTradeGui(new NpcMerchant(llllllllllllllIlllllIIlllIlIIIII, llllllllllllllIlllllIIlllIlIIIIl.getWindowTitle()));
      openContainer.windowId = llllllllllllllIlllllIIlllIlIIIIl.getWindowId();
      "".length();
      if ((0x46 ^ 0x2A ^ 0x32 ^ 0x5A) != 0) {}
    }
    else if (lIlIIlllIIIlIl(llIllIlIIIIl[llIllIlIIlII[34]].equals(llllllllllllllIlllllIIlllIlIIIIl.getGuiId())))
    {
      Entity llllllllllllllIlllllIIlllIIlllll = clientWorldController.getEntityByID(llllllllllllllIlllllIIlllIlIIIIl.getEntityId());
      if (lIlIIlllIIIlIl(llllllllllllllIlllllIIlllIIlllll instanceof EntityHorse))
      {
        llllllllllllllIlllllIIlllIlIIIII.displayGUIHorse((EntityHorse)llllllllllllllIlllllIIlllIIlllll, new AnimalChest(llllllllllllllIlllllIIlllIlIIIIl.getWindowTitle(), llllllllllllllIlllllIIlllIlIIIIl.getSlotCount()));
        openContainer.windowId = llllllllllllllIlllllIIlllIlIIIIl.getWindowId();
        "".length();
        if (((0x11 ^ 0x42 ^ 0xC3 ^ 0x84) & (0x61 ^ 0x79 ^ 0xA6 ^ 0xAA ^ -" ".length())) != "  ".length()) {}
      }
    }
    else if (lIlIIlllIIlIlI(llllllllllllllIlllllIIlllIlIIIIl.hasSlots()))
    {
      llllllllllllllIlllllIIlllIlIIIII.displayGui(new LocalBlockIntercommunication(llllllllllllllIlllllIIlllIlIIIIl.getGuiId(), llllllllllllllIlllllIIlllIlIIIIl.getWindowTitle()));
      openContainer.windowId = llllllllllllllIlllllIIlllIlIIIIl.getWindowId();
      "".length();
      if (((0x86 ^ 0xC3) & (0x46 ^ 0x3 ^ 0xFFFFFFFF)) <= (0xD ^ 0x9)) {}
    }
    else
    {
      ContainerLocalMenu llllllllllllllIlllllIIlllIIllllI = new ContainerLocalMenu(llllllllllllllIlllllIIlllIlIIIIl.getGuiId(), llllllllllllllIlllllIIlllIlIIIIl.getWindowTitle(), llllllllllllllIlllllIIlllIlIIIIl.getSlotCount());
      llllllllllllllIlllllIIlllIlIIIII.displayGUIChest(llllllllllllllIlllllIIlllIIllllI);
      openContainer.windowId = llllllllllllllIlllllIIlllIlIIIIl.getWindowId();
    }
  }
  
  public void handleBlockAction(S24PacketBlockAction llllllllllllllIlllllIIllIIllIlIl)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIIllIlIl, llllllllllllllIlllllIIllIIllIllI, gameController);
    gameController.theWorld.addBlockEvent(llllllllllllllIlllllIIllIIllIlIl.getBlockPosition(), llllllllllllllIlllllIIllIIllIlIl.getBlockType(), llllllllllllllIlllllIIllIIllIlIl.getData1(), llllllllllllllIlllllIIllIIllIlIl.getData2());
  }
  
  public void handleDisconnect(S40PacketDisconnect llllllllllllllIlllllIlIIIlIlIllI)
  {
    ;
    ;
    netManager.closeChannel(llllllllllllllIlllllIlIIIlIlIllI.getReason());
  }
  
  private static boolean lIlIIlllIlIIll(int ???, int arg1)
  {
    int i;
    String llllllllllllllIlllllIIIlIIlIIIIl;
    return ??? != i;
  }
  
  private static int lIlIIlllIlIlII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void handleStatistics(S37PacketStatistics llllllllllllllIlllllIIlIlllIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIlllIllIl, llllllllllllllIlllllIIlIlllIIlll, gameController);
    boolean llllllllllllllIlllllIIlIlllIllII = llIllIlIIlII[1];
    char llllllllllllllIlllllIIlIlllIIIll = llllllllllllllIlllllIIlIlllIllIl.func_148974_c().entrySet().iterator();
    "".length();
    if (-(18 + 30 - -104 + 14 ^ 56 + 62 - 27 + 71) > 0) {
      return;
    }
    while (!lIlIIlllIIlIlI(llllllllllllllIlllllIIlIlllIIIll.hasNext()))
    {
      Map.Entry<StatBase, Integer> llllllllllllllIlllllIIlIlllIlIll = (Map.Entry)llllllllllllllIlllllIIlIlllIIIll.next();
      StatBase llllllllllllllIlllllIIlIlllIlIlI = (StatBase)llllllllllllllIlllllIIlIlllIlIll.getKey();
      int llllllllllllllIlllllIIlIlllIlIIl = ((Integer)llllllllllllllIlllllIIlIlllIlIll.getValue()).intValue();
      if ((lIlIIlllIIIlIl(llllllllllllllIlllllIIlIlllIlIlI.isAchievement())) && (lIlIIlllIIlIIl(llllllllllllllIlllllIIlIlllIlIIl)))
      {
        if ((lIlIIlllIIIlIl(field_147308_k)) && (lIlIIlllIIlIlI(gameController.thePlayer.getStatFileWriter().readStat(llllllllllllllIlllllIIlIlllIlIlI))))
        {
          Achievement llllllllllllllIlllllIIlIlllIlIII = (Achievement)llllllllllllllIlllllIIlIlllIlIlI;
          gameController.guiAchievement.displayAchievement(llllllllllllllIlllllIIlIlllIlIII);
          gameController.getTwitchStream().func_152911_a(new MetadataAchievement(llllllllllllllIlllllIIlIlllIlIII), 0L);
          if (lIlIIlllIlIlIl(llllllllllllllIlllllIIlIlllIlIlI, AchievementList.openInventory))
          {
            gameController.gameSettings.showInventoryAchievementHint = llIllIlIIlII[1];
            gameController.gameSettings.saveOptions();
          }
        }
        llllllllllllllIlllllIIlIlllIllII = llIllIlIIlII[17];
      }
      gameController.thePlayer.getStatFileWriter().unlockAchievement(gameController.thePlayer, llllllllllllllIlllllIIlIlllIlIlI, llllllllllllllIlllllIIlIlllIlIIl);
    }
    if ((lIlIIlllIIlIlI(field_147308_k)) && (lIlIIlllIIlIlI(llllllllllllllIlllllIIlIlllIllII)) && (lIlIIlllIIIlIl(gameController.gameSettings.showInventoryAchievementHint))) {
      gameController.guiAchievement.displayUnformattedAchievement(AchievementList.openInventory);
    }
    field_147308_k = llIllIlIIlII[17];
    if (lIlIIlllIIIlIl(gameController.currentScreen instanceof IProgressMeter)) {
      ((IProgressMeter)gameController.currentScreen).doneLoading();
    }
  }
  
  public void handleEntityProperties(S20PacketEntityProperties llllllllllllllIlllllIIIllIlIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIIllIlIllIl, llllllllllllllIlllllIIIllIlIIlll, gameController);
    Entity llllllllllllllIlllllIIIllIlIllII = clientWorldController.getEntityByID(llllllllllllllIlllllIIIllIlIllIl.getEntityId());
    if (lIlIIlllIIIlll(llllllllllllllIlllllIIIllIlIllII))
    {
      if (lIlIIlllIIlIlI(llllllllllllllIlllllIIIllIlIllII instanceof EntityLivingBase)) {
        throw new IllegalStateException(String.valueOf(new StringBuilder(llIllIlIIIIl[llIllIlIIlII[56]]).append(llllllllllllllIlllllIIIllIlIllII).append(llIllIlIIIIl[llIllIlIIlII[57]])));
      }
      BaseAttributeMap llllllllllllllIlllllIIIllIlIlIll = ((EntityLivingBase)llllllllllllllIlllllIIIllIlIllII).getAttributeMap();
      llllllllllllllIlllllIIIllIlIIIlI = llllllllllllllIlllllIIIllIlIllIl.func_149441_d().iterator();
      "".length();
      if (" ".length() == 0) {
        return;
      }
      while (!lIlIIlllIIlIlI(llllllllllllllIlllllIIIllIlIIIlI.hasNext()))
      {
        S20PacketEntityProperties.Snapshot llllllllllllllIlllllIIIllIlIlIlI = (S20PacketEntityProperties.Snapshot)llllllllllllllIlllllIIIllIlIIIlI.next();
        IAttributeInstance llllllllllllllIlllllIIIllIlIlIIl = llllllllllllllIlllllIIIllIlIlIll.getAttributeInstanceByName(llllllllllllllIlllllIIIllIlIlIlI.func_151409_a());
        if (lIlIIlllIlIIlI(llllllllllllllIlllllIIIllIlIlIIl)) {
          llllllllllllllIlllllIIIllIlIlIIl = llllllllllllllIlllllIIIllIlIlIll.registerAttribute(new RangedAttribute(null, llllllllllllllIlllllIIIllIlIlIlI.func_151409_a(), 0.0D, 2.2250738585072014E-308D, Double.MAX_VALUE));
        }
        llllllllllllllIlllllIIIllIlIlIIl.setBaseValue(llllllllllllllIlllllIIIllIlIlIlI.func_151410_b());
        llllllllllllllIlllllIIIllIlIlIIl.removeAllModifiers();
        llllllllllllllIlllllIIIllIIlllll = llllllllllllllIlllllIIIllIlIlIlI.func_151408_c().iterator();
        "".length();
        if ("  ".length() != "  ".length()) {
          return;
        }
        while (!lIlIIlllIIlIlI(llllllllllllllIlllllIIIllIIlllll.hasNext()))
        {
          AttributeModifier llllllllllllllIlllllIIIllIlIlIII = (AttributeModifier)llllllllllllllIlllllIIIllIIlllll.next();
          llllllllllllllIlllllIIIllIlIlIIl.applyModifier(llllllllllllllIlllllIIIllIlIlIII);
        }
      }
    }
  }
  
  public void handleEntityEquipment(S04PacketEntityEquipment llllllllllllllIlllllIIllIlIIIIII)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIlIIIIII, llllllllllllllIlllllIIllIlIIIIIl, gameController);
    Entity llllllllllllllIlllllIIllIlIIIIlI = clientWorldController.getEntityByID(llllllllllllllIlllllIIllIlIIIIII.getEntityID());
    if (lIlIIlllIIIlll(llllllllllllllIlllllIIllIlIIIIlI)) {
      llllllllllllllIlllllIIllIlIIIIlI.setCurrentItemOrArmor(llllllllllllllIlllllIIllIlIIIIII.getEquipmentSlot(), llllllllllllllIlllllIIllIlIIIIII.getItemStack());
    }
  }
  
  public void handleEntityMetadata(S1CPacketEntityMetadata llllllllllllllIlllllIlIIlllllIlI)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIlllllIlI, llllllllllllllIlllllIlIIlllllIll, gameController);
    Entity llllllllllllllIlllllIlIIllllllII = clientWorldController.getEntityByID(llllllllllllllIlllllIlIIlllllIlI.getEntityId());
    if ((lIlIIlllIIIlll(llllllllllllllIlllllIlIIllllllII)) && (lIlIIlllIIIlll(llllllllllllllIlllllIlIIlllllIlI.func_149376_c()))) {
      llllllllllllllIlllllIlIIllllllII.getDataWatcher().updateWatchedObjectsFromList(llllllllllllllIlllllIlIIlllllIlI.func_149376_c());
    }
  }
  
  public Collection<NetworkPlayerInfo> getPlayerInfoMap()
  {
    ;
    return playerInfoMap.values();
  }
  
  public void handleWindowProperty(S31PacketWindowProperty llllllllllllllIlllllIIllIlIIlIIl)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIlIIlIIl, llllllllllllllIlllllIIllIlIIllIl, gameController);
    EntityPlayer llllllllllllllIlllllIIllIlIIlIll = gameController.thePlayer;
    if ((lIlIIlllIIIlll(openContainer)) && (lIlIIlllIIIlII(openContainer.windowId, llllllllllllllIlllllIIllIlIIlIIl.getWindowId()))) {
      openContainer.updateProgressBar(llllllllllllllIlllllIIllIlIIlIIl.getVarIndex(), llllllllllllllIlllllIIllIlIIlIIl.getVarValue());
    }
  }
  
  public void handleEntityMovement(S14PacketEntity llllllllllllllIlllllIlIIlIllIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIlIllIIll, llllllllllllllIlllllIlIIlIlIllII, gameController);
    Entity llllllllllllllIlllllIlIIlIllIIlI = llllllllllllllIlllllIlIIlIllIIll.getEntity(clientWorldController);
    if (lIlIIlllIIIlll(llllllllllllllIlllllIlIIlIllIIlI))
    {
      serverPosX += llllllllllllllIlllllIlIIlIllIIll.func_149062_c();
      serverPosY += llllllllllllllIlllllIlIIlIllIIll.func_149061_d();
      serverPosZ += llllllllllllllIlllllIlIIlIllIIll.func_149064_e();
      double llllllllllllllIlllllIlIIlIllIIIl = serverPosX / 32.0D;
      double llllllllllllllIlllllIlIIlIllIIII = serverPosY / 32.0D;
      double llllllllllllllIlllllIlIIlIlIllll = serverPosZ / 32.0D;
      if (lIlIIlllIIIlIl(llllllllllllllIlllllIlIIlIllIIll.func_149060_h()))
      {
        "".length();
        if ((0x63 ^ 0x67) != "   ".length()) {
          break label147;
        }
      }
      label147:
      float llllllllllllllIlllllIlIIlIlIlllI = rotationYaw;
      if (lIlIIlllIIIlIl(llllllllllllllIlllllIlIIlIllIIll.func_149060_h()))
      {
        "".length();
        if (((0x78 ^ 0x6B) & (0x1E ^ 0xD ^ 0xFFFFFFFF)) < (0x62 ^ 0x66)) {
          break label207;
        }
      }
      label207:
      float llllllllllllllIlllllIlIIlIlIllIl = rotationPitch;
      llllllllllllllIlllllIlIIlIllIIlI.setPositionAndRotation2(llllllllllllllIlllllIlIIlIllIIIl, llllllllllllllIlllllIlIIlIllIIII, llllllllllllllIlllllIlIIlIlIllll, llllllllllllllIlllllIlIIlIlIlllI, llllllllllllllIlllllIlIIlIlIllIl, llIllIlIIlII[25], llIllIlIIlII[1]);
      onGround = llllllllllllllIlllllIlIIlIllIIll.getOnGround();
    }
  }
  
  public void handleSetSlot(S2FPacketSetSlot llllllllllllllIlllllIIlllIIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlllIIIllIl, llllllllllllllIlllllIIlllIIIlllI, gameController);
    EntityPlayer llllllllllllllIlllllIIlllIIlIIlI = gameController.thePlayer;
    if (lIlIIlllIIIlII(llllllllllllllIlllllIIlllIIIllIl.func_149175_c(), llIllIlIIlII[35]))
    {
      inventory.setItemStack(llllllllllllllIlllllIIlllIIIllIl.func_149174_e());
      "".length();
      if ("  ".length() > " ".length()) {}
    }
    else
    {
      boolean llllllllllllllIlllllIIlllIIlIIIl = llIllIlIIlII[1];
      if (lIlIIlllIIIlIl(gameController.currentScreen instanceof GuiContainerCreative))
      {
        GuiContainerCreative llllllllllllllIlllllIIlllIIlIIII = (GuiContainerCreative)gameController.currentScreen;
        if (lIlIIlllIlIIll(llllllllllllllIlllllIIlllIIlIIII.getSelectedTabIndex(), CreativeTabs.tabInventory.getTabIndex()))
        {
          "".length();
          if (((0x78 ^ 0x63) & (0x3E ^ 0x25 ^ 0xFFFFFFFF)) == ((0x46 ^ 0x13) & (0x57 ^ 0x2 ^ 0xFFFFFFFF))) {
            break label162;
          }
        }
        label162:
        llllllllllllllIlllllIIlllIIlIIIl = llIllIlIIlII[1];
      }
      if ((lIlIIlllIIlIlI(llllllllllllllIlllllIIlllIIIllIl.func_149175_c())) && (lIlIIlllIIlIII(llllllllllllllIlllllIIlllIIIllIl.func_149173_d(), llIllIlIIlII[36])) && (lIlIIlllIlIIII(llllllllllllllIlllllIIlllIIIllIl.func_149173_d(), llIllIlIIlII[37])))
      {
        ItemStack llllllllllllllIlllllIIlllIIIllll = inventoryContainer.getSlot(llllllllllllllIlllllIIlllIIIllIl.func_149173_d()).getStack();
        if ((lIlIIlllIIIlll(llllllllllllllIlllllIIlllIIIllIl.func_149174_e())) && ((!lIlIIlllIIIlll(llllllllllllllIlllllIIlllIIIllll)) || (lIlIIlllIlIIII(stackSize, func_149174_estackSize)))) {
          func_149174_eanimationsToGo = llIllIlIIlII[29];
        }
        inventoryContainer.putStackInSlot(llllllllllllllIlllllIIlllIIIllIl.func_149173_d(), llllllllllllllIlllllIIlllIIIllIl.func_149174_e());
        "".length();
        if (null == null) {}
      }
      else if ((lIlIIlllIIIlII(llllllllllllllIlllllIIlllIIIllIl.func_149175_c(), openContainer.windowId)) && ((!lIlIIlllIIlIlI(llllllllllllllIlllllIIlllIIIllIl.func_149175_c())) || (lIlIIlllIIlIlI(llllllllllllllIlllllIIlllIIlIIIl))))
      {
        openContainer.putStackInSlot(llllllllllllllIlllllIIlllIIIllIl.func_149173_d(), llllllllllllllIlllllIIlllIIIllIl.func_149174_e());
      }
    }
  }
  
  public void handlePlayerListItem(S38PacketPlayerListItem llllllllllllllIlllllIIlIIlllIlll)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIIlllIlll, llllllllllllllIlllllIIlIIllllIII, gameController);
    boolean llllllllllllllIlllllIIlIIlllIlIl = llllllllllllllIlllllIIlIIlllIlll.func_179767_a().iterator();
    "".length();
    if ("  ".length() == 0) {
      return;
    }
    while (!lIlIIlllIIlIlI(llllllllllllllIlllllIIlIIlllIlIl.hasNext()))
    {
      S38PacketPlayerListItem.AddPlayerData llllllllllllllIlllllIIlIIllllIlI = (S38PacketPlayerListItem.AddPlayerData)llllllllllllllIlllllIIlIIlllIlIl.next();
      if (lIlIIlllIlIlIl(llllllllllllllIlllllIIlIIlllIlll.func_179768_b(), S38PacketPlayerListItem.Action.REMOVE_PLAYER))
      {
        "".length();
        "".length();
        if ("   ".length() >= (("  ".length() ^ 0x7F ^ 0x30) & (0x64 ^ 0x49 ^ 0x29 ^ 0x49 ^ -" ".length()))) {}
      }
      else
      {
        NetworkPlayerInfo llllllllllllllIlllllIIlIIllllIIl = (NetworkPlayerInfo)playerInfoMap.get(llllllllllllllIlllllIIlIIllllIlI.getProfile().getId());
        if (lIlIIlllIlIlIl(llllllllllllllIlllllIIlIIlllIlll.func_179768_b(), S38PacketPlayerListItem.Action.ADD_PLAYER))
        {
          llllllllllllllIlllllIIlIIllllIIl = new NetworkPlayerInfo(llllllllllllllIlllllIIlIIllllIlI);
          "".length();
        }
        if (lIlIIlllIIIlll(llllllllllllllIlllllIIlIIllllIIl)) {
          switch ($SWITCH_TABLE$net$minecraft$network$play$server$S38PacketPlayerListItem$Action()[llllllllllllllIlllllIIlIIlllIlll.func_179768_b().ordinal()])
          {
          case 1: 
            llllllllllllllIlllllIIlIIllllIIl.setGameType(llllllllllllllIlllllIIlIIllllIlI.getGameMode());
            llllllllllllllIlllllIIlIIllllIIl.setResponseTime(llllllllllllllIlllllIIlIIllllIlI.getPing());
            "".length();
            if ((0xC2 ^ 0x98 ^ 0xFA ^ 0xA4) != (0x7C ^ 0x48 ^ 0xC ^ 0x3C)) {
              return;
            }
            break;
          case 2: 
            llllllllllllllIlllllIIlIIllllIIl.setGameType(llllllllllllllIlllllIIlIIllllIlI.getGameMode());
            "".length();
            if (-"   ".length() >= 0) {
              return;
            }
            break;
          case 3: 
            llllllllllllllIlllllIIlIIllllIIl.setResponseTime(llllllllllllllIlllllIIlIIllllIlI.getPing());
            "".length();
            if (-" ".length() > "  ".length()) {
              return;
            }
            break;
          case 4: 
            llllllllllllllIlllllIIlIIllllIIl.setDisplayName(llllllllllllllIlllllIIlIIllllIlI.getDisplayName());
          }
        }
      }
    }
  }
  
  public void handleSpawnPosition(S05PacketSpawnPosition llllllllllllllIlllllIIlllllIIIlI)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlllllIIIlI, llllllllllllllIlllllIIlllllIIIll, gameController);
    gameController.thePlayer.setSpawnPoint(llllllllllllllIlllllIIlllllIIIlI.getSpawnPos(), llIllIlIIlII[17]);
    gameController.theWorld.getWorldInfo().setSpawn(llllllllllllllIlllllIIlllllIIIlI.getSpawnPos());
  }
  
  public void handleSignEditorOpen(S36PacketSignEditorOpen llllllllllllllIlllllIIllIlllIIII)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIlllIIII, llllllllllllllIlllllIIllIlllIIIl, gameController);
    TileEntity llllllllllllllIlllllIIllIllIllll = clientWorldController.getTileEntity(llllllllllllllIlllllIIllIlllIIII.getSignPosition());
    if (lIlIIlllIIlIlI(llllllllllllllIlllllIIllIllIllll instanceof TileEntitySign))
    {
      llllllllllllllIlllllIIllIllIllll = new TileEntitySign();
      llllllllllllllIlllllIIllIllIllll.setWorldObj(clientWorldController);
      llllllllllllllIlllllIIllIllIllll.setPos(llllllllllllllIlllllIIllIlllIIII.getSignPosition());
    }
    gameController.thePlayer.openEditSign((TileEntitySign)llllllllllllllIlllllIIllIllIllll);
  }
  
  public void handleTeams(S3EPacketTeams llllllllllllllIlllllIIIllllIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIIllllIIlII, llllllllllllllIlllllIIIllllIllIl, gameController);
    Scoreboard llllllllllllllIlllllIIIllllIlIll = clientWorldController.getScoreboard();
    ScorePlayerTeam llllllllllllllIlllllIIIllllIlIIl;
    if (lIlIIlllIIlIlI(llllllllllllllIlllllIIIllllIIlII.func_149307_h()))
    {
      ScorePlayerTeam llllllllllllllIlllllIIIllllIlIlI = llllllllllllllIlllllIIIllllIlIll.createTeam(llllllllllllllIlllllIIIllllIIlII.func_149312_c());
      "".length();
      if ((0x9D ^ 0x99) == (0x35 ^ 0x31)) {}
    }
    else
    {
      llllllllllllllIlllllIIIllllIlIIl = llllllllllllllIlllllIIIllllIlIll.getTeam(llllllllllllllIlllllIIIllllIIlII.func_149312_c());
    }
    if ((!lIlIIlllIIIlIl(llllllllllllllIlllllIIIllllIIlII.func_149307_h())) || (lIlIIlllIIIlII(llllllllllllllIlllllIIIllllIIlII.func_149307_h(), llIllIlIIlII[21])))
    {
      llllllllllllllIlllllIIIllllIlIIl.setTeamName(llllllllllllllIlllllIIIllllIIlII.func_149306_d());
      llllllllllllllIlllllIIIllllIlIIl.setNamePrefix(llllllllllllllIlllllIIIllllIIlII.func_149311_e());
      llllllllllllllIlllllIIIllllIlIIl.setNameSuffix(llllllllllllllIlllllIIIllllIIlII.func_149309_f());
      llllllllllllllIlllllIIIllllIlIIl.setChatFormat(EnumChatFormatting.func_175744_a(llllllllllllllIlllllIIIllllIIlII.func_179813_h()));
      llllllllllllllIlllllIIIllllIlIIl.func_98298_a(llllllllllllllIlllllIIIllllIIlII.func_149308_i());
      Team.EnumVisible llllllllllllllIlllllIIIllllIlIII = Team.EnumVisible.func_178824_a(llllllllllllllIlllllIIIllllIIlII.func_179814_i());
      if (lIlIIlllIIIlll(llllllllllllllIlllllIIIllllIlIII)) {
        llllllllllllllIlllllIIIllllIlIIl.setNameTagVisibility(llllllllllllllIlllllIIIllllIlIII);
      }
    }
    if ((!lIlIIlllIIIlIl(llllllllllllllIlllllIIIllllIIlII.func_149307_h())) || (lIlIIlllIIIlII(llllllllllllllIlllllIIIllllIIlII.func_149307_h(), llIllIlIIlII[25])))
    {
      llllllllllllllIlllllIIIllllIIIII = llllllllllllllIlllllIIIllllIIlII.func_149310_g().iterator();
      "".length();
      if (((0xEC ^ 0x8C) & (0x6D ^ 0xD ^ 0xFFFFFFFF)) == "  ".length()) {
        return;
      }
      while (!lIlIIlllIIlIlI(llllllllllllllIlllllIIIllllIIIII.hasNext()))
      {
        String llllllllllllllIlllllIIIllllIIlll = (String)llllllllllllllIlllllIIIllllIIIII.next();
        "".length();
      }
    }
    if (lIlIIlllIIIlII(llllllllllllllIlllllIIIllllIIlII.func_149307_h(), llIllIlIIlII[26]))
    {
      llllllllllllllIlllllIIIllllIIIII = llllllllllllllIlllllIIIllllIIlII.func_149310_g().iterator();
      "".length();
      if (((0xD ^ 0x7D ^ 0x93 ^ 0xBA) & (0xD4 ^ 0x97 ^ 0x2B ^ 0x31 ^ -" ".length())) != 0) {
        return;
      }
      while (!lIlIIlllIIlIlI(llllllllllllllIlllllIIIllllIIIII.hasNext()))
      {
        String llllllllllllllIlllllIIIllllIIllI = (String)llllllllllllllIlllllIIIllllIIIII.next();
        llllllllllllllIlllllIIIllllIlIll.removePlayerFromTeam(llllllllllllllIlllllIIIllllIIllI, llllllllllllllIlllllIIIllllIlIIl);
      }
    }
    if (lIlIIlllIIIlII(llllllllllllllIlllllIIIllllIIlII.func_149307_h(), llIllIlIIlII[17])) {
      llllllllllllllIlllllIIIllllIlIll.removeTeam(llllllllllllllIlllllIIIllllIlIIl);
    }
  }
  
  public void handleBlockChange(S23PacketBlockChange llllllllllllllIlllllIlIIIlIlllII)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIIlIlllII, llllllllllllllIlllllIlIIIlIllIll, gameController);
    "".length();
  }
  
  public void handleServerDifficulty(S41PacketServerDifficulty llllllllllllllIlllllIIlIlIlllIlI)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIlIlllIlI, llllllllllllllIlllllIIlIlIlllIll, gameController);
    gameController.theWorld.getWorldInfo().setDifficulty(llllllllllllllIlllllIIlIlIlllIlI.getDifficulty());
    gameController.theWorld.getWorldInfo().setDifficultyLocked(llllllllllllllIlllllIIlIlIlllIlI.isDifficultyLocked());
  }
  
  public void handleUpdateScore(S3CPacketUpdateScore llllllllllllllIlllllIIlIIIIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIIIIIIIll, llllllllllllllIlllllIIlIIIIIIlII, gameController);
    Scoreboard llllllllllllllIlllllIIlIIIIIIlll = clientWorldController.getScoreboard();
    ScoreObjective llllllllllllllIlllllIIlIIIIIIllI = llllllllllllllIlllllIIlIIIIIIlll.getObjective(llllllllllllllIlllllIIlIIIIIIIll.getObjectiveName());
    if (lIlIIlllIlIlIl(llllllllllllllIlllllIIlIIIIIIIll.getScoreAction(), S3CPacketUpdateScore.Action.CHANGE))
    {
      Score llllllllllllllIlllllIIlIIIIIIlIl = llllllllllllllIlllllIIlIIIIIIlll.getValueFromObjective(llllllllllllllIlllllIIlIIIIIIIll.getPlayerName(), llllllllllllllIlllllIIlIIIIIIllI);
      llllllllllllllIlllllIIlIIIIIIlIl.setScorePoints(llllllllllllllIlllllIIlIIIIIIIll.getScoreValue());
      "".length();
      if ((" ".length() & (" ".length() ^ -" ".length())) == 0) {}
    }
    else if (lIlIIlllIlIlIl(llllllllllllllIlllllIIlIIIIIIIll.getScoreAction(), S3CPacketUpdateScore.Action.REMOVE))
    {
      if (lIlIIlllIIIlIl(StringUtils.isNullOrEmpty(llllllllllllllIlllllIIlIIIIIIIll.getObjectiveName())))
      {
        llllllllllllllIlllllIIlIIIIIIlll.removeObjectiveFromEntity(llllllllllllllIlllllIIlIIIIIIIll.getPlayerName(), null);
        "".length();
        if ("   ".length() > "  ".length()) {}
      }
      else if (lIlIIlllIIIlll(llllllllllllllIlllllIIlIIIIIIllI))
      {
        llllllllllllllIlllllIIlIIIIIIlll.removeObjectiveFromEntity(llllllllllllllIlllllIIlIIIIIIIll.getPlayerName(), llllllllllllllIlllllIIlIIIIIIllI);
      }
    }
  }
  
  private static boolean lIlIIlllIIlIlI(int ???)
  {
    float llllllllllllllIlllllIIIlIIlIlIll;
    return ??? == 0;
  }
  
  public void handleUpdateHealth(S06PacketUpdateHealth llllllllllllllIlllllIIlllIllllll)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlllIllllll, llllllllllllllIlllllIIllllIIIIII, gameController);
    gameController.thePlayer.setPlayerSPHealth(llllllllllllllIlllllIIlllIllllll.getHealth());
    gameController.thePlayer.getFoodStats().setFoodLevel(llllllllllllllIlllllIIlllIllllll.getFoodLevel());
    gameController.thePlayer.getFoodStats().setFoodSaturationLevel(llllllllllllllIlllllIIlllIllllll.getSaturationLevel());
  }
  
  public void handleSpawnGlobalEntity(S2CPacketSpawnGlobalEntity llllllllllllllIlllllIlIlIIIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIlIIIllIII, llllllllllllllIlllllIlIlIIIlllll, gameController);
    double llllllllllllllIlllllIlIlIIIlllIl = llllllllllllllIlllllIlIlIIIllIII.func_149051_d() / 32.0D;
    double llllllllllllllIlllllIlIlIIIlllII = llllllllllllllIlllllIlIlIIIllIII.func_149050_e() / 32.0D;
    double llllllllllllllIlllllIlIlIIIllIll = llllllllllllllIlllllIlIlIIIllIII.func_149049_f() / 32.0D;
    Entity llllllllllllllIlllllIlIlIIIllIlI = null;
    if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIIllIII.func_149053_g(), llIllIlIIlII[17])) {
      llllllllllllllIlllllIlIlIIIllIlI = new EntityLightningBolt(clientWorldController, llllllllllllllIlllllIlIlIIIlllIl, llllllllllllllIlllllIlIlIIIlllII, llllllllllllllIlllllIlIlIIIllIll);
    }
    if (lIlIIlllIIIlll(llllllllllllllIlllllIlIlIIIllIlI))
    {
      serverPosX = llllllllllllllIlllllIlIlIIIllIII.func_149051_d();
      serverPosY = llllllllllllllIlllllIlIlIIIllIII.func_149050_e();
      serverPosZ = llllllllllllllIlllllIlIlIIIllIII.func_149049_f();
      rotationYaw = 0.0F;
      rotationPitch = 0.0F;
      llllllllllllllIlllllIlIlIIIllIlI.setEntityId(llllllllllllllIlllllIlIlIIIllIII.func_149052_c());
      "".length();
    }
  }
  
  private static String lIlIIllIllIIll(String llllllllllllllIlllllIIIlIlIIllII, String llllllllllllllIlllllIIIlIlIIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlllllIIIlIlIIllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllllIIIlIlIIlIll.getBytes(StandardCharsets.UTF_8)), llIllIlIIlII[33]), "DES");
      Cipher llllllllllllllIlllllIIIlIlIIlllI = Cipher.getInstance("DES");
      llllllllllllllIlllllIIIlIlIIlllI.init(llIllIlIIlII[21], llllllllllllllIlllllIIIlIlIIllll);
      return new String(llllllllllllllIlllllIIIlIlIIlllI.doFinal(Base64.getDecoder().decode(llllllllllllllIlllllIIIlIlIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlllllIIIlIlIIllIl)
    {
      llllllllllllllIlllllIIIlIlIIllIl.printStackTrace();
    }
    return null;
  }
  
  public void handleEffect(S28PacketEffect llllllllllllllIlllllIIlIllllIlll)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIllllIlll, llllllllllllllIlllllIIlIlllllIII, gameController);
    if (lIlIIlllIIIlIl(llllllllllllllIlllllIIlIllllIlll.isSoundServerwide()))
    {
      gameController.theWorld.playBroadcastSound(llllllllllllllIlllllIIlIllllIlll.getSoundType(), llllllllllllllIlllllIIlIllllIlll.getSoundPos(), llllllllllllllIlllllIIlIllllIlll.getSoundData());
      "".length();
      if ((0x22 ^ 0x15 ^ 0x95 ^ 0xA6) >= "  ".length()) {}
    }
    else
    {
      gameController.theWorld.playAuxSFX(llllllllllllllIlllllIIlIllllIlll.getSoundType(), llllllllllllllIlllllIIlIllllIlll.getSoundPos(), llllllllllllllIlllllIIlIllllIlll.getSoundData());
    }
  }
  
  private static boolean lIlIIlllIIlIII(int ???, int arg1)
  {
    int i;
    double llllllllllllllIlllllIIIlIIllllll;
    return ??? >= i;
  }
  
  private static int lIlIIlllIIlIll(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  private static boolean lIlIIlllIlIIlI(Object ???)
  {
    double llllllllllllllIlllllIIIlIIlIllll;
    return ??? == null;
  }
  
  public void handleChat(S02PacketChat llllllllllllllIlllllIlIIIIlIIIll)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIIIlIIIll, llllllllllllllIlllllIlIIIIlIIlII, gameController);
    if (lIlIIlllIIIlII(llllllllllllllIlllllIlIIIIlIIIll.getType(), llIllIlIIlII[21]))
    {
      gameController.ingameGUI.setRecordPlaying(llllllllllllllIlllllIlIIIIlIIIll.getChatComponent(), llIllIlIIlII[1]);
      "".length();
      if (" ".length() != 0) {}
    }
    else
    {
      gameController.ingameGUI.getChatGUI().printChatMessage(llllllllllllllIlllllIlIIIIlIIIll.getChatComponent());
    }
  }
  
  public void handleCombatEvent(S42PacketCombatEvent llllllllllllllIlllllIIlIllIIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIllIIlIll, llllllllllllllIlllllIIlIllIIIlII, gameController);
    Entity llllllllllllllIlllllIIlIllIIlIlI = clientWorldController.getEntityByID(field_179775_c);
    if (lIlIIlllIIIlIl(llllllllllllllIlllllIIlIllIIlIlI instanceof EntityLivingBase))
    {
      "".length();
      if ((0x7 ^ 0x3) != "  ".length()) {
        break label55;
      }
    }
    label55:
    EntityLivingBase llllllllllllllIlllllIIlIllIIlIIl = null;
    if (lIlIIlllIlIlIl(eventType, S42PacketCombatEvent.Event.END_COMBAT))
    {
      long llllllllllllllIlllllIIlIllIIlIII = llIllIlIIlII[44] * field_179772_d / llIllIlIIlII[0];
      MetadataCombat llllllllllllllIlllllIIlIllIIIlll = new MetadataCombat(gameController.thePlayer, llllllllllllllIlllllIIlIllIIlIIl);
      gameController.getTwitchStream().func_176026_a(llllllllllllllIlllllIIlIllIIIlll, 0L - llllllllllllllIlllllIIlIllIIlIII, 0L);
      "".length();
      if (null == null) {}
    }
    else if (lIlIIlllIlIlIl(eventType, S42PacketCombatEvent.Event.ENTITY_DIED))
    {
      Entity llllllllllllllIlllllIIlIllIIIllI = clientWorldController.getEntityByID(field_179774_b);
      if (lIlIIlllIIIlIl(llllllllllllllIlllllIIlIllIIIllI instanceof EntityPlayer))
      {
        MetadataPlayerDeath llllllllllllllIlllllIIlIllIIIlIl = new MetadataPlayerDeath((EntityPlayer)llllllllllllllIlllllIIlIllIIIllI, llllllllllllllIlllllIIlIllIIlIIl);
        llllllllllllllIlllllIIlIllIIIlIl.func_152807_a(deathMessage);
        gameController.getTwitchStream().func_152911_a(llllllllllllllIlllllIIlIllIIIlIl, 0L);
      }
    }
  }
  
  public void handleSpawnMob(S0FPacketSpawnMob llllllllllllllIlllllIlIIIIIIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIIIIIIIIl, llllllllllllllIlllllIIllllllIllI, gameController);
    double llllllllllllllIlllllIlIIIIIIIIII = llllllllllllllIlllllIlIIIIIIIIIl.getX() / 32.0D;
    double llllllllllllllIlllllIIllllllllll = llllllllllllllIlllllIlIIIIIIIIIl.getY() / 32.0D;
    double llllllllllllllIlllllIIlllllllllI = llllllllllllllIlllllIlIIIIIIIIIl.getZ() / 32.0D;
    float llllllllllllllIlllllIIllllllllIl = llllllllllllllIlllllIlIIIIIIIIIl.getYaw() * llIllIlIIlII[24] / 256.0F;
    float llllllllllllllIlllllIIllllllllII = llllllllllllllIlllllIlIIIIIIIIIl.getPitch() * llIllIlIIlII[24] / 256.0F;
    EntityLivingBase llllllllllllllIlllllIIlllllllIll = (EntityLivingBase)EntityList.createEntityByID(llllllllllllllIlllllIlIIIIIIIIIl.getEntityType(), gameController.theWorld);
    serverPosX = llllllllllllllIlllllIlIIIIIIIIIl.getX();
    serverPosY = llllllllllllllIlllllIlIIIIIIIIIl.getY();
    serverPosZ = llllllllllllllIlllllIlIIIIIIIIIl.getZ();
    renderYawOffset = (llllllllllllllIlllllIIlllllllIll.rotationYawHead = llllllllllllllIlllllIlIIIIIIIIIl.getHeadPitch() * llIllIlIIlII[24] / 256.0F);
    Entity[] llllllllllllllIlllllIIlllllllIlI = llllllllllllllIlllllIIlllllllIll.getParts();
    if (lIlIIlllIIIlll(llllllllllllllIlllllIIlllllllIlI))
    {
      int llllllllllllllIlllllIIlllllllIIl = llllllllllllllIlllllIlIIIIIIIIIl.getEntityID() - llllllllllllllIlllllIIlllllllIll.getEntityId();
      int llllllllllllllIlllllIIlllllllIII = llIllIlIIlII[1];
      "".length();
      if ((0xA ^ 0xE) <= ((0xA ^ 0x56) & (0xEC ^ 0xB0 ^ 0xFFFFFFFF))) {
        return;
      }
      while (!lIlIIlllIIlIII(llllllllllllllIlllllIIlllllllIII, llllllllllllllIlllllIIlllllllIlI.length))
      {
        llllllllllllllIlllllIIlllllllIlI[llllllllllllllIlllllIIlllllllIII].setEntityId(llllllllllllllIlllllIIlllllllIlI[llllllllllllllIlllllIIlllllllIII].getEntityId() + llllllllllllllIlllllIIlllllllIIl);
        llllllllllllllIlllllIIlllllllIII++;
      }
    }
    llllllllllllllIlllllIIlllllllIll.setEntityId(llllllllllllllIlllllIlIIIIIIIIIl.getEntityID());
    llllllllllllllIlllllIIlllllllIll.setPositionAndRotation(llllllllllllllIlllllIlIIIIIIIIII, llllllllllllllIlllllIIllllllllll, llllllllllllllIlllllIIlllllllllI, llllllllllllllIlllllIIllllllllIl, llllllllllllllIlllllIIllllllllII);
    motionX = (llllllllllllllIlllllIlIIIIIIIIIl.getVelocityX() / 8000.0F);
    motionY = (llllllllllllllIlllllIlIIIIIIIIIl.getVelocityY() / 8000.0F);
    motionZ = (llllllllllllllIlllllIlIIIIIIIIIl.getVelocityZ() / 8000.0F);
    clientWorldController.addEntityToWorld(llllllllllllllIlllllIlIIIIIIIIIl.getEntityID(), llllllllllllllIlllllIIlllllllIll);
    List<DataWatcher.WatchableObject> llllllllllllllIlllllIIllllllIlll = llllllllllllllIlllllIlIIIIIIIIIl.func_149027_c();
    if (lIlIIlllIIIlll(llllllllllllllIlllllIIllllllIlll)) {
      llllllllllllllIlllllIIlllllllIll.getDataWatcher().updateWatchedObjectsFromList(llllllllllllllIlllllIIllllllIlll);
    }
  }
  
  public void handleSetCompressionLevel(S46PacketSetCompressionLevel llllllllllllllIlllllIIlIlIIlIIll)
  {
    ;
    ;
    if (lIlIIlllIIlIlI(netManager.isLocalChannel())) {
      netManager.setCompressionTreshold(llllllllllllllIlllllIIlIlIIlIIll.func_179760_a());
    }
  }
  
  public void handleBlockBreakAnim(S25PacketBlockBreakAnim llllllllllllllIlllllIIllIIlIllIl)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIIlIllIl, llllllllllllllIlllllIIllIIlIlllI, gameController);
    gameController.theWorld.sendBlockBreakProgress(llllllllllllllIlllllIIllIIlIllIl.getBreakerId(), llllllllllllllIlllllIIllIIlIllIl.getPosition(), llllllllllllllIlllllIIllIIlIllIl.getProgress());
  }
  
  public void handleSpawnPlayer(S0CPacketSpawnPlayer llllllllllllllIlllllIlIIlllIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIlllIIIll, llllllllllllllIlllllIlIIlllIIlII, gameController);
    double llllllllllllllIlllllIlIIlllIllII = llllllllllllllIlllllIlIIlllIIIll.getX() / 32.0D;
    double llllllllllllllIlllllIlIIlllIlIll = llllllllllllllIlllllIlIIlllIIIll.getY() / 32.0D;
    double llllllllllllllIlllllIlIIlllIlIlI = llllllllllllllIlllllIlIIlllIIIll.getZ() / 32.0D;
    float llllllllllllllIlllllIlIIlllIlIIl = llllllllllllllIlllllIlIIlllIIIll.getYaw() * llIllIlIIlII[24] / 256.0F;
    float llllllllllllllIlllllIlIIlllIlIII = llllllllllllllIlllllIlIIlllIIIll.getPitch() * llIllIlIIlII[24] / 256.0F;
    EntityOtherPlayerMP llllllllllllllIlllllIlIIlllIIlll = new EntityOtherPlayerMP(gameController.theWorld, llllllllllllllIlllllIlIIlllIIlII.getPlayerInfo(llllllllllllllIlllllIlIIlllIIIll.getPlayer()).getGameProfile());
    prevPosX = (llllllllllllllIlllllIlIIlllIIlll.lastTickPosX = llllllllllllllIlllllIlIIlllIIlll.serverPosX = llllllllllllllIlllllIlIIlllIIIll.getX());
    prevPosY = (llllllllllllllIlllllIlIIlllIIlll.lastTickPosY = llllllllllllllIlllllIlIIlllIIlll.serverPosY = llllllllllllllIlllllIlIIlllIIIll.getY());
    prevPosZ = (llllllllllllllIlllllIlIIlllIIlll.lastTickPosZ = llllllllllllllIlllllIlIIlllIIlll.serverPosZ = llllllllllllllIlllllIlIIlllIIIll.getZ());
    int llllllllllllllIlllllIlIIlllIIllI = llllllllllllllIlllllIlIIlllIIIll.getCurrentItemID();
    if (lIlIIlllIIlIlI(llllllllllllllIlllllIlIIlllIIllI))
    {
      inventory.mainInventory[inventory.currentItem] = null;
      "".length();
      if (((0x4E ^ 0x67 ^ 0x5C ^ 0x70) & (0xC4 ^ 0xB1 ^ 0x72 ^ 0x2 ^ -" ".length())) == 0) {}
    }
    else
    {
      inventory.mainInventory[inventory.currentItem] = new ItemStack(Item.getItemById(llllllllllllllIlllllIlIIlllIIllI), llIllIlIIlII[17], llIllIlIIlII[1]);
    }
    llllllllllllllIlllllIlIIlllIIlll.setPositionAndRotation(llllllllllllllIlllllIlIIlllIllII, llllllllllllllIlllllIlIIlllIlIll, llllllllllllllIlllllIlIIlllIlIlI, llllllllllllllIlllllIlIIlllIlIIl, llllllllllllllIlllllIlIIlllIlIII);
    clientWorldController.addEntityToWorld(llllllllllllllIlllllIlIIlllIIIll.getEntityID(), llllllllllllllIlllllIlIIlllIIlll);
    List<DataWatcher.WatchableObject> llllllllllllllIlllllIlIIlllIIlIl = llllllllllllllIlllllIlIIlllIIIll.func_148944_c();
    if (lIlIIlllIIIlll(llllllllllllllIlllllIlIIlllIIlIl)) {
      llllllllllllllIlllllIlIIlllIIlll.getDataWatcher().updateWatchedObjectsFromList(llllllllllllllIlllllIlIIlllIIlIl);
    }
  }
  
  public void handleEntityHeadLook(S19PacketEntityHeadLook llllllllllllllIlllllIlIIlIIlllll)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIlIIlllll, llllllllllllllIlllllIlIIlIIlllII, gameController);
    Entity llllllllllllllIlllllIlIIlIIllllI = llllllllllllllIlllllIlIIlIIlllll.getEntity(clientWorldController);
    if (lIlIIlllIIIlll(llllllllllllllIlllllIlIIlIIllllI))
    {
      float llllllllllllllIlllllIlIIlIIlllIl = llllllllllllllIlllllIlIIlIIlllll.getYaw() * llIllIlIIlII[24] / 256.0F;
      llllllllllllllIlllllIlIIlIIllllI.setRotationYawHead(llllllllllllllIlllllIlIIlIIlllIl);
    }
  }
  
  public void handleSetExperience(S1FPacketSetExperience llllllllllllllIlllllIIlllIlllIIl)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlllIlllIIl, llllllllllllllIlllllIIlllIllllII, gameController);
    gameController.thePlayer.setXPStats(llllllllllllllIlllllIIlllIlllIIl.func_149397_c(), llllllllllllllIlllllIIlllIlllIIl.getTotalExperience(), llllllllllllllIlllllIIlllIlllIIl.getLevel());
  }
  
  public void handleEntityEffect(S1DPacketEntityEffect llllllllllllllIlllllIIlIllIllIlI)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIllIllIlI, llllllllllllllIlllllIIlIllIllIll, gameController);
    Entity llllllllllllllIlllllIIlIllIllIIl = clientWorldController.getEntityByID(llllllllllllllIlllllIIlIllIllIlI.getEntityId());
    if (lIlIIlllIIIlIl(llllllllllllllIlllllIIlIllIllIIl instanceof EntityLivingBase))
    {
      PotionEffect llllllllllllllIlllllIIlIllIllIII = new PotionEffect(llllllllllllllIlllllIIlIllIllIlI.getEffectId(), llllllllllllllIlllllIIlIllIllIlI.getDuration(), llllllllllllllIlllllIIlIllIllIlI.getAmplifier(), llIllIlIIlII[1], llllllllllllllIlllllIIlIllIllIlI.func_179707_f());
      llllllllllllllIlllllIIlIllIllIII.setPotionDurationMax(llllllllllllllIlllllIIlIllIllIlI.func_149429_c());
      ((EntityLivingBase)llllllllllllllIlllllIIlIllIllIIl).addPotionEffect(llllllllllllllIlllllIIlIllIllIII);
    }
  }
  
  public GameProfile getGameProfile()
  {
    ;
    return profile;
  }
  
  private static boolean lIlIIlllIIllll(int ???)
  {
    byte llllllllllllllIlllllIIIlIIlIlIIl;
    return ??? >= 0;
  }
  
  public void handleMultiBlockChange(S22PacketMultiBlockChange llllllllllllllIlllllIlIIIllIllIl)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIIllIllIl, llllllllllllllIlllllIlIIIllIlllI, gameController);
    boolean llllllllllllllIlllllIlIIIllIlIlI = (llllllllllllllIlllllIlIIIllIlIIl = llllllllllllllIlllllIlIIIllIllIl.getChangedBlocks()).length;
    char llllllllllllllIlllllIlIIIllIlIll = llIllIlIIlII[1];
    "".length();
    if (null != null) {
      return;
    }
    while (!lIlIIlllIIlIII(llllllllllllllIlllllIlIIIllIlIll, llllllllllllllIlllllIlIIIllIlIlI))
    {
      S22PacketMultiBlockChange.BlockUpdateData llllllllllllllIlllllIlIIIllIllll = llllllllllllllIlllllIlIIIllIlIIl[llllllllllllllIlllllIlIIIllIlIll];
      "".length();
    }
  }
  
  public void handleJoinGame(S01PacketJoinGame llllllllllllllIlllllIlIlIllllIlI)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIlIllllIlI, llllllllllllllIlllllIlIlIllllIll, gameController);
    gameController.playerController = new PlayerControllerMP(gameController, llllllllllllllIlllllIlIlIllllIll);
    clientWorldController = new WorldClient(llllllllllllllIlllllIlIlIllllIll, new WorldSettings(0L, llllllllllllllIlllllIlIlIllllIlI.getGameType(), llIllIlIIlII[1], llllllllllllllIlllllIlIlIllllIlI.isHardcoreMode(), llllllllllllllIlllllIlIlIllllIlI.getWorldType()), llllllllllllllIlllllIlIlIllllIlI.getDimension(), llllllllllllllIlllllIlIlIllllIlI.getDifficulty(), gameController.mcProfiler);
    gameController.gameSettings.difficulty = llllllllllllllIlllllIlIlIllllIlI.getDifficulty();
    gameController.loadWorld(clientWorldController);
    gameController.thePlayer.dimension = llllllllllllllIlllllIlIlIllllIlI.getDimension();
    gameController.displayGuiScreen(new GuiDownloadTerrain(llllllllllllllIlllllIlIlIllllIll));
    gameController.thePlayer.setEntityId(llllllllllllllIlllllIlIlIllllIlI.getEntityId());
    currentServerMaxPlayers = llllllllllllllIlllllIlIlIllllIlI.getMaxPlayers();
    gameController.thePlayer.setReducedDebug(llllllllllllllIlllllIlIlIllllIlI.isReducedDebugInfo());
    gameController.playerController.setGameType(llllllllllllllIlllllIlIlIllllIlI.getGameType());
    gameController.gameSettings.sendSettingsToServer();
    netManager.sendPacket(new C17PacketCustomPayload(llIllIlIIIIl[llIllIlIIlII[1]], new PacketBuffer(Unpooled.buffer()).writeString(ClientBrandRetriever.getClientModName())));
  }
  
  public void handleUpdateTileEntity(S35PacketUpdateTileEntity llllllllllllllIlllllIIllIlIlIIll)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIlIlIIll, llllllllllllllIlllllIIllIlIlIlII, gameController);
    if (lIlIIlllIIIlIl(gameController.theWorld.isBlockLoaded(llllllllllllllIlllllIIllIlIlIIll.getPos())))
    {
      TileEntity llllllllllllllIlllllIIllIlIlIllI = gameController.theWorld.getTileEntity(llllllllllllllIlllllIIllIlIlIIll.getPos());
      int llllllllllllllIlllllIIllIlIlIlIl = llllllllllllllIlllllIIllIlIlIIll.getTileEntityType();
      if (((lIlIIlllIIIlII(llllllllllllllIlllllIIllIlIlIlIl, llIllIlIIlII[17])) && (!lIlIIlllIIlIlI(llllllllllllllIlllllIIllIlIlIllI instanceof TileEntityMobSpawner))) || ((lIlIIlllIIIlII(llllllllllllllIlllllIIllIlIlIlIl, llIllIlIIlII[21])) && (!lIlIIlllIIlIlI(llllllllllllllIlllllIIllIlIlIllI instanceof TileEntityCommandBlock))) || ((lIlIIlllIIIlII(llllllllllllllIlllllIIllIlIlIlIl, llIllIlIIlII[25])) && (!lIlIIlllIIlIlI(llllllllllllllIlllllIIllIlIlIllI instanceof TileEntityBeacon))) || ((lIlIIlllIIIlII(llllllllllllllIlllllIIllIlIlIlIl, llIllIlIIlII[26])) && (!lIlIIlllIIlIlI(llllllllllllllIlllllIIllIlIlIllI instanceof TileEntitySkull))) || ((lIlIIlllIIIlII(llllllllllllllIlllllIIllIlIlIlIl, llIllIlIIlII[29])) && (!lIlIIlllIIlIlI(llllllllllllllIlllllIIllIlIlIllI instanceof TileEntityFlowerPot))) || ((lIlIIlllIIIlII(llllllllllllllIlllllIIllIlIlIlIl, llIllIlIIlII[30])) && (lIlIIlllIIIlIl(llllllllllllllIlllllIIllIlIlIllI instanceof TileEntityBanner)))) {
        llllllllllllllIlllllIIllIlIlIllI.readFromNBT(llllllllllllllIlllllIIllIlIlIIll.getNbtCompound());
      }
    }
  }
  
  private static boolean lIlIIlllIlIIII(int ???, int arg1)
  {
    int i;
    double llllllllllllllIlllllIIIlIIlllIll;
    return ??? < i;
  }
  
  private static boolean lIlIIlllIIIlll(Object ???)
  {
    float llllllllllllllIlllllIIIlIIllIlIl;
    return ??? != null;
  }
  
  public void handleAnimation(S0BPacketAnimation llllllllllllllIlllllIlIIIIIlIllI)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIIIIlIllI, llllllllllllllIlllllIlIIIIIlIlll, gameController);
    Entity llllllllllllllIlllllIlIIIIIllIlI = clientWorldController.getEntityByID(llllllllllllllIlllllIlIIIIIlIllI.getEntityID());
    if (lIlIIlllIIIlll(llllllllllllllIlllllIlIIIIIllIlI)) {
      if (lIlIIlllIIlIlI(llllllllllllllIlllllIlIIIIIlIllI.getAnimationType()))
      {
        EntityLivingBase llllllllllllllIlllllIlIIIIIllIIl = (EntityLivingBase)llllllllllllllIlllllIlIIIIIllIlI;
        llllllllllllllIlllllIlIIIIIllIIl.swingItem();
        "".length();
        if (" ".length() > 0) {}
      }
      else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIIIIIlIllI.getAnimationType(), llIllIlIIlII[17]))
      {
        llllllllllllllIlllllIlIIIIIllIlI.performHurtAnimation();
        "".length();
        if (null == null) {}
      }
      else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIIIIIlIllI.getAnimationType(), llIllIlIIlII[21]))
      {
        EntityPlayer llllllllllllllIlllllIlIIIIIllIII = (EntityPlayer)llllllllllllllIlllllIlIIIIIllIlI;
        llllllllllllllIlllllIlIIIIIllIII.wakeUpPlayer(llIllIlIIlII[1], llIllIlIIlII[1], llIllIlIIlII[1]);
        "".length();
        if (-(0x36 ^ 0x33) < 0) {}
      }
      else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIIIIIlIllI.getAnimationType(), llIllIlIIlII[26]))
      {
        gameController.effectRenderer.emitParticleAtEntity(llllllllllllllIlllllIlIIIIIllIlI, EnumParticleTypes.CRIT);
        "".length();
        if (((42 + 115 - 33 + 4 ^ '' + 106 - 210 + 118) & (0x5D ^ 0x79 ^ 0xB ^ 0x3D ^ -" ".length())) == 0) {}
      }
      else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIIIIIlIllI.getAnimationType(), llIllIlIIlII[29]))
      {
        gameController.effectRenderer.emitParticleAtEntity(llllllllllllllIlllllIlIIIIIllIlI, EnumParticleTypes.CRIT_MAGIC);
      }
    }
  }
  
  public void handleMaps(S34PacketMaps llllllllllllllIlllllIIllIIIIIIIl)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIIIIIIIl, llllllllllllllIlllllIIlIllllllll, gameController);
    MapData llllllllllllllIlllllIIllIIIIIIII = ItemMap.loadMapData(llllllllllllllIlllllIIllIIIIIIIl.getMapId(), gameController.theWorld);
    llllllllllllllIlllllIIllIIIIIIIl.setMapdataTo(llllllllllllllIlllllIIllIIIIIIII);
    gameController.entityRenderer.getMapItemRenderer().updateMapTexture(llllllllllllllIlllllIIllIIIIIIII);
  }
  
  public void handleWindowItems(S30PacketWindowItems llllllllllllllIlllllIIllIllllIIl)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIllllIIl, llllllllllllllIlllllIIllIlllIlll, gameController);
    EntityPlayer llllllllllllllIlllllIIllIllllIII = gameController.thePlayer;
    if (lIlIIlllIIlIlI(llllllllllllllIlllllIIllIllllIIl.func_148911_c()))
    {
      inventoryContainer.putStacksInSlots(llllllllllllllIlllllIIllIllllIIl.getItemStacks());
      "".length();
      if ("   ".length() > 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIIllIllllIIl.func_148911_c(), openContainer.windowId))
    {
      openContainer.putStacksInSlots(llllllllllllllIlllllIIllIllllIIl.getItemStacks());
    }
  }
  
  public void handleUseBed(S0APacketUseBed llllllllllllllIlllllIlIIIIIIlllI)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIIIIIlllI, llllllllllllllIlllllIlIIIIIIllll, gameController);
    "".length();
  }
  
  private static boolean lIlIIlllIIllII(int ???)
  {
    Exception llllllllllllllIlllllIIIlIIlIIlll;
    return ??? < 0;
  }
  
  private static boolean lIlIIlllIlIlIl(Object ???, Object arg1)
  {
    Object localObject;
    boolean llllllllllllllIlllllIIIlIIllIIIl;
    return ??? == localObject;
  }
  
  public void handleSpawnExperienceOrb(S11PacketSpawnExperienceOrb llllllllllllllIlllllIlIlIIlIlIlI)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIlIIlIlIlI, llllllllllllllIlllllIlIlIIlIlIII, gameController);
    Entity llllllllllllllIlllllIlIlIIlIlIIl = new EntityXPOrb(clientWorldController, llllllllllllllIlllllIlIlIIlIlIlI.getX() / 32.0D, llllllllllllllIlllllIlIlIIlIlIlI.getY() / 32.0D, llllllllllllllIlllllIlIlIIlIlIlI.getZ() / 32.0D, llllllllllllllIlllllIlIlIIlIlIlI.getXPValue());
    serverPosX = llllllllllllllIlllllIlIlIIlIlIlI.getX();
    serverPosY = llllllllllllllIlllllIlIlIIlIlIlI.getY();
    serverPosZ = llllllllllllllIlllllIlIlIIlIlIlI.getZ();
    rotationYaw = 0.0F;
    rotationPitch = 0.0F;
    llllllllllllllIlllllIlIlIIlIlIIl.setEntityId(llllllllllllllIlllllIlIlIIlIlIlI.getEntityID());
    clientWorldController.addEntityToWorld(llllllllllllllIlllllIlIlIIlIlIlI.getEntityID(), llllllllllllllIlllllIlIlIIlIlIIl);
  }
  
  public void handleScoreboardObjective(S3BPacketScoreboardObjective llllllllllllllIlllllIIlIIIIlIIIl)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIIIIlIIIl, llllllllllllllIlllllIIlIIIIlIIlI, gameController);
    Scoreboard llllllllllllllIlllllIIlIIIIlIlIl = clientWorldController.getScoreboard();
    if (lIlIIlllIIlIlI(llllllllllllllIlllllIIlIIIIlIIIl.func_149338_e()))
    {
      ScoreObjective llllllllllllllIlllllIIlIIIIlIlII = llllllllllllllIlllllIIlIIIIlIlIl.addScoreObjective(llllllllllllllIlllllIIlIIIIlIIIl.func_149339_c(), IScoreObjectiveCriteria.DUMMY);
      llllllllllllllIlllllIIlIIIIlIlII.setDisplayName(llllllllllllllIlllllIIlIIIIlIIIl.func_149337_d());
      llllllllllllllIlllllIIlIIIIlIlII.setRenderType(llllllllllllllIlllllIIlIIIIlIIIl.func_179817_d());
      "".length();
      if ("  ".length() > ((0x3F ^ 0x14) & (0x66 ^ 0x4D ^ 0xFFFFFFFF))) {}
    }
    else
    {
      ScoreObjective llllllllllllllIlllllIIlIIIIlIIll = llllllllllllllIlllllIIlIIIIlIlIl.getObjective(llllllllllllllIlllllIIlIIIIlIIIl.func_149339_c());
      if (lIlIIlllIIIlII(llllllllllllllIlllllIIlIIIIlIIIl.func_149338_e(), llIllIlIIlII[17]))
      {
        llllllllllllllIlllllIIlIIIIlIlIl.removeObjective(llllllllllllllIlllllIIlIIIIlIIll);
        "".length();
        if (-(0x0 ^ 0x4) <= 0) {}
      }
      else if (lIlIIlllIIIlII(llllllllllllllIlllllIIlIIIIlIIIl.func_149338_e(), llIllIlIIlII[21]))
      {
        llllllllllllllIlllllIIlIIIIlIIll.setDisplayName(llllllllllllllIlllllIIlIIIIlIIIl.func_149337_d());
        llllllllllllllIlllllIIlIIIIlIIll.setRenderType(llllllllllllllIlllllIIlIIIIlIIIl.func_179817_d());
      }
    }
  }
  
  public void handleSpawnObject(S0EPacketSpawnObject llllllllllllllIlllllIlIlIIllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIlIIllIllI, llllllllllllllIlllllIlIlIIllIlll, gameController);
    double llllllllllllllIlllllIlIlIlIIIIII = llllllllllllllIlllllIlIlIIllIllI.getX() / 32.0D;
    double llllllllllllllIlllllIlIlIIllllll = llllllllllllllIlllllIlIlIIllIllI.getY() / 32.0D;
    double llllllllllllllIlllllIlIlIIlllllI = llllllllllllllIlllllIlIlIIllIllI.getZ() / 32.0D;
    Entity llllllllllllllIlllllIlIlIIllllIl = null;
    if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[2]))
    {
      llllllllllllllIlllllIlIlIIllllIl = EntityMinecart.func_180458_a(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI, EntityMinecart.EnumMinecartType.byNetworkID(llllllllllllllIlllllIlIlIIllIllI.func_149009_m()));
      "".length();
      if (null == null) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[3]))
    {
      Entity llllllllllllllIlllllIlIlIIllllII = clientWorldController.getEntityByID(llllllllllllllIlllllIlIlIIllIllI.func_149009_m());
      if (lIlIIlllIIIlIl(llllllllllllllIlllllIlIlIIllllII instanceof EntityPlayer)) {
        llllllllllllllIlllllIlIlIIllllIl = new EntityFishHook(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI, (EntityPlayer)llllllllllllllIlllllIlIlIIllllII);
      }
      llllllllllllllIlllllIlIlIIllIllI.func_149002_g(llIllIlIIlII[1]);
      "".length();
      if ("  ".length() != " ".length()) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[4]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityArrow(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI);
      "".length();
      if ((0x16 ^ 0x41 ^ 0x49 ^ 0x1A) >= " ".length()) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[5]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntitySnowball(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI);
      "".length();
      if (((76 + 89 - 138 + 118 ^ '' + 12 - 79 + 131) & (0x37 ^ 0x31 ^ 0x33 ^ 0x65 ^ -" ".length())) == ((0x21 ^ 0x51 ^ 0x76 ^ 0x35) & (15 + 63 - 6 + 80 ^ 69 + '' - 169 + 117 ^ -" ".length()))) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[6]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityItemFrame(clientWorldController, new BlockPos(MathHelper.floor_double(llllllllllllllIlllllIlIlIlIIIIII), MathHelper.floor_double(llllllllllllllIlllllIlIlIIllllll), MathHelper.floor_double(llllllllllllllIlllllIlIlIIlllllI)), EnumFacing.getHorizontal(llllllllllllllIlllllIlIlIIllIllI.func_149009_m()));
      llllllllllllllIlllllIlIlIIllIllI.func_149002_g(llIllIlIIlII[1]);
      "".length();
      if ("   ".length() != "  ".length()) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[7]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityLeashKnot(clientWorldController, new BlockPos(MathHelper.floor_double(llllllllllllllIlllllIlIlIlIIIIII), MathHelper.floor_double(llllllllllllllIlllllIlIlIIllllll), MathHelper.floor_double(llllllllllllllIlllllIlIlIIlllllI)));
      llllllllllllllIlllllIlIlIIllIllI.func_149002_g(llIllIlIIlII[1]);
      "".length();
      if (null == null) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[8]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityEnderPearl(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI);
      "".length();
      if ("   ".length() >= 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[9]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityEnderEye(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI);
      "".length();
      if (((0x22 ^ 0x9) & (0xA8 ^ 0x83 ^ 0xFFFFFFFF)) <= 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[10]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityFireworkRocket(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI, null);
      "".length();
      if ("   ".length() >= " ".length()) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[11]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityLargeFireball(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI, llllllllllllllIlllllIlIlIIllIllI.getSpeedX() / 8000.0D, llllllllllllllIlllllIlIlIIllIllI.getSpeedY() / 8000.0D, llllllllllllllIlllllIlIlIIllIllI.getSpeedZ() / 8000.0D);
      llllllllllllllIlllllIlIlIIllIllI.func_149002_g(llIllIlIIlII[1]);
      "".length();
      if (('' + 111 - 166 + 94 ^ '©' + 59 - 166 + 132) != " ".length()) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[12]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntitySmallFireball(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI, llllllllllllllIlllllIlIlIIllIllI.getSpeedX() / 8000.0D, llllllllllllllIlllllIlIlIIllIllI.getSpeedY() / 8000.0D, llllllllllllllIlllllIlIlIIllIllI.getSpeedZ() / 8000.0D);
      llllllllllllllIlllllIlIlIIllIllI.func_149002_g(llIllIlIIlII[1]);
      "".length();
      if (((0xA5 ^ 0x8B) & (0x35 ^ 0x1B ^ 0xFFFFFFFF)) <= 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[13]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityWitherSkull(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI, llllllllllllllIlllllIlIlIIllIllI.getSpeedX() / 8000.0D, llllllllllllllIlllllIlIlIIllIllI.getSpeedY() / 8000.0D, llllllllllllllIlllllIlIlIIllIllI.getSpeedZ() / 8000.0D);
      llllllllllllllIlllllIlIlIIllIllI.func_149002_g(llIllIlIIlII[1]);
      "".length();
      if (null == null) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[14]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityEgg(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI);
      "".length();
      if ("   ".length() >= 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[15]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityPotion(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI, llllllllllllllIlllllIlIlIIllIllI.func_149009_m());
      llllllllllllllIlllllIlIlIIllIllI.func_149002_g(llIllIlIIlII[1]);
      "".length();
      if (-" ".length() < " ".length()) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[16]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityExpBottle(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI);
      llllllllllllllIlllllIlIlIIllIllI.func_149002_g(llIllIlIIlII[1]);
      "".length();
      if (-"  ".length() <= 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[17]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityBoat(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI);
      "".length();
      if ((0x50 ^ 0x54) >= " ".length()) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[18]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityTNTPrimed(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI, null);
      "".length();
      if ((0x5D ^ 0x7 ^ 0xC3 ^ 0x9D) != 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[19]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityArmorStand(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI);
      "".length();
      if (null == null) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[20]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityEnderCrystal(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI);
      "".length();
      if ((0x8E ^ 0x8B) != 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[21]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityItem(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI);
      "".length();
      if (null == null) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[22]))
    {
      llllllllllllllIlllllIlIlIIllllIl = new EntityFallingBlock(clientWorldController, llllllllllllllIlllllIlIlIlIIIIII, llllllllllllllIlllllIlIlIIllllll, llllllllllllllIlllllIlIlIIlllllI, Block.getStateById(llllllllllllllIlllllIlIlIIllIllI.func_149009_m() & llIllIlIIlII[23]));
      llllllllllllllIlllllIlIlIIllIllI.func_149002_g(llIllIlIIlII[1]);
    }
    if (lIlIIlllIIIlll(llllllllllllllIlllllIlIlIIllllIl))
    {
      serverPosX = llllllllllllllIlllllIlIlIIllIllI.getX();
      serverPosY = llllllllllllllIlllllIlIlIIllIllI.getY();
      serverPosZ = llllllllllllllIlllllIlIlIIllIllI.getZ();
      rotationPitch = (llllllllllllllIlllllIlIlIIllIllI.getPitch() * llIllIlIIlII[24] / 256.0F);
      rotationYaw = (llllllllllllllIlllllIlIlIIllIllI.getYaw() * llIllIlIIlII[24] / 256.0F);
      Entity[] llllllllllllllIlllllIlIlIIlllIll = llllllllllllllIlllllIlIlIIllllIl.getParts();
      if (lIlIIlllIIIlll(llllllllllllllIlllllIlIlIIlllIll))
      {
        int llllllllllllllIlllllIlIlIIlllIlI = llllllllllllllIlllllIlIlIIllIllI.getEntityID() - llllllllllllllIlllllIlIlIIllllIl.getEntityId();
        int llllllllllllllIlllllIlIlIIlllIIl = llIllIlIIlII[1];
        "".length();
        if (-"   ".length() >= 0) {
          return;
        }
        while (!lIlIIlllIIlIII(llllllllllllllIlllllIlIlIIlllIIl, llllllllllllllIlllllIlIlIIlllIll.length))
        {
          llllllllllllllIlllllIlIlIIlllIll[llllllllllllllIlllllIlIlIIlllIIl].setEntityId(llllllllllllllIlllllIlIlIIlllIll[llllllllllllllIlllllIlIlIIlllIIl].getEntityId() + llllllllllllllIlllllIlIlIIlllIlI);
          llllllllllllllIlllllIlIlIIlllIIl++;
        }
      }
      llllllllllllllIlllllIlIlIIllllIl.setEntityId(llllllllllllllIlllllIlIlIIllIllI.getEntityID());
      clientWorldController.addEntityToWorld(llllllllllllllIlllllIlIlIIllIllI.getEntityID(), llllllllllllllIlllllIlIlIIllllIl);
      if (lIlIIlllIIlIIl(llllllllllllllIlllllIlIlIIllIllI.func_149009_m()))
      {
        if (lIlIIlllIIIlII(llllllllllllllIlllllIlIlIIllIllI.getType(), llIllIlIIlII[4]))
        {
          Entity llllllllllllllIlllllIlIlIIlllIII = clientWorldController.getEntityByID(llllllllllllllIlllllIlIlIIllIllI.func_149009_m());
          if ((lIlIIlllIIIlIl(llllllllllllllIlllllIlIlIIlllIII instanceof EntityLivingBase)) && (lIlIIlllIIIlIl(llllllllllllllIlllllIlIlIIllllIl instanceof EntityArrow))) {
            shootingEntity = llllllllllllllIlllllIlIlIIlllIII;
          }
        }
        llllllllllllllIlllllIlIlIIllllIl.setVelocity(llllllllllllllIlllllIlIlIIllIllI.getSpeedX() / 8000.0D, llllllllllllllIlllllIlIlIIllIllI.getSpeedY() / 8000.0D, llllllllllllllIlllllIlIlIIllIllI.getSpeedZ() / 8000.0D);
      }
    }
  }
  
  public void handleEntityNBT(S49PacketUpdateEntityNBT llllllllllllllIlllllIIlIIIlllIIl)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIIIlllIIl, llllllllllllllIlllllIIlIIIlllIlI, gameController);
    Entity llllllllllllllIlllllIIlIIIlllIII = llllllllllllllIlllllIIlIIIlllIIl.getEntity(clientWorldController);
    if (lIlIIlllIIIlll(llllllllllllllIlllllIIlIIIlllIII)) {
      llllllllllllllIlllllIIlIIIlllIII.clientUpdateEntityNBT(llllllllllllllIlllllIIlIIIlllIIl.getTagCompound());
    }
  }
  
  private static boolean lIlIIlllIIlIIl(int ???)
  {
    char llllllllllllllIlllllIIIlIIlIIlIl;
    return ??? > 0;
  }
  
  private static boolean lIlIIlllIlIllI(Object ???, Object arg1)
  {
    Object localObject;
    short llllllllllllllIlllllIIIlIIllIlll;
    return ??? != localObject;
  }
  
  public void handleDisplayScoreboard(S3DPacketDisplayScoreboard llllllllllllllIlllllIIIllllllIlI)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIIllllllIlI, llllllllllllllIlllllIIIllllllIll, gameController);
    Scoreboard llllllllllllllIlllllIIIllllllIIl = clientWorldController.getScoreboard();
    if (lIlIIlllIIlIlI(llllllllllllllIlllllIIIllllllIlI.func_149370_d().length()))
    {
      llllllllllllllIlllllIIIllllllIIl.setObjectiveInDisplaySlot(llllllllllllllIlllllIIIllllllIlI.func_149371_c(), null);
      "".length();
      if (null == null) {}
    }
    else
    {
      ScoreObjective llllllllllllllIlllllIIIllllllIII = llllllllllllllIlllllIIIllllllIIl.getObjective(llllllllllllllIlllllIIIllllllIlI.func_149370_d());
      llllllllllllllIlllllIIIllllllIIl.setObjectiveInDisplaySlot(llllllllllllllIlllllIIIllllllIlI.func_149371_c(), llllllllllllllIlllllIIIllllllIII);
    }
  }
  
  public void handleDestroyEntities(S13PacketDestroyEntities llllllllllllllIlllllIlIIlIIlIlII)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIlIIlIlII, llllllllllllllIlllllIlIIlIIlIIlI, gameController);
    int llllllllllllllIlllllIlIIlIIlIIll = llIllIlIIlII[1];
    "".length();
    if (null != null) {
      return;
    }
    while (!lIlIIlllIIlIII(llllllllllllllIlllllIlIIlIIlIIll, llllllllllllllIlllllIlIIlIIlIlII.getEntityIDs().length)) {
      "".length();
    }
  }
  
  public void handlePlayerListHeaderFooter(S47PacketPlayerListHeaderFooter llllllllllllllIlllllIIlIlIIIlIll)
  {
    ;
    ;
    if (lIlIIlllIIlIlI(llllllllllllllIlllllIIlIlIIIlIll.getHeader().getFormattedText().length()))
    {
      "".length();
      if (-"   ".length() <= 0) {
        break label50;
      }
    }
    label50:
    null.setHeader(llllllllllllllIlllllIIlIlIIIlIll.getHeader());
    if (lIlIIlllIIlIlI(llllllllllllllIlllllIIlIlIIIlIll.getFooter().getFormattedText().length()))
    {
      "".length();
      if ((0x66 ^ 0x62) > "  ".length()) {
        break label106;
      }
    }
    label106:
    null.setFooter(llllllllllllllIlllllIIlIlIIIlIll.getFooter());
  }
  
  public void handleParticles(S2APacketParticles llllllllllllllIlllllIIIlllIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIIlllIIIIll, llllllllllllllIlllllIIIlllIIIlII, gameController);
    if (lIlIIlllIIlIlI(llllllllllllllIlllllIIIlllIIIIll.getParticleCount()))
    {
      double llllllllllllllIlllllIIIlllIlIIII = llllllllllllllIlllllIIIlllIIIIll.getParticleSpeed() * llllllllllllllIlllllIIIlllIIIIll.getXOffset();
      double llllllllllllllIlllllIIIlllIIllll = llllllllllllllIlllllIIIlllIIIIll.getParticleSpeed() * llllllllllllllIlllllIIIlllIIIIll.getYOffset();
      double llllllllllllllIlllllIIIlllIIlllI = llllllllllllllIlllllIIIlllIIIIll.getParticleSpeed() * llllllllllllllIlllllIIIlllIIIIll.getZOffset();
      try
      {
        clientWorldController.spawnParticle(llllllllllllllIlllllIIIlllIIIIll.getParticleType(), llllllllllllllIlllllIIIlllIIIIll.isLongDistance(), llllllllllllllIlllllIIIlllIIIIll.getXCoordinate(), llllllllllllllIlllllIIIlllIIIIll.getYCoordinate(), llllllllllllllIlllllIIIlllIIIIll.getZCoordinate(), llllllllllllllIlllllIIIlllIlIIII, llllllllllllllIlllllIIIlllIIllll, llllllllllllllIlllllIIIlllIIlllI, llllllllllllllIlllllIIIlllIIIIll.getParticleArgs());
        "".length();
        if (-" ".length() <= 0) {
          return;
        }
        return;
      }
      catch (Throwable llllllllllllllIlllllIIIlllIIllIl)
      {
        logger.warn(String.valueOf(new StringBuilder(llIllIlIIIIl[llIllIlIIlII[54]]).append(llllllllllllllIlllllIIIlllIIIIll.getParticleType())));
        "".length();
        if ("   ".length() >= "   ".length()) {
          return;
        }
      }
    }
    else
    {
      int llllllllllllllIlllllIIIlllIIllII = llIllIlIIlII[1];
      "".length();
      if ((0x8A ^ 0x8E) > (0x61 ^ 0x65)) {
        return;
      }
      while (!lIlIIlllIIlIII(llllllllllllllIlllllIIIlllIIllII, llllllllllllllIlllllIIIlllIIIIll.getParticleCount()))
      {
        double llllllllllllllIlllllIIIlllIIlIll = avRandomizer.nextGaussian() * llllllllllllllIlllllIIIlllIIIIll.getXOffset();
        double llllllllllllllIlllllIIIlllIIlIlI = avRandomizer.nextGaussian() * llllllllllllllIlllllIIIlllIIIIll.getYOffset();
        double llllllllllllllIlllllIIIlllIIlIIl = avRandomizer.nextGaussian() * llllllllllllllIlllllIIIlllIIIIll.getZOffset();
        double llllllllllllllIlllllIIIlllIIlIII = avRandomizer.nextGaussian() * llllllllllllllIlllllIIIlllIIIIll.getParticleSpeed();
        double llllllllllllllIlllllIIIlllIIIlll = avRandomizer.nextGaussian() * llllllllllllllIlllllIIIlllIIIIll.getParticleSpeed();
        double llllllllllllllIlllllIIIlllIIIllI = avRandomizer.nextGaussian() * llllllllllllllIlllllIIIlllIIIIll.getParticleSpeed();
        try
        {
          clientWorldController.spawnParticle(llllllllllllllIlllllIIIlllIIIIll.getParticleType(), llllllllllllllIlllllIIIlllIIIIll.isLongDistance(), llllllllllllllIlllllIIIlllIIIIll.getXCoordinate() + llllllllllllllIlllllIIIlllIIlIll, llllllllllllllIlllllIIIlllIIIIll.getYCoordinate() + llllllllllllllIlllllIIIlllIIlIlI, llllllllllllllIlllllIIIlllIIIIll.getZCoordinate() + llllllllllllllIlllllIIIlllIIlIIl, llllllllllllllIlllllIIIlllIIlIII, llllllllllllllIlllllIIIlllIIIlll, llllllllllllllIlllllIIIlllIIIllI, llllllllllllllIlllllIIIlllIIIIll.getParticleArgs());
          "".length();
          if ("   ".length() <= ((91 + 52 - 121 + 148 ^ 91 + 106 - 132 + 116) & (31 + 17 - 24 + 106 ^ 70 + 109 - 43 + 21 ^ -" ".length()))) {
            return;
          }
        }
        catch (Throwable llllllllllllllIlllllIIIlllIIIlIl)
        {
          logger.warn(String.valueOf(new StringBuilder(llIllIlIIIIl[llIllIlIIlII[55]]).append(llllllllllllllIlllllIIIlllIIIIll.getParticleType())));
          return;
        }
        llllllllllllllIlllllIIIlllIIllII++;
      }
    }
  }
  
  public void handleCloseWindow(S2EPacketCloseWindow llllllllllllllIlllllIIllIIlllIIl)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllIIlllIIl, llllllllllllllIlllllIIllIIlllIlI, gameController);
    gameController.thePlayer.closeScreenAndDropStack();
  }
  
  public void handleTimeUpdate(S03PacketTimeUpdate llllllllllllllIlllllIIlllllIlIII)
  {
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlllllIlIII, llllllllllllllIlllllIIlllllIIlll, gameController);
    gameController.theWorld.setTotalWorldTime(llllllllllllllIlllllIIlllllIlIII.getTotalWorldTime());
    gameController.theWorld.setWorldTime(llllllllllllllIlllllIIlllllIlIII.getWorldTime());
  }
  
  public void handlePlayerPosLook(S08PacketPlayerPosLook llllllllllllllIlllllIlIIIllllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIIllllllI, llllllllllllllIlllllIlIIlIIIIlll, gameController);
    EntityPlayer llllllllllllllIlllllIlIIlIIIIlIl = gameController.thePlayer;
    double llllllllllllllIlllllIlIIlIIIIlII = llllllllllllllIlllllIlIIIllllllI.getX();
    double llllllllllllllIlllllIlIIlIIIIIll = llllllllllllllIlllllIlIIIllllllI.getY();
    double llllllllllllllIlllllIlIIlIIIIIlI = llllllllllllllIlllllIlIIIllllllI.getZ();
    float llllllllllllllIlllllIlIIlIIIIIIl = llllllllllllllIlllllIlIIIllllllI.getYaw();
    float llllllllllllllIlllllIlIIlIIIIIII = llllllllllllllIlllllIlIIIllllllI.getPitch();
    if (lIlIIlllIIIlIl(llllllllllllllIlllllIlIIIllllllI.func_179834_f().contains(S08PacketPlayerPosLook.EnumFlags.X)))
    {
      llllllllllllllIlllllIlIIlIIIIlII += posX;
      "".length();
      if ("   ".length() != -" ".length()) {}
    }
    else
    {
      motionX = 0.0D;
    }
    if (lIlIIlllIIIlIl(llllllllllllllIlllllIlIIIllllllI.func_179834_f().contains(S08PacketPlayerPosLook.EnumFlags.Y)))
    {
      llllllllllllllIlllllIlIIlIIIIIll += posY;
      "".length();
      if ((0x2F ^ 0x33 ^ 0x40 ^ 0x59) > 0) {}
    }
    else
    {
      motionY = 0.0D;
    }
    if (lIlIIlllIIIlIl(llllllllllllllIlllllIlIIIllllllI.func_179834_f().contains(S08PacketPlayerPosLook.EnumFlags.Z)))
    {
      llllllllllllllIlllllIlIIlIIIIIlI += posZ;
      "".length();
      if (-"  ".length() < 0) {}
    }
    else
    {
      motionZ = 0.0D;
    }
    if (lIlIIlllIIIlIl(llllllllllllllIlllllIlIIIllllllI.func_179834_f().contains(S08PacketPlayerPosLook.EnumFlags.X_ROT))) {
      llllllllllllllIlllllIlIIlIIIIIII += rotationPitch;
    }
    if (lIlIIlllIIIlIl(llllllllllllllIlllllIlIIIllllllI.func_179834_f().contains(S08PacketPlayerPosLook.EnumFlags.Y_ROT))) {
      llllllllllllllIlllllIlIIlIIIIIIl += rotationYaw;
    }
    llllllllllllllIlllllIlIIlIIIIlIl.setPositionAndRotation(llllllllllllllIlllllIlIIlIIIIlII, llllllllllllllIlllllIlIIlIIIIIll, llllllllllllllIlllllIlIIlIIIIIlI, llllllllllllllIlllllIlIIlIIIIIIl, llllllllllllllIlllllIlIIlIIIIIII);
    netManager.sendPacket(new C03PacketPlayer.C06PacketPlayerPosLook(posX, getEntityBoundingBoxminY, posZ, rotationYaw, rotationPitch, llIllIlIIlII[1]));
    if (lIlIIlllIIlIlI(doneLoadingTerrain))
    {
      gameController.thePlayer.prevPosX = gameController.thePlayer.posX;
      gameController.thePlayer.prevPosY = gameController.thePlayer.posY;
      gameController.thePlayer.prevPosZ = gameController.thePlayer.posZ;
      doneLoadingTerrain = llIllIlIIlII[17];
      gameController.displayGuiScreen(null);
    }
  }
  
  public void handleEntityStatus(S19PacketEntityStatus llllllllllllllIlllllIIllllIIlIIl)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIllllIIlIIl, llllllllllllllIlllllIIllllIIlIlI, gameController);
    Entity llllllllllllllIlllllIIllllIIlIII = llllllllllllllIlllllIIllllIIlIIl.getEntity(clientWorldController);
    if (lIlIIlllIIIlll(llllllllllllllIlllllIIllllIIlIII)) {
      if (lIlIIlllIIIlII(llllllllllllllIlllllIIllllIIlIIl.getOpCode(), llIllIlIIlII[31]))
      {
        gameController.getSoundHandler().playSound(new GuardianSound((EntityGuardian)llllllllllllllIlllllIIllllIIlIII));
        "".length();
        if (-(0x13 ^ 0x17) <= 0) {}
      }
      else
      {
        llllllllllllllIlllllIIllllIIlIII.handleStatusUpdate(llllllllllllllIlllllIIllllIIlIIl.getOpCode());
      }
    }
  }
  
  public void handleConfirmTransaction(S32PacketConfirmTransaction llllllllllllllIlllllIIlllIIIIIII)
  {
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlllIIIIIII, llllllllllllllIlllllIIlllIIIIlIl, gameController);
    Container llllllllllllllIlllllIIlllIIIIIll = null;
    EntityPlayer llllllllllllllIlllllIIlllIIIIIlI = gameController.thePlayer;
    if (lIlIIlllIIlIlI(llllllllllllllIlllllIIlllIIIIIII.getWindowId()))
    {
      llllllllllllllIlllllIIlllIIIIIll = inventoryContainer;
      "".length();
      if (((0x2C ^ 0x3E) & (0x53 ^ 0x41 ^ 0xFFFFFFFF)) == 0) {}
    }
    else if (lIlIIlllIIIlII(llllllllllllllIlllllIIlllIIIIIII.getWindowId(), openContainer.windowId))
    {
      llllllllllllllIlllllIIlllIIIIIll = openContainer;
    }
    if ((lIlIIlllIIIlll(llllllllllllllIlllllIIlllIIIIIll)) && (lIlIIlllIIlIlI(llllllllllllllIlllllIIlllIIIIIII.func_148888_e()))) {
      llllllllllllllIlllllIIlllIIIIlIl.addToSendQueue(new C0FPacketConfirmTransaction(llllllllllllllIlllllIIlllIIIIIII.getWindowId(), llllllllllllllIlllllIIlllIIIIIII.getActionNumber(), llIllIlIIlII[17]));
    }
  }
  
  private static boolean lIlIIlllIIIlII(int ???, int arg1)
  {
    int i;
    long llllllllllllllIlllllIIIlIlIIIIll;
    return ??? == i;
  }
  
  public void handlePlayerAbilities(S39PacketPlayerAbilities llllllllllllllIlllllIIlIIllIIllI)
  {
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIIlIIllIIllI, llllllllllllllIlllllIIlIIllIIlll, gameController);
    EntityPlayer llllllllllllllIlllllIIlIIllIlIII = gameController.thePlayer;
    capabilities.isFlying = llllllllllllllIlllllIIlIIllIIllI.isFlying();
    capabilities.isCreativeMode = llllllllllllllIlllllIIlIIllIIllI.isCreativeMode();
    capabilities.disableDamage = llllllllllllllIlllllIIlIIllIIllI.isInvulnerable();
    capabilities.allowFlying = llllllllllllllIlllllIIlIIllIIllI.isAllowFlying();
    capabilities.setFlySpeed(llllllllllllllIlllllIIlIIllIIllI.getFlySpeed());
    capabilities.setPlayerWalkSpeed(llllllllllllllIlllllIIlIIllIIllI.getWalkSpeed());
  }
  
  public NetworkManager getNetworkManager()
  {
    ;
    return netManager;
  }
  
  public NetworkPlayerInfo getPlayerInfo(String llllllllllllllIlllllIIIllIIIllIl)
  {
    ;
    ;
    ;
    byte llllllllllllllIlllllIIIllIIIlIII = playerInfoMap.values().iterator();
    "".length();
    if (" ".length() >= "   ".length()) {
      return null;
    }
    while (!lIlIIlllIIlIlI(llllllllllllllIlllllIIIllIIIlIII.hasNext()))
    {
      NetworkPlayerInfo llllllllllllllIlllllIIIllIIIllII = (NetworkPlayerInfo)llllllllllllllIlllllIIIllIIIlIII.next();
      if (lIlIIlllIIIlIl(llllllllllllllIlllllIIIllIIIllII.getGameProfile().getName().equals(llllllllllllllIlllllIIIllIIIllIl))) {
        return llllllllllllllIlllllIIIllIIIllII;
      }
    }
    return null;
  }
  
  public void handleKeepAlive(S00PacketKeepAlive llllllllllllllIlllllIIlIIlllIIII)
  {
    ;
    ;
    llllllllllllllIlllllIIlIIlllIIIl.addToSendQueue(new C00PacketKeepAlive(llllllllllllllIlllllIIlIIlllIIII.func_149134_c()));
  }
  
  public NetHandlerPlayClient(Minecraft llllllllllllllIlllllIlIllIlIIIll, GuiScreen llllllllllllllIlllllIlIllIIlllIl, NetworkManager llllllllllllllIlllllIlIllIIlllII, GameProfile llllllllllllllIlllllIlIllIlIIIII)
  {
    gameController = llllllllllllllIlllllIlIllIlIIIll;
    guiScreenServer = llllllllllllllIlllllIlIllIlIIIlI;
    netManager = llllllllllllllIlllllIlIllIIlllII;
    profile = llllllllllllllIlllllIlIllIlIIIII;
  }
  
  public void handleResourcePack(S48PacketResourcePackSend llllllllllllllIlllllIIlIIlIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    final String llllllllllllllIlllllIIlIIlIIlIIl = llllllllllllllIlllllIIlIIlIIlIlI.getURL();
    final String llllllllllllllIlllllIIlIIlIIlIII = llllllllllllllIlllllIIlIIlIIlIlI.getHash();
    if (lIlIIlllIIIlIl(llllllllllllllIlllllIIlIIlIIlIIl.startsWith(llIllIlIIIIl[llIllIlIIlII[31]])))
    {
      String llllllllllllllIlllllIIlIIlIIIlll = llllllllllllllIlllllIIlIIlIIlIIl.substring(llIllIlIIIIl[llIllIlIIlII[47]].length());
      File llllllllllllllIlllllIIlIIlIIIllI = new File(gameController.mcDataDir, llIllIlIIIIl[llIllIlIIlII[48]]);
      File llllllllllllllIlllllIIlIIlIIIlIl = new File(llllllllllllllIlllllIIlIIlIIIllI, llllllllllllllIlllllIIlIIlIIIlll);
      if (lIlIIlllIIIlIl(llllllllllllllIlllllIIlIIlIIIlIl.isFile()))
      {
        netManager.sendPacket(new C19PacketResourcePackStatus(llllllllllllllIlllllIIlIIlIIlIII, C19PacketResourcePackStatus.Action.ACCEPTED));
        Futures.addCallback(gameController.getResourcePackRepository().setResourcePackInstance(llllllllllllllIlllllIIlIIlIIIlIl), new FutureCallback()
        {
          public void onFailure(Throwable lIIIIIIllI)
          {
            ;
            netManager.sendPacket(new C19PacketResourcePackStatus(llllllllllllllIlllllIIlIIlIIlIII, C19PacketResourcePackStatus.Action.FAILED_DOWNLOAD));
          }
          
          public void onSuccess(Object lIIIIIlIlI)
          {
            ;
            netManager.sendPacket(new C19PacketResourcePackStatus(llllllllllllllIlllllIIlIIlIIlIII, C19PacketResourcePackStatus.Action.SUCCESSFULLY_LOADED));
          }
        });
        "".length();
        if ((0x76 ^ 0x72) > "   ".length()) {}
      }
      else
      {
        netManager.sendPacket(new C19PacketResourcePackStatus(llllllllllllllIlllllIIlIIlIIlIII, C19PacketResourcePackStatus.Action.FAILED_DOWNLOAD));
        "".length();
        if (-" ".length() != "  ".length()) {}
      }
    }
    else if ((lIlIIlllIIIlll(gameController.getCurrentServerData())) && (lIlIIlllIlIlIl(gameController.getCurrentServerData().getResourceMode(), ServerData.ServerResourceMode.ENABLED)))
    {
      netManager.sendPacket(new C19PacketResourcePackStatus(llllllllllllllIlllllIIlIIlIIlIII, C19PacketResourcePackStatus.Action.ACCEPTED));
      Futures.addCallback(gameController.getResourcePackRepository().downloadResourcePack(llllllllllllllIlllllIIlIIlIIlIIl, llllllllllllllIlllllIIlIIlIIlIII), new FutureCallback()
      {
        public void onSuccess(Object lllllllllllllllIlIIIlIIIIIlIllIl)
        {
          ;
          netManager.sendPacket(new C19PacketResourcePackStatus(llllllllllllllIlllllIIlIIlIIlIII, C19PacketResourcePackStatus.Action.SUCCESSFULLY_LOADED));
        }
        
        public void onFailure(Throwable lllllllllllllllIlIIIlIIIIIlIlIIl)
        {
          ;
          netManager.sendPacket(new C19PacketResourcePackStatus(llllllllllllllIlllllIIlIIlIIlIII, C19PacketResourcePackStatus.Action.FAILED_DOWNLOAD));
        }
      });
      "".length();
      if (((0x18 ^ 0x1) & (0x65 ^ 0x7C ^ 0xFFFFFFFF)) <= ((0xA5 ^ 0x98) & (0x8C ^ 0xB1 ^ 0xFFFFFFFF))) {}
    }
    else if ((lIlIIlllIIIlll(gameController.getCurrentServerData())) && (lIlIIlllIlIllI(gameController.getCurrentServerData().getResourceMode(), ServerData.ServerResourceMode.PROMPT)))
    {
      netManager.sendPacket(new C19PacketResourcePackStatus(llllllllllllllIlllllIIlIIlIIlIII, C19PacketResourcePackStatus.Action.DECLINED));
      "".length();
      if (-"  ".length() <= 0) {}
    }
    else
    {
      new Runnable();
      {
        private static void lIlllllllll()
        {
          lllIlllIl = new int[4];
          lllIlllIl[0] = ("  ".length() & ("  ".length() ^ 0xFFFFFFFF));
          lllIlllIl[1] = " ".length();
          lllIlllIl[2] = "  ".length();
          lllIlllIl[3] = (0xCD ^ 0xC5);
        }
        
        private static String lIlllllIlll(String lIIlIllIlllIlI, String lIIlIllIlllIIl)
        {
          ;
          ;
          ;
          ;
          ;
          ;
          lIIlIllIlllIlI = new String(Base64.getDecoder().decode(lIIlIllIlllIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
          StringBuilder lIIlIllIlllIII = new StringBuilder();
          char[] lIIlIllIllIlll = lIIlIllIlllIIl.toCharArray();
          int lIIlIllIllIllI = lllIlllIl[0];
          byte lIIlIllIllIIII = lIIlIllIlllIlI.toCharArray();
          float lIIlIllIlIllll = lIIlIllIllIIII.length;
          char lIIlIllIlIlllI = lllIlllIl[0];
          while (llIIIIIIIII(lIIlIllIlIlllI, lIIlIllIlIllll))
          {
            char lIIlIllIlllIll = lIIlIllIllIIII[lIIlIllIlIlllI];
            "".length();
            "".length();
            if (null != null) {
              return null;
            }
          }
          return String.valueOf(lIIlIllIlllIII);
        }
        
        private static void lIllllllIIl()
        {
          lllIlIlll = new String[lllIlllIl[2]];
          lllIlIlll[lllIlllIl[0]] = lIlllllIlll("JSc/JDM4PjIpPzp8JzUiPCchNQo6PT4gLmY+Oj4/eQ==", "HRSPZ");
          lllIlIlll[lllIlllIl[1]] = lIllllllIII("J0/dc+S8QJw0QLoOnkcwWdyL5McWubF5GtINqeGhaP8=", "yjRiZ");
        }
        
        static
        {
          lIlllllllll();
          lIllllllIIl();
        }
        
        private static boolean llIIIIIIIII(int ???, int arg1)
        {
          int i;
          float lIIlIllIIlllII;
          return ??? < i;
        }
        
        private static String lIllllllIII(String lIIlIllIlIIIll, String lIIlIllIlIIlII)
        {
          try
          {
            ;
            ;
            ;
            ;
            SecretKeySpec lIIlIllIlIlIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIIlIllIlIIlII.getBytes(StandardCharsets.UTF_8)), lllIlllIl[3]), "DES");
            Cipher lIIlIllIlIIlll = Cipher.getInstance("DES");
            lIIlIllIlIIlll.init(lllIlllIl[2], lIIlIllIlIlIII);
            return new String(lIIlIllIlIIlll.doFinal(Base64.getDecoder().decode(lIIlIllIlIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
          }
          catch (Exception lIIlIllIlIIllI)
          {
            lIIlIllIlIIllI.printStackTrace();
          }
          return null;
        }
        
        public void run()
        {
          ;
          gameController.displayGuiScreen(new GuiYesNo(new GuiYesNoCallback()
          {
            private static boolean lIIlIIIIlllIll(int ???)
            {
              long lllllllllllllllIIlIlIIlIIllllIII;
              return ??? != 0;
            }
            
            public void confirmClicked(boolean lllllllllllllllIIlIlIIlIlIIIIIIl, int lllllllllllllllIIlIlIIlIlIIIIIII)
            {
              ;
              ;
              gameController = Minecraft.getMinecraft();
              if (lIIlIIIIlllIll(lllllllllllllllIIlIlIIlIIllllllI))
              {
                if (lIIlIIIIllllII(gameController.getCurrentServerData())) {
                  gameController.getCurrentServerData().setResourceMode(ServerData.ServerResourceMode.ENABLED);
                }
                netManager.sendPacket(new C19PacketResourcePackStatus(val$s1, C19PacketResourcePackStatus.Action.ACCEPTED));
                Futures.addCallback(gameController.getResourcePackRepository().downloadResourcePack(val$s, val$s1), new FutureCallback()
                {
                  public void onSuccess(Object llllllllllllllIlIllIlIIlIIIIIllI)
                  {
                    ;
                    netManager.sendPacket(new C19PacketResourcePackStatus(val$s1, C19PacketResourcePackStatus.Action.SUCCESSFULLY_LOADED));
                  }
                  
                  public void onFailure(Throwable llllllllllllllIlIllIlIIlIIIIIIlI)
                  {
                    ;
                    netManager.sendPacket(new C19PacketResourcePackStatus(val$s1, C19PacketResourcePackStatus.Action.FAILED_DOWNLOAD));
                  }
                });
                "".length();
                if ("  ".length() != "   ".length()) {}
              }
              else
              {
                if (lIIlIIIIllllII(gameController.getCurrentServerData())) {
                  gameController.getCurrentServerData().setResourceMode(ServerData.ServerResourceMode.DISABLED);
                }
                netManager.sendPacket(new C19PacketResourcePackStatus(val$s1, C19PacketResourcePackStatus.Action.DECLINED));
              }
              ServerList.func_147414_b(gameController.getCurrentServerData());
              gameController.displayGuiScreen(null);
            }
            
            private static boolean lIIlIIIIllllII(Object ???)
            {
              Exception lllllllllllllllIIlIlIIlIIllllIlI;
              return ??? != null;
            }
          }, I18n.format(lllIlIlll[lllIlllIl[0]], new Object[lllIlllIl[0]]), I18n.format(lllIlIlll[lllIlllIl[1]], new Object[lllIlllIl[0]]), lllIlllIl[0]));
        }
      };
      "".length();
    }
  }
  
  public NetworkPlayerInfo getPlayerInfo(UUID llllllllllllllIlllllIIIllIIlIlIl)
  {
    ;
    ;
    return (NetworkPlayerInfo)playerInfoMap.get(llllllllllllllIlllllIIIllIIlIlIl);
  }
  
  public void handleEntityTeleport(S18PacketEntityTeleport llllllllllllllIlllllIlIIllIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    PacketThreadUtil.checkThreadAndEnqueue(llllllllllllllIlllllIlIIllIlIIIl, llllllllllllllIlllllIlIIllIIlIlI, gameController);
    Entity llllllllllllllIlllllIlIIllIlIIII = clientWorldController.getEntityByID(llllllllllllllIlllllIlIIllIlIIIl.getEntityId());
    if (lIlIIlllIIIlll(llllllllllllllIlllllIlIIllIlIIII))
    {
      serverPosX = llllllllllllllIlllllIlIIllIlIIIl.getX();
      serverPosY = llllllllllllllIlllllIlIIllIlIIIl.getY();
      serverPosZ = llllllllllllllIlllllIlIIllIlIIIl.getZ();
      double llllllllllllllIlllllIlIIllIIllll = serverPosX / 32.0D;
      double llllllllllllllIlllllIlIIllIIlllI = serverPosY / 32.0D;
      double llllllllllllllIlllllIlIIllIIllIl = serverPosZ / 32.0D;
      float llllllllllllllIlllllIlIIllIIllII = llllllllllllllIlllllIlIIllIlIIIl.getYaw() * llIllIlIIlII[24] / 256.0F;
      float llllllllllllllIlllllIlIIllIIlIll = llllllllllllllIlllllIlIIllIlIIIl.getPitch() * llIllIlIIlII[24] / 256.0F;
      if ((lIlIIlllIIllII(lIlIIlllIIlIll(Math.abs(posX - llllllllllllllIlllllIlIIllIIllll), 0.03125D))) && (lIlIIlllIIllII(lIlIIlllIIlIll(Math.abs(posY - llllllllllllllIlllllIlIIllIIlllI), 0.015625D))) && (lIlIIlllIIllII(lIlIIlllIIlIll(Math.abs(posZ - llllllllllllllIlllllIlIIllIIllIl), 0.03125D))))
      {
        llllllllllllllIlllllIlIIllIlIIII.setPositionAndRotation2(posX, posY, posZ, llllllllllllllIlllllIlIIllIIllII, llllllllllllllIlllllIlIIllIIlIll, llIllIlIIlII[25], llIllIlIIlII[17]);
        "".length();
        if (-"   ".length() < 0) {}
      }
      else
      {
        llllllllllllllIlllllIlIIllIlIIII.setPositionAndRotation2(llllllllllllllIlllllIlIIllIIllll, llllllllllllllIlllllIlIIllIIlllI, llllllllllllllIlllllIlIIllIIllIl, llllllllllllllIlllllIlIIllIIllII, llllllllllllllIlllllIlIIllIIlIll, llIllIlIIlII[25], llIllIlIIlII[17]);
      }
      onGround = llllllllllllllIlllllIlIIllIlIIIl.getOnGround();
    }
  }
}

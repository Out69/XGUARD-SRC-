package net.minecraft.client.network;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ThreadLanServerPing;
import org.apache.logging.log4j.Logger;

public class LanServerDetector
{
  private static void lIlllIllIlIIII()
  {
    llllIllIIllI = new int[1];
    llllIllIIllI[0] = ((0xC ^ 0x5F ^ 0x64 ^ 0x26) & (40 + '¨' - 189 + 152 ^ '²' + '' - 174 + 28 ^ -" ".length()));
  }
  
  static
  {
    lIlllIllIlIIII();
    field_148551_a = new AtomicInteger(llllIllIIllI[0]);
  }
  
  public LanServerDetector() {}
  
  public static class ThreadLanServerFind
    extends Thread
  {
    static
    {
      lIIIlIlIlIIIII();
      lIIIlIlIIlllll();
    }
    
    private static String lIIIlIlIIlllII(String lllllllllllllllIIllIlIlIIlIllIll, String lllllllllllllllIIllIlIlIIlIlllII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIllIlIlIIllIIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIlIlIIlIlllII.getBytes(StandardCharsets.UTF_8)), lIllIIllIllI[8]), "DES");
        Cipher lllllllllllllllIIllIlIlIIlIlllll = Cipher.getInstance("DES");
        lllllllllllllllIIllIlIlIIlIlllll.init(lIllIIllIllI[5], lllllllllllllllIIllIlIlIIllIIIII);
        return new String(lllllllllllllllIIllIlIlIIlIlllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIlIlIIlIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIllIlIlIIlIllllI)
      {
        lllllllllllllllIIllIlIlIIlIllllI.printStackTrace();
      }
      return null;
    }
    
    private static void lIIIlIlIlIIIII()
    {
      lIllIIllIllI = new int[9];
      lIllIIllIllI[0] = ((0xCF ^ 0x8A ^ 0xFD ^ 0xB6) & (6 + 52 - -91 + 11 ^ '¤' + 9 - 129 + 130 ^ -" ".length()));
      lIllIIllIllI[1] = " ".length();
      lIllIIllIllI[2] = (-(0xFA63 & 0x25BF) & 0xFDFF & 0x337F);
      lIllIIllIllI[3] = (0xF3DA & 0x1FAD);
      lIllIIllIllI[4] = (-(0x995E & 0x6EFB) & 0xAD5B & 0x5EFD);
      lIllIIllIllI[5] = "  ".length();
      lIllIIllIllI[6] = "   ".length();
      lIllIIllIllI[7] = (0x6D ^ 0x69);
      lIllIIllIllI[8] = (0x4D ^ 0x51 ^ 0x33 ^ 0x27);
    }
    
    public void run()
    {
      ;
      ;
      ;
      ;
      byte[] lllllllllllllllIIllIlIlIIllIllIl = new byte[lIllIIllIllI[4]];
      "".length();
      if ((0x4 ^ 0x0) <= 0) {
        return;
      }
      label97:
      while (!lIIIlIlIlIIIIl(lllllllllllllllIIllIlIlIIllIlllI.isInterrupted()))
      {
        DatagramPacket lllllllllllllllIIllIlIlIIllIllII = new DatagramPacket(lllllllllllllllIIllIlIlIIllIllIl, lllllllllllllllIIllIlIlIIllIllIl.length);
        try
        {
          socket.receive(lllllllllllllllIIllIlIlIIllIllII);
          "".length();
          if (null == null) {
            break label97;
          }
          return;
        }
        catch (SocketTimeoutException lllllllllllllllIIllIlIlIIllIlIll)
        {
          "".length();
          if ("  ".length() >= 0) {
            continue;
          }
          return;
        }
        catch (IOException lllllllllllllllIIllIlIlIIllIlIlI)
        {
          LanServerDetector.logger.error(lIllIIllIlIl[lIllIIllIllI[5]], lllllllllllllllIIllIlIlIIllIlIlI);
          "".length();
          if (null == null) {
            break;
          }
        }
        return;
        String lllllllllllllllIIllIlIlIIllIlIIl = new String(lllllllllllllllIIllIlIlIIllIllII.getData(), lllllllllllllllIIllIlIlIIllIllII.getOffset(), lllllllllllllllIIllIlIlIIllIllII.getLength());
        LanServerDetector.logger.debug(String.valueOf(new StringBuilder().append(lllllllllllllllIIllIlIlIIllIllII.getAddress()).append(lIllIIllIlIl[lIllIIllIllI[6]]).append(lllllllllllllllIIllIlIlIIllIlIIl)));
        localServerList.func_77551_a(lllllllllllllllIIllIlIlIIllIlIIl, lllllllllllllllIIllIlIlIIllIllII.getAddress());
      }
      try
      {
        socket.leaveGroup(broadcastAddress);
        "".length();
        if ("   ".length() > (0xC5 ^ 0xA8 ^ 0x20 ^ 0x49)) {
          return;
        }
      }
      catch (IOException localIOException1)
      {
        socket.close();
      }
    }
    
    private static boolean lIIIlIlIlIIIlI(int ???, int arg1)
    {
      int i;
      short lllllllllllllllIIllIlIlIIIlIllll;
      return ??? < i;
    }
    
    private static void lIIIlIlIIlllll()
    {
      lIllIIllIlIl = new String[lIllIIllIllI[7]];
      lIllIIllIlIl[lIllIIllIllI[0]] = lIIIlIlIIlllII("C8jp7AjjRgJgRcdaKkZU0RYEq7ZoNs2N", "AMjbl");
      lIllIIllIlIl[lIllIIllIllI[1]] = lIIIlIlIIlllIl("K/HHt4koDuLUk9Vwr5UBWg==", "XPoXj");
      lIllIIllIlIl[lIllIIllIllI[5]] = lIIIlIlIIllllI("Fz8bKys6dxpnPz0+CWc8MSIYIj0=", "TPnGO");
      lIllIIllIlIl[lIllIIllIllI[6]] = lIIIlIlIIlllIl("l5An32OaDEQ=", "sAsOQ");
    }
    
    private static String lIIIlIlIIllllI(String lllllllllllllllIIllIlIlIIlIIIIII, String lllllllllllllllIIllIlIlIIIllllll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIIllIlIlIIlIIIIII = new String(Base64.getDecoder().decode(lllllllllllllllIIllIlIlIIlIIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIIllIlIlIIIlllllI = new StringBuilder();
      char[] lllllllllllllllIIllIlIlIIIllllIl = lllllllllllllllIIllIlIlIIIllllll.toCharArray();
      int lllllllllllllllIIllIlIlIIIllllII = lIllIIllIllI[0];
      float lllllllllllllllIIllIlIlIIIllIllI = lllllllllllllllIIllIlIlIIlIIIIII.toCharArray();
      String lllllllllllllllIIllIlIlIIIllIlIl = lllllllllllllllIIllIlIlIIIllIllI.length;
      double lllllllllllllllIIllIlIlIIIllIlII = lIllIIllIllI[0];
      while (lIIIlIlIlIIIlI(lllllllllllllllIIllIlIlIIIllIlII, lllllllllllllllIIllIlIlIIIllIlIl))
      {
        char lllllllllllllllIIllIlIlIIlIIIIIl = lllllllllllllllIIllIlIlIIIllIllI[lllllllllllllllIIllIlIlIIIllIlII];
        "".length();
        "".length();
        if ((0x57 ^ 0x17 ^ 0xCC ^ 0x88) < (36 + 105 - 115 + 117 ^ 11 + 34 - -9 + 85)) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIIllIlIlIIIlllllI);
    }
    
    private static String lIIIlIlIIlllIl(String lllllllllllllllIIllIlIlIIlIlIIII, String lllllllllllllllIIllIlIlIIlIIllll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIllIlIlIIlIlIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIlIlIIlIIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIIllIlIlIIlIlIIlI = Cipher.getInstance("Blowfish");
        lllllllllllllllIIllIlIlIIlIlIIlI.init(lIllIIllIllI[5], lllllllllllllllIIllIlIlIIlIlIIll);
        return new String(lllllllllllllllIIllIlIlIIlIlIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIlIlIIlIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIllIlIlIIlIlIIIl)
      {
        lllllllllllllllIIllIlIlIIlIlIIIl.printStackTrace();
      }
      return null;
    }
    
    public ThreadLanServerFind(LanServerDetector.LanServerList lllllllllllllllIIllIlIlIIlllIlIl)
      throws IOException
    {
      lllllllllllllllIIllIlIlIIlllIlII.<init>(String.valueOf(new StringBuilder(lIllIIllIlIl[lIllIIllIllI[0]]).append(LanServerDetector.field_148551_a.incrementAndGet())));
      localServerList = lllllllllllllllIIllIlIlIIlllIlIl;
      lllllllllllllllIIllIlIlIIlllIlII.setDaemon(lIllIIllIllI[1]);
      socket = new MulticastSocket(lIllIIllIllI[2]);
      broadcastAddress = InetAddress.getByName(lIllIIllIlIl[lIllIIllIllI[1]]);
      socket.setSoTimeout(lIllIIllIllI[3]);
      socket.joinGroup(broadcastAddress);
    }
    
    private static boolean lIIIlIlIlIIIIl(int ???)
    {
      int lllllllllllllllIIllIlIlIIIlIllIl;
      return ??? != 0;
    }
  }
  
  public static class LanServer
  {
    public String getServerIpPort()
    {
      ;
      return lanServerIpPort;
    }
    
    public void updateLastSeen()
    {
      ;
      timeLastSeen = Minecraft.getSystemTime();
    }
    
    public String getServerMotd()
    {
      ;
      return lanServerMotd;
    }
    
    public LanServer(String lllllllllllllllIlllIllIIIIlIlIll, String lllllllllllllllIlllIllIIIIlIIlll)
    {
      lanServerMotd = lllllllllllllllIlllIllIIIIlIlIII;
      lanServerIpPort = lllllllllllllllIlllIllIIIIlIIlll;
      timeLastSeen = Minecraft.getSystemTime();
    }
  }
  
  public static class LanServerList
  {
    private static String lIllIIlIlIIIII(String llllllllllllllIlllIIIlIIlIllllll, String llllllllllllllIlllIIIlIIlIlllllI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlllIIIlIIllIIIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllIIIlIIlIlllllI.getBytes(StandardCharsets.UTF_8)), lllIlIIlIlll[2]), "DES");
        Cipher llllllllllllllIlllIIIlIIllIIIIIl = Cipher.getInstance("DES");
        llllllllllllllIlllIIIlIIllIIIIIl.init(lllIlIIlIlll[3], llllllllllllllIlllIIIlIIllIIIIlI);
        return new String(llllllllllllllIlllIIIlIIllIIIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlllIIIlIIlIllllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlllIIIlIIllIIIIII)
      {
        llllllllllllllIlllIIIlIIllIIIIII.printStackTrace();
      }
      return null;
    }
    
    private static void lIllIIlIlIIIIl()
    {
      lllIlIIlIllI = new String[lllIlIIlIlll[1]];
      lllIlIIlIllI[lllIlIIlIlll[0]] = lIllIIlIlIIIII("IKEcTEtXCZ0=", "iioND");
    }
    
    static
    {
      lIllIIlIlIIIlI();
      lIllIIlIlIIIIl();
    }
    
    public LanServerList() {}
    
    private static boolean lIllIIlIlIIlII(int ???)
    {
      byte llllllllllllllIlllIIIlIIlIllIllI;
      return ??? != 0;
    }
    
    public synchronized List<LanServerDetector.LanServer> getLanServers()
    {
      ;
      return Collections.unmodifiableList(listOfLanServers);
    }
    
    public synchronized void func_77551_a(String llllllllllllllIlllIIIlIIllIIllIl, InetAddress llllllllllllllIlllIIIlIIllIlIIll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      String llllllllllllllIlllIIIlIIllIlIIlI = ThreadLanServerPing.getMotdFromPingResponse(llllllllllllllIlllIIIlIIllIIllIl);
      String llllllllllllllIlllIIIlIIllIlIIIl = ThreadLanServerPing.getAdFromPingResponse(llllllllllllllIlllIIIlIIllIlIlII);
      if (lIllIIlIlIIIll(llllllllllllllIlllIIIlIIllIlIIIl))
      {
        llllllllllllllIlllIIIlIIllIlIIIl = String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlllIIIlIIllIlIIll.getHostAddress())).append(lllIlIIlIllI[lllIlIIlIlll[0]]).append(llllllllllllllIlllIIIlIIllIlIIIl));
        boolean llllllllllllllIlllIIIlIIllIlIIII = lllIlIIlIlll[0];
        llllllllllllllIlllIIIlIIllIIIlll = listOfLanServers.iterator();
        "".length();
        if (null != null) {
          return;
        }
        while (!lIllIIlIlIIlIl(llllllllllllllIlllIIIlIIllIIIlll.hasNext()))
        {
          LanServerDetector.LanServer llllllllllllllIlllIIIlIIllIIllll = (LanServerDetector.LanServer)llllllllllllllIlllIIIlIIllIIIlll.next();
          if (lIllIIlIlIIlII(llllllllllllllIlllIIIlIIllIIllll.getServerIpPort().equals(llllllllllllllIlllIIIlIIllIlIIIl)))
          {
            llllllllllllllIlllIIIlIIllIIllll.updateLastSeen();
            llllllllllllllIlllIIIlIIllIlIIII = lllIlIIlIlll[1];
            "".length();
            if ("  ".length() == "  ".length()) {
              break;
            }
            return;
          }
        }
        if (lIllIIlIlIIlIl(llllllllllllllIlllIIIlIIllIlIIII))
        {
          new LanServerDetector.LanServer(llllllllllllllIlllIIIlIIllIlIIlI, llllllllllllllIlllIIIlIIllIlIIIl);
          "".length();
          wasUpdated = lllIlIIlIlll[1];
        }
      }
    }
    
    private static void lIllIIlIlIIIlI()
    {
      lllIlIIlIlll = new int[4];
      lllIlIIlIlll[0] = ((0x96 ^ 0xC1 ^ 0xE6 ^ 0xAC) & (47 + '' - 171 + 191 ^ 36 + '' - 16 + 23 ^ -" ".length()));
      lllIlIIlIlll[1] = " ".length();
      lllIlIIlIlll[2] = (0x6 ^ 0xE);
      lllIlIIlIlll[3] = "  ".length();
    }
    
    public synchronized void setWasNotUpdated()
    {
      ;
      wasUpdated = lllIlIIlIlll[0];
    }
    
    private static boolean lIllIIlIlIIIll(Object ???)
    {
      double llllllllllllllIlllIIIlIIlIlllIII;
      return ??? != null;
    }
    
    private static boolean lIllIIlIlIIlIl(int ???)
    {
      int llllllllllllllIlllIIIlIIlIllIlII;
      return ??? == 0;
    }
    
    public synchronized boolean getWasUpdated()
    {
      ;
      return wasUpdated;
    }
  }
}

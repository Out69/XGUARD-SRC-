package net.minecraft.client.renderer;

import net.minecraft.util.BlockPos;

public class DestroyBlockProgress
{
  private static void lllIIIlIIlIIII()
  {
    lIIlIlIIlIIIl = new int[1];
    lIIlIlIIlIIIl[0] = (0x9F ^ 0x95);
  }
  
  public void setPartialBlockDamage(int llllllllllllllIlIIIIIIIIlIIlIlll)
  {
    ;
    ;
    if (lllIIIlIIlIIIl(llllllllllllllIlIIIIIIIIlIIlIlll, lIIlIlIIlIIIl[0])) {
      llllllllllllllIlIIIIIIIIlIIlIlll = lIIlIlIIlIIIl[0];
    }
    partialBlockProgress = llllllllllllllIlIIIIIIIIlIIlIlll;
  }
  
  public int getPartialBlockDamage()
  {
    ;
    return partialBlockProgress;
  }
  
  public void setCloudUpdateTick(int llllllllllllllIlIIIIIIIIlIIIlllI)
  {
    ;
    ;
    createdAtCloudUpdateTick = llllllllllllllIlIIIIIIIIlIIIlllI;
  }
  
  public DestroyBlockProgress(int llllllllllllllIlIIIIIIIIlIlIIlII, BlockPos llllllllllllllIlIIIIIIIIlIlIIIll)
  {
    miningPlayerEntId = llllllllllllllIlIIIIIIIIlIlIIIIl;
    position = llllllllllllllIlIIIIIIIIlIlIIIll;
  }
  
  public int getCreationCloudUpdateTick()
  {
    ;
    return createdAtCloudUpdateTick;
  }
  
  private static boolean lllIIIlIIlIIIl(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIlIIIIIIIIlIIIIlll;
    return ??? > i;
  }
  
  public BlockPos getPosition()
  {
    ;
    return position;
  }
  
  static {}
}

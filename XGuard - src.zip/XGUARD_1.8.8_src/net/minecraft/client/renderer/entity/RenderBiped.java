package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.layers.LayerCustomHead;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.entity.EntityLiving;
import net.minecraft.util.ResourceLocation;

public class RenderBiped<T extends EntityLiving>
  extends RenderLiving<T>
{
  public RenderBiped(RenderManager llllllllllllllllIllIIIIllllllIII, ModelBiped llllllllllllllllIllIIIIllllllIll, float llllllllllllllllIllIIIIllllllIlI)
  {
    llllllllllllllllIllIIIIllllllIIl.<init>(llllllllllllllllIllIIIIllllllIII, llllllllllllllllIllIIIIllllllIll, llllllllllllllllIllIIIIllllllIlI, 1.0F);
    new LayerHeldItem(llllllllllllllllIllIIIIllllllIIl);
    "".length();
  }
  
  protected ResourceLocation getEntityTexture(T llllllllllllllllIllIIIIllllIIlIl)
  {
    return DEFAULT_RES_LOC;
  }
  
  static
  {
    lIIlIllllIIll();
    lIIlIllllIIlI();
  }
  
  private static boolean lIIlIllllIlII(int ???, int arg1)
  {
    int i;
    short llllllllllllllllIllIIIIlllIIIlII;
    return ??? < i;
  }
  
  private static String lIIlIllllIIIl(String llllllllllllllllIllIIIIlllIlIIII, String llllllllllllllllIllIIIIlllIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIllIIIIlllIlIIII = new String(Base64.getDecoder().decode(llllllllllllllllIllIIIIlllIlIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIllIIIIlllIlIIll = new StringBuilder();
    char[] llllllllllllllllIllIIIIlllIlIIlI = llllllllllllllllIllIIIIlllIIllll.toCharArray();
    int llllllllllllllllIllIIIIlllIlIIIl = llIIIlIlllI[0];
    short llllllllllllllllIllIIIIlllIIlIll = llllllllllllllllIllIIIIlllIlIIII.toCharArray();
    short llllllllllllllllIllIIIIlllIIlIlI = llllllllllllllllIllIIIIlllIIlIll.length;
    int llllllllllllllllIllIIIIlllIIlIIl = llIIIlIlllI[0];
    while (lIIlIllllIlII(llllllllllllllllIllIIIIlllIIlIIl, llllllllllllllllIllIIIIlllIIlIlI))
    {
      char llllllllllllllllIllIIIIlllIlIllI = llllllllllllllllIllIIIIlllIIlIll[llllllllllllllllIllIIIIlllIIlIIl];
      "".length();
      "".length();
      if (" ".length() != " ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIllIIIIlllIlIIll);
  }
  
  public RenderBiped(RenderManager llllllllllllllllIllIIIIllllIlIlI, ModelBiped llllllllllllllllIllIIIIllllIlIIl, float llllllllllllllllIllIIIIllllIllIl, float llllllllllllllllIllIIIIllllIllII)
  {
    llllllllllllllllIllIIIIllllIlIll.<init>(llllllllllllllllIllIIIIllllIlIlI, llllllllllllllllIllIIIIllllIlllI, llllllllllllllllIllIIIIllllIllIl);
    modelBipedMain = llllllllllllllllIllIIIIllllIlllI;
    field_77070_b = llllllllllllllllIllIIIIllllIllII;
    new LayerCustomHead(bipedHead);
    "".length();
  }
  
  public void transformHeldFull3DItemLayer()
  {
    GlStateManager.translate(0.0F, 0.1875F, 0.0F);
  }
  
  private static void lIIlIllllIIll()
  {
    llIIIlIlllI = new int[2];
    llIIIlIlllI[0] = ((0xAB ^ 0xB6 ^ 0x38 ^ 0x44) & (0xF4 ^ 0x9A ^ 0xB6 ^ 0xB9 ^ -" ".length()));
    llIIIlIlllI[1] = " ".length();
  }
  
  private static void lIIlIllllIIlI()
  {
    llIIIlIllIl = new String[llIIIlIlllI[1]];
    llIIIlIllIl[llIIIlIlllI[0]] = lIIlIllllIIIl("ITAPBycnMARcNzshHgcreiYDFiQwewcdNQ==", "UUwsR");
  }
}

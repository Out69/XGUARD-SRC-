package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelCreeper;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.layers.LayerCreeperCharge;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class RenderCreeper
  extends RenderLiving<EntityCreeper>
{
  protected void preRenderCallback(EntityCreeper lllllllllllllllIIllllIlIllIIIllI, float lllllllllllllllIIllllIlIlIllllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIIllllIlIllIIIlII = lllllllllllllllIIllllIlIllIIIllI.getCreeperFlashIntensity(lllllllllllllllIIllllIlIlIllllll);
    float lllllllllllllllIIllllIlIllIIIIll = 1.0F + MathHelper.sin(lllllllllllllllIIllllIlIllIIIlII * 100.0F) * lllllllllllllllIIllllIlIllIIIlII * 0.01F;
    lllllllllllllllIIllllIlIllIIIlII = MathHelper.clamp_float(lllllllllllllllIIllllIlIllIIIlII, 0.0F, 1.0F);
    lllllllllllllllIIllllIlIllIIIlII *= lllllllllllllllIIllllIlIllIIIlII;
    lllllllllllllllIIllllIlIllIIIlII *= lllllllllllllllIIllllIlIllIIIlII;
    float lllllllllllllllIIllllIlIllIIIIlI = (1.0F + lllllllllllllllIIllllIlIllIIIlII * 0.4F) * lllllllllllllllIIllllIlIllIIIIll;
    float lllllllllllllllIIllllIlIllIIIIIl = (1.0F + lllllllllllllllIIllllIlIllIIIlII * 0.1F) / lllllllllllllllIIllllIlIllIIIIll;
    GlStateManager.scale(lllllllllllllllIIllllIlIllIIIIlI, lllllllllllllllIIllllIlIllIIIIIl, lllllllllllllllIIllllIlIllIIIIlI);
  }
  
  private static boolean lIIIIllIIIlIlI(int ???)
  {
    int lllllllllllllllIIllllIlIlIIIlIlI;
    return ??? == 0;
  }
  
  private static void lIIIIllIIIlIII()
  {
    lIlIllIllIll = new String[lIlIllIlllII[5]];
    lIlIllIllIll[lIlIllIlllII[0]] = lIIIIllIIIIlll("z7HBCvRbNhaxrLLGgnEdr94dnZmVPQK4FvIs9RKe1DqBPGZrw2al4g==", "eTONL");
  }
  
  protected int getColorMultiplier(EntityCreeper lllllllllllllllIIllllIlIlIllIIII, float lllllllllllllllIIllllIlIlIllIlII, float lllllllllllllllIIllllIlIlIllIIll)
  {
    ;
    ;
    ;
    ;
    float lllllllllllllllIIllllIlIlIllIIlI = lllllllllllllllIIllllIlIlIllIIII.getCreeperFlashIntensity(lllllllllllllllIIllllIlIlIllIIll);
    if (lIIIIllIIIlIlI((int)(lllllllllllllllIIllllIlIlIllIIlI * 10.0F) % lIlIllIlllII[1])) {
      return lIlIllIlllII[0];
    }
    int lllllllllllllllIIllllIlIlIllIIIl = (int)(lllllllllllllllIIllllIlIlIllIIlI * 0.2F * 255.0F);
    lllllllllllllllIIllllIlIlIllIIIl = MathHelper.clamp_int(lllllllllllllllIIllllIlIlIllIIIl, lIlIllIlllII[0], lIlIllIlllII[2]);
    return lllllllllllllllIIllllIlIlIllIIIl << lIlIllIlllII[3] | lIlIllIlllII[4];
  }
  
  static
  {
    lIIIIllIIIlIIl();
    lIIIIllIIIlIII();
  }
  
  private static String lIIIIllIIIIlll(String lllllllllllllllIIllllIlIlIIIllll, String lllllllllllllllIIllllIlIlIIIlllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIllllIlIlIIlIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllllIlIlIIIlllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIllllIlIlIIlIIll = Cipher.getInstance("Blowfish");
      lllllllllllllllIIllllIlIlIIlIIll.init(lIlIllIlllII[1], lllllllllllllllIIllllIlIlIIlIlII);
      return new String(lllllllllllllllIIllllIlIlIIlIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllllIlIlIIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIllllIlIlIIlIIlI)
    {
      lllllllllllllllIIllllIlIlIIlIIlI.printStackTrace();
    }
    return null;
  }
  
  public RenderCreeper(RenderManager lllllllllllllllIIllllIlIllIIlllI)
  {
    lllllllllllllllIIllllIlIllIlIIIl.<init>(lllllllllllllllIIllllIlIllIIlllI, new ModelCreeper(), 0.5F);
    new LayerCreeperCharge(lllllllllllllllIIllllIlIllIlIIIl);
    "".length();
  }
  
  private static void lIIIIllIIIlIIl()
  {
    lIlIllIlllII = new int[6];
    lIlIllIlllII[0] = ((0x63 ^ 0x69) & (0xB2 ^ 0xB8 ^ 0xFFFFFFFF));
    lIlIllIlllII[1] = "  ".length();
    lIlIllIlllII[2] = ('ë' + 38 - 214 + 192 + (0x90 ^ 0x9A) - (121 + 26 - 11 + 108) + ('«' + 40 - 189 + 216));
    lIlIllIlllII[3] = ('' + '' - 180 + 54 ^ 94 + 112 - 78 + 55);
    lIlIllIlllII[4] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIlIllIlllII[5] = " ".length();
  }
  
  protected ResourceLocation getEntityTexture(EntityCreeper lllllllllllllllIIllllIlIlIlIlIll)
  {
    return creeperTextures;
  }
}

package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelEnderMite;
import net.minecraft.entity.monster.EntityEndermite;
import net.minecraft.util.ResourceLocation;

public class RenderEndermite
  extends RenderLiving<EntityEndermite>
{
  public RenderEndermite(RenderManager lIIlllIIIIlIII)
  {
    lIIlllIIIIlIll.<init>(lIIlllIIIIlIII, new ModelEnderMite(), 0.3F);
  }
  
  private static void lIllllIIllI()
  {
    lllIIllIl = new int[3];
    lllIIllIl[0] = ((68 + 101 - 108 + 94 ^ 115 + 78 - 99 + 47) & (0xAA ^ 0x99 ^ 0x3F ^ 0x1A ^ -" ".length()));
    lllIIllIl[1] = " ".length();
    lllIIllIl[2] = "  ".length();
  }
  
  private static void lIllllIIlIl()
  {
    lllIIllII = new String[lllIIllIl[1]];
    lllIIllII[lllIIllIl[0]] = lIllllIIlII("7EDYssCAb4upO4KYI9q1k0hEZEmEK15f8UIiwb3BQl8=", "rbLxT");
  }
  
  private static String lIllllIIlII(String lIIllIllllIlII, String lIIllIllllIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIllIllllIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIIllIllllIIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIIllIllllIllI = Cipher.getInstance("Blowfish");
      lIIllIllllIllI.init(lllIIllIl[2], lIIllIllllIlll);
      return new String(lIIllIllllIllI.doFinal(Base64.getDecoder().decode(lIIllIllllIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIllIllllIlIl)
    {
      lIIllIllllIlIl.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIllllIIllI();
    lIllllIIlIl();
  }
  
  protected ResourceLocation getEntityTexture(EntityEndermite lIIlllIIIIIlII)
  {
    return ENDERMITE_TEXTURES;
  }
  
  protected float getDeathMaxRotation(EntityEndermite lIIlllIIIIIllI)
  {
    return 180.0F;
  }
}

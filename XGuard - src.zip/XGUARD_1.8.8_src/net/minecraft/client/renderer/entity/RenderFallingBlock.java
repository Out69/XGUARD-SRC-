package net.minecraft.client.renderer.entity;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.entity.item.EntityFallingBlock;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

public class RenderFallingBlock
  extends Render<EntityFallingBlock>
{
  public void doRender(EntityFallingBlock lllllllllllllllIllIlIIIlllllIlII, double lllllllllllllllIllIlIIIlllllIIll, double lllllllllllllllIllIlIIIlllllIIIl, double lllllllllllllllIllIlIIIlllllIIII, float lllllllllllllllIllIlIIlIIIIIlIIl, float lllllllllllllllIllIlIIlIIIIIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIIIIlllIl(lllllllllllllllIllIlIIIlllllIlII.getBlock()))
    {
      lllllllllllllllIllIlIIIlllllIlIl.bindTexture(TextureMap.locationBlocksTexture);
      IBlockState lllllllllllllllIllIlIIlIIIIIIlIl = lllllllllllllllIllIlIIIlllllIlII.getBlock();
      Block lllllllllllllllIllIlIIlIIIIIIlII = lllllllllllllllIllIlIIlIIIIIIlIl.getBlock();
      BlockPos lllllllllllllllIllIlIIlIIIIIIIlI = new BlockPos(lllllllllllllllIllIlIIIlllllIlII);
      World lllllllllllllllIllIlIIlIIIIIIIII = lllllllllllllllIllIlIIIlllllIlII.getWorldObj();
      if ((lllIIIIIllllI(lllllllllllllllIllIlIIlIIIIIIlIl, lllllllllllllllIllIlIIlIIIIIIIII.getBlockState(lllllllllllllllIllIlIIlIIIIIIIlI))) && (lllIIIIlIIIII(lllllllllllllllIllIlIIlIIIIIIlII.getRenderType(), lIIlIIIlIlII[0])) && (lllIIIIlIIIIl(lllllllllllllllIllIlIIlIIIIIIlII.getRenderType(), lIIlIIIlIlII[1])))
      {
        GlStateManager.pushMatrix();
        GlStateManager.translate((float)lllllllllllllllIllIlIIIlllllIIll, (float)lllllllllllllllIllIlIIlIIIIIlIll, (float)lllllllllllllllIllIlIIIlllllIIII);
        GlStateManager.disableLighting();
        Tessellator lllllllllllllllIllIlIIIllllllllI = Tessellator.getInstance();
        WorldRenderer lllllllllllllllIllIlIIIlllllllII = lllllllllllllllIllIlIIIllllllllI.getWorldRenderer();
        lllllllllllllllIllIlIIIlllllllII.begin(lIIlIIIlIlII[2], DefaultVertexFormats.BLOCK);
        int lllllllllllllllIllIlIIIllllllIlI = lllllllllllllllIllIlIIlIIIIIIIlI.getX();
        int lllllllllllllllIllIlIIIllllllIIl = lllllllllllllllIllIlIIlIIIIIIIlI.getY();
        int lllllllllllllllIllIlIIIllllllIII = lllllllllllllllIllIlIIlIIIIIIIlI.getZ();
        lllllllllllllllIllIlIIIlllllllII.setTranslation(-lllllllllllllllIllIlIIIllllllIlI - 0.5F, -lllllllllllllllIllIlIIIllllllIIl, -lllllllllllllllIllIlIIIllllllIII - 0.5F);
        BlockRendererDispatcher lllllllllllllllIllIlIIIlllllIlll = Minecraft.getMinecraft().getBlockRendererDispatcher();
        IBakedModel lllllllllllllllIllIlIIIlllllIllI = lllllllllllllllIllIlIIIlllllIlll.getModelFromBlockState(lllllllllllllllIllIlIIlIIIIIIlIl, lllllllllllllllIllIlIIlIIIIIIIII, null);
        "".length();
        lllllllllllllllIllIlIIIlllllllII.setTranslation(0.0D, 0.0D, 0.0D);
        lllllllllllllllIllIlIIIllllllllI.draw();
        GlStateManager.enableLighting();
        GlStateManager.popMatrix();
        lllllllllllllllIllIlIIIlllllIlIl.doRender(lllllllllllllllIllIlIIIlllllIlII, lllllllllllllllIllIlIIIlllllIIll, lllllllllllllllIllIlIIlIIIIIlIll, lllllllllllllllIllIlIIIlllllIIII, lllllllllllllllIllIlIIlIIIIIlIIl, lllllllllllllllIllIlIIlIIIIIIlll);
      }
    }
  }
  
  private static boolean lllIIIIIllllI(Object ???, Object arg1)
  {
    Object localObject;
    String lllllllllllllllIllIlIIIllIllIIlI;
    return ??? != localObject;
  }
  
  protected ResourceLocation getEntityTexture(EntityFallingBlock lllllllllllllllIllIlIIIlllIlIllI)
  {
    return TextureMap.locationBlocksTexture;
  }
  
  private static void lllIIIIIlllII()
  {
    lIIlIIIlIlII = new int[4];
    lIIlIIIlIlII[0] = (-" ".length());
    lIIlIIIlIlII[1] = "   ".length();
    lIIlIIIlIlII[2] = (0xA ^ 0xD);
    lIIlIIIlIlII[3] = ((0xFE ^ 0xBA) & (0xD9 ^ 0x9D ^ 0xFFFFFFFF));
  }
  
  static {}
  
  private static boolean lllIIIIlIIIIl(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIllIlIIIllIllIllI;
    return ??? == i;
  }
  
  private static boolean lllIIIIlIIIII(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllIllIlIIIllIlIllII;
    return ??? != i;
  }
  
  public RenderFallingBlock(RenderManager lllllllllllllllIllIlIIlIIIlllIII)
  {
    lllllllllllllllIllIlIIlIIIlllIIl.<init>(lllllllllllllllIllIlIIlIIIlllIII);
    shadowSize = 0.5F;
  }
  
  private static boolean lllIIIIIlllIl(Object ???)
  {
    boolean lllllllllllllllIllIlIIIllIllIIII;
    return ??? != null;
  }
}

package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.model.ModelBat;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class RenderBat
  extends RenderLiving<EntityBat>
{
  public RenderBat(RenderManager lllllllllllllllllllllIllIIIIlIIl)
  {
    lllllllllllllllllllllIllIIIIlIII.<init>(lllllllllllllllllllllIllIIIIlIIl, new ModelBat(), 0.25F);
  }
  
  private static boolean lIIIllIllllI(int ???, int arg1)
  {
    int i;
    short lllllllllllllllllllllIlIllIIIIll;
    return ??? < i;
  }
  
  protected void rotateCorpse(EntityBat lllllllllllllllllllllIlIlllllIll, float lllllllllllllllllllllIlIlllllIlI, float lllllllllllllllllllllIlIllllIlII, float lllllllllllllllllllllIlIllllIIll)
  {
    ;
    ;
    ;
    ;
    ;
    if (lIIIllIlllIl(lllllllllllllllllllllIlIlllllIll.getIsBatHanging()))
    {
      GlStateManager.translate(0.0F, MathHelper.cos(lllllllllllllllllllllIlIllllIlIl * 0.3F) * 0.1F, 0.0F);
      "".length();
      if (((0x9A ^ 0xA5) & (0x2B ^ 0x14 ^ 0xFFFFFFFF)) == 0) {}
    }
    else
    {
      GlStateManager.translate(0.0F, -0.1F, 0.0F);
    }
    lllllllllllllllllllllIlIllllllII.rotateCorpse(lllllllllllllllllllllIlIlllllIll, lllllllllllllllllllllIlIllllIlIl, lllllllllllllllllllllIlIllllIlII, lllllllllllllllllllllIlIllllIIll);
  }
  
  static
  {
    lIIIllIlllII();
    lIIIllIllIll();
  }
  
  protected ResourceLocation getEntityTexture(EntityBat lllllllllllllllllllllIllIIIIIlIl)
  {
    return batTextures;
  }
  
  private static String lIIIllIllIlI(String lllllllllllllllllllllIlIllIlIlII, String lllllllllllllllllllllIlIllIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllllllllIlIllIlIlII = new String(Base64.getDecoder().decode(lllllllllllllllllllllIlIllIlIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllllllllIlIllIlIIlI = new StringBuilder();
    char[] lllllllllllllllllllllIlIllIlIIIl = lllllllllllllllllllllIlIllIIlllI.toCharArray();
    int lllllllllllllllllllllIlIllIlIIII = lIllIIIIlI[0];
    double lllllllllllllllllllllIlIllIIlIlI = lllllllllllllllllllllIlIllIlIlII.toCharArray();
    long lllllllllllllllllllllIlIllIIlIIl = lllllllllllllllllllllIlIllIIlIlI.length;
    char lllllllllllllllllllllIlIllIIlIII = lIllIIIIlI[0];
    while (lIIIllIllllI(lllllllllllllllllllllIlIllIIlIII, lllllllllllllllllllllIlIllIIlIIl))
    {
      char lllllllllllllllllllllIlIllIlIlIl = lllllllllllllllllllllIlIllIIlIlI[lllllllllllllllllllllIlIllIIlIII];
      "".length();
      "".length();
      if (((106 + '' - 60 + 8 ^ '' + '' - 146 + 11) & (3 + 33 - -87 + 50 ^ 43 + '' - 143 + 108 ^ -" ".length())) != 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllllllllIlIllIlIIlI);
  }
  
  private static boolean lIIIllIlllIl(int ???)
  {
    short lllllllllllllllllllllIlIllIIIIIl;
    return ??? == 0;
  }
  
  private static void lIIIllIlllII()
  {
    lIllIIIIlI = new int[2];
    lIllIIIIlI[0] = ("  ".length() & ("  ".length() ^ -" ".length()));
    lIllIIIIlI[1] = " ".length();
  }
  
  private static void lIIIllIllIll()
  {
    lIllIIIIIl = new String[lIllIIIIlI[1]];
    lIllIIIIIl[lIllIIIIlI[0]] = lIIIllIllIlI("JgA1GyQgAD5ANDwRJBsofQcsG38iCyo=", "ReMoQ");
  }
  
  protected void preRenderCallback(EntityBat lllllllllllllllllllllIllIIIIIIll, float lllllllllllllllllllllIllIIIIIIlI)
  {
    GlStateManager.scale(0.35F, 0.35F, 0.35F);
  }
}

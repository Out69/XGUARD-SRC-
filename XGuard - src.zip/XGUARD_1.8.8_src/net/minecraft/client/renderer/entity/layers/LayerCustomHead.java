package net.minecraft.client.renderer.entity.layers;

import com.mojang.authlib.GameProfile;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.client.renderer.tileentity.TileEntitySkullRenderer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.tileentity.TileEntitySkull;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.StringUtils;

public class LayerCustomHead
  implements LayerRenderer<EntityLivingBase>
{
  private static String lllIIIlIlllIll(String llllllllllllllIIlllllIllIIIIlIII, String llllllllllllllIIlllllIllIIIIIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIlllllIllIIIIllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIlllllIllIIIIIlll.getBytes(StandardCharsets.UTF_8)), lIIlIlIIlllll[5]), "DES");
      Cipher llllllllllllllIIlllllIllIIIIllII = Cipher.getInstance("DES");
      llllllllllllllIIlllllIllIIIIllII.init(lIIlIlIIlllll[4], llllllllllllllIIlllllIllIIIIllIl);
      return new String(llllllllllllllIIlllllIllIIIIllII.doFinal(Base64.getDecoder().decode(llllllllllllllIIlllllIllIIIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIlllllIllIIIIlIll)
    {
      llllllllllllllIIlllllIllIIIIlIll.printStackTrace();
    }
    return null;
  }
  
  private static String lllIIIllIIIIlI(String llllllllllllllIIlllllIllIIlIIlll, String llllllllllllllIIlllllIllIIlIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIlllllIllIIlIIlll = new String(Base64.getDecoder().decode(llllllllllllllIIlllllIllIIlIIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIlllllIllIIlIlIlI = new StringBuilder();
    char[] llllllllllllllIIlllllIllIIlIlIIl = llllllllllllllIIlllllIllIIlIlIll.toCharArray();
    int llllllllllllllIIlllllIllIIlIlIII = lIIlIlIIlllll[1];
    Exception llllllllllllllIIlllllIllIIlIIIlI = llllllllllllllIIlllllIllIIlIIlll.toCharArray();
    String llllllllllllllIIlllllIllIIlIIIIl = llllllllllllllIIlllllIllIIlIIIlI.length;
    double llllllllllllllIIlllllIllIIlIIIII = lIIlIlIIlllll[1];
    while (lllIIIllIIlIIl(llllllllllllllIIlllllIllIIlIIIII, llllllllllllllIIlllllIllIIlIIIIl))
    {
      char llllllllllllllIIlllllIllIIlIllIl = llllllllllllllIIlllllIllIIlIIIlI[llllllllllllllIIlllllIllIIlIIIII];
      "".length();
      "".length();
      if (" ".length() < ((0x1A ^ 0x5E) & (0x1B ^ 0x5F ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIlllllIllIIlIlIlI);
  }
  
  public void doRenderLayer(EntityLivingBase llllllllllllllIIlllllIllIlIIIIII, float llllllllllllllIIlllllIllIlIlIlII, float llllllllllllllIIlllllIllIlIlIIll, float llllllllllllllIIlllllIllIlIlIIlI, float llllllllllllllIIlllllIllIlIlIIIl, float llllllllllllllIIlllllIllIlIlIIII, float llllllllllllllIIlllllIllIlIIllll, float llllllllllllllIIlllllIllIlIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ItemStack llllllllllllllIIlllllIllIlIIllIl = llllllllllllllIIlllllIllIlIIIIII.getCurrentArmor(lIIlIlIIlllll[0]);
    if ((lllIIIllIIIlIl(llllllllllllllIIlllllIllIlIIllIl)) && (lllIIIllIIIlIl(llllllllllllllIIlllllIllIlIIllIl.getItem())))
    {
      Item llllllllllllllIIlllllIllIlIIllII = llllllllllllllIIlllllIllIlIIllIl.getItem();
      Minecraft llllllllllllllIIlllllIllIlIIlIll = Minecraft.getMinecraft();
      GlStateManager.pushMatrix();
      if (lllIIIllIIIllI(llllllllllllllIIlllllIllIlIIIIII.isSneaking())) {
        GlStateManager.translate(0.0F, 0.2F, 0.0F);
      }
      if ((lllIIIllIIIlll(llllllllllllllIIlllllIllIlIIIIII instanceof EntityVillager)) && ((!lllIIIllIIIllI(llllllllllllllIIlllllIllIlIIIIII instanceof EntityZombie)) || (lllIIIllIIIlll(((EntityZombie)llllllllllllllIIlllllIllIlIIIIII).isVillager()))))
      {
        "".length();
        if (null == null) {
          break label116;
        }
      }
      label116:
      boolean llllllllllllllIIlllllIllIlIIlIlI = lIIlIlIIlllll[2];
      if ((lllIIIllIIIlll(llllllllllllllIIlllllIllIlIIlIlI)) && (lllIIIllIIIllI(llllllllllllllIIlllllIllIlIIIIII.isChild())))
      {
        float llllllllllllllIIlllllIllIlIIlIIl = 2.0F;
        float llllllllllllllIIlllllIllIlIIlIII = 1.4F;
        GlStateManager.scale(llllllllllllllIIlllllIllIlIIlIII / llllllllllllllIIlllllIllIlIIlIIl, llllllllllllllIIlllllIllIlIIlIII / llllllllllllllIIlllllIllIlIIlIIl, llllllllllllllIIlllllIllIlIIlIII / llllllllllllllIIlllllIllIlIIlIIl);
        GlStateManager.translate(0.0F, 16.0F * llllllllllllllIIlllllIllIlIIlllI, 0.0F);
      }
      field_177209_a.postRender(0.0625F);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      if (lllIIIllIIIllI(llllllllllllllIIlllllIllIlIIllII instanceof ItemBlock))
      {
        float llllllllllllllIIlllllIllIlIIIlll = 0.625F;
        GlStateManager.translate(0.0F, -0.25F, 0.0F);
        GlStateManager.rotate(180.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.scale(llllllllllllllIIlllllIllIlIIIlll, -llllllllllllllIIlllllIllIlIIIlll, -llllllllllllllIIlllllIllIlIIIlll);
        if (lllIIIllIIIllI(llllllllllllllIIlllllIllIlIIlIlI)) {
          GlStateManager.translate(0.0F, 0.1875F, 0.0F);
        }
        llllllllllllllIIlllllIllIlIIlIll.getItemRenderer().renderItem(llllllllllllllIIlllllIllIlIIIIII, llllllllllllllIIlllllIllIlIIllIl, ItemCameraTransforms.TransformType.HEAD);
        "".length();
        if ("  ".length() >= " ".length()) {}
      }
      else if (lllIIIllIIlIII(llllllllllllllIIlllllIllIlIIllII, Items.skull))
      {
        float llllllllllllllIIlllllIllIlIIIllI = 1.1875F;
        GlStateManager.scale(llllllllllllllIIlllllIllIlIIIllI, -llllllllllllllIIlllllIllIlIIIllI, -llllllllllllllIIlllllIllIlIIIllI);
        if (lllIIIllIIIllI(llllllllllllllIIlllllIllIlIIlIlI)) {
          GlStateManager.translate(0.0F, 0.0625F, 0.0F);
        }
        GameProfile llllllllllllllIIlllllIllIlIIIlIl = null;
        if (lllIIIllIIIllI(llllllllllllllIIlllllIllIlIIllIl.hasTagCompound()))
        {
          NBTTagCompound llllllllllllllIIlllllIllIlIIIlII = llllllllllllllIIlllllIllIlIIllIl.getTagCompound();
          if (lllIIIllIIIllI(llllllllllllllIIlllllIllIlIIIlII.hasKey(lIIlIlIIllllI[lIIlIlIIlllll[1]], lIIlIlIIlllll[3])))
          {
            llllllllllllllIIlllllIllIlIIIlIl = NBTUtil.readGameProfileFromNBT(llllllllllllllIIlllllIllIlIIIlII.getCompoundTag(lIIlIlIIllllI[lIIlIlIIlllll[2]]));
            "".length();
            if ("   ".length() != ((0x61 ^ 0x68) & (0x1E ^ 0x17 ^ 0xFFFFFFFF))) {}
          }
          else if (lllIIIllIIIllI(llllllllllllllIIlllllIllIlIIIlII.hasKey(lIIlIlIIllllI[lIIlIlIIlllll[4]], lIIlIlIIlllll[5])))
          {
            String llllllllllllllIIlllllIllIlIIIIll = llllllllllllllIIlllllIllIlIIIlII.getString(lIIlIlIIllllI[lIIlIlIIlllll[0]]);
            if (lllIIIllIIIlll(StringUtils.isNullOrEmpty(llllllllllllllIIlllllIllIlIIIIll)))
            {
              llllllllllllllIIlllllIllIlIIIlIl = TileEntitySkull.updateGameprofile(new GameProfile(null, llllllllllllllIIlllllIllIlIIIIll));
              llllllllllllllIIlllllIllIlIIIlII.setTag(lIIlIlIIllllI[lIIlIlIIlllll[6]], NBTUtil.writeGameProfile(new NBTTagCompound(), llllllllllllllIIlllllIllIlIIIlIl));
            }
          }
        }
        TileEntitySkullRenderer.instance.renderSkull(-0.5F, 0.0F, -0.5F, EnumFacing.UP, 180.0F, llllllllllllllIIlllllIllIlIIllIl.getMetadata(), llllllllllllllIIlllllIllIlIIIlIl, lIIlIlIIlllll[7]);
      }
      GlStateManager.popMatrix();
    }
  }
  
  private static String lllIIIlIllllll(String llllllllllllllIIlllllIllIIIlIlll, String llllllllllllllIIlllllIllIIIlIllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIlllllIllIIIllIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIIlllllIllIIIlIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIIlllllIllIIIllIIl = Cipher.getInstance("Blowfish");
      llllllllllllllIIlllllIllIIIllIIl.init(lIIlIlIIlllll[4], llllllllllllllIIlllllIllIIIllIlI);
      return new String(llllllllllllllIIlllllIllIIIllIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIIlllllIllIIIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIlllllIllIIIllIII)
    {
      llllllllllllllIIlllllIllIIIllIII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIIllIIIlIl(Object ???)
  {
    float llllllllllllllIIlllllIlIllllllll;
    return ??? != null;
  }
  
  public boolean shouldCombineTextures()
  {
    return lIIlIlIIlllll[2];
  }
  
  public LayerCustomHead(ModelRenderer llllllllllllllIIlllllIllIllIIlII)
  {
    field_177209_a = llllllllllllllIIlllllIllIllIIlII;
  }
  
  private static boolean lllIIIllIIlIIl(int ???, int arg1)
  {
    int i;
    Exception llllllllllllllIIlllllIllIIIIIIIl;
    return ??? < i;
  }
  
  private static boolean lllIIIllIIIllI(int ???)
  {
    float llllllllllllllIIlllllIlIlllllIIl;
    return ??? != 0;
  }
  
  private static void lllIIIllIIIlII()
  {
    lIIlIlIIlllll = new int[9];
    lIIlIlIIlllll[0] = "   ".length();
    lIIlIlIIlllll[1] = ((0x50 ^ 0x3D ^ 0x2B ^ 0x59) & (93 + 56 - 51 + 68 ^ 116 + '' - 186 + 115 ^ -" ".length()));
    lIIlIlIIlllll[2] = " ".length();
    lIIlIlIIlllll[3] = (0xBA ^ 0xAE ^ 0x11 ^ 0xF);
    lIIlIlIIlllll[4] = "  ".length();
    lIIlIlIIlllll[5] = (0x97 ^ 0x9F);
    lIIlIlIIlllll[6] = (110 + 114 - 71 + 30 ^ 34 + 77 - 106 + 174);
    lIIlIlIIlllll[7] = (-" ".length());
    lIIlIlIIlllll[8] = (0x4D ^ 0x48);
  }
  
  private static boolean lllIIIllIIIlll(int ???)
  {
    byte llllllllllllllIIlllllIlIllllIlll;
    return ??? == 0;
  }
  
  private static void lllIIIllIIIIll()
  {
    lIIlIlIIllllI = new String[lIIlIlIIlllll[8]];
    lIIlIlIIllllI[lIIlIlIIlllll[1]] = lllIIIlIlllIll("1Toa43arZCoC8lxZtE5lzw==", "vYdzu");
    lIIlIlIIllllI[lIIlIlIIlllll[2]] = lllIIIlIllllll("EdQidsbH+ew4VIVoQqjGOQ==", "fFdiY");
    lIIlIlIIllllI[lIIlIlIIlllll[4]] = lllIIIlIllllll("WthcQVV9K67UL0Ig/pmy3A==", "abzhf");
    lIIlIlIIllllI[lIIlIlIIlllll[0]] = lllIIIllIIIIlI("HRssFi8BBzcfMQ==", "NpYzC");
    lIIlIlIIllllI[lIIlIlIIlllll[6]] = lllIIIllIIIIlI("KSMnBAs1PzwNFQ==", "zHRhg");
  }
  
  static
  {
    lllIIIllIIIlII();
    lllIIIllIIIIll();
  }
  
  private static boolean lllIIIllIIlIII(Object ???, Object arg1)
  {
    Object localObject;
    boolean llllllllllllllIIlllllIlIlllllIll;
    return ??? == localObject;
  }
}

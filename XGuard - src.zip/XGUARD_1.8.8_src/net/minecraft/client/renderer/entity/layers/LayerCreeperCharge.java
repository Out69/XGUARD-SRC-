package net.minecraft.client.renderer.entity.layers;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelCreeper;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderCreeper;
import net.minecraft.entity.monster.EntityCreeper;

public class LayerCreeperCharge
  implements LayerRenderer<EntityCreeper>
{
  private static String lIlIIlIIlIII(String lllllllllllllllllllIIlIlIIIIIlII, String lllllllllllllllllllIIlIlIIIIIIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllllIIlIlIIIIIlll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIIlIlIIIIIIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllllIIlIlIIIIIllI = Cipher.getInstance("Blowfish");
      lllllllllllllllllllIIlIlIIIIIllI.init(llIIlllIlI[4], lllllllllllllllllllIIlIlIIIIIlll);
      return new String(lllllllllllllllllllIIlIlIIIIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIIlIlIIIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllllIIlIlIIIIIlIl)
    {
      lllllllllllllllllllIIlIlIIIIIlIl.printStackTrace();
    }
    return null;
  }
  
  public boolean shouldCombineTextures()
  {
    return llIIlllIlI[0];
  }
  
  private static void lIlIIlIIllIl()
  {
    llIIlllIlI = new int[5];
    llIIlllIlI[0] = ((0x4B ^ 0x6 ^ 0x22 ^ 0x4E) & (56 + 35 - -33 + 17 ^ 101 + 52 - 9 + 28 ^ -" ".length()));
    llIIlllIlI[1] = " ".length();
    llIIlllIlI[2] = (0x9FAF & 0x7752);
    llIIlllIlI[3] = (-(0xCC4B & 0x73BD) & 0xDFDA & 0x772D);
    llIIlllIlI[4] = "  ".length();
  }
  
  private static boolean lIlIIlIIlllI(int ???)
  {
    Exception lllllllllllllllllllIIlIIllllllIl;
    return ??? != 0;
  }
  
  public LayerCreeperCharge(RenderCreeper lllllllllllllllllllIIlIlIlIIIlIl)
  {
    creeperRenderer = lllllllllllllllllllIIlIlIlIIIlIl;
  }
  
  private static void lIlIIlIIllII()
  {
    llIIlllIIl = new String[llIIlllIlI[1]];
    llIIlllIIl[llIIlllIlI[0]] = lIlIIlIIlIII("35jRyI+3VlNL2pbukrNzFFnNH4dzycfmp3xvs4JTqUnlZ2gMOJ9JaIkxB4FBaxTw", "aqhod");
  }
  
  public void doRenderLayer(EntityCreeper lllllllllllllllllllIIlIlIIllIlIl, float lllllllllllllllllllIIlIlIIllIlII, float lllllllllllllllllllIIlIlIIllIIll, float lllllllllllllllllllIIlIlIIlIIllI, float lllllllllllllllllllIIlIlIIllIIIl, float lllllllllllllllllllIIlIlIIllIIII, float lllllllllllllllllllIIlIlIIlIIIll, float lllllllllllllllllllIIlIlIIlIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIlIIlIIlllI(lllllllllllllllllllIIlIlIIllIlIl.getPowered()))
    {
      boolean lllllllllllllllllllIIlIlIIlIllIl = lllllllllllllllllllIIlIlIIllIlIl.isInvisible();
      if (lIlIIlIIlllI(lllllllllllllllllllIIlIlIIlIllIl))
      {
        "".length();
        if (null == null) {
          break label45;
        }
      }
      label45:
      GlStateManager.depthMask(llIIlllIlI[1]);
      creeperRenderer.bindTexture(LIGHTNING_TEXTURE);
      GlStateManager.matrixMode(llIIlllIlI[2]);
      GlStateManager.loadIdentity();
      float lllllllllllllllllllIIlIlIIlIllII = ticksExisted + lllllllllllllllllllIIlIlIIllIIlI;
      GlStateManager.translate(lllllllllllllllllllIIlIlIIlIllII * 0.01F, lllllllllllllllllllIIlIlIIlIllII * 0.01F, 0.0F);
      GlStateManager.matrixMode(llIIlllIlI[3]);
      GlStateManager.enableBlend();
      float lllllllllllllllllllIIlIlIIlIlIll = 0.5F;
      GlStateManager.color(lllllllllllllllllllIIlIlIIlIlIll, lllllllllllllllllllIIlIlIIlIlIll, lllllllllllllllllllIIlIlIIlIlIll, 1.0F);
      GlStateManager.disableLighting();
      GlStateManager.blendFunc(llIIlllIlI[1], llIIlllIlI[1]);
      creeperModel.setModelAttributes(creeperRenderer.getMainModel());
      creeperModel.render(lllllllllllllllllllIIlIlIIllIlIl, lllllllllllllllllllIIlIlIIllIlII, lllllllllllllllllllIIlIlIIllIIll, lllllllllllllllllllIIlIlIIllIIIl, lllllllllllllllllllIIlIlIIllIIII, lllllllllllllllllllIIlIlIIlIIIll, lllllllllllllllllllIIlIlIIlIlllI);
      GlStateManager.matrixMode(llIIlllIlI[2]);
      GlStateManager.loadIdentity();
      GlStateManager.matrixMode(llIIlllIlI[3]);
      GlStateManager.enableLighting();
      GlStateManager.disableBlend();
      GlStateManager.depthMask(lllllllllllllllllllIIlIlIIlIllIl);
    }
  }
  
  static
  {
    lIlIIlIIllIl();
    lIlIIlIIllII();
  }
}

package net.minecraft.client.renderer.entity.layers;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RenderEnderman;
import net.minecraft.entity.monster.EntityEnderman;

public class LayerEndermanEyes
  implements LayerRenderer<EntityEnderman>
{
  static
  {
    lllIllIlIIlIll();
    lllIllIlIIlIIl();
  }
  
  private static boolean lllIllIlIIllII(int ???)
  {
    double llllllllllllllIIllIIllllllIIlIlI;
    return ??? != 0;
  }
  
  public boolean shouldCombineTextures()
  {
    return lIIllIllllIlI[0];
  }
  
  private static boolean lllIllIlIIllIl(int ???, int arg1)
  {
    int i;
    double llllllllllllllIIllIIllllllIIllII;
    return ??? < i;
  }
  
  private static String lllIllIlIIlIII(String llllllllllllllIIllIIllllllIlllIl, String llllllllllllllIIllIIllllllIlIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIllIIllllllIlllIl = new String(Base64.getDecoder().decode(llllllllllllllIIllIIllllllIlllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIllIIllllllIllIll = new StringBuilder();
    char[] llllllllllllllIIllIIllllllIllIlI = llllllllllllllIIllIIllllllIlIlll.toCharArray();
    int llllllllllllllIIllIIllllllIllIIl = lIIllIllllIlI[0];
    float llllllllllllllIIllIIllllllIlIIll = llllllllllllllIIllIIllllllIlllIl.toCharArray();
    String llllllllllllllIIllIIllllllIlIIlI = llllllllllllllIIllIIllllllIlIIll.length;
    int llllllllllllllIIllIIllllllIlIIIl = lIIllIllllIlI[0];
    while (lllIllIlIIllIl(llllllllllllllIIllIIllllllIlIIIl, llllllllllllllIIllIIllllllIlIIlI))
    {
      char llllllllllllllIIllIIllllllIllllI = llllllllllllllIIllIIllllllIlIIll[llllllllllllllIIllIIllllllIlIIIl];
      "".length();
      "".length();
      if ("  ".length() == ((0x4F ^ 0x0) & (0x4 ^ 0x4B ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIllIIllllllIllIll);
  }
  
  public void doRenderLayer(EntityEnderman llllllllllllllIIllIlIIIIIIIIIlIl, float llllllllllllllIIllIlIIIIIIIIIlII, float llllllllllllllIIllIlIIIIIIIIllll, float llllllllllllllIIllIlIIIIIIIIIIlI, float llllllllllllllIIllIlIIIIIIIIIIIl, float llllllllllllllIIllIlIIIIIIIIllII, float llllllllllllllIIllIIllllllllllll, float llllllllllllllIIllIIlllllllllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    endermanRenderer.bindTexture(field_177203_a);
    GlStateManager.enableBlend();
    GlStateManager.disableAlpha();
    GlStateManager.blendFunc(lIIllIllllIlI[1], lIIllIllllIlI[1]);
    GlStateManager.disableLighting();
    if (lllIllIlIIllII(llllllllllllllIIllIlIIIIIIIIIlIl.isInvisible()))
    {
      "".length();
      if (((0xBC ^ 0x93) & (0x71 ^ 0x5E ^ 0xFFFFFFFF)) == 0) {
        break label77;
      }
    }
    label77:
    GlStateManager.depthMask(lIIllIllllIlI[1]);
    int llllllllllllllIIllIlIIIIIIIIlIIl = lIIllIllllIlI[2];
    int llllllllllllllIIllIlIIIIIIIIlIII = llllllllllllllIIllIlIIIIIIIIlIIl % lIIllIllllIlI[3];
    int llllllllllllllIIllIlIIIIIIIIIlll = llllllllllllllIIllIlIIIIIIIIlIIl / lIIllIllllIlI[3];
    OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, llllllllllllllIIllIlIIIIIIIIlIII / 1.0F, llllllllllllllIIllIlIIIIIIIIIlll / 1.0F);
    GlStateManager.enableLighting();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    endermanRenderer.getMainModel().render(llllllllllllllIIllIlIIIIIIIIIlIl, llllllllllllllIIllIlIIIIIIIIIlII, llllllllllllllIIllIlIIIIIIIIllll, llllllllllllllIIllIlIIIIIIIIIIIl, llllllllllllllIIllIlIIIIIIIIllII, llllllllllllllIIllIIllllllllllll, llllllllllllllIIllIIlllllllllllI);
    endermanRenderer.func_177105_a(llllllllllllllIIllIlIIIIIIIIIlIl, llllllllllllllIIllIlIIIIIIIIlllI);
    GlStateManager.depthMask(lIIllIllllIlI[1]);
    GlStateManager.disableBlend();
    GlStateManager.enableAlpha();
  }
  
  private static void lllIllIlIIlIll()
  {
    lIIllIllllIlI = new int[4];
    lIIllIllllIlI[0] = ((" ".length() ^ 0x7D ^ 0x5B) & (0x36 ^ 0x5C ^ 0x0 ^ 0x4D ^ -" ".length()));
    lIIllIllllIlI[1] = " ".length();
    lIIllIllllIlI[2] = (0xF7FE & 0xF8F1);
    lIIllIllllIlI[3] = (-(0x9FF9 & 0x7A96) & 0xDACF & 0x13FBF);
  }
  
  public LayerEndermanEyes(RenderEnderman llllllllllllllIIllIlIIIIIIlIIIIl)
  {
    endermanRenderer = llllllllllllllIIllIlIIIIIIlIIIIl;
  }
  
  private static void lllIllIlIIlIIl()
  {
    lIIllIllllIIl = new String[lIIllIllllIlI[1]];
    lIIllIllllIIl[lIIllIllllIlI[0]] = lllIllIlIIlIII("HQgTFhgbCBhNCAcZAhYURggFBggbAAoMQgwDDwcfBAwFPQgQCBhMHQcK", "imkbm");
  }
}

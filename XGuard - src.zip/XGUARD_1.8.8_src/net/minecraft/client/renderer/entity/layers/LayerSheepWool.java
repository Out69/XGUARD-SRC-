package net.minecraft.client.renderer.entity.layers;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.model.ModelSheep1;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderSheep;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.item.EnumDyeColor;

public class LayerSheepWool
  implements LayerRenderer<EntitySheep>
{
  private static boolean lIIlIIlllIIIIl(int ???)
  {
    byte lllllllllllllllIIlIIlIIIIIIIlllI;
    return ??? == 0;
  }
  
  private static boolean lIIlIIlllIIIll(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIIlIIlIIIIIIlIIlI;
    return ??? < i;
  }
  
  private static void lIIlIIllIIllII()
  {
    llIIIIIIlllI = new String[llIIIIIlIIll[3]];
    llIIIIIIlllI[llIIIIIlIIll[0]] = lIIlIIllIIlIll("GA0ZHjMeDRJFIwIcCB4/QxsJDyMcRxICIwkYPgwzHkYRBCE=", "lhajF");
    llIIIIIIlllI[llIIIIIlIIll[1]] = lIIlIIllIIlIll("PSgWKg==", "WMtup");
  }
  
  public boolean shouldCombineTextures()
  {
    return llIIIIIlIIll[1];
  }
  
  private static void lIIlIIlllIIIII()
  {
    llIIIIIlIIll = new int[4];
    llIIIIIlIIll[0] = ((0xDB ^ 0xB9) & (0x35 ^ 0x57 ^ 0xFFFFFFFF));
    llIIIIIlIIll[1] = " ".length();
    llIIIIIlIIll[2] = (105 + '' - 224 + 126 ^ 94 + 7 - 44 + 76);
    llIIIIIlIIll[3] = "  ".length();
  }
  
  private static String lIIlIIllIIlIll(String lllllllllllllllIIlIIlIIIIIIllllI, String lllllllllllllllIIlIIlIIIIIIlllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIIlIIIIIIllllI = new String(Base64.getDecoder().decode(lllllllllllllllIIlIIlIIIIIIllllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIlIIlIIIIIlIIIIl = new StringBuilder();
    char[] lllllllllllllllIIlIIlIIIIIlIIIII = lllllllllllllllIIlIIlIIIIIIlllIl.toCharArray();
    int lllllllllllllllIIlIIlIIIIIIlllll = llIIIIIlIIll[0];
    float lllllllllllllllIIlIIlIIIIIIllIIl = lllllllllllllllIIlIIlIIIIIIllllI.toCharArray();
    float lllllllllllllllIIlIIlIIIIIIllIII = lllllllllllllllIIlIIlIIIIIIllIIl.length;
    char lllllllllllllllIIlIIlIIIIIIlIlll = llIIIIIlIIll[0];
    while (lIIlIIlllIIIll(lllllllllllllllIIlIIlIIIIIIlIlll, lllllllllllllllIIlIIlIIIIIIllIII))
    {
      char lllllllllllllllIIlIIlIIIIIlIIlII = lllllllllllllllIIlIIlIIIIIIllIIl[lllllllllllllllIIlIIlIIIIIIlIlll];
      "".length();
      "".length();
      if ((101 + 19 - 20 + 56 ^ 125 + 98 - 153 + 83) <= 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIlIIlIIIIIlIIIIl);
  }
  
  static
  {
    lIIlIIlllIIIII();
    lIIlIIllIIllII();
  }
  
  private static boolean lIIlIIlllIIIlI(int ???)
  {
    String lllllllllllllllIIlIIlIIIIIIlIIII;
    return ??? != 0;
  }
  
  public LayerSheepWool(RenderSheep lllllllllllllllIIlIIlIIIIlllIlIl)
  {
    sheepRenderer = lllllllllllllllIIlIIlIIIIlllIlIl;
  }
  
  public void doRenderLayer(EntitySheep lllllllllllllllIIlIIlIIIIlIlIIII, float lllllllllllllllIIlIIlIIIIlIIllll, float lllllllllllllllIIlIIlIIIIllIIIII, float lllllllllllllllIIlIIlIIIIlIlllll, float lllllllllllllllIIlIIlIIIIlIIllII, float lllllllllllllllIIlIIlIIIIlIIlIll, float lllllllllllllllIIlIIlIIIIlIlllII, float lllllllllllllllIIlIIlIIIIlIllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIIlIIlllIIIIl(lllllllllllllllIIlIIlIIIIlIlIIII.getSheared())) && (lIIlIIlllIIIIl(lllllllllllllllIIlIIlIIIIlIlIIII.isInvisible())))
    {
      sheepRenderer.bindTexture(TEXTURE);
      if ((lIIlIIlllIIIlI(lllllllllllllllIIlIIlIIIIlIlIIII.hasCustomName())) && (lIIlIIlllIIIlI(llIIIIIIlllI[llIIIIIlIIll[1]].equals(lllllllllllllllIIlIIlIIIIlIlIIII.getCustomNameTag()))))
      {
        int lllllllllllllllIIlIIlIIIIlIllIlI = llIIIIIlIIll[2];
        int lllllllllllllllIIlIIlIIIIlIllIIl = ticksExisted / llIIIIIlIIll[2] + lllllllllllllllIIlIIlIIIIlIlIIII.getEntityId();
        int lllllllllllllllIIlIIlIIIIlIllIII = EnumDyeColor.values().length;
        int lllllllllllllllIIlIIlIIIIlIlIlll = lllllllllllllllIIlIIlIIIIlIllIIl % lllllllllllllllIIlIIlIIIIlIllIII;
        int lllllllllllllllIIlIIlIIIIlIlIllI = (lllllllllllllllIIlIIlIIIIlIllIIl + llIIIIIlIIll[1]) % lllllllllllllllIIlIIlIIIIlIllIII;
        float lllllllllllllllIIlIIlIIIIlIlIlIl = (ticksExisted % llIIIIIlIIll[2] + lllllllllllllllIIlIIlIIIIlIIllIl) / 25.0F;
        float[] lllllllllllllllIIlIIlIIIIlIlIlII = EntitySheep.func_175513_a(EnumDyeColor.byMetadata(lllllllllllllllIIlIIlIIIIlIlIlll));
        float[] lllllllllllllllIIlIIlIIIIlIlIIll = EntitySheep.func_175513_a(EnumDyeColor.byMetadata(lllllllllllllllIIlIIlIIIIlIlIllI));
        GlStateManager.color(lllllllllllllllIIlIIlIIIIlIlIlII[llIIIIIlIIll[0]] * (1.0F - lllllllllllllllIIlIIlIIIIlIlIlIl) + lllllllllllllllIIlIIlIIIIlIlIIll[llIIIIIlIIll[0]] * lllllllllllllllIIlIIlIIIIlIlIlIl, lllllllllllllllIIlIIlIIIIlIlIlII[llIIIIIlIIll[1]] * (1.0F - lllllllllllllllIIlIIlIIIIlIlIlIl) + lllllllllllllllIIlIIlIIIIlIlIIll[llIIIIIlIIll[1]] * lllllllllllllllIIlIIlIIIIlIlIlIl, lllllllllllllllIIlIIlIIIIlIlIlII[llIIIIIlIIll[3]] * (1.0F - lllllllllllllllIIlIIlIIIIlIlIlIl) + lllllllllllllllIIlIIlIIIIlIlIIll[llIIIIIlIIll[3]] * lllllllllllllllIIlIIlIIIIlIlIlIl);
        "".length();
        if (((0x82 ^ 0x89) & (0xBF ^ 0xB4 ^ 0xFFFFFFFF)) <= " ".length()) {}
      }
      else
      {
        float[] lllllllllllllllIIlIIlIIIIlIlIIlI = EntitySheep.func_175513_a(lllllllllllllllIIlIIlIIIIlIlIIII.getFleeceColor());
        GlStateManager.color(lllllllllllllllIIlIIlIIIIlIlIIlI[llIIIIIlIIll[0]], lllllllllllllllIIlIIlIIIIlIlIIlI[llIIIIIlIIll[1]], lllllllllllllllIIlIIlIIIIlIlIIlI[llIIIIIlIIll[3]]);
      }
      sheepModel.setModelAttributes(sheepRenderer.getMainModel());
      sheepModel.setLivingAnimations(lllllllllllllllIIlIIlIIIIlIlIIII, lllllllllllllllIIlIIlIIIIlIIllll, lllllllllllllllIIlIIlIIIIllIIIII, lllllllllllllllIIlIIlIIIIlIIllIl);
      sheepModel.render(lllllllllllllllIIlIIlIIIIlIlIIII, lllllllllllllllIIlIIlIIIIlIIllll, lllllllllllllllIIlIIlIIIIllIIIII, lllllllllllllllIIlIIlIIIIlIIllII, lllllllllllllllIIlIIlIIIIlIIlIll, lllllllllllllllIIlIIlIIIIlIlllII, lllllllllllllllIIlIIlIIIIlIllIll);
    }
  }
}

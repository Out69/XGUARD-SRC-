package net.minecraft.client.renderer.entity.layers;

import java.util.List;
import java.util.Random;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.util.MathHelper;

public class LayerArrow
  implements LayerRenderer<EntityLivingBase>
{
  public boolean shouldCombineTextures()
  {
    return lIIlllllIIII[0];
  }
  
  public LayerArrow(RendererLivingEntity lllllllllllllllIlIlIllIIlIlIllll)
  {
    field_177168_a = lllllllllllllllIlIlIllIIlIlIllll;
  }
  
  private static boolean llllIlIlIIIll(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllIlIlIllIIIllIlIIl;
    return ??? >= i;
  }
  
  private static boolean llllIlIlIIIlI(int ???)
  {
    Exception lllllllllllllllIlIlIllIIIllIIlll;
    return ??? > 0;
  }
  
  static {}
  
  public void doRenderLayer(EntityLivingBase lllllllllllllllIlIlIllIIlIIllIII, float lllllllllllllllIlIlIllIIlIIlIlll, float lllllllllllllllIlIlIllIIlIIlIllI, float lllllllllllllllIlIlIllIIlIIlIlIl, float lllllllllllllllIlIlIllIIlIIlIlII, float lllllllllllllllIlIlIllIIlIIlIIll, float lllllllllllllllIlIlIllIIlIIlIIlI, float lllllllllllllllIlIlIllIIlIIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIlIlIllIIlIIlIIII = lllllllllllllllIlIlIllIIlIIllIII.getArrowCountInEntity();
    if (llllIlIlIIIlI(lllllllllllllllIlIlIllIIlIIlIIII))
    {
      Entity lllllllllllllllIlIlIllIIlIIIllll = new EntityArrow(worldObj, posX, posY, posZ);
      Random lllllllllllllllIlIlIllIIlIIIlllI = new Random(lllllllllllllllIlIlIllIIlIIllIII.getEntityId());
      RenderHelper.disableStandardItemLighting();
      int lllllllllllllllIlIlIllIIlIIIllIl = lIIlllllIIII[0];
      "".length();
      if ((0x0 ^ 0x4) <= "   ".length()) {
        return;
      }
      while (!llllIlIlIIIll(lllllllllllllllIlIlIllIIlIIIllIl, lllllllllllllllIlIlIllIIlIIlIIII))
      {
        GlStateManager.pushMatrix();
        ModelRenderer lllllllllllllllIlIlIllIIlIIIllII = field_177168_a.getMainModel().getRandomModelBox(lllllllllllllllIlIlIllIIlIIIlllI);
        ModelBox lllllllllllllllIlIlIllIIlIIIlIll = (ModelBox)cubeList.get(lllllllllllllllIlIlIllIIlIIIlllI.nextInt(cubeList.size()));
        lllllllllllllllIlIlIllIIlIIIllII.postRender(0.0625F);
        float lllllllllllllllIlIlIllIIlIIIlIlI = lllllllllllllllIlIlIllIIlIIIlllI.nextFloat();
        float lllllllllllllllIlIlIllIIlIIIlIIl = lllllllllllllllIlIlIllIIlIIIlllI.nextFloat();
        float lllllllllllllllIlIlIllIIlIIIlIII = lllllllllllllllIlIlIllIIlIIIlllI.nextFloat();
        float lllllllllllllllIlIlIllIIlIIIIlll = (posX1 + (posX2 - posX1) * lllllllllllllllIlIlIllIIlIIIlIlI) / 16.0F;
        float lllllllllllllllIlIlIllIIlIIIIllI = (posY1 + (posY2 - posY1) * lllllllllllllllIlIlIllIIlIIIlIIl) / 16.0F;
        float lllllllllllllllIlIlIllIIlIIIIlIl = (posZ1 + (posZ2 - posZ1) * lllllllllllllllIlIlIllIIlIIIlIII) / 16.0F;
        GlStateManager.translate(lllllllllllllllIlIlIllIIlIIIIlll, lllllllllllllllIlIlIllIIlIIIIllI, lllllllllllllllIlIlIllIIlIIIIlIl);
        lllllllllllllllIlIlIllIIlIIIlIlI = lllllllllllllllIlIlIllIIlIIIlIlI * 2.0F - 1.0F;
        lllllllllllllllIlIlIllIIlIIIlIIl = lllllllllllllllIlIlIllIIlIIIlIIl * 2.0F - 1.0F;
        lllllllllllllllIlIlIllIIlIIIlIII = lllllllllllllllIlIlIllIIlIIIlIII * 2.0F - 1.0F;
        lllllllllllllllIlIlIllIIlIIIlIlI *= -1.0F;
        lllllllllllllllIlIlIllIIlIIIlIIl *= -1.0F;
        lllllllllllllllIlIlIllIIlIIIlIII *= -1.0F;
        float lllllllllllllllIlIlIllIIlIIIIlII = MathHelper.sqrt_float(lllllllllllllllIlIlIllIIlIIIlIlI * lllllllllllllllIlIlIllIIlIIIlIlI + lllllllllllllllIlIlIllIIlIIIlIII * lllllllllllllllIlIlIllIIlIIIlIII);
        prevRotationYaw = (lllllllllllllllIlIlIllIIlIIIllll.rotationYaw = (float)(Math.atan2(lllllllllllllllIlIlIllIIlIIIlIlI, lllllllllllllllIlIlIllIIlIIIlIII) * 180.0D / 3.141592653589793D));
        prevRotationPitch = (lllllllllllllllIlIlIllIIlIIIllll.rotationPitch = (float)(Math.atan2(lllllllllllllllIlIlIllIIlIIIlIIl, lllllllllllllllIlIlIllIIlIIIIlII) * 180.0D / 3.141592653589793D));
        double lllllllllllllllIlIlIllIIlIIIIIll = 0.0D;
        double lllllllllllllllIlIlIllIIlIIIIIlI = 0.0D;
        double lllllllllllllllIlIlIllIIlIIIIIIl = 0.0D;
        "".length();
        GlStateManager.popMatrix();
      }
      RenderHelper.enableStandardItemLighting();
    }
  }
  
  private static void llllIlIlIIIIl()
  {
    lIIlllllIIII = new int[1];
    lIIlllllIIII[0] = ((0xE5 ^ 0xA0) & (0x2B ^ 0x6E ^ 0xFFFFFFFF));
  }
}

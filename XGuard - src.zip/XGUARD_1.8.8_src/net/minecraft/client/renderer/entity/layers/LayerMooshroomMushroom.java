package net.minecraft.client.renderer.entity.layers;

import net.minecraft.block.BlockBush;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelQuadruped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderMooshroom;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.passive.EntityMooshroom;
import net.minecraft.init.Blocks;

public class LayerMooshroomMushroom
  implements LayerRenderer<EntityMooshroom>
{
  static {}
  
  public boolean shouldCombineTextures()
  {
    return lllIllIl[2];
  }
  
  private static void lIlllllIIl()
  {
    lllIllIl = new int[3];
    lllIllIl[0] = (0xFC5C & 0x7A7);
    lllIllIl[1] = (0xAC85 & 0x577F);
    lllIllIl[2] = " ".length();
  }
  
  public void doRenderLayer(EntityMooshroom lIlIIlIllIlIlll, float lIlIIlIlllIIIII, float lIlIIlIllIlllll, float lIlIIlIllIllllI, float lIlIIlIllIlllIl, float lIlIIlIllIlllII, float lIlIIlIllIllIll, float lIlIIlIllIllIlI)
  {
    ;
    ;
    ;
    if ((lIlllllIlI(lIlIIlIllIlIlll.isChild())) && (lIlllllIlI(lIlIIlIllIlIlll.isInvisible())))
    {
      BlockRendererDispatcher lIlIIlIllIllIIl = Minecraft.getMinecraft().getBlockRendererDispatcher();
      mooshroomRenderer.bindTexture(TextureMap.locationBlocksTexture);
      GlStateManager.enableCull();
      GlStateManager.cullFace(lllIllIl[0]);
      GlStateManager.pushMatrix();
      GlStateManager.scale(1.0F, -1.0F, 1.0F);
      GlStateManager.translate(0.2F, 0.35F, 0.5F);
      GlStateManager.rotate(42.0F, 0.0F, 1.0F, 0.0F);
      GlStateManager.pushMatrix();
      GlStateManager.translate(-0.5F, -0.5F, 0.5F);
      lIlIIlIllIllIIl.renderBlockBrightness(Blocks.red_mushroom.getDefaultState(), 1.0F);
      GlStateManager.popMatrix();
      GlStateManager.pushMatrix();
      GlStateManager.translate(0.1F, 0.0F, -0.6F);
      GlStateManager.rotate(42.0F, 0.0F, 1.0F, 0.0F);
      GlStateManager.translate(-0.5F, -0.5F, 0.5F);
      lIlIIlIllIllIIl.renderBlockBrightness(Blocks.red_mushroom.getDefaultState(), 1.0F);
      GlStateManager.popMatrix();
      GlStateManager.popMatrix();
      GlStateManager.pushMatrix();
      mooshroomRenderer.getMainModel()).head.postRender(0.0625F);
      GlStateManager.scale(1.0F, -1.0F, 1.0F);
      GlStateManager.translate(0.0F, 0.7F, -0.2F);
      GlStateManager.rotate(12.0F, 0.0F, 1.0F, 0.0F);
      GlStateManager.translate(-0.5F, -0.5F, 0.5F);
      lIlIIlIllIllIIl.renderBlockBrightness(Blocks.red_mushroom.getDefaultState(), 1.0F);
      GlStateManager.popMatrix();
      GlStateManager.cullFace(lllIllIl[1]);
      GlStateManager.disableCull();
    }
  }
  
  public LayerMooshroomMushroom(RenderMooshroom lIlIIlIlllIlIII)
  {
    mooshroomRenderer = lIlIIlIlllIlIII;
  }
  
  private static boolean lIlllllIlI(int ???)
  {
    float lIlIIlIllIIIIIl;
    return ??? == 0;
  }
}

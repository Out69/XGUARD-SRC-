package net.minecraft.client.renderer.entity.layers;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderWolf;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.item.EnumDyeColor;

public class LayerWolfCollar
  implements LayerRenderer<EntityWolf>
{
  private static boolean llllllIII(int ???)
  {
    float llIIIlIlIIIIlll;
    return ??? != 0;
  }
  
  private static void lllllIlll()
  {
    lIlIIIII = new int[3];
    lIlIIIII[0] = ((0x8 ^ 0xC) & (0xB ^ 0xF ^ 0xFFFFFFFF) & ((0x6D ^ 0x3E) & (0x6C ^ 0x3F ^ 0xFFFFFFFF) ^ 0xFFFFFFFF));
    lIlIIIII[1] = " ".length();
    lIlIIIII[2] = "  ".length();
  }
  
  static
  {
    lllllIlll();
    lllllIlII();
  }
  
  public boolean shouldCombineTextures()
  {
    return lIlIIIII[1];
  }
  
  private static void lllllIlII()
  {
    lIIlllII = new String[lIlIIIII[1]];
    lIIlllII[lIlIIIII[0]] = lllllIIlI("bQV1zWHk6QtaTpvvf86sHWyJjaLv6D3uOcLCi2Vg8aWD/BAQknCQ0Q==", "MlHWy");
  }
  
  public LayerWolfCollar(RenderWolf llIIIlIllIIlIlI)
  {
    wolfRenderer = llIIIlIllIIlIlI;
  }
  
  private static boolean llllllIIl(int ???)
  {
    byte llIIIlIlIIIIlIl;
    return ??? == 0;
  }
  
  public void doRenderLayer(EntityWolf llIIIlIlIllIIIl, float llIIIlIlIlllIll, float llIIIlIlIlIllll, float llIIIlIlIlllIIl, float llIIIlIlIlllIII, float llIIIlIlIlIllIl, float llIIIlIlIlIllII, float llIIIlIlIllIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((llllllIII(llIIIlIlIllIIIl.isTamed())) && (llllllIIl(llIIIlIlIllIIIl.isInvisible())))
    {
      wolfRenderer.bindTexture(WOLF_COLLAR);
      EnumDyeColor llIIIlIlIllIlII = EnumDyeColor.byMetadata(llIIIlIlIllIIIl.getCollarColor().getMetadata());
      float[] llIIIlIlIllIIll = EntitySheep.func_175513_a(llIIIlIlIllIlII);
      GlStateManager.color(llIIIlIlIllIIll[lIlIIIII[0]], llIIIlIlIllIIll[lIlIIIII[1]], llIIIlIlIllIIll[lIlIIIII[2]]);
      wolfRenderer.getMainModel().render(llIIIlIlIllIIIl, llIIIlIlIlllIll, llIIIlIlIlIllll, llIIIlIlIlllIII, llIIIlIlIlIllIl, llIIIlIlIlIllII, llIIIlIlIllIlIl);
    }
  }
  
  private static String lllllIIlI(String llIIIlIlIIIllII, String llIIIlIlIIIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIIIlIlIIlIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llIIIlIlIIIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llIIIlIlIIlIIII = Cipher.getInstance("Blowfish");
      llIIIlIlIIlIIII.init(lIlIIIII[2], llIIIlIlIIlIIIl);
      return new String(llIIIlIlIIlIIII.doFinal(Base64.getDecoder().decode(llIIIlIlIIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIIIlIlIIIllll)
    {
      llIIIlIlIIIllll.printStackTrace();
    }
    return null;
  }
}

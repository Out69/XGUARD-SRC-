package net.minecraft.client.renderer.entity.layers;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelSnowMan;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.client.renderer.entity.RenderSnowMan;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;

public class LayerSnowmanHead
  implements LayerRenderer<EntitySnowman>
{
  public boolean shouldCombineTextures()
  {
    return lIIIllIllllII[0];
  }
  
  static {}
  
  public LayerSnowmanHead(RenderSnowMan llllllllllllllIlIIlIlIllIlIIlIll)
  {
    snowManRenderer = llllllllllllllIlIIlIlIllIlIIlIll;
  }
  
  private static boolean llIllIIIIIIIII(int ???)
  {
    int llllllllllllllIlIIlIlIllIIlIIllI;
    return ??? == 0;
  }
  
  private static void llIlIlllllllll()
  {
    lIIIllIllllII = new int[1];
    lIIIllIllllII[0] = " ".length();
  }
  
  public void doRenderLayer(EntitySnowman llllllllllllllIlIIlIlIllIlIIIllI, float llllllllllllllIlIIlIlIllIlIIIlIl, float llllllllllllllIlIIlIlIllIlIIIlII, float llllllllllllllIlIIlIlIllIlIIIIll, float llllllllllllllIlIIlIlIllIlIIIIlI, float llllllllllllllIlIIlIlIllIlIIIIIl, float llllllllllllllIlIIlIlIllIlIIIIII, float llllllllllllllIlIIlIlIllIIllllll)
  {
    ;
    ;
    ;
    if (llIllIIIIIIIII(llllllllllllllIlIIlIlIllIlIIIllI.isInvisible()))
    {
      GlStateManager.pushMatrix();
      snowManRenderer.getMainModel().head.postRender(0.0625F);
      float llllllllllllllIlIIlIlIllIIlllllI = 0.625F;
      GlStateManager.translate(0.0F, -0.34375F, 0.0F);
      GlStateManager.rotate(180.0F, 0.0F, 1.0F, 0.0F);
      GlStateManager.scale(llllllllllllllIlIIlIlIllIIlllllI, -llllllllllllllIlIIlIlIllIIlllllI, -llllllllllllllIlIIlIlIllIIlllllI);
      Minecraft.getMinecraft().getItemRenderer().renderItem(llllllllllllllIlIIlIlIllIlIIIllI, new ItemStack(Blocks.pumpkin, lIIIllIllllII[0]), ItemCameraTransforms.TransformType.HEAD);
      GlStateManager.popMatrix();
    }
  }
}

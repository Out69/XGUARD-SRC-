package net.minecraft.client.renderer.entity.layers;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RenderSpider;
import net.minecraft.entity.monster.EntitySpider;

public class LayerSpiderEyes
  implements LayerRenderer<EntitySpider>
{
  private static String lIIIllIIIIIII(String llllllllllllllllIlllIlIllIlIIlII, String llllllllllllllllIlllIlIllIlIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIlllIlIllIlIIlII = new String(Base64.getDecoder().decode(llllllllllllllllIlllIlIllIlIIlII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIlllIlIllIlIIIlI = new StringBuilder();
    char[] llllllllllllllllIlllIlIllIlIIIIl = llllllllllllllllIlllIlIllIlIIIll.toCharArray();
    int llllllllllllllllIlllIlIllIlIIIII = lIllIllIIlI[0];
    byte llllllllllllllllIlllIlIllIIllIlI = llllllllllllllllIlllIlIllIlIIlII.toCharArray();
    double llllllllllllllllIlllIlIllIIllIIl = llllllllllllllllIlllIlIllIIllIlI.length;
    int llllllllllllllllIlllIlIllIIllIII = lIllIllIIlI[0];
    while (lIIIllIIIIlII(llllllllllllllllIlllIlIllIIllIII, llllllllllllllllIlllIlIllIIllIIl))
    {
      char llllllllllllllllIlllIlIllIlIIlIl = llllllllllllllllIlllIlIllIIllIlI[llllllllllllllllIlllIlIllIIllIII];
      "".length();
      "".length();
      if ((0xC5 ^ 0xC1) < "  ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIlllIlIllIlIIIlI);
  }
  
  public LayerSpiderEyes(RenderSpider llllllllllllllllIlllIlIllllIlIII)
  {
    spiderRenderer = llllllllllllllllIlllIlIllllIlIII;
  }
  
  private static void lIIIllIIIIIlI()
  {
    lIllIllIIlI = new int[4];
    lIllIllIIlI[0] = ((0x95 ^ 0x99) & (0x83 ^ 0x8F ^ 0xFFFFFFFF));
    lIllIllIIlI[1] = " ".length();
    lIllIllIIlI[2] = (0xF1F8 & 0xFEF7);
    lIllIllIIlI[3] = (-(0xAFF9 & 0x73FE) & 0xEFFF & 0x133F7);
  }
  
  private static boolean lIIIllIIIIlII(int ???, int arg1)
  {
    int i;
    char llllllllllllllllIlllIlIllIIlIIll;
    return ??? < i;
  }
  
  public boolean shouldCombineTextures()
  {
    return lIllIllIIlI[0];
  }
  
  private static boolean lIIIllIIIIIll(int ???)
  {
    Exception llllllllllllllllIlllIlIllIIlIIIl;
    return ??? != 0;
  }
  
  static
  {
    lIIIllIIIIIlI();
    lIIIllIIIIIIl();
  }
  
  public void doRenderLayer(EntitySpider llllllllllllllllIlllIlIlllIllIII, float llllllllllllllllIlllIlIlllIIlIll, float llllllllllllllllIlllIlIlllIlIllI, float llllllllllllllllIlllIlIlllIlIlIl, float llllllllllllllllIlllIlIlllIlIlII, float llllllllllllllllIlllIlIlllIIIlll, float llllllllllllllllIlllIlIlllIlIIlI, float llllllllllllllllIlllIlIlllIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    spiderRenderer.bindTexture(SPIDER_EYES);
    GlStateManager.enableBlend();
    GlStateManager.disableAlpha();
    GlStateManager.blendFunc(lIllIllIIlI[1], lIllIllIIlI[1]);
    if (lIIIllIIIIIll(llllllllllllllllIlllIlIlllIllIII.isInvisible()))
    {
      GlStateManager.depthMask(lIllIllIIlI[0]);
      "".length();
      if (" ".length() != (0x2F ^ 0x2B)) {}
    }
    else
    {
      GlStateManager.depthMask(lIllIllIIlI[1]);
    }
    int llllllllllllllllIlllIlIlllIlIIII = lIllIllIIlI[2];
    int llllllllllllllllIlllIlIlllIIllll = llllllllllllllllIlllIlIlllIlIIII % lIllIllIIlI[3];
    int llllllllllllllllIlllIlIlllIIlllI = llllllllllllllllIlllIlIlllIlIIII / lIllIllIIlI[3];
    OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, llllllllllllllllIlllIlIlllIIllll / 1.0F, llllllllllllllllIlllIlIlllIIlllI / 1.0F);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    spiderRenderer.getMainModel().render(llllllllllllllllIlllIlIlllIllIII, llllllllllllllllIlllIlIlllIIlIll, llllllllllllllllIlllIlIlllIlIllI, llllllllllllllllIlllIlIlllIlIlII, llllllllllllllllIlllIlIlllIIIlll, llllllllllllllllIlllIlIlllIlIIlI, llllllllllllllllIlllIlIlllIlIIIl);
    llllllllllllllllIlllIlIlllIlIIII = llllllllllllllllIlllIlIlllIllIII.getBrightnessForRender(llllllllllllllllIlllIlIlllIIlIIl);
    llllllllllllllllIlllIlIlllIIllll = llllllllllllllllIlllIlIlllIlIIII % lIllIllIIlI[3];
    llllllllllllllllIlllIlIlllIIlllI = llllllllllllllllIlllIlIlllIlIIII / lIllIllIIlI[3];
    OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, llllllllllllllllIlllIlIlllIIllll / 1.0F, llllllllllllllllIlllIlIlllIIlllI / 1.0F);
    spiderRenderer.func_177105_a(llllllllllllllllIlllIlIlllIllIII, llllllllllllllllIlllIlIlllIIlIIl);
    GlStateManager.disableBlend();
    GlStateManager.enableAlpha();
  }
  
  private static void lIIIllIIIIIIl()
  {
    lIllIllIIIl = new String[lIllIllIIlI[1]];
    lIllIllIIIl[lIllIllIIlI[0]] = lIIIllIIIIIII("DDw/HTQKPDRGJBYtLh04Vyo3ACUdKxgMOB0qaRkvHw==", "xYGiA");
  }
}

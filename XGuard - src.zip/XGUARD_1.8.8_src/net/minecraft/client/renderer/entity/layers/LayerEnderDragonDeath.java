package net.minecraft.client.renderer.entity.layers;

import java.util.Random;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.boss.EntityDragon;

public class LayerEnderDragonDeath
  implements LayerRenderer<EntityDragon>
{
  public boolean shouldCombineTextures()
  {
    return lIllIIIllIll[3];
  }
  
  public LayerEnderDragonDeath() {}
  
  private static boolean lIIIlIIlIIIlIl(int ???)
  {
    Exception lllllllllllllllIIllIllllIIIlIlIl;
    return ??? >= 0;
  }
  
  private static int lIIIlIIlIIIIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static int lIIIlIIlIIIIll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void doRenderLayer(EntityDragon lllllllllllllllIIllIllllIlIIIIll, float lllllllllllllllIIllIllllIlIIIIlI, float lllllllllllllllIIllIllllIlIIIIIl, float lllllllllllllllIIllIllllIlIIIIII, float lllllllllllllllIIllIllllIIllllll, float lllllllllllllllIIllIllllIIlllllI, float lllllllllllllllIIllIllllIIllllIl, float lllllllllllllllIIllIllllIIllllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIlIIlIIIlII(deathTicks))
    {
      Tessellator lllllllllllllllIIllIllllIIlllIll = Tessellator.getInstance();
      WorldRenderer lllllllllllllllIIllIllllIIlllIlI = lllllllllllllllIIllIllllIIlllIll.getWorldRenderer();
      RenderHelper.disableStandardItemLighting();
      float lllllllllllllllIIllIllllIIlllIIl = (deathTicks + lllllllllllllllIIllIllllIlIIIIII) / 200.0F;
      float lllllllllllllllIIllIllllIIlllIII = 0.0F;
      if (lIIIlIIlIIIlII(lIIIlIIlIIIIlI(lllllllllllllllIIllIllllIIlllIIl, 0.8F))) {
        lllllllllllllllIIllIllllIIlllIII = (lllllllllllllllIIllIllllIIlllIIl - 0.8F) / 0.2F;
      }
      Random lllllllllllllllIIllIllllIIllIlll = new Random(432L);
      GlStateManager.disableTexture2D();
      GlStateManager.shadeModel(lIllIIIllIll[0]);
      GlStateManager.enableBlend();
      GlStateManager.blendFunc(lIllIIIllIll[1], lIllIIIllIll[2]);
      GlStateManager.disableAlpha();
      GlStateManager.enableCull();
      GlStateManager.depthMask(lIllIIIllIll[3]);
      GlStateManager.pushMatrix();
      GlStateManager.translate(0.0F, -1.0F, -2.0F);
      int lllllllllllllllIIllIllllIIllIllI = lIllIIIllIll[3];
      "".length();
      if (null != null) {
        return;
      }
      while (!lIIIlIIlIIIlIl(lIIIlIIlIIIIll(lllllllllllllllIIllIllllIIllIllI, (lllllllllllllllIIllIllllIIlllIIl + lllllllllllllllIIllIllllIIlllIIl * lllllllllllllllIIllIllllIIlllIIl) / 2.0F * 60.0F)))
      {
        GlStateManager.rotate(lllllllllllllllIIllIllllIIllIlll.nextFloat() * 360.0F, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(lllllllllllllllIIllIllllIIllIlll.nextFloat() * 360.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(lllllllllllllllIIllIllllIIllIlll.nextFloat() * 360.0F, 0.0F, 0.0F, 1.0F);
        GlStateManager.rotate(lllllllllllllllIIllIllllIIllIlll.nextFloat() * 360.0F, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(lllllllllllllllIIllIllllIIllIlll.nextFloat() * 360.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(lllllllllllllllIIllIllllIIllIlll.nextFloat() * 360.0F + lllllllllllllllIIllIllllIIlllIIl * 90.0F, 0.0F, 0.0F, 1.0F);
        float lllllllllllllllIIllIllllIIllIlIl = lllllllllllllllIIllIllllIIllIlll.nextFloat() * 20.0F + 5.0F + lllllllllllllllIIllIllllIIlllIII * 10.0F;
        float lllllllllllllllIIllIllllIIllIlII = lllllllllllllllIIllIllllIIllIlll.nextFloat() * 2.0F + 1.0F + lllllllllllllllIIllIllllIIlllIII * 2.0F;
        lllllllllllllllIIllIllllIIlllIlI.begin(lIllIIIllIll[4], DefaultVertexFormats.POSITION_COLOR);
        lllllllllllllllIIllIllllIIlllIlI.pos(0.0D, 0.0D, 0.0D).color(lIllIIIllIll[5], lIllIIIllIll[5], lIllIIIllIll[5], (int)(255.0F * (1.0F - lllllllllllllllIIllIllllIIlllIII))).endVertex();
        lllllllllllllllIIllIllllIIlllIlI.pos(-0.866D * lllllllllllllllIIllIllllIIllIlII, lllllllllllllllIIllIllllIIllIlIl, -0.5F * lllllllllllllllIIllIllllIIllIlII).color(lIllIIIllIll[5], lIllIIIllIll[3], lIllIIIllIll[5], lIllIIIllIll[3]).endVertex();
        lllllllllllllllIIllIllllIIlllIlI.pos(0.866D * lllllllllllllllIIllIllllIIllIlII, lllllllllllllllIIllIllllIIllIlIl, -0.5F * lllllllllllllllIIllIllllIIllIlII).color(lIllIIIllIll[5], lIllIIIllIll[3], lIllIIIllIll[5], lIllIIIllIll[3]).endVertex();
        lllllllllllllllIIllIllllIIlllIlI.pos(0.0D, lllllllllllllllIIllIllllIIllIlIl, 1.0F * lllllllllllllllIIllIllllIIllIlII).color(lIllIIIllIll[5], lIllIIIllIll[3], lIllIIIllIll[5], lIllIIIllIll[3]).endVertex();
        lllllllllllllllIIllIllllIIlllIlI.pos(-0.866D * lllllllllllllllIIllIllllIIllIlII, lllllllllllllllIIllIllllIIllIlIl, -0.5F * lllllllllllllllIIllIllllIIllIlII).color(lIllIIIllIll[5], lIllIIIllIll[3], lIllIIIllIll[5], lIllIIIllIll[3]).endVertex();
        lllllllllllllllIIllIllllIIlllIll.draw();
        lllllllllllllllIIllIllllIIllIllI++;
      }
      GlStateManager.popMatrix();
      GlStateManager.depthMask(lIllIIIllIll[2]);
      GlStateManager.disableCull();
      GlStateManager.disableBlend();
      GlStateManager.shadeModel(lIllIIIllIll[6]);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.enableTexture2D();
      GlStateManager.enableAlpha();
      RenderHelper.enableStandardItemLighting();
    }
  }
  
  static {}
  
  private static boolean lIIIlIIlIIIlII(int ???)
  {
    String lllllllllllllllIIllIllllIIIlIIll;
    return ??? > 0;
  }
  
  private static void lIIIlIIlIIIIIl()
  {
    lIllIIIllIll = new int[7];
    lIllIIIllIll[0] = (-(0xC3EB & 0x7EBF) & 0xDFAF & 0x7FFB);
    lIllIIIllIll[1] = (-(0xDDFF & 0x3AD1) & 0xDBFA & 0x3FD7);
    lIllIIIllIll[2] = " ".length();
    lIllIIIllIll[3] = ((38 + 123 - 36 + 8 ^ '' + '¢' - 236 + 102) & (0x3E ^ 0x3 ^ 0x7 ^ 0xC ^ -" ".length()));
    lIllIIIllIll[4] = (0x9F ^ 0xC6 ^ 0xD9 ^ 0x86);
    lIllIIIllIll[5] = (84 + 31 - 15 + 44 + (0xFD ^ 0x83) - (0x9164 & 0x6F9F) + ('' + 'ç' - 263 + 128));
    lIllIIIllIll[6] = (0xBFA2 & 0x5D5D);
  }
}

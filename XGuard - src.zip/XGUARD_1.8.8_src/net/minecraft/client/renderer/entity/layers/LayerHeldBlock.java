package net.minecraft.client.renderer.entity.layers;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RenderEnderman;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.monster.EntityEnderman;

public class LayerHeldBlock
  implements LayerRenderer<EntityEnderman>
{
  private static void lllIIIlIIIlllI()
  {
    lIIlIlIIIllll = new int[2];
    lIIlIlIIIllll[0] = (0xC0FE & 0x13F01);
    lIIlIlIIIllll[1] = ((0x9E ^ 0xBE) & (0x39 ^ 0x19 ^ 0xFFFFFFFF));
  }
  
  private static boolean lllIIIlIIIllll(Object ???, Object arg1)
  {
    Object localObject;
    char llllllllllllllIlIIIIIIIIlIlIlIIl;
    return ??? != localObject;
  }
  
  public LayerHeldBlock(RenderEnderman llllllllllllllIlIIIIIIIIlllIIIll)
  {
    endermanRenderer = llllllllllllllIlIIIIIIIIlllIIIll;
  }
  
  public boolean shouldCombineTextures()
  {
    return lIIlIlIIIllll[1];
  }
  
  public void doRenderLayer(EntityEnderman llllllllllllllIlIIIIIIIIllIIIlll, float llllllllllllllIlIIIIIIIIllIlIlIl, float llllllllllllllIlIIIIIIIIllIlIlII, float llllllllllllllIlIIIIIIIIllIIIllI, float llllllllllllllIlIIIIIIIIllIlIIlI, float llllllllllllllIlIIIIIIIIllIlIIIl, float llllllllllllllIlIIIIIIIIllIlIIII, float llllllllllllllIlIIIIIIIIllIIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    IBlockState llllllllllllllIlIIIIIIIIllIIlllI = llllllllllllllIlIIIIIIIIllIIIlll.getHeldBlockState();
    if (lllIIIlIIIllll(llllllllllllllIlIIIIIIIIllIIlllI.getBlock().getMaterial(), Material.air))
    {
      BlockRendererDispatcher llllllllllllllIlIIIIIIIIllIIllIl = Minecraft.getMinecraft().getBlockRendererDispatcher();
      GlStateManager.enableRescaleNormal();
      GlStateManager.pushMatrix();
      GlStateManager.translate(0.0F, 0.6875F, -0.75F);
      GlStateManager.rotate(20.0F, 1.0F, 0.0F, 0.0F);
      GlStateManager.rotate(45.0F, 0.0F, 1.0F, 0.0F);
      GlStateManager.translate(0.25F, 0.1875F, 0.25F);
      float llllllllllllllIlIIIIIIIIllIIllII = 0.5F;
      GlStateManager.scale(-llllllllllllllIlIIIIIIIIllIIllII, -llllllllllllllIlIIIIIIIIllIIllII, llllllllllllllIlIIIIIIIIllIIllII);
      int llllllllllllllIlIIIIIIIIllIIlIll = llllllllllllllIlIIIIIIIIllIIIlll.getBrightnessForRender(llllllllllllllIlIIIIIIIIllIIIllI);
      int llllllllllllllIlIIIIIIIIllIIlIlI = llllllllllllllIlIIIIIIIIllIIlIll % lIIlIlIIIllll[0];
      int llllllllllllllIlIIIIIIIIllIIlIIl = llllllllllllllIlIIIIIIIIllIIlIll / lIIlIlIIIllll[0];
      OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, llllllllllllllIlIIIIIIIIllIIlIlI / 1.0F, llllllllllllllIlIIIIIIIIllIIlIIl / 1.0F);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      endermanRenderer.bindTexture(TextureMap.locationBlocksTexture);
      llllllllllllllIlIIIIIIIIllIIllIl.renderBlockBrightness(llllllllllllllIlIIIIIIIIllIIlllI, 1.0F);
      GlStateManager.popMatrix();
      GlStateManager.disableRescaleNormal();
    }
  }
  
  static {}
}

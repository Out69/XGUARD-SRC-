package net.minecraft.client.renderer.entity.layers;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RendererLivingEntity;

public class LayerBipedArmor
  extends LayerArmorBase<ModelBiped>
{
  protected void func_177194_a(ModelBiped llllllllllllllIlllllllIIlIIIIIlI)
  {
    ;
    llllllllllllllIlllllllIIlIIIIIlI.setInvisible(llIllIIIIIlI[1]);
  }
  
  private static void lIlIIlIllIIlII()
  {
    llIllIIIIIlI = new int[2];
    llIllIIIIIlI[0] = " ".length();
    llIllIIIIIlI[1] = ((0x32 ^ 0xF) & (0x30 ^ 0xD ^ 0xFFFFFFFF));
  }
  
  protected void initArmor()
  {
    ;
    field_177189_c = new ModelBiped(0.5F);
    field_177186_d = new ModelBiped(1.0F);
  }
  
  protected void func_177179_a(ModelBiped llllllllllllllIlllllllIIlIIIIlll, int llllllllllllllIlllllllIIlIIIIllI)
  {
    ;
    ;
    ;
    llllllllllllllIlllllllIIlIIIlIII.func_177194_a(llllllllllllllIlllllllIIlIIIlIlI);
    switch (llllllllllllllIlllllllIIlIIIIllI)
    {
    case 1: 
      bipedRightLeg.showModel = llIllIIIIIlI[0];
      bipedLeftLeg.showModel = llIllIIIIIlI[0];
      "".length();
      if ((" ".length() & (" ".length() ^ 0xFFFFFFFF)) < 0) {}
      break;
    case 2: 
      bipedBody.showModel = llIllIIIIIlI[0];
      bipedRightLeg.showModel = llIllIIIIIlI[0];
      bipedLeftLeg.showModel = llIllIIIIIlI[0];
      "".length();
      if (" ".length() > "   ".length()) {}
      break;
    case 3: 
      bipedBody.showModel = llIllIIIIIlI[0];
      bipedRightArm.showModel = llIllIIIIIlI[0];
      bipedLeftArm.showModel = llIllIIIIIlI[0];
      "".length();
      if (" ".length() <= ((0x39 ^ 0x68 ^ 0xD ^ 0x76) & (0x13 ^ 0x44 ^ 0x59 ^ 0x24 ^ -" ".length()))) {}
      break;
    case 4: 
      bipedHead.showModel = llIllIIIIIlI[0];
      bipedHeadwear.showModel = llIllIIIIIlI[0];
    }
  }
  
  public LayerBipedArmor(RendererLivingEntity<?> llllllllllllllIlllllllIIlIIlIIlI)
  {
    llllllllllllllIlllllllIIlIIlIIll.<init>(llllllllllllllIlllllllIIlIIlIIlI);
  }
  
  static {}
}

package net.minecraft.client.renderer.entity.layers;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.util.MathHelper;

public class LayerCape
  implements LayerRenderer
{
  public LayerCape(RenderPlayer lllllllllllllllIIlIlIlIIlllIIIII)
  {
    playerRenderer = lllllllllllllllIIlIlIlIIlllIIIII;
  }
  
  private static boolean lIIlIIIIIllIII(int ???)
  {
    float lllllllllllllllIIlIlIlIIlIIIIllI;
    return ??? != 0;
  }
  
  private static boolean lIIlIIIIIllIIl(int ???)
  {
    float lllllllllllllllIIlIlIlIIlIIIIlII;
    return ??? == 0;
  }
  
  private static boolean lIIlIIIIIlllII(int ???)
  {
    String lllllllllllllllIIlIlIlIIlIIIIIII;
    return ??? > 0;
  }
  
  private static void lIIlIIIIIlIIlI()
  {
    lIlllIlllIlI = new String[lIlllIllllII[1]];
    lIlllIlllIlI[lIlllIllllII[0]] = lIIlIIIIIlIIII("SqckgYPzYdiv7D6mpz2qkw==", "vgtdL");
  }
  
  private static int lIIlIIIIIlIllI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIIlIIIIIllIlI(Object ???)
  {
    boolean lllllllllllllllIIlIlIlIIlIIIlIII;
    return ??? != null;
  }
  
  public void doRenderLayer(EntityLivingBase lllllllllllllllIIlIlIlIIlIIllllI, float lllllllllllllllIIlIlIlIIlIlIIllI, float lllllllllllllllIIlIlIlIIlIlIIlIl, float lllllllllllllllIIlIlIlIIlIIllIll, float lllllllllllllllIIlIlIlIIlIIllIlI, float lllllllllllllllIIlIlIlIIlIlIIIlI, float lllllllllllllllIIlIlIlIIlIlIIIIl, float lllllllllllllllIIlIlIlIIlIlIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIlIlIlIIlIlIlIII.doRenderLayer((AbstractClientPlayer)lllllllllllllllIIlIlIlIIlIIllllI, lllllllllllllllIIlIlIlIIlIlIIllI, lllllllllllllllIIlIlIlIIlIlIIlIl, lllllllllllllllIIlIlIlIIlIlIIlII, lllllllllllllllIIlIlIlIIlIIllIlI, lllllllllllllllIIlIlIlIIlIlIIIlI, lllllllllllllllIIlIlIlIIlIlIIIIl, lllllllllllllllIIlIlIlIIlIlIIIII);
  }
  
  private static void lIIlIIIIIlIlIl()
  {
    lIlllIllllII = new int[4];
    lIlllIllllII[0] = ((0xC4 ^ 0x97) & (0xDB ^ 0x88 ^ 0xFFFFFFFF));
    lIlllIllllII[1] = " ".length();
    lIlllIllllII[2] = (0x32 ^ 0x3A);
    lIlllIllllII[3] = "  ".length();
  }
  
  public boolean shouldCombineTextures()
  {
    return lIlllIllllII[0];
  }
  
  private static String lIIlIIIIIlIIII(String lllllllllllllllIIlIlIlIIlIIIllll, String lllllllllllllllIIlIlIlIIlIIIlllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlIlIlIIlIIlIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlIlIlIIlIIIlllI.getBytes(StandardCharsets.UTF_8)), lIlllIllllII[2]), "DES");
      Cipher lllllllllllllllIIlIlIlIIlIIlIIIl = Cipher.getInstance("DES");
      lllllllllllllllIIlIlIlIIlIIlIIIl.init(lIlllIllllII[3], lllllllllllllllIIlIlIlIIlIIlIIlI);
      return new String(lllllllllllllllIIlIlIlIIlIIlIIIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlIlIlIIlIIIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlIlIlIIlIIlIIII)
    {
      lllllllllllllllIIlIlIlIIlIIlIIII.printStackTrace();
    }
    return null;
  }
  
  public void doRenderLayer(AbstractClientPlayer lllllllllllllllIIlIlIlIIllIlIIIl, float lllllllllllllllIIlIlIlIIllIlIIII, float lllllllllllllllIIlIlIlIIllIIllll, float lllllllllllllllIIlIlIlIIllIIlllI, float lllllllllllllllIIlIlIlIIllIIllIl, float lllllllllllllllIIlIlIlIIllIIllII, float lllllllllllllllIIlIlIlIIllIIlIll, float lllllllllllllllIIlIlIlIIllIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lIIlIIIIIllIII(lllllllllllllllIIlIlIlIIllIlIIIl.hasPlayerInfo())) && (lIIlIIIIIllIIl(lllllllllllllllIIlIlIlIIllIlIIIl.isInvisible())) && (lIIlIIIIIllIII(lllllllllllllllIIlIlIlIIllIlIIIl.isWearing(EnumPlayerModelParts.CAPE))) && (lIIlIIIIIllIlI(lllllllllllllllIIlIlIlIIllIlIIIl.getLocationCape())))
    {
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      playerRenderer.bindTexture(lllllllllllllllIIlIlIlIIllIlIIIl.getLocationCape());
      GlStateManager.pushMatrix();
      GlStateManager.translate(0.0F, 0.0F, 0.125F);
      double lllllllllllllllIIlIlIlIIllIIlIIl = prevChasingPosX + (chasingPosX - prevChasingPosX) * lllllllllllllllIIlIlIlIIllIIlllI - (prevPosX + (posX - prevPosX) * lllllllllllllllIIlIlIlIIllIIlllI);
      double lllllllllllllllIIlIlIlIIllIIlIII = prevChasingPosY + (chasingPosY - prevChasingPosY) * lllllllllllllllIIlIlIlIIllIIlllI - (prevPosY + (posY - prevPosY) * lllllllllllllllIIlIlIlIIllIIlllI);
      double lllllllllllllllIIlIlIlIIllIIIlll = prevChasingPosZ + (chasingPosZ - prevChasingPosZ) * lllllllllllllllIIlIlIlIIllIIlllI - (prevPosZ + (posZ - prevPosZ) * lllllllllllllllIIlIlIlIIllIIlllI);
      float lllllllllllllllIIlIlIlIIllIIIllI = prevRenderYawOffset + (renderYawOffset - prevRenderYawOffset) * lllllllllllllllIIlIlIlIIllIIlllI;
      double lllllllllllllllIIlIlIlIIllIIIlIl = MathHelper.sin(lllllllllllllllIIlIlIlIIllIIIllI * 3.1415927F / 180.0F);
      double lllllllllllllllIIlIlIlIIllIIIlII = -MathHelper.cos(lllllllllllllllIIlIlIlIIllIIIllI * 3.1415927F / 180.0F);
      float lllllllllllllllIIlIlIlIIllIIIIll = (float)lllllllllllllllIIlIlIlIIllIIlIII * 10.0F;
      lllllllllllllllIIlIlIlIIllIIIIll = MathHelper.clamp_float(lllllllllllllllIIlIlIlIIllIIIIll, -6.0F, 32.0F);
      float lllllllllllllllIIlIlIlIIllIIIIlI = (float)(lllllllllllllllIIlIlIlIIllIIlIIl * lllllllllllllllIIlIlIlIIllIIIlIl + lllllllllllllllIIlIlIlIIllIIIlll * lllllllllllllllIIlIlIlIIllIIIlII) * 100.0F;
      float lllllllllllllllIIlIlIlIIllIIIIIl = (float)(lllllllllllllllIIlIlIlIIllIIlIIl * lllllllllllllllIIlIlIlIIllIIIlII - lllllllllllllllIIlIlIlIIllIIIlll * lllllllllllllllIIlIlIlIIllIIIlIl) * 100.0F;
      if (lIIlIIIIIllIll(lIIlIIIIIlIllI(lllllllllllllllIIlIlIlIIllIIIIlI, 0.0F))) {
        lllllllllllllllIIlIlIlIIllIIIIlI = 0.0F;
      }
      if (lIIlIIIIIlllII(lIIlIIIIIlIlll(lllllllllllllllIIlIlIlIIllIIIIlI, 165.0F))) {
        lllllllllllllllIIlIlIlIIllIIIIlI = 165.0F;
      }
      float lllllllllllllllIIlIlIlIIllIIIIII = prevCameraYaw + (cameraYaw - prevCameraYaw) * lllllllllllllllIIlIlIlIIllIIlllI;
      lllllllllllllllIIlIlIlIIllIIIIll += MathHelper.sin((prevDistanceWalkedModified + (distanceWalkedModified - prevDistanceWalkedModified) * lllllllllllllllIIlIlIlIIllIIlllI) * 6.0F) * 32.0F * lllllllllllllllIIlIlIlIIllIIIIII;
      if (lIIlIIIIIllIII(lllllllllllllllIIlIlIlIIllIlIIIl.isSneaking()))
      {
        lllllllllllllllIIlIlIlIIllIIIIll += 25.0F;
        GlStateManager.translate(0.0F, 0.142F, -0.0178F);
      }
      GlStateManager.rotate(6.0F + lllllllllllllllIIlIlIlIIllIIIIlI / 2.0F + lllllllllllllllIIlIlIlIIllIIIIll, 1.0F, 0.0F, 0.0F);
      GlStateManager.rotate(lllllllllllllllIIlIlIlIIllIIIIIl / 2.0F, 0.0F, 0.0F, 1.0F);
      GlStateManager.rotate(-lllllllllllllllIIlIlIlIIllIIIIIl / 2.0F, 0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(180.0F, 0.0F, 1.0F, 0.0F);
      playerRenderer.getMainModel().renderCape(0.0625F);
      GlStateManager.popMatrix();
    }
  }
  
  static
  {
    lIIlIIIIIlIlIl();
    lIIlIIIIIlIIlI();
  }
  
  private static int lIIlIIIIIlIlll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIIlIIIIIllIll(int ???)
  {
    char lllllllllllllllIIlIlIlIIlIIIIIlI;
    return ??? < 0;
  }
}

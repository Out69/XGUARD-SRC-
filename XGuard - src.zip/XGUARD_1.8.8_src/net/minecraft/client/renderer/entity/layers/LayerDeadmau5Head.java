package net.minecraft.client.renderer.entity.layers;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderPlayer;

public class LayerDeadmau5Head
  implements LayerRenderer<AbstractClientPlayer>
{
  private static String llIlllIIIIllI(String lllllllllllllllIllIllllIIIlIlIlI, String lllllllllllllllIllIllllIIIlIIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIllllIIIlIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIllllIIIlIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIllllIIIlIllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIllllIIIlIllII.init(lIIIlllIlllI[1], lllllllllllllllIllIllllIIIlIllIl);
      return new String(lllllllllllllllIllIllllIIIlIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIllllIIIlIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIllllIIIlIlIll)
    {
      lllllllllllllllIllIllllIIIlIlIll.printStackTrace();
    }
    return null;
  }
  
  static
  {
    llIlllIIlIIll();
    llIlllIIIlIlI();
  }
  
  public void doRenderLayer(AbstractClientPlayer lllllllllllllllIllIllllIIlIIlIlI, float lllllllllllllllIllIllllIIlIlIllI, float lllllllllllllllIllIllllIIlIlIlIl, float lllllllllllllllIllIllllIIlIlIlII, float lllllllllllllllIllIllllIIlIlIIll, float lllllllllllllllIllIllllIIlIlIIlI, float lllllllllllllllIllIllllIIlIlIIIl, float lllllllllllllllIllIllllIIlIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if ((llIlllIIlIlll(lllllllllllllllIllIllllIIlIIlIlI.getName().equals(lIIIlllIllIl[lIIIlllIlllI[0]]))) && (llIlllIIlIlll(lllllllllllllllIllIllllIIlIIlIlI.hasSkin())) && (llIlllIIllIIl(lllllllllllllllIllIllllIIlIIlIlI.isInvisible())))
    {
      playerRenderer.bindTexture(lllllllllllllllIllIllllIIlIIlIlI.getLocationSkin());
      int lllllllllllllllIllIllllIIlIIllll = lIIIlllIlllI[0];
      "".length();
      if (-" ".length() != -" ".length()) {
        return;
      }
      while (!llIlllIIlllII(lllllllllllllllIllIllllIIlIIllll, lIIIlllIlllI[1]))
      {
        float lllllllllllllllIllIllllIIlIIlllI = prevRotationYaw + (rotationYaw - prevRotationYaw) * lllllllllllllllIllIllllIIlIlIlII - (prevRenderYawOffset + (renderYawOffset - prevRenderYawOffset) * lllllllllllllllIllIllllIIlIlIlII);
        float lllllllllllllllIllIllllIIlIIllIl = prevRotationPitch + (rotationPitch - prevRotationPitch) * lllllllllllllllIllIllllIIlIlIlII;
        GlStateManager.pushMatrix();
        GlStateManager.rotate(lllllllllllllllIllIllllIIlIIlllI, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(lllllllllllllllIllIllllIIlIIllIl, 1.0F, 0.0F, 0.0F);
        GlStateManager.translate(0.375F * (lllllllllllllllIllIllllIIlIIllll * lIIIlllIlllI[1] - lIIIlllIlllI[2]), 0.0F, 0.0F);
        GlStateManager.translate(0.0F, -0.375F, 0.0F);
        GlStateManager.rotate(-lllllllllllllllIllIllllIIlIIllIl, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(-lllllllllllllllIllIllllIIlIIlllI, 0.0F, 1.0F, 0.0F);
        float lllllllllllllllIllIllllIIlIIllII = 1.3333334F;
        GlStateManager.scale(lllllllllllllllIllIllllIIlIIllII, lllllllllllllllIllIllllIIlIIllII, lllllllllllllllIllIllllIIlIIllII);
        playerRenderer.getMainModel().renderDeadmau5Head(0.0625F);
        GlStateManager.popMatrix();
        lllllllllllllllIllIllllIIlIIllll++;
      }
    }
  }
  
  public boolean shouldCombineTextures()
  {
    return lIIIlllIlllI[2];
  }
  
  private static void llIlllIIIlIlI()
  {
    lIIIlllIllIl = new String[lIIIlllIlllI[2]];
    lIIIlllIllIl[lIIIlllIlllI[0]] = llIlllIIIIllI("aPecL5wUbNQ3gyWmGl1I/g==", "pHRdU");
  }
  
  private static boolean llIlllIIllIIl(int ???)
  {
    long lllllllllllllllIllIllllIIIIlllIl;
    return ??? == 0;
  }
  
  private static boolean llIlllIIlllII(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIllIllllIIIlIIIIl;
    return ??? >= i;
  }
  
  private static void llIlllIIlIIll()
  {
    lIIIlllIlllI = new int[3];
    lIIIlllIlllI[0] = ((0x29 ^ 0x6A) & (0x15 ^ 0x56 ^ 0xFFFFFFFF));
    lIIIlllIlllI[1] = "  ".length();
    lIIIlllIlllI[2] = " ".length();
  }
  
  public LayerDeadmau5Head(RenderPlayer lllllllllllllllIllIllllIIllIIIII)
  {
    playerRenderer = lllllllllllllllIllIllllIIllIIIII;
  }
  
  private static boolean llIlllIIlIlll(int ???)
  {
    short lllllllllllllllIllIllllIIIIlllll;
    return ??? != 0;
  }
}

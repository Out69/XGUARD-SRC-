package net.minecraft.client.renderer.entity.layers;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.model.ModelWitch;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.client.renderer.entity.RenderWitch;
import net.minecraft.entity.monster.EntityWitch;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public class LayerHeldItemWitch
  implements LayerRenderer<EntityWitch>
{
  public LayerHeldItemWitch(RenderWitch llllllllllllllllllIIllIlIlIlIIIl)
  {
    witchRenderer = llllllllllllllllllIIllIlIlIlIIIl;
  }
  
  static {}
  
  public void doRenderLayer(EntityWitch llllllllllllllllllIIllIlIlIIlIIl, float llllllllllllllllllIIllIlIlIIlIII, float llllllllllllllllllIIllIlIlIIIlll, float llllllllllllllllllIIllIlIlIIIllI, float llllllllllllllllllIIllIlIlIIIlIl, float llllllllllllllllllIIllIlIlIIIlII, float llllllllllllllllllIIllIlIlIIIIll, float llllllllllllllllllIIllIlIlIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ItemStack llllllllllllllllllIIllIlIlIIIIIl = llllllllllllllllllIIllIlIlIIlIIl.getHeldItem();
    if (lIlllllIIllI(llllllllllllllllllIIllIlIlIIIIIl))
    {
      GlStateManager.color(1.0F, 1.0F, 1.0F);
      GlStateManager.pushMatrix();
      if (lIlllllIIlll(witchRenderer.getMainModel().isChild))
      {
        GlStateManager.translate(0.0F, 0.625F, 0.0F);
        GlStateManager.rotate(-20.0F, -1.0F, 0.0F, 0.0F);
        float llllllllllllllllllIIllIlIlIIIIII = 0.5F;
        GlStateManager.scale(llllllllllllllllllIIllIlIlIIIIII, llllllllllllllllllIIllIlIlIIIIII, llllllllllllllllllIIllIlIlIIIIII);
      }
      witchRenderer.getMainModel()).villagerNose.postRender(0.0625F);
      GlStateManager.translate(-0.0625F, 0.53125F, 0.21875F);
      Item llllllllllllllllllIIllIlIIllllll = llllllllllllllllllIIllIlIlIIIIIl.getItem();
      Minecraft llllllllllllllllllIIllIlIIlllllI = Minecraft.getMinecraft();
      if ((lIlllllIIlll(llllllllllllllllllIIllIlIIllllll instanceof ItemBlock)) && (lIlllllIIlll(llllllllllllllllllIIllIlIIlllllI.getBlockRendererDispatcher().isRenderTypeChest(Block.getBlockFromItem(llllllllllllllllllIIllIlIIllllll), llllllllllllllllllIIllIlIlIIIIIl.getMetadata()))))
      {
        GlStateManager.translate(0.0F, 0.0625F, -0.25F);
        GlStateManager.rotate(30.0F, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(-5.0F, 0.0F, 1.0F, 0.0F);
        float llllllllllllllllllIIllIlIIllllIl = 0.375F;
        GlStateManager.scale(llllllllllllllllllIIllIlIIllllIl, -llllllllllllllllllIIllIlIIllllIl, llllllllllllllllllIIllIlIIllllIl);
        "".length();
        if (-(0x23 ^ 0x27) <= 0) {}
      }
      else if (lIlllllIlIIl(llllllllllllllllllIIllIlIIllllll, Items.bow))
      {
        GlStateManager.translate(0.0F, 0.125F, -0.125F);
        GlStateManager.rotate(-45.0F, 0.0F, 1.0F, 0.0F);
        float llllllllllllllllllIIllIlIIllllII = 0.625F;
        GlStateManager.scale(llllllllllllllllllIIllIlIIllllII, -llllllllllllllllllIIllIlIIllllII, llllllllllllllllllIIllIlIIllllII);
        GlStateManager.rotate(-100.0F, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(-20.0F, 0.0F, 1.0F, 0.0F);
        "".length();
        if ("  ".length() < "   ".length()) {}
      }
      else if (lIlllllIIlll(llllllllllllllllllIIllIlIIllllll.isFull3D()))
      {
        if (lIlllllIIlll(llllllllllllllllllIIllIlIIllllll.shouldRotateAroundWhenRendering()))
        {
          GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
          GlStateManager.translate(0.0F, -0.0625F, 0.0F);
        }
        witchRenderer.transformHeldFull3DItemLayer();
        GlStateManager.translate(0.0625F, -0.125F, 0.0F);
        float llllllllllllllllllIIllIlIIlllIll = 0.625F;
        GlStateManager.scale(llllllllllllllllllIIllIlIIlllIll, -llllllllllllllllllIIllIlIIlllIll, llllllllllllllllllIIllIlIIlllIll);
        GlStateManager.rotate(0.0F, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(0.0F, 0.0F, 1.0F, 0.0F);
        "".length();
        if (((0xED ^ 0xBC) & (0x4E ^ 0x1F ^ 0xFFFFFFFF)) == 0) {}
      }
      else
      {
        GlStateManager.translate(0.1875F, 0.1875F, 0.0F);
        float llllllllllllllllllIIllIlIIlllIlI = 0.875F;
        GlStateManager.scale(llllllllllllllllllIIllIlIIlllIlI, llllllllllllllllllIIllIlIIlllIlI, llllllllllllllllllIIllIlIIlllIlI);
        GlStateManager.rotate(-20.0F, 0.0F, 0.0F, 1.0F);
        GlStateManager.rotate(-60.0F, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(-30.0F, 0.0F, 0.0F, 1.0F);
      }
      GlStateManager.rotate(-15.0F, 1.0F, 0.0F, 0.0F);
      GlStateManager.rotate(40.0F, 0.0F, 0.0F, 1.0F);
      llllllllllllllllllIIllIlIIlllllI.getItemRenderer().renderItem(llllllllllllllllllIIllIlIlIIlIIl, llllllllllllllllllIIllIlIlIIIIIl, ItemCameraTransforms.TransformType.THIRD_PERSON);
      GlStateManager.popMatrix();
    }
  }
  
  public boolean shouldCombineTextures()
  {
    return llllIIIlll[0];
  }
  
  private static boolean lIlllllIIlll(int ???)
  {
    short llllllllllllllllllIIllIlIIIllIIl;
    return ??? != 0;
  }
  
  private static boolean lIlllllIlIIl(Object ???, Object arg1)
  {
    Object localObject;
    String llllllllllllllllllIIllIlIIIllIll;
    return ??? == localObject;
  }
  
  private static boolean lIlllllIIllI(Object ???)
  {
    byte llllllllllllllllllIIllIlIIIlllll;
    return ??? != null;
  }
  
  private static void lIlllllIIlIl()
  {
    llllIIIlll = new int[1];
    llllIIIlll[0] = ((0x4C ^ 0x15 ^ 0x47 ^ 0x22) & (120 + 66 - 116 + 87 ^ 9 + '' - 73 + 95 ^ -" ".length()));
  }
}

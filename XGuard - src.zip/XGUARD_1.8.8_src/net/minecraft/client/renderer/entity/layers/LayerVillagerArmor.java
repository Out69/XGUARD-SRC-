package net.minecraft.client.renderer.entity.layers;

import net.minecraft.client.model.ModelZombieVillager;
import net.minecraft.client.renderer.entity.RendererLivingEntity;

public class LayerVillagerArmor
  extends LayerBipedArmor
{
  private static void llIlIIIIlIlIll()
  {
    lIIIlIIIlIlII = new int[1];
    lIIIlIIIlIlII[0] = " ".length();
  }
  
  protected void initArmor()
  {
    ;
    field_177189_c = new ModelZombieVillager(0.5F, 0.0F, lIIIlIIIlIlII[0]);
    field_177186_d = new ModelZombieVillager(1.0F, 0.0F, lIIIlIIIlIlII[0]);
  }
  
  static {}
  
  public LayerVillagerArmor(RendererLivingEntity<?> llllllllllllllIlIlIIIlllllIIIIlI)
  {
    llllllllllllllIlIlIIIlllllIIIIll.<init>(llllllllllllllIlIlIIIlllllIIIIlI);
  }
}

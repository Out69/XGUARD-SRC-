package net.minecraft.client.renderer.entity.layers;

import net.minecraft.entity.EntityLivingBase;

public abstract interface LayerRenderer<E extends EntityLivingBase>
{
  public abstract boolean shouldCombineTextures();
  
  public abstract void doRenderLayer(E paramE, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7);
}

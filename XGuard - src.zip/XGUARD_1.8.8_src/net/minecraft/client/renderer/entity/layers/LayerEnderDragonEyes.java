package net.minecraft.client.renderer.entity.layers;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RenderDragon;
import net.minecraft.entity.boss.EntityDragon;

public class LayerEnderDragonEyes
  implements LayerRenderer<EntityDragon>
{
  public void doRenderLayer(EntityDragon lllllllllllllllllIIllllllllIllIl, float lllllllllllllllllIIllllllllIllII, float lllllllllllllllllIIlllllllllIlll, float lllllllllllllllllIIlllllllllIllI, float lllllllllllllllllIIlllllllllIlIl, float lllllllllllllllllIIllllllllIlIII, float lllllllllllllllllIIlllllllllIIll, float lllllllllllllllllIIllllllllIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    dragonRenderer.bindTexture(TEXTURE);
    GlStateManager.enableBlend();
    GlStateManager.disableAlpha();
    GlStateManager.blendFunc(lIIlIlIlIII[1], lIIlIlIlIII[1]);
    GlStateManager.disableLighting();
    GlStateManager.depthFunc(lIIlIlIlIII[2]);
    int lllllllllllllllllIIlllllllllIIIl = lIIlIlIlIII[3];
    int lllllllllllllllllIIlllllllllIIII = lllllllllllllllllIIlllllllllIIIl % lIIlIlIlIII[4];
    int lllllllllllllllllIIllllllllIllll = lllllllllllllllllIIlllllllllIIIl / lIIlIlIlIII[4];
    OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, lllllllllllllllllIIlllllllllIIII / 1.0F, lllllllllllllllllIIllllllllIllll / 1.0F);
    GlStateManager.enableLighting();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    dragonRenderer.getMainModel().render(lllllllllllllllllIIllllllllIllIl, lllllllllllllllllIIllllllllIllII, lllllllllllllllllIIlllllllllIlll, lllllllllllllllllIIlllllllllIlIl, lllllllllllllllllIIllllllllIlIII, lllllllllllllllllIIlllllllllIIll, lllllllllllllllllIIllllllllIIllI);
    dragonRenderer.func_177105_a(lllllllllllllllllIIllllllllIllIl, lllllllllllllllllIIllllllllIlIlI);
    GlStateManager.disableBlend();
    GlStateManager.enableAlpha();
    GlStateManager.depthFunc(lIIlIlIlIII[5]);
  }
  
  private static String lllIlIllIIll(String lllllllllllllllllIIlllllllIIIllI, String lllllllllllllllllIIlllllllIIIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllllIIlllllllIIlIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllIIlllllllIIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllllIIlllllllIIlIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllllIIlllllllIIlIlI.init(lIIlIlIlIII[6], lllllllllllllllllIIlllllllIIlIll);
      return new String(lllllllllllllllllIIlllllllIIlIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllllIIlllllllIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllllIIlllllllIIlIIl)
    {
      lllllllllllllllllIIlllllllIIlIIl.printStackTrace();
    }
    return null;
  }
  
  private static void lllIlIlllIlI()
  {
    lIIlIlIlIII = new int[7];
    lIIlIlIlIII[0] = (('' + 106 - 86 + 10 ^ 114 + 109 - 185 + 127) & (0x37 ^ 0x47 ^ 0xD5 ^ 0x9E ^ -" ".length()));
    lIIlIlIlIII[1] = " ".length();
    lIIlIlIlIII[2] = (-(0xCDF7 & 0x7BFA) & 0xDFF7 & 0x6BFB);
    lIIlIlIlIII[3] = (0xF0F4 & 0xFFFB);
    lIIlIlIlIII[4] = (0xD555 & 0x12AAA);
    lIIlIlIlIII[5] = (0xC71B & 0x3AE7);
    lIIlIlIlIII[6] = "  ".length();
  }
  
  static
  {
    lllIlIlllIlI();
    lllIlIlllIII();
  }
  
  private static void lllIlIlllIII()
  {
    lIIlIlIIllI = new String[lIIlIlIlIII[1]];
    lIIlIlIIllI[lIIlIlIlIII[0]] = lllIlIllIIll("B78jwNchsQHnEOyG/tPBdskCemTkVap60OtdTKbYH+v2kjj1NVDclidVjiC9lYz4", "nFlOM");
  }
  
  public boolean shouldCombineTextures()
  {
    return lIIlIlIlIII[0];
  }
  
  public LayerEnderDragonEyes(RenderDragon lllllllllllllllllIlIIIIIIIIIIlll)
  {
    dragonRenderer = lllllllllllllllllIlIIIIIIIIIIlll;
  }
}

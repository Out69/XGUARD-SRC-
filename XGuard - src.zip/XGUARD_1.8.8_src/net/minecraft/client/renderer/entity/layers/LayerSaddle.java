package net.minecraft.client.renderer.entity.layers;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelPig;
import net.minecraft.client.renderer.entity.RenderPig;
import net.minecraft.entity.passive.EntityPig;

public class LayerSaddle
  implements LayerRenderer<EntityPig>
{
  private static boolean lllIllIllIllII(int ???)
  {
    byte llllllllllllllIIllIIlllIIIllIlIl;
    return ??? != 0;
  }
  
  static
  {
    lllIllIllIlIll();
    lllIllIllIlIlI();
  }
  
  public LayerSaddle(RenderPig llllllllllllllIIllIIlllIIlllIIlI)
  {
    pigRenderer = llllllllllllllIIllIIlllIIlllIIlI;
  }
  
  private static void lllIllIllIlIlI()
  {
    lIIlllIIIIlIl = new String[lIIlllIIIIllI[1]];
    lIIlllIIIIlIl[lIIlllIIIIllI[0]] = lllIllIllIlIIl("3Phh8iXrdno/4ycyIy+V6k+LPOiV5gW3kzs46luBXGNUwxiPybhGAA==", "DPFlh");
  }
  
  private static void lllIllIllIlIll()
  {
    lIIlllIIIIllI = new int[4];
    lIIlllIIIIllI[0] = ((0x5C ^ 0x54) & (0xB7 ^ 0xBF ^ 0xFFFFFFFF));
    lIIlllIIIIllI[1] = " ".length();
    lIIlllIIIIllI[2] = (0x42 ^ 0x4A);
    lIIlllIIIIllI[3] = "  ".length();
  }
  
  public boolean shouldCombineTextures()
  {
    return lIIlllIIIIllI[0];
  }
  
  private static String lllIllIllIlIIl(String llllllllllllllIIllIIlllIIIlllIlI, String llllllllllllllIIllIIlllIIIlllIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllIIlllIIIllllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllIIlllIIIlllIIl.getBytes(StandardCharsets.UTF_8)), lIIlllIIIIllI[2]), "DES");
      Cipher llllllllllllllIIllIIlllIIIlllllI = Cipher.getInstance("DES");
      llllllllllllllIIllIIlllIIIlllllI.init(lIIlllIIIIllI[3], llllllllllllllIIllIIlllIIIllllll);
      return new String(llllllllllllllIIllIIlllIIIlllllI.doFinal(Base64.getDecoder().decode(llllllllllllllIIllIIlllIIIlllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllIIlllIIIllllIl)
    {
      llllllllllllllIIllIIlllIIIllllIl.printStackTrace();
    }
    return null;
  }
  
  public void doRenderLayer(EntityPig llllllllllllllIIllIIlllIIllIIllI, float llllllllllllllIIllIIlllIIlIlllII, float llllllllllllllIIllIIlllIIllIIlII, float llllllllllllllIIllIIlllIIllIIIll, float llllllllllllllIIllIIlllIIllIIIlI, float llllllllllllllIIllIIlllIIllIIIIl, float llllllllllllllIIllIIlllIIlIllIII, float llllllllllllllIIllIIlllIIlIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIllIllIllII(llllllllllllllIIllIIlllIIllIIllI.getSaddled()))
    {
      pigRenderer.bindTexture(TEXTURE);
      pigModel.setModelAttributes(pigRenderer.getMainModel());
      pigModel.render(llllllllllllllIIllIIlllIIllIIllI, llllllllllllllIIllIIlllIIlIlllII, llllllllllllllIIllIIlllIIllIIlII, llllllllllllllIIllIIlllIIllIIIlI, llllllllllllllIIllIIlllIIllIIIIl, llllllllllllllIIllIIlllIIlIllIII, llllllllllllllIIllIIlllIIlIlllll);
    }
  }
}

package net.minecraft.client.renderer.entity.layers;

import net.minecraft.block.BlockFlower;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelIronGolem;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RenderIronGolem;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.init.Blocks;

public class LayerIronGolemFlower
  implements LayerRenderer<EntityIronGolem>
{
  public void doRenderLayer(EntityIronGolem llllllllllllllIllIllllIIIlIIllII, float llllllllllllllIllIllllIIIlIllIIl, float llllllllllllllIllIllllIIIlIllIII, float llllllllllllllIllIllllIIIlIIlIll, float llllllllllllllIllIllllIIIlIlIllI, float llllllllllllllIllIllllIIIlIlIlIl, float llllllllllllllIllIllllIIIlIlIlII, float llllllllllllllIllIllllIIIlIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllIlIlIIIIII(llllllllllllllIllIllllIIIlIIllII.getHoldRoseTick()))
    {
      BlockRendererDispatcher llllllllllllllIllIllllIIIlIlIIlI = Minecraft.getMinecraft().getBlockRendererDispatcher();
      GlStateManager.enableRescaleNormal();
      GlStateManager.pushMatrix();
      GlStateManager.rotate(5.0F + 180.0F * ironGolemRenderer.getMainModel()).ironGolemRightArm.rotateAngleX / 3.1415927F, 1.0F, 0.0F, 0.0F);
      GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
      GlStateManager.translate(-0.9375F, -0.625F, -0.9375F);
      float llllllllllllllIllIllllIIIlIlIIIl = 0.5F;
      GlStateManager.scale(llllllllllllllIllIllllIIIlIlIIIl, -llllllllllllllIllIllllIIIlIlIIIl, llllllllllllllIllIllllIIIlIlIIIl);
      int llllllllllllllIllIllllIIIlIlIIII = llllllllllllllIllIllllIIIlIIllII.getBrightnessForRender(llllllllllllllIllIllllIIIlIIlIll);
      int llllllllllllllIllIllllIIIlIIllll = llllllllllllllIllIllllIIIlIlIIII % lllIllIIlIlI[0];
      int llllllllllllllIllIllllIIIlIIlllI = llllllllllllllIllIllllIIIlIlIIII / lllIllIIlIlI[0];
      OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, llllllllllllllIllIllllIIIlIIllll / 1.0F, llllllllllllllIllIllllIIIlIIlllI / 1.0F);
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      ironGolemRenderer.bindTexture(TextureMap.locationBlocksTexture);
      llllllllllllllIllIllllIIIlIlIIlI.renderBlockBrightness(Blocks.red_flower.getDefaultState(), 1.0F);
      GlStateManager.popMatrix();
      GlStateManager.disableRescaleNormal();
    }
  }
  
  public LayerIronGolemFlower(RenderIronGolem llllllllllllllIllIllllIIIllIIlII)
  {
    ironGolemRenderer = llllllllllllllIllIllllIIIllIIlII;
  }
  
  private static void lIllIlIIllllll()
  {
    lllIllIIlIlI = new int[2];
    lllIllIIlIlI[0] = (-(0xBF6F & 0x73FD) & 0xFF7E & 0x133ED);
    lllIllIIlIlI[1] = ((0x39 ^ 0x6D ^ 0x7A ^ 0x61) & (0x6C ^ 0x66 ^ 0x2B ^ 0x6E ^ -" ".length()));
  }
  
  static {}
  
  public boolean shouldCombineTextures()
  {
    return lllIllIIlIlI[1];
  }
  
  private static boolean lIllIlIlIIIIII(int ???)
  {
    short llllllllllllllIllIllllIIIIllIIIl;
    return ??? != 0;
  }
}

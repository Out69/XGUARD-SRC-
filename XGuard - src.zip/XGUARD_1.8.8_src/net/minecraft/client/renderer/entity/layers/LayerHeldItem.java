package net.minecraft.client.renderer.entity.layers;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public class LayerHeldItem
  implements LayerRenderer<EntityLivingBase>
{
  public boolean shouldCombineTextures()
  {
    return lIIllllllll[0];
  }
  
  private static boolean lllllIIIIlIl(int ???, int arg1)
  {
    int i;
    short lllllllllllllllllIIlIlIIIlllIIll;
    return ??? == i;
  }
  
  private static boolean lllllIIIIlII(int ???)
  {
    String lllllllllllllllllIIlIlIIIllIllll;
    return ??? != 0;
  }
  
  private static void lllllIIIIIlI()
  {
    lIIllllllll = new int[2];
    lIIllllllll[0] = ((0x6E ^ 0x28 ^ 0x3 ^ 0x56) & (" ".length() ^ 0x6 ^ 0x14 ^ -" ".length()));
    lIIllllllll[1] = "  ".length();
  }
  
  public LayerHeldItem(RendererLivingEntity<?> lllllllllllllllllIIlIlIIlIIlIlII)
  {
    livingEntityRenderer = lllllllllllllllllIIlIlIIlIIlIlII;
  }
  
  public void doRenderLayer(EntityLivingBase lllllllllllllllllIIlIlIIlIIIlIlI, float lllllllllllllllllIIlIlIIlIIIlIIl, float lllllllllllllllllIIlIlIIlIIIlIII, float lllllllllllllllllIIlIlIIlIIIIlll, float lllllllllllllllllIIlIlIIlIIIIllI, float lllllllllllllllllIIlIlIIlIIIIlIl, float lllllllllllllllllIIlIlIIlIIIIlII, float lllllllllllllllllIIlIlIIlIIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ItemStack lllllllllllllllllIIlIlIIlIIIIIlI = lllllllllllllllllIIlIlIIlIIIlIlI.getHeldItem();
    if (lllllIIIIIll(lllllllllllllllllIIlIlIIlIIIIIlI))
    {
      GlStateManager.pushMatrix();
      if (lllllIIIIlII(livingEntityRenderer.getMainModel().isChild))
      {
        float lllllllllllllllllIIlIlIIlIIIIIIl = 0.5F;
        GlStateManager.translate(0.0F, 0.625F, 0.0F);
        GlStateManager.rotate(-20.0F, -1.0F, 0.0F, 0.0F);
        GlStateManager.scale(lllllllllllllllllIIlIlIIlIIIIIIl, lllllllllllllllllIIlIlIIlIIIIIIl, lllllllllllllllllIIlIlIIlIIIIIIl);
      }
      ((ModelBiped)livingEntityRenderer.getMainModel()).postRenderArm(0.0625F);
      GlStateManager.translate(-0.0625F, 0.4375F, 0.0625F);
      if ((lllllIIIIlII(lllllllllllllllllIIlIlIIlIIIlIlI instanceof EntityPlayer)) && (lllllIIIIIll(fishEntity))) {
        lllllllllllllllllIIlIlIIlIIIIIlI = new ItemStack(Items.fishing_rod, lIIllllllll[0]);
      }
      Item lllllllllllllllllIIlIlIIlIIIIIII = lllllllllllllllllIIlIlIIlIIIIIlI.getItem();
      Minecraft lllllllllllllllllIIlIlIIIlllllll = Minecraft.getMinecraft();
      if ((lllllIIIIlII(lllllllllllllllllIIlIlIIlIIIIIII instanceof ItemBlock)) && (lllllIIIIlIl(Block.getBlockFromItem(lllllllllllllllllIIlIlIIlIIIIIII).getRenderType(), lIIllllllll[1])))
      {
        GlStateManager.translate(0.0F, 0.1875F, -0.3125F);
        GlStateManager.rotate(20.0F, 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(45.0F, 0.0F, 1.0F, 0.0F);
        float lllllllllllllllllIIlIlIIIllllllI = 0.375F;
        GlStateManager.scale(-lllllllllllllllllIIlIlIIIllllllI, -lllllllllllllllllIIlIlIIIllllllI, lllllllllllllllllIIlIlIIIllllllI);
      }
      if (lllllIIIIlII(lllllllllllllllllIIlIlIIlIIIlIlI.isSneaking())) {
        GlStateManager.translate(0.0F, 0.203125F, 0.0F);
      }
      lllllllllllllllllIIlIlIIIlllllll.getItemRenderer().renderItem(lllllllllllllllllIIlIlIIlIIIlIlI, lllllllllllllllllIIlIlIIlIIIIIlI, ItemCameraTransforms.TransformType.THIRD_PERSON);
      GlStateManager.popMatrix();
    }
  }
  
  private static boolean lllllIIIIIll(Object ???)
  {
    float lllllllllllllllllIIlIlIIIlllIIIl;
    return ??? != null;
  }
  
  static {}
}

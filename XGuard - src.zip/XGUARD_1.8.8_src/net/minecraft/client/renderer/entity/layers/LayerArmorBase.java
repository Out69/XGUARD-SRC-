package net.minecraft.client.renderer.entity.layers;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RendererLivingEntity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

public abstract class LayerArmorBase<T extends ModelBase>
  implements LayerRenderer<EntityLivingBase>
{
  public LayerArmorBase(RendererLivingEntity<?> lllllllllllllllIllIlIlIlIIIlllIl)
  {
    renderer = lllllllllllllllIllIlIlIlIIIlllIl;
    lllllllllllllllIllIlIlIlIIIlllII.initArmor();
  }
  
  public T func_177175_a(int lllllllllllllllIllIlIlIIlIlllllI)
  {
    ;
    ;
    if (llIllllllIllI(lllllllllllllllIllIlIlIIlIllllIl.isSlotForLeggings(lllllllllllllllIllIlIlIIlIlllllI)))
    {
      "".length();
      if ("  ".length() >= " ".length()) {
        break label40;
      }
      return null;
    }
    label40:
    return field_177186_d;
  }
  
  protected abstract void initArmor();
  
  protected abstract void func_177179_a(T paramT, int paramInt);
  
  private ResourceLocation getArmorResource(ItemArmor lllllllllllllllIllIlIlIIIllllIll, boolean lllllllllllllllIllIlIlIIIllllIlI, String lllllllllllllllIllIlIlIIIlllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIllllllIllI(lllllllllllllllIllIlIlIIIlllIlIl))
    {
      "".length();
      if (((0x8C ^ 0xA9 ^ 0x5 ^ 0x3B) & (0xCF ^ 0xB9 ^ 0x50 ^ 0x3D ^ -" ".length()) & ((0x94 ^ 0xA8 ^ 0xDC ^ 0xBB) & (0x5B ^ 0x3B ^ 0x56 ^ 0x6D ^ -" ".length()) ^ -" ".length())) == (('â' + 49 - 101 + 56 ^ 87 + 6 - 63 + 151) & ('£' + 4 - -7 + 29 ^ 33 + 89 - -1 + 29 ^ -" ".length()))) {
        break label195;
      }
      return null;
    }
    label195:
    lIIlIIIIIlIl[4][lIIlIIIIIlIl[3]] = Integer.valueOf(lIIlIIIIIlIl[4]);
    Object[] tmp199_30 = new Object[] { lllllllllllllllIllIlIlIIIllllIll.getArmorMaterial().getName() };
    if (llIlllllllIlI(lllllllllllllllIllIlIlIIIlllIlII))
    {
      "".length();
      if (((0x6E ^ 0x25 ^ 0x81 ^ 0x9C) & ('Ê' + 58 - 65 + 28 ^ 110 + '' - 225 + 122 ^ -" ".length())) >= 0) {
        break label307;
      }
      return null;
    }
    label307:
    lIIlIIIIIlIl[3][lIIlIIIIIlII[lIIlIIIIIlIl[2]]] = String.format(lIIlIIIIIlII[lIIlIIIIIlIl[1]], new Object[] { lllllllllllllllIllIlIlIIIlllIlII });
    String lllllllllllllllIllIlIlIIIllllIII = String.format(tmp199_30, tmp199_30);
    ResourceLocation lllllllllllllllIllIlIlIIIlllIlll = (ResourceLocation)ARMOR_TEXTURE_RES_MAP.get(lllllllllllllllIllIlIlIIIllllIII);
    if (llIlllllllIlI(lllllllllllllllIllIlIlIIIlllIlll))
    {
      lllllllllllllllIllIlIlIIIlllIlll = new ResourceLocation(lllllllllllllllIllIlIlIIIllllIII);
      "".length();
    }
    return lllllllllllllllIllIlIlIIIlllIlll;
  }
  
  private void renderLayer(EntityLivingBase lllllllllllllllIllIlIlIIllIllIIl, float lllllllllllllllIllIlIlIIlllIlIlI, float lllllllllllllllIllIlIlIIllIlIlll, float lllllllllllllllIllIlIlIIlllIlIII, float lllllllllllllllIllIlIlIIllIlIlIl, float lllllllllllllllIllIlIlIIllIlIlII, float lllllllllllllllIllIlIlIIlllIIlIl, float lllllllllllllllIllIlIlIIlllIIlII, int lllllllllllllllIllIlIlIIllIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ItemStack lllllllllllllllIllIlIlIIlllIIIlI = lllllllllllllllIllIlIlIIlllIllII.getCurrentArmor(lllllllllllllllIllIlIlIIllIllIIl, lllllllllllllllIllIlIlIIllIlIIIl);
    if ((llIllllllIlIl(lllllllllllllllIllIlIlIIlllIIIlI)) && (llIllllllIllI(lllllllllllllllIllIlIlIIlllIIIlI.getItem() instanceof ItemArmor)))
    {
      ItemArmor lllllllllllllllIllIlIlIIlllIIIIl = (ItemArmor)lllllllllllllllIllIlIlIIlllIIIlI.getItem();
      T lllllllllllllllIllIlIlIIlllIIIII = lllllllllllllllIllIlIlIIlllIllII.func_177175_a(lllllllllllllllIllIlIlIIllIlIIIl);
      lllllllllllllllIllIlIlIIlllIIIII.setModelAttributes(renderer.getMainModel());
      lllllllllllllllIllIlIlIIlllIIIII.setLivingAnimations(lllllllllllllllIllIlIlIIllIllIIl, lllllllllllllllIllIlIlIIlllIlIlI, lllllllllllllllIllIlIlIIllIlIlll, lllllllllllllllIllIlIlIIlllIlIII);
      lllllllllllllllIllIlIlIIlllIllII.func_177179_a(lllllllllllllllIllIlIlIIlllIIIII, lllllllllllllllIllIlIlIIllIlIIIl);
      boolean lllllllllllllllIllIlIlIIllIlllll = lllllllllllllllIllIlIlIIlllIllII.isSlotForLeggings(lllllllllllllllIllIlIlIIllIlIIIl);
      renderer.bindTexture(lllllllllllllllIllIlIlIIlllIllII.getArmorResource(lllllllllllllllIllIlIlIIlllIIIIl, lllllllllllllllIllIlIlIIllIlllll));
      switch ($SWITCH_TABLE$net$minecraft$item$ItemArmor$ArmorMaterial()[lllllllllllllllIllIlIlIIlllIIIIl.getArmorMaterial().ordinal()])
      {
      case 1: 
        int lllllllllllllllIllIlIlIIllIllllI = lllllllllllllllIllIlIlIIlllIIIIl.getColor(lllllllllllllllIllIlIlIIlllIIIlI);
        float lllllllllllllllIllIlIlIIllIlllIl = (lllllllllllllllIllIlIlIIllIllllI >> lIIlIIIIIlIl[5] & lIIlIIIIIlIl[6]) / 255.0F;
        float lllllllllllllllIllIlIlIIllIlllII = (lllllllllllllllIllIlIlIIllIllllI >> lIIlIIIIIlIl[7] & lIIlIIIIIlIl[6]) / 255.0F;
        float lllllllllllllllIllIlIlIIllIllIll = (lllllllllllllllIllIlIlIIllIllllI & lIIlIIIIIlIl[6]) / 255.0F;
        GlStateManager.color(colorR * lllllllllllllllIllIlIlIIllIlllIl, colorG * lllllllllllllllIllIlIlIIllIlllII, colorB * lllllllllllllllIllIlIlIIllIllIll, alpha);
        lllllllllllllllIllIlIlIIlllIIIII.render(lllllllllllllllIllIlIlIIllIllIIl, lllllllllllllllIllIlIlIIlllIlIlI, lllllllllllllllIllIlIlIIllIlIlll, lllllllllllllllIllIlIlIIllIlIlIl, lllllllllllllllIllIlIlIIllIlIlII, lllllllllllllllIllIlIlIIlllIIlIl, lllllllllllllllIllIlIlIIlllIIlII);
        renderer.bindTexture(lllllllllllllllIllIlIlIIlllIllII.getArmorResource(lllllllllllllllIllIlIlIIlllIIIIl, lllllllllllllllIllIlIlIIllIlllll, lIIlIIIIIlII[lIIlIIIIIlIl[4]]));
      case 2: 
      case 3: 
      case 4: 
      case 5: 
        GlStateManager.color(colorR, colorG, colorB, alpha);
        lllllllllllllllIllIlIlIIlllIIIII.render(lllllllllllllllIllIlIlIIllIllIIl, lllllllllllllllIllIlIlIIlllIlIlI, lllllllllllllllIllIlIlIIllIlIlll, lllllllllllllllIllIlIlIIllIlIlIl, lllllllllllllllIllIlIlIIllIlIlII, lllllllllllllllIllIlIlIIlllIIlIl, lllllllllllllllIllIlIlIIlllIIlII);
      }
      if ((llIllllllIlll(field_177193_i)) && (llIllllllIllI(lllllllllllllllIllIlIlIIlllIIIlI.isItemEnchanted()))) {
        lllllllllllllllIllIlIlIIlllIllII.func_177183_a(lllllllllllllllIllIlIlIIllIllIIl, lllllllllllllllIllIlIlIIlllIIIII, lllllllllllllllIllIlIlIIlllIlIlI, lllllllllllllllIllIlIlIIllIlIlll, lllllllllllllllIllIlIlIIlllIlIII, lllllllllllllllIllIlIlIIllIlIlIl, lllllllllllllllIllIlIlIIllIlIlII, lllllllllllllllIllIlIlIIlllIIlIl, lllllllllllllllIllIlIlIIlllIIlII);
      }
    }
  }
  
  public boolean shouldCombineTextures()
  {
    return lIIlIIIIIlIl[0];
  }
  
  private static String llIllllllIIlI(String lllllllllllllllIllIlIlIIIllIIIII, String lllllllllllllllIllIlIlIIIlIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllIlIlIIIllIIIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIlIIIllIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIlIIIllIIIll = new StringBuilder();
    char[] lllllllllllllllIllIlIlIIIllIIIlI = lllllllllllllllIllIlIlIIIlIlllll.toCharArray();
    int lllllllllllllllIllIlIlIIIllIIIIl = lIIlIIIIIlIl[0];
    Exception lllllllllllllllIllIlIlIIIlIllIll = lllllllllllllllIllIlIlIIIllIIIII.toCharArray();
    int lllllllllllllllIllIlIlIIIlIllIlI = lllllllllllllllIllIlIlIIIlIllIll.length;
    long lllllllllllllllIllIlIlIIIlIllIIl = lIIlIIIIIlIl[0];
    while (llIlllllllIll(lllllllllllllllIllIlIlIIIlIllIIl, lllllllllllllllIllIlIlIIIlIllIlI))
    {
      char lllllllllllllllIllIlIlIIIllIIllI = lllllllllllllllIllIlIlIIIlIllIll[lllllllllllllllIllIlIlIIIlIllIIl];
      "".length();
      "".length();
      if ("   ".length() < "  ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIllIlIlIIIllIIIll);
  }
  
  private static boolean llIllllllIlIl(Object ???)
  {
    float lllllllllllllllIllIlIlIIIIllIIII;
    return ??? != null;
  }
  
  private void func_177183_a(EntityLivingBase lllllllllllllllIllIlIlIIlIIllIII, T lllllllllllllllIllIlIlIIlIlIIllI, float lllllllllllllllIllIlIlIIlIlIIlIl, float lllllllllllllllIllIlIlIIlIlIIlII, float lllllllllllllllIllIlIlIIlIlIIIll, float lllllllllllllllIllIlIlIIlIIlIIll, float lllllllllllllllIllIlIlIIlIIlIIlI, float lllllllllllllllIllIlIlIIlIIlIIIl, float lllllllllllllllIllIlIlIIlIIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIllIlIlIIlIIllllI = ticksExisted + lllllllllllllllIllIlIlIIlIlIIIll;
    renderer.bindTexture(ENCHANTED_ITEM_GLINT_RES);
    GlStateManager.enableBlend();
    GlStateManager.depthFunc(lIIlIIIIIlIl[8]);
    GlStateManager.depthMask(lIIlIIIIIlIl[0]);
    float lllllllllllllllIllIlIlIIlIIlllIl = 0.5F;
    GlStateManager.color(lllllllllllllllIllIlIlIIlIIlllIl, lllllllllllllllIllIlIlIIlIIlllIl, lllllllllllllllIllIlIlIIlIIlllIl, 1.0F);
    int lllllllllllllllIllIlIlIIlIIlllII = lIIlIIIIIlIl[0];
    "".length();
    if (-(0xAA ^ 0xAE) > 0) {
      return;
    }
    while (!llIlllllllIIl(lllllllllllllllIllIlIlIIlIIlllII, lIIlIIIIIlIl[3]))
    {
      GlStateManager.disableLighting();
      GlStateManager.blendFunc(lIIlIIIIIlIl[9], lIIlIIIIIlIl[4]);
      float lllllllllllllllIllIlIlIIlIIllIll = 0.76F;
      GlStateManager.color(0.5F * lllllllllllllllIllIlIlIIlIIllIll, 0.25F * lllllllllllllllIllIlIlIIlIIllIll, 0.8F * lllllllllllllllIllIlIlIIlIIllIll, 1.0F);
      GlStateManager.matrixMode(lIIlIIIIIlIl[10]);
      GlStateManager.loadIdentity();
      float lllllllllllllllIllIlIlIIlIIllIlI = 0.33333334F;
      GlStateManager.scale(lllllllllllllllIllIlIlIIlIIllIlI, lllllllllllllllIllIlIlIIlIIllIlI, lllllllllllllllIllIlIlIIlIIllIlI);
      GlStateManager.rotate(30.0F - lllllllllllllllIllIlIlIIlIIlllII * 60.0F, 0.0F, 0.0F, 1.0F);
      GlStateManager.translate(0.0F, lllllllllllllllIllIlIlIIlIIllllI * (0.001F + lllllllllllllllIllIlIlIIlIIlllII * 0.003F) * 20.0F, 0.0F);
      GlStateManager.matrixMode(lIIlIIIIIlIl[11]);
      lllllllllllllllIllIlIlIIlIlIIllI.render(lllllllllllllllIllIlIlIIlIIllIII, lllllllllllllllIllIlIlIIlIlIIlIl, lllllllllllllllIllIlIlIIlIlIIlII, lllllllllllllllIllIlIlIIlIIlIIll, lllllllllllllllIllIlIlIIlIIlIIlI, lllllllllllllllIllIlIlIIlIIlIIIl, lllllllllllllllIllIlIlIIlIIlIIII);
      lllllllllllllllIllIlIlIIlIIlllII++;
    }
    GlStateManager.matrixMode(lIIlIIIIIlIl[10]);
    GlStateManager.loadIdentity();
    GlStateManager.matrixMode(lIIlIIIIIlIl[11]);
    GlStateManager.enableLighting();
    GlStateManager.depthMask(lIIlIIIIIlIl[4]);
    GlStateManager.depthFunc(lIIlIIIIIlIl[12]);
    GlStateManager.disableBlend();
  }
  
  private static void llIllllllIlII()
  {
    lIIlIIIIIlIl = new int[14];
    lIIlIIIIIlIl[0] = ((0x3D ^ 0x29) & (0x47 ^ 0x53 ^ 0xFFFFFFFF));
    lIIlIIIIIlIl[1] = (84 + 44 - 56 + 78 ^ 52 + 87 - 7 + 14);
    lIIlIIIIIlIl[2] = "   ".length();
    lIIlIIIIIlIl[3] = "  ".length();
    lIIlIIIIIlIl[4] = " ".length();
    lIIlIIIIIlIl[5] = (0xFC ^ 0xC0 ^ 0x90 ^ 0xBC);
    lIIlIIIIIlIl[6] = ((0x6C ^ 0x77) + (0x77 ^ 0xA) - (0x11 ^ 0x61) + (18 + '' - -33 + 12));
    lIIlIIIIIlIl[7] = ('' + 79 - 196 + 135 ^ 39 + 67 - 32 + 94);
    lIIlIIIIIlIl[8] = (-(0xFBFD & 0x64BB) & 0xF3BE & 0x6EFB);
    lIIlIIIIIlIl[9] = (-(0xDFEF & 0x7CBA) & 0xDFBD & 0x7FEB);
    lIIlIIIIIlIl[10] = (-(0xBCDA & 0x6BFF) & 0xBFFF & 0x7FDB);
    lIIlIIIIIlIl[11] = (0x9727 & 0x7FD8);
    lIIlIIIIIlIl[12] = (0xC603 & 0x3BFF);
    lIIlIIIIIlIl[13] = (0x2B ^ 0x2E);
  }
  
  public ItemStack getCurrentArmor(EntityLivingBase lllllllllllllllIllIlIlIIllIIIlIl, int lllllllllllllllIllIlIlIIllIIIIlI)
  {
    ;
    ;
    return lllllllllllllllIllIlIlIIllIIIlIl.getCurrentArmor(lllllllllllllllIllIlIlIIllIIIIlI - lIIlIIIIIlIl[4]);
  }
  
  private static boolean llIllllllIllI(int ???)
  {
    char lllllllllllllllIllIlIlIIIIlIllII;
    return ??? != 0;
  }
  
  private static boolean llIlllllllIll(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIllIlIlIIIIllIIlI;
    return ??? < i;
  }
  
  public void doRenderLayer(EntityLivingBase lllllllllllllllIllIlIlIlIIIIIlll, float lllllllllllllllIllIlIlIlIIIIllll, float lllllllllllllllIllIlIlIlIIIIlllI, float lllllllllllllllIllIlIlIlIIIIllIl, float lllllllllllllllIllIlIlIlIIIIIIll, float lllllllllllllllIllIlIlIlIIIIlIll, float lllllllllllllllIllIlIlIlIIIIIIIl, float lllllllllllllllIllIlIlIlIIIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllIlIlIlIIIIlIII.renderLayer(lllllllllllllllIllIlIlIlIIIIIlll, lllllllllllllllIllIlIlIlIIIIllll, lllllllllllllllIllIlIlIlIIIIlllI, lllllllllllllllIllIlIlIlIIIIIlII, lllllllllllllllIllIlIlIlIIIIIIll, lllllllllllllllIllIlIlIlIIIIlIll, lllllllllllllllIllIlIlIlIIIIIIIl, lllllllllllllllIllIlIlIlIIIIIIII, lIIlIIIIIlIl[1]);
    lllllllllllllllIllIlIlIlIIIIlIII.renderLayer(lllllllllllllllIllIlIlIlIIIIIlll, lllllllllllllllIllIlIlIlIIIIllll, lllllllllllllllIllIlIlIlIIIIlllI, lllllllllllllllIllIlIlIlIIIIIlII, lllllllllllllllIllIlIlIlIIIIIIll, lllllllllllllllIllIlIlIlIIIIlIll, lllllllllllllllIllIlIlIlIIIIIIIl, lllllllllllllllIllIlIlIlIIIIIIII, lIIlIIIIIlIl[2]);
    lllllllllllllllIllIlIlIlIIIIlIII.renderLayer(lllllllllllllllIllIlIlIlIIIIIlll, lllllllllllllllIllIlIlIlIIIIllll, lllllllllllllllIllIlIlIlIIIIlllI, lllllllllllllllIllIlIlIlIIIIIlII, lllllllllllllllIllIlIlIlIIIIIIll, lllllllllllllllIllIlIlIlIIIIlIll, lllllllllllllllIllIlIlIlIIIIIIIl, lllllllllllllllIllIlIlIlIIIIIIII, lIIlIIIIIlIl[3]);
    lllllllllllllllIllIlIlIlIIIIlIII.renderLayer(lllllllllllllllIllIlIlIlIIIIIlll, lllllllllllllllIllIlIlIlIIIIllll, lllllllllllllllIllIlIlIlIIIIlllI, lllllllllllllllIllIlIlIlIIIIIlII, lllllllllllllllIllIlIlIlIIIIIIll, lllllllllllllllIllIlIlIlIIIIlIll, lllllllllllllllIllIlIlIlIIIIIIIl, lllllllllllllllIllIlIlIlIIIIIIII, lIIlIIIIIlIl[4]);
  }
  
  private static void llIllllllIIll()
  {
    lIIlIIIIIlII = new String[lIIlIIIIIlIl[13]];
    lIIlIIIIIlII[lIIlIIIIIlIl[0]] = llIllllllIIII("8kTeziqeUMsuGcOCwglNQ/+Mese+91Q/3/Dvuq/rYcyNcDuaHAF/4w==", "Lurqz");
    lIIlIIIIIlII[lIIlIIIIIlIl[4]] = llIllllllIIIl("il0cCXAcNk8=", "lebIP");
    lIIlIIIIIlII[lIIlIIIIIlIl[3]] = llIllllllIIIl("k7Okn2GDuz7BHW0x/DTdLvHIAff+eq42X81Lps5o9XgIETcUWFwgBw==", "gCjWm");
    lIIlIIIIIlII[lIIlIIIIIlIl[2]] = llIllllllIIlI("", "MFivS");
    lIIlIIIIIlII[lIIlIIIIIlIl[1]] = llIllllllIIII("hPP5Ubh8P5k=", "maeed");
  }
  
  static
  {
    llIllllllIlII();
    llIllllllIIll();
    ENCHANTED_ITEM_GLINT_RES = new ResourceLocation(lIIlIIIIIlII[lIIlIIIIIlIl[0]]);
  }
  
  private static String llIllllllIIIl(String lllllllllllllllIllIlIlIIIlIlIIII, String lllllllllllllllIllIlIlIIIlIIllIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIlIlIIIlIlIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlIIIlIIllIl.getBytes(StandardCharsets.UTF_8)), lIIlIIIIIlIl[7]), "DES");
      Cipher lllllllllllllllIllIlIlIIIlIlIIlI = Cipher.getInstance("DES");
      lllllllllllllllIllIlIlIIIlIlIIlI.init(lIIlIIIIIlIl[3], lllllllllllllllIllIlIlIIIlIlIIll);
      return new String(lllllllllllllllIllIlIlIIIlIlIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlIIIlIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIlIlIIIlIlIIIl)
    {
      lllllllllllllllIllIlIlIIIlIlIIIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean llIllllllIlll(int ???)
  {
    String lllllllllllllllIllIlIlIIIIlIlIlI;
    return ??? == 0;
  }
  
  private static boolean llIlllllllIIl(int ???, int arg1)
  {
    int i;
    int lllllllllllllllIllIlIlIIIIllIllI;
    return ??? >= i;
  }
  
  private boolean isSlotForLeggings(int lllllllllllllllIllIlIlIIlIlllIIl)
  {
    ;
    if (llIlllllllIII(lllllllllllllllIllIlIlIIlIlllIIl, lIIlIIIIIlIl[3])) {
      return lIIlIIIIIlIl[4];
    }
    return lIIlIIIIIlIl[0];
  }
  
  private static boolean llIlllllllIII(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIllIlIlIIIIlllIlI;
    return ??? == i;
  }
  
  private static boolean llIlllllllIlI(Object ???)
  {
    Exception lllllllllllllllIllIlIlIIIIlIlllI;
    return ??? == null;
  }
  
  private ResourceLocation getArmorResource(ItemArmor lllllllllllllllIllIlIlIIlIIIIllI, boolean lllllllllllllllIllIlIlIIlIIIIlIl)
  {
    ;
    ;
    ;
    return lllllllllllllllIllIlIlIIlIIIIlll.getArmorResource(lllllllllllllllIllIlIlIIlIIIIIll, lllllllllllllllIllIlIlIIlIIIIlIl, null);
  }
  
  private static String llIllllllIIII(String lllllllllllllllIllIlIlIIIlIIIIIl, String lllllllllllllllIllIlIlIIIlIIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIlIlIIIlIIIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIlIIIlIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIlIIIlIIIlIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIlIIIlIIIlIl.init(lIIlIIIIIlIl[3], lllllllllllllllIllIlIlIIIlIIIllI);
      return new String(lllllllllllllllIllIlIlIIIlIIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIlIIIlIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIlIlIIIlIIIlII)
    {
      lllllllllllllllIllIlIlIIIlIIIlII.printStackTrace();
    }
    return null;
  }
}

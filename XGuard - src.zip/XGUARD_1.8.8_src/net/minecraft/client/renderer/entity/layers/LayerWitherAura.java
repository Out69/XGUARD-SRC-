package net.minecraft.client.renderer.entity.layers;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelWither;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderWither;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.util.MathHelper;

public class LayerWitherAura
  implements LayerRenderer<EntityWither>
{
  public LayerWitherAura(RenderWither lllllllllllllllIIlllIIIllllIllII)
  {
    witherRenderer = lllllllllllllllIIlllIIIllllIllII;
  }
  
  private static void lIIIlIIIIlllll()
  {
    lIllIIIIIlII = new int[5];
    lIllIIIIIlII[0] = ((0xD6 ^ 0xC3 ^ 0x9A ^ 0xB0) & (0x0 ^ 0x42 ^ 0x5E ^ 0x23 ^ -" ".length()));
    lIllIIIIIlII[1] = " ".length();
    lIllIIIIIlII[2] = (-('' + 98 - 225 + 192) & 0x9FDF & 0x77FF);
    lIllIIIIIlII[3] = (-(0xFFFFFFE0 & 0x60FF) & 0xFFFFFFDF & 0x77FF);
    lIllIIIIIlII[4] = "  ".length();
  }
  
  static
  {
    lIIIlIIIIlllll();
    lIIIlIIIIllllI();
  }
  
  private static String lIIIlIIIIlllIl(String lllllllllllllllIIlllIIIllIlIlIII, String lllllllllllllllIIlllIIIllIlIlIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIlllIIIllIlIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIlllIIIllIlIlIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIlllIIIllIlIllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIIlllIIIllIlIllII.init(lIllIIIIIlII[4], lllllllllllllllIIlllIIIllIlIllIl);
      return new String(lllllllllllllllIIlllIIIllIlIllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIlllIIIllIlIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIlllIIIllIlIlIll)
    {
      lllllllllllllllIIlllIIIllIlIlIll.printStackTrace();
    }
    return null;
  }
  
  public void doRenderLayer(EntityWither lllllllllllllllIIlllIIIlllIlIIII, float lllllllllllllllIIlllIIIlllIIllll, float lllllllllllllllIIlllIIIlllIIlllI, float lllllllllllllllIIlllIIIlllIIllIl, float lllllllllllllllIIlllIIIlllIllIIl, float lllllllllllllllIIlllIIIlllIllIII, float lllllllllllllllIIlllIIIlllIIlIlI, float lllllllllllllllIIlllIIIlllIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIIlIIIlIIIII(lllllllllllllllIIlllIIIlllIlIIII.isArmored()))
    {
      if (lIIIlIIIlIIIII(lllllllllllllllIIlllIIIlllIlIIII.isInvisible()))
      {
        "".length();
        if ((0x28 ^ 0x2D) != 0) {
          break label45;
        }
      }
      label45:
      GlStateManager.depthMask(lIllIIIIIlII[1]);
      witherRenderer.bindTexture(WITHER_ARMOR);
      GlStateManager.matrixMode(lIllIIIIIlII[2]);
      GlStateManager.loadIdentity();
      float lllllllllllllllIIlllIIIlllIlIlIl = ticksExisted + lllllllllllllllIIlllIIIlllIllIlI;
      float lllllllllllllllIIlllIIIlllIlIlII = MathHelper.cos(lllllllllllllllIIlllIIIlllIlIlIl * 0.02F) * 3.0F;
      float lllllllllllllllIIlllIIIlllIlIIll = lllllllllllllllIIlllIIIlllIlIlIl * 0.01F;
      GlStateManager.translate(lllllllllllllllIIlllIIIlllIlIlII, lllllllllllllllIIlllIIIlllIlIIll, 0.0F);
      GlStateManager.matrixMode(lIllIIIIIlII[3]);
      GlStateManager.enableBlend();
      float lllllllllllllllIIlllIIIlllIlIIlI = 0.5F;
      GlStateManager.color(lllllllllllllllIIlllIIIlllIlIIlI, lllllllllllllllIIlllIIIlllIlIIlI, lllllllllllllllIIlllIIIlllIlIIlI, 1.0F);
      GlStateManager.disableLighting();
      GlStateManager.blendFunc(lIllIIIIIlII[1], lIllIIIIIlII[1]);
      witherModel.setLivingAnimations(lllllllllllllllIIlllIIIlllIlIIII, lllllllllllllllIIlllIIIlllIIllll, lllllllllllllllIIlllIIIlllIIlllI, lllllllllllllllIIlllIIIlllIllIlI);
      witherModel.setModelAttributes(witherRenderer.getMainModel());
      witherModel.render(lllllllllllllllIIlllIIIlllIlIIII, lllllllllllllllIIlllIIIlllIIllll, lllllllllllllllIIlllIIIlllIIlllI, lllllllllllllllIIlllIIIlllIllIIl, lllllllllllllllIIlllIIIlllIllIII, lllllllllllllllIIlllIIIlllIIlIlI, lllllllllllllllIIlllIIIlllIIlIIl);
      GlStateManager.matrixMode(lIllIIIIIlII[2]);
      GlStateManager.loadIdentity();
      GlStateManager.matrixMode(lIllIIIIIlII[3]);
      GlStateManager.enableLighting();
      GlStateManager.disableBlend();
    }
  }
  
  public boolean shouldCombineTextures()
  {
    return lIllIIIIIlII[0];
  }
  
  private static void lIIIlIIIIllllI()
  {
    lIllIIIIIIll = new String[lIllIIIIIlII[1]];
    lIllIIIIIIll[lIllIIIIIlII[0]] = lIIIlIIIIlllIl("Nq4TaMpvYI+ikgJiBY+vfAF22kr8te95G76xS9XKAfw/UCkZSYc7JA==", "wuErd");
  }
  
  private static boolean lIIIlIIIlIIIII(int ???)
  {
    float lllllllllllllllIIlllIIIllIlIIIll;
    return ??? != 0;
  }
}

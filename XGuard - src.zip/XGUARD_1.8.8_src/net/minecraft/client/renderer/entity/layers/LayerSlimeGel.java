package net.minecraft.client.renderer.entity.layers;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderSlime;
import net.minecraft.entity.monster.EntitySlime;

public class LayerSlimeGel
  implements LayerRenderer<EntitySlime>
{
  public boolean shouldCombineTextures()
  {
    return lIIlIlIIllIlI[3];
  }
  
  private static void lllIIIlIlIIIll()
  {
    lIIlIlIIllIlI = new int[4];
    lIIlIlIIllIlI[0] = ((0xB8 ^ 0x90) & (0x2D ^ 0x5 ^ 0xFFFFFFFF));
    lIIlIlIIllIlI[1] = (-(0xBCC3 & 0x733D) & 0xFFFFFFFE & 0x3303);
    lIIlIlIIllIlI[2] = (-(0xD3FD & 0x7C9F) & 0xF3BF & 0x5FDF);
    lIIlIlIIllIlI[3] = " ".length();
  }
  
  static {}
  
  public void doRenderLayer(EntitySlime llllllllllllllIlIIIIIIIIIIIIIIIl, float llllllllllllllIlIIIIIIIIIIIlIIII, float llllllllllllllIlIIIIIIIIIIIIllll, float llllllllllllllIlIIIIIIIIIIIIlllI, float llllllllllllllIIllllllllllllllII, float llllllllllllllIlIIIIIIIIIIIIlIlI, float llllllllllllllIIlllllllllllllIII, float llllllllllllllIlIIIIIIIIIIIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIIlIlIIlII(llllllllllllllIlIIIIIIIIIIIIIIIl.isInvisible()))
    {
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.enableNormalize();
      GlStateManager.enableBlend();
      GlStateManager.blendFunc(lIIlIlIIllIlI[1], lIIlIlIIllIlI[2]);
      slimeModel.setModelAttributes(slimeRenderer.getMainModel());
      slimeModel.render(llllllllllllllIlIIIIIIIIIIIIIIIl, llllllllllllllIlIIIIIIIIIIIlIIII, llllllllllllllIlIIIIIIIIIIIIllll, llllllllllllllIIllllllllllllllII, llllllllllllllIlIIIIIIIIIIIIlIlI, llllllllllllllIIlllllllllllllIII, llllllllllllllIlIIIIIIIIIIIIIIll);
      GlStateManager.disableBlend();
      GlStateManager.disableNormalize();
    }
  }
  
  private static boolean lllIIIlIlIIlII(int ???)
  {
    String llllllllllllllIIllllllllllIIllII;
    return ??? == 0;
  }
  
  public LayerSlimeGel(RenderSlime llllllllllllllIlIIIIIIIIIIlIIIlI)
  {
    slimeRenderer = llllllllllllllIlIIIIIIIIIIlIIIlI;
  }
}

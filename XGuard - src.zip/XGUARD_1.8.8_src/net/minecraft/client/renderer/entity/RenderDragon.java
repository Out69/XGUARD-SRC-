package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelDragon;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.layers.LayerEnderDragonDeath;
import net.minecraft.client.renderer.entity.layers.LayerEnderDragonEyes;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.boss.BossStatus;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class RenderDragon
  extends RenderLiving<EntityDragon>
{
  private static int lIIllIlIllIIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static String lIIllIlIlIlIIl(String lllllllllllllllIIIlIlIIlIlIIIIll, String lllllllllllllllIIIlIlIIlIlIIIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIIlIlIIlIlIIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIlIlIIlIlIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIIIlIlIIlIlIIIlll = Cipher.getInstance("Blowfish");
      lllllllllllllllIIIlIlIIlIlIIIlll.init(llIIlIlIIIlI[2], lllllllllllllllIIIlIlIIlIlIIlIII);
      return new String(lllllllllllllllIIIlIlIIlIlIIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIlIlIIlIlIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIIlIlIIlIlIIIllI)
    {
      lllllllllllllllIIIlIlIIlIlIIIllI.printStackTrace();
    }
    return null;
  }
  
  private static String lIIllIlIlIlIII(String lllllllllllllllIIIlIlIIlIIllIlIl, String lllllllllllllllIIIlIlIIlIIlIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIIlIlIIlIIllIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIIIlIlIIlIIllIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIIlIlIIlIIllIIll = new StringBuilder();
    char[] lllllllllllllllIIIlIlIIlIIllIIlI = lllllllllllllllIIIlIlIIlIIlIllll.toCharArray();
    int lllllllllllllllIIIlIlIIlIIllIIIl = llIIlIlIIIlI[0];
    int lllllllllllllllIIIlIlIIlIIlIlIll = lllllllllllllllIIIlIlIIlIIllIlIl.toCharArray();
    String lllllllllllllllIIIlIlIIlIIlIlIlI = lllllllllllllllIIIlIlIIlIIlIlIll.length;
    double lllllllllllllllIIIlIlIIlIIlIlIIl = llIIlIlIIIlI[0];
    while (lIIllIlIlllIII(lllllllllllllllIIIlIlIIlIIlIlIIl, lllllllllllllllIIIlIlIIlIIlIlIlI))
    {
      char lllllllllllllllIIIlIlIIlIIllIllI = lllllllllllllllIIIlIlIIlIIlIlIll[lllllllllllllllIIIlIlIIlIIlIlIIl];
      "".length();
      "".length();
      if (((0x37 ^ 0x1) & (0x68 ^ 0x5E ^ 0xFFFFFFFF)) >= (0x18 ^ 0x1C)) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIIlIlIIlIIllIIll);
  }
  
  private static boolean lIIllIlIllIIll(int ???)
  {
    double lllllllllllllllIIIlIlIIlIIIlllII;
    return ??? > 0;
  }
  
  public RenderDragon(RenderManager lllllllllllllllIIIlIlIlIIIIIlllI)
  {
    lllllllllllllllIIIlIlIlIIIIIllIl.<init>(lllllllllllllllIIIlIlIlIIIIIlllI, new ModelDragon(0.0F), 0.5F);
    new LayerEnderDragonEyes(lllllllllllllllIIIlIlIlIIIIIllIl);
    "".length();
    new LayerEnderDragonDeath();
    "".length();
  }
  
  protected void renderModel(EntityDragon lllllllllllllllIIIlIlIIllllIllIl, float lllllllllllllllIIIlIlIIllllIllII, float lllllllllllllllIIIlIlIIllllIlIll, float lllllllllllllllIIIlIlIIllllIlIlI, float lllllllllllllllIIIlIlIIllllIlIIl, float lllllllllllllllIIIlIlIIlllIlllll, float lllllllllllllllIIIlIlIIllllIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIIllIlIllIIll(deathTicks))
    {
      float lllllllllllllllIIIlIlIIllllIIllI = deathTicks / 200.0F;
      GlStateManager.depthFunc(llIIlIlIIIlI[6]);
      GlStateManager.enableAlpha();
      GlStateManager.alphaFunc(llIIlIlIIIlI[7], lllllllllllllllIIIlIlIIllllIIllI);
      lllllllllllllllIIIlIlIIllllIIlIl.bindTexture(enderDragonExplodingTextures);
      mainModel.render(lllllllllllllllIIIlIlIIllllIllIl, lllllllllllllllIIIlIlIIllllIllII, lllllllllllllllIIIlIlIIllllIlIll, lllllllllllllllIIIlIlIIllllIlIlI, lllllllllllllllIIIlIlIIllllIlIIl, lllllllllllllllIIIlIlIIlllIlllll, lllllllllllllllIIIlIlIIllllIIlll);
      GlStateManager.alphaFunc(llIIlIlIIIlI[7], 0.1F);
      GlStateManager.depthFunc(llIIlIlIIIlI[8]);
    }
    "".length();
    mainModel.render(lllllllllllllllIIIlIlIIllllIllIl, lllllllllllllllIIIlIlIIllllIllII, lllllllllllllllIIIlIlIIllllIlIll, lllllllllllllllIIIlIlIIllllIlIlI, lllllllllllllllIIIlIlIIllllIlIIl, lllllllllllllllIIIlIlIIlllIlllll, lllllllllllllllIIIlIlIIllllIIlll);
    if (lIIllIlIllIIll(hurtTime))
    {
      GlStateManager.depthFunc(llIIlIlIIIlI[8]);
      GlStateManager.disableTexture2D();
      GlStateManager.enableBlend();
      GlStateManager.blendFunc(llIIlIlIIIlI[9], llIIlIlIIIlI[10]);
      GlStateManager.color(1.0F, 0.0F, 0.0F, 0.5F);
      mainModel.render(lllllllllllllllIIIlIlIIllllIllIl, lllllllllllllllIIIlIlIIllllIllII, lllllllllllllllIIIlIlIIllllIlIll, lllllllllllllllIIIlIlIIllllIlIlI, lllllllllllllllIIIlIlIIllllIlIIl, lllllllllllllllIIIlIlIIlllIlllll, lllllllllllllllIIIlIlIIllllIIlll);
      GlStateManager.enableTexture2D();
      GlStateManager.disableBlend();
      GlStateManager.depthFunc(llIIlIlIIIlI[6]);
    }
  }
  
  private static boolean lIIllIlIlllIII(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIIIlIlIIlIIlIIlII;
    return ??? < i;
  }
  
  public void doRender(EntityDragon lllllllllllllllIIIlIlIIlllIIllIl, double lllllllllllllllIIIlIlIIlllIIllII, double lllllllllllllllIIIlIlIIlllIIlIll, double lllllllllllllllIIIlIlIIlllIlIIIl, float lllllllllllllllIIIlIlIIlllIIlIIl, float lllllllllllllllIIIlIlIIlllIIlIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    BossStatus.setBossStatus(lllllllllllllllIIIlIlIIlllIIllIl, llIIlIlIIIlI[0]);
    lllllllllllllllIIIlIlIIlllIlIlIl.doRender(lllllllllllllllIIIlIlIIlllIIllIl, lllllllllllllllIIIlIlIIlllIIllII, lllllllllllllllIIIlIlIIlllIlIIlI, lllllllllllllllIIIlIlIIlllIlIIIl, lllllllllllllllIIIlIlIIlllIIlIIl, lllllllllllllllIIIlIlIIlllIIlIII);
    if (lIIllIlIllIlII(healingEnderCrystal)) {
      lllllllllllllllIIIlIlIIlllIlIlIl.drawRechargeRay(lllllllllllllllIIIlIlIIlllIIllIl, lllllllllllllllIIIlIlIIlllIIllII, lllllllllllllllIIIlIlIIlllIlIIlI, lllllllllllllllIIIlIlIIlllIlIIIl, lllllllllllllllIIIlIlIIlllIIlIII);
    }
  }
  
  static
  {
    lIIllIlIllIIIl();
    lIIllIlIlIlIlI();
  }
  
  protected void drawRechargeRay(EntityDragon lllllllllllllllIIIlIlIIllIlIlIlI, double lllllllllllllllIIIlIlIIllIIlIIll, double lllllllllllllllIIIlIlIIllIIlIIlI, double lllllllllllllllIIIlIlIIllIlIIlll, float lllllllllllllllIIIlIlIIllIIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIIIlIlIIllIlIIlIl = healingEnderCrystal.innerRotation + lllllllllllllllIIIlIlIIllIIlIIII;
    float lllllllllllllllIIIlIlIIllIlIIlII = MathHelper.sin(lllllllllllllllIIIlIlIIllIlIIlIl * 0.2F) / 2.0F + 0.5F;
    lllllllllllllllIIIlIlIIllIlIIlII = (lllllllllllllllIIIlIlIIllIlIIlII * lllllllllllllllIIIlIlIIllIlIIlII + lllllllllllllllIIIlIlIIllIlIIlII) * 0.2F;
    float lllllllllllllllIIIlIlIIllIlIIIll = (float)(healingEnderCrystal.posX - posX - (prevPosX - posX) * (1.0F - lllllllllllllllIIIlIlIIllIIlIIII));
    float lllllllllllllllIIIlIlIIllIlIIIlI = (float)(lllllllllllllllIIIlIlIIllIlIIlII + healingEnderCrystal.posY - 1.0D - posY - (prevPosY - posY) * (1.0F - lllllllllllllllIIIlIlIIllIIlIIII));
    float lllllllllllllllIIIlIlIIllIlIIIIl = (float)(healingEnderCrystal.posZ - posZ - (prevPosZ - posZ) * (1.0F - lllllllllllllllIIIlIlIIllIIlIIII));
    float lllllllllllllllIIIlIlIIllIlIIIII = MathHelper.sqrt_float(lllllllllllllllIIIlIlIIllIlIIIll * lllllllllllllllIIIlIlIIllIlIIIll + lllllllllllllllIIIlIlIIllIlIIIIl * lllllllllllllllIIIlIlIIllIlIIIIl);
    float lllllllllllllllIIIlIlIIllIIlllll = MathHelper.sqrt_float(lllllllllllllllIIIlIlIIllIlIIIll * lllllllllllllllIIIlIlIIllIlIIIll + lllllllllllllllIIIlIlIIllIlIIIlI * lllllllllllllllIIIlIlIIllIlIIIlI + lllllllllllllllIIIlIlIIllIlIIIIl * lllllllllllllllIIIlIlIIllIlIIIIl);
    GlStateManager.pushMatrix();
    GlStateManager.translate((float)lllllllllllllllIIIlIlIIllIIlIIll, (float)lllllllllllllllIIIlIlIIllIIlIIlI + 2.0F, (float)lllllllllllllllIIIlIlIIllIlIIlll);
    GlStateManager.rotate((float)-Math.atan2(lllllllllllllllIIIlIlIIllIlIIIIl, lllllllllllllllIIIlIlIIllIlIIIll) * 180.0F / 3.1415927F - 90.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate((float)-Math.atan2(lllllllllllllllIIIlIlIIllIlIIIII, lllllllllllllllIIIlIlIIllIlIIIlI) * 180.0F / 3.1415927F - 90.0F, 1.0F, 0.0F, 0.0F);
    Tessellator lllllllllllllllIIIlIlIIllIIllllI = Tessellator.getInstance();
    WorldRenderer lllllllllllllllIIIlIlIIllIIlllIl = lllllllllllllllIIIlIlIIllIIllllI.getWorldRenderer();
    RenderHelper.disableStandardItemLighting();
    GlStateManager.disableCull();
    lllllllllllllllIIIlIlIIllIIlIlIl.bindTexture(enderDragonCrystalBeamTextures);
    GlStateManager.shadeModel(llIIlIlIIIlI[11]);
    float lllllllllllllllIIIlIlIIllIIlllII = 0.0F - (ticksExisted + lllllllllllllllIIIlIlIIllIIlIIII) * 0.01F;
    float lllllllllllllllIIIlIlIIllIIllIll = MathHelper.sqrt_float(lllllllllllllllIIIlIlIIllIlIIIll * lllllllllllllllIIIlIlIIllIlIIIll + lllllllllllllllIIIlIlIIllIlIIIlI * lllllllllllllllIIIlIlIIllIlIIIlI + lllllllllllllllIIIlIlIIllIlIIIIl * lllllllllllllllIIIlIlIIllIlIIIIl) / 32.0F - (ticksExisted + lllllllllllllllIIIlIlIIllIIlIIII) * 0.01F;
    lllllllllllllllIIIlIlIIllIIlllIl.begin(llIIlIlIIIlI[4], DefaultVertexFormats.POSITION_TEX_COLOR);
    int lllllllllllllllIIIlIlIIllIIllIlI = llIIlIlIIIlI[12];
    int lllllllllllllllIIIlIlIIllIIllIIl = llIIlIlIIIlI[0];
    "".length();
    if ("  ".length() < 0) {
      return;
    }
    while (!lIIllIlIllIlll(lllllllllllllllIIIlIlIIllIIllIIl, llIIlIlIIIlI[12]))
    {
      float lllllllllllllllIIIlIlIIllIIllIII = MathHelper.sin(lllllllllllllllIIIlIlIIllIIllIIl % llIIlIlIIIlI[12] * 3.1415927F * 2.0F / 8.0F) * 0.75F;
      float lllllllllllllllIIIlIlIIllIIlIlll = MathHelper.cos(lllllllllllllllIIIlIlIIllIIllIIl % llIIlIlIIIlI[12] * 3.1415927F * 2.0F / 8.0F) * 0.75F;
      float lllllllllllllllIIIlIlIIllIIlIllI = lllllllllllllllIIIlIlIIllIIllIIl % llIIlIlIIIlI[12] * 1.0F / 8.0F;
      lllllllllllllllIIIlIlIIllIIlllIl.pos(lllllllllllllllIIIlIlIIllIIllIII * 0.2F, lllllllllllllllIIIlIlIIllIIlIlll * 0.2F, 0.0D).tex(lllllllllllllllIIIlIlIIllIIlIllI, lllllllllllllllIIIlIlIIllIIllIll).color(llIIlIlIIIlI[0], llIIlIlIIIlI[0], llIIlIlIIIlI[0], llIIlIlIIIlI[13]).endVertex();
      lllllllllllllllIIIlIlIIllIIlllIl.pos(lllllllllllllllIIIlIlIIllIIllIII, lllllllllllllllIIIlIlIIllIIlIlll, lllllllllllllllIIIlIlIIllIIlllll).tex(lllllllllllllllIIIlIlIIllIIlIllI, lllllllllllllllIIIlIlIIllIIlllII).color(llIIlIlIIIlI[13], llIIlIlIIIlI[13], llIIlIlIIIlI[13], llIIlIlIIIlI[13]).endVertex();
      lllllllllllllllIIIlIlIIllIIllIIl++;
    }
    lllllllllllllllIIIlIlIIllIIllllI.draw();
    GlStateManager.enableCull();
    GlStateManager.shadeModel(llIIlIlIIIlI[14]);
    RenderHelper.enableStandardItemLighting();
    GlStateManager.popMatrix();
  }
  
  private static boolean lIIllIlIllIlll(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIIIlIlIIlIIlIIIII;
    return ??? > i;
  }
  
  private static void lIIllIlIlIlIlI()
  {
    llIIlIIlllll = new String[llIIlIlIIIlI[15]];
    llIIlIIlllll[llIIlIlIIIlI[0]] = lIIllIlIlIlIII("NSYTGz4zJhhALi83AhsybiYFCy4zIBkWODUiB0AuLycOHSgzOhgbKi0cCQoqLG0bASw=", "ACkoK");
    llIIlIIlllll[llIIlIlIIIlI[1]] = lIIllIlIlIlIIl("Hhk9pC48GRP4/NpI59YcSjSHB2Hz0HKZsIsiv6yHGl/uP9v5Ibx2kUVFVOjht2PwFXgrjWNb9i0=", "qFBGc");
    llIIlIIlllll[llIIlIlIIIlI[2]] = lIIllIlIlIlIIl("8jihQcuBGLJb4qLvzy0utA1DTndiA9s7uxaBUXmKhzSCI8zMLAP04Q==", "hjxJp");
  }
  
  private static boolean lIIllIlIllIlII(Object ???)
  {
    String lllllllllllllllIIIlIlIIlIIIllllI;
    return ??? != null;
  }
  
  protected void rotateCorpse(EntityDragon lllllllllllllllIIIlIlIIlllllllII, float lllllllllllllllIIIlIlIlIIIIIIIll, float lllllllllllllllIIIlIlIlIIIIIIIlI, float lllllllllllllllIIIlIlIlIIIIIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIIIlIlIlIIIIIIIII = (float)lllllllllllllllIIIlIlIIlllllllII.getMovementOffsets(llIIlIlIIIlI[3], lllllllllllllllIIIlIlIlIIIIIIIIl)[llIIlIlIIIlI[0]];
    float lllllllllllllllIIIlIlIIlllllllll = (float)(lllllllllllllllIIIlIlIIlllllllII.getMovementOffsets(llIIlIlIIIlI[4], lllllllllllllllIIIlIlIlIIIIIIIIl)[llIIlIlIIIlI[1]] - lllllllllllllllIIIlIlIIlllllllII.getMovementOffsets(llIIlIlIIIlI[5], lllllllllllllllIIIlIlIlIIIIIIIIl)[llIIlIlIIIlI[1]]);
    GlStateManager.rotate(-lllllllllllllllIIIlIlIlIIIIIIIII, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(lllllllllllllllIIIlIlIIlllllllll * 10.0F, 1.0F, 0.0F, 0.0F);
    GlStateManager.translate(0.0F, 0.0F, 1.0F);
    if (lIIllIlIllIIll(deathTime))
    {
      float lllllllllllllllIIIlIlIIllllllllI = (deathTime + lllllllllllllllIIIlIlIlIIIIIIIIl - 1.0F) / 20.0F * 1.6F;
      lllllllllllllllIIIlIlIIllllllllI = MathHelper.sqrt_float(lllllllllllllllIIIlIlIIllllllllI);
      if (lIIllIlIllIIll(lIIllIlIllIIlI(lllllllllllllllIIIlIlIIllllllllI, 1.0F))) {
        lllllllllllllllIIIlIlIIllllllllI = 1.0F;
      }
      GlStateManager.rotate(lllllllllllllllIIIlIlIIllllllllI * lllllllllllllllIIIlIlIIlllllllIl.getDeathMaxRotation(lllllllllllllllIIIlIlIIlllllllII), 0.0F, 0.0F, 1.0F);
    }
  }
  
  private static void lIIllIlIllIIIl()
  {
    llIIlIlIIIlI = new int[16];
    llIIlIlIIIlI[0] = ((0xFF ^ 0x8B ^ 0x10 ^ 0x6C) & (0x4D ^ 0x14 ^ 0x19 ^ 0x48 ^ -" ".length()));
    llIIlIlIIIlI[1] = " ".length();
    llIIlIlIIIlI[2] = "  ".length();
    llIIlIlIIIlI[3] = (0xDD ^ 0x99 ^ 0xD ^ 0x4E);
    llIIlIlIIIlI[4] = (0x90 ^ 0x95);
    llIIlIlIIIlI[5] = (0x68 ^ 0x62);
    llIIlIlIIIlI[6] = (0x921F & 0x6FE3);
    llIIlIlIIIlI[7] = (-(0x9BB7 & 0x6D6C) & 0xEB7F & 0x1FA7);
    llIIlIlIIIlI[8] = (0xB35A & 0x4EA7);
    llIIlIlIIIlI[9] = (0xCF26 & 0x33DB);
    llIIlIlIIIlI[10] = (-(0xFEE9 & 0x6DFF) & 0xFFFFFFFB & 0x6FEF);
    llIIlIlIIIlI[11] = (-(33 + 57 - 24 + 87) & 0x9DF9 & 0x7F9F);
    llIIlIlIIIlI[12] = (92 + 42 - 31 + 63 ^ 115 + 111 - 73 + 21);
    llIIlIlIIIlI[13] = (81 + 47 - -25 + 102);
    llIIlIlIIIlI[14] = (0xDF0E & 0x3DF1);
    llIIlIlIIIlI[15] = "   ".length();
  }
  
  protected ResourceLocation getEntityTexture(EntityDragon lllllllllllllllIIIlIlIIlIllllllI)
  {
    return enderDragonTextures;
  }
}

package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelArmorStand;
import net.minecraft.client.model.ModelArmorStandArmor;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
import net.minecraft.client.renderer.entity.layers.LayerCustomHead;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.util.ResourceLocation;

public class ArmorStandRenderer
  extends RendererLivingEntity<EntityArmorStand>
{
  public ArmorStandRenderer(RenderManager llllllllllllllllllIIllIllIIllIlI)
  {
    llllllllllllllllllIIllIllIIllIll.<init>(llllllllllllllllllIIllIllIIllIlI, new ModelArmorStand(), 0.0F);
    LayerBipedArmor llllllllllllllllllIIllIllIIllIIl = new LayerBipedArmor(llllllllllllllllllIIllIllIIllIll)
    {
      protected void initArmor()
      {
        ;
        field_177189_c = new ModelArmorStandArmor(0.5F);
        field_177186_d = new ModelArmorStandArmor(1.0F);
      }
    };
    "".length();
    new LayerHeldItem(llllllllllllllllllIIllIllIIllIll);
    "".length();
    new LayerCustomHead(getMainModelbipedHead);
    "".length();
  }
  
  protected boolean canRenderName(EntityArmorStand llllllllllllllllllIIllIllIIIIllI)
  {
    ;
    return llllllllllllllllllIIllIllIIIIllI.getAlwaysRenderNameTag();
  }
  
  private static void lIlllllIIIll()
  {
    llllIIIIlI = new int[3];
    llllIIIIlI[0] = ((0x7C ^ 0x23) & (0x2C ^ 0x73 ^ 0xFFFFFFFF));
    llllIIIIlI[1] = " ".length();
    llllIIIIlI[2] = "  ".length();
  }
  
  protected void rotateCorpse(EntityArmorStand llllllllllllllllllIIllIllIIIlllI, float llllllllllllllllllIIllIllIIIllIl, float llllllllllllllllllIIllIllIIIllII, float llllllllllllllllllIIllIllIIIlIll)
  {
    ;
    GlStateManager.rotate(180.0F - llllllllllllllllllIIllIllIIIllII, 0.0F, 1.0F, 0.0F);
  }
  
  private static void lIlllllIIIIl()
  {
    llllIIIIIl = new String[llllIIIIlI[1]];
    llllIIIIIl[llllIIIIlI[0]] = lIlllllIIIII("NbqtFEjUQIaDIZoMur/HeiSgPyd0G36PUb02zOY0GLXCGZ9qgqDUdw==", "zbMma");
  }
  
  protected ResourceLocation getEntityTexture(EntityArmorStand llllllllllllllllllIIllIllIIlIlII)
  {
    return TEXTURE_ARMOR_STAND;
  }
  
  public ModelArmorStand getMainModel()
  {
    ;
    return (ModelArmorStand)llllllllllllllllllIIllIllIIlIIlI.getMainModel();
  }
  
  private static String lIlllllIIIII(String llllllllllllllllllIIllIlIllIlIlI, String llllllllllllllllllIIllIlIllIIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIIllIlIllIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIIllIlIllIIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIIllIlIllIllII = Cipher.getInstance("Blowfish");
      llllllllllllllllllIIllIlIllIllII.init(llllIIIIlI[2], llllllllllllllllllIIllIlIllIllIl);
      return new String(llllllllllllllllllIIllIlIllIllII.doFinal(Base64.getDecoder().decode(llllllllllllllllllIIllIlIllIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIIllIlIllIlIll)
    {
      llllllllllllllllllIIllIlIllIlIll.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIlllllIIIll();
    lIlllllIIIIl();
  }
}

package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.model.ModelEnderman;
import net.minecraft.client.renderer.entity.layers.LayerEndermanEyes;
import net.minecraft.client.renderer.entity.layers.LayerHeldBlock;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.util.ResourceLocation;

public class RenderEnderman
  extends RenderLiving<EntityEnderman>
{
  static
  {
    lllIllIIlIlIll();
    lllIllIIlIlIlI();
  }
  
  private static void lllIllIIlIlIlI()
  {
    lIIllIllIIlll = new String[lIIllIllIlIII[1]];
    lIIllIllIIlll[lIIllIllIlIII[0]] = lllIllIIlIlIIl("GiNCqxXGiFD0CFsGt4hDyny6XFskbIwY2cmOYnyTKoqZxxBHBlE1CQ==", "Uzfhg");
  }
  
  public RenderEnderman(RenderManager llllllllllllllIIllIlIIlIIIIIllII)
  {
    llllllllllllllIIllIlIIlIIIIIllIl.<init>(llllllllllllllIIllIlIIlIIIIIllII, new ModelEnderman(0.0F), 0.5F);
    new LayerEndermanEyes(llllllllllllllIIllIlIIlIIIIIllIl);
    "".length();
    new LayerHeldBlock(llllllllllllllIIllIlIIlIIIIIllIl);
    "".length();
  }
  
  private static String lllIllIIlIlIIl(String llllllllllllllIIllIlIIIlllIlIllI, String llllllllllllllIIllIlIIIlllIlIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIIllIlIIIlllIllIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIIllIlIIIlllIlIlll.getBytes(StandardCharsets.UTF_8)), lIIllIllIlIII[2]), "DES");
      Cipher llllllllllllllIIllIlIIIlllIllIlI = Cipher.getInstance("DES");
      llllllllllllllIIllIlIIIlllIllIlI.init(lIIllIllIlIII[3], llllllllllllllIIllIlIIIlllIllIll);
      return new String(llllllllllllllIIllIlIIIlllIllIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIIllIlIIIlllIlIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIIllIlIIIlllIllIIl)
    {
      llllllllllllllIIllIlIIIlllIllIIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIllIIlIllII(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllIIllIlIIIlllIIllll;
    return ??? != localObject;
  }
  
  private static boolean lllIllIIlIllIl(int ???)
  {
    int llllllllllllllIIllIlIIIlllIIllIl;
    return ??? != 0;
  }
  
  private static void lllIllIIlIlIll()
  {
    lIIllIllIlIII = new int[4];
    lIIllIllIlIII[0] = ((0x78 ^ 0x4E ^ 0x0 ^ 0x7C) & (0x78 ^ 0x1A ^ 0x56 ^ 0x7E ^ -" ".length()));
    lIIllIllIlIII[1] = " ".length();
    lIIllIllIlIII[2] = (0x90 ^ 0x98);
    lIIllIllIlIII[3] = "  ".length();
  }
  
  protected ResourceLocation getEntityTexture(EntityEnderman llllllllllllllIIllIlIIIlllllIIlI)
  {
    return endermanTextures;
  }
  
  public void doRender(EntityEnderman llllllllllllllIIllIlIIlIIIIIIIlI, double llllllllllllllIIllIlIIlIIIIIIIIl, double llllllllllllllIIllIlIIIllllllIII, double llllllllllllllIIllIlIIIlllllIlll, float llllllllllllllIIllIlIIIllllllllI, float llllllllllllllIIllIlIIIlllllllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIllIIlIllII(llllllllllllllIIllIlIIlIIIIIIIlI.getHeldBlockState().getBlock().getMaterial(), Material.air))
    {
      "".length();
      if (((0x3E ^ 0x7F) & (0x30 ^ 0x71 ^ 0xFFFFFFFF)) > -" ".length()) {
        break label64;
      }
    }
    label64:
    lIIllIllIlIII1isCarrying = lIIllIllIlIII[0];
    endermanModel.isAttacking = llllllllllllllIIllIlIIlIIIIIIIlI.isScreaming();
    if (lllIllIIlIllIl(llllllllllllllIIllIlIIlIIIIIIIlI.isScreaming()))
    {
      double llllllllllllllIIllIlIIIlllllllII = 0.02D;
      llllllllllllllIIllIlIIlIIIIIIIIl += rnd.nextGaussian() * llllllllllllllIIllIlIIIlllllllII;
      llllllllllllllIIllIlIIIlllllIlll += rnd.nextGaussian() * llllllllllllllIIllIlIIIlllllllII;
    }
    llllllllllllllIIllIlIIIllllllIll.doRender(llllllllllllllIIllIlIIlIIIIIIIlI, llllllllllllllIIllIlIIlIIIIIIIIl, llllllllllllllIIllIlIIlIIIIIIIII, llllllllllllllIIllIlIIIlllllIlll, llllllllllllllIIllIlIIIllllllllI, llllllllllllllIIllIlIIIlllllllIl);
  }
}

package net.minecraft.client.renderer.entity;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

public class RenderEntity
  extends Render<Entity>
{
  protected ResourceLocation getEntityTexture(Entity llllllllllllllIlIlIIllllIIllIlll)
  {
    return null;
  }
  
  public RenderEntity(RenderManager llllllllllllllIlIlIIllllIlIIlllI)
  {
    llllllllllllllIlIlIIllllIlIIllll.<init>(llllllllllllllIlIlIIllllIlIIlllI);
  }
  
  public void doRender(Entity llllllllllllllIlIlIIllllIIlllllI, double llllllllllllllIlIlIIllllIlIIIlII, double llllllllllllllIlIlIIllllIlIIIIll, double llllllllllllllIlIlIIllllIlIIIIlI, float llllllllllllllIlIlIIllllIIlllIlI, float llllllllllllllIlIlIIllllIIlllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.pushMatrix();
    renderOffsetAABB(llllllllllllllIlIlIIllllIIlllllI.getEntityBoundingBox(), llllllllllllllIlIlIIllllIlIIIlII - lastTickPosX, llllllllllllllIlIlIIllllIIllllII - lastTickPosY, llllllllllllllIlIlIIllllIlIIIIlI - lastTickPosZ);
    GlStateManager.popMatrix();
    llllllllllllllIlIlIIllllIlIIIllI.doRender(llllllllllllllIlIlIIllllIIlllllI, llllllllllllllIlIlIIllllIlIIIlII, llllllllllllllIlIlIIllllIIllllII, llllllllllllllIlIlIIllllIlIIIIlI, llllllllllllllIlIlIIllllIIlllIlI, llllllllllllllIlIlIIllllIIlllIIl);
  }
}

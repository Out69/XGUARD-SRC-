package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelBlaze;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.util.ResourceLocation;

public class RenderBlaze
  extends RenderLiving<EntityBlaze>
{
  private static void lIIlIlIlIllIll()
  {
    llIIIlIIlIll = new int[4];
    llIIIlIIlIll[0] = ((94 + 64 - 145 + 120 ^ 38 + 74 - 108 + 125) & (0x50 ^ 0x14 ^ 0xF7 ^ 0xB7 ^ -" ".length()));
    llIIIlIIlIll[1] = " ".length();
    llIIIlIIlIll[2] = (0x9A ^ 0x92);
    llIIIlIIlIll[3] = "  ".length();
  }
  
  public RenderBlaze(RenderManager lllllllllllllllIIIlllllllIIlIIII)
  {
    lllllllllllllllIIIlllllllIIIllll.<init>(lllllllllllllllIIIlllllllIIlIIII, new ModelBlaze(), 0.5F);
  }
  
  protected ResourceLocation getEntityTexture(EntityBlaze lllllllllllllllIIIlllllllIIIllII)
  {
    return blazeTextures;
  }
  
  private static void lIIlIlIlIllIIl()
  {
    llIIIlIIIlll = new String[llIIIlIIlIll[1]];
    llIIIlIIIlll[llIIIlIIlIll[0]] = lIIlIlIlIllIII("6vzxGECYmXIr1FG035Y54jVaZfWgNhLOF3HzemMInP0=", "lFHCJ");
  }
  
  private static String lIIlIlIlIllIII(String lllllllllllllllIIIlllllllIIIIIII, String lllllllllllllllIIIllllllIlllllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIIlllllllIIIIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIllllllIlllllll.getBytes(StandardCharsets.UTF_8)), llIIIlIIlIll[2]), "DES");
      Cipher lllllllllllllllIIIlllllllIIIIIlI = Cipher.getInstance("DES");
      lllllllllllllllIIIlllllllIIIIIlI.init(llIIIlIIlIll[3], lllllllllllllllIIIlllllllIIIIIll);
      return new String(lllllllllllllllIIIlllllllIIIIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIlllllllIIIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIIlllllllIIIIIIl)
    {
      lllllllllllllllIIIlllllllIIIIIIl.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIIlIlIlIllIll();
    lIIlIlIlIllIIl();
  }
}

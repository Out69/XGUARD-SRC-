package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;

public abstract class Render<T extends Entity>
{
  static
  {
    llIIIlIIllIlI();
    llIIIlIIIllIl();
  }
  
  private static boolean llIIIlIlIIIlI(int ???, int arg1)
  {
    int i;
    short llllllllllllllllIIIIlIIIlIllllll;
    return ??? > i;
  }
  
  private static boolean llIIIlIlIIlIl(int ???)
  {
    boolean llllllllllllllllIIIIlIIIlIllIIIl;
    return ??? > 0;
  }
  
  private static int llIIIlIIllIll(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  protected Render(RenderManager llllllllllllllllIIIIlIlIlIIIIIlI)
  {
    renderManager = llllllllllllllllIIIIlIlIlIIIIIlI;
  }
  
  private void func_180549_a(Block llllllllllllllllIIIIlIIlIlllIllI, double llllllllllllllllIIIIlIIlIlllIlIl, double llllllllllllllllIIIIlIIlIlllIlII, double llllllllllllllllIIIIlIIlIlllIIll, BlockPos llllllllllllllllIIIIlIIlIlIllIII, float llllllllllllllllIIIIlIIlIlllIIIl, float llllllllllllllllIIIIlIIlIlIlIllI, double llllllllllllllllIIIIlIIlIlIlIlIl, double llllllllllllllllIIIIlIIlIllIlllI, double llllllllllllllllIIIIlIIlIllIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIIlIIlllIl(llllllllllllllllIIIIlIIlIlllIllI.isFullCube()))
    {
      Tessellator llllllllllllllllIIIIlIIlIllIllII = Tessellator.getInstance();
      WorldRenderer llllllllllllllllIIIIlIIlIllIlIll = llllllllllllllllIIIIlIIlIllIllII.getWorldRenderer();
      double llllllllllllllllIIIIlIIlIllIlIlI = (llllllllllllllllIIIIlIIlIlllIIIl - (llllllllllllllllIIIIlIIlIlllIlII - (llllllllllllllllIIIIlIIlIlllIIlI.getY() + llllllllllllllllIIIIlIIlIllIlllI)) / 2.0D) * 0.5D * llllllllllllllllIIIIlIIlIllIIIII.getWorldFromRenderManager().getLightBrightness(llllllllllllllllIIIIlIIlIlllIIlI);
      if (llIIIlIlIIlII(llIIIlIlIIIll(llllllllllllllllIIIIlIIlIllIlIlI, 0.0D)))
      {
        if (llIIIlIlIIlIl(llIIIlIlIIIll(llllllllllllllllIIIIlIIlIllIlIlI, 1.0D))) {
          llllllllllllllllIIIIlIIlIllIlIlI = 1.0D;
        }
        double llllllllllllllllIIIIlIIlIllIlIIl = llllllllllllllllIIIIlIIlIlllIIlI.getX() + llllllllllllllllIIIIlIIlIlllIllI.getBlockBoundsMinX() + llllllllllllllllIIIIlIIlIlIlIlIl;
        double llllllllllllllllIIIIlIIlIllIlIII = llllllllllllllllIIIIlIIlIlllIIlI.getX() + llllllllllllllllIIIIlIIlIlllIllI.getBlockBoundsMaxX() + llllllllllllllllIIIIlIIlIlIlIlIl;
        double llllllllllllllllIIIIlIIlIllIIlll = llllllllllllllllIIIIlIIlIlllIIlI.getY() + llllllllllllllllIIIIlIIlIlllIllI.getBlockBoundsMinY() + llllllllllllllllIIIIlIIlIllIlllI + 0.015625D;
        double llllllllllllllllIIIIlIIlIllIIllI = llllllllllllllllIIIIlIIlIlllIIlI.getZ() + llllllllllllllllIIIIlIIlIlllIllI.getBlockBoundsMinZ() + llllllllllllllllIIIIlIIlIllIllIl;
        double llllllllllllllllIIIIlIIlIllIIlIl = llllllllllllllllIIIIlIIlIlllIIlI.getZ() + llllllllllllllllIIIIlIIlIlllIllI.getBlockBoundsMaxZ() + llllllllllllllllIIIIlIIlIllIllIl;
        float llllllllllllllllIIIIlIIlIllIIlII = (float)((llllllllllllllllIIIIlIIlIlllIlIl - llllllllllllllllIIIIlIIlIllIlIIl) / 2.0D / llllllllllllllllIIIIlIIlIlIlIllI + 0.5D);
        float llllllllllllllllIIIIlIIlIllIIIll = (float)((llllllllllllllllIIIIlIIlIlllIlIl - llllllllllllllllIIIIlIIlIllIlIII) / 2.0D / llllllllllllllllIIIIlIIlIlIlIllI + 0.5D);
        float llllllllllllllllIIIIlIIlIllIIIlI = (float)((llllllllllllllllIIIIlIIlIlllIIll - llllllllllllllllIIIIlIIlIllIIllI) / 2.0D / llllllllllllllllIIIIlIIlIlIlIllI + 0.5D);
        float llllllllllllllllIIIIlIIlIllIIIIl = (float)((llllllllllllllllIIIIlIIlIlllIIll - llllllllllllllllIIIIlIIlIllIIlIl) / 2.0D / llllllllllllllllIIIIlIIlIlIlIllI + 0.5D);
        llllllllllllllllIIIIlIIlIllIlIll.pos(llllllllllllllllIIIIlIIlIllIlIIl, llllllllllllllllIIIIlIIlIllIIlll, llllllllllllllllIIIIlIIlIllIIllI).tex(llllllllllllllllIIIIlIIlIllIIlII, llllllllllllllllIIIIlIIlIllIIIlI).color(1.0F, 1.0F, 1.0F, (float)llllllllllllllllIIIIlIIlIllIlIlI).endVertex();
        llllllllllllllllIIIIlIIlIllIlIll.pos(llllllllllllllllIIIIlIIlIllIlIIl, llllllllllllllllIIIIlIIlIllIIlll, llllllllllllllllIIIIlIIlIllIIlIl).tex(llllllllllllllllIIIIlIIlIllIIlII, llllllllllllllllIIIIlIIlIllIIIIl).color(1.0F, 1.0F, 1.0F, (float)llllllllllllllllIIIIlIIlIllIlIlI).endVertex();
        llllllllllllllllIIIIlIIlIllIlIll.pos(llllllllllllllllIIIIlIIlIllIlIII, llllllllllllllllIIIIlIIlIllIIlll, llllllllllllllllIIIIlIIlIllIIlIl).tex(llllllllllllllllIIIIlIIlIllIIIll, llllllllllllllllIIIIlIIlIllIIIIl).color(1.0F, 1.0F, 1.0F, (float)llllllllllllllllIIIIlIIlIllIlIlI).endVertex();
        llllllllllllllllIIIIlIIlIllIlIll.pos(llllllllllllllllIIIIlIIlIllIlIII, llllllllllllllllIIIIlIIlIllIIlll, llllllllllllllllIIIIlIIlIllIIllI).tex(llllllllllllllllIIIIlIIlIllIIIll, llllllllllllllllIIIIlIIlIllIIIlI).color(1.0F, 1.0F, 1.0F, (float)llllllllllllllllIIIIlIIlIllIlIlI).endVertex();
      }
    }
  }
  
  private static boolean llIIIlIIlllIl(int ???)
  {
    char llllllllllllllllIIIIlIIIlIlllIIl;
    return ??? != 0;
  }
  
  protected boolean bindEntityTexture(T llllllllllllllllIIIIlIlIIIlIllIl)
  {
    ;
    ;
    ;
    ResourceLocation llllllllllllllllIIIIlIlIIIlIllll = llllllllllllllllIIIIlIlIIIllIIIl.getEntityTexture(llllllllllllllllIIIIlIlIIIlIllIl);
    if (llIIIlIIllllI(llllllllllllllllIIIIlIlIIIlIllll)) {
      return lllllllIIII[0];
    }
    llllllllllllllllIIIIlIlIIIllIIIl.bindTexture(llllllllllllllllIIIIlIlIIIlIllll);
    return lllllllIIII[1];
  }
  
  private static String llIIIlIIIlIll(String llllllllllllllllIIIIlIIIlllIIlII, String llllllllllllllllIIIIlIIIlllIIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIIIIlIIIlllIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIIIIlIIIlllIIIll.getBytes(StandardCharsets.UTF_8)), lllllllIIII[10]), "DES");
      Cipher llllllllllllllllIIIIlIIIlllIIllI = Cipher.getInstance("DES");
      llllllllllllllllIIIIlIIIlllIIllI.init(lllllllIIII[3], llllllllllllllllIIIIlIIIlllIIlll);
      return new String(llllllllllllllllIIIIlIIIlllIIllI.doFinal(Base64.getDecoder().decode(llllllllllllllllIIIIlIIIlllIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIIIIlIIIlllIIlIl)
    {
      llllllllllllllllIIIIlIIIlllIIlIl.printStackTrace();
    }
    return null;
  }
  
  public FontRenderer getFontRendererFromRenderManager()
  {
    ;
    return renderManager.getFontRenderer();
  }
  
  public void doRender(T llllllllllllllllIIIIlIlIIllIIllI, double llllllllllllllllIIIIlIlIIlIllllI, double llllllllllllllllIIIIlIlIIlIlllIl, double llllllllllllllllIIIIlIlIIllIIIll, float llllllllllllllllIIIIlIlIIllIIIlI, float llllllllllllllllIIIIlIlIIllIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIIIlIlIIllIIIII.renderName(llllllllllllllllIIIIlIlIIllIIllI, llllllllllllllllIIIIlIlIIlIllllI, llllllllllllllllIIIIlIlIIllIIlII, llllllllllllllllIIIIlIlIIllIIIll);
  }
  
  public void bindTexture(ResourceLocation llllllllllllllllIIIIlIlIIIlIlIII)
  {
    ;
    ;
    renderManager.renderEngine.bindTexture(llllllllllllllllIIIIlIlIIIlIlIII);
  }
  
  private static boolean llIIIlIlIIIIl(int ???, int arg1)
  {
    int i;
    long llllllllllllllllIIIIlIIIlIlIllIl;
    return ??? != i;
  }
  
  private void renderShadow(Entity llllllllllllllllIIIIlIIllIlIlIlI, double llllllllllllllllIIIIlIIlllIIIIll, double llllllllllllllllIIIIlIIlllIIIIlI, double llllllllllllllllIIIIlIIlllIIIIIl, float llllllllllllllllIIIIlIIllIlIIllI, float llllllllllllllllIIIIlIIllIllllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.enableBlend();
    GlStateManager.blendFunc(lllllllIIII[5], lllllllIIII[6]);
    renderManager.renderEngine.bindTexture(shadowTextures);
    World llllllllllllllllIIIIlIIllIlllllI = llllllllllllllllIIIIlIIllIlIlIll.getWorldFromRenderManager();
    GlStateManager.depthMask(lllllllIIII[0]);
    float llllllllllllllllIIIIlIIllIllllIl = shadowSize;
    if (llIIIlIIlllIl(llllllllllllllllIIIIlIIllIlIlIlI instanceof EntityLiving))
    {
      EntityLiving llllllllllllllllIIIIlIIllIllllII = (EntityLiving)llllllllllllllllIIIIlIIllIlIlIlI;
      llllllllllllllllIIIIlIIllIllllIl *= llllllllllllllllIIIIlIIllIllllII.getRenderSizeModifier();
      if (llIIIlIIlllIl(llllllllllllllllIIIIlIIllIllllII.isChild())) {
        llllllllllllllllIIIIlIIllIllllIl *= 0.5F;
      }
    }
    double llllllllllllllllIIIIlIIllIlllIll = lastTickPosX + (posX - lastTickPosX) * llllllllllllllllIIIIlIIllIllllll;
    double llllllllllllllllIIIIlIIllIlllIlI = lastTickPosY + (posY - lastTickPosY) * llllllllllllllllIIIIlIIllIllllll;
    double llllllllllllllllIIIIlIIllIlllIIl = lastTickPosZ + (posZ - lastTickPosZ) * llllllllllllllllIIIIlIIllIllllll;
    int llllllllllllllllIIIIlIIllIlllIII = MathHelper.floor_double(llllllllllllllllIIIIlIIllIlllIll - llllllllllllllllIIIIlIIllIllllIl);
    int llllllllllllllllIIIIlIIllIllIlll = MathHelper.floor_double(llllllllllllllllIIIIlIIllIlllIll + llllllllllllllllIIIIlIIllIllllIl);
    int llllllllllllllllIIIIlIIllIllIllI = MathHelper.floor_double(llllllllllllllllIIIIlIIllIlllIlI - llllllllllllllllIIIIlIIllIllllIl);
    int llllllllllllllllIIIIlIIllIllIlIl = MathHelper.floor_double(llllllllllllllllIIIIlIIllIlllIlI);
    int llllllllllllllllIIIIlIIllIllIlII = MathHelper.floor_double(llllllllllllllllIIIIlIIllIlllIIl - llllllllllllllllIIIIlIIllIllllIl);
    int llllllllllllllllIIIIlIIllIllIIll = MathHelper.floor_double(llllllllllllllllIIIIlIIllIlllIIl + llllllllllllllllIIIIlIIllIllllIl);
    double llllllllllllllllIIIIlIIllIllIIlI = llllllllllllllllIIIIlIIlllIIIIll - llllllllllllllllIIIIlIIllIlllIll;
    double llllllllllllllllIIIIlIIllIllIIIl = llllllllllllllllIIIIlIIllIlIlIII - llllllllllllllllIIIIlIIllIlllIlI;
    double llllllllllllllllIIIIlIIllIllIIII = llllllllllllllllIIIIlIIlllIIIIIl - llllllllllllllllIIIIlIIllIlllIIl;
    Tessellator llllllllllllllllIIIIlIIllIlIllll = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIIIIlIIllIlIlllI = llllllllllllllllIIIIlIIllIlIllll.getWorldRenderer();
    llllllllllllllllIIIIlIIllIlIlllI.begin(lllllllIIII[4], DefaultVertexFormats.POSITION_TEX_COLOR);
    Exception llllllllllllllllIIIIlIIllIIlIIll = BlockPos.getAllInBoxMutable(new BlockPos(llllllllllllllllIIIIlIIllIlllIII, llllllllllllllllIIIIlIIllIllIllI, llllllllllllllllIIIIlIIllIllIlII), new BlockPos(llllllllllllllllIIIIlIIllIllIlll, llllllllllllllllIIIIlIIllIllIlIl, llllllllllllllllIIIIlIIllIllIIll)).iterator();
    "".length();
    if (((0x32 ^ 0x7C ^ 0xFD ^ 0xB5) & (73 + '¬' - 73 + 24 ^ '' + 44 - 74 + 77 ^ -" ".length())) != 0) {
      return;
    }
    while (!llIIIlIIlllII(llllllllllllllllIIIIlIIllIIlIIll.hasNext()))
    {
      BlockPos llllllllllllllllIIIIlIIllIlIllIl = (BlockPos)llllllllllllllllIIIIlIIllIIlIIll.next();
      Block llllllllllllllllIIIIlIIllIlIllII = llllllllllllllllIIIIlIIllIlllllI.getBlockState(llllllllllllllllIIIIlIIllIlIllIl.down()).getBlock();
      if ((llIIIlIlIIIIl(llllllllllllllllIIIIlIIllIlIllII.getRenderType(), lllllllIIII[7])) && (llIIIlIlIIIlI(llllllllllllllllIIIIlIIllIlllllI.getLightFromNeighbors(llllllllllllllllIIIIlIIllIlIllIl), lllllllIIII[8]))) {
        llllllllllllllllIIIIlIIllIlIlIll.func_180549_a(llllllllllllllllIIIIlIIllIlIllII, llllllllllllllllIIIIlIIlllIIIIll, llllllllllllllllIIIIlIIllIlIlIII, llllllllllllllllIIIIlIIlllIIIIIl, llllllllllllllllIIIIlIIllIlIllIl, llllllllllllllllIIIIlIIllIlIIllI, llllllllllllllllIIIIlIIllIllllIl, llllllllllllllllIIIIlIIllIllIIlI, llllllllllllllllIIIIlIIllIllIIIl, llllllllllllllllIIIIlIIllIllIIII);
      }
    }
    llllllllllllllllIIIIlIIllIlIllll.draw();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.disableBlend();
    GlStateManager.depthMask(lllllllIIII[1]);
  }
  
  private static void llIIIlIIllIlI()
  {
    lllllllIIII = new int[13];
    lllllllIIII[0] = ((103 + '' - 40 + 5 ^ 7 + 41 - 7 + 89) & (0x8D ^ 0x8A ^ 0xC1 ^ 0x95 ^ -" ".length()));
    lllllllIIII[1] = " ".length();
    lllllllIIII[2] = (0x62 ^ 0x7 ^ 0x2 ^ 0x27);
    lllllllIIII[3] = "  ".length();
    lllllllIIII[4] = (0x61 ^ 0x54 ^ 0xB8 ^ 0x8A);
    lllllllIIII[5] = (0xA71E & 0x5BE3);
    lllllllIIII[6] = (-(0xF9A7 & 0x1EFD) & 0xFBA7 & 0x1FFF);
    lllllllIIII[7] = (-" ".length());
    lllllllIIII[8] = "   ".length();
    lllllllIIII[9] = (-(0xA2 ^ 0xAA ^ "  ".length()));
    lllllllIIII[10] = (0xA2 ^ 0xAA);
    lllllllIIII[11] = (-" ".length() & 0xFFFFFFFF & 0x20FFFFFF);
    lllllllIIII[12] = (0x44 ^ 0x4E ^ 0xAA ^ 0xA4);
  }
  
  private static boolean llIIIlIlIIlll(Object ???)
  {
    double llllllllllllllllIIIIlIIIlIllllIl;
    return ??? != null;
  }
  
  private static int llIIIlIIlllll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  protected abstract ResourceLocation getEntityTexture(T paramT);
  
  private static int llIIIlIlIIllI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llIIIlIIlllII(int ???)
  {
    long llllllllllllllllIIIIlIIIlIllIlll;
    return ??? == 0;
  }
  
  private static boolean llIIIlIlIlIIl(int ???, int arg1)
  {
    int i;
    float llllllllllllllllIIIIlIIIllIIIIll;
    return ??? < i;
  }
  
  public RenderManager getRenderManager()
  {
    ;
    return renderManager;
  }
  
  private World getWorldFromRenderManager()
  {
    ;
    return renderManager.worldObj;
  }
  
  private static void llIIIlIIIllIl()
  {
    llllllIlIll = new String[lllllllIIII[12]];
    llllllIlIll[lllllllIIII[0]] = llIIIlIIIlIll("eJWV40biuW62FvudgOvdYNjaOoFKo9j32jcRoEq9guI=", "VVBzx");
    llllllIlIll[lllllllIIII[1]] = llIIIlIIIllII("NSAmAhEqKC4TSDolJwQZK2YuDgA9FiQGCz07F1c=", "XIHgr");
    llllllIlIll[lllllllIIII[3]] = llIIIlIIIlIll("JsxoKUI6P4ALED2ZrU2hyLkAgNC7eELGXNTupVXTBW8=", "Mnvvy");
    llllllIlIll[lllllllIIII[8]] = llIIIlIIIllII("DQQJHD8IFF0=", "iahxR");
  }
  
  private static boolean llIIIlIlIIIII(int ???)
  {
    String llllllllllllllllIIIIlIIIlIllIIll;
    return ??? <= 0;
  }
  
  private static int llIIIlIlIlIII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  protected void renderOffsetLivingLabel(T llllllllllllllllIIIIlIlIIIlllIIl, double llllllllllllllllIIIIlIlIIIlllIII, double llllllllllllllllIIIIlIlIIIllIlll, double llllllllllllllllIIIIlIlIIIlllllI, String llllllllllllllllIIIIlIlIIIllllIl, float llllllllllllllllIIIIlIlIIIllllII, double llllllllllllllllIIIIlIlIIIlllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIIIlIlIIlIIIIlI.renderLivingLabel(llllllllllllllllIIIIlIlIIIlllIIl, llllllllllllllllIIIIlIlIIIllllIl, llllllllllllllllIIIIlIlIIIlllIII, llllllllllllllllIIIIlIlIIIllIlll, llllllllllllllllIIIIlIlIIIlllllI, lllllllIIII[2]);
  }
  
  private static String llIIIlIIIllII(String llllllllllllllllIIIIlIIIllIIllll, String llllllllllllllllIIIIlIIIllIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIIIIlIIIllIIllll = new String(Base64.getDecoder().decode(llllllllllllllllIIIIlIIIllIIllll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIIIIlIIIllIlIIlI = new StringBuilder();
    char[] llllllllllllllllIIIIlIIIllIlIIIl = llllllllllllllllIIIIlIIIllIlIIll.toCharArray();
    int llllllllllllllllIIIIlIIIllIlIIII = lllllllIIII[0];
    long llllllllllllllllIIIIlIIIllIIlIlI = llllllllllllllllIIIIlIIIllIIllll.toCharArray();
    long llllllllllllllllIIIIlIIIllIIlIIl = llllllllllllllllIIIIlIIIllIIlIlI.length;
    Exception llllllllllllllllIIIIlIIIllIIlIII = lllllllIIII[0];
    while (llIIIlIlIlIIl(llllllllllllllllIIIIlIIIllIIlIII, llllllllllllllllIIIIlIIIllIIlIIl))
    {
      char llllllllllllllllIIIIlIIIllIlIlIl = llllllllllllllllIIIIlIIIllIIlIlI[llllllllllllllllIIIIlIIIllIIlIII];
      "".length();
      "".length();
      if ("  ".length() != "  ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIIIIlIIIllIlIIlI);
  }
  
  public boolean shouldRender(T llllllllllllllllIIIIlIlIIllllIII, ICamera llllllllllllllllIIIIlIlIIlllIIIl, double llllllllllllllllIIIIlIlIIlllIIII, double llllllllllllllllIIIIlIlIIlllIlIl, double llllllllllllllllIIIIlIlIIllIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    AxisAlignedBB llllllllllllllllIIIIlIlIIlllIIll = llllllllllllllllIIIIlIlIIllllIII.getEntityBoundingBox();
    if ((!llIIIlIIlllII(llllllllllllllllIIIIlIlIIlllIIll.func_181656_b())) || (llIIIlIIlllII(llIIIlIIllIll(llllllllllllllllIIIIlIlIIlllIIll.getAverageEdgeLength(), 0.0D)))) {
      llllllllllllllllIIIIlIlIIlllIIll = new AxisAlignedBB(posX - 2.0D, posY - 2.0D, posZ - 2.0D, posX + 2.0D, posY + 2.0D, posZ + 2.0D);
    }
    if ((llIIIlIIlllIl(llllllllllllllllIIIIlIlIIllllIII.isInRangeToRender3d(llllllllllllllllIIIIlIlIIlllIllI, llllllllllllllllIIIIlIlIIlllIlIl, llllllllllllllllIIIIlIlIIllIlllI))) && ((!llIIIlIIlllII(ignoreFrustumCheck)) || (llIIIlIIlllIl(llllllllllllllllIIIIlIlIIlllIIIl.isBoundingBoxInFrustum(llllllllllllllllIIIIlIlIIlllIIll))))) {
      return lllllllIIII[1];
    }
    return lllllllIIII[0];
  }
  
  public void doRenderShadowAndFire(Entity llllllllllllllllIIIIlIIlIIlIlllI, double llllllllllllllllIIIIlIIlIIlIIlII, double llllllllllllllllIIIIlIIlIIlIIIll, double llllllllllllllllIIIIlIIlIIlIlIll, float llllllllllllllllIIIIlIIlIIlIlIlI, float llllllllllllllllIIIIlIIlIIlIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIIIlIlIIlll(renderManager.options))
    {
      if ((llIIIlIIlllIl(renderManager.options.field_181151_V)) && (llIIIlIlIIlIl(llIIIlIlIIllI(shadowSize, 0.0F))) && (llIIIlIIlllII(llllllllllllllllIIIIlIIlIIlIlllI.isInvisible())) && (llIIIlIIlllIl(renderManager.isRenderShadow())))
      {
        double llllllllllllllllIIIIlIIlIIlIlIII = renderManager.getDistanceToCamera(posX, posY, posZ);
        float llllllllllllllllIIIIlIIlIIlIIlll = (float)((1.0D - llllllllllllllllIIIIlIIlIIlIlIII / 256.0D) * shadowOpaque);
        if (llIIIlIlIIlIl(llIIIlIlIIllI(llllllllllllllllIIIIlIIlIIlIIlll, 0.0F))) {
          llllllllllllllllIIIIlIIlIIlIllll.renderShadow(llllllllllllllllIIIIlIIlIIlIlllI, llllllllllllllllIIIIlIIlIIlIIlII, llllllllllllllllIIIIlIIlIIlIllII, llllllllllllllllIIIIlIIlIIlIlIll, llllllllllllllllIIIIlIIlIIlIIlll, llllllllllllllllIIIIlIIlIIlIIIIl);
        }
      }
      if ((llIIIlIIlllIl(llllllllllllllllIIIIlIIlIIlIlllI.canRenderOnFire())) && ((!llIIIlIIlllIl(llllllllllllllllIIIIlIIlIIlIlllI instanceof EntityPlayer)) || (llIIIlIIlllII(((EntityPlayer)llllllllllllllllIIIIlIIlIIlIlllI).isSpectator())))) {
        llllllllllllllllIIIIlIIlIIlIllll.renderEntityOnFire(llllllllllllllllIIIIlIIlIIlIlllI, llllllllllllllllIIIIlIIlIIlIIlII, llllllllllllllllIIIIlIIlIIlIllII, llllllllllllllllIIIIlIIlIIlIlIll, llllllllllllllllIIIIlIIlIIlIIIIl);
      }
    }
  }
  
  private static boolean llIIIlIlIIlII(int ???)
  {
    short llllllllllllllllIIIIlIIIlIllIlIl;
    return ??? >= 0;
  }
  
  private static boolean llIIIlIIllllI(Object ???)
  {
    String llllllllllllllllIIIIlIIIlIlllIll;
    return ??? == null;
  }
  
  private void renderEntityOnFire(Entity llllllllllllllllIIIIlIlIIIIIllIl, double llllllllllllllllIIIIlIIlllllIlII, double llllllllllllllllIIIIlIlIIIIIlIll, double llllllllllllllllIIIIlIlIIIIIlIlI, float llllllllllllllllIIIIlIlIIIIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.disableLighting();
    TextureMap llllllllllllllllIIIIlIlIIIIIlIII = Minecraft.getMinecraft().getTextureMapBlocks();
    TextureAtlasSprite llllllllllllllllIIIIlIlIIIIIIlll = llllllllllllllllIIIIlIlIIIIIlIII.getAtlasSprite(llllllIlIll[lllllllIIII[1]]);
    TextureAtlasSprite llllllllllllllllIIIIlIlIIIIIIllI = llllllllllllllllIIIIlIlIIIIIlIII.getAtlasSprite(llllllIlIll[lllllllIIII[3]]);
    GlStateManager.pushMatrix();
    GlStateManager.translate((float)llllllllllllllllIIIIlIIlllllIlII, (float)llllllllllllllllIIIIlIlIIIIIlIll, (float)llllllllllllllllIIIIlIlIIIIIlIlI);
    float llllllllllllllllIIIIlIlIIIIIIlIl = width * 1.4F;
    GlStateManager.scale(llllllllllllllllIIIIlIlIIIIIIlIl, llllllllllllllllIIIIlIlIIIIIIlIl, llllllllllllllllIIIIlIlIIIIIIlIl);
    Tessellator llllllllllllllllIIIIlIlIIIIIIlII = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIIIIlIlIIIIIIIll = llllllllllllllllIIIIlIlIIIIIIlII.getWorldRenderer();
    float llllllllllllllllIIIIlIlIIIIIIIlI = 0.5F;
    float llllllllllllllllIIIIlIlIIIIIIIIl = 0.0F;
    float llllllllllllllllIIIIlIlIIIIIIIII = height / llllllllllllllllIIIIlIlIIIIIIlIl;
    float llllllllllllllllIIIIlIIlllllllll = (float)(posY - getEntityBoundingBoxminY);
    GlStateManager.rotate(-renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
    GlStateManager.translate(0.0F, 0.0F, -0.3F + (int)llllllllllllllllIIIIlIlIIIIIIIII * 0.02F);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    float llllllllllllllllIIIIlIIllllllllI = 0.0F;
    int llllllllllllllllIIIIlIIlllllllIl = lllllllIIII[0];
    llllllllllllllllIIIIlIlIIIIIIIll.begin(lllllllIIII[4], DefaultVertexFormats.POSITION_TEX);
    "".length();
    if (((0x82 ^ 0x9F) & (0xD9 ^ 0xC4 ^ 0xFFFFFFFF)) != ((0x53 ^ 0x1C) & (0x74 ^ 0x3B ^ 0xFFFFFFFF))) {
      return;
    }
    label252:
    while (!llIIIlIlIIIII(llIIIlIIlllll(llllllllllllllllIIIIlIlIIIIIIIII, 0.0F)))
    {
      if (llIIIlIIlllII(llllllllllllllllIIIIlIIlllllllIl % lllllllIIII[3]))
      {
        "".length();
        if (null == null) {
          break label252;
        }
      }
      TextureAtlasSprite llllllllllllllllIIIIlIIlllllllII = llllllllllllllllIIIIlIlIIIIIIllI;
      llllllllllllllllIIIIlIIlllllIllI.bindTexture(TextureMap.locationBlocksTexture);
      float llllllllllllllllIIIIlIIllllllIll = llllllllllllllllIIIIlIIlllllllII.getMinU();
      float llllllllllllllllIIIIlIIllllllIlI = llllllllllllllllIIIIlIIlllllllII.getMinV();
      float llllllllllllllllIIIIlIIllllllIIl = llllllllllllllllIIIIlIIlllllllII.getMaxU();
      float llllllllllllllllIIIIlIIllllllIII = llllllllllllllllIIIIlIIlllllllII.getMaxV();
      if (llIIIlIIlllII(llllllllllllllllIIIIlIIlllllllIl / lllllllIIII[3] % lllllllIIII[3]))
      {
        float llllllllllllllllIIIIlIIlllllIlll = llllllllllllllllIIIIlIIllllllIIl;
        llllllllllllllllIIIIlIIllllllIIl = llllllllllllllllIIIIlIIllllllIll;
        llllllllllllllllIIIIlIIllllllIll = llllllllllllllllIIIIlIIlllllIlll;
      }
      llllllllllllllllIIIIlIlIIIIIIIll.pos(llllllllllllllllIIIIlIlIIIIIIIlI - llllllllllllllllIIIIlIlIIIIIIIIl, 0.0F - llllllllllllllllIIIIlIIlllllllll, llllllllllllllllIIIIlIIllllllllI).tex(llllllllllllllllIIIIlIIllllllIIl, llllllllllllllllIIIIlIIllllllIII).endVertex();
      llllllllllllllllIIIIlIlIIIIIIIll.pos(-llllllllllllllllIIIIlIlIIIIIIIlI - llllllllllllllllIIIIlIlIIIIIIIIl, 0.0F - llllllllllllllllIIIIlIIlllllllll, llllllllllllllllIIIIlIIllllllllI).tex(llllllllllllllllIIIIlIIllllllIll, llllllllllllllllIIIIlIIllllllIII).endVertex();
      llllllllllllllllIIIIlIlIIIIIIIll.pos(-llllllllllllllllIIIIlIlIIIIIIIlI - llllllllllllllllIIIIlIlIIIIIIIIl, 1.4F - llllllllllllllllIIIIlIIlllllllll, llllllllllllllllIIIIlIIllllllllI).tex(llllllllllllllllIIIIlIIllllllIll, llllllllllllllllIIIIlIIllllllIlI).endVertex();
      llllllllllllllllIIIIlIlIIIIIIIll.pos(llllllllllllllllIIIIlIlIIIIIIIlI - llllllllllllllllIIIIlIlIIIIIIIIl, 1.4F - llllllllllllllllIIIIlIIlllllllll, llllllllllllllllIIIIlIIllllllllI).tex(llllllllllllllllIIIIlIIllllllIIl, llllllllllllllllIIIIlIIllllllIlI).endVertex();
      llllllllllllllllIIIIlIlIIIIIIIII -= 0.45F;
      llllllllllllllllIIIIlIIlllllllll -= 0.45F;
      llllllllllllllllIIIIlIlIIIIIIIlI *= 0.9F;
      llllllllllllllllIIIIlIIllllllllI += 0.03F;
    }
    llllllllllllllllIIIIlIlIIIIIIlII.draw();
    GlStateManager.popMatrix();
    GlStateManager.enableLighting();
  }
  
  protected void renderName(T llllllllllllllllIIIIlIlIIlIlIlIl, double llllllllllllllllIIIIlIlIIlIIllll, double llllllllllllllllIIIIlIlIIlIlIIll, double llllllllllllllllIIIIlIlIIlIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIIIlIIlllIl(llllllllllllllllIIIIlIlIIlIlIllI.canRenderName(llllllllllllllllIIIIlIlIIlIlIlIl))) {
      llllllllllllllllIIIIlIlIIlIlIllI.renderLivingLabel(llllllllllllllllIIIIlIlIIlIlIlIl, llllllllllllllllIIIIlIlIIlIlIlIl.getDisplayName().getFormattedText(), llllllllllllllllIIIIlIlIIlIlIlII, llllllllllllllllIIIIlIlIIlIlIIll, llllllllllllllllIIIIlIlIIlIIllIl, lllllllIIII[2]);
    }
  }
  
  public static void renderOffsetAABB(AxisAlignedBB llllllllllllllllIIIIlIIlIlIIIIll, double llllllllllllllllIIIIlIIlIIllllII, double llllllllllllllllIIIIlIIlIlIIIIIl, double llllllllllllllllIIIIlIIlIlIIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.disableTexture2D();
    Tessellator llllllllllllllllIIIIlIIlIIllllll = Tessellator.getInstance();
    WorldRenderer llllllllllllllllIIIIlIIlIIlllllI = llllllllllllllllIIIIlIIlIIllllll.getWorldRenderer();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    llllllllllllllllIIIIlIIlIIlllllI.setTranslation(llllllllllllllllIIIIlIIlIIllllII, llllllllllllllllIIIIlIIlIlIIIIIl, llllllllllllllllIIIIlIIlIlIIIIII);
    llllllllllllllllIIIIlIIlIIlllllI.begin(lllllllIIII[4], DefaultVertexFormats.POSITION_NORMAL);
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, maxY, minZ).normal(0.0F, 0.0F, -1.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, maxY, minZ).normal(0.0F, 0.0F, -1.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, minY, minZ).normal(0.0F, 0.0F, -1.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, minY, minZ).normal(0.0F, 0.0F, -1.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, minY, maxZ).normal(0.0F, 0.0F, 1.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, minY, maxZ).normal(0.0F, 0.0F, 1.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, maxY, maxZ).normal(0.0F, 0.0F, 1.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, maxY, maxZ).normal(0.0F, 0.0F, 1.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, minY, minZ).normal(0.0F, -1.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, minY, minZ).normal(0.0F, -1.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, minY, maxZ).normal(0.0F, -1.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, minY, maxZ).normal(0.0F, -1.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, maxY, maxZ).normal(0.0F, 1.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, maxY, maxZ).normal(0.0F, 1.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, maxY, minZ).normal(0.0F, 1.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, maxY, minZ).normal(0.0F, 1.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, minY, maxZ).normal(-1.0F, 0.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, maxY, maxZ).normal(-1.0F, 0.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, maxY, minZ).normal(-1.0F, 0.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(minX, minY, minZ).normal(-1.0F, 0.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, minY, minZ).normal(1.0F, 0.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, maxY, minZ).normal(1.0F, 0.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, maxY, maxZ).normal(1.0F, 0.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIlllllI.pos(maxX, minY, maxZ).normal(1.0F, 0.0F, 0.0F).endVertex();
    llllllllllllllllIIIIlIIlIIllllll.draw();
    llllllllllllllllIIIIlIIlIIlllllI.setTranslation(0.0D, 0.0D, 0.0D);
    GlStateManager.enableTexture2D();
  }
  
  protected boolean canRenderName(T llllllllllllllllIIIIlIlIIlIIlIIl)
  {
    ;
    if ((llIIIlIIlllIl(llllllllllllllllIIIIlIlIIlIIlIIl.getAlwaysRenderNameTagForRender())) && (llIIIlIIlllIl(llllllllllllllllIIIIlIlIIlIIlIlI.hasCustomName()))) {
      return lllllllIIII[1];
    }
    return lllllllIIII[0];
  }
  
  protected void renderLivingLabel(T llllllllllllllllIIIIlIIlIIIIlIll, String llllllllllllllllIIIIlIIIlllllIll, double llllllllllllllllIIIIlIIlIIIIlIIl, double llllllllllllllllIIIIlIIlIIIIlIII, double llllllllllllllllIIIIlIIlIIIIIlll, int llllllllllllllllIIIIlIIlIIIIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    double llllllllllllllllIIIIlIIlIIIIIlIl = llllllllllllllllIIIIlIIlIIIIlIll.getDistanceSqToEntity(renderManager.livingPlayer);
    if (llIIIlIlIIIII(llIIIlIlIlIII(llllllllllllllllIIIIlIIlIIIIIlIl, llllllllllllllllIIIIlIIlIIIIIllI * llllllllllllllllIIIIlIIlIIIIIllI)))
    {
      FontRenderer llllllllllllllllIIIIlIIlIIIIIlII = llllllllllllllllIIIIlIIlIIIIllII.getFontRendererFromRenderManager();
      float llllllllllllllllIIIIlIIlIIIIIIll = 1.6F;
      float llllllllllllllllIIIIlIIlIIIIIIlI = 0.016666668F * llllllllllllllllIIIIlIIlIIIIIIll;
      GlStateManager.pushMatrix();
      GlStateManager.translate((float)llllllllllllllllIIIIlIIIlllllIlI + 0.0F, (float)llllllllllllllllIIIIlIIlIIIIlIII + height + 0.5F, (float)llllllllllllllllIIIIlIIlIIIIIlll);
      GL11.glNormal3f(0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(-renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
      GlStateManager.scale(-llllllllllllllllIIIIlIIlIIIIIIlI, -llllllllllllllllIIIIlIIlIIIIIIlI, llllllllllllllllIIIIlIIlIIIIIIlI);
      GlStateManager.disableLighting();
      GlStateManager.depthMask(lllllllIIII[0]);
      GlStateManager.disableDepth();
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(lllllllIIII[5], lllllllIIII[6], lllllllIIII[1], lllllllIIII[0]);
      Tessellator llllllllllllllllIIIIlIIlIIIIIIIl = Tessellator.getInstance();
      WorldRenderer llllllllllllllllIIIIlIIlIIIIIIII = llllllllllllllllIIIIlIIlIIIIIIIl.getWorldRenderer();
      int llllllllllllllllIIIIlIIIllllllll = lllllllIIII[0];
      if (llIIIlIIlllIl(llllllllllllllllIIIIlIIIlllllIll.equals(llllllIlIll[lllllllIIII[8]]))) {
        llllllllllllllllIIIIlIIIllllllll = lllllllIIII[9];
      }
      int llllllllllllllllIIIIlIIIlllllllI = llllllllllllllllIIIIlIIlIIIIIlII.getStringWidth(llllllllllllllllIIIIlIIIlllllIll) / lllllllIIII[3];
      GlStateManager.disableTexture2D();
      llllllllllllllllIIIIlIIlIIIIIIII.begin(lllllllIIII[4], DefaultVertexFormats.POSITION_COLOR);
      llllllllllllllllIIIIlIIlIIIIIIII.pos(-llllllllllllllllIIIIlIIIlllllllI - lllllllIIII[1], lllllllIIII[7] + llllllllllllllllIIIIlIIIllllllll, 0.0D).color(0.0F, 0.0F, 0.0F, 0.25F).endVertex();
      llllllllllllllllIIIIlIIlIIIIIIII.pos(-llllllllllllllllIIIIlIIIlllllllI - lllllllIIII[1], lllllllIIII[10] + llllllllllllllllIIIIlIIIllllllll, 0.0D).color(0.0F, 0.0F, 0.0F, 0.25F).endVertex();
      llllllllllllllllIIIIlIIlIIIIIIII.pos(llllllllllllllllIIIIlIIIlllllllI + lllllllIIII[1], lllllllIIII[10] + llllllllllllllllIIIIlIIIllllllll, 0.0D).color(0.0F, 0.0F, 0.0F, 0.25F).endVertex();
      llllllllllllllllIIIIlIIlIIIIIIII.pos(llllllllllllllllIIIIlIIIlllllllI + lllllllIIII[1], lllllllIIII[7] + llllllllllllllllIIIIlIIIllllllll, 0.0D).color(0.0F, 0.0F, 0.0F, 0.25F).endVertex();
      llllllllllllllllIIIIlIIlIIIIIIIl.draw();
      GlStateManager.enableTexture2D();
      "".length();
      GlStateManager.enableDepth();
      GlStateManager.depthMask(lllllllIIII[1]);
      "".length();
      GlStateManager.enableLighting();
      GlStateManager.disableBlend();
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      GlStateManager.popMatrix();
    }
  }
  
  private static int llIIIlIlIIIll(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
}

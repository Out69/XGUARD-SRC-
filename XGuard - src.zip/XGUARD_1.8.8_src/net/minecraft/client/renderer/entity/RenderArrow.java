package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

public class RenderArrow
  extends Render<EntityArrow>
{
  private static void lIIIlIllIIIllI()
  {
    lIllIlIIIlll = new int[6];
    lIllIlIIIlll[0] = ((0x21 ^ 0x46 ^ 0x28 ^ 0x79) & (0xD8 ^ 0x86 ^ 0x1B ^ 0x73 ^ -" ".length()));
    lIllIlIIIlll[1] = (99 + '½' - 109 + 23 ^ 0 + 109 - 31 + 114);
    lIllIlIIIlll[2] = (114 + '' - 113 + 31 ^ ' ' + 106 - 224 + 134);
    lIllIlIIIlll[3] = (0x3D ^ 0x22 ^ 0x7C ^ 0x64);
    lIllIlIIIlll[4] = (116 + 48 - 133 + 130 ^ 87 + 54 - 55 + 79);
    lIllIlIIIlll[5] = " ".length();
  }
  
  private static boolean lIIIlIllIIlIlI(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIIllIIlllIlllIlll;
    return ??? < i;
  }
  
  private static String lIIIlIllIIIlII(String lllllllllllllllIIllIIllllIIIIlll, String lllllllllllllllIIllIIllllIIIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIIllIIllllIIIIlll = new String(Base64.getDecoder().decode(lllllllllllllllIIllIIllllIIIIlll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIIllIIllllIIIlIlI = new StringBuilder();
    char[] lllllllllllllllIIllIIllllIIIlIIl = lllllllllllllllIIllIIllllIIIlIll.toCharArray();
    int lllllllllllllllIIllIIllllIIIlIII = lIllIlIIIlll[0];
    float lllllllllllllllIIllIIllllIIIIIlI = lllllllllllllllIIllIIllllIIIIlll.toCharArray();
    Exception lllllllllllllllIIllIIllllIIIIIIl = lllllllllllllllIIllIIllllIIIIIlI.length;
    boolean lllllllllllllllIIllIIllllIIIIIII = lIllIlIIIlll[0];
    while (lIIIlIllIIlIlI(lllllllllllllllIIllIIllllIIIIIII, lllllllllllllllIIllIIllllIIIIIIl))
    {
      char lllllllllllllllIIllIIllllIIIllIl = lllllllllllllllIIllIIllllIIIIIlI[lllllllllllllllIIllIIllllIIIIIII];
      "".length();
      "".length();
      if ("  ".length() >= "   ".length()) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIIllIIllllIIIlIlI);
  }
  
  protected ResourceLocation getEntityTexture(EntityArrow lllllllllllllllIIllIIllllIlIlIIl)
  {
    return arrowTextures;
  }
  
  public RenderArrow(RenderManager lllllllllllllllIIllIIllllllIllll)
  {
    lllllllllllllllIIllIIllllllIlllI.<init>(lllllllllllllllIIllIIllllllIllll);
  }
  
  private static void lIIIlIllIIIlIl()
  {
    lIllIlIIIllI = new String[lIllIlIIIlll[5]];
    lIllIlIIIllI[lIllIlIIIlll[0]] = lIIIlIllIIIlII("LAg8GiwqCDdBPDYZLRogdww2HDYvQzQAPg==", "XmDnY");
  }
  
  static
  {
    lIIIlIllIIIllI();
    lIIIlIllIIIlIl();
  }
  
  private static boolean lIIIlIllIIlIII(int ???)
  {
    boolean lllllllllllllllIIllIIlllIlllIlIl;
    return ??? > 0;
  }
  
  private static int lIIIlIllIIIlll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void doRender(EntityArrow lllllllllllllllIIllIIllllIlllllI, double lllllllllllllllIIllIIlllllIlIIll, double lllllllllllllllIIllIIllllIllllII, double lllllllllllllllIIllIIllllIlllIll, float lllllllllllllllIIllIIllllIlllIlI, float lllllllllllllllIIllIIllllIlllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    "".length();
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.pushMatrix();
    GlStateManager.translate((float)lllllllllllllllIIllIIlllllIlIIll, (float)lllllllllllllllIIllIIlllllIlIIlI, (float)lllllllllllllllIIllIIllllIlllIll);
    GlStateManager.rotate(prevRotationYaw + (rotationYaw - prevRotationYaw) * lllllllllllllllIIllIIllllIlllIIl - 90.0F, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(prevRotationPitch + (rotationPitch - prevRotationPitch) * lllllllllllllllIIllIIllllIlllIIl, 0.0F, 0.0F, 1.0F);
    Tessellator lllllllllllllllIIllIIlllllIIlllI = Tessellator.getInstance();
    WorldRenderer lllllllllllllllIIllIIlllllIIllIl = lllllllllllllllIIllIIlllllIIlllI.getWorldRenderer();
    int lllllllllllllllIIllIIlllllIIllII = lIllIlIIIlll[0];
    float lllllllllllllllIIllIIlllllIIlIll = 0.0F;
    float lllllllllllllllIIllIIlllllIIlIlI = 0.5F;
    float lllllllllllllllIIllIIlllllIIlIIl = (lIllIlIIIlll[0] + lllllllllllllllIIllIIlllllIIllII * lIllIlIIIlll[1]) / 32.0F;
    float lllllllllllllllIIllIIlllllIIlIII = (lIllIlIIIlll[2] + lllllllllllllllIIllIIlllllIIllII * lIllIlIIIlll[1]) / 32.0F;
    float lllllllllllllllIIllIIlllllIIIlll = 0.0F;
    float lllllllllllllllIIllIIlllllIIIllI = 0.15625F;
    float lllllllllllllllIIllIIlllllIIIlIl = (lIllIlIIIlll[2] + lllllllllllllllIIllIIlllllIIllII * lIllIlIIIlll[1]) / 32.0F;
    float lllllllllllllllIIllIIlllllIIIlII = (lIllIlIIIlll[1] + lllllllllllllllIIllIIlllllIIllII * lIllIlIIIlll[1]) / 32.0F;
    float lllllllllllllllIIllIIlllllIIIIll = 0.05625F;
    GlStateManager.enableRescaleNormal();
    float lllllllllllllllIIllIIlllllIIIIlI = arrowShake - lllllllllllllllIIllIIllllIlllIIl;
    if (lIIIlIllIIlIII(lIIIlIllIIIlll(lllllllllllllllIIllIIlllllIIIIlI, 0.0F)))
    {
      float lllllllllllllllIIllIIlllllIIIIIl = -MathHelper.sin(lllllllllllllllIIllIIlllllIIIIlI * 3.0F) * lllllllllllllllIIllIIlllllIIIIlI;
      GlStateManager.rotate(lllllllllllllllIIllIIlllllIIIIIl, 0.0F, 0.0F, 1.0F);
    }
    GlStateManager.rotate(45.0F, 1.0F, 0.0F, 0.0F);
    GlStateManager.scale(lllllllllllllllIIllIIlllllIIIIll, lllllllllllllllIIllIIlllllIIIIll, lllllllllllllllIIllIIlllllIIIIll);
    GlStateManager.translate(-4.0F, 0.0F, 0.0F);
    GL11.glNormal3f(lllllllllllllllIIllIIlllllIIIIll, 0.0F, 0.0F);
    lllllllllllllllIIllIIlllllIIllIl.begin(lIllIlIIIlll[3], DefaultVertexFormats.POSITION_TEX);
    lllllllllllllllIIllIIlllllIIllIl.pos(-7.0D, -2.0D, -2.0D).tex(lllllllllllllllIIllIIlllllIIIlll, lllllllllllllllIIllIIlllllIIIlIl).endVertex();
    lllllllllllllllIIllIIlllllIIllIl.pos(-7.0D, -2.0D, 2.0D).tex(lllllllllllllllIIllIIlllllIIIllI, lllllllllllllllIIllIIlllllIIIlIl).endVertex();
    lllllllllllllllIIllIIlllllIIllIl.pos(-7.0D, 2.0D, 2.0D).tex(lllllllllllllllIIllIIlllllIIIllI, lllllllllllllllIIllIIlllllIIIlII).endVertex();
    lllllllllllllllIIllIIlllllIIllIl.pos(-7.0D, 2.0D, -2.0D).tex(lllllllllllllllIIllIIlllllIIIlll, lllllllllllllllIIllIIlllllIIIlII).endVertex();
    lllllllllllllllIIllIIlllllIIlllI.draw();
    GL11.glNormal3f(-lllllllllllllllIIllIIlllllIIIIll, 0.0F, 0.0F);
    lllllllllllllllIIllIIlllllIIllIl.begin(lIllIlIIIlll[3], DefaultVertexFormats.POSITION_TEX);
    lllllllllllllllIIllIIlllllIIllIl.pos(-7.0D, 2.0D, -2.0D).tex(lllllllllllllllIIllIIlllllIIIlll, lllllllllllllllIIllIIlllllIIIlIl).endVertex();
    lllllllllllllllIIllIIlllllIIllIl.pos(-7.0D, 2.0D, 2.0D).tex(lllllllllllllllIIllIIlllllIIIllI, lllllllllllllllIIllIIlllllIIIlIl).endVertex();
    lllllllllllllllIIllIIlllllIIllIl.pos(-7.0D, -2.0D, 2.0D).tex(lllllllllllllllIIllIIlllllIIIllI, lllllllllllllllIIllIIlllllIIIlII).endVertex();
    lllllllllllllllIIllIIlllllIIllIl.pos(-7.0D, -2.0D, -2.0D).tex(lllllllllllllllIIllIIlllllIIIlll, lllllllllllllllIIllIIlllllIIIlII).endVertex();
    lllllllllllllllIIllIIlllllIIlllI.draw();
    int lllllllllllllllIIllIIlllllIIIIII = lIllIlIIIlll[0];
    "".length();
    if ("  ".length() <= 0) {
      return;
    }
    while (!lIIIlIllIIlIIl(lllllllllllllllIIllIIlllllIIIIII, lIllIlIIIlll[4]))
    {
      GlStateManager.rotate(90.0F, 1.0F, 0.0F, 0.0F);
      GL11.glNormal3f(0.0F, 0.0F, lllllllllllllllIIllIIlllllIIIIll);
      lllllllllllllllIIllIIlllllIIllIl.begin(lIllIlIIIlll[3], DefaultVertexFormats.POSITION_TEX);
      lllllllllllllllIIllIIlllllIIllIl.pos(-8.0D, -2.0D, 0.0D).tex(lllllllllllllllIIllIIlllllIIlIll, lllllllllllllllIIllIIlllllIIlIIl).endVertex();
      lllllllllllllllIIllIIlllllIIllIl.pos(8.0D, -2.0D, 0.0D).tex(lllllllllllllllIIllIIlllllIIlIlI, lllllllllllllllIIllIIlllllIIlIIl).endVertex();
      lllllllllllllllIIllIIlllllIIllIl.pos(8.0D, 2.0D, 0.0D).tex(lllllllllllllllIIllIIlllllIIlIlI, lllllllllllllllIIllIIlllllIIlIII).endVertex();
      lllllllllllllllIIllIIlllllIIllIl.pos(-8.0D, 2.0D, 0.0D).tex(lllllllllllllllIIllIIlllllIIlIll, lllllllllllllllIIllIIlllllIIlIII).endVertex();
      lllllllllllllllIIllIIlllllIIlllI.draw();
    }
    GlStateManager.disableRescaleNormal();
    GlStateManager.popMatrix();
    lllllllllllllllIIllIIlllllIlIlIl.doRender(lllllllllllllllIIllIIllllIlllllI, lllllllllllllllIIllIIlllllIlIIll, lllllllllllllllIIllIIlllllIlIIlI, lllllllllllllllIIllIIllllIlllIll, lllllllllllllllIIllIIllllIlllIlI, lllllllllllllllIIllIIllllIlllIIl);
  }
  
  private static boolean lIIIlIllIIlIIl(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIIllIIlllIllllIll;
    return ??? >= i;
  }
}

package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.Team.EnumVisible;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.GL11;

public abstract class RendererLivingEntity<T extends EntityLivingBase>
  extends Render<T>
{
  private static int llIllIIlIllII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public RendererLivingEntity(RenderManager lllllllllllllllIlllIIIlllllllllI, ModelBase lllllllllllllllIlllIIIllllllllIl, float lllllllllllllllIlllIIlIIIIIIIIII)
  {
    lllllllllllllllIlllIIIllllllllll.<init>(lllllllllllllllIlllIIIlllllllllI);
    mainModel = lllllllllllllllIlllIIIllllllllIl;
    shadowSize = lllllllllllllllIlllIIlIIIIIIIIII;
  }
  
  protected float handleRotationFloat(T lllllllllllllllIlllIIIlIlIllIlll, float lllllllllllllllIlllIIIlIlIllIlII)
  {
    ;
    ;
    return ticksExisted + lllllllllllllllIlllIIIlIlIllIlII;
  }
  
  protected void unsetBrightness()
  {
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    GlStateManager.enableTexture2D();
    GL11.glTexEnvi(lIIIllIIllII[14], lIIIllIIllII[15], OpenGlHelper.GL_COMBINE);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_RGB, lIIIllIIllII[16]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_RGB, OpenGlHelper.defaultTexUnit);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE1_RGB, OpenGlHelper.GL_PRIMARY_COLOR);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND1_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_ALPHA, lIIIllIIllII[16]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_ALPHA, OpenGlHelper.defaultTexUnit);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE1_ALPHA, OpenGlHelper.GL_PRIMARY_COLOR);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_ALPHA, lIIIllIIllII[10]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND1_ALPHA, lIIIllIIllII[10]);
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GL11.glTexEnvi(lIIIllIIllII[14], lIIIllIIllII[15], OpenGlHelper.GL_COMBINE);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_RGB, lIIIllIIllII[16]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND1_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_RGB, lIIIllIIllII[20]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE1_RGB, OpenGlHelper.GL_PREVIOUS);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_ALPHA, lIIIllIIllII[16]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_ALPHA, lIIIllIIllII[10]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_ALPHA, lIIIllIIllII[20]);
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.setActiveTexture(OpenGlHelper.GL_TEXTURE2);
    GlStateManager.disableTexture2D();
    GlStateManager.bindTexture(lIIIllIIllII[1]);
    GL11.glTexEnvi(lIIIllIIllII[14], lIIIllIIllII[15], OpenGlHelper.GL_COMBINE);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_RGB, lIIIllIIllII[16]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND1_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_RGB, lIIIllIIllII[20]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE1_RGB, OpenGlHelper.GL_PREVIOUS);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_ALPHA, lIIIllIIllII[16]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_ALPHA, lIIIllIIllII[10]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_ALPHA, lIIIllIIllII[20]);
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  protected float interpolateRotation(float lllllllllllllllIlllIIIlllllIIIll, float lllllllllllllllIlllIIIlllllIIllI, float lllllllllllllllIlllIIIlllllIIIIl)
  {
    ;
    ;
    ;
    ;
    float lllllllllllllllIlllIIIlllllIIlII = lllllllllllllllIlllIIIlllllIIllI - lllllllllllllllIlllIIIlllllIIIll;
    "".length();
    if (-(2 + '·' - 169 + 172 ^ '' + 121 - 123 + 41) > 0) {
      return 0.0F;
    }
    while (!llIllIIlIlllI(llIllIIlIllII(lllllllllllllllIlllIIIlllllIIlII, -180.0F))) {
      lllllllllllllllIlllIIIlllllIIlII += 360.0F;
    }
    "".length();
    if ("  ".length() <= 0) {
      return 0.0F;
    }
    while (!llIllIIlIllll(llIllIIlIllIl(lllllllllllllllIlllIIIlllllIIlII, 180.0F))) {
      lllllllllllllllIlllIIIlllllIIlII -= 360.0F;
    }
    return lllllllllllllllIlllIIIlllllIIIll + lllllllllllllllIlllIIIlllllIIIIl * lllllllllllllllIlllIIIlllllIIlII;
  }
  
  private static int llIllIIllIlll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llIllIIllIIll(int ???)
  {
    byte lllllllllllllllIlllIIIIllllIlIlI;
    return ??? > 0;
  }
  
  private static void llIllIIlIlIlI()
  {
    lIIIllIIllII = new int[24];
    lIIIllIIllII[0] = (0x48 ^ 0x58);
    lIIIllIIllII[1] = ((0x60 ^ 0x24 ^ 0x5C ^ 0x32) & (0x61 ^ 0x17 ^ 0x3D ^ 0x61 ^ -" ".length()));
    lIIIllIIllII[2] = (-" ".length());
    lIIIllIIllII[3] = (-(0xEEB7 & 0x795A) & 0xEB11 & 0x7DFF);
    lIIIllIIllII[4] = (0xC1 ^ 0xC5);
    lIIIllIIllII[5] = " ".length();
    lIIIllIIllII[6] = (-" ".length() & 0xFFFFFFFF & 0xFFFFFF);
    lIIIllIIllII[7] = "  ".length();
    lIIIllIIllII[8] = ('' + 79 - -2 + 43);
    lIIIllIIllII[9] = (0x89 ^ 0x81);
    lIIIllIIllII[10] = (0xC31E & 0x3FE3);
    lIIIllIIllII[11] = (-(0xF9FD & 0x56B7) & 0xFFFFFFBF & 0x53F7);
    lIIIllIIllII[12] = (-(0xDF7E & 0x64E5) & 0xEEFF & 0x5767);
    lIIIllIIllII[13] = (0x72 ^ 0x6A);
    lIIIllIIllII[14] = (-(0xFFFFFFBB & 0x4CE7) & 0xEFFF & 0x7FA2);
    lIIIllIIllII[15] = (-(0xDD7D & 0x23C7) & 0xFF5C & 0x23E7);
    lIIIllIIllII[16] = (-(0xFFFFFFBB & 0xAFE) & 0xEFFB & 0x3BBD);
    lIIIllIIllII[17] = (-(0xC47F & 0x7FFF) & 0xC77F & 0x7FFE);
    lIIIllIIllII[18] = (0x9F7D & 0x7E83);
    lIIIllIIllII[19] = (0xB273 & 0x6F8D);
    lIIIllIIllII[20] = (0xBF6F & 0x5792);
    lIIIllIIllII[21] = (82 + '' - 84 + 4 ^ 38 + 46 - 30 + 83);
    lIIIllIIllII[22] = (0xFFFFFFFF & 0x20FFFFFF);
    lIIIllIIllII[23] = "   ".length();
  }
  
  private static boolean llIllIIllIlIl(Object ???)
  {
    String lllllllllllllllIlllIIIIllllllIII;
    return ??? != null;
  }
  
  protected void renderModel(T lllllllllllllllIlllIIIllIlIlIIlI, float lllllllllllllllIlllIIIllIlIlllll, float lllllllllllllllIlllIIIllIlIlIIII, float lllllllllllllllIlllIIIllIlIlllII, float lllllllllllllllIlllIIIllIlIIlllI, float lllllllllllllllIlllIIIllIlIllIII, float lllllllllllllllIlllIIIllIlIIllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIllIIllIIlI(lllllllllllllllIlllIIIllIlIlIIlI.isInvisible()))
    {
      "".length();
      if (null == null) {
        break label31;
      }
    }
    label31:
    boolean lllllllllllllllIlllIIIllIlIlIlIl = lIIIllIIllII[5];
    if ((llIllIIllIlII(lllllllllllllllIlllIIIllIlIlIlIl)) && (llIllIIllIlII(lllllllllllllllIlllIIIllIlIlIIlI.isInvisibleToPlayer(getMinecraftthePlayer))))
    {
      "".length();
      if (-"   ".length() < 0) {
        break label83;
      }
    }
    label83:
    boolean lllllllllllllllIlllIIIllIlIlIlII = lIIIllIIllII[1];
    if ((!llIllIIllIlII(lllllllllllllllIlllIIIllIlIlIlIl)) || (llIllIIllIIlI(lllllllllllllllIlllIIIllIlIlIlII)))
    {
      if (llIllIIllIlII(lllllllllllllllIlllIIIllIllIIIll.bindEntityTexture(lllllllllllllllIlllIIIllIlIlIIlI))) {
        return;
      }
      if (llIllIIllIIlI(lllllllllllllllIlllIIIllIlIlIlII))
      {
        GlStateManager.pushMatrix();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 0.15F);
        GlStateManager.depthMask(lIIIllIIllII[1]);
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(lIIIllIIllII[10], lIIIllIIllII[11]);
        GlStateManager.alphaFunc(lIIIllIIllII[12], 0.003921569F);
      }
      mainModel.render(lllllllllllllllIlllIIIllIlIlIIlI, lllllllllllllllIlllIIIllIlIlllll, lllllllllllllllIlllIIIllIlIlIIII, lllllllllllllllIlllIIIllIlIlllII, lllllllllllllllIlllIIIllIlIIlllI, lllllllllllllllIlllIIIllIlIllIII, lllllllllllllllIlllIIIllIlIIllII);
      if (llIllIIllIIlI(lllllllllllllllIlllIIIllIlIlIlII))
      {
        GlStateManager.disableBlend();
        GlStateManager.alphaFunc(lIIIllIIllII[12], 0.1F);
        GlStateManager.popMatrix();
        GlStateManager.depthMask(lIIIllIIllII[5]);
      }
    }
  }
  
  protected float getSwingProgress(T lllllllllllllllIlllIIIlIlIlllllI, float lllllllllllllllIlllIIIlIlIlllIll)
  {
    ;
    ;
    return lllllllllllllllIlllIIIlIlIlllllI.getSwingProgress(lllllllllllllllIlllIIIlIlIlllIll);
  }
  
  public void setRenderOutlines(boolean lllllllllllllllIlllIIIlIIlIIlIIl)
  {
    ;
    ;
    renderOutlines = lllllllllllllllIlllIIIlIIlIIlIIl;
  }
  
  private static boolean llIllIIllIllI(int ???)
  {
    String lllllllllllllllIlllIIIIllllIllII;
    return ??? <= 0;
  }
  
  public void renderName(T lllllllllllllllIlllIIIlIIllIllII, double lllllllllllllllIlllIIIlIIllllIII, double lllllllllllllllIlllIIIlIIllIlIlI, double lllllllllllllllIlllIIIlIIlllIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (llIllIIllIIlI(lllllllllllllllIlllIIIlIIllllIlI.canRenderName(lllllllllllllllIlllIIIlIIllIllII)))
    {
      double lllllllllllllllIlllIIIlIIlllIlIl = lllllllllllllllIlllIIIlIIllIllII.getDistanceSqToEntity(renderManager.livingPlayer);
      if (llIllIIllIIlI(lllllllllllllllIlllIIIlIIllIllII.isSneaking()))
      {
        "".length();
        if (-" ".length() < 0) {
          break label56;
        }
      }
      label56:
      float lllllllllllllllIlllIIIlIIlllIlII = 64.0F;
      if (llIllIIlIllll(llIllIIlllIII(lllllllllllllllIlllIIIlIIlllIlIl, lllllllllllllllIlllIIIlIIlllIlII * lllllllllllllllIlllIIIlIIlllIlII)))
      {
        String lllllllllllllllIlllIIIlIIlllIIll = lllllllllllllllIlllIIIlIIllIllII.getDisplayName().getFormattedText();
        float lllllllllllllllIlllIIIlIIlllIIlI = 0.02666667F;
        GlStateManager.alphaFunc(lIIIllIIllII[12], 0.1F);
        if (llIllIIllIIlI(lllllllllllllllIlllIIIlIIllIllII.isSneaking()))
        {
          FontRenderer lllllllllllllllIlllIIIlIIlllIIIl = lllllllllllllllIlllIIIlIIllllIlI.getFontRendererFromRenderManager();
          GlStateManager.pushMatrix();
          if (llIllIIllIIlI(lllllllllllllllIlllIIIlIIllIllII.isChild()))
          {
            "".length();
            if ((0xC1 ^ 0xC4) > 0) {
              break label170;
            }
          }
          label170:
          GlStateManager.translate((float)lllllllllllllllIlllIIIlIIllIlIlI + height + 0.5F, height / 2.0F - 0.0F, (float)lllllllllllllllIlllIIIlIIlllIllI);
          GL11.glNormal3f(0.0F, 1.0F, 0.0F);
          GlStateManager.rotate(-renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
          GlStateManager.rotate(renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
          GlStateManager.scale(-0.02666667F, -0.02666667F, 0.02666667F);
          GlStateManager.translate(0.0F, 9.374999F, 0.0F);
          GlStateManager.disableLighting();
          GlStateManager.depthMask(lIIIllIIllII[1]);
          GlStateManager.enableBlend();
          GlStateManager.disableTexture2D();
          GlStateManager.tryBlendFuncSeparate(lIIIllIIllII[10], lIIIllIIllII[11], lIIIllIIllII[5], lIIIllIIllII[1]);
          int lllllllllllllllIlllIIIlIIlllIIII = lllllllllllllllIlllIIIlIIlllIIIl.getStringWidth(lllllllllllllllIlllIIIlIIlllIIll) / lIIIllIIllII[7];
          Tessellator lllllllllllllllIlllIIIlIIllIllll = Tessellator.getInstance();
          WorldRenderer lllllllllllllllIlllIIIlIIllIlllI = lllllllllllllllIlllIIIlIIllIllll.getWorldRenderer();
          lllllllllllllllIlllIIIlIIllIlllI.begin(lIIIllIIllII[21], DefaultVertexFormats.POSITION_COLOR);
          lllllllllllllllIlllIIIlIIllIlllI.pos(-lllllllllllllllIlllIIIlIIlllIIII - lIIIllIIllII[5], -1.0D, 0.0D).color(0.0F, 0.0F, 0.0F, 0.25F).endVertex();
          lllllllllllllllIlllIIIlIIllIlllI.pos(-lllllllllllllllIlllIIIlIIlllIIII - lIIIllIIllII[5], 8.0D, 0.0D).color(0.0F, 0.0F, 0.0F, 0.25F).endVertex();
          lllllllllllllllIlllIIIlIIllIlllI.pos(lllllllllllllllIlllIIIlIIlllIIII + lIIIllIIllII[5], 8.0D, 0.0D).color(0.0F, 0.0F, 0.0F, 0.25F).endVertex();
          lllllllllllllllIlllIIIlIIllIlllI.pos(lllllllllllllllIlllIIIlIIlllIIII + lIIIllIIllII[5], -1.0D, 0.0D).color(0.0F, 0.0F, 0.0F, 0.25F).endVertex();
          lllllllllllllllIlllIIIlIIllIllll.draw();
          GlStateManager.enableTexture2D();
          GlStateManager.depthMask(lIIIllIIllII[5]);
          "".length();
          GlStateManager.enableLighting();
          GlStateManager.disableBlend();
          GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
          GlStateManager.popMatrix();
          "".length();
          if (-"   ".length() < 0) {}
        }
        else
        {
          if (llIllIIllIIlI(lllllllllllllllIlllIIIlIIllIllII.isChild()))
          {
            "".length();
            if (null == null) {
              break label557;
            }
          }
          label557:
          lllllllllllllllIlllIIIlIIllIllII.renderOffsetLivingLabel(lllllllllllllllIlllIIIlIIllIlIll, lllllllllllllllIlllIIIlIIllIlIlI, height / 2.0F - 0.0D, lllllllllllllllIlllIIIlIIlllIllI, lllllllllllllllIlllIIIlIIlllIIll, 0.02666667F, lllllllllllllllIlllIIIlIIlllIlIl);
        }
      }
    }
  }
  
  private static void llIllIIlIIlIl()
  {
    lIIIllIIlIII = new String[lIIIllIIllII[23]];
    lIIIllIIlIII[lIIIllIIllII[1]] = llIllIIlIIIll("MoTYysU8/sRU4TgRgLuLbUxoIR997lAt", "FAZBH");
    lIIIllIIlIII[lIIIllIIllII[5]] = llIllIIlIIlII("KygHFiodIwYWKg==", "oAixO");
    lIIIllIIlIII[lIIIllIIllII[7]] = llIllIIlIIlII("LgItASo=", "ipXlG");
  }
  
  private static boolean llIllIIllIIlI(int ???)
  {
    boolean lllllllllllllllIlllIIIIlllllIlII;
    return ??? != 0;
  }
  
  private static boolean llIllIIllllIl(int ???, int arg1)
  {
    int i;
    long lllllllllllllllIlllIIIIllllllllI;
    return ??? < i;
  }
  
  private static String llIllIIlIIIll(String lllllllllllllllIlllIIIlIIIIIlIIl, String lllllllllllllllIlllIIIlIIIIIlIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlllIIIlIIIIIlllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIlIIIIIlIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIlIIIIIllIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIlIIIIIllIl.init(lIIIllIIllII[7], lllllllllllllllIlllIIIlIIIIIlllI);
      return new String(lllllllllllllllIlllIIIlIIIIIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIlIIIIIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlllIIIlIIIIIllII)
    {
      lllllllllllllllIlllIIIlIIIIIllII.printStackTrace();
    }
    return null;
  }
  
  protected boolean canRenderName(T lllllllllllllllIlllIIIlIIlIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    EntityPlayerSP lllllllllllllllIlllIIIlIIlIllIII = getMinecraftthePlayer;
    if ((llIllIIllIIlI(lllllllllllllllIlllIIIlIIlIlIIll instanceof EntityPlayer)) && (llIllIIlllIIl(lllllllllllllllIlllIIIlIIlIlIIll, lllllllllllllllIlllIIIlIIlIllIII)))
    {
      Team lllllllllllllllIlllIIIlIIlIlIlll = lllllllllllllllIlllIIIlIIlIlIIll.getTeam();
      Team lllllllllllllllIlllIIIlIIlIlIllI = lllllllllllllllIlllIIIlIIlIllIII.getTeam();
      if (llIllIIllIlIl(lllllllllllllllIlllIIIlIIlIlIlll))
      {
        Team.EnumVisible lllllllllllllllIlllIIIlIIlIlIlIl = lllllllllllllllIlllIIIlIIlIlIlll.getNameTagVisibility();
        switch ($SWITCH_TABLE$net$minecraft$scoreboard$Team$EnumVisible()[lllllllllllllllIlllIIIlIIlIlIlIl.ordinal()])
        {
        case 1: 
          return lIIIllIIllII[5];
        case 2: 
          return lIIIllIIllII[1];
        case 3: 
          if ((llIllIIllIlIl(lllllllllllllllIlllIIIlIIlIlIllI)) && (llIllIIllIlII(lllllllllllllllIlllIIIlIIlIlIlll.isSameTeam(lllllllllllllllIlllIIIlIIlIlIllI)))) {
            return lIIIllIIllII[1];
          }
          return lIIIllIIllII[5];
        case 4: 
          if ((llIllIIllIlIl(lllllllllllllllIlllIIIlIIlIlIllI)) && (llIllIIllIIlI(lllllllllllllllIlllIIIlIIlIlIlll.isSameTeam(lllllllllllllllIlllIIIlIIlIlIllI)))) {
            return lIIIllIIllII[1];
          }
          return lIIIllIIllII[5];
        }
        return lIIIllIIllII[5];
      }
    }
    if ((llIllIIllIIlI(Minecraft.isGuiEnabled())) && (llIllIIlllIIl(lllllllllllllllIlllIIIlIIlIlIIll, renderManager.livingPlayer)) && (llIllIIllIlII(lllllllllllllllIlllIIIlIIlIlIIll.isInvisibleToPlayer(lllllllllllllllIlllIIIlIIlIllIII))) && (llIllIIlllIlI(riddenByEntity))) {
      return lIIIllIIllII[5];
    }
    return lIIIllIIllII[1];
  }
  
  private static boolean llIllIIlllIlI(Object ???)
  {
    byte lllllllllllllllIlllIIIIlllllIllI;
    return ??? == null;
  }
  
  protected void rotateCorpse(T lllllllllllllllIlllIIIlIllIIllII, float lllllllllllllllIlllIIIlIllIIlIll, float lllllllllllllllIlllIIIlIllIIlIlI, float lllllllllllllllIlllIIIlIllIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    GlStateManager.rotate(180.0F - lllllllllllllllIlllIIIlIllIIlIlI, 0.0F, 1.0F, 0.0F);
    if (llIllIIllIIll(deathTime))
    {
      float lllllllllllllllIlllIIIlIllIIlIII = (deathTime + lllllllllllllllIlllIIIlIllIIlIIl - 1.0F) / 20.0F * 1.6F;
      lllllllllllllllIlllIIIlIllIIlIII = MathHelper.sqrt_float(lllllllllllllllIlllIIIlIllIIlIII);
      if (llIllIIllIIll(llIllIIllIlll(lllllllllllllllIlllIIIlIllIIlIII, 1.0F))) {
        lllllllllllllllIlllIIIlIllIIlIII = 1.0F;
      }
      GlStateManager.rotate(lllllllllllllllIlllIIIlIllIIlIII * lllllllllllllllIlllIIIlIllIIllIl.getDeathMaxRotation(lllllllllllllllIlllIIIlIllIIllII), 0.0F, 0.0F, 1.0F);
      "".length();
      if ("  ".length() != " ".length()) {}
    }
    else
    {
      String lllllllllllllllIlllIIIlIllIIIlll = EnumChatFormatting.getTextWithoutFormattingCodes(lllllllllllllllIlllIIIlIllIIllII.getName());
      if ((llIllIIllIlIl(lllllllllllllllIlllIIIlIllIIIlll)) && ((!llIllIIllIlII(lllllllllllllllIlllIIIlIllIIIlll.equals(lIIIllIIlIII[lIIIllIIllII[5]]))) || (llIllIIllIIlI(lllllllllllllllIlllIIIlIllIIIlll.equals(lIIIllIIlIII[lIIIllIIllII[7]])))) && ((!llIllIIllIIlI(lllllllllllllllIlllIIIlIllIIllII instanceof EntityPlayer)) || (llIllIIllIIlI(((EntityPlayer)lllllllllllllllIlllIIIlIllIIllII).isWearing(EnumPlayerModelParts.CAPE)))))
      {
        GlStateManager.translate(0.0F, height + 0.1F, 0.0F);
        GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
      }
    }
  }
  
  protected void unsetScoreTeamColor()
  {
    GlStateManager.enableLighting();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    GlStateManager.enableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.enableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
  }
  
  private static boolean llIllIIlllIIl(Object ???, Object arg1)
  {
    Object localObject;
    Exception lllllllllllllllIlllIIIIllllllIlI;
    return ??? != localObject;
  }
  
  private static String llIllIIlIIlII(String lllllllllllllllIlllIIIlIIIIllIll, String lllllllllllllllIlllIIIlIIIIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlllIIIlIIIIllIll = new String(Base64.getDecoder().decode(lllllllllllllllIlllIIIlIIIIllIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIlllIIIlIIIIllllI = new StringBuilder();
    char[] lllllllllllllllIlllIIIlIIIIlllIl = lllllllllllllllIlllIIIlIIIIlllll.toCharArray();
    int lllllllllllllllIlllIIIlIIIIlllII = lIIIllIIllII[1];
    short lllllllllllllllIlllIIIlIIIIlIllI = lllllllllllllllIlllIIIlIIIIllIll.toCharArray();
    double lllllllllllllllIlllIIIlIIIIlIlIl = lllllllllllllllIlllIIIlIIIIlIllI.length;
    double lllllllllllllllIlllIIIlIIIIlIlII = lIIIllIIllII[1];
    while (llIllIIllllIl(lllllllllllllllIlllIIIlIIIIlIlII, lllllllllllllllIlllIIIlIIIIlIlIl))
    {
      char lllllllllllllllIlllIIIlIIIlIIIIl = lllllllllllllllIlllIIIlIIIIlIllI[lllllllllllllllIlllIIIlIIIIlIlII];
      "".length();
      "".length();
      if (" ".length() < 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIlllIIIlIIIIllllI);
  }
  
  protected int getColorMultiplier(T lllllllllllllllIlllIIIlIlIIIllIl, float lllllllllllllllIlllIIIlIlIIIllII, float lllllllllllllllIlllIIIlIlIIIlIll)
  {
    return lIIIllIIllII[1];
  }
  
  protected void renderLivingAt(T lllllllllllllllIlllIIIlIllIllIIl, double lllllllllllllllIlllIIIlIllIllIII, double lllllllllllllllIlllIIIlIllIlIlII, double lllllllllllllllIlllIIIlIllIlIllI)
  {
    ;
    ;
    ;
    GlStateManager.translate((float)lllllllllllllllIlllIIIlIllIllIII, (float)lllllllllllllllIlllIIIlIllIlIlll, (float)lllllllllllllllIlllIIIlIllIlIllI);
  }
  
  protected void preRenderCallback(T lllllllllllllllIlllIIIlIlIIIlIIl, float lllllllllllllllIlllIIIlIlIIIlIII) {}
  
  protected boolean setDoRenderBrightness(T lllllllllllllllIlllIIIllIIlllllI, float lllllllllllllllIlllIIIllIlIIIIIl)
  {
    ;
    ;
    ;
    return lllllllllllllllIlllIIIllIlIIIlIl.setBrightness(lllllllllllllllIlllIIIllIlIIIIll, lllllllllllllllIlllIIIllIlIIIIIl, lIIIllIIllII[5]);
  }
  
  protected <V extends EntityLivingBase, U extends LayerRenderer<V>> boolean removeLayer(U lllllllllllllllIlllIIIllllllIIII)
  {
    ;
    ;
    return layerRenderers.remove(lllllllllllllllIlllIIIllllllIIII);
  }
  
  private static int llIllIIllIIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static int llIllIIlllIII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public void doRender(T lllllllllllllllIlllIIIllllIIIllI, double lllllllllllllllIlllIIIllllIIIlIl, double lllllllllllllllIlllIIIlllIlIllIl, double lllllllllllllllIlllIIIlllIlIllII, float lllllllllllllllIlllIIIllllIIIIlI, float lllllllllllllllIlllIIIlllIlIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.pushMatrix();
    GlStateManager.disableCull();
    mainModel.swingProgress = lllllllllllllllIlllIIIllllIIIlll.getSwingProgress(lllllllllllllllIlllIIIllllIIIllI, lllllllllllllllIlllIIIlllIlIlIIl);
    mainModel.isRiding = lllllllllllllllIlllIIIllllIIIllI.isRiding();
    mainModel.isChild = lllllllllllllllIlllIIIllllIIIllI.isChild();
    try
    {
      float lllllllllllllllIlllIIIllllIIIIII = lllllllllllllllIlllIIIllllIIIlll.interpolateRotation(prevRenderYawOffset, renderYawOffset, lllllllllllllllIlllIIIlllIlIlIIl);
      float lllllllllllllllIlllIIIlllIllllll = lllllllllllllllIlllIIIllllIIIlll.interpolateRotation(prevRotationYawHead, rotationYawHead, lllllllllllllllIlllIIIlllIlIlIIl);
      float lllllllllllllllIlllIIIlllIlllllI = lllllllllllllllIlllIIIlllIllllll - lllllllllllllllIlllIIIllllIIIIII;
      if ((llIllIIllIIlI(lllllllllllllllIlllIIIllllIIIllI.isRiding())) && (llIllIIllIIlI(ridingEntity instanceof EntityLivingBase)))
      {
        EntityLivingBase lllllllllllllllIlllIIIlllIllllIl = (EntityLivingBase)ridingEntity;
        lllllllllllllllIlllIIIllllIIIIII = lllllllllllllllIlllIIIllllIIIlll.interpolateRotation(prevRenderYawOffset, renderYawOffset, lllllllllllllllIlllIIIlllIlIlIIl);
        lllllllllllllllIlllIIIlllIlllllI = lllllllllllllllIlllIIIlllIllllll - lllllllllllllllIlllIIIllllIIIIII;
        float lllllllllllllllIlllIIIlllIllllII = MathHelper.wrapAngleTo180_float(lllllllllllllllIlllIIIlllIlllllI);
        if (llIllIIlIllll(llIllIIllIIII(lllllllllllllllIlllIIIlllIllllII, -85.0F))) {
          lllllllllllllllIlllIIIlllIllllII = -85.0F;
        }
        if (llIllIIlIlllI(llIllIIllIIIl(lllllllllllllllIlllIIIlllIllllII, 85.0F))) {
          lllllllllllllllIlllIIIlllIllllII = 85.0F;
        }
        lllllllllllllllIlllIIIllllIIIIII = lllllllllllllllIlllIIIlllIllllll - lllllllllllllllIlllIIIlllIllllII;
        if (llIllIIllIIll(llIllIIllIIIl(lllllllllllllllIlllIIIlllIllllII * lllllllllllllllIlllIIIlllIllllII, 2500.0F))) {
          lllllllllllllllIlllIIIllllIIIIII += lllllllllllllllIlllIIIlllIllllII * 0.2F;
        }
      }
      float lllllllllllllllIlllIIIlllIlllIll = prevRotationPitch + (rotationPitch - prevRotationPitch) * lllllllllllllllIlllIIIlllIlIlIIl;
      lllllllllllllllIlllIIIllllIIIlll.renderLivingAt(lllllllllllllllIlllIIIllllIIIllI, lllllllllllllllIlllIIIllllIIIlIl, lllllllllllllllIlllIIIllllIIIlII, lllllllllllllllIlllIIIlllIlIllII);
      float lllllllllllllllIlllIIIlllIlllIlI = lllllllllllllllIlllIIIllllIIIlll.handleRotationFloat(lllllllllllllllIlllIIIllllIIIllI, lllllllllllllllIlllIIIlllIlIlIIl);
      lllllllllllllllIlllIIIllllIIIlll.rotateCorpse(lllllllllllllllIlllIIIllllIIIllI, lllllllllllllllIlllIIIlllIlllIlI, lllllllllllllllIlllIIIllllIIIIII, lllllllllllllllIlllIIIlllIlIlIIl);
      GlStateManager.enableRescaleNormal();
      GlStateManager.scale(-1.0F, -1.0F, 1.0F);
      lllllllllllllllIlllIIIllllIIIlll.preRenderCallback(lllllllllllllllIlllIIIllllIIIllI, lllllllllllllllIlllIIIlllIlIlIIl);
      float lllllllllllllllIlllIIIlllIlllIIl = 0.0625F;
      GlStateManager.translate(0.0F, -1.5078125F, 0.0F);
      float lllllllllllllllIlllIIIlllIlllIII = prevLimbSwingAmount + (limbSwingAmount - prevLimbSwingAmount) * lllllllllllllllIlllIIIlllIlIlIIl;
      float lllllllllllllllIlllIIIlllIllIlll = limbSwing - limbSwingAmount * (1.0F - lllllllllllllllIlllIIIlllIlIlIIl);
      if (llIllIIllIIlI(lllllllllllllllIlllIIIllllIIIllI.isChild())) {
        lllllllllllllllIlllIIIlllIllIlll *= 3.0F;
      }
      if (llIllIIllIIll(llIllIIllIIIl(lllllllllllllllIlllIIIlllIlllIII, 1.0F))) {
        lllllllllllllllIlllIIIlllIlllIII = 1.0F;
      }
      GlStateManager.enableAlpha();
      mainModel.setLivingAnimations(lllllllllllllllIlllIIIllllIIIllI, lllllllllllllllIlllIIIlllIllIlll, lllllllllllllllIlllIIIlllIlllIII, lllllllllllllllIlllIIIlllIlIlIIl);
      mainModel.setRotationAngles(lllllllllllllllIlllIIIlllIllIlll, lllllllllllllllIlllIIIlllIlllIII, lllllllllllllllIlllIIIlllIlllIlI, lllllllllllllllIlllIIIlllIlllllI, lllllllllllllllIlllIIIlllIlllIll, 0.0625F, lllllllllllllllIlllIIIllllIIIllI);
      if (llIllIIllIIlI(renderOutlines))
      {
        boolean lllllllllllllllIlllIIIlllIllIlIl = lllllllllllllllIlllIIIllllIIIlll.setScoreTeamColor(lllllllllllllllIlllIIIllllIIIllI);
        lllllllllllllllIlllIIIllllIIIlll.renderModel(lllllllllllllllIlllIIIllllIIIllI, lllllllllllllllIlllIIIlllIllIlll, lllllllllllllllIlllIIIlllIlllIII, lllllllllllllllIlllIIIlllIlllIlI, lllllllllllllllIlllIIIlllIlllllI, lllllllllllllllIlllIIIlllIlllIll, 0.0625F);
        if (llIllIIllIIlI(lllllllllllllllIlllIIIlllIllIlIl))
        {
          lllllllllllllllIlllIIIllllIIIlll.unsetScoreTeamColor();
          "".length();
          if (null == null) {}
        }
      }
      else
      {
        boolean lllllllllllllllIlllIIIlllIllIIll = lllllllllllllllIlllIIIllllIIIlll.setDoRenderBrightness(lllllllllllllllIlllIIIllllIIIllI, lllllllllllllllIlllIIIlllIlIlIIl);
        lllllllllllllllIlllIIIllllIIIlll.renderModel(lllllllllllllllIlllIIIllllIIIllI, lllllllllllllllIlllIIIlllIllIlll, lllllllllllllllIlllIIIlllIlllIII, lllllllllllllllIlllIIIlllIlllIlI, lllllllllllllllIlllIIIlllIlllllI, lllllllllllllllIlllIIIlllIlllIll, 0.0625F);
        if (llIllIIllIIlI(lllllllllllllllIlllIIIlllIllIIll)) {
          lllllllllllllllIlllIIIllllIIIlll.unsetBrightness();
        }
        GlStateManager.depthMask(lIIIllIIllII[5]);
        if ((!llIllIIllIIlI(lllllllllllllllIlllIIIllllIIIllI instanceof EntityPlayer)) || (llIllIIllIlII(((EntityPlayer)lllllllllllllllIlllIIIllllIIIllI).isSpectator()))) {
          lllllllllllllllIlllIIIllllIIIlll.renderLayers(lllllllllllllllIlllIIIllllIIIllI, lllllllllllllllIlllIIIlllIllIlll, lllllllllllllllIlllIIIlllIlllIII, lllllllllllllllIlllIIIlllIlIlIIl, lllllllllllllllIlllIIIlllIlllIlI, lllllllllllllllIlllIIIlllIlllllI, lllllllllllllllIlllIIIlllIlllIll, 0.0625F);
        }
      }
      GlStateManager.disableRescaleNormal();
      "".length();
      if (null != null) {
        return;
      }
    }
    catch (Exception lllllllllllllllIlllIIIlllIllIIIl)
    {
      logger.error(lIIIllIIlIII[lIIIllIIllII[1]], lllllllllllllllIlllIIIlllIllIIIl);
      GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
      GlStateManager.enableTexture2D();
      GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
      GlStateManager.enableCull();
      GlStateManager.popMatrix();
      if (llIllIIllIlII(renderOutlines)) {
        lllllllllllllllIlllIIIllllIIIlll.doRender(lllllllllllllllIlllIIIllllIIIllI, lllllllllllllllIlllIIIllllIIIlIl, lllllllllllllllIlllIIIllllIIIlII, lllllllllllllllIlllIIIlllIlIllII, lllllllllllllllIlllIIIllllIIIIlI, lllllllllllllllIlllIIIlllIlIlIIl);
      }
    }
  }
  
  protected void renderLayers(T lllllllllllllllIlllIIIlIlIIllIll, float lllllllllllllllIlllIIIlIlIIllIlI, float lllllllllllllllIlllIIIlIlIlIIlII, float lllllllllllllllIlllIIIlIlIlIIIll, float lllllllllllllllIlllIIIlIlIlIIIlI, float lllllllllllllllIlllIIIlIlIIlIllI, float lllllllllllllllIlllIIIlIlIIlIlIl, float lllllllllllllllIlllIIIlIlIIlllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    short lllllllllllllllIlllIIIlIlIIlIIlI = layerRenderers.iterator();
    "".length();
    if (-"  ".length() > 0) {
      return;
    }
    while (!llIllIIllIlII(lllllllllllllllIlllIIIlIlIIlIIlI.hasNext()))
    {
      LayerRenderer<T> lllllllllllllllIlllIIIlIlIIllllI = (LayerRenderer)lllllllllllllllIlllIIIlIlIIlIIlI.next();
      boolean lllllllllllllllIlllIIIlIlIIlllIl = lllllllllllllllIlllIIIlIlIlIIlll.setBrightness(lllllllllllllllIlllIIIlIlIIllIll, lllllllllllllllIlllIIIlIlIIllIII, lllllllllllllllIlllIIIlIlIIllllI.shouldCombineTextures());
      lllllllllllllllIlllIIIlIlIIllllI.doRenderLayer(lllllllllllllllIlllIIIlIlIIllIll, lllllllllllllllIlllIIIlIlIIllIlI, lllllllllllllllIlllIIIlIlIlIIlII, lllllllllllllllIlllIIIlIlIIllIII, lllllllllllllllIlllIIIlIlIlIIIlI, lllllllllllllllIlllIIIlIlIIlIllI, lllllllllllllllIlllIIIlIlIIlIlIl, lllllllllllllllIlllIIIlIlIIlllll);
      if (llIllIIllIIlI(lllllllllllllllIlllIIIlIlIIlllIl)) {
        lllllllllllllllIlllIIIlIlIlIIlll.unsetBrightness();
      }
    }
  }
  
  static
  {
    llIllIIlIlIlI();
    llIllIIlIIlIl();
    byte lllllllllllllllIlllIIlIIIIIIlIII;
    short lllllllllllllllIlllIIlIIIIIIlIIl;
    logger = LogManager.getLogger();
    field_177096_e = new DynamicTexture(lIIIllIIllII[0], lIIIllIIllII[0]);
    int[] lllllllllllllllIlllIIlIIIIIIlIll = field_177096_e.getTextureData();
    int lllllllllllllllIlllIIlIIIIIIlIlI = lIIIllIIllII[1];
    "".length();
    if (-" ".length() >= 0) {
      return;
    }
    while (!llIllIIlIlIll(lllllllllllllllIlllIIlIIIIIIlIlI, lIIIllIIllII[3]))
    {
      lllllllllllllllIlllIIlIIIIIIlIll[lllllllllllllllIlllIIlIIIIIIlIlI] = lIIIllIIllII[2];
      lllllllllllllllIlllIIlIIIIIIlIlI++;
    }
    field_177096_e.updateDynamicTexture();
  }
  
  private static int llIllIIllIIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llIllIIlIlllI(int ???)
  {
    String lllllllllllllllIlllIIIIlllllIIII;
    return ??? >= 0;
  }
  
  private static boolean llIllIIlIllll(int ???)
  {
    boolean lllllllllllllllIlllIIIIllllIlllI;
    return ??? < 0;
  }
  
  public <V extends EntityLivingBase, U extends LayerRenderer<V>> boolean addLayer(LayerRenderer lllllllllllllllIlllIIIlllllllIII)
  {
    ;
    ;
    return layerRenderers.add(lllllllllllllllIlllIIIlllllllIII);
  }
  
  private static boolean llIllIIllIlII(int ???)
  {
    char lllllllllllllllIlllIIIIlllllIIlI;
    return ??? == 0;
  }
  
  public ModelBase getMainModel()
  {
    ;
    return mainModel;
  }
  
  protected boolean setBrightness(T lllllllllllllllIlllIIIlIllllIlll, float lllllllllllllllIlllIIIlIlllIlIII, boolean lllllllllllllllIlllIIIlIlllIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float lllllllllllllllIlllIIIlIllllIIlI = lllllllllllllllIlllIIIlIllllIlll.getBrightness(lllllllllllllllIlllIIIlIlllIlIII);
    int lllllllllllllllIlllIIIlIllllIIIl = lllllllllllllllIlllIIIlIlllIlIlI.getColorMultiplier(lllllllllllllllIlllIIIlIllllIlll, lllllllllllllllIlllIIIlIllllIIlI, lllllllllllllllIlllIIIlIlllIlIII);
    if (llIllIIllIIll(lllllllllllllllIlllIIIlIllllIIIl >> lIIIllIIllII[13] & lIIIllIIllII[8]))
    {
      "".length();
      if (((114 + 79 - 111 + 59 ^ 42 + 72 - -25 + 6) & (0xEF ^ 0xB3 ^ 0xE3 ^ 0xA3 ^ -" ".length())) == 0) {
        break label137;
      }
      return (0x7B ^ 0x3D ^ 0xB0 ^ 0xC6) & (0x3A ^ 0x5D ^ 0x58 ^ 0xF ^ -" ".length());
    }
    label137:
    boolean lllllllllllllllIlllIIIlIllllIIII = lIIIllIIllII[1];
    if ((llIllIIllIllI(hurtTime)) && (llIllIIllIllI(deathTime)))
    {
      "".length();
      if (null == null) {
        break label195;
      }
      return (0x53 ^ 0x58) & (0xAC ^ 0xA7 ^ 0xFFFFFFFF);
    }
    label195:
    boolean lllllllllllllllIlllIIIlIlllIllll = lIIIllIIllII[5];
    if ((llIllIIllIlII(lllllllllllllllIlllIIIlIllllIIII)) && (llIllIIllIlII(lllllllllllllllIlllIIIlIlllIllll))) {
      return lIIIllIIllII[1];
    }
    if ((llIllIIllIlII(lllllllllllllllIlllIIIlIllllIIII)) && (llIllIIllIlII(lllllllllllllllIlllIIIlIlllIIlll))) {
      return lIIIllIIllII[1];
    }
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    GlStateManager.enableTexture2D();
    GL11.glTexEnvi(lIIIllIIllII[14], lIIIllIIllII[15], OpenGlHelper.GL_COMBINE);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_RGB, lIIIllIIllII[16]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_RGB, OpenGlHelper.defaultTexUnit);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE1_RGB, OpenGlHelper.GL_PRIMARY_COLOR);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND1_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_ALPHA, lIIIllIIllII[18]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_ALPHA, OpenGlHelper.defaultTexUnit);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_ALPHA, lIIIllIIllII[10]);
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.enableTexture2D();
    GL11.glTexEnvi(lIIIllIIllII[14], lIIIllIIllII[15], OpenGlHelper.GL_COMBINE);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_RGB, OpenGlHelper.GL_INTERPOLATE);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_RGB, OpenGlHelper.GL_CONSTANT);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE1_RGB, OpenGlHelper.GL_PREVIOUS);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE2_RGB, OpenGlHelper.GL_CONSTANT);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND1_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND2_RGB, lIIIllIIllII[10]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_ALPHA, lIIIllIIllII[18]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_ALPHA, OpenGlHelper.GL_PREVIOUS);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_ALPHA, lIIIllIIllII[10]);
    "".length();
    if (llIllIIllIIlI(lllllllllllllllIlllIIIlIlllIllll))
    {
      "".length();
      "".length();
      "".length();
      "".length();
      "".length();
      if (null != null) {
        return (114 + 94 - 120 + 76 ^ 22 + 72 - 6 + 43) & (105 + '¨' - 176 + 79 ^ '' + 7 - 55 + 61 ^ -" ".length());
      }
    }
    else
    {
      float lllllllllllllllIlllIIIlIlllIlllI = (lllllllllllllllIlllIIIlIllllIIIl >> lIIIllIIllII[13] & lIIIllIIllII[8]) / 255.0F;
      float lllllllllllllllIlllIIIlIlllIllIl = (lllllllllllllllIlllIIIlIllllIIIl >> lIIIllIIllII[0] & lIIIllIIllII[8]) / 255.0F;
      float lllllllllllllllIlllIIIlIlllIllII = (lllllllllllllllIlllIIIlIllllIIIl >> lIIIllIIllII[9] & lIIIllIIllII[8]) / 255.0F;
      float lllllllllllllllIlllIIIlIlllIlIll = (lllllllllllllllIlllIIIlIllllIIIl & lIIIllIIllII[8]) / 255.0F;
      "".length();
      "".length();
      "".length();
      "".length();
    }
    "".length();
    GL11.glTexEnv(lIIIllIIllII[14], lIIIllIIllII[19], brightnessBuffer);
    GlStateManager.setActiveTexture(OpenGlHelper.GL_TEXTURE2);
    GlStateManager.enableTexture2D();
    GlStateManager.bindTexture(field_177096_e.getGlTextureId());
    GL11.glTexEnvi(lIIIllIIllII[14], lIIIllIIllII[15], OpenGlHelper.GL_COMBINE);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_RGB, lIIIllIIllII[16]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_RGB, OpenGlHelper.GL_PREVIOUS);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE1_RGB, OpenGlHelper.lightmapTexUnit);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND1_RGB, lIIIllIIllII[17]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_COMBINE_ALPHA, lIIIllIIllII[18]);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_SOURCE0_ALPHA, OpenGlHelper.GL_PREVIOUS);
    GL11.glTexEnvi(lIIIllIIllII[14], OpenGlHelper.GL_OPERAND0_ALPHA, lIIIllIIllII[10]);
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    return lIIIllIIllII[5];
  }
  
  protected float getDeathMaxRotation(T lllllllllllllllIlllIIIlIlIIIllll)
  {
    return 90.0F;
  }
  
  protected boolean setScoreTeamColor(T lllllllllllllllIlllIIIllIlllllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIlllIIIlllIIIIlll = lIIIllIIllII[6];
    if (llIllIIllIIlI(lllllllllllllllIlllIIIllIlllllll instanceof EntityPlayer))
    {
      ScorePlayerTeam lllllllllllllllIlllIIIlllIIIIlIl = (ScorePlayerTeam)lllllllllllllllIlllIIIllIlllllll.getTeam();
      if (llIllIIllIlIl(lllllllllllllllIlllIIIlllIIIIlIl))
      {
        String lllllllllllllllIlllIIIlllIIIIlII = FontRenderer.getFormatFromString(lllllllllllllllIlllIIIlllIIIIlIl.getColorPrefix());
        if (llIllIIlIlIll(lllllllllllllllIlllIIIlllIIIIlII.length(), lIIIllIIllII[7])) {
          lllllllllllllllIlllIIIlllIIIIlll = lllllllllllllllIlllIIIlllIIIlIlI.getFontRendererFromRenderManager().getColorCode(lllllllllllllllIlllIIIlllIIIIlII.charAt(lIIIllIIllII[5]));
        }
      }
    }
    float lllllllllllllllIlllIIIlllIIIIIll = (lllllllllllllllIlllIIIlllIIIIlll >> lIIIllIIllII[0] & lIIIllIIllII[8]) / 255.0F;
    float lllllllllllllllIlllIIIlllIIIIIlI = (lllllllllllllllIlllIIIlllIIIIlll >> lIIIllIIllII[9] & lIIIllIIllII[8]) / 255.0F;
    float lllllllllllllllIlllIIIlllIIIIIIl = (lllllllllllllllIlllIIIlllIIIIlll & lIIIllIIllII[8]) / 255.0F;
    GlStateManager.disableLighting();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    GlStateManager.color(lllllllllllllllIlllIIIlllIIIIIll, lllllllllllllllIlllIIIlllIIIIIlI, lllllllllllllllIlllIIIlllIIIIIIl, 1.0F);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
    GlStateManager.disableTexture2D();
    GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
    return lIIIllIIllII[5];
  }
  
  private static int llIllIIlIllIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void transformHeldFull3DItemLayer() {}
  
  private static boolean llIllIIlIlIll(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllIlllIIIlIIIIIIIlI;
    return ??? >= i;
  }
}

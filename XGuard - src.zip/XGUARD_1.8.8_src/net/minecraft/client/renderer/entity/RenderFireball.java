package net.minecraft.client.renderer.entity;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemModelMesher;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.init.Items;
import net.minecraft.util.ResourceLocation;

public class RenderFireball
  extends Render<EntityFireball>
{
  public void doRender(EntityFireball llllllllllllllIIllIlIllIIIIIIlII, double llllllllllllllIIllIlIllIIIIIIIll, double llllllllllllllIIllIlIllIIIIlIIll, double llllllllllllllIIllIlIllIIIIIIIIl, float llllllllllllllIIllIlIllIIIIlIIIl, float llllllllllllllIIllIlIllIIIIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.pushMatrix();
    "".length();
    GlStateManager.translate((float)llllllllllllllIIllIlIllIIIIIIIll, (float)llllllllllllllIIllIlIllIIIIIIIlI, (float)llllllllllllllIIllIlIllIIIIIIIIl);
    GlStateManager.enableRescaleNormal();
    GlStateManager.scale(scale, scale, scale);
    TextureAtlasSprite llllllllllllllIIllIlIllIIIIIllll = Minecraft.getMinecraft().getRenderItem().getItemModelMesher().getParticleIcon(Items.fire_charge);
    Tessellator llllllllllllllIIllIlIllIIIIIlllI = Tessellator.getInstance();
    WorldRenderer llllllllllllllIIllIlIllIIIIIllIl = llllllllllllllIIllIlIllIIIIIlllI.getWorldRenderer();
    float llllllllllllllIIllIlIllIIIIIllII = llllllllllllllIIllIlIllIIIIIllll.getMinU();
    float llllllllllllllIIllIlIllIIIIIlIll = llllllllllllllIIllIlIllIIIIIllll.getMaxU();
    float llllllllllllllIIllIlIllIIIIIlIlI = llllllllllllllIIllIlIllIIIIIllll.getMinV();
    float llllllllllllllIIllIlIllIIIIIlIIl = llllllllllllllIIllIlIllIIIIIllll.getMaxV();
    float llllllllllllllIIllIlIllIIIIIlIII = 1.0F;
    float llllllllllllllIIllIlIllIIIIIIlll = 0.5F;
    float llllllllllllllIIllIlIllIIIIIIllI = 0.25F;
    GlStateManager.rotate(180.0F - renderManager.playerViewY, 0.0F, 1.0F, 0.0F);
    GlStateManager.rotate(-renderManager.playerViewX, 1.0F, 0.0F, 0.0F);
    llllllllllllllIIllIlIllIIIIIllIl.begin(lIIllIlIlIlII[0], DefaultVertexFormats.POSITION_TEX_NORMAL);
    llllllllllllllIIllIlIllIIIIIllIl.pos(-0.5D, -0.25D, 0.0D).tex(llllllllllllllIIllIlIllIIIIIllII, llllllllllllllIIllIlIllIIIIIlIIl).normal(0.0F, 1.0F, 0.0F).endVertex();
    llllllllllllllIIllIlIllIIIIIllIl.pos(0.5D, -0.25D, 0.0D).tex(llllllllllllllIIllIlIllIIIIIlIll, llllllllllllllIIllIlIllIIIIIlIIl).normal(0.0F, 1.0F, 0.0F).endVertex();
    llllllllllllllIIllIlIllIIIIIllIl.pos(0.5D, 0.75D, 0.0D).tex(llllllllllllllIIllIlIllIIIIIlIll, llllllllllllllIIllIlIllIIIIIlIlI).normal(0.0F, 1.0F, 0.0F).endVertex();
    llllllllllllllIIllIlIllIIIIIllIl.pos(-0.5D, 0.75D, 0.0D).tex(llllllllllllllIIllIlIllIIIIIllII, llllllllllllllIIllIlIllIIIIIlIlI).normal(0.0F, 1.0F, 0.0F).endVertex();
    llllllllllllllIIllIlIllIIIIIlllI.draw();
    GlStateManager.disableRescaleNormal();
    GlStateManager.popMatrix();
    llllllllllllllIIllIlIllIIIIlIllI.doRender(llllllllllllllIIllIlIllIIIIIIlII, llllllllllllllIIllIlIllIIIIIIIll, llllllllllllllIIllIlIllIIIIIIIlI, llllllllllllllIIllIlIllIIIIIIIIl, llllllllllllllIIllIlIllIIIIlIIIl, llllllllllllllIIllIlIllIIIIlIIII);
  }
  
  static {}
  
  private static void lllIlIllllIIlI()
  {
    lIIllIlIlIlII = new int[1];
    lIIllIlIlIlII[0] = (96 + '­' - 244 + 171 ^ '' + 8 - 125 + 167);
  }
  
  protected ResourceLocation getEntityTexture(EntityFireball llllllllllllllIIllIlIlIlllllIIll)
  {
    return TextureMap.locationBlocksTexture;
  }
  
  public RenderFireball(RenderManager llllllllllllllIIllIlIllIIIlIllII, float llllllllllllllIIllIlIllIIIlIlIII)
  {
    llllllllllllllIIllIlIllIIIlIllIl.<init>(llllllllllllllIIllIlIllIIIlIlIIl);
    scale = llllllllllllllIIllIlIllIIIlIlIII;
  }
}

package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class RenderBoat
  extends Render<EntityBoat>
{
  private static String lIIIIlIlIIIlII(String lllllllllllllllIIllllllIIlIllIII, String lllllllllllllllIIllllllIIlIlIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIllllllIIlIlllIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllllllIIlIlIlll.getBytes(StandardCharsets.UTF_8)), lIlIlIlllllI[2]), "DES");
      Cipher lllllllllllllllIIllllllIIlIlllII = Cipher.getInstance("DES");
      lllllllllllllllIIllllllIIlIlllII.init(lIlIlIlllllI[3], lllllllllllllllIIllllllIIlIlllIl);
      return new String(lllllllllllllllIIllllllIIlIlllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllllllIIlIllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIllllllIIlIllIll)
    {
      lllllllllllllllIIllllllIIlIllIll.printStackTrace();
    }
    return null;
  }
  
  static
  {
    lIIIIlIlIIlIIl();
    lIIIIlIlIIIllI();
  }
  
  private static void lIIIIlIlIIlIIl()
  {
    lIlIlIlllllI = new int[4];
    lIlIlIlllllI[0] = ((0x30 ^ 0x27) & (0xAA ^ 0xBD ^ 0xFFFFFFFF));
    lIlIlIlllllI[1] = " ".length();
    lIlIlIlllllI[2] = (76 + 55 - 89 + 139 ^ 122 + '©' - 279 + 177);
    lIlIlIlllllI[3] = "  ".length();
  }
  
  private static int lIIIIlIlIIlIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean lIIIIlIlIIlllI(int ???)
  {
    Exception lllllllllllllllIIllllllIIlIlIIIl;
    return ??? > 0;
  }
  
  private static int lIIIIlIlIIlIll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static void lIIIIlIlIIIllI()
  {
    lIlIlIlllIIl = new String[lIlIlIlllllI[1]];
    lIlIlIlllIIl[lIlIlIlllllI[0]] = lIIIIlIlIIIlII("kMwmU/krvj8rMSUsy9rGNGsietcN0O0hM7tH+rnl00w=", "PfVhx");
  }
  
  public RenderBoat(RenderManager lllllllllllllllIIllllllIlIIlIlII)
  {
    lllllllllllllllIIllllllIlIIlIlIl.<init>(lllllllllllllllIIllllllIlIIlIlII);
    shadowSize = 0.5F;
  }
  
  private static boolean lIIIIlIlIIllIl(int ???)
  {
    Exception lllllllllllllllIIllllllIIlIlIIll;
    return ??? < 0;
  }
  
  protected ResourceLocation getEntityTexture(EntityBoat lllllllllllllllIIllllllIIlllIlII)
  {
    return boatTextures;
  }
  
  public void doRender(EntityBoat lllllllllllllllIIllllllIlIIIlIII, double lllllllllllllllIIllllllIlIIIIlll, double lllllllllllllllIIllllllIlIIIIllI, double lllllllllllllllIIllllllIlIIIIlIl, float lllllllllllllllIIllllllIIllllIlI, float lllllllllllllllIIllllllIIllllIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.pushMatrix();
    GlStateManager.translate((float)lllllllllllllllIIllllllIlIIIIlll, (float)lllllllllllllllIIllllllIIlllllII + 0.25F, (float)lllllllllllllllIIllllllIlIIIIlIl);
    GlStateManager.rotate(180.0F - lllllllllllllllIIllllllIIllllIlI, 0.0F, 1.0F, 0.0F);
    float lllllllllllllllIIllllllIlIIIIIlI = lllllllllllllllIIllllllIlIIIlIII.getTimeSinceHit() - lllllllllllllllIIllllllIIllllIIl;
    float lllllllllllllllIIllllllIlIIIIIIl = lllllllllllllllIIllllllIlIIIlIII.getDamageTaken() - lllllllllllllllIIllllllIIllllIIl;
    if (lIIIIlIlIIllIl(lIIIIlIlIIlIlI(lllllllllllllllIIllllllIlIIIIIIl, 0.0F))) {
      lllllllllllllllIIllllllIlIIIIIIl = 0.0F;
    }
    if (lIIIIlIlIIlllI(lIIIIlIlIIlIll(lllllllllllllllIIllllllIlIIIIIlI, 0.0F))) {
      GlStateManager.rotate(MathHelper.sin(lllllllllllllllIIllllllIlIIIIIlI) * lllllllllllllllIIllllllIlIIIIIlI * lllllllllllllllIIllllllIlIIIIIIl / 10.0F * lllllllllllllllIIllllllIlIIIlIII.getForwardDirection(), 1.0F, 0.0F, 0.0F);
    }
    float lllllllllllllllIIllllllIlIIIIIII = 0.75F;
    GlStateManager.scale(lllllllllllllllIIllllllIlIIIIIII, lllllllllllllllIIllllllIlIIIIIII, lllllllllllllllIIllllllIlIIIIIII);
    GlStateManager.scale(1.0F / lllllllllllllllIIllllllIlIIIIIII, 1.0F / lllllllllllllllIIllllllIlIIIIIII, 1.0F / lllllllllllllllIIllllllIlIIIIIII);
    "".length();
    GlStateManager.scale(-1.0F, -1.0F, 1.0F);
    modelBoat.render(lllllllllllllllIIllllllIlIIIlIII, 0.0F, 0.0F, -0.1F, 0.0F, 0.0F, 0.0625F);
    GlStateManager.popMatrix();
    lllllllllllllllIIllllllIlIIIlIIl.doRender(lllllllllllllllIIllllllIlIIIlIII, lllllllllllllllIIllllllIlIIIIlll, lllllllllllllllIIllllllIIlllllII, lllllllllllllllIIllllllIlIIIIlIl, lllllllllllllllIIllllllIIllllIlI, lllllllllllllllIIllllllIIllllIIl);
  }
}

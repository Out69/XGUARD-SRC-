package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.monster.EntityCaveSpider;
import net.minecraft.util.ResourceLocation;

public class RenderCaveSpider
  extends RenderSpider<EntityCaveSpider>
{
  private static void lIlllIlIll()
  {
    lllIlIIl = new int[2];
    lllIlIIl[0] = ((0xC9 ^ 0x90) & (0xC9 ^ 0x90 ^ 0xFFFFFFFF));
    lllIlIIl[1] = " ".length();
  }
  
  protected ResourceLocation getEntityTexture(EntityCaveSpider lIlIIlllIIIIlIl)
  {
    return caveSpiderTextures;
  }
  
  protected void preRenderCallback(EntityCaveSpider lIlIIlllIIIlIII, float lIlIIlllIIIIlll)
  {
    GlStateManager.scale(0.7F, 0.7F, 0.7F);
  }
  
  private static void lIlllIlIlI()
  {
    lllIlIII = new String[lllIlIIl[1]];
    lllIlIII[lllIlIIl[0]] = lIlllIlIIl("OysMJxk9Kwd8CSE6HScVYD0EOggqPFswDTkrKyAcJioRIUI/IBM=", "ONtSl");
  }
  
  private static String lIlllIlIIl(String lIlIIllIllIlIll, String lIlIIllIllIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIlIIllIllIlIll = new String(Base64.getDecoder().decode(lIlIIllIllIlIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIlIIllIllIlllI = new StringBuilder();
    char[] lIlIIllIllIllIl = lIlIIllIllIlIlI.toCharArray();
    int lIlIIllIllIllII = lllIlIIl[0];
    double lIlIIllIllIIllI = lIlIIllIllIlIll.toCharArray();
    double lIlIIllIllIIlIl = lIlIIllIllIIllI.length;
    boolean lIlIIllIllIIlII = lllIlIIl[0];
    while (lIlllIllII(lIlIIllIllIIlII, lIlIIllIllIIlIl))
    {
      char lIlIIllIlllIIIl = lIlIIllIllIIllI[lIlIIllIllIIlII];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(lIlIIllIllIlllI);
  }
  
  private static boolean lIlllIllII(int ???, int arg1)
  {
    int i;
    boolean lIlIIllIlIlllll;
    return ??? < i;
  }
  
  static
  {
    lIlllIlIll();
    lIlllIlIlI();
  }
  
  public RenderCaveSpider(RenderManager lIlIIlllIIIlIlI)
  {
    lIlIIlllIIIllIl.<init>(lIlIIlllIIIlIlI);
    shadowSize *= 0.7F;
  }
}

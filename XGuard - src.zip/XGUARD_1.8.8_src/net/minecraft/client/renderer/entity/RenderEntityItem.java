package net.minecraft.client.renderer.entity;

import java.util.Random;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemModelMesher;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.client.renderer.block.model.ItemTransformVec3f;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.util.vector.Vector3f;
import pl.xguard.modification.ItemPhysics;
import pl.xguard.modules.ItemPhysicModule;

public class RenderEntityItem
  extends Render<EntityItem>
{
  private static boolean lllIIIIIlIlII(int ???)
  {
    byte lllllllllllllllIllIlIIlIIlllIIIl;
    return ??? > 0;
  }
  
  private static boolean lllIIIIIIllll(Object ???)
  {
    char lllllllllllllllIllIlIIlIIlllIlll;
    return ??? == null;
  }
  
  private static void lllIIIIIIlllI()
  {
    lIIlIIIlIIII = new int[12];
    lIIlIIIlIIII[0] = ((114 + 121 - 108 + 91 ^ 92 + 32 - 91 + 115) & (0x14 ^ 0x13 ^ 0xDF ^ 0x96 ^ -" ".length()));
    lIIlIIIlIIII[1] = " ".length();
    lIIlIIIlIIII[2] = (0x2A ^ 0x62 ^ 0x5 ^ 0x7D);
    lIIlIIIlIIII[3] = (0x71 ^ 0x37 ^ 0x3C ^ 0x7F);
    lIIlIIIlIIII[4] = (0x5 ^ 0x25);
    lIIlIIIlIIII[5] = (0xAF ^ 0xAB);
    lIIlIIIlIIII[6] = (0x8F ^ 0x9F);
    lIIlIIIlIIII[7] = "   ".length();
    lIIlIIIlIIII[8] = "  ".length();
    lIIlIIIlIIII[9] = (0xAE7F & 0x5384);
    lIIlIIIlIIII[10] = (-(0xFD75 & 0x2EBF) & 0xBF7E & 0x6FB7);
    lIIlIIIlIIII[11] = (-(0xF8F5 & 0x37FF) & 0xFBFF & 0x37F7);
  }
  
  private static boolean lllIIIIIlIlIl(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllIllIlIIlIlIIIlIll;
    return ??? >= i;
  }
  
  protected ResourceLocation getEntityTexture(EntityItem lllllllllllllllIllIlIIlIlIllIIIl)
  {
    return TextureMap.locationBlocksTexture;
  }
  
  private int func_177078_a(ItemStack lllllllllllllllIllIlIIllIIIIIIII)
  {
    ;
    ;
    int lllllllllllllllIllIlIIlIllllllll = lIIlIIIlIIII[1];
    if (lllIIIIIlIIlI(stackSize, lIIlIIIlIIII[2]))
    {
      lllllllllllllllIllIlIIlIllllllll = lIIlIIIlIIII[3];
      "".length();
      if (-" ".length() >= ((0x75 ^ 0x14) & (0x11 ^ 0x70 ^ 0xFFFFFFFF))) {
        return (0xF2 ^ 0xA0) & (0x32 ^ 0x60 ^ 0xFFFFFFFF);
      }
    }
    else if (lllIIIIIlIIlI(stackSize, lIIlIIIlIIII[4]))
    {
      lllllllllllllllIllIlIIlIllllllll = lIIlIIIlIIII[5];
      "".length();
      if ("   ".length() == "  ".length()) {
        return (0x35 ^ 0xE ^ 0x2B ^ 0x4E) & (0x55 ^ 0x5 ^ 0x6C ^ 0x62 ^ -" ".length());
      }
    }
    else if (lllIIIIIlIIlI(stackSize, lIIlIIIlIIII[6]))
    {
      lllllllllllllllIllIlIIlIllllllll = lIIlIIIlIIII[7];
      "".length();
      if ("  ".length() == ('¡' + 116 - 167 + 66 ^ 34 + 45 - -93 + 8)) {
        return (19 + 45 - -25 + 47 ^ 15 + 106 - -17 + 29) & (0xC5 ^ 0x92 ^ 0x45 ^ 0x3D ^ -" ".length());
      }
    }
    else if (lllIIIIIlIIlI(stackSize, lIIlIIIlIIII[1]))
    {
      lllllllllllllllIllIlIIlIllllllll = lIIlIIIlIIII[8];
    }
    return lllllllllllllllIllIlIIlIllllllll;
  }
  
  private static boolean lllIIIIIlIIII(int ???)
  {
    byte lllllllllllllllIllIlIIlIIlllIIll;
    return ??? == 0;
  }
  
  private int func_177077_a(EntityItem lllllllllllllllIllIlIIllIIIlIIll, double lllllllllllllllIllIlIIllIIIlIIlI, double lllllllllllllllIllIlIIllIIlIIIll, double lllllllllllllllIllIlIIllIIlIIIlI, float lllllllllllllllIllIlIIllIIlIIIIl, IBakedModel lllllllllllllllIllIlIIllIIlIIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ItemStack lllllllllllllllIllIlIIllIIIlllll = lllllllllllllllIllIlIIllIIIlIIll.getEntityItem();
    Item lllllllllllllllIllIlIIllIIIllllI = lllllllllllllllIllIlIIllIIIlllll.getItem();
    if (lllIIIIIIllll(lllllllllllllllIllIlIIllIIIllllI)) {
      return lIIlIIIlIIII[0];
    }
    boolean lllllllllllllllIllIlIIllIIIlllIl = lllllllllllllllIllIlIIllIIlIIIII.isGui3d();
    int lllllllllllllllIllIlIIllIIIlllII = lllllllllllllllIllIlIIllIIIlIlII.func_177078_a(lllllllllllllllIllIlIIllIIIlllll);
    float lllllllllllllllIllIlIIllIIIllIll = 0.25F;
    float lllllllllllllllIllIlIIllIIIllIlI = MathHelper.sin((lllllllllllllllIllIlIIllIIIlIIll.getAge() + lllllllllllllllIllIlIIllIIlIIIIl) / 10.0F + hoverStart) * 0.1F + 0.1F;
    float lllllllllllllllIllIlIIllIIIllIIl = getItemCameraTransformsgetTransformGROUNDscale.y;
    GlStateManager.translate((float)lllllllllllllllIllIlIIllIIIlIIlI, (float)lllllllllllllllIllIlIIllIIIlIIIl + lllllllllllllllIllIlIIllIIIllIlI + 0.25F * lllllllllllllllIllIlIIllIIIllIIl, (float)lllllllllllllllIllIlIIllIIlIIIlI);
    if ((!lllIIIIIlIIII(lllllllllllllllIllIlIIllIIIlllIl)) || (lllIIIIIlIIIl(renderManager.options)))
    {
      float lllllllllllllllIllIlIIllIIIllIII = ((lllllllllllllllIllIlIIllIIIlIIll.getAge() + lllllllllllllllIllIlIIllIIlIIIIl) / 20.0F + hoverStart) * 57.295776F;
      GlStateManager.rotate(lllllllllllllllIllIlIIllIIIllIII, 0.0F, 1.0F, 0.0F);
    }
    if (lllIIIIIlIIII(lllllllllllllllIllIlIIllIIIlllIl))
    {
      float lllllllllllllllIllIlIIllIIIlIlll = -0.0F * (lllllllllllllllIllIlIIllIIIlllII - lIIlIIIlIIII[1]) * 0.5F;
      float lllllllllllllllIllIlIIllIIIlIllI = -0.0F * (lllllllllllllllIllIlIIllIIIlllII - lIIlIIIlIIII[1]) * 0.5F;
      float lllllllllllllllIllIlIIllIIIlIlIl = -0.046875F * (lllllllllllllllIllIlIIllIIIlllII - lIIlIIIlIIII[1]) * 0.5F;
      GlStateManager.translate(lllllllllllllllIllIlIIllIIIlIlll, lllllllllllllllIllIlIIllIIIlIllI, lllllllllllllllIllIlIIllIIIlIlIl);
    }
    GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    return lllllllllllllllIllIlIIllIIIlllII;
  }
  
  private static boolean lllIIIIIlIIll(int ???)
  {
    int lllllllllllllllIllIlIIlIIlllIlIl;
    return ??? != 0;
  }
  
  private static boolean lllIIIIIlIIIl(Object ???)
  {
    int lllllllllllllllIllIlIIlIIlllllIl;
    return ??? != null;
  }
  
  private static boolean lllIIIIIlIIlI(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIllIlIIlIlIIIIIll;
    return ??? > i;
  }
  
  public RenderEntityItem(RenderManager lllllllllllllllIllIlIIllIIlllIIl, RenderItem lllllllllllllllIllIlIIllIIlllIll)
  {
    lllllllllllllllIllIlIIllIIlllIlI.<init>(lllllllllllllllIllIlIIllIIllllII);
    itemRenderer = lllllllllllllllIllIlIIllIIlllIll;
    shadowSize = 0.15F;
    shadowOpaque = 0.75F;
  }
  
  public void doRender(EntityItem lllllllllllllllIllIlIIlIlllIllII, double lllllllllllllllIllIlIIlIlllIlIll, double lllllllllllllllIllIlIIlIllIIIIlI, double lllllllllllllllIllIlIIlIlllIlIIl, float lllllllllllllllIllIlIIlIlllIlIII, float lllllllllllllllIllIlIIlIlllIIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lllIIIIIlIIll(ItemPhysicModule.isEnabled()))
    {
      ItemPhysics.doRender(lllllllllllllllIllIlIIlIlllIllII, lllllllllllllllIllIlIIlIlllIlIll, lllllllllllllllIllIlIIlIlllIlIlI, lllllllllllllllIllIlIIlIlllIlIIl, lllllllllllllllIllIlIIlIlllIlIII, lllllllllllllllIllIlIIlIlllIIlll);
      "".length();
      if (null == null) {}
    }
    else
    {
      ItemStack lllllllllllllllIllIlIIlIlllIIllI = lllllllllllllllIllIlIIlIlllIllII.getEntityItem();
      field_177079_e.setSeed(187L);
      boolean lllllllllllllllIllIlIIlIlllIIlIl = lIIlIIIlIIII[0];
      if (lllIIIIIlIIll(lllllllllllllllIllIlIIlIllIIIllI.bindEntityTexture(lllllllllllllllIllIlIIlIlllIllII)))
      {
        renderManager.renderEngine.getTexture(lllllllllllllllIllIlIIlIllIIIllI.getEntityTexture(lllllllllllllllIllIlIIlIlllIllII)).setBlurMipmap(lIIlIIIlIIII[0], lIIlIIIlIIII[0]);
        lllllllllllllllIllIlIIlIlllIIlIl = lIIlIIIlIIII[1];
      }
      GlStateManager.enableRescaleNormal();
      GlStateManager.alphaFunc(lIIlIIIlIIII[9], 0.1F);
      GlStateManager.enableBlend();
      GlStateManager.tryBlendFuncSeparate(lIIlIIIlIIII[10], lIIlIIIlIIII[11], lIIlIIIlIIII[1], lIIlIIIlIIII[0]);
      GlStateManager.pushMatrix();
      IBakedModel lllllllllllllllIllIlIIlIlllIIIll = itemRenderer.getItemModelMesher().getItemModel(lllllllllllllllIllIlIIlIlllIIllI);
      int lllllllllllllllIllIlIIlIlllIIIlI = lllllllllllllllIllIlIIlIllIIIllI.func_177077_a(lllllllllllllllIllIlIIlIlllIllII, lllllllllllllllIllIlIIlIlllIlIll, lllllllllllllllIllIlIIlIlllIlIlI, lllllllllllllllIllIlIIlIlllIlIIl, lllllllllllllllIllIlIIlIlllIIlll, lllllllllllllllIllIlIIlIlllIIIll);
      int lllllllllllllllIllIlIIlIlllIIIIl = lIIlIIIlIIII[0];
      "".length();
      if ((" ".length() & (" ".length() ^ 0xFFFFFFFF)) != ((0x11 ^ 0x48) & (0x27 ^ 0x7E ^ 0xFFFFFFFF))) {
        return;
      }
      while (!lllIIIIIlIlIl(lllllllllllllllIllIlIIlIlllIIIIl, lllllllllllllllIllIlIIlIlllIIIlI))
      {
        if (lllIIIIIlIIll(lllllllllllllllIllIlIIlIlllIIIll.isGui3d()))
        {
          GlStateManager.pushMatrix();
          if (lllIIIIIlIlII(lllllllllllllllIllIlIIlIlllIIIIl))
          {
            float lllllllllllllllIllIlIIlIlllIIIII = (field_177079_e.nextFloat() * 2.0F - 1.0F) * 0.15F;
            float lllllllllllllllIllIlIIlIllIlllll = (field_177079_e.nextFloat() * 2.0F - 1.0F) * 0.15F;
            float lllllllllllllllIllIlIIlIllIlllIl = (field_177079_e.nextFloat() * 2.0F - 1.0F) * 0.15F;
            GlStateManager.translate(lllllllllllllllIllIlIIlIlllIIIII, lllllllllllllllIllIlIIlIllIlllll, lllllllllllllllIllIlIIlIllIlllIl);
          }
          GlStateManager.scale(0.5F, 0.5F, 0.5F);
          lllllllllllllllIllIlIIlIlllIIIll.getItemCameraTransforms().applyTransform(ItemCameraTransforms.TransformType.GROUND);
          itemRenderer.renderItem(lllllllllllllllIllIlIIlIlllIIllI, lllllllllllllllIllIlIIlIlllIIIll);
          GlStateManager.popMatrix();
          "".length();
          if ("  ".length() != ((0x8F ^ 0xAD ^ 0x6E ^ 0x6A) & (0x94 ^ 0xBA ^ 0x6C ^ 0x64 ^ -" ".length()))) {}
        }
        else
        {
          GlStateManager.pushMatrix();
          lllllllllllllllIllIlIIlIlllIIIll.getItemCameraTransforms().applyTransform(ItemCameraTransforms.TransformType.GROUND);
          itemRenderer.renderItem(lllllllllllllllIllIlIIlIlllIIllI, lllllllllllllllIllIlIIlIlllIIIll);
          GlStateManager.popMatrix();
          float lllllllllllllllIllIlIIlIllIlllII = getItemCameraTransformsground.scale.x;
          float lllllllllllllllIllIlIIlIllIllIlI = getItemCameraTransformsground.scale.y;
          float lllllllllllllllIllIlIIlIllIIlIII = getItemCameraTransformsground.scale.z;
          GlStateManager.translate(0.0F * lllllllllllllllIllIlIIlIllIlllII, 0.0F * lllllllllllllllIllIlIIlIllIllIlI, 0.046875F * lllllllllllllllIllIlIIlIllIIlIII);
        }
        lllllllllllllllIllIlIIlIlllIIIIl++;
      }
      GlStateManager.popMatrix();
      GlStateManager.disableRescaleNormal();
      GlStateManager.disableBlend();
      "".length();
      if (lllIIIIIlIIll(lllllllllllllllIllIlIIlIlllIIlIl)) {
        renderManager.renderEngine.getTexture(lllllllllllllllIllIlIIlIllIIIllI.getEntityTexture(lllllllllllllllIllIlIIlIlllIllII)).restoreLastBlurMipmap();
      }
      lllllllllllllllIllIlIIlIllIIIllI.doRender(lllllllllllllllIllIlIIlIlllIllII, lllllllllllllllIllIlIIlIlllIlIll, lllllllllllllllIllIlIIlIlllIlIlI, lllllllllllllllIllIlIIlIlllIlIIl, lllllllllllllllIllIlIIlIlllIlIII, lllllllllllllllIllIlIIlIlllIIlll);
    }
  }
  
  static {}
}

package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelBase;
import net.minecraft.entity.passive.EntityCow;
import net.minecraft.util.ResourceLocation;

public class RenderCow
  extends RenderLiving<EntityCow>
{
  static
  {
    llIllIlIIlIlI();
    llIllIlIIIllI();
  }
  
  private static String llIllIlIIIlIl(String lllllllllllllllIlllIIIIlllIlIIII, String lllllllllllllllIlllIIIIlllIIllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlllIIIIlllIlIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlllIIIIlllIIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlllIIIIlllIlIIlI = Cipher.getInstance("Blowfish");
      lllllllllllllllIlllIIIIlllIlIIlI.init(lIIIllIlIIIl[2], lllllllllllllllIlllIIIIlllIlIIll);
      return new String(lllllllllllllllIlllIIIIlllIlIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIlllIIIIlllIlIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlllIIIIlllIlIIIl)
    {
      lllllllllllllllIlllIIIIlllIlIIIl.printStackTrace();
    }
    return null;
  }
  
  public RenderCow(RenderManager lllllllllllllllIlllIIIIllllIIIII, ModelBase lllllllllllllllIlllIIIIlllIlllll, float lllllllllllllllIlllIIIIllllIIIlI)
  {
    lllllllllllllllIlllIIIIllllIIIIl.<init>(lllllllllllllllIlllIIIIllllIIIII, lllllllllllllllIlllIIIIlllIlllll, lllllllllllllllIlllIIIIllllIIIlI);
  }
  
  protected ResourceLocation getEntityTexture(EntityCow lllllllllllllllIlllIIIIlllIlllII)
  {
    return cowTextures;
  }
  
  private static void llIllIlIIIllI()
  {
    lIIIllIIllll = new String[lIIIllIlIIIl[1]];
    lIIIllIIllll[lIIIllIlIIIl[0]] = llIllIlIIIlIl("DTBdZiqSI4pxcTmhCKXF4rb5KK98JQUB5ZfFzwFyXsE=", "ZSZBY");
  }
  
  private static void llIllIlIIlIlI()
  {
    lIIIllIlIIIl = new int[3];
    lIIIllIlIIIl[0] = ((0x37 ^ 0xF ^ 0xA3 ^ 0x8B) & (0x7D ^ 0x1B ^ 0xF1 ^ 0x87 ^ -" ".length()));
    lIIIllIlIIIl[1] = " ".length();
    lIIIllIlIIIl[2] = "  ".length();
  }
}

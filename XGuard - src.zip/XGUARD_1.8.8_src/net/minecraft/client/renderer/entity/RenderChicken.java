package net.minecraft.client.renderer.entity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.model.ModelBase;
import net.minecraft.entity.passive.EntityChicken;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class RenderChicken
  extends RenderLiving<EntityChicken>
{
  public RenderChicken(RenderManager llllllllllllllllllIlIllIIllIllII, ModelBase llllllllllllllllllIlIllIIllIlIll, float llllllllllllllllllIlIllIIllIIllI)
  {
    llllllllllllllllllIlIllIIllIllIl.<init>(llllllllllllllllllIlIllIIllIllII, llllllllllllllllllIlIllIIllIlIll, llllllllllllllllllIlIllIIllIIllI);
  }
  
  static
  {
    lIllIIllIIIl();
    lIllIIllIIII();
  }
  
  protected ResourceLocation getEntityTexture(EntityChicken llllllllllllllllllIlIllIIllIIlII)
  {
    return chickenTextures;
  }
  
  private static void lIllIIllIIIl()
  {
    llIlllllIl = new int[3];
    llIlllllIl[0] = ((0x2 ^ 0x15) & (0x7C ^ 0x6B ^ 0xFFFFFFFF));
    llIlllllIl[1] = " ".length();
    llIlllllIl[2] = "  ".length();
  }
  
  protected float handleRotationFloat(EntityChicken llllllllllllllllllIlIllIIlIllllI, float llllllllllllllllllIlIllIIlIllIIl)
  {
    ;
    ;
    ;
    ;
    float llllllllllllllllllIlIllIIlIlllII = field_70888_h + (wingRotation - field_70888_h) * llllllllllllllllllIlIllIIlIllIIl;
    float llllllllllllllllllIlIllIIlIllIll = field_70884_g + (destPos - field_70884_g) * llllllllllllllllllIlIllIIlIllIIl;
    return (MathHelper.sin(llllllllllllllllllIlIllIIlIlllII) + 1.0F) * llllllllllllllllllIlIllIIlIllIll;
  }
  
  private static String lIllIIlIllll(String llllllllllllllllllIlIllIIlIIIlIl, String llllllllllllllllllIlIllIIlIIIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIlIllIIlIIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlIllIIlIIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIlIllIIlIIIlll = Cipher.getInstance("Blowfish");
      llllllllllllllllllIlIllIIlIIIlll.init(llIlllllIl[2], llllllllllllllllllIlIllIIlIIlIII);
      return new String(llllllllllllllllllIlIllIIlIIIlll.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlIllIIlIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIlIllIIlIIIllI)
    {
      llllllllllllllllllIlIllIIlIIIllI.printStackTrace();
    }
    return null;
  }
  
  private static void lIllIIllIIII()
  {
    llIlllllII = new String[llIlllllIl[1]];
    llIlllllII[llIlllllIl[0]] = lIllIIlIllll("RlLhsWzquvc70PdGMCtoWFCOPBHQV9uxRWE6n4EmL3w=", "LdlxB");
  }
}

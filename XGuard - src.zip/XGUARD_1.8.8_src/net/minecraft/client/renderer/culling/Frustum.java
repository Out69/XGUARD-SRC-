package net.minecraft.client.renderer.culling;

import net.minecraft.util.AxisAlignedBB;

public class Frustum
  implements ICamera
{
  public Frustum(ClippingHelper llllllllllllllIIlllIlllIlllIlllI)
  {
    clippingHelper = llllllllllllllIIlllIlllIlllIlllI;
  }
  
  public void setPosition(double llllllllllllllIIlllIlllIlllIlIII, double llllllllllllllIIlllIlllIlllIIlll, double llllllllllllllIIlllIlllIlllIIllI)
  {
    ;
    ;
    ;
    ;
    xPosition = llllllllllllllIIlllIlllIlllIlIII;
    yPosition = llllllllllllllIIlllIlllIlllIIlll;
    zPosition = llllllllllllllIIlllIlllIlllIIllI;
  }
  
  public boolean isBoxInFrustum(double llllllllllllllIIlllIlllIllIllIIl, double llllllllllllllIIlllIlllIllIllIII, double llllllllllllllIIlllIlllIllIlIlll, double llllllllllllllIIlllIlllIllIIllll, double llllllllllllllIIlllIlllIllIlIlIl, double llllllllllllllIIlllIlllIllIlIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    return clippingHelper.isBoxInFrustum(llllllllllllllIIlllIlllIllIllIIl - xPosition, llllllllllllllIIlllIlllIllIllIII - yPosition, llllllllllllllIIlllIlllIllIlIIII - zPosition, llllllllllllllIIlllIlllIllIIllll - xPosition, llllllllllllllIIlllIlllIllIlIlIl - yPosition, llllllllllllllIIlllIlllIllIlIlII - zPosition);
  }
  
  public Frustum()
  {
    llllllllllllllIIlllIlllIllllIlIl.<init>(ClippingHelperImpl.getInstance());
  }
  
  public boolean isBoundingBoxInFrustum(AxisAlignedBB llllllllllllllIIlllIlllIllIIIlll)
  {
    ;
    ;
    return llllllllllllllIIlllIlllIllIIlIII.isBoxInFrustum(minX, minY, minZ, maxX, maxY, maxZ);
  }
}

package net.minecraft.client.renderer.culling;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.MathHelper;

public class ClippingHelperImpl
  extends ClippingHelper
{
  private static void lIIlIllIlllIll()
  {
    llIIIllIIIll = new int[19];
    llIIIllIIIll[0] = (0x66 ^ 0x5D ^ 0x37 ^ 0x1C);
    llIIIllIIIll[1] = ((0x54 ^ 0x37 ^ 0x66 ^ 0x20) & (0xB1 ^ 0xAE ^ 0x5C ^ 0x66 ^ -" ".length()));
    llIIIllIIIll[2] = " ".length();
    llIIIllIIIll[3] = "  ".length();
    llIIIllIIIll[4] = "   ".length();
    llIIIllIIIll[5] = (0xCBF7 & 0x3FAF);
    llIIIllIIIll[6] = (0x8BE7 & 0x7FBE);
    llIIIllIIIll[7] = (71 + 107 - 139 + 134 ^ 58 + 121 - 30 + 20);
    llIIIllIIIll[8] = (0x9C ^ 0x94);
    llIIIllIIIll[9] = (0x19 ^ 0x31 ^ 0x8A ^ 0xAE);
    llIIIllIIIll[10] = (0x65 ^ 0x9 ^ 0x41 ^ 0x28);
    llIIIllIIIll[11] = ('²' + '' - 141 + 34 ^ 60 + 99 - 137 + 176);
    llIIIllIIIll[12] = (0xD8 ^ 0x92 ^ 0x14 ^ 0x53);
    llIIIllIIIll[13] = (0x1C ^ 0x1A);
    llIIIllIIIll[14] = (0x35 ^ 0x3F);
    llIIIllIIIll[15] = (0xB7 ^ 0xB9);
    llIIIllIIIll[16] = (0x71 ^ 0x76);
    llIIIllIIIll[17] = (0xA4 ^ 0xAF);
    llIIIllIIIll[18] = (0x83 ^ 0x8C);
  }
  
  private void normalize(float[] lllllllllllllllIIIlllIIIllIIIIII)
  {
    ;
    ;
    float lllllllllllllllIIIlllIIIllIIIIIl = MathHelper.sqrt_float(lllllllllllllllIIIlllIIIllIIIIII[llIIIllIIIll[1]] * lllllllllllllllIIIlllIIIllIIIIlI[llIIIllIIIll[1]] + lllllllllllllllIIIlllIIIllIIIIlI[llIIIllIIIll[2]] * lllllllllllllllIIIlllIIIllIIIIlI[llIIIllIIIll[2]] + lllllllllllllllIIIlllIIIllIIIIlI[llIIIllIIIll[3]] * lllllllllllllllIIIlllIIIllIIIIlI[llIIIllIIIll[3]]);
    lllllllllllllllIIIlllIIIllIIIIlI[llIIIllIIIll[1]] /= lllllllllllllllIIIlllIIIllIIIIIl;
    lllllllllllllllIIIlllIIIllIIIIlI[llIIIllIIIll[2]] /= lllllllllllllllIIIlllIIIllIIIIIl;
    lllllllllllllllIIIlllIIIllIIIIlI[llIIIllIIIll[3]] /= lllllllllllllllIIIlllIIIllIIIIIl;
    lllllllllllllllIIIlllIIIllIIIIlI[llIIIllIIIll[4]] /= lllllllllllllllIIIlllIIIllIIIIIl;
  }
  
  public ClippingHelperImpl() {}
  
  static {}
  
  public void init()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    "".length();
    "".length();
    "".length();
    GlStateManager.getFloat(llIIIllIIIll[5], projectionMatrixBuffer);
    GlStateManager.getFloat(llIIIllIIIll[6], modelviewMatrixBuffer);
    float[] lllllllllllllllIIIlllIIIlIllIlII = projectionMatrix;
    float[] lllllllllllllllIIIlllIIIlIllIIll = modelviewMatrix;
    "".length();
    "".length();
    "".length();
    "".length();
    clippingMatrix[llIIIllIIIll[1]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[1]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[1]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[2]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[7]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[3]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[8]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[4]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[9]]);
    clippingMatrix[llIIIllIIIll[2]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[1]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[2]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[2]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[10]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[3]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[11]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[4]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[12]]);
    clippingMatrix[llIIIllIIIll[3]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[1]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[3]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[2]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[13]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[3]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[14]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[4]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[15]]);
    clippingMatrix[llIIIllIIIll[4]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[1]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[4]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[2]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[16]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[3]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[17]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[4]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[18]]);
    clippingMatrix[llIIIllIIIll[7]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[7]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[1]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[10]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[7]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[13]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[8]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[16]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[9]]);
    clippingMatrix[llIIIllIIIll[10]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[7]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[2]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[10]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[10]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[13]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[11]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[16]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[12]]);
    clippingMatrix[llIIIllIIIll[13]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[7]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[3]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[10]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[13]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[13]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[14]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[16]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[15]]);
    clippingMatrix[llIIIllIIIll[16]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[7]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[4]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[10]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[16]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[13]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[17]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[16]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[18]]);
    clippingMatrix[llIIIllIIIll[8]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[8]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[1]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[11]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[7]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[14]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[8]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[17]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[9]]);
    clippingMatrix[llIIIllIIIll[11]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[8]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[2]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[11]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[10]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[14]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[11]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[17]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[12]]);
    clippingMatrix[llIIIllIIIll[14]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[8]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[3]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[11]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[13]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[14]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[14]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[17]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[15]]);
    clippingMatrix[llIIIllIIIll[17]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[8]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[4]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[11]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[16]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[14]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[17]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[17]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[18]]);
    clippingMatrix[llIIIllIIIll[9]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[9]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[1]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[12]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[7]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[15]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[8]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[18]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[9]]);
    clippingMatrix[llIIIllIIIll[12]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[9]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[2]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[12]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[10]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[15]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[11]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[18]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[12]]);
    clippingMatrix[llIIIllIIIll[15]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[9]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[3]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[12]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[13]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[15]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[14]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[18]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[15]]);
    clippingMatrix[llIIIllIIIll[18]] = (lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[9]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[4]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[12]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[16]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[15]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[17]] + lllllllllllllllIIIlllIIIlIllIIll[llIIIllIIIll[18]] * lllllllllllllllIIIlllIIIlIllIlII[llIIIllIIIll[18]]);
    float[] lllllllllllllllIIIlllIIIlIllIIlI = frustum[llIIIllIIIll[1]];
    lllllllllllllllIIIlllIIIlIllIIlI[llIIIllIIIll[1]] = (clippingMatrix[llIIIllIIIll[4]] - clippingMatrix[llIIIllIIIll[1]]);
    lllllllllllllllIIIlllIIIlIllIIlI[llIIIllIIIll[2]] = (clippingMatrix[llIIIllIIIll[16]] - clippingMatrix[llIIIllIIIll[7]]);
    lllllllllllllllIIIlllIIIlIllIIlI[llIIIllIIIll[3]] = (clippingMatrix[llIIIllIIIll[17]] - clippingMatrix[llIIIllIIIll[8]]);
    lllllllllllllllIIIlllIIIlIllIIlI[llIIIllIIIll[4]] = (clippingMatrix[llIIIllIIIll[18]] - clippingMatrix[llIIIllIIIll[9]]);
    lllllllllllllllIIIlllIIIlIllIlIl.normalize(lllllllllllllllIIIlllIIIlIllIIlI);
    float[] lllllllllllllllIIIlllIIIlIllIIIl = frustum[llIIIllIIIll[2]];
    lllllllllllllllIIIlllIIIlIllIIIl[llIIIllIIIll[1]] = (clippingMatrix[llIIIllIIIll[4]] + clippingMatrix[llIIIllIIIll[1]]);
    lllllllllllllllIIIlllIIIlIllIIIl[llIIIllIIIll[2]] = (clippingMatrix[llIIIllIIIll[16]] + clippingMatrix[llIIIllIIIll[7]]);
    lllllllllllllllIIIlllIIIlIllIIIl[llIIIllIIIll[3]] = (clippingMatrix[llIIIllIIIll[17]] + clippingMatrix[llIIIllIIIll[8]]);
    lllllllllllllllIIIlllIIIlIllIIIl[llIIIllIIIll[4]] = (clippingMatrix[llIIIllIIIll[18]] + clippingMatrix[llIIIllIIIll[9]]);
    lllllllllllllllIIIlllIIIlIllIlIl.normalize(lllllllllllllllIIIlllIIIlIllIIIl);
    float[] lllllllllllllllIIIlllIIIlIllIIII = frustum[llIIIllIIIll[3]];
    lllllllllllllllIIIlllIIIlIllIIII[llIIIllIIIll[1]] = (clippingMatrix[llIIIllIIIll[4]] + clippingMatrix[llIIIllIIIll[2]]);
    lllllllllllllllIIIlllIIIlIllIIII[llIIIllIIIll[2]] = (clippingMatrix[llIIIllIIIll[16]] + clippingMatrix[llIIIllIIIll[10]]);
    lllllllllllllllIIIlllIIIlIllIIII[llIIIllIIIll[3]] = (clippingMatrix[llIIIllIIIll[17]] + clippingMatrix[llIIIllIIIll[11]]);
    lllllllllllllllIIIlllIIIlIllIIII[llIIIllIIIll[4]] = (clippingMatrix[llIIIllIIIll[18]] + clippingMatrix[llIIIllIIIll[12]]);
    lllllllllllllllIIIlllIIIlIllIlIl.normalize(lllllllllllllllIIIlllIIIlIllIIII);
    float[] lllllllllllllllIIIlllIIIlIlIllll = frustum[llIIIllIIIll[4]];
    lllllllllllllllIIIlllIIIlIlIllll[llIIIllIIIll[1]] = (clippingMatrix[llIIIllIIIll[4]] - clippingMatrix[llIIIllIIIll[2]]);
    lllllllllllllllIIIlllIIIlIlIllll[llIIIllIIIll[2]] = (clippingMatrix[llIIIllIIIll[16]] - clippingMatrix[llIIIllIIIll[10]]);
    lllllllllllllllIIIlllIIIlIlIllll[llIIIllIIIll[3]] = (clippingMatrix[llIIIllIIIll[17]] - clippingMatrix[llIIIllIIIll[11]]);
    lllllllllllllllIIIlllIIIlIlIllll[llIIIllIIIll[4]] = (clippingMatrix[llIIIllIIIll[18]] - clippingMatrix[llIIIllIIIll[12]]);
    lllllllllllllllIIIlllIIIlIllIlIl.normalize(lllllllllllllllIIIlllIIIlIlIllll);
    float[] lllllllllllllllIIIlllIIIlIlIlllI = frustum[llIIIllIIIll[7]];
    lllllllllllllllIIIlllIIIlIlIlllI[llIIIllIIIll[1]] = (clippingMatrix[llIIIllIIIll[4]] - clippingMatrix[llIIIllIIIll[3]]);
    lllllllllllllllIIIlllIIIlIlIlllI[llIIIllIIIll[2]] = (clippingMatrix[llIIIllIIIll[16]] - clippingMatrix[llIIIllIIIll[13]]);
    lllllllllllllllIIIlllIIIlIlIlllI[llIIIllIIIll[3]] = (clippingMatrix[llIIIllIIIll[17]] - clippingMatrix[llIIIllIIIll[14]]);
    lllllllllllllllIIIlllIIIlIlIlllI[llIIIllIIIll[4]] = (clippingMatrix[llIIIllIIIll[18]] - clippingMatrix[llIIIllIIIll[15]]);
    lllllllllllllllIIIlllIIIlIllIlIl.normalize(lllllllllllllllIIIlllIIIlIlIlllI);
    float[] lllllllllllllllIIIlllIIIlIlIllIl = frustum[llIIIllIIIll[10]];
    lllllllllllllllIIIlllIIIlIlIllIl[llIIIllIIIll[1]] = (clippingMatrix[llIIIllIIIll[4]] + clippingMatrix[llIIIllIIIll[3]]);
    lllllllllllllllIIIlllIIIlIlIllIl[llIIIllIIIll[2]] = (clippingMatrix[llIIIllIIIll[16]] + clippingMatrix[llIIIllIIIll[13]]);
    lllllllllllllllIIIlllIIIlIlIllIl[llIIIllIIIll[3]] = (clippingMatrix[llIIIllIIIll[17]] + clippingMatrix[llIIIllIIIll[14]]);
    lllllllllllllllIIIlllIIIlIlIllIl[llIIIllIIIll[4]] = (clippingMatrix[llIIIllIIIll[18]] + clippingMatrix[llIIIllIIIll[15]]);
    lllllllllllllllIIIlllIIIlIllIlIl.normalize(lllllllllllllllIIIlllIIIlIlIllIl);
  }
  
  public static ClippingHelper getInstance()
  {
    instance.init();
    return instance;
  }
}

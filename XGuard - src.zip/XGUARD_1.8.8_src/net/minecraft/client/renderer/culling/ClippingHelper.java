package net.minecraft.client.renderer.culling;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Base64.Decoder;

public class ClippingHelper
{
  private static int lllIIllIlIIIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public ClippingHelper() {}
  
  private static void lllIIllIIlllll()
  {
    lIIlIllIlIIIl = new int[7];
    lIIlIllIlIIIl[0] = (0xFC ^ 0xB8 ^ 0x13 ^ 0x51);
    lIIlIllIlIIIl[1] = (0x97 ^ 0x93);
    lIIlIllIlIIIl[2] = (0x5A ^ 0x4A);
    lIIlIllIlIIIl[3] = (('ª' + 117 - 250 + 179 ^ 26 + 93 - 4 + 40) & (4 + 78 - 65377 + 3 ^ 91 + 26 - 8 + 74 ^ -" ".length()));
    lIIlIllIlIIIl[4] = " ".length();
    lIIlIllIlIIIl[5] = "  ".length();
    lIIlIllIlIIIl[6] = "   ".length();
  }
  
  static
  {
    lllIIllIIlllll();
    lllIIllIIllllI();
  }
  
  private static boolean lllIIllIlIIIll(int ???, int arg1)
  {
    int i;
    String llllllllllllllIIlllIllIllIIllIll;
    return ??? < i;
  }
  
  private static void lllIIllIIllllI()
  {
    lIIlIllIlIIII = new String[lIIlIllIlIIIl[4]];
    lIIlIllIlIIII[lIIlIllIlIIIl[3]] = lllIIllIIlllIl("BisNaFp1V2JhXXI=", "EgRXj");
  }
  
  public boolean isBoxInFrustum(double llllllllllllllIIlllIllIlllIlIlll, double llllllllllllllIIlllIllIlllIlIllI, double llllllllllllllIIlllIllIlllIlIlIl, double llllllllllllllIIlllIllIlllIlIlII, double llllllllllllllIIlllIllIlllIlIIll, double llllllllllllllIIlllIllIlllIIIIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    float llllllllllllllIIlllIllIlllIlIIIl = (float)llllllllllllllIIlllIllIlllIlIlll;
    float llllllllllllllIIlllIllIlllIlIIII = (float)llllllllllllllIIlllIllIlllIlIllI;
    float llllllllllllllIIlllIllIlllIIllll = (float)llllllllllllllIIlllIllIlllIIIllI;
    float llllllllllllllIIlllIllIlllIIlllI = (float)llllllllllllllIIlllIllIlllIlIlII;
    float llllllllllllllIIlllIllIlllIIllIl = (float)llllllllllllllIIlllIllIlllIlIIll;
    float llllllllllllllIIlllIllIlllIIllII = (float)llllllllllllllIIlllIllIlllIIIIll;
    int llllllllllllllIIlllIllIlllIIlIll = lIIlIllIlIIIl[3];
    "".length();
    if (" ".length() <= ((0x59 ^ 0x6D) & (0x5B ^ 0x6F ^ 0xFFFFFFFF))) {
      return (0x84 ^ 0xA2) & (0xE7 ^ 0xC1 ^ 0xFFFFFFFF);
    }
    while (!lllIIllIlIIIlI(llllllllllllllIIlllIllIlllIIlIll, lIIlIllIlIIIl[0]))
    {
      float[] llllllllllllllIIlllIllIlllIIlIlI = frustum[llllllllllllllIIlllIllIlllIIlIll];
      if ((lllIIllIlIIIIl(lllIIllIlIIIII(llllllllllllllIIlllIllIlllIIlIIl.dot(llllllllllllllIIlllIllIlllIIlIlI, llllllllllllllIIlllIllIlllIlIIIl, llllllllllllllIIlllIllIlllIlIIII, llllllllllllllIIlllIllIlllIIllll), 0.0F))) && (lllIIllIlIIIIl(lllIIllIlIIIII(llllllllllllllIIlllIllIlllIIlIIl.dot(llllllllllllllIIlllIllIlllIIlIlI, llllllllllllllIIlllIllIlllIIlllI, llllllllllllllIIlllIllIlllIlIIII, llllllllllllllIIlllIllIlllIIllll), 0.0F))) && (lllIIllIlIIIIl(lllIIllIlIIIII(llllllllllllllIIlllIllIlllIIlIIl.dot(llllllllllllllIIlllIllIlllIIlIlI, llllllllllllllIIlllIllIlllIlIIIl, llllllllllllllIIlllIllIlllIIllIl, llllllllllllllIIlllIllIlllIIllll), 0.0F))) && (lllIIllIlIIIIl(lllIIllIlIIIII(llllllllllllllIIlllIllIlllIIlIIl.dot(llllllllllllllIIlllIllIlllIIlIlI, llllllllllllllIIlllIllIlllIIlllI, llllllllllllllIIlllIllIlllIIllIl, llllllllllllllIIlllIllIlllIIllll), 0.0F))) && (lllIIllIlIIIIl(lllIIllIlIIIII(llllllllllllllIIlllIllIlllIIlIIl.dot(llllllllllllllIIlllIllIlllIIlIlI, llllllllllllllIIlllIllIlllIlIIIl, llllllllllllllIIlllIllIlllIlIIII, llllllllllllllIIlllIllIlllIIllII), 0.0F))) && (lllIIllIlIIIIl(lllIIllIlIIIII(llllllllllllllIIlllIllIlllIIlIIl.dot(llllllllllllllIIlllIllIlllIIlIlI, llllllllllllllIIlllIllIlllIIlllI, llllllllllllllIIlllIllIlllIlIIII, llllllllllllllIIlllIllIlllIIllII), 0.0F))) && (lllIIllIlIIIIl(lllIIllIlIIIII(llllllllllllllIIlllIllIlllIIlIIl.dot(llllllllllllllIIlllIllIlllIIlIlI, llllllllllllllIIlllIllIlllIlIIIl, llllllllllllllIIlllIllIlllIIllIl, llllllllllllllIIlllIllIlllIIllII), 0.0F))) && (lllIIllIlIIIIl(lllIIllIlIIIII(llllllllllllllIIlllIllIlllIIlIIl.dot(llllllllllllllIIlllIllIlllIIlIlI, llllllllllllllIIlllIllIlllIIlllI, llllllllllllllIIlllIllIlllIIllIl, llllllllllllllIIlllIllIlllIIllII), 0.0F)))) {
        return lIIlIllIlIIIl[3];
      }
      llllllllllllllIIlllIllIlllIIlIll++;
    }
    return lIIlIllIlIIIl[4];
  }
  
  private static boolean lllIIllIlIIIlI(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIIlllIllIllIIlllll;
    return ??? >= i;
  }
  
  private static boolean lllIIllIlIIIIl(int ???)
  {
    float llllllllllllllIIlllIllIllIIllIIl;
    return ??? <= 0;
  }
  
  private float dot(float[] llllllllllllllIIlllIllIllllIllll, float llllllllllllllIIlllIllIllllIlIlI, float llllllllllllllIIlllIllIllllIlIIl, float llllllllllllllIIlllIllIllllIlIII)
  {
    ;
    ;
    ;
    ;
    return llllllllllllllIIlllIllIllllIllll[lIIlIllIlIIIl[3]] * llllllllllllllIIlllIllIllllIlIlI + llllllllllllllIIlllIllIllllIllll[lIIlIllIlIIIl[4]] * llllllllllllllIIlllIllIllllIlIIl + llllllllllllllIIlllIllIllllIllll[lIIlIllIlIIIl[5]] * llllllllllllllIIlllIllIllllIlIII + llllllllllllllIIlllIllIllllIllll[lIIlIllIlIIIl[6]];
  }
  
  private static String lllIIllIIlllIl(String llllllllllllllIIlllIllIllIlIlIll, String llllllllllllllIIlllIllIllIlIllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIIlllIllIllIlIlIll = new String(Base64.getDecoder().decode(llllllllllllllIIlllIllIllIlIlIll.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIIlllIllIllIlIlllI = new StringBuilder();
    char[] llllllllllllllIIlllIllIllIlIllIl = llllllllllllllIIlllIllIllIlIllll.toCharArray();
    int llllllllllllllIIlllIllIllIlIllII = lIIlIllIlIIIl[3];
    long llllllllllllllIIlllIllIllIlIIllI = llllllllllllllIIlllIllIllIlIlIll.toCharArray();
    boolean llllllllllllllIIlllIllIllIlIIlIl = llllllllllllllIIlllIllIllIlIIllI.length;
    byte llllllllllllllIIlllIllIllIlIIlII = lIIlIllIlIIIl[3];
    while (lllIIllIlIIIll(llllllllllllllIIlllIllIllIlIIlII, llllllllllllllIIlllIllIllIlIIlIl))
    {
      char llllllllllllllIIlllIllIllIllIIIl = llllllllllllllIIlllIllIllIlIIllI[llllllllllllllIIlllIllIllIlIIlII];
      "".length();
      "".length();
      if (((0x45 ^ 0x63) & (0xE4 ^ 0xC2 ^ 0xFFFFFFFF)) != 0) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIIlllIllIllIlIlllI);
  }
}

package net.minecraft.client.renderer;

import java.util.List;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumWorldBlockLayer;

public abstract class ChunkRenderContainer
{
  public abstract void renderChunkLayer(EnumWorldBlockLayer paramEnumWorldBlockLayer);
  
  public ChunkRenderContainer() {}
  
  public void initialize(double lllllllIlIlIlI, double lllllllIlIIlIl, double lllllllIlIlIII)
  {
    ;
    ;
    ;
    ;
    initialized = lIlIIIIll[1];
    renderChunks.clear();
    viewEntityX = lllllllIlIlIlI;
    viewEntityY = lllllllIlIIlIl;
    viewEntityZ = lllllllIlIlIII;
  }
  
  public void addRenderChunk(RenderChunk lllllllIIlIlII, EnumWorldBlockLayer lllllllIIlIllI)
  {
    ;
    ;
    "".length();
  }
  
  private static void lIIIIlIlllI()
  {
    lIlIIIIll = new int[2];
    lIlIIIIll[0] = (0xEE77 & 0x5598);
    lIlIIIIll[1] = " ".length();
  }
  
  public void preRenderChunk(RenderChunk lllllllIIlllll)
  {
    ;
    ;
    ;
    BlockPos lllllllIIllllI = lllllllIIlllll.getPosition();
    GlStateManager.translate((float)(lllllllIIllllI.getX() - viewEntityX), (float)(lllllllIIllllI.getY() - viewEntityY), (float)(lllllllIIllllI.getZ() - viewEntityZ));
  }
  
  static {}
}

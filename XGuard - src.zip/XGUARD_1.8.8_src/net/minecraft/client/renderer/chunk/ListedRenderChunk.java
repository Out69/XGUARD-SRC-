package net.minecraft.client.renderer.chunk;

import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.World;

public class ListedRenderChunk
  extends RenderChunk
{
  static {}
  
  public void deleteGlResources()
  {
    ;
    lllIlIll.deleteGlResources();
    GLAllocation.deleteDisplayLists(baseDisplayList, EnumWorldBlockLayer.values().length);
  }
  
  public int getDisplayList(EnumWorldBlockLayer lllIllll, CompiledChunk llllIIIl)
  {
    ;
    ;
    ;
    if (lIIIlIIlIIlI(llllIIIl.isLayerEmpty(llllIIlI)))
    {
      "".length();
      if (null == null) {
        break label51;
      }
      return (0xB0 ^ 0xB9) & (0x13 ^ 0x1A ^ 0xFFFFFFFF);
    }
    label51:
    return lIlIlIllIl[0];
  }
  
  private static boolean lIIIlIIlIIlI(int ???)
  {
    boolean lllIlIIl;
    return ??? == 0;
  }
  
  public ListedRenderChunk(World llllllll, RenderGlobal lllllllI, BlockPos lllllIII, int llllllII)
  {
    lIIIIIIII.<init>(llllllll, lllllIIl, lllllIII, llllllII);
  }
  
  private static void lIIIlIIlIIIl()
  {
    lIlIlIllIl = new int[1];
    lIlIlIllIl[0] = (-" ".length());
  }
}

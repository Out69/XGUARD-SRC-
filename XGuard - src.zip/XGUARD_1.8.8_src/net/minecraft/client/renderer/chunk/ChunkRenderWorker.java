package net.minecraft.client.renderer.chunk;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.concurrent.CancellationException;
import java.util.concurrent.locks.ReentrantLock;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RegionRenderCacheBuilder;
import net.minecraft.crash.CrashReport;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumWorldBlockLayer;
import org.apache.logging.log4j.Logger;

public class ChunkRenderWorker
  implements Runnable
{
  private static String lllIIIIllIIII(String lllllllllllllllIllIlIIIIlllllIII, String lllllllllllllllIllIlIIIIllllIlll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIlIIIIllllllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIIllllIlll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIllIlIIIIllllllII = Cipher.getInstance("Blowfish");
      lllllllllllllllIllIlIIIIllllllII.init(lIIlIIIlllIl[2], lllllllllllllllIllIlIIIIllllllIl);
      return new String(lllllllllllllllIllIlIIIIllllllII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIlllllIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIlIIIIlllllIll)
    {
      lllllllllllllllIllIlIIIIlllllIll.printStackTrace();
    }
    return null;
  }
  
  protected void processTask(final ChunkCompileTaskGenerator lllllllllllllllIllIlIIIlIIIllIlI)
    throws InterruptedException
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllIlIIIlIIIllIlI.getLock().lock();
    try
    {
      if (lllIIIIllIllI(lllllllllllllllIllIlIIIlIIIllIlI.getStatus(), ChunkCompileTaskGenerator.Status.PENDING))
      {
        if (lllIIIIllIlll(lllllllllllllllIllIlIIIlIIIllIlI.isFinished())) {
          LOGGER.warn(String.valueOf(new StringBuilder(lIIlIIIlllII[lIIlIIIlllIl[2]]).append(lllllllllllllllIllIlIIIlIIIllIlI.getStatus()).append(lIIlIIIlllII[lIIlIIIlllIl[3]])));
        }
        return;
      }
      lllllllllllllllIllIlIIIlIIIllIlI.setStatus(ChunkCompileTaskGenerator.Status.COMPILING);
      "".length();
      if ((0xB3 ^ 0x89 ^ 0x26 ^ 0x18) <= 0) {
        return;
      }
    }
    finally
    {
      lllllllllllllllIllIlIIIlIIIllIlI.getLock().unlock();
    }
    lllllllllllllllIllIlIIIlIIIllIlI.getLock().unlock();
    Entity lllllllllllllllIllIlIIIlIIlIIlII = Minecraft.getMinecraft().getRenderViewEntity();
    if (lllIIIIlllIII(lllllllllllllllIllIlIIIlIIlIIlII))
    {
      lllllllllllllllIllIlIIIlIIIllIlI.finish();
      "".length();
      if ("   ".length() > ((0x7D ^ 0x5A) & (0x1A ^ 0x3D ^ 0xFFFFFFFF))) {}
    }
    else
    {
      lllllllllllllllIllIlIIIlIIIllIlI.setRegionRenderCacheBuilder(lllllllllllllllIllIlIIIlIIIllIll.getRegionRenderCacheBuilder());
      float lllllllllllllllIllIlIIIlIIlIIIll = (float)posX;
      float lllllllllllllllIllIlIIIlIIlIIIlI = (float)posY + lllllllllllllllIllIlIIIlIIlIIlII.getEyeHeight();
      float lllllllllllllllIllIlIIIlIIlIIIIl = (float)posZ;
      ChunkCompileTaskGenerator.Type lllllllllllllllIllIlIIIlIIlIIIII = lllllllllllllllIllIlIIIlIIIllIlI.getType();
      if (lllIIIIlllIIl(lllllllllllllllIllIlIIIlIIlIIIII, ChunkCompileTaskGenerator.Type.REBUILD_CHUNK))
      {
        lllllllllllllllIllIlIIIlIIIllIlI.getRenderChunk().rebuildChunk(lllllllllllllllIllIlIIIlIIlIIIll, lllllllllllllllIllIlIIIlIIlIIIlI, lllllllllllllllIllIlIIIlIIlIIIIl, lllllllllllllllIllIlIIIlIIIllIlI);
        "".length();
        if ((0x40 ^ 0x45) != 0) {}
      }
      else if (lllIIIIlllIIl(lllllllllllllllIllIlIIIlIIlIIIII, ChunkCompileTaskGenerator.Type.RESORT_TRANSPARENCY))
      {
        lllllllllllllllIllIlIIIlIIIllIlI.getRenderChunk().resortTransparency(lllllllllllllllIllIlIIIlIIlIIIll, lllllllllllllllIllIlIIIlIIlIIIlI, lllllllllllllllIllIlIIIlIIlIIIIl, lllllllllllllllIllIlIIIlIIIllIlI);
      }
      lllllllllllllllIllIlIIIlIIIllIlI.getLock().lock();
      try
      {
        if (lllIIIIllIllI(lllllllllllllllIllIlIIIlIIIllIlI.getStatus(), ChunkCompileTaskGenerator.Status.COMPILING))
        {
          if (lllIIIIllIlll(lllllllllllllllIllIlIIIlIIIllIlI.isFinished())) {
            LOGGER.warn(String.valueOf(new StringBuilder(lIIlIIIlllII[lIIlIIIlllIl[4]]).append(lllllllllllllllIllIlIIIlIIIllIlI.getStatus()).append(lIIlIIIlllII[lIIlIIIlllIl[5]])));
          }
          lllllllllllllllIllIlIIIlIIIllIll.freeRenderBuilder(lllllllllllllllIllIlIIIlIIIllIlI);
          return;
        }
        lllllllllllllllIllIlIIIlIIIllIlI.setStatus(ChunkCompileTaskGenerator.Status.UPLOADING);
        "".length();
        if ((0x4F ^ 0x4B) <= -" ".length()) {
          return;
        }
      }
      finally
      {
        lllllllllllllllIllIlIIIlIIIllIlI.getLock().unlock();
      }
      lllllllllllllllIllIlIIIlIIIllIlI.getLock().unlock();
      final CompiledChunk lllllllllllllllIllIlIIIlIIIlllll = lllllllllllllllIllIlIIIlIIIllIlI.getCompiledChunk();
      ArrayList lllllllllllllllIllIlIIIlIIIllllI = Lists.newArrayList();
      if (lllIIIIlllIIl(lllllllllllllllIllIlIIIlIIlIIIII, ChunkCompileTaskGenerator.Type.REBUILD_CHUNK))
      {
        lllllllllllllllIllIlIIIlIIIlIIII = (lllllllllllllllIllIlIIIlIIIIllll = EnumWorldBlockLayer.values()).length;
        lllllllllllllllIllIlIIIlIIIlIIIl = lIIlIIIlllIl[0];
        "".length();
        if ("  ".length() < ((87 + 86 - 23 + 70 ^ 109 + 10 - 88 + 157) & (0x5E ^ 0x59 ^ 0x15 ^ 0x72 ^ -" ".length()))) {
          return;
        }
        while (!lllIIIIlllIll(lllllllllllllllIllIlIIIlIIIlIIIl, lllllllllllllllIllIlIIIlIIIlIIII))
        {
          EnumWorldBlockLayer lllllllllllllllIllIlIIIlIIIlllIl = lllllllllllllllIllIlIIIlIIIIllll[lllllllllllllllIllIlIIIlIIIlIIIl];
          if (lllIIIIlllIlI(lllllllllllllllIllIlIIIlIIIlllll.isLayerStarted(lllllllllllllllIllIlIIIlIIIlllIl))) {
            "".length();
          }
          lllllllllllllllIllIlIIIlIIIlIIIl++;
        }
        "".length();
        if (-" ".length() <= 0) {}
      }
      else if (lllIIIIlllIIl(lllllllllllllllIllIlIIIlIIlIIIII, ChunkCompileTaskGenerator.Type.RESORT_TRANSPARENCY))
      {
        "".length();
      }
      final ListenableFuture<List<Object>> lllllllllllllllIllIlIIIlIIIlllII = Futures.allAsList(lllllllllllllllIllIlIIIlIIIllllI);
      lllllllllllllllIllIlIIIlIIIllIlI.addFinishRunnable(new Runnable()
      {
        static {}
        
        private static void llIlIIlIlIIlII()
        {
          lIIIlIIllllII = new int[1];
          lIIIlIIllllII[0] = (('Ü' + 'Ê' - 411 + 229 ^ 60 + 82 - 18 + 71) & (7 + 21 - -60 + 99 ^ 44 + 85 - 116 + 123 ^ -" ".length()));
        }
        
        public void run()
        {
          ;
          "".length();
        }
      });
      Futures.addCallback(lllllllllllllllIllIlIIIlIIIlllII, new FutureCallback()
      {
        private static String llIllIIIII(String lIIlIlIlIIlllIl, String lIIlIlIlIIlllII)
        {
          try
          {
            ;
            ;
            ;
            ;
            SecretKeySpec lIIlIlIlIlIIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lIIlIlIlIIlllII.getBytes(StandardCharsets.UTF_8)), lIIIIIIII[4]), "DES");
            Cipher lIIlIlIlIlIIIIl = Cipher.getInstance("DES");
            lIIlIlIlIlIIIIl.init(lIIIIIIII[2], lIIlIlIlIlIIIlI);
            return new String(lIIlIlIlIlIIIIl.doFinal(Base64.getDecoder().decode(lIIlIlIlIIlllIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
          }
          catch (Exception lIIlIlIlIlIIIII)
          {
            lIIlIlIlIlIIIII.printStackTrace();
          }
          return null;
        }
        
        private static boolean llIllIIlII(Object ???, Object arg1)
        {
          Object localObject;
          boolean lIIlIlIIllllIlI;
          return ??? == localObject;
        }
        
        private static String llIllIIIIl(String lIIlIlIlIIIlIlI, String lIIlIlIlIIIlllI)
        {
          ;
          ;
          ;
          ;
          ;
          ;
          lIIlIlIlIIIlIlI = new String(Base64.getDecoder().decode(lIIlIlIlIIIlIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
          StringBuilder lIIlIlIlIIIllIl = new StringBuilder();
          char[] lIIlIlIlIIIllII = lIIlIlIlIIIlllI.toCharArray();
          int lIIlIlIlIIIlIll = lIIIIIIII[0];
          long lIIlIlIlIIIIlIl = lIIlIlIlIIIlIlI.toCharArray();
          String lIIlIlIlIIIIlII = lIIlIlIlIIIIlIl.length;
          Exception lIIlIlIlIIIIIll = lIIIIIIII[0];
          while (llIllIIllI(lIIlIlIlIIIIIll, lIIlIlIlIIIIlII))
          {
            char lIIlIlIlIIlIIII = lIIlIlIlIIIIlIl[lIIlIlIlIIIIIll];
            "".length();
            "".length();
            if (null != null) {
              return null;
            }
          }
          return String.valueOf(lIIlIlIlIIIllIl);
        }
        
        static
        {
          llIllIIIll();
          llIllIIIlI();
        }
        
        private static boolean llIllIIllI(int ???, int arg1)
        {
          int i;
          short lIIlIlIIllllllI;
          return ??? < i;
        }
        
        public void onFailure(Throwable lIIlIlIlIlIllIl)
        {
          ;
          ;
          ChunkRenderWorker.this.freeRenderBuilder(lllllllllllllllIllIlIIIlIIIllIlI);
          if ((llIllIIlIl(lIIlIlIlIlIllIl instanceof CancellationException)) && (llIllIIlIl(lIIlIlIlIlIllIl instanceof InterruptedException))) {
            Minecraft.getMinecraft().crashed(CrashReport.makeCrashReport(lIIlIlIlIlIllIl, llllllll[lIIIIIIII[2]]));
          }
        }
        
        private static void llIllIIIll()
        {
          lIIIIIIII = new int[5];
          lIIIIIIII[0] = ((126 + 28 - 152 + 128 ^ 56 + 54 - 24 + 112) & (0x5D ^ 0x27 ^ 0x63 ^ 0x5D ^ -" ".length()));
          lIIIIIIII[1] = " ".length();
          lIIIIIIII[2] = "  ".length();
          lIIIIIIII[3] = "   ".length();
          lIIIIIIII[4] = (0x4D ^ 0x45);
        }
        
        public void onSuccess(List<Object> lIIlIlIlIllIIll)
        {
          ;
          ChunkRenderWorker.this.freeRenderBuilder(lllllllllllllllIllIlIIIlIIIllIlI);
          lllllllllllllllIllIlIIIlIIIllIlI.getLock().lock();
          try
          {
            if (llIllIIlII(lllllllllllllllIllIlIIIlIIIllIlI.getStatus(), ChunkCompileTaskGenerator.Status.UPLOADING))
            {
              lllllllllllllllIllIlIIIlIIIllIlI.setStatus(ChunkCompileTaskGenerator.Status.DONE);
              lllllllllllllllIllIlIIIlIIIllIlI.getLock().unlock();
              "".length();
              if (null == null) {
                break label169;
              }
              return;
            }
            if (llIllIIlIl(lllllllllllllllIllIlIIIlIIIllIlI.isFinished()))
            {
              ChunkRenderWorker.LOGGER.warn(String.valueOf(new StringBuilder(llllllll[lIIIIIIII[0]]).append(lllllllllllllllIllIlIIIlIIIllIlI.getStatus()).append(llllllll[lIIIIIIII[1]])));
              "".length();
              if (" ".length() < 0) {
                return;
              }
            }
          }
          finally
          {
            lllllllllllllllIllIlIIIlIIIllIlI.getLock().unlock();
          }
          lllllllllllllllIllIlIIIlIIIllIlI.getLock().unlock();
          return;
          label169:
          lllllllllllllllIllIlIIIlIIIllIlI.getRenderChunk().setCompiledChunk(lllllllllllllllIllIlIIIlIIIlllll);
        }
        
        private static boolean llIllIIlIl(int ???)
        {
          double lIIlIlIIllllIII;
          return ??? == 0;
        }
        
        private static void llIllIIIlI()
        {
          llllllll = new String[lIIIIIIII[3]];
          llllllll[lIIIIIIII[0]] = llIllIIIII("SIk5ffRgWDjsleHAOM1fD8yiD1KFn1x+", "IcKET");
          llllllll[lIIIIIIII[1]] = llIllIIIIl("UR47HBdRIHMcAQEMMA0cFUk6DVkFBnMbHFEcIxUWEA06Fx5KSTIbFgMdOhceUR0yChI=", "qiSyy");
          llllllll[lIIIIIIII[2]] = llIllIIIII("5ydyiXZNh/Vj3Ec2SLH+uw==", "HxCJQ");
        }
      });
    }
  }
  
  public ChunkRenderWorker(ChunkRenderDispatcher lllllllllllllllIllIlIIIlIlIIIlll)
  {
    lllllllllllllllIllIlIIIlIlIIlIII.<init>(lllllllllllllllIllIlIIIlIlIIIlll, null);
  }
  
  private static boolean lllIIIIllllII(Object ???)
  {
    float lllllllllllllllIllIlIIIIlIlllllI;
    return ??? != null;
  }
  
  private void freeRenderBuilder(ChunkCompileTaskGenerator lllllllllllllllIllIlIIIlIIIIlIII)
  {
    ;
    ;
    if (lllIIIIlllIII(regionRenderCacheBuilder)) {
      chunkRenderDispatcher.freeRenderBuilder(lllllllllllllllIllIlIIIlIIIIlIII.getRegionRenderCacheBuilder());
    }
  }
  
  private static boolean lllIIIIllllIl(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIllIlIIIIllIIlIII;
    return ??? < i;
  }
  
  private static void lllIIIIllIIll()
  {
    lIIlIIIlllII = new String[lIIlIIIlllIl[6]];
    lIIlIIIlllII[lIIlIIIlllIl[0]] = lllIIIIlIllll("AjIJEyE4KAFDNSQjRhc+cS8IFzQjNBMTJQ==", "QFfcQ");
    lIIlIIIlllII[lIIlIIIlllIl[1]] = lllIIIIlIllll("ERQMByw6Gx9EJzsAFg83", "SuxdD");
    lIIlIIIlllII[lIIlIIIlllIl[2]] = lllIIIIlIllll("MSsYGThSMQgZNxcxTQMyAShNADIBYw==", "rCmwS");
    lIIlIIIlllII[lIIlIIIlllIl[3]] = lllIIIIllIIII("MIFGGfC6UD5R25SgUm+FZk/Blj51nEDtVDhfbBbSGEn7IWYxMFXVJfvWsDRrZjryPR/3zLkZxD8=", "RvYwM");
    lIIlIIIlllII[lIIlIIIlllIl[4]] = lllIIIIllIIlI("gprrR28poNdv2mYeX5bNi/fT4GhbTIRS", "TezwV");
    lIIlIIIlllII[lIIlIIIlllIl[5]] = lllIIIIllIIlI("UBjtx1qppYaJigGntyYbwLxkW/g2R6dDNiiflW/OO3iJ+sKttC4U1UNQzDnbQ0RQ0fzTLLWhv9k=", "iHNOJ");
  }
  
  private static String lllIIIIlIllll(String lllllllllllllllIllIlIIIIllIllIII, String lllllllllllllllIllIlIIIIllIlllII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllIlIIIIllIllIII = new String(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIllIllIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIlIIIIllIllIll = new StringBuilder();
    char[] lllllllllllllllIllIlIIIIllIllIlI = lllllllllllllllIllIlIIIIllIlllII.toCharArray();
    int lllllllllllllllIllIlIIIIllIllIIl = lIIlIIIlllIl[0];
    byte lllllllllllllllIllIlIIIIllIlIIll = lllllllllllllllIllIlIIIIllIllIII.toCharArray();
    short lllllllllllllllIllIlIIIIllIlIIlI = lllllllllllllllIllIlIIIIllIlIIll.length;
    byte lllllllllllllllIllIlIIIIllIlIIIl = lIIlIIIlllIl[0];
    while (lllIIIIllllIl(lllllllllllllllIllIlIIIIllIlIIIl, lllllllllllllllIllIlIIIIllIlIIlI))
    {
      char lllllllllllllllIllIlIIIIllIllllI = lllllllllllllllIllIlIIIIllIlIIll[lllllllllllllllIllIlIIIIllIlIIIl];
      "".length();
      "".length();
      if (" ".length() < ((103 + 19 - 93 + 125 ^ 95 + 15 - 38 + 112) & (0x7F ^ 0x25 ^ 0xEA ^ 0x92 ^ -" ".length()))) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIllIlIIIIllIllIll);
  }
  
  private static boolean lllIIIIlllIIl(Object ???, Object arg1)
  {
    Object localObject;
    float lllllllllllllllIllIlIIIIllIIIIII;
    return ??? == localObject;
  }
  
  private static boolean lllIIIIllIlll(int ???)
  {
    char lllllllllllllllIllIlIIIIlIlllIII;
    return ??? == 0;
  }
  
  private static String lllIIIIllIIlI(String lllllllllllllllIllIlIIIIlllIlIll, String lllllllllllllllIllIlIIIIlllIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIlIIIIllllIIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIlIIIIlllIllII.getBytes(StandardCharsets.UTF_8)), lIIlIIIlllIl[7]), "DES");
      Cipher lllllllllllllllIllIlIIIIlllIllll = Cipher.getInstance("DES");
      lllllllllllllllIllIlIIIIlllIllll.init(lIIlIIIlllIl[2], lllllllllllllllIllIlIIIIllllIIII);
      return new String(lllllllllllllllIllIlIIIIlllIllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIlIIIIlllIlIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIlIIIIlllIlllI)
    {
      lllllllllllllllIllIlIIIIlllIlllI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIIIIlllIlI(int ???)
  {
    int lllllllllllllllIllIlIIIIlIlllIlI;
    return ??? != 0;
  }
  
  public void run()
  {
    try
    {
      do
      {
        ;
        ;
        ;
        lllllllllllllllIllIlIIIlIIlllIlI.processTask(chunkRenderDispatcher.getNextChunkUpdate());
        "".length();
      } while (-" ".length() <= "  ".length());
      return;
    }
    catch (InterruptedException lllllllllllllllIllIlIIIlIIlllIIl)
    {
      LOGGER.debug(lIIlIIIlllII[lIIlIIIlllIl[0]]);
      return;
    }
    catch (Throwable lllllllllllllllIllIlIIIlIIlllIII)
    {
      CrashReport lllllllllllllllIllIlIIIlIIllIlll = CrashReport.makeCrashReport(lllllllllllllllIllIlIIIlIIlllIII, lIIlIIIlllII[lIIlIIIlllIl[1]]);
      Minecraft.getMinecraft().crashed(Minecraft.getMinecraft().addGraphicsAndWorldToCrashReport(lllllllllllllllIllIlIIIlIIllIlll));
    }
  }
  
  private static boolean lllIIIIllIllI(Object ???, Object arg1)
  {
    Object localObject;
    String lllllllllllllllIllIlIIIIllIIIlII;
    return ??? != localObject;
  }
  
  private static boolean lllIIIIlllIII(Object ???)
  {
    byte lllllllllllllllIllIlIIIIlIllllII;
    return ??? == null;
  }
  
  private RegionRenderCacheBuilder getRegionRenderCacheBuilder()
    throws InterruptedException
  {
    ;
    if (lllIIIIllllII(regionRenderCacheBuilder))
    {
      "".length();
      if (-" ".length() == -" ".length()) {
        break label46;
      }
      return null;
    }
    label46:
    return chunkRenderDispatcher.allocateRenderBuilder();
  }
  
  public ChunkRenderWorker(ChunkRenderDispatcher lllllllllllllllIllIlIIIlIlIIIIlI, RegionRenderCacheBuilder lllllllllllllllIllIlIIIlIlIIIIIl)
  {
    chunkRenderDispatcher = lllllllllllllllIllIlIIIlIIllllll;
    regionRenderCacheBuilder = lllllllllllllllIllIlIIIlIlIIIIIl;
  }
  
  static
  {
    lllIIIIllIlIl();
    lllIIIIllIIll();
  }
  
  private static void lllIIIIllIlIl()
  {
    lIIlIIIlllIl = new int[8];
    lIIlIIIlllIl[0] = (('' + 110 - 166 + 102 ^ 101 + 22 - 94 + 140) & (0x2D ^ 0x32 ^ "  ".length() ^ -" ".length()));
    lIIlIIIlllIl[1] = " ".length();
    lIIlIIIlllIl[2] = "  ".length();
    lIIlIIIlllIl[3] = "   ".length();
    lIIlIIIlllIl[4] = (0x19 ^ 0x1D);
    lIIlIIIlllIl[5] = (0xB ^ 0xE);
    lIIlIIIlllIl[6] = (0x31 ^ 0x37);
    lIIlIIIlllIl[7] = (0xA4 ^ 0xAC);
  }
  
  private static boolean lllIIIIlllIll(int ???, int arg1)
  {
    int i;
    String lllllllllllllllIllIlIIIIllIIllII;
    return ??? >= i;
  }
}

package net.minecraft.client.renderer.chunk;

import com.google.common.collect.Sets;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockCactus;
import net.minecraft.block.BlockRedstoneWire;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RegionRenderCache;
import net.minecraft.client.renderer.RegionRenderCacheBuilder;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.vertex.VertexBuffer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumWorldBlockLayer;
import net.minecraft.world.World;
import optfine.BlockPosM;
import optfine.Reflector;
import optfine.ReflectorMethod;

public class RenderChunk
{
  private static boolean lllIllllIlIII(int ???, int arg1)
  {
    int i;
    char lllllllllllllllIlIllIllllIlIlIlI;
    return ??? != i;
  }
  
  private static String lllIlllIlIlll(String lllllllllllllllIlIllIlllllIIlIIl, String lllllllllllllllIlIllIlllllIIlIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIlIllIlllllIIlllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIlIllIlllllIIlIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllllllllllllllIlIllIlllllIIllIl = Cipher.getInstance("Blowfish");
      lllllllllllllllIlIllIlllllIIllIl.init(lIIllIlIlllI[7], lllllllllllllllIlIllIlllllIIlllI);
      return new String(lllllllllllllllIlIllIlllllIIllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIlIllIlllllIIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIlIllIlllllIIllII)
    {
      lllllllllllllllIlIllIlllllIIllII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllIlllIlllIl(int ???)
  {
    String lllllllllllllllIlIllIllllIlIlllI;
    return ??? == 0;
  }
  
  private static boolean lllIllllIIIII(int ???, int arg1)
  {
    int i;
    short lllllllllllllllIlIllIlllllIIIIlI;
    return ??? == i;
  }
  
  public void multModelviewMatrix()
  {
    ;
    GlStateManager.multMatrix(modelviewMatrix);
  }
  
  public void setPosition(BlockPos lllllllllllllllIlIlllIIIllIIIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIlIlllIIIllIIIlll.stopCompileTask();
    position = lllllllllllllllIlIlllIIIllIIIIIl;
    boundingBox = new AxisAlignedBB(lllllllllllllllIlIlllIIIllIIIIIl, lllllllllllllllIlIlllIIIllIIIIIl.add(lIIllIlIlllI[1], lIIllIlIlllI[1], lIIllIlIlllI[1]));
    EnumFacing[] lllllllllllllllIlIlllIIIllIIIlIl = EnumFacing.values();
    int lllllllllllllllIlIlllIIIllIIIlII = lllllllllllllllIlIlllIIIllIIIlIl.length;
    lllllllllllllllIlIlllIIIllIIIlll.initModelviewMatrix();
    int lllllllllllllllIlIlllIIIllIIIIll = lIIllIlIlllI[0];
    "".length();
    if (-(0x5C ^ 0x58) > 0) {
      return;
    }
    while (!lllIlllIlllll(lllllllllllllllIlIlllIIIllIIIIll, positionOffsets16.length))
    {
      positionOffsets16[lllllllllllllllIlIlllIIIllIIIIll] = null;
      lllllllllllllllIlIlllIIIllIIIIll++;
    }
  }
  
  private void initModelviewMatrix()
  {
    ;
    ;
    GlStateManager.pushMatrix();
    GlStateManager.loadIdentity();
    float lllllllllllllllIlIlllIIIIIIlIIIl = 1.000001F;
    GlStateManager.translate(-8.0F, -8.0F, -8.0F);
    GlStateManager.scale(lllllllllllllllIlIlllIIIIIIlIIIl, lllllllllllllllIlIlllIIIIIIlIIIl, lllllllllllllllIlIlllIIIIIIlIIIl);
    GlStateManager.translate(8.0F, 8.0F, 8.0F);
    GlStateManager.getFloat(lIIllIlIlllI[6], modelviewMatrix);
    GlStateManager.popMatrix();
  }
  
  public BlockPos func_181701_a(EnumFacing lllllllllllllllIlIllIllllllIIllI)
  {
    ;
    ;
    return lllllllllllllllIlIllIllllllIIlll.getPositionOffset16(lllllllllllllllIlIllIllllllIIllI);
  }
  
  public ChunkCompileTaskGenerator makeCompileTaskChunk()
  {
    ;
    ;
    lockCompileTask.lock();
    try
    {
      lllllllllllllllIlIlllIIIIlIIIIII.finishCompileTask();
      compileTask = new ChunkCompileTaskGenerator(lllllllllllllllIlIlllIIIIlIIIIII, ChunkCompileTaskGenerator.Type.REBUILD_CHUNK);
      ChunkCompileTaskGenerator lllllllllllllllIlIlllIIIIlIIIIlI = compileTask;
      "".length();
      if ((0xA0 ^ 0xA4) <= " ".length()) {
        return null;
      }
    }
    finally
    {
      lockCompileTask.unlock();
    }
    ChunkCompileTaskGenerator lllllllllllllllIlIlllIIIIlIIIIIl;
    lockCompileTask.unlock();
    return lllllllllllllllIlIlllIIIIlIIIIIl;
  }
  
  protected void finishCompileTask()
  {
    ;
    lockCompileTask.lock();
    try
    {
      if ((lllIllllIIIlI(compileTask)) && (lllIllllIIlIl(compileTask.getStatus(), ChunkCompileTaskGenerator.Status.DONE)))
      {
        compileTask.finish();
        compileTask = null;
        "".length();
        if ("  ".length() <= -" ".length()) {
          return;
        }
      }
    }
    finally
    {
      lockCompileTask.unlock();
    }
    lockCompileTask.unlock();
  }
  
  private static boolean lllIlllIllllI(int ???)
  {
    boolean lllllllllllllllIlIllIllllIllIIII;
    return ??? != 0;
  }
  
  private static boolean lllIllllIlIIl(Object ???, Object arg1)
  {
    Object localObject;
    Exception lllllllllllllllIlIllIllllIllIlII;
    return ??? == localObject;
  }
  
  public void stopCompileTask()
  {
    ;
    lllllllllllllllIlIllIllllllllllI.finishCompileTask();
    compiledChunk = CompiledChunk.DUMMY;
  }
  
  public void rebuildChunk(float lllllllllllllllIlIlllIIIlIIIllII, float lllllllllllllllIlIlllIIIlIIIlIll, float lllllllllllllllIlIlllIIIIllIIllI, ChunkCompileTaskGenerator lllllllllllllllIlIlllIIIlIIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    CompiledChunk lllllllllllllllIlIlllIIIlIIIlIII = new CompiledChunk();
    boolean lllllllllllllllIlIlllIIIlIIIIlll = lIIllIlIlllI[3];
    BlockPos lllllllllllllllIlIlllIIIlIIIIllI = position;
    BlockPos lllllllllllllllIlIlllIIIlIIIIlIl = lllllllllllllllIlIlllIIIlIIIIllI.add(lIIllIlIlllI[4], lIIllIlIlllI[4], lIIllIlIlllI[4]);
    lllllllllllllllIlIlllIIIlIIIlIIl.getLock().lock();
    try
    {
      if (lllIllllIIlIl(lllllllllllllllIlIlllIIIlIIIlIIl.getStatus(), ChunkCompileTaskGenerator.Status.COMPILING)) {
        return;
      }
      if (lllIllllIIllI(world)) {
        return;
      }
      RegionRenderCache lllllllllllllllIlIlllIIIlIIIIlII = new RegionRenderCache(world, lllllllllllllllIlIlllIIIlIIIIllI.add(lIIllIlIlllI[2], lIIllIlIlllI[2], lIIllIlIlllI[2]), lllllllllllllllIlIlllIIIlIIIIlIl.add(lIIllIlIlllI[3], lIIllIlIlllI[3], lIIllIlIlllI[3]), lIIllIlIlllI[3]);
      lllllllllllllllIlIlllIIIlIIIlIIl.setCompiledChunk(lllllllllllllllIlIlllIIIlIIIlIII);
      "".length();
      if ("  ".length() < ((0x6B ^ 0x73) & (0x92 ^ 0x8A ^ 0xFFFFFFFF))) {
        return;
      }
    }
    finally
    {
      lllllllllllllllIlIlllIIIlIIIlIIl.getLock().unlock();
    }
    RegionRenderCache lllllllllllllllIlIlllIIIlIIIIIll;
    lllllllllllllllIlIlllIIIlIIIlIIl.getLock().unlock();
    VisGraph lllllllllllllllIlIlllIIIlIIIIIlI = new VisGraph();
    HashSet lllllllllllllllIlIlllIIIlIIIIIIl = Sets.newHashSet();
    if (lllIlllIlllIl(lllllllllllllllIlIlllIIIlIIIIIll.extendedLevelsInChunkCache()))
    {
      renderChunksUpdated += lIIllIlIlllI[3];
      boolean[] lllllllllllllllIlIlllIIIlIIIIIII = new boolean[EnumWorldBlockLayer.values().length];
      BlockRendererDispatcher lllllllllllllllIlIlllIIIIlllllll = Minecraft.getMinecraft().getBlockRendererDispatcher();
      lllllllllllllllIlIlllIIIIllllllI = BlockPosM.getAllInBoxMutable(lllllllllllllllIlIlllIIIlIIIIllI, lllllllllllllllIlIlllIIIlIIIIlIl).iterator();
      boolean lllllllllllllllIlIlllIIIIlllllIl = Reflector.ForgeBlock_hasTileEntity.exists();
      boolean lllllllllllllllIlIlllIIIIlllllII = Reflector.ForgeBlock_canRenderInLayer.exists();
      boolean lllllllllllllllIlIlllIIIIllllIll = Reflector.ForgeHooksClient_setRenderLayer.exists();
      "".length();
      if (((0xA9 ^ 0x83 ^ 0xEF ^ 0xA5) & (7 + '' - 41 + 150 ^ 28 + 38 - 33 + 125 ^ -" ".length())) >= "  ".length()) {
        return;
      }
      boolean lllllllllllllllIlIlllIIIIlllIllI;
      label921:
      while (!lllIlllIlllIl(lllllllllllllllIlIlllIIIIllllllI.hasNext()))
      {
        BlockPosM lllllllllllllllIlIlllIIIIllllIlI = (BlockPosM)lllllllllllllllIlIlllIIIIllllllI.next();
        lllllllllllllllIlIlllIIIIllllIIl = lllllllllllllllIlIlllIIIlIIIIIll.getBlockState(lllllllllllllllIlIlllIIIIllllIlI);
        lllllllllllllllIlIlllIIIIllllIII = lllllllllllllllIlIlllIIIIllllIIl.getBlock();
        if (lllIlllIllllI(lllllllllllllllIlIlllIIIIllllIII.isOpaqueCube())) {
          lllllllllllllllIlIlllIIIlIIIIIlI.func_178606_a(lllllllllllllllIlIlllIIIIllllIlI);
        }
        if (lllIlllIllllI(lllllllllllllllIlIlllIIIIlllllIl))
        {
          boolean lllllllllllllllIlIlllIIIIlllIlll = Reflector.callBoolean(lllllllllllllllIlIlllIIIIllllllI, Reflector.ForgeBlock_hasTileEntity, new Object[] { lllllllllllllllIlIlllIIIIlllllll });
          "".length();
          if ((0xAC ^ 0xA8) != ((0x7E ^ 0x1C) & (0x5 ^ 0x67 ^ 0xFFFFFFFF))) {}
        }
        else
        {
          lllllllllllllllIlIlllIIIIlllIllI = lllllllllllllllIlIlllIIIIllllIII.hasTileEntity();
        }
        if (lllIlllIllllI(lllllllllllllllIlIlllIIIIlllIllI))
        {
          TileEntity lllllllllllllllIlIlllIIIIlllIlIl = lllllllllllllllIlIlllIIIlIIIIIll.getTileEntity(new BlockPos(lllllllllllllllIlIlllIIIIllllIlI));
          TileEntitySpecialRenderer lllllllllllllllIlIlllIIIIlllIlII = TileEntityRendererDispatcher.instance.getSpecialRenderer(lllllllllllllllIlIlllIIIIlllIlIl);
          if ((lllIllllIIIlI(lllllllllllllllIlIlllIIIIlllIlIl)) && (lllIllllIIIlI(lllllllllllllllIlIlllIIIIlllIlII)))
          {
            lllllllllllllllIlIlllIIIlIIIlIII.addTileEntity(lllllllllllllllIlIlllIIIIlllIlIl);
            if (lllIlllIllllI(lllllllllllllllIlIlllIIIIlllIlII.func_181055_a())) {
              "".length();
            }
          }
        }
        EnumWorldBlockLayer[] lllllllllllllllIlIlllIIIIlllIIlI;
        if (lllIlllIllllI(lllllllllllllllIlIlllIIIIlllllII))
        {
          EnumWorldBlockLayer[] lllllllllllllllIlIlllIIIIlllIIll = ENUM_WORLD_BLOCK_LAYERS;
          "".length();
          if (null == null) {}
        }
        else
        {
          lllllllllllllllIlIlllIIIIlllIIlI = blockLayersSingle;
          lllllllllllllllIlIlllIIIIlllIIlI[lIIllIlIlllI[0]] = lllllllllllllllIlIlllIIIIllllIII.getBlockLayer();
        }
        int lllllllllllllllIlIlllIIIIlllIIIl = lIIllIlIlllI[0];
        "".length();
        if (((60 + 2 - -44 + 31 ^ 35 + 77 - 2 + 60) & (0xBE ^ 0x99 ^ 0x4 ^ 0x0 ^ -" ".length())) != (('' + '' - 208 + 126 ^ '' + 86 - 213 + 133) & (0xD9 ^ 0x8E ^ 0x83 ^ 0x8F ^ -" ".length()))) {
          return;
        }
        while (!lllIlllIlllll(lllllllllllllllIlIlllIIIIlllIIIl, lllllllllllllllIlIlllIIIIlllIIlI.length))
        {
          EnumWorldBlockLayer lllllllllllllllIlIlllIIIIlllIIII = lllllllllllllllIlIlllIIIIlllIIlI[lllllllllllllllIlIlllIIIIlllIIIl];
          if (lllIlllIllllI(lllllllllllllllIlIlllIIIIlllllII))
          {
            boolean lllllllllllllllIlIlllIIIIllIllll = Reflector.callBoolean(lllllllllllllllIlIlllIIIIllllIII, Reflector.ForgeBlock_canRenderInLayer, new Object[] { lllllllllllllllIlIlllIIIIlllIIII });
            if (lllIlllIlllIl(lllllllllllllllIlIlllIIIIllIllll))
            {
              "".length();
              if (-(0xC6 ^ 0xC2) < 0) {
                break label921;
              }
              return;
            }
          }
          lllllllllllllllIlIlllIIIIlllIIII = lllllllllllllllIlIlllIIIlIIIllIl.fixBlockLayer(lllllllllllllllIlIlllIIIIllllIII, lllllllllllllllIlIlllIIIIlllIIII);
          if (lllIlllIllllI(lllllllllllllllIlIlllIIIIllllIll)) {
            Reflector.callVoid(Reflector.ForgeHooksClient_setRenderLayer, new Object[] { lllllllllllllllIlIlllIIIIlllIIII });
          }
          int lllllllllllllllIlIlllIIIIllIlllI = lllllllllllllllIlIlllIIIIlllIIII.ordinal();
          if (lllIllllIlIII(lllllllllllllllIlIlllIIIIllllIII.getRenderType(), lIIllIlIlllI[2]))
          {
            WorldRenderer lllllllllllllllIlIlllIIIIllIllIl = lllllllllllllllIlIlllIIIlIIIlIIl.getRegionRenderCacheBuilder().getWorldRendererByLayerId(lllllllllllllllIlIlllIIIIllIlllI);
            lllllllllllllllIlIlllIIIIllIllIl.setBlockLayer(lllllllllllllllIlIlllIIIIlllIIII);
            if (lllIlllIlllIl(lllllllllllllllIlIlllIIIlIIIlIII.isLayerStarted(lllllllllllllllIlIlllIIIIlllIIII)))
            {
              lllllllllllllllIlIlllIIIlIIIlIII.setLayerStarted(lllllllllllllllIlIlllIIIIlllIIII);
              lllllllllllllllIlIlllIIIlIIIllIl.preRenderBlocks(lllllllllllllllIlIlllIIIIllIllIl, lllllllllllllllIlIlllIIIlIIIIllI);
            }
            lllllllllllllllIlIlllIIIlIIIIIII[lllllllllllllllIlIlllIIIIllIlllI] |= lllllllllllllllIlIlllIIIIlllllll.renderBlock(lllllllllllllllIlIlllIIIIllllIIl, lllllllllllllllIlIlllIIIIllllIlI, lllllllllllllllIlIlllIIIlIIIIIll, lllllllllllllllIlIlllIIIIllIllIl);
          }
          lllllllllllllllIlIlllIIIIlllIIIl++;
        }
      }
      Block lllllllllllllllIlIlllIIIIllllIII = (lllllllllllllllIlIlllIIIIlllIllI = EnumWorldBlockLayer.values()).length;
      IBlockState lllllllllllllllIlIlllIIIIllllIIl = lIIllIlIlllI[0];
      "".length();
      if (((109 + 62 - 62 + 29 ^ 17 + 45 - -37 + 61) & (0x6C ^ 0x3D ^ 0xC ^ 0x77 ^ -" ".length())) != 0) {
        return;
      }
      while (!lllIlllIlllll(lllllllllllllllIlIlllIIIIllllIIl, lllllllllllllllIlIlllIIIIllllIII))
      {
        EnumWorldBlockLayer lllllllllllllllIlIlllIIIIllIllII = lllllllllllllllIlIlllIIIIlllIllI[lllllllllllllllIlIlllIIIIllllIIl];
        if (lllIlllIllllI(lllllllllllllllIlIlllIIIlIIIIIII[lllllllllllllllIlIlllIIIIllIllII.ordinal()])) {
          lllllllllllllllIlIlllIIIlIIIlIII.setLayerUsed(lllllllllllllllIlIlllIIIIllIllII);
        }
        if (lllIlllIllllI(lllllllllllllllIlIlllIIIlIIIlIII.isLayerStarted(lllllllllllllllIlIlllIIIIllIllII))) {
          lllllllllllllllIlIlllIIIlIIIllIl.postRenderBlocks(lllllllllllllllIlIlllIIIIllIllII, lllllllllllllllIlIlllIIIlIIIllII, lllllllllllllllIlIlllIIIIllIIlll, lllllllllllllllIlIlllIIIIllIIllI, lllllllllllllllIlIlllIIIlIIIlIIl.getRegionRenderCacheBuilder().getWorldRendererByLayer(lllllllllllllllIlIlllIIIIllIllII), lllllllllllllllIlIlllIIIlIIIlIII);
        }
        lllllllllllllllIlIlllIIIIllllIIl++;
      }
    }
    lllllllllllllllIlIlllIIIlIIIlIII.setVisibility(lllllllllllllllIlIlllIIIlIIIIIlI.computeVisibility());
    lockCompileTask.lock();
    try
    {
      HashSet lllllllllllllllIlIlllIIIIllIlIll = Sets.newHashSet(lllllllllllllllIlIlllIIIlIIIIIIl);
      HashSet lllllllllllllllIlIlllIIIIllIlIlI = Sets.newHashSet(field_181056_j);
      "".length();
      "".length();
      field_181056_j.clear();
      "".length();
      renderGlobal.func_181023_a(lllllllllllllllIlIlllIIIIllIlIlI, lllllllllllllllIlIlllIIIIllIlIll);
      "".length();
      if (-(121 + 33 - 38 + 31 ^ 46 + 81 - 35 + 59) >= 0) {
        return;
      }
    }
    finally
    {
      lockCompileTask.unlock();
    }
    lockCompileTask.unlock();
  }
  
  private static boolean lllIllllIIIlI(Object ???)
  {
    double lllllllllllllllIlIllIllllIlllIII;
    return ??? != null;
  }
  
  public void setNeedsUpdate(boolean lllllllllllllllIlIllIlllllllIIIl)
  {
    ;
    ;
    needsUpdate = lllllllllllllllIlIllIlllllllIIIl;
  }
  
  public CompiledChunk getCompiledChunk()
  {
    ;
    return compiledChunk;
  }
  
  public void deleteGlResources()
  {
    ;
    ;
    lllllllllllllllIlIllIllllllllIIl.stopCompileTask();
    world = null;
    int lllllllllllllllIlIllIllllllllIlI = lIIllIlIlllI[0];
    "".length();
    if (-" ".length() > (0x3 ^ 0x7)) {
      return;
    }
    while (!lllIlllIlllll(lllllllllllllllIlIllIllllllllIlI, EnumWorldBlockLayer.values().length))
    {
      if (lllIllllIIIlI(vertexBuffers[lllllllllllllllIlIllIllllllllIlI])) {
        vertexBuffers[lllllllllllllllIlIllIllllllllIlI].deleteGlBuffers();
      }
      lllllllllllllllIlIllIllllllllIlI++;
    }
  }
  
  private static boolean lllIllllIIlIl(Object ???, Object arg1)
  {
    Object localObject;
    boolean lllllllllllllllIlIllIllllIlllIlI;
    return ??? != localObject;
  }
  
  static
  {
    lllIlllIlllII();
    lllIlllIllIlI();
    __OBFID = lIIllIlIIllI[lIIllIlIlllI[0]];
  }
  
  public void setCompiledChunk(CompiledChunk lllllllllllllllIlIlllIIIIIIIIIlI)
  {
    ;
    ;
    lockCompiledChunk.lock();
    try
    {
      compiledChunk = lllllllllllllllIlIlllIIIIIIIIIlI;
      "".length();
      if ((0x7E ^ 0x7A) != (0x8B ^ 0x8F)) {
        return;
      }
    }
    finally
    {
      lockCompiledChunk.unlock();
    }
    lockCompiledChunk.unlock();
  }
  
  public void resortTransparency(float lllllllllllllllIlIlllIIIlIlIlllI, float lllllllllllllllIlIlllIIIlIlIllIl, float lllllllllllllllIlIlllIIIlIlIllII, ChunkCompileTaskGenerator lllllllllllllllIlIlllIIIlIlIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    CompiledChunk lllllllllllllllIlIlllIIIlIllIIIl = lllllllllllllllIlIlllIIIlIlIlIll.getCompiledChunk();
    if ((lllIllllIIIlI(lllllllllllllllIlIlllIIIlIllIIIl.getState())) && (lllIlllIlllIl(lllllllllllllllIlIlllIIIlIllIIIl.isLayerEmpty(EnumWorldBlockLayer.TRANSLUCENT))))
    {
      WorldRenderer lllllllllllllllIlIlllIIIlIllIIII = lllllllllllllllIlIlllIIIlIlIlIll.getRegionRenderCacheBuilder().getWorldRendererByLayer(EnumWorldBlockLayer.TRANSLUCENT);
      lllllllllllllllIlIlllIIIlIllIllI.preRenderBlocks(lllllllllllllllIlIlllIIIlIllIIII, position);
      lllllllllllllllIlIlllIIIlIllIIII.setVertexState(lllllllllllllllIlIlllIIIlIllIIIl.getState());
      lllllllllllllllIlIlllIIIlIllIllI.postRenderBlocks(EnumWorldBlockLayer.TRANSLUCENT, lllllllllllllllIlIlllIIIlIlIlllI, lllllllllllllllIlIlllIIIlIllIlII, lllllllllllllllIlIlllIIIlIlIllII, lllllllllllllllIlIlllIIIlIllIIII, lllllllllllllllIlIlllIIIlIllIIIl);
    }
  }
  
  private EnumWorldBlockLayer fixBlockLayer(Block lllllllllllllllIlIllIlllllIlIlII, EnumWorldBlockLayer lllllllllllllllIlIllIlllllIlIIll)
  {
    ;
    ;
    if (lllIllllIlIIl(lllllllllllllllIlIllIlllllIlIIll, EnumWorldBlockLayer.CUTOUT))
    {
      if (lllIlllIllllI(lllllllllllllllIlIllIlllllIlIlII instanceof BlockRedstoneWire))
      {
        "".length();
        if (-"  ".length() <= 0) {
          break label96;
        }
        return null;
      }
      if (lllIlllIllllI(lllllllllllllllIlIllIlllllIlIlII instanceof BlockCactus))
      {
        "".length();
        if (-" ".length() != "  ".length()) {
          break label96;
        }
        return null;
      }
      "".length();
      if ((0x86 ^ 0x83) != 0) {
        break label96;
      }
      return null;
    }
    label96:
    return lllllllllllllllIlIllIlllllIlIIll;
  }
  
  public boolean setFrameIndex(int lllllllllllllllIlIlllIIIllIlIlIl)
  {
    ;
    ;
    if (lllIllllIIIII(frameIndex, lllllllllllllllIlIlllIIIllIlIlIl)) {
      return lIIllIlIlllI[0];
    }
    frameIndex = lllllllllllllllIlIlllIIIllIlIlIl;
    return lIIllIlIlllI[3];
  }
  
  private static boolean lllIlllIlllll(int ???, int arg1)
  {
    int i;
    double lllllllllllllllIlIllIllllIlllllI;
    return ??? >= i;
  }
  
  private void postRenderBlocks(EnumWorldBlockLayer lllllllllllllllIlIlllIIIIIIllIlI, float lllllllllllllllIlIlllIIIIIIllIIl, float lllllllllllllllIlIlllIIIIIIllIII, float lllllllllllllllIlIlllIIIIIIlIlll, WorldRenderer lllllllllllllllIlIlllIIIIIIlllII, CompiledChunk lllllllllllllllIlIlllIIIIIIllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    if ((lllIllllIlIIl(lllllllllllllllIlIlllIIIIIIllIlI, EnumWorldBlockLayer.TRANSLUCENT)) && (lllIlllIlllIl(lllllllllllllllIlIlllIIIIIIllIll.isLayerEmpty(lllllllllllllllIlIlllIIIIIIllIlI))))
    {
      lllllllllllllllIlIlllIIIIIIlllII.func_181674_a(lllllllllllllllIlIlllIIIIIIllIIl, lllllllllllllllIlIlllIIIIIIllIII, lllllllllllllllIlIlllIIIIIIlIlll);
      lllllllllllllllIlIlllIIIIIIllIll.setState(lllllllllllllllIlIlllIIIIIIlllII.func_181672_a());
    }
    lllllllllllllllIlIlllIIIIIIlllII.finishDrawing();
  }
  
  public RenderChunk(World lllllllllllllllIlIlllIIIlllIIIll, RenderGlobal lllllllllllllllIlIlllIIIllIlllII, BlockPos lllllllllllllllIlIlllIIIlllIIIIl, int lllllllllllllllIlIlllIIIlllIIIII)
  {
    world = lllllllllllllllIlIlllIIIlllIIIll;
    renderGlobal = lllllllllllllllIlIlllIIIlllIIIlI;
    index = lllllllllllllllIlIlllIIIlllIIIII;
    if (lllIlllIlllIl(lllllllllllllllIlIlllIIIlllIIIIl.equals(lllllllllllllllIlIlllIIIllIllllI.getPosition()))) {
      lllllllllllllllIlIlllIIIllIllllI.setPosition(lllllllllllllllIlIlllIIIlllIIIIl);
    }
    if (lllIlllIllllI(OpenGlHelper.useVbo()))
    {
      int lllllllllllllllIlIlllIIIllIlllll = lIIllIlIlllI[0];
      "".length();
      if (((0x6B ^ 0x65) & (0x12 ^ 0x1C ^ 0xFFFFFFFF)) != 0) {
        throw null;
      }
      while (!lllIlllIlllll(lllllllllllllllIlIlllIIIllIlllll, EnumWorldBlockLayer.values().length))
      {
        vertexBuffers[lllllllllllllllIlIlllIIIllIlllll] = new VertexBuffer(DefaultVertexFormats.BLOCK);
        lllllllllllllllIlIlllIIIllIlllll++;
      }
    }
  }
  
  public BlockPos getPositionOffset16(EnumFacing lllllllllllllllIlIllIllllllIIIII)
  {
    ;
    ;
    ;
    ;
    int lllllllllllllllIlIllIlllllIlllll = lllllllllllllllIlIllIllllllIIIII.getIndex();
    BlockPos lllllllllllllllIlIllIlllllIllllI = positionOffsets16[lllllllllllllllIlIllIlllllIlllll];
    if (lllIllllIIllI(lllllllllllllllIlIllIlllllIllllI))
    {
      lllllllllllllllIlIllIlllllIllllI = lllllllllllllllIlIllIllllllIIIIl.getPosition().offset(lllllllllllllllIlIllIllllllIIIII, lIIllIlIlllI[1]);
      positionOffsets16[lllllllllllllllIlIllIlllllIlllll] = lllllllllllllllIlIllIlllllIllllI;
    }
    return lllllllllllllllIlIllIlllllIllllI;
  }
  
  public ReentrantLock getLockCompileTask()
  {
    ;
    return lockCompileTask;
  }
  
  private static void lllIlllIlllII()
  {
    lIIllIlIlllI = new int[8];
    lIIllIlIlllI[0] = (('Á' + '¯' - 270 + 138 ^ 7 + 16 - -1 + 136) & (107 + 115 - 133 + 115 ^ 103 + 0 - 76 + 101 ^ -" ".length()));
    lIIllIlIlllI[1] = (0x14 ^ 0x4);
    lIIllIlIlllI[2] = (-" ".length());
    lIIllIlIlllI[3] = " ".length();
    lIIllIlIlllI[4] = (0xB3 ^ 0xBC);
    lIIllIlIlllI[5] = (0xE ^ 0x9);
    lIIllIlIlllI[6] = (0x9FA7 & 0x6BFE);
    lIIllIlIlllI[7] = "  ".length();
  }
  
  public boolean isNeedsUpdate()
  {
    ;
    return needsUpdate;
  }
  
  private void preRenderBlocks(WorldRenderer lllllllllllllllIlIlllIIIIIlIlIIl, BlockPos lllllllllllllllIlIlllIIIIIlIlIlI)
  {
    ;
    ;
    lllllllllllllllIlIlllIIIIIlIlIIl.begin(lIIllIlIlllI[5], DefaultVertexFormats.BLOCK);
    lllllllllllllllIlIlllIIIIIlIlIIl.setTranslation(-lllllllllllllllIlIlllIIIIIlIlIlI.getX(), -lllllllllllllllIlIlllIIIIIlIlIlI.getY(), -lllllllllllllllIlIlllIIIIIlIlIlI.getZ());
  }
  
  private static boolean lllIllllIIllI(Object ???)
  {
    short lllllllllllllllIlIllIllllIllIIlI;
    return ??? == null;
  }
  
  public BlockPos getPosition()
  {
    ;
    return position;
  }
  
  private static void lllIlllIllIlI()
  {
    lIIllIlIIllI = new String[lIIllIlIlllI[3]];
    lIIllIlIIllI[lIIllIlIlllI[0]] = lllIlllIlIlll("DFILc8adyN40EG9g4IAg6A==", "mhCYF");
  }
  
  public VertexBuffer getVertexBufferByLayer(int lllllllllllllllIlIlllIIIllIIllIl)
  {
    ;
    ;
    return vertexBuffers[lllllllllllllllIlIlllIIIllIIllIl];
  }
  
  public ChunkCompileTaskGenerator makeCompileTaskTransparency()
  {
    ;
    ;
    ;
    ;
    lockCompileTask.lock();
    try
    {
      if ((lllIllllIIIlI(compileTask)) && (lllIllllIlIIl(compileTask.getStatus(), ChunkCompileTaskGenerator.Status.PENDING)))
      {
        ChunkCompileTaskGenerator lllllllllllllllIlIlllIIIIIllIlIl = null;
        lllllllllllllllIlIlllIIIIIlIllll = lllllllllllllllIlIlllIIIIIllIlIl;
        return lllllllllllllllIlIlllIIIIIlIllll;
      }
      if ((lllIllllIIIlI(compileTask)) && (lllIllllIIlIl(compileTask.getStatus(), ChunkCompileTaskGenerator.Status.DONE)))
      {
        compileTask.finish();
        compileTask = null;
      }
      compileTask = new ChunkCompileTaskGenerator(lllllllllllllllIlIlllIIIIIllIIll, ChunkCompileTaskGenerator.Type.RESORT_TRANSPARENCY);
      compileTask.setCompiledChunk(compiledChunk);
      ChunkCompileTaskGenerator lllllllllllllllIlIlllIIIIIllIlII = compileTask;
      ChunkCompileTaskGenerator lllllllllllllllIlIlllIIIIIllIlll = lllllllllllllllIlIlllIIIIIllIlII;
      "".length();
      if (null != null) {
        return null;
      }
    }
    finally
    {
      lockCompileTask.unlock();
    }
    ChunkCompileTaskGenerator lllllllllllllllIlIlllIIIIIllIllI;
    lockCompileTask.unlock();
    return lllllllllllllllIlIlllIIIIIllIllI;
  }
}

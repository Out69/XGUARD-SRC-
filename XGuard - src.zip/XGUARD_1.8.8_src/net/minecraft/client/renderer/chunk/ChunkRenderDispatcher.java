package net.minecraft.client.renderer.chunk;

import com.google.common.collect.Lists;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.common.util.concurrent.ListenableFutureTask;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.locks.ReentrantLock;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RegionRenderCacheBuilder;
import net.minecraft.client.renderer.VertexBufferUploader;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.WorldVertexBufferUploader;
import net.minecraft.client.renderer.vertex.VertexBuffer;
import net.minecraft.util.EnumWorldBlockLayer;
import org.apache.logging.log4j.LogManager;
import org.lwjgl.opengl.GL11;

public class ChunkRenderDispatcher
{
  private static int lIllllIIIlIIlI(long paramLong1, long paramLong2)
  {
    return paramLong1 < paramLong2;
  }
  
  public boolean updateChunkLater(RenderChunk llllllllllllllIllIlIIIIlIllIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIlIIIIlIllIIlII.getLockCompileTask().lock();
    try
    {
      final ChunkCompileTaskGenerator llllllllllllllIllIlIIIIlIllIIlll = llllllllllllllIllIlIIIIlIllIIlII.makeCompileTaskChunk();
      llllllllllllllIllIlIIIIlIllIIlll.addFinishRunnable(new Runnable()
      {
        public void run()
        {
          ;
          "".length();
        }
      });
      boolean llllllllllllllIllIlIIIIlIllIIllI = queueChunkUpdates.offer(llllllllllllllIllIlIIIIlIllIIlll);
      if (lIllllIIIlIIll(llllllllllllllIllIlIIIIlIllIIllI)) {
        llllllllllllllIllIlIIIIlIllIIlll.finish();
      }
      boolean llllllllllllllIllIlIIIIlIllIlIIl = llllllllllllllIllIlIIIIlIllIIllI;
      "".length();
      if (null != null) {
        return ('¾' + '' - 260 + 164 ^ 13 + 86 - -38 + 60) & (0x68 ^ 0x57 ^ 0x48 ^ 0x57 ^ -" ".length());
      }
    }
    finally
    {
      llllllllllllllIllIlIIIIlIllIIlII.getLockCompileTask().unlock();
    }
    boolean llllllllllllllIllIlIIIIlIllIlIII;
    llllllllllllllIllIlIIIIlIllIIlII.getLockCompileTask().unlock();
    return llllllllllllllIllIlIIIIlIllIlIII;
  }
  
  private static boolean lIllllIIIlIlll(Object ???)
  {
    double llllllllllllllIllIlIIIIIllIlllll;
    return ??? == null;
  }
  
  public ListenableFuture<Object> uploadChunk(final EnumWorldBlockLayer llllllllllllllIllIlIIIIlIIIllIlI, WorldRenderer llllllllllllllIllIlIIIIlIIIlllll, final RenderChunk llllllllllllllIllIlIIIIlIIIllllI, final CompiledChunk llllllllllllllIllIlIIIIlIIIlIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    if (lIllllIIIlIlII(Minecraft.getMinecraft().isCallingFromMinecraftThread()))
    {
      if (lIllllIIIlIlII(OpenGlHelper.useVbo()))
      {
        llllllllllllllIllIlIIIIlIIlIIIIl.uploadVertexBuffer(llllllllllllllIllIlIIIIlIIIllIIl, llllllllllllllIllIlIIIIlIIIllllI.getVertexBufferByLayer(llllllllllllllIllIlIIIIlIIIllIlI.ordinal()));
        "".length();
        if (null != null) {
          return null;
        }
      }
      else
      {
        llllllllllllllIllIlIIIIlIIlIIIIl.uploadDisplayList(llllllllllllllIllIlIIIIlIIIllIIl, ((ListedRenderChunk)llllllllllllllIllIlIIIIlIIIllllI).getDisplayList(llllllllllllllIllIlIIIIlIIIllIlI, llllllllllllllIllIlIIIIlIIIlIlll), llllllllllllllIllIlIIIIlIIIllllI);
      }
      llllllllllllllIllIlIIIIlIIIllIIl.setTranslation(0.0D, 0.0D, 0.0D);
      return Futures.immediateFuture(null);
    }
    ListenableFutureTask<Object> llllllllllllllIllIlIIIIlIIIlllII = ListenableFutureTask.create(new Runnable()
    {
      public void run()
      {
        ;
        "".length();
      }
    }, null);
    synchronized (queueChunkUploads)
    {
      "".length();
      return llllllllllllllIllIlIIIIlIIIlllII;
    }
  }
  
  private static boolean lIllllIIIlIIll(int ???)
  {
    float llllllllllllllIllIlIIIIIllIllIll;
    return ??? == 0;
  }
  
  private static boolean lIllllIIIlIlIl(int ???)
  {
    double llllllllllllllIllIlIIIIIllIllIIl;
    return ??? < 0;
  }
  
  private static void lIllllIIIIlIIl()
  {
    llllIlllIIlI = new String[llllIlllIIll[4]];
    llllIlllIIlI[llllIlllIIll[0]] = lIllllIIIIlIII("nZ7wD/ad1T0+z8qtrFGs0mVXukxuwxzX", "nliUB");
    llllIlllIIlI[llllIlllIIll[1]] = lIllllIIIIlIII("4u7IbaNeu6sNQtu/3aS8takzTQVkr2sJ779CtDMpeb4=", "WEzGL");
  }
  
  private static boolean lIllllIIIlIllI(int ???, int arg1)
  {
    int i;
    char llllllllllllllIllIlIIIIIlllIIlll;
    return ??? == i;
  }
  
  public boolean updateChunkNow(RenderChunk llllllllllllllIllIlIIIIlIlIlIIll)
  {
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIlIIIIlIlIlIIll.getLockCompileTask().lock();
    try
    {
      ChunkCompileTaskGenerator llllllllllllllIllIlIIIIlIlIlIlIl = llllllllllllllIllIlIIIIlIlIlIIll.makeCompileTaskChunk();
      try
      {
        renderWorker.processTask(llllllllllllllIllIlIIIIlIlIlIlIl);
        "".length();
        if ((0xD5 ^ 0x9C ^ 0xFA ^ 0xB7) <= " ".length()) {
          return (0 + 80 - 67 + 212 ^ 112 + 109 - 159 + 103) & (0xD ^ 0x30 ^ 0xEB ^ 0x92 ^ -" ".length());
        }
      }
      catch (InterruptedException localInterruptedException)
      {
        boolean llllllllllllllIllIlIIIIlIlIlIlll = llllIlllIIll[1];
        "".length();
        if (-" ".length() < ((0x6E ^ 0x41) & (0xB6 ^ 0x99 ^ 0xFFFFFFFF))) {
          break label161;
        }
      }
      return (0xC3 ^ 0x98) & (0x49 ^ 0x12 ^ 0xFFFFFFFF);
    }
    finally
    {
      llllllllllllllIllIlIIIIlIlIlIIll.getLockCompileTask().unlock();
    }
    label161:
    boolean llllllllllllllIllIlIIIIlIlIlIllI;
    llllllllllllllIllIlIIIIlIlIlIIll.getLockCompileTask().unlock();
    return llllllllllllllIllIlIIIIlIlIlIllI;
  }
  
  public String getDebugInfo()
  {
    ;
    return String.format(llllIlllIIlI[llllIlllIIll[1]], new Object[] { Integer.valueOf(queueChunkUpdates.size()), Integer.valueOf(queueChunkUploads.size()), Integer.valueOf(queueFreeRenderBuilders.size()) });
  }
  
  public boolean updateTransparencyLater(RenderChunk llllllllllllllIllIlIIIIlIIllIIll)
  {
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIllIlIIIIlIIllIIll.getLockCompileTask().lock();
    try
    {
      final ChunkCompileTaskGenerator llllllllllllllIllIlIIIIlIIlIllll = llllllllllllllIllIlIIIIlIIllIIll.makeCompileTaskTransparency();
      if (lIllllIIIlIlll(llllllllllllllIllIlIIIIlIIlIllll))
      {
        boolean llllllllllllllIllIlIIIIlIIllIIlI = llllIlllIIll[1];
        llllllllllllllIllIlIIIIlIIlIlIIl = llllllllllllllIllIlIIIIlIIllIIlI;
        return llllllllllllllIllIlIIIIlIIlIlIIl;
      }
      llllllllllllllIllIlIIIIlIIlIllll.addFinishRunnable(new Runnable()
      {
        public void run()
        {
          ;
          "".length();
        }
      });
      boolean llllllllllllllIllIlIIIIlIIllIIIl = queueChunkUpdates.offer(llllllllllllllIllIlIIIIlIIlIllll);
      "".length();
      if (-('¡' + 121 - 225 + 122 ^ '²' + '' - 238 + 95) >= 0) {
        return (0x59 ^ 0x1F ^ 0xB0 ^ 0x97) & ('' + 74 - 86 + 77 ^ 66 + 75 - -4 + 27 ^ -" ".length());
      }
    }
    finally
    {
      llllllllllllllIllIlIIIIlIIllIIll.getLockCompileTask().unlock();
    }
    boolean llllllllllllllIllIlIIIIlIIllIIII;
    llllllllllllllIllIlIIIIlIIllIIll.getLockCompileTask().unlock();
    return llllllllllllllIllIlIIIIlIIllIIII;
  }
  
  static
  {
    lIllllIIIlIIII();
    lIllllIIIIlIIl();
    logger = LogManager.getLogger();
  }
  
  public ChunkRenderDispatcher()
  {
    int llllllllllllllIllIlIIIIllIIIlIll = llllIlllIIll[0];
    "".length();
    if ((0x7D ^ 0x59 ^ 0xB8 ^ 0x98) < "   ".length()) {
      throw null;
    }
    while (!lIllllIIIlIIIl(llllllllllllllIllIlIIIIllIIIlIll, llllIlllIIll[4]))
    {
      ChunkRenderWorker llllllllllllllIllIlIIIIllIIIlIlI = new ChunkRenderWorker(llllllllllllllIllIlIIIIllIIIIlll);
      Thread llllllllllllllIllIlIIIIllIIIlIIl = threadFactory.newThread(llllllllllllllIllIlIIIIllIIIlIlI);
      llllllllllllllIllIlIIIIllIIIlIIl.start();
      "".length();
    }
    int llllllllllllllIllIlIIIIllIIIlIII = llllIlllIIll[0];
    "".length();
    if (-" ".length() >= 0) {
      throw null;
    }
    while (!lIllllIIIlIIIl(llllllllllllllIllIlIIIIllIIIlIII, llllIlllIIll[3]))
    {
      new RegionRenderCacheBuilder();
      "".length();
    }
    renderWorker = new ChunkRenderWorker(llllllllllllllIllIlIIIIllIIIIlll, new RegionRenderCacheBuilder());
  }
  
  private static boolean lIllllIIIllIII(Object ???)
  {
    int llllllllllllllIllIlIIIIIlllIIIIl;
    return ??? != null;
  }
  
  public void freeRenderBuilder(RegionRenderCacheBuilder llllllllllllllIllIlIIIIlIlIIIIll)
  {
    ;
    ;
    "".length();
  }
  
  private void uploadDisplayList(WorldRenderer llllllllllllllIllIlIIIIlIIIIlIll, int llllllllllllllIllIlIIIIlIIIIlllI, RenderChunk llllllllllllllIllIlIIIIlIIIIlIIl)
  {
    ;
    ;
    ;
    ;
    GL11.glNewList(llllllllllllllIllIlIIIIlIIIIlllI, llllIlllIIll[6]);
    GlStateManager.pushMatrix();
    llllllllllllllIllIlIIIIlIIIIlIIl.multModelviewMatrix();
    worldVertexUploader.func_181679_a(llllllllllllllIllIlIIIIlIIIIlIll);
    GlStateManager.popMatrix();
    GL11.glEndList();
  }
  
  private void uploadVertexBuffer(WorldRenderer llllllllllllllIllIlIIIIlIIIIIlII, VertexBuffer llllllllllllllIllIlIIIIlIIIIIIII)
  {
    ;
    ;
    ;
    vertexUploader.setVertexBuffer(llllllllllllllIllIlIIIIlIIIIIIII);
    vertexUploader.func_181679_a(llllllllllllllIllIlIIIIlIIIIIIIl);
  }
  
  public void clearChunkUpdates()
  {
    ;
    ;
    "".length();
    if (null != null) {
      return;
    }
    while (!lIllllIIIlIlII(queueChunkUpdates.isEmpty()))
    {
      ChunkCompileTaskGenerator llllllllllllllIllIlIIIIIllllllII = (ChunkCompileTaskGenerator)queueChunkUpdates.poll();
      if (lIllllIIIllIII(llllllllllllllIllIlIIIIIllllllII)) {
        llllllllllllllIllIlIIIIIllllllII.finish();
      }
    }
  }
  
  private static void lIllllIIIlIIII()
  {
    llllIlllIIll = new int[8];
    llllIlllIIll[0] = ((0x5C ^ 0x2A ^ 0xCE ^ 0x8C) & (0x5B ^ 0x1 ^ 0xCD ^ 0xA3 ^ -" ".length()));
    llllIlllIIll[1] = " ".length();
    llllIlllIIll[2] = (0x46 ^ 0x22);
    llllIlllIIll[3] = (0x1A ^ 0x1F);
    llllIlllIIll[4] = "  ".length();
    llllIlllIIll[5] = "   ".length();
    llllIlllIIll[6] = (0xFFFFFFDC & 0x1323);
    llllIlllIIll[7] = (0x23 ^ 0x2B);
  }
  
  public ChunkCompileTaskGenerator getNextChunkUpdate()
    throws InterruptedException
  {
    ;
    return (ChunkCompileTaskGenerator)queueChunkUpdates.take();
  }
  
  private static boolean lIllllIIIlIlII(int ???)
  {
    boolean llllllllllllllIllIlIIIIIllIlllIl;
    return ??? != 0;
  }
  
  public RegionRenderCacheBuilder allocateRenderBuilder()
    throws InterruptedException
  {
    ;
    return (RegionRenderCacheBuilder)queueFreeRenderBuilders.take();
  }
  
  public boolean runChunkUploads(long llllllllllllllIllIlIIIIlIlllIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    boolean llllllllllllllIllIlIIIIlIllllIIl = llllIlllIIll[0];
    long llllllllllllllIllIlIIIIlIlllIlll;
    do
    {
      boolean llllllllllllllIllIlIIIIlIllllIII = llllIlllIIll[0];
      synchronized (queueChunkUploads)
      {
        if (lIllllIIIlIIll(queueChunkUploads.isEmpty()))
        {
          ((ListenableFutureTask)queueChunkUploads.poll()).run();
          llllllllllllllIllIlIIIIlIllllIII = llllIlllIIll[1];
          llllllllllllllIllIlIIIIlIllllIIl = llllIlllIIll[1];
        }
        "".length();
        if (-" ".length() > 0) {
          return (71 + 65 - 83 + 107 ^ 51 + 110 - 141 + 158) & ('' + 8 - 83 + 105 ^ '' + 2 - 31 + 71 ^ -" ".length());
        }
      }
      if (!lIllllIIIlIlII(lIllllIIIlIIlI(llllllllllllllIllIlIIIIlIlllIlIl, 0L))) {
        break;
      }
      if (lIllllIIIlIIll(llllllllllllllIllIlIIIIlIllllIII))
      {
        "".length();
        if (" ".length() > 0) {
          break;
        }
        return (0x13 ^ 0x6 ^ 0x20 ^ 0x2D) & (0x6B ^ 0x11 ^ 0xDF ^ 0xBD ^ -" ".length());
      }
      llllllllllllllIllIlIIIIlIlllIlll = llllllllllllllIllIlIIIIlIlllIlIl - System.nanoTime();
    } while (!lIllllIIIlIlIl(lIllllIIIlIIlI(llllllllllllllIllIlIIIIlIlllIlll, 0L)));
    return llllllllllllllIllIlIIIIlIllllIIl;
  }
  
  private static String lIllllIIIIlIII(String llllllllllllllIllIlIIIIIllllIIII, String llllllllllllllIllIlIIIIIlllIllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIllIlIIIIIllllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIllIlIIIIIlllIllll.getBytes(StandardCharsets.UTF_8)), llllIlllIIll[7]), "DES");
      Cipher llllllllllllllIllIlIIIIIllllIIlI = Cipher.getInstance("DES");
      llllllllllllllIllIlIIIIIllllIIlI.init(llllIlllIIll[4], llllllllllllllIllIlIIIIIllllIIll);
      return new String(llllllllllllllIllIlIIIIIllllIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIllIlIIIIIllllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIllIlIIIIIllllIIIl)
    {
      llllllllllllllIllIlIIIIIllllIIIl.printStackTrace();
    }
    return null;
  }
  
  public void stopChunkUpdates()
  {
    ;
    ;
    ;
    llllllllllllllIllIlIIIIlIlIIlIll.clearChunkUpdates();
    while (!lIllllIIIlIIll(llllllllllllllIllIlIIIIlIlIIlIIl.runChunkUploads(0L))) {}
    List<RegionRenderCacheBuilder> llllllllllllllIllIlIIIIlIlIIlIlI = Lists.newArrayList();
    "".length();
    if (-"  ".length() >= 0) {
      return;
    }
    while (!lIllllIIIlIllI(llllllllllllllIllIlIIIIlIlIIlIlI.size(), llllIlllIIll[3])) {
      try
      {
        "".length();
        "".length();
        if (((1 + 4 - -71 + 146 ^ 71 + 8 - 60 + 134) & ('¬' + 11 - -6 + 20 ^ 51 + 40 - -34 + 25 ^ -" ".length())) != 0) {
          return;
        }
      }
      catch (InterruptedException localInterruptedException) {}
    }
    "".length();
  }
  
  private static boolean lIllllIIIlIIIl(int ???, int arg1)
  {
    int i;
    int llllllllllllllIllIlIIIIIlllIIIll;
    return ??? >= i;
  }
}

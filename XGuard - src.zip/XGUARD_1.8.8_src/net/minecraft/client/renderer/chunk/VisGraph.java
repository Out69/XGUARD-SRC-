package net.minecraft.client.renderer.chunk;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.BitSet;
import java.util.EnumSet;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class VisGraph
{
  private static void lIIlllIIIlIIII()
  {
    llIIllIIlllI = new String[llIIllllIlIl[2]];
    llIIllIIlllI[llIIllllIlIl[0]] = lIIlllIIIIllll("o3QrEXMyX0DFZcAHW0SEEQ==", "AOTrx");
  }
  
  private static int getIndex(BlockPos lllllllllllllllIIIIllIIlIlIlIIll)
  {
    ;
    return getIndex(lllllllllllllllIIIIllIIlIlIlIIll.getX() & llIIllllIlIl[3], lllllllllllllllIIIIllIIlIlIlIlII.getY() & llIIllllIlIl[3], lllllllllllllllIIIIllIIlIlIlIlII.getZ() & llIIllllIlIl[3]);
  }
  
  private static int getIndex(int lllllllllllllllIIIIllIIlIlIIllll, int lllllllllllllllIIIIllIIlIlIIlllI, int lllllllllllllllIIIIllIIlIlIIlIlI)
  {
    ;
    ;
    ;
    return lllllllllllllllIIIIllIIlIlIIllll << llIIllllIlIl[0] | lllllllllllllllIIIIllIIlIlIIlIll << llIIllllIlIl[6] | lllllllllllllllIIIIllIIlIlIIlIlI << llIIllllIlIl[7];
  }
  
  private static boolean lIIllllIIlllll(int ???)
  {
    long lllllllllllllllIIIIllIIIlllIIlII;
    return ??? >= 0;
  }
  
  public void func_178606_a(BlockPos lllllllllllllllIIIIllIIlIlIlIllI)
  {
    ;
    ;
    field_178612_d.set(getIndex(lllllllllllllllIIIIllIIlIlIlIllI), llIIllllIlIl[2]);
    field_178611_f -= llIIllllIlIl[2];
  }
  
  private static void lIIllllIIllIII()
  {
    llIIllllIlIl = new int[12];
    llIIllllIlIl[0] = ((0xB0 ^ 0xA3) & (0xBB ^ 0xA8 ^ 0xFFFFFFFF));
    llIIllllIlIl[1] = (-(0xD895 & 0x3F7E) & 0xDD7F & 0x3FDB);
    llIIllllIlIl[2] = " ".length();
    llIIllllIlIl[3] = ('¥' + 28 - 92 + 86 ^ 84 + 79 - 8 + 25);
    llIIllllIlIl[4] = (4 + 48 - -67 + 67 ^ 115 + 0 - 22 + 77);
    llIIllllIlIl[5] = (-(0xAFF7 & 0x5FBB) & 0x9FF3 & 0x7FBE);
    llIIllllIlIl[6] = (0xB1 ^ 0xB9);
    llIIllllIlIl[7] = (0xC1 ^ 0xC5);
    llIIllllIlIl[8] = (-(0xE39F & 0x3EFE) & 0xBF9D & 0x63FF);
    llIIllllIlIl[9] = (-(0xCBDE & 0x7679) & 0xEFFF & 0x53D7);
    llIIllllIlIl[10] = (-" ".length());
    llIIllllIlIl[11] = "  ".length();
  }
  
  private static String lIIlllIIIIllll(String lllllllllllllllIIIIllIIIlllllIIl, String lllllllllllllllIIIIllIIIlllllIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIIIIllIIIlllllllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIIllIIIlllllIlI.getBytes(StandardCharsets.UTF_8)), llIIllllIlIl[6]), "DES");
      Cipher lllllllllllllllIIIIllIIIllllllIl = Cipher.getInstance("DES");
      lllllllllllllllIIIIllIIIllllllIl.init(llIIllllIlIl[11], lllllllllllllllIIIIllIIIlllllllI);
      return new String(lllllllllllllllIIIIllIIIllllllIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIIllIIIlllllIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIIIIllIIIllllllII)
    {
      lllllllllllllllIIIIllIIIllllllII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIllllIIlllIl(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIIIIllIIIlllIlIlI;
    return ??? < i;
  }
  
  private void func_178610_a(int lllllllllllllllIIIIllIIlIIIIlllI, Set lllllllllllllllIIIIllIIlIIIIllIl)
  {
    ;
    ;
    ;
    ;
    ;
    int lllllllllllllllIIIIllIIlIIIlIIIl = lllllllllllllllIIIIllIIlIIIIlllI >> llIIllllIlIl[0] & llIIllllIlIl[3];
    if (lIIllllIIllllI(lllllllllllllllIIIIllIIlIIIlIIIl))
    {
      "".length();
      "".length();
      if ("   ".length() > -" ".length()) {}
    }
    else if (lIIllllIIllIll(lllllllllllllllIIIIllIIlIIIlIIIl, llIIllllIlIl[3]))
    {
      "".length();
    }
    int lllllllllllllllIIIIllIIlIIIlIIII = lllllllllllllllIIIIllIIlIIIIlllI >> llIIllllIlIl[6] & llIIllllIlIl[3];
    if (lIIllllIIllllI(lllllllllllllllIIIIllIIlIIIlIIII))
    {
      "".length();
      "".length();
      if ("   ".length() > "  ".length()) {}
    }
    else if (lIIllllIIllIll(lllllllllllllllIIIIllIIlIIIlIIII, llIIllllIlIl[3]))
    {
      "".length();
    }
    int lllllllllllllllIIIIllIIlIIIIllll = lllllllllllllllIIIIllIIlIIIIlllI >> llIIllllIlIl[7] & llIIllllIlIl[3];
    if (lIIllllIIllllI(lllllllllllllllIIIIllIIlIIIIllll))
    {
      "".length();
      "".length();
      if (" ".length() >= " ".length()) {}
    }
    else if (lIIllllIIllIll(lllllllllllllllIIIIllIIlIIIIllll, llIIllllIlIl[3]))
    {
      "".length();
    }
  }
  
  private static boolean lIIllllIIllIlI(int ???, int arg1)
  {
    int i;
    float lllllllllllllllIIIIllIIIlllIIIII;
    return ??? != i;
  }
  
  private static boolean lIIllllIIllllI(int ???)
  {
    int lllllllllllllllIIIIllIIIlllIIllI;
    return ??? == 0;
  }
  
  static
  {
    lIIllllIIllIII();
    lIIlllIIIlIIII();
    __OBFID = llIIllIIlllI[llIIllllIlIl[0]];
    float lllllllllllllllIIIIllIIlIlIlllll;
    short lllllllllllllllIIIIllIIlIllIIIII;
    float lllllllllllllllIIIIllIIlIllIIIIl;
    String lllllllllllllllIIIIllIIlIllIIIlI;
    String lllllllllllllllIIIIllIIlIllIIIll;
    short lllllllllllllllIIIIllIIlIllIIlII;
    field_178616_a = (int)Math.pow(16.0D, 0.0D);
    field_178614_b = (int)Math.pow(16.0D, 1.0D);
    field_178615_c = (int)Math.pow(16.0D, 2.0D);
    field_178613_e = new int[llIIllllIlIl[1]];
    boolean lllllllllllllllIIIIllIIlIllIlIlI = llIIllllIlIl[0];
    boolean lllllllllllllllIIIIllIIlIllIlIIl = llIIllllIlIl[2];
    int lllllllllllllllIIIIllIIlIllIlIII = llIIllllIlIl[0];
    int lllllllllllllllIIIIllIIlIllIIlll = llIIllllIlIl[0];
    "".length();
    if ((0x6A ^ 0x43 ^ 0x13 ^ 0x3F) == 0) {
      return;
    }
    while (!lIIllllIIlllII(lllllllllllllllIIIIllIIlIllIIlll, llIIllllIlIl[4]))
    {
      int lllllllllllllllIIIIllIIlIllIIllI = llIIllllIlIl[0];
      "".length();
      if ("   ".length() == 0) {
        return;
      }
      while (!lIIllllIIlllII(lllllllllllllllIIIIllIIlIllIIllI, llIIllllIlIl[4]))
      {
        int lllllllllllllllIIIIllIIlIllIIlIl = llIIllllIlIl[0];
        "".length();
        if ("   ".length() <= 0) {
          return;
        }
        while (!lIIllllIIlllII(lllllllllllllllIIIIllIIlIllIIlIl, llIIllllIlIl[4]))
        {
          if ((!lIIllllIIllIIl(lllllllllllllllIIIIllIIlIllIIlll)) || (!lIIllllIIllIlI(lllllllllllllllIIIIllIIlIllIIlll, llIIllllIlIl[3])) || (!lIIllllIIllIIl(lllllllllllllllIIIIllIIlIllIIllI)) || (!lIIllllIIllIlI(lllllllllllllllIIIIllIIlIllIIllI, llIIllllIlIl[3])) || (!lIIllllIIllIIl(lllllllllllllllIIIIllIIlIllIIlIl)) || (lIIllllIIllIll(lllllllllllllllIIIIllIIlIllIIlIl, llIIllllIlIl[3]))) {
            field_178613_e[(lllllllllllllllIIIIllIIlIllIlIII++)] = getIndex(lllllllllllllllIIIIllIIlIllIIlll, lllllllllllllllIIIIllIIlIllIIllI, lllllllllllllllIIIIllIIlIllIIlIl);
          }
          lllllllllllllllIIIIllIIlIllIIlIl++;
        }
        lllllllllllllllIIIIllIIlIllIIllI++;
      }
      lllllllllllllllIIIIllIIlIllIIlll++;
    }
  }
  
  private static boolean lIIllllIIlllII(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllIIIIllIIIlllIlllI;
    return ??? >= i;
  }
  
  private int func_178603_a(int lllllllllllllllIIIIllIIlIIIIIlII, EnumFacing lllllllllllllllIIIIllIIlIIIIIIll)
  {
    ;
    ;
    switch (VisGraph.1.field_178617_a[lllllllllllllllIIIIllIIlIIIIIIll.ordinal()])
    {
    case 1: 
      if (lIIllllIIllllI(lllllllllllllllIIIIllIIlIIIIIlII >> llIIllllIlIl[6] & llIIllllIlIl[3])) {
        return llIIllllIlIl[10];
      }
      return lllllllllllllllIIIIllIIlIIIIIlII - field_178615_c;
    case 2: 
      if (lIIllllIIllIll(lllllllllllllllIIIIllIIlIIIIIlII >> llIIllllIlIl[6] & llIIllllIlIl[3], llIIllllIlIl[3])) {
        return llIIllllIlIl[10];
      }
      return lllllllllllllllIIIIllIIlIIIIIlII + field_178615_c;
    case 3: 
      if (lIIllllIIllllI(lllllllllllllllIIIIllIIlIIIIIlII >> llIIllllIlIl[7] & llIIllllIlIl[3])) {
        return llIIllllIlIl[10];
      }
      return lllllllllllllllIIIIllIIlIIIIIlII - field_178614_b;
    case 4: 
      if (lIIllllIIllIll(lllllllllllllllIIIIllIIlIIIIIlII >> llIIllllIlIl[7] & llIIllllIlIl[3], llIIllllIlIl[3])) {
        return llIIllllIlIl[10];
      }
      return lllllllllllllllIIIIllIIlIIIIIlII + field_178614_b;
    case 5: 
      if (lIIllllIIllllI(lllllllllllllllIIIIllIIlIIIIIlII >> llIIllllIlIl[0] & llIIllllIlIl[3])) {
        return llIIllllIlIl[10];
      }
      return lllllllllllllllIIIIllIIlIIIIIlII - field_178616_a;
    case 6: 
      if (lIIllllIIllIll(lllllllllllllllIIIIllIIlIIIIIlII >> llIIllllIlIl[0] & llIIllllIlIl[3], llIIllllIlIl[3])) {
        return llIIllllIlIl[10];
      }
      return lllllllllllllllIIIIllIIlIIIIIlII + field_178616_a;
    }
    return llIIllllIlIl[10];
  }
  
  private static boolean lIIllllIIllIll(int ???, int arg1)
  {
    int i;
    boolean lllllllllllllllIIIIllIIIllllIIlI;
    return ??? == i;
  }
  
  private static boolean lIIllllIIllIIl(int ???)
  {
    boolean lllllllllllllllIIIIllIIIlllIlIII;
    return ??? != 0;
  }
  
  public Set func_178609_b(BlockPos lllllllllllllllIIIIllIIlIIllIlIl)
  {
    ;
    ;
    return lllllllllllllllIIIIllIIlIIlllIII.func_178604_a(getIndex(lllllllllllllllIIIIllIIlIIllIlIl));
  }
  
  public VisGraph() {}
  
  private Set func_178604_a(int lllllllllllllllIIIIllIIlIIlIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumSet lllllllllllllllIIIIllIIlIIlIlIII = EnumSet.noneOf(EnumFacing.class);
    ArrayDeque lllllllllllllllIIIIllIIlIIlIIlll = new ArrayDeque(llIIllllIlIl[9]);
    "".length();
    field_178612_d.set(lllllllllllllllIIIIllIIlIIlIlIIl, llIIllllIlIl[2]);
    "".length();
    if ("   ".length() <= ((0x80 ^ 0xB1) & (0x8D ^ 0xBC ^ 0xFFFFFFFF))) {
      return null;
    }
    while (!lIIllllIIllIIl(lllllllllllllllIIIIllIIlIIlIIlll.isEmpty()))
    {
      int lllllllllllllllIIIIllIIlIIlIIllI = ((Integer)lllllllllllllllIIIIllIIlIIlIIlll.poll()).intValue();
      lllllllllllllllIIIIllIIlIIlIlIlI.func_178610_a(lllllllllllllllIIIIllIIlIIlIIllI, lllllllllllllllIIIIllIIlIIlIlIII);
      lllllllllllllllIIIIllIIlIIIlllII = (lllllllllllllllIIIIllIIlIIIllIll = EnumFacing.VALUES).length;
      lllllllllllllllIIIIllIIlIIIlllIl = llIIllllIlIl[0];
      "".length();
      if (-" ".length() >= "  ".length()) {
        return null;
      }
      while (!lIIllllIIlllII(lllllllllllllllIIIIllIIlIIIlllIl, lllllllllllllllIIIIllIIlIIIlllII))
      {
        EnumFacing lllllllllllllllIIIIllIIlIIlIIlIl = lllllllllllllllIIIIllIIlIIIllIll[lllllllllllllllIIIIllIIlIIIlllIl];
        int lllllllllllllllIIIIllIIlIIlIIlII = lllllllllllllllIIIIllIIlIIlIlIlI.func_178603_a(lllllllllllllllIIIIllIIlIIlIIllI, lllllllllllllllIIIIllIIlIIlIIlIl);
        if ((lIIllllIIlllll(lllllllllllllllIIIIllIIlIIlIIlII)) && (lIIllllIIllllI(field_178612_d.get(lllllllllllllllIIIIllIIlIIlIIlII))))
        {
          field_178612_d.set(lllllllllllllllIIIIllIIlIIlIIlII, llIIllllIlIl[2]);
          "".length();
        }
        lllllllllllllllIIIIllIIlIIIlllIl++;
      }
    }
    return lllllllllllllllIIIIllIIlIIlIlIII;
  }
  
  public SetVisibility computeVisibility()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    SetVisibility lllllllllllllllIIIIllIIlIlIIIIlI = new SetVisibility();
    if (lIIllllIIlllIl(llIIllllIlIl[5] - field_178611_f, llIIllllIlIl[8]))
    {
      lllllllllllllllIIIIllIIlIlIIIIlI.setAllVisible(llIIllllIlIl[2]);
      "".length();
      if (((0x92 ^ 0xBE) & (0x6A ^ 0x46 ^ 0xFFFFFFFF)) < ((0x2E ^ 0x64) & (0xCA ^ 0x80 ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    else if (lIIllllIIllllI(field_178611_f))
    {
      lllllllllllllllIIIIllIIlIlIIIIlI.setAllVisible(llIIllllIlIl[0]);
      "".length();
      if ("   ".length() <= 0) {
        return null;
      }
    }
    else
    {
      lllllllllllllllIIIIllIIlIIllllII = (lllllllllllllllIIIIllIIlIIlllIll = field_178613_e).length;
      lllllllllllllllIIIIllIIlIIllllIl = llIIllllIlIl[0];
      "".length();
      if ((" ".length() & (" ".length() ^ -" ".length())) != 0) {
        return null;
      }
      while (!lIIllllIIlllII(lllllllllllllllIIIIllIIlIIllllIl, lllllllllllllllIIIIllIIlIIllllII))
      {
        int lllllllllllllllIIIIllIIlIlIIIIIl = lllllllllllllllIIIIllIIlIIlllIll[lllllllllllllllIIIIllIIlIIllllIl];
        if (lIIllllIIllllI(field_178612_d.get(lllllllllllllllIIIIllIIlIlIIIIIl))) {
          lllllllllllllllIIIIllIIlIlIIIIlI.setManyVisible(lllllllllllllllIIIIllIIlIlIIIIII.func_178604_a(lllllllllllllllIIIIllIIlIlIIIIIl));
        }
        lllllllllllllllIIIIllIIlIIllllIl++;
      }
    }
    return lllllllllllllllIIIIllIIlIlIIIIlI;
  }
}

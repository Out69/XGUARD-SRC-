package net.minecraft.client.renderer.chunk;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.BitSet;
import java.util.Iterator;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.EnumFacing;

public class SetVisibility
{
  public void setAllVisible(boolean llIlIIllIlll)
  {
    ;
    ;
    bitSet.set(lIIllIIIll[1], bitSet.size(), llIlIIllIlll);
  }
  
  public SetVisibility() {}
  
  private static String llllIllllIl(String llIlIIIIIIll, String llIlIIIIIlII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llIlIIIIlIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llIlIIIIIlII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llIlIIIIlIII = Cipher.getInstance("Blowfish");
      llIlIIIIlIII.init(lIIllIIIll[6], llIlIIIIlIIl);
      return new String(llIlIIIIlIII.doFinal(Base64.getDecoder().decode(llIlIIIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llIlIIIIIlll)
    {
      llIlIIIIIlll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lllllIIIlll(Object ???, Object arg1)
  {
    Object localObject;
    char llIIlllIllII;
    return ??? == localObject;
  }
  
  private static boolean lllllIIlIII(int ???)
  {
    short llIIlllIlIlI;
    return ??? != 0;
  }
  
  public boolean isVisible(EnumFacing llIlIIlIllll, EnumFacing llIlIIlIlllI)
  {
    ;
    ;
    ;
    return bitSet.get(llIlIIllIIlI.ordinal() + llIlIIlIlllI.ordinal() * COUNT_FACES);
  }
  
  public String toString()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    StringBuilder llIlIIIlllIl = new StringBuilder();
    "".length();
    short llIlIIIlIlII = (llIlIIIlIIll = EnumFacing.values()).length;
    float llIlIIIlIlIl = lIIllIIIll[1];
    "".length();
    if ("  ".length() < "  ".length()) {
      return null;
    }
    while (!lllllIIIllI(llIlIIIlIlIl, llIlIIIlIlII))
    {
      EnumFacing llIlIIIlllII = llIlIIIlIIll[llIlIIIlIlIl];
      "".length();
    }
    "".length();
    llIlIIIlIlII = (llIlIIIlIIll = EnumFacing.values()).length;
    llIlIIIlIlIl = lIIllIIIll[1];
    "".length();
    if ("   ".length() == 0) {
      return null;
    }
    label332:
    while (!lllllIIIllI(llIlIIIlIlIl, llIlIIIlIlII))
    {
      EnumFacing llIlIIIllIll = llIlIIIlIIll[llIlIIIlIlIl];
      "".length();
      llIlIIIlIIII = (llIlIIIIllll = EnumFacing.values()).length;
      llIlIIIlIIIl = lIIllIIIll[1];
      "".length();
      if (-" ".length() >= (0x29 ^ 0x2D)) {
        return null;
      }
      while (!lllllIIIllI(llIlIIIlIIIl, llIlIIIlIIII))
      {
        EnumFacing llIlIIIllIlI = llIlIIIIllll[llIlIIIlIIIl];
        if (lllllIIIlll(llIlIIIllIll, llIlIIIllIlI))
        {
          "".length();
          "".length();
          if (-"  ".length() > 0) {
            return null;
          }
        }
        else
        {
          boolean llIlIIIllIIl = llIlIIIllllI.isVisible(llIlIIIllIll, llIlIIIllIlI);
          if (lllllIIlIII(llIlIIIllIIl))
          {
            "".length();
            if (" ".length() == " ".length()) {
              break label332;
            }
            return null;
          }
          "".length();
        }
        llIlIIIlIIIl++;
      }
      "".length();
    }
    return String.valueOf(llIlIIIlllIl);
  }
  
  public void setVisible(EnumFacing llIlIlIIIIll, EnumFacing llIlIlIIIIlI, boolean llIlIIllllIl)
  {
    ;
    ;
    ;
    ;
    bitSet.set(llIlIlIIIIll.ordinal() + llIlIlIIIIlI.ordinal() * COUNT_FACES, llIlIIllllIl);
    bitSet.set(llIlIlIIIIlI.ordinal() + llIlIlIIIIll.ordinal() * COUNT_FACES, llIlIIllllIl);
  }
  
  private static boolean lllllIIIlIl(int ???)
  {
    boolean llIIllIllIll;
    return ??? == 0;
  }
  
  static
  {
    lllllIIIlII();
    llllIlllllI();
  }
  
  private static boolean lllllIIIllI(int ???, int arg1)
  {
    int i;
    short llIIllllIIII;
    return ??? >= i;
  }
  
  private static void lllllIIIlII()
  {
    lIIllIIIll = new int[7];
    lIIllIIIll[0] = " ".length();
    lIIllIIIll[1] = ((70 + '' - 200 + 137 ^ 74 + '' - 210 + 166) & (0xE6 ^ 0xB2 ^ 0x68 ^ 0x7 ^ -" ".length()));
    lIIllIIIll[2] = (0x15 ^ 0x35);
    lIIllIIIll[3] = (0xA0 ^ 0xAA);
    lIIllIIIll[4] = (0x90 ^ 0xA0 ^ 0x18 ^ 0x71);
    lIIllIIIll[5] = (0x11 ^ 0x7F);
    lIIllIIIll[6] = "  ".length();
  }
  
  public void setManyVisible(Set<EnumFacing> llIlIlIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    int llIlIlIIlIll = llIlIlIlIIIl.iterator();
    "".length();
    if (-" ".length() >= 0) {
      return;
    }
    while (!lllllIIIlIl(llIlIlIIlIll.hasNext()))
    {
      EnumFacing llIlIlIlIIII = (EnumFacing)llIlIlIIlIll.next();
      llIlIlIIlIIl = llIlIlIlIIIl.iterator();
      "".length();
      if ((95 + 123 - 197 + 159 ^ '' + 16 - 39 + 64) <= "  ".length()) {
        return;
      }
      while (!lllllIIIlIl(llIlIlIIlIIl.hasNext()))
      {
        EnumFacing llIlIlIIllll = (EnumFacing)llIlIlIIlIIl.next();
        llIlIlIIlllI.setVisible(llIlIlIlIIII, llIlIlIIllll, lIIllIIIll[0]);
      }
    }
  }
  
  private static void llllIlllllI()
  {
    lIIllIIIIl = new String[lIIllIIIll[0]];
    lIIllIIIIl[lIIllIIIll[1]] = llllIllllIl("Tj3h9NHBxnU=", "mXaBl");
  }
}

package net.minecraft.client.renderer.chunk;

import java.util.List;
import net.minecraft.client.renderer.WorldRenderer.State;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumWorldBlockLayer;

public class CompiledChunk
{
  protected void setLayerUsed(EnumWorldBlockLayer llllllllllllllllIllIIlIlIlllIlIl)
  {
    ;
    ;
    empty = llIIIIlIlll[1];
    layersUsed[llllllllllllllllIllIIlIlIlllIlIl.ordinal()] = llIIIIlIlll[0];
  }
  
  public void addTileEntity(TileEntity llllllllllllllllIllIIlIlIlIllIII)
  {
    ;
    ;
    "".length();
  }
  
  public void setState(WorldRenderer.State llllllllllllllllIllIIlIlIlIIIIII)
  {
    ;
    ;
    state = llllllllllllllllIllIIlIlIlIIIIII;
  }
  
  public boolean isVisible(EnumFacing llllllllllllllllIllIIlIlIlIIlllI, EnumFacing llllllllllllllllIllIIlIlIlIlIIII)
  {
    ;
    ;
    ;
    return setVisibility.isVisible(llllllllllllllllIllIIlIlIlIlIIIl, llllllllllllllllIllIIlIlIlIlIIII);
  }
  
  public boolean isLayerEmpty(EnumWorldBlockLayer llllllllllllllllIllIIlIlIllIlIll)
  {
    ;
    ;
    if (lIIlIllIIIIll(layersUsed[llllllllllllllllIllIIlIlIllIlIll.ordinal()]))
    {
      "".length();
      if (null == null) {
        break label51;
      }
      return (0x59 ^ 0x8) & (0xC6 ^ 0x97 ^ 0xFFFFFFFF);
    }
    label51:
    return llIIIIlIlll[0];
  }
  
  public WorldRenderer.State getState()
  {
    ;
    return state;
  }
  
  public CompiledChunk() {}
  
  public boolean isLayerStarted(EnumWorldBlockLayer llllllllllllllllIllIIlIlIlIlllll)
  {
    ;
    ;
    return layersStarted[llllllllllllllllIllIIlIlIlIlllll.ordinal()];
  }
  
  public void setVisibility(SetVisibility llllllllllllllllIllIIlIlIlIIlIIl)
  {
    ;
    ;
    setVisibility = llllllllllllllllIllIIlIlIlIIlIIl;
  }
  
  public void setLayerStarted(EnumWorldBlockLayer llllllllllllllllIllIIlIlIllIIlIl)
  {
    ;
    ;
    layersStarted[llllllllllllllllIllIIlIlIllIIlIl.ordinal()] = llIIIIlIlll[0];
  }
  
  public List<TileEntity> getTileEntities()
  {
    ;
    return tileEntities;
  }
  
  static {}
  
  private static void lIIlIllIIIIlI()
  {
    llIIIIlIlll = new int[2];
    llIIIIlIlll[0] = " ".length();
    llIIIIlIlll[1] = ((0x55 ^ 0x46) & (0xB1 ^ 0xA2 ^ 0xFFFFFFFF));
  }
  
  private static boolean lIIlIllIIIIll(int ???)
  {
    float llllllllllllllllIllIIlIlIIllllII;
    return ??? != 0;
  }
  
  public boolean isEmpty()
  {
    ;
    return empty;
  }
}

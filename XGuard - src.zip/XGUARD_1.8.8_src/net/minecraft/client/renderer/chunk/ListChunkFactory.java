package net.minecraft.client.renderer.chunk;

import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class ListChunkFactory
  implements IRenderChunkFactory
{
  public RenderChunk makeRenderChunk(World lllllllllllllllIIllIlIIllIlIllll, RenderGlobal lllllllllllllllIIllIlIIllIllIIlI, BlockPos lllllllllllllllIIllIlIIllIllIIIl, int lllllllllllllllIIllIlIIllIlIllII)
  {
    ;
    ;
    ;
    ;
    return new ListedRenderChunk(lllllllllllllllIIllIlIIllIlIllll, lllllllllllllllIIllIlIIllIllIIlI, lllllllllllllllIIllIlIIllIllIIIl, lllllllllllllllIIllIlIIllIlIllII);
  }
  
  public ListChunkFactory() {}
}

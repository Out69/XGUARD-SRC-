package net.minecraft.client.renderer;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;

public class ActiveRenderInfo
{
  public static float getRotationZ()
  {
    return rotationZ;
  }
  
  public static Block getBlockAtEntityViewpoint(World llllllllllllllIllIllIIIIlIlIIIll, Entity llllllllllllllIllIllIIIIlIIllIIl, float llllllllllllllIllIllIIIIlIIllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Vec3 llllllllllllllIllIllIIIIlIlIIIII = projectViewFromEntity(llllllllllllllIllIllIIIIlIIllIIl, llllllllllllllIllIllIIIIlIIllIII);
    BlockPos llllllllllllllIllIllIIIIlIIlllll = new BlockPos(llllllllllllllIllIllIIIIlIlIIIII);
    IBlockState llllllllllllllIllIllIIIIlIIllllI = llllllllllllllIllIllIIIIlIlIIIll.getBlockState(llllllllllllllIllIllIIIIlIIlllll);
    Block llllllllllllllIllIllIIIIlIIlllIl = llllllllllllllIllIllIIIIlIIllllI.getBlock();
    if (lIllIlllllllll(llllllllllllllIllIllIIIIlIIlllIl.getMaterial().isLiquid()))
    {
      float llllllllllllllIllIllIIIIlIIlllII = 0.0F;
      if (lIllIlllllllll(llllllllllllllIllIllIIIIlIIllllI.getBlock() instanceof BlockLiquid)) {
        llllllllllllllIllIllIIIIlIIlllII = BlockLiquid.getLiquidHeightPercent(((Integer)llllllllllllllIllIllIIIIlIIllllI.getValue(BlockLiquid.LEVEL)).intValue()) - 0.11111111F;
      }
      float llllllllllllllIllIllIIIIlIIllIll = llllllllllllllIllIllIIIIlIIlllll.getY() + llllIIIllIII[7] - llllllllllllllIllIllIIIIlIIlllII;
      if (lIlllIIIIIIIIl(lIlllIIIIIIIII(yCoord, llllllllllllllIllIllIIIIlIIllIll))) {
        llllllllllllllIllIllIIIIlIIlllIl = llllllllllllllIllIllIIIIlIlIIIll.getBlockState(llllllllllllllIllIllIIIIlIIlllll.up()).getBlock();
      }
    }
    return llllllllllllllIllIllIIIIlIIlllIl;
  }
  
  private static boolean lIllIlllllllll(int ???)
  {
    short llllllllllllllIllIllIIIIlIIlIIII;
    return ??? != 0;
  }
  
  private static void lIllIllllllllI()
  {
    llllIIIllIII = new int[8];
    llllIIIllIII[0] = (100 + 42 - 55 + 103 ^ '' + 89 - 163 + 109);
    llllIIIllIII[1] = "   ".length();
    llllIIIllIII[2] = (-(0xF616 & 0x39FB) & 0xFBBF & 0x3FF7);
    llllIIIllIII[3] = (0xEBE7 & 0x1FBF);
    llllIIIllIII[4] = (0x8BA7 & 0x7FFA);
    llllIIIllIII[5] = ((0x6D ^ 0x56) & (0x0 ^ 0x3B ^ 0xFFFFFFFF));
    llllIIIllIII[6] = "  ".length();
    llllIIIllIII[7] = " ".length();
  }
  
  public static float getRotationX()
  {
    return rotationX;
  }
  
  public static void updateRenderInfo(EntityPlayer llllllllllllllIllIllIIIIllIlIIlI, boolean llllllllllllllIllIllIIIIllIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    GlStateManager.getFloat(llllIIIllIII[2], MODELVIEW);
    GlStateManager.getFloat(llllIIIllIII[3], PROJECTION);
    GL11.glGetInteger(llllIIIllIII[4], VIEWPORT);
    float llllllllllllllIllIllIIIIllIlIIII = (VIEWPORT.get(llllIIIllIII[5]) + VIEWPORT.get(llllIIIllIII[6])) / llllIIIllIII[6];
    float llllllllllllllIllIllIIIIllIIllll = (VIEWPORT.get(llllIIIllIII[7]) + VIEWPORT.get(llllIIIllIII[1])) / llllIIIllIII[6];
    "".length();
    position = new Vec3(OBJECTCOORDS.get(llllIIIllIII[5]), OBJECTCOORDS.get(llllIIIllIII[7]), OBJECTCOORDS.get(llllIIIllIII[6]));
    if (lIllIlllllllll(llllllllllllllIllIllIIIIllIlIIIl))
    {
      "".length();
      if (((0x7A ^ 0x39) & (0x23 ^ 0x60 ^ 0xFFFFFFFF)) == 0) {
        break label212;
      }
    }
    label212:
    int llllllllllllllIllIllIIIIllIIlllI = llllIIIllIII[5];
    float llllllllllllllIllIllIIIIllIIllIl = rotationPitch;
    float llllllllllllllIllIllIIIIllIIllII = rotationYaw;
    rotationX = MathHelper.cos(llllllllllllllIllIllIIIIllIIllII * 3.1415927F / 180.0F) * (llllIIIllIII[7] - llllllllllllllIllIllIIIIllIIlllI * llllIIIllIII[6]);
    rotationZ = MathHelper.sin(llllllllllllllIllIllIIIIllIIllII * 3.1415927F / 180.0F) * (llllIIIllIII[7] - llllllllllllllIllIllIIIIllIIlllI * llllIIIllIII[6]);
    rotationYZ = -rotationZ * MathHelper.sin(llllllllllllllIllIllIIIIllIIllIl * 3.1415927F / 180.0F) * (llllIIIllIII[7] - llllllllllllllIllIllIIIIllIIlllI * llllIIIllIII[6]);
    rotationXY = rotationX * MathHelper.sin(llllllllllllllIllIllIIIIllIIllIl * 3.1415927F / 180.0F) * (llllIIIllIII[7] - llllllllllllllIllIllIIIIllIIlllI * llllIIIllIII[6]);
    rotationXZ = MathHelper.cos(llllllllllllllIllIllIIIIllIIllIl * 3.1415927F / 180.0F);
  }
  
  public static Vec3 projectViewFromEntity(Entity llllllllllllllIllIllIIIIlIllllII, double llllllllllllllIllIllIIIIlIlllIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    double llllllllllllllIllIllIIIIlIlllIlI = prevPosX + (posX - prevPosX) * llllllllllllllIllIllIIIIlIlllIll;
    double llllllllllllllIllIllIIIIlIlllIIl = prevPosY + (posY - prevPosY) * llllllllllllllIllIllIIIIlIlllIll;
    double llllllllllllllIllIllIIIIlIlllIII = prevPosZ + (posZ - prevPosZ) * llllllllllllllIllIllIIIIlIlllIll;
    double llllllllllllllIllIllIIIIlIllIlll = llllllllllllllIllIllIIIIlIlllIlI + positionxCoord;
    double llllllllllllllIllIllIIIIlIllIllI = llllllllllllllIllIllIIIIlIlllIIl + positionyCoord;
    double llllllllllllllIllIllIIIIlIllIlIl = llllllllllllllIllIllIIIIlIlllIII + positionzCoord;
    return new Vec3(llllllllllllllIllIllIIIIlIllIlll, llllllllllllllIllIllIIIIlIllIllI, llllllllllllllIllIllIIIIlIllIlIl);
  }
  
  public ActiveRenderInfo() {}
  
  public static Vec3 getPosition()
  {
    return position;
  }
  
  private static int lIlllIIIIIIIII(double paramDouble1, double paramDouble2)
  {
    return paramDouble1 < paramDouble2;
  }
  
  public static float getRotationXY()
  {
    return rotationXY;
  }
  
  public static float getRotationXZ()
  {
    return rotationXZ;
  }
  
  public static float getRotationYZ()
  {
    return rotationYZ;
  }
  
  static
  {
    lIllIllllllllI();
    VIEWPORT = GLAllocation.createDirectIntBuffer(llllIIIllIII[0]);
    MODELVIEW = GLAllocation.createDirectFloatBuffer(llllIIIllIII[0]);
    PROJECTION = GLAllocation.createDirectFloatBuffer(llllIIIllIII[0]);
  }
  
  private static boolean lIlllIIIIIIIIl(int ???)
  {
    int llllllllllllllIllIllIIIIlIIIlllI;
    return ??? >= 0;
  }
}

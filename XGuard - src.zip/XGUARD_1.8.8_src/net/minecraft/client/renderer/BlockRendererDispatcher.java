package net.minecraft.client.renderer;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.resources.IResourceManagerReloadListener;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.client.resources.model.SimpleBakedModel.Builder;
import net.minecraft.client.resources.model.WeightedBakedModel;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ReportedException;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.WorldType;

public class BlockRendererDispatcher
  implements IResourceManagerReloadListener
{
  public boolean renderBlock(IBlockState lIIIllllIIIIIll, BlockPos lIIIllllIIIIIlI, IBlockAccess lIIIlllIlllIlll, WorldRenderer lIIIllllIIIIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      int lIIIlllIlllllll = lIIIllllIIIIIll.getBlock().getRenderType();
      if (lllIIllIIl(lIIIlllIlllllll, lIIIIlIlI[1])) {
        return lIIIIlIlI[2];
      }
      switch (lIIIlllIlllllll)
      {
      case 1: 
        return fluidRenderer.renderFluid(lIIIlllIlllIlll, lIIIllllIIIIIll, lIIIlllIllllIII, lIIIllllIIIIIII);
      case 2: 
        return lIIIIlIlI[2];
      case 3: 
        IBakedModel lIIIlllIllllllI = lIIIllllIIIIlII.getModelFromBlockState(lIIIllllIIIIIll, lIIIlllIlllIlll, lIIIlllIllllIII);
        return blockModelRenderer.renderModel(lIIIlllIlllIlll, lIIIlllIllllllI, lIIIllllIIIIIll, lIIIlllIllllIII, lIIIllllIIIIIII);
      }
      return lIIIIlIlI[2];
    }
    catch (Throwable lIIIlllIlllllIl)
    {
      CrashReport lIIIlllIlllllII = CrashReport.makeCrashReport(lIIIlllIlllllIl, lIIIIlIIl[lIIIIlIlI[2]]);
      CrashReportCategory lIIIlllIllllIll = lIIIlllIlllllII.makeCategory(lIIIIlIIl[lIIIIlIlI[3]]);
      CrashReportCategory.addBlockInfo(lIIIlllIllllIll, lIIIlllIllllIII, lIIIllllIIIIIll.getBlock(), lIIIllllIIIIIll.getBlock().getMetaFromState(lIIIllllIIIIIll));
      throw new ReportedException(lIIIlllIlllllII);
    }
  }
  
  public void onResourceManagerReload(IResourceManager lIIIlllIIlllIII)
  {
    ;
    fluidRenderer.initAtlasSprites();
  }
  
  public boolean isRenderTypeChest(Block lIIIlllIIllllII, int lIIIlllIIlllllI)
  {
    ;
    ;
    if (lllIIllllI(lIIIlllIIllllII)) {
      return lIIIIlIlI[2];
    }
    int lIIIlllIIllllIl = lIIIlllIIllllII.getRenderType();
    if (lllIIllIIl(lIIIlllIIllllIl, lIIIIlIlI[0]))
    {
      "".length();
      if (((0xAD ^ 0x99) & (0xA5 ^ 0x91 ^ 0xFFFFFFFF)) != 0) {
        return (0x5E ^ 0x71) & (0x3D ^ 0x12 ^ 0xFFFFFFFF);
      }
    }
    else if (lllIIllIIl(lIIIlllIIllllIl, lIIIIlIlI[4]))
    {
      "".length();
      if (" ".length() >= 0) {
        break label155;
      }
      return (58 + 69 - 10 + 39 ^ 53 + '' - 119 + 79) & (0x38 ^ 0x2E ^ 0x51 ^ 0x4D ^ -" ".length());
    }
    label155:
    return lIIIIlIlI[2];
  }
  
  public IBakedModel getModelFromBlockState(IBlockState lIIIlllIlIlllII, IBlockAccess lIIIlllIlIllIll, BlockPos lIIIlllIlIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    Block lIIIlllIlIllIIl = lIIIlllIlIlllII.getBlock();
    if (lllIIlllII(lIIIlllIlIllIll.getWorldType(), WorldType.DEBUG_WORLD)) {
      try
      {
        lIIIlllIlIlllII = lIIIlllIlIllIIl.getActualState(lIIIlllIlIlllII, lIIIlllIlIllIll, lIIIlllIlIllIlI);
        "".length();
        if (((0x7A ^ 0x6E) & (0x58 ^ 0x4C ^ 0xFFFFFFFF)) == (0x57 ^ 0x53)) {
          return null;
        }
      }
      catch (Exception localException1) {}
    }
    IBakedModel lIIIlllIlIllIII = blockModelShapes.getModelForState(lIIIlllIlIlllII);
    if ((lllIIllIlI(lIIIlllIlIllIlI)) && (lllIIllIll(gameSettings.allowBlockAlternatives)) && (lllIIllIll(lIIIlllIlIllIII instanceof WeightedBakedModel))) {
      lIIIlllIlIllIII = ((WeightedBakedModel)lIIIlllIlIllIII).getAlternativeModel(MathHelper.getPositionRandom(lIIIlllIlIllIlI));
    }
    return lIIIlllIlIllIII;
  }
  
  public void renderBlockDamage(IBlockState lIIIllllIIlllIl, BlockPos lIIIllllIIlllII, TextureAtlasSprite lIIIllllIIlIIlI, IBlockAccess lIIIllllIIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Block lIIIllllIIllIIl = lIIIllllIIlllIl.getBlock();
    int lIIIllllIIllIII = lIIIllllIIllIIl.getRenderType();
    if (lllIIllIIl(lIIIllllIIllIII, lIIIIlIlI[0]))
    {
      lIIIllllIIlllIl = lIIIllllIIllIIl.getActualState(lIIIllllIIlllIl, lIIIllllIIllIlI, lIIIllllIIlIIll);
      IBakedModel lIIIllllIIlIlll = blockModelShapes.getModelForState(lIIIllllIIlllIl);
      IBakedModel lIIIllllIIlIllI = new SimpleBakedModel.Builder(lIIIllllIIlIlll, lIIIllllIIlIIlI).makeBakedModel();
      "".length();
    }
  }
  
  private static void lllIIllIII()
  {
    lIIIIlIlI = new int[5];
    lIIIIlIlI[0] = "   ".length();
    lIIIIlIlI[1] = (-" ".length());
    lIIIIlIlI[2] = ((0xD0 ^ 0x84 ^ 0xD ^ 0x4B) & (0x1D ^ 0x60 ^ 0x20 ^ 0x4F ^ -" ".length()));
    lIIIIlIlI[3] = " ".length();
    lIIIIlIlI[4] = "  ".length();
  }
  
  private static boolean lllIIllIIl(int ???, int arg1)
  {
    int i;
    String lIIIlllIIIIlllI;
    return ??? == i;
  }
  
  static
  {
    lllIIllIII();
    lllIIlIlll();
  }
  
  private static boolean lllIIlllII(Object ???, Object arg1)
  {
    Object localObject;
    char lIIIlllIIIIIllI;
    return ??? != localObject;
  }
  
  public BlockModelRenderer getBlockModelRenderer()
  {
    ;
    return blockModelRenderer;
  }
  
  private static void lllIIlIlll()
  {
    lIIIIlIIl = new String[lIIIIlIlI[4]];
    lIIIIlIIl[lIIIIlIlI[2]] = lllIIlIlIl("qxO0lJLCAXG23ciQJmjeGCsuknfi9GpimHILVCS3B84=", "RPkby");
    lIIIIlIIl[lIIIIlIlI[3]] = lllIIlIllI("LDUKECJOOwAaJwl5ERY6HTwJEj0LPQ==", "nYesI");
  }
  
  public void renderBlockBrightness(IBlockState lIIIlllIlIIIllI, float lIIIlllIlIIlIlI)
  {
    ;
    ;
    ;
    ;
    ;
    int lIIIlllIlIIlIIl = lIIIlllIlIIIllI.getBlock().getRenderType();
    if (lllIIlllIl(lIIIlllIlIIlIIl, lIIIIlIlI[1])) {
      switch (lIIIlllIlIIlIIl)
      {
      case 1: 
      default: 
        "".length();
        if (" ".length() == 0) {}
        break;
      case 2: 
        chestRenderer.renderChestBrightness(lIIIlllIlIIlIll.getBlock(), lIIIlllIlIIlIlI);
        "".length();
        if (-" ".length() >= 0) {}
        break;
      case 3: 
        IBakedModel lIIIlllIlIIlIII = lIIIlllIlIIIlll.getBakedModel(lIIIlllIlIIlIll, null);
        blockModelRenderer.renderModelBrightness(lIIIlllIlIIlIII, lIIIlllIlIIlIll, lIIIlllIlIIlIlI, lIIIIlIlI[3]);
      }
    }
  }
  
  private static boolean lllIIllllI(Object ???)
  {
    int lIIIlllIIIIIIlI;
    return ??? == null;
  }
  
  private IBakedModel getBakedModel(IBlockState lIIIlllIllIIllI, BlockPos lIIIlllIllIIlIl)
  {
    ;
    ;
    ;
    ;
    IBakedModel lIIIlllIllIlIII = blockModelShapes.getModelForState(lIIIlllIllIlIlI);
    if ((lllIIllIlI(lIIIlllIllIIlIl)) && (lllIIllIll(gameSettings.allowBlockAlternatives)) && (lllIIllIll(lIIIlllIllIlIII instanceof WeightedBakedModel))) {
      lIIIlllIllIlIII = ((WeightedBakedModel)lIIIlllIllIlIII).getAlternativeModel(MathHelper.getPositionRandom(lIIIlllIllIIlIl));
    }
    return lIIIlllIllIlIII;
  }
  
  private static String lllIIlIlIl(String lIIIlllIIlIllll, String lIIIlllIIlIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lIIIlllIIllIIlI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lIIIlllIIlIllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lIIIlllIIllIIIl = Cipher.getInstance("Blowfish");
      lIIIlllIIllIIIl.init(lIIIIlIlI[4], lIIIlllIIllIIlI);
      return new String(lIIIlllIIllIIIl.doFinal(Base64.getDecoder().decode(lIIIlllIIlIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lIIIlllIIllIIII)
    {
      lIIIlllIIllIIII.printStackTrace();
    }
    return null;
  }
  
  public BlockRendererDispatcher(BlockModelShapes lIIIllllIlIllII, GameSettings lIIIllllIlIlllI)
  {
    blockModelShapes = lIIIllllIlIllll;
    gameSettings = lIIIllllIlIlllI;
  }
  
  private static boolean lllIIllIlI(Object ???)
  {
    double lIIIlllIIIIIlII;
    return ??? != null;
  }
  
  private static String lllIIlIllI(String lIIIlllIIIllIlI, String lIIIlllIIIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lIIIlllIIIllIlI = new String(Base64.getDecoder().decode(lIIIlllIIIllIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lIIIlllIIIlllIl = new StringBuilder();
    char[] lIIIlllIIIlllII = lIIIlllIIIllllI.toCharArray();
    int lIIIlllIIIllIll = lIIIIlIlI[2];
    long lIIIlllIIIlIlIl = lIIIlllIIIllIlI.toCharArray();
    int lIIIlllIIIlIlII = lIIIlllIIIlIlIl.length;
    short lIIIlllIIIlIIll = lIIIIlIlI[2];
    while (lllIIlllll(lIIIlllIIIlIIll, lIIIlllIIIlIlII))
    {
      char lIIIlllIIlIIIII = lIIIlllIIIlIlIl[lIIIlllIIIlIIll];
      "".length();
      "".length();
      if ("   ".length() > "   ".length()) {
        return null;
      }
    }
    return String.valueOf(lIIIlllIIIlllIl);
  }
  
  private static boolean lllIIllIll(int ???)
  {
    char lIIIlllIIIIIIII;
    return ??? != 0;
  }
  
  private static boolean lllIIlllIl(int ???, int arg1)
  {
    int i;
    String lIIIllIllllllII;
    return ??? != i;
  }
  
  private static boolean lllIIlllll(int ???, int arg1)
  {
    int i;
    int lIIIlllIIIIlIlI;
    return ??? < i;
  }
  
  public BlockModelShapes getBlockModelShapes()
  {
    ;
    return blockModelShapes;
  }
}

package net.minecraft.client.renderer.block.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.JsonUtils;

public class BlockFaceUV
{
  private static boolean lllIIIlIlIlIl(int ???)
  {
    byte lllllllllllllllIllIIlllllIIIllll;
    return ??? != 0;
  }
  
  public float func_178348_a(int lllllllllllllllIllIIllllllIllIII)
  {
    ;
    ;
    ;
    if (lllIIIlIlIlII(uvs)) {
      throw new NullPointerException(lIIlIIlIlIII[lIIlIIlIllII[0]]);
    }
    int lllllllllllllllIllIIllllllIllIlI = lllllllllllllllIllIIllllllIlllII.func_178347_d(lllllllllllllllIllIIllllllIllIII);
    if ((lllIIIlIlIlIl(lllllllllllllllIllIIllllllIllIlI)) && (lllIIIlIlIllI(lllllllllllllllIllIIllllllIllIlI, lIIlIIlIllII[1])))
    {
      "".length();
      if (-" ".length() != "   ".length()) {
        break label94;
      }
      return 0.0F;
    }
    label94:
    return uvs[lIIlIIlIllII[0]];
  }
  
  private static String lllIIIlIIllII(String lllllllllllllllIllIIlllllIIlllII, String lllllllllllllllIllIIlllllIIllIIl)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllllllllllllllIllIIlllllIIlllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIlllllIIllIIl.getBytes(StandardCharsets.UTF_8)), lIIlIIlIllII[6]), "DES");
      Cipher lllllllllllllllIllIIlllllIIllllI = Cipher.getInstance("DES");
      lllllllllllllllIllIIlllllIIllllI.init(lIIlIIlIllII[2], lllllllllllllllIllIIlllllIIlllll);
      return new String(lllllllllllllllIllIIlllllIIllllI.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIlllllIIlllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllllllllllllllIllIIlllllIIlllIl)
    {
      lllllllllllllllIllIIlllllIIlllIl.printStackTrace();
    }
    return null;
  }
  
  private static void lllIIIlIlIIll()
  {
    lIIlIIlIllII = new int[7];
    lIIlIIlIllII[0] = ((0x38 ^ 0x25) & (0xE ^ 0x13 ^ 0xFFFFFFFF));
    lIIlIIlIllII[1] = " ".length();
    lIIlIIlIllII[2] = "  ".length();
    lIIlIIlIllII[3] = "   ".length();
    lIIlIIlIllII[4] = (0x3D ^ 0x67);
    lIIlIIlIllII[5] = (0x9B ^ 0x9F);
    lIIlIIlIllII[6] = (0x29 ^ 0x3D ^ 0x11 ^ 0xD);
  }
  
  public int func_178345_c(int lllllllllllllllIllIIllllllIIIlII)
  {
    ;
    ;
    return (lllllllllllllllIllIIllllllIIIlII + (lIIlIIlIllII[5] - rotation / lIIlIIlIllII[4])) % lIIlIIlIllII[5];
  }
  
  private int func_178347_d(int lllllllllllllllIllIIllllllIIlIlI)
  {
    ;
    ;
    return (lllllllllllllllIllIIllllllIIlIlI + rotation / lIIlIIlIllII[4]) % lIIlIIlIllII[5];
  }
  
  private static void lllIIIlIIllll()
  {
    lIIlIIlIlIII = new String[lIIlIIlIllII[2]];
    lIIlIIlIlIII[lIIlIIlIllII[0]] = lllIIIlIIlIll("PB0S", "IkaTF");
    lIIlIIlIlIII[lIIlIIlIllII[1]] = lllIIIlIIllII("J/TuTdNFhcI=", "SgCnv");
  }
  
  private static String lllIIIlIIlIll(String lllllllllllllllIllIIlllllIllIIIl, String lllllllllllllllIllIIlllllIlIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllllllllllllllIllIIlllllIllIIIl = new String(Base64.getDecoder().decode(lllllllllllllllIllIIlllllIllIIIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllllllllllllllIllIIlllllIlIllll = new StringBuilder();
    char[] lllllllllllllllIllIIlllllIlIlllI = lllllllllllllllIllIIlllllIlIlIll.toCharArray();
    int lllllllllllllllIllIIlllllIlIllIl = lIIlIIlIllII[0];
    double lllllllllllllllIllIIlllllIlIIlll = lllllllllllllllIllIIlllllIllIIIl.toCharArray();
    byte lllllllllllllllIllIIlllllIlIIllI = lllllllllllllllIllIIlllllIlIIlll.length;
    char lllllllllllllllIllIIlllllIlIIlIl = lIIlIIlIllII[0];
    while (lllIIIlIlIlll(lllllllllllllllIllIIlllllIlIIlIl, lllllllllllllllIllIIlllllIlIIllI))
    {
      char lllllllllllllllIllIIlllllIllIIlI = lllllllllllllllIllIIlllllIlIIlll[lllllllllllllllIllIIlllllIlIIlIl];
      "".length();
      "".length();
      if (((103 + '®' - 242 + 189 ^ '' + 51 - 167 + 176) & (101 + 57 - 36 + 46 ^ 116 + 106 - 162 + 78 ^ -" ".length())) != 0) {
        return null;
      }
    }
    return String.valueOf(lllllllllllllllIllIIlllllIlIllll);
  }
  
  public void setUvs(float[] lllllllllllllllIllIIlllllIllllII)
  {
    ;
    ;
    if (lllIIIlIlIlII(uvs)) {
      uvs = lllllllllllllllIllIIlllllIllllII;
    }
  }
  
  private static boolean lllIIIlIlIlll(int ???, int arg1)
  {
    int i;
    byte lllllllllllllllIllIIlllllIIlIIll;
    return ??? < i;
  }
  
  public BlockFaceUV(float[] lllllllllllllllIllIIlllllllIIlII, int lllllllllllllllIllIIlllllllIIIII)
  {
    uvs = lllllllllllllllIllIIlllllllIIIIl;
    rotation = lllllllllllllllIllIIlllllllIIIII;
  }
  
  static
  {
    lllIIIlIlIIll();
    lllIIIlIIllll();
  }
  
  private static boolean lllIIIlIlIlII(Object ???)
  {
    String lllllllllllllllIllIIlllllIIlIIIl;
    return ??? == null;
  }
  
  public float func_178346_b(int lllllllllllllllIllIIllllllIlIIlI)
  {
    ;
    ;
    ;
    if (lllIIIlIlIlII(uvs)) {
      throw new NullPointerException(lIIlIIlIlIII[lIIlIIlIllII[1]]);
    }
    int lllllllllllllllIllIIllllllIlIIIl = lllllllllllllllIllIIllllllIlIIll.func_178347_d(lllllllllllllllIllIIllllllIlIIlI);
    if ((lllIIIlIlIlIl(lllllllllllllllIllIIllllllIlIIIl)) && (lllIIIlIlIllI(lllllllllllllllIllIIllllllIlIIIl, lIIlIIlIllII[3])))
    {
      "".length();
      if (-" ".length() == -" ".length()) {
        break label95;
      }
      return 0.0F;
    }
    label95:
    return uvs[lIIlIIlIllII[1]];
  }
  
  private static boolean lllIIIlIlIllI(int ???, int arg1)
  {
    int i;
    Exception lllllllllllllllIllIIlllllIIIlIll;
    return ??? != i;
  }
  
  static class Deserializer
    implements JsonDeserializer<BlockFaceUV>
  {
    private static String lIIIIlIlllIlII(String lllllllllllllllIIllllIlIllllIlIl, String lllllllllllllllIIllllIlIlllIllll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIIllllIlIllllIlIl = new String(Base64.getDecoder().decode(lllllllllllllllIIllllIlIllllIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIIllllIlIllllIIll = new StringBuilder();
      char[] lllllllllllllllIIllllIlIllllIIlI = lllllllllllllllIIllllIlIlllIllll.toCharArray();
      int lllllllllllllllIIllllIlIllllIIIl = lIlIllIlIllI[0];
      short lllllllllllllllIIllllIlIlllIlIll = lllllllllllllllIIllllIlIllllIlIl.toCharArray();
      short lllllllllllllllIIllllIlIlllIlIlI = lllllllllllllllIIllllIlIlllIlIll.length;
      String lllllllllllllllIIllllIlIlllIlIIl = lIlIllIlIllI[0];
      while (lIIIIllIIIIllI(lllllllllllllllIIllllIlIlllIlIIl, lllllllllllllllIIllllIlIlllIlIlI))
      {
        char lllllllllllllllIIllllIlIllllIllI = lllllllllllllllIIllllIlIlllIlIll[lllllllllllllllIIllllIlIlllIlIIl];
        "".length();
        "".length();
        if (-" ".length() >= 0) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIIllllIlIllllIIll);
    }
    
    private static String lIIIIlIllllIlI(String lllllllllllllllIIllllIllIIIlIIlI, String lllllllllllllllIIllllIllIIIlIIIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIllllIllIIIlIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllllIllIIIlIIIl.getBytes(StandardCharsets.UTF_8)), lIlIllIlIllI[9]), "DES");
        Cipher lllllllllllllllIIllllIllIIIlIlII = Cipher.getInstance("DES");
        lllllllllllllllIIllllIllIIIlIlII.init(lIlIllIlIllI[4], lllllllllllllllIIllllIllIIIlIlIl);
        return new String(lllllllllllllllIIllllIllIIIlIlII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllllIllIIIlIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIllllIllIIIlIIll)
      {
        lllllllllllllllIIllllIllIIIlIIll.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIIIIllIIIIllI(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllIIllllIlIlllIIIII;
      return ??? < i;
    }
    
    static
    {
      lIIIIlIlllllIl();
      lIIIIlIllllIll();
    }
    
    private static boolean lIIIIlIlllllll(int ???)
    {
      short lllllllllllllllIIllllIlIllIllIII;
      return ??? >= 0;
    }
    
    private static void lIIIIlIlllllIl()
    {
      lIlIllIlIllI = new int[10];
      lIlIllIlIllI[0] = ((0x94 ^ 0xC7) & (0x61 ^ 0x32 ^ 0xFFFFFFFF));
      lIlIllIlIllI[1] = (0xEC ^ 0xB6);
      lIlIllIlIllI[2] = "   ".length();
      lIlIllIlIllI[3] = " ".length();
      lIlIllIlIllI[4] = "  ".length();
      lIlIllIlIllI[5] = (0x60 ^ 0x64);
      lIlIllIlIllI[6] = (0x4D ^ 0x48);
      lIlIllIlIllI[7] = (0x51 ^ 0x57);
      lIlIllIlIllI[8] = (0xC6 ^ 0xA1 ^ 0x3E ^ 0x5E);
      lIlIllIlIllI[9] = (0x85 ^ 0x8D);
    }
    
    private static String lIIIIlIlllIllI(String lllllllllllllllIIllllIllIIIIIIll, String lllllllllllllllIIllllIllIIIIIIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIllllIllIIIIlIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllllIllIIIIIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIIllllIllIIIIIlll = Cipher.getInstance("Blowfish");
        lllllllllllllllIIllllIllIIIIIlll.init(lIlIllIlIllI[4], lllllllllllllllIIllllIllIIIIlIII);
        return new String(lllllllllllllllIIllllIllIIIIIlll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllllIllIIIIIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIllllIllIIIIIllI)
      {
        lllllllllllllllIIllllIllIIIIIllI.printStackTrace();
      }
      return null;
    }
    
    private float[] parseUV(JsonObject lllllllllllllllIIllllIllIIlIIlIl)
    {
      ;
      ;
      ;
      ;
      if (lIIIIllIIIIIII(lllllllllllllllIIllllIllIIlIIlIl.has(lIlIllIlIIIl[lIlIllIlIllI[2]]))) {
        return null;
      }
      JsonArray lllllllllllllllIIllllIllIIlIlIII = JsonUtils.getJsonArray(lllllllllllllllIIllllIllIIlIlIIl, lIlIllIlIIIl[lIlIllIlIllI[5]]);
      if (lIIIIllIIIIIll(lllllllllllllllIIllllIllIIlIlIII.size(), lIlIllIlIllI[5])) {
        throw new JsonParseException(String.valueOf(new StringBuilder(lIlIllIlIIIl[lIlIllIlIllI[6]]).append(lllllllllllllllIIllllIllIIlIlIII.size())));
      }
      float[] lllllllllllllllIIllllIllIIlIIlll = new float[lIlIllIlIllI[5]];
      int lllllllllllllllIIllllIllIIlIIllI = lIlIllIlIllI[0];
      "".length();
      if (-(0x81 ^ 0x85) >= 0) {
        return null;
      }
      while (!lIIIIllIIIIlIl(lllllllllllllllIIllllIllIIlIIllI, lllllllllllllllIIllllIllIIlIIlll.length))
      {
        lllllllllllllllIIllllIllIIlIIlll[lllllllllllllllIIllllIllIIlIIllI] = JsonUtils.getFloat(lllllllllllllllIIllllIllIIlIlIII.get(lllllllllllllllIIllllIllIIlIIllI), String.valueOf(new StringBuilder(lIlIllIlIIIl[lIlIllIlIllI[7]]).append(lllllllllllllllIIllllIllIIlIIllI).append(lIlIllIlIIIl[lIlIllIlIllI[8]])));
        lllllllllllllllIIllllIllIIlIIllI++;
      }
      return lllllllllllllllIIllllIllIIlIIlll;
    }
    
    private static void lIIIIlIllllIll()
    {
      lIlIllIlIIIl = new String[lIlIllIlIllI[9]];
      lIlIllIlIIIl[lIlIllIlIllI[0]] = lIIIIlIlllIlII("GDYhAy4DNjs=", "jYUbZ");
      lIlIllIlIIIl[lIlIllIlIllI[3]] = lIIIIlIlllIlII("OB05IC8YF28zLAUSOygsH1M=", "qsOAC");
      lIlIllIlIIIl[lIlIllIlIllI[4]] = lIIIIlIlllIllI("7CGI/4t4dMxx15o6QWsapWHP50t0nIfoGbg17tIqkzwEKk1yau91UA==", "sfWhv");
      lIlIllIlIIIl[lIlIllIlIllI[2]] = lIIIIlIllllIlI("jEtODQ48ZfI=", "PQFQU");
      lIlIllIlIIIl[lIlIllIlIllI[5]] = lIIIIlIllllIlI("7eAZK6feqsc=", "lvtYo");
      lIlIllIlIIIl[lIlIllIlIllI[6]] = lIIIIlIlllIlII("ADYDESoxKxdUfWU7BVQ/JCIGETppbhUbPCsqSVQ=", "ENstI");
      lIlIllIlIIIl[lIlIllIlIllI[7]] = lIIIIlIlllIlII("DyMJ", "zURqi");
      lIlIllIlIIIl[lIlIllIlIllI[8]] = lIIIIlIlllIllI("02np0uCjwl4=", "QFjht");
    }
    
    public BlockFaceUV deserialize(JsonElement lllllllllllllllIIllllIllIIlllIIl, Type lllllllllllllllIIllllIllIIllllll, JsonDeserializationContext lllllllllllllllIIllllIllIIlllllI)
      throws JsonParseException
    {
      ;
      ;
      ;
      ;
      ;
      JsonObject lllllllllllllllIIllllIllIIllllIl = lllllllllllllllIIllllIllIIlllIIl.getAsJsonObject();
      float[] lllllllllllllllIIllllIllIIllllII = lllllllllllllllIIllllIllIIlllIlI.parseUV(lllllllllllllllIIllllIllIIllllIl);
      int lllllllllllllllIIllllIllIIlllIll = lllllllllllllllIIllllIllIIlllIlI.parseRotation(lllllllllllllllIIllllIllIIllllIl);
      return new BlockFaceUV(lllllllllllllllIIllllIllIIllllII, lllllllllllllllIIllllIllIIlllIll);
    }
    
    private static boolean lIIIIllIIIIIIl(int ???, int arg1)
    {
      int i;
      short lllllllllllllllIIllllIlIllIlllII;
      return ??? <= i;
    }
    
    private static boolean lIIIIllIIIIIll(int ???, int arg1)
    {
      int i;
      short lllllllllllllllIIllllIlIllIlIlII;
      return ??? != i;
    }
    
    private static boolean lIIIIllIIIIIII(int ???)
    {
      Exception lllllllllllllllIIllllIlIllIllIlI;
      return ??? == 0;
    }
    
    Deserializer() {}
    
    protected int parseRotation(JsonObject lllllllllllllllIIllllIllIIllIIlI)
    {
      ;
      ;
      int lllllllllllllllIIllllIllIIllIIIl = JsonUtils.getInt(lllllllllllllllIIllllIllIIllIIlI, lIlIllIlIIIl[lIlIllIlIllI[0]], lIlIllIlIllI[0]);
      if ((lIIIIlIlllllll(lllllllllllllllIIllllIllIIllIIIl)) && (lIIIIllIIIIIII(lllllllllllllllIIllllIllIIllIIIl % lIlIllIlIllI[1])) && (lIIIIllIIIIIIl(lllllllllllllllIIllllIllIIllIIIl / lIlIllIlIllI[1], lIlIllIlIllI[2]))) {
        return lllllllllllllllIIllllIllIIllIIIl;
      }
      throw new JsonParseException(String.valueOf(new StringBuilder(lIlIllIlIIIl[lIlIllIlIllI[3]]).append(lllllllllllllllIIllllIllIIllIIIl).append(lIlIllIlIIIl[lIlIllIlIllI[4]])));
    }
    
    private static boolean lIIIIllIIIIlIl(int ???, int arg1)
    {
      int i;
      Exception lllllllllllllllIIllllIlIlllIIlII;
      return ??? >= i;
    }
  }
}

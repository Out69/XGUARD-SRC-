package net.minecraft.client.renderer.block.model;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.resources.model.ModelRotation;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;

public class ModelBlockDefinition
{
  public boolean equals(Object lllllllllllllllIllIlIIIllllIlIII)
  {
    ;
    ;
    ;
    if (lllIIIIlIIIll(lllllllllllllllIllIlIIIllllIIlII, lllllllllllllllIllIlIIIllllIlIII)) {
      return lIIlIIIlIIll[0];
    }
    if (lllIIIIlIIlII(lllllllllllllllIllIlIIIllllIlIII instanceof ModelBlockDefinition))
    {
      ModelBlockDefinition lllllllllllllllIllIlIIIllllIIllI = (ModelBlockDefinition)lllllllllllllllIllIlIIIllllIlIII;
      return mapVariants.equals(mapVariants);
    }
    return lIIlIIIlIIll[1];
  }
  
  public int hashCode()
  {
    ;
    return mapVariants.hashCode();
  }
  
  private static boolean lllIIIIlIIIlI(Object ???)
  {
    char lllllllllllllllIllIlIIIlllIIlIll;
    return ??? == null;
  }
  
  private static boolean lllIIIIlIIlII(int ???)
  {
    byte lllllllllllllllIllIlIIIlllIIIlIl;
    return ??? != 0;
  }
  
  public ModelBlockDefinition(List<ModelBlockDefinition> lllllllllllllllIllIlIIlIIIIlIIlI)
  {
    long lllllllllllllllIllIlIIlIIIIIllll = lllllllllllllllIllIlIIlIIIIlIIlI.iterator();
    "".length();
    if ("  ".length() < 0) {
      throw null;
    }
    while (!lllIIIIIlllll(lllllllllllllllIllIlIIlIIIIIllll.hasNext()))
    {
      ModelBlockDefinition lllllllllllllllIllIlIIlIIIIlIlIl = (ModelBlockDefinition)lllllllllllllllIllIlIIlIIIIIllll.next();
      mapVariants.putAll(mapVariants);
    }
  }
  
  public ModelBlockDefinition(Collection<Variants> lllllllllllllllIllIlIIlIIIlIllll)
  {
    short lllllllllllllllIllIlIIlIIIlIlIIl = lllllllllllllllIllIlIIlIIIlIllll.iterator();
    "".length();
    if ("  ".length() <= 0) {
      throw null;
    }
    while (!lllIIIIIlllll(lllllllllllllllIllIlIIlIIIlIlIIl.hasNext()))
    {
      Variants lllllllllllllllIllIlIIlIIIlIlllI = (Variants)lllllllllllllllIllIlIIlIIIlIlIIl.next();
      "".length();
    }
  }
  
  private static boolean lllIIIIIlllll(int ???)
  {
    boolean lllllllllllllllIllIlIIIllIllllll;
    return ??? == 0;
  }
  
  static {}
  
  public static ModelBlockDefinition parseFromReader(Reader lllllllllllllllIllIlIIlIIIllIllI)
  {
    ;
    return (ModelBlockDefinition)GSON.fromJson(lllllllllllllllIllIlIIlIIIllIlIl, ModelBlockDefinition.class);
  }
  
  private static void lllIIIIIllIll()
  {
    lIIlIIIlIIll = new int[2];
    lIIlIIIlIIll[0] = " ".length();
    lIIlIIIlIIll[1] = ((0x23 ^ 0x15) & (0xBD ^ 0x8B ^ 0xFFFFFFFF));
  }
  
  private static boolean lllIIIIlIIIll(Object ???, Object arg1)
  {
    Object localObject;
    Exception lllllllllllllllIllIlIIIlllIIlllI;
    return ??? == localObject;
  }
  
  public Variants getVariants(String lllllllllllllllIllIlIIIlllllllIl)
  {
    ;
    ;
    ;
    Variants lllllllllllllllIllIlIIlIIIIIIIIl = (Variants)mapVariants.get(lllllllllllllllIllIlIIIlllllllIl);
    if (lllIIIIlIIIlI(lllllllllllllllIllIlIIlIIIIIIIIl)) {
      throw new MissingVariantException();
    }
    return lllllllllllllllIllIlIIlIIIIIIIIl;
  }
  
  public static class Deserializer
    implements JsonDeserializer<ModelBlockDefinition>
  {
    private static void llllIlIIlIl()
    {
      lIIlIlIlII = new String[lIIlIlIlIl[1]];
      lIIlIlIlII[lIIlIlIlIl[0]] = llllIlIIlII("KerhnKpbiEdEwkRUMoLVjg==", "OcRSE");
    }
    
    private static boolean llllIlIlIII(int ???)
    {
      short lllIlIIIIlII;
      return ??? != 0;
    }
    
    public ModelBlockDefinition deserialize(JsonElement lllIllIIIlll, Type lllIllIIllII, JsonDeserializationContext lllIllIIIllI)
      throws JsonParseException
    {
      ;
      ;
      ;
      ;
      ;
      JsonObject lllIllIIlIlI = lllIllIIIlll.getAsJsonObject();
      List<ModelBlockDefinition.Variants> lllIllIIlIIl = lllIllIIlIII.parseVariantsList(lllIllIIIllI, lllIllIIlIlI);
      return new ModelBlockDefinition(lllIllIIlIIl);
    }
    
    private static void llllIlIIllI()
    {
      lIIlIlIlIl = new int[3];
      lIIlIlIlIl[0] = ((0x89 ^ 0xAF) & (0x8D ^ 0xAB ^ 0xFFFFFFFF));
      lIIlIlIlIl[1] = " ".length();
      lIIlIlIlIl[2] = "  ".length();
    }
    
    protected List<ModelBlockDefinition.Variants> parseVariantsList(JsonDeserializationContext lllIlIllIlIl, JsonObject lllIlIllIlII)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      JsonObject lllIlIlllIIl = JsonUtils.getJsonObject(lllIlIllIlII, lIIlIlIlII[lIIlIlIlIl[0]]);
      List<ModelBlockDefinition.Variants> lllIlIlllIII = Lists.newArrayList();
      boolean lllIlIllIIII = lllIlIlllIIl.entrySet().iterator();
      "".length();
      if (-"   ".length() >= 0) {
        return null;
      }
      while (!llllIlIIlll(lllIlIllIIII.hasNext()))
      {
        Map.Entry<String, JsonElement> lllIlIllIlll = (Map.Entry)lllIlIllIIII.next();
        "".length();
      }
      return lllIlIlllIII;
    }
    
    public Deserializer() {}
    
    protected ModelBlockDefinition.Variants parseVariants(JsonDeserializationContext lllIlIlIIIIl, Map.Entry<String, JsonElement> lllIlIlIIllI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      String lllIlIlIIlIl = (String)lllIlIlIIllI.getKey();
      List<ModelBlockDefinition.Variant> lllIlIlIIlII = Lists.newArrayList();
      JsonElement lllIlIlIIIll = (JsonElement)lllIlIlIIllI.getValue();
      if (llllIlIlIII(lllIlIlIIIll.isJsonArray()))
      {
        lllIlIIllIll = lllIlIlIIIll.getAsJsonArray().iterator();
        "".length();
        if (" ".length() == -" ".length()) {
          return null;
        }
        while (!llllIlIIlll(lllIlIIllIll.hasNext()))
        {
          JsonElement lllIlIlIIIlI = (JsonElement)lllIlIIllIll.next();
          "".length();
        }
        "".length();
        if (((0x7 ^ 0x65 ^ 0xCB ^ 0xB1) & (111 + '' - 119 + 12 ^ 16 + 12 - -52 + 67 ^ -" ".length())) != 0) {
          return null;
        }
      }
      else
      {
        "".length();
      }
      return new ModelBlockDefinition.Variants(lllIlIlIIlIl, lllIlIlIIlII);
    }
    
    static
    {
      llllIlIIllI();
      llllIlIIlIl();
    }
    
    private static String llllIlIIlII(String lllIlIIIlIIl, String lllIlIIIlIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllIlIIIlllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllIlIIIlIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllIlIIIllIl = Cipher.getInstance("Blowfish");
        lllIlIIIllIl.init(lIIlIlIlIl[2], lllIlIIIlllI);
        return new String(lllIlIIIllIl.doFinal(Base64.getDecoder().decode(lllIlIIIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllIlIIIllII)
      {
        lllIlIIIllII.printStackTrace();
      }
      return null;
    }
    
    private static boolean llllIlIIlll(int ???)
    {
      int lllIlIIIIIlI;
      return ??? == 0;
    }
  }
  
  public static class Variants
  {
    public List<ModelBlockDefinition.Variant> getVariants()
    {
      ;
      return listVariants;
    }
    
    private static boolean llIllIIllIllII(int ???)
    {
      boolean llllllllllllllIlIIlIIlIlIIllIIll;
      return ??? == 0;
    }
    
    public boolean equals(Object llllllllllllllIlIIlIIlIlIlIIIlIl)
    {
      ;
      ;
      ;
      if (llIllIIllIlIll(llllllllllllllIlIIlIIlIlIlIIIllI, llllllllllllllIlIIlIIlIlIlIIIlIl)) {
        return lIIIllllIlIlI[0];
      }
      if (llIllIIllIllII(llllllllllllllIlIIlIIlIlIlIIIlIl instanceof Variants)) {
        return lIIIllllIlIlI[1];
      }
      Variants llllllllllllllIlIIlIIlIlIlIIIlII = (Variants)llllllllllllllIlIIlIIlIlIlIIIlIl;
      if (llIllIIllIllII(name.equals(name)))
      {
        "".length();
        if (((15 + 106 - 42 + 56 ^ 10 + 19 - -31 + 106) & (0xF ^ 0x18 ^ 0x7C ^ 0x4A ^ -" ".length())) >= 0) {
          break label171;
        }
        return ('¢' + '' - 294 + 148 ^ 79 + 76 - 120 + 129) & (0x91 ^ 0x88 ^ 0x3F ^ 0x2C ^ -" ".length());
      }
      label171:
      return listVariants.equals(listVariants);
    }
    
    public int hashCode()
    {
      ;
      ;
      int llllllllllllllIlIIlIIlIlIIllllIl = name.hashCode();
      llllllllllllllIlIIlIIlIlIIllllIl = lIIIllllIlIlI[2] * llllllllllllllIlIIlIIlIlIIllllIl + listVariants.hashCode();
      return llllllllllllllIlIIlIIlIlIIllllIl;
    }
    
    static {}
    
    public Variants(String llllllllllllllIlIIlIIlIlIlIIlllI, List<ModelBlockDefinition.Variant> llllllllllllllIlIIlIIlIlIlIIllIl)
    {
      name = llllllllllllllIlIIlIIlIlIlIlIIIl;
      listVariants = llllllllllllllIlIIlIIlIlIlIIllIl;
    }
    
    private static void llIllIIllIlIlI()
    {
      lIIIllllIlIlI = new int[3];
      lIIIllllIlIlI[0] = " ".length();
      lIIIllllIlIlI[1] = ((0x63 ^ 0x9 ^ 0x91 ^ 0xA6) & (83 + 102 - 126 + 157 ^ 58 + 99 - 135 + 111 ^ -" ".length()));
      lIIIllllIlIlI[2] = (0x7F ^ 0x60);
    }
    
    private static boolean llIllIIllIlIll(Object ???, Object arg1)
    {
      Object localObject;
      double llllllllllllllIlIIlIIlIlIIllIlIl;
      return ??? == localObject;
    }
  }
  
  public class MissingVariantException
    extends RuntimeException
  {
    public MissingVariantException() {}
  }
  
  public static class Variant
  {
    public Variant(ResourceLocation llllllllllllllllIlIlIlllIIIlIIlI, ModelRotation llllllllllllllllIlIlIlllIIIlIIIl, boolean llllllllllllllllIlIlIlllIIIlIIII, int llllllllllllllllIlIlIlllIIIIllll)
    {
      modelLocation = llllllllllllllllIlIlIlllIIIlIIlI;
      modelRotation = llllllllllllllllIlIlIlllIIIlIllI;
      uvLock = llllllllllllllllIlIlIlllIIIlIIII;
      weight = llllllllllllllllIlIlIlllIIIIllll;
    }
    
    public int getWeight()
    {
      ;
      return weight;
    }
    
    private static boolean lIIlllIIllllI(int ???)
    {
      double llllllllllllllllIlIlIllIlllIlIII;
      return ??? != 0;
    }
    
    public ResourceLocation getModelLocation()
    {
      ;
      return modelLocation;
    }
    
    public boolean isUvLocked()
    {
      ;
      return uvLock;
    }
    
    private static boolean lIIlllIIlllII(Object ???, Object arg1)
    {
      Object localObject;
      byte llllllllllllllllIlIlIllIlllIllII;
      return ??? == localObject;
    }
    
    private static boolean lIIlllIlIIIII(Object ???)
    {
      double llllllllllllllllIlIlIllIlllIlIlI;
      return ??? != null;
    }
    
    private static boolean lIIlllIIlllIl(int ???)
    {
      String llllllllllllllllIlIlIllIlllIIllI;
      return ??? == 0;
    }
    
    public ModelRotation getRotation()
    {
      ;
      return modelRotation;
    }
    
    private static boolean lIIlllIIlllll(int ???, int arg1)
    {
      int i;
      boolean llllllllllllllllIlIlIllIllllIIII;
      return ??? == i;
    }
    
    private static void lIIlllIIllIll()
    {
      llIIlllIIll = new int[3];
      llIIlllIIll[0] = " ".length();
      llIIlllIIll[1] = ((0xFA ^ 0x93 ^ 0xE1 ^ 0xB2) & (0x45 ^ 0x19 ^ 0x23 ^ 0x45 ^ -" ".length()));
      llIIlllIIll[2] = (0x0 ^ 0x1F);
    }
    
    public boolean equals(Object llllllllllllllllIlIlIllIlllllIll)
    {
      ;
      ;
      ;
      if (lIIlllIIlllII(llllllllllllllllIlIlIllIllllllll, llllllllllllllllIlIlIllIlllllIll)) {
        return llIIlllIIll[0];
      }
      if (lIIlllIIlllIl(llllllllllllllllIlIlIllIlllllIll instanceof Variant)) {
        return llIIlllIIll[1];
      }
      Variant llllllllllllllllIlIlIllIllllllIl = (Variant)llllllllllllllllIlIlIllIlllllIll;
      if ((lIIlllIIllllI(modelLocation.equals(modelLocation))) && (lIIlllIIlllII(modelRotation, modelRotation)) && (lIIlllIIlllll(uvLock, uvLock))) {
        return llIIlllIIll[0];
      }
      return llIIlllIIll[1];
    }
    
    static {}
    
    public int hashCode()
    {
      ;
      ;
      int llllllllllllllllIlIlIllIllllIllI = modelLocation.hashCode();
      if (lIIlllIlIIIII(modelRotation))
      {
        "".length();
        if (" ".length() >= 0) {
          break label64;
        }
        return (0x57 ^ 0x7B) & (0x3 ^ 0x2F ^ 0xFFFFFFFF);
      }
      label64:
      llllllllllllllllIlIlIllIllllIllI = modelRotation.hashCode() + llIIlllIIll[1];
      if (lIIlllIIllllI(uvLock))
      {
        "".length();
        if ("   ".length() != (0x4 ^ 0x72 ^ 0x5A ^ 0x28)) {
          break label150;
        }
        return (0x18 ^ 0x49 ^ 0x54 ^ 0x44) & (0xF8 ^ 0xA9 ^ 0x16 ^ 0x6 ^ -" ".length());
      }
      label150:
      llllllllllllllllIlIlIllIllllIllI = llIIlllIIll[0] + llIIlllIIll[1];
      return llllllllllllllllIlIlIllIllllIllI;
    }
    
    public static class Deserializer
      implements JsonDeserializer<ModelBlockDefinition.Variant>
    {
      private static boolean llIllIIllIIllI(int ???, int arg1)
      {
        int i;
        float llllllllllllllIlIIlIIlIllIIllIII;
        return ??? < i;
      }
      
      private static String llIllIIlIlIlIl(String llllllllllllllIlIIlIIlIlllIIIllI, String llllllllllllllIlIIlIIlIlllIIIlIl)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllIlIIlIIlIlllIIlIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIlIIlIlllIIIlIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher llllllllllllllIlIIlIIlIlllIIlIII = Cipher.getInstance("Blowfish");
          llllllllllllllIlIIlIIlIlllIIlIII.init(lIIIllllIIlII[2], llllllllllllllIlIIlIIlIlllIIlIIl);
          return new String(llllllllllllllIlIIlIIlIlllIIlIII.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIlIIlIlllIIIllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllIlIIlIIlIlllIIIlll)
        {
          llllllllllllllIlIIlIIlIlllIIIlll.printStackTrace();
        }
        return null;
      }
      
      static
      {
        llIllIIllIIlII();
        llIllIIlIllIll();
      }
      
      public Deserializer() {}
      
      private static boolean llIllIIllIIlIl(Object ???)
      {
        short llllllllllllllIlIIlIIlIllIIlIllI;
        return ??? == null;
      }
      
      protected int parseWeight(JsonObject llllllllllllllIlIIlIIlIlllIlIllI)
      {
        ;
        return JsonUtils.getInt(llllllllllllllIlIIlIIlIlllIlIllI, lIIIllllIIIIl[lIIIllllIIlII[7]], lIIIllllIIlII[1]);
      }
      
      private boolean parseUvLock(JsonObject llllllllllllllIlIIlIIlIlllllIllI)
      {
        ;
        return JsonUtils.getBoolean(llllllllllllllIlIIlIIlIlllllIllI, lIIIllllIIIIl[lIIIllllIIlII[1]], lIIIllllIIlII[0]);
      }
      
      private static String llIllIIlIllIlI(String llllllllllllllIlIIlIIlIllIlIIIIl, String llllllllllllllIlIIlIIlIllIIllllI)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllIlIIlIIlIllIlIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIIlIIlIllIIllllI.getBytes(StandardCharsets.UTF_8)), lIIIllllIIlII[8]), "DES");
          Cipher llllllllllllllIlIIlIIlIllIlIIIll = Cipher.getInstance("DES");
          llllllllllllllIlIIlIIlIllIlIIIll.init(lIIIllllIIlII[2], llllllllllllllIlIIlIIlIllIlIIlII);
          return new String(llllllllllllllIlIIlIIlIllIlIIIll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIIlIIlIllIlIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllIlIIlIIlIllIlIIIlI)
        {
          llllllllllllllIlIIlIIlIllIlIIIlI.printStackTrace();
        }
        return null;
      }
      
      public ModelBlockDefinition.Variant deserialize(JsonElement llllllllllllllIlIIlIIllIIIIIIlIl, Type llllllllllllllIlIIlIIllIIIIIllIl, JsonDeserializationContext llllllllllllllIlIIlIIllIIIIIllII)
        throws JsonParseException
      {
        ;
        ;
        ;
        ;
        ;
        ;
        ;
        JsonObject llllllllllllllIlIIlIIllIIIIIlIll = llllllllllllllIlIIlIIllIIIIIIlIl.getAsJsonObject();
        String llllllllllllllIlIIlIIllIIIIIlIlI = llllllllllllllIlIIlIIllIIIIIllll.parseModel(llllllllllllllIlIIlIIllIIIIIlIll);
        ModelRotation llllllllllllllIlIIlIIllIIIIIlIIl = llllllllllllllIlIIlIIllIIIIIllll.parseRotation(llllllllllllllIlIIlIIllIIIIIlIll);
        boolean llllllllllllllIlIIlIIllIIIIIlIII = llllllllllllllIlIIlIIllIIIIIllll.parseUvLock(llllllllllllllIlIIlIIllIIIIIlIll);
        int llllllllllllllIlIIlIIllIIIIIIlll = llllllllllllllIlIIlIIllIIIIIllll.parseWeight(llllllllllllllIlIIlIIllIIIIIlIll);
        return new ModelBlockDefinition.Variant(llllllllllllllIlIIlIIllIIIIIllll.makeModelLocation(llllllllllllllIlIIlIIllIIIIIlIlI), llllllllllllllIlIIlIIllIIIIIlIIl, llllllllllllllIlIIlIIllIIIIIlIII, llllllllllllllIlIIlIIllIIIIIIlll);
      }
      
      private static void llIllIIlIllIll()
      {
        lIIIllllIIIIl = new String[lIIIllllIIlII[8]];
        lIIIllllIIIIl[lIIIllllIIlII[0]] = llIllIIlIlIlIl("SiBsBjgV55c=", "qhert");
        lIIIllllIIIIl[lIIIllllIIlII[1]] = llIllIIlIllIII("EQIkBwYP", "dtHhe");
        lIIIllllIIIIl[lIIIllllIIlII[2]] = llIllIIlIllIII("Lw==", "WSPbZ");
        lIIIllllIIIIl[lIIIllllIIlII[3]] = llIllIIlIllIlI("2nywOl7IPgs=", "vElvF");
        lIIIllllIIIIl[lIIIllllIIlII[4]] = llIllIIlIlIlIl("Wbb7NFDllW+5hFcLyu6czS9eIRfN0Ez/YDSsgrRfSpI=", "yncKe");
        lIIIllllIIIIl[lIIIllllIIlII[5]] = llIllIIlIlIlIl("pzoJni63oPw=", "sPLdU");
        lIIIllllIIIIl[lIIIllllIIlII[6]] = llIllIIlIllIlI("BM9BsP8HxHo=", "JBeWE");
        lIIIllllIIIIl[lIIIllllIIlII[7]] = llIllIIlIlIlIl("bc9AmmmBc38=", "pQbte");
      }
      
      private static void llIllIIllIIlII()
      {
        lIIIllllIIlII = new int[9];
        lIIIllllIIlII[0] = ((0x1E ^ 0x59 ^ 0xF3 ^ 0xB8) & (0x26 ^ 0x1B ^ 0x12 ^ 0x23 ^ -" ".length()));
        lIIIllllIIlII[1] = " ".length();
        lIIIllllIIlII[2] = "  ".length();
        lIIIllllIIlII[3] = "   ".length();
        lIIIllllIIlII[4] = (0x95 ^ 0xA1 ^ 0x92 ^ 0xA2);
        lIIIllllIIlII[5] = (78 + 105 - 61 + 17 ^ 51 + 41 - 45 + 95);
        lIIIllllIIlII[6] = (0x67 ^ 0x3D ^ 0xA ^ 0x56);
        lIIIllllIIlII[7] = (79 + 74 - 60 + 66 ^ 96 + 55 - 113 + 114);
        lIIIllllIIlII[8] = (27 + 51 - 41 + 165 ^ 93 + '¹' - 238 + 154);
      }
      
      private static String llIllIIlIllIII(String llllllllllllllIlIIlIIlIllIllIllI, String llllllllllllllIlIIlIIlIllIllIlIl)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        llllllllllllllIlIIlIIlIllIllIllI = new String(Base64.getDecoder().decode(llllllllllllllIlIIlIIlIllIllIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder llllllllllllllIlIIlIIlIllIllIlII = new StringBuilder();
        char[] llllllllllllllIlIIlIIlIllIllIIll = llllllllllllllIlIIlIIlIllIllIlIl.toCharArray();
        int llllllllllllllIlIIlIIlIllIllIIlI = lIIIllllIIlII[0];
        float llllllllllllllIlIIlIIlIllIlIllII = llllllllllllllIlIIlIIlIllIllIllI.toCharArray();
        long llllllllllllllIlIIlIIlIllIlIlIll = llllllllllllllIlIIlIIlIllIlIllII.length;
        boolean llllllllllllllIlIIlIIlIllIlIlIlI = lIIIllllIIlII[0];
        while (llIllIIllIIllI(llllllllllllllIlIIlIIlIllIlIlIlI, llllllllllllllIlIIlIIlIllIlIlIll))
        {
          char llllllllllllllIlIIlIIlIllIllIlll = llllllllllllllIlIIlIIlIllIlIllII[llllllllllllllIlIIlIIlIllIlIlIlI];
          "".length();
          "".length();
          if (" ".length() != " ".length()) {
            return null;
          }
        }
        return String.valueOf(llllllllllllllIlIIlIIlIllIllIlII);
      }
      
      protected ModelRotation parseRotation(JsonObject llllllllllllllIlIIlIIlIllllIlIlI)
      {
        ;
        ;
        ;
        ;
        int llllllllllllllIlIIlIIlIllllIlIIl = JsonUtils.getInt(llllllllllllllIlIIlIIlIllllIlIlI, lIIIllllIIIIl[lIIIllllIIlII[2]], lIIIllllIIlII[0]);
        int llllllllllllllIlIIlIIlIllllIlIII = JsonUtils.getInt(llllllllllllllIlIIlIIlIllllIIlII, lIIIllllIIIIl[lIIIllllIIlII[3]], lIIIllllIIlII[0]);
        ModelRotation llllllllllllllIlIIlIIlIllllIIllI = ModelRotation.getModelRotation(llllllllllllllIlIIlIIlIllllIlIIl, llllllllllllllIlIIlIIlIllllIlIII);
        if (llIllIIllIIlIl(llllllllllllllIlIIlIIlIllllIIllI)) {
          throw new JsonParseException(String.valueOf(new StringBuilder(lIIIllllIIIIl[lIIIllllIIlII[4]]).append(llllllllllllllIlIIlIIlIllllIlIIl).append(lIIIllllIIIIl[lIIIllllIIlII[5]]).append(llllllllllllllIlIIlIIlIllllIlIII)));
        }
        return llllllllllllllIlIIlIIlIllllIIllI;
      }
      
      protected String parseModel(JsonObject llllllllllllllIlIIlIIlIlllIllIll)
      {
        ;
        return JsonUtils.getString(llllllllllllllIlIIlIIlIlllIllIll, lIIIllllIIIIl[lIIIllllIIlII[6]]);
      }
      
      private ResourceLocation makeModelLocation(String llllllllllllllIlIIlIIlIllllllIlI)
      {
        ;
        ;
        ResourceLocation llllllllllllllIlIIlIIlIllllllIll = new ResourceLocation(llllllllllllllIlIIlIIlIlllllllII);
        llllllllllllllIlIIlIIlIllllllIll = new ResourceLocation(llllllllllllllIlIIlIIlIllllllIll.getResourceDomain(), String.valueOf(new StringBuilder(lIIIllllIIIIl[lIIIllllIIlII[0]]).append(llllllllllllllIlIIlIIlIllllllIll.getResourcePath())));
        return llllllllllllllIlIIlIIlIllllllIll;
      }
    }
  }
}

package net.minecraft.client.renderer.block.model;

import net.minecraft.util.EnumFacing.Axis;
import org.lwjgl.util.vector.Vector3f;

public class BlockPartRotation
{
  public BlockPartRotation(Vector3f lllIIIlIIlIlll, EnumFacing.Axis lllIIIlIIllIll, float lllIIIlIIlIlIl, boolean lllIIIlIIlIlII)
  {
    origin = lllIIIlIIlIlll;
    axis = lllIIIlIIlIllI;
    angle = lllIIIlIIlIlIl;
    rescale = lllIIIlIIlIlII;
  }
}

package net.minecraft.client.renderer.block.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.MathHelper;
import org.lwjgl.util.vector.Vector3f;

public class ItemTransformVec3f
{
  private static boolean lIIlIIlIIIIlII(Object ???, Object arg1)
  {
    Object localObject;
    byte lllllllllllllllIIlIIlllIIIlIIllI;
    return ??? == localObject;
  }
  
  static {}
  
  public boolean equals(Object lllllllllllllllIIlIIlllIIIlllIII)
  {
    ;
    ;
    ;
    if (lIIlIIlIIIIlII(lllllllllllllllIIlIIlllIIIlllIIl, lllllllllllllllIIlIIlllIIIlllIII)) {
      return lIlllllllIIl[0];
    }
    if (lIIlIIlIIIIlIl(lllllllllllllllIIlIIlllIIIlllIIl.getClass(), lllllllllllllllIIlIIlllIIIlllIII.getClass())) {
      return lIlllllllIIl[1];
    }
    ItemTransformVec3f lllllllllllllllIIlIIlllIIIllIlll = (ItemTransformVec3f)lllllllllllllllIIlIIlllIIIlllIII;
    if (lIIlIIlIIIIllI(rotation.equals(rotation)))
    {
      "".length();
      if (-"   ".length() > 0) {
        return (0x90 ^ 0xB4 ^ 0x8A ^ 0xB7) & (0xFE ^ 0xC1 ^ 0x6D ^ 0x4B ^ -" ".length());
      }
    }
    else if (lIIlIIlIIIIllI(scale.equals(scale)))
    {
      "".length();
      if ((0x33 ^ 0x37) > " ".length()) {
        break label181;
      }
      return (0x73 ^ 0x48) & (0xFD ^ 0xC6 ^ 0xFFFFFFFF);
    }
    label181:
    return translation.equals(translation);
  }
  
  private static boolean lIIlIIlIIIIlIl(Object ???, Object arg1)
  {
    Object localObject;
    float lllllllllllllllIIlIIlllIIIlIlIlI;
    return ??? != localObject;
  }
  
  public int hashCode()
  {
    ;
    ;
    int lllllllllllllllIIlIIlllIIIllIIII = rotation.hashCode();
    lllllllllllllllIIlIIlllIIIllIIII = lIlllllllIIl[2] * lllllllllllllllIIlIIlllIIIllIIII + translation.hashCode();
    lllllllllllllllIIlIIlllIIIllIIII = lIlllllllIIl[2] * lllllllllllllllIIlIIlllIIIllIIII + scale.hashCode();
    return lllllllllllllllIIlIIlllIIIllIIII;
  }
  
  private static boolean lIIlIIlIIIIllI(int ???)
  {
    boolean lllllllllllllllIIlIIlllIIIlIIlII;
    return ??? == 0;
  }
  
  public ItemTransformVec3f(Vector3f lllllllllllllllIIlIIlllIIIllllll, Vector3f lllllllllllllllIIlIIlllIIIlllllI, Vector3f lllllllllllllllIIlIIlllIIIllllIl)
  {
    rotation = new Vector3f(lllllllllllllllIIlIIlllIIIllllll);
    translation = new Vector3f(lllllllllllllllIIlIIlllIIIlllllI);
    scale = new Vector3f(lllllllllllllllIIlIIlllIIIllllIl);
  }
  
  private static void lIIlIIlIIIIIll()
  {
    lIlllllllIIl = new int[3];
    lIlllllllIIl[0] = " ".length();
    lIlllllllIIl[1] = ((0xB2 ^ 0xAD) & (0x83 ^ 0x9C ^ 0xFFFFFFFF));
    lIlllllllIIl[2] = (0x6B ^ 0x74);
  }
  
  static class Deserializer
    implements JsonDeserializer<ItemTransformVec3f>
  {
    private static boolean lIlIIlIIllIIII(int ???)
    {
      String llllllllllllllIlllllllllIIlIIIIl;
      return ??? == 0;
    }
    
    private static String lIlIIlIIIllIlI(String llllllllllllllIlllllllllIlIlIlIl, String llllllllllllllIlllllllllIlIlIIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlllllllllIlIllIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllllllllIlIlIIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher llllllllllllllIlllllllllIlIlIlll = Cipher.getInstance("Blowfish");
        llllllllllllllIlllllllllIlIlIlll.init(llIlIllIllIl[2], llllllllllllllIlllllllllIlIllIII);
        return new String(llllllllllllllIlllllllllIlIlIlll.doFinal(Base64.getDecoder().decode(llllllllllllllIlllllllllIlIlIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlllllllllIlIlIllI)
      {
        llllllllllllllIlllllllllIlIlIllI.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIlIIlIIllIIll(int ???, int arg1)
    {
      int i;
      char llllllllllllllIlllllllllIIlIIIll;
      return ??? < i;
    }
    
    private static void lIlIIlIIlIIIlI()
    {
      llIlIllIIIIl = new String[llIlIllIllIl[7]];
      llIlIllIIIIl[llIlIllIllIl[0]] = lIlIIlIIIllIlI("NFd3ActM5Vt/mxFlWWZfZg==", "fdqUU");
      llIlIllIIIIl[llIlIllIllIl[1]] = lIlIIlIIIllllI("FT8tNhkNLDgxBQ8=", "aMLXj");
      llIlIllIIIIl[llIlIllIllIl[2]] = lIlIIlIIIllllI("GTUMHgk=", "jVmrl");
      llIlIllIIIIl[llIlIllIllIl[3]] = lIlIIlIIIllllI("IDY8IRMRKyhkQ0U=", "eNLDp");
      llIlIllIIIIl[llIlIllIllIl[4]] = lIlIIlIIIllIlI("qo+vImcgmc58WnVqD1x3LGM6P9Pergw7", "ATmla");
      llIlIllIIIIl[llIlIllIllIl[5]] = lIlIIlIIlIIIIl("ELcQAbAVLZg=", "vsFew");
      llIlIllIIIIl[llIlIllIllIl[6]] = lIlIIlIIlIIIIl("/GrwXB/EKhI=", "imjnT");
    }
    
    static
    {
      lIlIIlIIlIllll();
      lIlIIlIIlIIIlI();
      ROTATION_DEFAULT = new Vector3f(0.0F, 0.0F, 0.0F);
      TRANSLATION_DEFAULT = new Vector3f(0.0F, 0.0F, 0.0F);
    }
    
    private static String lIlIIlIIlIIIIl(String llllllllllllllIlllllllllIIllIIII, String llllllllllllllIlllllllllIIlIllIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec llllllllllllllIlllllllllIIllIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllllllllIIlIllIl.getBytes(StandardCharsets.UTF_8)), llIlIllIllIl[8]), "DES");
        Cipher llllllllllllllIlllllllllIIllIIlI = Cipher.getInstance("DES");
        llllllllllllllIlllllllllIIllIIlI.init(llIlIllIllIl[2], llllllllllllllIlllllllllIIllIIll);
        return new String(llllllllllllllIlllllllllIIllIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllIlllllllllIIllIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception llllllllllllllIlllllllllIIllIIIl)
      {
        llllllllllllllIlllllllllIIllIIIl.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIlIIlIIllIIlI(int ???, int arg1)
    {
      int i;
      Exception llllllllllllllIlllllllllIIlIIlll;
      return ??? >= i;
    }
    
    private static String lIlIIlIIIllllI(String llllllllllllllIlllllllllIlIIIIII, String llllllllllllllIlllllllllIIllllll)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      llllllllllllllIlllllllllIlIIIIII = new String(Base64.getDecoder().decode(llllllllllllllIlllllllllIlIIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder llllllllllllllIlllllllllIlIIIIll = new StringBuilder();
      char[] llllllllllllllIlllllllllIlIIIIlI = llllllllllllllIlllllllllIIllllll.toCharArray();
      int llllllllllllllIlllllllllIlIIIIIl = llIlIllIllIl[0];
      String llllllllllllllIlllllllllIIlllIll = llllllllllllllIlllllllllIlIIIIII.toCharArray();
      Exception llllllllllllllIlllllllllIIlllIlI = llllllllllllllIlllllllllIIlllIll.length;
      String llllllllllllllIlllllllllIIlllIIl = llIlIllIllIl[0];
      while (lIlIIlIIllIIll(llllllllllllllIlllllllllIIlllIIl, llllllllllllllIlllllllllIIlllIlI))
      {
        char llllllllllllllIlllllllllIlIIIllI = llllllllllllllIlllllllllIIlllIll[llllllllllllllIlllllllllIIlllIIl];
        "".length();
        "".length();
        if ((63 + '' - 191 + 138 ^ 49 + 85 - 39 + 66) == 0) {
          return null;
        }
      }
      return String.valueOf(llllllllllllllIlllllllllIlIIIIll);
    }
    
    public ItemTransformVec3f deserialize(JsonElement llllllllllllllIllllllllllIIIIlII, Type llllllllllllllIllllllllllIIIIIll, JsonDeserializationContext llllllllllllllIllllllllllIIIIIlI)
      throws JsonParseException
    {
      ;
      ;
      ;
      ;
      ;
      ;
      JsonObject llllllllllllllIllllllllllIIIIIIl = llllllllllllllIllllllllllIIIIlII.getAsJsonObject();
      Vector3f llllllllllllllIllllllllllIIIIIII = llllllllllllllIlllllllllIlllllIl.parseVector3f(llllllllllllllIllllllllllIIIIIIl, llIlIllIIIIl[llIlIllIllIl[0]], ROTATION_DEFAULT);
      Vector3f llllllllllllllIlllllllllIlllllll = llllllllllllllIlllllllllIlllllIl.parseVector3f(llllllllllllllIllllllllllIIIIIIl, llIlIllIIIIl[llIlIllIllIl[1]], TRANSLATION_DEFAULT);
      "".length();
      x = MathHelper.clamp_float(x, -1.5F, 1.5F);
      y = MathHelper.clamp_float(y, -1.5F, 1.5F);
      z = MathHelper.clamp_float(z, -1.5F, 1.5F);
      Vector3f llllllllllllllIlllllllllIllllllI = llllllllllllllIlllllllllIlllllIl.parseVector3f(llllllllllllllIllllllllllIIIIIIl, llIlIllIIIIl[llIlIllIllIl[2]], SCALE_DEFAULT);
      x = MathHelper.clamp_float(x, -4.0F, 4.0F);
      y = MathHelper.clamp_float(y, -4.0F, 4.0F);
      z = MathHelper.clamp_float(z, -4.0F, 4.0F);
      return new ItemTransformVec3f(llllllllllllllIllllllllllIIIIIII, llllllllllllllIlllllllllIlllllll, llllllllllllllIlllllllllIllllllI);
    }
    
    private static boolean lIlIIlIIllIIIl(int ???, int arg1)
    {
      int i;
      Exception llllllllllllllIlllllllllIIIlllIl;
      return ??? != i;
    }
    
    private static void lIlIIlIIlIllll()
    {
      llIlIllIllIl = new int[9];
      llIlIllIllIl[0] = ((0x14 ^ 0x3A) & (0xA4 ^ 0x8A ^ 0xFFFFFFFF));
      llIlIllIllIl[1] = " ".length();
      llIlIllIllIl[2] = "  ".length();
      llIlIllIllIl[3] = "   ".length();
      llIlIllIllIl[4] = (0x5A ^ 0x4 ^ 0x3E ^ 0x64);
      llIlIllIllIl[5] = (0xBA ^ 0xBF);
      llIlIllIllIl[6] = (0x12 ^ 0x14);
      llIlIllIllIl[7] = ("   ".length() ^ 0x87 ^ 0x83);
      llIlIllIllIl[8] = (0x29 ^ 0x21);
    }
    
    Deserializer() {}
    
    private Vector3f parseVector3f(JsonObject llllllllllllllIlllllllllIlllIIII, String llllllllllllllIlllllllllIllIllll, Vector3f llllllllllllllIlllllllllIllIlllI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      if (lIlIIlIIllIIII(llllllllllllllIlllllllllIlllIIII.has(llllllllllllllIlllllllllIllIlIIl))) {
        return llllllllllllllIlllllllllIllIlllI;
      }
      JsonArray llllllllllllllIlllllllllIllIllIl = JsonUtils.getJsonArray(llllllllllllllIlllllllllIlllIIII, llllllllllllllIlllllllllIllIlIIl);
      if (lIlIIlIIllIIIl(llllllllllllllIlllllllllIllIllIl.size(), llIlIllIllIl[3])) {
        throw new JsonParseException(String.valueOf(new StringBuilder(llIlIllIIIIl[llIlIllIllIl[3]]).append(llllllllllllllIlllllllllIllIlIIl).append(llIlIllIIIIl[llIlIllIllIl[4]]).append(llllllllllllllIlllllllllIllIllIl.size())));
      }
      float[] llllllllllllllIlllllllllIllIllII = new float[llIlIllIllIl[3]];
      int llllllllllllllIlllllllllIllIlIll = llIlIllIllIl[0];
      "".length();
      if (null != null) {
        return null;
      }
      while (!lIlIIlIIllIIlI(llllllllllllllIlllllllllIllIlIll, llllllllllllllIlllllllllIllIllII.length))
      {
        llllllllllllllIlllllllllIllIllII[llllllllllllllIlllllllllIllIlIll] = JsonUtils.getFloat(llllllllllllllIlllllllllIllIllIl.get(llllllllllllllIlllllllllIllIlIll), String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlllllllllIllIlIIl)).append(llIlIllIIIIl[llIlIllIllIl[5]]).append(llllllllllllllIlllllllllIllIlIll).append(llIlIllIIIIl[llIlIllIllIl[6]])));
        llllllllllllllIlllllllllIllIlIll++;
      }
      return new Vector3f(llllllllllllllIlllllllllIllIllII[llIlIllIllIl[0]], llllllllllllllIlllllllllIllIllII[llIlIllIllIl[1]], llllllllllllllIlllllllllIllIllII[llIlIllIllIl[2]]);
    }
  }
}

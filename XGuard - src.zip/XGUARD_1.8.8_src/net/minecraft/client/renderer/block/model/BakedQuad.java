package net.minecraft.client.renderer.block.model;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.util.EnumFacing;

public class BakedQuad
{
  public int[] getVertexDataSingle()
  {
    ;
    if (lIlllIIl(vertexDataSingle)) {
      vertexDataSingle = makeVertexDataSingle(vertexData, sprite);
    }
    return vertexDataSingle;
  }
  
  public EnumFacing getFace()
  {
    ;
    return face;
  }
  
  public int[] getVertexData()
  {
    ;
    return vertexData;
  }
  
  static
  {
    lIllIlll();
    lIllIlII();
  }
  
  public TextureAtlasSprite getSprite()
  {
    ;
    return sprite;
  }
  
  public BakedQuad(int[] lllIlIllIIlllII, int lllIlIllIIllIll, EnumFacing lllIlIllIIlllll, TextureAtlasSprite lllIlIllIIllllI)
  {
    vertexData = lllIlIllIIlllII;
    tintIndex = lllIlIllIlIIIII;
    face = lllIlIllIIlllll;
    sprite = lllIlIllIIllllI;
  }
  
  public BakedQuad(int[] lllIlIllIIIlIIl, int lllIlIllIIIlIII, EnumFacing lllIlIllIIIlIll)
  {
    vertexData = lllIlIllIIIlIIl;
    tintIndex = lllIlIllIIIlIII;
    face = lllIlIllIIIlIll;
  }
  
  public boolean hasTintIndex()
  {
    ;
    if (lIlllIII(tintIndex, lIllll[5])) {
      return lIllll[2];
    }
    return lIllll[0];
  }
  
  public String toString()
  {
    ;
    return String.valueOf(new StringBuilder(lIlIll[lIllll[0]]).append(vertexData.length / lIllll[1]).append(lIlIll[lIllll[2]]).append(tintIndex).append(lIlIll[lIllll[3]]).append(face).append(lIlIll[lIllll[4]]).append(sprite));
  }
  
  public int getTintIndex()
  {
    ;
    return tintIndex;
  }
  
  private static boolean lIlllIIl(Object ???)
  {
    char lllIlIlIIIllIlI;
    return ??? == null;
  }
  
  private static void lIllIlll()
  {
    lIllll = new int[9];
    lIllll[0] = ((0xFF ^ 0xB8) & (0xFA ^ 0xBD ^ 0xFFFFFFFF));
    lIllll[1] = (0x37 ^ 0x30);
    lIllll[2] = " ".length();
    lIllll[3] = "  ".length();
    lIllll[4] = "   ".length();
    lIllll[5] = (-" ".length());
    lIllll[6] = (25 + 4 - 21 + 139 ^ 122 + 39 - 93 + 83);
    lIllll[7] = (0x44 ^ 0x50 ^ 0x83 ^ 0x92);
    lIllll[8] = (35 + 14 - -45 + 42 ^ 16 + 26 - 30 + 116);
  }
  
  private static boolean lIlllIlI(int ???, int arg1)
  {
    int i;
    byte lllIlIlIIlIIIII;
    return ??? >= i;
  }
  
  private static boolean lIlllIII(int ???, int arg1)
  {
    int i;
    byte lllIlIlIIIlIllI;
    return ??? != i;
  }
  
  private static void lIllIlII()
  {
    lIlIll = new String[lIllll[7]];
    lIlIll[lIllll[0]] = lIllIIIl("2N1WbACh8yo32+cRDb9YIA==", "uCPDx");
    lIlIll[lIllll[2]] = lIllIIlI("eXonDykhYHM=", "UZSfG");
    lIlIll[lIllll[3]] = lIllIIll("5ZWjaWDKOjjcUUWQJC4iaw==", "oPRqz");
    lIlIll[lIllll[4]] = lIllIIIl("kSZRw7vwFownehpifQRCsw==", "DCPAL");
    lIlIll[lIllll[6]] = lIllIIIl("olDSZTp++YsQD3SBX+BRLQ==", "hEftb");
  }
  
  private static String lIllIIIl(String lllIlIlIlIIllII, String lllIlIlIlIIlIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllIlIlIlIlIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllIlIlIlIIlIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher lllIlIlIlIlIIII = Cipher.getInstance("Blowfish");
      lllIlIlIlIlIIII.init(lIllll[3], lllIlIlIlIlIIIl);
      return new String(lllIlIlIlIlIIII.doFinal(Base64.getDecoder().decode(lllIlIlIlIIllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllIlIlIlIIllll)
    {
      lllIlIlIlIIllll.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIllllII(int ???, int arg1)
  {
    int i;
    long lllIlIlIIIlllII;
    return ??? < i;
  }
  
  private static String lIllIIll(String lllIlIlIlIIIIIl, String lllIlIlIIlllllI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec lllIlIlIlIIIlII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllIlIlIIlllllI.getBytes(StandardCharsets.UTF_8)), lIllll[8]), "DES");
      Cipher lllIlIlIlIIIIll = Cipher.getInstance("DES");
      lllIlIlIlIIIIll.init(lIllll[3], lllIlIlIlIIIlII);
      return new String(lllIlIlIlIIIIll.doFinal(Base64.getDecoder().decode(lllIlIlIlIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception lllIlIlIlIIIIlI)
    {
      lllIlIlIlIIIIlI.printStackTrace();
    }
    return null;
  }
  
  private static int[] makeVertexDataSingle(int[] lllIlIlIllIIIII, TextureAtlasSprite lllIlIlIllIlIll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int[] lllIlIlIllIlIlI = new int[lllIlIlIllIIIII.length];
    int lllIlIlIllIlIIl = lIllll[0];
    "".length();
    if (null != null) {
      return null;
    }
    while (!lIlllIlI(lllIlIlIllIlIIl, lllIlIlIllIlIlI.length))
    {
      lllIlIlIllIlIlI[lllIlIlIllIlIIl] = lllIlIlIllIIIII[lllIlIlIllIlIIl];
      lllIlIlIllIlIIl++;
    }
    int lllIlIlIllIlIII = sheetWidth / lllIlIlIllIlIll.getIconWidth();
    int lllIlIlIllIIlll = sheetHeight / lllIlIlIllIlIll.getIconHeight();
    int lllIlIlIllIIllI = lIllll[0];
    "".length();
    if (((0x22 ^ 0x6) & (0x57 ^ 0x73 ^ 0xFFFFFFFF)) != 0) {
      return null;
    }
    while (!lIlllIlI(lllIlIlIllIIllI, lIllll[6]))
    {
      int lllIlIlIllIIlIl = lllIlIlIllIIllI * lIllll[1];
      float lllIlIlIllIIlII = Float.intBitsToFloat(lllIlIlIllIlIlI[(lllIlIlIllIIlIl + lIllll[6])]);
      float lllIlIlIllIIIll = Float.intBitsToFloat(lllIlIlIllIlIlI[(lllIlIlIllIIlIl + lIllll[6] + lIllll[2])]);
      float lllIlIlIllIIIlI = lllIlIlIllIlIll.toSingleU(lllIlIlIllIIlII);
      float lllIlIlIllIIIIl = lllIlIlIllIlIll.toSingleV(lllIlIlIllIIIll);
      lllIlIlIllIlIlI[(lllIlIlIllIIlIl + lIllll[6])] = Float.floatToRawIntBits(lllIlIlIllIIIlI);
      lllIlIlIllIlIlI[(lllIlIlIllIIlIl + lIllll[6] + lIllll[2])] = Float.floatToRawIntBits(lllIlIlIllIIIIl);
      lllIlIlIllIIllI++;
    }
    return lllIlIlIllIlIlI;
  }
  
  private static String lIllIIlI(String lllIlIlIIlIllII, String lllIlIlIIllIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    lllIlIlIIlIllII = new String(Base64.getDecoder().decode(lllIlIlIIlIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder lllIlIlIIlIllll = new StringBuilder();
    char[] lllIlIlIIlIlllI = lllIlIlIIllIIII.toCharArray();
    int lllIlIlIIlIllIl = lIllll[0];
    String lllIlIlIIlIIlll = lllIlIlIIlIllII.toCharArray();
    short lllIlIlIIlIIllI = lllIlIlIIlIIlll.length;
    float lllIlIlIIlIIlIl = lIllll[0];
    while (lIllllII(lllIlIlIIlIIlIl, lllIlIlIIlIIllI))
    {
      char lllIlIlIIllIIlI = lllIlIlIIlIIlll[lllIlIlIIlIIlIl];
      "".length();
      "".length();
      if ("  ".length() <= 0) {
        return null;
      }
    }
    return String.valueOf(lllIlIlIIlIllll);
  }
}

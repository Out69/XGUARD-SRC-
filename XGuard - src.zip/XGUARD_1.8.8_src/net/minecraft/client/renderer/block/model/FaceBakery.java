package net.minecraft.client.renderer.block.model;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.client.renderer.EnumFaceDirection;
import net.minecraft.client.renderer.EnumFaceDirection.VertexInformation;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.ModelRotation;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3i;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector3f;
import org.lwjgl.util.vector.Vector4f;

public class FaceBakery
{
  private float getFaceBrightness(EnumFacing llllllllllllllIlIlIIIlIllIlllllI)
  {
    ;
    switch (FaceBakery.1.field_178400_a[llllllllllllllIlIlIIIlIllIllllll.ordinal()])
    {
    case 1: 
      return 0.5F;
    case 2: 
      return 1.0F;
    case 3: 
    case 4: 
      return 0.8F;
    case 5: 
    case 6: 
      return 0.6F;
    }
    return 1.0F;
  }
  
  static
  {
    llIlIIIlIIlllI();
    llIlIIIlIIllIl();
    __OBFID = lIIIlIIlIIIII[lIIIlIIlIIIIl[0]];
    field_178418_a = 1.0F / (float)Math.cos(0.39269909262657166D) - 1.0F;
  }
  
  private static boolean llIlIIIlIlIIII(Object ???)
  {
    int llllllllllllllIlIlIIIlIIIllllllI;
    return ??? == null;
  }
  
  private void func_178401_a(int llllllllllllllIlIlIIIlIIlIllIIlI, int[] llllllllllllllIlIlIIIlIIlIllIIIl, EnumFacing llllllllllllllIlIlIIIlIIlIllIIII, BlockFaceUV llllllllllllllIlIlIIIlIIlIlIllll, TextureAtlasSprite llllllllllllllIlIlIIIlIIlIlIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIlIIIlIIlIlIllIl = lIIIlIIlIIIIl[8] * llllllllllllllIlIlIIIlIIlIllIIlI;
    float llllllllllllllIlIlIIIlIIlIlIllII = Float.intBitsToFloat(llllllllllllllIlIlIIIlIIlIllIIIl[llllllllllllllIlIlIIIlIIlIlIllIl]);
    float llllllllllllllIlIlIIIlIIlIlIlIll = Float.intBitsToFloat(llllllllllllllIlIlIIIlIIlIllIIIl[(llllllllllllllIlIlIIIlIIlIlIllIl + lIIIlIIlIIIIl[9])]);
    float llllllllllllllIlIlIIIlIIlIlIlIlI = Float.intBitsToFloat(llllllllllllllIlIlIIIlIIlIllIIIl[(llllllllllllllIlIlIIIlIIlIlIllIl + lIIIlIIlIIIIl[10])]);
    if ((!llIlIIIlIllIll(llIlIIIllIIIIl(llllllllllllllIlIlIIIlIIlIlIllII, -0.1F))) || (llIlIIIlIllIll(llIlIIIllIIIlI(llllllllllllllIlIlIIIlIIlIlIllII, 1.1F)))) {
      llllllllllllllIlIlIIIlIIlIlIllII -= MathHelper.floor_float(llllllllllllllIlIlIIIlIIlIlIllII);
    }
    if ((!llIlIIIlIllIll(llIlIIIllIIIIl(llllllllllllllIlIlIIIlIIlIlIlIll, -0.1F))) || (llIlIIIlIllIll(llIlIIIllIIIlI(llllllllllllllIlIlIIIlIIlIlIlIll, 1.1F)))) {
      llllllllllllllIlIlIIIlIIlIlIlIll -= MathHelper.floor_float(llllllllllllllIlIlIIIlIIlIlIlIll);
    }
    if ((!llIlIIIlIllIll(llIlIIIllIIIIl(llllllllllllllIlIlIIIlIIlIlIlIlI, -0.1F))) || (llIlIIIlIllIll(llIlIIIllIIIlI(llllllllllllllIlIlIIIlIIlIlIlIlI, 1.1F)))) {
      llllllllllllllIlIlIIIlIIlIlIlIlI -= MathHelper.floor_float(llllllllllllllIlIlIIIlIIlIlIlIlI);
    }
    float llllllllllllllIlIlIIIlIIlIlIlIIl = 0.0F;
    float llllllllllllllIlIlIIIlIIlIlIlIII = 0.0F;
    switch (FaceBakery.1.field_178400_a[llllllllllllllIlIlIIIlIIlIlIIlII.ordinal()])
    {
    case 1: 
      llllllllllllllIlIlIIIlIIlIlIlIIl = llllllllllllllIlIlIIIlIIlIlIllII * 16.0F;
      llllllllllllllIlIlIIIlIIlIlIlIII = (1.0F - llllllllllllllIlIlIIIlIIlIlIlIlI) * 16.0F;
      "".length();
      if ((29 + 114 - 135 + 173 ^ '¤' + 68 - 130 + 75) < -" ".length()) {
        return;
      }
      break;
    case 2: 
      llllllllllllllIlIlIIIlIIlIlIlIIl = llllllllllllllIlIlIIIlIIlIlIllII * 16.0F;
      llllllllllllllIlIlIIIlIIlIlIlIII = llllllllllllllIlIlIIIlIIlIlIlIlI * 16.0F;
      "".length();
      if ((0x8F ^ 0x8A) <= 0) {
        return;
      }
      break;
    case 3: 
      llllllllllllllIlIlIIIlIIlIlIlIIl = (1.0F - llllllllllllllIlIlIIIlIIlIlIllII) * 16.0F;
      llllllllllllllIlIlIIIlIIlIlIlIII = (1.0F - llllllllllllllIlIlIIIlIIlIlIlIll) * 16.0F;
      "".length();
      if ("   ".length() <= "  ".length()) {
        return;
      }
      break;
    case 4: 
      llllllllllllllIlIlIIIlIIlIlIlIIl = llllllllllllllIlIlIIIlIIlIlIllII * 16.0F;
      llllllllllllllIlIlIIIlIIlIlIlIII = (1.0F - llllllllllllllIlIlIIIlIIlIlIlIll) * 16.0F;
      "".length();
      if (-" ".length() != -" ".length()) {
        return;
      }
      break;
    case 5: 
      llllllllllllllIlIlIIIlIIlIlIlIIl = llllllllllllllIlIlIIIlIIlIlIlIlI * 16.0F;
      llllllllllllllIlIlIIIlIIlIlIlIII = (1.0F - llllllllllllllIlIlIIIlIIlIlIlIll) * 16.0F;
      "".length();
      if (-" ".length() > (0x6A ^ 0x64 ^ 0xA ^ 0x0)) {
        return;
      }
      break;
    case 6: 
      llllllllllllllIlIlIIIlIIlIlIlIIl = (1.0F - llllllllllllllIlIlIIIlIIlIlIlIlI) * 16.0F;
      llllllllllllllIlIlIIIlIIlIlIlIII = (1.0F - llllllllllllllIlIlIIIlIIlIlIlIll) * 16.0F;
    }
    int llllllllllllllIlIlIIIlIIlIlIIlll = llllllllllllllIlIlIIIlIIlIlIllll.func_178345_c(llllllllllllllIlIlIIIlIIlIllIIlI) * lIIIlIIlIIIIl[8];
    llllllllllllllIlIlIIIlIIlIllIIIl[(llllllllllllllIlIlIIIlIIlIlIIlll + lIIIlIIlIIIIl[2])] = Float.floatToRawIntBits(llllllllllllllIlIlIIIlIIlIlIlllI.getInterpolatedU(llllllllllllllIlIlIIIlIIlIlIlIIl));
    llllllllllllllIlIlIIIlIIlIllIIIl[(llllllllllllllIlIlIIIlIIlIlIIlll + lIIIlIIlIIIIl[2] + lIIIlIIlIIIIl[9])] = Float.floatToRawIntBits(llllllllllllllIlIlIIIlIIlIlIlllI.getInterpolatedV(llllllllllllllIlIlIIIlIIlIlIlIII));
  }
  
  private float[] getPositionsDiv16(Vector3f llllllllllllllIlIlIIIlIllIlllIIl, Vector3f llllllllllllllIlIlIIIlIllIllIlIl)
  {
    ;
    ;
    ;
    float[] llllllllllllllIlIlIIIlIllIllIlll = new float[EnumFacing.values().length];
    llllllllllllllIlIlIIIlIllIllIlll[net.minecraft.client.renderer.EnumFaceDirection.Constants.WEST_INDEX] = (x / 16.0F);
    llllllllllllllIlIlIIIlIllIllIlll[net.minecraft.client.renderer.EnumFaceDirection.Constants.DOWN_INDEX] = (y / 16.0F);
    llllllllllllllIlIlIIIlIllIllIlll[net.minecraft.client.renderer.EnumFaceDirection.Constants.NORTH_INDEX] = (z / 16.0F);
    llllllllllllllIlIlIIIlIllIllIlll[net.minecraft.client.renderer.EnumFaceDirection.Constants.EAST_INDEX] = (x / 16.0F);
    llllllllllllllIlIlIIIlIllIllIlll[net.minecraft.client.renderer.EnumFaceDirection.Constants.UP_INDEX] = (y / 16.0F);
    llllllllllllllIlIlIIIlIllIllIlll[net.minecraft.client.renderer.EnumFaceDirection.Constants.SOUTH_INDEX] = (z / 16.0F);
    return llllllllllllllIlIlIIIlIllIllIlll;
  }
  
  private static void llIlIIIlIIllIl()
  {
    lIIIlIIlIIIII = new String[lIIIlIIlIIIIl[9]];
    lIIIlIIlIIIII[lIIIlIIlIIIIl[0]] = llIlIIIlIIllII("0G7/RXV3fCppUNP/J056pQ==", "WwPGb");
  }
  
  private static boolean llIlIIIlIlIIIl(int ???, int arg1)
  {
    int i;
    char llllllllllllllIlIlIIIlIIlIIIlIlI;
    return ??? >= i;
  }
  
  private static int llIlIIIlIlIlll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public int rotateVertex(Vector3f llllllllllllllIlIlIIIlIlIlIlIlIl, EnumFacing llllllllllllllIlIlIIIlIlIlIIlllI, int llllllllllllllIlIlIIIlIlIlIlIIll, ModelRotation llllllllllllllIlIlIIIlIlIlIlIIlI, boolean llllllllllllllIlIlIIIlIlIlIlIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIlIIIlIlIllI(llllllllllllllIlIlIIIlIlIlIlIIlI, ModelRotation.X0_Y0)) {
      return llllllllllllllIlIlIIIlIlIlIlIIll;
    }
    llllllllllllllIlIlIIIlIlIlIlIIII.rotateScale(llllllllllllllIlIlIIIlIlIlIlIlIl, new Vector3f(0.5F, 0.5F, 0.5F), llllllllllllllIlIlIIIlIlIlIlIIlI.getMatrix4d(), new Vector3f(1.0F, 1.0F, 1.0F));
    return llllllllllllllIlIlIIIlIlIlIlIIlI.rotateVertex(llllllllllllllIlIlIIIlIlIlIIlllI, llllllllllllllIlIlIIIlIlIlIlIIll);
  }
  
  private static int llIlIIIlIlIIll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public BakedQuad makeBakedQuad(Vector3f llllllllllllllIlIlIIIlIllllllIIl, Vector3f llllllllllllllIlIlIIIlIllllllIII, BlockPartFace llllllllllllllIlIlIIIllIIIIIIIll, TextureAtlasSprite llllllllllllllIlIlIIIlIlllllIllI, EnumFacing llllllllllllllIlIlIIIllIIIIIIIIl, ModelRotation llllllllllllllIlIlIIIlIlllllIlII, BlockPartRotation llllllllllllllIlIlIIIlIlllllllll, boolean llllllllllllllIlIlIIIlIllllllllI, boolean llllllllllllllIlIlIIIlIlllllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int[] llllllllllllllIlIlIIIlIlllllllII = llllllllllllllIlIlIIIlIllllllIlI.makeQuadVertexData(llllllllllllllIlIlIIIllIIIIIIIll, llllllllllllllIlIlIIIlIlllllIllI, llllllllllllllIlIlIIIllIIIIIIIIl, llllllllllllllIlIlIIIlIllllllIlI.getPositionsDiv16(llllllllllllllIlIlIIIlIllllllIIl, llllllllllllllIlIlIIIlIllllllIII), llllllllllllllIlIlIIIlIlllllIlII, llllllllllllllIlIlIIIlIlllllllll, llllllllllllllIlIlIIIlIllllllllI, llllllllllllllIlIlIIIlIlllllIIIl);
    EnumFacing llllllllllllllIlIlIIIlIllllllIll = getFacingFromVertexData(llllllllllllllIlIlIIIlIlllllllII);
    if (llIlIIIlIIllll(llllllllllllllIlIlIIIlIllllllllI)) {
      llllllllllllllIlIlIIIlIllllllIlI.func_178409_a(llllllllllllllIlIlIIIlIlllllllII, llllllllllllllIlIlIIIlIllllllIll, blockFaceUV, llllllllllllllIlIlIIIlIlllllIllI);
    }
    if (llIlIIIlIlIIII(llllllllllllllIlIlIIIlIlllllllll)) {
      llllllllllllllIlIlIIIlIllllllIlI.func_178408_a(llllllllllllllIlIlIIIlIlllllllII, llllllllllllllIlIlIIIlIllllllIll);
    }
    return new BakedQuad(llllllllllllllIlIlIIIlIlllllllII, tintIndex, llllllllllllllIlIlIIIlIllllllIll, llllllllllllllIlIlIIIlIlllllIllI);
  }
  
  private void func_178407_a(Vector3f llllllllllllllIlIlIIIlIlIllIIlII, BlockPartRotation llllllllllllllIlIlIIIlIlIlIllllI)
  {
    ;
    ;
    ;
    ;
    ;
    if (llIlIIIlIlIlII(llllllllllllllIlIlIIIlIlIlIllllI))
    {
      Matrix4f llllllllllllllIlIlIIIlIlIllIIIlI = llllllllllllllIlIlIIIlIlIllIIIII.getMatrixIdentity();
      Vector3f llllllllllllllIlIlIIIlIlIllIIIIl = new Vector3f(0.0F, 0.0F, 0.0F);
      switch (FaceBakery.1.field_178399_b[axis.ordinal()])
      {
      case 1: 
        new Vector3f(1.0F, 0.0F, 0.0F);
        "".length();
        llllllllllllllIlIlIIIlIlIllIIIIl.set(0.0F, 1.0F, 1.0F);
        "".length();
        if (-" ".length() > -" ".length()) {
          return;
        }
        break;
      case 2: 
        new Vector3f(0.0F, 1.0F, 0.0F);
        "".length();
        llllllllllllllIlIlIIIlIlIllIIIIl.set(1.0F, 0.0F, 1.0F);
        "".length();
        if (null != null) {
          return;
        }
        break;
      case 3: 
        new Vector3f(0.0F, 0.0F, 1.0F);
        "".length();
        llllllllllllllIlIlIIIlIlIllIIIIl.set(1.0F, 1.0F, 0.0F);
      }
      if (llIlIIIlIIllll(rescale))
      {
        if (llIlIIIlIlIlIl(llIlIIIlIlIIll(Math.abs(angle), 22.5F)))
        {
          "".length();
          "".length();
          if ("  ".length() >= -" ".length()) {}
        }
        else
        {
          "".length();
        }
        new Vector3f(1.0F, 1.0F, 1.0F);
        "".length();
        "".length();
        if ("  ".length() != (0x2C ^ 0x23 ^ 0x7D ^ 0x76)) {}
      }
      else
      {
        llllllllllllllIlIlIIIlIlIllIIIIl.set(1.0F, 1.0F, 1.0F);
      }
      llllllllllllllIlIlIIIlIlIllIIIII.rotateScale(llllllllllllllIlIlIIIlIlIlIlllll, new Vector3f(origin), llllllllllllllIlIlIIIlIlIllIIIlI, llllllllllllllIlIlIIIlIlIllIIIIl);
    }
  }
  
  private void storeVertexData(int[] llllllllllllllIlIlIIIlIlIlllIIlI, int llllllllllllllIlIlIIIlIlIlllIIIl, int llllllllllllllIlIlIIIlIlIllllIII, Vector3f llllllllllllllIlIlIIIlIlIllIllll, int llllllllllllllIlIlIIIlIlIlllIllI, TextureAtlasSprite llllllllllllllIlIlIIIlIlIllIllIl, BlockFaceUV llllllllllllllIlIlIIIlIlIlllIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIlIIIlIlIlllIIll = llllllllllllllIlIlIIIlIlIlllIIIl * lIIIlIIlIIIIl[8];
    llllllllllllllIlIlIIIlIlIlllIIlI[llllllllllllllIlIlIIIlIlIlllIIll] = Float.floatToRawIntBits(x);
    llllllllllllllIlIlIIIlIlIlllIIlI[(llllllllllllllIlIlIIIlIlIlllIIll + lIIIlIIlIIIIl[9])] = Float.floatToRawIntBits(y);
    llllllllllllllIlIlIIIlIlIlllIIlI[(llllllllllllllIlIlIIIlIlIlllIIll + lIIIlIIlIIIIl[10])] = Float.floatToRawIntBits(z);
    llllllllllllllIlIlIIIlIlIlllIIlI[(llllllllllllllIlIlIIIlIlIlllIIll + lIIIlIIlIIIIl[11])] = llllllllllllllIlIlIIIlIlIlllIllI;
    llllllllllllllIlIlIIIlIlIlllIIlI[(llllllllllllllIlIlIIIlIlIlllIIll + lIIIlIIlIIIIl[2])] = Float.floatToRawIntBits(llllllllllllllIlIlIIIlIlIllIllIl.getInterpolatedU(llllllllllllllIlIlIIIlIlIlllIlII.func_178348_a(llllllllllllllIlIlIIIlIlIllllIII)));
    llllllllllllllIlIlIIIlIlIlllIIlI[(llllllllllllllIlIlIIIlIlIlllIIll + lIIIlIIlIIIIl[2] + lIIIlIIlIIIIl[9])] = Float.floatToRawIntBits(llllllllllllllIlIlIIIlIlIllIllIl.getInterpolatedV(llllllllllllllIlIlIIIlIlIlllIlII.func_178346_b(llllllllllllllIlIlIIIlIlIllllIII)));
  }
  
  private static boolean llIlIIIlIlIlIl(int ???)
  {
    int llllllllllllllIlIlIIIlIIIllllIlI;
    return ??? == 0;
  }
  
  private static String llIlIIIlIIllII(String llllllllllllllIlIlIIIlIIlIIlIIll, String llllllllllllllIlIlIIIlIIlIIlIIII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlIlIIIlIIlIIlIllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIIIlIIlIIlIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlIlIIIlIIlIIlIlIl = Cipher.getInstance("Blowfish");
      llllllllllllllIlIlIIIlIIlIIlIlIl.init(lIIIlIIlIIIIl[10], llllllllllllllIlIlIIIlIIlIIlIllI);
      return new String(llllllllllllllIlIlIIIlIIlIIlIlIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIIIlIIlIIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlIlIIIlIIlIIlIlII)
    {
      llllllllllllllIlIlIIIlIIlIIlIlII.printStackTrace();
    }
    return null;
  }
  
  private static int llIlIIIlIllIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static int llIlIIIlIlllll(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static boolean llIlIIIlIllllI(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllIlIlIIIlIIlIIIIllI;
    return ??? != localObject;
  }
  
  private static boolean llIlIIIlIIllll(int ???)
  {
    char llllllllllllllIlIlIIIlIIIlllllII;
    return ??? != 0;
  }
  
  private static boolean llIlIIIlIlllIl(int ???)
  {
    boolean llllllllllllllIlIlIIIlIIIlllIllI;
    return ??? < 0;
  }
  
  private static void llIlIIIlIIlllI()
  {
    lIIIlIIlIIIIl = new int[15];
    lIIIlIIlIIIIl[0] = ((0x84 ^ 0xAB ^ 0x5D ^ 0x32) & (35 + 18 - 5 + 86 ^ 'ª' + 9 - 135 + 154 ^ -" ".length()));
    lIIIlIIlIIIIl[1] = (0x81 ^ 0xA5 ^ 0x5E ^ 0x66);
    lIIIlIIlIIIIl[2] = (0xCA ^ 0xB0 ^ 0x2E ^ 0x50);
    lIIIlIIlIIIIl[3] = ((0x5C ^ 0x6D) + (85 + 27 - 3 + 39) - (0x88 ^ 0xB4) + (0x52 ^ 0x24));
    lIIIlIIlIIIIl[4] = (-(-(0x97AD & 0x6FDF) & 0xC7DF & 0x1003FAC));
    lIIIlIIlIIIIl[5] = (0x3C ^ 0x71 ^ 0xC7 ^ 0x9A);
    lIIIlIIlIIIIl[6] = (0x9A ^ 0xB5 ^ 0x85 ^ 0xA2);
    lIIIlIIlIIIIl[7] = (-" ".length());
    lIIIlIIlIIIIl[8] = (0xB5 ^ 0xB2);
    lIIIlIIlIIIIl[9] = " ".length();
    lIIIlIIlIIIIl[10] = "  ".length();
    lIIIlIIlIIIIl[11] = "   ".length();
    lIIIlIIlIIIIl[12] = (0x9E ^ 0x97);
    lIIIlIIlIIIIl[13] = (0x1D ^ 0x3F ^ 0x5F ^ 0x73);
    lIIIlIIlIIIIl[14] = (13 + 122 - -17 + 4 ^ 21 + 67 - -42 + 17);
  }
  
  private static int llIlIIIllIIIIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public void func_178409_a(int[] llllllllllllllIlIlIIIlIIlllllIlI, EnumFacing llllllllllllllIlIlIIIlIIlllllIIl, BlockFaceUV llllllllllllllIlIlIIIlIIlllllIII, TextureAtlasSprite llllllllllllllIlIlIIIlIIllllIlll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIlIIIlIIllllllII = lIIIlIIlIIIIl[0];
    "".length();
    if (-(0xAA ^ 0xAE) > 0) {
      return;
    }
    while (!llIlIIIlIlIIIl(llllllllllllllIlIlIIIlIIllllllII, lIIIlIIlIIIIl[2]))
    {
      llllllllllllllIlIlIIIlIlIIIIIIIl.func_178401_a(llllllllllllllIlIlIIIlIIllllllII, llllllllllllllIlIlIIIlIIlllllIlI, llllllllllllllIlIlIIIlIIllllllll, llllllllllllllIlIlIIIlIIlllllIII, llllllllllllllIlIlIIIlIIllllIlll);
      llllllllllllllIlIlIIIlIIllllllII++;
    }
  }
  
  public FaceBakery() {}
  
  private static boolean llIlIIIlIlIlII(Object ???)
  {
    char llllllllllllllIlIlIIIlIIlIIIIlII;
    return ??? != null;
  }
  
  private int getFaceShadeColor(EnumFacing llllllllllllllIlIlIIIlIlllIIIlII)
  {
    ;
    ;
    ;
    ;
    float llllllllllllllIlIlIIIlIlllIIIlll = llllllllllllllIlIlIIIlIlllIIlIIl.getFaceBrightness(llllllllllllllIlIlIIIlIlllIIIlII);
    int llllllllllllllIlIlIIIlIlllIIIllI = MathHelper.clamp_int((int)(llllllllllllllIlIlIIIlIlllIIIlll * 255.0F), lIIIlIIlIIIIl[0], lIIIlIIlIIIIl[3]);
    return lIIIlIIlIIIIl[4] | llllllllllllllIlIlIIIlIlllIIIllI << lIIIlIIlIIIIl[5] | llllllllllllllIlIlIIIlIlllIIIllI << lIIIlIIlIIIIl[6] | llllllllllllllIlIlIIIlIlllIIIllI;
  }
  
  private static boolean llIlIIIlIllIll(int ???)
  {
    short llllllllllllllIlIlIIIlIIIllllIII;
    return ??? >= 0;
  }
  
  private static int llIlIIIllIIIII(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private void rotateScale(Vector3f llllllllllllllIlIlIIIlIlIlIIIIII, Vector3f llllllllllllllIlIlIIIlIlIIllllll, Matrix4f llllllllllllllIlIlIIIlIlIlIIIIll, Vector3f llllllllllllllIlIlIIIlIlIlIIIIlI)
  {
    ;
    ;
    ;
    ;
    ;
    Vector4f llllllllllllllIlIlIIIlIlIlIIIIIl = new Vector4f(x - x, y - y, z - z, 1.0F);
    "".length();
    x *= x;
    y *= y;
    z *= z;
    llllllllllllllIlIlIIIlIlIlIIIIII.set(x + x, y + y, z + z);
  }
  
  private void func_178408_a(int[] llllllllllllllIlIlIIIlIIlllIIlII, EnumFacing llllllllllllllIlIlIIIlIIllIIlllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int[] llllllllllllllIlIlIIIlIIlllIIIlI = new int[llllllllllllllIlIlIIIlIIlllIIlII.length];
    System.arraycopy(llllllllllllllIlIlIIIlIIlllIIlII, lIIIlIIlIIIIl[0], llllllllllllllIlIlIIIlIIlllIIIlI, lIIIlIIlIIIIl[0], llllllllllllllIlIlIIIlIIlllIIlII.length);
    float[] llllllllllllllIlIlIIIlIIlllIIIIl = new float[EnumFacing.values().length];
    llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.WEST_INDEX] = 999.0F;
    llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.DOWN_INDEX] = 999.0F;
    llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.NORTH_INDEX] = 999.0F;
    llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.EAST_INDEX] = -999.0F;
    llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.UP_INDEX] = -999.0F;
    llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.SOUTH_INDEX] = -999.0F;
    int llllllllllllllIlIlIIIlIIlllIIIII = lIIIlIIlIIIIl[0];
    "".length();
    if (-(41 + 92 - 32 + 33 ^ 59 + 50 - 83 + 104) >= 0) {
      return;
    }
    while (!llIlIIIlIlIIIl(llllllllllllllIlIlIIIlIIlllIIIII, lIIIlIIlIIIIl[2]))
    {
      int llllllllllllllIlIlIIIlIIllIlllll = lIIIlIIlIIIIl[8] * llllllllllllllIlIlIIIlIIlllIIIII;
      float llllllllllllllIlIlIIIlIIllIllllI = Float.intBitsToFloat(llllllllllllllIlIlIIIlIIlllIIIlI[llllllllllllllIlIlIIIlIIllIlllll]);
      float llllllllllllllIlIlIIIlIIllIlllIl = Float.intBitsToFloat(llllllllllllllIlIlIIIlIIlllIIIlI[(llllllllllllllIlIlIIIlIIllIlllll + lIIIlIIlIIIIl[9])]);
      float llllllllllllllIlIlIIIlIIllIlllII = Float.intBitsToFloat(llllllllllllllIlIlIIIlIIlllIIIlI[(llllllllllllllIlIlIIIlIIllIlllll + lIIIlIIlIIIIl[10])]);
      if (llIlIIIlIlllIl(llIlIIIlIlllll(llllllllllllllIlIlIIIlIIllIllllI, llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.WEST_INDEX]))) {
        llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.WEST_INDEX] = llllllllllllllIlIlIIIlIIllIllllI;
      }
      if (llIlIIIlIlllIl(llIlIIIlIlllll(llllllllllllllIlIlIIIlIIllIlllIl, llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.DOWN_INDEX]))) {
        llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.DOWN_INDEX] = llllllllllllllIlIlIIIlIIllIlllIl;
      }
      if (llIlIIIlIlllIl(llIlIIIlIlllll(llllllllllllllIlIlIIIlIIllIlllII, llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.NORTH_INDEX]))) {
        llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.NORTH_INDEX] = llllllllllllllIlIlIIIlIIllIlllII;
      }
      if (llIlIIIlIlllII(llIlIIIllIIIII(llllllllllllllIlIlIIIlIIllIllllI, llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.EAST_INDEX]))) {
        llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.EAST_INDEX] = llllllllllllllIlIlIIIlIIllIllllI;
      }
      if (llIlIIIlIlllII(llIlIIIllIIIII(llllllllllllllIlIlIIIlIIllIlllIl, llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.UP_INDEX]))) {
        llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.UP_INDEX] = llllllllllllllIlIlIIIlIIllIlllIl;
      }
      if (llIlIIIlIlllII(llIlIIIllIIIII(llllllllllllllIlIlIIIlIIllIlllII, llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.SOUTH_INDEX]))) {
        llllllllllllllIlIlIIIlIIlllIIIIl[net.minecraft.client.renderer.EnumFaceDirection.Constants.SOUTH_INDEX] = llllllllllllllIlIlIIIlIIllIlllII;
      }
      llllllllllllllIlIlIIIlIIlllIIIII++;
    }
    EnumFaceDirection llllllllllllllIlIlIIIlIIllIllIll = EnumFaceDirection.getFacing(llllllllllllllIlIlIIIlIIllIIlllI);
    int llllllllllllllIlIlIIIlIIllIllIlI = lIIIlIIlIIIIl[0];
    "".length();
    if ("   ".length() <= " ".length()) {
      return;
    }
    while (!llIlIIIlIlIIIl(llllllllllllllIlIlIIIlIIllIllIlI, lIIIlIIlIIIIl[2]))
    {
      int llllllllllllllIlIlIIIlIIllIllIIl = lIIIlIIlIIIIl[8] * llllllllllllllIlIlIIIlIIllIllIlI;
      EnumFaceDirection.VertexInformation llllllllllllllIlIlIIIlIIllIllIII = llllllllllllllIlIlIIIlIIllIllIll.func_179025_a(llllllllllllllIlIlIIIlIIllIllIlI);
      float llllllllllllllIlIlIIIlIIllIlIlll = llllllllllllllIlIlIIIlIIlllIIIIl[field_179184_a];
      float llllllllllllllIlIlIIIlIIllIlIllI = llllllllllllllIlIlIIIlIIlllIIIIl[field_179182_b];
      float llllllllllllllIlIlIIIlIIllIlIlIl = llllllllllllllIlIlIIIlIIlllIIIIl[field_179183_c];
      llllllllllllllIlIlIIIlIIlllIIlII[llllllllllllllIlIlIIIlIIllIllIIl] = Float.floatToRawIntBits(llllllllllllllIlIlIIIlIIllIlIlll);
      llllllllllllllIlIlIIIlIIlllIIlII[(llllllllllllllIlIlIIIlIIllIllIIl + lIIIlIIlIIIIl[9])] = Float.floatToRawIntBits(llllllllllllllIlIlIIIlIIllIlIllI);
      llllllllllllllIlIlIIIlIIlllIIlII[(llllllllllllllIlIlIIIlIIllIllIIl + lIIIlIIlIIIIl[10])] = Float.floatToRawIntBits(llllllllllllllIlIlIIIlIIllIlIlIl);
      int llllllllllllllIlIlIIIlIIllIlIlII = lIIIlIIlIIIIl[0];
      "".length();
      if (-"  ".length() >= 0) {
        return;
      }
      while (!llIlIIIlIlIIIl(llllllllllllllIlIlIIIlIIllIlIlII, lIIIlIIlIIIIl[2]))
      {
        int llllllllllllllIlIlIIIlIIllIlIIll = lIIIlIIlIIIIl[8] * llllllllllllllIlIlIIIlIIllIlIlII;
        float llllllllllllllIlIlIIIlIIllIlIIlI = Float.intBitsToFloat(llllllllllllllIlIlIIIlIIlllIIIlI[llllllllllllllIlIlIIIlIIllIlIIll]);
        float llllllllllllllIlIlIIIlIIllIlIIIl = Float.intBitsToFloat(llllllllllllllIlIlIIIlIIlllIIIlI[(llllllllllllllIlIlIIIlIIllIlIIll + lIIIlIIlIIIIl[9])]);
        float llllllllllllllIlIlIIIlIIllIlIIII = Float.intBitsToFloat(llllllllllllllIlIlIIIlIIlllIIIlI[(llllllllllllllIlIlIIIlIIllIlIIll + lIIIlIIlIIIIl[10])]);
        if ((llIlIIIlIIllll(MathHelper.epsilonEquals(llllllllllllllIlIlIIIlIIllIlIlll, llllllllllllllIlIlIIIlIIllIlIIlI))) && (llIlIIIlIIllll(MathHelper.epsilonEquals(llllllllllllllIlIlIIIlIIllIlIllI, llllllllllllllIlIlIIIlIIllIlIIIl))) && (llIlIIIlIIllll(MathHelper.epsilonEquals(llllllllllllllIlIlIIIlIIllIlIlIl, llllllllllllllIlIlIIIlIIllIlIIII))))
        {
          llllllllllllllIlIlIIIlIIlllIIlII[(llllllllllllllIlIlIIIlIIllIllIIl + lIIIlIIlIIIIl[2])] = llllllllllllllIlIlIIIlIIlllIIIlI[(llllllllllllllIlIlIIIlIIllIlIIll + lIIIlIIlIIIIl[2])];
          llllllllllllllIlIlIIIlIIlllIIlII[(llllllllllllllIlIlIIIlIIllIllIIl + lIIIlIIlIIIIl[2] + lIIIlIIlIIIIl[9])] = llllllllllllllIlIlIIIlIIlllIIIlI[(llllllllllllllIlIlIIIlIIllIlIIll + lIIIlIIlIIIIl[2] + lIIIlIIlIIIIl[9])];
        }
        llllllllllllllIlIlIIIlIIllIlIlII++;
      }
      llllllllllllllIlIlIIIlIIllIllIlI++;
    }
  }
  
  private void fillVertexData(int[] llllllllllllllIlIlIIIlIllIlIIIlI, int llllllllllllllIlIlIIIlIllIIlIIIl, EnumFacing llllllllllllllIlIlIIIlIllIlIIIII, BlockPartFace llllllllllllllIlIlIIIlIllIIIllll, float[] llllllllllllllIlIlIIIlIllIIllllI, TextureAtlasSprite llllllllllllllIlIlIIIlIllIIIllIl, ModelRotation llllllllllllllIlIlIIIlIllIIlllII, BlockPartRotation llllllllllllllIlIlIIIlIllIIIlIll, boolean llllllllllllllIlIlIIIlIllIIllIlI, boolean llllllllllllllIlIlIIIlIllIIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    EnumFacing llllllllllllllIlIlIIIlIllIIllIII = llllllllllllllIlIlIIIlIllIIlllII.rotateFace(llllllllllllllIlIlIIIlIllIlIIIII);
    if (llIlIIIlIIllll(llllllllllllllIlIlIIIlIllIIIlIIl))
    {
      "".length();
      if ("   ".length() != -" ".length()) {
        break label49;
      }
    }
    label49:
    int llllllllllllllIlIlIIIlIllIIlIlll = lIIIlIIlIIIIl[7];
    EnumFaceDirection.VertexInformation llllllllllllllIlIlIIIlIllIIlIllI = EnumFaceDirection.getFacing(llllllllllllllIlIlIIIlIllIlIIIII).func_179025_a(llllllllllllllIlIlIIIlIllIIlIIIl);
    Vector3f llllllllllllllIlIlIIIlIllIIlIlIl = new Vector3f(llllllllllllllIlIlIIIlIllIIIlllI[field_179184_a], llllllllllllllIlIlIIIlIllIIIlllI[field_179182_b], llllllllllllllIlIlIIIlIllIIIlllI[field_179183_c]);
    llllllllllllllIlIlIIIlIllIIlIIll.func_178407_a(llllllllllllllIlIlIIIlIllIIlIlIl, llllllllllllllIlIlIIIlIllIIIlIll);
    int llllllllllllllIlIlIIIlIllIIlIlII = llllllllllllllIlIlIIIlIllIIlIIll.rotateVertex(llllllllllllllIlIlIIIlIllIIlIlIl, llllllllllllllIlIlIIIlIllIlIIIII, llllllllllllllIlIlIIIlIllIIlIIIl, llllllllllllllIlIlIIIlIllIIlllII, llllllllllllllIlIlIIIlIllIIllIlI);
    llllllllllllllIlIlIIIlIllIIlIIll.storeVertexData(llllllllllllllIlIlIIIlIllIlIIIlI, llllllllllllllIlIlIIIlIllIIlIlII, llllllllllllllIlIlIIIlIllIIlIIIl, llllllllllllllIlIlIIIlIllIIlIlIl, llllllllllllllIlIlIIIlIllIIlIlll, llllllllllllllIlIlIIIlIllIIIllIl, blockFaceUV);
  }
  
  private static int llIlIIIllIIIlI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public static EnumFacing getFacingFromVertexData(int[] llllllllllllllIlIlIIIlIlIIlIIllI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    Vector3f llllllllllllllIlIlIIIlIlIIlIIlIl = new Vector3f(Float.intBitsToFloat(llllllllllllllIlIlIIIlIlIIIllIII[lIIIlIIlIIIIl[0]]), Float.intBitsToFloat(llllllllllllllIlIlIIIlIlIIIllIII[lIIIlIIlIIIIl[9]]), Float.intBitsToFloat(llllllllllllllIlIlIIIlIlIIIllIII[lIIIlIIlIIIIl[10]]));
    Vector3f llllllllllllllIlIlIIIlIlIIlIIlII = new Vector3f(Float.intBitsToFloat(llllllllllllllIlIlIIIlIlIIIllIII[lIIIlIIlIIIIl[8]]), Float.intBitsToFloat(llllllllllllllIlIlIIIlIlIIIllIII[lIIIlIIlIIIIl[6]]), Float.intBitsToFloat(llllllllllllllIlIlIIIlIlIIIllIII[lIIIlIIlIIIIl[12]]));
    Vector3f llllllllllllllIlIlIIIlIlIIlIIIll = new Vector3f(Float.intBitsToFloat(llllllllllllllIlIlIIIlIlIIIllIII[lIIIlIIlIIIIl[13]]), Float.intBitsToFloat(llllllllllllllIlIlIIIlIlIIIllIII[lIIIlIIlIIIIl[14]]), Float.intBitsToFloat(llllllllllllllIlIlIIIlIlIIIllIII[lIIIlIIlIIIIl[5]]));
    Vector3f llllllllllllllIlIlIIIlIlIIlIIIlI = new Vector3f();
    Vector3f llllllllllllllIlIlIIIlIlIIlIIIIl = new Vector3f();
    Vector3f llllllllllllllIlIlIIIlIlIIlIIIII = new Vector3f();
    "".length();
    "".length();
    "".length();
    float llllllllllllllIlIlIIIlIlIIIlllll = (float)Math.sqrt(x * x + y * y + z * z);
    x /= llllllllllllllIlIlIIIlIlIIIlllll;
    y /= llllllllllllllIlIlIIIlIlIIIlllll;
    z /= llllllllllllllIlIlIIIlIlIIIlllll;
    EnumFacing llllllllllllllIlIlIIIlIlIIIllllI = null;
    float llllllllllllllIlIlIIIlIlIIIlllIl = 0.0F;
    char llllllllllllllIlIlIIIlIlIIIIllII = (llllllllllllllIlIlIIIlIlIIIIlIll = EnumFacing.values()).length;
    long llllllllllllllIlIlIIIlIlIIIIllIl = lIIIlIIlIIIIl[0];
    "".length();
    if (-" ".length() >= (0x33 ^ 0x5D ^ 0x39 ^ 0x53)) {
      return null;
    }
    while (!llIlIIIlIlIIIl(llllllllllllllIlIlIIIlIlIIIIllIl, llllllllllllllIlIlIIIlIlIIIIllII))
    {
      EnumFacing llllllllllllllIlIlIIIlIlIIIlllII = llllllllllllllIlIlIIIlIlIIIIlIll[llllllllllllllIlIlIIIlIlIIIIllIl];
      Vec3i llllllllllllllIlIlIIIlIlIIIllIll = llllllllllllllIlIlIIIlIlIIIlllII.getDirectionVec();
      Vector3f llllllllllllllIlIlIIIlIlIIIllIlI = new Vector3f(llllllllllllllIlIlIIIlIlIIIllIll.getX(), llllllllllllllIlIlIIIlIlIIIllIll.getY(), llllllllllllllIlIlIIIlIlIIIllIll.getZ());
      float llllllllllllllIlIlIIIlIlIIIllIIl = Vector3f.dot(llllllllllllllIlIlIIIlIlIIlIIIII, llllllllllllllIlIlIIIlIlIIIllIlI);
      if ((llIlIIIlIllIll(llIlIIIlIlIlll(llllllllllllllIlIlIIIlIlIIIllIIl, 0.0F))) && (llIlIIIlIlllII(llIlIIIlIlIlll(llllllllllllllIlIlIIIlIlIIIllIIl, llllllllllllllIlIlIIIlIlIIIlllIl))))
      {
        llllllllllllllIlIlIIIlIlIIIlllIl = llllllllllllllIlIlIIIlIlIIIllIIl;
        llllllllllllllIlIlIIIlIlIIIllllI = llllllllllllllIlIlIIIlIlIIIlllII;
      }
      llllllllllllllIlIlIIIlIlIIIIllIl++;
    }
    if (llIlIIIlIlllIl(llIlIIIlIllIIl(llllllllllllllIlIlIIIlIlIIIlllIl, 0.719F))) {
      if ((llIlIIIlIllllI(llllllllllllllIlIlIIIlIlIIIllllI, EnumFacing.EAST)) && (llIlIIIlIllllI(llllllllllllllIlIlIIIlIlIIIllllI, EnumFacing.WEST)) && (llIlIIIlIllllI(llllllllllllllIlIlIIIlIlIIIllllI, EnumFacing.NORTH)) && (llIlIIIlIllllI(llllllllllllllIlIlIIIlIlIIIllllI, EnumFacing.SOUTH)))
      {
        llllllllllllllIlIlIIIlIlIIIllllI = EnumFacing.UP;
        "".length();
        if (-" ".length() >= 0) {
          return null;
        }
      }
      else
      {
        llllllllllllllIlIlIIIlIlIIIllllI = EnumFacing.NORTH;
      }
    }
    if (llIlIIIlIlIIII(llllllllllllllIlIlIIIlIlIIIllllI))
    {
      "".length();
      if ("  ".length() != -" ".length()) {
        break label533;
      }
      return null;
    }
    label533:
    return llllllllllllllIlIlIIIlIlIIIllllI;
  }
  
  private Matrix4f getMatrixIdentity()
  {
    ;
    Matrix4f llllllllllllllIlIlIIIlIlIIlllIIl = new Matrix4f();
    "".length();
    return llllllllllllllIlIlIIIlIlIIlllIIl;
  }
  
  private int[] makeQuadVertexData(BlockPartFace llllllllllllllIlIlIIIlIllllIIIlI, TextureAtlasSprite llllllllllllllIlIlIIIlIllllIIIIl, EnumFacing llllllllllllllIlIlIIIlIlllIlIlIl, float[] llllllllllllllIlIlIIIlIlllIlIlII, ModelRotation llllllllllllllIlIlIIIlIlllIllllI, BlockPartRotation llllllllllllllIlIlIIIlIlllIlIIlI, boolean llllllllllllllIlIlIIIlIlllIlllII, boolean llllllllllllllIlIlIIIlIlllIlIIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int[] llllllllllllllIlIlIIIlIlllIllIlI = new int[lIIIlIIlIIIIl[1]];
    int llllllllllllllIlIlIIIlIlllIllIIl = lIIIlIIlIIIIl[0];
    "".length();
    if (((0x3 ^ 0x51) & (0x39 ^ 0x6B ^ 0xFFFFFFFF)) != 0) {
      return null;
    }
    while (!llIlIIIlIlIIIl(llllllllllllllIlIlIIIlIlllIllIIl, lIIIlIIlIIIIl[2]))
    {
      llllllllllllllIlIlIIIlIllllIIIll.fillVertexData(llllllllllllllIlIlIIIlIlllIllIlI, llllllllllllllIlIlIIIlIlllIllIIl, llllllllllllllIlIlIIIlIlllIlIlIl, llllllllllllllIlIlIIIlIllllIIIlI, llllllllllllllIlIlIIIlIlllIlllll, llllllllllllllIlIlIIIlIllllIIIIl, llllllllllllllIlIlIIIlIlllIllllI, llllllllllllllIlIlIIIlIlllIlIIlI, llllllllllllllIlIlIIIlIlllIlllII, llllllllllllllIlIlIIIlIlllIlIIII);
      llllllllllllllIlIlIIIlIlllIllIIl++;
    }
    return llllllllllllllIlIlIIIlIlllIllIlI;
  }
  
  private static boolean llIlIIIlIlllII(int ???)
  {
    long llllllllllllllIlIlIIIlIIIlllIlII;
    return ??? > 0;
  }
  
  private static boolean llIlIIIlIlIllI(Object ???, Object arg1)
  {
    Object localObject;
    long llllllllllllllIlIlIIIlIIlIIIIIII;
    return ??? == localObject;
  }
}

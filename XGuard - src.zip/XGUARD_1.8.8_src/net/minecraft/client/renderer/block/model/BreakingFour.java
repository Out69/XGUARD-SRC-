package net.minecraft.client.renderer.block.model;

import java.util.Arrays;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;

public class BreakingFour
  extends BakedQuad
{
  public BreakingFour(BakedQuad llllllllllllllIlIllIIIllllIIllII, TextureAtlasSprite llllllllllllllIlIllIIIllllIIlIII)
  {
    llllllllllllllIlIllIIIllllIIllIl.<init>(Arrays.copyOf(llllllllllllllIlIllIIIllllIIlIIl.getVertexData(), llllllllllllllIlIllIIIllllIIlIIl.getVertexData().length), tintIndex, FaceBakery.getFacingFromVertexData(llllllllllllllIlIllIIIllllIIlIIl.getVertexData()));
    texture = llllllllllllllIlIllIIIllllIIlIII;
    llllllllllllllIlIllIIIllllIIllIl.func_178217_e();
  }
  
  private static boolean llIIlIlIIIIIlI(Object ???)
  {
    char llllllllllllllIlIllIIIlllIlIIIlI;
    return ??? != null;
  }
  
  private void func_178216_a(int llllllllllllllIlIllIIIlllIlllIII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllIlIllIIIlllIllIlll = lIIIIlIIIIllI[2] * llllllllllllllIlIllIIIlllIlllIII;
    float llllllllllllllIlIllIIIlllIllIllI = Float.intBitsToFloat(vertexData[llllllllllllllIlIllIIIlllIllIlll]);
    float llllllllllllllIlIllIIIlllIllIlIl = Float.intBitsToFloat(vertexData[(llllllllllllllIlIllIIIlllIllIlll + lIIIIlIIIIllI[3])]);
    float llllllllllllllIlIllIIIlllIllIlII = Float.intBitsToFloat(vertexData[(llllllllllllllIlIllIIIlllIllIlll + lIIIIlIIIIllI[4])]);
    float llllllllllllllIlIllIIIlllIllIIll = 0.0F;
    float llllllllllllllIlIllIIIlllIllIIlI = 0.0F;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[face.ordinal()])
    {
    case 1: 
      llllllllllllllIlIllIIIlllIllIIll = llllllllllllllIlIllIIIlllIllIllI * 16.0F;
      llllllllllllllIlIllIIIlllIllIIlI = (1.0F - llllllllllllllIlIllIIIlllIllIlII) * 16.0F;
      "".length();
      if (" ".length() <= ((0x6C ^ 0x47) & (0xA ^ 0x21 ^ 0xFFFFFFFF))) {
        return;
      }
      break;
    case 2: 
      llllllllllllllIlIllIIIlllIllIIll = llllllllllllllIlIllIIIlllIllIllI * 16.0F;
      llllllllllllllIlIllIIIlllIllIIlI = llllllllllllllIlIllIIIlllIllIlII * 16.0F;
      "".length();
      if ("   ".length() <= " ".length()) {
        return;
      }
      break;
    case 3: 
      llllllllllllllIlIllIIIlllIllIIll = (1.0F - llllllllllllllIlIllIIIlllIllIllI) * 16.0F;
      llllllllllllllIlIllIIIlllIllIIlI = (1.0F - llllllllllllllIlIllIIIlllIllIlIl) * 16.0F;
      "".length();
      if (" ".length() < ((0x55 ^ 0x72) & (0x7 ^ 0x20 ^ 0xFFFFFFFF))) {
        return;
      }
      break;
    case 4: 
      llllllllllllllIlIllIIIlllIllIIll = llllllllllllllIlIllIIIlllIllIllI * 16.0F;
      llllllllllllllIlIllIIIlllIllIIlI = (1.0F - llllllllllllllIlIllIIIlllIllIlIl) * 16.0F;
      "".length();
      if (" ".length() == ((0x44 ^ 0x25) & (0xE6 ^ 0x87 ^ 0xFFFFFFFF))) {
        return;
      }
      break;
    case 5: 
      llllllllllllllIlIllIIIlllIllIIll = llllllllllllllIlIllIIIlllIllIlII * 16.0F;
      llllllllllllllIlIllIIIlllIllIIlI = (1.0F - llllllllllllllIlIllIIIlllIllIlIl) * 16.0F;
      "".length();
      if (" ".length() > " ".length()) {
        return;
      }
      break;
    case 6: 
      llllllllllllllIlIllIIIlllIllIIll = (1.0F - llllllllllllllIlIllIIIlllIllIlII) * 16.0F;
      llllllllllllllIlIllIIIlllIllIIlI = (1.0F - llllllllllllllIlIllIIIlllIllIlIl) * 16.0F;
    }
    vertexData[(llllllllllllllIlIllIIIlllIllIlll + lIIIIlIIIIllI[1])] = Float.floatToRawIntBits(texture.getInterpolatedU(llllllllllllllIlIllIIIlllIllIIll));
    vertexData[(llllllllllllllIlIllIIIlllIllIlll + lIIIIlIIIIllI[1] + lIIIIlIIIIllI[3])] = Float.floatToRawIntBits(texture.getInterpolatedV(llllllllllllllIlIllIIIlllIllIIlI));
  }
  
  private void func_178217_e()
  {
    ;
    ;
    int llllllllllllllIlIllIIIllllIIIlII = lIIIIlIIIIllI[0];
    "".length();
    if (-"  ".length() >= 0) {
      return;
    }
    while (!llIIlIlIIIIIII(llllllllllllllIlIllIIIllllIIIlII, lIIIIlIIIIllI[1]))
    {
      llllllllllllllIlIllIIIllllIIIIll.func_178216_a(llllllllllllllIlIllIIIllllIIIlII);
      llllllllllllllIlIllIIIllllIIIlII++;
    }
  }
  
  private static void llIIlIIlllllll()
  {
    lIIIIlIIIIllI = new int[8];
    lIIIIlIIIIllI[0] = ((0x7A ^ 0x59) & (0x7F ^ 0x5C ^ 0xFFFFFFFF));
    lIIIIlIIIIllI[1] = (0x30 ^ 0x34);
    lIIIIlIIIIllI[2] = (0x6D ^ 0x6A);
    lIIIIlIIIIllI[3] = " ".length();
    lIIIIlIIIIllI[4] = "  ".length();
    lIIIIlIIIIllI[5] = (0x13 ^ 0x15);
    lIIIIlIIIIllI[6] = "   ".length();
    lIIIIlIIIIllI[7] = (77 + 118 - 127 + 82 ^ 9 + 30 - -100 + 8);
  }
  
  static {}
  
  private static boolean llIIlIlIIIIIII(int ???, int arg1)
  {
    int i;
    byte llllllllllllllIlIllIIIlllIlIIlII;
    return ??? >= i;
  }
}

package net.minecraft.client.renderer.block.model;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.io.Reader;
import java.io.StringReader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.ResourceLocation;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ModelBlock
{
  private static boolean lIlIllllIlIIII(int ???, int arg1)
  {
    int i;
    double llllllllllllllIlllIlIIllIIIlIIII;
    return ??? < i;
  }
  
  private static boolean lIlIllllIIllIl(Object ???, Object arg1)
  {
    Object localObject;
    int llllllllllllllIlllIlIIllIIIIlIlI;
    return ??? == localObject;
  }
  
  private boolean hasParent()
  {
    ;
    if (lIlIllllIIlIll(parent)) {
      return lllIIlIIlllI[1];
    }
    return lllIIlIIlllI[0];
  }
  
  private static boolean lIlIllllIIlIll(Object ???)
  {
    boolean llllllllllllllIlllIlIIllIIIIlllI;
    return ??? != null;
  }
  
  public void getParentFromMap(Map<ResourceLocation, ModelBlock> llllllllllllllIlllIlIIlllIIlIlIl)
  {
    ;
    ;
    if (lIlIllllIIlIll(parentLocation)) {
      parent = ((ModelBlock)llllllllllllllIlllIlIIlllIIlIlIl.get(parentLocation));
    }
  }
  
  public String resolveTextureName(String llllllllllllllIlllIlIIlllIIIlIll)
  {
    ;
    ;
    if (lIlIllllIIllII(llllllllllllllIlllIlIIlllIIIllII.startsWithHash(llllllllllllllIlllIlIIlllIIIlIll))) {
      llllllllllllllIlllIlIIlllIIIlIll = String.valueOf(new StringBuilder(String.valueOf(lllIIlIIlllI[2])).append(llllllllllllllIlllIlIIlllIIIlIll));
    }
    return llllllllllllllIlllIlIIlllIIIllII.resolveTextureName(llllllllllllllIlllIlIIlllIIIlIll, new Bookkeep(llllllllllllllIlllIlIIlllIIIllII, null));
  }
  
  private String resolveTextureName(String llllllllllllllIlllIlIIllIlllllll, Bookkeep llllllllllllllIlllIlIIlllIIIIIlI)
  {
    ;
    ;
    ;
    ;
    if (lIlIllllIIlIlI(llllllllllllllIlllIlIIlllIIIIlII.startsWithHash(llllllllllllllIlllIlIIlllIIIIIll)))
    {
      if (lIlIllllIIllIl(llllllllllllllIlllIlIIlllIIIIlII, modelExt))
      {
        LOGGER.warn(String.valueOf(new StringBuilder(lllIIlIIllIl[lllIIlIIlllI[3]]).append(llllllllllllllIlllIlIIlllIIIIIll).append(lllIIlIIllIl[lllIIlIIlllI[4]]).append(name)));
        return lllIIlIIllIl[lllIIlIIlllI[5]];
      }
      String llllllllllllllIlllIlIIlllIIIIIIl = (String)textures.get(llllllllllllllIlllIlIIlllIIIIIll.substring(lllIIlIIlllI[1]));
      if ((lIlIllllIIlllI(llllllllllllllIlllIlIIlllIIIIIIl)) && (lIlIllllIIlIlI(llllllllllllllIlllIlIIlllIIIIlII.hasParent()))) {
        llllllllllllllIlllIlIIlllIIIIIIl = parent.resolveTextureName(llllllllllllllIlllIlIIlllIIIIIll, llllllllllllllIlllIlIIlllIIIIIlI);
      }
      modelExt = llllllllllllllIlllIlIIlllIIIIlII;
      if ((lIlIllllIIlIll(llllllllllllllIlllIlIIlllIIIIIIl)) && (lIlIllllIIlIlI(llllllllllllllIlllIlIIlllIIIIlII.startsWithHash(llllllllllllllIlllIlIIlllIIIIIIl)))) {
        llllllllllllllIlllIlIIlllIIIIIIl = model.resolveTextureName(llllllllllllllIlllIlIIlllIIIIIIl, llllllllllllllIlllIlIIlllIIIIIlI);
      }
      if ((lIlIllllIIlIll(llllllllllllllIlllIlIIlllIIIIIIl)) && (lIlIllllIIllII(llllllllllllllIlllIlIIlllIIIIlII.startsWithHash(llllllllllllllIlllIlIIlllIIIIIIl))))
      {
        "".length();
        if (null == null) {
          break label205;
        }
        return null;
      }
      label205:
      return lllIIlIIllIl[lllIIlIIlllI[6]];
    }
    return llllllllllllllIlllIlIIlllIIIIIll;
  }
  
  private static boolean lIlIllllIIlIlI(int ???)
  {
    float llllllllllllllIlllIlIIllIIIIIllI;
    return ??? != 0;
  }
  
  public ModelBlock getRootModel()
  {
    ;
    if (lIlIllllIIlIlI(llllllllllllllIlllIlIIllIlllIIll.hasParent()))
    {
      "".length();
      if ((0x38 ^ 0x76 ^ 0x1D ^ 0x57) >= ((0xD0 ^ 0x94 ^ 0x4 ^ 0x1C) & (0xAC ^ 0x89 ^ 0xCF ^ 0xB6 ^ -" ".length()))) {
        break label75;
      }
      return null;
    }
    label75:
    return llllllllllllllIlllIlIIllIlllIlII;
  }
  
  protected ModelBlock(ResourceLocation llllllllllllllIlllIlIIllllIIIIll, Map<String, String> llllllllllllllIlllIlIIllllIIlIII, boolean llllllllllllllIlllIlIIllllIIIIIl, boolean llllllllllllllIlllIlIIllllIIIllI, ItemCameraTransforms llllllllllllllIlllIlIIllllIIIlIl)
  {
    llllllllllllllIlllIlIIllllIIlIlI.<init>(llllllllllllllIlllIlIIllllIIIIll, Collections.emptyList(), llllllllllllllIlllIlIIllllIIlIII, llllllllllllllIlllIlIIllllIIIIIl, llllllllllllllIlllIlIIllllIIIllI, llllllllllllllIlllIlIIllllIIIlIl);
  }
  
  protected ModelBlock(List<BlockPart> llllllllllllllIlllIlIIllllIlIlIl, Map<String, String> llllllllllllllIlllIlIIllllIlIlII, boolean llllllllllllllIlllIlIIllllIlIIll, boolean llllllllllllllIlllIlIIllllIlIIlI, ItemCameraTransforms llllllllllllllIlllIlIIllllIlIIIl)
  {
    llllllllllllllIlllIlIIllllIlIllI.<init>(null, llllllllllllllIlllIlIIllllIlIlIl, llllllllllllllIlllIlIIllllIlIlII, llllllllllllllIlllIlIIllllIlIIll, llllllllllllllIlllIlIIllllIlIIlI, llllllllllllllIlllIlIIllllIlIIIl);
  }
  
  private boolean startsWithHash(String llllllllllllllIlllIlIIllIllllIlI)
  {
    ;
    if (lIlIllllIIllll(llllllllllllllIlllIlIIllIllllIlI.charAt(lllIIlIIlllI[0]), lllIIlIIlllI[2])) {
      return lllIIlIIlllI[1];
    }
    return lllIIlIIlllI[0];
  }
  
  public static ModelBlock deserialize(String llllllllllllllIlllIlIIlllllIIlII)
  {
    ;
    return deserialize(new StringReader(llllllllllllllIlllIlIIlllllIIIll));
  }
  
  static
  {
    lIlIllllIIlIIl();
    lIlIllllIIlIII();
    LOGGER = LogManager.getLogger();
  }
  
  public static void checkModelHierarchy(Map<ResourceLocation, ModelBlock> llllllllllllllIlllIlIIllIlIIlllI)
  {
    ;
    ;
    ;
    ;
    String llllllllllllllIlllIlIIllIlIIllII = llllllllllllllIlllIlIIllIlIIlllI.values().iterator();
    "".length();
    if (((0xC3 ^ 0xC7) & (0x99 ^ 0x9D ^ 0xFFFFFFFF)) > (0x7A ^ 0x7E)) {
      return;
    }
    while (!lIlIllllIIllII(llllllllllllllIlllIlIIllIlIIllII.hasNext()))
    {
      ModelBlock llllllllllllllIlllIlIIllIlIlIIIl = (ModelBlock)llllllllllllllIlllIlIIllIlIIllII.next();
      try
      {
        ModelBlock llllllllllllllIlllIlIIllIlIlIIII = parent;
        ModelBlock llllllllllllllIlllIlIIllIlIIllll = parent;
        "".length();
        if ("  ".length() < "  ".length()) {
          return;
        }
        while (!lIlIllllIIllIl(llllllllllllllIlllIlIIllIlIlIIII, llllllllllllllIlllIlIIllIlIIllll))
        {
          llllllllllllllIlllIlIIllIlIlIIII = parent;
          llllllllllllllIlllIlIIllIlIIllll = parent.parent;
        }
        throw new LoopException();
      }
      catch (NullPointerException localNullPointerException) {}
    }
  }
  
  public ResourceLocation getParentLocation()
  {
    ;
    return parentLocation;
  }
  
  public static ModelBlock deserialize(Reader llllllllllllllIlllIlIIlllllIIllI)
  {
    ;
    return (ModelBlock)SERIALIZER.fromJson(llllllllllllllIlllIlIIlllllIIlll, ModelBlock.class);
  }
  
  private static boolean lIlIllllIIlllI(Object ???)
  {
    short llllllllllllllIlllIlIIllIIIIlIII;
    return ??? == null;
  }
  
  private static boolean lIlIllllIIllII(int ???)
  {
    byte llllllllllllllIlllIlIIllIIIIIlII;
    return ??? == 0;
  }
  
  private ItemTransformVec3f func_181681_a(ItemCameraTransforms.TransformType llllllllllllllIlllIlIIllIlIllIlI)
  {
    ;
    ;
    if ((lIlIllllIIlIll(parent)) && (lIlIllllIIllII(cameraTransforms.func_181687_c(llllllllllllllIlllIlIIllIlIllIlI))))
    {
      "".length();
      if ("   ".length() > "  ".length()) {
        break label63;
      }
      return null;
    }
    label63:
    return cameraTransforms.getTransform(llllllllllllllIlllIlIIllIlIllIlI);
  }
  
  public List<BlockPart> getElements()
  {
    ;
    if (lIlIllllIIlIlI(llllllllllllllIlllIlIIlllIlIlIII.hasParent()))
    {
      "".length();
      if ((0x4E ^ 0x4A) > 0) {
        break label37;
      }
      return null;
    }
    label37:
    return elements;
  }
  
  public boolean isTexturePresent(String llllllllllllllIlllIlIIlllIIlIIIl)
  {
    ;
    ;
    if (lIlIllllIIlIlI(lllIIlIIllIl[lllIIlIIlllI[1]].equals(llllllllllllllIlllIlIIlllIIlIIII.resolveTextureName(llllllllllllllIlllIlIIlllIIlIIIl))))
    {
      "".length();
      if (null == null) {
        break label61;
      }
      return (0xC7 ^ 0x9F) & (0xF0 ^ 0xA8 ^ 0xFFFFFFFF);
    }
    label61:
    return lllIIlIIlllI[1];
  }
  
  private static boolean lIlIllllIIllll(int ???, int arg1)
  {
    int i;
    short llllllllllllllIlllIlIIllIIIlIlII;
    return ??? == i;
  }
  
  private ModelBlock(ResourceLocation llllllllllllllIlllIlIIlllIllIllI, List<BlockPart> llllllllllllllIlllIlIIlllIllIlIl, Map<String, String> llllllllllllllIlllIlIIlllIllIlII, boolean llllllllllllllIlllIlIIlllIlIllII, boolean llllllllllllllIlllIlIIlllIlIlIll, ItemCameraTransforms llllllllllllllIlllIlIIlllIlIlIlI)
  {
    elements = llllllllllllllIlllIlIIlllIllIlIl;
    ambientOcclusion = llllllllllllllIlllIlIIlllIlIllII;
    gui3d = llllllllllllllIlllIlIIlllIlIlIll;
    textures = llllllllllllllIlllIlIIlllIlIllIl;
    parentLocation = llllllllllllllIlllIlIIlllIllIllI;
    cameraTransforms = llllllllllllllIlllIlIIlllIlIlIlI;
  }
  
  private static void lIlIllllIIlIIl()
  {
    lllIIlIIlllI = new int[9];
    lllIIlIIlllI[0] = ((0x9F ^ 0xC6) & (0x60 ^ 0x39 ^ 0xFFFFFFFF));
    lllIIlIIlllI[1] = " ".length();
    lllIIlIIlllI[2] = (0x3D ^ 0x1E);
    lllIIlIIlllI[3] = "  ".length();
    lllIIlIIlllI[4] = "   ".length();
    lllIIlIIlllI[5] = (0x1C ^ 0x18);
    lllIIlIIlllI[6] = (0x8B ^ 0x8E);
    lllIIlIIlllI[7] = (17 + 19 - -53 + 79 ^ '£' + 24 - 164 + 151);
    lllIIlIIlllI[8] = ('' + 90 - 194 + 132 ^ 45 + 10 - -44 + 50);
  }
  
  public boolean isAmbientOcclusion()
  {
    ;
    if (lIlIllllIIlIlI(llllllllllllllIlllIlIIlllIlIIIIl.hasParent()))
    {
      "".length();
      if (((0x7E ^ 0x17 ^ 0x7C ^ 0x3F) & (111 + 9 - 10 + 66 ^ 9 + 36 - -19 + 90 ^ -" ".length())) <= 0) {
        break label121;
      }
      return ('é' + '´' - 369 + 211 ^ 78 + 54 - 95 + 141) & ("   ".length() ^ 0x40 ^ 0xE ^ -" ".length());
    }
    label121:
    return ambientOcclusion;
  }
  
  private static void lIlIllllIIlIII()
  {
    lllIIlIIllIl = new String[lllIIlIIlllI[7]];
    lllIIlIIllIl[lllIIlIIlllI[0]] = lIlIlllIlllllI("", "nPSCt");
    lllIIlIIllIl[lllIIlIIlllI[1]] = lIlIlllIllllll("cLL8X0sdPv/Z4HmO66r+kA==", "NgKAd");
    lllIIlIIllIl[lllIIlIIlllI[3]] = lIlIlllIllllll("Ea3qGMxbPdtkDAWfW3AZyEsU8VxkMNAiCmW8FKli9VsG4iYvfw2PC9QXXs0BbV35Q0UhiaqI4TA=", "QDCsF");
    lllIIlIIllIl[lllIIlIIlllI[4]] = lIlIlllIlllllI("Tis4Zw==", "nBVGx");
    lllIIlIIllIl[lllIIlIIlllI[5]] = lIlIllllIIIllI("3vohgd61CxaARJfsBFmiJA==", "lOhPH");
    lllIIlIIllIl[lllIIlIIlllI[6]] = lIlIlllIlllllI("Lg0rIBotAzY8", "CdXSs");
  }
  
  private static String lIlIlllIlllllI(String llllllllllllllIlllIlIIllIIllIIlI, String llllllllllllllIlllIlIIllIIllIIIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllIlllIlIIllIIllIIlI = new String(Base64.getDecoder().decode(llllllllllllllIlllIlIIllIIllIIlI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllIlllIlIIllIIllIIII = new StringBuilder();
    char[] llllllllllllllIlllIlIIllIIlIllll = llllllllllllllIlllIlIIllIIllIIIl.toCharArray();
    int llllllllllllllIlllIlIIllIIlIlllI = lllIIlIIlllI[0];
    Exception llllllllllllllIlllIlIIllIIlIlIII = llllllllllllllIlllIlIIllIIllIIlI.toCharArray();
    int llllllllllllllIlllIlIIllIIlIIlll = llllllllllllllIlllIlIIllIIlIlIII.length;
    byte llllllllllllllIlllIlIIllIIlIIllI = lllIIlIIlllI[0];
    while (lIlIllllIlIIII(llllllllllllllIlllIlIIllIIlIIllI, llllllllllllllIlllIlIIllIIlIIlll))
    {
      char llllllllllllllIlllIlIIllIIllIIll = llllllllllllllIlllIlIIllIIlIlIII[llllllllllllllIlllIlIIllIIlIIllI];
      "".length();
      "".length();
      if (null != null) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllIlllIlIIllIIllIIII);
  }
  
  public boolean isResolved()
  {
    ;
    if ((lIlIllllIIlIll(parentLocation)) && ((!lIlIllllIIlIll(parent)) || (lIlIllllIIllII(parent.isResolved())))) {
      return lllIIlIIlllI[0];
    }
    return lllIIlIIlllI[1];
  }
  
  private static String lIlIlllIllllll(String llllllllllllllIlllIlIIllIIIllIll, String llllllllllllllIlllIlIIllIIIlllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlllIlIIllIIlIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllIlIIllIIIlllII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllIlllIlIIllIIIlllll = Cipher.getInstance("Blowfish");
      llllllllllllllIlllIlIIllIIIlllll.init(lllIIlIIlllI[3], llllllllllllllIlllIlIIllIIlIIIII);
      return new String(llllllllllllllIlllIlIIllIIIlllll.doFinal(Base64.getDecoder().decode(llllllllllllllIlllIlIIllIIIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlllIlIIllIIIllllI)
    {
      llllllllllllllIlllIlIIllIIIllllI.printStackTrace();
    }
    return null;
  }
  
  public ItemCameraTransforms func_181682_g()
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ItemTransformVec3f llllllllllllllIlllIlIIllIllIlIlI = llllllllllllllIlllIlIIllIllIlIll.func_181681_a(ItemCameraTransforms.TransformType.THIRD_PERSON);
    ItemTransformVec3f llllllllllllllIlllIlIIllIllIlIIl = llllllllllllllIlllIlIIllIllIIlII.func_181681_a(ItemCameraTransforms.TransformType.FIRST_PERSON);
    ItemTransformVec3f llllllllllllllIlllIlIIllIllIlIII = llllllllllllllIlllIlIIllIllIIlII.func_181681_a(ItemCameraTransforms.TransformType.HEAD);
    ItemTransformVec3f llllllllllllllIlllIlIIllIllIIlll = llllllllllllllIlllIlIIllIllIIlII.func_181681_a(ItemCameraTransforms.TransformType.GUI);
    ItemTransformVec3f llllllllllllllIlllIlIIllIllIIllI = llllllllllllllIlllIlIIllIllIIlII.func_181681_a(ItemCameraTransforms.TransformType.GROUND);
    ItemTransformVec3f llllllllllllllIlllIlIIllIllIIlIl = llllllllllllllIlllIlIIllIllIIlII.func_181681_a(ItemCameraTransforms.TransformType.FIXED);
    return new ItemCameraTransforms(llllllllllllllIlllIlIIllIllIlIlI, llllllllllllllIlllIlIIllIllIlIIl, llllllllllllllIlllIlIIllIllIlIII, llllllllllllllIlllIlIIllIllIIlll, llllllllllllllIlllIlIIllIllIIllI, llllllllllllllIlllIlIIllIllIIlIl);
  }
  
  private static String lIlIllllIIIllI(String llllllllllllllIlllIlIIllIlIIIIII, String llllllllllllllIlllIlIIllIIllllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllIlllIlIIllIlIIIlIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlllIlIIllIIllllll.getBytes(StandardCharsets.UTF_8)), lllIIlIIlllI[8]), "DES");
      Cipher llllllllllllllIlllIlIIllIlIIIlII = Cipher.getInstance("DES");
      llllllllllllllIlllIlIIllIlIIIlII.init(lllIIlIIlllI[3], llllllllllllllIlllIlIIllIlIIIlIl);
      return new String(llllllllllllllIlllIlIIllIlIIIlII.doFinal(Base64.getDecoder().decode(llllllllllllllIlllIlIIllIlIIIIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllIlllIlIIllIlIIIIll)
    {
      llllllllllllllIlllIlIIllIlIIIIll.printStackTrace();
    }
    return null;
  }
  
  public boolean isGui3d()
  {
    ;
    return gui3d;
  }
  
  static final class Bookkeep
  {
    private Bookkeep(ModelBlock llllllllllllllllIlllllllllllIllI)
    {
      model = llllllllllllllllIlllllllllllIllI;
    }
  }
  
  public static class LoopException
    extends RuntimeException
  {
    public LoopException() {}
  }
  
  public static class Deserializer
    implements JsonDeserializer<ModelBlock>
  {
    private static void lIIIlIlIIlIlll()
    {
      lIllIIllIIlI = new int[12];
      lIllIIllIIlI[0] = ((" ".length() ^ 0x25 ^ 0x76) & (0xC5 ^ 0x85 ^ 0x80 ^ 0x92 ^ -" ".length()));
      lIllIIllIIlI[1] = " ".length();
      lIllIIllIIlI[2] = "  ".length();
      lIllIIllIIlI[3] = "   ".length();
      lIllIIllIIlI[4] = (0x45 ^ 0x4 ^ 0x7C ^ 0x39);
      lIllIIllIIlI[5] = (0x3F ^ 0x31 ^ 0x1C ^ 0x17);
      lIllIIllIIlI[6] = (0x19 ^ 0x30 ^ 0x21 ^ 0xE);
      lIllIIllIIlI[7] = (0x59 ^ 0x5E);
      lIllIIllIIlI[8] = (0xB5 ^ 0xBD);
      lIllIIllIIlI[9] = (0x74 ^ 0x7D);
      lIllIIllIIlI[10] = (0x1C ^ 0x16);
      lIllIIllIIlI[11] = (0x79 ^ 0x72);
    }
    
    static
    {
      lIIIlIlIIlIlll();
      lIIIlIlIIlIllI();
    }
    
    private Map<String, String> getTextures(JsonObject lllllllllllllllIIllIlIlIlllIIlIl)
    {
      ;
      ;
      ;
      ;
      ;
      Map<String, String> lllllllllllllllIIllIlIlIlllIIlII = Maps.newHashMap();
      if (lIIIlIlIIllIII(lllllllllllllllIIllIlIlIlllIIIIl.has(lIllIIllIIIl[lIllIIllIIlI[4]])))
      {
        JsonObject lllllllllllllllIIllIlIlIlllIIIll = lllllllllllllllIIllIlIlIlllIIIIl.getAsJsonObject(lIllIIllIIIl[lIllIIllIIlI[5]]);
        lllllllllllllllIIllIlIlIllIlllIl = lllllllllllllllIIllIlIlIlllIIIll.entrySet().iterator();
        "".length();
        if (" ".length() == 0) {
          return null;
        }
        while (!lIIIlIlIIllIIl(lllllllllllllllIIllIlIlIllIlllIl.hasNext()))
        {
          Map.Entry<String, JsonElement> lllllllllllllllIIllIlIlIlllIIIlI = (Map.Entry)lllllllllllllllIIllIlIlIllIlllIl.next();
          "".length();
        }
      }
      return lllllllllllllllIIllIlIlIlllIIlII;
    }
    
    private static boolean lIIIlIlIIllIlI(int ???, int arg1)
    {
      int i;
      byte lllllllllllllllIIllIlIlIlIIIlIII;
      return ??? < i;
    }
    
    private static boolean lIIIlIlIIllIII(int ???)
    {
      double lllllllllllllllIIllIlIlIlIIIIllI;
      return ??? != 0;
    }
    
    private static String lIIIlIlIIlIIll(String lllllllllllllllIIllIlIlIlIIlIIIl, String lllllllllllllllIIllIlIlIlIIlIIII)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIllIlIlIlIIlIlII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIlIlIlIIlIIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIIllIlIlIlIIlIIll = Cipher.getInstance("Blowfish");
        lllllllllllllllIIllIlIlIlIIlIIll.init(lIllIIllIIlI[2], lllllllllllllllIIllIlIlIlIIlIlII);
        return new String(lllllllllllllllIIllIlIlIlIIlIIll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIlIlIlIIlIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIllIlIlIlIIlIIlI)
      {
        lllllllllllllllIIllIlIlIlIIlIIlI.printStackTrace();
      }
      return null;
    }
    
    protected List<BlockPart> getModelElements(JsonDeserializationContext lllllllllllllllIIllIlIlIllIIlllI, JsonObject lllllllllllllllIIllIlIlIllIIllIl)
    {
      ;
      ;
      ;
      ;
      ;
      List<BlockPart> lllllllllllllllIIllIlIlIllIIllII = Lists.newArrayList();
      if (lIIIlIlIIllIII(lllllllllllllllIIllIlIlIllIIllIl.has(lIllIIllIIIl[lIllIIllIIlI[9]])))
      {
        lllllllllllllllIIllIlIlIllIIIllI = JsonUtils.getJsonArray(lllllllllllllllIIllIlIlIllIIllIl, lIllIIllIIIl[lIllIIllIIlI[10]]).iterator();
        "".length();
        if (((0x93 ^ 0x8C) & (0x3A ^ 0x25 ^ 0xFFFFFFFF)) > ((0x58 ^ 0x3B) & (0xF7 ^ 0x94 ^ 0xFFFFFFFF))) {
          return null;
        }
        while (!lIIIlIlIIllIIl(lllllllllllllllIIllIlIlIllIIIllI.hasNext()))
        {
          JsonElement lllllllllllllllIIllIlIlIllIIlIll = (JsonElement)lllllllllllllllIIllIlIlIllIIIllI.next();
          "".length();
        }
      }
      return lllllllllllllllIIllIlIlIllIIllII;
    }
    
    private static boolean lIIIlIlIIllIIl(int ???)
    {
      long lllllllllllllllIIllIlIlIlIIIIlII;
      return ??? == 0;
    }
    
    protected boolean getAmbientOcclusionEnabled(JsonObject lllllllllllllllIIllIlIlIllIlIlIl)
    {
      ;
      return JsonUtils.getBoolean(lllllllllllllllIIllIlIlIllIlIlIl, lIllIIllIIIl[lIllIIllIIlI[8]], lIllIIllIIlI[1]);
    }
    
    public ModelBlock deserialize(JsonElement lllllllllllllllIIllIlIlIllllIllI, Type lllllllllllllllIIllIlIllIIIIIIlI, JsonDeserializationContext lllllllllllllllIIllIlIllIIIIIIIl)
      throws JsonParseException
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      JsonObject lllllllllllllllIIllIlIllIIIIIIII = lllllllllllllllIIllIlIlIllllIllI.getAsJsonObject();
      List<BlockPart> lllllllllllllllIIllIlIlIllllllll = lllllllllllllllIIllIlIllIIIIIlII.getModelElements(lllllllllllllllIIllIlIllIIIIIIIl, lllllllllllllllIIllIlIllIIIIIIII);
      String lllllllllllllllIIllIlIlIlllllllI = lllllllllllllllIIllIlIllIIIIIlII.getParent(lllllllllllllllIIllIlIllIIIIIIII);
      boolean lllllllllllllllIIllIlIlIllllllIl = StringUtils.isEmpty(lllllllllllllllIIllIlIlIlllllllI);
      boolean lllllllllllllllIIllIlIlIllllllII = lllllllllllllllIIllIlIlIllllllll.isEmpty();
      if ((lIIIlIlIIllIII(lllllllllllllllIIllIlIlIllllllII)) && (lIIIlIlIIllIII(lllllllllllllllIIllIlIlIllllllIl))) {
        throw new JsonParseException(lIllIIllIIIl[lIllIIllIIlI[0]]);
      }
      if ((lIIIlIlIIllIIl(lllllllllllllllIIllIlIlIllllllIl)) && (lIIIlIlIIllIIl(lllllllllllllllIIllIlIlIllllllII))) {
        throw new JsonParseException(lIllIIllIIIl[lIllIIllIIlI[1]]);
      }
      Map<String, String> lllllllllllllllIIllIlIlIlllllIll = lllllllllllllllIIllIlIllIIIIIlII.getTextures(lllllllllllllllIIllIlIllIIIIIIII);
      boolean lllllllllllllllIIllIlIlIlllllIlI = lllllllllllllllIIllIlIllIIIIIlII.getAmbientOcclusionEnabled(lllllllllllllllIIllIlIllIIIIIIII);
      ItemCameraTransforms lllllllllllllllIIllIlIlIlllllIIl = ItemCameraTransforms.DEFAULT;
      if (lIIIlIlIIllIII(lllllllllllllllIIllIlIllIIIIIIII.has(lIllIIllIIIl[lIllIIllIIlI[2]])))
      {
        JsonObject lllllllllllllllIIllIlIlIlllllIII = JsonUtils.getJsonObject(lllllllllllllllIIllIlIllIIIIIIII, lIllIIllIIIl[lIllIIllIIlI[3]]);
        lllllllllllllllIIllIlIlIlllllIIl = (ItemCameraTransforms)lllllllllllllllIIllIlIllIIIIIIIl.deserialize(lllllllllllllllIIllIlIlIlllllIII, ItemCameraTransforms.class);
      }
      if (lIIIlIlIIllIII(lllllllllllllllIIllIlIlIllllllII))
      {
        new ModelBlock(tmp193_190, lllllllllllllllIIllIlIlIlllllIll, lllllllllllllllIIllIlIlIlllllIlI, lIllIIllIIlI[1], lllllllllllllllIIllIlIlIlllllIIl);
        new ResourceLocation(lllllllllllllllIIllIlIlIlllllllI);
        "".length();
        if (" ".length() >= ((0x29 ^ 0x31) & (0xB1 ^ 0xA9 ^ 0xFFFFFFFF))) {
          break label264;
        }
        return null;
      }
      label264:
      return new ModelBlock(lllllllllllllllIIllIlIlIllllllll, lllllllllllllllIIllIlIlIlllllIll, lllllllllllllllIIllIlIlIlllllIlI, lIllIIllIIlI[1], lllllllllllllllIIllIlIlIlllllIIl);
    }
    
    public Deserializer() {}
    
    private static String lIIIlIlIIlIlIl(String lllllllllllllllIIllIlIlIlIIllllI, String lllllllllllllllIIllIlIlIlIIlllIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIllIlIlIlIlIIIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIllIlIlIlIIlllIl.getBytes(StandardCharsets.UTF_8)), lIllIIllIIlI[8]), "DES");
        Cipher lllllllllllllllIIllIlIlIlIlIIIII = Cipher.getInstance("DES");
        lllllllllllllllIIllIlIlIlIlIIIII.init(lIllIIllIIlI[2], lllllllllllllllIIllIlIlIlIlIIIIl);
        return new String(lllllllllllllllIIllIlIlIlIlIIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIIllIlIlIlIIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIllIlIlIlIIlllll)
      {
        lllllllllllllllIIllIlIlIlIIlllll.printStackTrace();
      }
      return null;
    }
    
    private static String lIIIlIlIIlIlII(String lllllllllllllllIIllIlIlIlIlIlllI, String lllllllllllllllIIllIlIlIlIlIllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIIllIlIlIlIlIlllI = new String(Base64.getDecoder().decode(lllllllllllllllIIllIlIlIlIlIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIIllIlIlIlIllIIIl = new StringBuilder();
      char[] lllllllllllllllIIllIlIlIlIllIIII = lllllllllllllllIIllIlIlIlIlIllIl.toCharArray();
      int lllllllllllllllIIllIlIlIlIlIllll = lIllIIllIIlI[0];
      String lllllllllllllllIIllIlIlIlIlIlIIl = lllllllllllllllIIllIlIlIlIlIlllI.toCharArray();
      short lllllllllllllllIIllIlIlIlIlIlIII = lllllllllllllllIIllIlIlIlIlIlIIl.length;
      int lllllllllllllllIIllIlIlIlIlIIlll = lIllIIllIIlI[0];
      while (lIIIlIlIIllIlI(lllllllllllllllIIllIlIlIlIlIIlll, lllllllllllllllIIllIlIlIlIlIlIII))
      {
        char lllllllllllllllIIllIlIlIlIllIlII = lllllllllllllllIIllIlIlIlIlIlIIl[lllllllllllllllIIllIlIlIlIlIIlll];
        "".length();
        "".length();
        if ((29 + 37 - -12 + 79 ^ 118 + 67 - 111 + 79) == -" ".length()) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIIllIlIlIlIllIIIl);
    }
    
    private String getParent(JsonObject lllllllllllllllIIllIlIlIllIllIIl)
    {
      ;
      return JsonUtils.getString(lllllllllllllllIIllIlIlIllIllIIl, lIllIIllIIIl[lIllIIllIIlI[6]], lIllIIllIIIl[lIllIIllIIlI[7]]);
    }
    
    private static void lIIIlIlIIlIllI()
    {
      lIllIIllIIIl = new String[lIllIIllIIlI[11]];
      lIllIIllIIIl[lIllIIllIIlI[0]] = lIIIlIlIIlIIll("9ZHz+Kr6sUtieyCxLAAzsu7LXhxUTBrAjmz7DaSW1XZ4nImwVkvzFRGUbPZQ6ZMAPWs6hoAjOf5yrzfvn5uMuA==", "zTFNe");
      lIllIIllIIIl[lIllIIllIIlI[1]] = lIIIlIlIIlIlII("NSgMCyU6KwcNIlc2Bhk7HjYGG24SLRcAKwVkBgQrGiENHD1XKxFIPhY2BgY6W2QFBzsZIEMKIQMs", "wDchN");
      lIllIIllIIIl[lIllIIllIIlI[2]] = lIIIlIlIIlIlIl("l/9UBo9sCBY=", "siZyy");
      lIllIIllIIIl[lIllIIllIIlI[3]] = lIIIlIlIIlIlIl("Ko+BK/IgBKQ=", "NOiqg");
      lIllIIllIIIl[lIllIIllIIlI[4]] = lIIIlIlIIlIIll("sFJaic+zXLZHLKZrCUsR4w==", "miZqJ");
      lIllIIllIIIl[lIllIIllIIlI[5]] = lIIIlIlIIlIIll("5j6E4zwVIJsLZfP25pXl1g==", "gFSEV");
      lIllIIllIIIl[lIllIIllIIlI[6]] = lIIIlIlIIlIIll("6gft8/zX0Z4=", "pEVpe");
      lIllIIllIIIl[lIllIIllIIlI[7]] = lIIIlIlIIlIIll("d2YxLrHQq+4=", "SRLXR");
      lIllIIllIIIl[lIllIIllIIlI[8]] = lIIIlIlIIlIlII("OzgpOQY0ISQzADYgODkMNA==", "ZUKPc");
      lIllIIllIIIl[lIllIIllIIlI[9]] = lIIIlIlIIlIIll("iQqZqb6NxbDmF5lzqZ/3rw==", "uXjkH");
      lIllIIllIIIl[lIllIIllIIlI[10]] = lIIIlIlIIlIlIl("cSCChvyC89RaTgl5ieUq9g==", "ZLcKO");
    }
  }
}

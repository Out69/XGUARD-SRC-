package net.minecraft.client.renderer.block.model;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.JsonUtils;

public class BlockPartFace
{
  public BlockPartFace(EnumFacing llllllllllllllllIIIlIlllIlllIIlI, int llllllllllllllllIIIlIlllIlllIIIl, String llllllllllllllllIIIlIlllIlllIIII, BlockFaceUV llllllllllllllllIIIlIlllIllIlIlI)
  {
    cullFace = llllllllllllllllIIIlIlllIlllIIlI;
    tintIndex = llllllllllllllllIIIlIlllIllIllII;
    texture = llllllllllllllllIIIlIlllIlllIIII;
    blockFaceUV = llllllllllllllllIIIlIlllIllIlIlI;
  }
  
  static class Deserializer
    implements JsonDeserializer<BlockPartFace>
  {
    private static String lIIllIllllIlll(String lllllllllllllllIIIlIIlIIllIllIll, String lllllllllllllllIIIlIIlIIllIllIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIIlIIlIIlllIIIII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIlIIlIIllIllIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIIIlIIlIIllIlllll = Cipher.getInstance("Blowfish");
        lllllllllllllllIIIlIIlIIllIlllll.init(llIIllIIIlII[3], lllllllllllllllIIIlIIlIIlllIIIII);
        return new String(lllllllllllllllIIIlIIlIIllIlllll.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIlIIlIIllIllIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIIlIIlIIllIllllI)
      {
        lllllllllllllllIIIlIIlIIllIllllI.printStackTrace();
      }
      return null;
    }
    
    private EnumFacing parseCullFace(JsonObject lllllllllllllllIIIlIIlIlIIIIlIII)
    {
      ;
      ;
      String lllllllllllllllIIIlIIlIlIIIIIlll = JsonUtils.getString(lllllllllllllllIIIlIIlIlIIIIlIII, llIIllIIIIlI[llIIllIIIlII[3]], llIIllIIIIlI[llIIllIIIlII[4]]);
      return EnumFacing.byName(lllllllllllllllIIIlIIlIlIIIIIlll);
    }
    
    public BlockPartFace deserialize(JsonElement lllllllllllllllIIIlIIlIlIIIllIlI, Type lllllllllllllllIIIlIIlIlIIlIIIlI, JsonDeserializationContext lllllllllllllllIIIlIIlIlIIlIIIIl)
      throws JsonParseException
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      JsonObject lllllllllllllllIIIlIIlIlIIlIIIII = lllllllllllllllIIIlIIlIlIIIllIlI.getAsJsonObject();
      EnumFacing lllllllllllllllIIIlIIlIlIIIlllll = lllllllllllllllIIIlIIlIlIIIllIll.parseCullFace(lllllllllllllllIIIlIIlIlIIlIIIII);
      int lllllllllllllllIIIlIIlIlIIIllllI = lllllllllllllllIIIlIIlIlIIIllIll.parseTintIndex(lllllllllllllllIIIlIIlIlIIlIIIII);
      String lllllllllllllllIIIlIIlIlIIIlllIl = lllllllllllllllIIIlIIlIlIIIllIll.parseTexture(lllllllllllllllIIIlIIlIlIIlIIIII);
      BlockFaceUV lllllllllllllllIIIlIIlIlIIIlllII = (BlockFaceUV)lllllllllllllllIIIlIIlIlIIlIIIIl.deserialize(lllllllllllllllIIIlIIlIlIIlIIIII, BlockFaceUV.class);
      return new BlockPartFace(lllllllllllllllIIIlIIlIlIIIlllll, lllllllllllllllIIIlIIlIlIIIllllI, lllllllllllllllIIIlIIlIlIIIlllIl, lllllllllllllllIIIlIIlIlIIIlllII);
    }
    
    Deserializer() {}
    
    private static String lIIllIlllllIII(String lllllllllllllllIIIlIIlIIllIIlllI, String lllllllllllllllIIIlIIlIIllIIllll)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIIIlIIlIIllIlIIll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIIIlIIlIIllIIllll.getBytes(StandardCharsets.UTF_8)), llIIllIIIlII[6]), "DES");
        Cipher lllllllllllllllIIIlIIlIIllIlIIlI = Cipher.getInstance("DES");
        lllllllllllllllIIIlIIlIIllIlIIlI.init(llIIllIIIlII[3], lllllllllllllllIIIlIIlIIllIlIIll);
        return new String(lllllllllllllllIIIlIIlIIllIlIIlI.doFinal(Base64.getDecoder().decode(lllllllllllllllIIIlIIlIIllIIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIIIlIIlIIllIlIIIl)
      {
        lllllllllllllllIIIlIIlIIllIlIIIl.printStackTrace();
      }
      return null;
    }
    
    private static boolean lIIlllIIIIIllI(int ???, int arg1)
    {
      int i;
      String lllllllllllllllIIIlIIlIIllIIIlll;
      return ??? < i;
    }
    
    static
    {
      lIIlllIIIIIlIl();
      lIIllIlllllIIl();
    }
    
    private String parseTexture(JsonObject lllllllllllllllIIIlIIlIlIIIIllIl)
    {
      ;
      return JsonUtils.getString(lllllllllllllllIIIlIIlIlIIIIllIl, llIIllIIIIlI[llIIllIIIlII[2]]);
    }
    
    protected int parseTintIndex(JsonObject lllllllllllllllIIIlIIlIlIIIlIIII)
    {
      ;
      return JsonUtils.getInt(lllllllllllllllIIIlIIlIlIIIlIIII, llIIllIIIIlI[llIIllIIIlII[0]], llIIllIIIlII[1]);
    }
    
    private static void lIIllIlllllIIl()
    {
      llIIllIIIIlI = new String[llIIllIIIlII[5]];
      llIIllIIIIlI[llIIllIIIlII[0]] = lIIllIllllIllI("FSInOD4PLyw0", "aKILW");
      llIIllIIIIlI[llIIllIIIlII[2]] = lIIllIllllIlll("DEeDvZdzKfg=", "PxGUC");
      llIIllIIIIlI[llIIllIIIlII[3]] = lIIllIllllIlll("OkpEy2ueAWeVcWdoKmP0TA==", "ZMcur");
      llIIllIIIIlI[llIIllIIIlII[4]] = lIIllIlllllIII("z4OzHKkV9A8=", "KgMwL");
    }
    
    private static void lIIlllIIIIIlIl()
    {
      llIIllIIIlII = new int[7];
      llIIllIIIlII[0] = ((0x48 ^ 0x40) & (0x58 ^ 0x50 ^ 0xFFFFFFFF));
      llIIllIIIlII[1] = (-" ".length());
      llIIllIIIlII[2] = " ".length();
      llIIllIIIlII[3] = "  ".length();
      llIIllIIIlII[4] = "   ".length();
      llIIllIIIlII[5] = (0x9 ^ 0xD);
      llIIllIIIlII[6] = (0x2D ^ 0x25);
    }
    
    private static String lIIllIllllIllI(String lllllllllllllllIIIlIIlIIlllIllIl, String lllllllllllllllIIIlIIlIIllllIIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIIIlIIlIIlllIllIl = new String(Base64.getDecoder().decode(lllllllllllllllIIIlIIlIIlllIllIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIIIlIIlIIllllIIII = new StringBuilder();
      char[] lllllllllllllllIIIlIIlIIlllIllll = lllllllllllllllIIIlIIlIIllllIIIl.toCharArray();
      int lllllllllllllllIIIlIIlIIlllIlllI = llIIllIIIlII[0];
      Exception lllllllllllllllIIIlIIlIIlllIlIII = lllllllllllllllIIIlIIlIIlllIllIl.toCharArray();
      long lllllllllllllllIIIlIIlIIlllIIlll = lllllllllllllllIIIlIIlIIlllIlIII.length;
      int lllllllllllllllIIIlIIlIIlllIIllI = llIIllIIIlII[0];
      while (lIIlllIIIIIllI(lllllllllllllllIIIlIIlIIlllIIllI, lllllllllllllllIIIlIIlIIlllIIlll))
      {
        char lllllllllllllllIIIlIIlIIllllIIll = lllllllllllllllIIIlIIlIIlllIlIII[lllllllllllllllIIIlIIlIIlllIIllI];
        "".length();
        "".length();
        if ((0xFE ^ 0xA0 ^ 0xE3 ^ 0xB9) <= " ".length()) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIIIlIIlIIllllIIII);
    }
  }
}

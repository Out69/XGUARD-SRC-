package net.minecraft.client.renderer.block.model;

import com.google.common.collect.Maps;
import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumFacing.Axis;
import net.minecraft.util.JsonUtils;
import net.minecraft.util.MathHelper;
import org.lwjgl.util.vector.Vector3f;

public class BlockPart
{
  private void setDefaultUvs()
  {
    ;
    ;
    ;
    int llllllllllllllIlIIlIlIIlIlIIllII = mapFaces.entrySet().iterator();
    "".length();
    if (" ".length() != " ".length()) {
      return;
    }
    while (!llIllIIIIlllll(llllllllllllllIlIIlIlIIlIlIIllII.hasNext()))
    {
      Map.Entry<EnumFacing, BlockPartFace> llllllllllllllIlIIlIlIIlIlIlIIII = (Map.Entry)llllllllllllllIlIIlIlIIlIlIIllII.next();
      float[] llllllllllllllIlIIlIlIIlIlIIllll = llllllllllllllIlIIlIlIIlIlIIlllI.getFaceUvs((EnumFacing)llllllllllllllIlIIlIlIIlIlIlIIII.getKey());
      getValueblockFaceUV.setUvs(llllllllllllllIlIIlIlIIlIlIIllll);
    }
  }
  
  private static boolean llIllIIIIlllll(int ???)
  {
    byte llllllllllllllIlIIlIlIIlIIlllIIl;
    return ??? == 0;
  }
  
  public BlockPart(Vector3f llllllllllllllIlIIlIlIIlIlIllIlI, Vector3f llllllllllllllIlIIlIlIIlIlIlllll, Map<EnumFacing, BlockPartFace> llllllllllllllIlIIlIlIIlIlIllllI, BlockPartRotation llllllllllllllIlIIlIlIIlIlIlIlll, boolean llllllllllllllIlIIlIlIIlIlIlIllI)
  {
    positionFrom = llllllllllllllIlIIlIlIIlIlIllIlI;
    positionTo = llllllllllllllIlIIlIlIIlIlIlllll;
    mapFaces = llllllllllllllIlIIlIlIIlIlIllllI;
    partRotation = llllllllllllllIlIIlIlIIlIlIlIlll;
    shade = llllllllllllllIlIIlIlIIlIlIlIllI;
    llllllllllllllIlIIlIlIIlIlIllIll.setDefaultUvs();
  }
  
  static {}
  
  private float[] getFaceUvs(EnumFacing llllllllllllllIlIIlIlIIlIlIIIIII)
  {
    ;
    ;
    ;
    switch ($SWITCH_TABLE$net$minecraft$util$EnumFacing()[llllllllllllllIlIIlIlIIlIlIIIIII.ordinal()])
    {
    case 1: 
    case 2: 
      float[] llllllllllllllIlIIlIlIIlIlIIIlIl = { positionFrom.x, positionFrom.z, positionTo.x, positionTo.z };
      "".length();
      if ((55 + '' - 162 + 135 ^ 63 + '' - 172 + 125) < 0) {
        return null;
      }
      break;
    case 3: 
    case 4: 
      float[] llllllllllllllIlIIlIlIIlIlIIIlII = { positionFrom.x, 16.0F - positionTo.y, positionTo.x, 16.0F - positionFrom.y };
      "".length();
      if (((0x52 ^ 0x3C ^ 0x7B ^ 0x19) & (0x1A ^ 0x6 ^ 0x5F ^ 0x4F ^ -" ".length())) >= " ".length()) {
        return null;
      }
      break;
    case 5: 
    case 6: 
      float[] llllllllllllllIlIIlIlIIlIlIIIIll = { positionFrom.z, 16.0F - positionTo.y, positionTo.z, 16.0F - positionFrom.y };
      "".length();
      if ((0xA8 ^ 0xAC) == 0) {
        return null;
      }
      break;
    default: 
      throw new NullPointerException();
    }
    float[] llllllllllllllIlIIlIlIIlIlIIIIlI;
    return llllllllllllllIlIIlIlIIlIlIIIIlI;
  }
  
  private static boolean llIllIIIlIIIII(Object ???)
  {
    double llllllllllllllIlIIlIlIIlIIlllIll;
    return ??? != null;
  }
  
  private static void llIllIIIIllllI()
  {
    lIIIlllIIlIlI = new int[7];
    lIIIlllIIlIlI[0] = (0x2A ^ 0x2E);
    lIIIlllIIlIlI[1] = ((79 + 86 - -23 + 13 ^ 44 + 0 - 12 + 137) & (0x6A ^ 0x37 ^ 0x7C ^ 0x41 ^ -" ".length()));
    lIIIlllIIlIlI[2] = " ".length();
    lIIIlllIIlIlI[3] = "  ".length();
    lIIIlllIIlIlI[4] = "   ".length();
    lIIIlllIIlIlI[5] = (0x92 ^ 0x94);
    lIIIlllIIlIlI[6] = (0x1 ^ 0x4);
  }
  
  static class Deserializer
    implements JsonDeserializer<BlockPart>
  {
    private static boolean lllIlIIllIIll(int ???, int arg1)
    {
      int i;
      char lllllllllllllllIllIIIIlIllIlIlIl;
      return ??? >= i;
    }
    
    private Vector3f parsePositionFrom(JsonObject lllllllllllllllIllIIIIllIIlIIlII)
    {
      ;
      ;
      ;
      Vector3f lllllllllllllllIllIIIIllIIlIIllI = lllllllllllllllIllIIIIllIIlIIlIl.parsePosition(lllllllllllllllIllIIIIllIIlIIlII, lIIlIIlIlIll[lIIlIlllIllI[18]]);
      if ((lllIlIIlIlllI(lllIlIIllIIII(x, -16.0F))) && (lllIlIIlIlllI(lllIlIIllIIII(y, -16.0F))) && (lllIlIIlIlllI(lllIlIIllIIII(z, -16.0F))) && (lllIlIIlIllll(lllIlIIllIIIl(x, 32.0F))) && (lllIlIIlIllll(lllIlIIllIIIl(y, 32.0F))) && (lllIlIIlIllll(lllIlIIllIIIl(z, 32.0F)))) {
        return lllllllllllllllIllIIIIllIIlIIllI;
      }
      throw new JsonParseException(String.valueOf(new StringBuilder(lIIlIIlIlIll[lIIlIlllIllI[19]]).append(lllllllllllllllIllIIIIllIIlIIllI)));
    }
    
    private Vector3f parsePosition(JsonObject lllllllllllllllIllIIIIllIIIlllII, String lllllllllllllllIllIIIIllIIIlIllI)
    {
      ;
      ;
      ;
      ;
      ;
      JsonArray lllllllllllllllIllIIIIllIIIllIlI = JsonUtils.getJsonArray(lllllllllllllllIllIIIIllIIIlllII, lllllllllllllllIllIIIIllIIIlIllI);
      if (lllIlIIllIIlI(lllllllllllllllIllIIIIllIIIllIlI.size(), lIIlIlllIllI[3])) {
        throw new JsonParseException(String.valueOf(new StringBuilder(lIIlIIlIlIll[lIIlIlllIllI[20]]).append(lllllllllllllllIllIIIIllIIIlIllI).append(lIIlIIlIlIll[lIIlIlllIllI[21]]).append(lllllllllllllllIllIIIIllIIIllIlI.size())));
      }
      float[] lllllllllllllllIllIIIIllIIIllIIl = new float[lIIlIlllIllI[3]];
      int lllllllllllllllIllIIIIllIIIllIII = lIIlIlllIllI[0];
      "".length();
      if (null != null) {
        return null;
      }
      while (!lllIlIIllIIll(lllllllllllllllIllIIIIllIIIllIII, lllllllllllllllIllIIIIllIIIllIIl.length))
      {
        lllllllllllllllIllIIIIllIIIllIIl[lllllllllllllllIllIIIIllIIIllIII] = JsonUtils.getFloat(lllllllllllllllIllIIIIllIIIllIlI.get(lllllllllllllllIllIIIIllIIIllIII), String.valueOf(new StringBuilder(String.valueOf(lllllllllllllllIllIIIIllIIIlIllI)).append(lIIlIIlIlIll[lIIlIlllIllI[22]]).append(lllllllllllllllIllIIIIllIIIllIII).append(lIIlIIlIlIll[lIIlIlllIllI[23]])));
        lllllllllllllllIllIIIIllIIIllIII++;
      }
      return new Vector3f(lllllllllllllllIllIIIIllIIIllIIl[lIIlIlllIllI[0]], lllllllllllllllIllIIIIllIIIllIIl[lIIlIlllIllI[1]], lllllllllllllllIllIIIIllIIIllIIl[lIIlIlllIllI[2]]);
    }
    
    private static void lllIlIIlIIlll()
    {
      lIIlIlllIllI = new int[25];
      lIIlIlllIllI[0] = ((0x41 ^ 0x18) & (0x35 ^ 0x6C ^ 0xFFFFFFFF));
      lIIlIlllIllI[1] = " ".length();
      lIIlIlllIllI[2] = "  ".length();
      lIIlIlllIllI[3] = "   ".length();
      lIIlIlllIllI[4] = (0x7C ^ 0x3F ^ 0xFE ^ 0xB9);
      lIIlIlllIllI[5] = (0x7A ^ 0x7F);
      lIIlIlllIllI[6] = (0x5D ^ 0x79 ^ 0x27 ^ 0x5);
      lIIlIlllIllI[7] = (0x77 ^ 0x70);
      lIIlIlllIllI[8] = (0x34 ^ 0x3C);
      lIIlIlllIllI[9] = (0x86 ^ 0xBB ^ 0x60 ^ 0x54);
      lIIlIlllIllI[10] = (0x9A ^ 0xC7 ^ 0x5F ^ 0x8);
      lIIlIlllIllI[11] = ('' + 11 - -15 + 0 ^ 30 + '' - 116 + 107);
      lIIlIlllIllI[12] = (0x5 ^ 0x9);
      lIIlIlllIllI[13] = (0x85 ^ 0xB3 ^ 0x24 ^ 0x1F);
      lIIlIlllIllI[14] = (0x7D ^ 0x63 ^ 0xD0 ^ 0xC0);
      lIIlIlllIllI[15] = (0x9C ^ 0x93);
      lIIlIlllIllI[16] = (0x1E ^ 0xE);
      lIIlIlllIllI[17] = (0x38 ^ 0x19 ^ 0xF ^ 0x3F);
      lIIlIlllIllI[18] = (0xB4 ^ 0xC1 ^ 0x15 ^ 0x72);
      lIIlIlllIllI[19] = (0x7F ^ 0x6C);
      lIIlIlllIllI[20] = (0xBF ^ 0xAB);
      lIIlIlllIllI[21] = (0x7 ^ 0x12);
      lIIlIlllIllI[22] = (0x7B ^ 0x33 ^ 0xEF ^ 0xB1);
      lIIlIlllIllI[23] = (0x25 ^ 0x4A ^ 0x2F ^ 0x57);
      lIIlIlllIllI[24] = (65 + 19 - 76 + 121 ^ 57 + 65 - -17 + 14);
    }
    
    Deserializer() {}
    
    private static int lllIlIIlIllIl(float paramFloat1, float paramFloat2)
    {
      return paramFloat1 < paramFloat2;
    }
    
    private static boolean lllIlIIlIlIIl(int ???)
    {
      float lllllllllllllllIllIIIIlIllIIlIll;
      return ??? == 0;
    }
    
    private BlockPartRotation parseRotation(JsonObject lllllllllllllllIllIIIIlllIIlllIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      BlockPartRotation lllllllllllllllIllIIIIlllIIllIll = null;
      if (lllIlIIlIlIII(lllllllllllllllIllIIIIlllIIlllIl.has(lIIlIIlIlIll[lIIlIlllIllI[4]])))
      {
        JsonObject lllllllllllllllIllIIIIlllIIllIlI = JsonUtils.getJsonObject(lllllllllllllllIllIIIIlllIIlllIl, lIIlIIlIlIll[lIIlIlllIllI[5]]);
        Vector3f lllllllllllllllIllIIIIlllIIllIII = lllllllllllllllIllIIIIlllIIlIIII.parsePosition(lllllllllllllllIllIIIIlllIIllIlI, lIIlIIlIlIll[lIIlIlllIllI[6]]);
        "".length();
        EnumFacing.Axis lllllllllllllllIllIIIIlllIIlIllI = lllllllllllllllIllIIIIlllIIlIIII.parseAxis(lllllllllllllllIllIIIIlllIIllIlI);
        float lllllllllllllllIllIIIIlllIIlIlII = lllllllllllllllIllIIIIlllIIlIIII.parseAngle(lllllllllllllllIllIIIIlllIIllIlI);
        boolean lllllllllllllllIllIIIIlllIIlIIlI = JsonUtils.getBoolean(lllllllllllllllIllIIIIlllIIllIlI, lIIlIIlIlIll[lIIlIlllIllI[7]], lIIlIlllIllI[0]);
        lllllllllllllllIllIIIIlllIIllIll = new BlockPartRotation(lllllllllllllllIllIIIIlllIIllIII, lllllllllllllllIllIIIIlllIIlIllI, lllllllllllllllIllIIIIlllIIlIlII, lllllllllllllllIllIIIIlllIIlIIlI);
      }
      return lllllllllllllllIllIIIIlllIIllIll;
    }
    
    private Map<EnumFacing, BlockPartFace> parseFaces(JsonDeserializationContext lllllllllllllllIllIIIIllIlIIIIlI, JsonObject lllllllllllllllIllIIIIllIlIIIIIl)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      Map<EnumFacing, BlockPartFace> lllllllllllllllIllIIIIllIlIIIlll = Maps.newEnumMap(EnumFacing.class);
      JsonObject lllllllllllllllIllIIIIllIlIIIllI = JsonUtils.getJsonObject(lllllllllllllllIllIIIIllIlIIIIIl, lIIlIIlIlIll[lIIlIlllIllI[14]]);
      Exception lllllllllllllllIllIIIIllIIllllIl = lllllllllllllllIllIIIIllIlIIIllI.entrySet().iterator();
      "".length();
      if ("   ".length() <= 0) {
        return null;
      }
      while (!lllIlIIlIlIIl(lllllllllllllllIllIIIIllIIllllIl.hasNext()))
      {
        Map.Entry<String, JsonElement> lllllllllllllllIllIIIIllIlIIIlIl = (Map.Entry)lllllllllllllllIllIIIIllIIllllIl.next();
        EnumFacing lllllllllllllllIllIIIIllIlIIIlII = lllllllllllllllIllIIIIllIlIIIIll.parseEnumFacing((String)lllllllllllllllIllIIIIllIlIIIlIl.getKey());
        "".length();
      }
      return lllllllllllllllIllIIIIllIlIIIlll;
    }
    
    private static boolean lllIlIIllIlII(int ???, int arg1)
    {
      int i;
      float lllllllllllllllIllIIIIlIllIlIIIl;
      return ??? < i;
    }
    
    private static boolean lllIlIIlIllll(int ???)
    {
      boolean lllllllllllllllIllIIIIlIllIIIlll;
      return ??? <= 0;
    }
    
    private static int lllIlIIllIIII(float paramFloat1, float paramFloat2)
    {
      return paramFloat1 < paramFloat2;
    }
    
    static
    {
      lllIlIIlIIlll();
      lllIlIIlIIlII();
    }
    
    private static int lllIlIIllIIIl(float paramFloat1, float paramFloat2)
    {
      return paramFloat1 < paramFloat2;
    }
    
    private Vector3f parsePositionTo(JsonObject lllllllllllllllIllIIIIllIIlIllIl)
    {
      ;
      ;
      ;
      Vector3f lllllllllllllllIllIIIIllIIlIllll = lllllllllllllllIllIIIIllIIlIlllI.parsePosition(lllllllllllllllIllIIIIllIIlIllIl, lIIlIIlIlIll[lIIlIlllIllI[16]]);
      if ((lllIlIIlIlllI(lllIlIIlIllII(x, -16.0F))) && (lllIlIIlIlllI(lllIlIIlIllII(y, -16.0F))) && (lllIlIIlIlllI(lllIlIIlIllII(z, -16.0F))) && (lllIlIIlIllll(lllIlIIlIllIl(x, 32.0F))) && (lllIlIIlIllll(lllIlIIlIllIl(y, 32.0F))) && (lllIlIIlIllll(lllIlIIlIllIl(z, 32.0F)))) {
        return lllllllllllllllIllIIIIllIIlIllll;
      }
      throw new JsonParseException(String.valueOf(new StringBuilder(lIIlIIlIlIll[lIIlIlllIllI[17]]).append(lllllllllllllllIllIIIIllIIlIllll)));
    }
    
    private static String lllIIIlIlIIlI(String lllllllllllllllIllIIIIlIllIllllI, String lllllllllllllllIllIIIIlIllIlllIl)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIllIIIIlIlllIIIIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIIlIllIlllIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
        Cipher lllllllllllllllIllIIIIlIlllIIIII = Cipher.getInstance("Blowfish");
        lllllllllllllllIllIIIIlIlllIIIII.init(lIIlIlllIllI[2], lllllllllllllllIllIIIIlIlllIIIIl);
        return new String(lllllllllllllllIllIIIIlIlllIIIII.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIIlIllIllllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIllIIIIlIllIlllll)
      {
        lllllllllllllllIllIIIIlIllIlllll.printStackTrace();
      }
      return null;
    }
    
    public BlockPart deserialize(JsonElement lllllllllllllllIllIIIIlllIlllIlI, Type lllllllllllllllIllIIIIllllIIIIll, JsonDeserializationContext lllllllllllllllIllIIIIllllIIIIlI)
      throws JsonParseException
    {
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      ;
      JsonObject lllllllllllllllIllIIIIllllIIIIIl = lllllllllllllllIllIIIIlllIlllIlI.getAsJsonObject();
      Vector3f lllllllllllllllIllIIIIllllIIIIII = lllllllllllllllIllIIIIllllIIIlIl.parsePositionFrom(lllllllllllllllIllIIIIllllIIIIIl);
      Vector3f lllllllllllllllIllIIIIlllIllllll = lllllllllllllllIllIIIIllllIIIlIl.parsePositionTo(lllllllllllllllIllIIIIllllIIIIIl);
      BlockPartRotation lllllllllllllllIllIIIIlllIlllllI = lllllllllllllllIllIIIIllllIIIlIl.parseRotation(lllllllllllllllIllIIIIllllIIIIIl);
      Map<EnumFacing, BlockPartFace> lllllllllllllllIllIIIIlllIllllIl = lllllllllllllllIllIIIIllllIIIlIl.parseFacesCheck(lllllllllllllllIllIIIIllllIIIIlI, lllllllllllllllIllIIIIllllIIIIIl);
      if ((lllIlIIlIlIII(lllllllllllllllIllIIIIllllIIIIIl.has(lIIlIIlIlIll[lIIlIlllIllI[0]]))) && (lllIlIIlIlIIl(JsonUtils.isBoolean(lllllllllllllllIllIIIIllllIIIIIl, lIIlIIlIlIll[lIIlIlllIllI[1]])))) {
        throw new JsonParseException(lIIlIIlIlIll[lIIlIlllIllI[2]]);
      }
      boolean lllllllllllllllIllIIIIlllIllllII = JsonUtils.getBoolean(lllllllllllllllIllIIIIllllIIIIIl, lIIlIIlIlIll[lIIlIlllIllI[3]], lIIlIlllIllI[1]);
      return new BlockPart(lllllllllllllllIllIIIIllllIIIIII, lllllllllllllllIllIIIIlllIllllll, lllllllllllllllIllIIIIlllIllllIl, lllllllllllllllIllIIIIlllIlllllI, lllllllllllllllIllIIIIlllIllllII);
    }
    
    private float parseAngle(JsonObject lllllllllllllllIllIIIIllIlllIlIl)
    {
      ;
      ;
      float lllllllllllllllIllIIIIllIlllIllI = JsonUtils.getFloat(lllllllllllllllIllIIIIllIlllIlIl, lIIlIIlIlIll[lIIlIlllIllI[8]]);
      if ((lllIlIIlIlIII(lllIlIIlIlIlI(lllllllllllllllIllIIIIllIlllIllI, 0.0F))) && (lllIlIIlIlIII(lllIlIIlIlIlI(MathHelper.abs(lllllllllllllllIllIIIIllIlllIllI), 22.5F))) && (lllIlIIlIlIII(lllIlIIlIlIlI(MathHelper.abs(lllllllllllllllIllIIIIllIlllIllI), 45.0F)))) {
        throw new JsonParseException(String.valueOf(new StringBuilder(lIIlIIlIlIll[lIIlIlllIllI[9]]).append(lllllllllllllllIllIIIIllIlllIllI).append(lIIlIIlIlIll[lIIlIlllIllI[10]])));
      }
      return lllllllllllllllIllIIIIllIlllIllI;
    }
    
    private Map<EnumFacing, BlockPartFace> parseFacesCheck(JsonDeserializationContext lllllllllllllllIllIIIIllIlIlIlIl, JsonObject lllllllllllllllIllIIIIllIlIllIII)
    {
      ;
      ;
      ;
      ;
      Map<EnumFacing, BlockPartFace> lllllllllllllllIllIIIIllIlIlIlll = lllllllllllllllIllIIIIllIlIlIllI.parseFaces(lllllllllllllllIllIIIIllIlIllIIl, lllllllllllllllIllIIIIllIlIllIII);
      if (lllIlIIlIlIII(lllllllllllllllIllIIIIllIlIlIlll.isEmpty())) {
        throw new JsonParseException(lIIlIIlIlIll[lIIlIlllIllI[13]]);
      }
      return lllllllllllllllIllIIIIllIlIlIlll;
    }
    
    private static boolean lllIlIIllIIlI(int ???, int arg1)
    {
      int i;
      String lllllllllllllllIllIIIIlIllIIIIll;
      return ??? != i;
    }
    
    private EnumFacing parseEnumFacing(String lllllllllllllllIllIIIIllIIlllIII)
    {
      ;
      ;
      EnumFacing lllllllllllllllIllIIIIllIIllIlll = EnumFacing.byName(lllllllllllllllIllIIIIllIIlllIII);
      if (lllIlIIlIlIll(lllllllllllllllIllIIIIllIIllIlll)) {
        throw new JsonParseException(String.valueOf(new StringBuilder(lIIlIIlIlIll[lIIlIlllIllI[15]]).append(lllllllllllllllIllIIIIllIIllIllI)));
      }
      return lllllllllllllllIllIIIIllIIllIlll;
    }
    
    private static boolean lllIlIIlIlIII(int ???)
    {
      double lllllllllllllllIllIIIIlIllIIllIl;
      return ??? != 0;
    }
    
    private EnumFacing.Axis parseAxis(JsonObject lllllllllllllllIllIIIIllIllIlIlI)
    {
      ;
      ;
      ;
      String lllllllllllllllIllIIIIllIllIlIII = JsonUtils.getString(lllllllllllllllIllIIIIllIllIlIlI, lIIlIIlIlIll[lIIlIlllIllI[11]]);
      EnumFacing.Axis lllllllllllllllIllIIIIllIllIIllI = EnumFacing.Axis.byName(lllllllllllllllIllIIIIllIllIlIII.toLowerCase());
      if (lllIlIIlIlIll(lllllllllllllllIllIIIIllIllIIllI)) {
        throw new JsonParseException(String.valueOf(new StringBuilder(lIIlIIlIlIll[lIIlIlllIllI[12]]).append(lllllllllllllllIllIIIIllIllIlIII)));
      }
      return lllllllllllllllIllIIIIllIllIIllI;
    }
    
    private static String lllIIIlIlIIII(String lllllllllllllllIllIIIIlIlllIlllI, String lllllllllllllllIllIIIIlIllllIIlI)
    {
      ;
      ;
      ;
      ;
      ;
      ;
      lllllllllllllllIllIIIIlIlllIlllI = new String(Base64.getDecoder().decode(lllllllllllllllIllIIIIlIlllIlllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
      StringBuilder lllllllllllllllIllIIIIlIllllIIIl = new StringBuilder();
      char[] lllllllllllllllIllIIIIlIllllIIII = lllllllllllllllIllIIIIlIllllIIlI.toCharArray();
      int lllllllllllllllIllIIIIlIlllIllll = lIIlIlllIllI[0];
      String lllllllllllllllIllIIIIlIlllIlIIl = lllllllllllllllIllIIIIlIlllIlllI.toCharArray();
      double lllllllllllllllIllIIIIlIlllIlIII = lllllllllllllllIllIIIIlIlllIlIIl.length;
      double lllllllllllllllIllIIIIlIlllIIlll = lIIlIlllIllI[0];
      while (lllIlIIllIlII(lllllllllllllllIllIIIIlIlllIIlll, lllllllllllllllIllIIIIlIlllIlIII))
      {
        char lllllllllllllllIllIIIIlIllllIlII = lllllllllllllllIllIIIIlIlllIlIIl[lllllllllllllllIllIIIIlIlllIIlll];
        "".length();
        "".length();
        if (-"  ".length() > 0) {
          return null;
        }
      }
      return String.valueOf(lllllllllllllllIllIIIIlIllllIIIl);
    }
    
    private static int lllIlIIlIlIlI(float paramFloat1, float paramFloat2)
    {
      return paramFloat1 < paramFloat2;
    }
    
    private static String lllIIIlIlIIIl(String lllllllllllllllIllIIIIllIIIIIIIl, String lllllllllllllllIllIIIIllIIIIIIlI)
    {
      try
      {
        ;
        ;
        ;
        ;
        SecretKeySpec lllllllllllllllIllIIIIllIIIIIllI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllIllIIIIllIIIIIIlI.getBytes(StandardCharsets.UTF_8)), lIIlIlllIllI[8]), "DES");
        Cipher lllllllllllllllIllIIIIllIIIIIlIl = Cipher.getInstance("DES");
        lllllllllllllllIllIIIIllIIIIIlIl.init(lIIlIlllIllI[2], lllllllllllllllIllIIIIllIIIIIllI);
        return new String(lllllllllllllllIllIIIIllIIIIIlIl.doFinal(Base64.getDecoder().decode(lllllllllllllllIllIIIIllIIIIIIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
      }
      catch (Exception lllllllllllllllIllIIIIllIIIIIlII)
      {
        lllllllllllllllIllIIIIllIIIIIlII.printStackTrace();
      }
      return null;
    }
    
    private static void lllIlIIlIIlII()
    {
      lIIlIIlIlIll = new String[lIIlIlllIllI[24]];
      lIIlIIlIlIll[lIIlIlllIllI[0]] = lllIIIlIlIIII("FDA2IxA=", "gXWGu");
      lIIlIIlIlIll[lIIlIlllIllI[1]] = lllIIIlIlIIIl("EcGXwaIieVw=", "pcfst");
      lIIlIIlIlIll[lIIlIlllIllI[2]] = lllIIIlIlIIlI("kU6919fuym27sXpVLQCOn+BWyhZErmn8e/OuMr/uNew=", "aehjn");
      lIIlIIlIlIll[lIIlIlllIllI[3]] = lllIIIlIlIIlI("5FFtj7Ky7x8=", "mojfE");
      lIIlIIlIlIll[lIIlIlllIllI[4]] = lllIIIlIlIIII("ETgjKw0KODk=", "cWWJy");
      lIIlIIlIlIll[lIIlIlllIllI[5]] = lllIIIlIlIIlI("vAdkdciBGa3wsXa4FacA2g==", "wFmhM");
      lIIlIIlIlIll[lIIlIlllIllI[6]] = lllIIIlIlIIII("IyUzACsi", "LWZgB");
      lIIlIIlIlIll[lIIlIlllIllI[7]] = lllIIIlIlIIIl("JpFj5+tw140=", "ClpbM");
      lIIlIIlIlIll[lIIlIlllIllI[8]] = lllIIIlIlIIIl("nJXoyGymV8g=", "lKyUU");
      lIIlIIlIlIll[lIIlIlllIllI[9]] = lllIIIlIlIIII("DCc9DjssLWsdODEoPwY4K2k=", "EIKoW");
      lIIlIIlIlIll[lIIlIlllIllI[10]] = lllIIIlIlIIIl("OpbRdrqHVjBIiTFip8XBLBr+MV0PfjkQx8wv9B0k22foBqpTa0d/PfGPGnXndnjJ", "XdafN");
      lIIlIIlIlIll[lIIlIlllIllI[11]] = lllIIIlIlIIIl("ef4H/r2R0Tg=", "UZVLL");
      lIIlIIlIlIll[lIIlIlllIllI[12]] = lllIIIlIlIIIl("k8IQupvy/5GbuVUwq8E40xIe4jBrsY9G", "ZdeGl");
      lIIlIIlIlIll[lIIlIlllIllI[13]] = lllIIIlIlIIIl("aBgtpP0W+Lkrh+9qn8e6AfjLNSVBnYjAepke+VpgHVhc9eB2SR06uIsto/2+Kv6D", "CGCzm");
      lIIlIIlIlIll[lIIlIlllIllI[14]] = lllIIIlIlIIIl("g6i9n2m3klA=", "KgAMB");
      lIIlIIlIlIll[lIIlIlllIllI[15]] = lllIIIlIlIIIl("4qfCbQUYGUIwA27M52d6yYQjilXx+lrb", "JOHdr");
      lIIlIIlIlIll[lIIlIlllIllI[16]] = lllIIIlIlIIII("Nys=", "CDJZf");
      lIIlIIlIlIll[lIIlIlllIllI[17]] = lllIIIlIlIIlI("guNlBmS8GxV94PMn2vqDFyfm8fypc0Yup6wP+OnTzUzbYL4s285Xk0xea/M86iau", "KRsNN");
      lIIlIIlIlIll[lIIlIlllIllI[18]] = lllIIIlIlIIIl("PjAjtAvooTs=", "TfpOz");
      lIIlIIlIlIll[lIIlIlllIllI[19]] = lllIIIlIlIIIl("shUmVWFqM5OdwtnKeWh5qZJ0kxU4d0QNC1vmJwfMqgsHjP1m14GWYSZJQXTMSYvFBNZ0QuR+eQA=", "MexpF");
      lIIlIIlIlIll[lIIlIlllIllI[20]] = lllIIIlIlIIII("ES4VBiogMwFDenQ=", "TVecI");
      lIIlIIlIlIll[lIIlIlllIllI[21]] = lllIIIlIlIIIl("EyvgHAD6+KG++DN2b/9wXyiPEMz1x7/Y", "GQLrJ");
      lIIlIIlIlIll[lIIlIlllIllI[22]] = lllIIIlIlIIIl("tUjV2FEDvZI=", "SyabR");
      lIIlIIlIlIll[lIIlIlllIllI[23]] = lllIIIlIlIIlI("He6One896lg=", "TQTwF");
    }
    
    private static boolean lllIlIIlIlllI(int ???)
    {
      double lllllllllllllllIllIIIIlIllIIlIIl;
      return ??? >= 0;
    }
    
    private static boolean lllIlIIlIlIll(Object ???)
    {
      float lllllllllllllllIllIIIIlIllIIllll;
      return ??? == null;
    }
    
    private static int lllIlIIlIllII(float paramFloat1, float paramFloat2)
    {
      return paramFloat1 < paramFloat2;
    }
  }
}

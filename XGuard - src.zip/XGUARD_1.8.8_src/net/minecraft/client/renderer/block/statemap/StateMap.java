package net.minecraft.client.renderer.block.statemap;

import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.util.RegistryNamespacedDefaultedByKey;
import net.minecraft.util.ResourceLocation;

public class StateMap
  extends StateMapperBase
{
  protected ModelResourceLocation getModelResourceLocation(IBlockState lllllllllllllllIlIIIIIIIIlIIlIIl)
  {
    ;
    ;
    ;
    ;
    ;
    Map<IProperty, Comparable> lllllllllllllllIlIIIIIIIIlIIlIII = Maps.newLinkedHashMap(lllllllllllllllIlIIIIIIIIlIIlIIl.getProperties());
    String lllllllllllllllIlIIIIIIIIlIIIllI;
    if (lIIIIlIIlIIlIl(name))
    {
      String lllllllllllllllIlIIIIIIIIlIIIlll = ((ResourceLocation)Block.blockRegistry.getNameForObject(lllllllllllllllIlIIIIIIIIlIIlIIl.getBlock())).toString();
      "".length();
      if (-"   ".length() > 0) {
        return null;
      }
    }
    else
    {
      lllllllllllllllIlIIIIIIIIlIIIllI = name.getName((Comparable)lllllllllllllllIlIIIIIIIIlIIlIII.remove(name));
    }
    if (lIIIIlIIlIIllI(suffix)) {
      lllllllllllllllIlIIIIIIIIlIIIllI = String.valueOf(new StringBuilder(String.valueOf(lllllllllllllllIlIIIIIIIIlIIIllI)).append(suffix));
    }
    String lllllllllllllllIlIIIIIIIIIllllll = ignored.iterator();
    "".length();
    if (" ".length() == 0) {
      return null;
    }
    while (!lIIIIlIIlIIlll(lllllllllllllllIlIIIIIIIIIllllll.hasNext()))
    {
      IProperty<?> lllllllllllllllIlIIIIIIIIlIIIlIl = (IProperty)lllllllllllllllIlIIIIIIIIIllllll.next();
      "".length();
    }
    return new ModelResourceLocation(lllllllllllllllIlIIIIIIIIlIIIllI, lllllllllllllllIlIIIIIIIIlIIIlII.getPropertyString(lllllllllllllllIlIIIIIIIIlIIlIII));
  }
  
  private static boolean lIIIIlIIlIIlIl(Object ???)
  {
    boolean lllllllllllllllIlIIIIIIIIIllIIll;
    return ??? == null;
  }
  
  private static boolean lIIIIlIIlIIlll(int ???)
  {
    int lllllllllllllllIlIIIIIIIIIllIIIl;
    return ??? == 0;
  }
  
  private static boolean lIIIIlIIlIIllI(Object ???)
  {
    Exception lllllllllllllllIlIIIIIIIIIllIlIl;
    return ??? != null;
  }
  
  private StateMap(IProperty<?> lllllllllllllllIlIIIIIIIIlIlIIll, String lllllllllllllllIlIIIIIIIIlIlIIlI, List<IProperty<?>> lllllllllllllllIlIIIIIIIIlIlIlIl)
  {
    name = lllllllllllllllIlIIIIIIIIlIlIIll;
    suffix = lllllllllllllllIlIIIIIIIIlIlIIlI;
    ignored = lllllllllllllllIlIIIIIIIIlIlIlIl;
  }
  
  public static class Builder
  {
    public Builder ignore(IProperty<?>... llllllllllllllllIIIIIIIlIIIIIIII)
    {
      ;
      ;
      "".length();
      return llllllllllllllllIIIIIIIlIIIIIIll;
    }
    
    public Builder withSuffix(String llllllllllllllllIIIIIIIlIIIIIllI)
    {
      ;
      ;
      suffix = llllllllllllllllIIIIIIIlIIIIIllI;
      return llllllllllllllllIIIIIIIlIIIIlIIl;
    }
    
    public StateMap build()
    {
      ;
      return new StateMap(name, suffix, ignored, null);
    }
    
    public Builder withName(IProperty<?> llllllllllllllllIIIIIIIlIIIIlllI)
    {
      ;
      ;
      name = llllllllllllllllIIIIIIIlIIIIlllI;
      return llllllllllllllllIIIIIIIlIIIIllll;
    }
    
    public Builder() {}
  }
}

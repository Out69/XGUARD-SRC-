package net.minecraft.client.renderer.block.statemap;

import com.google.common.collect.ImmutableList;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.state.BlockState;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.resources.model.ModelResourceLocation;

public abstract class StateMapperBase
  implements IStateMapper
{
  private static boolean lIllIllIIIll(int ???)
  {
    boolean llllllllllllllllllIlIIlllIlIlIII;
    return ??? != 0;
  }
  
  static
  {
    lIllIllIIIlI();
    lIllIllIIIIl();
  }
  
  private static void lIllIllIIIlI()
  {
    lllIIlIIlI = new int[5];
    lllIIlIIlI[0] = ((0x89 ^ 0x9F ^ 0xBF ^ 0x8C) & (13 + 82 - -44 + 6 ^ 35 + '¦' - 198 + 177 ^ -" ".length()));
    lllIIlIIlI[1] = " ".length();
    lllIIlIIlI[2] = "  ".length();
    lllIIlIIlI[3] = "   ".length();
    lllIIlIIlI[4] = (0xA7 ^ 0xAF);
  }
  
  public Map<IBlockState, ModelResourceLocation> putStateModelLocations(Block llllllllllllllllllIlIIllllIIIllI)
  {
    ;
    ;
    ;
    boolean llllllllllllllllllIlIIllllIIIlII = llllllllllllllllllIlIIllllIIIllI.getBlockState().getValidStates().iterator();
    "".length();
    if (-(0xC1 ^ 0xA4 ^ 0x4E ^ 0x2F) > 0) {
      return null;
    }
    while (!lIllIllIIlII(llllllllllllllllllIlIIllllIIIlII.hasNext()))
    {
      IBlockState llllllllllllllllllIlIIllllIIlIII = (IBlockState)llllllllllllllllllIlIIllllIIIlII.next();
      "".length();
    }
    return mapStateModelLocations;
  }
  
  public String getPropertyString(Map<IProperty, Comparable> llllllllllllllllllIlIIllllIlIlII)
  {
    ;
    ;
    ;
    ;
    ;
    StringBuilder llllllllllllllllllIlIIllllIllIII = new StringBuilder();
    byte llllllllllllllllllIlIIllllIlIIIl = llllllllllllllllllIlIIllllIllIIl.entrySet().iterator();
    "".length();
    if ("  ".length() <= 0) {
      return null;
    }
    while (!lIllIllIIlII(llllllllllllllllllIlIIllllIlIIIl.hasNext()))
    {
      Map.Entry<IProperty, Comparable> llllllllllllllllllIlIIllllIlIlll = (Map.Entry)llllllllllllllllllIlIIllllIlIIIl.next();
      if (lIllIllIIIll(llllllllllllllllllIlIIllllIllIII.length())) {
        "".length();
      }
      IProperty llllllllllllllllllIlIIllllIlIllI = (IProperty)llllllllllllllllllIlIIllllIlIlll.getKey();
      Comparable llllllllllllllllllIlIIllllIlIlIl = (Comparable)llllllllllllllllllIlIIllllIlIlll.getValue();
      "".length();
      "".length();
      "".length();
    }
    if (lIllIllIIlII(llllllllllllllllllIlIIllllIllIII.length())) {
      "".length();
    }
    return String.valueOf(llllllllllllllllllIlIIllllIllIII);
  }
  
  protected abstract ModelResourceLocation getModelResourceLocation(IBlockState paramIBlockState);
  
  private static String lIllIllIIIII(String llllllllllllllllllIlIIlllIlIllll, String llllllllllllllllllIlIIlllIlIllII)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIlIIlllIllIIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlIIlllIlIllII.getBytes(StandardCharsets.UTF_8)), lllIIlIIlI[4]), "DES");
      Cipher llllllllllllllllllIlIIlllIllIIIl = Cipher.getInstance("DES");
      llllllllllllllllllIlIIlllIllIIIl.init(lllIIlIIlI[2], llllllllllllllllllIlIIlllIllIIlI);
      return new String(llllllllllllllllllIlIIlllIllIIIl.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlIIlllIlIllll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIlIIlllIllIIII)
    {
      llllllllllllllllllIlIIlllIllIIII.printStackTrace();
    }
    return null;
  }
  
  public StateMapperBase() {}
  
  private static void lIllIllIIIIl()
  {
    lllIIlIIIl = new String[lllIIlIIlI[3]];
    lllIIlIIIl[lllIIlIIlI[0]] = lIllIlIlllll("2PxAnwf8PHQ=", "JUfJL");
    lllIIlIIIl[lllIIlIIlI[1]] = lIllIllIIIII("lHjeJ/fQhPA=", "SHJjA");
    lllIIlIIIl[lllIIlIIlI[2]] = lIllIlIlllll("JyGPrkEHFeY=", "RPCfR");
  }
  
  private static String lIllIlIlllll(String llllllllllllllllllIlIIlllIllllII, String llllllllllllllllllIlIIlllIlllIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIlIIlllIllllll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIlIIlllIlllIll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIlIIlllIlllllI = Cipher.getInstance("Blowfish");
      llllllllllllllllllIlIIlllIlllllI.init(lllIIlIIlI[2], llllllllllllllllllIlIIlllIllllll);
      return new String(llllllllllllllllllIlIIlllIlllllI.doFinal(Base64.getDecoder().decode(llllllllllllllllllIlIIlllIllllII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIlIIlllIllllIl)
    {
      llllllllllllllllllIlIIlllIllllIl.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIllIllIIlII(int ???)
  {
    float llllllllllllllllllIlIIlllIlIIllI;
    return ??? == 0;
  }
}

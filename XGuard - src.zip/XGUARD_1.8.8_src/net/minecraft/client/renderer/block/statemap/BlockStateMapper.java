package net.minecraft.client.renderer.block.statemap;

import com.google.common.base.Objects;
import com.google.common.collect.Maps;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.util.RegistryNamespacedDefaultedByKey;

public class BlockStateMapper
{
  public void registerBuiltInBlocks(Block... llllllllllllllIllllIlIlIlIIlIlII)
  {
    ;
    ;
    "".length();
  }
  
  public BlockStateMapper() {}
  
  public Map<IBlockState, ModelResourceLocation> putAllStateModelLocations()
  {
    ;
    ;
    ;
    Map<IBlockState, ModelResourceLocation> llllllllllllllIllllIlIlIlIIIlllI = Maps.newIdentityHashMap();
    boolean llllllllllllllIllllIlIlIlIIIlIIl = Block.blockRegistry.iterator();
    "".length();
    if (null != null) {
      return null;
    }
    while (!lIlIlIIlIIlIll(llllllllllllllIllllIlIlIlIIIlIIl.hasNext()))
    {
      Block llllllllllllllIllllIlIlIlIIIllIl = (Block)llllllllllllllIllllIlIlIlIIIlIIl.next();
      if (lIlIlIIlIIlIll(setBuiltInBlocks.contains(llllllllllllllIllllIlIlIlIIIllIl))) {
        llllllllllllllIllllIlIlIlIIIlllI.putAll(((IStateMapper)Objects.firstNonNull((IStateMapper)blockStateMap.get(llllllllllllllIllllIlIlIlIIIllIl), new DefaultStateMapper())).putStateModelLocations(llllllllllllllIllllIlIlIlIIIllIl));
      }
    }
    return llllllllllllllIllllIlIlIlIIIlllI;
  }
  
  private static boolean lIlIlIIlIIlIll(int ???)
  {
    int llllllllllllllIllllIlIlIlIIIIlll;
    return ??? == 0;
  }
  
  public void registerBlockStateMapper(Block llllllllllllllIllllIlIlIlIIllIll, IStateMapper llllllllllllllIllllIlIlIlIIlllIl)
  {
    ;
    ;
    ;
    "".length();
  }
}

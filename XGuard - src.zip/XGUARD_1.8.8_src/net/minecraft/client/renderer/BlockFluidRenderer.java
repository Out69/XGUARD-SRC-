package net.minecraft.client.renderer;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.world.IBlockAccess;
import optfine.CustomColorizer;
import optfine.RenderEnv;

public class BlockFluidRenderer
{
  protected void initAtlasSprites()
  {
    ;
    ;
    TextureMap llllllllllllllllIlllIlIIlllIllII = Minecraft.getMinecraft().getTextureMapBlocks();
    atlasSpritesLava[lIllIllllII[1]] = llllllllllllllllIlllIlIIlllIllII.getAtlasSprite(lIllIllIlll[lIllIllllII[1]]);
    atlasSpritesLava[lIllIllllII[2]] = llllllllllllllllIlllIlIIlllIllII.getAtlasSprite(lIllIllIlll[lIllIllllII[2]]);
    atlasSpritesWater[lIllIllllII[1]] = llllllllllllllllIlllIlIIlllIllII.getAtlasSprite(lIllIllIlll[lIllIllllII[0]]);
    atlasSpritesWater[lIllIllllII[2]] = llllllllllllllllIlllIlIIlllIllII.getAtlasSprite(lIllIllIlll[lIllIllllII[3]]);
  }
  
  private static String lIIIllIIIllll(String llllllllllllllllIlllIIllllIIIlII, String llllllllllllllllIlllIIllllIIIIll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIlllIIllllIIlIIl = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlllIIllllIIIIll.getBytes(StandardCharsets.UTF_8)), lIllIllllII[6]), "DES");
      Cipher llllllllllllllllIlllIIllllIIlIII = Cipher.getInstance("DES");
      llllllllllllllllIlllIIllllIIlIII.init(lIllIllllII[0], llllllllllllllllIlllIIllllIIlIIl);
      return new String(llllllllllllllllIlllIIllllIIlIII.doFinal(Base64.getDecoder().decode(llllllllllllllllIlllIIllllIIIlII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIlllIIllllIIIlll)
    {
      llllllllllllllllIlllIIllllIIIlll.printStackTrace();
    }
    return null;
  }
  
  private static int lIIIllIIlIlIl(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  public boolean renderFluid(IBlockAccess llllllllllllllllIlllIlIIIlIIlIII, IBlockState llllllllllllllllIlllIlIIIlIIIlll, BlockPos llllllllllllllllIlllIlIIIlIIIllI, WorldRenderer llllllllllllllllIlllIlIIIlIIIlIl)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    BlockLiquid llllllllllllllllIlllIlIIlIlIllII = (BlockLiquid)llllllllllllllllIlllIlIIIlIIIlll.getBlock();
    llllllllllllllllIlllIlIIlIlIllII.setBlockBoundsBasedOnState(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI);
    if (lIIIllIIlIlll(llllllllllllllllIlllIlIIlIlIllII.getMaterial(), Material.lava))
    {
      "".length();
      if (null == null) {
        break label110;
      }
      return (111 + '©' - 194 + 93 ^ 83 + 15 - -35 + 13) & (16 + 83 - 40 + 71 ^ '' + '' - 156 + 40 ^ -" ".length());
    }
    label110:
    TextureAtlasSprite[] llllllllllllllllIlllIlIIlIlIlIll = atlasSpritesWater;
    int llllllllllllllllIlllIlIIlIlIlIlI = CustomColorizer.getFluidColor(llllllllllllllllIlllIlIIlIlIllII, llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI);
    float llllllllllllllllIlllIlIIlIlIlIIl = (llllllllllllllllIlllIlIIlIlIlIlI >> lIllIllllII[4] & lIllIllllII[5]) / 255.0F;
    float llllllllllllllllIlllIlIIlIlIlIII = (llllllllllllllllIlllIlIIlIlIlIlI >> lIllIllllII[6] & lIllIllllII[5]) / 255.0F;
    float llllllllllllllllIlllIlIIlIlIIlll = (llllllllllllllllIlllIlIIlIlIlIlI & lIllIllllII[5]) / 255.0F;
    boolean llllllllllllllllIlllIlIIlIlIIllI = llllllllllllllllIlllIlIIlIlIllII.shouldSideBeRendered(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI.up(), EnumFacing.UP);
    boolean llllllllllllllllIlllIlIIlIlIIlIl = llllllllllllllllIlllIlIIlIlIllII.shouldSideBeRendered(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI.down(), EnumFacing.DOWN);
    RenderEnv llllllllllllllllIlllIlIIlIlIIlII = RenderEnv.getInstance(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIlIlIllll, llllllllllllllllIlllIlIIIlIIIllI);
    boolean[] llllllllllllllllIlllIlIIlIlIIIll = llllllllllllllllIlllIlIIlIlIIlII.getBorderFlags();
    llllllllllllllllIlllIlIIlIlIIIll[lIllIllllII[1]] = llllllllllllllllIlllIlIIlIlIllII.shouldSideBeRendered(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI.north(), EnumFacing.NORTH);
    llllllllllllllllIlllIlIIlIlIIIll[lIllIllllII[2]] = llllllllllllllllIlllIlIIlIlIllII.shouldSideBeRendered(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI.south(), EnumFacing.SOUTH);
    llllllllllllllllIlllIlIIlIlIIIll[lIllIllllII[0]] = llllllllllllllllIlllIlIIlIlIllII.shouldSideBeRendered(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI.west(), EnumFacing.WEST);
    llllllllllllllllIlllIlIIlIlIIIll[lIllIllllII[3]] = llllllllllllllllIlllIlIIlIlIllII.shouldSideBeRendered(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI.east(), EnumFacing.EAST);
    if ((lIIIllIIllIII(llllllllllllllllIlllIlIIlIlIIllI)) && (lIIIllIIllIII(llllllllllllllllIlllIlIIlIlIIlIl)) && (lIIIllIIllIII(llllllllllllllllIlllIlIIlIlIIIll[lIllIllllII[1]])) && (lIIIllIIllIII(llllllllllllllllIlllIlIIlIlIIIll[lIllIllllII[2]])) && (lIIIllIIllIII(llllllllllllllllIlllIlIIlIlIIIll[lIllIllllII[0]])) && (lIIIllIIllIII(llllllllllllllllIlllIlIIlIlIIIll[lIllIllllII[3]]))) {
      return lIllIllllII[1];
    }
    boolean llllllllllllllllIlllIlIIlIlIIIlI = lIllIllllII[1];
    float llllllllllllllllIlllIlIIlIlIIIIl = 0.5F;
    float llllllllllllllllIlllIlIIlIlIIIII = 1.0F;
    float llllllllllllllllIlllIlIIlIIlllll = 0.8F;
    float llllllllllllllllIlllIlIIlIIllllI = 0.6F;
    Material llllllllllllllllIlllIlIIlIIlllIl = llllllllllllllllIlllIlIIlIlIllII.getMaterial();
    float llllllllllllllllIlllIlIIlIIlllII = llllllllllllllllIlllIlIIlIllIIIl.getFluidHeight(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI, llllllllllllllllIlllIlIIlIIlllIl);
    float llllllllllllllllIlllIlIIlIIllIll = llllllllllllllllIlllIlIIlIllIIIl.getFluidHeight(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI.south(), llllllllllllllllIlllIlIIlIIlllIl);
    float llllllllllllllllIlllIlIIlIIllIlI = llllllllllllllllIlllIlIIlIllIIIl.getFluidHeight(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI.east().south(), llllllllllllllllIlllIlIIlIIlllIl);
    float llllllllllllllllIlllIlIIlIIllIIl = llllllllllllllllIlllIlIIlIllIIIl.getFluidHeight(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI.east(), llllllllllllllllIlllIlIIlIIlllIl);
    double llllllllllllllllIlllIlIIlIIllIII = llllllllllllllllIlllIlIIIlIIIllI.getX();
    double llllllllllllllllIlllIlIIlIIlIlll = llllllllllllllllIlllIlIIIlIIIllI.getY();
    double llllllllllllllllIlllIlIIlIIlIllI = llllllllllllllllIlllIlIIIlIIIllI.getZ();
    float llllllllllllllllIlllIlIIlIIlIlIl = 0.001F;
    if (lIIIllIIllIIl(llllllllllllllllIlllIlIIlIlIIllI))
    {
      llllllllllllllllIlllIlIIlIlIIIlI = lIllIllllII[2];
      TextureAtlasSprite llllllllllllllllIlllIlIIlIIlIlII = llllllllllllllllIlllIlIIlIlIlIll[lIllIllllII[1]];
      float llllllllllllllllIlllIlIIlIIlIIll = (float)BlockLiquid.getFlowDirection(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI, llllllllllllllllIlllIlIIlIIlllIl);
      if (lIIIllIIllIlI(lIIIllIIlIlIl(llllllllllllllllIlllIlIIlIIlIIll, -999.0F))) {
        llllllllllllllllIlllIlIIlIIlIlII = llllllllllllllllIlllIlIIlIlIlIll[lIllIllllII[2]];
      }
      llllllllllllllllIlllIlIIIlIIIlIl.setSprite(llllllllllllllllIlllIlIIlIIlIlII);
      llllllllllllllllIlllIlIIlIIlllII -= llllllllllllllllIlllIlIIlIIlIlIl;
      llllllllllllllllIlllIlIIlIIllIll -= llllllllllllllllIlllIlIIlIIlIlIl;
      llllllllllllllllIlllIlIIlIIllIlI -= llllllllllllllllIlllIlIIlIIlIlIl;
      llllllllllllllllIlllIlIIlIIllIIl -= llllllllllllllllIlllIlIIlIIlIlIl;
      float llllllllllllllllIlllIlIIlIIlIIIl;
      float llllllllllllllllIlllIlIIlIIIlIIl;
      float llllllllllllllllIlllIlIIlIIIllll;
      float llllllllllllllllIlllIlIIlIIIIlll;
      float llllllllllllllllIlllIlIIlIIIllIl;
      float llllllllllllllllIlllIlIIlIIIIlIl;
      float llllllllllllllllIlllIlIIlIIIlIll;
      float llllllllllllllllIlllIlIIlIIIIIll;
      if (lIIIllIIllIll(lIIIllIIlIllI(llllllllllllllllIlllIlIIlIIlIIll, -999.0F)))
      {
        float llllllllllllllllIlllIlIIlIIlIIlI = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedU(0.0D);
        float llllllllllllllllIlllIlIIlIIIlIlI = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedV(0.0D);
        float llllllllllllllllIlllIlIIlIIlIIII = llllllllllllllllIlllIlIIlIIlIIlI;
        float llllllllllllllllIlllIlIIlIIIlIII = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedV(16.0D);
        float llllllllllllllllIlllIlIIlIIIlllI = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedU(16.0D);
        float llllllllllllllllIlllIlIIlIIIIllI = llllllllllllllllIlllIlIIlIIIlIII;
        float llllllllllllllllIlllIlIIlIIIllII = llllllllllllllllIlllIlIIlIIIlllI;
        float llllllllllllllllIlllIlIIlIIIIlII = llllllllllllllllIlllIlIIlIIIlIlI;
        "".length();
        if (-(0x93 ^ 0x97) > 0) {
          return (0x5E ^ 0x49) & (0xBE ^ 0xA9 ^ 0xFFFFFFFF);
        }
      }
      else
      {
        float llllllllllllllllIlllIlIIlIIIIIlI = MathHelper.sin(llllllllllllllllIlllIlIIlIIlIIll) * 0.25F;
        float llllllllllllllllIlllIlIIlIIIIIIl = MathHelper.cos(llllllllllllllllIlllIlIIlIIlIIll) * 0.25F;
        float llllllllllllllllIlllIlIIlIIIIIII = 8.0F;
        llllllllllllllllIlllIlIIlIIlIIIl = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedU(8.0F + (-llllllllllllllllIlllIlIIlIIIIIIl - llllllllllllllllIlllIlIIlIIIIIlI) * 16.0F);
        llllllllllllllllIlllIlIIlIIIlIIl = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedV(8.0F + (-llllllllllllllllIlllIlIIlIIIIIIl + llllllllllllllllIlllIlIIlIIIIIlI) * 16.0F);
        llllllllllllllllIlllIlIIlIIIllll = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedU(8.0F + (-llllllllllllllllIlllIlIIlIIIIIIl + llllllllllllllllIlllIlIIlIIIIIlI) * 16.0F);
        llllllllllllllllIlllIlIIlIIIIlll = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedV(8.0F + (llllllllllllllllIlllIlIIlIIIIIIl + llllllllllllllllIlllIlIIlIIIIIlI) * 16.0F);
        llllllllllllllllIlllIlIIlIIIllIl = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedU(8.0F + (llllllllllllllllIlllIlIIlIIIIIIl + llllllllllllllllIlllIlIIlIIIIIlI) * 16.0F);
        llllllllllllllllIlllIlIIlIIIIlIl = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedV(8.0F + (llllllllllllllllIlllIlIIlIIIIIIl - llllllllllllllllIlllIlIIlIIIIIlI) * 16.0F);
        llllllllllllllllIlllIlIIlIIIlIll = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedU(8.0F + (llllllllllllllllIlllIlIIlIIIIIIl - llllllllllllllllIlllIlIIlIIIIIlI) * 16.0F);
        llllllllllllllllIlllIlIIlIIIIIll = llllllllllllllllIlllIlIIlIIlIlII.getInterpolatedV(8.0F + (-llllllllllllllllIlllIlIIlIIIIIIl - llllllllllllllllIlllIlIIlIIIIIlI) * 16.0F);
      }
      int llllllllllllllllIlllIlIIIlllllll = llllllllllllllllIlllIlIIlIlIllII.getMixedBrightnessForBlock(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI);
      int llllllllllllllllIlllIlIIIllllllI = llllllllllllllllIlllIlIIIlllllll >> lIllIllllII[4] & lIllIllllII[7];
      int llllllllllllllllIlllIlIIIlllllIl = llllllllllllllllIlllIlIIIlllllll & lIllIllllII[7];
      float llllllllllllllllIlllIlIIIlllllII = llllllllllllllllIlllIlIIlIlIIIII * llllllllllllllllIlllIlIIlIlIlIIl;
      float llllllllllllllllIlllIlIIIllllIll = llllllllllllllllIlllIlIIlIlIIIII * llllllllllllllllIlllIlIIlIlIlIII;
      float llllllllllllllllIlllIlIIIllllIlI = llllllllllllllllIlllIlIIlIlIIIII * llllllllllllllllIlllIlIIlIlIIlll;
      llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII + 0.0D, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIlIIlllII, llllllllllllllllIlllIlIIlIIlIllI + 0.0D).color(llllllllllllllllIlllIlIIIlllllII, llllllllllllllllIlllIlIIIllllIll, llllllllllllllllIlllIlIIIllllIlI, 1.0F).tex(llllllllllllllllIlllIlIIlIIlIIIl, llllllllllllllllIlllIlIIlIIIlIIl).lightmap(llllllllllllllllIlllIlIIIllllllI, llllllllllllllllIlllIlIIIlllllIl).endVertex();
      llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII + 0.0D, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIlIIllIll, llllllllllllllllIlllIlIIlIIlIllI + 1.0D).color(llllllllllllllllIlllIlIIIlllllII, llllllllllllllllIlllIlIIIllllIll, llllllllllllllllIlllIlIIIllllIlI, 1.0F).tex(llllllllllllllllIlllIlIIlIIIllll, llllllllllllllllIlllIlIIlIIIIlll).lightmap(llllllllllllllllIlllIlIIIllllllI, llllllllllllllllIlllIlIIIlllllIl).endVertex();
      llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII + 1.0D, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIlIIllIlI, llllllllllllllllIlllIlIIlIIlIllI + 1.0D).color(llllllllllllllllIlllIlIIIlllllII, llllllllllllllllIlllIlIIIllllIll, llllllllllllllllIlllIlIIIllllIlI, 1.0F).tex(llllllllllllllllIlllIlIIlIIIllIl, llllllllllllllllIlllIlIIlIIIIlIl).lightmap(llllllllllllllllIlllIlIIIllllllI, llllllllllllllllIlllIlIIIlllllIl).endVertex();
      llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII + 1.0D, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIlIIllIIl, llllllllllllllllIlllIlIIlIIlIllI + 0.0D).color(llllllllllllllllIlllIlIIIlllllII, llllllllllllllllIlllIlIIIllllIll, llllllllllllllllIlllIlIIIllllIlI, 1.0F).tex(llllllllllllllllIlllIlIIlIIIlIll, llllllllllllllllIlllIlIIlIIIIIll).lightmap(llllllllllllllllIlllIlIIIllllllI, llllllllllllllllIlllIlIIIlllllIl).endVertex();
      if (lIIIllIIllIIl(llllllllllllllllIlllIlIIlIlIllII.func_176364_g(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI.up())))
      {
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII + 0.0D, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIlIIlllII, llllllllllllllllIlllIlIIlIIlIllI + 0.0D).color(llllllllllllllllIlllIlIIIlllllII, llllllllllllllllIlllIlIIIllllIll, llllllllllllllllIlllIlIIIllllIlI, 1.0F).tex(llllllllllllllllIlllIlIIlIIlIIIl, llllllllllllllllIlllIlIIlIIIlIIl).lightmap(llllllllllllllllIlllIlIIIllllllI, llllllllllllllllIlllIlIIIlllllIl).endVertex();
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII + 1.0D, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIlIIllIIl, llllllllllllllllIlllIlIIlIIlIllI + 0.0D).color(llllllllllllllllIlllIlIIIlllllII, llllllllllllllllIlllIlIIIllllIll, llllllllllllllllIlllIlIIIllllIlI, 1.0F).tex(llllllllllllllllIlllIlIIlIIIlIll, llllllllllllllllIlllIlIIlIIIIIll).lightmap(llllllllllllllllIlllIlIIIllllllI, llllllllllllllllIlllIlIIIlllllIl).endVertex();
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII + 1.0D, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIlIIllIlI, llllllllllllllllIlllIlIIlIIlIllI + 1.0D).color(llllllllllllllllIlllIlIIIlllllII, llllllllllllllllIlllIlIIIllllIll, llllllllllllllllIlllIlIIIllllIlI, 1.0F).tex(llllllllllllllllIlllIlIIlIIIllIl, llllllllllllllllIlllIlIIlIIIIlIl).lightmap(llllllllllllllllIlllIlIIIllllllI, llllllllllllllllIlllIlIIIlllllIl).endVertex();
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII + 0.0D, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIlIIllIll, llllllllllllllllIlllIlIIlIIlIllI + 1.0D).color(llllllllllllllllIlllIlIIIlllllII, llllllllllllllllIlllIlIIIllllIll, llllllllllllllllIlllIlIIIllllIlI, 1.0F).tex(llllllllllllllllIlllIlIIlIIIllll, llllllllllllllllIlllIlIIlIIIIlll).lightmap(llllllllllllllllIlllIlIIIllllllI, llllllllllllllllIlllIlIIIlllllIl).endVertex();
      }
    }
    if (lIIIllIIllIIl(llllllllllllllllIlllIlIIlIlIIlIl))
    {
      float llllllllllllllllIlllIlIIIllllIIl = llllllllllllllllIlllIlIIlIlIlIll[lIllIllllII[1]].getMinU();
      float llllllllllllllllIlllIlIIIllllIII = llllllllllllllllIlllIlIIlIlIlIll[lIllIllllII[1]].getMaxU();
      float llllllllllllllllIlllIlIIIlllIlll = llllllllllllllllIlllIlIIlIlIlIll[lIllIllllII[1]].getMinV();
      float llllllllllllllllIlllIlIIIlllIllI = llllllllllllllllIlllIlIIlIlIlIll[lIllIllllII[1]].getMaxV();
      int llllllllllllllllIlllIlIIIlllIlIl = llllllllllllllllIlllIlIIlIlIllII.getMixedBrightnessForBlock(llllllllllllllllIlllIlIIIlIIlIII, llllllllllllllllIlllIlIIIlIIIllI.down());
      int llllllllllllllllIlllIlIIIlllIlII = llllllllllllllllIlllIlIIIlllIlIl >> lIllIllllII[4] & lIllIllllII[7];
      int llllllllllllllllIlllIlIIIlllIIll = llllllllllllllllIlllIlIIIlllIlIl & lIllIllllII[7];
      llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII, llllllllllllllllIlllIlIIlIIlIlll, llllllllllllllllIlllIlIIlIIlIllI + 1.0D).color(llllllllllllllllIlllIlIIlIlIIIIl, llllllllllllllllIlllIlIIlIlIIIIl, llllllllllllllllIlllIlIIlIlIIIIl, 1.0F).tex(llllllllllllllllIlllIlIIIllllIIl, llllllllllllllllIlllIlIIIlllIllI).lightmap(llllllllllllllllIlllIlIIIlllIlII, llllllllllllllllIlllIlIIIlllIIll).endVertex();
      llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII, llllllllllllllllIlllIlIIlIIlIlll, llllllllllllllllIlllIlIIlIIlIllI).color(llllllllllllllllIlllIlIIlIlIIIIl, llllllllllllllllIlllIlIIlIlIIIIl, llllllllllllllllIlllIlIIlIlIIIIl, 1.0F).tex(llllllllllllllllIlllIlIIIllllIIl, llllllllllllllllIlllIlIIIlllIlll).lightmap(llllllllllllllllIlllIlIIIlllIlII, llllllllllllllllIlllIlIIIlllIIll).endVertex();
      llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII + 1.0D, llllllllllllllllIlllIlIIlIIlIlll, llllllllllllllllIlllIlIIlIIlIllI).color(llllllllllllllllIlllIlIIlIlIIIIl, llllllllllllllllIlllIlIIlIlIIIIl, llllllllllllllllIlllIlIIlIlIIIIl, 1.0F).tex(llllllllllllllllIlllIlIIIllllIII, llllllllllllllllIlllIlIIIlllIlll).lightmap(llllllllllllllllIlllIlIIIlllIlII, llllllllllllllllIlllIlIIIlllIIll).endVertex();
      llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIlIIllIII + 1.0D, llllllllllllllllIlllIlIIlIIlIlll, llllllllllllllllIlllIlIIlIIlIllI + 1.0D).color(llllllllllllllllIlllIlIIlIlIIIIl, llllllllllllllllIlllIlIIlIlIIIIl, llllllllllllllllIlllIlIIlIlIIIIl, 1.0F).tex(llllllllllllllllIlllIlIIIllllIII, llllllllllllllllIlllIlIIIlllIllI).lightmap(llllllllllllllllIlllIlIIIlllIlII, llllllllllllllllIlllIlIIIlllIIll).endVertex();
      llllllllllllllllIlllIlIIlIlIIIlI = lIllIllllII[2];
    }
    int llllllllllllllllIlllIlIIIlllIIlI = lIllIllllII[1];
    "".length();
    if ("  ".length() >= "   ".length()) {
      return (0x25 ^ 0x3C) & (0x82 ^ 0x9B ^ 0xFFFFFFFF);
    }
    label2265:
    while (!lIIIllIIllllI(llllllllllllllllIlllIlIIIlllIIlI, lIllIllllII[8]))
    {
      int llllllllllllllllIlllIlIIIlllIIIl = lIllIllllII[1];
      int llllllllllllllllIlllIlIIIlllIIII = lIllIllllII[1];
      if ((!lIIIllIIllIII(llllllllllllllllIlllIlIIIlllIIlI)) || ((!lIIIllIIlllII(llllllllllllllllIlllIlIIIlllIIlI, lIllIllllII[2])) || ((!lIIIllIIlllII(llllllllllllllllIlllIlIIIlllIIlI, lIllIllllII[0])) || (lIIIllIIlllII(llllllllllllllllIlllIlIIIlllIIlI, lIllIllllII[3]))))) {}
      BlockPos llllllllllllllllIlllIlIIIllIllll = llllllllllllllllIlllIlIIIlIIIllI.add(llllllllllllllllIlllIlIIIlllIIIl, lIllIllllII[1], llllllllllllllllIlllIlIIIlllIIII);
      TextureAtlasSprite llllllllllllllllIlllIlIIIllIlllI = llllllllllllllllIlllIlIIlIlIlIll[lIllIllllII[2]];
      llllllllllllllllIlllIlIIIlIIIlIl.setSprite(llllllllllllllllIlllIlIIIllIlllI);
      if (lIIIllIIllIIl(llllllllllllllllIlllIlIIlIlIIIll[llllllllllllllllIlllIlIIIlllIIlI]))
      {
        llllllllllllllllIlllIlIIIlllIIIl++;
        if (lIIIllIIllIII(llllllllllllllllIlllIlIIIlllIIlI))
        {
          float llllllllllllllllIlllIlIIIllIIlIl = llllllllllllllllIlllIlIIlIIlllII;
          float llllllllllllllllIlllIlIIIllIIIIl = llllllllllllllllIlllIlIIlIIllIIl;
          double llllllllllllllllIlllIlIIIlIlllIl = llllllllllllllllIlllIlIIlIIllIII;
          double llllllllllllllllIlllIlIIIllIllIl = llllllllllllllllIlllIlIIlIIllIII + 1.0D;
          double llllllllllllllllIlllIlIIIlIllIIl = llllllllllllllllIlllIlIIlIIlIllI + llllllllllllllllIlllIlIIlIIlIlIl;
          double llllllllllllllllIlllIlIIIllIlIIl = llllllllllllllllIlllIlIIlIIlIllI + llllllllllllllllIlllIlIIlIIlIlIl;
          "".length();
          if (((0x68 ^ 0x7A) & (0x9A ^ 0x88 ^ 0xFFFFFFFF)) <= -" ".length()) {
            return (0x88 ^ 0x8D) & (0x61 ^ 0x64 ^ 0xFFFFFFFF);
          }
        }
        else if (lIIIllIIlllII(llllllllllllllllIlllIlIIIlllIIlI, lIllIllllII[2]))
        {
          float llllllllllllllllIlllIlIIIllIIlII = llllllllllllllllIlllIlIIlIIllIlI;
          float llllllllllllllllIlllIlIIIllIIIII = llllllllllllllllIlllIlIIlIIllIll;
          double llllllllllllllllIlllIlIIIlIlllII = llllllllllllllllIlllIlIIlIIllIII + 1.0D;
          double llllllllllllllllIlllIlIIIllIllII = llllllllllllllllIlllIlIIlIIllIII;
          double llllllllllllllllIlllIlIIIlIllIII = llllllllllllllllIlllIlIIlIIlIllI + 1.0D - llllllllllllllllIlllIlIIlIIlIlIl;
          double llllllllllllllllIlllIlIIIllIlIII = llllllllllllllllIlllIlIIlIIlIllI + 1.0D - llllllllllllllllIlllIlIIlIIlIlIl;
          "".length();
          if (null != null) {
            return (" ".length() ^ 0x4B ^ 0x72) & (0x8 ^ 0x60 ^ 0x66 ^ 0x36 ^ -" ".length());
          }
        }
        else if (lIIIllIIlllII(llllllllllllllllIlllIlIIIlllIIlI, lIllIllllII[0]))
        {
          float llllllllllllllllIlllIlIIIllIIIll = llllllllllllllllIlllIlIIlIIllIll;
          float llllllllllllllllIlllIlIIIlIlllll = llllllllllllllllIlllIlIIlIIlllII;
          double llllllllllllllllIlllIlIIIlIllIll = llllllllllllllllIlllIlIIlIIllIII + llllllllllllllllIlllIlIIlIIlIlIl;
          double llllllllllllllllIlllIlIIIllIlIll = llllllllllllllllIlllIlIIlIIllIII + llllllllllllllllIlllIlIIlIIlIlIl;
          double llllllllllllllllIlllIlIIIlIlIlll = llllllllllllllllIlllIlIIlIIlIllI + 1.0D;
          double llllllllllllllllIlllIlIIIllIIlll = llllllllllllllllIlllIlIIlIIlIllI;
          "".length();
          if ((0x59 ^ 0x47 ^ 0x6 ^ 0x1D) == 0) {
            return (72 + 56 - -13 + 33 ^ 9 + '' - 92 + 86) & ("   ".length() ^ 0x65 ^ 0x55 ^ -" ".length());
          }
        }
        else
        {
          llllllllllllllllIlllIlIIIllIIIlI = llllllllllllllllIlllIlIIlIIllIIl;
          llllllllllllllllIlllIlIIIlIllllI = llllllllllllllllIlllIlIIlIIllIlI;
          llllllllllllllllIlllIlIIIlIllIlI = llllllllllllllllIlllIlIIlIIllIII + 1.0D - llllllllllllllllIlllIlIIlIIlIlIl;
          llllllllllllllllIlllIlIIIllIlIlI = llllllllllllllllIlllIlIIlIIllIII + 1.0D - llllllllllllllllIlllIlIIlIIlIlIl;
          llllllllllllllllIlllIlIIIlIlIllI = llllllllllllllllIlllIlIIlIIlIllI;
          llllllllllllllllIlllIlIIIllIIllI = llllllllllllllllIlllIlIIlIIlIllI + 1.0D;
        }
        llllllllllllllllIlllIlIIlIlIIIlI = ;;;;;;;;;;;;
        float llllllllllllllllIlllIlIIIllIIIlI;
        float llllllllllllllllIlllIlIIIlIllllI;
        double llllllllllllllllIlllIlIIIlIllIlI;
        double llllllllllllllllIlllIlIIIllIlIlI;
        double llllllllllllllllIlllIlIIIlIlIllI;
        double llllllllllllllllIlllIlIIIllIIllI;
        if (lIIIllIIlllIl(llllllllllllllllIlllIlIIIlllIIlI, lIllIllllII[0]))
        {
          "".length();
          if ("   ".length() > 0) {
            break label2265;
          }
          return (0xC9 ^ 0xC7) & (0xAF ^ 0xA1 ^ 0xFFFFFFFF);
        }
        float llllllllllllllllIlllIlIIIlIIllIl = llllllllllllllllIlllIlIIlIIllllI;
        float llllllllllllllllIlllIlIIIlIIllII = llllllllllllllllIlllIlIIlIlIIIII * llllllllllllllllIlllIlIIIlIIllIl * llllllllllllllllIlllIlIIlIlIlIIl;
        float llllllllllllllllIlllIlIIIlIIlIll = llllllllllllllllIlllIlIIlIlIIIII * llllllllllllllllIlllIlIIIlIIllIl * llllllllllllllllIlllIlIIlIlIlIII;
        float llllllllllllllllIlllIlIIIlIIlIlI = llllllllllllllllIlllIlIIlIlIIIII * llllllllllllllllIlllIlIIIlIIllIl * llllllllllllllllIlllIlIIlIlIIlll;
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIIlIllIlI, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIIllIIIlI, llllllllllllllllIlllIlIIIlIlIllI).color(llllllllllllllllIlllIlIIIlIIllII, llllllllllllllllIlllIlIIIlIIlIll, llllllllllllllllIlllIlIIIlIIlIlI, 1.0F).tex(llllllllllllllllIlllIlIIIlIlIlIl, llllllllllllllllIlllIlIIIlIlIIll).lightmap(llllllllllllllllIlllIlIIIlIIllll, llllllllllllllllIlllIlIIIlIIlllI).endVertex();
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIIllIlIlI, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIIlIllllI, llllllllllllllllIlllIlIIIllIIllI).color(llllllllllllllllIlllIlIIIlIIllII, llllllllllllllllIlllIlIIIlIIlIll, llllllllllllllllIlllIlIIIlIIlIlI, 1.0F).tex(llllllllllllllllIlllIlIIIlIlIlII, llllllllllllllllIlllIlIIIlIlIIlI).lightmap(llllllllllllllllIlllIlIIIlIIllll, llllllllllllllllIlllIlIIIlIIlllI).endVertex();
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIIllIlIlI, llllllllllllllllIlllIlIIlIIlIlll + 0.0D, llllllllllllllllIlllIlIIIllIIllI).color(llllllllllllllllIlllIlIIIlIIllII, llllllllllllllllIlllIlIIIlIIlIll, llllllllllllllllIlllIlIIIlIIlIlI, 1.0F).tex(llllllllllllllllIlllIlIIIlIlIlII, llllllllllllllllIlllIlIIIlIlIIIl).lightmap(llllllllllllllllIlllIlIIIlIIllll, llllllllllllllllIlllIlIIIlIIlllI).endVertex();
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIIlIllIlI, llllllllllllllllIlllIlIIlIIlIlll + 0.0D, llllllllllllllllIlllIlIIIlIlIllI).color(llllllllllllllllIlllIlIIIlIIllII, llllllllllllllllIlllIlIIIlIIlIll, llllllllllllllllIlllIlIIIlIIlIlI, 1.0F).tex(llllllllllllllllIlllIlIIIlIlIlIl, llllllllllllllllIlllIlIIIlIlIIIl).lightmap(llllllllllllllllIlllIlIIIlIIllll, llllllllllllllllIlllIlIIIlIIlllI).endVertex();
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIIlIllIlI, llllllllllllllllIlllIlIIlIIlIlll + 0.0D, llllllllllllllllIlllIlIIIlIlIllI).color(llllllllllllllllIlllIlIIIlIIllII, llllllllllllllllIlllIlIIIlIIlIll, llllllllllllllllIlllIlIIIlIIlIlI, 1.0F).tex(llllllllllllllllIlllIlIIIlIlIlIl, llllllllllllllllIlllIlIIIlIlIIIl).lightmap(llllllllllllllllIlllIlIIIlIIllll, llllllllllllllllIlllIlIIIlIIlllI).endVertex();
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIIllIlIlI, llllllllllllllllIlllIlIIlIIlIlll + 0.0D, llllllllllllllllIlllIlIIIllIIllI).color(llllllllllllllllIlllIlIIIlIIllII, llllllllllllllllIlllIlIIIlIIlIll, llllllllllllllllIlllIlIIIlIIlIlI, 1.0F).tex(llllllllllllllllIlllIlIIIlIlIlII, llllllllllllllllIlllIlIIIlIlIIIl).lightmap(llllllllllllllllIlllIlIIIlIIllll, llllllllllllllllIlllIlIIIlIIlllI).endVertex();
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIIllIlIlI, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIIlIllllI, llllllllllllllllIlllIlIIIllIIllI).color(llllllllllllllllIlllIlIIIlIIllII, llllllllllllllllIlllIlIIIlIIlIll, llllllllllllllllIlllIlIIIlIIlIlI, 1.0F).tex(llllllllllllllllIlllIlIIIlIlIlII, llllllllllllllllIlllIlIIIlIlIIlI).lightmap(llllllllllllllllIlllIlIIIlIIllll, llllllllllllllllIlllIlIIIlIIlllI).endVertex();
        llllllllllllllllIlllIlIIIlIIIlIl.pos(llllllllllllllllIlllIlIIIlIllIlI, llllllllllllllllIlllIlIIlIIlIlll + llllllllllllllllIlllIlIIIllIIIlI, llllllllllllllllIlllIlIIIlIlIllI).color(llllllllllllllllIlllIlIIIlIIllII, llllllllllllllllIlllIlIIIlIIlIll, llllllllllllllllIlllIlIIIlIIlIlI, 1.0F).tex(llllllllllllllllIlllIlIIIlIlIlIl, llllllllllllllllIlllIlIIIlIlIIll).lightmap(llllllllllllllllIlllIlIIIlIIllll, llllllllllllllllIlllIlIIIlIIlllI).endVertex();
      }
      llllllllllllllllIlllIlIIIlllIIlI++;
    }
    llllllllllllllllIlllIlIIIlIIIlIl.setSprite(null);
    return llllllllllllllllIlllIlIIlIlIIIlI;
  }
  
  private static String lIIIllIIIlllI(String llllllllllllllllIlllIIllllIlIllI, String llllllllllllllllIlllIIllllIllIlI)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllIlllIIllllIlIllI = new String(Base64.getDecoder().decode(llllllllllllllllIlllIIllllIlIllI.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllIlllIIllllIllIIl = new StringBuilder();
    char[] llllllllllllllllIlllIIllllIllIII = llllllllllllllllIlllIIllllIllIlI.toCharArray();
    int llllllllllllllllIlllIIllllIlIlll = lIllIllllII[1];
    String llllllllllllllllIlllIIllllIlIIIl = llllllllllllllllIlllIIllllIlIllI.toCharArray();
    float llllllllllllllllIlllIIllllIlIIII = llllllllllllllllIlllIIllllIlIIIl.length;
    String llllllllllllllllIlllIIllllIIllll = lIllIllllII[1];
    while (lIIIllIIlllIl(llllllllllllllllIlllIIllllIIllll, llllllllllllllllIlllIIllllIlIIII))
    {
      char llllllllllllllllIlllIIllllIlllII = llllllllllllllllIlllIIllllIlIIIl[llllllllllllllllIlllIIllllIIllll];
      "".length();
      "".length();
      if (((0x49 ^ 0x69) & (0x98 ^ 0xB8 ^ 0xFFFFFFFF)) > ((0x7C ^ 0x48) & (0x84 ^ 0xB0 ^ 0xFFFFFFFF))) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllIlllIIllllIllIIl);
  }
  
  private static boolean lIIIllIIlllIl(int ???, int arg1)
  {
    int i;
    short llllllllllllllllIlllIIlllIllIlIl;
    return ??? < i;
  }
  
  private float getFluidHeight(IBlockAccess llllllllllllllllIlllIIllllllllII, BlockPos llllllllllllllllIlllIIlllllllIll, Material llllllllllllllllIlllIlIIIIIIIlII)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    ;
    int llllllllllllllllIlllIlIIIIIIIIll = lIllIllllII[1];
    float llllllllllllllllIlllIlIIIIIIIIlI = 0.0F;
    int llllllllllllllllIlllIlIIIIIIIIIl = lIllIllllII[1];
    "".length();
    if (null != null) {
      return 0.0F;
    }
    while (!lIIIllIIllllI(llllllllllllllllIlllIlIIIIIIIIIl, lIllIllllII[8]))
    {
      BlockPos llllllllllllllllIlllIlIIIIIIIIII = llllllllllllllllIlllIlIIIIIIIlIl.add(-(llllllllllllllllIlllIlIIIIIIIIIl & lIllIllllII[2]), lIllIllllII[1], -(llllllllllllllllIlllIlIIIIIIIIIl >> lIllIllllII[2] & lIllIllllII[2]));
      if (lIIIllIIlIlll(llllllllllllllllIlllIIllllllllII.getBlockState(llllllllllllllllIlllIlIIIIIIIIII.up()).getBlock().getMaterial(), llllllllllllllllIlllIlIIIIIIIlII)) {
        return 1.0F;
      }
      IBlockState llllllllllllllllIlllIIllllllllll = llllllllllllllllIlllIIllllllllII.getBlockState(llllllllllllllllIlllIlIIIIIIIIII);
      Material llllllllllllllllIlllIIlllllllllI = llllllllllllllllIlllIIllllllllll.getBlock().getMaterial();
      if (lIIIllIIlllll(llllllllllllllllIlllIIlllllllllI, llllllllllllllllIlllIlIIIIIIIlII))
      {
        if (lIIIllIIllIII(llllllllllllllllIlllIIlllllllllI.isSolid()))
        {
          llllllllllllllllIlllIlIIIIIIIIlI += 1.0F;
          llllllllllllllllIlllIlIIIIIIIIll++;
          "".length();
          if (((0xF7 ^ 0x97 ^ 0xD6 ^ 0xAC) & (0x29 ^ 0xD ^ 0x81 ^ 0xBF ^ -" ".length())) != 0) {
            return 0.0F;
          }
        }
      }
      else
      {
        int llllllllllllllllIlllIIllllllllIl = ((Integer)llllllllllllllllIlllIIllllllllll.getValue(BlockLiquid.LEVEL)).intValue();
        if ((!lIIIllIIlllIl(llllllllllllllllIlllIIllllllllIl, lIllIllllII[6])) || (lIIIllIIllIII(llllllllllllllllIlllIIllllllllIl)))
        {
          llllllllllllllllIlllIlIIIIIIIIlI += BlockLiquid.getLiquidHeightPercent(llllllllllllllllIlllIIllllllllIl) * 10.0F;
          llllllllllllllllIlllIlIIIIIIIIll += 10;
        }
        llllllllllllllllIlllIlIIIIIIIIlI += BlockLiquid.getLiquidHeightPercent(llllllllllllllllIlllIIllllllllIl);
        llllllllllllllllIlllIlIIIIIIIIll++;
      }
      llllllllllllllllIlllIlIIIIIIIIIl++;
    }
    return 1.0F - llllllllllllllllIlllIlIIIIIIIIlI / llllllllllllllllIlllIlIIIIIIIIll;
  }
  
  private static boolean lIIIllIIlllII(int ???, int arg1)
  {
    int i;
    short llllllllllllllllIlllIIlllIllllIl;
    return ??? == i;
  }
  
  private static boolean lIIIllIIllllI(int ???, int arg1)
  {
    int i;
    short llllllllllllllllIlllIIlllIlllIIl;
    return ??? >= i;
  }
  
  private static boolean lIIIllIIllIll(int ???)
  {
    String llllllllllllllllIlllIIlllIlIIlll;
    return ??? < 0;
  }
  
  private static boolean lIIIllIIlllll(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllllIlllIIlllIllIIIl;
    return ??? != localObject;
  }
  
  private static void lIIIllIIlIlII()
  {
    lIllIllllII = new int[10];
    lIllIllllII[0] = "  ".length();
    lIllIllllII[1] = ((0x5E ^ 0x3C) & (0xDD ^ 0xBF ^ 0xFFFFFFFF));
    lIllIllllII[2] = " ".length();
    lIllIllllII[3] = "   ".length();
    lIllIllllII[4] = (0xA9 ^ 0xB9);
    lIllIllllII[5] = (31 + 72 - -113 + 39);
    lIllIllllII[6] = (0x13 ^ 0x1B);
    lIllIllllII[7] = (-" ".length() & 0xFFFFFFFF & 0xFFFF);
    lIllIllllII[8] = (0x24 ^ 0x7 ^ 0x2C ^ 0xB);
    lIllIllllII[9] = (0x35 ^ 0x30);
  }
  
  public BlockFluidRenderer()
  {
    llllllllllllllllIlllIlIIllllIIIl.initAtlasSprites();
  }
  
  private static boolean lIIIllIIllIlI(int ???)
  {
    int llllllllllllllllIlllIIlllIlIIlIl;
    return ??? > 0;
  }
  
  private static void lIIIllIIlIIII()
  {
    lIllIllIlll = new String[lIllIllllII[9]];
    lIllIllIlll[lIllIllllII[1]] = lIIIllIIIlIlI("Cz41fVcfU5mS4WX1UncqND8UqcEzI+9N14LgReraVJU=", "omXXH");
    lIllIllIlll[lIllIllllII[2]] = lIIIllIIIlllI("DgM/FxARCzcGSQEGPhEYEEU9EwUCNTceHBQ=", "cjQrs");
    lIllIllIlll[lIllIllllII[0]] = lIIIllIIIlllI("HwYPAw4ADgcSVxADDgUGAUAWBxkXHT4VGRsDDQ==", "roafm");
    lIllIllIlll[lIllIllllII[3]] = lIIIllIIIllll("BM0BSW1JkIkyWhsgGegXpxFpqhEC217J7xvd70w8oJc=", "jAbTL");
    lIllIllIlll[lIllIllllII[8]] = lIIIllIIIlllI("ACEyYlJzXV9nU3o=", "CmmRb");
  }
  
  private static boolean lIIIllIIllIIl(int ???)
  {
    double llllllllllllllllIlllIIlllIlIlIll;
    return ??? != 0;
  }
  
  static
  {
    lIIIllIIlIlII();
    lIIIllIIlIIII();
  }
  
  private static boolean lIIIllIIllIII(int ???)
  {
    char llllllllllllllllIlllIIlllIlIlIIl;
    return ??? == 0;
  }
  
  private static int lIIIllIIlIllI(float paramFloat1, float paramFloat2)
  {
    return paramFloat1 < paramFloat2;
  }
  
  private static String lIIIllIIIlIlI(String llllllllllllllllIlllIIlllllIlIIl, String llllllllllllllllIlllIIlllllIlIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllIlllIIlllllIlllI = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllIlllIIlllllIlIlI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllIlllIIlllllIllIl = Cipher.getInstance("Blowfish");
      llllllllllllllllIlllIIlllllIllIl.init(lIllIllllII[0], llllllllllllllllIlllIIlllllIlllI);
      return new String(llllllllllllllllIlllIIlllllIllIl.doFinal(Base64.getDecoder().decode(llllllllllllllllIlllIIlllllIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllIlllIIlllllIllII)
    {
      llllllllllllllllIlllIIlllllIllII.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIIIllIIlIlll(Object ???, Object arg1)
  {
    Object localObject;
    String llllllllllllllllIlllIIlllIlIllIl;
    return ??? == localObject;
  }
}

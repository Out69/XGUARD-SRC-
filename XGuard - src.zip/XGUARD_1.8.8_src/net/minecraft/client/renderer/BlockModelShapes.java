package net.minecraft.client.renderer;

import com.google.common.collect.Maps;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockBed;
import net.minecraft.block.BlockCactus;
import net.minecraft.block.BlockColored;
import net.minecraft.block.BlockCommandBlock;
import net.minecraft.block.BlockDirt;
import net.minecraft.block.BlockDirt.DirtType;
import net.minecraft.block.BlockDispenser;
import net.minecraft.block.BlockDoor;
import net.minecraft.block.BlockDoublePlant;
import net.minecraft.block.BlockDropper;
import net.minecraft.block.BlockFenceGate;
import net.minecraft.block.BlockFire;
import net.minecraft.block.BlockFlower;
import net.minecraft.block.BlockFlowerPot;
import net.minecraft.block.BlockHopper;
import net.minecraft.block.BlockJukebox;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockNewLeaf;
import net.minecraft.block.BlockNewLog;
import net.minecraft.block.BlockOldLeaf;
import net.minecraft.block.BlockOldLog;
import net.minecraft.block.BlockPlanks;
import net.minecraft.block.BlockPrismarine;
import net.minecraft.block.BlockQuartz;
import net.minecraft.block.BlockQuartz.EnumType;
import net.minecraft.block.BlockRedSandstone;
import net.minecraft.block.BlockRedstoneWire;
import net.minecraft.block.BlockReed;
import net.minecraft.block.BlockSand;
import net.minecraft.block.BlockSandStone;
import net.minecraft.block.BlockSapling;
import net.minecraft.block.BlockSilverfish;
import net.minecraft.block.BlockStem;
import net.minecraft.block.BlockStone;
import net.minecraft.block.BlockStoneBrick;
import net.minecraft.block.BlockStoneSlab;
import net.minecraft.block.BlockStoneSlab.EnumType;
import net.minecraft.block.BlockStoneSlabNew;
import net.minecraft.block.BlockStoneSlabNew.EnumType;
import net.minecraft.block.BlockTNT;
import net.minecraft.block.BlockTallGrass;
import net.minecraft.block.BlockTripWire;
import net.minecraft.block.BlockWall;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.block.statemap.BlockStateMapper;
import net.minecraft.client.renderer.block.statemap.IStateMapper;
import net.minecraft.client.renderer.block.statemap.StateMap.Builder;
import net.minecraft.client.renderer.block.statemap.StateMapperBase;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.model.IBakedModel;
import net.minecraft.client.resources.model.ModelManager;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.RegistryNamespacedDefaultedByKey;
import net.minecraft.util.ResourceLocation;

public class BlockModelShapes
{
  public void reloadModels()
  {
    ;
    ;
    bakedModelStore.clear();
    Exception llllllllllllllllllIIlllllllIllll = blockStateMapper.putAllStateModelLocations().entrySet().iterator();
    "".length();
    if ("  ".length() <= " ".length()) {
      return;
    }
    while (!lIlllIllIllI(llllllllllllllllllIIlllllllIllll.hasNext()))
    {
      Map.Entry<IBlockState, ModelResourceLocation> llllllllllllllllllIIllllllllIIlI = (Map.Entry)llllllllllllllllllIIlllllllIllll.next();
      "".length();
    }
  }
  
  private static boolean lIlllIllIIll(Object ???, Object arg1)
  {
    Object localObject;
    Exception llllllllllllllllllIIlllllIIlllIl;
    return ??? == localObject;
  }
  
  private static String lIllIIIllllI(String llllllllllllllllllIIllllllIlIIll, String llllllllllllllllllIIllllllIlIIlI)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIIllllllIllIII = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIIllllllIlIIlI.getBytes(StandardCharsets.UTF_8)), lllIlIllll[9]), "DES");
      Cipher llllllllllllllllllIIllllllIlIlll = Cipher.getInstance("DES");
      llllllllllllllllllIIllllllIlIlll.init(lllIlIllll[2], llllllllllllllllllIIllllllIllIII);
      return new String(llllllllllllllllllIIllllllIlIlll.doFinal(Base64.getDecoder().decode(llllllllllllllllllIIllllllIlIIll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIIllllllIlIllI)
    {
      llllllllllllllllllIIllllllIlIllI.printStackTrace();
    }
    return null;
  }
  
  private static boolean lIlllIllIllI(int ???)
  {
    float llllllllllllllllllIIlllllIIllIIl;
    return ??? == 0;
  }
  
  private static void lIllIIlIIIII()
  {
    llIlllIlII = new String[lllIlIllll[23]];
    llIlllIlII[lllIlIllll[0]] = lIllIIIlllIl("KTsCJi82Mwo3diY+AyAnN30cLy0qOR8cIyU5", "DRlCL");
    llIlllIlII[lllIlIllll[1]] = lIllIIIllllI("0K/VY3UfwEIBv7XGdAQ5TrKTr+LZnmhyzizYdFyO74s=", "keBcN");
    llIlllIlII[lllIlIllll[2]] = lIllIIIlllll("2ftiHgw9rMQ2b6aI+Y2T7EzTVP2foHY4VfAN16f5tzc=", "ejmvg");
    llIlllIlII[lllIlIllll[3]] = lIllIIIllllI("is5jIFIVe4BqPLwze/L0fWXufGmL4spGkRYp0Wxkzyk=", "sDtYR");
    llIlllIlII[lllIlIllll[4]] = lIllIIIlllIl("KB04FTs3FTAEYicYORMzNlslHy0pKyURNiE=", "EtVpX");
    llIlllIlII[lllIlIllll[5]] = lIllIIIlllIl("CyU3NgEULT8nWA84PD4RSS44IRAPKSs=", "fLYSb");
    llIlllIlII[lllIlIllll[7]] = lIllIIIlllll("wHVhnIjxNns=", "jZRjE");
    llIlllIlII[lllIlIllll[8]] = lIllIIIlllIl("FwUAJwEtGg==", "HieFw");
    llIlllIlII[lllIlIllll[9]] = lIllIIIlllll("28uK41RR/sc=", "yyZrt");
    llIlllIlII[lllIlIllll[10]] = lIllIIIlllll("2MJzrZ9nJoF2OY+ADH4y6A==", "VnYbv");
    llIlllIlII[lllIlIllll[11]] = lIllIIIlllIl("KgoUFQM=", "uyxta");
    llIlllIlII[lllIlIllll[12]] = lIllIIIlllIl("FS85PDs=", "JXVSW");
    llIlllIlII[lllIlIllll[13]] = lIllIIIllllI("u25ztq6RQQs=", "QrBlA");
    llIlllIlII[lllIlIllll[14]] = lIllIIIlllIl("FgEnBwAnFzc5ASgANwMHLBYMBQUoCw==", "IrSfi");
    llIlllIlII[lllIlIllll[15]] = lIllIIIlllll("tOhXQ479dtfiQ6MfChxmwWyLipVrjnMQ", "tEiQB");
    llIlllIlII[lllIlIllll[16]] = lIllIIIllllI("IW2kC5vRp1bVEHAwPq9Kvg==", "KTMxC");
    llIlllIlII[lllIlIllll[6]] = lIllIIIlllll("rduz2O2l94A=", "FeXsy");
    llIlllIlII[lllIlIllll[17]] = lIllIIIllllI("HZ0XZzSuR/Q=", "jaRzg");
    llIlllIlII[lllIlIllll[18]] = lIllIIIlllll("VUTh6iKs1DVnI4EnI3W/kA==", "QTeOb");
    llIlllIlII[lllIlIllll[19]] = lIllIIIllllI("f7coublm3uU=", "mETTA");
    llIlllIlII[lllIlIllll[20]] = lIllIIIlllIl("KAEpNg==", "wmFQf");
    llIlllIlII[lllIlIllll[21]] = lIllIIIlllIl("PTMDLhgJMA==", "bCoOv");
    llIlllIlII[lllIlIllll[22]] = lIllIIIlllll("US7+sUFyR3vm9Qv4W9eqKQ==", "EzHUm");
  }
  
  public BlockModelShapes(ModelManager llllllllllllllllllIlIIIIIIIlIlII)
  {
    modelManager = llllllllllllllllllIlIIIIIIIlIlII;
    llllllllllllllllllIlIIIIIIIlIlIl.registerAllBlocks();
  }
  
  private static boolean lIlllIllIlIl(Object ???)
  {
    char llllllllllllllllllIIlllllIIllIll;
    return ??? == null;
  }
  
  public IBakedModel getModelForState(IBlockState llllllllllllllllllIIlllllllllllI)
  {
    ;
    ;
    ;
    IBakedModel llllllllllllllllllIIllllllllllIl = (IBakedModel)bakedModelStore.get(llllllllllllllllllIIlllllllllllI);
    if (lIlllIllIlIl(llllllllllllllllllIIllllllllllIl)) {
      llllllllllllllllllIIllllllllllIl = modelManager.getMissingModel();
    }
    return llllllllllllllllllIIllllllllllIl;
  }
  
  public void registerBuiltInBlocks(Block... llllllllllllllllllIIlllllllIIIII)
  {
    ;
    ;
    blockStateMapper.registerBuiltInBlocks(llllllllllllllllllIIlllllllIIIII);
  }
  
  static
  {
    lIlllIllIIIl();
    lIllIIlIIIII();
  }
  
  private static boolean lIlllIllIlII(Object ???, Object arg1)
  {
    Object localObject;
    short llllllllllllllllllIIlllllIlIIIll;
    return ??? != localObject;
  }
  
  private static String lIllIIIlllll(String llllllllllllllllllIIlllllIlIlllI, String llllllllllllllllllIIlllllIlIllll)
  {
    try
    {
      ;
      ;
      ;
      ;
      SecretKeySpec llllllllllllllllllIIlllllIllIIll = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllllllIIlllllIlIllll.getBytes(StandardCharsets.UTF_8)), "Blowfish");
      Cipher llllllllllllllllllIIlllllIllIIlI = Cipher.getInstance("Blowfish");
      llllllllllllllllllIIlllllIllIIlI.init(lllIlIllll[2], llllllllllllllllllIIlllllIllIIll);
      return new String(llllllllllllllllllIIlllllIllIIlI.doFinal(Base64.getDecoder().decode(llllllllllllllllllIIlllllIlIlllI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
    }
    catch (Exception llllllllllllllllllIIlllllIllIIIl)
    {
      llllllllllllllllllIIlllllIllIIIl.printStackTrace();
    }
    return null;
  }
  
  public void registerBlockWithStateMapper(Block llllllllllllllllllIIlllllllIIlll, IStateMapper llllllllllllllllllIIlllllllIlIIl)
  {
    ;
    ;
    ;
    blockStateMapper.registerBlockStateMapper(llllllllllllllllllIIlllllllIlIlI, llllllllllllllllllIIlllllllIlIIl);
  }
  
  public TextureAtlasSprite getTexture(IBlockState llllllllllllllllllIlIIIIIIIIIlIl)
  {
    ;
    ;
    ;
    ;
    Block llllllllllllllllllIlIIIIIIIIlIII = llllllllllllllllllIlIIIIIIIIIlIl.getBlock();
    IBakedModel llllllllllllllllllIlIIIIIIIIIlll = llllllllllllllllllIlIIIIIIIIIllI.getModelForState(llllllllllllllllllIlIIIIIIIIIlIl);
    if ((!lIlllIllIIlI(llllllllllllllllllIlIIIIIIIIIlll)) || (lIlllIllIIll(llllllllllllllllllIlIIIIIIIIIlll, modelManager.getMissingModel())))
    {
      if ((!lIlllIllIlII(llllllllllllllllllIlIIIIIIIIlIII, Blocks.wall_sign)) || (!lIlllIllIlII(llllllllllllllllllIlIIIIIIIIlIII, Blocks.standing_sign)) || (!lIlllIllIlII(llllllllllllllllllIlIIIIIIIIlIII, Blocks.chest)) || (!lIlllIllIlII(llllllllllllllllllIlIIIIIIIIlIII, Blocks.trapped_chest)) || (!lIlllIllIlII(llllllllllllllllllIlIIIIIIIIlIII, Blocks.standing_banner)) || (lIlllIllIIll(llllllllllllllllllIlIIIIIIIIlIII, Blocks.wall_banner))) {
        return modelManager.getTextureMap().getAtlasSprite(llIlllIlII[lllIlIllll[0]]);
      }
      if (lIlllIllIIll(llllllllllllllllllIlIIIIIIIIlIII, Blocks.ender_chest)) {
        return modelManager.getTextureMap().getAtlasSprite(llIlllIlII[lllIlIllll[1]]);
      }
      if ((!lIlllIllIlII(llllllllllllllllllIlIIIIIIIIlIII, Blocks.flowing_lava)) || (lIlllIllIIll(llllllllllllllllllIlIIIIIIIIlIII, Blocks.lava))) {
        return modelManager.getTextureMap().getAtlasSprite(llIlllIlII[lllIlIllll[2]]);
      }
      if ((!lIlllIllIlII(llllllllllllllllllIlIIIIIIIIlIII, Blocks.flowing_water)) || (lIlllIllIIll(llllllllllllllllllIlIIIIIIIIlIII, Blocks.water))) {
        return modelManager.getTextureMap().getAtlasSprite(llIlllIlII[lllIlIllll[3]]);
      }
      if (lIlllIllIIll(llllllllllllllllllIlIIIIIIIIlIII, Blocks.skull)) {
        return modelManager.getTextureMap().getAtlasSprite(llIlllIlII[lllIlIllll[4]]);
      }
      if (lIlllIllIIll(llllllllllllllllllIlIIIIIIIIlIII, Blocks.barrier)) {
        return modelManager.getTextureMap().getAtlasSprite(llIlllIlII[lllIlIllll[5]]);
      }
    }
    if (lIlllIllIlIl(llllllllllllllllllIlIIIIIIIIIlll)) {
      llllllllllllllllllIlIIIIIIIIIlll = modelManager.getMissingModel();
    }
    return llllllllllllllllllIlIIIIIIIIIlll.getParticleTexture();
  }
  
  private static boolean lIlllIllIIlI(Object ???)
  {
    short llllllllllllllllllIIlllllIlIIIIl;
    return ??? != null;
  }
  
  private void registerAllBlocks()
  {
    ;
    llllllllllllllllllIIllllllIlllIl.registerBuiltInBlocks(new Block[] { Blocks.air, Blocks.flowing_water, Blocks.water, Blocks.flowing_lava, Blocks.lava, Blocks.piston_extension, Blocks.chest, Blocks.ender_chest, Blocks.trapped_chest, Blocks.standing_sign, Blocks.skull, Blocks.end_portal, Blocks.barrier, Blocks.wall_sign, Blocks.wall_banner, Blocks.standing_banner });
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.stone, new StateMap.Builder().withName(BlockStone.VARIANT).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.prismarine, new StateMap.Builder().withName(BlockPrismarine.VARIANT).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.leaves, new StateMap.Builder().withName(BlockOldLeaf.VARIANT).withSuffix(llIlllIlII[lllIlIllll[7]]).ignore(new IProperty[] { BlockLeaves.CHECK_DECAY, BlockLeaves.DECAYABLE }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.leaves2, new StateMap.Builder().withName(BlockNewLeaf.VARIANT).withSuffix(llIlllIlII[lllIlIllll[8]]).ignore(new IProperty[] { BlockLeaves.CHECK_DECAY, BlockLeaves.DECAYABLE }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.cactus, new StateMap.Builder().ignore(new IProperty[] { BlockCactus.AGE }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.reeds, new StateMap.Builder().ignore(new IProperty[] { BlockReed.AGE }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.jukebox, new StateMap.Builder().ignore(new IProperty[] { BlockJukebox.HAS_RECORD }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.command_block, new StateMap.Builder().ignore(new IProperty[] { BlockCommandBlock.TRIGGERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.cobblestone_wall, new StateMap.Builder().withName(BlockWall.VARIANT).withSuffix(llIlllIlII[lllIlIllll[9]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.double_plant, new StateMap.Builder().withName(BlockDoublePlant.VARIANT).ignore(new IProperty[] { BlockDoublePlant.field_181084_N }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.oak_fence_gate, new StateMap.Builder().ignore(new IProperty[] { BlockFenceGate.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.spruce_fence_gate, new StateMap.Builder().ignore(new IProperty[] { BlockFenceGate.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.birch_fence_gate, new StateMap.Builder().ignore(new IProperty[] { BlockFenceGate.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.jungle_fence_gate, new StateMap.Builder().ignore(new IProperty[] { BlockFenceGate.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.dark_oak_fence_gate, new StateMap.Builder().ignore(new IProperty[] { BlockFenceGate.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.acacia_fence_gate, new StateMap.Builder().ignore(new IProperty[] { BlockFenceGate.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.tripwire, new StateMap.Builder().ignore(new IProperty[] { BlockTripWire.DISARMED, BlockTripWire.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.double_wooden_slab, new StateMap.Builder().withName(BlockPlanks.VARIANT).withSuffix(llIlllIlII[lllIlIllll[10]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.wooden_slab, new StateMap.Builder().withName(BlockPlanks.VARIANT).withSuffix(llIlllIlII[lllIlIllll[11]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.tnt, new StateMap.Builder().ignore(new IProperty[] { BlockTNT.EXPLODE }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.fire, new StateMap.Builder().ignore(new IProperty[] { BlockFire.AGE }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.redstone_wire, new StateMap.Builder().ignore(new IProperty[] { BlockRedstoneWire.POWER }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.oak_door, new StateMap.Builder().ignore(new IProperty[] { BlockDoor.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.spruce_door, new StateMap.Builder().ignore(new IProperty[] { BlockDoor.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.birch_door, new StateMap.Builder().ignore(new IProperty[] { BlockDoor.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.jungle_door, new StateMap.Builder().ignore(new IProperty[] { BlockDoor.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.acacia_door, new StateMap.Builder().ignore(new IProperty[] { BlockDoor.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.dark_oak_door, new StateMap.Builder().ignore(new IProperty[] { BlockDoor.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.iron_door, new StateMap.Builder().ignore(new IProperty[] { BlockDoor.POWERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.wool, new StateMap.Builder().withName(BlockColored.COLOR).withSuffix(llIlllIlII[lllIlIllll[12]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.carpet, new StateMap.Builder().withName(BlockColored.COLOR).withSuffix(llIlllIlII[lllIlIllll[13]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.stained_hardened_clay, new StateMap.Builder().withName(BlockColored.COLOR).withSuffix(llIlllIlII[lllIlIllll[14]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.stained_glass_pane, new StateMap.Builder().withName(BlockColored.COLOR).withSuffix(llIlllIlII[lllIlIllll[15]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.stained_glass, new StateMap.Builder().withName(BlockColored.COLOR).withSuffix(llIlllIlII[lllIlIllll[16]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.sandstone, new StateMap.Builder().withName(BlockSandStone.TYPE).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.red_sandstone, new StateMap.Builder().withName(BlockRedSandstone.TYPE).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.tallgrass, new StateMap.Builder().withName(BlockTallGrass.TYPE).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.bed, new StateMap.Builder().ignore(new IProperty[] { BlockBed.OCCUPIED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.yellow_flower, new StateMap.Builder().withName(Blocks.yellow_flower.getTypeProperty()).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.red_flower, new StateMap.Builder().withName(Blocks.red_flower.getTypeProperty()).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.stone_slab, new StateMap.Builder().withName(BlockStoneSlab.VARIANT).withSuffix(llIlllIlII[lllIlIllll[6]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.stone_slab2, new StateMap.Builder().withName(BlockStoneSlabNew.VARIANT).withSuffix(llIlllIlII[lllIlIllll[17]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.monster_egg, new StateMap.Builder().withName(BlockSilverfish.VARIANT).withSuffix(llIlllIlII[lllIlIllll[18]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.stonebrick, new StateMap.Builder().withName(BlockStoneBrick.VARIANT).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.dispenser, new StateMap.Builder().ignore(new IProperty[] { BlockDispenser.TRIGGERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.dropper, new StateMap.Builder().ignore(new IProperty[] { BlockDropper.TRIGGERED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.log, new StateMap.Builder().withName(BlockOldLog.VARIANT).withSuffix(llIlllIlII[lllIlIllll[19]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.log2, new StateMap.Builder().withName(BlockNewLog.VARIANT).withSuffix(llIlllIlII[lllIlIllll[20]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.planks, new StateMap.Builder().withName(BlockPlanks.VARIANT).withSuffix(llIlllIlII[lllIlIllll[21]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.sapling, new StateMap.Builder().withName(BlockSapling.TYPE).withSuffix(llIlllIlII[lllIlIllll[22]]).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.sand, new StateMap.Builder().withName(BlockSand.VARIANT).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.hopper, new StateMap.Builder().ignore(new IProperty[] { BlockHopper.ENABLED }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.flower_pot, new StateMap.Builder().ignore(new IProperty[] { BlockFlowerPot.LEGACY_DATA }).build());
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.quartz_block, new StateMapperBase()
    {
      protected ModelResourceLocation getModelResourceLocation(IBlockState lllIllIlllIlI)
      {
        ;
        ;
        BlockQuartz.EnumType lllIllIlllIll = (BlockQuartz.EnumType)lllIllIlllIlI.getValue(BlockQuartz.VARIANT);
        switch ($SWITCH_TABLE$net$minecraft$block$BlockQuartz$EnumType()[lllIllIlllIll.ordinal()])
        {
        case 1: 
        default: 
          return new ModelResourceLocation(lIIIIIlIII[lIIIIIlIIl[0]], lIIIIIlIII[lIIIIIlIIl[1]]);
        case 2: 
          return new ModelResourceLocation(lIIIIIlIII[lIIIIIlIIl[2]], lIIIIIlIII[lIIIIIlIIl[3]]);
        case 3: 
          return new ModelResourceLocation(lIIIIIlIII[lIIIIIlIIl[4]], lIIIIIlIII[lIIIIIlIIl[5]]);
        case 4: 
          return new ModelResourceLocation(lIIIIIlIII[lIIIIIlIIl[6]], lIIIIIlIII[lIIIIIlIIl[7]]);
        }
        return new ModelResourceLocation(lIIIIIlIII[lIIIIIlIIl[8]], lIIIIIlIII[lIIIIIlIIl[9]]);
      }
      
      private static void llIlIIlIlII()
      {
        lIIIIIlIII = new String[lIIIIIlIIl[10]];
        lIIIIIlIII[lIIIIIlIIl[0]] = llIlIIlIIIl("DPlehpsqsIiZ1CEyvYsNzg==", "RiyiQ");
        lIIIIIlIII[lIIIIIlIIl[1]] = llIlIIlIIlI("HA0lNS0e", "rbWXL");
        lIIIIIlIII[lIIIIIlIIl[2]] = llIlIIlIIlI("DTEGGB0CPAs0CRs4HR8CMTsDBBsF", "nYokx");
        lIIIIIlIII[lIIIIIlIIl[3]] = llIlIIlIIll("mDF3Z8cwf4I=", "XsivX");
        lIIIIIlIII[lIIIIIlIIl[4]] = llIlIIlIIll("G6WygRXe5otCRRGYLjxizA==", "zlOEY");
        lIIIIIlIII[lIIIIIlIIl[5]] = llIlIIlIIIl("55PaiFBqlbI=", "yrNKd");
        lIIIIIlIII[lIIIIIlIIl[6]] = llIlIIlIIlI("ED4MISQbFA48PBQmAw==", "aKmSP");
        lIIIIIlIII[lIIIIIlIIl[7]] = llIlIIlIIll("MpYqGEd1eUA=", "rKeBV");
        lIIIIIlIII[lIIIIIlIIl[8]] = llIlIIlIIll("wEuhP3KGBebjQBK4qw8O2Q==", "legPO");
        lIIIIIlIII[lIIIIIlIIl[9]] = llIlIIlIIIl("BV3XYOaLw7Y=", "ARdzp");
      }
      
      private static boolean llIlIIlIllI(Object ???)
      {
        char lllIlIlllllll;
        return ??? != null;
      }
      
      private static String llIlIIlIIlI(String lllIllIlIllII, String lllIllIlIlIll)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        lllIllIlIllII = new String(Base64.getDecoder().decode(lllIllIlIllII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder lllIllIlIlIlI = new StringBuilder();
        char[] lllIllIlIlIIl = lllIllIlIlIll.toCharArray();
        int lllIllIlIlIII = lIIIIIlIIl[0];
        String lllIllIlIIIlI = lllIllIlIllII.toCharArray();
        char lllIllIlIIIIl = lllIllIlIIIlI.length;
        float lllIllIlIIIII = lIIIIIlIIl[0];
        while (llIlIIlIlll(lllIllIlIIIII, lllIllIlIIIIl))
        {
          char lllIllIlIllIl = lllIllIlIIIlI[lllIllIlIIIII];
          "".length();
          "".length();
          if (" ".length() == 0) {
            return null;
          }
        }
        return String.valueOf(lllIllIlIlIlI);
      }
      
      private static String llIlIIlIIll(String lllIllIIlIlll, String lllIllIIlIlII)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllIllIIllIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllIllIIlIlII.getBytes(StandardCharsets.UTF_8)), lIIIIIlIIl[8]), "DES");
          Cipher lllIllIIllIIl = Cipher.getInstance("DES");
          lllIllIIllIIl.init(lIIIIIlIIl[2], lllIllIIllIlI);
          return new String(lllIllIIllIIl.doFinal(Base64.getDecoder().decode(lllIllIIlIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllIllIIllIII)
        {
          lllIllIIllIII.printStackTrace();
        }
        return null;
      }
      
      private static void llIlIIlIlIl()
      {
        lIIIIIlIIl = new int[11];
        lIIIIIlIIl[0] = ((0x0 ^ 0x28) & (0x57 ^ 0x7F ^ 0xFFFFFFFF));
        lIIIIIlIIl[1] = " ".length();
        lIIIIIlIIl[2] = "  ".length();
        lIIIIIlIIl[3] = "   ".length();
        lIIIIIlIIl[4] = (0x5 ^ 0x1);
        lIIIIIlIIl[5] = (0xA7 ^ 0x8B ^ 0xB1 ^ 0x98);
        lIIIIIlIIl[6] = (0xD5 ^ 0xA4 ^ 0x67 ^ 0x10);
        lIIIIIlIIl[7] = (25 + 63 - 30 + 82 ^ 51 + 25 - -17 + 46);
        lIIIIIlIIl[8] = (0x3D ^ 0x35);
        lIIIIIlIIl[9] = (32 + 57 - -34 + 32 ^ 46 + 91 - 78 + 87);
        lIIIIIlIIl[10] = (0x9F ^ 0xA6 ^ 0xA0 ^ 0x93);
      }
      
      private static boolean llIlIIlIlll(int ???, int arg1)
      {
        int i;
        char lllIllIIIIIIl;
        return ??? < i;
      }
      
      static
      {
        llIlIIlIlIl();
        llIlIIlIlII();
      }
      
      private static String llIlIIlIIIl(String lllIllIIIlIII, String lllIllIIIlIIl)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllIllIIIllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllIllIIIlIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher lllIllIIIllII = Cipher.getInstance("Blowfish");
          lllIllIIIllII.init(lIIIIIlIIl[2], lllIllIIIllIl);
          return new String(lllIllIIIllII.doFinal(Base64.getDecoder().decode(lllIllIIIlIII.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllIllIIIlIll)
        {
          lllIllIIIlIll.printStackTrace();
        }
        return null;
      }
    });
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.deadbush, new StateMapperBase()
    {
      private static String llIIlllIllllIl(String llllllllllllllIlIlIIllIIIlIIIlIl, String llllllllllllllIlIlIIllIIIlIIIllI)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllIlIlIIllIIIlIIlIlI = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIIllIIIlIIIllI.getBytes(StandardCharsets.UTF_8)), lIIIIlllIllII[3]), "DES");
          Cipher llllllllllllllIlIlIIllIIIlIIlIIl = Cipher.getInstance("DES");
          llllllllllllllIlIlIIllIIIlIIlIIl.init(lIIIIlllIllII[2], llllllllllllllIlIlIIllIIIlIIlIlI);
          return new String(llllllllllllllIlIlIIllIIIlIIlIIl.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIIllIIIlIIIlIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllIlIlIIllIIIlIIlIII)
        {
          llllllllllllllIlIlIIllIIIlIIlIII.printStackTrace();
        }
        return null;
      }
      
      protected ModelResourceLocation getModelResourceLocation(IBlockState llllllllllllllIlIlIIllIIIlIIllll)
      {
        return new ModelResourceLocation(lIIIIlllIlIlI[lIIIIlllIllII[0]], lIIIIlllIlIlI[lIIIIlllIllII[1]]);
      }
      
      private static void llIIlllIllllll()
      {
        lIIIIlllIlIlI = new String[lIIIIlllIllII[2]];
        lIIIIlllIlIlI[lIIIIlllIllII[0]] = llIIlllIllllIl("dMZN2b7/Ilx+P2PdAnWfdA==", "pLwfJ");
        lIIIIlllIlIlI[lIIIIlllIllII[1]] = llIIlllIlllllI("ugtFcTBiEdc=", "ZoHDN");
      }
      
      private static String llIIlllIlllllI(String llllllllllllllIlIlIIllIIIIlllIlI, String llllllllllllllIlIlIIllIIIIlllIIl)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllIlIlIIllIIIIllllIl = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIIllIIIIlllIIl.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher llllllllllllllIlIlIIllIIIIllllII = Cipher.getInstance("Blowfish");
          llllllllllllllIlIlIIllIIIIllllII.init(lIIIIlllIllII[2], llllllllllllllIlIlIIllIIIIllllIl);
          return new String(llllllllllllllIlIlIIllIIIIllllII.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIIllIIIIlllIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllIlIlIIllIIIIlllIll)
        {
          llllllllllllllIlIlIIllIIIIlllIll.printStackTrace();
        }
        return null;
      }
      
      static
      {
        llIIllllIIIlII();
        llIIlllIllllll();
      }
      
      private static void llIIllllIIIlII()
      {
        lIIIIlllIllII = new int[4];
        lIIIIlllIllII[0] = ((0x20 ^ 0x6 ^ 0xAB ^ 0x92) & (0x61 ^ 0x20 ^ 0x26 ^ 0x78 ^ -" ".length()));
        lIIIIlllIllII[1] = " ".length();
        lIIIIlllIllII[2] = "  ".length();
        lIIIIlllIllII[3] = (0xCC ^ 0xC4);
      }
    });
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.pumpkin_stem, new StateMapperBase()
    {
      protected ModelResourceLocation getModelResourceLocation(IBlockState llllllllllllllIlIlIIlIIIIIIllllI)
      {
        ;
        ;
        ;
        Map<IProperty, Comparable> llllllllllllllIlIlIIlIIIIIIlllIl = Maps.newLinkedHashMap(llllllllllllllIlIlIIlIIIIIIllllI.getProperties());
        if (llIlIIIIlIIIlI(llllllllllllllIlIlIIlIIIIIIllllI.getValue(BlockStem.FACING), EnumFacing.UP)) {
          "".length();
        }
        return new ModelResourceLocation((ResourceLocation)Block.blockRegistry.getNameForObject(llllllllllllllIlIlIIlIIIIIIllllI.getBlock()), llllllllllllllIlIlIIlIIIIIIlllll.getPropertyString(llllllllllllllIlIlIIlIIIIIIlllIl));
      }
      
      private static boolean llIlIIIIlIIIlI(Object ???, Object arg1)
      {
        Object localObject;
        long llllllllllllllIlIlIIlIIIIIIlIllI;
        return ??? != localObject;
      }
    });
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.melon_stem, new StateMapperBase()
    {
      private static boolean llIIlIIIIII(Object ???, Object arg1)
      {
        Object localObject;
        Exception lIIIlIIIIlIIlI;
        return ??? != localObject;
      }
      
      protected ModelResourceLocation getModelResourceLocation(IBlockState lIIIlIIIlIIIlI)
      {
        ;
        ;
        ;
        Map<IProperty, Comparable> lIIIlIIIlIIlIl = Maps.newLinkedHashMap(lIIIlIIIlIIIlI.getProperties());
        if (llIIlIIIIII(lIIIlIIIlIIIlI.getValue(BlockStem.FACING), EnumFacing.UP)) {
          "".length();
        }
        return new ModelResourceLocation((ResourceLocation)Block.blockRegistry.getNameForObject(lIIIlIIIlIIIlI.getBlock()), lIIIlIIIlIIlll.getPropertyString(lIIIlIIIlIIlIl));
      }
    });
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.dirt, new StateMapperBase()
    {
      protected ModelResourceLocation getModelResourceLocation(IBlockState lllllllllllllllIlIIlIIIIllIlIIIl)
      {
        ;
        ;
        ;
        ;
        Map<IProperty, Comparable> lllllllllllllllIlIIlIIIIllIlIlII = Maps.newLinkedHashMap(lllllllllllllllIlIIlIIIIllIlIIIl.getProperties());
        String lllllllllllllllIlIIlIIIIllIlIIll = BlockDirt.VARIANT.getName((BlockDirt.DirtType)lllllllllllllllIlIIlIIIIllIlIlII.remove(BlockDirt.VARIANT));
        if (lIIIIIIIIlIllI(BlockDirt.DirtType.PODZOL, lllllllllllllllIlIIlIIIIllIlIIIl.getValue(BlockDirt.VARIANT))) {
          "".length();
        }
        return new ModelResourceLocation(lllllllllllllllIlIIlIIIIllIlIIll, lllllllllllllllIlIIlIIIIllIlIllI.getPropertyString(lllllllllllllllIlIIlIIIIllIlIlII));
      }
      
      private static boolean lIIIIIIIIlIllI(Object ???, Object arg1)
      {
        Object localObject;
        float lllllllllllllllIlIIlIIIIllIIlIll;
        return ??? != localObject;
      }
    });
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.double_stone_slab, new StateMapperBase()
    {
      private static String lIIlIllllIIl(String lllllllllllllllllllIlllIIlIIIIII, String lllllllllllllllllllIlllIIIllllll)
      {
        ;
        ;
        ;
        ;
        ;
        ;
        lllllllllllllllllllIlllIIlIIIIII = new String(Base64.getDecoder().decode(lllllllllllllllllllIlllIIlIIIIII.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
        StringBuilder lllllllllllllllllllIlllIIIllllIl = new StringBuilder();
        char[] lllllllllllllllllllIlllIIIllllII = lllllllllllllllllllIlllIIIllllll.toCharArray();
        int lllllllllllllllllllIlllIIIlllIlI = llIIIIIllI[0];
        short lllllllllllllllllllIlllIIIllIlII = lllllllllllllllllllIlllIIlIIIIII.toCharArray();
        byte lllllllllllllllllllIlllIIIllIIll = lllllllllllllllllllIlllIIIllIlII.length;
        int lllllllllllllllllllIlllIIIllIIlI = llIIIIIllI[0];
        while (lIIllIlIlIII(lllllllllllllllllllIlllIIIllIIlI, lllllllllllllllllllIlllIIIllIIll))
        {
          char lllllllllllllllllllIlllIIlIIllll = lllllllllllllllllllIlllIIIllIlII[lllllllllllllllllllIlllIIIllIIlI];
          "".length();
          "".length();
          if (null != null) {
            return null;
          }
        }
        return String.valueOf(lllllllllllllllllllIlllIIIllllIl);
      }
      
      private static void lIIlIllllIll()
      {
        lIlllllIll = new String[llIIIIIllI[3]];
        lIlllllIll[llIIIIIllI[0]] = lIIlIllllIII("+LCp0YrX0DU=", "qigta");
        lIlllllIll[llIIIIIllI[1]] = lIIlIllllIIl("BgA3CzcE", "hoEfV");
        lIlllllIll[llIIIIIllI[2]] = lIIlIllllIlI("fCz+qsGVXkONaB3TCI/4Zw==", "KlcRS");
      }
      
      private static void lIIllIIllIlI()
      {
        llIIIIIllI = new int[5];
        llIIIIIllI[0] = (('' + '¢' - 247 + 112 ^ 120 + 45 - 95 + 107) & (0x65 ^ 0x5B ^ 0x8 ^ 0x20 ^ -" ".length()));
        llIIIIIllI[1] = " ".length();
        llIIIIIllI[2] = "  ".length();
        llIIIIIllI[3] = "   ".length();
        llIIIIIllI[4] = (0x1A ^ 0x12);
      }
      
      private static String lIIlIllllIlI(String lllllllllllllllllllIlllIIIlIIIlI, String lllllllllllllllllllIlllIIIlIIIll)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllllllllllllllllllIlllIIIlIIlll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIlllIIIlIIIll.getBytes(StandardCharsets.UTF_8)), llIIIIIllI[4]), "DES");
          Cipher lllllllllllllllllllIlllIIIlIIllI = Cipher.getInstance("DES");
          lllllllllllllllllllIlllIIIlIIllI.init(llIIIIIllI[2], lllllllllllllllllllIlllIIIlIIlll);
          return new String(lllllllllllllllllllIlllIIIlIIllI.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIlllIIIlIIIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllllllllllllllllllIlllIIIlIIlIl)
        {
          lllllllllllllllllllIlllIIIlIIlIl.printStackTrace();
        }
        return null;
      }
      
      static
      {
        lIIllIIllIlI();
        lIIlIllllIll();
      }
      
      private static boolean lIIllIlIlIII(int ???, int arg1)
      {
        int i;
        int lllllllllllllllllllIllIlllllllIl;
        return ??? < i;
      }
      
      protected ModelResourceLocation getModelResourceLocation(IBlockState lllllllllllllllllllIlllIIllIIlll)
      {
        ;
        ;
        ;
        ;
        Map<IProperty, Comparable> lllllllllllllllllllIlllIIllIIllI = Maps.newLinkedHashMap(lllllllllllllllllllIlllIIllIIlll.getProperties());
        String lllllllllllllllllllIlllIIllIIlIl = BlockStoneSlab.VARIANT.getName((BlockStoneSlab.EnumType)lllllllllllllllllllIlllIIllIIllI.remove(BlockStoneSlab.VARIANT));
        "".length();
        if (lIIllIIlllII(((Boolean)lllllllllllllllllllIlllIIllIIIll.getValue(BlockStoneSlab.SEAMLESS)).booleanValue()))
        {
          "".length();
          if (-"  ".length() <= 0) {
            break label100;
          }
          return null;
        }
        label100:
        String lllllllllllllllllllIlllIIllIIlII = lIlllllIll[llIIIIIllI[1]];
        return new ModelResourceLocation(String.valueOf(new StringBuilder(String.valueOf(lllllllllllllllllllIlllIIllIIlIl)).append(lIlllllIll[llIIIIIllI[2]])), lllllllllllllllllllIlllIIllIIlII);
      }
      
      private static boolean lIIllIIlllII(int ???)
      {
        byte lllllllllllllllllllIllIllllllIll;
        return ??? != 0;
      }
      
      private static String lIIlIllllIII(String lllllllllllllllllllIlllIIIIIlIIl, String lllllllllllllllllllIlllIIIIIlIII)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec lllllllllllllllllllIlllIIIIIllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(lllllllllllllllllllIlllIIIIIlIII.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher lllllllllllllllllllIlllIIIIIlIll = Cipher.getInstance("Blowfish");
          lllllllllllllllllllIlllIIIIIlIll.init(llIIIIIllI[2], lllllllllllllllllllIlllIIIIIllII);
          return new String(lllllllllllllllllllIlllIIIIIlIll.doFinal(Base64.getDecoder().decode(lllllllllllllllllllIlllIIIIIlIIl.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception lllllllllllllllllllIlllIIIIIlIlI)
        {
          lllllllllllllllllllIlllIIIIIlIlI.printStackTrace();
        }
        return null;
      }
    });
    llllllllllllllllllIIllllllIllllI.registerBlockWithStateMapper(Blocks.double_stone_slab2, new StateMapperBase()
    {
      private static String llIIllIIlIlIIl(String llllllllllllllIlIlIlIlllIIlIlIlI, String llllllllllllllIlIlIlIlllIIlIlIIl)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllIlIlIlIlllIIlIllll = new SecretKeySpec(Arrays.copyOf(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIlIlllIIlIlIIl.getBytes(StandardCharsets.UTF_8)), lIIIIlIlllIll[4]), "DES");
          Cipher llllllllllllllIlIlIlIlllIIlIlllI = Cipher.getInstance("DES");
          llllllllllllllIlIlIlIlllIIlIlllI.init(lIIIIlIlllIll[2], llllllllllllllIlIlIlIlllIIlIllll);
          return new String(llllllllllllllIlIlIlIlllIIlIlllI.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIlIlllIIlIlIlI.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllIlIlIlIlllIIlIllIl)
        {
          llllllllllllllIlIlIlIlllIIlIllIl.printStackTrace();
        }
        return null;
      }
      
      private static boolean llIIllIIlIllIl(int ???)
      {
        char llllllllllllllIlIlIlIlllIIlIIlIl;
        return ??? != 0;
      }
      
      protected ModelResourceLocation getModelResourceLocation(IBlockState llllllllllllllIlIlIlIlllIlIIlIII)
      {
        ;
        ;
        ;
        ;
        Map<IProperty, Comparable> llllllllllllllIlIlIlIlllIlIIIlll = Maps.newLinkedHashMap(llllllllllllllIlIlIlIlllIlIIlIII.getProperties());
        String llllllllllllllIlIlIlIlllIlIIIllI = BlockStoneSlabNew.VARIANT.getName((BlockStoneSlabNew.EnumType)llllllllllllllIlIlIlIlllIlIIIlll.remove(BlockStoneSlabNew.VARIANT));
        "".length();
        if (llIIllIIlIllIl(((Boolean)llllllllllllllIlIlIlIlllIlIIIlII.getValue(BlockStoneSlabNew.SEAMLESS)).booleanValue()))
        {
          "".length();
          if ("   ".length() > 0) {
            break label99;
          }
          return null;
        }
        label99:
        String llllllllllllllIlIlIlIlllIlIIIlIl = lIIIIlIlllIlI[lIIIIlIlllIll[1]];
        return new ModelResourceLocation(String.valueOf(new StringBuilder(String.valueOf(llllllllllllllIlIlIlIlllIlIIIllI)).append(lIIIIlIlllIlI[lIIIIlIlllIll[2]])), llllllllllllllIlIlIlIlllIlIIIlIl);
      }
      
      private static String llIIllIIlIlIlI(String llllllllllllllIlIlIlIlllIIllIlll, String llllllllllllllIlIlIlIlllIIllIllI)
      {
        try
        {
          ;
          ;
          ;
          ;
          SecretKeySpec llllllllllllllIlIlIlIlllIIllllII = new SecretKeySpec(MessageDigest.getInstance("MD5").digest(llllllllllllllIlIlIlIlllIIllIllI.getBytes(StandardCharsets.UTF_8)), "Blowfish");
          Cipher llllllllllllllIlIlIlIlllIIlllIll = Cipher.getInstance("Blowfish");
          llllllllllllllIlIlIlIlllIIlllIll.init(lIIIIlIlllIll[2], llllllllllllllIlIlIlIlllIIllllII);
          return new String(llllllllllllllIlIlIlIlllIIlllIll.doFinal(Base64.getDecoder().decode(llllllllllllllIlIlIlIlllIIllIlll.getBytes(StandardCharsets.UTF_8))), StandardCharsets.UTF_8);
        }
        catch (Exception llllllllllllllIlIlIlIlllIIlllIlI)
        {
          llllllllllllllIlIlIlIlllIIlllIlI.printStackTrace();
        }
        return null;
      }
      
      private static void llIIllIIlIlIll()
      {
        lIIIIlIlllIlI = new String[lIIIIlIlllIll[3]];
        lIIIIlIlllIlI[lIIIIlIlllIll[0]] = llIIllIIlIlIIl("IxpW8xnuJoo=", "hIghB");
        lIIIIlIlllIlI[lIIIIlIlllIll[1]] = llIIllIIlIlIlI("1tGPtSY9Bm4=", "JgYlC");
        lIIIIlIlllIlI[lIIIIlIlllIll[2]] = llIIllIIlIlIlI("0tEZXuIcCRIflmaZ87V6Sg==", "arIfS");
      }
      
      static
      {
        llIIllIIlIllII();
        llIIllIIlIlIll();
      }
      
      private static void llIIllIIlIllII()
      {
        lIIIIlIlllIll = new int[5];
        lIIIIlIlllIll[0] = ((0x71 ^ 0x34) & (0x43 ^ 0x6 ^ 0xFFFFFFFF));
        lIIIIlIlllIll[1] = " ".length();
        lIIIIlIlllIll[2] = "  ".length();
        lIIIIlIlllIll[3] = "   ".length();
        lIIIIlIlllIll[4] = (21 + 106 - 107 + 108 ^ 83 + 70 - 49 + 32);
      }
    });
  }
  
  private static String lIllIIIlllIl(String llllllllllllllllllIIllllllIIIlIl, String llllllllllllllllllIIlllllIllllll)
  {
    ;
    ;
    ;
    ;
    ;
    ;
    llllllllllllllllllIIllllllIIIlIl = new String(Base64.getDecoder().decode(llllllllllllllllllIIllllllIIIlIl.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8);
    StringBuilder llllllllllllllllllIIllllllIIIIll = new StringBuilder();
    char[] llllllllllllllllllIIllllllIIIIlI = llllllllllllllllllIIlllllIllllll.toCharArray();
    int llllllllllllllllllIIllllllIIIIIl = lllIlIllll[0];
    Exception llllllllllllllllllIIlllllIlllIll = llllllllllllllllllIIllllllIIIlIl.toCharArray();
    long llllllllllllllllllIIlllllIlllIlI = llllllllllllllllllIIlllllIlllIll.length;
    byte llllllllllllllllllIIlllllIlllIIl = lllIlIllll[0];
    while (lIlllIlllIlI(llllllllllllllllllIIlllllIlllIIl, llllllllllllllllllIIlllllIlllIlI))
    {
      char llllllllllllllllllIIllllllIIIllI = llllllllllllllllllIIlllllIlllIll[llllllllllllllllllIIlllllIlllIIl];
      "".length();
      "".length();
      if (((0x11 ^ 0x59) & (0xEB ^ 0xA3 ^ 0xFFFFFFFF)) > "   ".length()) {
        return null;
      }
    }
    return String.valueOf(llllllllllllllllllIIllllllIIIIll);
  }
  
  public BlockStateMapper getBlockStateMapper()
  {
    ;
    return blockStateMapper;
  }
  
  private static void lIlllIllIIIl()
  {
    lllIlIllll = new int[24];
    lllIlIllll[0] = ((121 + 31 - 41 + 22 ^ 103 + 127 - 197 + 106) & (0x1E ^ 0x4D ^ 0xFD ^ 0xA0 ^ -" ".length()));
    lllIlIllll[1] = " ".length();
    lllIlIllll[2] = "  ".length();
    lllIlIllll[3] = "   ".length();
    lllIlIllll[4] = (0x4F ^ 0x4 ^ 0x15 ^ 0x5A);
    lllIlIllll[5] = (0x48 ^ 0x4D);
    lllIlIllll[6] = (18 + '' - 154 + 142 ^ 38 + 70 - 105 + 131);
    lllIlIllll[7] = (0xE8 ^ 0x86 ^ 0x5 ^ 0x6D);
    lllIlIllll[8] = (0xB4 ^ 0xB3);
    lllIlIllll[9] = (0x25 ^ 0x2D);
    lllIlIllll[10] = (0x5E ^ 0x1A ^ 0x88 ^ 0xC5);
    lllIlIllll[11] = (0x12 ^ 0x18);
    lllIlIllll[12] = (17 + 88 - 4 + 57 ^ '' + 76 - 82 + 14);
    lllIlIllll[13] = ('' + '´' - 200 + 71 ^ 109 + 126 - 143 + 89);
    lllIlIllll[14] = (0x65 ^ 0x68);
    lllIlIllll[15] = (16 + 44 - 53 + 130 ^ 63 + 12 - -24 + 36);
    lllIlIllll[16] = (0x8A ^ 0x8D ^ 0xAB ^ 0xA3);
    lllIlIllll[17] = (0x3E ^ 0x44 ^ 0xC7 ^ 0xAC);
    lllIlIllll[18] = (0x65 ^ 0x77);
    lllIlIllll[19] = (0xC2 ^ 0x87 ^ 0xE8 ^ 0xBE);
    lllIlIllll[20] = (0x81 ^ 0x95);
    lllIlIllll[21] = (0x68 ^ 0x64 ^ 0x35 ^ 0x2C);
    lllIlIllll[22] = (52 + 40 - -2 + 89 ^ 77 + 125 - 110 + 69);
    lllIlIllll[23] = (0xC0 ^ 0x9F ^ 0x32 ^ 0x7A);
  }
  
  private static boolean lIlllIlllIlI(int ???, int arg1)
  {
    int i;
    short llllllllllllllllllIIlllllIlIIlll;
    return ??? < i;
  }
  
  public ModelManager getModelManager()
  {
    ;
    return modelManager;
  }
}
